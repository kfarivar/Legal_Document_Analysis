# "BSG" v R [2023] EWCA Crim 1041

Court of Appeal, Criminal Division

The Vice-President of the Court of Appeal, Criminal Division, Lord Justice Holroyde, Mr Justice Goose and Sir
Robin Spencer

12 September 2023Judgment

**Stephen Knight (instructed by Bhatt Murphy Solicitors) for the Applicant**

**Andrew Johnson (instructed by CPS Appeals and Review Unit) for the Respondent**

Hearing date: 20 July 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

WARNING: the applicant is entitled to anonymity, and reporting restrictions apply to the contents transcribed in this
document, as stated in paragraph 2 of the judgment. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

.

**Lord Justice Holroyde:**

1. This applicant, now aged 24, pleaded guilty to drugs offences committed when he was a teenager, and
was sentenced in 2017 to terms of detention. He now makes applications to this court on the basis that at
the time of the offending, he was a victim of trafficking or modern slavery (for convenience, a “VMS”).

2. The applicant further applies for an order granting him anonymity in these proceedings. We have
considered the principles stated by this court in _R v L_ _[[2017] EWCA Crim 2129 at [9-15]. We bear very](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
much in mind the importance of the principle of open justice. We are however satisfied that it is necessary
and appropriate to make an order for anonymity. As will become apparent, the applicant has been
recognised by the Single Competent Authority (“SCA”) as a VMS, and we accept that there is a real risk
that he will be subject to reprisals and/or to further trafficking if his true identity is revealed. Moreover,
issues which in some respect overlap with the issues before this court have also arisen in proceedings
before the First-tier Tribunal (Immigration and Asylum Chamber) (“the FTT”). An order for the applicant's
anonymity was made in those proceedings. The purpose of that order would be defeated if he were
identified in these applications. We therefore grant the applicant anonymity in these proceedings. We
order, pursuant to s11 of the Contempt of Court Act 1981, that in any report of these proceedings the
applicant must not be named, and should be referred to only by the randomly-chosen letters “BSG”.


-----

3. We are grateful to counsel – Mr Knight for the applicant and Mr Johnson for the respondent – for their
written and oral submissions. At the conclusion of the hearing on 20 July 2023 we reserved judgment and
indicated that we would give our decision and our reasons in writing. This we now do.

**The relevant events:**

4. We omit from this summary details which may undermine the anonymity order.

5. The applicant, a native of Somalia, came to this country as a child. His mother claimed asylum for
herself and her son. The applicant was initially granted leave to remain as a refugee. In 2013 he was
granted indefinite leave to remain.

6. In March 2016 the applicant, then aged 17, was arrested in possession of Class A drugs. This arrest
gave rise to charges of possession with intent to supply of heroin and cocaine (“the Aylesbury offences”).
The applicant made no comment when interviewed under caution. He was released on bail.

7. In July 2016 the applicant was arrested, again in possession of heroin and cocaine and involved with
others in a “cuckooing” operation in the home of a vulnerable drug user. This arrest gave rise to two
further charges of possession with intent to supply of Class A controlled drugs (“the Canterbury offences”).
He again made no comment in interview, and was again released on bail.

8. The applicant was further interviewed about the Aylesbury offences. For the most part, he made no
comment; but he said that he had been “forced” to do what he did and had received a threatening text
message.

9. In December 2016 the applicant pleaded guilty to the Aylesbury offences before a youth court, and was
committed to the Crown Court at Aylesbury for sentence. In February 2017 he was sentenced to a total of
28 months' detention.

10. The Criminal Appeal Office, for whose vigilance we are as always grateful, has drawn to our attention
that two errors were made in those proceedings. First, the Memorandum wrongly recorded the statutory
power under which the applicant had been committed for sentence. In another part of the same document,
however, the committal was correctly noted as having been made pursuant to s3B of the Powers of
[Criminal Courts (Sentencing) Act 2000 (“PCC(S)A 2000”). We are satisfied that the error in the record](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1DG-00000-00&context=1519360)
does not invalidate the committal for sentence.

11. Secondly, the judge variously referred to the sentence as being one of imprisonment, and one of
detention in a Young Offender Institution (“YOI”). Neither of those sentences could lawfully be imposed, as
the applicant was aged 17 at the date of his conviction.

12. Later in February 2017, in the Crown Court at Canterbury, the applicant pleaded guilty to the
Canterbury offences. Sentence was adjourned, the judge understandably expressing her disappointment
that no attempt had been made to link the proceedings in order to deal with the Aylesbury and Canterbury
offences at the same time.

13. In December 2017 the applicant was sentenced for the Canterbury offences to a total of 24 months'
detention in a YOI. He subsequently applied for leave to appeal against that sentence, on grounds of
totality. His written grounds of appeal asserted that he had been groomed by a drug gang to sell drugs for
them, and had committed the Canterbury offences because he was in debt to that gang following the
seizing by the police of the drugs in his possession in March 2016. The application was refused on the
papers by the single judge, and was not renewed.

14. Pausing there, this appeal hearing is concerned only with the criminal proceedings in relation to the
Aylesbury and Canterbury offences. It is, however, necessary to refer to some later events and criminal
proceedings.

15. The applicant was released on licence in December 2018. In June 2019 he was notified of decisions
by the Secretary of State to revoke his protection status and refuse his claim for asylum, and was served
with a deportation order.


-----

16. In the autumn of 2019 the applicant was recalled to custody for 28 days because he had failed to
comply with his licence conditions.

17. In November 2019 the Salvation Army referred the applicant through the National Referral Mechanism
(“NRM”) to the SCA. In March 2020 the SCA made a positive Reasonable Grounds decision in the
applicant's favour.

18. In the spring of 2020, the applicant was arrested at a property in which Class A drugs were found. So
far as we are aware, that matter remains under investigation, and no charges have been brought.

19. In July 2020, the applicant was arrested and charged with conspiracy to supply controlled drugs of
Class A. In March 2021, in the Crown Court at Snaresbrook, he pleaded guilty to conspiracy to supply
heroin and cocaine (“the Snaresbrook offence”). His sentencing was adjourned to await the outcome of
prosecutions of other alleged conspirators.

20. In July 2021 the SCA made a Conclusive Grounds decision that, on the balance of probabilities, the
applicant was a victim of modern slavery in the UK during the period between March and July 2016 “for
the specific purposes of forced criminality”. That decision, of course, relates to the period when the
Aylesbury and Canterbury offences were committed.

21. In February 2022 the SCA made a positive Reasonable Grounds decision in relation to the period
when the Snaresbrook offence was committed.

22. In the following month, the applicant appealed successfully to the FTT against the decision of the
Secretary of State revoking his refugee status. The applicant gave evidence and was cross-examined.
His appeal was allowed on asylum and human rights grounds. The judge of the FTT found that the
applicant was a credible witness, whose oral evidence was consistent with the available documentary
evidence; that he had committed the Aylesbury and Canterbury offences at a time when he had been a
VMS; and that the period from December 2019 to January 2020 was a continuation of his forced
criminality.

23. Later in 2022, the applicant put forward an amended written basis of his plea to the Snaresbrook
offence. In summary, he asserted that he had left home in 2016 aged 17 and had come into contact with a
man (to whom we shall refer as “X”), who had offered him accommodation and an easy way to earn
money. He had been selling drugs for X when arrested in March 2016. He was then told by X that he
would have to replace the drugs and money which the police had seized from him, and the only way he
could do so was by continuing to work for X. He was accordingly selling drugs for X when arrested in July
2016. Following that arrest, he had tried to sever his connection with X; but when he was released from
prison after his recall in 2019 he was told that he was still in debt to X. In order to repay that debt he had
agreed to take part in selling drugs, and had held a drugs line phone for 2 months. He cleared his debt,
declined an invitation to continue working for X, and obtained legitimate employment. The applicant
therefore asserted that his involvement in the Snaresbrook offence stemmed back to the events in 2016.

24. That basis of plea was disputed by the prosecution, and a _Newton hearing was held in September_
2022. The applicant did not pursue those parts of his written basis of plea which asserted his status as a
VMS. In giving evidence, he declined to answer questions as to the circumstances in which he had
become involved in the Snaresbrook offence. He did, however, argue successfully that his involvement in
that offence was limited to the period between December 2019 and January 2020, and not the longer
period alleged by the prosecution.

25. In late April 2023 the applicant was sentenced for the Snaresbrook offence to imprisonment for 5 years
3 months.  He has subsequently been released on licence from that sentence.

**The applications to this court:**

26. The applicant applies for extensions of time (in excess of five years) to make the following
applications: in relation to the Aylesbury offences, for leave to appeal against his sentence; and in relation
to the Canterbury offences, for leave to appeal against his convictions, to renew his application for leave to
appeal against sentence and to vary his grounds of appeal against sentence in order to rely on the fact that


-----

[he is a VMS. He also applies pursuant to s23 of the Criminal Appeal Act 1968 (“CAA 1968”) for leave to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1P8-00000-00&context=1519360)
adduce fresh evidence in support of his case that he has at all material times been a VMS.

27. Each of the applications is opposed by the respondent. They have all been referred to the full court by
the Registrar.

28. We understand that the applicant is making a separate application to the Criminal Cases Review
Commission (“CCRC”) in relation to the convictions for the Aylesbury offences.

29. There is no application before this court in relation to the Snaresbrook offence.

**The grounds of appeal:**

30. Although it has been necessary to set out the chronology at some length, the grounds of appeal and
the issues before this court can be summarised briefly.

31. The ground of appeal against the convictions for the Canterbury offences is that the applicant was a
child VMS who should not have been prosecuted, and that it was an abuse of the process to prosecute
him. The **_[Modern Slavery Act 2015 (“MSA 2015”) came into force on 31 July 2015, before any of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
applicant's arrests. It is submitted that the police failed in their duty under s52 of that Act to refer the
applicant into the NRM, despite his having been arrested with older known criminals in circumstances
which suggested he may be a child VMS, and despite his having said in interview that he was “forced”. It
is further submitted that his legal representatives failed to advise him of the possibility of a defence under
s45 of MSA 2015, despite his having given instructions consistent with such a defence. Reliance is placed
on the SCA's finding that the applicant was a child VMS, which it is submitted is determinative of the
applicant's status, and on the decision of the FTT. It is submitted that there is no reason to go behind
those decisions. Mr Knight accordingly submits that the applicant was deprived, during the proceedings for
the Canterbury offences, of defences of duress and/or under s45 of MSA 2015 which would probably have
succeeded.

32. The grounds of appeal against sentence are that the sentences for the Aylesbury and Canterbury
offences were manifestly excessive because they failed to take into account the applicant's status as a
VMS. It is submitted that that status, together with the applicant's psychiatric issues, reduced his
culpability to such an extent that non-custodial sentences were appropriate.

33. The original grounds of appeal against sentence in relation to the Canterbury offences are no longer
pursued. Leave to vary the grounds of appeal is sought in accordance with the principles stated by this
court in R v James _[2018] EWCA Crim 285._

34. In relation to the need for long extensions of time, Mr Knight submits that the applicant's status as a
VMS was not identified by his legal representatives, or by the prosecution, at any point during the
proceedings in the courts below, and that the applicant was not aware in 2017 of the grounds of appeal on
which he now relies. The applicant instructed fresh legal representatives following his successful appeal to
the FTT, in which his evidence that he was a VMS was accepted as credible. It is submitted that he has
acted promptly since that time.

**The fresh evidence application:**

35. The applicant seeks to rely on the following as fresh evidence in support of his grounds of appeal.
First, his own witness statements prepared in connection with his immigration proceedings, in which he
gives an account similar to that summarised in paragraph 23 above. Secondly, notes from his previous
legal representatives which confirm that he was not advised of the possible defences on which he now
relies. Thirdly, the positive Conclusive Grounds decision of the SCA. Fourthly, the decision of the FTT.
Fifthly, a report in February 2022 by Ms Beddoe, a specialist adviser on human trafficking and child
exploitation, who described the methods of county lines drug dealers who groom and recruit vulnerable
persons in the position of the applicant, and opined that the applicant's account was consistent with that of
a victim of trafficking for county lines exploitation.  Ms Beddoe also referred to the risk of retribution if a
VMS approached the authorities. Sixthly, a report in February 2022 by Dr Galappathie, a consultant
forensic psychiatrist who diagnosed the applicant as suffering from a single episode depressive disorder of


-----

moderate severity but without psychotic symptoms and from post-traumatic stress disorder (“ PTSD”).
Lastly, a report in July 2023 by Dr Fairweather, a consultant psychiatrist, dealing with the applicant's
present mental health.

**The grounds of opposition:**

36. The respondent did not oppose the court's considering the proposed fresh evidence de bene esse. Mr
Johnson submits that a failure to refer the applicant to the NRM, and/or a failure to advise him about
possible defences, would not in themselves provide substantive grounds of appeal: the key issue is
whether a defence and/or grounds for an application to stay proceedings as an abuse of the process were
available to the applicant and would probably have succeeded. Relying on what was said by this court in R
_v BRP_ _[[2023] EWCA Crim 40 at [63-68], it is submitted that the deference to be given to decisions by the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67DB-27J3-RRJW-500Y-00000-00&context=1519360)_
SCA is lessened in a case which involves events only within this jurisdiction.

37. The respondent concedes that, if the applicant's account is accepted, the applications are likely to
succeed. However, the respondent does not accept the credibility of the applicant's account, and
accordingly invites the court to consider whether the applicant engaged voluntarily in his offending. Mr
Johnson draws attention to the pre-sentence report prepared for the Crown Court at Aylesbury, which
records the applicant as saying that he was not pressured into selling drugs, and ticks boxes categorising
his motives as money and thrill-seeking. Mr Johnson also places emphasis on the fact that in the
Snaresbrook proceedings, the applicant did not pursue those parts of his basis of plea which asserted that
he was forced to offend. Mr Johnson acknowledges that the applicant was an adult at the time of the
Snaresbrook offence and that accordingly a defence under s45(4) of MSA 2015 would not have been
available to him; but, he submits, even if the applicant had been advised that he would not be able to rely
on the more restricted defence under s45(1) of the Act, the facts asserted in his basis of plea would have
provided important mitigation. Mr Johnson submits that the applicant's failure to give oral evidence of
those facts should cause this court to depart from the conclusions of the SCA and the FTT.

38. Mr Johnson draws attention to the rather unusual circumstances of this hearing: the only application
for leave to appeal against conviction is in relation to the Canterbury offences (this court having no
jurisdiction to hear an appeal against the convictions in the youth court for the Aylesbury offences); but the
core submissions of the applicant are to the effect that all the convictions (including the Snaresbrook
offence) are unsafe, and the grounds of the application for leave to appeal against sentence in relation to
the Aylesbury offences are premised on the same submissions. Mr Johnson suggests that it would be
inappropriate for this court to determine the application for leave to appeal against sentence in relation to
the Aylesbury offences, and should instead adjourn that application to await the outcome of the applicant's
application to the CCRC.

39. In advance of the hearing, the respondent had invited the court to consider whether it was appropriate
to hear oral evidence from the applicant. The court, without making any decision on that submission, had
directed that the applicant should attend the hearing (in person or via a link) so that he would be available
to give evidence if required. In the event, however, the applicant did not attend. A medical report by a
consultant psychiatrist Dr Fairweather was put forward, to the effect that the applicant suffers from PTSD.
She opined that he was medically fit to give evidence at the hearing before this court, but that doing so had
a real potential to cause him harm due to his psychiatric disorder. The applicant's solicitors informed the
court that he did not feel able to face the stress and potential detriment to his health of giving evidence.
They confirmed that the applicant was aware that the absence of oral evidence could cause the court to
give less weight to the documentary evidence on which he relied.

**The legal framework:**

40. The United Kingdom has obligations under international law to protect victims of human trafficking.
The NRM was established as a framework for identifying and supporting VMS in order to meet those
obligations. The obligations, and their incorporation into domestic law, have been considered in detail by
this court in a number of cases, including the recent decisions in R v AAD [2022] EWCA Crim 2022 and R
_v AFU_ _[[2023] EWCA Crim 23. For present purposes, it is unnecessary to reiterate all the principles set out](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
in those cases It is sufficient to note the following


-----

41. Subject to exceptions which are not relevant in the circumstances of this case, s45 of MSA 2015
provides a defence for slavery or trafficking victims who commit an offence. The applicant was 17 at the
time of the Aylesbury and Canterbury offences, and the relevant defence in his case is accordingly that
provided by sub-section (4); but it is relevant also to note the defence afforded to adults by sub-section (1):

“(1) A person is not guilty of an offence if –

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

…

(4) A person is not guilty of an offence if –

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.”

42. Once a defendant has raised such a defence, the burden is on the prosecution to disprove it to the
criminal standard: see R v MK [2018] EWCA Crim 667.

43. A VMS who (as in this case) did not raise such a defence may apply for leave to appeal on the
grounds that his conviction is unsafe because, if the true facts of his status as a VMS had been known, his
prosecution would not have been in the public interest, and either he would not have been prosecuted or
his prosecution would have been stayed as an abuse of the process. If this court concludes that the
indictment would have been stayed if an application had been made to the trial court, then the conviction
will be quashed. But, as was said in R v AAJ _[[2021] EWCA Crim 1278 at [39(iv)]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_

“There is no blanket immunity from prosecution for victims of trafficking. Thus, if there is no reasonable
nexus of connection between the offence and the trafficking, generally a prosecution should proceed. If
some nexus remains, then whether or not to prosecute depends on various factors, including the gravity of
the offence, the degree of continuing compulsion and the alternatives reasonably available to the
defendant. Each case is fact specific.”

44. By s52 of MSA 2015, the chief officer of police for a police area is required to notify the Secretary of
State if he or she has reasonable grounds to believe that a person may be a victim of slavery or human
trafficking.

45. Decisions of the SCA are not admissible at trial, but may be adduced on appeal: see R v AAD at [8182], and _R v AFU_ at [88]. Although not binding, such a decision will usually be respected by this court,
unless there is significant evidence to contradict it: see, eg, R v AAJ at [39(vii)]. The SCA is a specialist
authority with particular knowledge and expertise in the area of trafficking: see R v JXP _[2019] EWCA Crim_
_1280. It is, however, for the court to decide whether a conviction is unsafe; and the decision in R v AAD at_

[108] recognises that it may be necessary for an applicant's account to be tested by cross-examination
before this court:

“if the suggested trafficking is based, for instance, on unsatisfactory and untested hearsay evidence from
the appellant, the court may express the view that it would be preferable for the appellant to give evidence
for the proper resolution of the issues on the appeal, thereby enabling his or her account to be
appropriately tested.”


-----

46. A defendant who has pleaded guilty may appeal against his conviction only in limited circumstances:
see _R v Tredget_ _[[2022] EWCA Crim 108. One category of case in which an appeal may be brought is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
where a guilty plea resulted from incorrect legal advice which deprived the defendant of a defence that
quite probably would have succeeded, such that a clear injustice had been done [158]. Another category
is where there was a legal obstacle to the defendant being tried, for example where the prosecution was an
abuse of the process [160].

47. By s23 of CAA 1968, this court may receive fresh evidence if it thinks it necessary or expedient in the
interests of justice to do so. In considering whether to receive any evidence, the court must have regard in
particular to the four criteria set out in sub-section (2), one of which is whether the evidence would have
been admissible at trial. In that regard, it is relevant to note that, although expert evidence may be
admissible in relation to issues such as a defendant's psychiatric state or “the detailed mores of people
trafficking grounds operating in countries that are outside the court's own knowledge and experience”, the
court in R v AAD rejected, at [86], a submission –

“… that a trafficking expert can express an opinion in evidence before the jury as to the plausibility and
consistency of the defendant's account. Similarly, we disagree with the suggestion that a trafficking expert
during a trial can comment on the vulnerability of the defendant.”

48. The important general principle that a defendant has only one chance to advance his defence, and
that this court will only in the most exceptional cases allow a defendant to advance on appeal what are in
effect fresh instructions about the facts of his case, applies to trafficking appeals as it does to all other
types of appeal.

**Analysis          :**

49. All of the applications turn on the applicant's core contention that he was a VMS and that he should
therefore not have been prosecuted; or, if prosecuted, should have been advised of a defence under
s45(4) of MSA 2015 which would probably have succeeded; or alternatively, that he should have been
sentenced much more leniently than he was. If that core contention fails it is not suggested that there is
any other basis for challenging the safety of the Canterbury convictions or for challenging any of the
sentences. In those circumstances, it is unnecessary to engage in any detailed examination of the
circumstances of the offences. It is sufficient, in our view, to focus on issues relating to the statutory
defence. We therefore do not think it necessary to give detailed consideration to whether there would have
been a prosecution if the facts now asserted had been known to the CPS, or to whether a defence of
duress, or an application to stay the proceedings, would have succeeded.

50. The core contention now advanced comes late in the day. However, we accept that at the time of the
proceedings in relation to the Aylesbury and Canterbury proceedings the applicant was a child, and must
largely have been dependent on the advice received from his legal representatives. It is clear that those
representatives did not at any stage advise him of the potential availability of a statutory defence. It is also
clear that no action was taken at any stage by the police to refer him into the NRM. Moreover, if the
applicant's account is correct, the fear of reprisals would no doubt have played a part in the account he felt
able to put forward. It is, therefore, unsurprising that he did not advance his core contention until a much
later stage, after the FTT's decision.

51. One of the elements of the defence available under s45(1) of MSA 2015 to an adult offender is that he
did the act which constituted the offence because he was compelled to do it. That element is absent from
the defence available under s45(4) to a child offender, who is only required to have acted as he did as a
direct consequence of his having been a VMS. That distinction between the defences is in our view
important in this case.

52. We think it unfortunate that the applicant did not attend to give evidence to this court. We are however
persuaded that, although desirable, it was not necessary for him to do so: first, because we have the
Conclusive Grounds decision and the decision of the FTT; and secondly, because we accept the evidence
that there would be some risk to his mental health if he was required to give evidence.


-----

53. The Conclusive Grounds decision is not binding upon us; but we do not find any significant evidence to
contradict it. The contents of the pre-sentence report to which we have referred at paragraph 37 above do,
on the face of it, tend to undermine the applicant's account; but we take into account that it was prepared
about two months after the applicant had told the police that he had been forced to take part in the drugs
offences and had been threatened with a message saying “we know where you live”.

54. We have been more troubled by the fact that the applicant did not pursue, in relation to the
Snaresbrook offence, that part of his basis of plea which reflected the case advanced to this court, and
which would have been relevant, at the very least, as important mitigation.  We accept, however, Mr
Knight's submission that the applicant at the Newton hearing concentrated on the issue as to the duration
of his involvement but did not expressly disavow his written assertions that he had been a VMS throughout
all the drugs offences. We can understand why the applicant's counsel, who had been instructed only
shortly before the _Newton hearing, did not think it appropriate to advance matters which had not been_
relied on as the basis for a defence under s45(1) of MSA 2015. With some hesitation, we accept that this
feature of the _Newton hearing does not significantly impact upon the consistent account which the_
applicant has put forward in his immigration proceedings and in this appeal hearing.

55. Moreover, the Conclusive Grounds decision is consistent with the FTT decision. The experienced FTT
judge heard the oral evidence of the applicant, saw how he reacted to cross-examination, and found him to
be credible on issues which substantially overlapped with those before this court. We regard that as an
important test of the applicant's credibility.

56. We have not found Ms Beddoe's report to be of assistance. Much of it is inadmissible, for the reasons
explained in _R v AAD and which we have noted at paragraph 47 above. In any event, Ms Beddoe's_
opinions were premised upon the accuracy of the applicant's account, and therefore add nothing if we are
persuaded for other reasons that the account is credible.

57. In those circumstances, we accept that the defence under s45(4) of MSA 2015 was not advanced
because the applicant was not advised about it. We further accept that, if it had been advanced, it would
probably have succeeded and that a clear injustice has been done: the applicant has put forward a credible
account to the effect that he offended as a direct consequence of his having been groomed, exploited and
threatened by X and X's subordinates; and we accept that a reasonable person in the applicant's situation
would have done the same as he did.

58. We are therefore satisfied that the extensions of time should be granted and the appeal against
conviction of the Canterbury offences allowed. The appeal against sentence in relation to those offences
accordingly falls away.

59. The unlawful sentence imposed for the Aylesbury offences must be quashed. For each of those
offences, the appropriate sentence was in our view a detention and training order for 24 months: although
the judge would have had power to impose sentences of detention for a longer term, we think that he
would have imposed detention and training orders if he had properly considered the sentences lawfully
available to him. We are not persuaded that this aspect of the hearing should be adjourned to await the
decision of the CCRC.

60. For those reasons we grant the necessary extensions of time. We admit as fresh evidence all the
evidence referred to in paragraph 35 above except for the report of Ms Beddoe. We grant leave to appeal,
allow the appeal against the convictions for the Canterbury offences and quash those convictions. We
grant leave to appeal and allow the appeal against the sentences for the Aylesbury offences: we quash the
sentences imposed below and substitute on each count, concurrently, a detention and training order for 24
months. Those sentences have, of course, already been served.

**End of Document**


-----

