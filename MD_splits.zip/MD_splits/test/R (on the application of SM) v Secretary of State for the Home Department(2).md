# R (on the application of SM) v Secretary of State for the Home Department

_[[2024] EWHC 1683 (Admin), [2024] All ER (D) 19 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6CDB-6583-RRV3-7047-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 01/07/2024**

# Catchwords & Digest

**IMMIGRATION - LEAVE TO REMAIN – VICTIM OF TRAFFICKING**

The Administrative court allowed the claimant's judicial review of the competent authority's decision that
there were no reasonable grounds to believe that the claimant 17 year old Albanian national was a victim of
trafficking/modern slavery. The claimant had obtained a false passport and travelled to the UK via Germany and
when interviewed on arrival had stated that he was stressed because he was in debt to the person helping him into
the UK. On reconsideration the competent authority suggested that the claimant was smuggled into the UK and was
not a victim of trafficking because he was not forced to carry out any work against his will or under any menace of
penalty. The court held that the competent authority's decision when taken as a whole, and applying a fair and
contextual approach, had not shown, expressly or by implication, that the relevant factors in favour of the claimant
had been taken into account. The decision had correctly stated that the focus was on the question of whether there
were reasonable grounds to believe that the claimant was transported 'for the purpose of exploitation' applying
ordinary language and common sense. However, there was no reference to paras 2.23-2.24 of the 'Modern
**_Slavery: Statutory Guidance for England and Wales' under_** _[s 49 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)_ **_Modern Slavery Act 2015. Given the_**
claimant's circumstances, it was clearly a case under the 'what if someone hasn’t yet been exploited' section of the
guidance which made clear that a person could be a victim of trafficking even if they had not yet been exploited and
that it was the purpose that was key rather than whether or not the exploitation had actually occurred.

# Cases considered by this case


R (on the application of TVN) v Secretary of State for the Home Department

_[2021] EWHC 3019 (Admin)_
Considered

MN v Secretary of State for the Home Department; IXU v Secretary of State for the
Home Department (AIRE Centre and another intervening)

_[[2020] EWCA Civ 1746, [2021] 1 WLR 1956, [2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
Considered


11/11/2021

AdminCt

21/12/2020

CACivD


R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State 19/06/2018


-----

for the Home Department (Equality and Human Rights Commission intervening)

_[[2018] EWCA Civ 1395, [2018] 1 WLR 4922, [2018] All ER (D) 38 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
Considered

R (on the application of Hoang) v Secretary of State for the Home Department

_[[2015] EWHC 1725 (Admin), [2015] All ER (D) 228 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G91-1T31-DYBP-N2W2-00000-00&context=1519360)_
Followed

R (on the application of FM) v Secretary Of State For The Home Department

_[[2015] EWHC 844 (Admin), [2015] All ER (D) 300 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FM2-VRV1-DYBP-N4M7-00000-00&context=1519360)_
Considered

R (on the application of Y) v Secretary of State for the Home Department

_[[2012] EWHC 1075 (Admin), [2012] All ER (D) 103 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55MS-4XH1-DYBP-N232-00000-00&context=1519360)_
Applied

Mibanga v Secretary of State for the Home Department

_[[2005] EWCA Civ 367, [2005] INLR 377, [2005] All ER (D) 307 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG21-DYBP-P50W-00000-00&context=1519360)_
Considered

R (on the application of Sarkisian) v Immigration Appeal Tribunal

_[[2001] EWHC Admin 486, [2002] INLR 80, [2001] All ER (D) 329 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_
Considered

**End of Document**


CACivD

18/06/2015

AdminCt

26/03/2015

AdminCt

20/04/2012

AdminCt

17/03/2005

CACivD

28/06/2001

AdminCt


-----

