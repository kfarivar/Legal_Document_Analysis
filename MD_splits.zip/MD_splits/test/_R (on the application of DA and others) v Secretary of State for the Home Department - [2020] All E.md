(Nov)

# *R (on the application of DA and others) v Secretary of State for the Home
 Department [2020] All ER (D) 101 (Nov)

[2020] EWHC 3080 (Admin)

Queen's Bench Division, Administrative Court (London)

Fordham J

13 November 2020

**Immigration – Trafficking – Relevant questions**
Abstract

_The claimants applied for judicial review challenging the practice that was taken in asylum screening interviews and_
_its implications for identifying or not identifying potential victims of trafficking. In the course of those proceedings,_
_the claimants applied for interim relief, requesting, among other things, that the court give an order which was by_
_way of a direction requiring an instruction to caseworkers. In granting the interim relief sought, albeit in a narrower_
_and more tailored form, the Administrative Court ordered, among other things, that: (1) asylum screening interviews_
_in all cases should involve the asking of question 3.1 (why have you come to the UK?) and question 3.3 (please_
_outline your journey to the UK?) as set out in the defendant Home Secretary's published policy guidance on asylum_
_screening (Asylum Screening and Routing), as updated in April 2020; (2) that the Secretary of State should confirm_
_to the court that she had taken steps to satisfy herself that those conducting asylum screening interviews were_
_aware of two key points, namely that: (i) the test for an NRM referral to the competent authority was the one_
_articulated at paras 31(1) and 33(1) of R (on the application of TDT, by his litigation friend Topteagarden) v_
_Secretary of State for the Home Department[2018] All ER (D) 38 (Jul); and (ii) 'there is evidence of a particular risk_
_to migrants of being forced into modern slavery whilst in Libya'._
Digest

The judgment is available at: [2020] EWHC 3080 (Admin)

**Background**

The legal framework to deliver protection for victims of trafficking promoted protective outcomes for relevant
individuals in delivering the rights that they had under the law as reflected in the relevant published policy
instruments. Those outcomes could include state support for an appropriate period. They included a legal bar on
removal for any individual in respect of whom, following a referral under the National Referral Mechanism (NRM), a
'positive reasonable grounds decision' was made. The threshold for a referral was the one identified in R (on the
_application of TDT, by his litigation friend Topteagarden) v Secretary of State for the Home Department (Equality_
_[and Human Rights Commission intervening) [2018] All ER (D) 38 (Jul) (TDT). All of those protective outcomes, and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
that important duty of enquiry and follow-up, arose under the umbrella of the Council of Europe Convention on
Action Against Trafficking in Human Beings and art 4 of the European Convention on Human Rights. Public law
required that published policy guidance instruments be adhered to, absent a good reason for departure.

[Statutory guidance (Modern Slavery Act 2015 – Statutory Guidance for England and Wales), issued by the Home](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Office under the **_[Modern Slavery Act 2015 emphasised the importance of the role of 'first responders' and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**


-----

(Nov)

identified Home Office Border Force and immigration authorities as first responders owing those duties. That
statutory guidance expressly referred to the Home Secretary's published policy guidance on asylum screening
(Asylum Screening and Routing)(the ASR guidance), making explicit reference to 'the Asylum Screening Pro Forma

[which] provides for questions relating to **_modern slavery'. The ASR guidance recognised that certain so-called_**
'soft questions' were relevant to open up the dialogue with the individual; there was then a direct question about
whether there had been 'exploitation'; and then further questions including question 3.1 (why have you come to the
UK?) and question 3.3 (please outline your journey to the UK)(the questions at issue). Those questions were
identified, within the ASR guidance, as relevant to the detection as a first responder of whether the individual facing
potential detention and removal directions with certification of a protection claim was a potential victim of trafficking.
The ASR guidance explained how 'suitability for detention' was also to be approached by the interviewer.

The ASR guidance was updated and implemented from 30 March 2020 in the light of the Covid-19 pandemic and
was published for Home Office staff on 2 April 2020 (the April 2020 guidance). It was described as 'a reduced
contact model', involving some questions being unasked, and one of them at least pre-filled in by the interviewer. It
was explained that in the light of the pandemic, in order to ensure the objectives of continuing at pace with asylum
registration with minimal on-site staffing and reduced flooring, the standard interview had been reduced with certain
answers pre-filled where questions were to be omitted (eg. questions 3.2, 3.4) or where the answer was known (eg.
question 3.3: arrival details (not journey)).

The present proceedings concerned three claimants who had arrived in the UK. The first claimant had arrived on 7
September 2020 and had his screening interview (in person) on 11 September 2020. On the evidence, the interview
had lasted 15 minutes. The answer to his journey question (question 3.3) had been recorded as 'arrived illegally by
boat on 07/09/2020'. He claimed that he had stated at the interview that his journey had involved transiting through
Libya where he had been 'imprisoned and sold'. He was detained. His protection claim was certified and he was
given a notice of removal on 22 September. It was only after his solicitors came on the record and wrote a letter
before claim on 29 September 2020, that he was then asked questions on 30 September about his journey. There
was subsequently an NRM referral which had led to a positive reasonable grounds decision. The position in relation
to the second and third claimants from Sudan, was very similar except that they had both been interviewed by
telephone. The claimants' case was that they had been detained, for 19 days, one month and one month
respectively, longer than they would have been had they been dealt with on their case lawfully. They claimed that
the only reason why they had been able to secure release and legal protection from removal, under the criteria
recognised by the Secretary of State as applicable to individuals in their situations, was because of the action by
their solicitors.

The claimants commenced judicial review proceedings, challenging the practice that was taken in asylum screening
interviews and its implications for identifying or not identifying potential victims of trafficking. The challenge raised
as an integral part of it the question of the 'risk indicator' arising out of transit through Libya and had at its heart the
function of applying the appropriate legal threshold of making referrals to the relevant competent authority. On 4
November, the case came before a judge who directed the hearing of interim relief as sought by the claimants.

The claimants requested: (1) an order that asylum screening interviews in all cases should involve the asking of
question 3.1 (why have you come to the UK?) and question 3.3 (please outline your journey to the UK?) as set out
in the April 2020 guidance (the questions at issue); and (2) a direction requiring an instruction to caseworkers. The
two points which were required to be embodied in that instruction were: (i) that the test for an NRM referral to the
competent authority was the one articulated at paras 31(1) and 33(1) of TDT; and (2) that 'there is evidence of a
particular risk to migrants of being forced into modern slavery whilst in Libya' (the two key points).

**Issues and decisions**

Whether interim relief should be granted.

The claimants submitted that the court should require by way of interim relief the full logic and force of the interview
process described in the ASR guidance. They submitted, among other things, that the interim relief should be


-----

(Nov)

granted and not restricted to the questions at issue which explicitly referred to a link to potential victims of
trafficking.

The present case was a case not only of 'serious risk of irreparable harm', but of 'deprivation of an opportunity'; it
had an impact which although more than minimal was not over-intrusive given the circumstances and implications;
it was a case that involved giving primacy, at least at the interim stage, to the relevant instrument: that instrument
was the April 2020 guidance which dealt with screening interviews and their importance and function so far as
questions relating to potential victims of trafficking were concerned (see [23] of the judgment).

In relation to the questions at issue, it would be ordered that asylum screening interviews in all cases should involve
the asking of those questions, as set out on pages 66 and 67 of the April 2020 guidance. On the basis of the
material before the court and the submissions made to the court, it was strongly arguable that the Secretary of
State was acting unlawfully in curtailing asylum screening interviews by asking a narrower set of questions than
those which were identified in her published policy guidance. There was a strong prima facie case, in particular, that
the omission in that interview of the relevant questions was contrary to law. Those arguments were strongly
arguable on the basis that that was a departure without good reason from the Secretary of State's published policy
guidance. There were also strongly arguable on the basis that there was, in any event, no good reason for that
curtailed practice sufficient to be able to uphold it as lawful. So far as concerned the balance of convenience and
justice, notwithstanding the expedited timetable and the prospect of resolution on their substantive merits of the
arguments before the court by the end of the calendar year, there was a serious risk of injustice and irreversible
harm from those questions continuing to be unasked and unanswered: resolution at the end of the day, were the
claimants to succeed, would not be able to secure or remedy that injustice and harm. The court was quite satisfied
that the real and substantial change that the asking of the relevant questions would mean was a real and
substantial protective change that was needed in the interim in the interests of justice. It was accepted that if the
interim order was made, on the evidence, that would be likely to double the length of the interview. That burden was
necessary and fully justified (see [9] of the judgment).

Consequently, it would be ordered that asylum screening interviews in all cases should involve the asking of
Questions 3.1 and 3.3, as set out on pages 66 and 67 of the April 2020 guidance (see [2], [29] of the judgment).

With regard to the two key points, on the evidence, it was strongly arguable that something had gone wrong, at
least in the 'Libya Risk Group' cases, so far as the screening interview and referrals were concerned. The balance
of convenience and justice strongly supported the court ensuring that it had the confidence that the Secretary of
State no doubt expressed, namely that decision-makers were aware of the substance of the relevant legal test for a
referral and second, that they were aware of the risk recognised by the Secretary of State so far as Libya was
concerned (see [26] of the judgment).

Accordingly, it would be ordered that the Secretary of State should confirm to the court that she had taken steps to
satisfy herself that those conducting asylum screening interviews were aware of those two key points (see [2] of the
judgment).

The Secretary of State should ensure as soon as possible but at the latest by 4pm Monday 16 November 2020, that
Asylum Screening Interviews in all cases had to involve asking Questions 3.1 and 3.3. Further, the Secretary of
State should confirm to the court that she had taken steps to satisfy herself that those conducting asylum screening
interviews were aware of the two key points (see [2], [29] of the judgment).

_R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State for the Home Department_
_(Equality and Human Rights Commission intervening)_ _[2018] EWCA Civ 1395 applied;_ _Medical Justice (R on the_
_application of) v Secretary Of State For The Home Department_ _[[2010] EWHC 1425 (Admin) followed;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_ _R (on the_
_application of NN) v Secretary of State for the Home Department; R (on the application of LP) v Secretary of State_
_for the Home Department_ _[2019] EWHC 1003 (Admin) followed;_ _Secretary of State for Work and Pensions v_
_Johnson and others_ _[2020] EWCA Civ 778 considered;_ _R (on the application of Pantellerisco and others) v_
_Secretary of State for Work and Pensions_ _[2020] EWHC 1944 (Admin) considered._


-----

(Nov)

Application allowed.

Chris Buttler and Zoe McCallum (instructed by Duncan Lewis) for the claimants.

Jack Holborn (instructed by the Government Legal Department) for the Secretary of State.
Neneh Munu Barrister.

**End of Document**


-----

