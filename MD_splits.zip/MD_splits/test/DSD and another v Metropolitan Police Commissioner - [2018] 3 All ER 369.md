# DSD and another v Metropolitan Police Commissioner [2018] 3 All ER 369

[2018] UKSC 11

SUPREME COURT

LADY HALE P, LORD MANCE DP, LORD KERR, LORD HUGHES JJSC AND LORD NEUBERGER

13, 14 MARCH 2017, 21 FEBRUARY 2018

**Human rights — Inhuman or degrading treatment — State's obligation to prevent inhuman or degrading**
**treatment — Alleged failures of police forces to conduct effective investigations of crimes — Whether duty**
**to investigate — Whether duty to investigate only where state complicit in breach — Whether duty to**
**investigate conduct of non-state actors — Human Rights Act 1998, ss 7, 8, Sch 1, Pt I, art 3.**

Between 2003 and 2008, W, the driver of a black cab in London, had committed a legion of sexual offences on
women, including the two respondents. The respondents brought proceedings against the Commissioner of the
[Metropolitan Police Service ('the MPS'), under ss 7 and 8 of the Human Rights Act 1998, for the alleged failure of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y050-00000-00&context=1519360)
the police to conduct effective investigations into W's crimes. The respondents contended that the police failures in
the investigation of the crimes committed by W had constituted a violation of their rights under art 3 of the European
Convention for the Protection of Human Rights and Fundamental Freedoms 1950 (as set out in Sch 1 to the 1998
Act), which provided that '[n]o one shall be subjected to torture or to inhuman or degrading treatment or
punishment'. The respondents succeeded in their claim before the judge and were subsequently awarded
compensation (see _[[2015] 2 All ER 272). The Court of Appeal dismissed the MPS's appeal (see](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FN9-JCC1-DYBP-M07W-00000-00&context=1519360)_ _[[2016] 3 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)_
_[986) and the MPS appealed to the Supreme Court. The MPS accepted that there had been significant errors by the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)_
police in each of the investigations into the crimes committed against the respondents. The principal issue for the
court was the nature of the duty to investigate ill-treatment amounting to a violation of art 3. In particular, the court
considered: (i) whether it was a public duty or one owed to individual victims of the breach of art 3; (ii) whether it
was a systems or an operational duty; (iii) whether the duty to investigate breaches of art 3 in relation to a particular
individual arose only when it was alleged that state authorities were complicit in the breach; (iv) whether, if the duty
comprehended an obligation to investigate breaches of art 3, even if there was no involvement of state agents,
there was a right to claim compensation against the state; (v) whether the fact that a victim could obtain redress
against an offender or make a claim under the Criminal Injuries Compensation Authority ('CICA') affected
consideration of the availability of a right to compensation under the 1998 Act; (vi) whether it was relevant that UK
courts had, so far, refused to recognise a common law duty of care on the police in relation to the manner in which
officers prevented and investigated crime; and (vii) whether the clearest statement in consistent decisions of the
European Court of Human Rights ('ECtHR') to the effect that

**[*370]**

a positive duty was owed by the state to individuals who suffered treatment contrary to art 3 at the hands of another
individual was required before holding that the investigative duty of the state was animated.

**Held – (Per Lady Hale P, Lord Kerr and Lord Neuberger; Lord Hughes dissenting in part) The state was obliged**
under art 3 to conduct an effective investigation into crimes which involved serious violence to persons, whether
that had been carried out by state agents or individual criminals. Further, in order that the protective right should be
practical and effective, an individual who had suffered ill-treatment contrary to art 3 had a right to claim
compensation against the state where there had been a failure by state authorities to conduct a sufficient


-----

investigation into the crime. If the relevant circumstances were present, there was a duty on the part of state
authorities to investigate where non-state agents were responsible for the infliction of the harm. That could not be
characterised as other than an operational duty. Deficiencies in investigation, if they were sufficiently egregious,
could of themselves constitute a violation of art 3; they did not have to be part and parcel of a flawed approach of
the system generally to give rise to a breach of art 3. However, simple errors or isolated omissions would not give
rise to a violation of art 3 at the supra-national and the national levels; only conspicuous or substantial errors in
investigation would qualify. Errors in investigation, to give rise to a breach of art 3, had to be egregious and
significant. Further, it was not required that there be state involvement in the acts alleged to amount to breach of art
3. The inquiry into compliance with the art 3 duty was first and foremost concerned, not with the effect on the
claimant, but with the overall nature of the investigative steps to be taken by the state and the award of
compensation was geared principally to the upholding of standards concerning the discharge of the state's duty to
conduct proper investigations into criminal conduct which fell foul of art 3. In the present case, the catalogue of
failures warranted the award of compensation to the respondents, irrespective of the fact that they had received
damages from both W and CICA and the compensation award would be upheld. Moreover, the argument that the
exemption from liability of the police at common law should be extended to claims advanced under the 1998 Act
would be rejected. The bases of liability were different and no assumption should be made that the policy reasons
which underlaid the conclusion that an exemption of police from liability at common law applied mutatis mutandi to
liability for breach of convention rights. The police either had a protective duty under art 3 or they did not. The
presence of the duty could not depend on the conception of whether it was fair, just or reasonable for it to exist.
Accordingly (Lord Mance DP and Lord Hughes concurring) the appeal would dismissed (see [20], [23]–[30], [48],

[58], [59], [62], [65], [67]–[70], [78]–[80], [85], [92], [93], [97], [99]–[101], [140], [141], [150], [151], below); Assenov v
_Bulgaria_ _[(1998) 28 EHRR 652, Calvelli and Ciglio v Italy](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_ _[[2002] ECHR 32967/96, MC v Bulgaria](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_ _[(2003) 15 BHRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
_[627, Szula v UK (2007) 44 EHRR SE19, Secic v Croatia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_ _[(2007) 23 BHRC 24, Beganovicì v Croatia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0G8-00000-00&context=1519360)_ _[[2009] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_
_[46423/06, Vasilyev v Russia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_ _[[2009] ECHR 32704/04 and CAS v Romania (2012) 61 EHRR 479 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_

[Decision of the Court of Appeal [2016] 3 All ER 986 affirmed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)
**[*371] Notes**

For obligations imposed on state parties under the European Convention on Human Rights, the duty to provide for
investigation of art 3 violations and the duty to prosecute effectively, see 88A _Halsbury's Laws_ (5th edn) (2018)
paras 238, 240, 243.

[For the Human Rights Act 1998, ss 7, 8, Sch 1, Pt I, art 3, see 7(1) Halsbury's Statutes (4th edn) (2015 reissue)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y050-00000-00&context=1519360)
871, 874, 893.
**Cases referred to**

_[A v Ireland (2010) 29 BHRC 423, (2010) 53 EHRR 429, [2011] 3 FCR 244, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W260-00000-00&context=1519360)_

_A v UK_ _[(1998) 5 BHRC 137, (1998) 27 EHRR 611, [1998] 2 FLR 959, [1998] 3 FCR 597, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_

_Amadayev v Russia_ _[[2014] ECHR 18114/06, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X29G-00000-00&context=1519360)_

_Ambrose v Harris (Procurator Fiscal, Oban)_ _[[2011] UKSC 43, [2012] 3 LRC 70, [2011] 1 WLR 2435.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565X-1F41-DYJ0-80H4-00000-00&context=1519360)_

_Assenov v Bulgaria_ _[(1998) 28 EHRR 652, [1998] ECHR 24760/94, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_

_Atalay v Turkey_ _[[2008] ECHR 1249/03, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2PY-00000-00&context=1519360)_

_Ay v Turkey (App no 30951/96) (22 March 2005, unreported), ECt HR._

_Bati v Turkey (2004) 42 EHRR 736, ECt HR._

_Beganovicì v Croatia_ _[[2009] ECHR 46423/06, ECt HR,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_

_B_ _k_ _M t_ _lit_ _P li_ _C_ _[[2005] UKHL 24 [2005] 2 All ER 489 [2005] 1 WLR 1495](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4G4F-CJY0-TWP1-600J-00000-00&context=1519360)_


-----

_BV v Belgium (App no 61030/08) (2 May 2017, unreported), ECt HR._

_BV v Croatia (App no 38435/13) (21 January 2016, unreported), ECt HR._

_Calvelli and Ciglio v Italy_ _[[2002] ECHR 32967/96, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_

_[CAS v Romania (2012) 61 EHRR 479, [2012] ECHR 26692/05, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0KW-00000-00&context=1519360)_

_Celik v Turkey_ _[[2004] ECHR 44093/98, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0FR-00000-00&context=1519360)_

_Chernaya v Ukraine (App no 1661/08) (15 December 2016, unreported), ECt HR._

_CN v UK_ _[(2012) 34 BHRC 1, (2012) 56 EHRR 24, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_

_Costello-Roberts v UK_ _[(1993) 19 EHRR 112, [1994] 1 FCR 65, [1994] ELR 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X3T4-00000-00&context=1519360)_

_Duran v Turkey (App no 42942/02) (8 April 2008, unreported), ECt HR._

_E v UK_ _[[2003] 1 FLR 348, (2002) 36 EHRR 519, [2002] 3 FCR 700, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G22T-00000-00&context=1519360)_

_El-Masri v Former Yugoslav Republic of Macedonia_ _[(2012) 34 BHRC 313, (2012) 57 EHRR 783, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1M5-00000-00&context=1519360)_

_Gafgen v Germany_ _[(2010) 28 BHRC 463, (2011) 52 EHRR 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN21-DYBP-W4T7-00000-00&context=1519360)_

_Hill v Chief Constable of West Yorkshire Police_ _[[1988] 2 All ER 238, [1989] AC 53, [1988] 2 WLR 1049, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-601S-00000-00&context=1519360)_

_Keyu v Secretary of State for Foreign and Commonwealth Affairs_ _[[2015] UKSC 69, [2016] 4 All ER 794, [2016] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M6M-Y091-DYBP-M1X7-00000-00&context=1519360)_
[1355, (2015) 40 BHRC 228 [2015] 3 WLR 1665.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JTK-XS51-DYBP-W1N4-00000-00&context=1519360)

_Knightley v Johns_ _[[1982] 1 All ER 851, [1982] 1 WLR 349, [1982] RTR 182, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-612P-00000-00&context=1519360)_

_Koky v Slovakia_ _[[2012] ECHR 13624/03, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X027-00000-00&context=1519360)_

_Kudla v Poland_ _[(2000) 10 BHRC 269, (2000) 35 EHRR 198, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R1J-9531-DYBP-W1NP-00000-00&context=1519360)_

_Manchester City Council v Pinnock_ _[[2010] UKSC 45, [2011] 1 All ER 285, [2011] 2 AC 104, (2010) 31 BHRC 670,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5217-THM1-DYBP-M2JG-00000-00&context=1519360)_

[2010] 3 WLR 1441.

_MC v Bulgaria_ _[(2003) 15 BHRC 627, (2005) 40 EHRR 459, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_

_MC v Romania (App no 12060/12) (12 April 2016, unreported), ECt HR._

_Mehmet v Turkey (App no 28013/02) (11 March 2008, unreported), ECt HR._

_[Menson v UK (2003) 37 EHRR CD 220, [2003] ECHR 47916/99, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X29M-00000-00&context=1519360)_
**[*372]**

_Michael v Chief Constable of South Wales Police_ _[[2015] UKSC 2, [2015] 2 All ER 635, [2015] AC 1732, [2015] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FXB-8P21-DYBP-M543-00000-00&context=1519360)_
WLR 343.

_[Mikheyev v Russia [2006] ECHR 77617/01, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4YS-00000-00&context=1519360)_

_Milanovic v Serbia_ _[[2010] ECHR 44614/07, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X141-00000-00&context=1519360)_

_Moohan v Lord Advocate_ _[[2014] UKSC 67, [2015] 2 All ER 361, [2015] AC 901, [2015] 4 LRC 379, [2015] 2 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FR0-X8N1-DYBP-M3MC-00000-00&context=1519360)_
141


-----

_[Nikolova v Bulgaria (2007) 48 EHRR 915, [2007] ECHR 7888/03, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2XD-00000-00&context=1519360)_

_O'Keefe v Ireland_ _[(2014) 35 BHRC 601, (2014) 59 EHRR 605, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3BS-00000-00&context=1519360)_

_Osman v UK_ _[(1998) 5 BHRC 293, (1998) 29 EHRR 245, [1999] 1 FLR 193, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_

_P (Adoption: Unmarried Couple), Re_ _[[2008] UKHL 38, [2008] 2 FLR 1084, [2008] NI 310, sub nom Re G (Adoption:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3TY-00000-00&context=1519360)_
_Unmarried Couple) [2009] AC 173, [2008] 3 WLR 76._

_P v Cheshire West and Chester Council, P v Surrey CC_ _[2014] UKSC 19,_ _[[2014] 2 All ER 585, [2014] AC 896,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C3W-8501-DYBP-M1BF-00000-00&context=1519360)_

_[[2014] 5 LRC 428, [2014] 2 WLR 642.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DP7-5H21-DYJ0-83KP-00000-00&context=1519360)_

_R (on the application of Alconbury Developments Ltd) v Secretary of State for the Environment, Transport and the_
_Regions_ _[[2001] UKHL 23, [2001] 2 All ER 929, [2003] 2 AC 295, [2001] 2 WLR 1389, (2001) 82 P & CR 513.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD5-S270-TWP1-60VN-00000-00&context=1519360)_

_R (on the application of Al-Skeini) v Secretary of State for Defence_ _[[2007] UKHL 26, [2007] 3 All ER 685, [2008] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PDJ-CV20-TWP1-60ND-00000-00&context=1519360)_
[AC 153, (2007) 22 BHRC 518, [2007] 3 WLR 33.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2KV-00000-00&context=1519360)

_R (on the application of AM) v Secretary of State for the Home Dept_ _[[2009] EWCA Civ 219, [2009] All ER (D) 171](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V7X-C600-Y96Y-H3MX-00000-00&context=1519360)_
_[(Mar).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V7X-C600-Y96Y-H3MX-00000-00&context=1519360)_

_R (on the application of Amin) v Secretary of State for the Home Dept_ _[[2003] UKHL 51, [2003] 4 All ER 1264, [2004]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7P90-TWP1-61DP-00000-00&context=1519360)_
[1 AC 653, [2004] 3 LRC 746, [2003] 3 WLR 1169.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7R1-DYJ0-802D-00000-00&context=1519360)

_R (on the application of Chester) v Secretary of State for Justice, McGeoch v Lord President of the Council [2013]_
_[UKSC 63, [2014] 1 All ER 683, [2014] AC 271, [2013] 3 WLR 1076, [2014] 1 CMLR 1245.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BFY-R391-DYBP-M492-00000-00&context=1519360)_

_[R (on the application of Gentle) v Prime Minister [2008] UKHL 20, [2008] 3 All ER 1, [2008] 1 AC 1356, (2008) 27](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SSF-CGD0-TWP1-61H2-00000-00&context=1519360)_
_[BHRC 1, [2008] 2 WLR 879.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W391-00000-00&context=1519360)_

_R (on the application of Greenfield) v Secretary of State for the Home Dept_ _[[2005] UKHL 14, [2005] 2 All ER 240,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FYY-B590-TWP1-607D-00000-00&context=1519360)_

[[2005] 1 WLR 673, (2005) 18 BHRC 252.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W2KW-00000-00&context=1519360)

_[R (on the application of Middleton) v West Somerset Coroner [2004] UKHL 10, [2004] 2 All ER 465, [2004] 2 AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-612W-00000-00&context=1519360)_
182, [2004] 2 WLR 800.

_R (on the application of Smith) v Secretary of State for Defence_ _[[2010] UKSC 29, [2010] 3 All ER 1067, [2010] 5](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:50XS-GCR1-DYBP-M373-00000-00&context=1519360)_
_[LRC 558, sub nom](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-83SK-00000-00&context=1519360)_ _R ( the application of Smith) v Oxfordshire Assistant Deputy Coroner (Equality and Human_
_Rights Commission intervening) [2011] 1 AC 1, [2010] 3 WLR 223._

_R (on the application of Ullah) v Special Adjudicator, Do v Secretary of State for the Home Dept_ _[2004] UKHL 26,_

_[[2004] 3 All ER 785, [2004] 2 AC 323, [2005] 1 LRC 740, [2004] 3 WLR 23.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDW-G4B0-TWP1-60B4-00000-00&context=1519360)_

_R (on the application of Wright) v Secretary of State for the Home Dept_ _[[2001] EWHC Admin 520, (2001) 62 BMLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FNG-MXM0-TWW8-X0D4-00000-00&context=1519360)_
_[16, [2001] UKHRR 1399, [2001] Lloyd's Rep Med 478.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FNG-MXM0-TWW8-X0D4-00000-00&context=1519360)_

_R v Horncastle, R v Marquis_ _[[2009] UKSC 14, [2010] 2 All ER 359, [2010] 2 AC 373, [2010] 4 LRC 125, [2010] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y9D-TF90-Y96Y-G0X5-00000-00&context=1519360)_
WLR 47.

_R v Metropolitan Police Comr, ex p Blackburn_ _[[1968] 1 All ER 763, [1968] 2 QB 118, [1968] 2 WLR 893, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35V0-TWP1-606D-00000-00&context=1519360)_

_Rabone v Pennine Care NHS Foundation Trust [2012] UKSC 2,_ _[[2012] 2 All ER 381, [2012] 2 AC 72,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55D5-29K1-DYBP-M0HT-00000-00&context=1519360)_ _[(2012) 33](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W34C-00000-00&context=1519360)_
_[BHRC 208, [2012] 2 WLR 381.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W34C-00000-00&context=1519360)_

_[Secic v Croatia (2007) 23 BHRC 24 (2007) 49 EHRR 408 ECt HR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0G8-00000-00&context=1519360)_


-----

**[*373]**

_Siliadin v France_ _[(2005) 20 BHRC 654, (2005) 43 EHRR 287, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

_[Swinney v Chief Constable of Northumbria Police Force [1996] 3 All ER 449, [1997] QB 464, [1996] 3 WLR 968,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-605C-00000-00&context=1519360)_
CA.

_Szula v UK (2007) 44 EHRR SE19, ECt HR._

_Tunç v Turkey (App no 24014/05) (14 April 2015, unreported), ECt HR._

_Van Colle v Chief Constable of Hertfordshire Police, Smith v Chief Constable of Sussex Police_ _[2008] UKHL 50,_

_[[2008] 3 All ER 977, [2009] AC 225, [2009] 3 LRC 272, [2008] 3 WLR 593.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T9K-8RS0-TWP1-612N-00000-00&context=1519360)_

_Vasilyev v Russia_ _[[2009] ECHR 32704/04, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_

_[Veznedaroglou v Turkey (2000) 33 EHRR 1412, [2000] ECHR 32357/96, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2RD-00000-00&context=1519360)_

_[X v Netherlands (1985) 8 EHRR 235, [1985] ECHR 8978/80, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_

_Yasa v Turkey_ _[(1999) 28 EHRR 408, [1998] ECHR 22495/93, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4DN-00000-00&context=1519360)_

_Z v UK_ _[(2001) 10 BHRC 384, [2001] 2 FLR 612, (2001) 34 EHRR 97, [2001] 2 FCR 246, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41D-00000-00&context=1519360)_
**Additional cases referred to in list of authorities**

_Airey v Ireland_ _[(1979) 2 EHRR 305, [1979] ECHR 6289/73, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_

_Al-Adsani v UK_ _[(2001) 12 BHRC 88, (2002) 34 EHRR 273, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4B8-00000-00&context=1519360)_

_Angelova v Bulgaria_ _[(2007) 23 BHRC 61, (2008) 47 EHRR 236, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W306-00000-00&context=1519360)_

_Artico v Italy_ _[(1980) 3 EHRR 1, [1980] ECHR 6694/74, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1KB-00000-00&context=1519360)_

_AT v Hungary (26 January 2005, unreported), CEDAW._

_Babajanov v Turkey_ _[[2016] ECHR 49867/08, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1D2-00000-00&context=1519360)_

_Banks v UK (App no 21387/05) (6 February 2007, unreported), ECt HR._

_[Bevacqua v Bulgaria [2008] ECHR 71127/01, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0J8-00000-00&context=1519360)_

_[Budayeva v Russia (2014) 59 EHRR 59, [2008] ECHR 15339/02, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4WS-00000-00&context=1519360)_

_Burnip v Birmingham City Council, Trengove (by her personal representative) v Walsall Metropolitan BC, Gorry v_
_Wiltshire CC_ _[[2012] EWCA Civ 629, [2012] LGR 954, [2013] PTSR 117, [2013] HLR 1, [2012] EqLR 701.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:573Y-7H51-DYBR-34RD-00000-00&context=1519360)_

_[Campbell v MGN Ltd [2004] UKHL 22, [2004] 2 All ER 995, [2004] 2 AC 457, [2004] 2 WLR 1232, (2004) 16 BHRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDW-G4B0-TWP1-6183-00000-00&context=1519360)_
_[500, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W01M-00000-00&context=1519360)_

_D v East Berkshire Community Health NHS Trust, K v Dewsbury Healthcare NHS Trust, K v Oldham NHS Trust_

_[[2005] UKHL 23, [2005] 2 All ER 443, [2005] 2 AC 373, [2005] 2 FLR 284, [2005] 2 WLR 993.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4G4F-CJX0-TWP1-61DY-00000-00&context=1519360)_

_DH v Czech Republic_ _[(2007) 23 BHRC 526, (2007) 47 EHRR 59, [2008] ELR 17, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0HK-00000-00&context=1519360)_

_Durdevic v Croatia (App no 52442/09) (19 July 2011, unreported), ECt HR._


-----

_Edwards v UK (2002) 35 EHRR 487, ECt HR._

_Elguzouli-Daf v Comr of Police of the Metropolis, McBrearty v Ministry of Defence [1995] QB 335, [1995] 2 WLR_
[173, [1995] 1 All ER 833, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61NB-00000-00&context=1519360)

_Eremia v Moldova (2014) 58 EHRR 16, ECt HR._

_Eweida v UK (2013) 57 EHRR 213, ECt HR._

_[Glaser v UK (2000) 33 EHRR 1, [2000] 3 FCR 193, [2000] ECHR 32346/96, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3W6-00000-00&context=1519360)_

_Gustafsson v Sweden_ _[(1996) 22 EHRR 409, [1996] ECHR 15573/89, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0HM-00000-00&context=1519360)_

_Hounslow London BC v Powell (Secretary of State for Communities and Local Government intervening), Leeds City_
_Council v Hall (Secretary of State for Communities and Local Government intervening), Birmingham City Council v_
_Frisby (Secretary of State for Communities and Local Government intervening)_ _[[2011] UKSC 8, [2011] 2 All ER 129,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52K1-YWR1-DYBP-M44R-00000-00&context=1519360)_

[[2011] 2 AC 186, [2011] LGR 363, [2011] 2 WLR 287.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52Y8-51K1-DYBR-341X-00000-00&context=1519360)

_Ireland v UK_ _[(1978) 2 EHRR 25, [1978] ECHR 5310/71, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X27J-00000-00&context=1519360)_
**[*374]**

_Jordan v UK_ _[(2001) 11 BHRC 1, (2003) 37 EHRR 52, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3KM-00000-00&context=1519360)_

_Keenan v UK_ _[(2001) 10 BHRC 319, (2001) 33 EHRR 913, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R1J-9531-DYBP-W0D2-00000-00&context=1519360)_

_Kennedy v Charity Commission_ _[[2014] UKSC 20, [2014] 2 All ER 847, [2015] AC 455, [2014] IP & T 733.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C8B-JMH1-DYBP-M1KB-00000-00&context=1519360)_

_M v Romania_ _[[2011] ECHR 29032/04, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4SY-00000-00&context=1519360)_

_Magyar Helsinki Bizottsag v Hungary_ _[[2016] ECHR 18030/11, [2016] All ER (D) 02 (Dec), ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M97-47F1-DYBP-N30Y-00000-00&context=1519360)_

_Mamatkulov v Turkey (2005) 41 EHRR 494, ECt HR._

_Manchester City Council v Pinnock (No 2)_ _[[2011] UKSC 6, [2011] 2 All ER 586, [2011] 2 AC 104, (2011) 31 BHRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52VH-9P71-DYBP-M0MT-00000-00&context=1519360)_
_[699, [2011] 2 WLR 220.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0CW-00000-00&context=1519360)_

_Marinescu v Romania_ _[[2015] ECHR 68842/13, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0NK-00000-00&context=1519360)_

_Maryin v Russia_ _[[2010] ECHR 1719/04, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1JD-00000-00&context=1519360)_

_McVicar v UK_ _[(2002) 12 BHRC 567, (2002) 35 EHRR 566, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4VR-00000-00&context=1519360)_

_MG v Turkey (App no 646/10) (22 March 2016, unreported), ECt HR._

_MGC v Romania (App no 61495/11) (15 March 2016, unreported), ECt HR._

_Moog v Germany (App no 23280/08) (6 October 2016, unreported), ECt HR._

_Opuz v Turkey_ _[(2009) 27 BHRC 159, (2010) 50 EHRR 695, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W34W-00000-00&context=1519360)_

_Osborn v Parole Board, Booth v Parole Board, Re Reilly's application for Judicial Review (Northern Ireland) [2013]_
_[UKSC 61, [2014] 1 All ER 369, [2014] AC 1115, [2014] NI 154, [2013] 3 WLR 1020.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B9H-78R1-DYBP-M4XP-00000-00&context=1519360)_

_Othman v UK (2012) 55 EHRR 1, ECt HR._

_Ouranio Toxo v Greece (2007) 45 EHRR 277, ECt HR._


-----

_Özgür Gündem v Turkey (2001) 31 EHRR 1082, ECt HR._

_Perinçek v Switzerland_ _[(2015) 40 BHRC 313, (2016) 63 EHRR 193, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K56-RC91-DYBP-W0XC-00000-00&context=1519360)_

_Premininy v Russia_ _[(2011) 31 BHRC 9, (2016) 62 EHRR 625, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1KB-00000-00&context=1519360)_

_R (on the application of Animal Defenders International) v Secretary of State for Culture, Media and Sport [2008]_
_[UKHL 15, [2008] 3 All ER 193, [2008] 1 AC 1312, [2008] 5 LRC 687, [2008] 2 WLR 781.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SW6-XF50-TWP1-602H-00000-00&context=1519360)_

_R (on the application of Atamewan) v Secretary of State for the Home Dept_ _[2013] EWHC 2727 (Admin), [2014] 1_
[WLR 1959, [2013] All ER (D) 61 (Sep).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:599S-X571-DYBP-N3C4-00000-00&context=1519360)

_R (on the application of B) v DPP_ _[[2009] EWHC 106 (Admin), (2009) 106 BMLR 152, [2009] 1 WLR 2072, [2009] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V9W-1480-Y9D7-6055-00000-00&context=1519360)_
Cr App Rep 580, DC.

_R (on the application of Bermingham) v Director of the Serious Fraud Office, Bermingham v Government of the_
_[United States of America [2006] EWHC 200 (Admin), [2006] 3 All ER 239, [2007] QB 727, [2007] 2 WLR 635, DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4KBF-17Y0-TWP1-60R8-00000-00&context=1519360)_

_R (on the application of Collins) v Secretary of State for Justice_ _[2016] EWHC 33 (Admin),_ _[[2016] 3 All ER 490,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K92-0571-DYBP-M15F-00000-00&context=1519360)_

[2016] QB 862, [2016] 2 WLR 1303, [2016] 1 Cr App Rep 363.

_R (on the application of Hicks) v Metropolitan Police Comr (Secretary of State for the Home Dept intervening)_

_[[2017] UKSC 9, [2018] 1 All ER 374, [2017] AC 256, (2017) 43 BHRC 254, [2017] 2 WLR 824.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RGY-PVB1-DYBP-M18F-00000-00&context=1519360)_

_R (on the application of Humberstone) v Legal Services Commission (Lord Chancellor intervening)_ _[2010] EWCA_
_[Civ 1479, (2011) 118 BMLR 79, [2011] 1 WLR 1460.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52N5-FT51-DYJ0-B1RP-00000-00&context=1519360)_

_R (on the application of NM) v Secretary of State for Justice_ _[[2012] EWCA Civ 1182, [2012] All ER (D) 63 (Sep).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56JK-P501-DYBP-N0BR-00000-00&context=1519360)_

_R (on the application of SG) v Secretary of State for Work and Pensions (Child Poverty Action Group intervening)_

_[[2015] UKSC 16, [2015] 4 All ER 939, [2015] 1 WLR 1449, [2015] PTSR 471.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HHT-9M41-DYBP-M3F7-00000-00&context=1519360)_

_R (on the application of Smith) v Oxfordshire Assistant Deputy Coroner_ _[2010] UKSC 29,_ _[[2010] 3 All ER 1067,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:50XS-GCR1-DYBP-M373-00000-00&context=1519360)_

[[2011] 1 AC 1, [2010] 5 LRC 558, [2010] 3 WLR 223.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-83SK-00000-00&context=1519360)

_Rantsev v Cyprus_ _[(2010) 28 BHRC 313, (2010) 51 EHRR 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
**[*375]**

_Rees v UK_ _[[1987] 2 FLR 111, (1986) 9 EHRR 56, [1993] 2 FCR 49, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G2H4-00000-00&context=1519360)_

_Rice v Connolly_ _[[1966] 2 All ER 649, [1966] 2 QB 414, [1966] 3 WLR 17, DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94J0-TWP1-60ST-00000-00&context=1519360)_

_Sánchez v Spain (2012) 54 EHRR 872, ECt HR._

_[Smith v Littlewoods Organisation Ltd (Chief Constable, Fife Constabulary, third party) [1987] 1 All ER 710, [1987]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6044-00000-00&context=1519360)_
[AC 241, [1987] 2 WLR 480, 1987 SCLR 489, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPG-BS80-TWYV-J0KT-00000-00&context=1519360)

_Smith v Ministry of Defence_ _[[2013] UKSC 41, [2013] 4 All ER 794, [2014] AC 52, [2014] 1 LRC 663, [2013] 3 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59WH-T011-JBWM-X1PS-00000-00&context=1519360)_
69.

_Soderman v Sweden_ _[(2013) 36 BHRC 257 (2014) 58 EHRR 997, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3C8-00000-00&context=1519360)_

_Thlimmenos v Greece_ _[(2000) 9 BHRC 12, (2000) 31 EHRR 411, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3V5-00000-00&context=1519360)_

_[United Communist Party of Turkey v Turkey (1998) 4 BHRC 1 (1998) 26 EHRR 121 ECt HR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3DG-00000-00&context=1519360)_


-----

_Wemhoff v Germany_ _[(1968) 1 EHRR 55, [1968] ECHR 2122/64, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X12J-00000-00&context=1519360)_

_[Y v Slovenia (2015) 39 BHRC 625, (2016) 62 EHRR 111, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W12D-00000-00&context=1519360)_

_Yildirim (decd) v Austria (1 October 2007, unreported), CEDAW._
**Appeal**

The appellant, the Metropolitan Police Commissioner, appealed from the decision of the Court of Appeal (Lord
[Dyson MR, Laws and Kitchin LJJ) on 30 June 2015 ([2015] EWCA Civ 646, [2016] 3 All ER 986, [2016] QB 161)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)
dismissing his appeal from the judgments of Green J on liability and damages of 28 February 2014 ([2014] EWHC
_436 (QB),_ _[[2014] All ER (D) 76 (Mar)) and 23 July 2014 ([2014] EWHC 2493 (QB),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BPM-5YK1-DYBP-N0NC-00000-00&context=1519360)_ _[[2015] 2 All ER 272)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FN9-JCC1-DYBP-M07W-00000-00&context=1519360)_
[respectively, upon claims brought by the respondents, DSD and NBV, for declarations and damages under ss 7, 8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y050-00000-00&context=1519360)
of the Human Rights Act 1998 in relation to alleged failings on the part of the Metropolitan Police Service to conduct
an effective investigation into crimes carried out by John Worboys between 2002 and 2008. The following parties
intervened in the appeal: (1) Liberty (2) the Secretary of State for the Home Department; (3) Rape Crisis England
and Wales; (4) End Violence Against Women Coalition; (5) Southall Black Sisters and (6) the Nia Project. The facts
are set out in the judgment of Lord Kerr.

_Lord Pannick QC and Jeremy Johnson QC (instructed by Metropolitan Police Directorate of Legal Services) for the_
appellant.

_Phillippa Kaufmann QC and Ruth Brander (instructed by Birnberg Peirce) for the respondents._

_Karen Steyn QC and Hannah Slarks (instructed by Liberty) for the first intervener._

_James Eadie QC and David Pievsky (instructed by The Government Legal Department) for the second intervener._

_Karon Monaghan QC, Helen Law and Kirsten Sjøvoll (instructed by Deighton Pierce Glynn) for the third to sixth_
interveners.

_Judgment was reserved._

21 February 2018. The following judgments were delivered.

**LORD KERR**

(with whom Lady Hale P agrees).
**Introduction**

**[1] Between 2003 and 2008, John Worboys, the driver of a black cab in London, committed a legion of sexual**
offences on women. The first respondent in these proceedings (who has been referred to throughout as DSD)
**[*376]**

was among his first victims. She was attacked in 2003. The second respondent (NBV) became Worboys' victim in
July 2007. Many others were attacked by him between 2003 and 2007 and, sadly, yet more after NBV was
assaulted.

**[2] DSD and NBV brought proceedings against the Commissioner of the Metropolitan Police Service ('MPS') for the**
alleged failure of the police to conduct effective investigations into Worboys' crimes. The claims were brought under
_[ss 7 and 8 of the Human Rights Act 1998 ('HRA'). The combined effect of these provisions (so far as this case is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y050-00000-00&context=1519360)_
concerned) is to allow a person who claims that a public authority has acted in a way which is incompatible with
their rights under the European Convention for the Protection of Human Rights and Fundamental Freedoms 1950
(as set out in Sch 1 to the HRA) ('ECHR') to bring proceedings against the public authority and to be awarded
damages.

**[3] The kernel of DSD and NBV's claims is that the police failures in the investigation of the crimes committed by**
Worboys constituted a violation of their rights under art 3 of ECHR. This provides that '[n]o one shall be subjected to


-----

torture or to inhuman or degrading treatment or punishment'. They succeeded in that claim before Green J, who
delivered judgment on the liability issues on 28 February 2014 ([2014] EWHC 436 (QB), _[[2014] All ER (D) 76](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BPM-5YK1-DYBP-N0NC-00000-00&context=1519360)_
_[(Mar)). In a second judgment handed down on 23 July 2014 ([2014] EWHC 2493 (QB), [2015] 2 All ER 272, [2015]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BPM-5YK1-DYBP-N0NC-00000-00&context=1519360)_
1 WLR 1833), Green J awarded compensation to DSD and NBV against MPS. An appeal by MPS was dismissed
[by the Court of Appeal (Lord Dyson MR, Laws and Kitchin LJJ) on 30 June 2015 ([2015] EWCA Civ 646, [2016] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)
_[All ER 986, [2016] QB 161). MPS has appealed to this court. The Secretary of State for the Home Department](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)_
('SSHD') intervened, making written and oral submissions. A number of other parties intervened. Liberty intervened,
as did jointly the organisations Rape Crisis, England and Wales, the End Violence Against Women Coalition,
Southall Black Sisters and the Nia Project. They made helpful written submissions and valuable oral submissions.

**[4] In this appeal MPS accepts that both respondents were subjected to serious sexual assault by Worboys. It**
further accepts that there were significant errors by the police in each of the investigations into the crimes
committed against them. MPS has said that, whatever the outcome of this appeal, MPS will not seek to recoup any
of the compensation and consequential costs which have been paid.

**[5] DSD and NBV have recovered compensation from Worboys and each of them has received an award from the**
Criminal Injuries Compensation Authority ('CICA').
**The principal issue**

**[6] It is accepted that HRA imposes a general duty to investigate ill-treatment amounting to a violation of art 3 of**
ECHR. The main area of dispute is the nature of that duty. That issue has a number of themes. They can be
summarised as follows:

(i)   Is it a public duty or one owed to individual victims of the breach of art 3?

(ii)   Is it a systems or an operational duty?

(iii)   Does the duty to investigate breaches of art 3 in relation to a particular individual arise only when it is
alleged that state authorities are complicit in the breach?

**[*377]**

(iv)   If the duty comprehends an obligation to investigate breaches of art 3, even if there is no
involvement of state agents, is there a right to claim compensation against the state?

(v)   Should the fact that a victim can obtain redress against an offender or make a claim under the CICA
scheme affect consideration of the availability of a right to compensation under HRA?

(vi)   In this context, is it relevant that UK courts have, so far, refused to recognise a common-law duty of
care on the police in relation to the manner in which officers prevent and investigate crime?

(vii)   Finally, it is suggested that it would require the clearest statement in consistent decisions of the
European Court of Human Rights ('ECtHR') Grand Chamber to the effect that a positive duty was owed by
the state to individuals who suffered treatment contrary to art 3 at the hands of another individual before
holding that the investigative duty of the state was animated. If ECtHR jurisprudence is found to be less
than clear, the appropriate course was to allow the government to deploy its arguments in Strasbourg—R
_(on the application of Ullah) v Special Adjudicator, Do v Secretary of State for the Home Dept_ _[2004] UKHL_
_[26, [2004] 3 All ER 785, [2004] 2 AC 323.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDW-G4B0-TWP1-60B4-00000-00&context=1519360)_

**[7] Many of these themes overlap and blend into one another and it is impossible to consider them other than**
compendiously, not least because that is how they are treated in many of the relevant authorities, both domestic
and European. It is necessary at the outset, however, to recognise that examination of the nature of the duty is a
multi-faceted exercise.
**The nature of the duty owed under HRA—the arguments**

**[8] The appellant argues that the duty of the police to investigate, detect and prosecute crime is of a communal**
nature; one which is owed to the public at large, not to individual citizens. It is submitted that the 'general rule' is that
no private law duty is owed to victims of crime. This is because it has been deemed that it would not be 'fair, just
and reasonable' to impose such a duty The consistent theme of judicial decisions on the liability of the police at


-----

common law has been, the appellant suggests, that there are overwhelming public policy reasons that no such
liability should be recognised. The Court of Appeal in the present case had emphasised the importance of
consistency between the common law and HRA. It would be anomalous, the appellant contends, for there to be
different bases of duty owed by the police at common law and under HRA. Many of the public policy considerations
which militated against the recognition of such a duty at common law apply with equal force to the duty to
investigate that arises under art 3 of HRA.

**[9] It is accepted that there is a duty to investigate allegations of ill-treatment which amount to a violation of art 3 but**
it is suggested that this duty can be enforced through the disciplinary regime, under the independent oversight of
the Independent Police Complaints Commission. The existence of this regime, the appellant says, reflects the
public nature of that duty.

**[10] Insofar as art 3 of ECHR imposes a positive obligation to respond to ill-treatment by a member of the public**
who is not a state agent, that obligation, the appellant submits, is to put in place the legal structures required to
ensure that a proper inquiry can be conducted. It does not extend to the operational content of an individual inquiry.
The investigative obligation in relation to individual cases arises only where state agents are complicit in the alleged
ill-treatment.
**[*378]**

**[11] The SSHD submits that the origin of the investigative duty is Assenov v Bulgaria** _[(1998) 28 EHRR 652, [1998]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
_[ECHR 24760/94 where ECtHR stated that an effective official investigation was required where there was an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
arguable claim of serious ill-treatment 'by the police or other such agents of the State unlawfully and in breach of
Article 3'—para 102. It is therefore argued that the principled foundation for the implication of an investigative duty
is to underpin the effectiveness of the express prohibition set out in art 3. That prohibition could only apply, the
SSHD argues, to agents of the state, not to private individuals.

**[12] The respondents' riposte to these arguments is that the state has a duty under art 3 to conduct an effective**
investigation into crimes which involve serious violence to an individual. This is a positive, protective obligation to
take measures designed to ensure that individuals within its jurisdiction are not subject to the treatment which art 3
prohibits. The duty is not an abstract one owed to the public at large but can be invoked by an individual who
demonstrates that the state's failure to fulfil its obligation has led to her or his suffering treatment prohibited by the
article.

**[13] The respondents submit that the appellant's argument about the need for consistency between the common-**
law position and the availability of a claim under HRA is, properly analysed, one of justiciability. They point out that
the appellant accepts that there is a domestic law duty to investigate effectively serious criminal offences. It is
accepted that there were several deficiencies in the investigation of these offences. The decision by Parliament to
enact HRA effectively disposes of the issue of justiciability. The incorporation of ECHR into domestic law made
available to an individual a remedy for a breach by the state of the art 3 protective obligation. This was entirely in
line with the jurisprudence of ECtHR.

**[14] In any event, the respondents argue, the public policy considerations which have been held to underlie the**
exemption from liability at common law do not translate to the position under HRA. As Lord Brown of Eaton-underHeywood held in _Van Colle v Chief Constable of Hertfordshire Police, Smith v Chief Constable of Sussex Police_

_[[2008] UKHL 50, [2008] 3 All ER 977, [2009] AC 225(para [138]), Convention claims have quite different aims from](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T9K-8RS0-TWP1-612N-00000-00&context=1519360)_
civil actions.

**[15] On the appellant's argument that the duty of the state under art 3 is confined to putting in place legal structures**
to prohibit such ill-treatment as is forbidden by the article, the respondents claim that this is unsustainable, again in
light of the decision in _Van Colle. That decision was premised on the existence of an operational duty to protect_
against a real and immediate risk of serious violence.
**The relevant case law on the nature of the duty**


-----

**[16] In** _MC v Bulgaria_ _[(2003) 15 BHRC 627, (2005) 40 EHRR 459 the applicant complained that she had been](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
raped by two men when she was 14 years old. The men in question were interviewed but it was concluded that they
had not used threats or violence and there was no evidence of resistance on the part of the complainant. The
district prosecutor therefore issued a decree terminating the proceedings. The complainant's application to ECtHR
rested on the twin assertions that Bulgarian law did not provide effective protection against rape and sexual abuse
as only cases where the victim had actively resisted were prosecuted, and that the authorities had not properly
investigated her allegations. It is important to recognise that the court found that the failure
**[*379]**

properly to investigate her allegations constituted violation of her rights under arts 3 and 8 of ECHR. As I shall
discuss below, the appellant has concentrated on the first of the assertions made by the applicant in _MC. The_
second aspect of her complaint—that there was not a proper investigation of her allegations is a distinct and
unconnected ground on which the court decided that art 3 had been breached.

**[17] In para 151 of MC ECtHR observed that, in a number of cases, art 3 of ECHR gives rise to a positive obligation**
to conduct an official investigation. The court expressly said that such positive obligations 'cannot be considered in
principle to be limited solely to cases of ill-treatment by state agents'. It concluded that the authorities had failed to
explore the surrounding circumstances—para 178. On that account, there was a violation of the state's positive
obligation under art 3—para 187. This was a duty owed to the applicant personally and she was awarded
compensation—para 194.

**[18] A significant passage from the court's judgment is to be found in para 153:**

'… the court considers that states have a positive obligation inherent in arts 3 and 8 of the convention to enact
criminal law provisions effectively punishing rape and to apply them in practice through effective investigation
_and prosecution.' (Emphasis supplied.)_

**[19] The binary nature of the positive obligation arising under these articles was noted by Green J in para [163] of**
his judgment: effective systems and operational duties:

'… There were two relevant aspects. First, whether the state of Bulgarian law on rape was so flawed as to
amount to a breach of the state's positive obligation under arts 3 and 8 (the systemic failings). Secondly, to
consider whether the alleged shortcomings in the investigation were, also, so flawed as also to amount to a
breach of the state's obligations under the same articles (the operational failings). Under the heading “general
approach” the court explained that the duty to create a corpus of law and the duty to “apply them in practice”
through investigation and punishment were separate …'

**[20] Lord Hughes has suggested (in para [117] of his judgment) that the statement in para 153 of ECtHR's**
judgment, that 'art 3 carries an obligation in some circumstances to investigate third party offending' leaves 'only
uncertainties about its source and thus its extent'. What is not in the least uncertain, however, is that, if the relevant
circumstances are present, there is a duty on the part of state authorities to investigate where non-state agents are
responsible for the infliction of the harm. That cannot be characterised as other than an operational duty. The
debate must focus, therefore, not on the existence of such a duty but on the circumstances in which it is animated.

**[21] It is suggested (para [119] of Lord Hughes' judgment) that** _Calvelli and Ciglio v Italy_ _[[2002] ECHR 32967/96](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_
does not provide authority for the second proposition in para 151 of _MC, namely, that positive obligations to_
investigate cannot be considered in principle to be limited solely to cases of ill-treatment by state agents. It should
be observed, however, that part of the applicants' complaint in that case related to the unexplained delay in the
proper investigation of their representations that the doctor who was ultimately
**[*380]**

charged with manslaughter was responsible for the death of their child—see para 43 of the judgment. In other
words, an operational failure. At para 54, the court said this:


-----

'In the instant case, the Court notes that the criminal proceedings instituted against the doctor concerned
became time-barred because of procedural shortcomings that led to delays, particularly during the police
inquiry and judicial investigation.'

**[22] The rejection of the applicants' case in Calvelli and Ciglio was not because ECtHR considered that the duty to**
investigate was confined to 'an obligation to provide a sufficient investigative structure', as Lord Hughes puts it in
the final sentence of para [119] of his judgment. To the contrary, the Strasbourg court held that, because of the
applicants' entitlement to issue proceedings in the civil courts and the fact that they entered into a settlement
agreement with the doctor's insurers, they had waived their rights to pursue criminal proceedings (para 54). Nothing
in the court's judgment supports the suggestion that it was founded on a view that the extent of the ancillary duty
under art 2 was to provide a sufficient investigative structure rather than a duty not to be negligent in the way in
which the inquiry was conducted. The court made that unequivocally clear in para 56 of its judgment where it said
that because the applicants had denied themselves the 'best means' of elucidating the extent of the doctor's
responsibility for the death of their child, it was unnecessary to examine whether the time bar on bringing
proceedings prevented the doctor from being prosecuted. The coming into force of the time bar had, of course,
been contributed to by the operational failure of the state authorities to conduct investigations more expeditiously.

**[23] Lord Hughes has described the statement in para 152 of MC as 'tentative'—see para [121] of his judgment. It**
seems to me clear, however, that the court was there recording that, hitherto, ECtHR had not excluded the prospect
that it would be held that actions by non-state agents would give rise to positive obligations on the part of the state
under arts 2 and 3 of ECHR. MC provided the occasion to proclaim that such a positive obligation existed.

**[24] In order to be an effective deterrent, laws which prohibit conduct constituting a breach of art 3 must be**
rigorously enforced and complaints of such conduct must be properly investigated. There is a clear line of
Strasbourg authority for the duty to properly investigate reported offences and allegations of ill-treatment, which is
summarised with approval at para 172 of O'Keefe v Ireland _[(2014) 35 BHRC 601, (2014) 59 EHRR 605:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3BS-00000-00&context=1519360)_

['The court recalls the principles outlined in [CAS v Romania (2012) 61 EHRR 479, [2012] ECHR 26692/05] at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0KW-00000-00&context=1519360)
paras 68–70 to the effect that art 3 requires the authorities to conduct an effective official investigation into
alleged ill-treatment inflicted by private individuals which investigation should, in principle, be capable of
leading to the establishment of the facts of the case and to the identification and punishment of those
responsible. That investigation should be conducted independently, promptly and with reasonable expedition.
The victim should be able to participate effectively.'

**[25] It has been suggested (Lord Hughes at para [123]) that ECtHR in** _MC made it clear that it regarded the_
deficiencies in the investigation as 'the consequence of, and part and parcel with, the flawed approach of the
Bulgarian system generally to the issue of lack of consent'. At para 179 the court said this:
**[*381]**

'It is highly significant that the reason for that failure [to conduct a proper investigation] was, apparently, the
investigator's and the prosecutors' opinion that since what was alleged to have occurred was a “date rape”, in
the absence of “direct” proof of rape, such as traces of violence and resistance or calls for help, they could not
infer proof of lack of consent and, therefore, of rape from an assessment of all the surrounding circumstances.
That approach transpires clearly from the position of the investigator and, in particular, from the regional
prosecutor's decision of May 13, 1997 and the chief public prosecutor's decision of June 24, 1997.'

**[26] In my view, the court was not suggesting in this passage that the deficiencies in the investigation were**
somehow subsumed into the shortcomings of the Bulgarian law. Nor was it suggested that deficiencies in
investigation had to be accompanied in all circumstances by systemic defects. In MC, the lack of assiduity in the
investigation could be explained because of the inadequacy of that law but it does not follow that deficiencies in
investigation, if they are sufficiently egregious, cannot of themselves constitute a violation of art 3. Cases decided
after MC make that unambiguously clear. I will discuss those cases presently.


-----

**[27] Concentrating for the moment on** _MC, however, Lord Hughes suggests that his thesis, that deficiencies in_
investigation were part and parcel of 'the flawed approach of the Bulgarian system generally', was supported by the
words of para 168 which he quotes at para [122] of his judgment. In para 168, ECtHR said that it was not
concerned with 'allegations of errors or isolated omissions in the investigation'. The court accepted that it could not
replace the domestic authorities' assessment of the facts of the case nor could it decide on the alleged perpetrators'
criminal responsibility.

**[28] These statements must be seen in context. The Strasbourg court is a supra-national body. There are obvious**
limitations on its opportunity to examine deficiencies in investigation. National courts are not so constrained. This
case provides the perfect example. Green J heard detailed evidence of the errors that had been made by police in
the investigation of Worboys' crimes. He was in a position to form a judgment as to the impact of those errors on
the respondents' cases. And it was open to him to find, as he correctly did, that the errors were so serious that a
violation of art 3 was established.

**[29] I cannot accept a suggestion that, to give rise to a breach of art 3, deficiencies in investigation had to be part**
and parcel of a flawed approach of the system generally. I accept, however, that simple errors or isolated omissions
will not give rise to a violation of art 3 at the supra-national and the national levels. That is why, as I point out below,
only conspicuous or substantial errors in investigation would qualify. The Strasbourg court disavowed any close
examination of the errors in investigation because it was a supra-national court. It left that to national courts. But,
my reference to ECtHR's disinclination to conduct such a close examination is not intended to suggest that minor
errors in investigation will give rise to a breach of the Convention right on the national plane. To the contrary, as I
make clear in paras [53] and [72] below, errors in investigation, to give rise to a breach of art 3, must be egregious
and significant.

**[30] As I hope is now clear, not every error in investigation will give rise to a breach of art 3. But the difficulty in**
defining those errors which qualify should not prompt capitulation to the notion that there has to be some form of
**[*382]**

structural deficiency before egregious errors in the investigation of the offences, such as occurred in this case, can
amount to a breach of art 3. That proposition is strongly supported by consideration of cases decided after MC and I
turn now to those cases.

**[31] The case of Szula v UK (2007) 44 EHRR SE19 involved a complaint of sexual and physical abuse brought by a**
minor during the time that he was in a residential approved school. The applicant's claim was deemed inadmissible
but this was because it was concluded that there was 'no indication that the authorities showed any lack of diligence
or expedition' in the investigation of his allegations. Implicit in that finding was that, had there been such an
indication, the applicant's case would have been admissible. It has been suggested that this case is an example of
the court having looked for evidence of a structural defect or culpable disregard or an absence of good faith in the
administration of the domestic system (Lord Hughes in para [126] below). I do not agree. In that case the court
expressly recognised that the criminal law prohibited the physical and sexual abuse alleged by the applicant. True it
is that the court, after reviewing steps taken by police and prosecuting authorities, also said (in para 1 of its
judgment):

'While that sequence of events was somewhat unfortunate, the Court does not consider that it discloses any
culpable disregard, discernible bad faith or lack of will on the part of the police or prosecuting authorities as
regards properly holding perpetrators of serious criminal offences accountable pursuant to domestic law.'

**[32] It is unquestionably clear that these observations were made in relation to the discharge by the police and the**
prosecuting authorities of their operational duties. There is no hint in the judgment that this was in any way related
to a 'structural defect'. As I have said, the court had examined the criminal law system and not found it wanting. I
cannot accept, therefore, that the quoted passage had anything whatever to do with a systemic or structural failure.
It was plainly pertinent—and only pertinent—to a review of the operational actions and decisions of the police and
prosecuting authorities. The fact that the court considered it necessary to conduct such a review, when no systemic
defect was present, is important, however. It can only have been necessary if the court considered that a purely
ti l f ili ti l l t d t ' t t l d f t' ld h i i t i l ti f t 3


-----

**[33] In Secic v Croatia** _[(2007) 23 BHRC 24, (2007) 49 EHRR 408 (31 May 2007), ECtHR considered a complaint of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0G8-00000-00&context=1519360)_
ineffective criminal investigation of a racially motivated physical assault. The court again repeated the statement
from _MC that art 3 may give rise to a positive obligation to conduct an official investigation—para 53. The court_
stated that the obligation on the state to conduct an official investigation is one of means, not result, referring to the
[art 2 cases of Menson v UK (2003) 37 EHRR CD 220, [2003] ECHR 47916/99 and Yasa v Turkey](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X29M-00000-00&context=1519360) _[(1999) 28 EHRR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4DN-00000-00&context=1519360)_
_[408, [1998] ECHR 22495/93. At para 54, however, it observed that the authorities had to take 'all reasonable steps](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4DN-00000-00&context=1519360)_
available to them to secure the evidence concerning the incident' and that the authorities must act with 'promptness
and reasonable expedition.' Having considered the investigations conducted by the police, ECtHR concluded, at
para 59, that 'the failure of the state authorities to further the case or obtain any tangible evidence with a view to
identifying and arresting the attackers over a prolonged period of time indicates that the investigation did not meet
the requirements of art 3 of the convention'. It therefore found that art 3 had
**[*383]**

been breached and that the applicant was entitled to be compensated. Lord Hughes has cited this case as an
example where there were 'plain overtones of structural state deficiencies in relation to the investigation of
allegations of racially motivated or discriminatory violence' (para [126]).

**[34] The applicant's submissions are set out in paras 38–42 of the court's judgment. None of these submissions**
touched on any structural or systemic deficiency in Croatian law or procedure. To the contrary, the applicant
complained that Croatian law provided for many processes and police methods which the police had failed to follow.
He also complained that they had failed to apply to a Croatian court for an order compelling a journalist to reveal the
name of an interviewee who might have been able to shed light on the attack on him. Such an application could
have been made under s 30 of the Media Act. No complaint was made about any inadequacy in that provision. All
of the applicant's complaints were in relation to the operational failings of the police.

**[35] The Croatian government's submissions are set out in paras 43–48 of the Strasbourg court's judgment. Apart**
from claiming that the applicant's ill-treatment did not reach the threshold required for a breach of art 3 and that the
positive obligation under that article arose only where the state had been made aware of acts which it was
reasonable to expect them to prevent, all the government's submissions were focused on a defence of the
operational decisions and actions of the police. The question of systemic deficiencies was simply not in play in this
case. That is obvious also from the court's decision. At para 53 the court said that art 3 may give rise to a positive
obligation to conduct an official investigation. This was not, in principle, limited to cases of ill-treatment by state
agents. And at para 54 the court said this:

'… the court recalls that the scope of the … obligation by the state is one of means, not of result; the authorities
must have taken all reasonable steps available to them to secure the evidence concerning the incident. A
requirement of promptness and reasonable expedition of the investigation is implicit in this context.'

**[36] The complaint of lack of promptness related solely to police inaction. Nothing about any structural or systemic**
deficiency was instanced. And the remainder of the court's judgment focused entirely on the operational failings of
the police. For my part, therefore, I have not been able to find any overtones of structural state deficiencies in the
report of this case.

**[37]** _Beganovicì v Croatia_ _[[2009] ECHR 46423/06 (25 June 2009) was a case in which the applicant had been](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_
assaulted by three individuals. Although ECtHR acknowledged (in para 69 of its judgment) that no direct
responsibility can attach to a member state under ECHR for the acts of private individuals, it stated (in paras 70 and
71):

'70. … even in the absence of any direct responsibility for the acts of a private individual under art 3 of the
Convention, State responsibility may nevertheless be engaged through the obligation imposed by art 1 of the
Convention. In this connection the Court reiterates that the obligation on the High Contracting Parties under art
1 of the Convention to secure to everyone within their jurisdiction the rights and freedoms defined in the
Convention, taken together with art 3, requires States to take measures designed to ensure that individuals
within their jurisdiction are not subjected to torture or inhuman or degrading treatment or punishment, including


-----

such ill-treatment administered by private individuals (see [A v UK _[(1998) 5 BHRC 137, (1998) 27 EHRR 611],](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_
para 22).

**[*384]**

71. … In order that a State may be held responsible it must … be shown that the domestic legal system, and in
particular the criminal law applicable in the circumstances of the case, _fails to provide practical and effective_
_protection of the rights guaranteed by art 3 (see [X and Y v Netherlands_ _[(1985) 8 EHRR 235,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_ _[[1985] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_
_[8978/80], para 30, and A v United Kingdom,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_ cited above, opinion of the Commission, para 48).' (Emphasis
supplied)

**[38] The court made clear that, as well as examining the 'impugned regulations and practices, and in particular the**
domestic authorities' compliance with the relevant procedural rules', it would also consider 'the manner in which the
criminal-law mechanisms were implemented in the instant case'—para 74. At para 75, ECtHR set out the 'minimum
standards applicable' in respect of 'the duty to investigate'. They included that the investigation be independent,
impartial and subject to public scrutiny, and that the authorities act with diligence and promptness. It also reiterated
that 'for an investigation to be considered effective, the authorities must take whatever reasonable steps they can to
secure the evidence concerning the incident, including, inter alia, a detailed statement concerning the allegations
from the alleged victim, eyewitness testimony, forensic evidence and, where appropriate, additional medical
reports'. The failings in fact identified in this case arose at the post-investigative stage and ECtHR confirmed the
principle that the requirement for effective criminal law provisions extends to the trial phase of proceedings—para
77.

**[39] The ECtHR decided that the state authorities did not fulfil their positive obligations under art 3. Violation of that**
article was found. Compensation was awarded to the applicant. The various elements of an effective investigation
identified by the court should be noted. It must be independent. It requires to be prompt. Evidence must be secured.
Failure to adhere to these standards renders the state liable to the individual affected by that failure.

**[40] In the case of Vasilyev v Russia** _[[2009] ECHR 32704/04 (17 December 2009) the applicant and his friend were](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_
seriously assaulted and robbed. Although police officers attended the scene, no investigation into the
circumstances of the assault were conducted. The police officers claimed to have considered that the applicant and
his friend were intoxicated, so they moved them from the position where they had been found and left them. A
number of criminal investigations were subsequently instituted, largely on the initiative of the applicant's mother. It
was decided to suspend the proceedings because the perpetrators could not be identified. This decision was
reversed and restored on a number of occasions. The two police officers who had attended the scene were
prosecuted for failing to fulfil their legal duty to protect victims of offences. They were acquitted.

**[41] The applicant did not lay blame on the state authorities for the attack; nor was it suggested that they knew or**
ought to have known that the applicant was at risk of physical violence at the hands of third parties. The court
explicitly found, however, that this did not absolve the state from obligations under art 3. At para 99, it said that what
the article required was that 'the authorities conduct an effective investigation into the alleged ill-treatment even if
such treatment has been inflicted by private individuals'. It elaborated on this statement at para 100:

'… For the investigation to be regarded as “effective”, it should in principle be capable of leading to the
establishment of the facts of the case and to the identification and punishment of those responsible. This is not

**[*385]**

an obligation of result, but one of means. The authorities must have taken the reasonable steps available to
them to secure the evidence concerning the incident, including, _inter alia, eyewitness testimony, forensic_
evidence, and so on. Any deficiency in the investigation which undermines its ability to establish the cause of
injuries or the identity of the persons responsible will risk falling foul of this standard, and a requirement of
promptness and reasonable expedition is implicit in this context (see, among many authorities, _Mikheyev v_
_[Russia [2006] ECHR 77617/01, para 107 et seq, 26 January 2006, and [Assenov v Bulgaria](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4YS-00000-00&context=1519360)_ _[(1998) 28 EHRR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
_[652, [1998] ECHR 24760/94], paras 102 et seq.).'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_


-----

**[42] It was held that there had been a violation of art 3 under its procedural limb in that the investigation into the**
assault on the applicant was ineffective. He was awarded compensation.

**[43] A similar approach to that in the cases already discussed is found in later decisions of ECtHR such as**
_Milanovic v Serbia_ _[[2010] ECHR 44614/07 (14 December 2010),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X141-00000-00&context=1519360)_ _CAS v Romania (2012) 61 EHRR 479,_ _[[2012]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0KW-00000-00&context=1519360)_
_[ECHR 26692/05 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0KW-00000-00&context=1519360)_ _BV v Croatia (App no 38435/13) (21 January 2016, unreported). The statement of the_
applicable principles concerning the procedural obligations in _CAS v Romania (which reflected the exposition of_
those in the cases considered in detail above) was expressly endorsed by the Grand Chamber in O'Keefe v Ireland
_[(2014) 35 BHRC 601, (2014) 59 EHRR 605. These propositions have been reiterated by the second section of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3BS-00000-00&context=1519360)_
ECtHR most recently in BV v Belgium (App no 61030/08) (2 May 2017, unreported). At para 56 the court stated that
the obligation to carry out an effective investigation 'cannot be limited to cases of ill-treatment by agents of the
state'.
**A clear and constant line of authority?**

**[44] In** _R (on the application of Ullah) v Special Adjudicator, Do v Secretary of State for the Home Dept_ _[2004]_
_[UKHL 26, [2004] 3 All ER 785, [2004] 2 AC 323, Lord Bingham of Cornhill, at para [20], quoted with approval the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDW-G4B0-TWP1-60B4-00000-00&context=1519360)_
statement of Lord Slynn of Hadley in R (on the application of Alconbury Developments Ltd) v Secretary of State for
_the Environment, Transport and the Regions_ _[[2001] UKHL 23, [2001] 2 All ER 929, [2003] 2 AC 295(at [26]), where](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD5-S270-TWP1-60VN-00000-00&context=1519360)_
he said:

'Your Lordships have been referred to many decisions of the European Court of Human Rights on art 6 of the
convention. Although the 1998 Act does not provide that a national court is bound by these decisions it is
obliged to take account of them so far as they are relevant. In the absence of some special circumstances it
seems to me that the court should follow any clear and constant jurisprudence of the European Court of
Human Rights.'

**[45] The respondents argue that the authorities which I have reviewed above constitute clear and constant**
jurisprudence to the effect that the state has a duty under art 3 to conduct an effective investigation into crimes
which involve serious violence to an individual. In order that the protective right under the article be practical and
effective, the respondents also assert that failure to conduct such an investigation gives rise to a right to hold the
state to account by, among other things, a claim for compensation on the part of a person who was a victim of the
art 3 violation and the state's failure to discharge its obligations under the article.

**[46] The appellant counters this argument, claiming that the Strasbourg court's extensive case law (including**
decisions of the Grand Chamber) refers
**[*386]**

back to _Assenov as the authoritative source of the obligation, derived from art 3, to investigate allegations of ill-_
treatment by state agents. It is suggested that Assenov explicitly limits the investigative duty to cases where the illtreatment has been perpetrated 'by the police or other such agents of the State unlawfully and in breach of Article 3'
(para 102). This approach, it is claimed, has been followed by decisions of the Grand Chamber in such cases as
_Gafgen v Germany_ _[(2010) 28 BHRC 463, (2011) 52 EHRR 1 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN21-DYBP-W4T7-00000-00&context=1519360)_ _El-Masri v Former Yugoslav Republic of_
_Macedonia_ _[(2012) 34 BHRC 313, (2012) 57 EHRR 783.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1M5-00000-00&context=1519360)_

**[47] It is to be noted, of course, that Assenov was a case where the claim was based on allegations against state**
agents, namely, the Bulgarian police. When, therefore, the court expressed the view, which it did in para 102 of its
judgment, that, 'where an individual raises an arguable claim that he has been seriously ill-treated by the police or
other such agents of the State unlawfully and in breach of Article 3, that provision … requires by implication that
there should be an effective official investigation', it did not address the question whether such a duty arose where
the perpetrators of the ill-treatment were not state agents. It did not need to do so. The issue simply did not arise in
that case.

**[48] Likewise, in Gafgen the complaint was made concerning the applicant's ill-treatment by police. So also in El-**
_Masri the applicant claimed that he had suffered ill-treatment at the hands of state agents and that they had been_


-----

actively involved in his subsequent rendition by CIA agents. Statements in the judgments in both cases which echo
that in Assenov quoted in the preceding paragraph do not sound on the question whether ill-treatment by individuals
other than state agents can give rise to the duty to investigate under art 3. Those decisions do not impinge upon,
much less derogate from, the authority of the cases decided by ECtHR between 2005 and 2017 discussed in paras

[16] to [28] above. I consider that those cases amount to clear and constant case law of the Strasbourg court. And I
have concluded that they establish that the state is obliged under art 3 to conduct an effective investigation into
crimes which involve serious violence to persons, whether that has been carried out by state agents or individual
criminals. Further, in order that the protective right should be practical and effective, an individual who has suffered
ill-treatment contrary to art 3 has a right to claim compensation against the state where there has been a failure by
state authorities to conduct a sufficient investigation into the crime.

**[49] At para [127] of Lord Hughes' judgment, he suggests that the proper test for the positive obligation to**
investigate reports of past violence under art 3 is whether the state 'has a proper structure of legal provision
designed to punish it when it occurs and has administered [it] in good faith and with proper regard for the gravity of
the behaviour under consideration'. It is not clear whether this formulation excludes any investigation of operational
failings on the part of state authorities such as the police. Conceivably, I suppose, a failure to administer the proper
structure of criminal legal provisions might entail an examination of the way in which police conducted their inquiries
into a particular case. But, importantly, the duty to administer is qualified in Lord Hughes' exposition by the
stipulation that the administration of the structure of legal provision, if it is to fall foul of the test, must be shown to
have been conducted in bad faith or without proper regard for the gravity of the behaviour involved. This places an
obvious limitation on the scope of any review of the operational actions and decisions of the police. There is no
suggestion in this case, for instance, that the police acted in bad faith. It might possibly be said that there were
instances of the police failing to have regard for
**[*387]**

the gravity of the crimes which the respondents complained of but I am unsure whether this would fulfil Lord
Hughes' test because the failure to have due regard to the gravity of the crime must take place in the context of the
administration of the proper structure of legal provisions.

**[50] It is true, as Lord Hughes says in para [140], that there were structural errors. But I cannot agree with his**
statement that the various detailed failings in the conduct of the inquiry were 'largely attributable to this flawed
structural approach'. Green J dealt with the operational failures in these two cases in a long passage of his
judgment between paras [285] and [313]. Some of these were related by him to lack of training but many were not.
Significantly, the judge found that if the operational failings had not occurred, the police officers involved in the
investigation 'would have taken steps which would have been capable of identifying and arresting Worboys'.

**[51] It is unnecessary to list all the operational failings. These are set out in admirable and clear detail by the trial**
judge in his judgment. It is sufficient to refer to a sample of these to explain why I do not accept that these were
largely attributable to a flawed structural approach.

(i)   Reception staff failed to record relevant names, addresses and vehicle registration details. If these
had been recorded, it was 'perfectly feasible to believe', the judge found, that Worboys might have been
apprehended earlier or might even have been deterred from further offending;

(ii)   Failure to interview promptly a witness known as Kevin. He could have identified Worboys and could
have given evidence that might have led to his arrest;

(iii)   Failure to collect CCTV evidence. Worboys had driven his taxi to a police station. The timing of his
arrival at and departure from the police station was known. If police officers had checked the CCTV
footage, they could have identified the registration number and this would have led them to Worboys;

(iv)   Between 2003 and 2008 many complaints were made to police which should have been sufficient to
trigger the arrest of Worboys. The failure to make the link between these complaints was due not only to a
lack of training but also to a failure to adhere to procedures;

(v)   Failure to conduct searches.


-----

**[52] None of these failures can be described as a failure in training or in the structures that were in place for the**
investigation of serious crime at the material time. Many other operational failures, none of which can be ascribed to
a 'flawed structural approach' were found by Green J to have occurred. These were considered by him to have
contributed in a significant way to his finding that a breach of art 3 had been established. If I have understood Lord
Hughes' formulation of the relevant test correctly, none of them was relevant to that conclusion.

**[53] The prospect of every complaint of burglary, car theft or fraud becoming the subject of an action under the**
Human Rights Act has been raised. I do not believe that this is a serious possibility. All of the cases in this area
involve conspicuous and substantial shortcomings in the conduct of the police and prosecutorial investigation. And,
as this case illustrates, frequently, operational failures will be accompanied by systemic defects. The recognition
that really serious operational failures by police in the investigation of offences
**[*388]**

can give rise to a breach of art 3 cannot realistically be said to herald an avalanche of claims for every
retrospectively detected error in police investigations of minor crime.
**A systems or an operational duty?**

**[54] The appellant argued that MC v Bulgaria should not be taken as authority for the proposition that how the state**
carried out its investigative duty at an operational level required to be examined in order to determine whether art 3
had been breached. That case, it was said, involved a systemic problem with Bulgarian law in relation to sexual
offences. Under that law, it was not sufficient, in a rape prosecution, to show that a complainant had not consented
to sexual intercourse. It was necessary to show that she was incapable of defending herself, or that she had been
compelled by force or threats or that she had been brought to a state of defencelessness. The case was therefore
primarily concerned with the system of laws in Bulgaria, the appellant claimed, and the court did not find a breach of
art 3 because of any particular failing in the investigation in isolation, but because the legal system itself was
deficient. The appellant claims that nothing in the judgment says in positive terms that art 3 gives rise to an
obligation to investigate in cases where the state is not complicit in ill-treatment.

**[55] I do not accept these arguments. As pointed out in para [18] above, the Strasbourg court in** _MC clearly_
specified that the state's duty had two aspects. The first was to enact criminal-law provisions which would
effectively punish rape. The second, distinct but definite obligation was to carry out proper investigation and
prosecution so that the laws could be applied effectively. It should be noted that the applicant's complaint in that
case had two separate aspects, described in para 109 of the judgment as follows:

'The applicant complained that Bulgarian law and practice did not provide effective protection against rape and
sexual abuse as only cases where the victim had resisted actively were prosecuted and that the authorities had
_not investigated the events of July 31 and August 1 1995 effectively.' (Emphasis supplied)_

**[56] The second aspect of her complaint was elaborated on in para 117 of the judgment where it is recorded that**
she alleged that the investigation had not been thorough and complete. The crucial issue of the timing of all the
movements of the men and the applicant during the night in question had not been investigated.

**[57] The court's conclusions on the second aspect of the applicant's complaint were unmistakable. At paras 176–**
178 it said:

'176. The court recognises that the Bulgarian authorities faced a difficult task, as they were confronted with two
conflicting versions of the events and little “direct” evidence. The court does not underestimate the efforts
invested by the investigator and the prosecutors in their work on the case.

177. It notes, none the less, that the presence of two irreconcilable versions of the facts obviously called for a
context-sensitive assessment of the credibility of the statements made and for verification of all the surrounding
circumstances. Little was done, however, to test the credibility of the version of the events proposed by P and
A [the alleged rapists] and the witnesses called by them. In particular, the witnesses whose statements
contradicted each other, such as Ms T and Mr M, were not confronted. No

**[*389]**


-----

attempt was made to establish with more precision the timing of the events. The applicant and her
representative were not given the opportunity to put questions to the witnesses whom she accused of perjury.
In their decisions, the prosecutors did not devote any attention to the question whether the story proposed by P
and A was credible when some of their statements called for caution, such as the assertion that the applicant,
14 years old at the time, had started caressing A minutes after having had sex for the first time in her life with
another man.

178. The court thus considers that the authorities failed to explore the available possibilities for establishing all
the surrounding circumstances and did not assess sufficiently the credibility of the conflicting statements
made.'

**[58] Plainly, therefore, the court made a separate finding in relation to the inadequacy of the police investigation.**
This finding was entirely freestanding of its conclusions in relation to the systemic deficiencies in the Bulgarian law
in relation to rape. That approach has been consistently followed in the cases examined above. It is incontestably
clear, therefore, that the positive obligation to conduct a proper inquiry into behaviour amounting to breach of art 3
may constitute a violation of the state's duty under the article.
**Is state complicity a prerequisite?**

**[59] The answer to the argument that the positive obligation to investigate is animated only where there is state**
involvement in the acts said to breach art 3 can be simply supplied by reference to the passage from para 151 of
_MC quoted at para [17] above. The statement that positive obligations are not solely confined to cases of ill-_
treatment by state agents could not be clearer.

**[60] In fact, of course, statements to like effect appear repeatedly in ECtHR jurisprudence—see, for instance, para**
70 of Beganovicì quoted at para [37] above; Vasilyev where the applicant expressly disavowed any accusation of
[blame on the state authorities for the attack on him; and para 83 of Milanovic [2010] ECHR 44614/07 (mentioned at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X141-00000-00&context=1519360)
para [43] above) where the court said (para 83):

'In general, actions incompatible with art 3 of the Convention primarily incur the liability of a Contracting State if
they were inflicted by persons holding an official position. However, the obligation on the High Contracting
Parties under art 1 of the Convention to secure to everyone within their jurisdiction the rights and freedoms
defined in the Convention, taken in conjunction with art 3, also requires States to take measures designed to
ensure that individuals within their jurisdiction are not subjected to ill-treatment administered by other private
persons (see [A v UK _[(1998) 5 BHRC 137, para 22; Z v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_ _[(2001) 10 BHRC 384, para 73–75; E v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41D-00000-00&context=1519360)_ _[[2003] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G22T-00000-00&context=1519360)_
_[FLR 348]).'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G22T-00000-00&context=1519360)_

**[61] Likewise, in** _CAS v Romania (2012) 61 EHRR 479 where there was no question of state involvement in the_
sexual abuse of the first applicant, the court was unambiguous in its finding that this was not a prerequisite to a
breach of art 3. At para 69, it said:

'… the absence of any direct state responsibility for acts of violence that meet the condition of severity such as
to engage art. 3 of the Convention does not absolve the state from all obligations under this provision. In such

**[*390]**

cases, art. 3 requires that the authorities conduct an effective official investigation into the alleged ill-treatment
even if such treatment has been inflicted by private individuals.'

**[62] I am satisfied, therefore, that ECtHR has consistently held that it is not required that there be state involvement**
in the acts alleged to amount to breach of art 3. The appellant's argument based on that proposition must be
rejected.
**Compensation**

**[63] The themes outlined in para [6](iv) and (v) above may be taken together. They can be dealt with briefly.**
Compensation is by no means automatically payable for breaches of the art 3 duty to investigate and prosecute
crime As Lord Bingham pointed out in R (on the application of Greenfield) v Secretary of State for the Home Dept


-----

_[[2005] UKHL 14, [2005] 2 All ER 240, [2005] 1 WLR 673(at [8]), in many cases the Strasbourg court has treated the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FYY-B590-TWP1-607D-00000-00&context=1519360)_
finding of the violation as, in itself, just satisfaction under art 41 (although that was said in the context of art 6
breaches).

**[64] It is well settled, however, that the award of compensation for breach of a Convention right serves a purpose**
which is distinctly different from that of an order for the payment of damages in a civil action. As Lord Brown said in
_Van Colle_ _[[2008] 3 All ER 977, [2009] AC 225(at [138]):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T9K-8RS0-TWP1-612N-00000-00&context=1519360)_

'… convention claims have very different objectives from civil actions. Where civil actions are designed
essentially to compensate claimants for their losses, convention claims are intended rather to uphold minimum
human rights standards and to vindicate those rights. That is why time limits are markedly shorter … It is also
why s 8(3) of the [HRA] provides that no damages are to be awarded unless necessary for just satisfaction …'

**[[65] Laws LJ said in para [68] of his judgment in the Court of Appeal ([2016] 3 All ER 986, [2016] QB 161), that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)**
inquiry into compliance with the art 3 duty is 'first and foremost concerned, not with the effect on the claimant, but
with the overall nature of the investigative steps to be taken by the state'. I agree with that. The award of
compensation is geared principally to the upholding of standards concerning the discharge of the state's duty to
conduct proper investigations into criminal conduct which falls foul of art 3. In paras [72]–[78] of his judgment, Laws
LJ set out the systemic and operational failures of the appellant, quoting extensively from the judgment of Green J
as to the first of these. That catalogue of failures was considered to warrant the award of compensation to the
respondents, irrespective of the fact that they had received damages from both Worboys and CICA. I cannot find
any flaw in the judge's decision to award that compensation nor in the Court of Appeal's decision to uphold that
decision.
**The relevance of the circumstance that there is no common law duty of care**

**[66] In Van Colle and Smith, two associated cases heard together, the complaint was that police had failed to follow**
up reports of threats to kill. In _Van Colle, the alleged failure had resulted, it was claimed, in the killing of the_
individual who was the subject of the threats. In Smith, the victim was seriously injured. The first case was brought
solely under HRA, alleging violation of art 2. It failed on its facts. In Smith, no HRA claim was made. The appellant
relied solely on the common law, alleging negligence by the police. The House of Lords rejected the argument that
'the common law should now be
**[*391]**

developed to reflect the Strasbourg jurisprudence about the positive obligation arising under arts 2 and 3 of the
convention' (para [136]). A similar approach was taken by the majority in this court in Michael v Chief Constable of
_South Wales Police_ _[[2015] UKSC 2, [2015] 2 All ER 635, [2015] AC 1732.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FXB-8P21-DYBP-M543-00000-00&context=1519360)_

**[67] As Laws LJ, in the Court of Appeal in this case, pointed out, the essence of the argument on behalf of the**
appellants in those cases was that the common law rule (that police owe 'no general duty of care … to identify or
apprehend an unknown criminal, nor … a duty of care to individual members of the public who might suffer injury
through the criminal's activities …'— Hill v Chief Constable of West Yorkshire Police _[[1988] 2 All ER 238, [1989] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-601S-00000-00&context=1519360)_
53) should be moderated so as to accommodate the ECHR—para [30]. As he observed, the converse is contended
for in this appeal. The appellant and the Secretary of State argue that the exemption from liability of the police at
common law should be extended to claims advanced under HRA so that the two systems should be in harmony.
There are two reasons for rejecting the argument.

**[68] In the first place, the bases of liability are different, as mentioned at para [44] above. In as much as it was**
considered that the common-law duty should not be adapted to harmonise with the perceived duty arising under
ECHR, so should the latter duty remain free from the influence of the pre-HRA domestic law. Alternatively, it
requires, at least, to be considered on its own merits, without the encumbrance of the corpus of jurisprudence under
common-law.

**[69] Secondly and more importantly, no assumption should be made that the policy reasons which underlay the**
conclusion that an exemption of police from liability at common law apply mutatis mutandi to liability for breach of


-----

Convention rights. In Michael much of the debate as to whether police owed a duty to an individual member of the
public centred on the question whether there was a sufficient proximity of relationship between the claimant and the
police force against whom action was taken. No such considerations arise in the present context. The issue here is
simple. Did the state through the police force fail to comply with its protective obligation under art 3?

**[70] The other principal argument advanced on behalf of the police in Michael was that it would not be 'fair, just and**
reasonable' to impose liability on them for failings in individual cases. This is a concept with which the common law,
with its innate flexibility, can cope but it is not one which can easily be accommodated in Convention jurisprudence.
The police either have a protective duty under art 3 or they do not. The presence of the duty cannot depend on
one's conception of whether it is fair, just or reasonable for it to exist.

**[71] Lord Hughes has said (in para [132] of his judgment) that law enforcement and the investigation of crime**
involve a complex series of judgments and discretionary decisions; that they concern the choice of lines of inquiry,
the weighing of evidence and the allocation of finite resources. All of that is unexceptionable. But the claim that to
're-visit such matters step-by-step by way of litigation … would inhibit the robust operation of police work … divert
resources from current inquiries [and act as a deterrent] not a spur to, law enforcement' is unsupported by any
evidence. In the first place, none of the cases cited above required a painstaking, minute examination of decisions
taken by police. Nothing in the Strasbourg jurisprudence suggests that this would be appropriate, much less that it
would be even admissible, as the basis for advancing a claim under art 3. Carrying out police investigations
efficiently
**[*392]**

should not give rise to a diversion of resources. On the contrary, it should lead to more effective investigation of
crime, the enhancement of standards and the saving of resources. There is no reason to suppose that the
existence of a right under art 3 to call to account egregious errors on the part of the police in the investigation of
serious crime would do other than act as an incentive to avoid those errors and to deter, indeed eliminate, the
making of such grievous mistakes.

**[72] The statement made by Lord Hughes (in para [132]) about the undesirability of the investigation of terrorist**
activity and the 'delicate and difficult decisions' it involves being subject to review would be a powerful factor, if it
were a possible consequence of following the jurisprudence of ECtHR in this area. But, in my view, it is not. Nothing
in that case law supports the notion that a charter has been created for the examination of every judgment or choice
of strategy made. As I have said, only obvious and significant shortcomings in the conduct of the police and
prosecutorial investigation will give rise to the possibility of a claim. There is no reason to suppose that courts will
not be able to forestall challenges to police inquiries based on spurious or speculative claims.
**Should the question be left to Strasbourg?**

**[73] It was strongly argued, particularly on behalf of the Secretary of State, that the question whether a liability such**
as that contended for by the respondents arises was one on which ECtHR should be invited to pronounce. The subtext to this argument appeared to be that, where Strasbourg has not yet spoken, national courts should not venture
forth.

**[74] This argument carries echoes of those which found favour in such cases as R (on the application of Al-Skeini)**
_v Secretary of State for Defence_ _[2007] UKHL 26,_ _[[2007] 3 All ER 685, [2008] 1 AC 153, and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PDJ-CV20-TWP1-60ND-00000-00&context=1519360)_ _Ambrose v Harris_
_(Procurator Fiscal, Oban_ _[2011] UKSC 43,_ _[[2012] 3 LRC 70, [2011] 1 WLR 2435. In](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565X-1F41-DYJ0-80H4-00000-00&context=1519360)_ _Al-Skeini Lord Brown_
suggested that where ECtHR had not spoken, our courts should hold back, explaining that, if it proved that
Convention rights have been denied by too narrow a construction, the aggrieved individual can have the decision
corrected in Strasbourg. And in R (on the application of Smith) v Secretary of State for Defence _[2010] UKSC 29,_

_[[2010] 3 All ER 1067, [2011] 1 AC 1Lord Phillips followed a similar line.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:50XS-GCR1-DYBP-M373-00000-00&context=1519360)_

**[75] The difficulty with the argument is that it fails to address the circumstance that the courts of this country,**
constituted as they are as public authorities, must give effect to (or refuse to give effect to) Convention rights as a
matter of domestic law. The HRA introduced to the law of the United Kingdom the European Convention on Human
Rights and Fundamental Freedoms by making the Convention part of national law so that the rights became


-----

domestic rights. Because the rights are domestic, they must be given effect according to the correct interpretation of
the domestic statute. As Lord Hoffmann said _Re P (Adoption: Unmarried Couple) [2008] UKHL 38,_ _[[2008] 2 FLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3TY-00000-00&context=1519360)_
_[1084, [2009] AC 173(para [34]) '[the courts'] first duty is to give effect to the domestic statute according to what they](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3TY-00000-00&context=1519360)_
consider to be its proper meaning, even if its provisions are in the same language as the international instrument
which is interpreted in Strasbourg'.

**[76] The so-called 'mirror principle' (whereby pronouncements by national courts on Convention rights should**
precisely match those of Strasbourg) is often attributed to Lord Bingham's statement in Ullah at para [20] where he
said 'The duty of national courts is to keep pace with the Strasbourg
**[*393]**

jurisprudence as it evolves over time: no more, but certainly no less'. As explained in para [232] of Keyu v Secretary
_of State for Foreign and Commonwealth Affairs_ _[2015] UKSC 69,_ _[[2016] 4 All ER 794, [2016] AC 1355, Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M6M-Y091-DYBP-M1X7-00000-00&context=1519360)_
Bingham was careful to refer to the interpretation of the Convention (as opposed to the interpretation of HRA).
Despite this, his opinion in that case has been used in a number of subsequent judgments to support the
proposition that the content of domestic rights under HRA should not, as a matter of principle, differ from that
pronounced by Strasbourg. Indeed, his judgment has been construed as indicating that, unless ECtHR has given
clear guidance on the nature and content of a particular Convention right, the national courts of the United Kingdom
should refrain from recognising the substance of a claimed entitlement under ECHR—see, for instance, Al-Skeini,
_Smith and Ambrose, referred to in para [74] above._

**[77] In more recent cases, a departure from the mirror principle can be detected. Thus, in Rabone v Pennine Care**
_NHS Foundation Trust [2012] UKSC 2,_ _[[2012] 2 All ER 381, [2012] 2 AC 72it was held that there was a positive](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55D5-29K1-DYBP-M0HT-00000-00&context=1519360)_
obligation to protect the life of a mentally ill young woman who had been admitted to hospital informally because of
serious attempts to take her own life. This decision was reached notwithstanding the fact that there was no authority
from ECtHR to that effect. In P v Cheshire West and Chester Council, P v Surrey CC _[[2014] UKSC 19, [2014] 2 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C3W-8501-DYBP-M1BF-00000-00&context=1519360)_
_[ER 585, [2014] AC 896(para [62]) Lord Neuberger said that where there was no Strasbourg authority which dealt](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C3W-8501-DYBP-M1BF-00000-00&context=1519360)_
precisely with the issues before this court, this court could rely on principles expressed by ECtHR, even if only
indirectly relevant, and apply them to the cases which it had to decide. And in _Moohan v Lord Advocate_ _[2014]_
_[UKSC 67, [2015] 2 All ER 361, [2015] AC 901Lord Wilson suggested that there had been a 'retreat' from the Ullah](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FR0-X8N1-DYBP-M3MC-00000-00&context=1519360)_
principle which had led the court to 'substantially' modify it. At para [105] he said:

'… where there is no directly relevant decision of the ECtHR with which it would be possible (even if
appropriate) to keep pace, we can and must do more. We must determine for ourselves the existence or
otherwise of an alleged Convention right …'

**[78] This seems to me to be inescapably correct. Reticence by the courts of the UK to decide whether a Convention**
right has been violated would be an abnegation of our statutory obligation under s 6 of HRA. This section makes it
unlawful for a public authority, including a court, to act in a way which is incompatible with a Convention right.

**[79] As it happens, of course, I consider that the jurisprudence of the Strasbourg court is clear and constant on the**
issues which this court has to decide. Even if it were not, however, I would firmly reject the suggestion that the
decision of this court on whether the respondents enjoy a right under the HRA to claim compensation against the
appellant should be influenced, much less inhibited, by any perceived absence of authoritative guidance from
ECtHR.
**Conclusion**

**[80] For these reasons and for those given in the judgment of Lord Neuberger, with which I agree, I would dismiss**
the appeal.

**LORD NEUBERGER**

(with whom Lady Hale P agrees).


-----

**[81] The claimants, DSD and NBV, succeeded before Green J ([2014] EWHC 2493 (QB),** _[[2015] 2 All ER 272,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FN9-JCC1-DYBP-M07W-00000-00&context=1519360)_

[2015] 1 WLR 1833) in establishing that they
**[*394]**

were entitled to damages from the defendant, the Commissioner of the Police of the Metropolis, as a result of
failures by the police properly to investigate serious sexual assaults which had been perpetrated against them. The
claims were founded on the propositions that (i) art 3 of the European Convention for the Protection of Human
Rights and Fundamental Freedoms 1950 (as set out in _Sch 1 to the Human Rights Act 1998) carries with it an_
obligation on the state to carry out an effective investigation when it receives a credible allegation that serious harm
has been caused to an individual, and (ii) there were serious defects in the police investigation of the assaults on
the claimants.

**[[82] The Court of Appeal upheld the decision ([2015] EWCA Civ 646, [2016] 3 All ER 986, [2016] QB 161), and this](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)**
court takes the same view. However, we disagree on one issue. That issue is whether a person in the claimants'
position needs to establish that the serious defects in the investigation in question were attributable to failures of a
structural nature (also referred to as systems, or systemic, failures), and not to purely operational failures (ie failings
on the part of the individual police officers responsible for conducting the specific investigation).

**[83] We do not need to decide this issue in order to resolve the appeal, but I agree that we should do so. It has**
been fully and helpfully argued by the parties and the interveners, the competing arguments have been admirably
expounded by Lord Kerr and Lord Hughes, and it seems to me to be an important issue which should be decided if
possible.

**[84] The competing arguments have been fully set out in the judgments of Lord Kerr and Lord Hughes. Lord Kerr**
favours the wider approach, namely that a claimant need only establish serious defects in the investigation into her
particular case, irrespective of whether they are systemic or operational failures. Lord Hughes prefers the narrower
approach, the effect of which is that a claimant has to establish serious failings of a systemic nature, and that
failings of a purely operational nature will not suffice, at least where the perpetrator of the alleged assault was not a
state agent.

**[85] In agreement with Lord Kerr, I am of the view, that serious failures which are purely operational will suffice to**
establish a claim that an investigation carried out pursuant to an art 3 (or indeed an art 2) duty infringed that duty.

**[86] So far as the Strasbourg jurisprudence is concerned, I consider that the judgments to which we have been**
referred support the wider approach. The investigatory duty was identified in Assenov v Bulgaria _[(1998) 28 EHRR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
_[652, [1998] ECHR 24760/94 (para 102), where the court said that art 3, read with art 1, 'requires by implication that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
there should be an effective official investigation' into cases where 'an individual raises an arguable claim that he
has been seriously ill-treated by the police or other such agents of the State unlawfully and in breach of Article 3'. I
also note that the wider approach appears to have been adopted by the Grand Chamber in the art 2 case of Tunç v
_Turkey (App no 24014/05) (14 April 2015, unreported)—see at paras 183–209._

**[87] I accept of course that those decisions were concerned with cases of ill-treatment by state agents, and that the**
approval of the principle in other decisions of the Grand Chamber (eg _Gafgen v Germany_ _[(2010) 28 BHRC 463,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN21-DYBP-W4T7-00000-00&context=1519360)_
(2011) 52 EHRR 1 and El-Masri v Former Yugoslav Republic of Macedonia _[(2012) 34 BHRC 313, (2012) 57 EHRR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1M5-00000-00&context=1519360)_
783) were also concerned with such cases. I also accept that the standard which a court should apply when
considering whether the investigatory duty has been satisfied may well be more stringent in cases where the
alleged ill-treatment was caused by state agents than in cases where
**[*395]**

it was caused by others. However, I see no basis for holding that the duty is different in kind in the two types of
case. While in a number of Strasbourg court decisions, it is stated that the duty extends to cases where the alleged
ill-treatment was caused by third parties, there is no suggestion that the nature of the duty to investigate is different
in kind in the two types of case. Thus, in the recent case of _BV v Belgium (App no 61030/08) (2 May 2017,_
unreported) (para 56) the court stated that the obligation to carry out an effective investigation 'cannot be limited to


-----

cases of ill-treatment by agents of the state', without suggesting that there was any difference in the basic nature of
the duty.

**[88] It is true that in** _Beganovicì v Croatia_ _[[2009] ECHR 46423/06 (para 69) the court said that 'the scope of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_
State's positive obligations might differ between cases where treatment contrary to art 3 of the Convention has
been inflicted through the involvement of State agents and cases where violence is inflicted by private individuals'.
However, even without considering other decisions of the Strasbourg court, that seems to me to be a very small
peg on which to hang a contention that the two cases require approaches which differ in nature. In any event, when
that observation was repeated in Vasilyev v Russia _[[2009] ECHR 32704/04 (para 100) the court immediately went](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_
on to make the point that 'the requirements as to an official investigation are similar', and that was a point repeated
in a number of subsequent decisions—see eg _Koky v Slovakia_ _[[2012] ECHR 13624/03 (para 215),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X027-00000-00&context=1519360)_ _Amadayev v_
_Russia_ _[[2014] ECHR 18114/06 (para 70) and MC v Romania (App no 12060/12) (12 April 2016, unreported) (para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X29G-00000-00&context=1519360)_
111). Indeed, I note that in Beganovicì itself, when considering whether the investigatory duty had been complied
with in a case where the alleged perpetrator had been a non-state agent, the court said in para 74 that it should
consider 'whether or not the impugned regulations and practices, and in particular the domestic authorities'
compliance with the relevant procedural rules, as well as the manner in which the criminal-law mechanisms were
implemented in the instant case, were defective to the point of constituting a violation of the respondent state's
positive obligations under art 3'. And the subsequent analysis of the facts in paras 80–86, which led the court to
conclude that there had been a violation in that case, focussed very much on the operational failures.

**[89] That approach appears to be supported by other Strasbourg court decisions involving the investigatory duty in**
relation to acts of serious ill-treatment by non-state agents. There is no suggestion in _MC v Bulgaria_ _[(2003) 15](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
_[BHRC 627, (2005) 40 EHRR 459 that that duty is restricted to having effective systems in place: at para 153, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
court referred to the duty of a state 'to enact criminal law provisions effectively punishing rape and to apply them in
practice through effective investigation and prosecution'. In para 167, the court seems to me to have been referring
to both systemic and operational failures when it mentioned 'significant flaws' in 'the impugned legislation and
practice and its application in the case at hand, combined with the alleged shortcomings in the investigation' (and
see para 179). The finding of inadmissibility in _Szula v UK (2007) 44 EHRR SE19 appears to me to have been_
based on the assumption that operational failures would, in principle, suffice to found a claim—see para 1.

**[90] To the same effect, in Secic v Croatia** _[(2007) 23 BHRC 24, (2007) 49 EHRR 408, the court said in para 54 that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0G8-00000-00&context=1519360)_
the police should have taken 'all reasonable steps available to them' to obtain relevant evidence, which, as a matter
of ordinary language, naturally refers to operational steps. In para 59 the court
**[*396]**

concluded that what appear to me to have been operational, rather than structural, failures (summarised in paras
56–58) enabled the art 3 claim to succeed. In _Beganovicì, para 75, the court made the point that 'the duty to_
investigate' involved 'the authorities [having to] take whatever reasonable steps they can to secure the evidence
concerning the incident'—which covers operational matters at least as much as systems. Vasilyev is another case
where the court described the duty in terms which are, at least in my view, significantly more consistent with the
wider approach, namely that 'the authorities [should] conduct an effective investigation' involving 'the reasonable
steps available to them' (paras 99 and 100). In the 2016 case of _Chernaya v Ukraine (App no 1661/08) (15_
December 2016, unreported), which involved an injury inflicted by a non-state agent, the court reiterated in para 25
that '[t]he minimum standards of effectiveness laid down by the Court's case law include the requirements that the
investigation be independent, impartial and subject to public scrutiny, and that the competent authorities must act
with exemplary diligence and promptness'—again focusing on the operational aspects of the particular
investigation.

**[91] Of course, this court is not required to follow Strasbourg jurisprudence, even in a case such as this where there**
is a clear and consistent approach adopted in a significant number of chamber decisions. Dialogue between the
United Kingdom Supreme Court (and indeed other courts in the United Kingdom) and the Strasbourg court has
proved to be beneficial to the development of human rights law in this jurisdiction—and, I hope, in Strasbourg.
Accordingly, if it appears to us that the narrower approach is even only probably correct, the fact that the
Strasbourg court has consistently taken a different view should not necessarily stand in the way of our coming to a


-----

contrary conclusion. In this case, the notion that we can take such a course can fairly be said to be supported by
the fact that, although it is inconsistent with the views expressed in a number of decisions of the Strasbourg court,
the notion that the narrower approach is correct has not, so far as I can see, been specifically raised in that court.
But there must be a good reason for our taking such a course, and in this case, at least in my view, there is not.

**[92] Indeed, in my view, there are good reasons for favouring the wider approach. First, one starts with the**
proposition that, given that it is rightly accepted on all sides that the authorities have an investigatory duty, it would
be of little value unless it was a duty to investigate effectively. Provided that courts bear clearly in mind 'the
difficulties involved in policing modern societies, the unpredictability of human conduct and the operational choices
which must be made in terms of priorities and resources' and the need to interpret the duty 'in a way which does not
impose an impossible or disproportionate burden on the authorities' (Osman v UK _[(1998) 5 BHRC 293, (1998) 29](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_
EHRR 245 (para 116)), I find it hard to understand why an investigation which is seriously defective in purely
operational terms should, in effect, be held to satisfy the investigatory duty.

**[93] Secondly, I cannot see any basis in its jurisprudence to suggest that it is likely that the Strasbourg court would**
think it right to limit the extent of the investigatory duty to systemic, as opposed to operational, failures. It is true that
in A v UK _[(1998) 5 BHRC 137, (1998) 27 EHRR 611, having held that art 3, together with art 1, 'requires states to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_
take measures designed to ensure that individuals within their jurisdiction are not subjected to torture or inhuman or
degrading treatment or punishment', the court concluded that then-current statutory provisions 'did not provide
adequate protection to the applicant
**[*397]**

against treatment or punishment contrary to art 3' and that 'the failure to provide adequate protection constitutes a
violation of art 3' (paras 21 and 24). However, that conclusion merely reflected the factual basis and arguments in
the case. If the statute did not provide adequate protection, there was a systemic failure, and it was both
unnecessary and pointless to consider the operational aspects of the legal system. However, clearly to my mind, it
does not follow that, if the statutory provisions had complied with art 3, but the legal processes had been defective,
the United Kingdom would have been acquitted of infringing art 3. Indeed, the court's summary of the law in A v UK
(para 22) contains nothing to suggest that the state's obligation there being discussed should be limited to systemic
matters.

**[94] Similarly, while the court in** _Osman (para 116) was concerned to ensure that the investigatory duty was not_
interpreted or applied unrealistically, there is no indication in that paragraph that it was intending to limit the duty to
the provision of a satisfactory framework, irrespective of how ineptly it operated in a particular case. Indeed, such
an approach would seem to me to be inconsistent with how the Strasbourg court approaches cases generally,
namely by reference to the specific facts of the particular case.

**[95] Thirdly, there are forensic considerations. In that connection, I would start by rejecting the notion that it could**
be right for a court to dismiss a claim that an investigation was seriously defective simply because the relevant
police procedures as set out in official documents were satisfactory. It would not merely be formalistic, but both
unjust and unrealistic, to hold that an investigation, which was seriously systematically defective in practice,
nonetheless complied with the art 3 investigatory duty simply on the grounds that, while the systemic defects
occurred in practice, they did not reflect the systems as laid down officially. Whether the wider or the narrower
approach is correct, the court must surely consider the real, not the hypothetical.

**[96] Once that is accepted, I consider that the narrower approach could present a court with difficult practical,**
categorisation, and apportionment issues. Whichever approach applies, a court must inevitably start by considering
the failures in the particular case. On the wider approach, the court would simply ask whether those failures were
sufficiently serious to represent an infringement of the investigatory duty. On the other hand, on the narrower
approach, the court would have to consider which of the failures were operational and which were systemic, and
that, as I see it, is where problems would often start. Serious operational failures by individual officers would
frequently throw up arguable systemic issues, such as systems of supervision or even of appointment of those
officers. And, in order to decide whether the operational failures were systemic in origin, the court might often have
to embark on an inquiry whether, for instance, the failures were redolent of what happened in other investigations.


-----

That could involve a potentially time-consuming and expensive inquiry into other investigations, as well as
arguments as to the number and types of investigation, if any, to which the inquiry should be restricted. The
question whether the defective investigation was attributable to systemic, rather than purely operational, failures
could also involve difficult issues of categorisation and inference. For instance, in many cases it may be hard to
decide whether a particular failure is operational or systemic, or whether the operational failures in an investigation
or a set of investigations entitle the court to infer a systemic failure. And what happens if, as may very often be the
case, there are some operational failures which are purely operational and some which are attributable to structural
failures?
**[*398]**

**[97] I do not consider that my view is undermined by the reasoning expressed or conclusions reached in Hill v Chief**
_Constable of West Yorkshire Police_ _[[1988] 2 All ER 238, [1989] AC 53, Brooks v Metropolitan Police Comr [2005]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-601S-00000-00&context=1519360)_
_[UKHL 24, [2005] 2 All ER 489, [2005] 1 WLR 1495, Van Colle v Chief Constable of Hertfordshire Police, Smith v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4G4F-CJY0-TWP1-600J-00000-00&context=1519360)_
_Chief Constable of Sussex Police_ _[2008] UKHL 50,_ _[[2008] 3 All ER 977, [2009] AC 225and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T9K-8RS0-TWP1-612N-00000-00&context=1519360)_ _Michael v Chief_
_Constable of South Wales Police_ _[[2015] UKSC 2, [2015] 2 All ER 635, [2015] AC 1732. Those cases establish that,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FXB-8P21-DYBP-M543-00000-00&context=1519360)_
absent special factors, our domestic law adopts the view that, when investigating crime, the police owe no duty of
care in tort to individual citizens. That is because courts in this country consider that the imposition of such a duty
would, as Lord Hughes puts it, 'inhibit the robust operation of police work, and divert resources from current
inquiries; it would be detrimental to, not a spur, to law enforcement'. That view is entirely defensible, but, at least in
the absence of concrete evidence to the contrary, so is the opposite view that the imposition of such a duty,
provided that it is realistically interpreted and applied, would serve to enhance the effectiveness of police
operations. It is therefore understandable that human rights law, with its investigatory duty under art 2 and 3, differs
from domestic tort law in holding that it is right to impose an investigatory duty on the police. Just as the majority of
this court accepted in _Michael, at paras [123]–[128], that the domestic tortious test for liability should not be_
widened to achieve consistency with the human rights test, so should the human rights test for liability not be
narrowed to achieve consistency with the domestic, tortious test.

**[98] Finally, I turn to an argument which I have already touched on, namely that the wider interpretation involves**
placing too great a burden on public authorities, in particular on the police. This concern was recognised in relation
to the similar art 2 obligation on the police in Osman v UK _[(1998) 5 BHRC 293, (1998) 29 EHRR 245 (para 116),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_
where, as I have mentioned, the Strasbourg court said that the 'obligation must be interpreted in a way which does
not impose an impossible or disproportionate burden on the authorities' (and see to the same effect CN v UK _[(2012)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_
_[34 BHRC 1, (2012) 56 EHRR 24 (para 68)). The point was developed in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_ _MC v Bulgaria, where at para 168, the_
Strasbourg court made it clear that, when considering whether an investigation had satisfied art 2, a court should
not be 'concerned with allegations of errors or isolated omissions in the investigation'. As the Grand Chamber said
in _Tunç v Turkey_ (para 176), 'the nature and degree of scrutiny which satisfy the minimum threshold of the
investigation's effectiveness depend on the circumstances of the particular case'. The court in that case went on to
find 'shortcomings' in the investigation, but held that there had been no infringement of art 2, because they were not
'serious' or 'decisive' (paras 189 and 195), and it concluded in para 209 that there were 'no such shortcomings as
might call into question the overall adequacy and promptness of the investigation'. And in _Beganovicì v Croatia,_
para 78, the Strasbourg court emphasised that it should only conclude that the investigatory duty had been
infringed 'in cases of manifest disproportion between the gravity of the act and the results obtained at domestic
[level' (citing the earlier decisions of Nikolova v Bulgaria (2007) 48 EHRR 915, [2007] ECHR 7888/03 (para 62) and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2XD-00000-00&context=1519360)
_Atalay v Turkey_ _[[2008] ECHR 1249/03 (para 40), which are to the like effect). It is because of the concern](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2PY-00000-00&context=1519360)_
expressed in Osman (para 116) that it is important to emphasise that only 'serious' defects in any investigation can
lead to the conclusion that there has been an infringement of art 2 or art 3.
**[*399]**

**[99] Accordingly, I conclude that a claim based on serious defects in the performance of the investigatory duty**
under art 3 (and equally under art 2) can succeed even if defects are all of a purely operational, as opposed to a
systemic, nature.

**[100] For these reasons, which are little more than a summary of those given by Lord Kerr, with whose judgment I**
agree I would therefore dismiss this appeal


-----

**LORD HUGHES.**

**[101] I agree that the appeal of the Metropolitan Police in this case should be dismissed. It seems to me, however,**
important that the ambit of the positive duties which arise under art 3 of the European Convention for the Protection
of Human Rights and Fundamental Freedoms 1950 (as set out in Sch 1 to the Human Rights Act 1998) ('ECHR')
should be subject to examination, if not that an exhaustive definition should be attempted.

**[102] The context in which this case comes to this court needs to be remarked. It is unusual. The treatment under**
consideration is the very serious offence of rape of victims who were exploited after putting themselves in
apparently trustworthy hands (a black cab driver) and who had then been rendered helpless by stupefaction. There
has been no dispute from the beginning that there were notable general failings in the police approach to
investigation into the kind of complaint which both claimants made. They affected both the initial complaint by DSD
in 2003, at least from the time of the morning after the event, at which stage she first realised that she had been
sexually attacked, and the later complaint by NBV in 2007. The findings recorded by the judge in a meticulous
judgment were almost entirely to the same effect as, and were grounded upon, the police's own conclusions,
following detailed internal reports, about the deficiencies of their approach to the possibility of drug induced rape.
The consequences were extremely serious. Because the first incident reported was not approached properly, the
attacker remained undetected and became a serial rapist. Although only a small proportion (ten) of his many
attacks were reported to the police at the time, it is now known that he raped more than 100 women, employing a
similar method. His modus operandi was highly specific. Once anyone put two or more of the reported incidents
side by side, the inference that there was a single serial offender was irresistible. Once that was done, early in
2008, the rapist was arrested, and compelling evidence against him found, within eight days. That could and should
have been done years earlier. Recognising the substantial justice of the complaints, the police have made it clear
that in the event that their appeal should be successful, they do not seek repayment of the compensation ordered
by the judge. But the elementary justice of the complainants' cases makes it all the more important that the ambit of
the duty should be considered. Otherwise indignation at their experiences may lead to an over-wide formulation
passing unnoticed, with detrimental results for the criminal justice system.
**The origin of the positive duties**

**[103] Article 3 ECHR says this:**

'No one shall be subjected to torture or to inhuman or degrading treatment or punishment.'

**[*400]**

**[104] It is elementary that, as Laws LJ pointed out in the Court of Appeal in the present case ([2015] EWCA Civ**
_[646, [2016] 3 All ER 986, [2016] QB 161), the obligations created by the Convention lie upon the party states and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KM0-N9D1-DYBP-M4MD-00000-00&context=1519360)_
upon no one else. The Convention governs the relationship between the state and the citizen. It creates no duties
for individuals. Article 1 is explicit. It is on the states that it imposes the obligation to 'secure' to those within their
jurisdiction the rights and freedoms defined in the Convention. It is perfectly clear that the primary case of behaviour
which is a breach of art 3 is where torture or inhuman or degrading treatment is meted out by the state against a
person within its jurisdiction. Even without the origins of the Convention in the aftermath of the Second World War,
the very use of the expressions 'torture' and 'inhuman or degrading treatment' is sufficient demonstration of that;
these are typically descriptions of state misbehaviour. And the same is demonstrated by the words 'subjected to'. If
the state inflicts such treatment, it has subjected the citizen to it. Anything beyond that is a judicial gloss on the
Convention, well established as that gloss may now be. In fact, there have been developed two glosses. Similar
glosses have been applied to the primary obligation in art 2, concerning the right to life, and it may be to other
rights.

**[105] The first gloss was explained by the Strasbourg court in** _Assenov v Bulgaria_ _[(1998) 28 EHRR 652,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_ _[[1998]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
_[ECHR 24760/94, in which there was an allegation of police violence towards a suspect in custody. It builds on the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
primary obligation of the state not itself to inflict prohibited treatment on the individual. If that primary obligation
stood alone, it might well be ineffective because the state organ which inflicts such treatment may deny it or cover it
up. It will be effective only if, when there is a reason to think that such ill-treatment may have been inflicted by a


-----

state organ, there is an ancillary 'positive obligation' to take steps to investigate the allegation and to bring to book
those who are found to be responsible. At para 102 the court set out the reason for this obligation:

'The Court considers that … where an individual raises an arguable claim that he has been seriously ill-treated
by the police or other such agents of the State unlawfully and in breach of Article 3, that provision, read in
conjunction with the State's general duty under Article 1 of the Convention to “secure to everyone within their
jurisdiction the rights and freedoms in [the] Convention”, requires by implication that there should be an
effective official investigation. This obligation, as with that under Article 2, should be capable of leading to the
identification and punishment of those responsible. If this were not the case, the general legal prohibition
**of torture and inhuman and degrading treatment and punishment, despite its fundamental importance,**
**would be ineffective in practice and it would be possible in some cases for agents of the State to abuse**
**the rights of those within their control with virtual impunity.' (Emphasis supplied)**

**[106] The same rationale was explained (in the context of the ancillary art 2 positive obligation to investigate state**
responsibility for death in custody) by Lord Bingham in R (on the application of Amin) v Secretary of State for the
_Home Dept_ _[[2003] UKHL 51, [2003] 4 All ER 1264, [2004] 1 AC 653(at [31]). The purpose of the duty is, he said:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7P90-TWP1-61DP-00000-00&context=1519360)_

'to ensure so far as possible that the full facts are brought to light; that culpable and discreditable conduct is
exposed and brought to public notice;

**[*401]**

that suspicion of deliberate wrongdoing (if unjustified) is allayed; that dangerous practices and procedures are
rectified; and that those who have lost their relative may at least have the satisfaction of knowing that lessons
learned from his death may save the lives of others.'

The reference to culpable and discreditable conduct was plainly to such conduct on the part of state organs. The
nature of the obligation was neatly summed up by Jackson J in R (on the application of Wright) v Secretary of State
_for the Home Dept_ _[2001] EWHC Admin 520, (2001)_ _[62 BMLR 16, [2001] UKHRR 1399 in terms repeated by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FNG-MXM0-TWW8-X0D4-00000-00&context=1519360)_
Sedley LJ in R (on the application of AM) v Secretary of State for the Home Dept _[[2009] EWCA Civ 219, [2009] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V7X-C600-Y96Y-H3MX-00000-00&context=1519360)_
_[ER (D) 171 (Mar): that an art 2 or art 3 investigation 'is required in order to maximise future compliance with those](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V7X-C600-Y96Y-H3MX-00000-00&context=1519360)_
articles'.

**[107] The second gloss is different and is the one in question in the present case. It concerns ill-treatment not by**
the state but by an individual or other third party actor. Plainly a citizen may be subjected to inhuman or degrading
treatment (or torture) by a fellow citizen. It has become commonplace to speak of this as a breach of art 3, but it is
not. An individual cannot be in breach of the Convention. In the ordinary way, if treatment falling within art 3 is
applied by A to B, then A may have subjected B to it, but the state has not. The state's responsibility is simply not
engaged. But it may be if, and only if, the state fails to take steps to afford its protection to B against A's
misbehaviour. In that event, it is still not a case of the state subjecting the individual to inhuman or degrading
treatment, but by judicial gloss the article is read as carrying with it an unspoken but implicit 'positive obligation'
upon the state to afford its protection.

**[108] This second gloss has the potential to extend considerably wider than the first. Whilst the first is concerned to**
give effect to the primary obligation of the state not itself to subject people to inhuman or degrading treatment, the
second reaches into the question of what the state is bound to do in relation to the acts of people for whose
behaviour it is not responsible. When one comes to this question, there are considerations which do not apply to the
first gloss.

**[109] Even in the most law-abiding of states, that sometimes serious harm will be inflicted by one individual upon**
another, in the context of all manner of disputes and in pursuit of many different objectives, is a regrettably
unavoidable feature of life. No one suggests that the state is bound to guarantee that this will not happen. Indeed,
some steps which an authoritarian state might be inclined to take with a view to preventing it (such as preventive
detention without conviction or other court order, house arrest, intensive surveillance and the like) might themselves
be infringements of other fundamental rights afforded to the citizen. That consideration apart, the systems which


-----

states adopt for the protection of those within their boundaries do not have to be the same. It has never been
suggested that it is the function of the Convention to monitor every act of enforcement or policing of the varied
domestic legal requirements, nor the content of those requirements, so long as they provide sufficiently for the
protection of the individual against third party behaviour which meets the high threshold of severity contemplated by
art 3. Otherwise, what would be involved would not be a gloss on the primary obligation imposed by art 3, nor would
the 'positive obligation' be in any sense ancillary to that primary obligation. Rather, the duty would be of a
**[*402]**

completely different character to the primary obligation, and would entail wholesale assimilation of, and judicial
control of, the legal systems of independent states.

**[110] The positive obligation constituted by this second gloss—relating to the protection of citizens from third party**
ill-treatment—requires first that the state have a legal framework for the prohibition of conduct passing the art 3
threshold, and thus afford the protection of its legal system against such behaviour. A v UK _[(1998) 5 BHRC 137,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_
(1998) 27 EHRR 611 was an example of a legal system which failed to provide sufficient protection to children
against the infliction of serious harm via corporal punishment, until the former English defence of 'reasonable
chastisement' was altered. Such cases concern the structure of a state's system.

**[111] The more difficult question is whether the implied positive obligation recognised by the second gloss extends**
beyond the structure of the state's system to its operation in an individual case. The Strasbourg court confronted
this in Osman v UK _[(1998) 5 BHRC 293, (1998) 29 EHRR 245, where the complaint was that the police force had](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_
failed sufficiently to heed reports suggesting that an obsessive might be a danger to an individual, who had then
been attacked and almost killed (and his father killed). The context was the equivalent gloss on art 2, but the
principles are the same as for art 3. The court concluded that the implied positive obligation to protect could apply
but in narrow circumstances of 'a real and immediate risk to the life of an identified individual by a third party, of
which risk the State either knew or ought to have known'. If such an immediate threat exists, then the state's
obligation is to do what can reasonably be expected of it which might reasonably have avoided the risk; it is not
limited to a duty to avoid gross negligence. As Lord Bingham observed in _Van Colle v Chief Constable of_
_Hertfordshire Police, Smith v Chief Constable of Sussex Police_ _[2008] UKHL 50,_ _[[2008] 3 All ER 977, [2009] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T9K-8RS0-TWP1-612N-00000-00&context=1519360)_
225(at [29]), it is quite apparent that every ingredient of this carefully drafted test is of importance. It defines the
restricted circumstances in which a duty arises under the Convention to take reasonable operational steps to
forestall known specific threats to the safety of an individual from eventuating.

**[112] The court in Osman made clear the reason why this test is restrictive. It lies in the realities of law enforcement**
and policing. At para 116 it said this:

'For the court, and bearing in mind the difficulties involved in policing modern societies, the unpredictability of
human conduct and the operational choices which must be made in terms of priorities and resources, such an
obligation must be interpreted in a way which does not impose an impossible or disproportionate burden on the
authorities. Accordingly, not every claimed risk to life can entail for the authorities a convention requirement to
take operational measures to prevent that risk from materialising. Another relevant consideration is the need to
ensure that the police exercise their powers to control and prevent crime in a manner which fully respects the
due process and other guarantees which legitimately place restraints on the scope of their action to investigate
crime and bring offenders to justice, including the guarantees contained in art 5 and 8 of the Convention.'

**[113] This duty recognised in** _Osman is a duty to take reasonable steps not to enforce the law or to punish a_
perpetrator, but to prevent serious violence from occurring to an individual when the threat of it is sufficiently
specific. It is an expansion of the second gloss beyond the requirement for structures and
**[*403]**

systems to render serious violence unlawful, but it is carefully narrow in extent. The House of Lords faithfully
applied Osman in Van Colle v Chief Constable of Hertfordshire Police.


-----

**[114] What has happened since is that the second gloss has been further extended beyond prevention of**
anticipated violent crime to a duty to investigate reported past violence. The usually identified origin of this further
extension is _MC v Bulgaria_ _[(2003) 15 BHRC 627, (2005) 40 EHRR 459. There is no doubt that the formulation](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
adopted in that case has been often repeated, usually word for word, in later cases. In that sense there is, no doubt,
a consistent line of authority. The difficulty is that much remains unclear, indeed unexplained. Unclear remain the
rationale for the extension, the issue whether it can be derived from Osman and/or Assenov or if not why departure
from the principles of those cases is justified, and the extent of the duty as extended.

**[115]** _MC v Bulgaria concerned a complaint of rape made by a 14 year old against two young men of her_
acquaintance with whom she had spent an evening and night travelling around in their car. They had been arrested
on the day that she made her complaint to the police, a few days after the alleged event. Their case was that she
had consented. There were multiple clashes of evidence between the complainant on the one hand and those she
accused, plus other witnesses, on the other. But the prosecutors' investigation had been closed on the grounds that
neither force (physical or psychological) nor threats of the same, nor physical resistance by the complainant, had
been established. The point of the case was the court's rejection of that criterion for rape, which was at the time
consistently adopted by the Bulgarian authorities, and was asserted by the government to be the rule: see paras
122 and 166. Thus there was a breach of art 3 (and indeed of art 8) because the Bulgarian structures or system for
the criminalisation of rape did not sufficiently protect an individual's sexual autonomy; absence of consent must be
the criterion, rather than the use of force.

**[116] That sufficiently demonstrated a breach of art 3 in the same way as in A v UK. The court, however, went on to**
draw attention to deficiencies in the prosecutors' investigation of the complaint. At the outset of its judgment it made
the following statement of principle, which has subsequently been adopted, often word for word, in later cases.

'151. In a number of cases art 3 of the convention gives rise to a positive obligation to conduct an official
investigation. Such positive obligations cannot be considered in principle to be limited solely to cases of illtreatment by state agents.

152. Further, the court has not excluded the possibilities that the state's positive obligation under art 8 to
safeguard the individual's physical integrity may extend to questions relating to the effectiveness of a criminal
investigation.

153. On that basis the court considers that states have a positive obligation inherent in arts 3 and 8 of the
convention to enact criminal law provisions effectively punishing rape and to apply them in practice through
**effective investigation and prosecution.' (Emphasis supplied)**

The emphasised passage in para 153 is expressed as a summary of the three propositions in paras 151 and 152.
As to those, authority is cited for each of them. The authority cited for the first sentence of 151 is Assenov (at para
102). For the second sentence of 151 it is _Calvelli and Ciglio v Italy_ _[[2002] ECHR 32967/96. For the third](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_
proposition, in 152, it is Osman at para 128.
**[*404]**

**[117] Whilst these paragraphs show that the court asserts that art 3 carries an obligation in some circumstances to**
investigate third party offending, they leave only uncertainties about its source and thus its extent.

**[118] As has been seen, Assenov does indeed show that art 3 gives rise to a positive obligation 'in a number of**
cases' to conduct an official investigation. But those cases are ones where the investigation is into suspected state
involvement in ill-treatment and is necessary if the primary obligation on the state is not to be ineffective. That
rationale does not apply to cases of third party offending and _MC v Bulgaria does not say anything about the_
difference between the two situations. Given the explanation in _Assenov of the reasons why an ancillary positive_
obligation has been devised by judicial gloss, the difference is fundamental.

**[119]** _Calvelli and Ciglio was a case of alleged medical negligence in the course of the delivery of a baby who died_
shortly afterwards. It had been treated by the Italian authorities as a case of possible criminal manslaughter. The
doctor had been convicted but his conviction was eventually set aside by the Court of Cassation on the grounds


-----

that he had wrongly been convicted in his absence. A re-trial was ordered but by then the limitation period had
expired. The claimants asserted that there had been no effective system of investigation and trial because owing to
delays the limitation period had expired and the doctor had not been convicted. The court held that there had been
no violation of art 2. The obligation discussed was the duty to run a system which provided sufficient remedies: see
paras 49–54. That is the A v UK duty. There had been no breach of it because in the field of medical negligence a
civil rather than a criminal process can suffice and here there had been sufficient remedies in (1) a right to damages
(which had been pursued and then settled by the claimants without a finding of liability against the doctor, thus
waiving an entitlement to pursue the case to such a finding) and (2) disciplinary regulation of doctors. True, there
was complaint of delay made, but there was no examination in this case of the question what duty existed to
investigate the doctor's actions. The nearest that the court got to that question was the observation that remedies
must be effective and not exist in theory only. It is not easy to see how this case generated the second sentence of
para 151 in MC v Bulgaria, but if it did it is more consistent with an obligation to provide a sufficient investigative
structure than with a duty not to be negligent in the detailed inquiry.

**[120] As to para 152 of MC v Bulgaria, para 128 of Osman (a) is concerned with whether there had been a breach**
of art 8 and (b) simply re-states the finding that the police did not know, nor ought to have known, of a real and
immediate threat to the safety of the complainant. Of course it is true that in order to establish whether a sufficiently
real and immediate threat to the safety of the complainant exists, it will in some cases be necessary for the police to
investigate the complaint. But that does not alter the fact that the carefully limited duty recognised in _Osman is_
concerned not with an obligation to investigate a past event, but with an obligation to prevent a future one.

**[121] The tentative tone of para 152 is also to be noted. No more is said than that the possibility of the positive**
obligation extending to a duty to mount an effective investigation is 'not excluded'. No further reasoning is shown for
the progression from that to the much more positive statement in para 153. It is not clear why that more positive
statement follows from the previous two paragraphs, even if those two had been themselves firmly grounded on the
authority cited.
**[*405]**

**[122] The court in** _MC v Bulgaria was moreover at pains to set some limit to the permissible review of the_
investigation. At paras 167–168 it said this:

'167. In the light of the above, the court's task is to examine whether or not the impugned legislation and
practice and its application in the case at hand, combined with the alleged shortcomings in the investigation,
had such significant flaws as to amount to a breach of the respondent state's positive obligations under arts 3
and 8 of the convention.

168 The issue before the court is limited to the above. The court is not concerned with allegations of errors or
isolated omissions in the investigation; it cannot replace the domestic authorities in the assessment of the facts
of the case; nor can it decide on the alleged perpetrators' criminal responsibility.'

**[123] The court identified, at para 177, deficiencies in the investigation. It concluded that the conflicting assertions**
were not sufficiently sensitively assessed, and that inquiries which could have been made into timings, which might
have shown which version was correct, were not made. It also criticised the fact that the complainant had not had
the opportunity to confront and question the witnesses relied upon by the accused. Lastly, the investigators had not,
it was said, sufficiently taken into account the unlikelihood that a 14 year old would make advances to the second
man only minutes after losing her virginity to the first. But at para 179, set out by Lord Kerr at para [25] above, the
court made it clear that it regarded the deficiencies in the investigation as the consequence of, and part and parcel
with, the flawed approach of the Bulgarian system generally to the issue of lack of consent. It was because of the
criterion of force/resistance that the investigation did not go into matters which otherwise it should have done. This
must be the explanation for the observations about investigation, for otherwise it is very difficult to see that the
criticisms made could found a breach of art 3 given the words of paras 167 and 168. Those paragraphs make it
clear that the gloss on art 3 is not a vehicle for the second-guessing via the Convention of the ordinary domestic
process of assessment of conflicting evidence. Of course it is true that the Strasbourg court is a supra-national one,
but there is no sign that the limit on concern with 'errors or isolated omissions' is restricted to that court as distinct


-----

from a national court when the latter is applying the Convention; on the contrary, the limit is expressed to be one
which determines when there is a breach of art 3 and this plainly is the same for all courts examining that question.
Nor can it be the case that a system which does not involve pre-trial confrontation of witnesses, as some Code
Napoleon systems do, but other systems, including all the United Kingdom ones, do not, is ipso facto in breach of
art 3.

**[124] What has happened since MC v Bulgaria is that the formulation cited above has been repeated, or in some**
cases summarised. It is plain that in several of them the summary has been to the effect that whenever there is an
allegation of ill-treatment passing the art 3 threshold, by whomever committed, there is an obligation on the state to
conduct 'an effective investigation'.

**[125] But in none of these cases has the basis for, and thus the ambit of, any obligation to investigate third party**
violence ever been addressed. Reference back to _MC v Bulgaria, and to its reliance on_ _Assenov,_ _Calvelli and_
_Osman is frequently made, but never examined and the uncertainties mentioned above have not been confronted._
In some cases, there is additional reliance on a series of Turkish cases: Ay v Turkey (App no 30951/96) (22 March
2005, unreported),
**[*406]**

_Duran v Turkey (App no 42942/02) (8 April 2008, unreported),_ _Mehmet v Turkey (App no 28013/02) (11 March_
2008, unreported), Celik v Turkey _[[2004] ECHR 44093/98 and Bati v Turkey (2004) 42 EHRR 736. But all of these](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0FR-00000-00&context=1519360)_
were cases of allegations of serious police torture or ill-treatment of suspects; the citation of such cases illustrates
the manner in which the difference between the first gloss and the second has not received attention.

**[126] In most cases the injunction that the court is not concerned with errors or isolated omissions is similarly**
repeated. In some, the court appears to have looked accordingly for evidence of a structural defect, alternatively
'culpable disregard' or an absence of good faith, in the administration of the domestic system: see for example
_Szula v UK (2007) 44 EHRR SE19 and BV v Croatia (App no 38435/13) (21 January 2016, unreported). But this is_
not always the case. The injunction notwithstanding, in some of the cases the criticisms of the investigation have
been very particular. In some, there are plain overtones of structural state deficiencies in relation to the investigation
of allegations of racially motivated or discriminatory violence: examples include Secic v Croatia _[(2007) 23 BHRC 24,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0G8-00000-00&context=1519360)_
(2007) 49 EHRR 408, _Beganovicì v Croatia_ _[[2009] ECHR 46423/06, and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_ _Milanovic v Serbia_ _[[2010] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X141-00000-00&context=1519360)_
_[44614/07, but this was not given as a reason for the decisions. In others, such as Vasilyev v Russia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X141-00000-00&context=1519360)_ _[[2009] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_
_[32704/04, the nub of the allegation was serious misbehaviour by the police, in that case by dumping the injured](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_
men in the street in the aftermath of a third party assault. But in some, the court has found itself simply pronouncing
on whether the investigation was sufficiently careful. An example appears to be CAS v Romania (2012) 61 EHRR
479, _[[2012] ECHR 26692/05, where the complaint was of sexual abuse of a boy in his home by a visitor or](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0KW-00000-00&context=1519360)_
neighbour. It is possible that the basis of the decision was a conclusion that, as in some other cases, the state did
not take allegations of sexual abuse seriously enough, but that is not said. The court found a breach of art 3 not
only in delay, which did not prevent the prosecution of the specific individual identified, but also in what it described
as a failure sufficiently to evaluate conflicting testimony, supported by the fact that when that individual accused
was acquitted, the police did not look for anyone else. That is very close to, if not indistinguishable from, a view that
the outcome of the trial was wrong, and moreover that if it was wrong that could itself amount to a breach of art 3.
_Beganovicì is another case in which (at para 77) the court appears to have held that the positive obligation under_
art 3 may extend into examination of the conduct of the trial. Such instances, which may be atypical, leave
unanswered the question what is meant by the principle that a breach of art 3 is not constituted by a bona fide
decision in the course of investigation or law enforcement which is afterwards held to have been an error.

**[127] Occasionally in the Strasbourg cases, the general statement of principles includes the seminal passage from**
_Osman v UK (para 116) which is set out at para [112] above. In most of them it does not. But it is surely clear that_
these considerations relating to the practical business of policing, to the operational choices which have to be made
as to priorities and to the allocation of finite resources, must apply with equal if not greater force to the investigation
of allegations of past third party violence as they do to reports of threats of future violence. These considerations
point firmly to the proper test for the ancillary positive obligation under art 3 to investigate reports of past violence


-----

being whether the state has a proper structure of legal and policing provision designed to punish it when it occurs
and has administered that structure in good faith and with proper regard for the gravity of the behaviour
**[*407]**

under consideration. They do not point towards a test of ex post facto assessment of whether the investigation was
careless or made mistakes which ought not to have been made, nor to a finding that there has been a breach of the
right not to suffer torture, or inhuman or degrading treatment, when the complaint is that an investigation could and
should have been done better.
**The threshold of behaviour**

**[128] This is the more so when one considers the range of behaviour which is treated as triggering the ancillary**
positive obligation under art 3. It is clear, and regularly emphasised, that treatment must pass 'a minimum of
severity' before it falls within art 3. It is also clear, and routinely stated, that what that minimum amounts to is
relative and varies according to the circumstances of the case, such as the nature and context of the punishment,
the manner and method of its execution, its duration, its physical and mental effects, and in some instances the sex
age and state of health of the victim. That statement derives from an early corporal punishment case, _Costello-_
_Roberts v UK (1993) 19 EHRR 112 (para 30). It was repeated in_ _A v UK at para 20 and in many subsequent_
judgments. It is no doubt plain that in the case involving breach of the state's primary obligation not to inflict
inhuman or degrading treatment on its citizens, almost any physical injury perpetrated upon a citizen by a state
official, typically the police, will cross the art 3 threshold. Save where necessary in the course of resisted arrest or
the prevention of crime, there is simply no place in policing for causing injury of any kind to a suspect. The practice
of the Strasbourg court in relation to third party violence might have built upon the relative nature of the threshold in
order to limit the ancillary positive obligation to very serious violence but it has not done so. In Milanovic v Serbia

_[[2010] ECHR 44614/07 numerous cuts combined with feelings of fear and helplessness were regarded (at para 87)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X141-00000-00&context=1519360)_
as triggering the ancillary positive obligation. In _BV v Croatia (at paras 153 and 121) injuries to the head and_
contusions to the body were treated likewise. It is plain from the cases that the threshold is regarded as falling, in
English terms, somewhere on the scale of actual bodily harm. To that must be added rape and child sexual abuse;
whether indecent assault passes the threshold remains unclear but it is perhaps likely that it may. So also one
would think must be added false imprisonment (for example by relatives), violent disorder, most terrorist offences
and many other crimes. It follows that the great majority of violent and sexual offences will trigger the ancillary
positive obligation, and that potentially the investigation of all such offences might lead to an action under s 6 of the
Human Rights Act, querying the adequacy of the police treatment of the case.

**[129] It might also be noted that the application of the judicial glosses to the other rights protected by the**
Convention has not, as yet, received detailed consideration. But it is difficult to see why, if they are sound, they may
not in principle be applied equally to other rights. In Siliadin v France _[(2005) 20 BHRC 654, (2005) 43 EHRR 287](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_
the court held that the second gloss applied to art 4 at least as far as the obligation to put in place legal prohibition
of forced labour was concerned, but an obligation in relation to investigation was not in issue. Some third party
behaviour in relation to modern slavery might indeed be considerably more serious than actual bodily harm in a
fight outside a club. Some of the cases clearly contemplate that third party infringement of art 8 rights may trigger
the ancillary positive obligation: see in _CAS v Romania at para 72, and_ _Szula v UK_ at para 1. The possible
application of that ancillary positive obligation to third party interference with the right to enjoyment of
**[*408]**

one's possessions under art 1 Protocol 1 has yet, it seems, to be considered. But in principle, the state has a duty
to protect this right in its citizens, as it has in relation to all the other rights under the Convention. If so, the prospect
may exist of the response to every complaint of burglary, car theft or fraud becoming the subject of an action under
the Human Rights Act.
**English domestic law and its relevance**

**[130] English law recognises a public legal duty owed by the police to enforce the law. The police enjoy a wide**
measure of discretion as to how to go about it, what inquiries to make, and when and whom to prosecute, but a
structural failure to enforce a particular part of the law is amenable to direction by the court via judicial review on the
[application of any interested party: R v Metropolitan Police Comr, ex p Blackburn [1968] 1 All ER 763, [1968] 2 QB](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35V0-TWP1-606D-00000-00&context=1519360)


-----

118. Such a public duty is real, not abstract. That is consistent with the implied positive obligation recognised by the
Strasbourg court in cases such as A v UK. English law also recognises the liability of the police to individuals where
a tortious duty of care is broken, as it may be where they have directly or indirectly occasioned physical harm:
_Knightley v Johns_ _[[1982] 1 All ER 851, [1982] 1 WLR 349is a simple example. Further, it has a statutory scheme for](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-612P-00000-00&context=1519360)_
the independent investigation of complaints about the police, and a different statutory scheme for the compensation
of citizens who are injured through the criminal acts of others. What English law does not recognise is a duty of care
in tort owed by the police to individual citizens and sounding in damages in relation to the detection of crime and the
enforcement of the law.

**[131] The reasons for this absence of private law duty of care were fully explained by the House of Lords in Hill v**
_Chief Constable of West Yorkshire Police_ _[[1988] 2 All ER 238, [1989] AC 53, and confirmed by that court in Brooks](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-601S-00000-00&context=1519360)_
_v Metropolitan Police Comr [2005] UKHL 24,_ _[[2005] 2 All ER 489, [2005] 1 WLR 1495and in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4G4F-CJY0-TWP1-600J-00000-00&context=1519360)_ _Van Colle v Chief_
_[Constable of Hertfordshire Police, Smith v Chief Constable of Sussex Police [2008] 3 All ER 977, [2009] AC 225;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T9K-8RS0-TWP1-612N-00000-00&context=1519360)_
and by this court in Michael v Chief Constable of South Wales Police _[[2015] UKSC 2, [2015] 2 All ER 635, [2015]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FXB-8P21-DYBP-M543-00000-00&context=1519360)_
AC 1732. They find convincing expression in the first three cases in the separate speeches of Lords Keith, Steyn,
Hope, Phillips, Carswell and Brown and were supported also by Lord Bingham despite his solitary dissent on the
extent of the particular duty (of prevention) under consideration in _Smith. A convenient summary is perhaps_
afforded by the judgment of Lord Phillips in Smith at para [97]:

'I do not find it possible to approach Hill's case and Brooks's case as cases that turned on their own facts. The
fact that Lord Steyn applied the decision in _Hill's case to the facts of_ _Brooks's case, which were so very_
different, underlines the fact that Lord Steyn was indeed applying a “core principle” that had been
“unchallenged … for many years”. That principle is, so it seems to me, that in the absence of special
circumstances the police owe no common law duty of care to protect individuals against harm caused by
criminals. The two relevant justifications advanced for the principle are (i) that a private law duty of care in
relation to individuals would be calculated to distort, by encouraging defensive action, the manner in which the
police would otherwise deploy their limited resources; (ii) resources would be diverted from the performance of
the public duties of the police in order to deal with claims advanced for alleged breaches of private law duties
owed to individuals.'

**[*409]**

As Lord Hope explained in the same case at para [75]:

'The point that he [Lord Steyn] was making in Brooks's case, in support of the core principle in Hill's case, was
that the principle had been enunciated in the interests of the whole community. Replacing it with a legal
principle which focuses on the facts of each case would amount, in Lord Steyn's words, to a retreat from the
core principle. We must be careful not to allow ourselves to be persuaded by the shortcomings of the police in
individual cases to undermine that principle. That was the very thing that he was warning against, because of
the risks that this would give rise to. As Ward LJ said in _Swinney v Chief Constable of Northumbria Police_
_Force_ _[[1996] 3 All ER 449 at 467, [1997] QB 464 at 487, the greater public good outweighs any individual](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-605C-00000-00&context=1519360)_
hardship.'

**[132] These reasons are powerful, repeated and carefully considered. They are grounded in public policy and have**
something in common with the considerations explained by the Strasbourg court in Osman v UK at para 116 (see
above at para [112]). In the briefest of terms, law enforcement and the investigation of alleged crime involve a
complex series of judgments and discretionary decisions. They concern, amongst many other things, the choice of
lines of inquiry, the weighing of evidence thus far assembled and the allocation of limited resources as between
competing claims. To re-visit such matters step by step by way of litigation with a view to private compensation
would inhibit the robust operation of police work, and divert resources from current inquiries; it would be detrimental
to, not a spur to, law enforcement. It is not carrying out the impugned investigation efficiently which is likely to lead
to diversion of resources; on the contrary. It is the re-investigation of past investigations in response to litigation
which is likely to do so. Moreover, whilst there may exist a mechanism by way of summary judgment for stopping
short such a re-investigation if the litigation be 'spurious' in the sense of demonstrably bad on the papers, other
claims, and particularly those which turn out to be speculative, cannot thus be halted. In short, the public duty would


-----

be inhibited by a private duty of such a kind. A contemporary example can be seen in terrorist activity. It is well
known that large numbers of possible activists are, to some extent or other, known to the police or security services.
The most delicate and difficult decisions have to be made about whom to concentrate upon, whose movements to
watch, who to make the subject of potentially intrusive surveillance and so on. It is in no sense in the public interest
that, if a terrorist attack should unfortunately occur, litigation should become the forum for a review of the
information held about different suspects and of the decisions made as to how they were to be dealt with. Nor is it
difficult to see that it is by no means necessarily in the public interest that there should be pressure on the
authorities, via the prospect of litigation, to ratchet up the surveillance of additional persons. The long-standing
controversy over police use of powers of 'stop and search', for instance in relation to the carrying of knives by
youths, affords another example.

**[133] It may be noted that in his separate opinion on Osman in the Commission, Sir Nicholas Bratza recognised the**
force of these considerations: (1998) 29 EHRR 245 at 298. As he pointed out, the difficulties highlighted by the
House of Lords in _Hill were well illustrated by the facts of_ _Osman. The allegations there made by the claimant_
would, he said, involve an investigation not only into issues of fact but into acutely difficult questions of policy and
discretion.
**[*410]**

**[134] The relevance of the position at which English law has arrived, after long consideration at the highest level, is**
not that English law can control the operation of the ECHR. But it is to highlight the delicate balance between the
duty of the state to the public generally and its relationship to individuals in particular cases of reported or
anticipated crime. That delicate balance is as applicable to the ambit of the implied ancillary positive obligation
under arts 2, 3 and maybe others as it is to an action in tort in the domestic courts. When taken together with the
uncertainties as to the nature and extent of the implied positive obligation as found by the second gloss on those
articles, it points clearly to the undesirability of any assertion of a detailed review of the course of a particular
criminal investigation by way of the Convention. It is one thing to say that a state must take seriously its protective
obligation, must put in place structures which enforce the law and must not then ignore them. It is quite another to
say that by way of the Convention every police investigation should be examined in detail to see whether it should
have been done better, and that compensation should be paid out of the limited police resources, at the expense of
other necessary expenditure on current cases, if the decision is that it should have been. These important public
considerations have nowhere been examined or put into the balance in any of the Strasbourg cases on the second
gloss, from MC v Bulgaria onwards.

**[135] It can properly be said that the distinction between structural and operational defects may at times be difficult**
to make. It is, however, no more difficult than the distinction which it is suggested must be made, if operational
negligence suffices, between errors which amount to breaches of art 3 and those which do not. To say that the
errors must be serious and significant in order to amount to a breach of art 3 is surely more to present than to solve
the difficulty. Nor is such a restriction clearly to be found anywhere in the line of Strasbourg cases relied upon. If the
test is not to be simply a falling below the standard to be expected of the police, and thus the same as negligence, it
is not easy to see what it is.

**[136] The English cases make a clear distinction between the objectives served by a tortious duty to compensate**
and a Convention-based duty to uphold the prohibition on inhuman or degrading treatment: see for example Lord
Brown in _Van Colle at para [138]. In substance, the Convention-based duty is not aimed at compensation but at_
upholding and vindicating minimum human rights standards. It is, substantially, to insist on performance of a public
duty. It is now said that this distinction justifies the acceptance of a general duty under art 3 to investigate any report
of past behaviour passing the threshold of that article, because such will not impinge on the common law position
as firmly established in the cases beginning with Hill. The error in this argument is to seek to have it both ways. One
cannot both uphold the distinction and effectively eliminate it by employing a Convention claim to serve substantially
the same purpose as an action in tort. That it will do if the wide ambit of the ancillary art 3 duty is accepted, and if
compensation routinely follows a finding that a criminal investigation should have been better conducted. True it is
that the limitation period differs, but this will not remove the disadvantages to policing which were identified in the
English cases. It may be that there is a more relaxed approach to causation in a Convention-based claim, but that if
anything only increases the prospect of such a claim becoming a substitute for a claim in tort There is no doubt


-----

some difference of approach to the calculation of compensation, but the present case is a good illustration of the
marginal, if not imperceptible, nature of the distinction in
**[*411]**

outcome—see the judge's scrupulous quantum judgment at paras [33], [130] and [143]. If, on the other hand, the
positive duty under art 3 is recognised to conform to the public duty, to put in place structures to outlaw the
prohibited behaviour and to operate them in good faith, the Convention-based claim will afford the possibility of
some compensation where the English common law rules do not, but will not result in wholesale substitution of the
Convention for a duty in tort.
**The claimants' argument**

**[137] For the claimants Ms Kaufmann QC mounts an elegant argument. It is that the positive obligation to**
investigate past third party crime for which she contends is simply analogous to the _Osman_ duty to protect from
threatened violent crime. Just as the latter arises when there is a real and immediate risk of prescribed behaviour,
so she contends the former arises when there is a credible report that the prescribed behaviour has already
occurred.

**[138] Elegant as the argument is, the two situations are not analogous. There is a clear distinction between**
protection from an immediately anticipated danger and inquiry into a past event. The carefully limited Osman duty
arises because there is an immediate risk of death or serious injury to an identified individual, communicated to the
state. By contrast, a crime of violence committed by A against B will only occasionally carry a risk of repetition,
whether against B or against others; there is generally no immediate danger to an identified person.

**[139] It is no doubt possible to categorise the duty to investigate reports of third party crime as deriving from the**
state's duty to protect its citizens, in the same way as does its duty to have in place structures which make such
behaviour unlawful. So viewed, the duty to investigate each reported crime can be said to be an application of
cases such as _A v UK. But the reality is that there is a marked and vital distinction, even if it is sometimes of_
degree, between structural failure to outlaw the behaviour and operational failings in the investigation of particular
reports.
**The present case**

**[140] The judge's findings as to what went wrong are not disputed, and were in any event largely based on the very**
critical internal police reports, as well as on that of the Independent Police Complaints Commission. What went
wrong involved plain structural errors. The Metropolitan Police had a written policy for recognising and dealing with
cases of drug induced rape but it was institutionally treated as mere form and there was no proper training in its
application. The complaints made by the claimants were simply not accorded the kind of weight which they
demanded because of generic failures to treat them with sufficient care and gravity. Moreover there was pressure
internally to write off cases of the kind here encountered. The various detailed failings in the conduct of the inquiry
were largely attributable to this flawed structural approach. They included those set out by Lord Kerr at para [51].
There is, as explained at the outset, no appeal as to quantum. In those circumstances, this is a case which falls
within the ancillary positive duty under art 3, as it ought to be interpreted. It is for that reason that I agree that the
appeal in the present case ought to be dismissed.

**LORD MANCE DP.**

**[141] I have read with benefit the three judgments prepared in this case by Lord Kerr, Lord Neuberger and Lord**
Hughes. The result is not in doubt, but
**[*412]**

there is a significant difference between Lord Kerr and Lord Neuberger on the one hand and Lord Hughes on the
[other regarding the extent to which the Convention rights, as domesticated by the Human Rights Act 1998, should](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
be seen as imposing on the state an operational duty to investigate serious offences the commission of which there
is no reason to attribute to state agents. If there is such a duty, then I do not see that it can or should be confined to
the victim of the offence in question. Part of its purpose must be not only to punish, but also to deter and to prevent


-----

the occurrence of further such offences, and, if a third person suffers foreseeably as a result of a failure properly to
investigate, that third person appears to me, potentially at least, to be a victim.

**[142] There is much force in Lord Hughes' analysis and critique in relation to the question whether any such**
general duty exists. What has happened in the Strasbourg jurisprudence is, unfortunately, not unprecedented. The
European Court of Human Rights starts from a solidly rationalised principle, but then extends it to situations to
which the rationale does not apply, without overt recognition of the extension, without formulating any fresh
rationale and relying on supposed authority which does not actually support the extension. Further, the European
Court of Human Rights has not in the present context really focused at any stage on the implications for policing of
the general duty which it has suggested. These have been discussed domestically in a number of common law
cases, and include the risks of defensive policing and of police priorities being affected by the perceived risk of
being sued, as well as the significant financial implications of exposing the police to all those potentially affected by
any failure in police investigative work: see eg Michael v Chief Constable of South Wales Police _[2015] UKSC 2,_

_[[2015] 2 All ER 635, [2015] AC 1732(at [121]–[122]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FXB-8P21-DYBP-M543-00000-00&context=1519360)_

**[143] In these circumstances, while appreciating the pressures under which the European Court of Human Rights**
operates, and the difficulties of maintaining coherence and discipline in a court consisting in the first instance of
multiple chambers, an approach, careful to identify, rationalise and justify any significant development of principle,
would save domestic litigants and courts time, effort and expense.

**[144] The starting point is the positive duty on the state under art 3 not to subject anyone 'to torture or to inhuman**
or degrading treatment or punishment'. One (solidly rationalised) principle which the court has derived from that
duty, by way of gloss, is an ancillary positive duty to conduct 'an effective official investigation' where 'an individual
raises an arguable case that he has been seriously ill-treated by the police or other such agents of the State
unlawfully and in breach of art 3': Assenov v Bulgaria _[(1998) 28 EHRR 652, [1998] ECHR 24760/94 (para 102); the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X11F-00000-00&context=1519360)_
basis for this being that:

'If this were not the case, the general legal prohibition of torture and inhuman and degrading treatment and
punishment, despite its fundamental importance, would be ineffective in practice and it would be possible in
some cases for agents of the State to abuse the rights of those within their control with virtual impunity.'

**[145] This is a coherent gloss, derived from the rationale of art 3. It was repeated in Veznedaroglou v Turkey (2000)**
[33 EHRR 1412, [2000] ECHR 32357/96 (para 32), cited in Jacobs, White and Ovey's The European Convention on](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2RD-00000-00&context=1519360)
_Human Rights (OUP, 2014) where this rationalisation is cited as the basis of any positive investigative duty. The_
Supreme Court in R (on the application of Smith)
**[*413]**

_v Secretary of State for Defence_ _[2010] UKSC 29,_ _[[2010] 3 All ER 1067, [2011] 1 AC 1, expressed a similar](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:50XS-GCR1-DYBP-M373-00000-00&context=1519360)_
understanding of the parallel ancillary investigative duty capable of arising under art 2 (providing that 'Everyone's
right to life shall be protected by law'): 'the investigative obligation under article 2 arose only in circumstances where
there was ground for suspicion that the state might have breached a substantive obligation under article 2', and 'the
death of a soldier on active service did not of itself raise a presumption of such a breach': see [2011] 1 AC
1headnote, holding (2). At paras [200]–[212], I examined both the Strasbourg and the domestic jurisprudence on
this point, including the analysis of the point by the House of Lords in the prior authority of R (on the application of
_Middleton) v West Somerset Coroner [2004] UKHL 10,_ _[[2004] 2 All ER 465, [2004] 2 AC 182(at [3]) per Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-612W-00000-00&context=1519360)_
Bingham, and _R (on the application of Gentle) v Prime Minister [2008] UKHL 20,_ _[[2008] 3 All ER 1, [2008] 1 AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SSF-CGD0-TWP1-61H2-00000-00&context=1519360)_
1356(at [6]) per Lord Bingham. The investigative duty was in short parasitic.

**[146] At para [210], I examined the various specific situations in which the European Court of Human Rights had**
held that there was sufficient state involvement to give rise to a substantive obligation to protect, combined with a
parasitic duty to investigate after the event: killings by state agents and deaths of persons in custody or mental
health detainees, deaths of conscripts, as well as situations where under the principle in _Osman v UK_ _[(1998) 5](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_
_[BHRC 293, (1998) 29 EHRR 245, the state was on notice of a specific and immediate threat to someone's life and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_
bound accordingly to take protective steps.


-----

**[147] In para [211], I pointed out the distinction between the procedural investigative obligation arising in such**
circumstances and 'the general substantive obligation under art 2 to establish an appropriate regulatory,
investigatory and judicial system'.

**[148] To my mind, Lord Hughes' analysis fits perfectly with what the House and the Supreme Court then**
understood to be the law under art 2, and I believe would also have thought the law to be under art 3, since there is
no reason to differentiate in this respect between them. The case of MC v Bulgaria _[(2003) 15 BHRC 627, (2005) 40](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
EHRR 459 was not even cited in R (Smith) and there is reason to believe that its potential significance under these
articles was not appreciated until much more recently: see paras [149] and [150] below.

**[149] It is at this point that the European Court of Human Rights extended a solidly rationalised principle to**
situations to which the rationale did not apply. What it did in MC v Bulgaria _[(2003) 15 BHRC 627, (2005) 40 EHRR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
459 (para 151) was to cite Assenov (para 102), in support of propositions that:

'In a number of cases art 3 of the convention gives rise to a positive obligation to conduct an official
investigation. Such positive obligations cannot be considered in principle to be limited solely to cases of illtreatment by state agents.'

The other case cited in support of the second sentence was _Calvelli and Ciglio v Italy_ _[[2002] ECHR 32967/96,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_
where the court remarked that procedural shortcomings had led to a time-bar in relation to any criminal proceedings
against the (private) doctor involved, but that the complainants had been able to commence civil proceedings,
which, but for the fact that they chose to settle them, would 'in the special circumstances of the instant case, …
have satisfied the positive obligations arising under art 2': para 55. This reasoning and decision do not directly
address the subject matter of either sentence cited
**[*414]**

above, and offer negligible support for any departure from the rationale of any investigative obligation stated in
_Assenov. It is also consistent with a requirement that there should be a sufficient system for redress._

**[150] On this authority has however been piled a weight of subsequent Strasbourg case law, including some recent**
Grand Chamber authority, to the effect that the investigative duty is not, or not necessarily, confined to cases of
suspected misdoing or default by state agents. Lord Kerr and Lord Neuberger have examined this case law. While
its foundations or rationale may be shaky, I cannot ignore at any rate the clear terms in which the conclusion has
now so often been expressed, to the effect that the state's positive investigative obligation can arise even where the
relevant offence is not arguably attributable to any state agent.

**[151] There are however some caveats that I would make, based on such explanations as the court has given as to**
the working of this extended duty:

(i)   The court has reiterated that the 'scope' of the state's positive obligations might differ between cases
where treatment contrary to art 3 of the Convention has been inflicted through the involvement of state
agents and cases where violence [is] inflicted by private individuals: see eg _Beganovicì v Croatia_ _[[2009]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_
_[ECHR 46423/06 (para 62), Vasilyev v Russia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_ _[[2009] ECHR 32704/04 (para 100) and other cases cited by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4VJ-00000-00&context=1519360)_
Lord Neuberger in para [88]. This must mean something in practice, even though the court went on to say
that 'the requirements as to an official investigation are similar'.

(ii)   The court has also repeatedly emphasised that it is not concerned with 'allegations of errors or
isolated omissions in the investigation'. A statement to that effect appears in the seminal authority of MC v
_Bulgaria (para 168), and is repeated in CAS v Romania (2012) 61 EHRR 479 (para 69), BV v Croatia (App_
no 38435/13) (21 January 2016, unreported) and _BV v Belgium (App no 61030/08) (2 May 2017,_
unreported) (paras 55–61). In place of what was once understood to be a distinction between casual errors
of judgments or acts of negligence, consisting of 'operational' as opposed to systematic failures by state
servants or agents, there is now a distinction to be drawn between simple errors or isolated omissions in
the investigation and more serious failings. In this connection, I agree with Lord Hughes, para [123], that
there is no basis for treating this qualification on the scope of the positive investigative duty under art 3 as


-----

**[*415]**


confined to Strasbourg as a supra-national court, and as irrelevant to the English domestic courts'
interpretation of art 3. I had understood Lord Kerr to suggest the contrary, but he has clarified in paras [27]
to [30] that this is not the case.

(iii)   In paras [27] to [30], Lord Kerr expresses a conclusion that the only shortcomings relevant when it
comes to the operational duty to conduct an investigation are those which are 'conspicuous or substantial',
or 'really serious', or 'egregious' or 'obvious and significant'. Lord Hughes considers that this is 'more to
present than to solve the difficulty', and that no such restriction is 'clearly to be found anywhere in the line
of Strasbourg cases relied upon': para [136]. But a distinction between mere shortcomings and more
serious failures is at least consistent with the court's statements of principle set out in the previous
subparagraph, and appears in the

reasoning in Tunç v Turkey (App no 24014/05) (14 April 2015, unreported) (paras 189, 192 and 195). It is
also consistent with the court's more general jurisprudence, to the effect that:


'… ill-treatment must attain a minimum level of severity if it is to fall within the scope of art 3. The assessment
of this minimum is, in the nature of things, relative; it depends on all the circumstances of the case, such as the
nature and context of the treatment, the manner and method of its execution, its duration, its physical or mental
effects and, in some instances, the sex, age and state of health of the victim …'

See Kudla v Poland _[(2000) 10 BHRC 269, (2000) 35 EHRR 198 (para 91); and also A v Ireland (2010) 29](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R1J-9531-DYBP-W1NP-00000-00&context=1519360)_
_[BHRC 423, (2010) 53 EHRR 429 (paras 164–165). It is evident from the way the court explains the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W260-00000-00&context=1519360)_
assessment of the minimum level of severity that it is not going to be easy to predict where it falls in any
individual case.

(iv)   The investigative duty currently under consideration should not be confused with, and cannot be
treated as part of, an _Osman type duty on the state to act in the face of a real and immediate threat_
imperilling the life or bodily well-being of a potential victim. That would involve mining and extending a
separate strand of Strasbourg case law. In some cases, it would mean there was no investigative duty at
all, if no real and immediate threat was apparent to anyone, or anyone other than the original victim,
following the original offence. The investigative duty which the Strasbourg case law, in my opinion, now
recognises is not tied down by any such restriction. It arises from the fact of the offence. I endorse what
Lord Hughes says on this aspect in his paras [137]–[138].

**[152] Finally, I do not accept that Lord Bingham's well-known cautionary remarks in R (on the application of Ullah) v**
_Special Adjudicator, Do v Secretary of State for the Home Dept_ _[[2004] UKHL 26, [2004] 3 All ER 785, [2004] 2 AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDW-G4B0-TWP1-60B4-00000-00&context=1519360)_
323were confined to the international level (whatever relevance that would mean they had domestically). They
were, and have correctly been understood in later authority, such as R (on the application of Al-Skeini) v Secretary
_of State for Defence_ _[[2007] UKHL 26, [2007] 3 All ER 685, [2008] 1 AC 153, as guidance relating to the general](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PDJ-CV20-TWP1-60ND-00000-00&context=1519360)_
approach which domestic courts should take. The general aim of the Human Rights Act was to align domestic law
with Strasbourg law. Domestic courts should not normally refuse to follow Strasbourg authority, although
circumstances can arise where this is appropriate and a healthy dialogue may then ensue: see eg R v Horncastle,
_R v Marquis_ _[2009] UKSC 14,_ _[[2010] 2 All ER 359, [2010] 2 AC 373;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y9D-TF90-Y96Y-G0X5-00000-00&context=1519360)_ _Manchester City Council v Pinnock_ _[2010]_
_[UKSC 45, [2011] 1 All ER 285, [2011] 2 AC 104(at [48]) and R (on the application of Chester) v Secretary of State](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5217-THM1-DYBP-M2JG-00000-00&context=1519360)_
_[for Justice, McGeoch v Lord President of the Council [2013] UKSC 63, [2014] 1 All ER 683, [2014] AC 271(at [27]–](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BFY-R391-DYBP-M492-00000-00&context=1519360)_

[28]). Conversely, domestic courts should not, at least by way of interpretation of the Convention rights as they
apply domestically, forge ahead, without good reason. That follows, not merely from Ullah, but, as Lord Hoffmann
said in Re P (Adoption: Unmarried Couple) _[[2008] UKHL 38, [2008] 2 FLR 1084, [2008] 3 WLR 76(at [36]), from the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3TY-00000-00&context=1519360)_
'ordinary respect' attaching to the European Court of Human Rights and 'the general desirability of a uniform
interpretation of the Convention in all Member States'.

**[153] There are however cases where the English courts can and should, as a matter of domestic law, go with**
confidence beyond existing Strasbourg authority: see eg _Rabone v Pennine Care NHS Foundation Trust [2012]_
_UKSC 2,_

**[*416]**


-----

_[[2012] 2 All ER 381, [2012] 2 AC 72. If the existence or otherwise of a Convention right is unclear, then it may be](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55D5-29K1-DYBP-M0HT-00000-00&context=1519360)_
appropriate for domestic courts to make up their minds whether the Convention rights should or should not be
understood to embrace it. Further, where the European Court of Human Rights has left a matter to states' margin of
appreciation, then domestic courts have to decide what the domestic position is, what degree of involvement or
intervention by a domestic court is appropriate, and what degree of institutional respect to attach to any relevant
legislative choice in the particular area: see _Re P (Adoption: Unmarried Couple), paras [30]–[38] per Lord_
Hoffmann, para [56] per Lord Hope and paras [128]–[130] per Lord Mance.

Appeal dismissed.

Wendy Herring Barrister.

**End of Document**


-----

