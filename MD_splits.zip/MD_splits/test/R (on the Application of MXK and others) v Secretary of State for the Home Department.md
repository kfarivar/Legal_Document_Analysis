# R (on the Application of MXK and others) v Secretary of State for the Home
 Department [2023] EWHC 1272 (Admin)

King's Bench Division (Administrative Court)

Mr Justice Chamberlain

26 May 2023Judgment

**Dan Squires KC and Shu Shin Luh (instructed by Bhatt Murphy Solicitors) for the  Claimants**

**Nicholas Chapman and Richard Evans (instructed by the** **Government Legal Department) for the**
**Defendant**

Hearing dates: 10-11 May 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on [date] by circulation to the parties or their representatives
by e-mail and by release to the National Archives.

.............................

MR JUSTICE CHAMBERLAIN

**Mr Justice Chamberlain:**

**Introduction**

1 MXK and SXB are foreign nationals with limited leave to enter and remain in the UK. Both are mothers
of young children and have outstanding debts for medical treatment provided by NHS trusts at a time
when, because of their immigration status, they were liable to pay for it. Both have been stopped, detained
and questioned about their NHS debts when re-entering the UK with their children (the second and third
claimants in MXK's case and the second claimant in SXB's case) after travelling abroad.

2 With permission granted on the papers by James Strachan KC, sitting as a Deputy High Court Judge,
the claimants challenge:

(a) their examination and detention pursuant to paras 2 or 2A and 16 of Sch. 2 to the Immigration Act 1971
(“Sch. 2”):

(i) in MXK's case, on 4 September 2021 at Heathrow Airport and on 5 March 2022 at Luton Airport;

(ii) in SXB's case, on 19 March 2022 at the UK border control point at the Eurostar Terminal at the Gare
du Nord in Paris;[1] and

(b) the Secretary of State's unpublished policy on the use of the examination and detention powers in Sch.
2 in relation to those with limited leave to remain with outstanding NHS debts.

3 There are four grounds of challenge:


-----

(a) The claimants were stopped and detained pursuant to a misdirection of law and/or for the improper
purpose of assisting with the recovery of NHS debts. (Ground 1)

(b) The claimants were stopped and detained pursuant to an unpublished policy which apparently directs
Immigration Officers (“IOs”) to stop and detain individuals with NHS debts for the purpose of taking up-todate contact details and passing these on to the relevant NHS Trust. Detention pursuant to this policy is
unlawful because the policy approves the exercise of examination and detention powers for reasons other
than those permitted by paras 2 and 2A of Sch. 2 and because the policy is unpublished: _R (Lumba) v_
_SSHD_ _[2011] UKSC 12, [2012] 1 AC 245. (Ground 2)_

(c) The powers to stop and detain in Sch. 2 to the 1971 Act can be exercised without the IO having any
reason to believe or suspect the person has done anything justifying the curtailment or cancellation of their
leave and they are not accompanied by sufficient safeguards (such as a published code of practice and/or
a regime for independent review of the exercise of the power). They are accordingly not “prescribed by
law” for the purposes of Articles 5 and 8 ECHR. (Ground 3)

(d) Given the obvious risk that powers of this kind may be exercised on grounds that are discriminatory,
and in the absence of any consideration of the equality impacts of the use of the detention power in Sch. 2,
the Secretary of State is in breach of her duty under s. 149 of the Equality Act 2010 (“the 2010 Act”) to
have “due regard” to the need to eliminate discrimination. (Ground 4)

**The claimants' evidence**

MXK

4 MXK is an Albanian national. She has three children, all British citizens. She arrived in the UK in 2012,
pregnant with her second child, and claimed to be a victim of trafficking. She received antenatal care from
Newham University Hospital and gave birth at University College London Hospital. Her claim to be
recognised as a victim of trafficking was refused, as was a claim for asylum, but she was granted 30
months' discretionary leave to remain. She applied to renew her leave before its expiry on 5 February
2016. The form did not ask about NHS debts, but the Home Office was aware of them. It nonetheless
decided to extend her leave to remain for a further 30 months, because of her relationship with her British
children. Her leave was extended again in January 2019, this time on the “10-year parent route” under the
Immigration Rules. There was a further 30-month extension in February 2022. After the expiry of that
leave, she hopes to apply for indefinite leave to remain.

5 MXK has travelled abroad eight or nine times since her first grant of leave, either to Albania or on
holiday elsewhere. She says that she has been stopped on return at the airport (Heathrow, Stansted or
Luton) every time. On each occasion apart from the first two, the reason given was that she owed debts to
the NHS. The duration of the detention varied. On 5 September 2015, she recalls being detained for
around three or four hours, when travelling with her baby daughter. They were held in a cordoned off
holding area with no toilet or nappy changing facilities and without access to food. She remembers the
officer telling her that she would be stopped every time she entered the UK while her NHS debt remained
outstanding.

6 On 15 August 2021, MXK travelled with her three children to see her family. They arrived back at
Heathrow Airport on 4 September 2021. The officer at the desk said that he was going to have to write a
statement, which would take some time. MXK said she knew that she was being stopped because of her
NHS debt. The officer directed her to a waiting area. MXK's 17-year old son was permitted to proceed,
leaving MXK and her two young children EH and HH waiting. The only question the officer asked was
whether there were any changes to her address. MXK confirmed that there were not and that her
telephone number also had not changed. After some time, the officer told MXK that she was free to leave,
she did not have to contact the NHS; they would contact her. MXK believes she was detained for around
an hour.

7 On 5 March 2022, MXK and her youngest child HH were returning to Luton Airport after a trip to Albania.
They had arrived at around 10am. The officer said they would have to wait while he did some checks. They


-----

waited for between 30 and 45 minutes. The officer came and asked the usual question: was she aware that
she had an NHS debt? She replied that she was and the officer told her that she was free to go but she
must get in touch with the hospital and arrange to repay the debt.

SXB

8 SXB is a Malian national. She has two daughters. The elder daughter lives in Mali with SXB's family. The
younger daughter lives in the UK with SXB and is a British citizen. SXB was subjected to female genital
mutilation (“FGM”) in Mali. She arrived in the UK on a visit visa in June 2014 and later claimed asylum. Her
asylum claim was refused in July 2015 and her appeal dismissed in April 2016. After a period in
immigration detention between December 2017 and June 2018, she started a relationship with a man. She
suffered several miscarriages and a still birth. Her partner was physically and emotionally abusive towards
her. In August 2019, he threw her out of the home they shared when she was 34 weeks' pregnant. She
became homeless and was provided with accommodation by the local authority.

9 SXB received treatment from Guy's and St Thomas' NHS Trust in respect of the miscarriages and the
still birth and antenatal and maternity care in respect of her daughter. She has a debt of around £13,000 for
this care. In February 2020, SXB applied for leave to remain as parent of a British citizen child. The
application form does not ask about NHS debts. SXB was granted 30 months' leave to remain until
September 2022 with no condition restricting her recourse to public funds. This meant that she was able to
apply for benefits for herself and her daughter. Following the grant of leave, SXB received a letter from
Guy's and St Thomas' NHS Trust about making arrangements to repay the debt. Maternity Action wrote to
the Trust on her behalf asking them to waive the debt, given that SXB is a victim of FGM. There has been
no response.

10 In March 2021, SXB and her baby daughter ALK were stopped at Heathrow Airport on return to the UK
from a trip to Mali. The officer asked her if she was aware that she had an NHS debt. She replied that she
was. The officer told her to sit to one side and she did so. The officer then returned and took her to another
area. He explained that he had been instructed by the Home Office to refuse her entry because of her NHS
debt. She could not understand everything that was said, because her English is not fluent and there was
no French interpreter. She tried to explain that Maternity Action was seeking to have the debt cancelled.
SXB says that she and her daughter were detained for approximately six hours in a small cordoned-off
zone. They were not offered any food. Her daughter was crying and getting very hungry. Her mobile phone
battery had run down, so she could not contact anyone. She asked a female Border Force officer for water
and food for her baby. The officer said she should have brought food with her, but then came back with
croissants, which her baby daughter was too young to eat. She believes the detention lasted for about six
hours.

11 In March 2022, SXB and her daughter went to Paris to visit SXB's sister, who was unwell. On 19 March
2022, on their way back home, they were stopped again at the UK border control point at the Eurostar
Terminal at the Gare du Nord Station. They reached the immigration desk at about 7.30pm. SXB was
asked to show a copy of her daughter's birth certificate. She showed the officer a copy of this on her phone
and the officer seemed satisfied. The officer then checked SXB's details on her system and asked if SXB
had an NHS debt. SXB replied that she did. The officer said that, as she had an NHS debt, SXB did not
have the right to pass through immigration. The officer instructed SXB to wait in a waiting area and a
colleague would come to see her. SXB tried to explain that Maternity Action were trying to get the debt
cancelled.

12 SXB took her daughter and sat down as instructed. Other passengers were passing through, which she
found stigmatising and embarrassing. Her daughter was crying. She was alarmed and anxious that she
would be refused entry to the UK or miss her train. She heard the last call for the train and told the officers
that the train was about to leave. The officer then returned the passports, gave her an IS81 form and let
SXB and her daughter board the train. They had to run to do so. The officers helped SXB carry her
luggage. She believes they were detained for 30-35 minutes. SXB is anxious about travelling again.

Evidence about detention of passengers in other cases


-----

13 Janet Farrell is the claimants' solicitor. She is aware of other examples of individuals with limited leave
to remain being detained and examined about NHS debts on seeking to re-enter the UK. In particular:

(a) JTW was asked about her NHS debt and then detained with her child at Heathrow Airport for
approximately 1.5 to 2 hours, asked for her contact details and told she must pay her debt, before being
allowed to proceed. A claim brought by JTW and her child was settled by the Secretary of State.

(b) SB was detained on two occasions when returning to the UK with her infant daughter. She has issued
separate proceedings challenging the detention.

(c) MA has been stopped on three occasions, when returning to the UK with her husband and infant
daughter (both British citizens). She was detained for 20 minutes, 30 minutes and 1 hour. On each
occasion her husband showed the officer bank statements indicating that her NHS debts was being paid by
instalments. These detentions have made her worried about travelling again.

(d) SM has been stopped and detained on return to the UK sometime after March 2018 and asked about
her NHS debts She was asked whether she had paperwork showing that she was paying these debts off.

(e) AM was stopped and detained at Heathrow Airport in 2017 and asked about NHS debts. She was
detained for several hours.

14 Other examples come from the evidence filed in JTW's claim by non-governmental organisations who
filed evidence supporting that claim.

15 Christine Benson is the senior legal officer for Maternity Action. That organisation is aware of seven
women who have been stopped, detained and questioned about NHS debts. One of them, who has mental
health problems, has not travelled since because of the stress of being detained and questioned. Another
describes being aggressively questioned and told that she would be stopped if she ever travelled again.

16 Zoe Dexter is the housing and welfare officer for the Helen Bamber Foundation. She described what
happened to three clients. Client 1 has been stopped, detained and questioned about her NHS debt each
time she entered the UK. The detention lasted for around 1 hour on each of the first three occasions and
around 40 minutes on the fourth occasion. Client 2 was stopped on return to the UK in December 2020 and
held for over 1 hour, at the end of which he was given a handwritten note with the contact details of the
hospital to which he owed a debt. Client 3 was stopped twice and asked about her NHS debt, detained for
about 10 minutes and then told that she could leave but must resolve her debt.

17 Ann Campbell Viswanathan is director of Bail for Immigration Detainees. Her client was stopped in
2019 on return to the UK at Heathrow Airport, told there was something on her file and that she could not
proceed. She began to panic and other passengers were so concerned that they called paramedics. After
her condition had stabilised, she remained detained. She was told that her records showed an NHS debt.
She was detained for around 8 hours before being allowed to proceed without her documents.

18 Nicholas Beales is lead immigration advisor at the Refugee and Migrant Forum of Essex and East
London (“RAMFEL”). He described the experiences of two clients with limited leave to remain and
outstanding NHS debts who had travelled abroad and been detained for questioning about their NHS debts
on return. In one case, the client was detained and questioned robustly about his NHS debts and the
officer demanded to see proof of his NHS payments. As his bank statements were on his phone, which
was not charged, he had to wait until his phone had charged before showing these to the officer and being
released.

19 Aron Fein is an immigration practitioner working in private practice for Clowes Bureaucracy Experts
Ltd. He describes the experience of two clients. One was a Swiss national who was wrongly charged for
NHS maternity services. She was returning from holiday with her seven children, the youngest a baby of
nine months who was being breastfed. She was detained for checks at Manchester Airport late one
evening and asked questions about her NHS debt. She explained that it was being disputed. She was held
for five hours with her husband and other children. She was not given anything to eat, although she was
breastfeeding. She was granted immigration bail and told must appear at Manchester Airport a few days
later unless confirmation was received from the NHS that there was no debt


-----

20 The second client was the non-EEA spouse of an EEA national. She was returning to the UK and was
detained at Manchester Airport, late in the evening, with her five children and her baby, while officers made
enquiries about her NHS debt. She was detained for approximately 3 hours. Once Mr Fein offered to come
to Manchester Airport, she was granted immigration bail and required to report back to Manchester Airport
a few days later. She went with Mr Fein, who says that her documents were returned “with a stark warning
that if she had not paid off her NHS debt by the next time she was seeking re-entry to the UK, she would
not be allowed in”.

21 Ms Farrell's second witness statement contains further examples of individuals who have been
detained at port on return to the UK. It includes descriptions of what happened to AXJ and KSJ (detained
at Heathrow Airport for about 45 minutes in September 2022, told that the sum she was repaying was not
enough and asked why she could not get a job to repay the rest – private law claim pursued), Ms C
(detained for 2-3 hours in September 2022 for questioning about her NHS debt – claim settled), Ms O
(detained at Heathrow Airport for about 2 hours in July 2022 and told she may not be admitted again if the
debt is not paid off – pre-action correspondence sent), Ms A (detained at Gatwick Airport for approximately
2 hours in August 2022 without access to medication, then told she could go, but needed to speak to the
NHS trust about her debt – pre-action correspondence sent), Ms C (detained at Luton Airport for
approximately one hour in February and September 2022 – private law claim pursued), Ms K (detained at
Heathrow Airport for about 30-40 minutes with two young children and at Calais Eurotunnel Terminal for
around 20 minutes, in October 2022 – private law claim pursued), Ms S (detained every time she has
travelled for the last eight years at various ports and airports – private law claim pursued), Ms B (detained
for seven hours in 2015 and again at Gatwick Airport in October 2022 – private law claim pursued), Ms K
(detained at Luton Airport for about one hour in October 2022 and again for about one and a half hours in
January 2023) and Ms O (detained in Calais in October 2021 and August 2022 and at Gatwick Airport in
November 2021 and June 2022 – in August 2022, the detention lasted for 2-3 hours – private law claim
pursued).

**The Secretary of State's evidence**

22 The Secretary of State's evidence is in the form of three witness statements from Laurence Brammer,
Senior Policy Advisor in the Compliant Environment and Enforcement Unit in the Home Office, and a single
witness statement from Lesley Bern, Senior Policy Advisor in the Home Office, dated 11 May 2023, filed on
the second day of the hearing.

The policy

23 Mr Brammer explains that NHS secondary care is free only to those ordinarily resident in the UK or
those who qualify for one of the exemptions from charges. NHS Trusts notify the Home Office if an invoice
is not paid within 2 months. Pursuant to para. 9.11.1 of the Immigration Rules, an extant NHS debt above
the applicable threshold (£1,000 until 6 April 2016, £500 since then) is a discretionary ground for refusal of
entry clearance, permission to enter or permission to stay. Details of NHS debts and the trust or trusts to
whom the debt is owed (though not the treatment in respect of which the debt was incurred) are recorded
in an individual's immigration records. The debt is also added as a “warning marker” on the Warnings Index
(“WI”).

24 The WI is a Home Office system that provides the capability to query a database of biographical
information relating to persons, documents and organisations that may be of interest to the Secretary of
State and other public authorities. Individuals subject to a warning marker may be stopped at the border. If
they are, an IS81 document is issued while the Border Force officer checks in the back office for further
information to determine whether to permit the individual to proceed.

25 The Secretary of State set out her approach to NHS debts in a previous case, JTW & SBF, as follows:

“In relation to entry clearance holders specifically, before granting entry clearance, an entry clearance
officer will have checked the Home Office records, but it is possible that the information on NHS debts may
have been entered since they made the visa application. If these persons are encountered and there is


-----

evidence of them making false representations to obtain the visa, or there is evidence of a change of
circumstances since the visa was issued, permission to enter must be refused.

Persons with continuing leave would not normally be refused entry for an outstanding NHS debt. However,
officers should take up-to-date contact details for the passenger and pass these on to the NHS trust. The
person can be reminded that the outstanding debt may prevent any further leave being granted.”

26 The NHS debtor rule was first introduced in 2011. Its purpose was set out in a Statement of Changes to
the Immigration Rules (HC1511, 10 October 2011), at para. 7.17:

“The Immigration Rules change will provide that where a person subject to immigration control has failed to
pay charges of £1,000 or more due to one or more relevant NHS body in respect of NHS treatment
charges invoiced on or after 1 November 2011, the person should normally be refused permission to enter
or remain in the country or have their leave cancelled. The UK Border Agency will be provided with
sufficient data to identify the debtor, namely full name, address, nationality and date of birth, Medical data
will not be provided. This Immigration Rules change is to:

- Deter overseas visitors from misusing the NHS by making it clear that the UK health services are not an
international free for all;

- Encourage overseas visitors to meet their obligations to pay for the NHS services they use;

- Enable the UK Border Agency to identify more effectively and take action against migrants with
significant unpaid NHS charges; and

- Reassure the public that we are determined to operate fair and robust controls on migrants' access to
public benefits and services.”

27 Mr Brammer says that warning markers continue to serve a purpose even if an individual has been
granted some form of leave since the debt was incurred, since the existence of the debt could be relevant
to a further application for leave. Once a passenger is found to have a warning marker because of extant
NHS debt, they would not normally be refused entry or have their continuing leave cancelled. However, Mr
Brammer continues:

“…as the passenger is then in contact with an immigration official, there is a practical opportunity to further
the public interest by the steps set out in the Defendant's approach. These are ancillary to the steps that
have already been taken in relation to the passenger's immigration position, and are not the purpose for
which the Defendant's immigration powers have been exercised (as that purpose will have been completed
by this time). Nevertheless, as a complaint has been made by these Claimants and another claimant in
previous litigation about the taking of contact details, after consideration the Defendant can confirm that
she will be removing the instruction contained within the 'NHS Debtors' Border Force guidance which
instructs Border Force officials to obtain up-to-date contact details as an ancillary function within the stop
performed at the border in order to aid recovery of outstanding NHS debt. In addition, Border Force officials
will not be instructed to make enquiries with the NHS trust where an individual with continuing leave but
owing a debt to the NHS is encountered at the border.”

28 In his second statement Mr Brammer explains that when a passenger arrives at a primary control point
the Border Force officer will be alerted to the existence of, but not the reason for, the warning marker. To
find the reasons, the officer must undertake checks on a back-office system. To enable this to happen, the
passenger is issued a form IS81 and required to wait for the checks to be completed. Only on checking the
back-office system does the reason for the marker become apparent.

29 A guidance document entitled _Detention and Detention at Port was in force until withdrawn on 26_
March 2015. That specified that no person should be detained using a form IS81 for more than 4 hours. In
February 2022, the Home Office issued a new guidance document entitled _Controlled Waiting Area and_
_Temporary Detention at Port, which said that individuals should not be detained on the basis of an IS81 for_
more than 1 hour. This was changed to 2 hours when the document was reissued in July 2022. The current
version provides:


-----

“The detained person must be detained for as short a time as possible, and periods of initial examination
should last up to a period of two hours on an IS81 unless exceptional circumstances arise.”

30 Detention beyond this period requires the issue of a separate form IS91R and must comply with the
[Short-term Holding Facility Rules 2018 (SI 2018/409).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5RYY-JSS1-F16W-C1VJ-00000-00&context=1519360)

31 In his third witness statement, Mr Brammer makes clear that there has never been any policy
document or instruction given to IOs or Border Force staff requiring them to contact the NHS in all
circumstances. Rather, the guidance has been that the need to contact the NHS should be assessed case
by case: for example, where a passenger claims to have paid off an NHS debt but has no document
proving this.

32 In her witness statement, Ms Bern explains that, on some of the forms which a patient is required to
complete to apply for leave to remain (though not those which MXK or SXB completed), questions are
asked about NHS treatment and payment for that treatment. It is not possible to say that IOs were
checking for misrepresentations when detaining the claimants, but it is possible that they were.

The stops in MXK's case

33 For the 2015 stop (not the subject of the present claim, but referred in MXK's evidence), the Secretary
of State has produced the Home Office minute sheet recording what happened from the perspective of the
IO. This indicates that at 10.18, MXK was stopped and the IO discovered that she was the subject of
“home office record entries”, which it is agreed means that there was a marker on the WI. An IS81 form
was issued. The IO referred the case to another member of staff who requested that the Home Office
entries were checked. At 10.30, it is recorded that background office checks were conducted which
confirmed an outstanding NHS debt of £1,189 from Barts Health NHS Trust. The IO checked to see
whether this had been taken into account during MXK's “ILR application” (presumably, her application for
leave to remain). At 11.00, the IO made calls, one of which was to Barts Health NHS Trust, but the
operator there said that the control and finance department was shut at weekends. At 11.05 a referral was
made to a more senior officer, who told the IO that they should speak to the passenger and confirm
whether she had paid her debt or whether it had been discussed with her. At 11.10, there is a record of this
discussion taking place, including this entry: “Returned to pax [passenger] and asked whether she paid her
outstanding debt or whether the debt had been declared during her LTR application”. At 11.15, the more
senior officer suggested that the passenger could be granted temporary admission and the case referred to
casework so they could contact the hospital and set up a payment plan. At 11.20, the passenger was
offered water (accepted) and food (declined). A further discussion is minuted. Refreshments and snacks
were offered again at 12.18 and this time they were accepted. The last entry on the minute is at 12.42 at
which point it appears the passenger was allowed to proceed. This would mean the detention lasted for 2
hours and 24 minutes.

34 The Home Office has no record of any stop on 4 September 2021, but the defendant says that she is
likely to have been detained for a relatively short period, likely to be less than the one hour claimed.

35 For the stop on 5 March 2022, the Home Office has disclosed a log book entry, which records “time of
initial stop” as 08.28 and “time clear of PCP [primary control point]” as 08.29. There is no evidence in the
Secretary of State's witness evidence or otherwise to explain what “time clear of PCP” means. However,
Mr Chapman invited me to conclude that it was the time when the passenger is permitted to proceed,
which would mean that the detention lasted for only 1 minute.

The stop in SXB's case

36 In SXB's case, the Secretary of State has disclosed an IS81 for the stop on 5 March 2021 at Heathrow
Airport Terminal 2 showing “IS81 Time” as 14.47 and “Left STHR Time” as 15.43, i.e. a total detention time
of 56 minutes.

37 For the stop on 19 March 2022, there is a log entry showing a “stop time” of 7.35pm and an “end time”
of 7.44pm, but again there is no explanation in the witness statements or otherwise of what these entries
mean


-----

**Law, guidance and instructions**

NHS debts

38 Section 175 of the National Health Service Act 2006 empowers the making of regulations to provide for
the making and recovery of charges in respect of persons not ordinarily resident in Great Britain. The
current regime is set out in the National Health Service (Charges to Overseas Visitors) Regulations 2015
[(SI 2015/238). This provides in broad terms as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5F9X-Y3F1-F16W-C1VN-00000-00&context=1519360)

(a) Anyone in Great Britain is entitled to free primary medical, dental and ophthalmic services and
emergency care (including Accident & Emergency treatment and emergency transport in an ambulance):
see regs 2, 4 and 9.

(b) Subject to various exemptions, anyone who is an “overseas visitor” (i.e. not “ordinarily resident” in the
UK) is required to pay for other forms of healthcare: see regs 2 and 4. By s. 39 of the Immigration Act
2014, a reference to persons not ordinarily resident includes persons who have leave to enter or remain in
the UK for a limited time.

(c) There are exemptions: (i) where the immigration health charge has been paid or the person is exempt
from paying that charge; (ii) where the individual is a refugee, asylum seeker, victim of modern slavery,
dependant thereof or a supported individual or looked after child: regs 6, 15 and 25; and (iii) where the
treatment relates to torture, FGM, domestic or sexual violence, family planning, sexually transmitted
infections, palliative care or any of the conditions listed in Schedule 1: see reg. 9. Maternity treatment is not
exempted.

Powers to examine and detain

39 Paragraph 2 of Schedule 2 to the IA 1971 has been in force since 1 January 1973. At the times
relevant to this case, it provided materially as follows:

“(1) An immigration officer may examine any persons who have arrived in the United Kingdom by ship or
aircraft (including transit passengers, members of the crew and others not seeking to enter the United
Kingdom) for the purpose of determining—

(a) whether any of them is or is not a British citizen; and

(b) whether, if he is not, he may or may not enter the United Kingdom without leave;

(c) whether, if he may not—

(i) he has been given leave which is still in force,

(ii) he should be given leave and for what period or on what conditions (if any), or

(iii) he should be refused leave; and

(d) whether, if he has been given leave which is still in force, his leave should be curtailed.”

40 Paragraph 2A was inserted by the _[Immigration and Asylum Act 1999 with effect from 14 February](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)_
2000. It provided materially as follows:

“(1) This paragraph applies to a person who has arrived in the United Kingdom with leave to enter which is
in force but which was given to him before his arrival.

(2) He may be examined by an immigration officer for the purpose of establishing—

(a) whether there has been such a change in the circumstances of his case, since that leave was given,
that it should be cancelled;

(b) whether that leave was obtained as a result of false information given by him or his failure to disclose
material facts; or

(c) whether there are medical grounds on which that leave should be cancelled.


-----

(2A) Where the person's leave to enter derives, by virtue of section 3A(3), from an entry clearance, he may
also be examined by an immigration officer for the purpose of establishing whether the leave should be
cancelled on the grounds that the person's purpose in arriving in the United Kingdom is different from the
purpose specified in the entry clearance.

(3) He may also be examined by an immigration officer for the purpose of determining whether it would be
conducive to the public good for that leave to be cancelled.

…

(7) An immigration officer examining a person under this paragraph may by notice suspend his leave to
enter until the examination is completed.

(8) An immigration officer may, on the completion of any examination of a person under this paragraph,
cancel his leave to enter.”

41 Paragraph 16 provides materially as follows:

“(1) A person who may be required to submit to examination under paragraph 2 above may be detained
under the authority of an immigration officer pending his examination and pending a decision to give or
refuse him leave to enter.

(1A) A person whose leave to enter has been suspended under paragraph 2A may be detained under the
authority of an immigration officer pending—

(a) completion of his examination under that paragraph; and

(b) a decision on whether to cancel his leave to enter.”

The Immigration Rules

42 The Immigration Rules provide materially as follows:

“False representations, etc. grounds

9.7.1. An application for entry clearance, permission to enter or permission to stay may be refused where,
in relation to the application, or in order to obtain documents from the Secretary of State or a third party
provided in support of the application:

(a) false representations are made, or false documents or false information submitted (whether or not
relevant to the application, and whether or not to the applicant's knowledge); or

(b) relevant facts are not disclosed.

9.7.2. An application for entry clearance, permission to enter or permission to stay must be refused where
the decision maker can prove that it is more likely than not the applicant used deception in the application.

9.7.3. Entry clearance or permission held by a person may be cancelled where, in relation to an
application, or in order to obtain documents from the Secretary of State or a third party provided in support
of the application:

(a) false representations were made, or false documents or false information submitted (whether or not
relevant to the application, and whether or not to the applicant's knowledge); or

(b) relevant facts were not disclosed.

…

**Debt to the NHS grounds**

9.11.1. An application for entry clearance, permission to enter or permission to stay may be refused where
a relevant NHS body has notified the Secretary of State that the applicant has failed to pay charges under
relevant NHS regulations on charges to overseas visitors and the outstanding charges have a total value of
at least £500.


-----

…

**Change of circumstances or purpose grounds**

9.20.1. Entry clearance or permission held by a person may be cancelled where there has been such a
change in circumstances since the entry clearance or permission was granted that it should be cancelled.

9.20.2. Entry clearance or permission to enter held by a person on arrival in the UK may be cancelled
where the person's purpose in seeking entry is different from the purpose specified in their entry
clearance.”

43 As can be seen from the above extracts, failure to pay NHS debt is a ground for refusing an application
for entry clearance, permission to enter or permission to stay (para. 9.11.1), but is not (in and of itself) a
ground for cancelling any of these, once granted. The grounds for cancellation of leave to enter or stay are
that false representations were made or relevant facts not disclosed (para. 9.7.3) or that circumstances or
the applicant's purpose in entering/staying have changed (paras 9.20.1 and 9.20.2).

Guidance and instructions

44 The following appears in a guidance document entitled _Suitability: refusal of entry on arrival in the_
_United Kingdom and cancellation of extant entry clearance or permission, version 2.0:_

“Change of circumstances

When a person's circumstances have changed since their entry clearance or permission was granted you
must consider whether the change is sufficient to justify cancelling their entry clearance or permission.

You should consider whether the person continues to meet the eligibility requirements of the Rules under
which they were granted. For example, where a person with entry clearance as a Skilled Worker has had
their offer of employment withdrawn it would normally be appropriate to cancel the entry clearance and
refuse entry.

…

**Change of purpose**

Where a person holds entry clearance and is seeking entry for a purpose different to that for which the
entry clearance was granted you must consider whether the change of purpose justifies cancellation of
their entry clearance or permission to enter under paragraph 9.20.2. of Part 9 of the Immigration Rules.

Examples of change of purpose include a person who arrives with a visit visa but there is evidence from
documents in their luggage that their true purpose is to work in the UK.”

45 The Border Force Operating Mandate v3 has been in force since February 2015, but is not published. It
has been disclosed in heavily redacted form. It requires Border Force officials to carry out “full checks” on
all individuals entering the UK, including checks against the WI.

46 The current guidance on the processing of passengers with an NHS debt is contained in a document
entitled NHS debtors, version 6.0, published on 13 September 2021, which is not published, but has been
disclosed in redacted form in these proceedings. It provides materially:

“If a passenger seeks permission to enter but has an entry on the Warnings Index (WI) due to an unpaid
debt to the NHS that meets or exceeds the threshold, you may refuse (or in the case of a person holding
an entry clearance consider cancelling) permission to enter. Applicants who hold entry clearance (EC) as a
family member will already have had the level of debt assessed as part of their application under Appendix
FM or Appendix Armed Forces and the Secretary of State for the Home Department (SSHD) has exercised
discretion to grant EC despite the debt.

Refusal on the basis of NHS debt is discretionary not mandatory. You must be satisfied that there are no
compelling or compassionate circumstances or human rights considerations that would make refusal
disproportionate. More information on this ground for refusal, is set out here Suitability: Debt to the NHS
and should be read alongside this document


-----

[…]

Arrangements for payment of the debt are between the passenger and the NHS. You should provide the
contact details of the relevant NHS trust if requested but do no more. Some NHS trusts may use a shared
business debt management service and you can share this number with the passenger, which is 03031
231155. This number will be recorded on either Atlas, the Case Information Database (CID) or the
Warnings Index (WI).

If a debt is settled and you can confirm this, there are no longer grounds to refuse entry on this basis. You
then need to be satisfied that the passenger meets the other requirements for the category in which they
are seeking permission to enter.

[…]

**Entry clearance holders**

Before granting EC, an Entry Clearance Officer (ECO) will have checked the WI, but it is possible that the
information on NHS debts may have been entered since they made the entry clearance application. If you
encounter these passengers and you find evidence of them making false representations to obtain the
visa, or there is evidence of a change of circumstances since the visa was issued, refer to the guidance on
false representations and change of circumstances.

[…]

Passengers with continuing leave would not normally be refused entry for an outstanding NHS debt.
However, officers should take up-to-date contact details for the passenger and pass these on to the NHS
trust. You can remind the passenger that the outstanding debt may prevent any further leave being
granted.”

47 The Secretary of State is amending this guidance to give more detail to IOs and Border Force staff as
to the circumstances in which enquiries with NHS Trusts will be appropriate and to make clear that they
must no longer obtain up-to-date contact details. An Interim Operation Instruction to this effect was issued
on 9 March 2023, but not published. The Secretary of State, through Mr Brammer, has confirmed that the
amended guidance will be published.

**Ground 1**

Submissions

48 Dan Squires KC for the claimants submits that, under paras 2 and 2A of Sch. 2 to the 1971 Act, the
only lawful purpose for which an immigrant with continuing leave to remain in the UK (“a returning
resident”) can be examined is to determine whether their leave to enter or remain should be cancelled or
curtailed. If the examination takes place on the basis of a misdirection of law, or for a purpose other than
those permitted by the statute, the examination (and therefore any detention for the purpose of the
examination) will be unlawful. NHS debt can be relevant to a future application for leave by a returning
resident, but is not a basis for cancelling or curtailing existing leave. If existing leave was procured by false
representations, or by failing to disclose relevant facts, that can be a ground for cancelling leave. But the
claimants in these cases were not examined about that – and nor were the others whose cases are
described in the evidence. In both claimants' cases, the forms on which they had applied for leave did not
ask about NHS debts. What happened to them is consistent with the policy in NHS debtors, version 6.0:
they were examined generally about their NHS debts, their up-to-date contact details were taken and they
were warned about the need to pay those debts off. None of that was a proper basis for examination. It
follows that their detention was unlawful.

49 Nicholas Chapman for the Secretary of State accepts that the mere fact of an extant NHS debt is not a
proper basis on which to cancel or curtail leave. He also accepts that the claimants were examined and
detained due to the existence of a marker on the WI because of their NHS debts. However, the powers in
Sch. 2 to the 1971 Act to stop, examine and detain are not conditional on the existence of a legal basis for
curtailment or cancellation of leave They exist to enable the officer to ascertain whether such a basis


-----

exists or not. The system is configured in such a way that, at the point of detention, the officer will know
that there is a warning marker on the system, but not the reason for it. Some element of delay is inherent in
checking the back-office system and a short period of detention may be required for this purpose.

50 Mr Chapman accepts that, once the officer finds that the marker relates to an NHS debt, the only basis
on which the officer can lawfully examine a returning resident in relation to that debt is to determine
whether to cancel the resident's leave on the basis that they made false representations, or failed to
disclose relevant facts, when they applied for it. He submitted, however, that the officer could lawfully
examine a returning resident to determine whether there were grounds for cancellation not connected to
the NHS debt, for example a change in circumstances. In these claimants' cases, there was power to
examine and detain and nothing to indicate that the power was exercised for anything other than a lawful
purpose.

_Note: The Defendant's submission that there was a statutory power to examine in relation to issues_
_unconnected with the NHS debt (including whether there was a change of circumstances) was not withdrawn.The_
_Defendants' position remained that the statutory powers to examine and/or cancel are not contingent on a WI flag_
_and the issues upon which a person may be examined are not limited to those underlying any WI flag (i.e. the_
_power to examine is “suspicionless”); the statutory power to examine may (according to the statute) be exercised_
_for the purposes of establishing whether any basis for cancelling leave may exist, such as “non-conducive” (eg_
_national security) grounds, medical grounds, commission of an offence, withdrawal of sponsorship, customs breach_
_etc. The Defendant identified change of circumstances as one example of a lawful basis for cancellation not_
_connected to the NHS debt (see, e.g., §24 of the Detailed Grounds of Defence and §39 of the Defendant's_
_skeleton).The Defendant did however accept that an officer's examination must relate to establishing whether_
_grounds for cancellation exist; and NHS debt would only be material to that question if there was evidence that it_
_had been concealed etc. on a previous application.        Discussion_

_Note: The Defendant's submission that there was a statutory power to examine in relation to issues_
_unconnected with the NHS debt (including whether there was a change of circumstances) was not withdrawn._

_The Defendants' position remained that the statutory powers to examine and/or cancel are not contingent_
_on a WI flag and the issues upon which a person may be examined are not limited to those underlying any WI flag_
_(i.e. the power to examine is “suspicionless”); the statutory power to examine may (according to the statute) be_
_exercised for the purposes of establishing whether any basis for cancelling leave may exist, such as “non-_
_conducive” (eg national security) grounds, medical grounds, commission of an offence, withdrawal of sponsorship,_
_customs breach etc. The Defendant identified change of circumstances as one example of a lawful basis for_
_cancellation not connected to the NHS debt (see, e.g., §24 of the Detailed Grounds of Defence and §39 of the_
_Defendant's skeleton)._

_The Defendant did however accept that an officer's examination must relate to establishing whether_
_grounds for cancellation exist; and NHS debt would only be material to that question if there was evidence that it_
_had been concealed etc. on a previous application._

_The burden of proof in a claim alleging unlawful detention_

51 In this case, the Secretary of State concedes that the claimants were detained and the claimants
concede that their detention was initially lawful, up to the point when the officer realised that the flag on the
WI related only to NHS debt. They say it is for the Secretary of State to show that detention for examination
after that time was for a purpose permitted by the statute; and she has failed to do so. This raises the
question whether it is the claimants who bear the burden of proving that the detention became unlawful or
the Secretary of State who bears the burden of proving that it remained lawful.

52 In my judgment, it is the Secretary of State who bears the burden of proof. In claims alleging unlawful
detention, the general position is that once the claimant has shown that he was detained, it is for the
defendant to show that there was lawful justification for the detention: Lumba, [65]. A purported authority to
detain may be impugned either because the defendant acted in excess of jurisdiction in the narrow sense
(i e had no jurisdiction to detain) or because such jurisdiction was wrongly exercised in breach of a rule of


-----

public law: _ibid.,_ [66]. Either way, “all the claimant has to do is to prove that he was detained. The
Secretary of State must prove that the decision was justified in law”: [88]. _Lumba seems to me to show_
that, in a case where the claimant brings judicial review proceedings alleging that detention was unlawful
because a power to detain was exercised in breach of a public law rule, the public authority must prove not
only that it had the power to detain but also that it exercised that power lawfully.

53 While this is correct at the level of principle, it is important not to expect an unrealistic level of detail
from a public authority seeking to justify detention. I do not think that an IO needs to record every question
asked of a returning resident. If the instructions given to officers are accurate and specific about the
purposes for which examination of a returning resident is permissible, it should generally be sufficient to
record – at the point when it is discovered that the flag relates only to NHS debt – that the resident is
detained with a view to determining whether he has made false representations or failed to disclose
relevant facts in his application for leave.

54 In any event, the outcome of the present case does not turn on the allocation of the burden of proof.
For reasons which follow, it would be the same even if the claimants had to prove that the detention was
vitiated by a public law error.

_The proper approach to finding the facts_

55 The primary targets of the claimants' challenges are the decisions to detain them. As to what happened
on these occasions, there is a dispute between the parties.

56 In R (F) v Surrey County Council _[2023] EWHC 980 (Admin), at [46]-[50], I set out what I consider to be_
the proper approach to findings of fact in judicial review proceedings, by reference to previous authority: S
_v Airedale NHS Trust_ _[[2002] EWHC 1780 (Admin);](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0C7-00000-00&context=1519360)_ _R (Safeer) v Secretary of State for the Home_
_Department_ _[2018] EWCA Civ 2518;_ _R (Singh) v Secretary of State for the Home Department_ _[2018]_
_EWCA Civ 2861; and R (Talpada) v Secretary of State for the Home Department_ _[2018] EWCA Civ 841. At_

[50], I said this:

“(c) There is no absolute rule that the court must accept in full every part of the statement of a witness who
has not been cross-examined, whether the statement is adduced for the claimant or the defendant. The
court can reject evidence in a witness statement if it 'cannot be correct' (Safeer, [16]-[19] and Singh, [16]).
That might be so if it is contradicted by 'undisputed objective evidence… that cannot sensibly be explained
away': _S v Airedale, [18]. But there are also examples of courts rejecting evidence given in witness_
statements as, on balance, inconsistent with other written evidence: see e.g. Talpada, [48].

(d) In some cases, the court may be unable to resolve a conflict of written evidence on a question of
primary fact. In that situation, “the court will proceed on the basis that the fact has not been proved”:
_Talpada, [2]. This will be to the disadvantage of whichever party asserts the fact. That will generally be the_
claimant, because in judicial review the claimant generally bears the burden of proving all facts necessary
to show that the decision challenged is unlawful. Thus, the principle that the defendant's evidence is to be
preferred, save where it 'cannot be correct', arises because of the difficulty of satisfying the burden of proof
where there is a conflict in written evidence, not because evidence adduced on behalf of a defendant is
inherently more likely to be true than that adduced on behalf of a claimant.”

57 Neither party sought to persuade me to depart from this approach.

_The relevance of the evidence about the policy and the treatment of other individuals_

58 Before considering the evidence about what happened to the claimants, it is necessary to say
something about the context in which that evidence falls to be assessed.

59 First, the policy document NHS debtors, version 6.0 is likely to have informed the approach of Border
Force staff to those with markers on the WI for NHS debts. This document does not tell staff that the only
basis for cancelling leave in connection with an NHS debt is where the person has made false
representations or failed to disclose relevant facts on a previous application for leave; and (as Mr Chapman
accepts) any examination in relation to NHS debt must be directed towards establishing whether there are


-----

grounds for cancellation. On the contrary, by saying that “[p]assengers with continuing leave would not
normally be refused entry for an outstanding NHS debt” (emphasis added), it implies that the existence of
an NHS debt may itself be a sufficient ground for cancellation of leave, at least in some cases. The
following sentence suggests that taking contact details and giving advice about the consequences of not
paying off the debt are among the lawful purposes for which a passenger may be examined and detained.

60 Second, it is not necessary or appropriate to make detailed findings about what happened to
individuals other than the claimants, not least because some of their accounts may fall to be considered on
fuller evidence in future cases. However, the evidence relied upon by the claimants, taken together with the
Secretary of State's evidence and the relevant policy documents, seems to establish that there was a
practice of detaining returning residents for varying periods in order to examine them about their NHS
debts. The topics about which individuals have been questioned include whether the debt remains
outstanding, its amount and the sufficiency of any arrangements made to pay it off. This is not surprising:
an official reading the policy documents would think that these were proper topics about which to question
returning residents. There is no evidence of any individual being asked questions relevant to whether they
have made false representations or failed to disclose relevant facts in previous applications for leave.
There is nothing in the policy documents which would focus the minds of officials on those questions.

61 Third, the Secretary of State has had every opportunity to file evidence in this case about how the
powers of examination and detention under Sch. 2 to the 1971 Act are in fact used. Border Force staff who
deal with a large number of people every day are unlikely to remember what they did in particular cases, so
it is not surprising that there are no witness statements from them about the individual cases relied upon in
evidence. It would, however, have been possible to file evidence about how staff are trained to use Sch. 2
powers in cases where the only warning marker on the WI relates to NHS debt, or (for example) evidence
from an experienced Border Force officer about how they generally use those powers. There is no such
evidence. In particular, there is nothing to show that Border Force staff are aware that the only lawful
purpose for examination in such a case is to determine whether the passenger has made false
representations or failed to disclose relevant facts on a previous application for leave, or that examinations
in such cases are in fact directed to that purpose. Mr Chapman told me on instruction that the systems to
which officers have access would enable them to access the documents they would need to undertake
such an examination (e.g. the resident's previous applications for leave and associated correspondence),
but there was no evidence verified by a statement of truth to substantiate this and, in any event, nothing to
suggest that officers in fact access such documents as part of an examination under Sch. 2 to the 1971
Act.

_MXK_

62 MXK's account of the stop in 2015 (not one of the instances of detention that are challenged in these
proceedings) accords closely with the Home Office detailed minute of that stop, though the duration
recorded (2 hours, 24 minutes) is slightly less than MXK's estimate (3-4 hours). This justifies the inference
that MXK's recollection, even of events taking place some years ago, is broadly reliable.

63 MXK has given clear and relatively detailed evidence about what happened to her and to EH and HH
on 4 September 2021. The Home Office has no records of that stop, but sensibly does not suggest that the
absence of a record means that the stop did not happen at all. In my judgment, there is no proper basis on
which to doubt any part of MXK's account of what she was asked or what she said in reply. It is possible
that, as in 2015, the detention lasted for a little less time than she thought. Applying a conservative
approach, I find that she was detained for at least 45 minutes. In the absence of records, it is difficult to
pinpoint exactly when during that detention the officer realised that the only reason for the flag on the WI
system was an NHS debt. However, in the absence of any evidence that there was any problem with the
back-office system on that day, or that the officer was otherwise occupied, that it is likely to have become
apparent within a maximum of 15 minutes. During the remaining 30 minutes of the detention, there is no
evidence that the officer asked any question the answer to which would have been relevant to whether
MXK had made false representations or failed to disclose relevant facts when applying for leave, or
gathered information relevant to those matters.


-----

64 MXK's evidence about her and HH's detention on 5 March 2022 is also clear and relatively detailed.
She recalls being offered (and accepting) water, a detail which she would have no reason to make up and
which suggests that she must have been detained for some time. The only evidence relied upon is the
Home Office log book entry from which Mr Chapman for the Secretary of State invited me to infer that the
detention had lasted for only 1 minute (rather than the 30-45 minutes she estimates). That could only be
true if MXK's account were fabricated. The log book entry is an inadequate basis on which to reach that
view, given the absence of any evidence from the Secretary of State to explain what the various entries
mean. The inference Mr Chapman invites me to draw depends on an assumption not only that the times
are recorded correctly, but also that the “time clear of PCP” is the time at which the detention ended. There
was no evidence to substantiate that assumption. It is more likely, given the evidence as a whole, that
“time clear of PCP” means the time the passenger moved from the PCP to the holding area, still under
detention. MXK's estimate of the length of detention (given in a witness statement signed less than 4
months later) is likely to be broadly reliable. Applying a conservative approach, I find that the detention
lasted for 30 minutes. Again, there is no evidence that there was any problem with the back-office system
on that day, nor that the officer was otherwise occupied. I accordingly find that it could not have taken the
officer more than 15 minutes to discover that the only reason for the flag on the WI was MXK's NHS debt.
During the remaining 15 minutes there is no evidence that the officer asked any question the answer to
which would have been relevant to whether MXK had made false representations or failed to disclose
relevant facts when applying for leave, or gathered information relevant to those matters.

65 On the evidence, I therefore find that, on each of 4 September 2021 and 5 March 2022, MXK's
examination and detention were initially lawful during the period when the officer was checking to see what
the flag related to. However, after 15 minutes the detention continued but the examination was not for any
of the purposes specified in paras 2 or 2A of Sch. 2 to the 1971 Act. MXK was accordingly unlawfully
detained:

(a) for 30 minutes on 4 September 2021 with her two children EH and HH; and

(b) for 15 minutes on 5 March 2022 with her youngest child, HH.

(The Secretary of State did not dispute that EH and HH were so young that they could not proceed without
their mother. It follows that by unlawfully detaining MXK the Secretary of State also unlawfully detained EH
and HH.)

_SXB_

66 There is a significant discrepancy between SXB's account of her stop at Heathrow Airport on 11 March
2021 (when she estimates she was detained for about 6 hours) and the IS81, which the Secretary of State
submits records detention lasting 56 minutes. Since this is not one of the instances of detention challenged
in this claim it is not necessary to make any clear findings about this stop. However, the IS81 on its own,
with no explanation of what the entries mean, supplies no proper basis to conclude that SXB's account was
fabricated.

67 SXB's evidence about the stop at the Gare du Nord, Paris, on 19 March 2022 is clear and relatively
comprehensive. She says that the officer realised while at the desk that the marker on the WI related to an
NHS debt. It is unclear whether Mr Brammer's evidence that the system does not enable the officer to
identify the cause of the WI flag applies to the system used in Paris. There is no detail about how the
systems are configured there. In any event, I find on the basis of SXB's evidence that the officer discovered
very early on, within the first five minutes, that the flag related only to an NHS debt. There is a further detail
in SXB's evidence about Border Force staff helping her with her luggage after the final call for the train
which departed at 8.13pm, which SXB would have had no reason to make up. The log book entries are a
wholly inadequate basis on which to reject SXB's account. There is, again, nothing to explain what these
entries mean. In particular, the significance of the “End Time” recorded in the log book is unclear and there
is no explanation of why the “Total Time” is different from the 9 minutes between the “Stop Time” and “End
Time”. I accordingly find that SXB and her child ALK were detained for 30 minutes and, applying a
conservative approach, that for 25 minutes of that time it was apparent to the detaining officer that the flag


-----

on the WI related only to an NHS debt. During the detention there is no evidence that SXB was asked any
question the answer to which would have enabled the examiner to form a view about whether she had
made false representations or failed to disclose relevant facts when applying for leave.

68 On the evidence, I therefore find that, on 19 March 2022, SXB and ALK were detained for an
examination which was lawful at its inception but became unlawful after 5 minutes because it was then
carried out for a purpose other than those specified in paras 2 and 2A of Sch. 2 to the 1971 Act. For the
last 25 minutes, that detention was unlawful.

**Ground 2**

Submissions

69 Mr Squires submits that, applying the test in R (A) v Secretary of State for the Home Department _[2021]_
_UKSC 37, [2021] 1 WLR 3931, at [46],_ _NHS debtors, version 6.0 is unlawful. First, the use of the word_
“normally” suggests that NHS debts can sometimes be a ground for cancelling or curtailing leave. Second,
the immediately following sentences tell officers that taking contact details and giving advice about the
consequences of not paying off an NHS debt are permissible purposes to detain. In both respects, the
policy positively authorises or approves unlawful conduct, namely examination and detention for a purpose
other than those specified in paras 2 and 2A of Sch. 2 to the 1971 Act. At the very least, this is a policy
directed to staff who would be expected to take direction from the Secretary of State about the exercise of
their functions. It purports to provide a full account of the legal position and fails to achieve that because of
an omission which has the effect that the policy, read as a whole, presents a misleading picture of the true
legal position. Furthermore, Mr Squires submits that the policy is unlawful because it relates to detention
but is unpublished: Lumba, [34]-[36].

70 Mr Chapman accepts that the use of the word “normally” in the policy was an error and that detention
for the purposes of taking contact details and reminding passengers of the consequences of not paying off
their debt would be unlawful. This does not mean, however, that the test in _A's case is met. The policy_
does not induce officers to act unlawfully because it is possible to follow it without acting unlawfully. Nor
can the policy be characterised as an exhaustive or detailed statement of the law of the kind that might
mislead by omission. There is no invariable requirement to publish policies if there are compelling public
interest reasons not to do so: see Lumba, [38]. In this case, Mr Chapman said – on instructions – that the
Secretary of State had concluded that there were indeed public interest reasons against publication.

Discussion

71 In A, at [46], Lord Sales and Lord Burnett (with whom the other members of the court agreed) identified
three situations in which a policy can be unlawful:

“(i) where the policy includes a positive statement of law which is wrong and which will induce a person
who follows the policy to breach their legal duty in some way (i.e. the type of case under consideration in
_Gillick [1986] AC 112); (ii) where the authority which promulgates the policy does so pursuant to a duty to_
provide accurate advice about the law but fails to do so, either because of a misstatement of law or
because of an omission to explain the legal position; and (iii) where the authority, even though not under a
duty to issue a policy, decides to promulgate one and in doing so purports in the policy to provide a full
account of the legal position but fails to achieve that, either because of a specific misstatement of the law
or because of an omission which has the effect that, read as a whole, the policy presents a misleading
picture of the true legal position. In a case of the type described by Rose LJ, where a Secretary of State
issues guidance to his or her own staff explaining the legal framework in which they perform their functions,
the context is likely to be such as to bring it within category (iii). The audience for the policy would be
expected to take direction about the performance of their functions on behalf of their department from the
Secretary of State at the head of the department, rather than seeking independent advice of their own. So,
read objectively, and depending on the content and form of the policy, it may more readily be interpreted as
a comprehensive statement of the relevant legal position and its lawfulness will be assessed on that basis.”


-----

72 In this case, there are three aspects of the policy which are relevant to its lawfulness. First, there is the
use of the word “normally”, which Mr Chapman concedes is an error. As I have noted, it implies wrongly
that the existence of an NHS debt may itself be a sufficient ground for cancellation of leave, at least in
some cases. Second, there is the absence of any reference to what Mr Chapman concedes are the only
purposes for which a returning resident can be lawfully examined in relation to an NHS debt. The absence
is significant because one of these purposes (checking for false representations) is mentioned in relation to
persons with entry clearance. This means officers may well assume that there is no need to focus on that
question when dealing with returning residents with leave. Third, there are the positive statements that
detained passengers may be asked to provide up-to-date contact details and given advice about the
consequences of not paying off the debt. Mr Chapman now accepts that detention for those purposes
would be unlawful and the new guidance instructs staff not to seek these details or give this advice.

73 Taken together, these three aspects bring the policy within the first of the three situations identified at

[46] of _A._ They are capable of inducing an officer to breach his legal obligations by examining and
detaining a returning resident for purposes other than those permitted by paras 2 and 2A of Sch. 2 to the
1971 Act. Even if that were wrong, the policy falls squarely within the third situation identified. It is issued to
the Secretary of State's own non-legally trained staff. It purports to give comprehensive instructions on how
to exercise their legal powers (which include powers of detention). Staff would reasonably expect and be
expected to follow these instructions rather than to seek independent advice of their own. The policy is, at
best, misleading in that it fails to identify the sole purposes for which they may examine and detain a
person with limited leave to enter or remain in relation to an NHS debt – and in doing so gives the
impression that the permitted purposes are broader. In my judgment, the policy is therefore unlawful.

74 The fact that the policy is unpublished supplies a further reason why it is unlawful. The main reason
why the unpublished policy in _Lumba was unlawful was because it was at odds with the Secretary of_
State's published policy. However, the reasoning of Lord Dyson also supports the wider proposition that,
where statute confers a broad power of detention on the executive, the rule of law calls for a transparent
statement of the circumstances in which the power will be exercised: see at [34]. One benefit of publication
is that the individual to whom the policy is applied can challenge an adverse decision: see at [36]. This is
likely to be of greater relevance to the longer-term powers of detention at issue in _Lumba than in the_
present case, though even here the evidence discloses some cases where lawyers were involved in
challenging detentions lasting several hours.

75 There is another advantage to the publication of policy, which is vividly illustrated by the facts of these
cases. People who have to interpret and apply the law sometimes make legal errors. This of course applies
to lawyers and judges, but also to those who formulate and draft policy. Especially where the policy
concerns the exercise of powers of detention, there is a powerful public interest in the early identification of
any errors, so as to avoid unlawful detention and minimise the liability of the detaining authority. If such a
policy is not published, there is a danger that a practice will develop, which has not been transparently
avowed and which can only be discerned by piecing together the accounts given by a large number of
individuals to their respective lawyers. The result may be that large numbers of people are unlawfully
detained before the practice can be identified and the illegality exposed.

76 That is what seems to have happened here. The practice of detaining returning residents for
examination in relation to NHS debts appears to have been identified through discussion between solicitors
and immigration practitioners each representing no more than a few clients. The policy was only disclosed
in the course of the litigation. Once it was disclosed, and submissions made about it, the errors in the
policy were recognised by the Secretary of State and the policy was withdrawn or amended. By that time,
however, it is likely that it had been applied to a very large number of people. It would have been much
better for all concerned if the policy had been published and its illegality recognised earlier.

77 I should add that it is well established that there is no legal obligation to publish a policy, even one
relating to the exercise of administrative powers of detention, where there are compelling national security
or other public interest reasons against publication: see _Lumba, [38]. As I have indicated, Mr Chapman_
submitted in the course of argument that the Secretary of State had determined that publication would be
contrary to the public interest here If that submission were to be seriously maintained it would be


-----

necessary to consider carefully the evidence about the circumstances in which the decision was made and
the reasons for it. But, as Mr Chapman later conceded, there was no such evidence in any of the witness
statements adduced by the Secretary of State, or otherwise. Indeed, the evidence did not even attest to the
fact that such a determination had been made. Courts cannot proceed on the basis of bare submissions
that are not supported by evidence. Moreover, as Mr Squires pointed out, it is difficult to see how there
could have been a compelling reason for non-publication of the policy, given that the Secretary of State
has undertaken to publish the new policy once that has been formulated.

78 Ground 2 therefore succeeds.

**Ground 3**

79 This focus of this claim has been on examination and detention of those whose WI marker relates only
to NHS debt. Ground 3 is much broader in scope. It challenges the Sch. 2 detention powers more generally
as failing to meet the “prescribed by law” requirement in Article 5 ECHR and the “in accordance with law”
requirement in Article 8 ECHR, as interpreted in the Strasbourg and domestic case law. After hearing a
little of the argument, I enquired whether it was necessary for me to resolve this ground of challenge if the
claimants succeeded on grounds 1 and/or 2. Mr Squires and Mr Chapman agreed that it was not. In the
circumstances, it seems to me that it would not be appropriate for me to determine ground 3 in this case,
particularly given that compliance of detention powers with the clarity and accessibility requirements of the
Convention may depend (among other things) on the terms of any policy governing the exercise of the
powers; and the policy is being rewritten, at least as it relates to NHS debs. In any event, the arguments
are factually and legally complex and ought to be resolved in a case where they matter to the outcome.

**Ground 4**

Submissions

80 Mr Squires submits that the formulation of policy about the exercise of Sch. 2 powers and the exercise
of those powers generally are “functions” within the meaning of s. 149 of the 2010 Act. There is an inherent
danger that broad powers of detention will be exercised in a way that is directly or indirectly discriminatory.
The Secretary of State has produced no evidence that she has discharged the s. 149 duty in relation to the
exercise of the Sch. 2 powers either generally or in relation to NHS debtors in particular.

81 Mr Chapman submits that s. 149 does not impose a general duty to gather and analyse statistics.
Decisions about how to discharge the duty (e.g. what information to gather) can be impugned only on
rationality grounds: R (Sheakh) v Lambeth LBC _[2022] EWCA Civ 457, [2022] PTSR 1315, [10] and [73]._
The Secretary of State has always recognised that charging for NHS services is likely to have a disparate
impact on women as a group and on those who are or have been pregnant in particular. These impacts
were recognised in equality impact assessments (“EIAs”) undertaken when it was decided to charge for
NHS services (in 2011) and to make NHS debts relevant to certain immigration decisions (also in 2011).
Further analyses were conducted in 2013 (as part of a consultation on migrant access and financial
contribution to NHS provision in England) and 2015 (in the EIA to accompanying the National Health
Service (Charges of Overseas Visitors) Regulations 2015. Furthermore, the Secretary of State
commissioned a one-off internal data exercise, which reported in 2022, showing that NHS debtors were
disproportionately female.

82 Mr Chapman submits that, when these documents are considered together, it can be seen that the
Secretary of State had regard to equality impacts but concluded that any indirect discrimination based on
pregnancy/maternity/sex was justified in pursuit of the legitimate aims of safeguarding the NHS and
effective border control. Alternatively, he relies on s. 31(2A) of the Senior Courts Act 1981 and says that, if
there was a breach of s. 149, it is highly likely that the outcome would not have been substantially different.

Discussion

83 The principles applicable in a claim alleging breach of s. 149 of the 2010 Act have been developed in a
series of cases. They were summarised in R (Bracking) v Secretary of State for Work and Pensions _[2013]_


-----

_EWCA Civ 1345, [2014] EqLR 60, [25] (approved in Hotak v Southwark LBC_ _[2015] UKSC 30, [2016] AC_
811, [73]) and R (Bridges) v Chief Constable of South Wales Police _[2020] EWCA Civ 1058, [2020] 1 WLR_
5037. In the last of these cases, at [175], the Court of Appeal identified six principles:

“(1) The PSED must be fulfilled before and at the time when a particular policy is being considered.

(2) The duty must be exercised in substance, with rigour, and with an open mind. It is not a question of
ticking boxes.

(3) The duty is non-delegable.

(4) The duty is a continuing one.

(5) If the relevant material is not available, there will be a duty to acquire it and this will frequently mean
that some further consultation with appropriate groups is required.

(6) Provided the court is satisfied that there has been a rigorous consideration of the duty, so that there is a
proper appreciation of the potential impact of the decision on equality objectives and the desirability of
promoting them, then it is for the decision-maker to decide how much weight should be given to the various
factors informing the decision.”

84 Often, compliance with s. 149 is evidenced by the production of a formal EIA. But there is no statutory
requirement to produce such a document. Indeed, there is no obligation to produce any contemporaneous
document. However, if there is no such document it may be more difficult to show that the duty has been
discharged “in substance” and “with rigour”.

85 In this case, the evidence shows that equality impacts were considered in substance and with rigour (i)
by the Department of Health in 2011, when the policy of charging for NHS services was under
consideration and (ii) by the Secretary of State in 2011, when the policy of making NHS debts relevant to
certain immigration decisions was under consideration. The considerations in 2013 and 2015 were both by
the Department of Health in the context of reviews of the policy of charging for NHS services.

86 In my judgment, it is important to bear in mind that the obligation imposed by s. 149 applies to each
public authority separately “in the exercise of its functions”. An equality analysis undertaken for the
purposes of the exercise of function A by department X may in principle be relevant and useful to
department Y when it considers the equality impacts of a related function B. But the focus must always be
on the public authority whose decision is under challenge and the consideration given by that authority to
any equality impacts relevant to the exercise of its functions.

87 In this case, the defendant is the Secretary of State for the Home Department and the relevant
functions are the Sch. 2 examination and detention powers. The question is therefore whether the
Secretary of State has given substantial and rigorous consideration to the equality impacts of her use of
the examination and detention powers in Sch. 2. Once the question is put in that way, the EIAs undertaken
by a different department in 2011, 2013 and 2015 in relation to a different policy (whether to charge for
NHS services) can be seen to be of tangential relevance at most. The relevance of the EIA undertaken by
the Home Office in 2011 is greater, but even that did not specifically address the equality impacts of the
exercise of examination and detention powers. Nor did the information-gathering exercise which reported
in 2022, which showed that NHS debtors were disproportionately female.

88 I accept that it is important to read and apply s. 149 with a degree of flexibility and common sense. But
it is not the role of the courts to excuse non-compliance with an obligation which Parliament has imposed.
In this case, there is no evidence to show that the Secretary of State or any official has ever considered the
equality impacts of her use of the examination and detention powers in Sch. 2, let alone kept those impacts
under continuing review.

89 If the examination and detention powers had been considered, those responsible for the formulation of
policy about the exercise of those powers would have had to focus on the question whether a practice of
detaining returning residents for varying periods for examination about NHS debts could be justified, given
its disproportionate impact on women and any other groups which are disproportionately affected. The


-----

consideration of that issue would not have to be elaborate. It would be for the Secretary of State to decide,
subject to _Wednesbury review only, whether the information currently held was sufficient to inform the_
decision.

90 Given the absence of any witness evidence about the consideration given to these issues, it is not
possible to say what the outcome would have been if equality impacts had been taken into account.
Certainly, it is not possible to conclude that it is highly likely that the outcome would not have been
substantially different: see by analogy R (Buckley) v Bath and North East Somerset Council _[[2018] EWHC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SKW-8RS1-F0JY-C49C-00000-00&context=1519360)_
_[1551 (Admin), [2019] PTSR 335, [43]. Apart from anything else, the policy has in fact been modified as a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SKW-8RS1-F0JY-C49C-00000-00&context=1519360)_
result of this litigation. In my view, that is fatal to any argument relying on s. 31(2A) of the 1981 Act.

91 Ground 4 therefore succeeds.

**Conclusion**

92 For these reasons, grounds 1, 2 and 4 succeed. It is neither necessary nor appropriate to determine
ground 3. I shall invite submissions as to the proper form of relief.

**End of Document**


-----

