# TT (Vietnam) v Secretary of State for the Home Department [2019] EWCA Civ
 248

Court of Appeal, Civil Division

Davis, Simon LLJ and Sir Stephen Richards

27 February 2019Judgment

**Stephen Knafler QC (instructed by A2 Solicitors) for the Appellant**

**Jennifer Thelen (instructed by Government Legal Department) for the Respondent**

Hearing date: 13 February 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Davis :**

**Introduction**

1. This appeal, brought with permission granted by Irwin LJ, raises two discrete matters: albeit both arise
in the context of human trafficking. The first is whether the Secretary of State was lawfully entitled to certify
the appellant's asylum claim as clearly unfounded. The second is whether the appellant is entitled to
substantive damages in respect of his immigration detention between 4 July 2015 and 14 September 2015.

2. The judge in substance decided both points adversely to the appellant. As to the unlawful detention
claim, it is a feature of the case that (for reasons I will come on to explain) it throughout has been
conceded on behalf of the respondent Secretary of State that the relevant period of detention was unlawful
in that relevant published policies had not been applied. But the judge accepted that the Secretary of State
both could (lawfully) and would have detained the appellant throughout that period in any event. Thus he
awarded only nominal damages.

3. Before us the appellant was represented by Mr Stephen Knafler QC (who had not appeared below) and
the Secretary of State was represented by Ms Jennifer Thelen (who had appeared below). I would like to
acknowledge the careful and thorough arguments presented to us.

**Background Facts**

4. The background, in summary, is this.

5. The appellant is a national of Vietnam. Although there has been some dispute as to his age, the
Secretary of State concluded that he was born in 1991; and at all times relevant to these proceedings he
has been regarded (and was regarded by the judge) as an adult.

6. During the course of 2013 he entered the United Kingdom illegally (via France). His claim has
subsequently been that he was trafficked into the United Kingdom and was required to work in producing
cannabis at a location in Fleetwood in order to pay off a large debt incurred to those who had trafficked him
from Vietnam into the United Kingdom.


-----

7. In due course the appellant was apprehended, following a police raid at that address. He appeared to
have been living there for a significant period of time. He also had been responsible for helping to cultivate
a large quantity of cannabis plants at that address. The production set-up was to be described as
“sophisticated”.

8. He was (with another) charged with producing cannabis and abstracting electricity. He was remanded.
He in due course pleaded guilty. No defence of duress, for example, was raised or pursued. There is no
record of there being any basis of plea. He came before HHJ Altham in the Preston Crown Court on 3
November 2014, where he was represented by counsel. The judge treated him as 23 years old at the time.
The judge fully described the sophisticated nature of the cannabis production operation. The valuation of
the yield from the plants over the relevant period was estimated at £182,000 at street level.

9. The judge in his sentencing remarks recorded the appellant as having said that he had been at the
premises for about a year and that he had been there to work. It was recorded that he said that he had
received a “notional” remuneration of £200 per week but that was “to be set off against a debt which he
apparently owed to those who brought him from France into the United Kingdom”.

10. The judge described his role as having elements of a significant and of a lesser role. The judge said of
both accused: “these men were, for reasons that they had largely brought upon themselves, under
pressure to assist.” Each, it was found, knew of the scale of the operation.

11. As for the appellant he had made early admissions and was given full credit for his plea. The judge
regarded it as an aggravating factor that he had been at the premises as a “gardener” for, as the judge put
it, “a considerable period of time”. He was of good character. With credit for plea, he was given a sentence
of 20 months imprisonment. In consequence he stood to be released at the halfway stage less time spent
on remand. The judge also observed in his sentencing remarks that the end of their sentences in each
case may be marked by deportation, although that was not a matter for the court.

12. A notice of decision to deport was served on the appellant on 19 December 2014.

13. By letter dated 9 February 2015 the appellant, through his solicitors, then claimed asylum. No such
claim had previously been made. The letter was accompanied by a witness statement from the appellant.
In it, he said that he was single. His foster mother lived in Vietnam. He had a sister living in the United
Kingdom, although at that time he did not say where.

14. He was to state that a customer, whom he called Anh and whom he met in a restaurant in Hanoi
where he worked, in 2012 offered him the chance of a well-paid job. He agreed. He was taken to Thailand
where he worked in a bar. In due course he was deported from Thailand. He returned to Hanoi to his
various old jobs. The same customer, Anh, saw him in the restaurant and was surprised to see him.
According to the appellant, Anh then said that he was owed money for taking him to Thailand. He was
arrested by the police in Hanoi when he refused to work again for Anh. He was released and then Anh
arranged for him to leave Vietnam for China at the end of 2012. From there he travelled by air to France,
with a passport provided to him. He stayed in France for around 2 months and then came to the United
Kingdom by car. He was told that he had to work hard to pay off all the money he owed. He was then taken
to the house in Fleetwood. He was told that he had no choice. He says that he was “slapped a few times”
and that threats were made with regard to his foster mother in Vietnam and to his sister, if he did not
cooperate.

15. At the conclusion of his statement he said this:

“I am afraid to go back Vietnam now. Anh Hung got me arrested the last time, I am afraid the same or
worse will happen to me now. I cannot go anywhere else in Vietnam because of the household registration
system in Vietnam. The police will find me easily because of this.

I believe that if sent back to Vietnam, I would be imprisoned and treated in an inhumane manner. I further
believe that if sent back to Vietnam, I will be trafficked to another country and I may not survive if this
happens.”

**D t** **ti**


-----

16. The appellant was due to be released from custody on 15 April 2015. However, on that date he was
removed into immigration detention, pending his prospective deportation. He was detained at IRC
Dungavel in South Lanarkshire. No complaint is made as to that initial detention.

17. On 23 June 2015 (some two months after entering immigration detention) the appellant by his
solicitors submitted formal representations that he had been a victim of trafficking. He was interviewed
shortly thereafter. In his interview, he among other things said: “I just fear for the safety of my life. I don't
want to go back.” He gave answers broadly consistent with his previous statement. He then said: “If they
return me to Vietnam I fear they will beat me up and my life will be in danger. And they might force me to
work like I was in Thailand.” He also made reference to sexual abuse in Thailand: something which he had
not previously mentioned.

18. On 14 September 2015, the appellant (on the direction of the First-tier Tribunal) was released on bail.
He was bailed to the address of his sister (who had by now been located in London) and reporting
conditions were imposed.

19. The response to the representations as to trafficking was (unacceptably) not produced by the
Competent Authority until 5 October 2015. That concluded that there were reasonable grounds to believe
that the appellant had been the victim of **_modern slavery (human trafficking). A conclusive grounds_**
decision was indicated as being forthcoming after the usual 45 day recovery and reflection period.

20. In the event such conclusive grounds decision was (again unacceptably) not forthcoming until 28 April
2016. As notified to the appellant, it stated the conclusion on the part of the Competent Authority that the
appellant had been trafficked. Having stated that conclusion, the letter went on:

“Although you were found to be trafficked because of the particular circumstances of your case, those
circumstances no longer exist and as you do not qualify for leave to remain in the United Kingdom you will
be liable for removal.”

21. The underpinning conclusive grounds consideration minute with regard to that decision letter set out in
detail the reasons for the conclusion that the appellant had been trafficked. He met the three constituent
elements of trafficking: “action, means, exploitation”. It was also considered that, following the reasonable
grounds decision, the appellant had provided an internally consistent account. Overall, it was concluded
that he was a victim of human trafficking both into and within the United Kingdom. The minute concluded:

“However, it has been decided that you do not require a period of leave for any reason. Consequently a
positive conclusive grounds decision without leave has been made”.

22. Thereafter, by decision letter of 22 July 2016, the Secretary of State refused the appellant's claims for
asylum and humanitarian protection and his claim based on Article 8 of the Convention. The claims were
[also certified under s.94 (1) of the Nationality, Immigration and Asylum Act 2002.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)

23. After correspondence, the Judicial Review claim was issued on 1 November 2016.

**Certification**

24. Against that background, I turn to the first point: which is the challenge to the certification of the
appellant's claims. This matter came before the judge by way of renewed application, the single judge
having refused permission on the papers on this issue.

25. The relevant legal principles are by now sufficiently well established and I do not think that for present
purposes I need engage in any detailed discussion of them. They are particularly helpfully reviewed and
discussed in the judgment of Beatson LJ in _FR (Albania) v Secretary of State for the Home Department_

_[2016] EWCA Civ 605. The relevant core principle is, in short, that a claim can only properly be certified if it_
is rationally assessed as “bound to fail”. That sets a very high bar. Further, whilst the actual decision is for
the Secretary of State nevertheless the courts, in reviewing such a decision, will adopt an appropriate
intensity of review.

26. It was Mr Knafler's submission that the Secretary of State could not rationally or properly conclude that
this claim to asylum was bound to fail He said that the appellant “ticked all the boxes” for being at risk of


-----

retrafficking if returned to Vietnam. The conclusive grounds decision had found that the appellant had been
the victim of trafficking. Further, he owed money to the traffickers; he had no family in Vietnam and had no
support network; he had barely any education; and he had no vocational skills or other resources available
to him. He had, it was stressed, already been trafficked into Thailand and then re-trafficked into Europe.
Yet further, the objective evidence showed that trafficking remains a constant problem throughout Vietnam
and frequently involves organised crime.

27. However, this was not a case where the Secretary of State had purported to reject as not credible all
the factual matters as advanced on behalf of the appellant or had purported to go behind the findings in the
conclusive grounds letter. What the Secretary of State had concluded, in the very lengthy and careful
decision letter extending over 107 paragraphs and 15 pages, was that this appellant would not be at risk if
returned. Vietnam was a large country, with a population of over 90 million and several cities. There was a
sufficiency of protection. Further, there was no reason to think that those to whom the appellant owed
money in Hanoi would know of his return or of his location; and there was no reason why – as an ablebodied young man with work experience – he could not relocate from Hanoi.

28. In this respect, the decision letter had most fully set out and applied relevant aspects of the country
information and guidance material relating to Vietnam. As identified, the risk of re-trafficking (if returned to
Vietnam) depended, among other things, on the particular circumstances of the case and the capacity and
interest which those owed the debt or other persecutors had in pursuing and locating the individual.

29. Mr Knafler said that the Upper Tribunal decision of Nguyen [2015] UKUT 160 (IAC), which is referred
to in some of the relevant policy documents relating to Vietnam, was distinguishable from the present case.
That decision had, among other things, noted that there was no universal rule that a victim of trafficking is
unreturnable to the country from which he or she was trafficked. Mr Knafler did not in any way dissent from
that. But he pointed out that in that case (where it was adjudged that there was no real risk in the appellant
in that case being returned to Vietnam) there were a number of distinguishing factual features as to the
trafficking and other background as compared to the present case. I accept that: that case in its actual
outcome, albeit instructive as to its general approach, was to an extent based on its own facts. But
nowhere in the decision letter in the present case was it indicated that _Nguyen was binding as to the_
outcome here. To the contrary, the decision letter – which did not even cite Nguyen – appraised all relevant
objective materials, including country material post-dating the decision in Nguyen.

30. Mr Knafler further said that there was objective evidence that persons in Vietnam who reside away
from their home are required to register with the local police. He said that if the appellant re-located he
would be required so to register and thereby, he said, would potentially become known to his persecutors.
But this point was dealt with in the decision letter, which noted further objective evidence that residency
laws were not usually implemented; and which also noted that it was unexplained how the persecutors in
Hanoi would even know of the appellant's return to Vietnam or be able or inclined to access any
registration records.

31. It is also to be borne in mind, of course, that the conclusive grounds letter had itself said of the
circumstances surrounding his trafficking: “those circumstances no longer exist”.

32. I do not propose to say more on this issue. Accepting, as I do for present purposes, the very high bar
for certification, I nevertheless conclude that this very thorough and fully-reasoned decision letter rationally
explained just how that very high bar was surmounted in this case. It withstands intensive review. In my
judgment, the judge below was correct in his conclusion. This ground therefore fails.

**Detention**

33. No challenge is made to the appellant's detention between 15 April 2015 and 4 July 2015. The
question is whether he was unlawfully detained thereafter until his release on bail on 14 September 2015.

34. As the judge noted, there are three relevant published policies in this regard.

35. The first is the Competent Authority Guidance with regard to Victims of Trafficking. In the version then
applicable it was among other things stated:


-----

“If the potential victim of trafficking is in immigration detention they will normally need to be released on TA

[Temporary Admission] or TR [Temporary Release] unless in the particular circumstances, their detention
can be justified on grounds of public order. The decision letter advises the person that they have been
granted 45 days for recovery and reflection on TA or TR to remain in the UK whilst a conclusive decision is
made on their case. This does not grant any leave to enter to remain.”

36. Second, in Chapter 9 of the then applicable Enforcement and Instructions Guidance (EIG), which
relates to victims of trafficking, the following is among other things stated at paragraphs 9.9 and 9.10:

“Competent Authorities will aim to complete an assessment of whether there are 'reasonable grounds to
believe' someone is a victim within 5 days of referral. A positive decision will trigger a 45 day 'recovery and
reflection' period during which time individuals will not be detained and removal action will be suspended.
Victims will have access to certain rights, including accommodation and advice.

…

The FR should refer the case to the CA [Competent Authority] using the approved referral form. The CA
has a target of 5 working days from the receipt of the referral to reach a decision. Where a case needs to
be fast tracked, e.g. the person may be detained, the CA is expected to treat the case as a priority and
reach the decision as soon as possible. Once the decision has been reached as to whether there are
reasonable grounds to believe that the person may have been trafficked the CA will notify the decision to
the FR and the PVoT. If they meet the reasonable grounds threshold they will be given a period of 45
calendar days for reflection and recovery, whilst the CA makes a conclusive decision on the case.

…

Where the CA accepts the reasonable grounds the PVoT is allowed a 45 day reflection period to recover
and consider their options. The PVoT cannot be detained on immigration grounds unless in the particular
circumstances their detention can be justified on grounds of public order.”

37. Third, in Chapter 55 of the EIG, which deals with detention and temporary release, it was among other
things said at paragraph 55.1.3:

“Detention must be used sparingly and for the shortest period necessary …. Due to the clear imperative to
protect the public from harm, the risk of reoffending or absconding should be weighed against the
presumption in favour of temporary admission or temporary release in cases where the deportation criteria
are met….”

A little further on this was said:

“Substantial weight should be given to the risk of further offending or harm to the public indicated by the
subject criminality. Both the likelihood of the person re-offending and the seriousness of the harm if the
person does re-offend must be considered. Where the offence which is triggered in the deportation is
included in the list [and there is a link which includes drugs offences in such list] the weight which should
be given to the risk of further offending or harm to the public is particularly substantial when balanced
against other factors in favour of release. In cases involving these serious offences therefore a decision to
release is likely to be the proper conclusion only when the factors in favour of release are particularly
compelling. In practice release is likely to be appropriate only in exceptional cases because of the
seriousness of violent, sexual, drug related and similar offences.”

And in paragraph 55.10 this was said:

“Certain persons are normally considered suitable for detention in only very exceptional circumstances,
whether in dedicated immigration accommodation or prisons. Others are unsuitable for immigration
detention accommodation because their detention require particular security care and control. In criminal
casework cases the risks of further offending or harm to the public must be carefully weighed against the
reason why the individual may be unsuitable for detention. There may be cases where the risk of harm to
the public is such that it outweighs factors that would otherwise normally indicate a person was unsuitable
for detention. The following are normally considered suitable for detention in only very exceptional


-----

circumstances whether in dedicated immigration detention accommodation or prisons … persons identified
by the competent authorities as victims of trafficking (as set out in Chapter 9 which contains very specific
criteria, concerning detention of such persons). If a decision is made to detain a person in any of the above
categories the casework character must set out the very exceptional circumstances for doing so on file.”

38. In the present case the letter from the appellant's solicitors making the formal trafficking
representations was received on 23 June 2015. The resulting interview was conducted on 25 June 2015;
and the relevant referral form, as the judge found, was returned by the detention centre on 29 June 2015
and scanned and submitted for consideration on 30 June 2015.

39. Under paragraph 9.10 of the EIG a decision should then have been expected at all events within 5
working days. However, as the appellant was already in detention the competent authority was expected
under the policy guidance to treat the case as a priority and to reach the decision as soon as possible. The
judge found that proper adherence to the policy meant that such a decision should have been made by
Friday 3 July 2015. There is no challenge by the Secretary of State to that finding. Mr Knafler was, very
fairly, prepared to allow some time for the (putative) decision to be implemented. But he said that the
appellant should at all events have been released on 4 July 2015. In the event, of course, the reasonable
grounds decision was, as I have said, only made on 5 October 2015.

40. Moreover, and in addition to that, it was accepted on behalf of the Secretary of State that, in
accordance with the EIG, a conclusive grounds decision should then have been made within 45 calendar
days. The judge found, on the evidence, that such decision should have been made by 17 August 2015:
and there is no challenge to that finding either. Allowing (as Mr Knafler again very fairly was prepared to
allow) a short implementation period, that connoted release by 18 August 2015. In the event, as I have
said, the conclusive grounds decision was only made and communicated on 28 April 2016.

41. The Secretary of State thus has conceded unlawfulness in the decision making process in the
circumstances of this particular case, through want of compliance with the guidance as to timeliness set
out in the published policies (a want of compliance, I note, which is not explained by evidence). His case
was, however, that the Secretary of State both could (lawfully) and would have detained the appellant in
any event. Accordingly the appellant was and is not entitled to substantive damages.

42. That means, among other things, that if the Secretary of State is to justify such detention he must
show that from 4 July 2015 until 18 August 2015 detention was justified “on grounds of public order”.
Thereafter, until the appellant's actual release on 14 September 2015, the Secretary of State must show
that detention was justified as being in “very exceptional circumstances”. That was not in dispute before us.
Nor was it in dispute before us that the relevant burden was on the Secretary of State and that the relevant
standard applicable was that of the balance of probabilities: see the discussion in the judgment of Beatson
LJ in R (VC) v Secretary of State for the Home Department [2018] EWCA Civ 57, [2018] IWLR 4781. In
those circumstances, it is convenient to do as the judge did and to divide the overall period into two parts
reflecting the two different applicable tests (the “public order” and “very exceptional circumstances”
grounds respectively).

43. The judge found on the evidence that if the Secretary of State could lawfully have detained the
appellant then the Secretary of State would have done so in each period: see paragraphs 45 and 50 of his
judgment. Although Mr Knafler queried the finding that the Secretary of State would so have detained, I
see no sufficient basis for interfering with that factual evaluation made by the judge. So the real question
then becomes as to the “could” ground: that is, whether the judge was correct to conclude that the “public
order” ground and the “very exceptional circumstances” ground were respectively made out.

**The detention reviews**

44. The Secretary of State has not sought to put in substantive evidence in this case. Instead, reliance is
essentially placed on the contemporaneous detention reviews, coupled with a degree of amplification in the
written arguments below.


-----

45. As the judge found, in the present case the “critical factors were clearly risk of absconding and risk of
reoffending”. He considered that, at least until 17 August 2015, the question of risk of harm was “of
secondary importance”: paragraph 42.

46. Thus in the third detention review relating to the appellant signed off on 7 July 2015, it was noted that
the appellant was by then a potential victim of trafficking and that the claim “is still under consideration”.
Risk of absconding was assessed as “high”. Risk of reoffending and risk of harm were assessed as
“medium”. The outstanding barriers to deportation were recorded as being the extant victim of trafficking
claim and the extant asylum claim.

47. The recommendation in the detention review was recorded as follows:

“[T] was convicted of count 1; production of class B-drug cannabis and count 2; abstracting electricity and
was sentenced for count 1; 20 months imprisonment and for count 2; sentence to lie on file. He has been
assessed as a medium risk of harm and re-offending. There is no evidence of legal entry into the UK. He
has failed to comply with Immigration laws, by avoiding Border control on entry. This would suggest that he
is unlikely to comply with reporting restrictions. He has been assessed as high risk of absconding. [T] made
an application for asylum only after being notified of his liability to deportation, this is under consideration.
A person in genuine need of humanitarian protection would likely make such an application at their first
opportunity. This is more like the expected actions of someone attempting to frustrate the deportation
process. There are no compelling reasons to believe that he would remain in contact with the Home Office
so we can effect his removal.

Bearing these facts in mind, I have considered the presumption to liberty as outlined in Chapter 55 of the
Enforcement Instructions and Guidance. In this case the presumption is on balance outweighed by the risk
of harm to the public should he re-offend, the likelihood of re-offending, and the significant risk of
absconding. I concur with the proposal that detention remains proportionate at this time.”

Authoriser's comments were as follows:

“I agree but we really need to be getting on with the asylum consideration and I would like to know that an
interview has been arranged before the next review is due.”

The reviewing officer agreed with that recommendation. It was noted that “simply claiming to be a PVOT is
insufficient in itself to rule out detention”. It was assessed that the presumption of liberty was “outweighed
by the risk of harm to the public should he reoffend, the likelihood of reoffending and the significant risk of
absconding”.

48. It is to be observed that, in the supporting materials forming part of that review, it was expressly
recorded, among other things, that the appellant had been non-compliant at a previous interview relating to
travel documentation, having refused to sign the bio-data form and having refused to have his photograph
taken. In addition, it had been noted, for the purposes of assessing the risk of absconding, that at that time
the appellant had little known ties in the UK such as to make him stay in one place.

49. At a further (fourth) review on 7 August 2015 the assessment was to like effect. The authorising
officer's response to the continued recommendation to detain was this:

“Detention is agreed due to the high risk of flight posed. [T] has made a PVOT and asylum claim. It is
critical that the asylum action is completed and that the CO works closely [sic] the PVOT competent
authority in order to establish whether there is merit to his claim.”

50. In the subsequent (fifth) detention review dated 8 September 2015, the risk of absconding again was
assessed as “high”. But by now the assessment of the risk of harm had also been increased to “high”. This
is explained by the following entry in the case summary:

“On 17 August 2015 [T] was involved in an incident at Dungavel House. On 18 August 2015 [T] was placed
under Rule 40 conditions after being identified along with six other Vietnamese nationals in being in an
assault causing severe injury to two detainees. The Scottish Police will attend the centre on the 18 August
to interview. The case owner contacted Depmu to have FNO transferred to another IRC. On 24 August


-----

2015 [T] was transferred to Brook House IRC. On 25 August 2015 a RSRA has been completed and [T] is
deemed to be a high risk, as such he has been granted single occupancy. This will be reviewed again on
the 25 November 2015.”

The text further explained that the risk of harm was high “due to the nature of his offence and to the fact
that he has been involved in a serious assault on 2 other detainees”. Some concerns were expressed
about the delay in consideration of the asylum claim: but the recommendation to detain was approved.

51. Finally, for these purposes, there was the bail application to the First-tier Tribunal made on behalf of
the appellant in September 2015. That was opposed. In the Bail Summary submitted by the Home Office it
was said of the incident which occurred on 17 August 2015:

“The applicant was involved in an incident at Dungavel House. The applicant along with six other
Vietnamese nationals was involved in an assault causing severe injury to two detainees. The Scottish
police will attend the centre on 18/08/15 for interview.”

The entry in the summary for the following day said:

“The Scottish police attended the centre and charged the applicant with assault. The applicant was placed
under Rule 40 conditions (deemed to be high risk).”

52. Neither we nor the judge had any further evidence about this assault incident. When we enquired, Mr
Knafler said, on instructions, that the appellant had not in fact been charged with any offence. When we
asked Ms Thelen, she said, on instructions, that the appellant had certainly not been convicted of such an
offence and that the Secretary of State also had no record of any charge in fact being brought against him.

**The judge's decision on the detention issue**

53. The judge carefully went through the detention reviews. He also reviewed the recorded answers of the
appellant in interview: where, amongst other things, he had said when interviewed in June 2015 that he did
not then know the residence of his sister in the United Kingdom, although he had known where she
worked, and was thoroughly vague about his degree of contact with her.

54. So far as the first period of detention under challenge is concerned, the judge's conclusion is
encapsulated in paragraph 45 of his judgment:

“The starting point is that potential victims of trafficking are not usually to be detained. However, they can
be detained on public order grounds. The nature of the public order grounds that might be material appears
clearly from the passages that I have read from the policies dealing with matters before the conclusive
grounds determination. In the present case the fact of the drugs conviction, the fact of lack of any close ties
in the UK, and the fact of failure to comply with border controls (albeit that this might have been explicable
by trafficking), when taken together with the material fact of the lateness of the asylum claim, lead me to
the conclusion on the balance of probabilities that detention would have been continued notwithstanding
the reasonable grounds decision. In my judgment, detention would have been justified on public order
grounds in those circumstances, bearing in mind in particular that the conviction for the drugs offences was
a matter to be regarded as of significant seriousness.”

55. So far as the second period of detention under challenge is concerned, the judge said this at
paragraph 47:

“But for one thing, the “very exceptional circumstances” criterion could not in my view have been met. If the
circumstances had remained as they were at the time of the third and fourth detention reviews, continued
detention on normal public order grounds would have involved undue dilution of the “very exceptional
circumstances” criterion.”

Having then considered the entries relating to the assault incident on 17 August 2015, the judge expressed
his conclusion in these terms at paragraph 50:

“These matters seem to me to indicate that the circumstances were at that point “very exceptional” within
the meaning of paragraph 55.10. There was already a high risk of absconding. There was already


-----

considered to be a medium risk of re-offending. Both of those risk assessments were eminently justified,
where [T] was said to be in debt-bondage to the traffickers who brought him to the UK. The incident on 17
August was one to which the defendant was bound to have regard to in deciding whether or not to continue
detention. The fact that, over and above significant but in themselves unexceptional risks of absconding
and re-offending, there was now a specific incident involving a serious assault on other Vietnamese
nationals was itself, in my judgment, sufficient to constitute very exceptional circumstances. It must be
remembered that “very exceptional circumstances” are to be considered from the starting point of someone
who has a conclusive grounds determination. Factors that are particular to this case and would themselves
justify detention (such as criminality) are therefore capable of forming part of the matrix of very exceptional
circumstances, even if they are not in and of themselves very exceptional. The claimant's previous history
and circumstances (in particular, his immigration infractions, criminality and lack of domestic ties) would not
themselves have been sufficient to constitute very exceptional circumstances. However, the incident
recorded in the fifth detention review, which caused [T] to be assessed as posing a high risk to others, was
properly to be regarding as constituting very exceptional circumstances. I find that it was strongly probable
that the Secretary of State would have continued the detention in the light of such an assessment.”

**Disposal**

56. Mr Knafler at the outset of his submissions placed considerable emphasis on the decision of the Court
of Appeal, Criminal Division, in the case of R v L [2013] EWCA Crim 991, [2014] 2 Cr. App. R 23. He said
that, the applicant being a victim of trafficking in the way that he had been, his criminal offence was a
manifestation of that exploitation. He said that, had the true position been known at the time, the appellant
should not and would not have been prosecuted at all. Further, his conviction should not, given those
circumstances, provide any proper support to a finding of a risk of reoffending or absconding. Moreover,
the risk of reoffending for drugs offences of this type also had to be viewed in the light of the fact that the
appellant had been removed from his trafficked situation. Yet further, the fact that the appellant had been
trafficked also was relevant to the assessment of the risk in other ways: for example, his illegal entry into
the UK could not fairly be used against him in circumstances where (as now established) he had been
trafficked into the UK.

57. I do not accept, on the evidence available, that in the circumstances the appellant would not and
should not have been prosecuted or convicted. As the decision in L makes clear, all these cases ultimately
are fact specific. In the present case, the prosecution and plea both postdated the decision in L. It is not
thinkable that the legal teams for the prosecution and defence, and the judge himself, would have
overlooked the decision in _L_ had it really been clearly in point. As the recent decision of the Court of
Appeal, Criminal Division in R v S(G) [2018] EWCA Crim 1824, [2019] 1 Cr. App. R 7 confirms, there is no
blanket immunity from prosecution conferred on victims of trafficking. The level of coercion involved is not
necessarily such that criminal culpability is reduced to a point where it would not be in the public interest to
prosecute; and moreover there needs to be a causal nexus between the trafficking and the offence. In
circumstances where the appellant here had been at the property for over a year, and where there was no
evidence from him as to his degree of supervision or freedom to leave the house or access to mobile
phones and so on, those points stressed in _S(G)_ apply here. The appellant, it will be recalled, had legal
representation at the time. It is noticeable that, apparently, no defence of duress was ever mooted; and no
basis of plea seemingly was ever proffered to the sentencing court, either.

58. As to the risk of absconding, Mr Knafler accepted that in an appropriate case a high risk of absconding
could be a ground of “public order” which, under the relevant policy, could justify detention. But his
submission remained that this was not an appropriate case and that the decision to detain for the first
period was made at this time without the relevant officials having (as they should have had) the letter from
the Competent Authority stating that there were reasonable grounds for believing the appellant to be a
victim of trafficking.

59. In my opinion, the reasonable grounds letter from the Competent Authority cannot in any way be taken
as determinative on the question of risk. The fact is that the appellant had properly been assessed as of a
high risk of absconding. The focus for detention purposes was not simply, or even principally, on his


-----

conviction. There was also the high risk of absconding because of his perceived lack of ties with the UK
and his obstructiveness towards obtaining the travel documentation needed to return him to Vietnam.
Moreover, the asylum claim had only emerged very late in the day, after the notice of intention to deport.
The reasonable grounds letter impacts on none of those points.

60. In my opinion, the reasoning of the judge at paragraph 45 of his judgment is wholly sustainable. The
public order ground was made out. I would endorse the judge's conclusion that detention in this period was
justified. The appellant could have lawfully been detained in that period; and, as also found by the judge,
he would have been.

61. Clearly, however, the whole approach is required to be significantly different for the second, later,
period of detention: by reason of the requirement of “very exceptional circumstances” (and the word “very”
is for this purpose also not to be ignored).

62. As will be gathered, the judge had accepted – in my opinion, quite rightly – that had circumstances
remained the same after 17 August 2015 then continued detention could not, without more, have met the
“very exceptional circumstances” requirement. But he concluded that, when added to the other matters, the
assault incident on 17 August 2015 made the crucial difference for this purpose. So the question is: did it?

63. It is unfortunate that we, and the judge, had such limited evidence on this aspect. But as Mr Knafler
entirely properly pointed out, the burden is on the Secretary of State: and the Secretary of State is confined
to the materials adduced.

64. The entry in the fifth detention review provides very little hard evidence of what actually occurred on 17
August 2015. Mr Knafler in fact submitted that the entry is just as consistent with the appellant being
innocently caught up in the fracas: and he also suggested that he may have been placed on his own in a
cell under Rule 40 for his own protection. However, in my view the entry, naturally read, more obviously
suggests that the appellant had been in some way a participant in the attack on the two victims: and that is
also consistent with the information provided in the subsequent Bail Summary.

65. But, that said, the information remains woefully scant. It remains wholly unclear just what part the
appellant himself actually played in the assault. Further, what he was asked, and said, in police interview
was not put before the court. Although the assault was described as a group assault and the injury caused
was said to be “severe” there was no medical or other evidence adduced as to what that injury actually
was. It is not explained whether or not any weapons or objects were used in the attack; it is not explained
whether or not the assault was planned or suddenly erupted; and so on.

66. It is also of concern that there is no evidence of any charge or conviction: to the contrary, it would
seem, from what we were told, that there was neither. If that is so, that also places some doubt on the
seriousness of the assault and the severity of any injury caused. Moreover, reliance on one isolated
incident of this kind in a detention centre (there was no other evidence of any violent misconduct on the
part of the appellant at any other time whilst he was in custody or in detention) provides a slender basis for
inferring a propensity to violence or a risk of harm to the public.

67. That being the evidential position, and so much being left unexplained, in my opinion it cannot be
concluded that continued detention would have been justifiable on the “very exceptional circumstances”
basis. Therefore, with all respect to the judge, I would disagree with his appraisal set out in paragraph 50 of
his judgment. In saying that, I stress that I should not be taken as saying that violent misconduct whilst in
custody or in detention on the part of a victim of trafficking (whether comprising one incident of appropriate
gravity or a series of incidents) can never bring a case within the “very exceptional circumstances”
criterion. Of course it may. But it all depends on the particular circumstances. And here those
circumstances, on the evidence (or, rather, lack of evidence), do not, in my opinion, suffice.

68. Consequently, I would for my part reverse the judge's decision on this aspect of the detention. I would
hold that the appellant was wrongfully detained between 18 August 2015 and 14 September 2015; and
thus is entitled to substantive damages.

**Conclusion**


-----

69. I would reject the appeal on the certification ground. I would reject the appeal with regard to the first
period of detention. But I would allow the appeal with regard to the detention between 18 August 2015 and
14 September 2015 and would award damages accordingly.

70. It is to be hoped that the parties can in due course agree the quantum of such damages. If they
cannot, the issue of quantum is to be remitted for assessment by a Master of the Queen's Bench Division.
Any submissions on matters such as costs (if they cannot be agreed) should be provided to this court in
writing and will be decided by this court on the papers.

**Lord Justice Simon:**

71. I agree.

**Sir Stephen Richards:**

72. I also agree.

**End of Document**


-----

