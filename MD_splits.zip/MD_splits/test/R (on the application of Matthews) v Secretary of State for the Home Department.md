# R (on the application of Matthews) v Secretary of State for the Home
 Department [2018] EWHC 2026 (Admin)

Queen's Bench Division, Administrative Court (London)

David Elvin QC (sitting as a Deputy High Court Judge)

1 August 2018Judgment

**Helen Foot (instructed by Kesar & Co.) appeared on behalf of the Claimant**

**Zane Malik (instructed by the Government Legal Department) appeared on behalf of the Defendant**

**Hearing dates: 2-3 May 2018**

- - - - - - - - - - - - - - - - - - - - - - - - - 
**Judgment Approved**

DAVID ELVIN QC (Sitting as a Deputy Judge of the High Court)

Introduction

1. This is an application for judicial review brought with permission granted by David Edwards QC (sitting
as a Deputy High Court Judge) on 16 November 2017 of the decision of the Secretary of State (“SSHD”)
on 4 May 2017 to refuse to issue the Claimant a passport on the basis that she was not satisfied that the
Claimant (“C”) is a British citizen.

2. The issue before me resolves to the simply stated question of whether C is the individual Oluwakemi
Otitodun Olorunleke Matthews (“OM”) who was born in Bradford on 1 June 1976. While it is accepted that
[OM is a British citizen pursuant to the relevant provisions of the British Nationality Act 1948 in force at the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0D9-00000-00&context=1519360)
time of OM's birth, it is disputed that C is the OM who is named in the birth certificate.

3. This category of case is an unusual one in terms of this Court's jurisdiction in that the C's legal status is
a question of precedent fact to be decided on the balance of probabilities by the Court. See **_Harrison v_**
**_Secretary of State for the Home Department_** _[[2003] EWCA Civ 432 at [34] where Keene LJ held:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFS1-DYBP-P0CK-00000-00&context=1519360)_

“If, therefore, there is a dispute as to whether a person has the legal right under the 1981 Act to the status
of a British citizen, that dispute is something which can be resolved in the courts. Such a person can bring
proceedings for a declaration that he is entitled as of right under that Act to British citizenship, as both Mr
Richmond and Mr Pannick agree. In determining that matter the court will itself resolve any issues of fact
as well as any issues of law. This is not, in truth, judicial review of a decision taken by any administrative
body or person, but the more conventional resolution of a dispute with which the courts are very familiar.
That being so, the court would not afford to the Secretary of State any margin of appreciation or degree of
deference where the resolution of issues of fact is concerned. It will find the facts for itself according to the
evidence before it.”

4. I have accordingly not only been provided with a bundle of documents said to bear on the issue of C's
status but have also heard lengthy oral evidence from C, called by Ms Foot, which was subject to crossexamination by Mr Malik on behalf of the SSHD.


-----

Issues


**Relevant statutory provisions**

_[British Nationality Act 1948](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0D9-00000-00&context=1519360)_

5. S. 4 of the British Nationality Act 1948, governing nationality at the time of the Claimant's birth, states as
follows:

“Subject to the provisions of this section, every person born within the United Kingdom and Colonies after
the commencement of this Act shall be a citizen of the United Kingdom and Colonies by birth.”

6. Provided that a person shall not be such a citizen by virtue of this section if at the time of his birth—

(a) his father possesses such immunity from suit and legal process as is accorded to an envoy of a foreign
sovereign power accredited to His Majesty, and is not a citizen of the United Kingdom and Colonies; or

(b) his father is an enemy alien and the birth occurs in a place then under occupation by the enemy.”

_[British Nationality Act 1981](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GSM0-TWPY-Y0YY-00000-00&context=1519360)_

7. The _[British Nationality Act 1981,makes the following provision in respect of Citizens of the UK and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GSM0-TWPY-Y0YY-00000-00&context=1519360)_
Colonies at section 11:

“11 Citizens of U.K. and Colonies who are to become British citizens at commencement.

(1) Subject to subsection (2), a person who immediately before commencement—

(a) was a citizen of the United Kingdom and Colonies; and

[(b) had the right of abode in the United Kingdom under the Immigration Act 1971 as then in force,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

shall at commencement become a British citizen.”

_[Immigration Act 1971](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

8. By virtue of s. 2 of the Immigration Act 1971, Citizens of the UK and Colonies who were born in the UK
had the right of abode.

9. Section 3(8) Immigration Act 1971 states as follows:

“When any question arises under this Act whether or not a person is [a British citizen], or is entitled to any
exemption under this Act, it shall lie on the person asserting it to prove that he is.”

10. It is common ground between the parties that:

(1) OM who is named in the birth certificate is a British citizen and would be entitled to a British passport
since, although his parents had Nigerian nationality at the time they were in the UK while OM's father was
studying in Bradford, OM was born in the UK; and

(2) The burden of proof lies on C to demonstrate on the balance of probabilities that he is OM named in
the birth certificate.

11. C must therefore prove through the documentation produced to the court and his oral testimony that
he is OM and is therefore a British citizen.

12. Other issues were raised in the statement of facts and grounds relating to fairness and consistency,
since there had been previous decisions of the Defendant which had appeared to accept C's claim to
British nationality. However, those decisions do not definitively determine the issue before the Court and
regardless of what might have been assumed at the time, I have to consider the evidence as a whole. Ms
Foot, realistically, did not seek to pursue the other pleaded issues but focussed her submissions on proof
of the C's status.


The Claimant's case


-----

13. C's case is that he is OM, who was born in Bradford on 1 June 1976 and whom the Secretary of State
accepts is a British citizen by operation of law. His claim is based on his own oral testimony given on oath
and on the documentary evidence which has been produced to the Court.

14. His case on the facts is as follows, that is to say this is a summary of his account of the facts in the
Statement of Facts and Grounds and in the witness statements.

15. C was born in Bradford, West Yorkshire, on 1 June 1976 to two Nigerian nationals, David Kayode
Matthews and Bamidele Edna Matthews, who were living in the UK as at the time the Claimant's father
David Matthews was a student at Bradford College.

Nigeria

16. C subsequently left the UK with his mother and his older sister (Adenike Matthews), who is five years
older than him (born on 18 May 1971), when she returned to Nigeria in August 1977, with the Claimant
travelling as an infant on his mother's passport. At that time, C's sister would have been six years old. C's
father subsequently returned to Nigeria from the UK separately and re-joined the family in Nigeria.

17. C grew up and was educated in Nigeria. His parents separated and C initially lived with his mother in
Ilorin and saw his father who lived in Ibadan with his other wife. Because of his mother's poor health, he
moved to live close to his mother with his father's sister-in-law. He was educated at the Alade Nursery and
Primary School and then at Kwara State Polytechnic in Ilorin. C says that both his mother and his sister
told him he was a British citizen. Both his parents were killed in a road traffic accident on 24 July 1993 in
which the Claimant was also badly injured. Following this incident C says he and his older sister were
raised by their grandmother and other family members, since his grandmother was away selling animal
skins for months at a time. His sister lived with his father's widow.

18. Following the death of his parents C lived in very difficult financial circumstances with his extended
family in Nigeria. He was working as a trader selling poultry and living with his grandmother's nephew
Abuda who mistreated him. C says he told his sister of these problems when she visited and but she was
still a student an unable to help but his grandmother and sister believed that the solution to his problems
would be to obtain a British passport, as he was born in the UK, and then move away from Nigeria.

19. C believes that his sister went to an immigration lawyer in 1999 or 2000 for advice on C's behalf and
was advised that as he did not have his original birth certificate, which was lost when he was a child, C
could not obtain a British passport at the High Commission in Lagos. Although this had not originally been
mentioned, C also said that he remembered going with his sister to the police to report the missing birth
certificate though his oral account of this was confused.

20. In 2001 C's grandmother and sister met two men who claimed to reside in the UK, apparently named
Lekan and Austin. It seems that C's grandmother had done business with them previously. C's
grandmother thought that they could assist in obtaining a new copy of C's birth certificate from the UK and
send it to C so that he could apply for a British passport. The two men offered to assist in this way and
returned to the UK.

21. Around Easter of that year they then returned to Nigeria and informed the Claimant that they had not
been able to get a copy of his birth certificate and told him that he would have to come to the UK to obtain
it in person. They said that they could help him and asked for a substantial sum of money, which C's sister
and grandmother agreed to pay.

22. They instructed C to wait for them to contact him and then he would meet them at Lagos airport. The
Claimant was told that they would ensure he had a passport to travel to the UK. In 2002 he was contacted
and arranged to meet them but this attempt at travel proved abortive and he did not travel until March
2003. On this occasion he was met by Lekan, who walked him to a particular immigration officer who then
walked him to the plane. C was given a passport. When he arrived in the UK he was met at the airport by
Austin, who took the passport. C did not see that passport again.

United Kingdom


-----

23. C was taken to Strood for three days and then to Rochester, where he was made to live with Lekan,
Lekan's wife and their children. C was made to work for no pay as a cleaner and childminder to Lekan's
children. Lekan's wife also appeared to work as a cleaner. Lekan travelled frequently to Nigeria, leaving C
to be supervised by the wife. During this time Lekan was refusing to assist C in obtaining a birth certificate
as promised and would make threats to C that he would inform the police that C was here illegally unless C
obeyed him. C was held by Lekan from approximately 2003 to 2005.

24. In 2005 C was instructed by Lekan to leave his family home and to meet with another person,
apparently called Brimo, who said that C would have to work in order to accommodate himself and to pay
for his birth certificate and passport, which Brimo promised to obtain for him. He was made to stay in very
overcrowded accommodation in Peckham

25. Around six months later Brimo presented C with a fake passport in the name of Olatunji Okunola,
stating that this was to enable C to start working as C needed to work first to pay for his own birth
certificate and passport to be obtained. C knew that this was wrong but did not know what else to do. Since
being in the UK he had been in a vulnerable position and continued to feel that he had no option but to
trust this individual.

26. By early 2006 C had started working unlawfully using the false passport. He met his partner Mariam,
another Nigerian national, although they did not live together at this point. In October 2006 the Claimant
tried to open a bank account using the false document. He was arrested and immediately informed the
police that the passport was a false document that had been given to him. He was prosecuted in respect of
the false passport.

27. C pleaded guilty and was sentenced to 12 months' imprisonment and recommended for deportation.
He recalls being interviewed by two immigration officers who informed him that someone had tried to
obtain a passport in his name, which they showed him, using a photograph which was not of C. C believes
that his traffickers, Lekan and Austin, may have used his identity to make this passport application, which
he understands occurred in 2005 and that therefore he has been the victim of an identity crime.

28. After release from prison, C's partner Mariam gave birth to their son on 13 July 2007. He instructed an
immigration solicitor who advised him to obtain documents evidencing his identity from Nigeria. After the
solicitor received a number of documents from the Claimant's family the solicitor applied for a birth
certificate for him, which was then sent to SSHD. C then applied for a national insurance number using his
birth certificate, his mother's Nigerian passport and the letter from the Respondent stating that he was
British.

First application for UK passport

29. C's first application for a British passport was in 2009 and in July 2009 he was interviewed by two
immigration officers at Her Majesty's Passport Office (HMPO). The Claimant's passport application was
first refused in 2009 and the refusal was maintained by HMPO throughout 2009-2012. The correspondence
from HMPO requests additional documents and information as to the Claimant's “adult life prior to 2006
including travel documentation showing how you re-entered the UK” and “conclusive evidence” that he held
his identity prior to 2006. C had lost touch with his sister at that time and was struggling to obtain further
documentation but supplied all the evidence he had available, including his mother's passport (containing
OM's details and evidencing her return to Nigeria with OM), documents relating to his school attendance
and life in Nigeria, and documents relating to his father's education in the UK. In 2010 C obtained a
Nigerian passport to which he was entitled through his parents and sent this to HMPO. In the same year
Mariam gave birth to the couple's daughter.

30. C applied for a judicial review in May 2012 which was refused on the papers but prior to the hearing of
the oral renewal application the SSHD agreed to reconsider C's passport application and the matter was
withdrawn by consent. Throughout 2013 HMPO maintained their refusal of C's passport application
including on the basis that he had failed to produce “adequate documentation” and that there was no
“substantial new evidence that (your client) inhabited the Matthews identity prior to his arrest for
possession of a false instrument”.


-----

31. In 2015 C obtained further documentation in respect of his identity and submitted these to HMPO. This
led to a further refusal in November 2015, on the basis that
“you have failed to establish to our satisfaction that you are the genuine holder of the Matthews identity.
Although you are in possession of a limited amount of documentation you have not demonstrated that prior
to 2006 the records refer to you”.

32. The refusal letter also referred to 
“your admission that you entered the UK illegally and do not appear to have asserted the Matthews identity
until your arrest and imprisonment in 2006, and your interview at the London office in 2009, have proved
significant obstacles to overcome.”

33. When he eventually came to understand that he had been the victim of trafficking C reported this crime
to the police. A referral was made on his behalf, by the Salvation Army, to the National Referral Mechanism
('NRM') for identifying and referring potential victims of trafficking and modern slavery. C was issued with
a “conclusive grounds” decision from the National Crime Agency on 11 May 2016 that he was a victim of
**_modern slavery. Whilst this demonstrates that C suffered as a trafficked person for several years, and is_**
undoubtedly affected by it, it does not itself establish his identity as OM or provide material support to his
application before me.

34. Although SSHD had written in 2007 accepting that C was OM and a British Citizen, the position was
not maintained and it is agreed that it was not binding on the SSHD.

2017 application for UK passport

35. On 14 March 2017 C applied again for a UK passport in the name of OM and submitted in support of
this:

(a) a Nigerian passport issued in 2010;

(b) a copy of a Nigerian passport in the name of Bamidele Edna Matthews;

(c) a student ID card;

(d) seven photographs;

(e) a letter from the National Crime Agency dated 11 May 2016;

(f) two solicitors' letters addressed to UKVI;

(g) a witness statement;

(h) a birth certificate for Oluwakemi Otitodum Olorunleke Matthews;

(i) nine educational certificates issued to David Kayode Matthews;

(j) two college letters;

(k) two invoices;

(l) seven Nigerian primary school certificates and correspondence;

(m) a Nigerian secondary school certificate and correspondence;

(n) two medical letters.

36. On 4 May 2017, the SSHD refused to issue the Claimant with a UK passport and following pre-action
correspondence, proceedings were issued on 10 August 2017. Following the refusal of permission on the
papers, permission was granted on renewal on 15 November 2017.

The evidence

37. In addition to the witness statements and documents submitted by the parties, I heard oral evidence
from C which was subject to cross-examination from Mr Malik on behalf of SSHD and some questions from
lf Th i ti f C


-----

38. Whilst I heard oral testimony from C dealing with the account of the facts I have summarised above
(and which I shall assess below) it is notable that no other witnesses were called, in particular no evidence
nor even a sworn statement was produced from OM's elder sister who was 5 at the time of his birth and 6
when the family returned to Nigeria in 1977. This is surprising since on C's evidence she would have seen
OM from birth, she is said to have travelled back to Nigeria with OM and their mother, and seen him
growing up in Nigeria. C's evidence was that they stayed in touch even after he left Nigeria for the UK.
Indeed, C said that she had herself visited an immigration lawyer in about 2001 in an attempt to assist C
obtain a UK passport.

39. I was told by C that she was currently living in France and had been there since 2005. When asked in
cross-examination why she had not been asked to support the application C did not give a clear or
satisfactory response:

“Q. Do you talk to your sister?

A. It's been a long time that I've spoke to her. Last year.

Q. Why is it that your sister has not given anything to support your application?

A. She did. She try all her best, but when there's nothing to do, what can she do?

Q. But she could have given a statement to support what you have said.

….

JUDGE ELVIN: … What Mr Malik is asking you is your sister could have come and given evidence to the
Court as well and identified you.

A. Okay. All right. Correct.

…

A. I didn't know is that I don't even know her status in France you understand. I don't know her status in
France and she is the only one calling me and she is always calling me. When I call her, her phone don't
go through. She's always calling me.

Q. So you do speak to your sister.

A. She is the one that call me.

Q. So you never asked her on what basis she was living in France.

A. Because every time when when every time she is talking to me, she is always complaining as well that
she want to go somewhere else. She want to go to Dubai.

Q. Thank you.”

40. Similarly, although a short supporting statutory declaration was provided by OM's cousin (Mr
Oloruntoba Mathew) in 2011 this did not provide much detail and he was not called to give oral evidence.
No explanation was given for his not being called.

41. C's partner Mariam was also not called although she could presumably have spoken to what
happened to C from about 2005/6 onwards.

42. Accordingly, I am only able to assess the strength of C's case on the basis of his testimony alone and
from the documents. It is self-evidently difficult for C to give evidence as to his birth and his early years.

43. His evidence was unclear, unsatisfactory and unconvincing on a number of issues, including the
following matters:

(1) I refer below, in connection with documentation, to the family photographs and their limited probative
value. Although at one point C said that he had asked for family photographs to be sent by his
grandmother, which were sent, he then later said there were other photographs, possibly of himself, his
sister and their parents, but they had not been sent –


-----

“Q. Who gave you those photographs?

A. My grandmum.

Q. If your grandmother can give you those photographs, why can she not give you photographs showing
you and your sister and parents together?

A. The photographs she gave to me is the one I requested for, like when I was born in London, in
Bradford. That is what I requested for. I never requested for photograph of me and my sister.

Q. Okay. So you are suggesting that there are photographs.

A. There are many pictures.

Q. There are photographs showing you, your sister and parents together in Nigeria.

A. Yes.

Q. But you have not asked anyone to send you them.

A. I asked them to send pictures, everything concerning my family, but this is just the one they sent to me.

Q. Sorry. Just to clarify the answers that you have just given. You have just told us that the photographs
that you have produced

A. Mm hm.

Q. Are the photographs that you specifically asked for.

A. Yes.

Q. So you did specifically ask

A. No, I didn't specifically ask for pictures like that. I said to them any document, any pictures regarding
me, my mum, my school result, any result that they have seen that have got anything to do with me they
should send it.

Q. So the fact that they have not sent any other photographs means that there are no other photographs,
does it not?

A. Yes. I'm sure there will be more photograph. I can ask them to send more pictures.

Q. I will move on.”

However, C has been represented by immigration lawyers and been assisted in making his applications for
a UK passport for a number of years and it must have been impressed on him (not least as a result of the
rejection of his applications by the UK authorities) that he needed to obtain significant and convincing
evidence of his identity. His answers seemed to me not to recognise that important requirement. While C is
of course not a lawyer and had been mistreated for a number of years, he must at least have appreciated
the importance of providing sufficient evidence to satisfy the UK authorities to obtain a UK passport which
had been a matter of great concern to him for many years.

(2) C insisted that his sister had told him he could trust Lekan though clearly Lekan was one of those who
then trafficked him into the UK. While it is possible that C's sister and grandmother were misled by Lekan,
C said that

“JUDGE ELVIN: .. Did your sister tell you why she trusted Lekan?

A. Er, my sister just said she trusted Lekan that he will never be that kind of person, because after they
met with my grandmum my sister always see Lekan. She always go and see him.”

C also said that Lekan and Austin had come to his grandmother's shop previously. However, C was sure
that he could not trust Lekan from the moment when they got to the UK:

“Q. You then explain in your statement as to how Lekan mistreated you when you arrived in the United
Kingdom When is it that you precisely realised that Lekan was not sincere with you?


-----

A. Right from day one.

Q. Day one. I am grateful. Thank you. Now para.38 you say that in 2005 Lekan told you that if you go to
London you will get your passport there and that is how you came to London.

A. That's how.

Q. If you knew from day one

A. Yeah.

Q. that Lekan was not sincere with you

A. Because he treating me bad.

Q. Listen to the question. If you knew from day one that Lekan was not sincere to you, he was treating
you badly, why would you believe him that you would get your passport in London and would travel to
London?

A. Because whenever what Lekan was doing to me when my sister call I used to talk to my sister about it
and my sister would always say to me, "There is nothing left for you. You have to face it. You have to make
sure you get this, because there's nothing for you," and she trust Lekan. My sister really trust him and she
said, "I'm sure he will get you your passport.”

Whilst I appreciate that C was in a difficult position, was scared to go to the police because he had no proof
of who he was, and may have thought he had no option but to accept what Lekan was telling him to do, I
find his evidence to be unconvincing. In particular I find it difficult to accept his claims that his sister was
telling him to proceed, was apparently unconcerned about his position in the UK that Lekan and Austin had
supposedly been known to both C's sister and his grandmother and that Lekan was really trusted by his
sister.

44. These are not the only examples of confused or faulty recollection. Others arise in respect of the
circumstances of the motor accident in which C's parents were killed and C was injured and the visits to the
immigration lawyer and police station in 2001/2002, in respect of which it became unclear whether there
had been a report to the police, or a visit to an inspector who was a friend of the family, but it is
unnecessary to deal with them all in detail. In general terms, the clarity with which C's evidence was
presented in his two statements of 24 July 2012 and 25 January 2018 was lacking in C's oral evidence,
even making allowance for the passage of time and the stress of giving evidence.

45. While I have to take account of the effect of the passage of time on memory, and the effect of being
trafficked on C, I nonetheless have to be satisfied that his evidence supports his claim. Further, at a
number of points in evidence, C showed considerable stress and reacted highly emotionally especially
when asked question in cross-examination which went to his credibility or the reliability of the documentary
evidence. While it is to be expected that a claimant in the circumstances C has faced is likely to find
challenge to his evidence to be difficult to deal with I was concerned that these episodes did tend to occur
at points when the challenge to his account was most critical and where C needed to give clear and
convincing answers, e.g. on the issue of why his sister had not been asked to given evidence.

46. Documentary evidence has been provided in a number of forms as sent to the SSHD in 2017. Some of
those documents in the bundle were also produced as originals in Court, e.g. OM's mother's passport. I
have considered them in the light of the evidence as a whole:

(1) The documents relating to OM's parents, including OPM's father's student ID card, family photographs,
apparently of OM's parents, and OM's mother's passport, as well as OM's birth certificate, do not provide a
direct connection with C nor demonstrate that C is OM. Whilst it might be said that the fact that they have
been provided shows some connection existed with those able to obtain OM's family documentation they
fall far short of establishing that C is OM;

(2) Invoices and bills relating to C's business may use the name “OM” but do not take the matter further;


-----

(3) Documents relating to OM's parents, which do not provide proof that C is OM. There is no doubt that
they were OM's parents and that OM was born in the UK;

(4) I have no reason to doubt that OM's mother's passport or the family photographs were genuine
(originals were produced) and they support C's claim to the extent that they were produced from Nigeria to
support his claim so there was clearly access to OM's family documents;

(5) Various documents said to have been signed by OM appeared to have different signatures. Compare
those appearing in the trial bundle at pp. C67, D31, F17, F36 and F37;

(6) Although C said he had told Mariam his real name, OM, when she came to register the birth of their
son she used the name that had appeared on the false passport, Okunola, although C said he had told her
his real name at the outset –

“Q. I understand, but why would she give a false surname?

A. I don't know. That's what I asked her. I did ask her when I came out. She said that's what she want to
do. That she don't want me to got anything to do with her son.

Q. I understand. Then why not give another name?

A. I don't know.

Q. Why give a name

A. Because that's the name she used to call me. She used to call me Okunola. That's what I said to you.
They introduced me to her as Okunola. I spoke to her. I said to her that is not my real name.

Q. But, nevertheless, she decided, with full knowledge that your real name was Matthews, to give a false
name.

A. She might not be sure then as well, because the introduced like someone introduce you that this is
Okunola and I went back to her. I said "That is not my name.”

(7) C also used the false name, Olatunji Okunola, when registering with the Department of Work and
Pensions;

(8) School records obtained via family members from Nigeria. The Alade Nursery and Primary School
Records (trial bundle Tab L pp 21-27) have no pupil's name attached and do not assist but there is a
Certificate of Primary Education stamped 5/3/2007 relating to school years 1981-2 to 1986-7 (trial bundle
Tab L p. 35) bearing the same or a closely similar stamp and signature to the unnamed school records.
Though some are stamped 4/11/2007 and some dated 1985. There is a letter of confirmation ostensibly
from the Principal that OM was a student of Kwara Polytechnic Secondary School from 1991 to June 1994
and a Senior School Certificate for June 1994. There is a letter from A. A. Abiodun, Head Teacher of Alade
Nursery and Primary School forwarding a “copy of the transcript of academic records” which is stamped
4/11/2007 (trial bundle Tab L p 50) - the same date as some of the records;

(9) There were discrepancies or troubling features in the school records 
(a) The documents bore different and often more recent dates, which were probably the dates they were
stamped and sent from Nigeria when requested by C.

(b) Although the Certificate of Primary Education (trial bundle Tab L p 35) states that OM was in Class
Primary 3 from 1983-4, the Report Card (trial bundle Tab L p 29 and D p 38) records instead that he was in
Class 3 in 1984-5. It is unclear when the Report Card was created, I assume it is the original, whereas the
Certificate has the date of 5/3/2007 and appears to have been produced when C requested educational
records in 2007. It is possible that the discrepancy was generated by an inaccurate completion of the 2007
version but it is clear that this was not a contemporary certificate and had for completion (though not
completed) student's signature with a printed “Date….. 20….” which appears to show a modern form being
used to completed a record for the 1980s. No explanation was offered for this;


-----

(c) There was a further discrepancy since the Certificate states that in 1986-7 C was in Primary 6 though
C said that he had left in Primary 5

(d) Whilst appreciating that this related to a period of education 30 or more years ago, C was confused
(despite the signatures on the records) about the identity of the head teacher A. A. Abiodun although his
name appears on a number of the forms (both the report card for 1984/5 and the certificate issued in 2007)
and the 1985 record cards and wrote enclosing the copy records on 4.11.2007;

47. C's evidence as to the identity of his head teacher and the name which appears on the record cards
was confused and lacked clarity. The name of “Abiodun” appears on the cards and the letter as Head
Teacher with respect to the Alade Nursery and Primary School. C said in evidence that he had spoken the
headmaster himself at the time he asked his cousin in Nigeria to get copies of his records. He said he had
spoken to someone called Yemi, who was the head, though the letters and records say “Abiodun”. C then
suggested Abiodun was the owner of the school, and was female, though even this changed, but could not
explain why that name appeared as headmaster or head teacher. This is concerning since the name
“Abiodun” not only appears in respect of the report card from 1984/5 but also over 20 years later in the
copy records and letter. The answers given in cross-examination were unsatisfactory –

“A. … When they asked me to send more document, more document, more document, that's when I
spoke to him last and that must be like five years ago.

Q. Thank you. So this gentleman, Mr Yemi, was not your head teacher then?

A. Wasn't my headteacher when I was in school. It was not my headteacher when I was in school, no.

Q. Can you go to p.50, please?

…

Q. Behind tab F.

A. Tab F, yeah. Yeah, p.50.

Q. Can you see the name of the headteacher who signed this document?

A. Abiuduh.

Q. He is not same gentleman that you spoke to.

A. The headmaster I spoke to is not the same person.

Q. Why is that?

A. I don't know, because I don't know. Truly, I don't know.

JUDGE ELVIN: The date stamp on this is 2009.

A. I don't know, truly.

MR MALIK: Are you suggesting that when you spoke to a gentleman over the telephone he told you that
his name was Mr Yemi, but when he wrote the letter he put his name as Mr Abiduh.

A. Mr Yemi is headmaster. Abiuduh is the owner of the school.

JUDGE ELVIN: Well, it says "headmaster" here.

A. Abiuduh is the owner of the school. That is my believe. Abiuduh is the owner of the school.

MR MALIK: Have you ever seen Mr Abiuduh?

A. The owner of the school?

Q. Yes.

A. When I was young, I used to see him, yeah. Yeah, when I was young.

Q. Can you go back to p.29 same tab.


-----

A. 29.

Q. Yes. This is the report that we were just looking at.

A. Yeah.

Q. Can you tell us what is the name of the headteacher stated on there?

A. Abiuduh.

….

A. It's Mrs. It is not even Mr. It is Mrs Abiuduh.

MR MALIK: Is that not the same person who issued the letter that you have just

A. It's the same person, yeah, because I can see the name now, because I didn't even go through all
these document that they are giving me.

Q. Let us get this straight. Who is Abiuduh?

A. It's the owner of the school. She is the owner of the school.

Q. She is not the headteacher.

A. No, she is the owner of the school.

Q. So when she said at p.29 and p.30 that she was the headteacher, she was wrong.

A. Maybe she is wrong. I don't know. Nigerians, you can't -- sorry, sir -- Nigerians you can't compare the
level of education in this country to Nigeria like. Nigerians all the things that they put together is somehow
that I don't understand. Truly, that's my own belief, truly.

Q. Well, you told us a few minutes ago that you have no recollection of who the headteacher was.

A. Because now I'm thinking Abiuduh, Abiuduh. That's what I'm just thinking Abiuduh, Abiuduh, because
my -- the owner of the school is a man and his wife is Abiuduh. The owner of the school is a man. It's -
Q. It is all right.

A. Why?

Q. You will agree that the documents at p.29 and p.50 contain inaccurate details.

A. Because now I can say that, because where I was born, Ilorin, I don't know who gave them that. With
the dates, I don't know who gave them that as well. So, it's been difficult for me now, because all these
document I spoke to the headmaster and he said to me my cousin should come, that he's going to give him
everything.

Q. Yes, yes. As I recall, a few minutes ago you told us that you have seen these documents and you are
satisfied that these documents were accurate.

A. Because I saw the document, but they sent it to my solicitor. They send it to my solicitor. I didn't even
have time, because I'm not even thinking for myself.”

Given the importance attached to these records and the earlier apparently clear statements by C in writing,
not supported in his oral evidence, I regrettably cannot accept that the education documentation is reliable.

48. Finally, and in any event, the records do not demonstrate that the OM named in the records is the OM
named in the birth certificate and their role as supporting evidence is significantly flawed for the reasons
given above.

49. I accept Mr Malik's preliminary submissions on behalf of SSHD that:

(1) A birth certificate is not satisfactory evidence of identity as it is merely evidence of an event, in this
instance, that OM was born in Bradford to Nigerian parents on 1 June 1976. Ms Foot does not dispute this,


-----

(2) The letter dated 28 February 2007 was issued to the Claimant in error. This can be seen from a file
note for 27 February 2007 which indicates that the statement that C is a British citizen was derived from
the receipt of a birth certificate for OM. The letter in question was issued without any further checks being
carried out to verify that C was OM. Again, this is not disputed.

(3) The assessment of whether C was a victim of modern slavery was not informed by any investigation
as to C's identity and does not therefore support to C's contention that he is the person who was born in
the UK on 1 June 1976.

(4) The identity of OM was recognised as being vulnerable following the fraudulent attempt to obtain a
passport in that name in 2005.

Conclusion on the evidence

50. I have considered the evidence as a whole carefully, in the light of the above, and assessed C's oral
evidence with particular care to ascertain whether it does provide the requisite degree of support for his
claim to be a British citizen. I have not referred to every document in the trial bundle in this judgment but I
have considered each of them to ascertain whether they can provide support for the claim.

51. However, despite the passage of time and the evident stress and emotion which C displayed in the
witness box I am not satisfied on the balance of probabilities that he is OM identified in the birth certificate.
Whilst there is some supporting documentation, I do not find them to provide sufficient support for the claim
and its probative value was reduced by the confused and unsatisfactory explanations given for significant
aspects of it by C in oral evidence, particularly the school records. Moreover, there is lacking from the
documentary evidence anything which provides a clear, independent and reliable link between C and the
OM identified in the birth certificate.

52. For obvious reasons, C cannot testify to his own birth and early years and despite there being at least
two persons who might well have been be able to do so, namely OM's sister and cousin (Mr Oloruntoba
Mathew), they were not called.

53. Mr Mathew made a statutory declaration on 8 August 2011 stating that he has known OM since
childhood and that he was OM's first cousin. He states that he has seen the photograph in C's Nigerian
Passport (A02117114) dated 20.9.10 and confirmed it was a true likeness of OM. There is little detail in the
declaration which runs to 4 short paragraphs. Whilst the declaration supports C's claim it is light on detail
and would have carried much greater weight if it had been supported by oral testimony.

54. Not only were OM's sister and cousin not called, nor his partner, it appeared that no attempt had been
made even to request their attendance. OM's sister did not even provide an affidavit or witness statement.
To my mind, this significant and obvious lack of evidence from at least one person who should have been
able to speak directly to the issue of the identity of C and OM from birth was in my view a critical omission
which might have made up for the lack of reliability in the documentary evidence and C's account of it. The
lack of coherent explanation for the failure to call her or even to ask her to give evidence, and C's strong
reaction to being questioned about such matters, casts doubt on the credibility of C's own evidence.

55. Since I am not satisfied on the balance of probabilities that C is the OM named in the valid birth
certificate, I do not consider that he has established that he is a British Citizen and thus is not entitled to a
declaration to that effect. The decision of SSHD dated 4 May 2017 to refuse C a UK passport was
therefore lawful. I dismiss the application.

56. I am grateful to the parties for agreeing the form of the Court order prior to the handing down of this
judgment. I therefore order that:

(1) The judicial review be dismissed.

(2) The Claimant to pay the Defendant's reasonable costs of these proceedings, to be subject to detailed
assessed if not agreed.

(3) There be detailed assessment of the Claimant's publicly funded costs in accordance with the Civil
Legal Aid (Costs) Regulations 2013


-----

**End of Document**


-----

