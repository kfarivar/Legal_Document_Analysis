# R v Falder [2018] EWCA Crim 2514

Court of Appeal, Criminal Division

Holroyde LJ, King J and The Recorder of Winchester Judge Cutler CBE

16 October 2018Judgment

**MR ANDREW D SMITH QC appeared on behalf of the Applicant**

**MR TOM FORSTER & MISS RUONA IGUYOVWE OBE appeared on behalf of the Crown**

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

HOLROYDE LJ:

1. On 16th October 2017, in the Crown Court at Birmingham, Matthew Falder pleaded guilty to a total of 137
offences, all of which were either of a sexual nature or were sexually motivated. On 19th February 2018 he was
sentenced for four of those offences to consecutive extended determinate sentences, amounting in total to an
extended sentence of 38 years, comprising a custodial term of 32 years and an extension period of six years, with
concurrent determinate sentences for all the other offences. His application for leave to appeal against his total
sentence has been referred to the Full Court by the Registrar.

2. We express at the outset our gratitude to all counsel for the care with which they have presented the matter to
us.

3. We shall refer to those against whom the offences were committed as the applicant's victims, without naming
them. In doing so, we mean no disrespect to those who might prefer to be called 'survivors' of the offences rather
than 'victims'.

[4. The provisions of the Sexual Offences (Amendment) Act 1992 apply in this case. Under those provisions where a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
sexual offence has been committed against a person, no matter relating to that person shall, during his or her
lifetime, be included in any publication if it is likely to lead members of the public to identify that person as a victim
of the offence. This prohibition will continue to apply unless lifted in accordance with section 3 of the Act.

5. The offences were charged in four indictments and in a schedule of offences which had been committed to the
Crown Court pursuant to section 41 of the Crime and Disorder Act 1988. The details of the charge and the
sentences imposed for each offence are set out in a convenient table which forms an appendix to this judgment.

6. It is sufficient at this stage to summarise the offences as including offences of intentionally encouraging rape,
contrary to sections 44 and 58 of the Serious Crime Act 2007; causing or inciting sexual exploitation of a child,
contrary to section 48 of the Sexual Offences Act 2003; causing or inciting a child to engage in sexual activity
involving penetration, contrary to section 10 of that Act; encouraging an offence of sexual activity with a child family
member, contrary to sections 44 and 58 of the Serious Crime Act 2007; blackmail, contrary to section 21 of the
Theft Act 1968; conspiracy to commit blackmail; fraud by representation, contrary to section 1(4) of the Fraud Act
2006; forced compulsory labour, contrary to section 1 of Modern Slavery Act 2015; making indecent images of a
child, contrary to section 1 of the Protection of Children Act 1978; distributing indecent images of a child, contrary to
section 1 of that Act; conspiracy to take or make indecent images of children; conspiracy to distribute indecent
images of children; possession of indecent images with a view to their distribution contrary to section 1 of the 1978


-----

Act; possession of prohibited images of children, contrary to section 2 of Coroners and Justice Act 2009;
possession of extreme pornography, contrary to section 3 of the Criminal Justice and Immigration Act 2008;
possession of a paedophile manual, contrary to section 69 of the Serious Crime Act 2015; publishing an obscene
article, contrary to section 2 of the Obscene Publications Act 1959; voyeurism - recording a private act, contrary to
section 67 of the Sexual Offences Act 2003; malicious communication, contrary to section 1 of the Malicious
Communications Act 1988; and conspiracy to send electronic communication with intent to cause distress or
anxiety.

7. The offences involved what the learned judge, in his admirably careful sentencing remarks, aptly referred to as
"ever increasing depravity". It is a measure of their seriousness that four of the offences to which the appellant
pleaded guilty carry life imprisonment, 45 of them are punishable with a maximum of fourteen years' imprisonment
and another 55 are punishable with a maximum of ten years' imprisonment.

8. The appellant is now approaching his 30th birthday. No previous convictions had been recorded against him. He
grew up in what is clearly a loving and caring family, who are now bewildered by his offending. He excelled at
school and university, holds the Degrees of Master of Art and Doctor of Philosophy, and was a university lecturer at
the time of his arrest. He enjoyed an active social life and was highly regarded by those who knew him. A number of
testimonials were provided to the judge from which it was plain that the applicant's shocking offending was
regarded by those who thought they knew him as wholly out of character. No application was made for a presentence report and no report was or is necessary.

9. The disturbing nature of the offences, which were committed between 2007 and 2017, was described in detail to
the learned judge, who heard the prosecution opening and defence mitigation over a period of three days. We have
read the transcript of the hearing and have the details well in mind. It is sufficient for present purposes for us to give
a comparatively brief summary of the nature and circumstances of the offences.

10. The applicant began with offences of voyeurism from 2007 onwards. From 2010 he began to use the internet to
commit blackmail and other serious offences. It is a feature of his offending that he displayed considerable technical
skill in ensuring, by the use of false names, encryption, untraceable email addresses and the dark web, to avoid
being detected and identified. Between 2013 and 2017, not only the police in this country, but also law enforcement
authorities in the USA and other countries were investigating his activities. During that time, he not only successfully
concealed his identity, but also boasted about his ability to do so in order to increase the terror and distress
experienced by his victims.

11. The judge divided the offending into six categories, and we adopt the same approach.

12. The voyeurism offences involved eight female victims, of whom the applicant had taken 27 videos by the use of
hidden cameras. He secretly recorded imagery of these women in bathrooms and lavatories, including at student
halls of residence, at his parents' home and at the family's holiday home. Some of the victims were young women
who regarded the applicant as a friend. As an illustration of what he did with the recordings, he hacked into the
Facebook account of one of his victims, and replaced her profile picture with an image which he had recorded of
her naked. He sent emails to another of his victims attaching naked pictures of her, saying that unless she
responded he was "going to share this". He retained the recordings, which were found on his computer on arrest.

13. The second category of offences involved blackmail, sexual exploitation, fraud and distribution. These offences
involved the ruthless targeting by the applicant of more than twenty victims, most of them female and aged under
18. One of his victims was aged only 13, others aged 14 and 15.

14. The applicant targeted victims whom he knew to be both young and vulnerable - for example, by picking out
girls who had posted on a website devoted to those suffering from anorexia. He began by offering his chosen victim
money, in exchange for naked photographs of herself. In order to make the offer more acceptable, he used a
variety of deceptions. He posed, for example, as a female artist who had suffered from depression and who found
therapy in making life sketches from photographs. Once his selected victim had been induced to provide initial
images, the applicant asked for more. He continued to offer (but never actually to make) payment. Having acquired


-----

the images he wanted, he then used the threat of disclosing them to family, friends and neighbours to blackmail his
victim into obeying his commands.

15. In contrast to many blackmailers, the applicant does not appear to have been motivated by financial reward.
Rather, he appears to have derived pleasure from manipulating, humiliating and distressing his victims.

16. By way of illustration, he blackmailed a 15-year-old girl into sending him increasingly graphic sexual images of
herself, which he then threatened to distribute. He was wholly unmoved by her pitiable pleas to be left alone. When
she told him that she had informed her parents, who were going to report the matter to the police, the applicant's
response was to boast about the fact that he could not be caught and to increase his blackmail threats. He
continued to make demands of his victim, eventually driving her to the point where she attempted suicide. Even
after that, the applicant continued to blackmail her, and went to the length of conspiring with a boy who went to the
same school as her to make further demands.

17. Other victims of the applicant's blackmail were required not only to provide sexual images of themselves but
also to engage in utterly degrading and demeaning conduct. By way of illustration, a 15-year-old girl who had been
lured into providing naked pictures of herself, was required to make recordings of herself consuming dog food whilst
lying naked on the floor, licking a toilet seat and a soiled toilet brush, licking a used tampon, pinning bulldog clips to
her breasts and vagina, writing words such as "Slut" on herself, and holding up signs containing racist and
homophobic remarks. The applicant's messages to her made clear that he was enjoying watching her humiliation.
He also shared the images of her with others who were using sinister websites on the dark web.

18. An illustration of another way in which the applicant used the product of his blackmail relates to one of the
victims whom he had covertly recorded in a voyeurism offence. In correspondence with a fellow user of a particular
website, he sent one of the images of his victim. He instructed his correspondent to make further images, in which
that picture was covered with semen or stabbed with a knife, and also to display messages addressed to the named
victim, making terrifying threats as to what would happen to her. The correspondent sent back such images to the
applicant, who replied, complimenting his work so far, but telling him to display further and yet more appalling
messages to the named victim. He said:

19. "As for the knife, be creative ... be as scary as you can. LOL."

20. In another email exchange with a like-minded individual about one of his victims whom he knew to be aged 14,
the applicant boasted that he was trying to make her trust him so that she would send nude pictures. He added that
he was "also encouraging her to try to be anorexic too". He said that he thought he should be able to get some
good nude pictures from her willingly, and continued:

21. "Then I will see if I can get enough info to blackmail her. But if not, I'm thinking of just betraying her as harshly
as I can to see how much I can mentally fuck her up. I think there's even a bit of a chance of a suicide."

22. The applicant, as we have indicated, plainly derived pleasure from the anguish he caused to others. He
expressed complete disregard for their suffering. When threatening his victims as to the consequences of their
failing to comply with his demands, he made it clear that in the event of non-compliance he would ruin their lives.
He threatened that harm would be caused to a victim, her family or her friends. He threatened one adolescent girl
that he would take steps to try to arrange for Social Services to take her younger brother into care. He boasted that,
because he was completely untraceable, any attempt by a victim to end communication with him, "won't hurt me but
will end badly for you".

23. The blackmail and associated offences inevitably caused the applicant's victims the utmost distress and misery.
It appears that, in all, four of his victims attempted suicide. Others began to self-harm. Their ability to form
relationships was badly damaged. There were victim personal statements before the sentencing judge, which made
plain what they had suffered. We too have read their statements and we take them into account. We pay tribute to
their courage in reporting matters, as they eventually did.


-----

24. We turn to the third category of offending, which involved the applicant encouraging rape and other sexual
offences against a 2-year-old child in the United States. In this regard the applicant, through the use of the internet,
was acting jointly with two US citizens, one of whom was the child's father. That man has recently been sentenced
in America. The other has not yet been identified.

25. We summarise the distressing facts very briefly. The applicant instructed the man, whom he believed to be the
child's father, to provide images of the child being raped. He thereafter received images of the child being orally
raped by a man. The applicant encouraged his correspondent to send further images of the child being raped orally
and anally, and having urine poured over him. By way of exchange, the applicant provided images which included
imagery of torture.

26. The fourth category of offending identified by the judge related to offences involving forced compulsory labour,
blackmail and child sexual exploitation in relation to a young man in the United States then aged 19 or 20, to whom
we will refer as 'N'. As with his female victims, the applicant first enticed N into sending him indecent images and
then proceeded to blackmail him over many months. During that period, the applicant instructed his victim to carry
out and record increasingly degrading and unpleasant acts. He required N, for example, to smear faeces over his
face, to eat soiled lavatory paper, to tie weights to his genitals, to make covert recordings of his mother and younger
sister using the bathroom, and to upload a video to an internet chat site in which he spelled out, in repellent and
racist terms, a fantasy of kidnapping and raping a young black girl. After a time, N tried to refuse further activity,
saying that he did not believe the applicant would disclose any of the material because the applicant himself would
be at risk of prosecution. In response, the applicant threatened to harm N and members of his family, in particular
his mother and sister, "in all sorts of nasty ways". He went on to tell N that he had a choice between "complete
destruction and being a slave". He also indicated that even if N committed suicide, as N had indicated he was
thinking of doing, that would not stop the applicant from distributing the images both to N's family and online. He
went on to instruct N to make a video recording of himself performing a series of degrading and demeaning tasks,
and to entitle the video "Hello and welcome to blackmailed boy slut". When N again tried to resist, the applicant
boasted about the impossibility of tracing him and repeated his threats to distribute the recorded imagery. He said
that rather than go to the trouble of sending the material direct to N's family, he would make it available on sites on
the dark web where "blackmail victims are shared and people basically compete to see how much they can ruin the
victim's life". He said that he did not especially want to push N on until he committed suicide, he just enjoyed having
him do things.

27. The fifth category of offending was summarised by the judge as encouraging others to commit offences and
peddling material on chat websites. In summary, the applicant made postings on a number of paedophile chat
websites, in which he tried to encourage rape of a child, blackmail and the making and distribution of indecent
images of children. He posted videos and images of a sickening and distressing nature. Upon receiving a video
showing a new-born baby girl being raped, his response was to post suggestions as to further crimes which should
be committed against her. He invited comments from others about his proposal that he should tie N to a tree and
leave him for dead.

28. Finally, the sixth category of offending involved the possession and distribution of indecent imagery. A search of
his computer following his arrest revealed a total of nearly 14,000 indecent images of children, 1,251 videos, 49
prohibited images and 52 extreme pornographic images.

29. We believe this very brief summary suffices to show the gravity of the offending.

30. In his detailed and thorough sentencing remarks, the judge described the nature of the offending and the
terrible harm which the applicant had caused to his victims. He found the applicant to be a dangerous offender, as
that term is defined for sentencing purposes. He carefully considered whether the seriousness of the offending
justified a life sentence in respect of one or more of the offences which carry life imprisonment. In this regard, he
indicated that he had considered the decision of this court in Leighton [2017] EWCA (Crim) 2057. He described that
case as, "remarkably similar in some respects, though less serious in overall terms". He concluded that public
safety would sufficiently be protected by a lengthy extended determinate sentence.


-----

31. The judge considered the relevant sentencing guidelines, and indicated his view as to the categorisation of the
individual offences covered by those guidelines. He also indicated, in relation to each of the six categories of
offending, what overall sentence he would regard as appropriate for that category, before consideration of totality.
He indicated that, giving full credit for the guilty pleas, the appropriate overall sentence for the category 1 voyeurism
offences would be one year four months' imprisonment; for the blackmail and related offences in category 2, nine
years and four months' imprisonment; for the category 3 offences of encouraging rape, twelve years imprisonment;
for the forced compulsory labour and related offences in category 4, six years eight months' imprisonment; for the
offences in category 5, ten years eight months' imprisonment; for the offences in category 6, three years four
months' imprisonment. Thus the judge, after careful consideration, concluded that simple addition of the appropriate
sentences for the categories of offending which he had identified would result in a total sentence after trial of 65
years' imprisonment, reduced by full credit for the guilty pleas to a total of 43 years and four months. The judge then
reminded himself of the general principles stated at page 5 of the Sentencing Council's Definitive Guideline on
Offences Taken into Consideration and Totality:

"The principle of totality comprises of two elements:

(1) All courts, when sentencing for more than a single offence, should pass a total sentence which reflects
_all the offending behaviour before it and is just and proportionate. This is so whether the sentences are_
structured as concurrent or consecutive. Therefore, concurrent sentences will ordinarily be longer than a
single sentence for a single offence.

(2) It is usually impossible to arrive at a just and proportionate sentence for multiple offending simply by
adding together notional single sentences. It is necessary to address the offending behaviour, together with
factors personal to the offender as a whole."

32. With those principles in mind, the judge considered that the appropriate overall sentence should be reduced by
what he described as a "reasonably substantial margin" to take account of totality, of the applicant's comparatively
young age and of personal mitigation. As can be seen in the annexed table, he imposed, in relation to four of the
offences, consecutive extended sentences; he passed concurrent determinate sentences on all other offences. The
total sentence was an extended sentence, comprising a custodial term of 32 years and an extended licence period
of six years. The judge also made a sexual harm prevention order of indefinite duration.

33. The ground of appeal is that the total custodial term was manifestly excessive in all the circumstances of the
case. Mr Andrew Smith QC, on behalf of the applicant, realistically acknowledges that there can be no challenge to
the judge's categorisation of the individual offences by reference to relevant sentencing guidelines or to his
identification of the many aggravating factors. Mr Smith does not seek to challenge the finding of dangerousness.
He further accepts that a very substantial sentence was inevitable for this very grave offending. He submits,
however, that a total overall sentence after trial of 65 years was too high. Although this applicant's offences are
more numerous than those committed by the offender in the case of Leighton, Mr Smith submits that the two cases
have many serious features in common and that a difference of 30 years in the sentences after trial for the two
cases cannot be justified. He suggests that by grouping the offences into six categories as he did, when particular
types of offending can be found represented in more than one of those categories, the judge increased the starting
point too dramatically. In any event, submits Mr Smith, insufficient allowance was made for the principle of totality.

34. Mr Smith suggests that the learned judge accepted that the applicant had expressed genuine remorse.
However, whilst the judge certainly acknowledged as a point in the applicant's favour that he has expressed
remorse, including in a letter to the court, we do not see in the sentencing remarks any specific acceptance that
there was genuine remorse. The observation of the judge came in the context of the issue of dangerousness, in
relation to which an acknowledgment of responsibility (as opposed to genuine remorse) may well be significant.

35. At the direction of the Registrar, the prosecution has provided a skeleton argument; and Mr Forster QC and
Miss Iguyovwe have attended to assist us and to make oral submissions. They submit that the sentence, although
severe, was not manifestly excessive, having regard to the gravity of the offending. They submit that the judge had
careful regard to totality and, indeed, took it into account at more than one stage of the process. They argue that the


-----

judge's approach was in accordance with established principles, was carefully reasoned and involved a thorough
examination of the relevant facts.

36. In addition to Leighton, they invite the court's attention to the cases of Watkins [2015] 1 Cr App R (S) 6, and DJ

[2015] 2 Cr App R (S) 16. In Watkins, the offender pleaded guilty at a late stage to charges including two offences
of rape of a child aged under 13 years, sexual assault of that child, conspiracies to rape and to sexually assault
another child, taking, possessing and distributing indecent photographs of a child and possessing extreme
pornographic images. He was allowed credit of 10% for his late pleas. The evidence made clear that he derived
pleasure from the commission of very serious sexual offences against babies. He showed no remorse. The
aggravating features of his offences were the very young age of his victims, planning, the targeting of vulnerable
victims, the commission of offences jointly with another, abuse of trust, abuse of power, the recording of the
offences and the use of drugs in association with the offences. The judge imposed determinate sentences totalling
15 years' imprisonment, with a consecutive extended sentence, comprising fourteen years' imprisonment and a sixyear period of extended licence. Thus, the total custodial term was 29 years after guilty pleas. On appeal, the only
issue was whether the total sentence was a just and proportionate reflection of the whole of the offending. This
court concluded that offences of "such shocking depravity" demanded a very lengthy sentence. It held that the total
sentence was not even arguably manifestly excessive. The renewed application for leave to appeal against
sentence was therefore refused.

37. In DJ, the offender had committed numerous sexual offences over a period of approximately ten years. He had
regularly and repeatedly raped his daughter from the age of 5. He had had regular sexual intercourse with a
teenage girl whose mental health problems meant that she functioned at the level of a young child. He had
committed other sexual offences against other young victims. Large quantities of indecent imagery were found in
his possession. The offender pleaded guilty to many offences and was convicted of others after a trial. He was
sentenced to an extended sentence, comprising a custodial term of 33 years and an extended licence period of six
years. On appeal, this court noted that nine victims had been identified. There were multiple aggravating features,
including breaches of trust, recording of the offending, threats to the victims, deceit, grooming and controlling
vulnerable individuals. The duration and scale of the offending was particularly substantial. Although the aspects of
seriousness were not as eye catching as those in Watkins, the offences were of a comparable level of gravity for
different reasons. The individual sentences could not be criticised, but this court concluded that the judge had not
made sufficient allowance for totality. The sentence was accordingly reduced to a custodial term of 30 years, with
an extended licence of six years.

38. In _Leighton, the offender pleaded guilty to three offences of rape of a child aged under 13, assault by_
penetration, offences of causing a child to engage in sexual activity, blackmail and making and distributing indecent
photographs of a child. Full credit was given for the guilty pleas. He was sentenced to concurrent extended
sentences, comprising a custodial term of sixteen years and an extended licence period of six years. As in the
present case, the offending included blackmail by the use of the internet of victims in the United States. On an
application by Her Majesty's Attorney-General, this court increased the total sentence to an extended sentence,
comprising twenty years' custodial term and seven years' extended licence. In doing so, this court concluded that
an appropriate overall sentence after a trial of all matters would have been of the order of 35 years, before having
regard to totality, and that the least total sentence that ultimately would have been appropriate would have been 30
years' imprisonment.

39. We have reflected on the submissions in the present case. At this stage of proceedings, our focus must be on
the overall length of sentence rather than on its structure. We do, however, make an observation about the use of
consecutive extended sentences. Such sentences are not unlawful and on occasions they may be necessary and
appropriate. But they can give rise to confusion about the date of eligibility for release on licence and in our view
they should, in general, be avoided if possible. We do not criticise the learned judge for the structure of his
sentencing in this case; and if they were the only point at issue in this application, we would not interfere with the
approach which he adopted. We do, however, take the view that, in the circumstances of the present case, the use
of concurrent extended sentences of a length reflecting the overall gravity of the offending would have been
preferable. The powers of this court include the power to amend the structure of the sentence and the length of its


-----

component parts, provided that, overall, the applicant is not more severely dealt with than he was in the court
below.

40. In our judgment, the most serious aggravating features of the applicant's offending are as follows. First, the
duration of the offending, which had extended over about a decade and was continuing when the applicant was
arrested. Secondly, the deliberate targeting of many vulnerable victims, followed by the cynical exploitation of their
specific weaknesses. Thirdly, the remorseless, protracted pursuit of his selected victims, apparently for the purpose
of his own amusement, with disregard of their obvious suffering and of their begging him to leave them alone.
Fourthly, the recording and preservation of imagery, to be used not only as leverage for the offences of blackmail,
but also as a form of currency to promote his dealings with like-minded individuals on the dark web. Fifthly, his
encouragement and incitement of others to commit dreadful crimes against very young victims. Sixthly, his
conspiring with others in order to further his own offending. Seventhly, the combination of careful planning of his
crimes, with the taking of elaborate and successful steps to conceal his identity and avoid detection for many years.

41. The mitigation available to the applicant is, in our view, very limited. He clearly has a better side to his
character. He is comparatively young, with no previous convictions, facing imprisonment for the first time. He has
the benefit of his guilty pleas, for which the judge was prepared to give full credit.

42. We have already indicated that the judge acknowledged (but did not expressly accept), the applicant's
expressions of remorse. For our part, bearing in mind that the applicant is a highly intelligent man, who has enjoyed
a happy family life and many advantages, we find it impossible to accept the assertion in his letter to the court that
he has now begun to realise the extent of the harm he has caused. He must, in our view, have been fully aware
throughout of exactly what harm he was causing. The message which we have quoted, in which he refers to the
possibility of suicide by one young victim, makes that abundantly clear.

43. There is, as we have said, no challenge to the finding of dangerousness. There is nothing in the papers before
us to suggest that the applicant has suffered from a formal mental illness or disorder which is susceptible to
treatment and which need not be a matter of concern for the future. The disturbing nature of the offending and the
clear evidence that the applicant derived pleasure from inflicting suffering on others, coupled with the gravity of the
offences, brings the case close to requiring life imprisonment. However, we well understand why the judge
concluded that it was not necessary to take that course and that a long extended sentence is sufficient.

44. As to the length of the sentence, we have no doubt that the judge took care to observe the principle of totality,
as is evident from the explanations he gave in his sentencing remarks. He was alive to the need to avoid double
counting of aggravating features, in circumstances where there is a clear overlap between some of the categories
of offending which he identified.

45. However, whilst we hesitate to differ from the judge, who had considered the case with such care, we accept
the submission that he did fall into error in failing to have sufficient regard to totality. He was correct to begin by
considering what sentences would have been imposed after trial in the absence of any consideration of totality; and
there can be no criticism of his approaching that consideration by dividing the offences into categories. But the
degree of overlap between offending and features of offending within the categories, and the consequent risk of
double counting of aggravating features, can be illustrated by reference to the fifth and sixth categories which the
judge identified. Although of course distinct offending was involved, there was, in our view, much in common
between those categories and other categories of offending, yet categories 5 and 6 contributed 21 years to the total
of 65 years, which the judge reached before considering credit for pleas and reduction for totality. In our view, that
feature in itself illustrates the importance of the principle of totality in a case such as this. It is illustrative of the point
made by Mr Smith that the judge's approach, though perfectly understandable, inadvertently caused him to lose
sight of the full extent of overlap between categories of offending, and therefore to make insufficient allowance
when considering totality in this very difficult case.

46. None of the three previous cases to which we have referred is a guideline case. Each must be regarded as a
decision on its own facts. We agree with the judge that the circumstances of _Leighton, grave though they were,_
were less serious overall than the present case. There is nonetheless force in Mr Smith's submission that there are
i ifi t f t f i il it b t _L i ht_ d thi d th t th diff b t th t t l t


-----

in _Leighton and the total sentence here is a further indication that the judge failed fully to apply the important_
principle of totality.

47. We have considered carefully what total sentence would impose just and proportionate punishment for the
grave offences committed by this applicant. In our judgment, the appropriate total custodial term in this case, taking
into account the full credit for the guilty pleas and the principle of totality, is one of 25 years. We therefore conclude,
with all respect to the learned judge, that the total custodial term imposed below was manifestly excessive in length
and must be reduced accordingly. We do, however, also take the view that the extended period of licence should be
for the full term permitted by law, namely eight years.

48. The effect of our decision will be that the applicant will serve at least two-thirds of the custodial term of 25 years.
He will then be eligible for consideration for release on licence, but there is no guarantee that he will be released at
that stage. Depending on the view taken by the Parole Board as to whether he remains dangerous, he may remain
in custody for the full term of 25 years. When he is released, he will be on licence for any remaining part of the
custodial term and for a further eight years thereafter.

49. We therefore grant leave to appeal. We allow the appeal to the following extent: we quash the consecutive
extended sentences imposed on count 89 of indictment 1, count 8 of indictment 3, and count 23 of indictment 4,
and we substitute on each of those counts concurrently an extended sentence of 33 years, comprising a custodial
term of 25 years and an extension period of eight years. We order that the sentence on count 15 of indictment 1,
namely an extended sentence of nine years six months, comprising a custodial term of eight years and an
extension period of eighteen months, should run concurrently with the other extended sentences. In all other
respects the sentencing remains as it was in the court below.

50. Mr Smith, Mr Forster, thank you both for your submissions in this difficult case.

**Annex**

M A FALDER

The individual offences were sentenced as follows:

Count Offence Sentence Maximum
(years)

**Substantiv**
**e**
**consecutiv**
**e**
**sentences**
Indictment 1 Inciting sexual exploitation 8 years custodial term plus 14

Count 15 18 months extended licence

_[s.48(1) Sexual Offences Act 2003.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

Indictment 1 Intentionally encouraging an offence of rape 10 years custodial term plus Life

Count 89 18 months extended licence

_[s.44(1) and 58 Serious Crime Act 2007](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_

Indictment 3 Forced or Compulsory Labour 6 years custodial term Life

Count 8 plus 18 months extended licence

_[s.1(1)(b) of the Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C212-00000-00&context=1519360)_

Indictment 4 Intentionally encouraging a rape of a child 8 years custodial term Life

|Count|Offence|Sentence|Maximum (years)|
|---|---|---|---|

|Substantiv e consecutiv e sentences|Inciting sexual exploitation 8 years custodial term plus 14 18 months extended licence s.48(1) Sexual Offences Act 2003.|Col3|Col4|
|---|---|---|---|
|Indictment 1 Count 15||||
|Indictment 1 Count 89|Intentionally encouraging an offence of rape s.44(1) and 58 Serious Crime Act 2007|10 years custodial term plus 18 months extended licence|Life|
|Indictment 3 Count 8|Forced or Compulsory Labour s.1(1)(b) of the Modern Slavery Act 2015|6 years custodial term plus 18 months extended licence|Life|


-----

|Count 23|s.44(1) and 58 Serious Crime Act 2007|plus 18 months extended licence|Col4|
|---|---|---|---|


2 C
a
u
s
i


8
years
impris
onme
nt


14


-----

n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||n c e s A c t 2 0 0 3|||
|4||B l a c k m a i l s|5 years impris onme nt|14|
|||. 2|||
|||1|||
|||( 1|||
|||) T h e f t A c t 1 9 6 8|||


7 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g


40
month
s
impris
onme
nt


14


-----

a

c
h
i
l
d

t
o

e
n
g
a
g
e

i
n

s
e
x
u
a
l

a
c
t
i
v
i
t
y

i
n
v
o
l
v
i
n
g

p
e
n
e
t
r
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y005-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y005-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y005-00000-00&context=1519360)_


-----

|Col1|0 ( 1 ) & ( 2 ) S e x u a l O f f e n c e s A c t 2 0 0 3 .|Col3|Col4|
|---|---|---|---|


8 C
o
n
s
p
i
r
a
c
y

t
o

b
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_


40
month
s
impris
onme
nt


14


-----

|Col1|1 ( 1 ) C r i m i n a l L a w A c t 1 9 7 7|Col3|Col4|
|---|---|---|---|


9 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

F
r
a
u
d

A
c


3
years
impris
onme
nt


10


-----

|Col1|t 2 0 0 6|Col3|Col4|
|---|---|---|---|


11 M
a
k
i
n
g

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o


2
years
impris
onme
nt


10


-----

|Col1|n o f C h i l d r e n A c t 1 9 7 8|Col3|Col4|Col5|
|---|---|---|---|---|
|12|C a u s i n g / I n c i t i n g a c h i l d t o e n g a g e i n s e|2 years impris onme nt|14||


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||x u a l a c t i v i t y s|||
|||. 1|||
|||0|||
|||( 1|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


13 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g


40
month
s
impris
onme
nt


14


-----

a

c
h
i
l
d

t
o

e
n
g
a
g
e

i
n

s
e
x
u
a
l

a
c
t
i
v
i
t
y

i
n
v
o
l
v
i
n
g

p
e
n
e
t
r
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y005-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y005-00000-00&context=1519360)_


-----

|Col1|1 0 ( 1 ) & ( 2 ) S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


14 B
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_

T
h
e
f
t

A
c


5
years
impris
onme
nt


14


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||t 1 9 6 8|||
|16||F r a u d b y r e p r e s e n t a t i o n s|3 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


17 C
a
u
s
i
n
g
/
I
n
c
i
t
i


40
month
s
impris
onme
nt


14


-----

n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e
n
c
e
s

A
c
t


-----

|Col1|2 0 0 3|Col3|Col4|
|---|---|---|---|


18 M
a
k
i
n
g

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n


1 year
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||o f C h i l d r e n A c t 1 9 7 8|||
|19||B l a c k m a i l s|5 years impris onme nt|14|
|||. 2|||
|||1|||
|||( 1|||
|||) T h e f t A c t 1 9 6 8|||


20 F
r
a
u
d

b
y

r


3
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||e p r e s e n t a t i o n s|||
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


21 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i


40
month
s
impris
onme
nt


14


-----

|Col1|t a t i o n o f a c h i l d s . 4 8 ( 1 ) S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


22 B
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_


5
years
impris
onme
nt


14


-----

|Col1|2 1 ( 1 ) T h e f t A c t 1 9 6 8|Col3|Col4|
|---|---|---|---|


23 M
a
k
i
n
g

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_


1 year
impris
onme
nt


10


-----

|Col1|) ( a ) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|Col3|Col4|
|---|---|---|---|


25 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_


3
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||1|||
|||F r a u d A c t 2 0 0 6|||
|26||C a u s i n g / I n c i t i n g s e x u a l e x p l o i t a t i o n o f a c h i l|40 month s impris onme nt|14|


-----

|Col1|d s . 4 8 ( 1 ) S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


28 B
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_

T
h
e
f
t

A
c
t


5
years
impris
onme
nt


14


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||1 9 6 8|||
|30|F r a u d b y r e p r e s e n t a t i o n s . 1 F r a u d A c t 2 0 0 6|2 years impris onme nt|10|
|31|B l a c k m a i l s . 2 1 (|40 month s impris onme nt|14|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||1|||
|||) T h e f t A c t 1 9 6 8|||
|32||F r a u d b y r e p r e s e n t a t i o n s|2 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


33 C
a
u


40
month
s


14


-----

s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f


impris
onme
nt


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||f e n c e s A c t 2 0 0 3|||
|35||B l a c k m a i l s|5 years impris onme nt|14|
|||. 2|||
|||1|||
|||( 1|||
|||) T h e f t A c t 1 9 6 8|||


36 D
i
s
t
r
i
b
u
t
i
o
n

o
f


1 year
impris
onme
nt


10


-----

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o
f

C
h
i
l
d
r
e
n

A


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||c t 1 9 7 8|||
|37||F r a u d b y r e p r e s e n t a t i o n s|2 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


38 C
a
u
s
i
n
g
/
I
n
c
i
t


4
years
impris
onme
nt


14


-----

i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e
n
c
e
s

A
c
t


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||2 0 0 3|||
|39||F r a u d b y r e p r e s e n t a t i o n s|2 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


40 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n


30
month
s
impris
onme
nt


14


-----

g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e
n
c
e
s

A
c
t

2


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||0 0 3|||
|41||F r a u d b y r e p r e s e n t a t i o n s|2 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


42 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g


30
month
impris
onme
nt


14


-----

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e
n
c
e
s

A
c
t

2
0
0


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||3|||
|43||F r a u d b y r e p r e s e n t a t i o n s|2 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


44 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e


30
month
impris
onme
nt


14


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||x u a l e x p l o i t a t i o n o f a c h i l d s|||
|||. 4|||
|||8|||
|||( 1|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


45 F 2 10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||r a u d b y r e p r e s e n t a t i o n s|years impris onme nt||
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


46 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u


30
month
impris
onme
nt


14


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||a l e x p l o i t a t i o n o f a c h i l d s|||
|||. 4|||
|||8|||
|||( 1|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


47 F
r
a


2
years
impris


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||u d b y r e p r e s e n t a t i o n s|onme nt||
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


48 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l


4
years
impris
onme
nt


14


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||e x p l o i t a t i o n o f a c h i l d s|||
|||. 4|||
|||8|||
|||( 1|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


50 F
r
a
u
d


2
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||b y r e p r e s e n t a t i o n s|||
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


51 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e


4
years
impris
onme
nt


14


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||x p l o i t a t i o n o f a c h i l d s|||
|||. 4|||
|||8|||
|||( 1|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


52 F
r
a
u
d

b


2
years
impris
onme
nt


10


-----

|Col1|y r e p r e s e n t a t i o n s . 1 F r a u d A c t 2 0 0 6|Col3|Col4|Col5|
|---|---|---|---|---|


53 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_


2
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||F r a u d A c t 2 0 0 6|||
|54|C a u s i n g / I n c i t i n g s e x u a l e x p l o i t a t i o n o f a c h i l d|30 month impris onme nt|14|


-----

|Col1|s . 4 8 ( 1 ) S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


55 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

F


2
years
impris
onme
nt


10


-----

|Col1|r a u d A c t 2 0 0 6|Col3|Col4|
|---|---|---|---|


56 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_


4
years
impris
onme
nt


14


-----

|Col1|. 4 8 ( 1 ) S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


57 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

F
r
a


3
years
impris
onme
nt


10


-----

|Col1|u d A c t 2 0 0 6|Col3|Col4|
|---|---|---|---|


59 M
a
k
i
n
g

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t


1 year
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||e c t i o n o f C h i l d r e n A c t 1 9 7 8|||
|60||B l a c k m a i l s|5 years impris onme nt|14|
|||. 2|||
|||1|||
|||( 1|||
|||) T h e f t A c t 1 9 6 8|||


61 C
a
u


40
month
s


14


-----

s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l

O
f


impris
onme
nt


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||f e n c e s A c t 2 0 0 3|||
|63||F r a u d b y r e p r e s e n t a t i o n s|2 years impris onme nt|10|
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


64 B
l
a
c
k


40
month
s
impris
onme


14


-----

|Col1|m a i l s . 2 1 ( 1 ) T h e f t A c t 1 9 6 8|nt|Col4|
|---|---|---|---|


65 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

F
r
a
u
d

A


2
years
impris
onme
nt


10


-----

|Col1|c t 2 0 0 6|Col3|Col4|
|---|---|---|---|


66 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_


30
month
impris
onme
nt


14


-----

|Col1|S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


68 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

F
r
a
u
d

A
c
t


3
years
impris
onme
nt


10


-----

|Col1|2 0 0 6|Col3|Col4|
|---|---|---|---|


69 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S


30
month
impris
onme
nt


14


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||e x u a l O f f e n c e s A c t 2 0 0 3|||
|70|D i s t r i b u t i o n o f i n d e c e n t i m a g e s o f a c h|16 month s impris onme nt|10|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||i l d s|||
|||. 1|||
|||( 1|||
|||) ( b|||
|||) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|||


72 D
i
s
t
r
i
b
u
t
i
o
n

o
f

i


16
month
s
impris
onme
nt


10


-----

n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o
f

C
h
i
l
d
r
e
n

A
c
t


-----

|Col1|1 9 7 8|Col3|Col4|
|---|---|---|---|


73 D
i
s
t
r
i
b
u
t
i
o
n

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t


2
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||e c t i o n o f C h i l d r e n A c t 1 9 7 8|||
|74|D i s t r i b u t i o n o f i n d e c e n t i m a g e s o f|2 years impris onme nt|10|


-----

|Col1|Col2|a c h i l d s|Col4|Col5|Col6|
|---|---|---|---|---|---|
|||. 1||||
|||( 1||||
|||) ( b||||
|||) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8||||


75 F
r
a
u
d

b
y

r
e
p
r


2
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||e s e n t a t i o n s|||
|||. 1|||
|||F r a u d A c t 2 0 0 6|||


76 S
e
n
d
i
n
g

e
l
e
c
t
r
o
n
i
c

c
o
m
m
u
n
i
c
a
t
i
o
n


6
month
s
impris
onme
nt


2


-----

w
i
t
h

i
n
t
e
n
t

t
o

c
a
u
s
e

d
i
s
t
r
e
s
s

o
r

a
n
x
i
e
t
y

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i
o
u
s

C


-----

|Col1|o m m u n i c a t i o n s A c t 1 9 8 8|Col3|Col4|
|---|---|---|---|


77 C
o
n
s
p
i
r
a
c
y

t
o

b
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_

C
r
i
m
i
n
a
l


32
month
s
impris
onme
nt


14


-----

|Col1|L a w A c t 1 9 7 7|Col3|Col4|
|---|---|---|---|


78 C
o
n
s
p
i
r
a
c
y

t
o

b
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_

C
r
i
m
i
n
a
l

L
a
w

A
c
t

1
9


32
month
s
impris
onme
nt


14


-----

|Col1|7 7|Col3|Col4|
|---|---|---|---|


79 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u


2
years
impris
onme
nt


14


-----

|Col1|a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


81 F
r
a
u
d

b
y

r
e
p
r
e
s
e
n
t
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

F
r
a
u
d

A
c
t

2
0
0
6


2
years
impris
onme
nt


10


-----

82 C
a
u
s
i
n
g
/
I
n
c
i
t
i
n
g

s
e
x
u
a
l

e
x
p
l
o
i
t
a
t
i
o
n

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y072-00000-00&context=1519360)_

S
e
x
u
a
l


40
month
impris
onme
nt


14


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||O f f e n c e s A c t 2 0 0 3|||
|86|C o n s p i r a c y t o t a k e / m a k e i n d e c e n t i m a g e s o f a|4 years impris onme nt|10|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||c h i l d s|||
|||. 1|||
|||( 1|||
|||) C r i m i n a l L a w A c t 1 9 7 7|||


87 C
o
n
s
p
i
r
a
c
y

t
o

d
i
s
t
r
i
b
u
t
e

i
n


2
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||d e c e n t i m a g e s o f a c h i l d s|||
|||. 1|||
|||( 1|||
|||) o f t h e C r i m i n a l L a w A c t 1 9 7 7|||


93 C
o


4
years


10


-----

n
s
p
i
r
a
c
y

t
o

t
a
k
e
/
m
a
k
e

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_

C
r
i
m
i
n


impris
onme
nt


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||a l L a w A c t 1 9 7 7|||
|94|C o n s p i r a c y t o d i s t r i b u t e i n d e c e n t i m a g e s o f a c|2 years impris onme nt|10|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||h i l d s|||
|||. 1|||
|||( 1|||
|||) C r i m i n a l L a w A c t 1 9 7 7|||


96 I
n
t
e
n
t
i
o
n
a
l
l
y

e
n
c
o
u
r
a
g
i
n
g

a
n


10
years
impris
onme
nt


Life


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||o f f e n c e o f r a p e s|||
|||. 4|||
|||4|||
|||( 1|||
|||) a n d 5|||
|||8|||
|||S e r i o u s C r i m e A c t 2 0 0 7|||


99 I
n
t
e
n
t
i
o
n


4
years
impris
onme
nt


14


-----

a
l
l
y

e
n
c
o
u
r
a
g
i
n
g

a
n

o
f
f
e
n
c
e

o
f

s
e
x
u
a
l

a
c
t
i
v
i
t
y

w
i
t
h

a

c
h
i
l
d

f
a


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||m i l y m e m b e r s|||
|||. 4|||
|||4|||
|||( 1|||
|||) a n d 5|||
|||8|||
|||S e r i o u s C r i m e A c t 2 0 0 7|||


100 C
o
n
s
p
i
r
a
c
y

t
o


6
month
s
impris
onme
nt


2


-----

s
e
n
d

a
n

e
l
e
c
t
r
o
n
i
c

c
o
m
m
u
n
i
c
a
t
i
o
n

w
i
t
h

i
n
t
e
n
t

t
o

c
a
u
s
e

d
i
s
t
r
e
s


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||s o r a n x i e t y s|||
|||. 1|||
|||( 1|||
|||) C r i m i n a l L a w A c t 1 9 7 7|||


101 C
o
n
s
p
i
r
a
c
y

t
o

s
e
n
d

a
n


6
month
s
impris
onme
nt


2


-----

e
l
e
c
t
r
o
n
i
c

c
o
m
m
u
n
i
c
a
t
i
o
n

w
i
t
h

i
n
t
e
n
t

t
o

c
a
u
s
e

d
i
s
t
r
e
s
s

o
r

a
n
x


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||i e t y s|||
|||. 1|||
|||( 1|||
|||) C r i m i n a l L a w A c t 1 9 7 7|||


102 C
o
n
s
p
i
r
a
c
y

t
o

s
e
n
d

a
n

e
l
e
c
t
r
o


6
month
s
impris
onme
nt


2


-----

n
i
c

c
o
m
m
u
n
i
c
a
t
i
o
n

w
i
t
h

i
n
t
e
n
t

t
o

c
a
u
s
e

d
i
s
t
r
e
s
s

o
r

a
n
x
i
e
t
y

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_


-----

**_Indictment_**
**_2_**
1 P 40 10
o month
s s
s impris
e onme
s nt
s
i
o
n

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

w
i
t
h

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||( 1 ) C r i m i n a l L a w A c t 1 9 7 7|||
|Indictment 2||||


-----

a

v
i
e
w

t
o

t
h
e
i
r

d
i
s
t
r
i
b
u
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[c](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o
f

C
h
i
l
d
r
e
n


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||A c t 1 9 7 8|||
|2|P o s s e s s i o n o f i n d e c e n t i m a g e s w i t h a v i e w t o t h e i r d i|40 month s impris onme nt|10|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||s t r i b u t i o n s|||
|||. 1|||
|||( 1|||
|||) ( c|||
|||) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|||


3 P
o
s
s
e
s
s
i
o
n


1 year
impris
onme
nt


3


-----

o
f

p
r
o
h
i
b
i
t
e
d

i
m
a
g
e
s

o
f

c
h
i
l
d
r
e
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95G0-Y97X-705D-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95G0-Y97X-705D-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95G0-Y97X-705D-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95G0-Y97X-705D-00000-00&context=1519360)_

C
o
r
o
n
e
r
s

a
n
d

J
u
s
t
i
c
e

A
c


-----

|Col1|t 2 0 0 9|Col3|Col4|
|---|---|---|---|


5 P
o
s
s
e
s
s
i
o
n

o
f

e
x
t
r
e
m
e

p
o
r
n
o
g
r
a
p
h
y

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y03M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y03M-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y03M-00000-00&context=1519360)_
_[3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y03M-00000-00&context=1519360)_

C
r
i
m
i
n
a
l

J
u
s
t
i
c
e


6
month
s
impris
onme
nt


3


-----

|Col1|a n d I m m i g r a t i o n A c t 2 0 0 8|Col3|Col4|
|---|---|---|---|


6 P
o
s
s
e
s
s
i
o
n

o
f

a

p
a
e
d
o
p
h
i
l
e

m
a
n
u
a
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_
_[9](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_


1 year
impris
onme
nt


3


-----

|Col1|S e r i o u s C r i m e A c t 2 0 1 5|Col3|Col4|
|---|---|---|---|


7 V
o
y
e
u
r
i
s
m

–

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_


16
month
s
impris
onme
nt


2


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||7|||
|||( 3|||
|||) a|||
|||n|||
|||d|||
|||( 5|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||
|8||V o y e u r i s m – r e c o r d i n g a p|16 month s impris onme nt|2|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||r i v a t e a c t s|||
|||. 6|||
|||7|||
|||( 3|||
|||) a|||
|||n|||
|||d|||
|||( 5|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


11 V
o
y
e
u
r
i
s
m

–


16
month
s
impris
onme
nt


2


-----

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[7](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[n](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[d](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e
n
c
e
s

A
c
t

2


-----

|Col1|0 0 3|Col3|Col4|
|---|---|---|---|


13 V
o
y
e
u
r
i
s
m

–

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[7](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[n](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[d](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

S
e
x
u
a
l


16
month
s
impris
onme
nt


2


-----

|Col1|O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


14 V
o
y
e
u
r
i
s
m

–

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[7](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_


16
month
s
impris
onme
nt


2


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||n|||
|||d|||
|||( 5|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||
|16||V o y e u r i s m – r e c o r d i n g a p r i v a t e|16 month s impris onme nt|2|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||a c t s|||
|||. 6|||
|||7|||
|||( 3|||
|||) a|||
|||n|||
|||d|||
|||( 5|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


17 V
o
y
e
u
r
i
s
m

–

r
e
c
o
r


16
month
s
impris
onme
nt


2


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||d i n g a p r i v a t e a c t s|||
|||. 6|||
|||7|||
|||( 3|||
|||) a|||
|||n|||
|||d|||
|||( 5|||
|||) S e x u a l O f f e n c e s A c t 2 0 0 3|||


21 V
o
y


16
month
s


2


-----

e
u
r
i
s
m

–

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[7](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[n](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[d](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

S
e
x
u
a
l

O
f
f
e
n
c


impris
onme
nt


-----

|Col1|e s A c t 2 0 0 3|Col3|Col4|Col5|
|---|---|---|---|---|


22 V
o
y
e
u
r
i
s
m

–

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[7](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[n](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[d](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_

_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_


16
month
s
impris
onme
nt


2


-----

|Col1|S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


24 V
o
y
e
u
r
i
s
m

–

r
e
c
o
r
d
i
n
g

a

p
r
i
v
a
t
e

a
c
t

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y11N-00000-00&context=1519360)_


16
month
s
impris
onme
nt


2


-----

**_Indictment_**
**_3_**
1 P 1 year 10
u impris
b onme
l nt
i
s
h
i
n
g

a
n

a
d
v
e
r
t

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||. 6 7 ( 3 ) a n d ( 5 ) S e x u a l O f f e n c e s A c t 2 0 0 3|||
|Indictment 3||||


-----

i
s
e
m
e
n
t

a
b
o
u
t

d
i
s
t
r
i
b
u
t
i
o
n

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[d](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

o
f

t
h
e


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|||
|2|D i s t r i b u t i n g i n d e c e n t i m a g e s o|1 year impris onme nt|10|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||f a c h i l d s|||
|||. 1|||
|||( 1|||
|||) ( b|||
|||) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|||


3 D
i
s
t
r
i
b
u
t
i
n


1 year
impris
onme
nt


10


-----

g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o
f

C
h
i
l
d
r
e
n


-----

|Col1|A c t 1 9 7 8|Col3|Col4|
|---|---|---|---|


4 M
a
k
i
n
g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n


1 year
impris
onme
nt


10


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||o f C h i l d r e n A c t 1 9 7 8|||
|5|E n c o u r a g i n g / a s s i s t i n g t h e c o m m i s s i o n o f o|1 year impris onme nt|10|


-----

f
f
e
n
c
e
s

o
f

t
a
k
i
n
g
,

m
a
k
i
n
g

o
r

d
i
s
t
r
i
b
u
t
i
n
g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_


-----

|Col1|( 1 ) a n d 5 8 S e r i o u s C r i m e A c t 2 0 0 7|Col3|Col4|
|---|---|---|---|


6 B
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_

T
h
e
f
t

A
c
t

1


5
years
impris
onme
nt


14


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||9 6 8|||
|9|S e n d i n g e l e c t r o n i c c o m m u n i c a t i o n w i t h i n t e n t t o c a u s e d i s t r|1 year impris onme nt|2|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||e s s o r a n x i e t y s|||
|||. 1|||
|||( 1|||
|||) ( a|||
|||) M a l i c i o u s C o m m u n i c a t i o n s A c t 1 9 8 8|||


10 B
l
a
c


5
years
impris
onme


14


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||k m a i l s|nt||
|||. 2|||
|||1|||
|||( 1|||
|||) T h e f t A c t 1 9 6 8|||


11 S
e
n
d
i
n
g

e
l
e
c
t
r
o
n
i
c

c
o
m
m
u
n
i
c
a
t
i
o
n

w


6
month
s
impris
onme
nt


2


-----

i
t
h

i
n
t
e
n
t

t
o

c
a
u
s
e

d
i
s
t
r
e
s
s

o
r

a
n
x
i
e
t
y

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i
o
u
s

C
o


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||m m u n i c a t i o n s A c t 1 9 8 8|||
|14|E n c o u r a g i n g / a s s i s t i n g t h e c o m m i s s i o n o f o|1 year impris onme nt|10|


-----

f
f
e
n
c
e
s

o
f

t
a
k
i
n
g
,

m
a
k
i
n
g

o
r

d
i
s
t
r
i
b
u
t
i
n
g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_


-----

|Col1|( 1 ) a n d 5 8 S e r i o u s C r i m e A c t 2 0 0 7|Col3|Col4|
|---|---|---|---|


16 B
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1GV-00000-00&context=1519360)_

T
h
e
f
t

A
c
t

1


5
years
impris
onme
nt


14


-----

|Col1|9 6 8|Col3|Col4|Col5|
|---|---|---|---|---|
|17|E n c o u r a g i n g / a s s i s t i n g t h e c o m m i s s i o n o f o f f e n c e s o f t a k i n g ,|1 year impris onme nt|10||


-----

m
a
k
i
n
g

o
r

d
i
s
t
r
i
b
u
t
i
n
g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_

a
n
d

_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_

S
e
r
i
o
u
s


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||C r i m e A c t 2 0 0 7|||
|18|S e n d i n g e l e c t r o n i c c o m m u n i c a t i o n w i t h i n t e n t t o|6 month s impris onme nt|2|


-----

c
a
u
s
e

d
i
s
t
r
e
s
s

o
r

a
n
x
i
e
t
y

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i
o
u
s

C
o
m
m
u
n
i
c
a
t
i
o
n
s


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||A c t 1 9 8 8|||
|20|A r r a n g i n g / f a c i l i t a t i n g s e x u a l e x p l o i t a t i o n o f a c h i l d|4 years impris onme nt|14|


-----

|Col1|s . 5 0 ( 1 ) S e x u a l O f f e n c e s A c t 2 0 0 3|Col3|Col4|
|---|---|---|---|


21 C
o
n
s
p
i
r
a
c
y

t
o

b
l
a
c
k
m
a
i
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)_


44
month
s
impris
onme
nt


14


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||) C r i m i n a l L a w A c t 1 9 7 7|||
|23|S e n d i n g e l e c t r o n i c c o m m u n i c a t i o n w i t h i|6 month s impris onme nt|2|


-----

n
t
e
n
t

t
o

c
a
u
s
e

d
i
s
t
r
e
s
s

o
r

a
n
x
i
e
t
y

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i
o
u
s

C
o
m
m
u
n
i


-----

**_Indictment_**
**_4_**
1 E 32 14
n month
c s
o impris
u onme
r nt
a
g
i
n
g
/
a
s
s
i
s
t
i
n
g

a
n

o
f
f
e
n
c
e

o
f

b
l
a
c
k
m
a

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||c a t i o n s A c t 1 9 8 8|||
|Indictment 4||||


-----

i
l
,

b
e
l
i
e
v
i
n
g

i
t

w
i
l
l

b
e

c
o
m
m
i
t
t
e
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_

a
n
d

_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_

S
e
r
i
o
u
s

C
r
i
m


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||e A c t 2 0 0 7|||
|2|E n c o u r a g i n g / a s s i s t i n g t h e c o m m i s s i o n o f o f f e n c e s o f|2 years impris onme nt|10|


-----

t
a
k
i
n
g
,

m
a
k
i
n
g

o
r

d
i
s
t
r
i
b
u
t
i
n
g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_

a
n
d

_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||S e r i o u s C r i m e A c t 2 0 0 7|||
|3|E n c o u r a g i n g / a s s i s t i n g a n o f f e n c e o f b l a c|40 month s impris onme nt|14|


-----

k
m
a
i
l
,

b
e
l
i
e
v
i
n
g

i
t

w
i
l
l

b
e

c
o
m
m
i
t
t
e
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1GM-00000-00&context=1519360)_

a
n
d

_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_

S
e
r
i
o
u
s

C


-----

|Col1|r i m e A c t 2 0 0 7|Col3|Col4|
|---|---|---|---|


4 D
i
s
t
r
i
b
u
t
i
o
n

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_


1
years
impris
onme
nt


10


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||( b|||
|||) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|||
|5||E n c o u r a g i n g / a s s i s t i n g t h e c|32 month s impris onme nt|10|


-----

o
m
m
i
s
s
i
o
n

o
f

o
f
f
e
n
c
e
s

o
f

t
a
k
i
n
g
,

m
a
k
i
n
g

o
r

d
i
s
t
r
i
b
u
t
i
n
g

i
n
d
e
c
e


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||n t i m a g e s s|||
|||. 4|||
|||6|||
|||( 1|||
|||) a n d 5|||
|||8|||
|||S e r i o u s C r i m e A c t 2 0 0 7|||


6 D
i
s
t
r
i
b
u
t
i
o
n

o
f


1 year
impris
onme
nt


10


-----

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o
f

C
h
i
l
d
r
e
n

A


-----

|Col1|c t 1 9 7 8|Col3|Col4|
|---|---|---|---|


7 D
i
s
t
r
i
b
u
t
i
o
n

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r


2
years
impris
onme
nt


10


-----

|Col1|o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|Col3|Col4|
|---|---|---|---|


8 P
u
b
l
i
s
h
i
n
g

a
n

o
b
s
c
e
n
e

a
r
t
i
c
l
e

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_


6
month
s
impris
onme
nt


5


-----

|Col1|( 1 ) O b s c e n e P u b l i c a t i o n s A c t 1 9 5 9 a s a m e n d e d b y t h e O b s c e n e P u|Col3|Col4|
|---|---|---|---|


-----

|Col1|b l i c a t i o n s A c t 1 9 6 4|Col3|Col4|
|---|---|---|---|


10 P
u
b
l
i
s
h
i
n
g

a
n

o
b
s
c
e
n
e

a
r
t
i
c
l
e

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_

O
b
s
c
e
n


6
month
s
impris
onme
nt


5


-----

|Col1|e P u b l i c a t i o n s A c t 1 9 5 9 a s a m e n d e d b y t h e O b s c e n e P u b l i c a t i o n s|Col3|Col4|
|---|---|---|---|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||A|||
|||c|||
|||t 1|||
|||9|||
|||6|||
|||4|||
|12||P a r t i c i p a t i n g i n t h e a c t i v i t i e s o f a n o r g a n i s e d c r i m e|1 year impris onme nt|5|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||g r o u p s|||
|||. 4|||
|||5|||
|||S e r i o u s C r i m e A c t 2 0 1 5|||


13 P
a
r
t
i
c
i
p
a
t
i
n
g

i
n

t
h
e

a
c
t
i
v
i
t


1 year
impris
onme
nt


5


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||i e s o f a n o r g a n i s e d c r i m e g r o u p s|||
|||. 4|||
|||5|||
|||S e r i o u s C r i m e A c t 2 0 1 5|||


14 D
i
s


2
years
impris


10


-----

t
r
i
b
u
t
i
o
n

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

a

c
h
i
l
d

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[b](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o


onme
nt


-----

|Col1|f C h i l d r e n A c t 1 9 7 8|Col3|Col4|
|---|---|---|---|


15 P
o
s
s
e
s
s
i
o
n

o
f

a

p
a
e
d
o
p
h
i
l
e

m
a
n
u
a
l

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_
_[9](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3H7-00000-00&context=1519360)_

S
e
r
i


1 year
impris
onme
nt


3


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||o u s C r i m e A c t 2 0 1 5|||
|16|I n t e n t i o n a l l y e n c o u r a g i n g / a s s i s t i n g a n o f f e n|32 month s impris onme nt|14|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||c e o f b l a c k m a i l s . 4 4 ( 1 ) & 5 8 S|||
|||e|||
|||r i o|||
|||u|||
|||s|||
|||C|||
|||r i m|||
|||e|||
|||A|||
|||c|||
|||t 2|||
|||0|||
|||0|||
|||7|||


17 E
n
c
o
u
r
a
g
i
n


2
years
impris
onme
nt


10


-----

g
/
a
s
s
i
s
t
i
n
g

t
h
e

c
o
m
m
i
s
s
i
o
n

o
f

o
f
f
e
n
c
e
s

o
f

t
a
k
i
n
g
,

m
a
k
i
n
g

o
r

d
i


-----

s
t
r
i
b
u
t
i
n
g

i
n
d
e
c
e
n
t

i
m
a
g
e
s

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y1BS-00000-00&context=1519360)_

a
n
d

_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_

S
e
r
i
o
u
s

C
r
i
m
e

A
c
t

2
0


-----

|Col1|0 7|Col3|Col4|
|---|---|---|---|


18


14


I
n
t
e
n
t
i
o
n
a
l
l
y

e
n
c
o
u
r
a
g
i
n
g
/
a
s
s
i
s
t
i
n
g

a
n

o
f
f
e
n
c
e

o
f

c
h
i
l
d

s
e
x


40
month
s
impris
onme
nt


-----

e
x
p
l
o
i
t
a
t
i
o
n

u
n
d
e
r

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1KB-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1KB-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1KB-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1KB-00000-00&context=1519360)_

S
O
A

2
0
0
3

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y106-00000-00&context=1519360)_

a
n
d

_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_
_[8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KX-00000-00&context=1519360)_

S
e
r
i
o
u
s

C
r
i
m
e


-----

|Col1|A c t 2 0 0 7|Col3|Col4|
|---|---|---|---|


21 M
a
k
i
n
g

o
f

i
n
d
e
c
e
n
t

i
m
a
g
e
s

o
f

c
h
i
l
d
r
e
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e


1 year
impris
onme
nt


10


-----

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||c t i o n o f C h i l d r e n A c t 1 9 7 8|||
|22|D i s t r i b u t i o n o f i n d e c e n t i m a g e s o f a|32 month s impris onme nt|10|


-----

|Col1|Col2|Col3|Col4|R v F|
|---|---|---|---|---|
|||c h i l d s|||
|||. 1|||
|||( 1|||
|||) ( b|||
|||) P r o t e c t i o n o f C h i l d r e n A c t 1 9 7 8|||


24 M
a
k
i
n
g

o
f

i
n
d
e


1 year
impris
onme
nt


10


-----

c
e
n
t

i
m
a
g
e
s

o
f

c
h
i
l
d
r
e
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0P9-00000-00&context=1519360)_

P
r
o
t
e
c
t
i
o
n

o
f

C
h
i
l
d
r
e
n

A
c
t

1


-----

|Col1|9 7 8|Col3|Col4|
|---|---|---|---|


25 P
u
b
l
i
s
h
i
n
g

a
n

o
b
s
c
e
n
e

a
r
t
i
c
l
e

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[2](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y14C-00000-00&context=1519360)_

O
b
s
c
e
n
e

P
u
b
l
i
c
a
t
i
o
n
s

A


6
month
s
impris
onme
nt


5


-----

|Col1|Col2|c t 1 9 5 9 a s a m e n d e d b y t h e O|Col4|Col5|Col6|
|---|---|---|---|---|---|
|||b||||
|||s||||
|||c||||
|||e||||
|||n||||
|||e||||
|||P||||
|||u||||
|||b||||
|||l i c||||
|||a||||
|||t i o||||
|||n||||
|||s||||
|||A||||
|||c||||
|||t 1||||
|||9||||
|||6||||
|||4||||
|27||P a r t i c i|1 year impris onme nt|5||


-----

p
a
t
i
n
g

i
n

t
h
e

a
c
t
i
v
i
t
i
e
s

o
f

a
n

o
r
g
a
n
i
s
e
d

c
r
i
m
e

g
r
o
u
p

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C2PF-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C2PF-00000-00&context=1519360)_
_[4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C2PF-00000-00&context=1519360)_
_[5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C2PF-00000-00&context=1519360)_

S
e
r
i


-----

**_s.41_**
**_Offences_**
1 M 1 6 months
a month
l impris
i onme
c nt
i
o
u
s

c
o
m
m
u
n
i
c
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i
o
u
s

|Col1|Col2|Col3|R v F|
|---|---|---|---|
||o u s C r i m e A c t 2 0 1 5|||
|s.41 Offences||||


-----

|Col1|C o m m u n i c a t i o n s A c t 1 9 8 8|Col3|Col4|
|---|---|---|---|


2 M
a
l
i
c
i
o
u
s

c
o
m
m
u
n
i
c
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i
o
u


1
month
impris
onme
nt


6 months


-----

|Col1|s C o m m u n i c a t i o n s A c t 1 9 8 8|Col3|Col4|
|---|---|---|---|


3 M
a
l
i
c
i
o
u
s

c
o
m
m
u
n
i
c
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i
c
i


1
month
impris
onme
nt


6 months


-----

|Col1|o u s C o m m u n i c a t i o n s A c t 1 9 8 8|Col3|Col4|
|---|---|---|---|


4 M
a
l
i
c
i
o
u
s

c
o
m
m
u
n
i
c
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a
l
i


1
month
impris
onme
nt


6 months


-----

|Col1|c i o u s C o m m u n i c a t i o n s A c t 1 9 8 8|Col3|Col4|
|---|---|---|---|


5 M
a
l
i
c
i
o
u
s

c
o
m
m
u
n
i
c
a
t
i
o
n

_[s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[(](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_
_[)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y19R-00000-00&context=1519360)_

M
a


1
month
impris
onme
nt


6 months


-----

|Col1|l i c i o u s C o m m u n i c a t i o n s A c t 1 9 8 8|Col3|Col4|
|---|---|---|---|


**Total** **E**
**Sentence:** **x**

**t**
**e**
**n**
**d**
**e**
**d**

**S**
**e**
**n**
**t**
**e**
**n**
**c**
**e**

**o**
**f**

**3**
**8**

**y**
**e**
**a**
**r**
**s**


-----

|Col1|Col2|Custodial term of 32 years and an Extension Period of 6 years|
|---|---|---|
|Other relevant orders: Sexual Harm Prevention Order pursuant to s.103 of the Sexual Offences Act 2003 (until further order)|||


**End of Document**


-----

