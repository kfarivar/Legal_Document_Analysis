# Re A (Wardship: 17-Year Old: Section 20 Accommodation) [2019] 1 FLR 105

[2018] EWHC 1121 (Fam)

Family Division

Williams J

7 March 2018

**Wardship — 17-year old — Section 20 accommodation — Risk to safety and ongoing criminal proceedings**
**— Application for wardship — Best interests**

The local authority became involved with A, a 17-year-old, when the relationship with his father broke down and he
began absconding from home. His mother lived in Africa and played no part in his life. He was accommodated by
the local authority but continued to absent himself and got caught up with gang related activity and drug dealing. He
gave a detailed statement to the police as part of their investigations in Operation Trident and thereafter there were
concerns that he might be at risk of gang-related violence for having done so or that he might be drawn back into
gang activity. Prior to his seventeenth birthday, interim care and secure accommodation orders were made. He was
reportedly making good progress in secure accommodation in another part of the country but due to ongoing
concerns for his safety and the possibility of future criminal proceedings, an application to make him a ward of court
[was made. The care plan was for him to continue to be accommodated under s 20 of the Children Act 1989 and for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1TN-00000-00&context=1519360)
him to be supported by the leaving care provisions.

**Held – making the boy a ward of court –**

(1) Ultimately, the decision as to whether to utilise the wardship jurisdiction was a welfare decision that required a
consideration of the child's interests and those best interests were the paramount consideration: J and Another v C
_and Others (1969) FLR Rep 360. That involved an appraisal in the widest sense of what was in A's wellbeing and_
his interests. The chronology of A's life and history was not quite unique but of extreme rarity in the experience of
the Family Courts. In the circumstances of this case, there was doubt as to whether the father had parental
responsibility, but, in any event, that relationship had broken down and the mother was absent from his life. Since
the local authority would be exercising jurisdiction under s 20 and that A, himself, wished for the court to have some
involvement, it was in his best interests to be made a ward of court, particularly given the ongoing risks to him and
his involvement in the criminal process (see paras [50]–[57]).

(2) In making a wardship order the court did not intend to tread on the toes of either the local authority in fulfilling
their statutory obligations in relation to s 20, nor in relation to the prosecuting authorities in relation to their decisionmaking, but to confer on the court the responsibility for A's custody and provide a framework within which reference
may be made back to court, and in terms of making clear that there was somebody who would hold decisionmakers accountable in respect of their decisions over A. In this exceptional case it was appropriate to exercise the
wardship jurisdiction (see para [58]).

(3) Further information should not be disclosed to the police by the local authority about A. He objected to it and
there was no welfare benefit to him at this stage in doing so. If the police wanted further information, they would
have to make an application for it. Any such application, and the ultimate decision in criminal proceedings, should


-----

be notified to the Family Court as well as an explanation as to the fact that all statutory obligations had been
complied with by, in particular, the prosecuting authorities (see para [59]).
**[*106] Statutory provisions considered**

_[Children Act 1989, ss 1(1), 20(3), (11), 22, 25(1), 31(3), 38(4)(c), 100(2)(c), 105](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y0VV-00000-00&context=1519360)_

Children (Leaving Care) Act 2000, s 20

**_[Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

[Family Procedure Rules 2010 (SI 2010/2955), Part 12](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:51WD-T591-F16W-C2MJ-00000-00&context=1519360)

Hague Convention on Jurisdiction, Applicable Law, Recognition, Enforcement and Co-operation in Respect of
Parental Responsibility and Measures for the Protection of Children 1996, Art 16(4)
**Cases referred to in judgment**

_[A v Liverpool City Council and Another [1982] AC 363, [1981] 2 WLR 948, (1981) 2 FLR 222, [1981] 2 All ER 385,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G1G0-00000-00&context=1519360)_
HL

_[A Ward of Court (Wardship: Interview), Re [2017] EWHC 1022 (Fam), [2017] 3 WLR 593, [2017] 2 FLR 1515, sub](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMC1-DY9F-G4X5-00000-00&context=1519360)_
[nom Re A (A Child) (Ward of Court: Security Service Interview) [2017] 4 All ER 331, FD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2VK-00000-00&context=1519360)

_[E (Wardship Order: Child in Voluntary Accommodation), Re [2012] EWCA Civ 1773, [2013] 2 FLR 63, [2012] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3Y0-00000-00&context=1519360)_
_[(D) 262 (Nov), CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:573X-P6N1-DYBP-N3D8-00000-00&context=1519360)_

_[G, Re; Re R Note (Wards) (Police Interviews) [1990] 2 FLR 347, [1990] 2 All ER 633, FD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMP1-DY9F-G3R5-00000-00&context=1519360)_

_[G (Education: Religious Upbringing), Re [2012] EWCA Civ 1233, [2013] 1 FLR 677, [2012] All ER (D) 50 (Oct), CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G22M-00000-00&context=1519360)_

_[J and Another v C and Others [1970] AC 668, [1969] 2 WLR 540, (1969) FLR Rep 360, [1969] 1 All ER 788, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35S0-TWP1-613P-00000-00&context=1519360)_

_[M (Jurisdiction: Wardship), Re [2016] EWCA Civ 937, [2017] 2 FLR 153, CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G0R5-00000-00&context=1519360)_

_[Mansour v Mansour [1989] 1 FLR 418, CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G45K-00000-00&context=1519360)_

_[SA (Vulnerable Adult with Capacity: Marriage), Re [2005] EWHC 2942 (Fam), [2006] 1 FLR 867, FD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMC1-DY9F-G4W9-00000-00&context=1519360)_

_X (A Child) (Jurisdiction: Secure Accommodation), Re; Re Y (A Child) (Jurisdiction: Secure Accommodation) [2016]_
_EWHC 2271 (Fam), [2017] Fam 80, [2016] 3 WLR 1718, sub nom Re X and Y (Secure Accommodation: Inherent_
_Jurisdiction)_ _[[2017] 2 FLR 1717, FD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G1DG-00000-00&context=1519360)_

_Alex Laing appeared on behalf of the applicant (instructed by oneSource)_

_Kevin Gordon appeared on behalf of the first respondent (instructed by Haslaw & Co Ltd)_

_Edward Elliott appeared on behalf of the second respondent (instructed by Gary Jacobs & Co Solicitors Ltd)_

_J (children's guardian) appeared in person_

_Judgment was reserved._

**WILLIAMS J:**

**[1] This is my judgment relating to A, who was born in 2000 and is now 17 years old. The applicant is the local**
authority, who is represented by Mr Laing. The first respondent is Mr F, A's father, who is represented by Mr
Gordon. A's mother is in a country in Africa and has played no part in these proceedings, so is neither presented


-----

nor represented. A himself, who has played a significant role in these proceedings, is in court today as he was
yesterday. He is represented by Mr Elliott, he having parted company with his guardian, Mr J, some time ago. Mr J
is here today representing himself.

**[2] The applications which were before the court comprise, first of all, an application for a care order and a secure**
accommodation order that was issued on 8 September 2017. It was issued on the basis that A was beyond parental
control having become involved in gangs, having been forced to sell drugs,

**[*107] and being subjected to violence. The second application, which followed soon after the first, was an**
application which sought to engage the inherent jurisdiction of the High Court with respect to children in order to
seek a deprivation of liberty order. That was issued on 21 September 2017 on the basis that there was no
registered secure bed available but that other quasi-secure places may be available.

**[3] The very brief background to both of those applications was that, in early 2017, A's relationship with his father**
was under significant strain and he absented himself from home for significant periods of time which led to him
being accommodated by the local authority in May 2017. Between May and August, he was frequently missing from
the accommodation provided and it became clear that in that period he had been caught up in gang activity,
including drug dealing. In August 2017, he gave a very detailed statement to the police.

**[4] The police and the local authority were consequently very concerned that he may be drawn back into that**
activity, that he may be subjected to coercion and violence by gang members, and, given the number of gang
related killings in the area, the police and local authority were seriously concerned for his physical safety, indeed for
his life. As a result of his having given that detailed statement to the police, there was an additional concern that if
he were either called to give evidence in any prosecution or were his statement to be disclosed to any individual
charged with an offence that that would create an additional danger to him.

**[5] The matter first came before the court on 8 September 2017, I think in the local Family Court, when a district**
judge gave directions and the application was transferred to this court on the basis that an application under the
inherent jurisdiction would also be made. The matter then came first before Holman J on 14 September when he
adjourned the deprivation of liberty application. As a result, the applications came before me for the first time on 20
September when I heard evidence, in particular, from a police constable from Operation Trident, but also from the
social worker (Mr A), and I think from Mr J. On that occasion, I made an interim care order and adjourned the
deprivation of liberty application part heard.

**[6] That came back before me on 28 September 2017, by which time a secure bed had become available. On that**
occasion, I concluded that the evidence fully justified the finding that there was a history of absconding by A at that
point and that the evidence established that there was a real possibility that A would abscond from any other
accommodation. I also concluded that if he absconded he was likely to suffer significant harm and that although
placement in secure accommodation in another part of the country was contrary to his expressed and strongly held
wishes, that that was consistent with his welfare and it was necessary, and given the risks, proportionate.

**[7] So, following that, the matter came back fairly swiftly in October because that was immediately prior to A's**
seventeenth birthday. The local authority sought on that occasion to persuade the court that it was appropriate for it
to make a care order on the basis that if it was not made that day, the statutory jurisdiction to make such an order
would be lost and that, overall, it was in A's interests for a care order then to be made.

**[8] That application was opposed by the father, by A, and by Mr J. I concluded that although the threshold was**
clearly met, on welfare grounds

**[*108] and process grounds it would not be appropriate to make the order at that stage because, in particular, A**
was strongly opposed to that and was unhappy with his current social worker. I also concluded that I could not then
properly assess welfare, I could not properly assess other family options and I did not consider that a final order that
would confer parental responsibility on the local authority until A was 18 was a necessary and proportionate order to
make at that point in time. A was then placed in the aforementioned other part of the country and he made good
progress there.


-----

**[9] On 21 December, the application was restored before Knowles J because the secure accommodation order**
was about to expire and required extension. The matter then came back before me on 11 January 2018 on an
issues resolution hearing. By that stage, as I say, A had made good progress in the secure accommodation and
had either just moved or was just about to move to another placement in a different part of the country. On the basis
that everything appeared to be moving in a satisfactory direction, I reduced the time estimate from 3 days to 2 days
and thus the matter came back before me yesterday.

**[10] In the course of the hearing, I have had the benefit of position statements from the local authority, from the**
father, on behalf of A, and I have got the guardian's analysis which has stood in for his position statement. No party
felt it necessary for any witness to give evidence and so no further evidence has been called. Having heard
considerable evidence from social workers, the police, Mr J and A himself back in September, in the context of this
case I do not think the absence of any oral evidence in the course of this hearing has in any way been detrimental
to the consideration of A's future.

**[11] I have heard detailed submissions from all of the advocates. In particular, in relation to the current position and**
the proposals for the future, I have had the benefit of the statement from Ms L, who is the social worker who has
taken over from Mr A and I have had the benefit of the care plan.

**[12] The up-to-date position in relation to A's potential involvement in any prosecution is that it remains a work in**
progress because although I think even when the police constable from Operation Trident gave evidence back in
September, he was hoping to have a decision on whether A would be used as a witness within the next few days or
weeks. That decision has still not been taken. I am told by Mr Laing on behalf of the local authority that the Crown
Prosecution Service (CPS) is approaching the case on the basis that it may be prosecuted under the provisions of
[the Modern Slavery Act 2015, which I am told may be the first prosecution brought under that Act and therefore](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
they are proceeding very cautiously. They want to speak to A again about his evidence. A has already indicated to
the police that he does not want to give evidence and he has received advice from several sources that it would not
be in his interests to give evidence. The police have also indicated that they seek access to the local authority files
in respect of A in order to ascertain whether there are any skeletons waiting there which might be used to
undermine A by the defence in the event that any prosecution was to be pursued and A was to be called.

**[13] So the net position in respect of that aspect of the case is that no decision has yet been made in respect of**
charging any individual and nor has any decision been made yet in respect of whether A will actually be called to
give evidence. Whether that decision will be taken before A reaches the age of

**[*109] 18 can only be a matter of speculation, but one would have thought that something would happen over the**
next 7 months or so.

**[14] In respect of the approach of the local authority then to promoting A's future, the basis of the planning is that**
he continues to remain at risk if he were to return to his local area due to the vestigial gang issues but, of course,
there is the particular and heightened risk if he were used as a witness. In terms of family, the assessments of the
father and A's older sister, who I think is studying for nursing, is that they could not provide a suitable placement for
A.

**[15] In respect of his mother, of course, she remains in a country in Africa. Other potential placements might have**
included his stepmother, with whom he lived for some time and who I think is also the mother of his half-sister, but
no contact has been possible with her. So the net result of that, although I do not think it is truly a default position, is
that the proposal is that A should continue to live at the semi-independent accommodation in the area of the country
in which he is in now, where he is settling well, indeed, where it is said that his attitude to education has been an
inspiration to the other residents there.

**[16] It is therefore expected that he will remain there until at least the end of the academic year 2018. In the run up**
to the end of that year, there will be exploration in late May and June of alternatives for his education. Whether he,
by May, wants to stay in the part of the country in which he is currently in and continue his A levels at a local college
or whether he wants to start afresh somewhere closer to his home location is something that will have to be thought


-----

about in May or June so that, if A does wish to start again elsewhere, the necessary steps can be taken to put that
into effect by the start of the academic year 2018/2019. Depending on his decision in relation to the education issue
and proximity to his home location, then that will also require consideration of his accommodation and it seems
clear from the plan that the allocated social worker, Ms L, has put together that there will be both a multi-agency risk
assessment in relation to ongoing risks for A, but also a more practical consideration and review of the education
and accommodation options.

**[17] A particularly positive aspect of the attendance of the parties over the last 2 days is that, whilst the care plan**
referred to the fact that the relationship between A and his father had almost completely broken down, yesterday in
the course of the hearing there was a degree of reconciliation between the two of them as they were able to give
each other a hug at court. So I hope that that may represent the shoots of a new or a regeneration of that
relationship and that A is able to have such benefits as may be available from a better relationship with his father
and his sister so that he is, as it were, not solely reliant on the carers and his social workers who are currently
involved in ensuring his welfare is met.

**[18] The care plan overall, whilst needing a certain modest amount of updating to deal with that aspect and, of**
course, needing as they always will a degree of modification to reflect changes of circumstances on the ground,
seems to cover the essential elements that need to be put in place to ensure that A's needs are met under a s 20
accommodation arrangement. In particular, in relation to what will happen as he nears 18 and so nears the point at
which he can take full responsibility for his own life, the plan recognises that, as a

**[*110] looked-after child, he having been both a child subject to an interim care order but also a looked-after child**
[under s 20 accommodation, he will qualify for ongoing support under the Children (Leaving Care) Act 2000 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y13V-00000-00&context=1519360)
associated leaving care regulations. So, it seems clear from the care plan and what I have been told by Mr Laing
amplifying that, that there will, as it were, be follow-on provision to support A as he makes the transition from
technically being a child to being an adult.

**[19] In terms of the legal position, Mr Laing points out, of course, that because A is now 17, the statutory deadline**
in s 31(3) has passed. Happily, s 25 secure accommodation is not currently on the agenda and so the ongoing
provision for A would be under s 20 accommodation. Mr Laing makes clear that the basis on which that
[accommodation is provided is within the parameters of s 20(3) of the Children Act 1989, also on the basis that the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1TN-00000-00&context=1519360)
father does not object and indeed has signed a consent to A being accommodated, and indeed in accordance with
s 20(11) that A is consenting to that accommodation.

**[20] Mr Laing has also referred me to the definitions of a looked-after child under s 22(1) and s 105 which identify**
[that the requirements of the Children (Leaving Care) Act 2000 are engaged. He says that, at this stage, deprivation](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y13V-00000-00&context=1519360)
of liberty is not required but as a looked-after child or an accommodated child, secure accommodation would still
technically be available up until the age of 18 and that, again technically but hopefully not on the agenda,
deprivation of liberty applications would also be available if that were required if there was a U-turn, as it were, in
the progress that has been made so far.

**[21] The local authority's original position was that it opposed the suggestion that A be made a ward of court on the**
basis that that was not required; although, as a result of the exchanges in the course of yesterday, the local
authority modified its position to the extent that it would not oppose the making of a wardship on the basis that it
was only really targeted at the exceptional circumstances which exist relating to the potential prosecution.

**[22] On behalf of A's father, Mr Gordon helpfully provided the authorities, Re E (Wardship Order: Child in Voluntary**
_Accommodation) [2012] EWCA Civ 1773,_ _[[2013] 2 FLR 63 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3Y0-00000-00&context=1519360)_ _Re M (Jurisdiction: Wardship) [2016] EWCA Civ_
_[937, [2017] 2 FLR 153, on the use of wardship in circumstances where a child is subject to s 20 accommodation. I](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G0R5-00000-00&context=1519360)_
also have read A's father's recent statement. He accepts that A cannot return to live at home at the present time
although he does not agree with the entirety of the assessment made of him and he accepts that A's situation both
requires that he be accommodated by the local authority but also that he requires a higher level of engagement by
both the local authority and by the court given the exceptional risks that A has faced and may continue to face.


-----

**[23] A's father, thinks, or believes at least, that he has parental responsibility in respect of A although, as I will**
return to later, that is not entirely clear. He criticises some aspect of the care plan as being insufficiently clear
although appears to accept that the general nature of the plans is appropriate. He invites me to make A a ward of
court on the basis set out in para [9] of Re E; essentially, that it is necessary to ensure A's safety and to, as it were,
ensure that the court has a hand on the tiller of the arrangements that are put in place for A and, in particular, to
ensure that the local authority, as it

**[*111] were, lives up to expectations. Some particular aspects which Mr Gordon identified as being concerns of the**
father were that A should have access to therapy to deal with the experience he has been through and to ensure
that the education and accommodation aspects of the plan are properly implemented.

**[24] In respect of what A himself wants, Mr Elliott submitted that given the particular situation that he is in, he does**
support the proposition that he be a ward of this court. In particular, Mr Elliott emphasised that in this case there is a
lack of clarity in respect of whether anybody has parental responsibility for A within this country and that somebody
ought to clearly have responsibility for A, notwithstanding that he is 17, because of the exceptional situation he finds
himself in. In particular, Mr Elliott emphasised that the criminal process issues warrant the use of wardship to
ensure that A's welfare is properly taken into account in determining decisions taken in respect of disclosure of
information from the criminal process, any consideration of A giving evidence and what arrangements might be
made for his safety in that regard.

**[25] It is right to say that Mr Elliott recognises and accepts that, of course, there are limitations on the court's ability**
to manage those issues given the police and CPS's own statutory jurisdictions in relation to matters such as calling
witnesses. Mr Elliott also submitted that wardship had benefits because the issues related to practicalities, in
particular accommodation, also, in fact, raises significant safety issues because of the possibility of a return to A's
local area and thus a reinsertion into the environment that had given rise to the original concerns.

**[26] Mr J, on his own behalf, also supported the use of the wardship jurisdiction in the exceptional circumstances of**
this case because, as he said, there is still a huge amount of risk which surrounds A. He was pleased with the
beginnings of the reconciliation between A and his father and, in particular, Mr J I think was impressed by the extent
of the work that the allocated social worker, Ms L, has conducted over the period since she took over the case and
that the independent reviewing officer was also similarly committed. Mr J thought that the planning arrangements
within the care plan were appropriate and that the looked-after child (LAC) review in the July would be a key date
for the future. In particular, he thought that there were some minor aspects of the care plan which needed updating
but, in general terms, he was satisfied that the local authority's approach over recent weeks and months
demonstrated that they would implement the care plan as anticipated and would live up to their statutory
responsibilities.

**[27] All of this has to be viewed then against the factual background which I shall only set out briefly in this**
judgment. A was, of course, born in a country in Africa. We have not seen a copy of his birth certificate although the
father believes that he was named on that birth certificate and it seems that A lived in that country in Africa with his
mother until about 2007 when he arrived in the UK. Following that, he made his life for the last nearly 11 years in
the UK with his father and with his sister, and with his stepmother and his half-sister.

**[28] Things seem to have started to unravel from early 2016 onwards when his father and stepmother split up and**
she moved away to another part of the country with his sister. In July 2016, A was reported missing. By that time,
he

**[*112] had been missing for, I think, some 12 days and, in August, he was found sleeping in the service area at a**
shopping centre.

**[29] In October 2016, he was given a referral order for possession of a bladed article and, by April, it appears he**
had left the family home and was sleeping rough. That seems to have been for about 4 weeks because on about 19
May, he was found sleeping rough at the local shopping centre and had been stealing food. A remarkable aspect of
the case is that the police record that when he was found at the local shopping centre he was doing his homework


-----

for his GCSEs, which I suspect is probably unique in the annals of family courts' experience of young people in this
situation and so that reflects very well on A that he should be so dedicated to that work.

**[30] He was originally placed, I think, with family friends but by certainly 22 May he had been accommodated under**
_[s 20 of the Children Act 1989 at a semi-independent unit near his home location. Over the following 3 months](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1TN-00000-00&context=1519360)_
though, his absences from that accommodation led to him being drawn into gang activity which, in his first absence,
led to him being taken to a house in another part of the country and being forced to remain there and sell drugs. He
stayed there for a period of time and then left but was subsequently found by the gang, robbed by them, told he had
a debt, and then taken to a different part of the country. Either before or after that, he was beaten up with baseball
bats. He stayed, apparently, for 2 weeks in that new place when that property was targeted by another gang and A
was attacked by them, bitten, and hit with a baseball bat. All of this information, by and large, comes from A himself
because, after that incident, he was seen by the police with injuries and gave a lengthy interview to the team who
are part of Operation Trident.

**[31] Following his return from that new place and interview, he returned to the semi-independent accommodation**
and there are incidents recorded on 18, 24, 25 and 29 August, and on 1 September of him going missing again
from that accommodation. On 12 September, he was arrested for breach of a curfew and I think it was on that
occasion that there was an altercation with police in the course of which A, I think, was pepper sprayed. That then
all led to the institution of these proceedings which I have already set out the history of.

**[32] Since being in his current location, he has by and large settled well and is working hard. There have been**
recently two incidents of him being away from the accommodation overnight. No, as it were, additional concerns
have arisen from those absences, but I sincerely hope that A will be able to settle as fully in that accommodation as
he can and make the very best use of it that he can. I suspect that they are relatively minor blips in a generally
positive upward trajectory for A, but I think all of those around him are doing their very best to ensure that that is the
case.

**[33] That very brief narrative makes abundantly clear that A's life has, whilst he has experienced lengthy periods of**
stability, there have been life-changing events for him which most young people would never have to face. Most
would never have to face even one of the significant events let alone the multiple events that A has faced. That puts
him into, in my view, a relatively exceptional category of individual in this court's experience.

**[34] So, turning then briefly to the legal framework which I have to apply to A having regard to his life to date. An**
issue which we have grappled with is the question of whether A's father actually has parental responsibility. It is not
clear whether he does or does not. It must be right that over the years he has

**[*113] exercised parental responsibility, in fact, because he has been the one with care of A but the extent of the**
rupture between them so far means that, in practice, he is no longer exercising parental responsibility to any
significant degree. As a matter of law, it seems that he may not have acquired parental responsibility. Under the
relevant African national law, I do not know what the position is. If he had been married to A's mother, the
presumption that foreign law is the same as English could have applied so as to enable this court to presume that
A's father had parental responsibility applying the principles in _Mansour v Mansour_ _[[1989] 1 FLR 418, but that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G45K-00000-00&context=1519360)_
cannot be applied in this case.

**[35] In relation to the question of an unmarried father acquiring parental responsibility for an individual, I cannot**
presume that the same is true in relation to an unmarried father obtaining parental responsibility because A's date
of birth pre-dates the changes to our domestic legislation which now provides that an unmarried father named on a
birth certificate would acquire parental responsibility. So that does not apply and nor, contrary to the possibility that I
floated yesterday with Mr Elliott, does Art 16(4) of the Hague Convention on Jurisdiction, Applicable Law,
Recognition, Enforcement and Co-operation in Respect of Parental Responsibility and Measures for the Protection
of Children 1996 assist because the terms of that state that:


-----

'If the child's habitual residence changes, the attribution of parental responsibility by operation of law to a
person who does not already have such responsibility is governed by the law of the State of the new habitual
residence.'

**[36] So, whilst that can have the effect of conferring parental responsibility in some circumstances, it would not**
apply in this case because A was born before the changes to UK law on unmarried fathers named on the birth
certificate. So a father named on a birth certificate in the UK prior to 1 December 2003 would not have acquired
parental responsibility and therefore I do not think that Art 16(4) assists in conferring parental responsibility on A's
father.

**[37] So the situation remains unclear in respect of A's father's parental responsibility. He may have it as a matter of**
the relevant African national law, but we do not know for sure whether he does or does not. So there is a lack of
clarity. Given that no application has formally been made that A's father be granted parental responsibility and given
that he may already have it, I am not prepared to make an order which purports to grant parental responsibility
today when, in fact, it might already exist.

**[38] In relation to care orders, of course, s 31(3) provides that no care order may be made with respect to a child**
who has reached the age of 17. Just for the sake of clarity, because an issue was raised but ultimately not pursued,
[the interim order that was made in September endured by operation of s 38(4) of the Children Act 1989 for such](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1JT-00000-00&context=1519360)
period as may be specified. Section 38(4) provides that it would cease to have effect on the occurrence of certain
events. The only event which applies in this case is s 38(4)(c), which is the disposal of the application. So the
interim care order would endure until the disposal of the application, ie today. There is no provision for it to cease
on the child reaching the age of 17.

**[[*114] [39] In terms of the question of accommodation, that is all set out in ss 20 and 22 of the Children Act 1989:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1TN-00000-00&context=1519360)**

**'20 Provision of accommodation for children: general.**

(1) Every local authority shall provide accommodation for any child in need within their area who appears to
them to require accommodation as a result of—

(a) there being no person who has parental responsibility for him;

(b) his being lost or having been abandoned; or

(c) the person who has been caring for him being prevented (whether or not permanently, and for whatever
reason) from providing him with suitable accommodation or care.

…

(3) Every local authority shall provide accommodation for any child in need within their area who has reached
the age of sixteen and whose welfare the authority consider is likely to be seriously prejudiced if they do not
provide him with accommodation.

…

(7) A local authority may not provide accommodation under this section for any child if any person who—

(a) has parental responsibility for him; and

(b) is willing and able to—

(i) provide accommodation for him; or

(ii) arrange for accommodation to be provided for him

objects


-----

(8) Any person who has parental responsibility for a child may at any time remove the child from
accommodation provided by or on behalf of the local authority under this section.

…

(11) Subsections (7) and (8) do not apply where a child who has reached the age of sixteen agrees to being
provided with accommodation under this section.'

**'22 General duty of local authority in relation to children looked after by them.**

(1) In this section any reference to a child who is looked after by a local authority is a reference to a child who
is—

(a) in their care; or

(b) provided with accommodation by the authority in the exercise of any functions (in particular those under
[this Act) which are social services functions within the meaning of the Local Authority Social Services Act 1970,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y089-00000-00&context=1519360)
apart from functions under sections 23B and 24B.

(2) In subsection (1) “accommodation” means accommodation which is provided for a continuous period of
more than 24 hours.

(3) It shall be the duty of a local authority looking after any child—

(a) to safeguard and promote his welfare; and

**[*115] (b) to make such use of services available for children cared for by their own parents as appears to the**
authority reasonable in his case.

(3A) The duty of a local authority under subsection (3)(a) to safeguard and promote the welfare of a child
looked after by them includes in particular a duty to promote the child's educational achievement.

(3B) A local authority must appoint at least one person for the purpose of discharging the duty imposed by
virtue of subsection (3A).

(3C) A person appointed by a local authority under subsection (3B) must be an officer employed by that
authority or another local authority.'

In particular, s 22 sets out that a child is a looked-after child if he is provided with accommodation by the local
authority.

**[40] As a result of that, the** _[Children (Leaving Care) Act 2000 and the associated regulations are engaged. Mr](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y13V-00000-00&context=1519360)_
Laing provided me with a helpful flowchart which sets out the pathway which A will fit into under the statute and the
obligations which accompany that. It is clear from that that currently as a 17-year old who is accommodated, he will
be eligible for support on leaving care including a personal advisor, a needs assessment, a pathway plan, and
reviews of that. The alternative possibility is that he would become a relevant child which would carry with it
accommodation and maintenance, financial assistance to meet education and training, and if he ceased to be
accommodated for some reasons, he would become a former relevant child which would still carry with it certain
obligations.

**[41] Turning then to the question of wardship, the inherent jurisdiction of the High Court with respect to children**
derives from the right and duty of the Crown to its citizens to take care of those who are not able to take care of
themselves, often called the parens patriae jurisdiction. The nature of that jurisdiction is the duty of the court to see
that a child is properly taken care of and the welfare of the child being the object of that converts in current
terminology into the inherent jurisdiction being a paramount welfare jurisdiction covered by _[s 1(1) of the Children](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y0VV-00000-00&context=1519360)_


-----

Act 1989. For a recent exposition of the nature and limits of the inherent jurisdiction and wardship see para [84] of
_[Re SA (Vulnerable Adult with Capacity: Marriage) [2005] EWHC 2942 (Fam), [2006] 1 FLR 867.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMC1-DY9F-G4W9-00000-00&context=1519360)_

**[[42] It is clear though that there are limits on the inherent jurisdiction; in particular, those set out in s 100 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C289-00000-00&context=1519360)**
Children Act 1989 which, in subs (2) states that:

'No court shall exercise the High Court's inherent jurisdiction with respect to children—

(a) so as to require a child to be placed in the care, or put under the supervision, of a local authority;

(b) so as to require a child to be accommodated by or on behalf of a local authority;

(c) so as to make a child who is the subject of a care order a ward of court; or

**[*116] (d) for the purpose of conferring on any local authority power to determine any question which has**
arisen, or which may arise, in connection with any aspect of parental responsibility for a child.'

**[43] Where the local authority seeks to invoke the inherent jurisdiction, it requires permission. In this case, the local**
authority is not seeking to invoke the inherent jurisdiction and so leave is not required in this case. I would also note
that the interim care order which comes to an end on the disposal of this application will therefore not provide a bar
within s 100(2)(c) to the court making A a ward of the court.

**[44] Notwithstanding the fact that s 100(2) is clearly designed to limit the court's ability to impose duties on local**
authorities in relation to children and young people, there are circumstances in which the court has recognised that
where care proceedings are concluding and a child is to be accommodated under s 20, that wardship may be
[appropriate (see Re E (Wardship Order: Child in Voluntary Accommodation) [2012] EWCA Civ 1773, [2013] 2 FLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3Y0-00000-00&context=1519360)
_[63 and Re M (Jurisdiction: Wardship) [2016] EWCA Civ 937, [2017] 2 FLR 153).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3Y0-00000-00&context=1519360)_

**[45] A significant, indeed perhaps the critical, issue identified in these and other similar cases is that the use of the**
wardship powers must not conflict with another statutory power or duty, whether that arises under _[s 100 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C289-00000-00&context=1519360)_
Children Act 1989 or whether the relevant duty arises under any other part of the _[Children Act 1989 or criminal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
statutes. Hence, in the recent case before the President, Re A Ward of Court (Wardship: Interview) [2017] EWHC
_1022 (Fam), [2017] 3 WLR 593,_ _[[2017] 2 FLR 1515, the President considered whether a ward was in any way](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMC1-DY9F-G4X5-00000-00&context=1519360)_
insulated from the usual requirements in relation to being a witness in a criminal trial or being interviewed:

'[49] There is, in my judgment, a pressing need for paragraph 5 of PD12D to be considered as a matter of
urgency by the Family Procedure Rule Committee. Radical surgery will probably be required.

[50] In the meantime, police officers, officers of the Security Service and others in a similar position should
follow the guidance given by Sir Stephen Brown P in the following passages in his judgment in _Re G; Re R_
_Note (Wards) (Police Interviews)_ _[[1990] 2 FLR 347 (emphasis added):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMP1-DY9F-G3R5-00000-00&context=1519360)_

“In the majority of cases there will be no time, in any event, to seek the court's leave before the interviewing of
[a minor in such circumstances. Provided that the requirements of the Police and Criminal Evidence Act 1984](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0Y0-TWPY-Y0VH-00000-00&context=1519360)
_with regard to juveniles are complied with, the duty upon the police is discharged. They have no extra duty to_
_perform. There is, of course, a duty upon those having the care of the minor to inform the court at the earliest_
practical opportunity of what has taken, place, but there is no further duty upon the police themselves in those
_circumstances._

… I make it clear for their assistance that when they arrest a minor who in fact is a ward then they may properly
_proceed to interview him in accordance with their normal procedure provided of course that they comply with_
_[the provisions relating to all juveniles under the Police and Criminal Evidence Act 1984. It](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0Y0-TWPY-Y0VH-00000-00&context=1519360)_

**[*117] will then be for the person having charge of the minor to notify the court of what is taking place or has**
_taken place._


-----

…where a suspect is arrested, then it seems appropriate that I should make it clear that the police should not
_be inhibited from following their normal procedures with regard to such a person.”_

[The Police and Criminal Evidence Act 1984 does not apply to the Security Service. In relation to the Security](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0Y0-TWPY-Y0VH-00000-00&context=1519360)
Service and other agencies to which it does not apply, Sir Stephen's references to the 1984 Act should
therefore be read as referring to the relevant legislative framework governing the functions of the Security
Service or other agency involved.'

**[46] As a result, the relevant practice direction dealing with wards of court, which is issued under Part 12, para**
5.1.1 of the Family Procedure Rules 2010 (FPR 2010), was rapidly amended so that in respect of criminal
proceedings, it now provides that:

'There is no requirement for the police or any other agency carrying out statutory powers of investigation … to
seek the permission of the court to interview a child who is a ward … The fact that a child is a ward of court
does not affect the powers and duties of the police … in relation to their investigations. Provided that the
relevant statutory requirements are complied with, the police or other agencies are under no duty to take any
special steps in carrying out their functions in relation to a child who is a ward of court.'

**[47] Paragraph 5.1.2 makes clear, which is of particular application in this case:**

'Where a child has been interviewed by the police in connection with contemplated criminal proceedings and
the child is, or subsequently becomes, a ward of court, the permission of the court is not required for the child
to be called as a witness in the criminal proceedings.'

**[48] It is right to say that the previous authorities on which the President relied in the authority I have cited do make**
clear that, in relation to young people who are interviewed or who are contemplated to be witnesses, there may be
quite independent statutory duties which are laid upon the police or prosecuting authorities in relation to the taking
of evidence from or calling as a witness a child.

**[49] So the net result of the limitations which are placed on the court is that, provided the use of wardship does not**
conflict with a statutory scheme, it may be deployed in order to protect or secure the welfare of a child. Its ability to
fill in where statute has neither provided nor excluded has been confirmed, for instance see _A v Liverpool City_
_Council and Another [1982] AC 363, [1981] 2 WLR 948,_ _[(1981) 2 FLR 222, at 373, 953 and 266, respectively,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G1G0-00000-00&context=1519360)_
where the House of Lords said:

'In some instances, there may be an area of concern to which the powers of the local authority, limited as they
are by statute, do not

**[*118] extend. Sometimes, the local authority itself may invite the supplementary assistance of the court. Then**
the wardship may be continued with a view to action by the court. The court's general inherent power is always
available to fill gaps or to supplement the powers of the local authority. What it will not do, except by way of
judicial review where appropriate, is to supervise the exercise of discretion within the field committed by statute
to the local authority.' (See also the decision of Baker J in _Re X (A Child) (Jurisdiction: Secure_
_Accommodation); Re Y (A Child) (Jurisdiction: Secure Accommodation) [2016] EWHC 2271 (Fam), [2017] Fam_
80, [2016] 3 WLR 1718, sub nom _Re X and Y (Secure Accommodation: Inherent Jurisdiction)_ _[[2017] 2 FLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G1DG-00000-00&context=1519360)_
_[1717, at paras [31]–[50] for a consideration of the fill-in powers provided by the inherent jurisdiction.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G1DG-00000-00&context=1519360)_

**[50] The approach therefore to the exercise of wardship has to be seen in the light of not treading on the statutory**
toes of any other body and seeking, where necessary, to fill in or supplement other duties. However, ultimately, the
decision as to whether to utilise it is a welfare decision that requires a consideration of the child's interests and
those best interests are the paramount consideration, as was said in J and Another v C and Others [1970] AC 668,

[1969] 2 WLR 540, (1969) FLR Rep 360 by Lord MacDermott. The phrase 'first and paramount' connotes a process
whereby:


-----

'… when all the relevant facts, relationships, claims and wishes of parents, risks, choices and other
circumstances are taken into account and weighed, the course to be followed will be that which is most in the
interests of the child's welfare as that term has now to be understood. That is the first consideration because it
is of first importance and the paramount consideration because it rules upon or determines the course to be
followed.

…

The word “welfare” must be taken in its widest sense.' (See _Re G (Education: Religious Upbringing) [2012]_
_[EWCA Civ 1233, [2013] 1 FLR 677.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G22M-00000-00&context=1519360)_

**[51] This involves an appraisal in the widest sense of what is in A's wellbeing and his interests. It extends to and**
embraces everything that relates to his development. Although not required to apply the welfare checklist, I have it
in mind. I also have the no order principle in mind.

**[52] So concluding then, the chronology of A's life and the history that I have set out is perhaps not quite unique**
but of extreme rarity in the experience of the Family Courts. For the following reasons I consider he ought to
become a ward of court which will last until he is 18. First of all, there is doubt over whether his father does have
parental responsibility for him. His relationship with his father had broken down and although there may be some
regeneration of that, the extent to which his father will be able or willing to exercise parental responsibility is
uncertain.

**[53] Secondly, because A will be accommodated under s 20, the local authority will not have parental responsibility**
for him, although it will have statutory obligations to him as a looked-after child and a child leaving care.

**[*119] His social worker appears to me to be proactive and well engaged, but that is not the same as having a**
pushy parent. His mother is absent from his life. The very considerable life events, in particular his separation from
his family and the risks posed by the gang-related violence and his possibly being called as a witness, create
exceptional welfare concerns. The concerns that were expressed back in September by the police officer from
Operation Trident were characterised as the gravest possible risks and the risks in relation to him giving evidence
are a significant part of that.

**[54] I take into account that A himself wants to have some continued court oversight in relation to his protection.**
Notwithstanding the duties that are imposed on the local authority, there are some aspects of what will happen over
the next few months which means A needs, I think, to have in the background somebody who is looking out for him
with a specific obligation of parental responsibility. That, in itself, may not appear to provide much but I think the fact
that he will be a ward and the court has an interest in him needs to be known to those who have dealings with him
and that it is the court itself, not simply a parent, who will be holding those who have statutory obligations to A
accountable to the court if those obligations are not fully complied with.

**[55] I am satisfied in this case that the court does not need to be involved in day-to-day decision-making in respect**
of A. I am satisfied that the local authority will implement the plan as envisaged, and that for the court to be
exercising some supervisory function over that would fall foul of the limitations which are placed on the court when it
interfaces with a local authority exercising statutory functions. The care plan itself makes provision for many
alternatives. There is a recognition that if there was a severe deterioration in the situation that the secure
accommodation and deprivation of liberty options remain on the table and so I will exclude from the ambit of
decisions which the court needs to approve of or to be notified of those day-to-day decisions relating to
accommodation, schooling, medical treatment, etc. What I am interested in, in particular, in this and what I think
requires that A be a ward, is the situation relating to the criminal process.

**[56] Of course, in matters relating to that, it is for the prosecuting agencies to take the decisions, but I want the**
prosecuting agencies to know that A is a ward of court and that the court expects to be informed of decisions taken
in relation to A. The court will expect those taking such decisions to account to the court for them and to satisfy the
court that all their relevant statutory obligations have been complied with in the taking of any decisions of that
nature


-----

**[57] In the absence of having a parent who can, as it were, step into that role and having regard to the fact that the**
allocated social worker, Ms L, does not hold parental responsibility and I do not think it would be fair, as it were, to
put on her the responsibility of asking her voluntarily, as it were, to take on the role of the proactive or pushy parent,
it should be the court who exercises that in the absence of anybody else and in the unique circumstances of this
case.

**[58] So I do conclude therefore that it is in A's welfare interests for him to be made a ward of court, in particular for**
that purpose. I do not intend by making that wardship order to in any sense tread on the toes of either the local
authority in fulfilling its statutory obligations in relation to s 20 nor in relation

**[*120] to the prosecuting authorities in relation to their decision-making, but for the reasons essentially which are**
set out or at least endorsed by Thorpe LJ in _Re E (Wardship Order: Child in Voluntary Accommodation) [2012]_
_[EWCA Civ 1773, [2013] 2 FLR 63 that the making of A a ward and conferring on the court the responsibility for his](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3Y0-00000-00&context=1519360)_
custody (to use the old terminology), that, together with providing a framework within which reference may be made
back to court, and in terms of making clear that there is somebody who will hold decision-makers accountable in
respect of their decisions over A, in my view, makes it appropriate to exercise the wardship jurisdiction in this
exceptional case.

**[59] So I will therefore reserve any further application in relation to A to myself if I am available. I endorse the local**
authority's designation of accommodation as falling under s 23 insofar as that has any relevance at all. I do not
believe that any further information should be disclosed to the police by the local authority about A. He objects to it
and I cannot see any welfare benefit to him at this stage in doing so. If the police want further information, they will
have to make an application for it. Whether that is to the criminal court or to this court I am not entirely clear, but I
would expect to know about any such application if it were made. I expect to be informed of the ultimate decision
which is made in respect of A's involvement in any criminal proceedings and to receive an explanation as to the fact
that all statutory obligations have been complied with by, in particular, the prosecuting authorities.

**[60] I hope that that will enable you to draw the relevant order and I sincerely hope for A that things develop as you**
want them to in your current location, that you get some A levels under your belt and that, if you want to, that you go
off to university and that this is another step along the line to a more positive future. However, I will, until you are 18,
be in the background, hopefully as a positive influence, in relation to decisions that are made in respect of you and
decisions you make.

Order accordingly.

SAMANTHA BANGHAM Law Reporter

**End of Document**


-----

