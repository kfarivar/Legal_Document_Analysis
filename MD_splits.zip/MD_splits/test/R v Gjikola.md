# R v Gjikola [2024] EWCA Crim 207

Court of Appeal, Criminal Division

Lord Justice William Davis, Mr Justice Murray, The Recorder Of Preston, His Honour Judge Altham (Sitting As A
Judge Of The Cacd)

15 February 2024Judgment

MR B DOUGLAS-JONES appeared on behalf of the Applicant

MR A JOHNSON appeared on behalf of the Crown

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. LORD JUSTICE WILLIAM DAVIS: The applicant is now aged 27. On 14 October 2019 in the Crown

Court at Stoke‑on‑Trent, he pleaded guilty to producing a controlled drug of class B, namely cannabis, and

possession of an identity document with improper intention. Three days later on 17 October 2019 he was
sentenced to 21 months' imprisonment in respect of producing a controlled drug of class B and a
consecutive sentence of six months in respect of the possession of an identity document. A total sentence
of 27 months' imprisonment.

2. He now applies for an extension of time of just over 1,300 days for leave to appeal against conviction.
His application has been referred to the full court by the Registrar.

3. The essence of his appeal is that had the applicant and his representatives been aware of material
which is now available, he would not have pleaded guilty because he would have had a sound defence
[pursuant to the Modern Slavery Act 2015. Equally, had the prosecution been aware of it, it is said they](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
would not have continued with the prosecution or if they had attempted to do so they would have been met
with a successful abuse of process application.

4. He seeks leave to adduce evidence now pursuant to section 23 of the _[Criminal Appeal Act 1968:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1P8-00000-00&context=1519360)_
evidence relating to his asylum application and a positive conclusive grounds decision by the Single
Competent Authority that he was and is a victim of trafficking.

5. He has been represented by Mr Ben Douglas‑Jones KC. The prosecution have been represented by

Mr Andrew Johnson. Their position is that on a proper examination of the facts the court can and should


-----

conclude that the applicant would not have been able to avail himself of any defence pursuant to the 2015
Act and that even if everything had been known that now is known the prosecution would have continued
without any interference from the court. That prosecution in all likelihood would have succeeded.

6. The core facts are not in dispute. In the middle of September 2019 the police went to a house in

Burslem, Stoke‑on‑Trent. It was a two‑bedroomed terraced house. Three of the rooms had been adapted

for the purpose of growing cannabis. There were the usual heating, lighting and ventilation systems in
place. The electricity meter at the house had been bypassed. There were 133 growing cannabis plants at
the property.

7. Police also found three Romanian identity documents in different names and two Romanian driving
licences in different names. All of the documents bore a photograph. In each case the photograph was a
photograph of the applicant. In some cases the applicant was wearing a dark top, in other cases a red top.
They were all false documents. The applicant is in fact an Albanian national, not a Romanian.

8. Whilst the police were still at the property, the applicant arrived. He had arrived in a car. The car was
registered in the name of one of the names on the false identity documents i.e. one of the documents
bearing the photograph of the applicant. He came into the house, opening the front door using a key.
Upon entry he was arrested.

9. He was interviewed by the police. He said he had been in the United Kingdom for about six months.
He declined to say how long he had been living at the address in Burslem. He said that he had not worked
since entering the United Kingdom. Having confirmed that he was somebody who smoked cannabis he
declined to answer any further questions.

10. We have seen the letter of engagement that was provided by him from a firm of solicitors in Stafford
for his representation in the criminal proceedings. As we have said, he appeared at the Crown Court and
was sentenced. On each occasion he was represented by counsel.

11. Before his final sentence at the Crown Court, he was interviewed by an immigration officer whilst being
held on remand. It was apparent to the authorities he was in the country illegally. The authorities needed
to interview him to see what his position was. He claimed asylum. He was referred by the officer who
interviewed him through the National Referral Mechanism to the Single Competent Authority, the process
by which any potential victim of trafficking can be identified.

12. A short form relating to potential adult victims of modern slavery was completed by a Home Office
official. This recorded the applicant's account at that point. He said that he had left Albania in April of 2019
to begin his journey to the United Kingdom. Before his departure he had arranged to meet a man who
would assist him with his entry into this country. He travelled from Albania to Italy on a bus, purchasing his
own ticket. He had stayed in Italy for about one or two weeks. During that time he met the person who
was going to arrange his trip to this country. He had entered the UK hidden in the back of a lorry.
Arrangements had been made for him to work as a cleaner in London. He then was taken to

Stoke‑on‑Trent where he worked looking after cannabis plants. He told the immigration officer that he was

not paid any money for all of this; rather his work would repay the money he owed for his travel to the
United Kingdom.

13. The applicant's case was considered by the Single Competent Authority towards the end of October,
their initial reasonable grounds decision being made shortly after he was sentenced. That decision
determined that there were reasonable grounds to suspect that he was a victim of trafficking but as is
usually the case, the Single Competent Authority indicated the case would have to be looked at in more
detail before a conclusive grounds decision could be made.

14. In the early stages of the further consideration of his case, the applicant provided a handwritten
document to the relevant authority setting out various matters which appeared to be in response to queries
addressed to him. He said first that he had the key to the house because they (people who were using
him) "made me go in and out. If I didn't do that they will threat my family in Albania." Second, he said:
"They gave me a car a week before my arrest so I could sleep in it." Third, he said that he came to the


-----

United Kingdom in April and up until September he worked as a cleaner. He said: "Everything I had I was
forced by them to hold and use as I was told [this presumably being a reference to, amongst other things,
the identity documents]. No questions asked."

15. In course the Single Competent Authority made its conclusive grounds decision. As was said in AAJ

_[[2021] EWCA Crim 1278, the decision of the Competent Authority is not binding on this or any court but,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_
unless there is evidence to contradict it or other reasons substantially to doubt it, then the court must
respect that decision. In this instance the Single Competent Authority concluded: "You have given a
generally detailed, plausible and relatively consistent account in relation to your claimed exploitation." The
decision noted there were inconsistencies. The decision dealt with them in turn. First, the applicant had
said that he was taken against his will to care for the cannabis plants, yet the police had encountered him
coming back into the house using a key having been out somewhere. As the judge had commented, he
was plainly able to come and go freely to the house, not something normally associated with what the
judge referred to as gardeners. The Single Competent Authority's decision rehearsed what the applicant
had said in the handwritten document to which we have already referred and stated: "The clarification of
the inconsistencies you have given are considered to be a reasonable explanation." In relation to the use
of the car, the Single Competent Authority again acknowledged that such use appeared to contradict the
proposition that the applicant was in debt to trafficker and was not being paid. By reference to what the
applicant said in his document, namely that he had been given the car to sleep in, the Single Competent
Authority again said: "The clarification of the inconsistencies is considered to be a reasonable explanation."
As to the five counterfeit documents, the Single Competent Authority rehearsed what was said by the
applicant about having been given these various items with a warning to keep them safe. Without more,
the Single Competent Authority concluded that that clarification was considered to be a reasonable
explanation. Thus, the decision was that there were conclusive grounds to conclude that the applicant was
a victim of trafficking.

16. Our principal task is to consider whether that material and other material in the case would have led a
reasonable prosecutor in 2019 to take a view of the case determining that it would not have been in the
public interest to prosecute.

17. In investigating that issue we have heard evidence from the applicant. We have done so because, as
was said in _AAD_ _[[2022] EWCA Crim 106, where there is unsatisfactory and untested hearsay evidence](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
which gives rise to the decision on which reliance is placed, it will often be the case that an applicant has to

give evidence before this court. That is what happened in this case. Mr Douglas‑Jones did not suggest

that any other course was appropriate.

18. The applicant's evidence was that at some point in about the middle of 2018 he had borrowed £14,000
to £15,000 (or the Albanian equivalent thereof) in order to pay for medical treatment for his mother. He
said that he was going to repay this by working with his father. We observe that he had earlier said that his
father was working somewhere in Greece in a location which he did not know and in circumstances which
meant that he was unable to contact him. According to the applicant there were no repayment
arrangements made. No money was repaid.

19. The applicant told us that about six months later at the beginning of 2019 he was abducted and was
kept hostage or prisoner in a house somewhere near Tirana for the better part of two months. During that
time he was regularly assaulted, his family were threatened and for the first time it was said he was going
to have to pay interest on the debt. Having been so kept hostage, in a way that meant he was unable to do
anything at all to meet the debt, he told us that he had got away. No detail was provided of his means of
escape. He stayed for a while with somebody in Albania and then travelled to Italy. This was under his
own steam. He went there in order to work. The consequence of that evidence is that, notwithstanding the
fact that he had apparently been kidnapped by a gang who kept him hostage for nearly two months and
threatened to do serious damage to his family unless he cooperated with them and repaid the money that
he owed them, he simply ran away from the house he was being kept in and went to Italy without any
concern for his family.


-----

20. He then said that he was discovered by the members of the group whilst in Italy. It was from there that
he was brought to the United Kingdom in a lorry. He lived for a few months in London in a house he was
unable to identify by reference to any area in London. He worked to pay off his debt doing cleaning jobs in
domestic settings. He was able to come and go from the house in which he was living but he did not leave
because he was scared for his family. He said he was threatened, or more accurately his family was
threatened: "Don't forget you have family. We shall kill your mum, dad, brother and sister." As we have
already observed that sort of threat did not appear to have dissuaded him from making his escape from the
house in Albania where he had been kept hostage.

21. He went up, he said, to Stoke two or three weeks before his arrest, having been taken there in a van.
He agreed that at the house in Stoke he had seen the various false identification documents. He did not
know why they were there. He had had nothing to do with them being made. Each of them bears what is
clearly a photograph of him. In every case he said he had no idea how the photograph came to be
attached to the false document. The car was registered in one of the false identities. He told us that he
had no idea why the car was at the house or for what it was meant to be used. He would use it from time
to time amongst other things to get shopping, although he sometimes slept in the car. His case was that
throughout all of this he was very stressed and worried and scared about his family.

22. We have to assess the credibility of that evidence. On his behalf, Mr Douglas‑Jones has invited us to

conclude that, despite some of the apparent inconsistencies and contradictions, overall his evidence was
credible and should be accepted by us.

23. We regret to say that we take precisely the opposite view. We do not find any part of his evidence
credible. We find it incredible that he felt it appropriate for him, having escaped from the clutches of his
kidnappers, simply to go off to Italy without any concern at all for his family. In this country he was living in

a house in Stoke‑on‑Trent with multiple false identities, a car and other items, all of which would appear to

be wholly at odds with the notion that he was a trafficked individual.

24. For his application to have any prospect of success we would have to find there is at least a possibility
[that he would have been able to take advantage of the defence in section 45(1) of the Modern Slavery Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

_[2015 when he appeared before the Crown Court in Stoke‑on‑Trent. We do not even trouble to mention the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

fact that much of what he said to his counsel at sentence was at odds with what he said to us and had
previously said in the course of his dealings with the Single Competent Authority. But the defence requires
a jury to conclude at least as a possibility that the applicant had done what he did because he was
compelled to do so and the compulsion was attributable to slavery or relevant exploitation. On the
evidence we have heard, we are satisfied that the jury would have rejected both of those propositions,
leaving us in the position where it would be wholly unnecessary for us to consider what the reasonable
person might or might not have done.

25. In all of those circumstances, our judgment is that the fresh evidence upon which the applicant seeks
to rely is not evidence capable of belief in terms of establishing either the defence under section 45 or the
situation where any proceedings would have been found as an abuse of process. Given that is the

position, it is self‑evident that the evidence we have heard would not have afforded any ground at all for

allowing the appeal had we received the evidence other than de bene esse.

26. In all of those circumstances, given that we do not receive this evidence for the reasons we have
given, there is no basis at all for this application to extend time and for leave to appeal to be granted.
Therefore both are refused.

27. It is common place for there to be anonymity in cases of this kind. Given our conclusions in this case
we do not consider that an anonymity order would be appropriate. Insofar as the case is reported, it may
be reported in the full name of the applicant.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.


-----

Lower Ground Floor, 46 Chancery Lane, London, WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

