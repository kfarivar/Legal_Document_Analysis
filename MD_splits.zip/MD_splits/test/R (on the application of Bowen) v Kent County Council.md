# R (on the application of Bowen) v Kent County Council [2023] EWHC 1261
 (Admin)

King's Bench Division (Administrative Court)

Mr Justice Constable

26 May 2023Judgment

DAVID WOLFE KC and KATY SHERIDAN (instructed by Simpson Millar LLP) for the Claimant

NIGEL GIFFIN KC (instructed by Bevan Brittan LLP) for the Defendant

Hearing dates: 16-17 May 2023

- - - - - - - - - - - - - - - - - - - - 
**JUDGMENT**

This judgment was handed down remotely at 10.30am on Friday 26[th] May 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives

(see eg https://www.bailii.org/ew/cases/EWCA/Civ/2022/1169.html).

**Mr Justice Constable:**

A.        Introduction

1. The Claimant, Stephen Bowen, is a humanist. Mr Bowen subscribes to a worldview based on logic,
rationality, science, education, and mutual respect. As described in evidence cited in R (Harrison) v
Secretary of State for Justice and Ors [2021] PTSR 322:

_“Humanists are people who shape their own lives in the here and now, because we believe this is the only_
_life we have. Humanism is a non-religious worldview and humanists are therefore either atheists or_
_agnostics. We adopt a naturalistic outlook, believing that, in the absence of an afterlife and any_
_discernible purpose to the universe, human beings can act to give their own lives meaning by seeking_
_happiness in this life and helping others to do the same. We make sense of the world through logic,_
_reason, and evidence, and concern for human beings and other sentient animals, always seeking to treat_
_those around us with warmth, understanding and respect.”_

2. Mr Bowen sought to be appointed to join Group A of the Standing Advisory Council for Religious
Education ('SACRE') of Kent County Council ('KCC').  Pursuant to section 390(4)(a) of the Education Act
1996 ('the 1996 Act'), set out more fully later in this Judgment, Group A is required to be 'a group of
_persons to represent such Christian denominations and other religions and denominations of such religions_
_as, in the opinion of the authority, will appropriately reflect the principal religious traditions in the area.'_
KCC refused to appoint Mr Bowen because, as a humanist, Mr Bowen does not represent 'a religion or a
_denomination of a religion' for the purposes of section 390(4)(a) of the 1996 Act.  KCC considered that it_
did not have the power to appoint Mr Bowen to Group A and that it would have been unlawful for it to do
so.


-----

3. Mr Bowen brings this case to challenge KCC's decision.  Put simply, he says this is discriminatory and
so in breach of Article 14 of the European Convention on Human Rights ('ECHR'). As such, he contends
[that pursuant to section 3 of the Human Rights Act 1998 ('HRA 1998'), section 390(4)(a) must be read in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
such a way as to avoid the breach.  It is accepted by David Wolfe KC, on behalf of Mr Bowen, that on any
normal use of language, humanism is not a 'religion' or a 'denomination of a religion' ('religion' involves a
spiritual or non-secular belief system: see R (Hodkin) v Registrar General [2014] 1 AC 610. However, it is
argued that the words 'other religions' can and should be, pursuant to section 3 of the HRA 1998,
construed as incorporating the duty of care of neutrality recognised by the ECHR, in much the same way
that Warby J construed the phrase 'religious education' in R (Fox) v Education Secretary [2016] P.T.S.R.
405. Mr Bowen's challenge, therefore, stands or falls on the proper construction of section 390(4)(a) of the
1996 Act, in light of section 3 of the HRA.

4. There are four fundamental issues:

(1) Is ECHR Article 14 engaged at all?  This question turns on whether the matter falls within the 'ambit' of
ECHR Article 9, or Article 2 of the 1[st] Protocol to the ECHR ('A2P1').

(2) If Article 14 is engaged, does section 390(4)(a) as construed by KCC involve a breach of Article 14?
This turns on

(a) whether persons of no religious belief are, in the context of section 390 of the 1996 Act, in an
analogous position to persons holding religious beliefs: and

(b) (if they are), whether the legislative distinction drawn between them represents a proportionate
approach taken in pursuit of the legislative aim (i.e. justification and proportionality).

(3) If section 390(4)(a) is in breach of Article 14, is it possible to read and give effect to section 390(4)(a) in
a way which is compatible with the Convention rights?

(4) If so, should the decision of KCC prohibiting Mr Bowen from being included as a Humanist
representative within Group A of KCC's SACREE be quashed and/or declared as unlawful?

B.          The Legal Framework

5. All state funded schools in England are required to provide religious education for all registered pupils at
school. For maintained schools (i.e. those maintained by local authorities, rather than academies under the
_[Academies Act 2010), this requirement comes from statute: the 1996 Act, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8024-1GG0-Y97X-72SC-00000-00&context=1519360)_ _[School Standards and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYD0-TWPY-Y10M-00000-00&context=1519360)_
_[Framework Act 1998 ('the 1998 Act'), and the Education Act 2002 ('the 2002 Act').](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYD0-TWPY-Y10M-00000-00&context=1519360)_

6. Section 78(1) of the 2002 Act specifies the general requirements in relation to the curriculum in
maintained schools in England. It provides:

“The curriculum for a maintained school or maintained nursery school satisfies the requirements of this
_section if it is a balanced and broadly based curriculum which:_

_(a) promotes the spiritual, moral, cultural, mental and physical development of pupils at the school and of_
_society, and_

_(b) prepares pupils at the school for the opportunities, responsibilities, and experiences of life.”_

7. Section 79 of the 2002 Act requires local authorities and the governing bodies and headteachers of
maintained schools to exercise their functions with a view to ensuring that the curriculum in each
maintained school satisfies those requirements. The functions include “in particular” (by section 79 (4)),
“functions relating to religious education and religious worship” (in relation to schools, but not nurseries).

8. More specific requirements for the curriculum are set out in section 80(1), which requires that “the
_curriculum for every maintained school in England shall comprise a basic curriculum”. The basic curriculum_
includes four components: sex and relationships education, health education, the “National Curriculum”,
and religious education ('RE'). In relation to RE, there must be “provision for religious education for all
_registered pupils at the school (in accordance with such of the provisions of_ _[Schedule 19 to the School](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y198-00000-00&context=1519360)_
_Standards and Framework Act 1998 as apply in relation to the School).”_


-----

9. Schedule 19 of the 1998 Act provides that the required provision for religious education in those
maintained schools that are community schools, foundation or voluntary schools without a designated
religious character must comply with an “agreed syllabus”. By paragraph 1 (1), “agreed syllabus” has the
meaning given by section 375 of the 1996 Act, which provides:

_“(1) In this Act, “agreed syllabus” means a syllabus of religious education –_

_(a) Prepared before the commencement of this Act in accordance with Schedule 5 to the Education Act_
_1944 or after commencement in accordance with Schedule 31, and_

_(b) Adopted by the local authority under that Schedule_

_whether it is for use in all schools maintained by them or for use in particular such schools or in relation to_
_any particular class or description of pupils in such schools._

_(2) Every agreed syllabus shall reflect the fact that the religious traditions in Great Britain are in the main_
_Christian whilst taking account of the teaching and practices of other principal religions represented in_
_Great Britain.”_

10. As described by Warby J in Fox, the agreed syllabus is, therefore, the key document in determining
what is taught in RE in the relevant type of school.  The mechanisms for creating an agreed syllabus are
laid down by section 390 of and Schedule 31 to the 1996 Act.  The responsibility for producing the
syllabus is allocated to an occasional body which the local authority must establish, generally called an
agreed syllabus conference ('ASC').  Local authorities are also required to establish a permanent body
known as the SACRE.   Section 390(2) provides that, in England, the SACRE shall consist of such groups
of persons appointed by the authority as representatives ('representative groups') as are required by subsection 390(4).

11. Section 390(4) states, in relation to the position in England:

'The representative groups required by this subsection are
(a) …a group of persons to represent such Christian denominations and other religions and denominations
of such religions as, in the opinion of the authority, will appropriately reflect the principal religious traditions
in the area;

(b) …a group of persons to represent the Church of England;

(c) a group of persons to represent such associations representing teachers as, in the opinion of the
authority, ought to be represented, having regard to the circumstances of the area; and

(d) a group of persons to represent the authority.

12. Section 390(5) provides that where (as will be the case in England), a representative is required by
section 390(4)(b) (i.e. of the Church of England), the representative group required under section 390(4)(a)
shall not include persons appointed to represent the Church of England.

13. Pursuant to sections 390(3) and (7), the SACRE may also include co-opted members, but a co-opted
member is not a voting member. Furthermore, each representative group has a single vote.

14. Section 390(6) provides that the number of representative members appointed to any representative
group under subsection 390(4)(a) to represent each denomination or religion required to be represented
shall, so far as consistent with the efficient discharge of the group's functions, reflect broadly the
proportionate strength of that denomination or religion in the area.

15. Section 391 provides that the function of the SACRE is to advise the local authority on matters which
may include the methods of teaching, the choice of materials and the provision of training for teachers
connected with the religious education which is to be given in relation to an agreed or other syllabus.  One
of the powers vested in the SACRE is to require a review of any agreed syllabus for the time being adopted
by the local authority.  If required by the SACRE, the local authority has to convene a conference (i.e. the
ASC) for the purpose of reconsidering any agreed syllabus.


-----

16. Prior to 30 April 2021, England and Wales were governed by materially the same procedures (save in
relation to the existence of a Church of England representative group).  Following an issued (but
conceded) judicial review by a humanist in a Welsh local authority, the Welsh Cabinet Secretary for
Education wrote to the Welsh Local Authority Directors for Education.  The letter provided:

“to ensure compatibility with the _[Human Rights Act 1998 the provisions relating to the constitution of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_SACREs and ASCs in the 1996 Act are to be interpreted as permitting the appointment of persons who_
_represent holders of non-religious beliefs in the same way as they permit the appointment of persons who_
_represent holders of religious beliefs…However, we consider the non-religious beliefs adhered to by the_
_person to be appointed must be analogous to a religious belief, such as humanism.”_

17. This is, in substance, the interpretation that Mr Bowen contends is correct in the present proceedings.
In Wales, legislative reform has since taken place, and following amendments to section 390 the position in
relation to Wales is that the advisory council is on 'Religion, Values and Ethics' (section 390(1A)). The
equivalent of the representative group required by section 390(1)(a) is:

'a group of persons to represent –

_(i)              Christian denominations and other religions and denominations of such religions_

_(ii)              non-religious philosophical convictions'._

18. Thus, it is mandatory for SACRVEs in Wales to contain representatives of those holding non-religious
philosophical convictions, broadly reflective of the proportionate strength of that non-religious philosophical
conviction in the area. At the same time as this reform, the syllabus was overhauled to reflect greater
emphasis on non-religious values and ethics.

19. Before turning to consider the three issues in dispute, it is necessary to outline in a little more detail the
decision of the High Court in Fox.  In that case, the issue before the court was whether a statement within
the proposals for the content of GCSEs in religious studies at Key Stage 4 contained an error of law.  The
introduction to the subject content asserted that the scope of the subject content was consistent with the
requirements for the statutory provision of religious education in schools.  This was taken to mean that it
was being asserted that a properly specified GCSE would, without more, fulfil the state's legal obligation as
to the provision of religious education at Key Stage 4 ('the assertion').  However, Warby J (as he then
was) found that pursuant to articles 9 and A2P1 of the ECHR the state had a duty to take care that
religious education was conveyed in a pluralistic manner, and pursuant to section 3 of HRA 1998, the
Secretary of State's statutory obligation to provide 'religious education' in sections 78 and 80 of the 2002
Act was therefore to be interpreted as incorporating that Convention duty. In light of the fact that it was, in
fact, possible to properly specify a religious studies GCSE in accordance with the subject content in a
manner which excluded any study of non-religious beliefs and that, as such, this would not of itself satisfy
the state's obligation to provide religious education in a pluralistic manner, Warby J found that the assertion
was erroneous in law.

20. In coming to this conclusion, Warby J expressly considered and rejected the argument that the state
was required to afford 'equal treatment' to all religious and all non-religious views.  The heart of Warby J's
analysis is found at paragraph 39, in which he set out what he considered the full obligation upon the state
to be, upon which I have touched in the previous paragraph:

'Taken overall, the human rights jurisprudence establishes the following points of relevance to this claim. In
_carrying out its educational functions the state owes parents a positive duty to respect their religious and_
_philosophical convictions; the state has considerable latitude in deciding exactly how that duty should be_
_performed, having regard among other things to available resources, local conditions and, in particular, the_
_preponderance in its society of particular religious views, and their place in the tradition of the country;_
_thus, the state may legitimately give priority to imparting knowledge of one religion above others, where_
_that religion is practised or adhered to by a majority in society; but the state has a duty to take care that_
_information or knowledge included in the curriculum is conveyed in a pluralistic manner; subject to certain_
_threshold requirements, immaterial here, the state must accord equal respect to different religious_
_convictions and to non-religious beliefs; it is not entitled to discriminate between religions and beliefs on a_


-----

_qualitative basis; its duties must be performed from a standpoint of neutrality and impartiality as regards_
_the quality and validity of parents' convictions.'_

21. From this Mr Wolfe identifies, correctly, that the curriculum upon which the SACRE is specifically
constituted to advise must include non-religious worldviews. It is equally right, as Mr Giffin KC, on behalf of
KCC, emphasises (and which is not disputed), that it is not the case that the curriculum must be balanced
equally in this regard. Weighting towards Christianity, as opposed to other religions or philosophies,
remains acceptable in a country where that reflects the national history and traditions.

22. I should note that whilst pointing out that the decision is not binding on this Court, Mr Giffin does not
invite me to say that Fox was wrong in its result, or in the reasoning upon which the result was directly
based (although he reserves his position on that question were this case to proceed further).  Even if
invited to do so, I would have not have done so: in my respectful view, Fox was correctly decided.

C.        Factual Background

23. Mr Bowen has always held a worldview based on science, logic and rationality. He has become
actively involved in humanism in the last ten years, and became a committee member of Kent Humanists,
subsequently becoming its Chair. He has been a school speaker for Humanists UK for the last six years,
which is a trained and accredited role. Mr Bowen considers that it is important that children understand
worldview beliefs, and that those children who share such a worldview know what it is called.  Since 2019,
Mr Bowen has been a Co-convener for the Ashford Interfaith Group, which group includes Anglicans,
Catholics, Jews, Muslims, Jains, humanists and others.  Mr Bowen's predecessor as Chair of Kent
Humanists, Richard Norman, had previously had observer status on Kent SACRE. He had previously
asked to become a full voting member, but at the time the then existing (voting) members of the SACRE
had voted against accepting a humanist as a full member.

24. Humanists UK initially wrote to the chair of Kent SACRE on 22 August 2021 on Mr Bowen's behalf
requesting a position for a local humanist representative. The Chair of Kent's SACRE, Mr Manion,
responded swiftly on 24 August 2021, noting that Professor Norman had been an observer, and inviting his
successor to their meetings. Humanists UK responded on 27 August 2021 confirming that their request
was for full membership as opposed to mere observer status.

25. There followed some further exchanges between KCC and Mr Bowen directly, which Mr Bowen
regarded as unsatisfactory. He sent KCC a letter before action. As a result of that letter, KCC through its
solicitors responded on 16 November 2021, stating that not only had they not acted unlawfully, but also
that there had been no relevant legal decision. Following further correspondence, KCC agreed on 1
December 2021 to make a decision as to whether or not to allow a humanist full membership of the
SACRE, with voting rights. KCC decided on 17 June 2022 not to allow a humanist full membership of the
SACRE.

26. The Leader of the Council decided to:

'a) APPROVE the current [SACRE] membership without change;

_b)            NOTE that the current legislation prohibits the inclusion of Humanist representatives within_
_Group A of SACRE Membership;_

_…'_

27. Under 'Reasons for Decision', KCC stated:

'The Decision is necessary to clarify that KCC, as the responsible Local Authority for the Kent SACRE,
_maintains the membership arrangements in full compliance with the relevant national legislation. Specific_
_clarification of this point is required to address membership requests raised by the relevant groups._

_The decision will not prevent the inclusion of Humanists or other relevant groups within SACRE as_
_observers or non-voting co-optees (such arrangements for the welcoming of observers or co-optees are_
_matters for determination by SACRE, subject to advice from the Local Authority)._


-----

_…_

**_Equalities implications_**

_The relevant protected characteristic group is Religion and Belief. While this decision limits the role of_
_those seeking to represent Humanist views in terms of voting roles within SACRE, this arrangement is in_
_line with the legislative requirements. More broadly, this decision does not prohibit involvement of_
_Humanist representatives via co-optee and observer status._

**_Legal implications_**

_KCC is required under the_ _[Education Act 1996 to establish a SACRE. Membership arrangements and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6190-TWPY-Y0S0-00000-00&context=1519360)_
_requirements continue to be subject to this legislation and this decision confirms compliance with the_
_current legal position._

_Membership and other SACRE arrangements will be reviewed in the event of new legislation or new_
_guidance issued by the Department for Education.'_

28. It is not in dispute that a number of other Local Authorities have accepted humanists as full members
of Group A SACRE. It is said to be 66 according to the evidence of Mr Copson, Chief Executive of
Humanist UK, but the precise number does not matter. It not the majority of Local Authorities, it is about
40%.  There is no evidence before the Court on how those local authorities have gone about the selection
process, and whether or to what extent the local authorities have turned their mind to how to comply with
section 390(6). The Department for Education noted, when named as an interested party in these
proceedings by KCC, that it wished to adopt a neutral stance, submitting that it ought not be added as an
IP. It stated that it considered the application of section 390 and the selection of groups for SACREs is a
matter for Local Authorities, and that it was anecdotally aware that there is currently a divergence in the
approach of different LAs to this issue.

29. All GCSE specifications for Religious Studies must presently require students to demonstrate
knowledge and understanding of the fact that '

'-the religious traditions of Great Britain are, in the main, Christian

_-            religious traditions in Great Britain are diverse and include the following religions:_
_Christianity, Buddhism, Hinduism, Islam, Judaism and Sikhism, as well as other religions and non-religious_
_beliefs, such as atheism and humanism.'_

30. In Kent, the agreed syllabus in fact includes references to the teaching of humanism.

31. Finally, on the available evidence before the Court, the number of those in Kent who identify as
humanists can be, for the reasons set out below, regarded as materially 'significant'. According to Mr
Bowen, Humanists UK has 1,742 registered members and supporters in Kent. The 2021 Census data for
Kent identified, amongst others, the following numbers:

Christian 763716

Buddhist 8749

Hindu 19242

Jewish 2050

Muslim 25614

Sikh 12307

Humanist 293

Baha'i 82

32. Overall, there were over 40 other religions listed, from Animism (20 people) to Zoroastrian (67). In
addition to humanism, there were also 5 categories of other non-religious beliefs declared, from Agnostic
(809) to 'Realist' (1) Baha'i has been included in the list of religions specifically identified above because


-----

there are more declared humanists within Kent than those with Baha'i beliefs.  There is presently a
representative of the Baha'i religion selected to be part of KCC's SACRE Group A.  It should be
emphasised that Mr Bowen makes no complaint about the fact that Baha'i is represented, merely that
humanism is not represented.

D.        Is Article 14 engaged?

33. Article 14 enshrines the protection against discrimination in the enjoyment ofthe rights set forth in the
ECHR. It provides that “ The enjoyment of the rights and freedoms set forth in [the] Convention shall be
_secured without discrimination on any ground such as sex, race, colour, language, religion, political or_
_other opinion, national or social origin, association with a national minority, property, birth or other status.”_

34. It is well understood that article 14 confers no free-standing rights.  It is engaged only when the
subject-matter of the alleged discrimination falls with the ambit of some other Convention right.

35. In R (Stott) v Secretary of State for Justice [2018] UKSC 59, Lady Black set out a succinct summary of
the well-established approach to an article 14 claim:

_In order to establish that different treatment amounts to a violation of article 14, it is necessary to establish_
_four elements. First, the circumstances must fall within the ambit of a Convention right. Secondly, the_
_divergence in treatment must have been on the ground of one of the characteristics listed in article 14 or_
_other status. Thirdly, the claimant and the person who has been treated differently must be in analogous_
_situations. Fourthly, objective justification for the different treatment will be lacking. It is not always easy to_
_keep the third and the fourth elements entirely separate, and it is not uncommon to see judgments_
_concentrate upon the question of justification, rather than upon whether the people in question are in_
_analogous situations._

36. In the present case, there is no dispute about status.  There is, however, a dispute about ambit
(whether article 14 is engaged), and analogous situation and justification (whether the impugned measure
is in breach of article 14).

_Ambit_

37. Mr Wolfe contends that the ambit hurdle is a 'very low one'. Mr Giffin argues, and I agree, that it is not
necessarily helpful to focus on whether one might regard the test as low or high. Nonetheless, there is
agreement that the concept of ambit is a 'wide' one where it is not necessary for there to have been a
violation of the substantive right, and it does not need to be a right that the state was obliged to protect at
all.

38. As summarised by Lord Stephens in the Privy Council judgment in Royal Cayman Islands Police
Association and others v Commissioners of the Royal Cayman Islands Police Service & another [2022]
ICR 117

_'56.                            M v Secretary of State for Work and Pensions is the leading United_
_Kingdom authority in relation to the test as to what is “within the ambit” of a substantive provision of the_
_ECHR or of its Protocols. Lord Bingham said (at para 4):_

_“It is not difficult, when considering any provision of the Convention, including article 8 and article 1 of the_
_First Protocol ('article 1P1'), to identify the core values which the provision is intended to protect. But the_
_further a situation is removed from one infringing those core values, the weaker the connection becomes,_
_until a point is reached when there is no meaningful connection at all. At the inner extremity a situation may_
_properly be said to be within the ambit or scope of the right, nebulous though those expressions_
_necessarily are. At the outer extremity, it may not. There is no sharp line of demarcation between the two._
_An exercise of judgment is called for…I cannot accept that even a tenuous link is enough. That would be a_
_recipe for artificiality and legalistic ingenuity of an unacceptable kind.” (emphasis added)_

_A similar approach was adopted by Lord Nicholls at para 14 in which he stated:_


-----

_“… the more seriously and directly the discriminatory provision or conduct impinges upon the values_
_underlying the particular substantive article, the more readily will it be regarded as within the ambit of that_
_article; and vice versa. In other words, the ECtHR makes in each case what in English law is often called a_
_'value judgment'.”_

_At para 60 Lord Walker stated that there is no simple bright-line test and the Strasbourg case law does not_
_“lead to the conclusion that precisely the same sort of approach is appropriate, whatever substantive article_
_is in point.”_

39. At paragraph 59 of Royal Cayman, Lord Stephens then set out the approach to be taken:

'ambit should be considered by reference to a value judgment as to the proximity between the facts at
_issue to the core values which are engaged in respect of an employment-related dispute between an_
_individual and the state, as protected by section 9 of the Constitution (and by its equivalent, article 8_
_ECHR). The linkage must be more than tenuous for the facts at issue to be within the ambit of the_
_substantive provision.'_

40. A further and recent articulation of 'ambit' making this clear is found in the Supreme Court's judgment
in A&B v Criminal Injuries Compensation Authority [2021] 1 WLR 3746. This was a case in which the
claimants were brothers who had been convicted in Lithuania of burglary and theft and sentenced to terms
of imprisonment. Those convictions remained unspent when they were trafficked into the United Kingdom
and subjected to exploitation and abuse. They applied for compensation under the Criminal Injuries
Compensation Scheme (2012) as victims of **_modern slavery and trafficking. The Criminal Injuries_**
Compensation Authority refused their applications pursuant to an exclusionary rule relating to applicants
with certain convictions. The claimants sought judicial review.  Whilst ultimately concluding the refusal
was lawful, on the question of ambit the Supreme Court determined that the United Kingdom's voluntary
application of its Criminal Injury Compensation Scheme to victims of trafficking was sufficiently connected
to the core value of the protection of victims of trafficking under article 4 of the Human Rights Convention
so as to bring the operation of the Scheme within the 'ambit' of that article.

41. Dealing with the breadth of the concept of ambit, Lord Lloyd-Jones stated, relying upon the concurring
opinion of Judge Sir Nicolas Bratza, President of the ECtHR, in _Zarb Adami v Malta (2007) 44 EHRR 3_
stated as follows:

'Nevertheless, it is apparent that this is an area where the law has moved on and the attitude of the ECtHR
_has changed. While “the English courts have made rather heavy weather of the ambit point” (In re_
_McLaughlin, para 20 per Lady Hale) the ECtHR has taken a much more relaxed approach to the issue._
_This is apparent from Zarb Adami v Malta 44 EHRR 3. Mr Adami complained of discrimination on grounds_
_of sex in respect of his call for compulsory jury service. He relied, inter alia, on article 4 in conjunction with_
_article 14. The ECtHR held that although article 4(3)(d) excludes “any work or service which forms part of_
_normal civic obligations” from the prohibition in article 4(2) on “forced or compulsory labour”, the fact that a_
_situation corresponded to a normal civic obligation did not preclude the applicability of article 4 in_
_conjunction with article 14. The concurring judgment of the President, Judge Sir Nicolas Bratza, is_
_particularly illuminating. He observed at O-I7:_

_“The central question which arises is what constitutes 'the ambit' of one of the substantive articles, in this_
_case article 4. It has been argued that 'even the most tenuous links with another provision in the_
_Convention will suffice' for article 14 to be engaged. (See Grosz, Beatson and Duffy, The 1998 Act and the_
_European Convention, …, para C14-10.) Even if this may be seen as going too far, it is indisputable that a_
_wide interpretation has consistently been given by the Court to the term 'within the ambit'. Thus, according_
_to the constant case law of the Court, the application of article 14 not only does not presuppose the_
_violation of one of the substantive Convention rights or a direct interference with the exercise of such right,_
_but it does not even require that the discriminatory treatment of which complaint is made falls within the_
_four corners of the individual rights guaranteed by the article. This is best illustrated by the fact that article_
_14 has been held to cover not only the enjoyment of the rights that states are obliged to safeguard under_
_the Convention but also those rights and freedoms that a state has chosen to guarantee, even if in doing_
_so it goes beyond the requirements of the Convention (See eg the Belgian Linguistics Case (No 2)_


-----

_(Merits) (A/6) (1979-80) 1 EHRR 252, at para 9; Abdulaziz, Cabales and Balkandali v United Kingdom, …,_
_at para 71.) This would indicate in my view that the 'ambit' of an article for this purpose must be given a_
_significantly wider meaning than the 'scope' of the particular rights defined in the article itself. Thus, in the_
_specific context of article 4 of the Convention, the fact that work or service falling within the definition of_
_'normal civic obligations' in para 3 are expressly excluded from the scope of the right guaranteed by para 2_
_of that article, in no sense means that they are also excluded from the ambit of the article seen as a_
_whole.”_

42. Thus, in A&B, whilst there was no obligation upon the United Kingdom to introduce compensation
against trafficking, having done so there was a more than tenuous connection to the core value of the
protection of victims of trafficking so as to bring the scheme within the ambit of article 4. This aspect of
'ambit' has been described as a 'modality'.  Another example of modality is found in In Re McLaughlin

[2018] 1 WLR 4250in which Lady Hale recognised that the widowed parent's allowance was a positive
measure which, though not required by ECHR article 8, was a modality of the exercise of the rights
guaranteed by the Article. She concluded that it had 'a more than tenuous connection with the core values
_protected by article 8….There is no need for any adverse impact other than the denial of the benefit in_
_question'.   As similarly explained by Sir Terence Etherton MR in Smith v Lancashire Teaching Hospitals_
NHS Foundation Trust and Others [2018] QB 804 at [55]:

'The claim is capable of falling within Article 14 even though there has been no infringement of Article 8. If
_the State has brought into existence a positive measure which, even though not required by Article 8, is a_
_modality of the exercise of the rights guaranteed by Article 8, the State will be in breach of Article 14 if the_
_measure has more than a tenuous connection with the core values protected by Article 8 and is_
_discriminatory and not justified. It is not necessary that the measure has any adverse impact on the_
_complainant in a positive modality case other than the fact that the complainant is not entitled to the benefit_
_of the positive measure in question.'_

43. In summary, therefore, it is necessary for a claimant to establish a 'more than tenuous' connection
between the subject-matter of the case and the 'core values' of the article in question, and one way in
which a connection may be established is through 'modality'.

44. The two Convention rights relied upon by the Claimant are article 9 and A2P1.  There is considerable
overlap between the two in the circumstances of the present case given that, as Warby J pointed out in
Fox, A2P1 has been described as the "lex specialis" for article 9 in the education context: _Lautsi v Italy_
(2012) 54 EHRR 3 [59].  Indeed, Mr Giffin effectively relied upon the same general arguments (save for
one specific point relating to A2P1) when addressing his case on article 9 and A2P1.

45. Article 9 states:

_Article 9_

_Freedom of thought, conscience and religion_

1. _Everyone has the right to freedom of thought, conscience and religion; this right includes freedom to_
_change his religion or belief and freedom, either alone or in community with others and in public or private,_
_to manifest his religion or belief, in worship, teaching practice and observance._

2. Freedom to manifest one's religion or beliefs shall be subject only to such limitations as are prescribed
_by law and are necessary in a democratic society in the interests of public safety, for the protection of_
_public order, health or morals, or for the protection of the rights and freedoms of others._

46. The relevant core value here is one of tolerance and pluralism.  See for example Rabczewska v
Poland (2023) 76 EHRR 26:

'States have the positive obligation under Article 9 of the Convention of ensuring the peaceful coexistence
_of all religions and those not belonging to a religious group by ensuring mutual tolerance…These_
_obligations may required the adoption of measures to ensure respect for freedom of religion even in the_
_relations between individuals.'_


-----

47. See also Dogan v Turkey (2017) 64 EHRR 5 at [107-8]:

_'107.              The Court has frequently emphasised the state's role as the neutral an impartial_
_organiser of the exercise of various religions, faiths and beliefs, and has stated that this role is conducive to_
_public order, religious harmony and tolerance in a democratic society. As indicated above, where the views_
_in question attain a certain level of cogency, seriousness, cohesion and importance, the state's duty of_
_neutrality and impartiality excludes any discretion on its part to determine whether religious beliefs or the_
_means used to express such beliefs are legitimate. Religious and philosophical beliefs concern individuals'_
_attitudes towards religion, an area in which even subjective perceptions may be important in view of the_
_fact that religions form a very broad dogmatic and moral entity which has or may have answers to every_
_question of a philosophical, cosmological or moral nature._

_108.              In democratic societies the state does not need to take measures to ensure that_
_religious communities remain or are brought under a unified leadership. In that connection, state action_
_favouring one leader of a divided religious community or undertaken with the purpose of forcing the_
_community to come together under a single leadership against its own wishes would likewise constitute an_
_interference with freedom of religion. The role of the authorities in such a case is not to adopt measures_
_favouring one interpretation of religion over another or to remove the cause of the tensions by eliminating_
_pluralism, but to ensure that the competing groups tolerate each other.'_

48. A2P1 states:

'No person shall be denied the right to education. In the exercise of any functions which it assumes in
_relation to education and to teaching, the State shall respect the right of parents to ensure such education_
_and teaching in conformity with their own religious and philosophical convictions.'_

49. Mr Giffin argues that the core value of A2P1 is primarily that the state should not either indoctrinate
children in a way which is antithetical to their parents' beliefs, or stand in the way of parents themselves
teaching their children what they believe to be right.  He contends that the core values of A2P1 are all
about restraining, in the context of education and beliefs, the state's intrusion into the parent-child
relationship.  However, it is right that the core value goes beyond merely the restraint of indoctrination, as
explained in Efstratiou v Greece No 24095-24, 18 December 1996:

'28.  The Court reiterates that Article 2 of Protocol No. 1 (P1-2) enjoins the State to respect parents'
_convictions, be they religious or philosophical, throughout the entire State education programme (see the_
_Kjeldsen, Busk Madsen and Pedersen judgment cited above, p. 25, para. 51). That duty is broad in its_
_extent as it applies not only to the content of education and the manner of its provision but also to the_
_performance of all the "functions" assumed by the State. The verb "respect" means more than_
_"acknowledge" or "take into account". In addition to a primarily negative undertaking, it implies some_
_positive obligation on the part of the State (see the Campbell and Cosans judgment cited above, p. 17,_
_para. 37).'_

50. It is clear that before attracting the protection of Article 9, the thought, conscience and religion must
attain a certain level of cogency, seriousness, cohesion and importance.  Humanist beliefs undoubtedly
qualify in this regard.  Indeed, as already noted in Harrison at [22], humanism has already been afforded
equal status to the major world religions in many aspects of public life in the United Kingdom.  Once this
threshold has been satisfied, the state's duty of neutrality and impartiality is incompatible with any power on
the state's part to assess the legitimacy of holding religious beliefs or the ways in which those beliefs are
expressed or manifested. However, as explained in Eweida v United Kingdom (2013) 57 EHRR:

'Even where the belief in question attains the required level of cogency and importance, it cannot be said
_that every act which is in some way inspired, motivated or influenced by it constitutes a 'manifestation' of_
_the belief.  Thus, for example, acts or omissions which do not directly express the belief concerned or_
_which are only remotely connected to a precept of faith fall outside the protection of art.9(1).  In order to_
_count as a 'manifestation' within the meaning of article 9, the act in question must be intimately linked to_
_the religion or belief. An example would be an act or worship or devotion which format part of the practice_
_of a religion or belief in a generally recognised form. However, the manifestation of a religion or belief is_


-----

_not limited to such acts; the existence of a sufficiently close and direct nexus between the act and the_
_underlying belief must be determined on the facts of each case.'_

51. Mr Giffin contends, rightly, that when it comes to assessing the ambit of article 9 for the purposes of an
article 14 claim, one should first consider whether the allegedly discriminatory measure represents a
means by which that the state seeks to allow individuals to express their beliefs freely, or whether the
alleged discrimination is of a kind which has a sufficiently direct impact upon the expression of beliefs.  He
argues that representative membership of SACRE within Group A is neither a manifestation of belief, nor
even tenuously linked to any such manifestation.

52. On the spectrum which can be ascertained from the authorities, Mr Giffin argues that the present case
is far removed from those where discriminatory acts have been established as being within the ambit of
article 9.  In this context, both parties rely upon the case of Dogan. Mr Giffin characterises it as a true
illustration of what ECHR and article 9 values are really about. He points to the conclusion of the ECtHR
that the extent of systematic disadvantage and inhibitions on the manifestation of the Alevi faith to which
the community was subject by the Turkish state was existential, impacting the survival and development of
the faith itself.  This, he contends, could not be further removed from the present one. Mr Wolfe points
out, however, that these aspects of the Dogan decision relate to the claim for direct interference with the
right to freedom of religion as guaranteed by article 9, and are not therefore directly relevant to the present
Article 14 claim.  The basis of the article 14 claim centred upon the provision by the Turkish state of a
'denominational public service in the religious sphere' centred on the Sunni understanding of Islam. No
equivalent existed for the Alevi community. The contention was therefore that although states were not
obliged to take positive measures in that regard, the Turkish State had decided of its own accord to provide
a public religious service to one particular faith, while refusing the same favourable treatment to other
beliefs and religions.  This therefore fell within the ambit of article 9. Mr Wolfe drew a direct comparison:
there was no obligation upon the state to set up a SACRE for the purposes of advising local authorities
upon religious education, but having done so, it was required to do that in a non-discriminatory way.  Mr
Wolfe submitted that the present case, as with Dogan, was a classic example of ambit being established
through modality.

53. In my judgment, the very structure by which the state in England has determined that the specific
syllabus and methods of teaching for religious education should be decentralised to local authorities is a
recognition of the importance of religious education being reflective of the make up of that local community.
The aim, and effect, of this is that the content and emphasis within religious education can (for example) be
different in Bradford, where the local community is approximately 30% Muslim, to the teaching of religious
education in Bideford, where it is less than 1%.  This approach, in which the SACRE forms a central role,
is fundamentally about tolerance and pluralism in society, the core value of article 9. Therefore, it is plain
that the ability to be a representative of a particular relevant belief on a SACRE is (at the very least) more
than tenuously connected with that core value, so as to bring the alleged discrimination through the
prevention of membership of SACRE within the ambit of article 9.

54. In argument, Mr Giffin was asked whether if, hypothetically, section 390(4)(a) had defined the groups
within SACRE as they are presently formulated but with the additional specific stipulation of the exclusion
of Catholics from Group A an article 14 claim brought by a Catholic for discrimination would in these
circumstances be within the ambit of article 9. He conceded it would be, but sought to distinguish the
hypothetical example from the present case (as he therefore needed to). Mr Giffin did so by arguing that a
potential distinction existed with the required analysis between consequences and reasons, drawing upon
the judgment in Royal Cayman. At paragraphs 66 to 73 the judgment contains a discussion of Denisov v
Ukraine (Application No 76639/11 (unreported) 25 September 2018, ECtHR (GC).  This related to a
complaint brought under article 8 ECHR that the claimant's right to respect for his private life had been
violated by his dismissal as President of the Administrative Court of Appeal in Ukraine, because his career,
reputation and social and professional relationships had been irreparably damaged.  The ECtHR
considered 'private life' in employment related scenarios and concluded that employment-related disputes
were not per se excluded from the scope of 'private life' within the meaning of article 8 ECHR, stating:


-----

'there are two ways in which a private-life issue would usually arise in such a dispute: either because of the
_underlying reasons for the impugned measure (…the reason-based approach) or – in certain cases –_
_because of the consequences for private life (….the consequence-based approach).'_

55. The ECtHR considered the reason-based approach and cited examples.  As can be seen from the
examples, the 'reason-based approach' considers whether the reason for the dismissal (in an employment
context) is sufficiently linked with the complainant's private life within the meaning of article 8 (examples
being sexual orientation, or particular targeted close personal relationships). The 'consequence-based
approach' examines whether the impugned measures have sufficiently serious negative consequences for
the applicant's private life.

56. Mr Giffin says that the reasoning, whilst not articulated in the context of Article 9, may be applied
analogously.  When looking at the consequence-based approach, Mr Giffin maintains that neither the
Catholic nor the humanist would be able to claim a sufficiently non-tenuous link with the manifestation of
their belief to establish that the act complained of is within the ambit of Article 9.  In terms of a reasonsbased approach, however, Mr Giffin argued that (unlike the present case), the exclusion of Catholics could
only ever have been driven by discriminatory intentions (in contrast to the exclusion of humanists, which he
argues is justified for the reasons considered later).

57. Mr Giffin accepted that if one only looked at 'ambit' through the lens of consequences, the Catholic and
the humanist would be in the same boat (exclusion from SACRE Group A) and there should, without more,
be no rational basis for saying that the Catholic's claim was in the 'ambit' of Article 9. However, he argued
that it was when looking at ambit through the lens of reasons that a distinction can be found.

58. In light of my determination that the creation and operation of SACREs is more than tenuously linked
with the core values of article 9, it is not necessary for me to determine whether, in the context of an article
9 claim (rather than an employment related article 8 claim) an analysis by reference to 'reasons' or
'consequence', is particularly illuminating. In deference to the argument, however, I observe merely that
these could be considered tools by which one might seek to illustrate a sufficient connection with the core
values of a particular article, the relevance of which is likely to be dependent upon the circumstances of the
particular claim.  In the present case, however, I note that the 'reason' for the decision not to consider Mr
Bowen for membership of Group A is fairly and squarely the fact that he has a non-religious belief system
rather than a religious one.  Looked at through the 'reason' lens, this is in the present case another way by
which one can safely conclude that there is a sufficient connection between the alleged discriminatory act
and the core values of article 9 so as to bring it within its ambit for the purposes of Article 14.

59. In relation to A2P1, similar reasoning applies.  In my judgment the SACRE was created by the state
as part of the function it has assumed in relation to education and teaching.  As such it must operate
SACREs without discrimination in order to respect the right of parents to ensure such education and
teaching is in conformity with their own religious and philosophical convictions.  Mr Giffin argues that this
end is achieved by other legislative provisions and guidance, including the statutory requirement for a
balanced and broadly based curriculum, and statutory provisions conferring the rights of withdrawal. It is
certainly correct that the SACRE is not the only way in which the state seeks to act in conformity with
A2P1, but it is very clearly an important part of the overall state machinery put in place to achieve a
balanced religious education curriculum. A claim that it is being operated in a discriminatory way is more
than tenuously connected with A2P1 so as to bring such a claim within its ambit for the purposes of Article
14.

60. The only additional argument advanced by Mr Giffin in relation to A2P1 is by analogy with R
(Williamson) v Secretary of State for Education and Employment [2005] 2 AC 246. The case concerned
teachers at, and parents who sent their children to, independent private schools specifically established to
provide Christian education based on biblical observance. As part of the regime, and as agreed with the
parents, mild corporal punishment was used, and the claimants contended that it was part of their
fundamental Christian beliefs that such measures could be adopted. The teachers claimed that section
548 of the 1996 Act which banned corporal punishment in all schools infringed their rights under A2P1.
The claim failed because the right protected by the second sentence of the article is a right of the parents,


-----

not the teachers.  The teachers therefore had no claim under the article.  By analogy, Mr Giffin argues
that Mr Bowen cannot rely upon A2P1 as he is not (in the present context) a parent.  However, as Mr
Wolfe points out, in Williamson the teachers were bringing a direct claim for interference of their rights
under A2P1.  That is plainly a different question to whether a discrimination claim under article 14 falls
within the ambit of A1P2.  In relation to that question the fact that Mr Bowen is not a parent is not fatal to
the claim.

61. In the circumstances, I consider that article 14 is engaged and the claim that it is discriminatory to
refuse to permit Mr Bowen's membership of Group A on grounds that he holds non-religious beliefs is
within the ambit of both article 9 and A2P1.

E.        Does s390(4)(a) as construed by KCC involve a breach of Article 14?

62. Once ambit and status are satisfied, as is the case here, the essential question for the court is whether
the alleged discrimination 'can withstand scrutiny', in the words of Lord Nicholls of Birkenhead in R
(Carson) v Secretary of State for Work and Pensions [2006] 1 AC 173 at [3]. As he observed, sometimes
the answer to this question is plain. He continued:

'There may be such an obvious, relevant difference between the claimant and those with whom he seeks
_to compare himself that their situations cannot be regarded as analogous. Sometimes, where the position_
_is not so clear, a different approach is called for. Then the court's scrutiny may best be directed at_
_considering whether the differentiation has a legitimate aim and whether the means chosen to achieve the_
_aim is appropriate and not disproportionate in its adverse impact.'_

63. As is often the case, the issues relating to analogous situation and justification overlap (see _Re_
_McLaughlin_ at [24]).  A number of the points raised by Mr Giffin to argue that there is no analogous
situation in the present case are relevant to his arguments on justification. Nevertheless, in the first
instance the issues will be considered sequentially.

64. Mr Bowen argues that, as a humanist, he has a right to be considered for membership of Group A of
SACRE. The specific question to be asked is whether persons without religious beliefs are in an
analogous position to those holding religious beliefs in the context of and for the purposes of Group A
membership.  In order to analyse this, it is necessary to consider the nature and purpose of SACRE, and
of the role of Group A within SACRE.

65. Mr Giffin contends that Group A is, within the scheme of the legislation, intended to represent faith
groups.  Group B is intended specifically to represent the Church of England.  Groups C and D are, by
contrast to A and B, intended to be 'secular', representing teaching associations and a group representing
the local authority respectively.  The local authority itself has the responsibility for ensuring that, in the
teaching of religious education, plurality is respected.  Having defined the groups this way, Mr Giffin then
contends that the Court should ask whether, in the context of a body which has been split in a manner
defined by those representing spiritual concerns (Groups A and B) and those representing secular
concerns (Groups C and D), someone who is an adherent to and represents a belief that is explicitly
secular is in an analogous position to a person of faith for the purposes of membership of Group A.

66. The fundamental difficulty with this argument is that it entirely mischaracterises the nature of the
Groups within the SACRE, and as such draws a false comparison.  The purpose of the SACRE is, as set
out in section 391 of the 1996 Act, to advise the local authority on the religious education to be given in
accordance with an agreed syllabus. This advice will broadly fall into two categories: the content of the
syllabus and the implementation of the teaching of that syllabus.  In other words, what is taught and how it
is taught.  It is clear, in my judgment, that the primary concern of Groups A and B is, broadly speaking,
the content of religious education and the primary concern of Groups C and D is, broadly speaking, the
implementation of religious education within the area. Of course, this does not mean that in practice
members of each group are somehow confined in SACRE meetings to expressing views solely on matters
of content or implementation respectively; it is merely to say that the SACRE as a whole is sensibly
structured so as to constitute a range of suitably qualified views for the purposes of addressing both
content and implementation of religious education. The particular expertise on content generally comes


-----

from Groups A and B, and the particular expertise on implementation generally comes from Groups C and
D.

67. It is therefore also wrong to characterise the members of Groups C and D, as Mr Giffin does, as those
providing the SACRE with a 'secular perspective'. The perspective of Group C is intended to be the view
of associations of teachers. Their personal beliefs (be they religious or non-religious) are not relevant to
their representative role in the SACRE. As Mr Giffin accepted, they could be entirely made up of followers
of various religious faiths. The same applies for those representing local authorities.  Indeed, the fact that
the role of those in Group D is generally not to advise on content (whether from a secular perspective or
otherwise) is demonstrated by the fact that the Group D is not entitled to a vote when it comes to
determining whether the content of the agreed syllabus should be reviewed in accordance with section
391.

68. Where a religious education curriculum is wholly based on the teaching of religions, with a weighting
towards Christianity and the Church of England in particular, it would be entirely unsurprising for the
composition of Groups A and B to reflect that. However, it is plain from Fox that a religious education
[curriculum must, in order to be compliant with the HRA 1998,cover more than religious faith teaching.  The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
content of religious education teaching must include, at least to some degree, the teaching of non-religious
beliefs (such as humanism).  In this context, when seeking to consider the 'analogous situation' criteria, it
is plainly wrong, and circular, to define Group A solely by reference to holders of religious based beliefs.

69. I am not persuaded by Mr Giffin's suggestion that Group A is to be taken as 'faith only' by reference to
the fact Group A shares a single vote.  There is no logical basis to think, in terms of advising upon the
provision of religious education which is to include both religious and non-religious beliefs, there should be
a particular, defining community of interests based on belief. For example, taking the census data for Kent,
it seems to me implausible that there is the necessary community of interest between the Satanist (there
are 145 in Kent) and the Buddhist (8749 people) so intrinsic that it should define those entitled to
participate in Group A. The SACRE voting system clearly requires those with disparate belief systems to
share a single vote when it comes to determining whether to require the local authority to convene the
ASC; including the possibility that the constituency of Group A may include a humanist does not change
the fundamental characteristic of the group which is derived, as set out above, from its function as a group
to advise upon the content of religious education in the area.

70. Analysed properly, when looking at membership of a group the purpose of which is to advise upon the
content of a religious education syllabus, it is obvious that all people who are holders of belief systems
appropriate to be included within that syllabus are in an analogous position.  It is in my view clearly
discriminatory to exclude someone from SACRE Group A solely by reference to the fact that their belief,
whilst appropriate to be included within the agreed syllabus for religious education, is a non-religious,
rather than a religious, belief.

71. It is therefore necessary to consider the question of justification.

72. Mr Giffin makes a number of points justifying the exclusion of those with non-religious beliefs from
Group A in addition to the points made relating to analogous position.  The further points can be
summarised as follows:

(1) As a matter of principle:

(a) the approach to religious education in schools lies in the area of general social policy and the
questions raised are sensitive and controversial ones;

(b) this is not 'suspect ground' territory;

(c) the composition of SACREs has been specifically considered by Parliament;

(d) the margin of discretion accorded to the judgment of Parliament is a wide one.

(2) The policy is justified (given the wide margin of discretion) because:


-----

(a) There is a practical difficulty of determining which non-religious beliefs qualify for representation and/or
what people might be properly considered as representative of any particular non-religious belief;

(b) Individuals may be adherents to more than one non-religious belief system;

(c) Both of the foregoing cause difficulties in the local authority's ability to comply with the proportionate
representation requirement of section 390(6).

73. Starting with the discretion which should be accorded to the judgments made by Parliament, and the
related question of what use the Court should make of the parliamentary debate material placed before me
by KCC, both parties rely upon the single judgment of Lord Reed (with which all the other members of a
seven member Court agreed) in the recent Supreme Court decision of R(SC) v Secretary of State for Work
[and Pensions [2021] UKSC 26. The case related to the changes introduced by the Welfare Reform and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JCG-1JH1-DYCN-C2XJ-00000-00&context=1519360)
_[Work Act 2016 by which a family making a new claim would not be awarded child tax credit for a child born](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JCG-1JH1-DYCN-C2XJ-00000-00&context=1519360)_
after 6 April 2017 if they were already receiving child tax credit for two or more children, subject to certain
exceptions.  It was claimed that this measure unjustifiably discriminated against adult claimants as
women, as compared with men; and against the child claimants, as compared with adults or other children
in smaller households.  The second and third preliminary issues of principle Lord Reed considered before
turning to their application in that particular case were (a) whether the approach to proportionality under
article 14 set out in Humphreys v Revenue and Customs Comrs [2012] 1 WLR 1545('Humphreys'), and
followed in several later cases, to the effect that the court will respect the policy choice of the executive or
the legislature in relation to general measures of economic or social strategy unless it is manifestly without
reasonable foundation, accurately reflects the approach of the ECtHR and should continue to be followed;
and (b) the use which can be made of Parliamentary debates and other Parliamentary material when
considering whether primary legislation is compatible with Convention rights, having regard to
Parliamentary privilege. Both of these issues are of relevance in the present case.

74. In relation to the first of these issues, Lord Reed commenced by identifying that it was well settled in
European jurisprudence that states have 'a margin of appreciation in assessing whether and to what extent
_differences in otherwise similar situations justify a different treatment' and that 'the scope of this margin will_
_vary according to the circumstances, the subject matter and the background'.  He then identified that there_
was no existing systematic analysis of the relevant factors or an explanation of how they interact, but
considered it useful to consider that there were a range of factors which tend to heighten, or lower, the
intensity of the review of the decision required by the court.  He continued at [100]:

'One particularly important factor is the ground of the difference in treatment. In principle, and all other
_things being equal, the court usually applies a strict review to the reasons advanced in justification of a_
_difference in treatment based on what it has sometimes called suspect grounds of discrimination. However,_
_these grounds form a somewhat inexact category, which has developed in the case law over time, and is_
_capable of further development by the European court. Furthermore, a much less intense review may be_
_applied even in relation to some so-called suspect grounds where other factors are present which render a_
_strict approach inappropriate, as some of the cases to be discussed will demonstrate…._

_[…]_

_These cases illustrate three points of wider significance. The first is that the court's statements that “very_
_weighty reasons” are required to justify a difference in treatment on a particular ground do not necessarily_
_exclude the possibility that a relatively wide margin of appreciation, and a correspondingly less intense_
_standard of review, may nevertheless be appropriate in particular circumstances, as for example where_
_historical inequalities are being addressed in pace with changes in social attitudes. The second is that the_
_court's case law evolves in the light of the development of common standards among the contracting_
_states. The third is that the court has moved over time towards explaining the need for weighty reasons to_
_justify certain grounds of differences in treatment in terms of the link between those grounds and problems_
_of stereotyping, stigma and social exclusion, which prevent participation in society on an equal footing to_
_others._


-----

75. In the case before me, Mr Giffin urges that this is not a case where the grounds of difference in
treatment are linked with problems of stereotyping, stigma and social exclusion. Mr Wolfe contends the
opposite, and that the discrimination in issue in this case is one of the 'suspect' categories where 'weighty
reasons' may generally be thought necessary to justify the approach taken.  Lord Reed dealt specifically
with the application of these issues in the context of an article 9 claim at [109]-[110]. He observed:

_'109.            The court has generally adopted a strict approach also to differences in treatment on_
_the ground of religious belief, in the light of the importance of the right enshrined in article 9 in guaranteeing_
_the individual's self-fulfilment. It has repeatedly said that a distinction based essentially on a difference in_
_religion alone is not acceptable : see, for example, Vojnity v Hungary [2013] 2 FCR 495, para 31. The_
_principle does not, however, appear to be as absolute as that language might suggest. In Vojnity, the court_
_went on to say at para 36 that such treatment will only be compatible with the Convention if very weighty_
_reasons exist. The court described its approach as being similar to that applied in the context of differences_
_in treatment on the basis of sex, birth status, sexual orientation and nationality._

_110.            The court has, however, taken a less strict approach in some cases concerned with_
_discrimination on the ground of religious belief, where other factors were relevant. …'_

76. Lord Reed then identified the example of Eweida, in which the restriction of wearing of necklaces by
staff handling patients was, whilst an interference with the nurse's freedom to manifest her religion, justified
by the 'importance of the reason for it' (clinical safety). The second complaint in Eweida related to a
registrar of births, deaths and marriages who had a religious objection to same-sex unions and lost her job
after refusing to register them. The court observed that it 'generally allows the national authorities a wide
_margin of appreciation when it comes to striking a balance between competing Convention rights', and held_
there had been no violation of article 14.

77. At paragraph 115, Lord Reed then summarised five general points, the first, second and fifth of which
are of potential relevance in the present case:

_'(1) One is that the court distinguishes between differences of treatment on certain grounds, discussed in_
_paras 100—113 above, which for the reasons explained are regarded as especially serious and therefore_
_call, in principle, for a strict test of justification (or, in the case of differences in treatment on the ground of_
_race or ethnic origin, have been said to be incapable of justification), and differences of treatment on other_
_grounds, which are in principle the subject of less intensive review._

_(2) Another, repeated in many of the judgments already cited, sometimes alongside a statement that 'very_
_weighty reasons' must be shown, is that a wide margin is usually allowed to the state when it comes to_
_general measures of economic or social strategy. That was said, for example, in Ponomaryov, para 52, in_
_relation to state provision of education; in Schalk, para 97, in relation to the legal recognition of same-sex_
_relationships; in Biao v Denmark, para 93, in relation to the grant of residence permits; in Guberina, para_
_73, in relation to taxation; in Bah v United Kingdom, para 37, in relation to the provision of social housing;_
_in Stummer v Austria, para 89, in relation to the provision of a state retirement pension; and in Yigøit v_
_Turkey, para 70, in relation to a widow s pension. In some of these cases, the width of the margin of_
_appreciation available in principle was reflected in the statement that the court 'will generally respect the_
_legislature s policy choice unless it is 'manifestly without reasonable foundation'  : see Bah, para 37, and_
_Stummer, para 89._

_…_

_(5) Finally, there may be a wide variety of other factors which bear on the width of the margin of_
_appreciation in particular circumstances. The point is illustrated by such cases as MS v Germany,_
_Ponomaryov and Eweida v United Kingdom.'_

78. At paragraphs 117 to 142, Lord Reed explored the European jurisprudence dealing with application of
the term 'manifestly without reasonable foundation', noting in paragraph 142 that the breadth of the margin
of appreciation would be fact specific and that, in the context of article 14, the fact that a difference in
treatment is based on a 'suspect' ground is particularly significant, and in these cases 'strict scrutiny' may
be required At paragraphs 143 to 162 Lord Reed then summarised the way in which domestic courts


-----

had sought to apply an analogous approach to the concept of 'the margin of appreciation' which is specific
to the European Court.  A key reason for an equivalent 'discretionary area of judgement' (R v Director of
Public Prosecutions, Ex p Kebilene [2000] 2 AC 326, 380) is, as emphasised in argument before me by Mr
Giffin, the need for domestic courts to respect the separation of powers between the judiciary and the
elected branches of government.  At [144] Lord Reed explained:

_'They therefore have to accord appropriate respect to the choices made in the field of social and economic_
_policy by the Government and Parliament, while at the same time providing a safeguard against_
_unjustifiable discrimination. As Lord Neuberger of Abbotsbury observed in R (RJM) v Secretary of State for_
_Work and Pensions [2009] AC 311, para 57, “there will come a point where the justification for a policy is_
_so weak, or the line has been drawn in such an arbitrary position, that, even with the broad margin of_
_appreciation accorded to the state, the court will conclude that the policy is unjustifiable”'_

79. At paragraph 146, Lord Reed then identifies that the administrative law test of unreasonableness is
generally applied in contexts such as economic policy and social policy with considerable care and caution,
and that the same is true of the Convention test of proportionality. Both tests have to be applied in a way
which reconciles the rule of law with the separation of powers. Thus, as identified at paragraph 161,
matters raising sensitive moral or ethical issues will afford substantial weight to the primary decision-maker
(i.e. in the present circumstances, the legislature), such that the test 'manifestly without reasonable
_foundation' may well be appropriate.  The Court must at all times be extremely conscious of the risk of_
undue interference by the courts in the sphere of political choices, which risk can only be avoided if the
courts apply the principle of proportionality in a manner which respects the boundaries between legality
and the political process (see [162]).

80. In the present case, it is plain that discrimination on the basis of faith is, indeed, one of the types of
differences of treatment which are regarded as especially serious, and therefore call, in principle, for a
strict test of justification.  However, it is equally plain that the provision of religious education (now
including, for the avoidance of doubt, the inclusion of at least some teaching of non-religious belief
systems) is a measure of social strategy and one in relation to which a legislature will generally be afforded
a wide margin in respect of its policy choice.  I consider that, whilst a matter of real significance as it
touches upon the important rights protected by article 9 and A2P1, I should nevertheless be satisfied that
the policy choice is manifestly without reasonable foundation if I am to consider it to be disproportionate
and without justification.

81. As regards the use of parliamentary material, paragraphs 163 to 185 of SC contain the discussion by
Lord Reed of the prior case law, and underlying principles relating to, the use of Parliamentary debates and
other Parliamentary material, having regard to Parliamentary privilege.  From this I extract the following
statements of principle relevant to the determination of issues in the present case:

(1) considerable care has to be taken when considering the use of Parliamentary materials in connection
with the Human Rights Act (see [173]);

(2) the fact that Parliament can be seen to have been aware of the various interests involved, and can
therefore be taken to have considered how a balance should be struck between them, can legitimately be
taken into account in assessing the proportionality of legislation (see [178]);

(3) the degree of respect which the courts should show to primary legislation will depend on the
circumstances, which circumstances may include whether it is relatively recent or dates from an age with
different values from the present time, and whether Parliament can be taken to have made its own
judgment of the issues which are relevant to the court's assessment.  If so, the court will be more inclined
to accept Parliament's decision, out of respect for democratic decision-making on questions of political
controversy (see [180]);

(4) in deciding whether the difference in treatment resulting from legislation which is challenged as
discriminatory has a reasonable justification, it may be a relevant factor in the court's assessment if it can
be inferred that Parliament formed a judgment that the legislation was appropriate notwithstanding its
potential impact upon interests protected by Convention rights (see [182]);


-----

(5) if there is no indication that the issue was considered by Parliament, that factor is simply absent from
the assessment (see [182]);

(6) the court should simply identify whether matters relevant to compatibility were raised, and should not
assess the adequacy or cogency of the consideration of them nor treat the absence or poverty of debate
as a reason supporting a finding of incompatibility (see [183-4]).

82. I will not in this judgment set out the various exchanges from the Parliamentary debates to which I was
taken in argument by Mr Giffin, but instead will set out the evidence from Amy Tschobotko, a solicitor
instructed by KCC. Ms Tschobotko summarises the evidence and extracts the key quotes upon which Mr
Giffin bases his submission that the issue before me has been considered by Parliament. As such, he
contends that, in accordance with the foregoing principles, this should be a factor weighing in favour of
considering the policy choice proportionate:

'18.At various points in the history of the legislation there has been specific parliamentary discussion as to
_whether the agreed syllabus conference should contain representatives of non-religious viewpoints. For_
_example, this was a matter raised in the House of Commons committee stage of the Education Bill on 5_
_April 1944, when Mr Butler as President of the Board of Education responded by saying that the purpose of_
_Schedule 5 was to provide for an agreed syllabus of religious instruction, and that its object would not be_
_achieved by “a disagreed anti-religious syllabus which does not give religious instruction.” (See Exhibit_
_AT3.)_

_19.              Similarly, at the House of Lords report stage of the Education Reform Bill on 21 June_
_1988, there was an amendment (tabled by Lord Sefton of Garston) to require a curriculum which would_
_promote “an understanding of various religious beliefs and living beliefs such as humanist and secular_
_points of view, but does not promote any particular religion or belief.” The Minister opposed a variety of_
_amendments on the ground that the earlier amendments proposed by the Bishop of London and by the_
_government “form a coherent package and fit within the legislative framework already set out in the 1944_
_Act”, and that attempted revisions “would unravel the careful agreement reached with all the interests and_
_Churches.” (See Exhibit AT4.)_

_20.              On 21 June 1993, government amendments were tabled at the House of Lords report_
_stage of the Education Bill, which contained the “proportionate strength” provisions already mentioned. It_
_appears that they represented the government's response to amendments tabled by Baroness Cox at_
_committee stage on 27 April 1993, when the Minister asked Baroness Cox not to press her amendments_
_on the assurance that government amendments would be brought forward. In the report stage debate_
_issues were raised, principally by Lord Dormand of Easington and by Lord Sefton, as to the non-inclusion_
_on SACREs of people without a religious faith. They asked whether the government would be prepared to_
_table amendments to achieve this. The Minister (Baroness Blatch) indicated that the government did not_
_support this approach. She said amongst other matters that the subject-matter of the relevant provisions_
_was religious education, which she described as “education that seeks to expand . . . knowledge not only_
_of . . . Christianity – but also of other principal religions of the country and in particular of local areas”, and_
_that humanism and what she referred to as other “'isms' of all and sundry . . . humanism, agnosticism,_
_atheism, communism, fascism or anything similar” were not religions and were therefore not related to this_
_subject matter. She also said this_

_“Atheism, agnosticism and humanism are not religions. Therefore, it would be very difficult to include them_
_in proportionate representation on the SACRE committee or to include any of them as one of the principal_
_religions to be studied.”_

83. KCC also rely upon the fact that a Private Member's Bill called the Education (Non-religious
Philosophical Convictions) Bill was introduced into the House of Lords by Baroness Burt of Solihull on 14
June 2022.

84. It is quite clear to me from reviewing the Parliamentary material in full that the entire context of the
debate at the time was that religious education was to be confined to teaching Christianity and other
principal faiths.  It is right that there was consideration of whether that should be the case, but that is an


-----

entirely different issue from whether, once it is recognised (as it is now, in a way it was not in 1993 and
earlier) that the curriculum _must include some elements of non-religious beliefs, a SACRE's constitution_
should be capable of including representatives of those non-religious beliefs which are appropriate to be
included in the curriculum.  Therefore, the parliamentary material is not in my judgment of any relevance to
the issue I have to decide.

85. Against this background, I turn to the issue of whether the discrimination I have identified is
proportionate and justifiable. Notwithstanding the wide margin I consider must be afforded to the
legislature, I do not consider that any of the grounds identified can remotely justify the discrimination.

86. First, Mr Giffin points to the practical difficulty of determining which non-religious beliefs qualify for
representation. However, whilst in some circumstances this might no doubt be a difficult and sensitive
question, the local authority and SACRE already have to grapple with the equivalent question of which
non-religious beliefs should be included within the overall religious education provision.  Mr Giffin relies, by
way of illustration, on the government's position explained by Lord Agnew of Oulton then serving as a
parliamentary under secretary of state at the Department of Education, in the House of Lords on the
Commission of Religious Education's September 2018 Report.  The Commission had proposed renaming
RE as 'religion and worldviews'.  Lord Agnew said:

'We have decided that now is not the time to implement the commission's ambitious recommendations
_radically to reform religious education […]_

_One of the commission's key recommendations is to change legislation so that all state-funded schools_
_have to deliver the national entitlement on religion and worldviews. Reworded legislation would therefore_
_be extended to encompass non-religious worldviews. Many teachers already cover aspects of worldviews_
_in their RE lessons. Both GCSE and A level content specifications include reference to non-religious views._
_But the potential scope of what could be considered a worldview is very wide. Agreeing precisely what_
_should be taught as part of a national entitlement would be fraught with difficulty._

_The commission's report suggests that existentialism and Confucianism are examples of suitable non-_
_religious worldviews as they each make ontological and epistemological claims. This illustrates how_
_defining worldviews and then deciding those worthy of study is complex. There is a risk that religious_
_education is diluted in an attempt to embrace many other strands of thinking.'_

87. Mr Giffin relies upon this to demonstrate the purportedly 'radical' outcome of construing section 390 as
other than in line with the normal usage of the words, and as evidence of the complexity of the practical
problems that lie behind the policy choice embedded in the legislation as it presently stands.  However,
whether or not it is 'fraught with difficulty', it is already the position that determining 'what ought to be
_taught' insofar as it relates to non-religious beliefs is an issue with which the local authority must grapple,_
following the recognition in Fox that at least some such teaching is required as part of religious education
[in order to be compliant with HRA 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

88. Moreover, it is not a qualitatively different question to that which must already be asked in relation to
religious representatives. The local authority in Kent, based upon the 2021 Census data, might already
find itself having to decide whether SACRE should contain Satanist, Reconstructionist or Pagan
representatives.  In this context, a request for representation from someone with a particular belief system
may require the local authority to consider the potentially difficult question of whether the beliefs attain a
certain level of cogency, seriousness, cohesion and importance so as to merit consideration at all,
irrespective of whether the belief system is religious or non-religious.  Interestingly, it might also be noted
that whilst the quote from Lord Agnew above highlights Confucianism as an example of a non-religious
worldview giving rise to potential complexity, the Kent census data of 2021 has Confucianism listed under
'Other religion', rather than 'non-religion'.  This aptly illustrates how the definitional problems already exist
at what might be called (with no disrespect intended) the margins, irrespective of a distinction between
religious and non-religious belief. Moreover, it is difficult to see how any such problem arises in any event
in the case of humanism which is (a) not a non-religious worldview 'at the margins', but well recognised as
one which should be afforded equal treatment (see Harrison) and (b) is already a subject matter included in
91% of agreed syllabuses including that in Kent Ultimately a local authority must form a judgment in


-----

relation to these questions, which is not made more or less difficult by the inclusion of people wishing to
represent recognized non-religious belief systems.

89. Similarly, the purported practically difficult task required in identifying a particular representative of a
non-religious belief system when compared to a religious belief system is equally overstated, and certainly
is wholly insufficient to justify the discriminatory nature of section 390 if construed so as to exclude those
who adhere to belief systems which are themselves appropriate to be included within the agreed syllabus
for religious education.  In accordance with section 392, the local authority must, before appointing a
person as a representative of a particular belief system, take all reasonable steps to assure themselves
that the appointee is representative of that belief system.  No doubt, that would involve enquiring into how
and why the person considers themselves to be representative.  In the case of a non-religious believer
such as a humanist, the prospective appointee might readily identify participation in group meetings or
holding positions of responsibility within relevant organisations in much the same way a religious believer
would identify their equivalent suitability.  Whilst it is obvious that one humanist is unlikely to be truly
representative of all humanists, the same is equally true of representatives of religions and denominations.
Indeed, the task of a local authority in this respect may be easier in the case of appointing a humanist
representative than (say) an animist.  Ultimately, again, judgment is required in a materially similar way
whether the prospective appointee holds a religious or a non-religious belief.

90. I also reject Mr Giffin's contention that possible adherence to more than one belief system is, itself,
problematic in circumstances where a person is appointed to represent a particular belief system.  The
example given by Mr Giffin was that a humanist may also be a communist, in a way that a catholic is
unlikely also to be pagan. However, putting aside whether communism is truly a non-religious belief
system appropriate for inclusion within a religious education syllabus, the point is that the representative
would be appointed as a representative of humanism.  If the local authority had legitimate grounds to
consider that their separate belief in communism undermined their ability to properly be representative of
the humanist belief, they would be entitled to refuse to appoint the person as the representative.
Moreover, this does not just apply to non-religious appointees: a catholic might equally be a communist,
but the latter would not of itself disqualify the catholic from being a representative of Catholicism on
SACRE.  On any view, this does not come close to a valid justification for the exclusion from Group A of
SACRE of those with non-religious belief systems which are relevant to the content of religious education
in a particular area.

91. As to the workability of Section 390(6), this states, as set out above, that the number of representative
members appointed to any representative group to represent each religion or denomination required to be
represented shall, so far as consistent with the efficient discharge of the group's functions, reflect broadly
the proportionate strength of that denomination or religion in the area. Pointing to the evidence of Mr
Copson, who states that as many as 400,000 of the 1.5m population in Kent may hold humanist beliefs, Mr
Giffin argues that membership proportionately within Group A would be 'transformative' in a context where,
he says, the purpose of Groups A and B is to represent faith views. I have already rejected the contention
that the purpose of Groups A and B is to represent faith groups; it is intended to consist of a group of
people able to bring experience and expertise generally to advice on the content of the syllabus drawn
from those with religious and non-religious beliefs which are appropriate to be included within a religious
education syllabus. However, Mr Giffin's fear is unfounded in any event, and certainly does not amount to
a justification for the discriminatory effect of section 390(4) as construed by KCC. The fact that religious
education will remain predominantly based on religions rather than non-religious beliefs will no doubt be a
factor a local authority will take into account when ensuring that the proportions of representation should
always remain consistent with the efficient discharge of SACRE's functions, as explicitly required by
section 390(6).  Thus, pursuant to this section the number of non-religious belief holders appointed might
legitimately also need to be reflective of the (more limited) extent of non-religious belief content required
within the syllabus. It does not need to be rigidly dictated by the proportion of people with a particular nonreligious belief in the local area. Irrespective of the eligibility of those with non-religious belief systems, a
local authority needs to be practical and sensible in applying section 390(6), always consistent with the
efficient discharge of the function of the group. This affords the local authority considerable discretion.
I d d th t tit ti f G A SACRE b KCC i t i t i tl fl ti f th


-----

proportions of particular religions within Kent, but that does not mean of itself that its constitution is
unlawful (the subject matter of these proceedings aside).

92. Far from assisting Mr Giffin's argument, I consider that section 390(6) fundamentally undermines it. It
demonstrates (as Mr Giffin himself states at paragraph 66 of his skeleton argument) that the aim of the
statutory provisions is to achieve broad correspondence between the constituency of the groups drawn
from the local area and the nature of the curriculum into which they are to have their input.  This is itself at
least to some extent intended to reflect the range of different beliefs specific to the area in order to promote
tolerance and pluralism in religious education.  However, the overall effect of the statutory provisions as
interpreted by KCC is that, in circumstances where the religious education curriculum must, as determined
in Fox, contain teaching of some non-religious beliefs, such correspondence is impossible to achieve.

93. I therefore conclude that the discriminatory nature of section 390(4) as interpreted by KCC is
manifestly without reasonable foundation and not justifiable. Indeed, it is antithetical to what the provisions
can sensibly be considered as aiming to achieve, when that aim is now to be realised in light of the fact
that 'religious education' must include some teaching of non-religious beliefs, as confirmed in Fox.

94. As such, section 390(4)(a) as construed by KCC does involve a breach of Article 14.

F. Is it possible to read and give effect to section 390(4)(a) in a way which is compatible with the
Convention rights?

95. Section 3(1) of the HRA provides that:

'So far as it is possible to do so, primary legislation and subordinate legislation must be read and given
_effect in a way which is compatible with the Convention rights.'_

96. By way of guidance as to the Court's approach to the exercise required by section 3, I rely upon the
judgment of Lord Nicholls in Ghaidan v Godin-Mendoza [2004] 2 AC 557. At paragraphs 32 and 33 he
states as follows:

'32.From this the conclusion which seems inescapable is that the mere fact the language under
_consideration is inconsistent with a Convention-compliant meaning does not of itself make a Convention-_
_compliant interpretation under section 3 impossible. Section 3 enables language to be interpreted_
_restrictively or expansively.  But section 3 goes further than this.  It is also apt to require a court to read in_
_words which change the meaning of the enacted legislation, so as to make it Convention-compliant. In_
_order words, the intention of Parliament in enacting section 3 was that, to an extent bounded only by what_
_is “possible”, a court can modify the meaning, and hence the effect, of primary and secondary legislation._

_33.              Parliament, however, cannot have intended that in the discharge of this extended_
_interpretative function the courts should adopt a meaning inconsistent with a fundamental feature of_
_legislation.  That would be to cross the constitutional boundary section 3 seeks to demarcate and_
_preserve. … Words implied must, in the phrase of my noble and learned friend, Lord Rodger of Earlsferry,_
_“go with the grain of the legislation”.  Nor can Parliament have intended that section 3 should required_
_courts to make decisions for which they are not equipped.  There may be several ways of making a_
_provision Convention-compliant, and the choice may involve issues calling for legislative deliberation.'_

97. In Ghaidan, the House of Lords interpreted 'spouse', defined in paragraph 2 of Schedule 1 of the Rent
Act 1977, as extending, in the context of rights to be afforded to a surviving same-sex partner, to persons
living with another as if they were husband and wife.

98. The obligation under section 3 is imposed not just on the courts, but also on those tasked with
interpreting and applying the relevant legislation.  As Lord Rodger of Earlsferry put it at paragraph [106]:

_“Nevertheless, the section is not aimed exclusively, or indeed mainly, at the courts. … section 3 is_
_carefully drafted in the passive voice to avoid specifying, and so limiting, the class of persons who are to_
_read and give effect to the legislation in accordance with it. Parliament thereby indicates that the section_
_is of general application. It applies, of course, to the courts, but it applies also to everyone else who may_


-----

_have to interpret and give effect to legislation. The most obvious examples are public authorities such as_
_organs of central and local government … ”_

99. In terms of what may be 'possible' (and therefore permissible), Mr Wolfe relies upon the decision of
Colton J in Smyth _[[2017] NIQB 55. This case concerned the Convention-compliance of provisions within](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PX4-5SC1-DYBP-Y1KT-00000-00&context=1519360)_
the Marriage (Northern Ireland) Order 2003 ('the Order') which prevented the claimant from having a legally
recognised humanist marriage ceremony conducted by a humanist celebrant approved as an officiant
under the Order.  As part of this, it was argued that the term 'religious marriage' can and should be read to
include the concept of 'belief marriage'. The claim succeeded, and Colton J relied upon section 3 to read
the words 'or belief' into Articles 14 to 17 of the Order where it had referred to the words 'religious body'.
On appeal, the Court of Appeal identified what it considered to be an easier route to achieve the same end
(and to that extent allowed the appeal), but otherwise agreed with Colton J's carefully reasoned judgment.

100. One of the formulations advanced by Mr Wolfe in argument is to follow Colton J and read into section
390 the word 'or belief' after the reference to 'religion' as necessary.  Mr Wolfe also pointed to the way the
Welsh Cabinet Secretary for Education formulated the appropriate interpretation, which I have quoted in
paragraph 16 above, as a potential solution.

101. Mr Giffin contends, first, that it is not possible to construe section 390 in the manner contended as to
do so would go against the grain of the legislation.  I reject that argument for the reasons I have already
given. In summary, far from going against the grain of the legislation, I consider that in circumstances
where 'religious education' within section 80 must include at least some teaching of non-religious beliefs, it
is anomalous to read section 390(4) as prohibiting persons holding beliefs which would be appropriate for
inclusion within the syllabus from membership of Group A of a SACRE.

102. Second, he contends that there a number of different ways in which the incompatibility may be
remedied, and this should be left for Parliament.  I accept that there are indeed a number of different ways
in which Parliament might seek to amend the various religious education related provisions, including
section 390, and accept that that may involve policy decisions which are beyond the remit of this Court.

103. However, I remind myself that the principal question before me is whether KCC made an error of law
in prohibiting Mr Bowen from being a member of Group A of their SACRE on the basis of KCC's
understanding that section 390 required them to prohibit that appointment.

104. In order to answer that question (to which there is a binary answer) I accept, as Mr Wolfe submits in
the alternative to the various formulations he advances, that in doing so it is not necessary for me
expressly to reformulate the legislation as though I were a statutory draftsman or, indeed, at all.  I note that
in Fox, Warby J did not attempt to re-word sections 78 and, in particular, 80 of the 2002 Act in order to give
effect to his determination that those statutory provisions were 'to be interpreted as incorporating the duty
_of care recognised by the European court'._

105. Whilst I accept Mr Giffin's submission that 'religious education' within section 80 may be regarded as
something of a label, it is plain to me that all of the related and interconnected provisions relating to the
provision of religious education are explicit in their use of the language of 'religions' and 'religious
traditions'.  Indeed, whilst it is not necessary to do so, one need only look back to the passages of
parliamentary material Mr Giffin himself relies upon in relation to the previous issue to understand that
(following debate), that was _precisely the intention of parliament at that time.  Non-religious worldview_
teaching was consciously excluded, and that explains the original drafting. However, in Fox, Warby J
recognised that this was not compatible with HRA, and found that at least some teaching of non-religious
belief systems would be required within 'religious education' to be compliant with Convention rights, and
that the assertion which stated or implied the opposite was wrong.  At paragraph 76, Warby J said:

'That conclusion can be analysed as a finding that the assertion involves a breach of section 6 of the HRA,
_or as a finding that the defendant has made an error of law in her interpretation of the education statutes._
_It may not matter greatly, but in my view the latter is the better analysis.  In accordance with sections 3 of_
_the HRA, sections 78 and 80 of the 2002 Acct are to be interpreted as incorporating the duty of care_
_recognised by the European Court.'_


-----

106. Whilst not embarking on the exercise of re-drafting the legislation, Warby J can only have concluded
that it was possible to 'read in' some words in accordance with s3 of the HRA to permit it to be interpreted
in accordance with the HRA.  It was not necessary for him positively to articulate the precise reformulation
of the education statutes in order to determine that the assertion was an error of law.  I shall limit myself
likewise. It is not necessary to decide whether the words to read in are 'beliefs' or 'non- religious
worldviews' or 'cogent philosophical convictions' or some other formulation in order to determine that it
was an error of law to exclude Mr Bowen from consideration for appointment to Group A merely because
humanism is a non-religious belief system.  In interpreting section 390(4)(a) as KCC did, it failed to
interpret the provision in compliance with the _[HRA 1998 when it was possible to do so. Whatever the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
precise wording that might in due course be adopted by Parliament, should it choose to do so, humanism
is self evidently a belief system which is appropriate to be included within a religious education syllabus
(not least because it overwhelmingly is already), and would be encompassed within any Conventioncompliant interpretation of section 390(4)(a).

107. It follows from this that my judgment extends no further than determining that the basis of KCC's
decision was erroneous in law. It does not follow that any and every non-religious belief would need to be
treated similarly – for example, it may be legitimate to conclude that a particular belief (religious or nonreligious) does not attain the requisite level of cogency, seriousness, cohesion and importance to attract
protection.  Similarly, as I have described, there remains considerable discretion for the local authority
when determining who to appoint pursuant to section 390(6) to ensure consistency with the efficient
discharge of the group's functions.

G.          Should the decision of KCC prohibiting Mr Bowen from being included as a Humanist
representative within Group A of KCC's SACREE be quashed and/or declared as unlawful?

108. Yes.

The application for judicial review succeeds.  I quash the decision of KCC dated 17 June 2022 on the basis that it
was unlawful.

**End of Document**


-----

