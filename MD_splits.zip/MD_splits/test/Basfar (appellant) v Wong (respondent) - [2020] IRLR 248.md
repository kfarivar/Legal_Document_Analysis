# Basfar (appellant) v Wong (respondent) [2020] IRLR 248

UKEAT/0223/19/BA

Employment Appeal Tribunal

31012020

**_[987   Diplomatic Privileges Act](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_**

**_[4300   Tribunals](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7M1-DYNP-N057-00000-00&context=1519360)_**

**_[4395   Jurisdiction](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5DDJ-M0T1-DYNP-N3V6-00000-00&context=1519360)_**
**The facts:**

On the assumed (but disputed) facts, the claimant was a Philippine national. She was brought to the UK to work for
the respondent, a serving diplomat in the UK, in his diplomatic residence. She was issued with an overseas
domestic workers visa as a private servant in a diplomatic household. In order to obtain that visa she was provided
with a contract or statement of main terms and conditions of employment. She alleged that her treatment bore no
relation to those apparent terms and conditions and amounted to circumstances of **_modern slavery; she was a_**
victim of international trafficking, exploited by the respondent and his family. The claimant brought a variety of
complaints in the employment tribunal. A preliminary issue arose as to whether the claimant enjoyed immunity from
suit under art 31(1) of the Vienna Convention on Diplomatic Relations 1961 (as enacted into domestic law by s 2(1)
of and _[Sch 1 to the Diplomatic Privileges Act 1964), or whether the claim fell within the exception set out in art](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y1CB-00000-00&context=1519360)_
31(1)(c) in respect of 'an action relating to any professional or commercial activity exercised by the diplomatic agent
in the receiving State outside his official functions'. It was accepted that the claim fell outside the respondent's
official functions, and the sole issue was whether it related to any 'commercial activity' exercised by him in the UK.
Following the obiter observations of the (three to two) majority in Reyes v Al-Malki _[[2018] IRLR 267 (a case with a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
very similar factual matrix), the employment tribunal held that it did, and rejected the respondent's entitlement to
[diplomatic immunity. The majority had taken a different view to the Court of Appeal in that case (see [2015] IRLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)
_[289), but ultimately that issue was not essential in order to determine the appeal in that case. The respondent](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)_
appealed.

The EAT (Mr Justice Soole) by a reserved judgment given on 31 January 2020 allowed the appeal.
**The EAT held:**

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_

The claims did not relate to any 'commercial activity' exercised by the respondent in the UK and he was entitled to
diplomatic immunity under art 31 of the 1961 Convention.

The decision of the Court of Appeal in _Reyes as to whether the respondent's conduct constituted 'commercial_
activity' did not constitute binding precedent. The only precedent in that litigation was the ratio that decided the case
in the Supreme Court and the lower courts and tribunals were not bound by the Court of Appeal's decision


-----

However, the decision of the Court of Appeal on that issue was persuasive authority. In terms of which approach
was to be preferred, more weight should be given to those judgments of the higher courts in Reyes which, in light of
detailed analysis of the relevant material, provided a clear (albeit non-binding) conclusion on the point; and less
weight should be given to judgments that expressed even very strong doubts on that conclusion. The Court of
Appeal reached a clear and fully reasoned decision, on assumed facts akin to those in the present case, that there
was no 'commercial activity'. The material that it considered was comprehensive, taking full account of the relevant
international treaty obligations and international authority, and endorsed existing domestic authority. The minority of
the Supreme Court reviewed that and further material in great detail and reached a conclusion, albeit in non-binding
terms, which accorded with that of the Court of Appeal on the issue of 'commercial activity'. The majority did not
reach a clear view to the contrary, but expressed doubts as to the minority opinion. In such circumstances, the
tribunal had been wrong to assume that, if it had been necessary to decide the point, the majority would not have
adopted the construction proposed by the minority. On the contrary, the decisions of the Court of Appeal and of the
minority in the Supreme Court represented the current state of the law on the issue of 'commercial activity'.
**Cases referred to:**

_Al-Mehdawi v Secretary of State for the Home Department_ _[[1989] 3 All ER 843, [1990] 1 AC 876,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-609T-00000-00&context=1519360)_ _[[1991] LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KP9-CMW1-DYJ0-8446-00000-00&context=1519360)_
_[(Const) 716, [1989] 3 WLR 1294HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KP9-CMW1-DYJ0-8446-00000-00&context=1519360)_

_[Benkharbouche v Embassy of the Republic of Sudan [2017] UKSC 62, [2018] IRLR 123, [2019] AC 777, [2018] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RDV-T4H1-DYPB-W0M3-00000-00&context=1519360)_
_[All ER 662, [2017] ICR 1327](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RNF-6RS1-DYBP-M4NN-00000-00&context=1519360)_

_Brownlie v Four Seasons Holdings Incorporated [2015] EWCA Civ 665, [2016] 1 WLR 1814_

_Helena Partnerships Ltd (formerly Helena Housing Ltd) v Revenue and Customs Comrs (A-G intervening) [2012]_
_[EWCA Civ 569, [2012] 4 All ER 111, [2012] STC 1584, [2012] HLR 502](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56P0-7BJ1-DYBP-M0H4-00000-00&context=1519360)_

_Iranian Offshore Engineering and Construction Co v Dean Investment Holdings SA [2018] EWHC 2759 (Comm),_

[2019] 1 WLR 82

_[OPO (by his litigation friend) v Rhodes sub nom OPO v MLA [2015] UKSC 32, [2015] 4 All ER 1, [2016] AC 219,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GYB-J701-DYBP-M1N4-00000-00&context=1519360)_

[2015] 2 WLR 1373, [2014] EMLR 4

_Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 CA_

_R v Diggines, ex parte Rahmani_ _[[1986] 1 All ER 921, [1986] AC 475, [1986] 2 WLR 530, [1987] LRC (Const) 700;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-614H-00000-00&context=1519360)_
_affg_ _[[1985] 1 All ER 1073, [1985] QB 1109, [1985] 2 WLR 611CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-60PY-00000-00&context=1519360)_

_Reyes v Al-Malki [2017] UKSC 61,_ _[[2018] IRLR 267, [2019] AC 735,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_ _[[2018] 1 All ER 629, [2017] ICR 1417;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RNF-6RT1-DYBP-M0KY-00000-00&context=1519360)_
[reversing in part [2015] EWCA Civ 32, [2015] IRLR 289, [2015] ICR 931, [2016] 2 All ER 136, [2016] 1 WLR 1785;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)
_[affirming (2013) (2013) UKEAT/0403/12, [2013] IRLR 929, [2014] ICR 135](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59TP-7XT1-DYPB-W2RS-00000-00&context=1519360)_

_Sabbithi v Al Saleh (2009) 605 F Supp 2d 122 US DC_

_Tabion v Mufti 73 F 3d 535, (1996) 107 ILR 452, US CA (4th Cir)_

_Thorpe v Commissioners Revenue and Customs Comrs_ _[[2009] EWHC 611 (Ch), [2009] STC 2107, 12 ITELR 279](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WPM-VB50-Y970-24MS-00000-00&context=1519360)_

_Young v Bristol Aeroplane Co Ltd,_ _[[1944] 2 All ER 293, [1944] KB 718](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP70-TWP1-60C7-00000-00&context=1519360)_
**Appearances:**

Vienna Convention on Diplomatic Relations: art 31(1)

_[Diplomatic Privileges Act 1964: s 2(1), Sch 1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)_

For diplomatic immunity see Harvey PIII [201]–[210]


-----

For the respondent:

MOHINDERPAL SETHI QC and SOPHIA BERRY, instructed by Reynolds Porter Chamberlain LLP

For the claimant:

PHILIPPA WEBB and ISHAANI SHRIVASTAVA, instructed by Wilson & Co Solicitors
1

**SOOLE J: This appeal concerns the defence of diplomatic immunity. The particular question is whether a serving**
diplomat's employment of a 'trafficked' domestic servant at his diplomatic residence constitutes a 'commercial
activity exercised … outside his official functions' within the meaning of art 31(1)(c) of the Vienna Convention on
[Diplomatic Relations 1961 ('the 1961 Convention') as enacted into domestic law by s 2(1) Diplomatic Privileges Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y0D1-00000-00&context=1519360)
1964. The appeal in turn raises a question on the doctrine of precedent. I will refer to the parties as the Claimant
and Respondent.
2

The Respondent appeals from the Judgment of the Employment Tribunal at London Central (2206477/2018)
(Employment Judge Brown) ('the Tribunal') sent to the parties on 13 June 2019 following a
**[*249]**

hearing on the Respondent's application that the Claimant's claims should be struck out on the ground of diplomatic
immunity. The Tribunal dismissed the application.
3

The application proceeded on the agreed basis that the Claimant's case should be considered at its highest, ie on
assumed facts, as pleaded in her ET1 claim. In essence, this is that in circumstances of **_modern slavery the_**
Claimant was trafficked by the Respondent to the UK in order to work as a domestic servant in his diplomatic
residence.
4

The assumed facts may be taken shortly from the Judgment. The Claimant is of Philippine nationality. She was
employed by the diplomatic household of the Respondent in Saudi Arabia from November 2015. On 1 August 2016,
she was brought to the UK to continue working for the Respondent in this country. The UK Border Agency issued
her with an Overseas Domestic Workers Visa as a private servant in a diplomatic household. In order to obtain that
visa she was provided with a contract or statement of main terms and conditions of employment. These included
employment to work eight hours a day, 50 hours per week, with 16 hours' free time each day and one day off work
each week and one month off each year. She was to be provided with sleeping accommodation and paid at the
National Minimum Wage.
5

On the assumed but disputed facts, her employment and treatment bore no relation to these apparent terms and
conditions and amounted to circumstances of **_modern slavery. She was a victim of international trafficking,_**
exploited by the Respondent and his family. It is agreed that the Respondent was at all material times, and remains,
a serving diplomat in this country and that he employed the Claimant to work in his official diplomatic residence.
6

By the Claimant's ET1 form presented on 18 October 2018, she brought complaints of wrongful (constructive)
dismissal, failure to pay the National Minimum Wage, unlawful deductions from wages, claims under the Working
[Time Regulations 1998 (SI 1998/1833), failure to provide written wage slips and failure to provide written](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW8-5HJ0-TX08-C19K-00000-00&context=1519360)
employment particulars. The form states that her employment ended on 24 May 2018.
7

Article 31(1) of the 1961 Convention provides, so far as relevant:


-----

'1. A diplomatic agent shall enjoy immunity from the criminal jurisdiction of the receiving State. He shall also
enjoy immunity from its civil and administrative jurisdiction except in the case of:

…

(c) an action relating to any professional or commercial activity exercised by the diplomatic agent in the
receiving State outside his official functions.'

8

Article 39(2) provides, as relevant:

'2. When the functions of a person enjoying privileges and immunities have come to an end, such privileges
and immunities shall normally cease at the moment when he leaves the country, or on expiry of a reasonable
period in which to do so, but shall subsist until that time … However, with respect to acts performed by such a
person in the exercise of his functions as a member of the mission, immunity shall continue to subsist.'

9

With one important qualification, the assumed facts of this case are materially the same as those in _Reyes v Al-_
_Malki (2013)_ _(2013) UKEAT/0403/12,_ _[[2013] IRLR 929, [2014] ICR 135,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59TP-7XT1-DYPB-W2RS-00000-00&context=1519360)_ _[2015] EWCA Civ 32,_ _[[2015] IRLR 289,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)_

[[2015] ICR 931and [2017] UKSC 61, [2018] IRLR 267, [2017] ICR 1417('Reyes' ). The qualification is that in Reyes](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
the respondent ceased to be a serving diplomat in the course of the litigation, namely on 29 August 2014 between
the decision in the EAT and the hearing in the Court of Appeal. This change in the facts was not treated as material
in the Court of Appeal but was decisive in the Supreme Court. As will be seen, this becomes potentially relevant on
the issue of precedent.
10

Before the Tribunal, the Claimant contended that there was a further difference from the assumed facts in Reyes. In
that case it was not clear that the respondent had personally trafficked the employee. However, the Tribunal
concluded that this was not a material difference from the assumed facts in the present case ([53]); and the
Claimant has not pursued that argument in answer to this appeal.
11

It is common ground that the binding effect of the Supreme Court decision in Reyes is that, on the assumed facts,
the Respondent's activity was 'outside his official functions' within the meaning of art 31(1)(c). Accordingly, the sole
issue under the Article is whether it was 'relating to any … commercial activity' exercised by him in the UK.
12

The Respondent's first submission before the Tribunal was that it was bound by the decision of the Court of Appeal
in Reyes to conclude that his employment of the Claimant did not constitute 'commercial activity'. The Claimant's
response was that the effect of the subsequent Supreme Court decision was that the Court of Appeal decision on
that point was persuasive only; and that the non-binding observations on the point of three Justices of the Supreme
Court (Lord Wilson JSC, Baroness Hale of Richmond PSC and Lord Clarke of Stone-cum-Ebony JSC) should be
preferred. The Respondent's alternative submission was that the non-binding observations of the two other Justices
(Lords Sumption JSC and Neuberger of Abbotsbury JSC), together with the unanimous decision of the Court of
Appeal, should be preferred. The first issue on precedent depends on the correct interpretation of the decision of
[the Court of Appeal in Al-Mehdawi v Secretary of State for the Home Department [1989] 3 All ER 843, [1990] 1 AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-609T-00000-00&context=1519360)
876('Al-Mehdawi'). For convenience of reference only, I will refer to the two groups of Supreme Court Justices as
'the majority' and 'the minority' respectively.
13

The Tribunal accepted the submissions of the Claimant and held that (i) the decision of the Court of Appeal was not
binding [55]–[73] and (ii) the observations of the majority in the Supreme Court were to be preferred [74]–[88].
Accordingly, the defence of diplomatic immunity was rejected.
14
**Reyes v Al-Malki**


-----

It is necessary to start with the history and reasoning of the successive decisions in _Reyes. The employment_
tribunal rejected Mr Al-Malki's defence of diplomatic immunity, accepting the claimants' argument that the defence
constituted a procedural bar which was in breach of art 6 of the ECHR.
15

On the respondent's appeal to the EAT, the claimants conceded that a literal application of the words 'commercial
activity' did not permit the claims to proceed [8]. The concession was based on the statement of Laws J, as he then
was, in Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 that 'commercial activity' referred to any 'activity which
might be carried on by the diplomat on his own account for profit' (p 635). However, the claimants reserved the right
to argue at a higher level that a broader view should be taken of the words 'commercial activity'. In allowing the
respondent's appeal, Langstaff P agreed with the employment tribunal that the activity was outside his 'official
functions'; but held that art 6 was no bar to reliance on the immunity.
**[*250]**
16

The claimants' appeal to the Court of Appeal was heard in November 2014. In his judgment, Lord Dyson MR noted
that the two claimants had been employed for periods in 2011; and that 'The employers have now left the United
Kingdom' [1]–[2]. This reflected the fact, subsequently recorded in the judgment of Lord Sumption [4], that the
respondent's posting in London had come to an end on 29 August 2014. However the hearing before the Court of
Appeal proceeded without consideration of art 39(2). Under art 31(1)(c) the claimants advanced the argument,
which they had reserved below, that their employment by the respondent did constitute 'commercial activity' by him.
17

The Court of Appeal rejected that argument. In an extensive analysis, following a wide-ranging review of
international and domestic material on the 1961 Convention in general and art 31 in particular, Lord Dyson (with
whom Arden and Lloyd Jones LJJ agreed) held that the actions of the respondent neither constituted 'commercial
activity' nor were exercised by him 'outside his official functions'. Lord Dyson considered the meaning of
'commercial activity' with particular regard to the interpretative principles of the Vienna Convention on the Law of
Treaties 1969 ('the 1969 Convention'); the overall scheme of the 1961 Convention; the travaux preparatoires;
domestic and international authority; and the 'trafficking dimension'.
18

Having reached his conclusion Lord Dyson observed:

'This may appear to be an affront to one's sense of justice and fairness, but … it is salutary to bear in mind the
concluding words of the decision in Tabion [v Mufti 73 F 3d 535, para 15]:

“… there may appear to be some unfairness to the person against whom the invocation occurs. But it must be
remembered that the outcome merely reflects policy choices already made. Policymakers … have believed that
diplomatic immunity not only ensures the efficient functioning of diplomatic missions in foreign states, but
fosters goodwill and enhances relations among nations. Thus, they have determined that apparent inequity to a
private individual is outweighed by the great injury to the public that would arise from permitting suit against the
[entity or its agent calling for application of immunity” ' [2015] IRLR 289 at [77]; [2015] ICR 931 at [77].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)

19

The Supreme Court decided Ms Reyes' appeal on a different ground based on the fact that on 29 August 2014 the
respondent's posting in London had come to an end; and that in consequence any entitlement to continuing
immunity depended on the provisions of art 39(2). With the support of all other members of the Court, Lord
Sumption held that the employment of Ms Reyes by the respondent constituted acts which were clearly outside his
'functions as a member of the mission' within the meaning of art 39(2); and that accordingly the respondent was no
longer entitled to any immunity: [48]. The appeal was allowed on that basis alone.
20


-----

Thus the judgments of the Supreme Court on the position under art 31(1)(c) are not binding: see Lord Sumption at

[51] and Lord Wilson at [56]–[57]. However, the Court heard full argument on the point. As to the words 'outside his
official functions', those functions were treated as having the same meaning as 'his functions as a member of the
mission' in art 39(2): [50]. In consequence the present Respondent does not dispute that his activities were outside
his official functions; and the sole focus is on the issue of 'commercial activity'.
21

The judgment of Lord Sumption (with whom Lord Neuberger agreed) considered and answered this point
comprehensively. It rejected the argument that the assumed actions of the respondent employer, including its
trafficking dimension, constituted 'commercial activity'.
22

Without attempting an exhaustive summary, the following points in the reasoning are particularly noteworthy. First,
that the 'exercise' of a professional or commercial activity '… means practising the profession or carrying on the
business. The diplomatic agent must be a person practising the profession or carrying on (or participating in
carrying on) the business. He must, so to speak, 'set up shop' [21](2). This was the gist of the reasoning of Laws J
in Propend [21](3).
23

Secondly, that any wider scope for the exception would have the effect that the immunity in respect of non-official
acts would mean very little, 'for every purchase that a diplomat might make in the course of his daily life from a
business carried on by someone else would be a commercial activity exercised by the diplomat for the purpose of
art 31(1)(c)', which in turn would be contrary to the carefully constructed scheme of the 1961 Convention: [21](6).
24

Thirdly, that the authorities most directly in point are from the United States, notably the leading case of Tabion v
_Mufti 73 F 3d 535. Whilst that and other decisions were influenced by the State Department's 'Statement of Interest'_
and the constitutional division of powers which requires US courts to show 'substantial deference' to the executive's
views on such matters, that did not undermine their authority: [25].
25

Fourthly, that this interpretation was not undermined by the 'trafficking dimension' or the related provisions of the
'Palermo Protocol' (2000), ie the 'Protocol to Prevent, Suppress and Punish Trafficking in Persons Especially
Women and Children'. By way of analogy –

'… if I knowingly buy stolen property from a professional fence for my personal use, both of us will incur
criminal liability for receiving stolen goods and civil liability to the true owner for conversion. The fence will also
be engaging in a commercial activity. But it does not follow that the same is true of me.

[46] For the same reason, it cannot matter that the trafficking may enable the ultimate employer to pay the
victim less than the proper rate or nothing at all. To pursue the analogy, I will no doubt pay the fence less for
the stolen goods than I would have had to pay for the same goods to an honest shopkeeper. But that does not
alter the characterisation of my purchase, which is no more the exercise by me of a commercial activity in the
one case than it is in the other. Likewise, the employment of a domestic servant to provide purely personal
services cannot rationally be characterised as the exercise of a commercial activity if she is paid less than the
going rate or the national minimum wage, but not if she is paid more. One might perhaps loosely say that the
victim is being treated as a commodity. But a figure of speech should not be confused with a legal concept.'

_[[2018] IRLR 267 at [45]–[46], [2019] AC 735, at [45]–[46].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_

26

Lord Sumption concluded that if the respondent had still been in post and the question had therefore arisen for
direct decision, '… I would have held that he was immune, because the employment and treatment of Ms Reyes did
not amount to carrying on or participating in carrying on a professional or commercial activity. Her employment,
although it continued for about two months, was plainly not an alternative occupation of Mr Al-Malki's. Nothing that


-----

was done by him or his wife was done by way of business … There is no sense which can reasonably be given to
art 31(1)(c) which
**[*251]**

[would make the consumption of goods and services the exercise of a commercial activity.' [2018] IRLR 267 at [51],](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)

[2019] AC 735 at [51].
27

Lord Wilson, with whom Baroness Hale and Lord Clarke agreed, stated that he was pleased that the Court would
not be answering the central question under art 31(1)(c) in any binding form. He continued: 'Lord Sumption JSC's
emphatic answer to the question is “no”. His answer is (if he will forgive my saying so) the obvious answer. It may
be correct. But my personal experience has been that, the more one thinks about the question, the less obviously
[correct does his answer become.' [2018] IRLR 267 at [57], [2019] AC 735 at [57].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
28

He then referred to five aspects of the background. First, the evidence demonstrating that the UK confronted a
[significant problem in relation to the exploitation of migrant domestic workers by foreign diplomats [2018] IRLR 267](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
_[at [59], [2019] AC 735 at [59]. Secondly, the universality of the international community's determination to combat](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
[human trafficking [2018] IRLR 267 at [60], [2019] AC 735 at [60]. Thirdly, the definition of trafficking in the Palermo](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
Protocol and the subsequent Council of Europe Convention on Action against Trafficking in Human Beings (2005),
[which endeavoured to encompass the whole sequence of actions that leads to the exploitation of the victim [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
_[IRLR 267 at [61], [2019] AC 735 at [61]. In consequence he questioned the suggested analogy between an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
employer of a trafficked migrant and a purchaser of stolen goods at a cheap pric : '… another rational view is that
the relevant “activity” is not just the so-called employment but the trafficking; that the employer of the migrant is an
integral part of the chain, who knowingly effects the “receipt” ' of the migrant and supplies the specified purpose,
namely that of exploiting her, which drives the entire exercise from her recruitment onwards; that the employer's
exploitation of the migrant has no parallel in the purchaser's treatment of the stolen goods; and that, in addition to
the physical and emotional cruelty inherent in it, the employer's conduct contains a substantial commercial element
[of obtaining domestic assistance without paying for it properly or at all' [2018] IRLR 267 at [62], [2019] AC 735 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)

[62].
29

[Fourthly, that diplomatic immunity was an aspect of state immunity; and thus it was relevant to take account of s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y0VV-00000-00&context=1519360)
_[3(3) of the State Immunity Act 1978 whose definition of a 'commercial transaction' excluded from state immunity](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y0VV-00000-00&context=1519360)_
'any contract for the supply of goods or services'. Section 16(1)(a) of that statute, which purported to provide
immunity where the proceedings concerned the employment of the members of a mission including staff in its
domestic service, could be disregarded as incompatible with art 6 ECHR: _Benkharbouche v Embassy of the_
_Republic of Sudan_ _[[2018] IRLR 123, [2019] AC 777. He continued: 'I cannot readily explain why proceedings](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RDV-T4H1-DYPB-W0M3-00000-00&context=1519360)_
relating to a contract of employment entered into by a foreign state, for performance in the UK, will not in principle
attract immunity in circumstances in which, if the contract is entered into by a diplomat, it will in principle attract
[immunity' [2018] IRLR 267 at [65], [2019] AC 735 at [65].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
30

Fifthly, if the purpose of diplomatic immunity as defined in the 1961 Convention was 'not to benefit individuals but to
ensure the efficient performance of the functions of diplomatic missions as representing states', a question arose as
to how that purpose accorded with a result which gave diplomatic immunity in circumstances where, as here, there
was no apparent link between the duties of the employee and the official functions of the diplomatic employer

_[[2018] IRLR 267 at [66], [2019] AC 735 at [66].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
31

On the other side of the scale, Lord Wilson recognised two 'perceived problems'. First, art 31(1) of the 1969
Convention required the interpretation of treaties to be undertaken in accordance with the ordinary meaning to be
given to its terms, in their context and in the light of its object and purpose. He was persuaded that, when agreeing


-----

to the terms of the 1961 Convention, the parties would have rejected any suggestion that the proceedings brought
[by Ms Reyes related to any commercial activity exercised by Mr Al-Malki [2018] IRLR 267 at [67], [2019] AC 735 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)

[67].
32

However, in contrast to Lord Sumption's opinion, he was '… less persuaded that, even if (which is debatable) art 31
of the 1961 Convention does not by its terms contemplate any future development of its meaning, the latter would
have been unable to develop over 56 years. Article 31(3)(c) of the Vienna Convention [on the Law of Treaties]
requires the interpretation of an article to take account of any relevant rules of international law applicable in the
[relations between the parties; and the requirement is not further qualified.' [2018] IRLR 267 at [67], [2019] AC 735](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
at [67]. He indicated that this in turn could allow an interpretation which took account of the emergence of an
international prohibition against trafficking.
33

The second perceived problem was that an international treaty calls for international interpretation by reference to
'broad principles of general acceptation'; and not least in respect of protection to be afforded to diplomats serving
abroad. Thus, it would be a 'strong thing for this court to diverge from the US jurisprudence set out in … Tabion…
and to adopt the robust interpretation of art 31(1)[(c)] for which Ms Reyes contends.' Conversely, '… it is difficult for
this court to forsake what it perceives to be a legally respectable solution and instead to favour a conclusion that its
system cannot provide redress for an apparently serious case of domestic servitude here in our capital city.' Lord
Wilson concluded: 'In the event my colleagues and I are not put to that test today. Far preferable would it be for the
International Law Commission, midwife to the 1961 Convention, to be invited, through the mechanism of art 17 of
the statute which created it, to consider, and to consult and to report upon, the international acceptability of an
amendment of art 31 which would put beyond doubt the exclusion of immunity in a case such as that of Ms Reyes'

_[[2018] IRLR 267 at [68], [2019] AC 735 at [68].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
34

In their short following judgment, Baroness Hale and Lord Clarke observed that, had the proper construction of art
31(1)(c) risen for decision, '… we would associate ourselves with the doubts expressed by Lord Wilson [JSC] as to
whether the construction adopted by Lord Sumption [JSC] in this particular context is correct especially in the light
[of what we would regard as desirable developments in this area of the law.' [2018] IRLR 267 at [69], [2019] AC 735](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
at [69].
35
**Precedent**

In Al-Mehdawi, the Court of Appeal was faced with the question of whether it was bound by its previous decision in
[a case (R v Diggines, ex parte Rahmani [1985] 1 All ER 1073, [1985] QB 1109('Rahmani')) where, on appeal to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-60PY-00000-00&context=1519360)
[House of Lords ([1986] 1 All ER 921, [1986] AC 475), it had been held that the issue determined both at first](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-614H-00000-00&context=1519360)
instance and by the Court of Appeal did not arise on a true view of the relevant facts and law. The Court held that it
[was not so bound, albeit its previous decision was strong persuasive authority: [1989] 1 All ER 777 at 780, [1990] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
AC 876, at 881A–883C. However, the present parties disagree as to the true ratio of its decision to that effect.
36

In Rahmani, an immigration adjudicator, in purported exercise of a power under r 12 of the Immigration
**[*252]**

[Appeals (Procedure) Rules 1972 (SI 1972/1684), had dismissed an appeal without a hearing. At first instance and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW8-F2P0-TX08-21DJ-00000-00&context=1519360)
in the Court of Appeal it was held that the denial of a hearing was a breach of the rules of natural justice. On appeal
to the House of Lords the important question of principle was whether a power conferred by statute and exercised
without procedural impropriety or irregularity could nonetheless be quashed upon judicial review for breach of the
rules of natural justice. However, at the hearing the House raised the point that r 12 had no application to the
particular facts; and dismissed the appeal on that sole basis.
37


-----

In _Al-Mehdawi, Counsel for the Secretary of State (Mr John Laws) submitted that the case of_ _Rahmani must be_
seen as one continuous piece of litigation; and in consequence its true ratio was the simple one propounded in the
House of Lords and the views expressed by the Court of Appeal on the issue of principle, albeit of high persuasive
[value, were not binding on that Court: [1989] 1 All ER 777 at 780c, [1990] 1 AC 876 at 881E. He submitted that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
three established exceptions to the principle of stare decisis identified in Young v Bristol Aeroplane Co Ltd, _[[1944] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP70-TWP1-60C7-00000-00&context=1519360)_
_[All ER 293 at 300, [1944] KB 718 at 729were not exhaustive: 'They may well be inapt where the House of Lords, in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP70-TWP1-60C7-00000-00&context=1519360)_
giving the final decision of a case, expressly indicates that on the true facts, the issue resolved by the Court of
[Appeal did not require to be decided.' ([1989] 1 All ER 777 at 780e, [1990] 1 AC 876 at 881H–882A). Alternatively,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
such a case might be akin to the second exception in Young v Bristol Aeroplane, namely that 'The court is bound to
refuse to follow a decision of its own which, though not expressly overruled, cannot, in its opinion, stand with a
[decision of the House of Lords.': Young at [1944] 2 All ER 293 at 300, [1944] KB 718 at 729.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP70-TWP1-60C7-00000-00&context=1519360)
38

In considering these submissions, Taylor LJ observed that the House of Lords in Rahmani had gone further than
stating simply that the issue below did not arise for decision. Lord Scarman had stated: 'Your Lordships have not,
therefore, considered, nor have they heard arguments upon, the point of principle which was the ground of decision
in both courts below. Accordingly I express no opinion on the point. I must not be understood to have indicated
even a provisional view upon the soundness or otherwise of the alleged principle. Indeed, it would be dangerous, in
[my view, to discuss the point save in a case where the circumstances and the facts require it to be decided.' ([1986]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-614H-00000-00&context=1519360)
_[1 All ER 921 at 922–923, [1986] AC 475 at 478). Taylor LJ commented 'It would be strange indeed if despite those](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-614H-00000-00&context=1519360)_
[final words, the decision of this court is to be regarded as binding authority on the point of principle.' ([1989] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
_[ER 777 at 780j, [1990] 1 AC 876 at 882E).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)_
39

Counsel for Al-Mehdawi submitted that the ratio of a court's decision remained binding even if the facts upon which
the court based it subsequently turned out to be wrong; and cited observations to that effect by AL Goodhart in his
essay 'Determining the ratio decidendi of a case' (Yale Law Journal, vol XL, No 2, p 161 (1930)). To this Taylor LJ
responded: 'But here it is not merely that knowledge subsequent and extraneous to the proceedings shows the
facts to be wrong; the House of Lords in the very case, giving its final opinion, has ruled that the issue determined
[below did not arise for decision.': [1989] 1 All ER 777 at 781c, [1990] 1 AC 876 at 883B.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
40

Taylor LJ (with whom Nicholls and O'Connor LJJ agreed) concluded that the Court was not bound by its reasoning
[in Rahmani, albeit it was of powerful persuasive influence: [1989] 1 All ER 777 at 781d, [1990] 1 AC 876 at 883C.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
He suggested that, if the case should go further, the House of Lords might consider it appropriate to consider stare
decisis in this context '… in which a decision of their Lordships' House may neither overrule nor be on all fours with
the decision of this court in the same case.': _[[1989] 1 All ER 777 at 781j, [1990] 1 AC 876 at 883H–884A. The](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)_
[House declined the invitation: [1989] 3 All ER 843 at 846d, [1990] 1 AC 876 at 894B. In doing so Lord Bridge of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-609T-00000-00&context=1519360)
Harwich described the successful submission in the Court of Appeal as that 'Rahmani's case was not of binding
authority since the House of Lords had decided the case on a different ground and had held that the point of
principle decided by the Court of Appeal did not arise.': _[[1989] 3 All ER 843 at 846c, [1990] 1 AC 876 at 893H–](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-609T-00000-00&context=1519360)_
894A.
41

On behalf of the Respondent, Mr Sethi QC submitted here and below that the true ratio of the decision on
precedent in Al-Mehdawi is that the Court of Appeal is not bound by its previous decision where the House of Lords,
in deciding the case on a different factual basis, has expressly ruled that on the true facts the issue resolved by the
[Court of Appeal did not require to be decided by that Court. In support he cites Mr Laws' submissions at [1989] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
_[ER 777 at 780e, [1990] 1 AC 876 at 882A and Taylor LJ's statement at [1989] 1 All ER 777 at 781c, [1990] 1 AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)_
876 at 883B that 'the House of Lords in the very case, giving its final decision, has ruled that the issue determined
below did not arise for decision.' The Supreme Court had made no such express ruling in its decision in _Reyes._
Accordingly, the decision in the Court of Appeal on the issue of whether the activities constituted 'commercial
activity' was binding on itself and therefore all lower courts and tribunals.


-----

42

On behalf of the Claimant, Ms Webb responded that the true ratio of _Al-Mehdawi was that a case must be_
considered as one continuous piece of litigation; and that accordingly its true ratio was to be found in the decision at
[the highest level in the litigation. This was Mr Laws' essential and successful submission: [1989] 1 All ER 777 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
_[780c, [1990] 1 AC 876 at 881E. Accordingly the Court of Appeal's decision on the meaning of 'commercial activity'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)_
formed no part of the binding ratio in Reyes; and was persuasive only. She cited in support subsequent decisions of
the Court of Appeal (Brownlie v Four Seasons Holdings Incorporated [2015] EWCA Civ 665, [2016] 1 WLR 1814)
and at first instance (Iranian Offshore Engineering and Construction Co v Dean Investment Holdings SA [2018]
_EWHC 2759 (Comm), [2019] 1 WLR 82)._
43

In _Brownlie, the Court of Appeal had to consider the status of its previous decision on a particular issue, in_
circumstances where the Supreme Court had reversed the result on another ground and therefore did not have to
deal with the particular issue: OPO v MLA _[[2015] UKSC 32, [2015] 4 All ER 1, [2014] EMLR 4, [2015] 2 WLR 1373.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GYB-J701-DYBP-M1N4-00000-00&context=1519360)_
Citing _Al-Mehdawi, Arden LJ accepted that the decision of the Court of Appeal in_ _OPO_ on that issue was '… no
longer binding under the doctrine of precedent, though it would constitute strong persuasive authority …' [2016] 1
WLR 1814 at [89].
44

In Iranian Offshore Engineering, Andrew Baker J observed, in respect of the substantive issue considered by the
Court of Appeal in OPO and in Brownlie that 'Further, each decision was reversed by reference to other points in
the Supreme Court … so that even if those passages had been part of the ratio in the Court of Appeal they would
not strictly now bind me.' [2019] 1 WLR 82 at [12].
45

The Tribunal preferred the Claimant's submissions on the effect of _Al-Mehdawi [64]–[66] and concluded that the_
Court of Appeal decision in Reyes was persuasive only [73.5].
**[*253]**
46

In reaching its decision on precedent, the Tribunal also took into account its conclusion that the Court of Appeal had
(at least arguably) given a 'composite answer' to the two questions of whether the respondent's activities (i)
constituted 'commercial activity' and (ii) were carried on within his 'official functions' [62]; [73.3]; and Lord Wilson's
statement that he was pleased that the Supreme Court was not giving a binding interpretation on the issues raised
by art 31(1)(c) [71]; [73.5].
47

In support of the Tribunal's conclusion on the correct interpretation of Al-Mehdawi, Ms Webb in this appeal cited two
further decisions. In Helena Partnerships Ltd (formerly Helena Housing Ltd) v Revenue and Customs Comrs (A-G
_[intervening) [2012] EWCA Civ 569, [2012] 4 All ER 111 Lloyd LJ, citing Al-Mehdawi, stated 'If the decision of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56P0-7BJ1-DYBP-M0H4-00000-00&context=1519360)_
Court of Appeal had not been subject to an appeal, that statement might have been part of the ratio decidendi.
However, since it was appealed, and since the decision of the House of the Lords went on a different basis, what
the Court of Appeal said cannot be regarded as part of the ratio of the case': [55].
48

In Thorpe v Commissioners Revenue and Customs Comrs _[[2009] EWHC 611 (Ch), [2009] STC 2107, Sir Edward](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WPM-VB50-Y970-24MS-00000-00&context=1519360)_
Evans-Lombe (sitting as a judge of the High Court) gave detailed consideration to the ratio of Al-Mehdawi [37]–[41].
[Having cited Taylor LJ's judgment at [1989] 1 All ER 777 at 780c–d, [1990] 1 AC 876 at 883A–B, he concluded: 'It](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
[seems to me that in arriving at this conclusion Taylor LJ was accepting the submission of Mr Laws ([1989] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
_[777 at 780, [1990] 1 AC 876 at 881) that the case had to be considered as one continuous piece of litigation](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)_
notwithstanding that it was divided into hearings at first instance, in the Court of Appeal and in the House of Lords'

[41]. Applying that principle to the particular decision of the Court of Appeal on the issue under review, the Judge


-----

concluded that the decision formed no part of the ratio of the case; and that accordingly, 'though of great persuasive
value', it was not binding on him [41].
49
_Respondent's submission on precedent_

In challenging the Tribunal's conclusion on precedent, Mr Sethi submits first that his alternative interpretation of the
Court of Appeal's decision in _Al-Mehdawi is supported by the critical passage in Taylor LJ's judgment where he_
drew a distinction between the position where it is '… merely that knowledge subsequent and extraneous to the
proceedings shows the facts to be wrong' and where '… the House of Lords in the very case, giving its final opinion,
[has ruled that the issue determined below did not arise for decision.' ([1989] 1 All ER 777 at 781c, [1990] 1 AC 876](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
at 883B).
50

Secondly, the statements of the Court of Appeal in Brownlie and Helena Partnership simply referred to the decision
in Al-Mehdawi. Accordingly, the only relevant focus must be on the language of that decision. Furthermore, since
_Brownlie was itself overturned in the Supreme Court, it was itself not binding. As to the first instance decisions,_
_Iranian Offshore simply depended on_ _Brownlie. As to_ _Thorpe, the judge's identification of the ratio in_ _Al-Mehdawi_
was wrong and should not be followed.
51

Thirdly, he points to the summary of the law in _Halsbury's Laws of England,_ Vol 11 (2015) para 30. Under the
heading 'Court of Appeal decisions' it states : 'The decisions of the Court of Appeal upon questions of law must be
followed by Divisional Courts and courts of first instance and, as a general rule, are binding on the Court of Appeal
until a contrary determination has been arrived at by the Supreme Court. There are, however, three exceptions to
this rule; thus: (1) the Court of Appeal is entitled and bound to decide which of two conflicting decisions of its own it
will follow; (2) it is bound to refuse to follow a decision of its own which, although not expressly over-ruled, cannot,
in its opinion, stand with a decision of the Supreme Court; and further is not bound by one of its decisions if the
**Supreme Court has decided the case on different grounds, ruling that the issue decided by the Court of**
**Appeal did not arise for decision; and (3) the Court of Appeal is not bound to follow a decision of its own if given**
_per incuriam.' (emphasis supplied). The footnote to the emphasised proposition cites Al-Mehdawi as authority._
52

He also referred to _The Law-Making Process, Michael Zander (2015). Under the heading 'Is the Court of Appeal_
bound by its own decisions?' and consideration of the Young v Bristol Aeroplane exceptions, the author states: 'A
variant of the second exception is where the first case decided by the Court of Appeal goes on appeal to the House
of Lords which rules that the point decided by the Court of Appeal did not arise for decision. If the issue then comes
up again, the Court of Appeal is not bound by its own previous decision – see [Al-Mehdawi]': p 228.
53

Fourthly, that in circumstances where (as here) the decision of the Court of Appeal had been made on the basis of
assumed facts, it was immaterial that the decision of the House of Lords had been made on the basis of a separate
true fact, ie that the respondent's diplomatic status had ended. It was commonplace for the Court to make binding
decisions on the basis of assumed facts.
54

Fifthly, that the Tribunal was in any event bound as a matter of precedent by the definition of 'commercial activity' in
_Propend (Laws J) and the EAT decision in Reyes which proceeded on the basis of the claimant's concession based_
on Propend.
55

Sixthly, that the Tribunal was wrong to state that the Court of Appeal in Reyes had treated the issues of 'commercial
activity' and 'official functions' as a composite question; or to treat that, or Lord Wilson's expression of pleasure that
the observations of the minority were not binding, as relevant to the issue of precedent.
56


-----

_Conclusion on Precedent_

In my judgment, for the reasons essentially advanced by Ms Webb here and below, the Tribunal was right to
conclude that the Court of Appeal decision in Reyes is not binding.
57

First, I consider that the decisions of the Court of Appeal in Brownlie and Helena Partnership bind lower courts and
tribunals as to the correct interpretation of _Al-Mehdawi; alternatively, they are highly persuasive authority which_
should be followed. Whilst the discussion in those cases involves no detailed analysis of that decision, each
identifies the ratio of Al-Mehdawi in terms to the broad effect that a decision of the Court of Appeal on a particular
issue ceases to bind that Court when an appeal to the Supreme Court is allowed on other grounds and the issue
therefore does not fall for decision. Furthermore, that conclusion is consistent with the proposition that the Court in
_Al-Mehdawi accepted Mr Laws' central submission that a case was to be seen as one continuous and_
unfragmented piece of litigation; and that in consequence the only true ratio was to be found in the decision at the
highest level in the particular litigation.
58

Secondly, I respectfully agree with the conclusion of Sir Edward Evans-Lombe in _Thorpe_ that Taylor LJ indeed
accepted that core submission of Mr Laws; and that accordingly it was the true ratio of Al-Mehdawi. The contrary
argument places undue weight on Taylor LJ's observation that the House of Lords had 'ruled'
**[*254]**

[that the issue determined below did not arise for decision ([1989] 1 All ER 777 at 781c, [1990] 1 AC 876 at 883B).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60G4-00000-00&context=1519360)
In that sentence, Taylor LJ was simply drawing a distinction between the position (i) where subsequent events show
the factual basis of a decision to be wrong (decision remains binding) and (ii) where the highest court concludes
that a material change in the facts makes it unnecessary for it to reach a decision on the issue which was
determined below (decision on that issue no longer binding). He was not suggesting that stare decisis in this
context depends on whether the highest court has in its judgment made an express ruling that it had been
unnecessary for the Court of Appeal to reach a decision on the issue. Nor can I see any principled basis for an
interpretation which depends upon any such formalistic requirement.
59

I read _Halsbury and Mr Zander's commentary to the same effect. Their respective references to a ruling that the_
point or issue decided by the Court of Appeal 'did not arise for decision' simply mean those cases where the highest
court concludes that it does not need to make a decision on the point decided below. This is further supported by
the statement in Cross and Harris, Precedent in English Law (4th edn, 1991) – supplied by the Respondent after
the hearing – which states that 'The Court of Appeal is not bound by a decision of its own where the earlier decision
was taken on appeal to the House of Lords and the House decided that the point on which the Court of Appeal had
given a ruling did not arise for decision' (p 154).
60

Thirdly, I am not persuaded that the position is any different where the decision of the Court of Appeal is based on
facts which have been assumed rather than found. I can see no good reason why eg an interlocutory decision
based on a set of assumed facts should have a different status for the purpose of precedent than a decision after
trial where those facts have been established. I should add that I do not accept the Claimant's contention that the
respondent's status as a serving diplomat was not one of the assumed facts in Reyes.
61

Fourthly, if the Court of Appeal's decision in _Reyes was not binding on it, I do not accept that the Tribunal was_
nonetheless bound by the decision of Laws J in Propend, let alone by the claimants' qualified concession before the
EAT in Reyes. In any event, the point is now academic at this appellate level.
62

For completeness, I agree that the Tribunal was wrong to support its decision on precedent on the additional
grounds that the Court of Appeal in Reyes had (at least arguably) dealt with the issues of 'commercial activity' and


-----

'outside his official functions' as one composite question; or by reference to Lord Wilson's statement that he was
pleased that the Supreme Court's observations on art 31(1)(c) were not binding. As I understood Ms Webb to
acknowledge, it is clear from Lord Dyson's judgment that he considered those two ingredients of art 31(1)(c) quite
distinctly: see in particular [29]. In my judgment the issue of precedent depends on the correct interpretation of the
decision in Al-Mehdawi.

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
63

My conclusion is that the Court of Appeal's decision on the issue of whether the respondent's conduct constitutes
'commercial activity' does not bind that Court. Since the reason for the rule on precedent is that the only true ratio is
that which decided the case in the Supreme Court, it must also follow that lower courts and tribunals are not bound
by the Court of Appeal decision in Reyes. Accordingly, the Respondent's appeal on that ground must be dismissed.

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
64
**Whether commercial activity**

However the decision of the Court of Appeal on that issue is of course persuasive authority. The second question
on this appeal is whether the Tribunal was right to prefer the observations of the majority in the Supreme Court to
the reasoning and conclusion of the Court of Appeal and the Supreme Court minority.
65

The Tribunal concluded that the correct approach was 'to decide which of the non-binding dicta of the superior
Courts I should follow' [77]. For this purpose it first observed that 'Ordinarily, a lower court would be likely to follow
the dicta of the majority of the Supreme Court in another case brought on identical facts.' [80]. It then concluded
that it should make the assumption that, had the Supreme Court been required to make a decision on the correct
interpretation of art 31, the majority would not have adopted the construction proposed by Lord Sumption: 'The
majority did not agree with that construction' [81]. The Tribunal adopted the reasoning of that majority [82], citing
various extracts from their judgments [83]–[86]. It concluded that the claim related to 'commercial activity' exercised
outside the respondent's 'official functions' [87] and thus rejected the defence of diplomatic immunity [88].
66
**Respondent's submissions**

In challenging this conclusion, Mr Sethi makes the following particular submissions. First, that the Tribunal in its
consideration of Reyes took no real account of the very detailed reasoning of the Court of Appeal or of the Supreme
Court minority. After passing references thereto [76]–[78], its focus turned to the observations of the Supreme Court
majority. It then simply adopted the reasoning of that majority without further consideration and analysis: [82].
67

Secondly, that the Tribunal was wrong to proceed on the basis of an assumption that, if the point had fallen for
binding decision, the majority would not have adopted the construction proposed by Lord Sumption. That
assumption was unwarranted because the observations of the majority amounted only to expressions of doubt as to
whether the interpretation adopted by the minority and the Court of Appeal was correct. Thus Lord Wilson expressly
accepted that Lord Sumption's 'emphatic' answer to the question 'may be correct' [57]; conceded that when
agreeing to its terms the parties to the 1961 Convention would have rejected any suggestion that the proceedings
brought by Ms Reyes related to any commercial activity exercised by her employer [67]; observed that in the
context of international interpretation of an international treaty it would be a 'strong thing' for the Court to divert from
the US jurisprudence set out in Tabion and to adopt the 'robust interpretation' for which Ms Reyes contended [68];
and stated that it would be preferable for the International Law Commission ('ILC') to be invited to consider, consult
and report upon the international acceptability of an amendment which would put beyond doubt the exclusion of
immunity in such a case [68]. No subsequent amendment had been made to art 31. Furthermore, the short
judgment of Baroness Hale and Lord Clarke simply expressed their agreement with what it described as 'the


-----

doubts' expressed by Lord Wilson as to whether the construction adopted by Lord Sumption was correct in this
particular context.
68

Thirdly, the Tribunal should have preferred the very detailed reasoning of the Court of Appeal and the Supreme
Court minority. The clear and emphatic conclusion reached in those judgments should have been preferred to the
doubts expressed by the Supreme Court majority.
69

Fourthly, even if not strictly bound thereby, the High Court decision in Propend and the EAT decision in Reyes were
highly persuasive; as is the US decision in _Tabion. The correctness of Laws J's statement in_ _Propend was_
expressly acknowledged in Reyes by
**[*255]**

Lord Dyson MR ([17]) and Lord Sumption ([21](3)). In this context of the international interpretation of an
international treaty, the authority of Tabion was accepted by Lord Dyson ([13]–[14]) and Lord Sumption ([23]).
70

Fifthly, that in referring ([85]) to Lord Wilson's contrast between a 'legally respectable solution' and a conclusion that
the legal system 'cannot provide redress for an apparently serious case of domestic servitude' ([68]), the Tribunal
had taken no account of his statements in the same paragraph that the Court was not put to the test of making that
choice and that it would be preferable for the ILC to be invited to consider an amendment to art 31. In any event,
the degree of seriousness of the subject matter could not affect the issue of whether or not there was diplomatic
immunity in the particular case.
71
**Claimant's response**

In response, Ms Webb emphasised that the Claimant's situation is not simply that of an employee seeking to
enforce employment rights. On the assumed facts she is a victim of trafficking, exploitation and **_modern slavery_**
conducted by the Respondent. She refers to the broad definition of trafficking in the Palermo Protocol (2000) and to
Lord Wilson's observation that this definition 'endeavours to encompass the whole sequence of actions that lead to
the exploitation of the victim' [61]. She points to the evidence which was before the Supreme Court and as updated
in such other documents as the 2014 report from the ILO 'Profits and poverty: the economics of forced labour'. As
expressed by Lord Wilson 'The perceived immunity makes trafficking with a view to domestic servitude a low risk,
high reward activity for diplomats': [59](5).
72

Adopting the observations of Lord Wilson, art 31(1)(c) should now be interpreted in the light of the 'universality of
the international community's determination to combat human trafficking' [60] as expressed through the Palermo
Protocol (2000), the Council of Europe Convention on Action against Trafficking in Human Beings (2005) and the
Arab Charter on Human Rights (2004). In that context, there was no true analogy between the employer of a
trafficked domestic servant and the purchaser of stolen property at a cheap price [62].
73

The Tribunal was right to have preferred these arguments when reaching its decision on the issue of 'commercial
activity' as applied to the assumed facts in this case; and not to prefer the reasoning of the Court of Appeal or the
Supreme Court minority in Reyes or the decisions in Propend and Tabion.
74

As to Reyes, the Tribunal had expressly referred to and taken into account the judgments of the Court of Appeal
and the Supreme Court minority: see [75]. There was no error of law nor perversity in its conclusion that the correct
approach was to decide 'which of the non-binding dicta of the superior Courts' should be followed [77]. The
Respondent's challenge to its decision placed undue weight both on the Tribunal's conclusion that it should assume
that the majority would not have adopted the construction proposed by Lord Sumption ([81]) and on its adoption of


-----

Lord Wilson's reference to an 'apparently serious' case of domestic servitude [85]). Ms Webb emphasised that
assessment of the various judgments should not involve a mere 'counting of heads'.
75

As to the United States cases, with the exception of Sabbithi v Al Saleh (2009) 605 F Supp 2d 122, these did not
involve consideration of the element of human trafficking. In that jurisdiction deference was given to a Statement of
Interest by the Government. Furthermore, Tabion and all the other decisions also found that the employment of the
domestic servant was within the official functions of the diplomat; and thus were at odds with the unanimous
decision of the Supreme Court on that point.
76

The Tribunal had taken the appropriate course of preferring the approach set out in the judgment of Lord Wilson;
and, in the context of an internationally-recognised trafficking problem, adopting a modern-day meaning to the
language of art 31(1)(c). Even on the narrow interpretation favoured by Lord Sumption, the critical feature of
trafficking the Claimant as a commodity was properly to be described as 'commercial activity'.
77
**Conclusion**

The question which fell for decision by the Tribunal is a pure question of law, to which there is a right and a wrong
answer. For this reason, the submissions relating to the approach taken by the Tribunal to that question are of
limited assistance. The question on appeal is whether the Tribunal's conclusion was correct in law. In effect, I have
to consider the question of law afresh.
78

For this purpose, I make two preliminary observations. First, I need no persuasion of the natural impulse to provide
legal redress for victims of this abhorrent trade. However, as all the judgments of the Court of Appeal and Supreme
Court emphasise, diplomatic immunity involves countervailing issues of high international policy.
79

Secondly, the parties have rightly not taken me through the detail of the domestic and international material which
was considered by the Court of Appeal and Supreme Court in _Reyes or thereby reargued the case through that_
extensive material. Instead they have taken the sensible course of pointing to the conclusions and observations in
the various judgments of the higher courts in Reyes and then presented arguments as to which should be regarded
as the more persuasive.

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
80

This inevitably results in a somewhat invidious task for a lower tribunal. However, I am fully persuaded that, at least
at this level, greater weight should be given to those judgments of the higher courts in Reyes which, in the light of
detailed analysis of the relevant material, provide a clear (albeit non-binding) conclusion on the point; and that
lesser weight should be given to judgments which express even very strong doubts on that conclusion. This is not
to fall into the error of treating judgments in the first category as if they were binding, nor of 'counting heads', but is
simply to give greater weight to those higher judicial observations which have reached emphatic conclusions on the
point. Whether those conclusions should ultimately prevail is a matter for resolution at a higher level.

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
81

In Reyes the Court of Appeal reached a clear and fully reasoned decision, on assumed facts akin to those in the
present case, that this was not 'commercial activity'. The material which it considered was comprehensive, taking
full account of the relevant international treaty obligations and international authority, notably Tabion; and endorsing
existing domestic authority, in particular Propend. In the Supreme Court, Lord Sumption reviewed this and further
material in great detail and reached a conclusion, albeit in non-binding terms, which accorded with the Court of
Appeal on the issue of 'commercial activity' Lord Neuberger agreed with his analysis and conclusion


-----

82

I should add that I do not accept the Claimant's submission that, of the US decisions, it is only Sabbithi
**[*256]**

which involves the 'trafficking dimension': see Lord Sumption's discussion of those decisions at [47].

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
83

By contrast, Lord Wilson's judgment on this point does not reach a clear conclusion to the contrary. Thus, it
recognises the force of established features of international law in this respect; and accepts that when agreeing to
the terms of the 1961 Convention the parties would have rejected any suggestion that the proceedings brought by
Ms Reyes related to any commercial activity exercised by her employer. Having advanced arguments that
interpretation should not be frozen in time but should reflect developments in international law, Lord Wilson
nonetheless acknowledges that the established principles for the international interpretation of international treaties
would make it a 'strong thing' to divert from the jurisprudence in the United States, in particular Tabion. The wish for
a 'legally respectable solution' providing redress is made clear. However, in circumstances where the Court is 'not
being put to that test', he concludes that it would be preferable for the ILC to review the whole matter and consider
the 'international acceptability' of an amendment to put the matter beyond doubt. The judgment of Baroness Hale
and Lord Clarke then associates them with what it describes as 'the doubts' expressed by Lord Wilson on the
construction adopted by Lord Sumption.

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
84

In circumstances where the observations of Lord Wilson, Baroness Hale and Lord Clarke were expressed in these
relatively tentative terms, I consider that the Tribunal was wrong to proceed on the basis of an assumption that, if it
had been necessary to decide the point, the majority would not have adopted the construction proposed by Lord
Sumption. In my judgment the decisions of the Court of Appeal and of Lords Sumption and Neuberger represent the
current state of the law on the issue of 'commercial activity'. Accordingly, I would allow the appeal on this ground
and hold that the defence of diplomatic immunity succeeds.

**End of Document**


-----

