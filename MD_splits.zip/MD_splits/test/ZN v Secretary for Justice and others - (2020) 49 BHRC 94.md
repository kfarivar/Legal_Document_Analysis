# ZN v Secretary for Justice and others (2020) 49 BHRC 94

[2019] HKCFA 53

COURT OF FINAL APPEAL OF HONG KONG

MA CJ, RIBEIRO, FOK PJJ, CHAN AND McLACHLIN NPJJ

3, 4 DECEMBER 2019, 10 JANUARY 2020

**Slavery, servitude and forced or compulsory labour — Human trafficking — Appellant trafficked to Hong**
**Kong — Whether prohibition against slavery, servitude or forced or compulsory labour including**
**prohibition against human trafficking — Whether positive duty to maintain specific offence criminalising**
**slavery, servitude or forced or compulsory labour — Hong Kong Bill of Rights, art 4.**

The appellant was brought to Hong Kong to work as a foreign domestic helper between 2007 and 2010. During that
period, he was badly mistreated by his employer to an extent that constituted forced or compulsory labour within the
meaning of art 4(3)[a] of the Hong Kong Bill of Rights. Article 4 was derived from and was in similar terms to art 8 of
the International Covenant on Civil and Political Rights ('ICCPR'). After returning to Hong Kong in 2012, the
appellant sought to report that treatment to various government agencies. Unsatisfied with the response, he
commenced judicial review proceedings. The judge found, inter alia, that implicit in each of the concepts prohibited
by art 4 was a prohibition against trafficking a person for each of slavery, servitude and forced or compulsory labour
respectively, and that the prohibited concepts of slavery, servitude and forced or compulsory labour under art 4
included cases where a person was trafficked for such purposes and that anyone involved in the transportation of a
person for slavery, servitude or forced or compulsory labour was caught by that provision. He was satisfied that the
evidence supported a case that the appellant was a victim of trafficking for the purpose of forced labour. He went on
to find that the current legal regime in Hong Kong did not address adequately or effectively the positive obligations
under art 4 to tackle forced labour and the trafficking of persons for forced labour, in particular because of the lack
of a criminal offence and penalty that addressed the prohibited concept of forced or compulsory labour. The
respondents' appeal against that judgment was successful in part. On the appellant's further appeal, two principal
issues arose. First, whether art 4 included a prohibition against human trafficking and, if so, what the scope of that
prohibition was. Secondly, whether art 4 imposed a positive duty on the Government of the Hong Kong Special
Administrative Region ('HKSARG') to maintain a specific offence criminalising the activities prohibited under that
article.

**Held – (1) As a general proposition, when the legislature had chosen, in the course of the same provision of an**
ordinance, to use different words to express concepts, it was to be assumed that the different words were intended
to convey different meanings. There was no reason to disapply that principle to an international treaty (the ICCPR)
which a local ordinance (the Bill of Rights) had domesticated. It was clear that art 4 was structured to distinguish
between

1

**[*95]**

A i l 4 i [5] b l


-----

slavery, servitude and forced or compulsory labour as separate and distinct concepts, with the concept of forced or
compulsory labour being qualitatively different from slavery and servitude in that it was derogable. Even assuming
that human trafficking for the purposes of slavery fell within the phrase 'slavery and the slave-trade in all their forms'
in art 4(1), the prohibitions on servitude and forced or compulsory labour in art 4(2) and (3)(a) were prohibitions of
substantive conduct rather than processes. The prohibition on servitude in art 4(2) was clearly a reference to the
state of being held in servitude and not to any anterior process by which a person might be brought to that status.
To expand the meaning of art 4 to prohibit human trafficking for exploitation generally would be to ignore the
language of art 4 and impermissibly to alter the underlying concepts addressed in art 4(2) and (3)(a). Moreover, the
reference in art 4(1) to 'slavery and the slave-trade in all their forms' was not a generic reference to servitude and
forced or compulsory labour. Similarly, it was not helpful to describe human trafficking as a form of modern slavery
(a term that was not well-defined) in order to define art 4. Although art 4, as a constitutionally protected human right,
was to be construed generously, its language did not support the expansive construction contended for by the
appellant. Similarly, although the Bill of Rights was to be construed as a living instrument, there was no justification
for giving an updated construction to the concepts of slavery, servitude and forced or compulsory labour that
resulted in a meaning that was conceptually different (see [41]–[47], [54], [55], [80]–[82], below). Rantsev v Cyprus
_[and Russia (App no 25965/04) (2010) 28 BHRC 313 criticised. Hacienda Brasil Verde Workers v Brazil (20 October](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
2016, unreported) distinguished. Boyce v R _[(2004) 17 BHRC 118 and Birmingham City Council v Oakley [2001] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4PW-00000-00&context=1519360)_
_[All ER 385 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61N3-00000-00&context=1519360)_

(2) The HKSARG had a wide margin of discretion in the manner in which it complied with its positive obligations
under art 4 and there was no absolute duty on the HKSARG to maintain an offence specifically criminalising forced
or compulsory labour. To comply with its obligations in respect of art 4, the HKSARG had to take steps to afford
practical and effective protection of those rights. Whether practical and effective protection had been provided
would depend on the facts of any given case. The determination that a bespoke offence was not required did not
preclude a different conclusion being reached in a future case, in the event that the HKSARG was shown in future
not to have afforded practical and effective protection of the rights under art 4 by reason of the absence of such an
offence. Nor should the instant judgment be taken to indicate that a patchwork of offences would necessarily be
sufficient to address a prohibition on human trafficking, if the HKSARG were under a constitutional duty to prohibit
that activity (see [93], [100], [104], [114], [121], [122], below).
**Cases referred to**

_[Beganović v Croatia (App no 46423/06) [2009] ECHR 46423/06, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_

_[Birmingham City Council v Oakley [2001] 1 All ER 385, [2001] 1 AC 617, [2001] LGR 110, [2000] 3 WLR 1936, UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61N3-00000-00&context=1519360)_
HL.

_[Botta v Italy (App no 21439/93) (1998) 4 BHRC 81, (1998) 26 EHRR 241, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3GY-00000-00&context=1519360)_

_[Boyce v R [2004] UKPC 32, (2004) 17 BHRC 118, [2005] 1 AC 400, [2004] 4 LRC 749, [2004] 3 WLR 786, Barb](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4PW-00000-00&context=1519360)_
PC.

_CN v France (App no 67724/09) (judgment, 11 October 2012), ECtHR._

_[CN v UK (App no 4239/08) (2012) 34 BHRC 1, (2012) 56 EHRR 24, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_

_[Comilang v Director of Immigration [2019] HKCFA 10, (2019) 48 BHRC 254, (2019) 22 HKCFAR 59, HK CFA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YYJ-M7F3-CGXG-02MB-00000-00&context=1519360)_

**[*96]**

_Courtauld v Legh (1869) LR 4 Exch 126._

_[Demir v Turkey (App No 34503/97) [2009] IRLR 766, (2008) 48 EHRR 1272, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W43C-00000-00&context=1519360)_

_Director of Immigration v Chong Fung Yuen [2001] HKCFA 48, (2001) 4 HKCFAR 211, [2001] 2 HKLRD 533, HK_
CFA


-----

_European Roma Rights Centre v Immigration Officer at Prague Airport (United Nations High Commissioner for_
_[Refugees intervening) [2004] UKHL 55, (2004) 18 BHRC 1, [2005] 2 AC 1, [2005] 1 All ER 527, [2005] 2 WLR 1,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W04T-00000-00&context=1519360)_
UK HL.

_Hacienda Brasil Verde Workers v Brazil (20 October 2016, unreported), IACHR._

_HKSAR v Cheung Wai Kwong [2017] HKCFA 103, (2017) 20 HKCFAR 524, HK CFA._

_HKSAR v Wan Thomas [2018] HKCFA 15, (2018) 21 HKCFAR 214, HK CFA._

_Koon Wing Yee v Insider Dealing Tribunal [2008] HKCFA 21, (2008) 11 HKCFAR 170, [2008] 3 HKLRD 372, HK_
CFA.

_[Lendore v A-G [2017] UKPC 25, [2017] 5 LRC 369, [2017] 1 WLR 3369, T & T PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R18-V471-DYJ0-83VD-00000-00&context=1519360)_

_Leung Kwok Hung v HKSAR [2005] HKCFA 40, (2005) 8 HKCFAR 229, [2005] 3 HKLRD 164, HK CFA._

_[M v Italy and Bulgaria (App no 40020/03) (2013) 57 EHRR 29, [2012] ECHR 40020/03, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3WW-00000-00&context=1519360)_

_[Matadeen v Pointu [1998] 3 LRC 542, [1999] 1 AC 98, [1998] 3 WLR 18, Maur PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84JK-00000-00&context=1519360)_

_[Ng Ka Ling v Director of Immigration [1999] HKCFA 17, (1999) 6 BHRC 447, (1999) 2 HKCFAR 4, HK CFA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W075-00000-00&context=1519360)_

_[O'Keeffe v Ireland (App no 35810/09) (2014) 35 BHRC 601, (2014) 59 EHRR 605, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3BS-00000-00&context=1519360)_

_[Plattform Arzte für das Leben v Austria (App no 10126/82) (1988) 13 EHRR 204, (1988) Times, 30 June, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4XS-00000-00&context=1519360)_

_Prosecutor v Kunarac (Case nos IT 96–23 and IT-96–23/1) (22 February 2001), ICTY; (12 June 2002), ICTY_
(Appeals Chamber).

_R v Islam_ _[[2009] UKHL 30, [2010] 1 All ER 493, [2009] AC 1076, [2009] 3 WLR 1, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XNJ-DJK0-Y96Y-G16X-00000-00&context=1519360)_

_[R v K [2011] EWCA Crim 1691, [2012] 1 All ER 1090, [2013] QB 82, [2012] 3 WLR 933, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M31M-00000-00&context=1519360)_

_[R v Tang [2008] HCA 39, (2008) 25 BHRC 35, (2008) 237 CLR 1, [2009] 2 LRC 592, Aus HC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W35D-00000-00&context=1519360)_

_[R (on the application of Quintavalle) v Secretary of State for Health [2003] UKHL 13, [2003] 2 All ER 113, [2003] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-60B3-00000-00&context=1519360)_
[AC 687, (2003) 71 BMLR 209, [2003] 2 WLR 692, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FNG-MXM0-TWW8-X131-00000-00&context=1519360)

_[Rantsev v Cyprus and Russia (App no 25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_Shum Kwok Sher v HKSAR [2002] HKCFA 27, (2002) 5 HKCFAR 381, HK CFA._

_[Siliadin v France (App no 73316/01) (2005) 20 BHRC 654, (2005) 43 EHRR 287, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

_Ubamaka v Secretary for Security [2012] HKCFA 87, (2012) 15 HKCFAR 743, HK CFA._
**Appeal**

The appellant, ZN, appealed with permission from the judgment of the Court of Appeal (Cheung CJHC, Lam VP
and Poon JA) of 2 August 2018 ([2018] HKCA

**[*97]**

473, [2018] 3 HKLRD 778) allowing in part the appeal of the respondents, the Secretary for Justice, Director of
Immigration, Commissioner of Police and Commissioner for Labour, from the judgment of Zervos J of 23 December


-----

2016 granting the appellant declaratory relief in his judicial review claim alleging a breach of his rights under art 4 of
the Hong Kong Bill of Rights. The facts are set out in the judgment of Fok PJ.

Raza Husain QC and Azan Marwah (instructed by Patricia Ho & Associates, assigned by the Director of Legal Aid)
for the appellant.

Lord Pannick QC, Stewart Wong SC, Jin Pao SC and John Leung (instructed by the Department of Justice) for the
first to fourth respondents.

10 January 2020. The following judgments were delivered.

**MA CJ.**

**[1] I agree with the judgment of Fok PJ.**

**RIBEIRO PJ.**

**[2] I agree with the judgment of Fok PJ.**

**FOK PJ.**
**A. Introduction**

**[3] The appellant, whose name has been anonymised in these proceedings as ZN, was brought to Hong Kong to**
work as a foreign domestic helper between 2007 and 2010. During that period, he was badly mistreated by his
employer to an extent that constituted forced or compulsory labour within the meaning of art 4(3) of the Hong Kong
Bill of Rights.[1] After returning to Hong Kong in 2012, the appellant sought to report that treatment to various
Government agencies but was treated in a way described to us by the respondents' counsel as 'disgraceful'.

**[4] As will be seen, arising from those basic facts, which are described in more detail below, this appeal broadly**
raises two important questions of law concerning BOR4:[2]

(1)   Does BOR4 include a prohibition against human trafficking and, if so, what is the scope of that
prohibition?

(2)   Does BOR4 impose a positive duty on the Government of the Hong Kong Special Administrative
Region ('HKSARG') to maintain a specific offence criminalising the activities prohibited under that article?

_A.1 BOR4_

**[5] Since it is central to this appeal, it is convenient to set out the terms of BOR4 at the outset of this judgment.**
BOR4 provides:

'Article 4

**No slavery or servitude**

(1) No one shall be held in slavery; slavery and the slave-trade in all their forms shall be prohibited.

(2) No one shall be held in servitude.

2

1   The Hong Kong Bill of Rights ('HKBOR') is set out in s 8 of the Hong Kong Bill of Rights Ordinance (Cap 383)
('HKBORO'). In this judgment, articles in the HKBOR will be referred to by the abbreviation 'BOR' followed by the
l b d i l


-----

**[*98]**

(3) (a) No one shall be required to perform forced or compulsory labour.

(b) For the purpose of this paragraph the term “forced or compulsory labour” shall not include—

(i) any work or service normally required of a person who is under detention in consequence of a lawful order
of a court, or of a person during conditional release from such detention;

(ii) any service of a military character and, where conscientious objection is recognized, any national service
required by law of conscientious objectors;

(iii) any service exacted in cases of emergency or calamity threatening the life or well-being of the community;

(iv) any work or service which forms part of normal civil obligations.'

_A.2 The phenomenon of human trafficking_

**[6] Although the present case arises out of the facts concerning the appellant's own case, the context of the case is**
wider. That wider context is the phenomenon of human trafficking, which is a worldwide problem and has also been
recognised by the HKSARG as a Hong Kong problem. The accepted definition of human trafficking (which will be
referred to in greater detail later in this judgment) is that set out in the Protocol to the United Nations Convention
against Transnational Organized Crime, commonly referred to as the Palermo Protocol.[3] Human trafficking can
rightly be called an evil scourge since it involves the movement of persons by deployment of certain underhand
means for the purpose of exploiting them. The exploitation takes a number of serious forms including sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of organs.

**[7] Although, as will be seen, the Palermo Protocol does not apply to Hong Kong, the problem of human trafficking**
nevertheless remains recognised as a substantive problem internationally as reflected by various measures taken
in various parts of the world to combat it. In May 2005, the Council of Europe Convention on Action Against
Trafficking in Human Beings ('the Anti-Trafficking Convention') was adopted with one of its purposes being the
prevention of human trafficking. In April 2011, the European Commission adopted a Directive on the trafficking in
human beings.[4] In 2015, the United Nations adopted 17 Sustainable Development Goals, which included a target to
end slavery, with a directive to 'take immediate and effective measures to eradicate forced labour, end **_modern_**
**_slavery and human trafficking and secure the prohibition and elimination of the worst forms of child labour'.[5] Also in_**
[2015, the UK enacted the Modern Slavery Act 2015, which makes provision about slavery, servitude and forced or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
compulsory labour and about human trafficking.

**[8] With a total of approximately 370,000 foreign domestic helpers working in Hong Kong, there is potentially a**
sizeable number of persons at risk of exploitative practices that might constitute either forced or compulsory labour
or human trafficking. That these matters are also a problem in Hong Kong, albeit the scale of that problem is a
matter of contention between the parties, is reflected in the further evidence that was filed for the hearing of this
case in the

3

2   The questions of law for which leave to appeal to this Court was granted by the Court of Appeal are set out below
in section A.5.

3   Its full name is the 'Protocol to Prevent, Suppress and Punish Trafficking in Persons Especially Women and
Children, supplementing the United Nations Convention against Transnational Organized Crime'; Adopted and opened
for signature, ratification and accession by General Assembly Resolution 55/25 of 15 November 2000.

4   Directive 2011/36/EU.

5 R l i d d b h G l A bl 25 S b 2015 A/RES/70/1 [8 7] 20


-----

**[*99]**

Court of Appeal. That evidence (discussed further below) refers to the fact that, in March 2018, the HKSARG
established 'a high-level, inter-bureaux/departmental Steering Committee chaired by the Chief Secretary for
Administration to offer [a] strategic steer in respect of tackling [issues concerning human trafficking]' and that an
'Action Plan to Tackle Trafficking in Persons and to Enhance Protection of Foreign Domestic Helpers in Hong Kong'
was launched on 21 March 2018.[6]

_A.3 The Judicial Review_

**[9] Following the treatment to which he was subjected by the Immigration Department, the Police and the Labour**
Department (described in section A.6 below), the appellant commenced judicial review proceedings against the
respondents seeking declaratory relief and damages for breach of his rights under BOR4. The proceedings were
heard by Zervos J (as he then was) in January 2016 and the appellant gave oral evidence at the hearing which was
subject to cross-examination.[7] The Judge noted that he was asked to determine whether the appellant was a victim
of human trafficking for forced labour[8] and also whether the officers of the relevant authorities failed or neglected, in
breach of BOR4, to take appropriate action in dealing with his case as one involving human trafficking or forced
labour.[9]

**[10] Whilst acknowledging that he did not have evidence from the appellant's employer or any other relevant**
witness concerning the events during 2007 and 2010, Zervos J made findings of fact based on the evidence
presented to him. These findings, at [160] and [161] of the CFI Judgment, are set out in section A.6 below. There
was no appeal by the respondents against those findings of fact.

**[11] The central legal issue in the judicial review was the interpretation of BOR4.[10] The Judge held that implicit in**
each of the concepts prohibited by BOR4 is a prohibition against trafficking a person for each of slavery, servitude
and forced or compulsory labour respectively.[11] He held that the prohibited concepts of slavery, servitude and
forced or compulsory labour under BOR4 included cases where a person is trafficked for such purposes and that
anyone involved in the transportation of a person for slavery, servitude or forced or compulsory labour is caught by
BOR4.[12]

**[12] The Judge was satisfied that the evidence supported a case that the appellant was a victim of trafficking of a**
person for the purpose of forced labour.[13]

**[13] The Judge found that the current legal regime in Hong Kong does not address adequately or effectively the**
positive obligations under BOR4 to tackle forced labour and the trafficking of persons for forced labour.[14] He held
that the

4

6   Affidavit of Ng Hoi Ka, Assistant Secretary for Security of the Security Bureau, dated 4 May 2018, at [4].

7   HCAL 15/2015, Judgment dated 23 December 2016 ('CFI Judgment') ([2016] HKCFI 2179, [2017] 1 HKC 340,

[2017] 1 HKLRD 559).

8   The appellant initially argued his case amounted one of servitude but ultimately put his case on the basis he was a
victim of human trafficking for forced labour: CFI Judgment at [8].

9   CFI Judgment at [10] and [18].

10 _Ibid at [163]._

11 _Ibid at [260]._

12 _Ibid at [353]._

13 _Ibid at [337] and [343]._

14 _Ibid_ [312]


-----

**[*100]**

critical flaw in the HKSARG's obligations under BOR4 was the lack of a criminal offence and penalty that addresses
the prohibited concept of forced or compulsory labour.[15] The Judge went on to hold that the HKSARG had positive
obligations under BOR4 to enact measures to ensure the prohibition of forced or compulsory labour, including
trafficking for that purpose.[16] He found that the HKSARG has not adequately fulfilled its positive obligations under
BOR4 and that the appellant was denied his rights thereunder in not having his case recognised by the relevant
authorities as one possibly involving human trafficking for forced labour.[17]

**[14] The Judge therefore granted a declaration in the following terms:**

'The application for judicial review be granted in so far as on the evidence presented, the evidence points to the
Applicant having been a victim of human trafficking for forced labour, or forced labour, and that he, on various
occasions from April 2012, approached officers of the relevant authorities and gave an account of his case that
should have been sufficient to alert them, at least on some occasions, that this was a possible case of human
trafficking for forced labour, or forced labour, and prompted them to take appropriate action; and that the
Applicant was denied protection under Article 4 of the BOR, which in turn was due to the failure of the
HKSARG to fulfil its obligations under Article 4 of the BOR.'

He also directed that a further hearing be fixed for argument on the question of relief, including the question of costs
and damages.
_A.4 The Court of Appeal_

**[15] The respondents' appeal against Zervos J's judgment was allowed in part.[18] There were four issues on the**
appeal: (1) whether BOR4 covers human trafficking for forced labour; (2) whether the appellant was a victim of
forced labour; (3) whether the HKSARG is in breach of its positive duties under BOR4 by not enacting a specific
criminal offence to combat forced labour (or human trafficking for forced labour); and (4) whether the HKSARG
breached its investigative duty under BOR4 in the case of the appellant.[19]

**[16] The main judgment was delivered by Cheung CJHC (as Cheung PJ then was), with concurring judgments from**
Lam VP and Poon JA.

(1)   On issue (1), the Court of Appeal held that BOR4 does not cover human trafficking (as a form of
**_modern slavery) or human trafficking for forced labour.[20]_**

(2)   On issue (2), the Court held that a case of forced labour in contravention of BOR4(3) had clearly
been established.[21]

(3)   On issue (3), the Court held that the case that the HKSARG had breached its positive obligations
under BOR4 to provide practical and effective protection against forced labour by means of a specific
criminal

5

15 _Ibid at [351]._

16 _Ibid at [355]._

17 _Ibid at [356]._

18   CACV 14/2017, [2018] HKCA 473, [2018] 3 HKLRD 778, judgment dated 2 August 2018 ('CA Judgment').

19   CA Judgment at [35].

20 _Ibid at [132]._

21 _Ibid_ [151]


-----

**[*101]**

offence had not been made out and that Zervos J's finding that the HKSARG had breached its positive
duties under BOR4 must be disturbed.[22]

(4)   On issue (4), the Court upheld the Judge's finding that the HKSARG had failed in its investigative
duty under BOR4 in relation to the appellant's complaints in the present case.[23]

**[17] By way of disposition of the appeal, the Court of Appeal allowed the appeal in part by amending the declaration**
made by Zervos J (set out at [14] above) to read:

'The application for judicial review be granted on the basis that: (1) on the evidence presented, the evidence
points to the applicant having been a victim of forced labour; (2) he, on various occasions from April 2012,
approached officers of the relevant authorities and gave an account of his case that should have been
sufficient to alert them, at least on some occasions, that this was a possible case of forced labour, and
prompted them to take appropriate action which they failed to do; (3) the HKSARG was therefore in breach of
its procedural obligation to investigate situations of potential forced labour under article 4 of the BOR; and (4)
the applicant was denied protection under the same as a result.'[24]

_A.5 Leave to appeal to this Court_

**[18] The Court of Appeal[25] granted the appellant leave to appeal to the Court of Final Appeal on two questions of**
law of great general or public importance, namely:

'Does art 4 BOR prohibit human trafficking: (a) for the purpose of exploitation; (b) for the purposes of slavery,
servitude and forced labour; or (c) for the purpose of forced labour?'

and

'Does art 4 BOR impose an absolute duty on the Hong Kong SARG to maintain an offence specifically
criminalising (a) forced labour; or (b) human trafficking for the purposes of forced labour; or (c) human
trafficking for the purposes of slavery, servitude and forced labour; or (d) human trafficking for the purpose of
exploitation? If not, does art 4 BOR impose (i) a contingent duty to maintain such an offence, and (ii) does the
contingency arise (and is the duty triggered) when existing criminal law measures are ineffective, or (iii) is there
a further requirement, such as the requirement, for example that maintaining such an offence is the only means
of redressing the ineffectiveness?'

_A.6 The Judge's findings of fact_

**[19] The facts concerning the appellant's employment and the exploitation to which he was subjected by his**
employer as well as the woefully ineffectual response of the respondents when he tried to report the mistreatment
to the authorities were set out at [160] and [161] of the CFI Judgment. These tell a disturbing story and merit being
set out in full.

**[20] The Judge recorded (at [160]):**

6

**[*102]**

22 _Ibid at [187]._

23 _Ibid at [196]._

24 _Ibid at [198]._

25   Order of Lam VP, Barma and Poon JJA dated 21 May 2019 (Barma JA sitting in place of Cheung CJHC, who by
h h d b i d P J d f hi C )


-----

'On the evidence and materials before me, and for the purposes of these proceedings, I make the following
relevant findings of fact:

(1) The applicant is a Pakistani national who is a member of the Malik caste, which is considered in Pakistan,
and accepted by the applicant, as being inferior to the Rana caste.

(2) The employer and his family belong to the Rana caste. The employer comes from a prominent and wellconnected family in Punjab, Pakistan, with extensive business interests in Pakistan, South Africa and Hong
Kong.

(3) The applicant worked for the employer and his family in Pakistan. Socio-economic and cultural norms led
to the employer asserting considerable command and control over the applicant.

(4) The employer and his family arranged for the applicant to work for them in Hong Kong. They sponsored his
work permit and arranged his transportation to Hong Kong. The applicant had not previously travelled out of
Pakistan. Because of his low education and low socioeconomic status he was not familiar with the system and
structures in Hong Kong.

(5) The employer promised the applicant that he would have good working conditions and that he would
receive a salary of $4,000 per month, although in the two contracts the monthly salary payment specified was
respectively $3,400 plus $300 food allowance, and $3,580 plus $300 food allowance. I accept that documents
may have been presented to him by the employer, but that he did not understand them and in some instances
did not sign them.

(6) The applicant was accompanied to Hong Kong in January 2007 by a member of the employer's family who
held the travel and identification documents of the applicant. These documents were kept by the employer
while he was in Hong Kong.

(7) While in Hong Kong the applicant was kept under the control of the employer and his family. The applicant
was constrained and controlled both psychologically and economically by the employer.

(8) All formal arrangements for the applicant's employment and residence in Hong Kong were organised and
arranged by the employer. The applicant had no knowledge of his rights and obligations or of those of his
employer. He was placed in a state of dependency on the employer.

(9) The applicant was employed as a foreign domestic helper. However, he was required to work in the
employer's trading company (which the applicant agreed to do) and reside at the office premises of the
company. He slept on the carpeted floor of one of the offices at the premises. He was required to work long
hours, seven days a week. He was given two meals a day and his movements were restricted to the office
premises except for office errands. He was able to take breaks, but it is unclear how often these occurred and
for how long they lasted. As the applicant resided at the office premises, he was under the direction and control
of the employer; his movements were restricted; he had limited enjoyment of privacy; and was unable to live a
normal life.

(10) The applicant was regularly abused and beaten by the employer. Although he did not sustain serious
injuries, he was nevertheless treated in a degrading and abusive manner. He worked under conditions of
constant abuse, threats and beatings.

(11) The employer and his family cajoled and deceived the applicant into taking up the employment in Hong
Kong. The applicant was deceived

**[*103]**

about his working conditions (long hours of work and subjection to abuse and beatings) and payment of wages
(unpaid for nearly four years).


-----

(12) The employer threatened the applicant that serious harm would result to him and his family if he left his
employ, and claimed that he owed the employer a large sum of money for having been brought to Hong Kong.

(13) The employer tricked the applicant into agreeing not to receive his monthly wage, and put off paying him
the full remuneration due to him under the terms of his employment contracts.

(14) At the end of 2010, the applicant asked the employer to give him an advance on his unpaid wages to
assist his family in Pakistan. The employer deceived the applicant into returning to Pakistan, and then
terminated his contract and sponsorship in order to avoid paying him the money that he owed him. This was
also designed to prevent the applicant from returning to Hong Kong and claiming his unpaid wages against the
employer.

(15) The employer and members of his family and his associates, both in Hong Kong and in Pakistan,
threatened the applicant and his family regarding the applicant's pursuit of his claim for outstanding wages from
the employer.

(16) The employer, both directly and through his associates, made threats against the applicant in order to get
him to withdraw or settle his unpaid salary claim.

(17) During the period when the applicant worked for the employer, from May 2007 to December 2010, he
made no report or complaint to the police or to any other authorities. He was not aware of his rights or
remedies, and in particular he was unaware that his case could amount to one of human trafficking for forced
labour.

(18) The applicant in early December 2010 requested payment of the monies the employer owed him. The
employer arranged the return of the applicant to Pakistan on the basis of him taking a holiday. While the
applicant was in Pakistan, the employer terminated his contract and revoked his sponsorship in order to
prevent the applicant from returning to Hong Kong to make a claim against him for the unpaid wages.

(19) The applicant returned illegally to Hong Kong in April 2012 to claim his unpaid wages from his employer
and to report the mistreatment that he had suffered from the employer.

(20) The applicant attended the Immigration Department in early April 2012 to report that he had returned
illegally to Hong Kong to claim his unpaid wages from his employer, and that he had been mistreated by him.

(a) On the occasions where there are records of his attendances, these records do not disclose the detailed
information that the applicant states he provided at the time. It is recorded that the applicant did mention that
he had returned to claim unpaid wages for nearly four years['] work, and this factor alone should have alerted
the officer that his case may have involved a serious abuse of labour.

(b) There was an occasion in early April 2012 when the applicant attended the office at Skyline Tower and
spoke to an Immigration Department officer. He told the officer that he had come to Hong Kong illegally and
was seeking help from the authorities to obtain his unpaid salary from his employer. He told the officer that he
had worked in Hong Kong for almost four years and had never been paid. He gave details of the employer's
name and the place of work. He told the officer

**[*104]**

about the unfair treatment he had received from the employer, and mentioned that the employer had assaulted
and abused him. The officer told him that this was a police case and that he should go to the police station.

(21) From June to September 2013, the applicant was interviewed on several occasions by an officer of the
Immigration Department in relation to his CAT claim. During the interviews, the applicant mentioned to the
officer his entire story concerning the circumstances of his four-year employment in Hong Kong, including that
he had been mistreated by the employer and that he had not been paid for the work that he had performed.


-----

(22) The applicant attended the Labour Department on 2 May 2012 and, with the assistance of a Labour
Department officer, registered a claim for unpaid wages of over $200,000. He told the officer that he had
worked for the employer for four years and was never paid. He said his employer had beaten him during his
employment, and had forced him to return to Pakistan.

(23) The applicant on various occasions in early April 2012, and on 17 May 2012, 28 May 2012, 27 July 2012
and 18 August 2012, attended various police stations and reported or complained to police officers about
matters concerning threats by his employer in relation to his past employment with the employer and his claim
for unpaid wages.

(a) In early April 2012, the applicant attended the Tsim Sha Tsui Police Station, having been told to report his
case to the police by an officer of the Immigration Department. He told a police officer that he had entered
Hong Kong without a visa and that he had worked in Hong Kong for four years and had not been paid. The
police officer told him to return to the Immigration Department.

(b) On another occasion in early April 2012, the applicant attended Yau Ma Tei Police Station. He was spoken
to by several police officers. He told them that he did not have a visa. He said he had worked for four years in
Hong Kong and that he had not been paid. He said he returned to Hong Kong to obtain his unpaid salary. He
said that during his employment he was beaten by his employer. He also told them that his employer wanted to
kill him. The police officers said it was not a police matter and that he should go back to the Immigration
Department.

(c) On 16 July 2015, the applicant together with his legal representative attended Wan Chai Police Station.
They reported to the police recent threats made to the applicant, and mentioned his human trafficking and
forced labour case. A senior officer was informed about the applicant's human trafficking and forced labour
case. This officer registered the case, but suggested that the matter be referred to the Immigration Department.

(24) The applicant stood trial in the District Court for an offence of robbery against associates of the employer,
of which he was acquitted. There is a distinct possibility that he was wrongly accused of the crime.'

**[21] The Judge went on to record (at [161]):**

'On the evidence and materials before me, and for the purposes of these proceedings, I accept that:

(1) The applicant was deceived by the employer and his family about his working conditions and payment of
wages.

**[*105]**

(2) The applicant was regularly abused and beaten by the employer. Although this was not to a degree that
required his hospitalisation, it was to such an extent that that the applicant was put in fear of the employer and
placed under his control.

(3) The applicant worked long hours and was taken advantage of by the employer.

(4) Whilst the applicant was generally able to go out, he was nevertheless subject to restrictions by the
employer that prevented him from living a normal life. His foreignness was exploited by the employer in order to
restrict his movements and control him. He was also controlled due to the employer's psychological and
financial power over him.

(5) The applicant lived in the office premises and relied on handouts, although he may have received some
funds.

(6) The applicant did not complain of the ill treatment he was receiving by the employer for the reasons he has
given. He was afraid of the employer and his family and he expected he would receive the money owing to him.
I should point out that the applicant, like many victims of abuse, tolerated and accepted more than he should


-----

have. Furthermore, he was unaware of his rights and remedies in Hong Kong and of the fact that the ill
treatment he was suffering potentially constituted a case of human trafficking for forced labour.

(7) The employer tricked the applicant into returning to Pakistan and then terminated his contract and
sponsorship in order to prevent the applicant from making a claim against him for his unpaid salary.

(8) The employer refused to pay the applicant his unpaid wages and used force and threats in Pakistan
against him and his family to stop him from pursuing his claim.

(9) The applicant returned to Hong Kong to press his claim for his unpaid salary, and to seek justice in relation
to the treatment he had received from the employer.

(10) The employer and his associates threatened the applicant and his family in relation to the applicant's
claim for the unpaid salary in Hong Kong.

(11) The applicant attended the offices of the Immigration Department, the Labour Department and the Police
on the various occasions that he has claimed, and revealed to the officers whom he saw information about the
treatment he had received from the employer, and the fact that he had not been paid wages for a period of four
years. The officers concerned should have been alerted that the applicant's case involved a serious abuse of
labour and that the applicant was potentially a victim of human trafficking or forced labour.

(12) The applicant did not appreciate that he was a victim of human trafficking for forced labour.'

**B. The parties' contentions on this appeal**

**[22] The issues have narrowed since the hearing in the Court of Appeal. The appellant now seeks from this Court a**
declaration that the HKSARG is obliged to promote laws specifically criminalising human trafficking and forced or
compulsory labour as specific offences.

**[23] It was the contention of Mr Raza Husain QC, leading counsel for the appellant,[26] that the two questions set out**
at [4] above should be answered in the

7

**[*106]**

affirmative and that, accordingly, the declaration he sought (at [25] below) should follow. On the first question, it was
his contention that human trafficking was prohibited under BOR4 generally and as a separate and distinct concept.
Alternatively, he contended that human trafficking was prohibited under BOR4 in respect of each of slavery,
servitude and forced or compulsory labour. In the further alternative, he contended that BOR4 prohibited human
trafficking for forced or compulsory labour.

**[24] On the second question, Mr Husain contended that there was a positive duty on the HKSARG to criminalise**
the activities prohibited under BOR4 by way of specific, or 'bespoke', offences. The scope of the duty to enact
specific criminal legislation would depend on the answer to the first question as to the scope of BOR4. Mr Husain
contended that this would in any event require a duty to criminalise forced or compulsory labour and also human
trafficking for forced or compulsory labour.

**[25] Mr Husain did not seek an order of mandamus requiring the HKSARG to enact specific legislation but sought,**
instead, a declaration as to the duty upon the HKSARG. In this regard, he referred to the declaration that was
sought in the judicial review, namely:

26 A i i h M A M h


-----

'A declaration that the failure of the [HKSARG] to take steps to enact legislation specifically targeting human
trafficking, including both adult and child trafficking and general labour trafficking as well as trafficking for
sexual purposes is a breach of the Applicant's rights under [BOR4] and of the rights of other trafficking victims
in Hong Kong and of all persons entitled to the protection of the Basic Law who are or may be at risk of
becoming trafficking victims in Hong Kong or elsewhere.'

This declaration, to which he invited the Court to add 'and forced or compulsory labour' after the words 'as well as
trafficking for sexual purposes' would, he contended, be a sufficient disposition of the appeal if the Court were to
find in the appellant's favour.

**[26] On the other hand, it was the contention of Lord Pannick QC, leading counsel for the respondents,[27] that the**
two questions should be answered in the negative. He contended that BOR4, properly construed, does not prohibit
human trafficking either generally or for any of the prohibited activities of slavery, servitude or forced or compulsory
labour. Nor does it impose a positive obligation on the HKSARG to enact specific legislation to criminalise any of
the activities prohibited by BOR4.

**[27] In relation to the second question, Lord Pannick accepted that BOR4 does impose a positive obligation on the**
HKSARG to take steps to protect potential victims of slavery, servitude and forced or compulsory labour. However,
while accepting that there had to be in place legislation to tackle these matters, he contended that there was no
obligation to enact 'bespoke' legislation for these purposes. He also contended that the new evidence placed by the
respondents before the Court of Appeal showed that the HKSARG was seriously committed to combatting human
trafficking and protecting vulnerable persons from exploitation.
**C. Question 1: The scope of BOR4**

**[28] The HKBORO enacts the provisions of the International Covenant on Civil and Political Rights ('ICCPR') as**
applied to Hong Kong and, by virtue of art 39(1) of the Basic Law of the Hong Kong Special Administrative Region,
is

8

**[*107]**

given constitutional status.[28] BOR4 (set out in section A.1 above) is derived from and is in identical terms to art 8 of
the ICCPR ('ICCPR8'), save that the latter includes an additional sub-para (3)(b) excluding imprisonment with hard
labour from the definition of forced or compulsory labour. BOR4(3)(b) is therefore equivalent to ICCPR8(3)(c).
BOR4/ICCPR8 are also similar to art 4 of the European Convention on Human Rights ('ECHR4' and 'ECHR'
respectively), save that ECHR4 combines the prohibitions against slavery and servitude into one sub-paragraph
and omits reference to the 'slave-trade'.[29]

_C.1 Principles of construction_

**[29] The answer to the question as to the scope of BOR4 is a matter of construction. BOR4 is a provision in the**
HKBORO, which is domestic legislation giving effect to the ICCPR, an international convention applicable to Hong
Kong and having constitutional status by reason of art 39(1) of the Basic Law. In the interpretation of constitutional
instruments and statutes, the focus is on the context, purpose and actual words of the provision being construed.

(1)   In Ng Ka Ling v Director of Immigration, the earliest case on interpretation of the Basic Law heard by
this Court, the Court said:

'… in ascertaining the true meaning of the instrument, the courts must consider the purpose of the instrument
and its relevant provisions as well as the language of its text in the light of the context, context being of
particular importance in the interpretation of a constitutional instrument.'[30]

27 A i i h M S W SC M Ji P SC d M J h L


-----

(2)   Similarly, in Director of Immigration v Chong Fung Yuen, this Court held:

'The exercise of interpretation requires the courts to identify the meaning borne by the language when
considered in the light of its context and purpose. This is an objective exercise. Whilst the courts must avoid a
literal, technical, narrow or rigid approach, they cannot give the language a meaning which the language
cannot bear.'[31]

(3)   The importance of the language used is also a point emphasised in Lord Hoffmann's judgment for the
Privy Council in _Matadeen v Pointu[32] and Lord Bingham's speech in the House of Lords in the_ _Roma_
_Rights case.[33] In the latter case, Lord Bingham said (at [18]):_

'However generous and purposive its approach to interpretation, the court's task remains one of interpreting the
written document to which the contracting states have committed themselves. It must interpret what they have
agreed. It has no warrant to give effect to what they might, or in an ideal world would, have agreed. This would
violate the rule, also

9

**[*108]**

expressed in art 31(1) of the Vienna Convention, that a treaty should be interpreted in accordance with the
ordinary meaning to be given to the terms of the treaty in their context.'

(4)   The approach of the European Court of Human Rights ('ECtHR') in respect of the ECHR is the same:

'The Court is required to ascertain the ordinary meaning to be given to the words in their context and in the light
of the object and purpose of the provision from which they are drawn.'[34]

**[30] Taking these principles into account, the Court should give a generous interpretation to provisions containing**
constitutional guarantees of freedoms and must keep in mind that constitutional provisions are living instruments
intended to meet changing needs and circumstances: Ng Ka Ling v Director of Immigration _[(1999) 6 BHRC 447 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W075-00000-00&context=1519360)_
_[463–464, (1999) 2 HKCFAR 4 at 28 and 29. The principle that a statute is 'always speaking' requires the courts to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W075-00000-00&context=1519360)_
consider whether a new activity falls within the meaning of original statutory language: _R (on the application of_
_[Quintavalle) v Secretary of State for Health [2003] UKHL 13, [2003] 2 All ER 113, [2003] 2 AC 687(at [9]) per Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-60B3-00000-00&context=1519360)_
Bingham.
_C.2 The structure and context of BOR4_

**[31] In terms of its structure, the provisions of BOR4 (as in the case of ICCPR8) are set out in three separate**
numbered paragraphs setting out prohibited forms of treatment. As a matter of immediate context within BOR4,
therefore, the starting point is that the concepts of slavery (including all forms of slavery and the slave-trade),
servitude and forced or compulsory labour are distinct. That the concepts are distinct can also be seen from the
travaux préparatoires in relation to ICCPR8.[35]

[28   See Comilang v Director of Immigration [2019] HKCFA 10, (2019) 48 BHRC 254, (2019) 22 HKCFAR 59 (at [24]–](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YYJ-M7F3-CGXG-02MB-00000-00&context=1519360)

[25]) and the cases there cited.

29   ECHR4(1) provides: 'No one shall be held in slavery or servitude.'

30   (1999) 2 HKCFAR 4 at 28.

31 _Director of Immigration v Chong Fung Yuen [2001] HKCFA 48, (2001) 4 HKCFAR 211 at 223–224._

32 _[Matadeen v Pointu [1998] 3 LRC 542 at 551, [1999] 1 AC 98 at 108.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84JK-00000-00&context=1519360)_

33 _European Roma Rights Centre v Immigration Officer at Prague Airport (United Nations High Commissioner for_
_R f_ _i_ _i_ _[) [2004] UKHL 55 (2004) 18 BHRC 1 [2005] 2 AC 1(](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W04T-00000-00&context=1519360)_ [18] [19])


-----

**[32] These distinct concepts each have recognised definitions (and no issue is taken by the parties on these**
definitions):

(1)   'Slavery' and the 'slave-trade' are defined in the Slavery Convention of 1926 in the following terms:

'(1) Slavery is the status or condition of a person over whom any or all of the powers attaching to the right of
ownership are exercised.

(2) The slave trade includes all acts involved in the capture, acquisition or disposal of a person with intent to
reduce him to slavery; all acts involved in the acquisition of a slave with a view to selling or exchanging him; all
acts of disposal by sale or exchange of a slave acquired with a view to being sold or exchanged, and, in
general, every act of trade or transport in slaves.'[36]

10

**[*109]**

(2)   'Servitude' has been defined, by the ECtHR in relation to ECHR4, as 'an obligation to provide one's
services that is imposed by the use of coercion' and therefore 'to be linked with the concept of “slavery” '.[37]
The ECtHR has also said:

'… that servitude corresponds to a special type of forced or compulsory labour or, in other words, “aggravated”
forced or compulsory labour. As a matter of fact, the fundamental distinguishing feature between servitude and
forced or compulsory labour within the meaning of art 4 of the Convention lies in the victim's feeling that their
condition is permanent and that the situation is unlikely to change. It is sufficient that this feeling be based on
the above-mentioned objective criteria or brought about or kept alive by those responsible for the situation.'[38]

(3)   The recognised definition of 'forced or compulsory labour' is contained in art 2(1) of the Forced
Labour Convention 1930 ('FLC'), which states:

'For the purposes of this Convention, the term forced or compulsory labour shall mean all work or service which
is exacted from any person under the menace of any penalty and for which the said person has not offered
himself voluntarily.'

**[33] The distinction between the concepts is reinforced by reference to s 5 of the HKBORO.**

(1)   Section 5(1) provides:

'In time of public emergency which threatens the life of the nation and the existence of which is officially
proclaimed, measures may be taken derogating from the Bill of Rights to the extent strictly required by the
exigencies of the situation, but these measures shall be taken in accordance with law.'

(2)   Section 5(2) then provides that:

'No measure shall be taken under subsection (1) that—

34 _[M v Italy and Bulgaria (App no 40020/03) (2013) 57 EHRR 29, [2012] ECHR 40020/03 at para 147.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3WW-00000-00&context=1519360)_

35   Draft International Covenants on Human Rights, Annotation, A/2929, 1 July 1955, pp 91–92 at [17]; _UN_
_International Covenant on Civil and Political Rights, Nowak's CCPR Commentary (3rd Revised edn) at pp 224–225,_
paras [8]–[9].

36   Slavery Convention 1926, art 1. This definition has been accepted by the ECtHR, see Siliadin v France (App no
73316/01) _[(2005) 20 BHRC 654, (2005) 43 EHRR 287 at para 122 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_ _M v Italy and Bulgaria_ (App no 40020/03)
[(2013) 57 EHRR 29, [2012] ECHR 40020/03 at para 149; by the High Court of Australia in R v Tang [2008] HCA 39,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3WW-00000-00&context=1519360)
_[(2008) 25 BHRC 35, (2008) 237 CLR 1 (at [137]); and by the Court of Appeal of England and Wales in R v K [2011]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W35D-00000-00&context=1519360)_
_EWCA C i_ _[1691 [2012] 1 All ER 1090 [2013] QB 82(](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M31M-00000-00&context=1519360)_ [39])


-----

(a) is inconsistent with any obligation under international law that applies to Hong Kong (other than an
obligation under the International Covenant on Civil and Political Rights);

(b) involves discrimination solely on the ground of race, colour, sex, language, religion or social origin; or

(c) derogates from articles 2, 3, 4(1) and (2), 7, 12, 13 and 15.'

(3)   Thus, the prohibition against slavery and servitude are non-derogable rights under the HKBOR, even
in time of public emergency which threatens the life of the nation. In contrast, the prohibition of the
requirement to perform forced or compulsory labour is derogable. This is plain both from: (i) the fact there
are excluded forms of work or service expressly set out in BOR4(3)(b) itself (in contrast to the absence of
any exclusions in BOR4(1) and (2)); and also, (ii) from the omission of BOR4(3)(a) from s 5(2)(c) of the
HKBORO.

11

**[*110]**
_C.3 The appellant's construction argumentsC.3a The primary argument: BOR4 prohibits human trafficking generally_
for exploitation

**[34] Mr Husain's primary construction argument is that human trafficking generally for exploitation is included within**
the prohibition in BOR4. This argument is based on the wording in BOR4(1) stating that 'slavery and the slave-trade
in all their forms shall be prohibited' and relies on the definition of human trafficking in art 3 of the Palermo Protocol
('PP3').

**[35] PP3 defines the term 'trafficking in persons' in the following terms:**

'(a) “Trafficking in persons” shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person, for the purpose of exploitation.
Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs;

(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph (a) of
this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered “trafficking in persons” even if this does not involve any of the means set forth in subparagraph
(a) of this article;

(d) “Child” shall mean any person under eighteen years of age.'

**[36] There are three discrete parts to the definition of human trafficking in PP3. There must be an action involved,**
namely 'the recruitment, transportation, transfer, harbouring or receipt of persons'. Next, certain wrongful _means_
must be used, specifically 'the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve
the consent of a person having control over another person'. Finally, the action and means must be intended for a
_purpose, namely 'exploitation'. It should be noted that:_

37 _[Siliadin v France (App no 73316/01) (2005) 20 BHRC 654, (2005) 43 EHRR 287 at para 124.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

38 _CN_ _F_ (A 67724/09) (j d 11 O b 2012) 91


-----

(1)   The forms of exploitation are non-exhaustively described and include each of slavery, servitude and
forced labour but also include other forms of exploitation such as prostitution and the removal of organs.

(2)   However, the exploitation need not have actually occurred for human trafficking to have taken place.
It is the 'recruitment, transportation' (etc), by use of the specified means for the purpose of exploitation, that
constitutes human trafficking.

(3)   For that reason, human trafficking is a process of, for example, recruiting (etc) a person by the use of
underhand means with a view to exploiting them in a particular manner. It is not directed to the outcome or
_substantive conduct, which is the carrying out of the actual exploitative purpose for which someone is, for_
example, deceptively recruited.

**[37] The prohibition in BOR4(1) on 'slavery and the slave-trade in all their forms', in particular the reference to 'the**
slave-trade', may be said to incorporate the process whereby a person is subjected to and brought into the state of
slavery. Mr Husain therefore contended that, since BOR4(1) contemplates the

**[*111]**

prohibition of a process, when construed generously and evolutively, BOR4 must include a prohibition on human
trafficking generally for exploitation and this would therefore include exploitation for the purpose of forced labour.

**[38] Mr Husain also relied on the concept of 'modern slavery', of which human trafficking is said to be a form in**
[support of a generous and evolutive construction of BOR4. Paragraph [4] of the Explanatory Notes[39] to the Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
**_[Slavery Act 2015, for example, states:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

'Modern slavery is a brutal form of organised crime in which people are treated as commodities and exploited
for criminal gain … **_Modern slavery, in particular human trafficking, is an international problem …_** **_Modern_**
**_slavery takes a number of forms, including sexual exploitation, forced labour and domestic servitude, and_**
victims come from all walks of life …'[40]

Judicially, recognition of contemporary forms of slavery also derives some support from the ECtHR decision in
_Rantsev v Cyprus and Russia,[41] to which it will be necessary to return later in this judgment._
C.3b The alternative argument: BOR4 prohibits human trafficking for slavery, servitude and forced or compulsory
labour

**[39] Mr Husain's first alternative argument is a narrower version of his primary argument, relying on the same**
materials, to contend that the prohibition in BOR4, construed generously and evolutively, includes a prohibition on
human trafficking for any of the three concepts in BOR4, namely slavery, servitude and forced or compulsory
labour.
C.3c The further alternative argument: BOR4(3)(a) prohibits human trafficking for forced labour

**[40] Mr Husain's further alternative argument is based on the contention that BOR4(3)(a) not only prohibits forced**
or compulsory labour but also states that '[n]o one shall be required to perform' it. It is contended that the provision
includes the prior process by which someone can be made to perform forced labour: a person may be 'required to
perform' forced labour at the point at which the trafficker recruits the victim because the trafficker knows that he
requires the victim to perform forced labour. Hence, it is contended that BOR4(3)(a) includes a prohibition on
human trafficking for forced labour.
_C.4 Rejecting the appellant's construction arguments_

**[41] For the following reasons, I cannot accept any of the appellant's three construction arguments.**
C.4a Appellant's arguments contrary to the language of BOR4

**[42] As a general proposition, when the Legislature has chosen, in the course of the same provision of an**
ordinance, to use different words to express concepts, it is to be assumed that the different words were intended to
convey different meanings.[42] There is no reason to disapply that principle to an


-----

12

**[*112]**

international treaty (the ICCPR) which a local ordinance (the HKBORO) has domesticated. On the contrary, art
31(1) of the Vienna Convention on the Law of Treaties 1969 ('the Vienna Convention') states that a treaty is to be
interpreted 'in accordance with the ordinary meaning to be given to the terms of the treaty in their context and in the
light of its object and purpose'.[43] There would need to be good reason to assume that different terms employed in a
single article of an international treaty were intended to convey the same meaning.

**[43] The appellant's primary argument, however, blurs the distinctions between slavery, servitude and forced or**
compulsory labour in BOR4 to the point that they are no longer distinct concepts. The effect of the argument is to
treat them all collectively under the rubric of human trafficking generally for exploitation. Although there is scope for
suggesting that the concepts of slavery, servitude and forced or compulsory labour are cognate concepts with some
overlap,[44] it is nevertheless clear that BOR4 is structured to distinguish between the three as separate and distinct
concepts, with the latter concept of forced or compulsory labour being qualitatively different from slavery and
servitude in that it is derogable (see section C.2 above).[45]

**[44] Even assuming that human trafficking for the purposes of slavery falls within the phrase 'slavery and the slave-**
trade in all their forms' in BOR4(1), the prohibitions in BOR4(2) and BOR4(3)(a) are prohibitions of substantive
conduct rather than processes. The argument to the contrary in respect of BOR4(3)(a) is addressed below in
section C.4g. The prohibition on servitude in BOR4(2), however, is clearly a reference to the state of being held in
servitude and not to any anterior process by which a person might be brought to that status. To expand the
meaning of BOR4 to prohibit human trafficking for exploitation generally would be to ignore the language of BOR4
and impermissibly to alter the underlying concepts addressed in BOR4(2) and BOR4(3)(a).

**[45] Further, the reference in BOR4(1) to 'slavery and the slave-trade in all their forms' is not a generic reference to**
servitude and forced or compulsory labour. The travaux préparatoires to the ICCPR show that ICCPR8(1) was
intended to refer to slavery and the slave-trade in their narrow, traditional sense, ie as destruction of one's juridical
personality.[46]

**[46] The argument based on the expansion of the concept of slavery to include modern slavery (addressed further**
in section C.4c below) might have some force if BOR4 only included a prohibition on 'slavery and the slave-trade in
all their forms'. However, BOR4 is not limited to that form of exploitation and includes, as separate prohibitions,
servitude and forced or compulsory labour. There is no proper basis for blurring the distinctions to deprive those
concepts of separate meanings by confining them to the meaning of slavery and the slave-trade in some wide
generic sense of human trafficking generally for exploitation.

**[47] As Gleeson CJ observed, in R v Tang:**

'It is important not to debase the currency of language, or to banalise crimes against humanity, by giving
slavery a meaning that extends beyond

39   It should be noted, however, that the Introduction to the Explanatory Notes states that '[t]hey do not form part of
the Act and have not been endorsed by Parliament' [1] and '[t]hey are not, and are not meant to be, a comprehensive
description of the Act' [2].

40   See, also, UN International Covenant on Civil and Political Rights, Nowak's CCPR Commentary (3rd Revised edn,
2019) at p 226, para [11], expressing the view: 'Modern or contemporary forms of slavery consist of human trafficking,
forced labour and bonded labour.'

41 _[(2010) 28 BHRC 313, (2010) 51 EHRR 1 at paras 280–281.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

42 S l _HKSAR_ _Ch_ _W i K_ [2017] HKCFA 103 (2017) 20 HKCFAR 524 ( [32])


-----

13

**[*113]**

the limits set by the text, context, and purpose of the 1926 Slavery Convention. In particular it is important to
recognise that harsh and exploitative conditions of labour do not of themselves amount to slavery. The term
“slave” is sometimes used in a metaphorical sense to describe victims of such conditions, but that sense is not
of present relevance. Some of the factors identified as relevant in _Prosecutor v Kunarac, such as control of_
movement and control of physical environment, involve questions of degree. An employer normally has some
degree of control over the movements, or work environment, of an employee. Furthermore, geographical and
other circumstances may limit an employee's freedom of movement. Powers of control, in the context of an
issue of slavery, are powers of the kind and degree that would attach to a right of ownership if such a right
were legally possible, not powers of a kind that are no more than an incident of harsh employment, either
generally or at a particular time or place.'[47]

C.4b Impermissible application of Palermo Protocol to Hong Kong

**[48] The Palermo Protocol does not apply to Hong Kong. When the People's Republic of China ('PRC') acceded to**
the Palermo Protocol on 8 February 2010, the Central People's Government ('CPG') lodged a declaration in
accordance with art 153 of the Basic Law[48] to the effect that, unless notified by it, the Palermo Protocol should not
apply to the Hong Kong Special Administrative Region.[49]

**[49] In the appellant's written case, it was rightly accepted that this is an important matter.[50] Its significance lies in**
the fact that, under the common law dualist principle, an international treaty is not self-executing and that, until
made part of Hong Kong domestic law by legislation, the provisions of such a treaty do not confer or impose any
rights or obligations on individual citizens.[51] It also lies in the fact that the PRC's reservation in respect of the
Palermo Protocol was a deliberate choice not to apply its provisions to Hong Kong. As Lord Bingham observed, in
the Roma Rights case:

'The principle that pacta sunt servanda cannot require departure from what has been agreed. This is the more
obviously true where a state or states very deliberately decided what they were and were not willing to
undertake to do …'[52]

**[50] However, the appellant's argument that it is nevertheless permissible to use PP3(a) as an aid to construe**
ICCPR8, which does apply to Hong Kong and which BOR4 implements, so as to construe BOR4 as prohibiting
human trafficking generally for exploitation, or as prohibiting human trafficking for servitude or forced or compulsory
labour would be to apply the provisions of the

14

[43   See the reference to M v Italy and Bulgaria (App no 40020/03) (2013) 57 EHRR 29, [2012] ECHR 40020/03 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3WW-00000-00&context=1519360)
_[para [29](4) above.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3WW-00000-00&context=1519360)_

[44   See, in this context, R v Tang (2008) 25 BHRC 35, (2008) 237 CLR 1 (at [29]) per Gleeson CJ.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W35D-00000-00&context=1519360)

45   See, also, UN International Covenant on Civil and Political Rights, Nowak's CCPR Commentary (3rd Revised edn,
2019) p 223, para [5], stating: 'Its location alongside the prohibition of slavery is justified in that the boundaries between
slavery and servitude and other forms of forced or compulsory labour are not hard and fast. However, in light of the
exceptions permitted for forced and compulsory labour, a precise delineation between the terms is necessary.'

46 _UN International Covenant on Civil and Political Rights, Nowak's CCPR Commentary (3rd Revised edn, 2019) pp_
224–225, para [8]; see, also, [32(1)] above.

47 _[(2008) 25 BHRC 35 [2009] 2 LRC 592 (](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W35D-00000-00&context=1519360)_ [32]) l Ki b J [112]


-----

**[*114]**

Palermo Protocol to Hong Kong despite the clear intention of the CPG and the HKSARG that it should not apply.
The argument is convoluted and not at all easy to follow. However, be that as it may, it would be inappropriate to
give a 'backdoor' application to a treaty which the PRC has expressly declared should not apply to Hong Kong.

**[51] The appellant's written case referred to art 31(3)(c) of the Vienna Convention[53] to support the contention that a**
treaty should so far as possible be interpreted in harmony with other rules of international law. Mr Husain also cited
_Demir v Turkey[54] in support of the proposition that ratification by a state of an instrument is not necessary for it to be_
an aid to interpretation of a treaty to which that state is a party. However, the Vienna Convention is not relevant in
the present context as the Court is not construing an unincorporated treaty which has not been applied to Hong
Kong. Even if it were relevant, it would be to take the proposition in Demir v Turkey too far to ignore the declaration
by the PRC that the Palermo Protocol should not apply to Hong Kong at all and to conclude that, notwithstanding
that express reservation, PP3(a) should be used to construe ICCPR8 and therefore BOR4.
C.4c Modern slavery as a concept does not eliminate the distinctions between slavery, servitude and forced or
compulsory labour

**[52] The term 'modern slavery' is not a term of art and its genesis is not clear. The Explanatory Notes to the UK's**
**_[Modern Slavery Act 2015 have been referred to above. However, the Act does not seek to define the concept of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
'modern slavery' nor does it criminalise **_modern slavery as a separate concept. Instead, the principal offences_**
under that Act are: (i) slavery and servitude (s 1(1)(a)); (ii) forced or compulsory labour (s 1(1)(b)); and (iii) human
trafficking (s 2). The forms of exploitation which are the target of the offence of human trafficking are listed in s 3
and are: slavery, servitude and forced or compulsory labour; sexual exploitation; removal of organs etc (under the
_[Human Tissue Act 2004); securing services etc by force, threats or deception; and securing services etc from](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y0GB-00000-00&context=1519360)_
children and vulnerable persons.

**[53] The earliest judicial references in the authorities cited in this Court to contemporary forms of slavery are the**
judgments of the Trial Chamber of the International Criminal Tribunal for the Former Yugoslavia ('ICTY') in
_Prosecutor v Kunarac [55] and in the Appeals Chamber of that Tribunal in the same case.[56] That case was referred to_
in Rantsev v Cyprus and Russia,[57] where the ECtHR said:

'280. The court observes that the International Criminal Tribunal for the Former Yugoslavia concluded that the
traditional concept of “slavery” has evolved to encompass various contemporary forms of slavery based on the
exercise of any or all of the powers attaching to the right of ownership. In assessing whether a situation
amounts to a contemporary form of slavery, the tribunal held that relevant factors included whether there was
control of a person's movement or physical environment, whether there was an

15

48   Article 153(1) of the Basic Law provides: 'The application to the Hong Kong Special Administrative Region of
international agreements to which the People's Republic of China is or becomes a party shall be decided by the
Central People's Government, in accordance with the circumstances and needs of the Region, and after seeking the
views of the government of the Region.'

49   In contrast, the CPG declared that the Palermo Protocol would apply to the Macau Special Administrative Region.

50   Written Case of the Appellant at [38].

51 _[Comilang, Milagros Tecson v Director of Immigration [2019] HKCFA 10, (2019) 48 BHRC 254, (2019) 22 HKCFAR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YYJ-M7F3-CGXG-02MB-00000-00&context=1519360)_
59 (at [74]).

52 _[(2004) 18 BHRC 1, [2005] 2 AC 1(at [19]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W04T-00000-00&context=1519360)_

53   Article 31(3) provides: 'There shall be taken into account, together with the context … (c) any relevant rules of
i i l l li bl i h l i b h i '


-----

**[*115]**

element of psychological control, whether measures were taken to prevent or deter escape and whether there
was control of sexuality and forced labour.

281. The court considers that trafficking in human beings, by its very nature and aim of exploitation, is based
on the exercise of powers attaching to the right of ownership. It treats human beings as commodities to be
bought and sold and put to forced labour, often for little or no payment, usually in the sex industry but also
elsewhere. It implies close surveillance of the activities of victims, whose movements are often circumscribed.
It involves the use of violence and threats against victims, who live and work under poor conditions. It is
described by Interights and in the explanatory report accompanying the Anti-Trafficking Convention as the
modern form of the old worldwide slave trade. The Cypriot Ombudsman referred to sexual exploitation and
trafficking taking place, “under a regime of modern slavery”.'[58]

**[54] However, there are a number of problematic features in this description of human trafficking as a form of**
**_modern slavery for the purposes of construing BOR4._**

(1)   First, human trafficking is already defined internationally in PP3(a). That definition has been
addressed above: it consists of three elements describing a process. The ECtHR's definition of human
trafficking (see the citation above to _Rantsev v Cyprus and Russia at [281]), in contrast, looks to an_
outcome rather than the process.

(2)   Secondly, in limiting the aim of human trafficking to the exercise of ownership rights, the ECtHR's
definition of human trafficking unduly limits the forms of exploitation that may be involved in human
trafficking too narrowly. Contrast instead the forms of exploitation that are included in the definition of
human trafficking in PP3(a).

(3)   Thirdly, as will be seen in the discussion in section C.4d below, the ECtHR's approach to human
trafficking is, at the same time, too broad as it ignores the separate concepts of slavery, servitude and
forced or compulsory labour contained in ECHR4 (as they are in BOR4).[59]

**[55] These are cogent reasons for rejecting the construction of BOR4 that proceeds from the basis that human**
trafficking is **_modern slavery and, therefore, since (it is said)_** **_modern slavery must fall within the prohibition in_**
BOR4(1), BOR4 should be construed as prohibiting human trafficking generally for exploitation. In addition to the
objection noted at [44] above, if BOR4 is construed to prohibit human trafficking generally for exploitation, it would
also prohibit other purposes than the three concepts of slavery, servitude and forced or compulsory labour (such as
the removal of human organs) and would therefore ignore the specific concepts in BOR4.

**[56] On his first alternative construction argument that BOR4 should instead be construed to prohibit human**
trafficking for slavery, servitude and forced or compulsory labour, Mr Husain was constrained to accept in argument
before us that his construction argument would mean that human trafficking for slavery and human trafficking for
servitude are non-derogable prohibitions but that

16

54 _[[2009] IRLR 766, (2008) 48 EHRR 1272 at paras 85–86.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W43C-00000-00&context=1519360)_

55 _Prosecutor v Kunarac (Case nos IT-96–23 & 23/1) (Trial Chamber judgment, 22 February 2001); at paras 539–_
542.

56 _Prosecutor v Kunarac (Case nos IT-96–23 & 23/1) (Appeals Chamber judgment, 12 June 2002), at paras 116–_
119.

57 _[(2010) 28 BHRC 313, (2010) 51 EHRR 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

58 _Ibid_ [280] [281] (f i d)


-----

**[*116]**

human trafficking for forced or compulsory labour is derogable (see [33] above). This is an artificial construction
which has no discernable justification in logic or policy.
C.4d No judicial support for the appellant's construction arguments

**[57] The appellant's construction arguments are not supported by any judicial decisions on ICCPR8 or BOR4 or**
similar provisions. In the appellant's written case, however, it was contended that the decision of the ECtHR in
_Rantsev v Cyprus and Russia[60] is 'valuable persuasive authority on the general principles underlying the protection'_
of BOR4(1).[61] This was the only judicial decision on ICCPR8 directly supporting the appellant's arguments.

**[58] That case concerned the adequacy of measures taken by Cyprus to investigate the death of a young woman**
who had been allegedly trafficked from Russia to work in a cabaret in Cyprus. In relation to ECHR4, it was held, in
that case, that there had been a violation by Cyprus in failing to afford the woman practical and effective protection
against trafficking and exploitation in general and specific measures of protection. Of relevance are the following
paragraphs of the ECtHR's judgment in relation to ECHR4:

'277. The absence of an express reference to trafficking in the convention is unsurprising. The convention was
inspired by the Universal Declaration of Human Rights (Paris, 10 December 1948; UN TS 2 (1949); Cmd
7226), proclaimed by the General Assembly of the United Nations in 1948, which itself made no express
mention of trafficking. In its art 4, the Declaration prohibited “slavery and the slave trade in all their forms”.
However, in assessing the scope of art 4 of the convention, sight should not be lost of the convention's special
features or of the fact that it is a living instrument which must be interpreted in the light of present-day
conditions. The increasingly high standards required in the area of the protection of human rights and
fundamental liberties correspondingly and inevitably require greater firmness in assessing breaches of the
fundamental values of democratic societies

278. The court notes that trafficking in human beings as a global phenomenon has increased significantly in
recent years. In Europe, its growth has been facilitated in part by the collapse of former Communist blocs. The
conclusion of the Palermo Protocol in 2000 and the Anti-Trafficking Convention in 2005 demonstrate the
increasing recognition at international level of the prevalence of trafficking and the need for measures to
combat it.

279. The court is not regularly called upon to consider the application of art 4 and, in particular, has had only
one occasion to date to consider the extent to which treatment associated with trafficking fell within the scope
of that article. In that case, the court concluded that the treatment suffered by the applicant amounted to
servitude and forced and compulsory labour, although it fell short of slavery. In light of the proliferation of both
trafficking itself and of measures taken to combat it, the court considers it appropriate in the present case to
examine the extent to which trafficking itself may be considered to run counter to the spirit and purpose of art 4
of the convention such as to fall within the scope of the guarantees offered by

17

**[*117]**

that article without the need to assess which of the three types of proscribed conduct are engaged by the
particular treatment in the case in question.'[62]

59   ECHR4 provides that '(1) No one shall be held in slavery or servitude'; and '(2) No one shall be required to
perform forced or compulsory labour.'

60 _[(2010) 28 BHRC 313, (2010) 51 EHRR 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

61 W i C f h A ll [48]


-----

**[59] The ECtHR adopted a broad brush approach in holding that human trafficking itself fell within the scope of**
ECHR4 and that it was not necessary to identify whether the treatment complained of was slavery, servitude or
forced or compulsory labour. It held:

'282. There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its
victims and cannot be considered compatible with a democratic society and the values expounded in the
Convention. In view of its obligation to interpret the Convention in light of present-day conditions, the Court
considers it unnecessary to identify whether the treatment about which the applicant complains constitutes
“slavery”, “servitude” or “forced and compulsory labour”. Instead, the Court concludes that trafficking itself,
within the meaning of art.3(a) of the Palermo Protocol and art.4(a) of the Anti-Trafficking Convention, falls
within the scope of art.4 of the Convention. The Russian Government's objection of incompatibility _ratione_
_materiae is accordingly dismissed.'_

**[60] The appropriateness of the Hong Kong courts taking account of established principles of international**
jurisprudence, including that of the ECtHR, in interpreting fundamental rights in the Basic Law and the BOR was
acknowledged by this Court in _Shum Kwok Sher v HKSAR.[63] The decisions of the ECtHR on provisions of the_
ECHR in the same or substantially the same terms as the BOR, though not binding on the courts of Hong Kong, are
of high persuasive authority and have been so regarded by this Court.[64] However, the ECtHR plays a supranational role under an international treaty in relation to member states of the Council of Europe and therefore
functions quite differently to this Court which is a court of final adjudication in a domestic forum. Such differences
may sometimes make it inappropriate to take the path followed by the ECtHR.[65] In addition, the ECtHR's
jurisprudence is fact sensitive so that it is hazardous to apply the decisions of that court to facts which are
different.[66]

**[61] Regardless of that general caveat, the broad brush approach of the ECtHR in Rantsev v Cyprus and Russia is**
in any event unsatisfactory and should not be followed in respect of BOR4 because it expressly ignores the
separate concepts of slavery, servitude and forced or compulsory labour. The appellant's own case does not seek
to ignore the distinctions between the different types of prohibited conduct in BOR4 (see FN8 above). That
approach is correct since it would otherwise debase the language of BOR4 to treat the prohibited types of conduct
in this broad brush manner.

**[62] As a matter of context, it should also be noted that it was clearly material, however, to the ECtHR's decision in**
that case that both Cyprus and Russia were parties to the Palermo Protocol[67] and also that the Anti-Trafficking
Convention[68] had been signed by 41 Member States of the Council of Europe and 26 had also

18

**[*118]**

62   Footnotes in citation omitted.

63 _Shum Kwok Sher v HKSAR [2002] HKCFA 27, (2002) 5 HKCFAR 381 at para 59._

64 _Koon Wing Yee v Insider Dealing Tribunal [2008] HKCFA 21, (2008) 11 HKCFAR 170, [2008] 3 HKLRD 372 (at_

[27]).

[65   See the decision of the Privy Council in Lendore v A-G [2017] UKPC 25, [2017] 5 LRC 369 [2017] 1 WLR 3369 (at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R18-V471-DYJ0-83VD-00000-00&context=1519360)

[60]–[61]).

66 _Koon Wing Yee v Insider Dealing Tribunal (2008) 11 HKCFAR 170 at [28]._

67 _[(2010) 28 BHRC 313, (2010) 51 EHRR 1 at para 149.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

68 CETS N 197 16 M 2005


-----

ratified it (including Cyprus).[69] It is also relevant to note, as a matter of context when considering the European
jurisprudence, that art 5 of the Charter of Fundamental Rights of the European Union contains an express
prohibition against trafficking in human beings.[70]

**[63] A similar contextual qualification also applies to Mr Husain's reliance on a decision of the Inter-American Court**
of Human Rights in Hacienda Brasil Verde Workers v Brazil.[71] Mr Husain contended that the Inter-American Court's
interpretation in that case of the scope of the freedom from slavery in art 6 of the American Convention on Human
Rights supported his primary BOR4 construction argument. However, art 6 of the American Convention is materially
quite different to BOR4 in that it includes a specific prohibition on trafficking in women.[72] The principal issue in that
case was whether the absence of protection in Brazil against the trafficking of male workers was discriminatory and
not, as here, whether the concept of a prohibition of trafficking generally for exploitation can be implied into
ICCPR8.
C.4e HRC General Comment No 28 and HRC Concluding Observations provide no support for appellant's
construction of BOR4

**[64] In the appellant's written case, it was contended that the United Nations Human Rights Committee ('HRC') 'has**
concluded that ICCPR art 8 covers [human trafficking], despite the absence of any express reference to [human
trafficking]'.[73] That contention was based on the statement by the HRC in its General Comment No 28 in respect of
art 3 of the ICCPR,[74] at [12], that:

'Having regard to their obligations under article 8, States parties should inform the Committee of measures
taken to eliminate trafficking of women and children, within the country or across borders, and forced
prostitution. They must also provide information on measures taken to protect women and children, including
foreign women and children, from slavery, disguised, inter alia, as domestic or other kinds of personal service.
States parties where women and children are recruited, and from which they are taken, and States parties
where they are received should provide information on measures, national or international, which have been
taken in order to prevent the violation of women's and children's rights.'

**[65] It is, however, to read too much into that paragraph to conclude that ICCPR8 (and therefore BOR4) are to be**
construed as prohibiting human trafficking either generally for exploitation or for the specified purposes of slavery,
servitude and forced or compulsory labour. There is no indication that the HRC was there stating definitively that
ICCPR8 must, as a matter of its proper construction, be taken to prohibit human trafficking per se. The paragraph
instead refers to the desirability of States Parties informing the HRC of measures taken to eliminate trafficking of
women and children. Having regard to the prohibition on slavery and the slave-trade in all their forms in ICCPR8(1),
that statement is understandable. This is reinforced by the statement of the

19

**[*119]**

desirability of the provision of information on measures to protect women and children 'from slavery, disguised, inter
alia, as domestic or other kinds of personal service'.

69 _[(2010) 28 BHRC 313, (2010) 51 EHRR 1 at para 160.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

70   Article 5(3) provides: 'Trafficking in human beings is prohibited.'

71 _Hacienda Brasil Verde Workers v Brazil_ (20 October 2016, unreported) (Preliminary Objections, Merits,
Reparations and Costs).

72   Article 6(1) of the American Convention provides: 'No one shall be subject to slavery or to involuntary servitude,
which are prohibited in all their forms, as are the slave trade and traffic in women.'

73   Written Case of the Appellant at [33].

74 Ad d h Si i h h i f h HRC 29 M h 2000


-----

**[66] In any event, the weight to be attached to this particular paragraph in this General Comment is clearly a point**
open to argument. Although Sir Anthony Mason NPJ said, in this Court, that '[t]he General Comments are a
valuable jurisprudential resource which is availed of by the Committee in its adjudicative role' and that 'they provide
influential guidance as to how the ICCPR is applied and will be applied by the [HRC] when sitting as a judicial body
in making determinations',[75] it is far from clear that those comments should apply to this particular General
Comment. There is no indication in General Comment No 28 of the analysis by the HRC of ICCPR8 and its
provisions, nor is there any indication of the scope of any representations made to the HRC regarding the
obligations arising under ICCPR8. Absent a clear indication of the reasoning of the HRC for the statements in
question, it would not be safe to conclude that the paragraph in question is intended to go as far as the proposition
for which Mr Husain cites it.

**[67] This view is supported in particular by the travaux préparatoires which show that a proposal to replace the term**
'slave-trade' in ICCPR8(1) with 'trade in human beings', in order to cover traffic in women as well, was rejected on
the basis that ICCPR8(1) should refer only to slavery and the slave-trade in their true sense.[76]

**[68] Similarly, Mr Husain's reliance on the HRC's Concluding Observations on the Third Periodic Report of Hong**
Kong, China,[77] as well as the Concluding Observations of the HRC in respect of the reports of various other States
Parties in support of his construction of ICCPR8 as including a prohibition against human trafficking cannot be read
as binding statements on the scope of ICCPR8.

**[69] In its observations on the Third Periodic Report of Hong Kong, for example, the HRC stated (at [20]):**

'The Committee is concerned about the persistence of the phenomenon of trafficking in persons in Hong Kong,
China, and reports that Hong Kong, China, is a source, destination, and transit point for men, women, and
teenage girls from Hong Kong, the mainland of China, and elsewhere in Southeast Asia, subjected to human
trafficking and forced labour. The Committee is concerned about the reluctance of Hong Kong, China, to take
steps which could lead to the extension of the Protocol to Prevent, Suppress and Punish Trafficking in Persons,
Especially Women and Children, supplementing the United Nations Convention against Transnational
Organized Crime (Palermo Protocol) to Hong Kong, China, (art. 8).

Hong Kong, China, should intensify its efforts to identify victims of trafficking and ensure the systematic
collection of data on trafficking flows to and in transit through the region, review its sentencing policy for
perpetrators of trafficking-related crimes, support private shelters offering protection to victims, strengthen
victim assistance by ensuring interpretation, medical care, counselling, legal support for claiming unpaid wages
and compensation, long-term support for rehabilitation and stability

20

**[*120]**

of legal status to all victims of trafficking. The Committee recommends the inclusion of certain practices
regarding foreign domestic workers in the definition of the crime of human trafficking. Hong Kong, China,
should consider taking steps which could lead to the extension of the Palermo Protocol to Hong Kong, China,
in order to strengthen its commitment to fight trafficking in persons in the region.'

**[70] The status of Concluding Observations of the HRC is ill-defined. They have no binding status and, although**
deserving of respect given the eminence of their authors, a distinction is to be drawn between pronouncements by

75 _Koon Wing Yee v Insider Dealing Tribunal [2008] HKCFA 21, (2008) 11 HKCFAR 170, [2008] 3 HKLRD 372 (at_

[101]).

76   Draft International Covenants on Human Rights, Annotation, A/2929, 1 July 1955, pp 91–92 at [17]; _UN_
_International Covenant on Civil and Political Rights, Nowak's CCPR Commentary (3rd Revised Edn) at p 225, para [9]._

77 Ad d b h HRC i 107 h i (11 28 M h 2013)


-----

the HRC on issues of violation of the ICCPR and where they otherwise purport to interpret treaty provisions, on the
one hand, and where they provide general advice on strategies for enhanced implementation of a treaty and when
they opine on matters extraneous to the actual treaty obligations of a State Party, on the other.[78]

**[71] The prescriptive nature of the HRC's Concluding Observations in respect of Hong Kong in the passage quoted**
above are self-evident and neither those observations nor the other Concluding Observations referred to provide
any reasoned analysis of why human trafficking falls within the protection afforded by ICCPR8.
C.4f HKSAR policy does not govern the interpretation of BOR4

**[72] A point which Mr Husain repeatedly stressed in his submissions was that the respondents' evidence in this**
case shows that the HKSARG 'attaches great importance in combating human trafficking, as well as servitude and
forced labour' and 'spares no effort in combating human trafficking'.[79]

**[73] Whilst the respondents' evidence as to its commitment to addressing human trafficking and the practical**
measures taken by the HKSARG is certainly relevant in the context of one aspect of Question 2 (see below), that
evidence is not relevant to the construction of BOR4. There is a clear and obvious distinction between legal
obligation and government policy. The decision to pursue a particular policy is a matter which may be based on
administrative rather than legal considerations and the mere fact of pursuit of a policy to combat human trafficking
does not require BOR4 to be construed as prohibiting that activity.
C.4g BOR4(3)(a) prohibits the substantive conduct not the process

**[74] Mr Husain's further alternative construction argument can be disposed of briefly. The argument is that the word**
'required' in BOR4(3)(a) must refer to a process, since a person can be required to perform forced or compulsory
labour even before he actually does so and, therefore, that human trafficking for forced or compulsory labour would
fall within the meaning of requiring someone to perform forced or compulsory labour.

**[75] This construction of BOR4(3)(a) is untenable. The word 'required' is singularly inapt to convey a meaning of**
trafficking. If this was intended a much more suitable term would have been used. Additionally, the word 'required' is
also used twice in the descriptions in BOR4(3)(b) of excluded activities which do not fall within the prohibition on
forced or compulsory labour: see BOR4(3)(b)(i) 'any work or service normally required of a person who is under

21

**[*121]**

detention …' and BOR4(3)(b)(ii) 'any service of a military character and, where conscientious objection is
recognized, any national service required by law of conscientious objectors' (italics added).

**[76] Mr Husain accepted that the activities in BOR4(3)(b) referred to conduct rather than processes. That being so,**
it would mean that the same word used in BOR4(3) was to be given one meaning in BOR4(3)(a) and another in
BOR4(3)(b). There is no good reason to do so. On the contrary, 'it is a sound rule of construction to give the same
meaning to the same words occurring in different parts of an Act of Parliament'.[80]

**[77] The word 'required' in BOR4(3)(a) is consistent with the definition of forced or compulsory labour in art 2(1) of**
the FLC (see [32(3)] above). While BOR4(3)(a) uses the passive voice 'required', art 2(1) of the FLC uses the active
voice to define forced or compulsory labour as 'work or service which is exacted from any person'. It is the
substantive work or service that is prohibited.

78   The Concluding Observations of United Nations Human Rights Treaty Bodies, Michael O'Flaherty (2006) 6:1
_Human Rights Law Review 27–52 at 36._

79 Affi i f L W d 10 S b 2015 [6] d [41]


-----

**[78] Mr Husain referred, in the course of the argument, to the 'Protocol of 2014 to the FLC 1930' adopted by the**
International Labour Organization ('ILO'), the Preamble of which included the statement:

'Recognizing that the context and forms of forced or compulsory labour have changed and trafficking in
persons for the purposes of forced or compulsory labour, which may involve sexual exploitation, is the subject
of growing international concern and requires urgent action for its effective elimination.'

He also referred to art 1(3) of that Protocol which states:

'The definition of forced or compulsory labour contained in the Convention [ie the FLC] is reaffirmed, and
therefore the measures referred to in this Protocol shall include specific action against trafficking in persons for
the purposes of forced or compulsory labour.'

**[79] The 2014 Protocol to the FLC does not support the appellant's construction of BOR4(3)(a). The PRC, and**
therefore Hong Kong, is not a party to that Protocol and so its terms are not applicable. Nor does it purport to
amend the definition of forced or compulsory labour in the FLC (at [32(3)] above). Instead, art 1(3) of the Protocol
'reaffirms' that definition and states that the measures in the Protocol are additional measures to be taken to combat
human trafficking 'for the purposes of forced or compulsory labour'. The expanded obligations under the 2014
Protocol, which does not apply to Hong Kong in any event, cannot be used to support the appellant's construction
of BOR4(3)(a).[81]

_C.5 Answering Question 1_

**[80] I would therefore answer Question 1 as follows.**

(1)   Although BOR4(1) may, by referring to 'slavery and the slave-trade in all their forms', prohibit
trafficking for the purposes of slavery, BOR4(1) does not prohibit human trafficking generally for the
purposes of exploitation.

22

**[*122]**

(2)   Nor does BOR4(1) prohibit human trafficking for the purposes of servitude and forced or compulsory
labour (even assuming it prohibits human trafficking for slavery).

(3)   BOR4(3)(a) does not prohibit human trafficking for forced or compulsory labour.

**[81] Although BOR4, as a constitutionally protected human right is to be construed generously, its language does**
not support the expansive constructions contended for on behalf of the appellant. Similarly, although the BOR is to
be construed as a living instrument, there is no justification for giving an updated construction to the concepts of
slavery, servitude and forced or compulsory labour which result in a meaning that is conceptually different: Boyce v
_[R (2004) 17 BHRC 118 at [28]–[29]; Birmingham City Council v Oakley [2001] 1 All ER 385 at 396, [2001] 1 AC 617](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4PW-00000-00&context=1519360)_
at 631–632.

**[82] This is not, it should be emphasised, to endorse a literal, technical, narrow or rigid construction of the language**
of BOR4. That, it is clear, must be avoided.[82] Even so, for the reasons set out above, the appellant's construction
arguments cannot be accepted.
**D. Question 2: Does BOR4 require bespoke legislation?**

80 _Courtauld v Legh (1869) LR 4 Exch 126, quoted by Lord Walker of Gestingthorpe in R v Islam_ _[2009] UKHL 30,_

_[[2010] 1 All ER 493, [2009] AC 1076(at [23]): see, HKSAR v Wan Thomas [2018] HKCFA 15, (2018) 21 HKCFAR 214](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XNJ-DJK0-Y96Y-G16X-00000-00&context=1519360)_
(at [27]).

81   Similarly, where the ILO has linked forced or compulsory labour in the FLC with human trafficking, it has done so
on the basis of the Palermo Protocol: ILO Report III (Part 1B), 96th Session, 2007, _Eradication of Forced Labour at_

[77] 41 ILO R III (P 1B) 101 S i 2012 Gi i _Gl b li_ _i_ _H_ _F_ [297] 128


-----

**[83] Question 2 concerns the scope of the positive steps required to be taken by the HKSARG under BOR4. The**
respondents accept that there is an investigative duty imposed on the HKSARG by BOR4 and that the respondents
failed to discharge that duty in respect of the appellant (and hence there is no appeal against the Court of Appeal's
decision on that issue). However, the question before us is whether BOR4 imposes an obligation on the HKSARG
to enact specific or bespoke legislation to afford protection against the activities prohibited by BOR4 or whether
reliance on a 'patchwork' of statutory provisions is sufficient.
_D.1 The appellant's case on Question 2_

**[84] The appellant's submissions on Question 2, as set out in his written case, are that:**

'a. There is an absolute (alternatively, a contingent) obligation to specifically criminalise all forms of [human
trafficking];

b. There is a contingent obligation to specifically criminalise [forced or compulsory labour];

c. The contingency is that a patchwork of general offences, adaptively applied, is not shown by the
Government to be effective – it is not necessary for the individual to show further that the enactment of a
specific offence is the only means of redressing the ineffectiveness;

d. That contingency is made out on the facts accepted by the courts below in the present case.'[83]

**[85] Having concluded, in answer to Question 1, that BOR4 does not contain a prohibition against human trafficking**
either generally for exploitation or specifically for forced or compulsory labour (see section C.5 above), the premise
on which the appellant's contention on Question 2 that the HKSARG is under a

23

**[*123]**

duty to promote a specific offence criminalising human trafficking is undermined.[84] This conclusion also means that
the appellant's reliance on art 5 of the Palermo Protocol[85] as an aid to interpreting BOR4 is misplaced.

**[86] However, the appellant's contention that there is an obligation under BOR4 to criminalise forced or compulsory**
labour remains to be determined. In support of this contention, the appellant relies variously on: art 25 of the FLC
('FLC25'); statements of the ILO Committee of Experts and Concluding Observations of the HRC; and the
jurisprudence of the ECtHR on ECHR4. Mr Husain repeated, in this context, his submission that the respondents'
evidence showed that the HKSARG was committed, as a matter of policy, to combatting human trafficking and that
this therefore showed that there was no policy objection to the enactment of a bespoke offence to criminalise forced
or compulsory labour. He also submitted that, by analogy with torture, a patchwork of general criminal offences was
not sufficient to protect the rights under BOR4.

**[87] The respondents accept that the authorities show that there is a positive duty on the HKSARG under BOR4 to**
have in place measures providing practical and effective protection against the activities prohibited under BOR4.
However, they do not accept there is a duty to enact bespoke criminal legislation for that purpose.
_D.2 The HKSARG's margin of discretion under BOR4_

**[88] The rights protected under BOR4, like the right of peaceful assembly, involve a positive duty on the part of the**
HKSARG: see _Leung Kwok Hung v HKSAR [2005] HKCFA 40, (2005) 8 HKCFAR 229, [2005] 3 HKLRD 164 (at_

[22]). But, just as the authorities cannot guarantee that all lawful assemblies will always proceed peacefully, they
cannot ensure that no person will ever be subjected by another to the treatment prohibited by BOR4. Since (as will

82 _[Ng Ka Ling v Director of Immigration [1999] HKCFA 17, (1999) 6 BHRC 447 at 463, (1999) 2 HKCFAR 4 at 28.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STV1-DYBP-W075-00000-00&context=1519360)_

83 W i C f h A ll [67]


-----

be seen from the ECtHR decisions discussed in section D.3a below) the touchstone is whether the protection of the
rights under BOR4 is practical and effective, the decision as to how to achieve such protection must necessarily be
a matter for the HKSARG, subject, of course, to the supervision of the courts to assess the practical efficacy of the
measures adopted.

**[89] Part of the relevant context of ICCPR8, applied to Hong Kong through BOR4, is art 2(2) of the ICCPR**
('ICCPR2(2)'), which provides:

'Where not already provided for by existing legislative or other measures, each State Party to the present
Covenant undertakes to take the necessary steps, in accordance with its constitutional processes and with the
provisions of the present Covenant, to adopt such laws or other measures as may be necessary to give effect
to the rights recognized in the present Covenant.'

**[90] The wording of BOR4/ICCPR8 does not say in terms that specific criminal offences must be created to support**
the prohibition against slavery, servitude and forced or compulsory labour. On the contrary, as ICCPR2(2) shows,
the obligation on States Parties presupposes a discretion as to the manner in which the rights, including those
under BOR4/ICCPR8, are protected.

24

**[*124]**

**[91] In the circumstances, it is appropriate that the discretion as to the choice of measures to be used should be**
wide as recognised by this Court and by the ECtHR in relation to the duty to protect the right to freedom of
assembly.[86] Even in the context of the non-derogable rights not to be subject to torture or cruel, inhuman or
degrading treatment, the ECtHR has recognised that the positive obligation should 'be interpreted in such a way as
not to impose an excessive burden on the authorities, bearing in mind, in particular, the unpredictability of human
conduct and operational choices which must be made in terms of priorities and resources'.[87]

**[92] Inherent in this wide margin of discretion, also, is the need to consider whether an alleged breach of BOR4**
rights has arisen because of the lack of a specific criminal offence. For the contention that a bespoke criminal
offence is required in this case, there must be a causal connection between the absence of that specific offence
against forced or compulsory labour and the breach of the appellant's BOR4 rights: see, in this context, the
reference to _CN v UK (below).[88] To similar effect on the need for a causal connection between alleged failure to_
implement a particular measure and breach of an ECHR right, see: Beganović v Croatia,[89] _O'Keeffe v Ireland[90] and_
_Botta v Italy.[91] As will be seen (in section D.5 below), that causal connection is not established in the present case._
_D.3 The appellant's arguments for a bespoke criminal offence_

**[93] For the following reasons, I would reject the appellant's contention that BOR4 necessarily requires the**
HKSARG to enact a bespoke offence criminalising forced or compulsory labour (although, as will be seen, this may
be demonstrated to be necessary if the measures adopted by the HKSARG are shown not to afford practical and
effective protection of BOR4 rights).
D.3a The European jurisprudence

84 _Ibid at [68]._

85   Article 5(1) provides under the heading 'Criminalization', that: 'Each State Party shall adopt such legislative and
other measures as may be necessary to establish as criminal offences the conduct set forth in art 3 of this Protocol,
when committed intentionally.' Article 5(2) requires each State Party to adopt legislative and other measures to
establish as criminal offences, 'attempting' and 'organizing or directing other persons' to commit, and 'participating as
li ' i ff bli h d i d i h 5(1)


-----

**[94] Mr Husain relied on the decisions of the ECtHR in Siliadin v France,[92]** _CN and V v France,[93]_ _CN v UK,[94] and_
_Rantsev v Cyprus and Russia[95] in support of his contention that there is a positive obligation on the HKSARG under_
BOR4 to enact a bespoke offence criminalising forced or compulsory labour.

**[95] Siliadin v France concerned an applicant, aged 15 at the relevant time, who was found (at para 129) to have**
been held in servitude within the meaning of ECHR4. The ECtHR held (at para 89) that 'governments have positive
obligations … to adopt criminal law provisions which penalise the practices referred to in [ECHR4] and to apply
them in practice' and (at para 112) that 'Member States' positive obligations under [ECHR4] must be seen as
requiring the penalisation and effective prosecution of any act aimed at maintaining a person in such a situation'.

25

**[*125]**

**[96] In that case, the French Government relied on various articles of the Criminal Code but the ECtHR observed**
(at para 142) that 'those provisions do not deal specifically with the rights guaranteed under [ECHR4], but concern,
in a much more restrictive way, exploitation through labour and subjection to working and living conditions that are
incompatible with human dignity'. The ECtHR went on to say that '[i]t therefore needs to be determined whether, in
the instant case, those articles provided effective penalties for the conduct to which the applicant had been
subjected'. That question was answered in the negative on the facts as assessed by the ECtHR (at para 148).

**[97] The approach in Siliadin v France was followed in CN v France and in CN v UK respectively.**

(1)   In _CN v France, at paras 105–108, the ECtHR followed the reasoning and conclusion in_ _Siliadin v_
_France and found, again on the facts, that there had been a violation of ECHR4 in respect of the first_
applicant (who had been found to have been subjected to forced or compulsory labour) 'as regards the
State's positive obligation to set in place a legislative and administrative framework to effectively combat
servitude and forced labour'.

(2)   In CN v UK, at paras 66 and 76, the ECtHR followed Siliadin v France and found, on the facts of that
case, that the investigation into the applicant's complaints of domestic servitude was ineffective due to the
absence of specific legislation criminalising such treatment. Consistent with Siliadin v France, the standard
applied was whether 'the legislative provisions in force in the United Kingdom at the relevant time were
inadequate to afford practical and effective protection against treatment falling within the scope of

[ECHR4]'.

**[98] The ECtHR followed the same approach in** _Rantsev v Cyprus and Russia. There, the ECtHR found, on the_
facts, that there had been a breach of the applicant's ECHR4 rights by Cyprus to afford her 'practical and effective

86 _Leung Kwok Hung v HKSAR [2005] HKCFA 40, (2005) 8 HKCFAR 229, [2005] 3 HKLRD 164 (at [22]); Plattform_
_[Arzte für das Leben v Austria (App no 10126/82) (1988) 13 EHRR 204, (1988) Times, 30 June at para 34.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4XS-00000-00&context=1519360)_

87 _[O'Keeffe v Ireland (App no 35810/09) (2014) 35 BHRC 601, (2014) 59 EHRR 605 at para 144.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3BS-00000-00&context=1519360)_

88 _[(2012) 34 BHRC 1, (2012) 56 EHRR 24 at paras 78–81.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_

89 _[Beganović v Croatia (App no 46423/06) [2009] ECHR 46423/06 at para 71.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3TH-00000-00&context=1519360)_

90 _[(2014) 35 BHRC 601, (2014) 59 EHRR 605 at para 149.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3BS-00000-00&context=1519360)_

91 _[Botta v Italy (App no 21439/93) (1998) 4 BHRC 81, (1998) 26 EHRR 241 at para 34.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3GY-00000-00&context=1519360)_

92 _[Siliadin v France (App no 73316/01) (2005) 20 BHRC 654, (2005) 43 EHRR 287.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

93 _CN v France (App no 67724/09) (judgment, 11 October 2012)._

94 _[(2012) 34 BHRC 1, (2012) 56 EHRR 24.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_

95 _[(2010) 28 BHRC 313 (2010) 51 EHRR 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_


-----

protection against trafficking and exploitation' (at para 293) and in respect of the failures of the police authorities to
take effective measures for her protection (at para 298), and by Russia in respect of its procedural obligation to
investigate trafficking in relation to her case (at para 308). The ECtHR did not, however, hold that there was a
breach of ECHR4 by reason of the failure of either Cyprus or Russia to enact specific legislation to criminalise any
particular activity.

**[99] It is also to be noted, as a matter of context, that in Rantsev v Cyprus and Russia the ECtHR took into account**
the obligations under the Palermo Protocol and the Anti-Trafficking Convention in considering the scope of the
obligations arising under ECHR4:

['In Siliadin v France (2005) 20 BHRC 654 at paras 89 and 112, the court confirmed that art 4 entailed a specific](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)
positive obligation on member states to penalise and prosecute effectively any act aimed at maintaining a
person in a situation of slavery, servitude or forced or compulsory labour. In order to comply with this
obligation, member states are required to put in place a legislative and administrative framework to prohibit and
punish trafficking. The court observes that the Palermo Protocol and the Anti-Trafficking Convention refer to the
need for a comprehensive approach to combat trafficking which includes measures to prevent trafficking and to
protect victims, in addition to measures to punish traffickers. It is clear from the provisions of these two
instruments that the contracting states, including almost all of the member states of the Council of Europe,
have formed the view that only a combination of measures addressing all three aspects can

**[*126]**

be effective in the fight against trafficking. Accordingly, the duty to penalise and prosecute trafficking is only
one aspect of member states' general undertaking to combat trafficking. The extent of the positive obligations
arising under art 4 must be considered within this broader context.'[96]

**[100] Given the different context of ECHR4, the European jurisprudence relied upon by the appellant in relation to**
BOR4 must be read with some caution. Even so, none of the ECtHR cases relied upon by the appellant supports
the contention that BOR4 necessarily requires the HKSARG to enact specific criminal offences to penalise slavery,
servitude and forced or compulsory labour. Instead, the relevant inquiry is whether, on the facts of any given case,
the protection of the rights under the ECHR or, in our case, the BOR has been rendered 'practical and effective'.[97]

_D.3b FLC25 and the views of the ILO Committee of Experts_

**[101] FLC25 provides that:**

'The illegal exaction of forced or compulsory labour shall be punishable as a penal offence, and it shall be an
obligation on any Member ratifying this Convention to ensure that the penalties imposed by law are really
adequate and are strictly enforced.'

**[102] Whilst the FLC is applicable to Hong Kong, FLC25 has not been incorporated into Hong Kong law.[98] That**
notwithstanding, the Committee of Experts of the ILO has stated that:

'Although desirable, general provisions making the use of forced labour a punishable offence with appropriate
penalties are not always necessary to give effect to the provisions of Article 25 of the Convention. The
Committee seeks assurance from governments, often by requesting supplementary information, that there are
provisions allowing punishment of persons guilty of forced labour practices found to have occurred in their
country. A wide range of provisions can thus be used in practice by the courts, especially where those
provisions are interpreted together (with others such as those concerning coercion, the use of threats or
violence, detention, exploitation of vulnerability, freedom of employment, and so on).'[99]

**[103] It is also clear from the Committee of Expert's Report that, whilst '[i]t may in practice not be enough to adopt**
provisions making the use of forced labour an offence and establishing penalties for it in general terms', by
implication general provisions may be enough if the protection is sufficient for victims and to enable the authorities
responsible for protecting their rights to ensure that they are enforced.[100]


-----

**[104] This material therefore falls far short of supporting the contention that a bespoke offence criminalising forced**
or compulsory labour is a positive obligation of the HKSARG under BOR4.

26

**[*127]**
D.3c Concluding Observations of the HRC

**[105] In the appellant's written case, reference is made to the Concluding Observations of the HRC in respect of**
Brazil in 1996 where the HRC said:

'The Committee urges the State party to enforce laws prohibiting forced labour … and to implement
programmes to prevent and combat such human rights abuses … It is imperative that persons who are
responsible for, or who directly profit from, forced labour … be severely punished under law.'[101]

**[106] This comment must be read in its proper context, as must also the HRC's Concluding Observations on the**
Third Periodic Report of Hong Kong, China,[102] and the many other similar examples to which Mr Husain referred
the Court during the hearing. The nature of the HRC's Concluding Observations has been addressed above (in
section C.4e) and they are tailored to the particular circumstances of the individual States Parties concerned. There
is no statement in any of those Concluding Observations of the existence of a positive legal obligation to enact a
specific law to criminalise forced or compulsory labour, as opposed to general criminal legislation which may be
used in practice to combat the exploitation of victims of forced or compulsory labour.
D.3d HKSARG policy irrelevant to construction of BOR4

**[107] The respondents' evidence as to the HKSARG's commitment, as a matter of policy, to combat human**
trafficking may demonstrate that there is no policy objection to the enactment of a bespoke offence to criminalise
forced or compulsory labour. However, for the reasons stated in section C.4f above, that policy is not relevant to the
construction of BOR4.
D.3e Analogy with torture inapt

**[108] Mr Husain sought to draw an analogy with torture to support his contention that specific offences were**
required to criminalise slavery, servitude and forced or compulsory labour.[103] In Hong Kong, torture is the subject of
the Crimes (Torture) Ordinance creating a specific offence of torture.[104] The analogy is not, however, apt. The
Crimes (Torture) Ordinance was necessary to ensure compliance with the HKSARG's obligation under the UN
Convention Against Torture and Other Cruel, Inhuman or Degrading Treatment or Punishment ('the CAT'),[105] rather
than to secure compliance with BOR3. Torture, unlike other forms of physical assault and abuse addressed by the
general criminal law, is a separate type of pain and suffering specifically defined in art 1 of the CAT and, under the
Crimes (Torture) Ordinance, consists of the

27

96 _[(2010) 28 BHRC 313, (2010) 51 EHRR 1 at para 285 (footnotes omitted).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

97 _[Siliadin v France (App no 73316/01) (2005) 20 BHRC 654, (2005) 43 EHRR 287 at para 148; Demir v Turkey (App](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_
No 34503/97) _[[2009] IRLR 766, (2008) 48 EHRR 1272, para 66;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W43C-00000-00&context=1519360)_ _Rantsev v Cyprus and Russia (App no 25965/04)_
_[(2010) 28 BHRC 313, (2010) 51 EHRR 1 at para 275; CN v France (App no 67724/09) (judgment, 11 October 2012),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
[para 121; CN v UK (App no 4239/08) (2012) 34 BHRC 1, (2012) 56 EHRR 24, para 77.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)

98   See the dualist principle referred to at [49] above.

99   ILO Report III (Part 1B), 96th Session, 2007, Eradication of Forced Labour at FN319, pp 73–74.

100 _Ibid at [138], p 74._


-----

**[*128]**

intentional infliction of severe pain or suffering by a public official or by another person acting at the instigation of a
public official or with his consent or acquiescence. No general offence already existing under the criminal law of
Hong Kong would criminalise that activity and so a specific ordinance was necessary.
D.4 The measures taken by the HKSARG to protect BOR4 rights

**[109] The respondents' evidence before the Judge as to the measures taken to combat human trafficking,**
exploitation and forced labour was principally set out in the affirmation of Leung Wendy, the Administrative
Assistant to the Secretary for Security.[106] Her affirmation described the efforts of the HKSARG to address issues
arising from human trafficking and forced labour by reference to inter-departmental collaboration, enforcement and
prosecution, victim identification, victim protection and prevention and international cooperation.

**[110] It is unnecessary to summarise Ms Leung's evidence at length. However, in respect of enforcement and**
prosecution, whilst acknowledging that Hong Kong 'does not have a single unified piece of human trafficking or
forced labour legislation',[107] Ms Leung provided a list of the statutory offences that could be invoked to combat
offences in relation to human trafficking and forced labour. They are directed to 'a wide range of conduct commonly
found in human trafficking and forced labour cases, including physical abuse, false imprisonment, criminal
intimidation, unlawful custody of personal valuables, child abduction, child pornography, various trafficking activities
for the purposes of prostitution and rape or other sexual offences'[108] and include provisions of: the Crimes
Ordinance,[109] the Immigration Ordinance,[110] the Protection of Children and Juveniles Ordinance,[111] the Offences
Against the Person Ordinance,[112] the Prevention of Child Pornography Ordinance,[113] the Employment Ordinance,[114]
the Employment of Children Regulations,[115] and the Human Organ Transplant Ordinance.[116]

**[111] Ms Leung's evidence also addressed the steps to improve the HKSARG's capability to enforce offences**
related to human trafficking and forced labour. This includes the inter-departmental Joint Investigation Team of the
Hong Kong Police Force, set up in 1998, to focus on human smuggling and whose terms of reference were
expanded in 2014 to cover forced labour.[117] She also referred to the Prosecution Code published by the
Prosecutions Division of the Department of Justice in September 2013, in which a new paragraph on 'Human
Exploitation Cases' was added in order to provide guidelines for prosecutors to assist them in identifying cases of
human exploitation.[118]

28

101   Written Case of the Appellant at [73] citing Concluding Observations of the HRC on Brazil, CCPR/C/79/Add.66,
24 July 1996 at [31].

102   Adopted by the HRC at its 107th session (11–28 March 2013).

103   In support his argument on Question 1 that BOR4 should be construed as including a protection against human
trafficking as an anterior process to the prohibited conduct, Mr Husain also sought to draw on the analogy of torture by
contending that the protection against torture in art 3 of the BOR ('BOR3') is also construed as including a prohibition
on refoulement to another country where there is a real risk of torture. However, torture is distinguishable in this
respect because the obligation of non-refoulement relates to the HKSARG taking a decision as to how to deal with a
person within Hong Kong: see _Ubamaka v Secretary for Security_ [2012] HKCFA 87, (2012) 15 HKCFAR 743 (at
section H).

104   (Cap 427).

105   Article 4 of the Convention provides: '(1) Each State Party shall ensure that all acts of torture are offences under
its criminal law. The same shall apply to an attempt to commit torture and to an act by any person which constitutes
complicity or participation in torture. (2) Each State Party shall make these offences punishable by appropriate
penalties which take into account their grave nature.'

106   Affirmation dated 10 September 2015 ('Leung affirmation').

107 L ffi i [14]


-----

**[*129]**

**[112] Before the hearing in the Court of Appeal, the respondents were given leave to file further evidence to**
address steps taken by the HKSARG in tackling issues concerning human trafficking and forced labour since the
hearing before Zervos J. In the affidavit of Mr Ng Hoi Ka,[119] Assistant Secretary for Security, it was explained that in
March 2018 the HKSARG had established a high-level Steering Committee, chaired by the Chief Secretary for
Administration, which had promulgated and launched, on 21 March 2018, an 'Action Plan to Tackle Trafficking in
Persons and to Enhance Protection of Foreign Domestic Helpers in Hong Kong'.[120]

**[113] Mr Ng also provided an updated list of statutory provisions that could be invoked to combat offences in**
relation to human trafficking or forced labour. Mr Ng explained that: in December 2016, the Security Bureau issued
a 'Guideline on Inter-departmental Cooperation for the Handling of Suspected Cases of Trafficking in Persons';[121] in
February 2018, the Employment Ordinance was amended to afford enhanced protection for foreign domestic
helpers by increasing the maximum penalties for the offences of overcharging commission and for operating an
unlicensed employment agency;[122] in 2015, the Immigration Department introduced a victim screening mechanism
to identify victims of human trafficking.[123]

**[114] Given the wide margin of discretion that is to be afforded to the HKSARG in respect of its positive obligations**
under BOR4, the approach described in the respondents' evidence is an acceptable method of compliance
providing it affords practical and effective protection of the rights under BOR4.
_D.5 Absence of bespoke offence not shown to be cause of breach of appellant's BOR4 rights_

**[115] Having concluded, in answer to Question 1, that the scope of the protection in BOR4 does not extend to**
human trafficking for forced or compulsory labour, the approach and analysis of Zervos J on the nature of the
obligation to protect potential victims under BOR4 can be disregarded. Instead, the question for this Court is
whether it is shown that the breach of the appellant's BOR4 rights was caused by the absence of a bespoke offence
criminalising forced or compulsory labour.

**[116] Here, it is necessary to keep in focus the finding as to breach of BOR4 in this case. The Court of Appeal**
upheld the Judge's finding that the HKSARG had failed in its investigative duty under BOR4 in relation to the
appellant's complaints in this case.[124] There is no appeal against that finding by the respondents and he will, in due
course, receive a remedy for that breach in the further hearing directed by the Judge (see [14] above). However,
there is no finding that the breach of the investigative duty under BOR4 was the result of the absence of a specific
offence criminalising forced or compulsory labour. On the contrary, Cheung CJHC concluded:

'From the evidence presented before the court, it is plain that the breach was due not to the absence of any
specific criminal offence as such, but rather the lack of training of the officers of the various government

29

108 _Ibid at [13]._

109   (Cap 200).

110   (Cap 115).

111   (Cap 213).

112   (Cap 212).

113   (Cap 579).

114   (Cap 57).

115   (Cap 57B).

116   (Cap 465).

117   Leung affirmation at [16].

118 _Ibid_ [19] [23]


-----

**[*130]**

authorities involved regarding article 4 violations, and the total lack of central supervision and coordination in
terms of investigating and combating such violations.'[125]

**[117] There is no proper basis to disturb that finding of the Court of Appeal. Whilst it is true, as the appellant points**
out,[126] that his former employer has not been prosecuted for the misconduct alleged against him, it does not follow
that this demonstrates that the patchwork of offences for which he might be prosecuted are inadequate to provide
practical and effective protection against forced or compulsory labour. Given the range of offences of which the
employer might have been charged, the failure by the respondents to investigate the appellant's case could not,
realistically, be said to have occurred because of the lack of a specific offence criminalising forced or compulsory
labour.

**[118] Focusing on the obligation to protect against the requirement to perform forced or compulsory labour, it also**
cannot be said that the patchwork of offences available to the HKSARG is inadequate to provide practical and
effective protection of that BOR4 right. The argument to the contrary advanced on behalf of the appellant was one
of form over substance. It simply could not be shown that, had there been a bespoke offence prohibiting forced or
compulsory labour, the appellant would have been better protected against the gross mistreatment to which he was
subjected by his employer.

**[119] On the other hand, as the European jurisprudence in respect of ECHR4 shows, the fact sensitive nature of**
the inquiry as to the adequacy of measures taken in discharge of the positive obligation arising under BOR4
requires the HKSARG to be vigilant in ensuring its measures to prevent, identify and investigate cases of forced or
compulsory labour, to enforce laws and prosecute offenders under the existing patchwork of criminal offences, and
to provide protection for victims are practical and effective.

**[120] In his conclusion in the Court of Appeal on the issue of whether a specific criminal offence was required,**
Cheung CJHC said this:

'From the latest evidence filed by the government with leave from us, it would appear that further and more
sophisticated efforts have been and are being made by the government to strengthen the protection afforded to
potential victims of art 4 with the aim to providing them with practical and effective protection. The effectiveness
of those measures is doubted by the evidence filed on behalf of the applicant also with leave from us. It
remains to be seen whether these or other further efforts by the government (absent specific criminal
legislation) are sufficient to provide the requisite practical and effective protection. As I said, regardless of
whether the learning curve is steep or not, the government should act fast. It may not take too many more
cases to be brought to court before it will come to the ultimate conclusion that the enactment of specific
criminal law is the only way out.'[127]

**[121] I would respectfully agree. It would be wrong for the respondents to rest on the laurels of their success on the**
appeal in this Court by relaxing the vigilance with which the measures to combat breaches of the rights protected by
BOR4 are administered and enforced. Mr Husain was right to point out that human rights protections must not be
'theoretical and illusory'.[128] Moreover, the

30

119   Affidavit dated 4 May 2018 ('Ng affidavit').

120   Ng affidavit at [4].

121 _Ibid at [10]._

122 _Ibid at [11]._

123 _Ibid at [12]._


-----

**[*131]**

respondents' treatment of the appellant when he complained to the authorities of his mistreatment does not cast the
respondents in a favourable light and was rightly described by Lord Pannick as disgraceful. Practical and effective
protection of BOR4 rights should ensure that a case like the present is a rare and isolated event.
_D.6 Answering Question 2_

**[122] I would therefore answer Question 2 as follows:**

(1)   The HKSARG has a wide margin of discretion in the manner in which it complies with its positive
obligations under BOR4 and there is no absolute duty on the HKSARG to maintain an offence specifically
criminalising forced or compulsory labour.

(2)   To comply with its obligations in respect of BOR4, the HKSARG must take steps to afford practical
and effective protection of those rights. Whether practical and effective protection has been provided will
depend on the facts of any given case.

(3)   On the facts of this case, it has not been shown that a bespoke offence criminalising forced or
compulsory labour is necessary in that the patchwork of offences already in existence failed to afford the
appellant sufficient protection.

(4)   The determination that a bespoke offence is not required does not preclude a different conclusion
being reached in a future case, in the event that the HKSARG is shown in future not to afford practical and
effective protection of the rights under BOR4 by reason of the absence of such an offence. Nor should this
judgment be taken to indicate that a patchwork of offences would necessarily be sufficient to address a
prohibition on human trafficking, if the HKSARG were under a constitutional duty to prohibit that activity.

**[123] The appellant's failure to establish a breach of his BOR4 rights by reason of the absence of a bespoke**
offence criminalising forced or compulsory labour is distinct from the question of whether the respondents were in
breach of BOR4 in failing adequately to investigate the appellant's complaints, for which a damages hearing will in
due course be fixed in accordance with the Judge's direction.
**E. Conclusion and disposition**

**[124] For the reasons set out above, I would dismiss this appeal.**

**[125] I would direct by way of order nisi that the parties bear their own costs of this appeal, with the appellant's own**
costs to be taxed in accordance with the Legal Aid Regulations. I would also direct that there be liberty to the
parties, if so advised, to file written submissions as to costs within 14 days of the date of the handing down of this
judgment, and that, in the absence of such submissions, the order nisi stand as an order absolute without further
direction.

**CHAN NPJ.**

**[126] I agree with the judgment of Fok PJ.**

**MCLACHLIN NPJ.**

**[127] I agree with the judgment of Fok PJ.**

125 _Ibid at [176]._

126   Written Case of the Appellant at [79].

127   CA Judgment at [188].

128 _D_ _i_ _T_ _k_ (A N [34503/97) [2009] IRLR 766 (2008) 48 EHRR 1272](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W43C-00000-00&context=1519360) 66


-----

**End of Document**


-----

