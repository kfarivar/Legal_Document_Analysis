# A Local Authority v AB and others [2018] EWHC 539 (Fam)

Family Division

Keehan J

16 March 2018Judgment

**Ms N Butt (instructed by the local authority) for the Applicant**

**Mr P Bowe (instructed by Straw and Pearce) for the 1st Respondent**

**Ms A Cranny (instructed by Dodds Solicitors) for the 2nd Respondent**

**Mr R Jones (instructed by R P Robinson Solicitors) for the 3rd Respondent**

**Ms J Matthews - Stroud (instructed by Mander Cruickshank Solicitors) for the 4th- 6th Respondents**

Hearing dates: 14th – 16th March

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

MR JUSTICE KEEHAN

This judgment was delivered in private.  The judge has given leave for this version of the judgment to be published
on condition that (irrespective of what is contained in the judgment) in any published version of the judgment the
anonymity of the children and members of their family must be strictly preserved.  All persons, including
representatives of the media, must ensure that this condition is strictly complied with.  Failure to do so will be a
contempt of court.

**The Hon. Mr Justice Keehan :**

Introduction

1. I am concerned with three children, GH who is 8 years of age, IJ who is 4 years of age, and KL who is 2
years of age.

2. The mother of GH is the First Respondent, AB. The mother of IJ and KL is the Second Respondent,
CD. The father of all children is the Third Respondent, EF.

3. The Applicant local authority issued these public law care proceedings in respect of all three children on
30th May 2017. The children were accommodated pursuant to the provisions of s.20 Children Act 1989 on
15th May 2017 consequent upon the arrest of CD and EF. They were each made the subject of interim


-----

care orders on 5th June 2017. The children have remained living with foster carers since they were
received into care on 15th May.

4. On 13th November 2017 CD pleaded guilty to an offence of Modern Day Slavery contrary to s.1 of the
Modern Day Slavery Act 2015. On 19th January 2018 she was sentenced to a term of imprisonment of 4
years.

5. On 14th November 2017 EF (hereinafter referred to as 'the father') pleaded guilty to an offence of
Modern Day Slavery contrary to s.1 of the 2015 Act and to 5 counts of rape. On 19th January 2018 he was
sentenced to an extended term of imprisonment of 23 years.

6. In consequence of the convictions and custodial sentences of the mother and the father, both concede
to the threshold criteria of s.31(2) of the Children Act 1989 are satisfied. The father :

i) accepted the care plan of adoption for IJ and KL;

ii) agreed the care plan for GH of long term foster care;

iii) wanted to have a contact with GH when she is ready to see him;

iv) whilst not contesting the negative viability assessment of the paternal grandmother, would wish her to
have contact with GH; and

v) did not wish to attend, in person or by video link, this final hearing.

7. CD, the mother of IJ and KL:

i) wished to resume the care of IJ and KL upon her release from prison. The earliest release date is
August 2019;

ii) accordingly, she opposed the plan for IJ and KL to be placed for adoption;

iii) she contended that the children should remain in long term foster care pending her release from prison
and that, in the meantime, she should continue to have indirect contact with the children by means of
letters, cards and photographs.

8. AB, the mother of GH:

i) accepted GH could not return to her care;

ii) did not oppose the care plan of long term foster care; but

iii) did seek consideration to be given to there being contact between herself and GH.

9. The Children's Guardian supported the local authority's care plans of placement for adoption of IJ and
KL and placement in long term foster care for GH.

The Law

10. The local authority invited me to make a number of findings of fact in respect of allegations made by
GH which were not the subject of criminal proceedings brought against the father or CD. When considering
the evidence and whether to make the findings sought I have well in mind that (a) the burden of proof is
borne by the local authority and (b) the standard of proof is the simple balance of probabilities.

11. I give myself a revised Lucas direction that I should only take account of lies told by a party if there is
no plausible or credible reason for the witness lying and that, in any event, the finding that a witness has
lied cannot, of itself, constitute proof of the disputed fact or facts.

12. In considering the care plans for the children I take full account that the welfare best interests of all
three children are my paramount consideration: s.1(1) Children 1989 and I have had regard to the
provisions of s.1(3) 1989 Act – the welfare checklist. In respect of IJ and KL I have also taken account of
the provisions of ss1(2) and 1(4) of the Adoption and Children Act 2002: in particular that I must have
regard to their welfare best interests throughout the whole of their respective lives.


-----

13. When considering the applications for placement orders in respect of IJ and KL I take account not only
of the provisions of ss1(2) and 1(4) of the 2002 Act but also of the provisions of s.52 of the Act and whether
I am satisfied that the welfare of each child requires me to dispense with the consent of the mother and
father to the adoption of both children.

14. I must undertake an holistic and not linear evaluation of the realistic options for the future care of the
children as emphasised by the Court of Appeal in first _Re B-S [2013] EWCA Civ 1146 and then in_
subsequent judgments of the Court of Appeal.

15. I have had regard to the Art 6 and Art 8 rights of each child and of each parent: most especially
whether the placement of IJ and KL for adoption is (a) a proportionate and necessary step in light of the
circumstances of the case and the risks of harm identified and accepted by the court; and (b) nothing else
will do in the interests of both of these children.

16. When considering the Art 8 rights of the children and of the parents, I bear in mind that where there is
a tension between the Art 8 rights of the children, or one or more of them, on the one hand, and the Art 8
[rights of a parent, on the other, the rights of the child prevail Yousef v The Netherlands [2003] 1 FLR 210.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G2J2-00000-00&context=1519360)

Background

17. AB has an older child from a previous relationship prior to her relationship with the father. This child
lives with his father. During her relationship with the father GH was born. Subsequent to the breakdown of
their relationship GH went to live with the father. AB had not seen GH for some 18 months prior to the local
authority issuing these proceedings.

18. The mother, CD, has an older child of a previous relationship. This child has lived with his father
following an allegation that EF had hit him.

19. The father, EF has two other children born during a relationship he had in between his relationship
ending with AB and commencing with CD. These children live with their mother. He has no contact with
them.

20. GH was the subject of a child protection plan before her birth under the category of physical abuse
which was revised to one of neglect when she was 7 months of age as a result of her parents' chaotic
lifestyle.

21. AB and the father separated in January 2010.

22. GH remained on a child in need plan between February 2011 to May 2011 when her case was closed.
As a result of various issues in AB's life, GH remained the subject of scrutiny by social services.

23. The father separated from his partner who was the mother of his two other children in March 2013.
Almost immediately afterwards he commenced a relationship with the mother. Within weeks of that
relationship commencing the mother's son alleged EF has assaulted him. Social services were involved
and this child moved to live with his father where he remains to date.

24. In July 2013, the mother was pregnant with IJ. A pre birth assessment was undertaken and the unborn
child was placed on a child protection plan under the category of neglect. In December 2013, because of
the positive engagement with the social workers by the mother and father, the plan became one of a Child
in Need. IJ was born in February 2014 and the Child in Need plan ended in June 2014.

25. In August 2014 GH was on her second child protection plan with Warwickshire County Council's
Children's Team because of her mother's neglectful care. The father removed GH from the care of her
mother, AB, in October 2014 and Warwickshire County Council completed a s.37 report. The father
secured a child arrangements order in his favour in respect of GH in November 2014.

26. Consequent upon her move to live with her father, a Local Authority became the responsible local
authority. She was placed on a child protection plan under the category of neglect.


-----

27. GH made an allegation of sexual abuse against her mother's then partner in December 2015. The
father stopped all contact with the mother. The child protection plan came to an end as a result of an
absence of any issues about the care afforded to GH by her father and CD.

28. KL was born in August 2015.

29. A referral was made to the local authority in October 2016 because GH had been seen with bruising to
her face and ear. A s.47 investigation was undertaken and GH underwent a medical examination. The
mother and father's explanation of an accidental injury was accepted.

30. Nevertheless issues remained and increased about the lack of parental supervision and a failure by
the parents to meet GH's emotional needs, which led to a decision to convene an Initial Child Protection
Case Conference in December 2016. This resulted in GH being placed on a Child in Need plan – neither IJ
nor KL were made the subject of a Child in Need plan. GH's plan came to an end on 5th April 2017 on the
basis that (a) the issues had been addressed through work done with the family and (b) the school would
continue to monitor GH and her school attendance.

31. On 28th April 2017 the Leicestershire Police made a referral to the local authority on the basis that
GH, IJ and KL may have been exposed to domestic violence between the father and a young female living
with the family.

32. Prior to this referral the local authority had no knowledge that this young person, MN, had been living
at the family home. On those occasions when social work professionals had seen her at the parents' home,
she had been introduced as a family friend. Neither the mother nor the father had hitherto disclosed that
she was living with them.

33. On 4th May 2017 MN underwent an ABE interview with the police. During this interview she alleged
that:

i) She had met the father in 2015 and had since September 2015 been living in the family home;

ii) She had been emotionally, physically, sexually and financially abused by the father throughout the time
she had lived with them;

iii) The father's serial abuse of her had occurred with the knowledge and involvement of the mother;

iv) She had been made to clean the family home and care for the children;

v) The mother and the father has physically abused GH;

vi) The children has been exposed to inappropriate sexual conduct; and

vii) The father beat her during sexual abuse of her and forced her to have sex with him and with other
males, who paid the father money for the same.

34. On 5th May 2017, the police notified the local authority that the mother and father were suspected of
[offences contrary to the Modern Slavery Act 2015. In consequence of which the local authority decided to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
undertake a s.47 assessment on 8th May.

35. On 15th May social workers and the police attended the family home as part of a planned police
operation. The father was immediately arrested and removed from the home. The mother was then
arrested. She gave consent for IJ and KL to be accommodated pursuant to s.20 of the 1989 Act. All 3
children were taken by Social Workers and placed with foster carers. Later whilst in police custody the
father gave his consent for all three children to be accommodated by the local authority.

36. The local authority issued these proceedings on 25th May 2017. All three children were made the
subject of Interim Care orders on 5th June 2017.

37. During the course of the police interviews the father denied all of the offences, denied having had
sexual intercourse with MN or of sexually abusing her and denied she had ever lived in the family home.

38. During the police interviews the mother denied all of the offences, denied any knowledge of the
father's abuse and maltreatment of MN but did confirm that she had been living in the family home


-----

39. On 19th June 2017, MN gave further ABE interviews in which she gave graphic details of the sexual
abuse and maltreatment to which she had been subjected. She gave accounts of numerous occasions
when she had been vaginally and anally raped by the father.

40. One significant piece of evidence was a video recording taken by the father on his mobile phone. MN
was engaged in a sexual act and was being assaulted by the father. It is clear that the mother, IJ and KL
were present in the same room during which these events occurred.

41. On 30th June 2017, GH underwent an ABE interview. She gave divers accounts of the physical abuse
she suffered in the family home and of seeing the mother and MN engaged in sexual activity with the
father.

42. As set out above, in November 2017 the father pleaded guilty to an offence of Modern Day Slavery
and five counts of rape in respect of MN. The mother pleaded guilty to an offence of Modern Day Slavery.
On 19th January 2018, the father was sentenced to 23 years imprisonment and the mother was sentenced
to 4 years imprisonment.

Evidence

43. The father, as I have mentioned, did not wish to take any part in this Hearing either by attending in
person or by video link from prison although on the second morning of the hearing he did appear by video
link but solely for the purposes of giving instructions to his counsel and solicitor.

44. The mother initially took a more equivocal stance. Just prior to the commencement of this hearing I
was told by those representing her that she did not wish to attend this hearing in person. Accordingly, a
video link was arranged for her to give oral evidence to the Court by video link from her prison. I was
subsequently informed that she did not wish to give oral evidence. Accordingly she appeared by video link
from prison yesterday to hear counsels' submissions in respect of IJ and KL and, most especially, to hear
the submissions of her Counsel, Ms Cranny.

45. No party sought to call any witness to give oral evidence and neither AB, CD or the father sought to
cross examine any witness. CD and the father had confirmed at an earlier Directions Hearing that neither
wished GH or MN to be called to give evidence.

46. GH and MN gave clear and detailed accounts of the severe and regular physical abuse GH had
suffered at the hands of her father. They gave detailed accounts of the inappropriate sexual conduct to
which GH and/or IJ and/or KL were exposed. GH had alleged CD was, on occasions physically abusive
towards her. She described one occasion where CD woke her up by grabbing her throat and shouted in
her face because she had used some of CD's perfume.

47. GH has subsequently spoken to her carers and to some of the professionals involved with her of the
abuse she suffered from her father and CD. She has been consistent in her accounts save for one matter.
She alleged that her mother's partner had assaulted her. GH has recently said this was untrue and she had
only made the allegation because her father had told her to do so.

48. I do not propose to set out GH's allegations in any greater detail.

49. The father denied he had physically abused or ill treated GH at all. In contrast CD accepted there were
such occasions and she should have acted to protect GH but she did not do so.

50. CD denied assaulting GH and in particular denied she had grabbed GH by her throat and shouted at
her. In contrast the father accepted that such an event took place.

51. In the context of the fact finding aspect of this case and of the welfare issues it is instructive to
consider some of the comments and responses made by the father when seen by Dr Blyth, the forensic
psychologist, and some of her conclusions and opinions

i) “For most part, [GH] finds it difficult to talk about her experienced, and has a tendency to blame herself
for her own abuse. For example, she reported to me that her father only hit her or shouted at her when she
was naughty or did not immediately do what she was told.”


-----

ii) “One of the reasons for this is because the pathological need for a child to bond with their carer, no
matter how abusive, is such a strong biological imperative that once a bond is formed, even with an
abusive parent, it is difficult to break (Sullivan & Lasley, 2010). It may also be easier for GH to keep
blaming herself for her father's behaviour, than to face the painful and unthinkable realisation that he does
not love her.

It is also possible that GH experienced period of positive affection from her father as well as episodes of
abuse. Experiencing both positive and extreme negative behaviours from a parent, can lead to a child
becoming almost co-dependent. In addition to GH's descriptions of her father's violence and aggression,
she told me that her father also bought her nice presents, such as a princess coach and Barbie Doll, for
her birthday. This combination of care and violence, sometimes referred to as 'traumatic bonding', can
make it extremely difficult for a child to separate from the parent (Baker & Schneiderman, 2013.)”

iii) “EF and later his mother OP were both under the impression that the reason I wanted to speak with
them was so that they could tell me about GH's terrible start in life when she was in the care of AB.”

iv) “For example, in discussions with her previous foster carer, QR, GH told her about a game she and her
husband could play. When asked to describe the game, GH told her about one of the games her father
used to play, when he would lie on the floor with his eyes closed and no clothes on, and then have to
guess which of the women in the room had 'touched his cock'.

EF denied any knowledge of this 'game' when I interviewed him. However, he then stated that GH was
always being told to stay in her own room (because there were no internal doors in the house), so if she
decided to come out and sit on the stairs, then it was her own fault if she saw the adult playing games.”

v) In summary, due to her long history of maltreatment, abuse and neglect, GH presents as an emotionally
damaged little girl with significant physical and psychological needs. GH's carers will need to be
experienced and skilled in caring for a child with attachment problems who displays sexualised and
aggressive behaviour. They will also require an enormous capacity to empathise with GH's experiences
and to understand, tolerate and manage her challenging behaviour.”

vi) “Interestingly, when I talked to GH about who is in her family she was unable to explain to me what
constitutes a family and found it very difficult to understand the concept. Therefore, when I went through
her family tree with GH, she was extremely surprised to learn of her mother's and father's other children.”

vii) “Similarly, if EF is not convicted, I recommend between two and three supervised contacts per year.
Whatever decision is made regarding contact with EF this should only be permitted during the school
holidays. This is because research demonstrates that contact with a parent in prison can affect the child's
attention and concentration and increase behavioural problems around that time (University of Pittsburgh
Office of Child Development, 2011).”

viii) “Because GH experienced a combination of kindness and violence in the care of her father, she has
developed a complex relationship with him indicative of a traumatic bond. This type of relationship is likely
to make it extremely difficult for GH to emotionally separate from her father, and will need to be taken into
consideration by those caring for her in the future.”

Analysis – Findings of Fact

52. Neither the father nor CD have fully accepted the allegations made by GH of the ill treatment and
abuse she suffered at their hands. I note that having initially denied the entirety of MN's allegations in
respect of their abuse and ill treatment of her, by their guilty pleas they respectively admitted the truth of
what she had alleged.

53. MN, quite independently of GH, gave accounts to the police of GH's abuse and ill treatment by her
father and by CD which mirror and, in my judgment, corroborate the allegations made by GH in her ABE
interview with the Police.

54. On the totality of the evidence I am wholly satisfied of the following matters and make findings of fact
that:


-----

i) GH and MN have both given credible and cogent accounts of the abuse suffered by GH at the hands of
the father and of CD;

ii) The father and CD subjected GH to degrading and cruel treatment and she was serially mistreated by
both of them;

iii) GH was exposed to inappropriate sexual conduct in the family home of the father and CD which is
exemplified by her inappropriate knowledge of adult sexual relationships and her extreme displays of
sexualised behaviour; and

iv) CD may not be aware of the full extent of the father's abuse of GH but nevertheless she repeatedly
failed to protect her; and

v) IJ and KL suffered significant emotional harm by witnessing the abuse and ill treatment of GH in the
family home and inappropriate sexual conduct and their mother repeatedly failed to protect them from the
same.

Analysis – Welfare

55. I propose to consider the case of GH separately from that of IJ and KL.

56. The father recognised and accepted that he cannot now and will not be able to care for GH in the
future. AB, GH's mother, similarly recognised and accepted, albeit for very different reasons from the
father, that she is not and will not be able to care for GH. No other family member or person is put forward
by either of them to care for GH, save that at one stage the father put forward his mother. The viability
assessment of the paternal grandmother was negative: neither the father nor the paternal grandmother
sought to challenge the conclusion of this assessment.

57. Accordingly, given her age, I am left with only one placement option for GH, namely long term foster
care. The local authority are hopeful that GH will be able to remain in her current foster home. It has been
GH's consistently expressed wish to remain in foster care and not to return home to the care of her mother,
or CD or her father.

58. This plan will lead to the separation of GH from IJ and KL. It will also lead, if the Court approves the
plan for the placement of IJ and KL for adoption, to the possible termination, for the foreseeable future, of
direct contact between GH and IJ and KL. The local authority will explore the possibility of ongoing direct
contact but, understandably to some extent, will need to prioritise the stability and confidentiality of the two
younger children's potential adoptive placement.

59. Whilst I very much hope it will prove possible to continue and promote regular direct contact between
GH and her half siblings, I consider it prudent to consider the proposed care plan for GH on the basis that it
will not prove possible to maintain direct contact between her IJ and KL, albeit I very much hope this not to
be the case.

60. On the basis that such contact will occur, I note that Dr Blyth, a consultant clinical psychologist advised
in her report of 11th February 2018 that GH should be placed separately from IJ and KL because (a) GH
requires a great deal of one to one attention and (b) she needs to be the youngest child in her long term
placement by at least 5 years because of the significant demands she is likely to place on her carers.

61. She recommended that GH should continue to have direct contact with IJ and KL at a level of between
4 and 6 times per year for between one and two hours on each occasion.

62. I note the care plan for GH, dated 5th March 2018, proposed that 'consideration' will be given to GH
maintaining contact with her half siblings and that “it may be felt to be appropriate for them to have direct
contact once or twice a year” in addition to indirect letterbox contact.

63. I consider this to be (a) far too woolly and (b) in the light of Dr Blyth's opinion, fails to explain why there
may be contact once or twice a year as opposed to the 4 to 6 times a year which she recommended. In my
judgment it is in the welfare best interests of GH for the care plan to reflect that it is in her interests that


-----

i) There will be direct contact between the siblings subject to the priority to secure an adoptive placement
for IJ and KL; and

ii) Such direct contact will occur on 4-6 times per year for a period of 1-2 hours in addition to letterbox
contact.

64. So whilst I am of the clear view that such contact is in the best interest of GH, I remain satisfied that,
even if it proved not to be possible for such contact to take place, it is overwhelmingly in the welfare best
interests of GH to be made the subject of a care plan for her to remain placed in long term foster care.

65. Very sadly GH's initial foster placement broke down in October 2017. After a very brief period in a
respite foster placement, GH was placed with her current foster carers. Happily she settled with them very
quickly. The social worker observed that GH craves love and feeling part of a family unit. GH has shared
that she wishes to stay with her current carers because “they are kind to her, take good care of her and
feed her.” I very much hope this proves to be achievable for GH's ultimate benefit and wellbeing. I note the
local authority, by its Head of Service, has given an assurance that all will be done to secure this
placement for GH and financial issues will not be a relevant factor.

66. GH has consistently said that her father threatened to kill her if she ever told anyone about his
behaviour towards her. This is a threat she believes he had the capacity to carry out. She has started
writing letters to her father but she is not yet ready for them to be given to him. She does not wish to see
him.

67. In the premises I am wholly satisfied that it would be contrary to GH's welfare best interests for there to
be any contact between her and her father. She is simply not, given the abuse she has suffered,
emotionally or psychologically robust enough to cope with any such contact. I shall return to the issue of
the father's contact later in this judgment.

68. In respect of GH having any contact with the paternal grandmother, I note that GH has told the social
worker that (a) she feels let down by her paternal grandmother because she never believed her when 'the
bad things were happening' and (b) she does not want contact with her. In more recent times she has
expressed different views. It is now proposed that contact should take place between GH and her paternal
grandmother six times a year in the school holidays. In my judgment this contact must be very closely
supervised, be the subject of a very tight and clear written agreement and must be regularly reviewed. The
grandmother must not be permitted to discuss the father, his feelings towards GH or his incarceration with
GH. If she were to do so the contact session must be immediately terminated and the benefits for GH of
future contact must be reviewed.

69. Similarly GH has previously been consistent that she does not wish to have any contact with her
mother. Once again she has changed her mind in more recent times and now wishes to see her. The
mother and the social workers are working co-operatively together to come to a point where direct contact
will be resumed in the near future.

70. The options for IJ and KL are (a) to remain in foster care until their mother is released from prison
when theoretically they could be returned to her care or (b) placement for adoption.

71. The only other option of long term fostering which was not advanced by any party would in my
judgment to be wholly inimical to the welfare best interests of IJ and KL. They are only 4 and 2 years of
age. It would not be in their interests to be cared for by the state for 14 and 16 years respectively.

72. I readily recognise that a plan of adoption against the wishes of a parent is the most draconian order a
Court can make. I have intense regard to the fact that I must consider the impact of the adoption of IJ and
KL throughout the whole of their respective lives.

73. The father consents to placing the children for adoption.

74. The stance of the mother is that the children can wait in foster care until she is released from prison
next August, at the earliest, and that it is not too long a time for them to wait to be rehabilitated to her care.
Ms Cranny, on behalf of the mother, reminded me in submissions of some of the mother's positive qualities


-----

as reported in the parenting assessment. She emphasised that the mother loves the children and IJ and KL
love her. She wants the chance to be able to care for the children upon her release from prison and she
wants the children to know that she fought to have them returned to her care.

75. Whilst I do not doubt that the mother loves her children and that they love her and I accept those
submissions prayed in aid on behalf of the mother, her stance is utterly fanciful and bears no relation to
reality whatsoever.

76. The period of her incarceration and the date of her release from prison is just one fact which I have to
take into account in considering the welfare best interests of these two very young children. The mother is,
in my judgment, being totally disingenuous. I have to have regard not just to the length of her incarceration
but the reasons for the same.

77. The judge in his sentencing remarks commented that she had voluntarily associated herself with her
father and observed that she was not the victim she was portraying herself to be. Further he did not accept
that she did not know about the sexual abuse of MN. He said she was complicit and although enthralled by
the father, she did nothing to support MN nor to end the exploitation she knew was being perpetrated.

78. I respectfully agree. The evidence in support of those comments and observations is overwhelming.
Furthermore, in light of my own findings of fact, the mother was an active participant in the abuse of GH.
Therefore, although the mother may correctly assert that she was a victim, in some respects, of the abuse
and controlling behaviour of the father, that does not begin to explain, let alone excuse, the abusive acts of
the mother toward GH, her failure to protect her and for her failure to take any steps to protect or prevent
the abuse of MN by the father. Still less does it explain or excuse the readiness of the mother to permit or
allow IJ and KL to be present and to witness the controlling, and/or physical and/or sexual abuse by the
father of MN. Nor does it explain or excuse why the mother permitted or allowed IJ and KL to be present
during or to witness the fathers and/or her abuse or mistreatment of GH.

79. The mother appeared not to recognise or accept any of the foregoing.

80. In the premises, the jobs she has secured in prison and the classes she has embarked upon may well
be beneficial for her own long term wellbeing and she is to be congratulated for engaging in the same, but
they have, in my judgment, no impact on the mother's ability to care for these children on the facts of this
case.

81. The mother's failings as a parent, as set out above, are so grave that the prospect of the mother being
able to parent IJ and KL in a safe, nurturing and positive manner is, whether now or in the future, remote in
the extreme.

82. The fact that the mother does not even begin to acknowledge the seriousness of her failings as a
parent, preferring to see herself as a victim, demonstrates that the prospects of the mother changing so
radically as to be able to be a safe parent are very poor.

83. If I were to approve a future rehabilitation of the children to the mother it would have the benefit of
them living with their mother once more. The singular disadvantage is that it would expose IJ and KL to a
very high risk of suffering yet further serious and significant emotional and psychological harm.

84. The disadvantage of the adoption of IJ and KL is the termination of their relationship with their mother
and their father and their status as children of the parents. This will have an impact on them for the whole
of their respective lives. The advantage is that they will both have the best possible opportunity to live in a
loving and stable home with dedicated and committed carers which will enable them to achieve their full
potential in their lives.

85. The children's guardian in her helpful and clear final report reached the same conclusions.

86. The only option which meets the welfare best interests of IJ and KL is for them to be placed for
adoption. This plan is a wholly proportionate course to take when balanced against the very real risks of
serious harm if the children were to be rehabilitated to the care of the mother.

Conclusions


-----

87. I will make a care order in respect of GH and I approve the plan for her to remain in long term foster
care as supported by both her mother and father. The issue of whether GH will remain in the care of her
current foster carers as a long term placement must be resolved immediately and without any delay
whatsoever. It is vital that this young troubled and vulnerable girl knows where she is going to live and who
is going to care for her long term.

88. I am pleased to hear that GH would like to see her mother. The mother accepted that direct and
indirect contact with GH should only take place if and when the professionals judge it to be in her welfare
best interests. Accordingly it is agreed I do not need to consider making a s.34(4) order in respect of the
mother.

89. The issue of GH having contact with her father demands the very closest examination and
consideration. He, as I have found, had repeatedly physically abused GH and has caused her grave
emotional and psychological damage for which he accepts no responsibility whatsoever. GH blames
herself for her father's abuse. He denied and denies he has done so and, as set out above, he blamed GH
for being exposed to adult sexual activity “it was her own fault”. This is a truly shocking and troubling
stance for this father to take. Unless there is a fundamental and genuine change in his thought process
and acceptance of his abusive actions and his responsibility, I do not see how contact, in any form, would
be in the welfare best interests of GH.

90. GH's expressed wishes, which may include a wish to see her father, must be carefully considered in
the context of the grave emotional and psychological harm she has suffered. I respect Dr Blyth's opinions
on the issue of contact but part company with her on the issue of GH having contact with her father, after I
have taken account of the totality of the evidence.

91. Initially the local authority did not seek a s.34(4) order in respect of the father. On further reflection, it
has changed its approach and yesterday invited me to make this order. Mr Jones, on behalf of the father,
opposed the order on the basis that, taking account of the provisions of s1(5) of the 1989 Act an order was
not needed and that the position of the father's contact could be the subject of an appropriately worded
recital. This would reflect the father's current stance that contact should only take place when the
professionals consider it is in her welfare best interests and GH wants to see her father.

92. I disagree. In my judgment the father is a dangerous and manipulative man. He accepts no
responsibility for his abuse of GH. In denying the truth of her allegations he is, in effect, accusing her of
lying. I have no confidence that his current apparent co-operative and reasonable stance on the issue of
contact with GH will be maintained in the future. An order under s.34(4) is a permissive order. My concerns
about the father having contact are so grave that it is wholly appropriate for me to relieve this local
authority of its statutory duty to promote contact between GH and her father. I am satisfied that the social
workers will remain alive to this issue and if the time comes when it is considered to be in GH's welfare
best interests to have some form of contact with him, they will arrange the same.

93. I note the criminal trial judge in his sentencing remarks described the father “as a dangerous offender
who is a risk of committing further serious offences in the future” (I acknowledge these remarks were made
in the context of the charges which related to MN).

94. The father consents to the adoption of IJ and KL; the mother does not. Although the father consents
to the making of placement orders and consents to them being adopted, he has not signed the requisite
consent forms. Accordingly all counsel agreed, including counsel for the father, that if I approved the plans
of the local authority and considered making placement orders, I should consider formally dispensing with
the consent of the father pursuant to s.52 of the 2002 Act. For the reasons given above I am in no doubt
that the only appropriate and necessary plan for IJ and KL is one of adoption. Accordingly, I am wholly
satisfied it is in their welfare best interests that I:

i) make them both the subjects of care orders;

ii) pursuant to s.52 of the 2002 Act, dispense with the consent of the mother and the father in respect of
both of them; and


-----

iii) make them the subject of placement orders.

95. The father did not seek a farewell contact with the children. The mother did and the local authority
agreed to make arrangements for a farewell contact visit in the family room at the mother's prison.

96. The neglect and later abuse of GH took place when Warwickshire County Council and a Local
Authority were involved with GH and her family. In respect of the latter this involvement covered the period
when MN was seriously abused over a lengthy period of time in the family home. The children's guardian
suggested in her report that this case should be the subject of a Serious Case Review. The local authority
agree. So do I.

97. I wish to express my grateful thanks to Counsel and to their instructing solicitors for their conduct and
presentation of this case which has been immensely helpful to the Court and entirely proportionate.

**End of Document**


-----

