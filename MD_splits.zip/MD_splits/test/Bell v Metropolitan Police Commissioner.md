# Bell v Metropolitan Police Commissioner [2024] EWHC 379 (KB)

King's Bench Division

Mrs Justice Hill DBE

21 February 2024Judgment

**Stephen Simblet KC and Stephen Clark (instructed by Bindmans LLP) for the Claimant**

**Adam Clemens (instructed by Directorate of Legal Services, Metropolitan Police) for the Defendant**

Hearing dates: 20-23 November 2023

Further submissions: 1, 8 and 14 December 2023; 13, 14 and 16 February 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 2:00pm on 21 February 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

MRS JUSTICE HILL

**Mrs Justice Hill DBE:**

**Introduction**

1. By a claim issued on 30 March 2021, the Claimant brings proceedings under the _[Human Rights Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_[1998 (“the HRA”), s.6 for a breach of his rights to respect for family life under Article 8 of the European](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
Convention on Human Rights (“the ECHR”) and in negligence. His claims arise out of the abduction of his
3 year old son, ROC, by his former partner, ALK, on the afternoon of 26 September 2013. ALK took ROC
to Brazil and has not returned with him since, such that the Claimant's relationship with his son has been
irreparably damaged.

2. The Claimant contends that not only did the Defendant's officers fail to act, but they assisted and
enabled ALK in carrying out the abduction. This was because, having initially secured ROC's passport from
ALK, the officers returned it to her without good reason. Further, they did so without putting in place other
protective measures such as a “port alert” and without telling him what they had done, so he could try and
secure appropriate court orders to prevent the abduction.

3. The Defendant broadly accepts that the officers acted as alleged, but contends that they were justified
in doing so, and that the Claimant's claims fail as a matter of law. The Defendant admits that he is
[vicariously liable for the acts of his officers under the Police Act 1996, s.88 and that he is a public authority](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0MX-00000-00&context=1519360)
for the purposes of the HRA, s.6. By virtue of a series of agreements between the parties, no limitation
issues arise on the HRA claim.


-----

4. The Defendant chose to call none of the officers to give evidence at the trial. The Claimant contended
that there was no credible explanation for this, such that inferences should be drawn against the Defendant
in accordance with the principles set out in _Wisniewski v Central Manchester Health Authority_ _[[1998]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68Y7-2BH3-S7C0-22TD-00000-00&context=1519360)_
_[EWCA Civ 596; [1998] PIQR 324 (“the Wisnieswki issue”).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68Y7-2BH3-S7C0-22TD-00000-00&context=1519360)_

5. A further preliminary issue was whether, as a matter of law, the police officers had any power to retain
ROC's passport, once ALK had sought its return (“the passport retention issue”).

6. The Claimant's HRA claim sought just satisfaction in the form of (i) reimbursement of the legal fees and
incidental expenses he has incurred in trying to secure more contact with ROC and his return to England;
and (ii) non-pecuniary damages to reflect his extensive distress and anxiety. His negligence claim was
advanced on a narrower basis, and only sought item (i) by way of special damages. I therefore considered
the HRA claim first.

7. This judgment is structured as follows:

**Section 2          : The evidence in overview: see [10]-[22] below;**

**Section 3          : The relevant procedures, guidance and court powers: [23]-[46];**

**Section 4          : The factual background: [47]-[123];**

**Section 5          : The Wisniewski issue: [124]-[144];**

**Section 6          : The passport retention issue: [145]-[180];**

**Section 7          : The HRA claim: [181]-[294];**

**Section 8          : The negligence claim: [295]-[347]; and**

**Section 9          : Conclusions: [348]-[355].**

8. The parties agreed a list of issues with respect to the HRA and negligence claims, which are broadly
reflected in the sub-headings within sections 7 and 8.

9. An order has been made granting anonymity to ROC given his age and the sensitive and personal
nature of the subject-matter. I have withheld from this judgment details that would unnecessarily increase
the risk of ROC otherwise being identified by jigsaw identification. This includes the name of his mother,
hence her being referred to as ALK. As this case involves detailed consideration of issues that have been
considered in the family law proceedings, I have followed the Practice Guidance issued by the President of
the Family Division in December 2018 on the avoidance of the identification of children in judgments. The
parties assisted in this task.

**2: The evidence in overview**

10. The Claimant was a clear and compelling witness. He set out the background to the breakdown of his
relationship with ALK, his growing concerns that she would try and take ROC to Brazil without his consent
and the detail of his actions over the key days in late September 2013. He described the significant
psychological impact on him of not having seen ROC in person since 2013, other than one brief visit, and
the extensive financial impact of the abduction on him, principally through the costs of lengthy legal
proceedings in both England and Brazil.

11. The Claimant also relied on evidence from Alison Shalaby OBE, Chief Executive Officer of Reunite
International Child Abduction Centre. Reunite is the leading UK charity dealing with the movement of
children across borders. It has an international reach and is recognised overseas. It is funded by the
Ministry of Justice and the Foreign and Commonwealth Office.

12. Ms Shalaby was an impressive witness. She set out in detail the assistance that Reunite had provided
to the Claimant after he called them for help on 26 September 2013. She was highly critical of the officers
with whom she dealt on the Claimant's behalf, saying that she was “shocked” at their attitudes. Her
unchallenged evidence was that they did not understand the law properly and were dismissive of the
advice she tried to give them Officers from other police forces call the Reunite advice line to seek


-----

assistance and work constructively with Reunite. However her experience was that Metropolitan Police
Service officers generally do not do so, but consider that “they know best”, “show no curiosity as to the
issues” and “do not try to learn or rectify their knowledge”. She said that the Claimant's case remains in her
mind “one of the worst experiences” she has had in her 30 years of working in the field of international child
abduction.

13. The Claimant relied on expert evidence from Carolina Marin Pedreño, a solicitor and internationally
recognised expert on the workings of the Hague Convention on the Civil Aspects of International Child
Abduction (“the Hague Convention”). Ms Pedreño reviewed each stage of the relevant chronology. Her
expert opinion was to the effect that the officers had failed to take the basic steps required to prevent that
from happening. This was principally by failing to put in place a port alert or by supporting him in seeking
his own legal redress through the civil courts.

14. In Part 35 questions to Ms Pedreño the Defendant had suggested that she had exceeded the scope of
her instructions; and the role of an expert generally. No specific submissions to this effect were made at
the trial by Mr Clemens. However, for the avoidance of doubt, I have made my own assessment of the
evidence and none of the conclusions I have reached below are based solely on Ms Pedreño's evidence.

15. Both parties relied on the key contemporaneous documents, primarily the relevant entries on the
Defendant's Computer Aided Dispatch (“CAD”) records, the Crime Report Information System (“CRIS”), the
'MERLIN' system and the Claimant's Custody Record. Reference was also made to material from the
family proceedings and one contemporaneous email sent after ROC's passport had been returned to ALK.

16. These documents provided a relatively clear picture of what had happened but gave virtually no detail
as to why it had. There were, crucially, no contemporaneous documents explaining why the decision to
return ROC's passport was taken and why no other protective measures such as a port alert were put in
place.

17. On 30 June 2014 the Claimant filed a police complaint about what happened. DI Brown investigated
the complaint. He took accounts from seven officers who had been involved: PC Abery, PC Burroughs, DC
Wiltshire, DS Johnson, DS Hassall, DS Taylor and DS Hicks. The last three of these were specialist Child
Abuse Investigation Team (“CAIT”) officers. DI Brown provided his report on the investigation to the
Claimant on 17 January 2017.

18. On 24 September 2018 the Claimant's solicitor sent the Defendant a letter of claim which specifically
sought disclosure of the accounts the officers had given to the complaint investigation, among other things.
Despite receipt of this letter, on or shortly after 6 January 2019 the Defendant deleted the officers' accounts
that were held on DI Brown's email account. This deletion of documents was said to be justified because DI
Brown was retiring, and it was usual practice to delete officers' email accounts at that point. The Defendant
did not preserve the accounts in the complaint file on the borough server either (if they had ever been
saved there, which was unclear). No attempt was made to explain to the court this apparent breach of the
duty to preserve disclosable documents once litigation is contemplated: see, for example, Practice
Direction 31B, paragraph 7, which requires preservation of electronic documents which would “otherwise
be deleted in accordance with a document retention policy or otherwise deleted in the ordinary course of
business”.

19. DC Wiltshire had retired on 2 April 2018 and DS Johnson on 29 May 2018. Their email accounts, and
any documentation relevant to this case contained therein, were also deleted on their retirement. In
fairness, this was before the letter of claim was sent. However it was after the Claimant had filed the police
complaint, which had been partly upheld, rendering a civil claim a realistic possibility.

20. As it happened, one of the officers, DS Hassall, had preserved her own copy of the account she gave
to the investigation. The email account DS Taylor had provided to the investigation was also located. The
Defendant relied on these accounts. The Defendant also sought to rely on DI Brown's summary of DC
Wiltshire's account as set out in the investigation report.

21. No hearsay notices had been served by the Defendant in relation to this material. The Claimant did not
object to the material being considered Accordingly this evidence was admitted but I approached it with


-----

[caution, having regard to all the circumstances and in particular those factors set out in the Civil Evidence](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYC0-TWPY-Y1CG-00000-00&context=1519360)
_[Act 1995, ss.4(2)(a)-(d). I concluded that (i) it would have been “reasonable and practicable” to produce DS](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYC0-TWPY-Y1CG-00000-00&context=1519360)_
Hassall, DS Taylor and DC Wiltshire as witnesses (see further at [137]-[142] below); (ii) none of the
documents were made contemporaneously with the key events but over 2½ years later; (iii) in the case of
DI Brown's evidence, the evidence involved multiple hearsay; and (iv) given that DS Hassall, DS Taylor
and DC Wiltshire were providing their accounts in the context of an investigation into their conduct, which
they had been told might lead to criminal or disciplinary proceedings being brought against them, they may
well have had a “motive to conceal or misrepresent” matters.

22. That said, DS Hassall's detailed account of the advice she gave justifying the initial seizure of ROC's
passport was entirely consistent with the relevant guidance and the contemporaneous evidence (namely
an email she had sent on 1 October 2013). I found it credible. The untested accounts from DS Taylor and
from DC Wiltshire were much more problematic, as they bore on the central issues of whether there was a
real and imminent threat that ALK would abduct ROC and why it was considered appropriate to give her
his passport.

**3: The relevant procedures, guidance and court powers**

_The Defendant's Standard Operating Procedure (“SOP”), January 2009_

23. The Defendant's Child Abduction SOP applied to all police officers and staff. It stated that the police
“MUST instigate counter-measures” to run in parallel with any civil proceedings being brought by a parent,
“requiring police to follow these instructions” [emphasis here and in the extracts below in the original].

24. It explained that the _[Child Abduction Act 1984 (“the CAA”), s.1 makes it an offence for a person](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0Y0-TWPY-Y17P-00000-00&context=1519360)_
connected with a child under the age of 16 to take the child out of the UK without the appropriate consent.
The statutory definition of “appropriate consent” was set out, making clear that in the context of this case it
meant the consent of both ALK and the Claimant, as he had parental responsibility for ROC (having been
married to ALK at the time of ROC's birth). The SOP made clear that the only exceptions to this rule,
permitting a parent to remove a child from the country without the other parent's consent, are where there
is a relevant family court order in place.

25. The SOP stated that “the key to police action” was “is the threat believed to be 'real and imminent'?”. It
continued:

“DEFINITIONS

**Real and imminent**

Guidance to determine whether removal of the child is 'real and imminent'.

(a)  Have any preparatory steps been taken?

(b)  Have threats of removal recently been made?

(c)  Is the removal likely to be within the next 24 to 48 hours?

(d)  Has the person considered likely to abduct the child unsupervised access and, if so:

a. Is the child with the “abducting” person at present; and

b. Has the “abductor” previously returned the child on time after access?

c. Has the “abductor” any links abroad, i.e. home, relatives, financial and /or job”.

26. The SOP set out a series of actions that “MUST” be taken immediately by the officer taking the initial
report from the complainant: immediately informing the Duty Officer, opening CRIS and MERLIN PAC
reports, informing other police teams as appropriate and carrying out a risk assessment jointly with the
Duty Officer to ascertain if the threat of abduction was real and imminent, and recording that assessment
on the CRIS report.

27. It continued:


-----

“IMMEDIATE ACTION BY REPORTING OFFICER IN THE EVENT OF 'REAL AND IMMINENT' THREAT
**OF ABDUCTION**

    - Create a…CAD incident report

    - Transmit a 'port warn' to 'PORTS' (National Ports Office - extn [number given] – 24 hrs) by MSS SMG
**PORTWARN to ensure early notification of the event**

     - (NB: Consideration should be made as to whether the request for a 'port alert' is not being sought by way
_of insurance by a third party e.g. Solicitor contacting police requesting a port alert is not sufficient to create_
_an alert unless an allegation of child abduction has actually been made and falls within the criteria for 'Real_
_and Imminent')_

     - Create a Missing Person report for the child on MERLIN and cross reference it to the CRIS report for full
investigation

    - Create a Wanted Missing or Locate Trace on the PNC [Police National Computer] for the potential
abductor

     - Once the fast track action has been completed, inform the relevant investigation unit will take over the
investigation:

o For Offences under S1 Child Abduction Act and S49 Children Act 1989 – SCD5 investigate [SCD being
the Defendant's Specialist Crime Directorate]

o Offences under S2 Child Abduction Act – BOCU CID investigate

**PLEASE NOTE CHILD ABDUCTION CASES ARE COMPLEX AND THE ABOVE SHOULD BE**
**CONSIDERED IN ALL CASES. ADVICE CAN BE SOUGHT FROM THE LOCAL CAIT OR for out of**
**hours contact SCD5 RESERVE DESK on [number given]”.**

28. The SOP continued by setting out in detail the information to be obtained from complainants in all
cases, the initial action to be taken by the investigative unit and the further action to be taken by SCD5 in
relation to cases involving offences under the CAA, s.1. This included making contact with Reunite and
ensuring the Complainant had access to legal advice.

29. Appendix A to the SOP addressed the role of the police in assisting the Tipstaff from the High Court
(Family Division) in executing the various types of civil orders obtained under the Child Abduction Custody
Act 1985 (described further at [41]-[46] below). These orders can only be obtained from a High Court
Judge or a Circuit Judge authorised to sit as a High Court Judge.

30. Appendix B contained a flowchart of the necessary police actions in all cases.

31. I was also provided with the Defendant's Child Abduction Toolkit setting out the necessary actions for
the Investigatory Unit. Although the version I was shown had been created in August 2014, and so after the
events material to this claim, it largely reflected the actions in the SOP. I note that the complaint
investigation refers to a version of the toolkit from 2008.

_Guidance from the National Crime Agency (“the NCA”), June 2019_

32. This guidance post-dated the key events in this case. The NCA itself was formed during 2013.
However guidance of this kind had been provided by the NCA's predecessor, the Serious Organised Crime
Agency (“SOCA”) for many years. Ms Pedreño said that the aspects of the guidance relating to the role of
the police, and those relating to port alerts, have not materially changed.

33. The NCA guidance emphasised the need to ensure that both civil and criminal remedies were
considered to provide an effective response to the risk of abduction. Page 5 is headed **“Fast time**
**actions”. The guidance stated: “It is essential to act quickly in order to locate the child and prevent him her**
from leaving the jurisdiction”.

34. It then set out a list of fast time actions to be considered. These included categorising the case as a
'Crime in Action' notifying the Duty Inspector conducting ANPR checks and taking specialist advice from


-----

for example, the NCA's UK Missing Persons Unit, the NCA's International Crime Bureau and Reunite. It
also referred to using the “Child Rescue Alert” system across public and media channels, circulating the
child as 'missing' and the offender as 'wanted' on the PNC (the Police National Computer) and using
“Emergency Watchlisting” on the Warning Index Control unit with the National Border Targeting Centre.

35. Ms Shalaby said that she has always directed police officers dealing with potential abduction cases to
the SOCA/NCA guidance.

_'International Parental Child Abduction: Prevention Guide for England and Wales', published by Reunite_

36. This guide, which is aimed at parents, is publicly available. The version I was shown was from 2020
but Ms Shalaby explained that the relevant sections about the role of the police have not changed
substantively since 2013.

37. It identifies certain “warning signs” of the risk of child abduction: (i) threats to take the child away; (ii)
talking about another country and a desire to go there; (iii) the potential abducting parent being from a
different country and having family, friends and other contacts in that country; and (iv) the breakdown of the
relationship with the other parent.

38. The section of the guide on “first steps” devotes several pages to actions to be taken in respect of
passports. It explains that a father with parental responsibility, like a mother, can consent to the issuing of a
passport for a child or can object to such a passport being issued. It advises a parent who is concerned
about the risk of abduction to keep the child's passport in a safe place that the potential abductor will not be
able to find or access.

39. The guide gives detailed advice by reference to the action to be taken where there is (i) a “low level
risk or concern about abduction”; (ii) an “increased level of concern but [where it is] not likely that an
abduction will take place in the next 48-72 hours”; or (iii) a concern that an “abduction is very likely and
imminent (in the next 48 hours)”.

_Family Procedure Rules Practice Direction 12F – International Child Abduction_

40. This Practice Direction set out the roles of various agencies in respect of abduction cases. Sections
4.2-4.8 address “Police assistance to prevent removal from England and Wales” and include the following:

“4.2 The police provide the following 24 hour service to prevent the unlawful removal of a child –

(a) they inform the ports directly when there is a real and imminent threat but a child is about to be
removed unlawfully from the country; and

(b) they liaise with Immigration Officers at the ports in an attempt to identify children at risk of removal.

4.3 Where the child is under 16, it is not necessary to obtain a court order before seeking for police
assistance…

4.5 The application for police assistance must be made by the applicant or his legal representative to the
applicant's local police station…

4.6 The police will, if they consider it appropriate, institute the 'port alert' system (otherwise known as an
“all ports warning”) to try and prevent removal from the jurisdiction where the danger of removal is –

(a) real (i.e. not being sought merely by way of insurance); and

(b) imminent (ie. within 24 to 48 hours).”

_Relevant court powers_

41. If the police decline to put in place a port alert, a parent can apply to the court for an order to this
effect. A police ordered port alert will last for 28 days. A court ordered alert can last much longer.

42. The italicised text in the SOP at [27] above and the reference in PD12F at [40] above to port alerts not
being appropriate by way of “insurance” reflect Mostyn J's judgment in A v B _[2021] EWHC 1716 (Fam)._
Th h d li d t d t th t f t l t d b hild' f th i t b h


-----

was not satisfied that there was sufficient evidence of a real and imminent risk that the child would be
removed. One of the reasons for this conclusion was that the only passport that the child had was in the
father's possession: [40]-[41]. He emphasised that the court would not make port alert orders “routinely” or
“in reliance on evidence which amounts to no more than mere assertion or which is otherwise flimsy or
unsubstantiated”. Rather, what was required was proof of a degree of probability “not far short” of the more
likely than not standard, that the child would be removed: [39].

43. There are various other court orders a parent concerned about the risk of child abduction can seek: a
Location Order (an order to locate the child and remove the passport and travel documents from them), a
Collection Order (an order to hand over the child and seize their passports), a Passport Seizure Order (an
order to seize the passports), a Prohibited Steps Order (“PSO”) (which can prevent a parent from removing
the child from the jurisdiction) and/or a Specific Issue Order (which can be used to arrange for a child's
passport to be lodged with an appointed solicitor). Orders can also be backed by a bench warrant ordering
any person with knowledge of that child to give information to the Tipstaff who assists in the execution of
their orders.

44. Ms Pedreño explained that, in this context, applications for such orders are usually made to the court
without notice. The court listing staff are usually very flexible and accommodating when there is a concern
that an order is needed to prevent the wrongful removal of a child from the jurisdiction. Applications for
these orders can be made by telephone and out of hours if need be. While the necessary paperwork takes
around an hour to complete, applications can be made orally if the urgency requires that. Typically, the
orders are made and sealed the same day for service. However, the court routinely gives permission for
solicitors to serve the order before it has been sealed and by email to save time. Copies are then also sent
to the police. Accordingly, these orders can be obtained very quickly, where the same is necessary to
prevent a wrongful removal.

45. The Tipstaff typically attends court when an urgent application of this kind is made. Once an order is
made, the Tipstaff and their team assist in enforcing the orders by, for example, issuing the port alert as
soon as the order is made or taking steps to locate the child and seize their passport. They usually remain
in constant communication with the applicant's solicitors while the child is located.

46. Once relevant orders have been made, the case is listed for an on notice hearing shortly thereafter for
the alleged abductor to advance their case.

**4: The factual background**

_The Claimant, ALK and ROC_

47. The Claimant and ALK met in early 2006 and were married in Brazil in July 2009. ROC, their only
child, was born in 2010. The Claimant felt that soon after ROC was born, ALK started wanting to return to
Brazil. She would regularly tell him she wanted to do this if they separated. The Claimant regularly and
categorically made clear to ALK he did not want ROC to be taken to Brazil and brought up there.

48. During 2013 the Claimant's relationship with ALK was in difficulties and the Claimant feared that the
breakdown of their marriage was imminent. In early 2013 he took possession of ROC's passport because
he feared ALK would take ROC to Brazil without his consent. He concealed it in his own bag. This was
consistent with the advice given in the Reunite guide at [38] above, although it is not suggested that the
Claimant had seen the guide at this point.

49. ALK told police that on 23 September 2013, she started to make plans to leave the Claimant. There
was a further argument on the evening of 24 September 2013.

_25 September 2013_

_(i): ALK's complaint to the police_

50. At around 6.00 am ROC woke up and had a cuddle with the Claimant. ALK was getting ready earlier
than usual but she told the Claimant she had an early work meeting. She had, in fact, located ROC's
passport and later told officers that she packed “as much of their belongings as she could”. The Claimant


-----

later told the complaint investigation that ALK had removed “nearly everything”. ALK kissed the Claimant
goodbye as normal and told him she was taking ROC to his childminder. She left the house.

51. At 8.04 am ALK called the police from her car. She reported that the Claimant had been aggressive
and violent towards her on several occasions. The Claimant denies these allegations and the Defendant
now accepts that they were probably untrue.

52. ALK was taken to the police station with ROC, where her complaint was recorded at 8.28 am. ALK
spoke to DC Wiltshire, an officer in the Community Safety Unit (“CSU”), who was duly appointed officer in
the case (“OIC”). ALK told DC Wiltshire that she was from Brazil and wished to visit her family there “for a
holiday” and to seek their support, but that the Claimant would not agree to that.

53. DC Wiltshire sought advice from DS Hassall, a specialist officer within the CAIT, though apparently not
the local CAIT. DC Wiltshire asked about the rights of a parent to take a child on holiday without the other
parent's consent. DS Hassall referred DC Wiltshire to the CAA (see [24] above, which makes clear that
ALK had no such right). DC Wiltshire's account to the complaint acknowledges that she received advice to
the effect that ALK was not allowed to leave the country with ROC without the Claimant's consent.

_(ii): The Claimant's complaint to the police and his arrest_

54. In the meantime, the Claimant had noticed ROC's passport, clothes, shoes and toys were missing. He
called ROC's childminder and his family and attempted to contact ALK.

55. At 8.48 am the Claimant called 999 to report his concerns that ALK was abducting ROC. The relevant
CAD document records him telling police that he feared ALK was “running off with child”, “taking child to
brazil” and that “she left this morning on way to airport, taken passports and suitcases”. He said she was in
her car and provided the registration details. At 8.51 am he said he believed she was going to “heathrow”.
At 8.52 am he said that ALK had told the childminder that she was not feeling well and would not be
bringing ROC in that day; and that he believed she was going “to sao paulo to her parents home”.

56. At 9.20 am PC Abery and PC Burroughs attended at the Claimant's home to arrest him for offences
arising out of ALK's complaint. PC Abery recorded in his notebook that on opening the door to the officers
the Claimant immediately asked where ROC was. PC Abery told him that he was with police officers and
safe. PC Abery explained the allegations against the Claimant and told him he was under arrest. He
recorded that the Claimant:

“…explained that he is very concerned that his partner will leave the country and go back to Brazil with his
very young son. He went on to state that his sons passport and his partners passport was missing. A large
number of items of clothing for both people had been removed too. [He] genuinely seemed more
concerned about this matter than the fact he had just been arrested”.

57. PC Abery permitted the Claimant to call his mother, his employer and a friend. He noted that the
Claimant's friend was already “on his way over to drive [the Claimant] to the airport as he was that
confident that [ALK] would leave the country and not return”.

_(iii): Ds Hassall's advice and the seizure by consent of ROC's passport_

58. PC Abery escalated the Claimant's concerns to DS Hassall. This caused DS Hassall “immediate
alarm” given DC Wiltshire's earlier contact and the reference to a “holiday”. She was aware that uniformed
colleagues were taking a statement from ALK and that she had ROC with her. DS Hassall explained that
as an experienced member of the CAIT she was well aware of the need for the CAIT and Children's Social
Care (within the relevant local authority) to investigate the threat of abduction jointly; and that the Claimant
was entitled to have the opportunity to seek a “prohibited steps order from the Family Court…to prevent the
child leaving the country”.

59. DS Hassall therefore “immediately sought out” DC Wiltshire and the officers taking the statement from
ALK. DS Hassall advised them that “in the immediate interests of child safeguarding” they “needed” to
“secure the voluntary surrender” of ROC's passport from ALK. This “needed to be done immediately” but
“with extreme compassion” given her allegations of domestic violence DS Hassall also advised them that


-----

“though her husband was in custody he had outlined [a] clear fear of abduction of his child to police & we
had a duty of care to both the child and him”. She told the officers that they should let ALK know that the
passport would be held in the police station safe “and family law court would ultimately decide upon return
and any conditions”.

60. ALK voluntarily handed over ROC's passport and it was duly placed in the police station safe. It
appears she handed over her own passport as well. DS Hassall also directed the uniformed officers to
“advise her husband of passports surrender and right to seek court order to pevent [sic] childs travel”. She
advised DC Wiltshire to appraise the CAIT Detective Inspector and engage with the local CAIT
immediately, so that “investigation into [the] threat of abduction could be initiated and progressed by them”.

_(iv): PC Abery's reassurance to the Claimant about ROC's passport_

61. The Claimant said that shortly after his arrival at the police station at 9.35 am, PC Abery spoke to him
about ROC's passport. He described being in a corridor leading from where the police had parked to the
custody suite. He said that PC Abery went away and then came back to talk to him.

62. In his witness statement the Claimant described PC Abery's words thus: “He…told me they had taken
the passports off [ALK]. He told me the passport would remain in the police's possession for safekeeping
and that I could be reassured there was no way that [ALK] could take [ROC] out of the jurisdiction”. In oral
evidence he said he was told that the passports “had been seized from her and she would not be going
anywhere”.

63. He said his fear that ALK was going to abduct ROC was the only thing on his mind. He said he was
very distressed and confused, but “relieved” when PC Abery told him that the passports were not in ALK's
possession. Under cross-examination he said he had a clear recollection of the conversation. It was
apparent to me that he did. The Claimant's account was entirely consistent with what DS Hassall had
advised the uniformed officers to do; and with what officers later on in the chronology understood had
happened. There was, of course, no evidence from PC Abery to contradict it. I therefore accept the
Claimant's account about where this conversation took place and about what was said.

64. It is right to note that there is a suggestion in DI Brown's report that DC Wiltshire said she retained
ROC's passport later in the day, after she had interviewed the Claimant. However as noted at [21] above,
this was multiple hearsay and unsupported by any witness evidence in the trial. Moreover, even if that was
correct, and the passport was not seized from ROC until after 2.19 pm when the interview concluded, that
makes no material difference to the analysis which follows: the content of the conversation and the
Claimant's reliance on it is more significant than the fact that it may have taken place a few hours after he
recollected.

65. There is no evidence that PC Abery or any other uniformed officer complied with DS Hassall's direction
that the Claimant be informed of his right to seek a court order to prevent ROC's travel.

_(v): Further events during 25 September 2013_

66. At 10.12 am the Claimant's detention was authorised and he was booked into custody.

67. At 10.18 am, further details were taken from ALK about her allegations. ALK apparently repeated in
this conversation that she intended to take ROC to Brazil.

68. It is now known that at 10.53 am ALK called a travel agency.

69. At around 11.00 am, DC Wiltshire visited the Claimant in his cell. She asked whether ALK had his
permission to take their son to Brazil. The Claimant said she did not. DC Wiltshire told ALK she did not
have the Claimant's permission to take ROC to Brazil. ALK confirmed that she understood.

70. Around this time the Claimant spoke to the Duty Solicitor by telephone. Following this, he reiterated his
concern that his son was going to be abducted by reporting this to the Custody Sergeant. The Claimant's
unchallenged evidence was that the officer “had his arms folded” and “just shrugged his shoulders” in


-----

response to the Claimant's concerns. He had a “blasé attitude” towards the Claimant and did not suggest
that he would do anything.

71. From 2.10 pm to 2.19 pm, the Claimant was interviewed by DC Wiltshire. He gave a prepared
statement denying the allegations ALK had made against him, saying that at most he had slammed a door.
He again stressed his concern that ALK wanted to return to her “extended family in Brazil” and had
removed ROC's passport from its “usual place”. He suggested to the officers the possibility that ALK had
made false allegations against him precisely so that she could take ROC to Brazil.

72. At 2.24 pm, a MERLIN report was created by PC Stanford. It recorded that ALK “had always though[t]
about leaving and returning to her home country (Brazil) where her family are but father hid the passports”.
DS Oddy carried out a “pre-assessment check” in relation to ROC and noted that he was “fit and well” and
“happily playing with officers” while his mother gave her statement. DS Oddy recorded that ROC's passport
had been “taken off of mother to prevent her leaving the country” and the plan was that they would be
taken to a hostel. DS Oddy nevertheless recorded that the risk remained “AMBER”. DS Oddy referred the
case to the local authority's Multi-Agency Safeguarding Hub (“MASH”) due to concerns that there was a
risk of “imminently damaging ECM [Every Child Matters] outcomes”.

73. At 7.27 pm the Claimant was charged with two counts of common assault on ALK. He was refused bail
and remanded in custody overnight, to await a hearing in the Magistrates' Court the following morning. The
CRIS recorded that ALK had said she would spend the night at the family home but would allow herself to
be re-housed in a refuge the following day.

_26 September 2013_

_(i): The return of ROC's passport to ALK and the abduction of ROC_

74. According to the CRIS, ALK left the family home with ROC and went to the police station at around
8.00 am. She apparently said she was concerned that the Claimant was going to be released on bail that
day. In fact, it appears she had plans to travel to Brazil later that day.

75. At around 9.08 am the Claimant left the police station with private contractors, Serco. He was
transported to the Magistrates Court for a hearing listed for 10.00 am. It appears that DC Wiltshire attended
at the front desk and spoke to ALK.

76. At 11.18 am DC Wiltshire made an entry on the CRIS, reflecting ALK's attendance at the police
station.

77. ALK declined the offer of a place in a refuge, saying she was staying with friends. It is agreed that DC
Wiltshire sought no further details of the friends or tried to verify their identities.

78. The CRIS continued:

“[ALK] is fully aware of her obligations in regard to her son and…she has been warned by me that to take

[ROC] from the country without [the Claimant's] consent could be construed as child abduction. She was
very tearful and willing to assist in any way and very fearful of contravening any law. She will keep me
updated as to her whereabouts but remained very fearful of [the Claimant] finding where she was. I
explained to her that she should seek legal advice re her marriage, the custody of her son and her wish to
visit her family abroad and she said she would do so”.

79. What the CRIS did not record was that during this attendance at the police station, ALK had asked for
ROC's passport back and the officers had given it to her. This occurred at some point between 8.00 am
and 11.18 am but it is not clear when. Mr Simblet KC contended that it was likely to have been at or around
8.00 am, but there is simply no evidence that this was the case. There is evidence that some advice was
taken about whether to return the passport, and one might think that CRIS entries are written up relatively
contemporaneously, both of which would suggest the return took place later in the timeframe. I simply
cannot say anything other than that it was at some point between 8.00 am and 11.18 am.

80. ALK was apparently asked to confirm in writing that she understood that to take ROC to Brazil would
be a criminal offence


-----

81. The fact of the return of the passports to ALK was not recorded anywhere else on police systems. Nor
did the entry on the CRIS set out what factors had been considered in deciding whether to return ROC's
passport to ALK. No mention was made of any factors that might have reduced the risk of ROC being
unlawfully removed, other than the advice given by DC Wiltshire to ALK. The Defendant admitted that no
formal and documented risk assessment, mandatory under the SOP, was carried out before the decision to
return ROC's passport to ALK was taken.

82. On returning ROC's passport to ALK, the officers did not put in place a port alert or any other
protective measure, nor was the Claimant updated as to what had happened to the passport.

83. That afternoon ALK flew to Brazil with ROC. She has not returned with him since.

_(ii): The release of the Claimant on bail and his efforts to prevent ROC's abduction_

84. At 1.21 pm the Claimant was released on bail from the Magistrates' Court. While driving home, he
began a series of calls to different solicitors. Once home, he discovered a handwritten note from ALK
saying “Sorry but you left me no choice”. He saw from his telephone bill on his mobile phone that ALK had
run up extensive call charges which was out of character for her, and which he attributed to overseas calls.
This concerned him as he thought it evidenced her making plans to go abroad. He also identified that at
10.53 am on the previous day she had talked to a travel agent, Crystal Travel. He made several calls to
seek legal advice, to Reunite, and at 9.46 pm to the police station directly. DC Annor told him about the
note on the CRIS to the effect that ALK had been warned that abducting ROC would be criminal offence.
He was advised to report his concerns in person.

85. At around 11-11.30 pm, Reunite advised the Claimant to go to the police station in person and ask that
a port alert be put in place.

_27 September 2013_

_(i): The Claimant's attendance at the police station_

86. At 00.30 am the Claimant attended the police station to make a formal request for a port alert. At 1.00
am a new report was opened on the CRIS, apparently by PCSO Clarke. According to an entry made at
2.55 am, PCSO Clarke located the earlier MERLIN report about ROC and took advice from a CAIT officer,
who had spoken to a supervisor, DS Mehmet. This was to the effect that they should continue with the
CRIS report and the MERLIN as they “cannot confirm if DS Oddy has removed the passports at this hour
of the day”.

87. The Claimant felt that the officers did not take his concerns seriously. At around 4.00 am he was told
by an officer on reception that it appeared that the passports had been taken from ALK. The words used
indicated that the police still held the passport which was “somewhat a relief” to the Claimant. One officer
said words to the effect of “that is great, I can close this report then” but the other officer seemed unsure.
The Claimant expressed his concern that it now seemed unclear whether the police still had ROC's
passport and said that a port alert was needed. However “the officer was insistent the report did not go any
further and it was left at that”. He was given a crime reference number and went home.

88. At 3.10 am DS Mehmet made an entry on the CRIS referencing the Claimant's attendance at the
police station. The officer noted that the Claimant had failed to inform the police that the “passports were
already taken by police from mother day previously”. DS Mehmet recorded that it was “extremely unlikely
that she has travelled anywhere without passports”. The situation “did not warrant a welfare check as child
is likely to be at hostel placed by police”. Further “[t]he cell data to travel agents does not prove anything at
this stage. It is possible mother tried to cancel any flights she may have had book [sic]. Requested this
matter be CRI'd until further checks are completed as no offences committed at present”. My
understanding is that “CRI” means “Crime Related Incident”, a distinct categorisation to a recording a
crime.

89. It is therefore clear that the officer on reception to whom the Claimant spoke and DS Mehmet were
both under the mistaken impression that the police still had possession of the passports.


-----

_(ii): Further events during the day of 27 September 2013_

90. During the morning, Reunite opened a file in relation to the Claimant, noting that he believed that the
police were in possession of his son's passport.

91. At 9.32 am, DS Oddy made an entry on the CRIS report correcting the mistaken assumption that he
had seized ALK's passport, stating that he could not confirm this and had no knowledge of the same.

92. At 10.45 am, DS Taylor was appointed as OIC to investigate the Claimant's complaint that his son
might be abducted. At 10.21 am, DS Taylor had emailed DS Hassall and DC Wiltshire as follows: “Please
can one of you call me re the above. This man has again reported that he believes his wife will go to Brazil
with his child, cris 5414300/13. Hopefully I can just write it off but just wanted to check a few things.” At
10.50 am DS Taylor made an entry on the CRIS to the effect that she had emailed the CSU “to ascertain if
the passports were seized”. The entry also recorded that there had been “no concerns” on the previous
day that the mother would leave the country.

93. Between 11.27 am and 3.25 pm, the Claimant called Heathrow Airport six times as well as Reunite. He
also made a series of calls to the police station, the Crime Management Unit, the Criminal Investigation
Department and to the police via the '101' number.

94. Shortly before 4.00 pm the Claimant was informed by someone within the Crime Management Unit
that the police no longer had the passports and that they had been returned to ALK. He felt “real despair”
due to “knowing [ALK] would depart as soon as she could with [ROC]”. She had, of course, already left.

95. At 4.07 pm, CAD 6304 was updated as follows: “Caller states he has been contacted by police to say
do not have child passport, caller has been advised to get a port alert. Caller states wife does not have
consent to take child abroad and was currently try to get court paper to prevent this”.

96. During further calls to the police the Claimant again said that ALK did not have his consent to take
ROC out of the country and asked for a port alert to be put in place. He said he was not taken seriously.

97. At 4.12 pm, the CAD was updated further: “…if she was circulated for parental child abduction we will
be advised if she attempts to leave the country, OIC will need to inform National Border Targeting Centre
on [number given] to add her to watchlist”. DS Taylor, the OIC, did not do this.

98. At 4.24 pm it was recorded that “the CSU should have seized the passports – we are making urgent
enquiries with them.”

99. At 4.26 pm, the CAD was updated to the (incorrect) effect that the CSU had seized the passports and
were still in possession of them. Accordingly, the confusion about what had happened with respect to the
passports continued.

100. The Claimant spoke to someone on '101' who said arrangements would be made with the police
station to put in place a port alert. A police officer then called the Claimant back and identified himself as
the person dealing with the case. The officer told the Claimant that “they had visited my wife and that she
was still there” (which was incorrect). The officer said that they had been advised by the child abuse team
that ALK could take ROC out of the country for 28 days. The Claimant said that this was incorrect and
asked the officer to check the law with his senior officer. The officer did not put in place a port alert but
insisted on visiting the Claimant at home.

_(iii): Ms Shalaby's involvement with the officers_

101. At 6.11 pm the Claimant telephoned Reunite's emergency line and spoke to Ms Shalaby. During the
call, two officers arrived at his house. The Claimant recognised one of them as one of the officers who had
arrested him 2 days previously. He put Ms Shalaby on loudspeaker.

102. Ms Shalaby sought to correct the officers' understanding that ALK was permitted to take ROC abroad
for up to 28 days without the Claimant's consent. She explained that the 28 day “rule” only applies when
there is a court order in place relating to the child, which was not the case here. The officers reiterated to
the Claimant that his wife was “still here” (in England) and that “if she wanted to go she could” because she


-----

was not able to contact him (due to his bail conditions) to secure his consent. Ms Shalaby said that this
was “ridiculous”. The Claimant said that this reasoning did not “hold” because he had already made clear
that he did not consent to her leaving with ROC while in custody, and the police had a record to this effect.

103. The Claimant said that the officers spoke over Ms Shalaby in an aggressive manner. He said the
officers were not interested in what he had to say, got angry and left. Ms Shalaby's unchallenged evidence
was that it was “very clear” to her from the contents of the call that the police lacked appropriate knowledge
on child abduction; the officers were “impatient, irritated and dismissive” of her; they “felt they knew best”;
and they “could not be bothered to investigate the issues or what I was saying further”.

104. Between 6.54 pm and 8.23 pm the Claimant and Ms Shalaby both made repeated calls to the police
to obtain an update as to what was happening.

105. Later in the evening DC Wiltshire called Ms Shalaby and stated that ALK had “every right to remove
the child”. Ms Shalaby again tried to correct the position. DC Wiltshire asserted that ALK “couldn't get the
appropriate consent as there was no communication allowed”. Ms Shalaby reiterated that the police were
aware that the Claimant did not consent to ALK taking ROC abroad. DC Wiltshire said that ALK was taking
ROC on a holiday and would return. Ms Shalaby said that around 40% of Reunite's cases are cases of
“wrongful retention” where a parent takes the child on holiday and does not return. DC Wiltshire said she
“didn't deal with statistics”.

106. DC Wiltshire indicated that the Claimant would be prosecuted. She said she had advised ALK that if
she did not return with ROC she could “get into trouble”. Ms Shalaby said that this was irrelevant if ALK did
not have the appropriate consent. She said she thought DC Wiltshire was being biased against the
Claimant which she denied.

107. Ms Shalaby asked if a port alert was in place. DC Wiltshire said she had not effected one; and she
was not sure if her colleagues had. She then said she was busy and put the phone down without saying
goodbye.

108. Ms Shalaby's unchallenged evidence was that during the call DC Wiltshire was dismissive, spoke in a
raised voice and was not interested in exploring what Ms Shalaby had to say. Ms Shalaby said that in 30
years of dealing with police officers she has never been spoken to with the “level of aggression” displayed
by DC Wiltshire.

_28-30 September 2013_

109. 28/29 September 2013 was a weekend. On Monday 30 September 2013, the Claimant applied to
court for a PSO. The application noted that he had “been advised that [ALK] was in a refuge at the
moment”.

110. District Judge Bowles granted the PSO the same day. The order prohibited ALK from removing ROC
from the jurisdiction and required her to surrender his passport It also ordered the police to provide
information about ALK's whereabouts. The Claimant's solicitors informed the police that the PSO was in
place.

_1 October 2013_

111. At 7.32 am, DS Hassall emailed DS Taylor, apparently in response to being told about the PSO,
explaining that the passports had been returned to ALK on the advice of other officers.

112. At 12.31 pm DC Wiltshire called ALK and heard an international dialling tone. She did not get
through. ALK returned the call a few minutes later. DC Wiltshire updated the CRIS report to this effect:
“I...asked her where she was - she replied she was with her family in Brazil, I asked when she was
intending to return, and she informed me when she was needed…I firmly directed her to return to the UK to
have the situation sorted out at the family court”.

113. At 6.48 pm, DS Taylor noted on the CRIS that the Claimant “does not know at this stage that the
mother has left the country”.


-----

114. The Claimant was not told that the officers had made contact with ALK and that she was in Brazil with
ROC.

_2 October 2013 and events thereafter_

115. At 10.17 am on 2 October 2013, DS Taylor called ALK. ALK confirmed she would not return to the
jurisdiction unless obliged to.

116. In the early evening of 3 October 2013, ALK called the Claimant. He ended the call for fear of
breaching his bail conditions and informed DS Taylor of the call.

117. On around 4 October 2013, the Claimant called Reunite again, saying he was “now really scared” as
he was “pretty sure [ALK] had gone”. He said he felt that the police were “stalling”.

118. On 10 October 2013, a further hearing in the family proceedings took place, at which the police
confirmed to the Claimant that ALK was no longer in England.

119. The Crown Prosecution Service later charged ALK with child abduction.

120. On 21 October 2013 the Claimant commenced proceedings under the Hague Convention.

121. On 31 October 2013 ALK informed DC Linahan that she would not be returning to the UK for any
criminal trial in relation to the allegations of assault she had made against the Claimant.

122. Brazil is, and was known at the time of these events to be, a country that does not comply with the
Hague Convention, meaning that ROC effectively now lives in Brazil. If requested, Reunite would have
provided the officers with information about Brazil's lack of compliance with the Hague Convention. Ms
Pedreño also explained that basic research would have told the officers that there is no extradition treaty in
place with Brazil.

123. The Claimant has had very little contact with ROC since 26 September 2013, despite the extensive
legal proceedings in which he has been involved.

**5: The Wisniewski issue**

_The relevant legal principles_

124. _Wisniewski_ was a clinical negligence case in which a key doctor had moved to Australia. The trial
judge held that the Defendant had advanced no legitimate reason for not ensuring the doctor's return to
England to give evidence at trial or for having his evidence taken by other means. The judge observed that
the Defendant was entitled to take this approach “for tactical reasons” but could not thereafter complain if
he drew the inference against the Defendant that the doctor's failure to attend was because “he had no
answer to the criticism made”: pp.330 and 331.

125. Brooke LJ, with whom the Roch and Aldous LJJ agreed, upheld the judge's approach, noting at p.343
that there had also been a “deafening silence” from the other members of the relevant medical team at the
hospital. In so doing, at p.338 he derived the following principles from the authorities:

“(1) In certain circumstances a court may be entitled to draw adverse inferences from the absence or
silence of a witness who might be expected to have material evidence to give on an issue in an action.

(2) If a court is willing to draw such inferences they may go to strengthen the evidence adduced on that
issue by the other party or to weaken the evidence, if any, adduced by the party who might reasonably
have been expected to call the witness.

(3) There must, however, have been some evidence, however weak, adduced by the former on the matter
in question before the court is entitled to draw the desired inference: in other words, there must be a case
to answer on that issue.

(4) If the reason for the witness's absence or silence satisfies the court then no such adverse inference
may be drawn. If, on the other hand, there is some credible explanation given, even if it is not wholly
satisfactory the potentially detrimental effect of his/her absence or silence may be reduced or nullified”


-----

126. In Royal Mail Group v Efobi _[2021] UKSC 33, [2021] 1 WLR 3863 at [41], Lord Leggatt JSC described_
Brooke LJ's observations in _Wisniewski as “sensible statements”, but observed that there was a “risk of_
making overly legal and technical what really is or ought to be just a matter of ordinary rationality”. He
considered that whether any positive significance should be attached to the fact that a person has not
given evidence “depends entirely on the context and particular circumstances”. Further:

“Relevant considerations will include such matters as whether the witness was available to give evidence,
what relevant evidence it is reasonable to expect that the witness would have been able to give, what other
relevant evidence there was bearing on the point(s) on which the witness could potentially have given
relevant evidence, and the significance of those points in the context of the case as a whole”.

127. Leggatt J (as he then was) had addressed the difficulties with the memories of witnesses in Gestmin
_v Credit Suisse_ _[2013] EWHC 3560 (Comm) at [22], holding as follows:_

“…the best approach for a judge to adopt in the trial of a commercial case is, in my view, to place little if
any reliance at all on witnesses' recollections of what was said in meetings and conversations, and to base
factual findings on inferences drawn from the documentary evidence and known or probable facts. This
does not mean that oral testimony serves no useful purpose – though its utility is often disproportionate to
its length. But its value lies largely, as I see it, in the opportunity which cross-examination affords to
subject the documentary record to critical scrutiny and to gauge the personality, motivations and working
practices of a witness, rather than in testimony of what the witness recalls of particular conversations and
events. Above all, it is important to avoid the fallacy of supposing that, because a witness has confidence
in his or her recollection and is honest, evidence based on that recollection provides any reliable guide to
the truth”.

128. In _Kimathi v Foreign and Commonwealth Office_ _[2018] EWHC 2066 (QB) at [95]-[96], Stewart J_
distilled the relevant principles from _Gestmin and other cases addressing the approach to witness_
evidence. These included Mostyn J's recognition in _Lachaux v Lachaux [2017] 4 WLR 57of the “utmost_
importance” of contemporary documents; and his observations in _Carmarthenshire County Council v Y_

_[2017] EWFC 36; [2017] 4 WLR 136to the effect that while oral evidence given under cross-examination is_
generally “considered the “gold standard” as “the best way of assessing the reliability of evidence is by
confronting the witness”, it is “far from the be all and end all of forensic proof”.

_PS White's statement_

129. The Defendant contended that no Wisniewski inference should be drawn against him. To support this
argument, he sought to rely on an MG11 (a police witness statement) from PS Joe White in his Department
of Professional Standards dated 19 August 2020. The primary purpose of this MG11 was to respond to a
series of entirely proper requests for disclosure that had been made by the Claimant's solicitor.

130. The Claimant applied to have PS White's MG11 excluded from the trial under CPR PD 32 due to the
procedural defects in it: it did not distinguish between statements that were from the officer's own
knowledge and those that were matters of information and belief; and it did not contain the necessary
statement of truth, contrary to PD 32, paras. 18.2 and 20. These requirements in the CPR are important, as
was recently emphasised by Chief Master Marsh in Punjab National Bank v Techtrek India _[2020] EWHC_
_539 (Ch) at [20] and MF Tel Sarl v Visa Europe Ltd [2023] EWHC 1336 at [8]._

131. There were a series of concerning gaps in the disclosure in this case that called for proper
explanation. The Defendant was also relying on PS White's evidence on a substantive point in the trial,
namely the _Wisniewski issue. In those circumstances a CPR compliant statement should have been_
obtained from PS White. The officer should also have been called to give evidence at trial, because the
court had not ordered otherwise, nor had the Defendant served a hearsay notice in relation to the officer's
statement, in breach of CPR 32.5(1)(b).

132. However, (i) PS White did, to some degree, identify the sources of the evidence, setting out who had
been contacted in order to prepare it, and with what result, in the MG11; (ii) the MG11 contained a
declaration of truth on pain of a criminal prosecution for perjury which is comparable to (indeed arguably


-----

more serious than) the statement of truth prescribed by the CPR; and (iii) any CPR-compliant witness
statement from PS White would be likely to have simply exhibited the MG11.

133. I therefore concluded that it would not be consistent with the overriding objective to exclude PS
White's statement from consideration entirely, albeit that the procedural defects in it would potentially be
relevant to the weight to be attached to it: see, for example, Punjab National Bank at [20], where the Chief
Master held that “[a] failure to identify the source in a manner that complies with paragraph 18.2 will mean
the court has to consider whether to place any weight on the evidence, especially where it touches on the
central issue”. Moreover, the practical consequence of the fact that PS White was not called to give
evidence at trial meant that certain gaps in his evidence in the MG11 remained unaddressed.

134. PS White's MG11 is the source of the information about the failure to preserve the officers' accounts
to the complaint investigation and the deletion of officers' email accounts set out at [18]-[19] above. He
contacted DS Hassall (who provided the documents she had), DS (by then DI) Taylor (who had not
retained any documentation and only recalled one conversation by telephone) and DS Hicks (who had not
retained any documentation and said that the advice provided by telephone would have been recorded on
the CRIS). There was no suggestion PS White had spoken to any other officer.

_Whether a Wisniewski inference should be drawn in this case_

135. The central factual issue in this case was why the decision had been taken to return ROC's passport
to ALK, when she was saying she intended to take him to Brazil, and when it was known that the Claimant
did not consent to this, without taking any other protective measures such as putting in place a port alert or
telling the Claimant about the return of the passport to ALK.

136. In my judgment all seven of the officers who gave accounts to the complaint investigation, DI Brown,
the officers in the custody suite and the others who made the key entries on the CRIS cited above were all
witnesses “who might be expected to have material evidence to give” in the trial, adopting the words of
Brooke LJ's Wisniewski principle (1).

137. The Claimant's evidence, including that from Ms Shalaby and the expert evidence from Ms Pedreño
provided a clear basis for the Claimant's case that the officers' actions were in breach of Article 8 and
negligent: they advanced a “case to answer” for the Defendant and thus satisfied Brooke LJ's Wisniewski
principle (3). On that basis it is necessary to consider the “reason for the…absence” from the trial of these
witnesses, under his principle (4).

138. Mr Clemens explained that the Defendant had taken a deliberate decision not to obtain witness
evidence from any of the officers. This was because, given the passage of time, it could safely be inferred
that their recollection of events in 2013 would “probably be impaired”, such that their evidence would “add
nothing” and be “meaningless” to the trial.

139. I cannot accept that such a wide-ranging and blanket inference should be drawn.

140. Experience dictates that witnesses can, in some cases, have a good recollection of past events,
especially perhaps when, as here, the facts are rather unusual and where detailed contemporaneous
documents as to what happened do exist. DS Taylor clearly had some recollection of one part of the
events, as PS White's statement made clear. Other officers may have done so had they been able to look
at the relevant documents such as the CRIS. PS White's statement did not provide an evidential basis for
the assertion that none of the officers would be able to recollect matters: he only spoke to some of the
officers and the focus of those discussions was what documents they could provide. None of the officers
had given sworn statements to the effect that they could not remember anything material. For these
reasons I do not consider that it can simply be assumed that the officers would not be able to remember
pertinent details of what happened.

141. Moreover, Leggatt J made clear in Gestmin that oral evidence can serve another important purpose,
namely “the opportunity which cross-examination affords to subject the documentary record to critical
scrutiny and to gauge the personality, motivations and working practices of a witness”. This applied here,


-----

given that there had apparently been significant departures from the Defendant's expected “working
practices” (as evidenced through the SOP and other guidance).

142. As to the other relevant matters referred to by Lord Leggatt in Efobi:

(i) There was no suggestion that the witnesses were not available. Of those who gave accounts to the
complaint investigation it appears they are all still serving save for three, and it is a reasonable inference
that they are receiving a police pension and could be located;

(ii) Given their involvement in the material events it is reasonable to expect that the witnesses would have
been able to give evidence in either of the categories noted at [139] and [140] above;

(iii) The “other relevant evidence bearing on the point(s) on which the witness could potentially have given
relevant evidence” – namely why the key decisions were made - was very limited: see [16] above; and

(iv) This “why” question had a heavy “significance...in the context of the case as a whole”: it was the most
significant issue.

143. I therefore do not find the Defendant's explanation for not calling any witness evidence credible. The
case is very similar to _Wisniewski in that there was a “deafening silence” in the case put forward by the_
Defendant. In fact, the position was more stark than in Wisniewski because at least in that case, the doctor
had provided a signed witness statement addressing the material issues (albeit that he could not be tested
on it in cross-examination), whereas that did not apply to any of the officers here.

144. In light of all the factors above I infer that the reason the Defendant did not call any evidence was that
he considered that they “had no answer to the criticism made”, as in _Wisniewski. This inference could_
properly have been used to add to the case advanced by the Claimant in accordance with the approach
described in _Wisniewski and_ _Efobi. In fact, as will become apparent, it was not necessary to do so, as I_
have found the Claimant's case proved based on the evidence that was available. By definition this
included no witness evidence from the Defendant, but that was his choice.

**6: The passport retention issue**

_The development of this issue in the litigation_

145. The Particulars of Claim made clear that the Claimant's case was that ROC's passport should not
have been returned to ALK. A key part of the Defence was the proposition that, to the contrary, the officers
had no legal power to retain ROC's passport once ALK requested it back. However the Defendant failed to
set out in his Defence any reasons for denying the Claimant's case on this issue, in breach of CPR
16.5(2)(a).

146. Matters were then complicated by the fact that the Claimant's expert, Ms Pedreño, agreed with the
Defendant's legal analysis. The Defendant assumed that in light of this evidence the Claimant would
concede the issue, but he did not.

147. Neither party addressed the passport retention issue in their skeleton arguments for trial. They each
appeared to have commenced the trial with a fundamental misunderstanding of the others' position on this
potentially significant issue, and each thinking that the other had no answer to their own position. Ms
Pedreño was asked very limited questions on this issue. It was not until closing submissions that the
Claimant's counsel contended that her evidence on this issue was inadmissible.

148. It therefore became necessary to permit both parties to file fairly extensive further written
submissions on this issue after the trial. The Defendant initially contended that the Claimant was not
entitled to advance this point at such a late stage, but eventually accepted that not only was the Claimant
so entitled, but that the Defendant bore the burden of proof on the issue, as it was part of his Defence.

149. It was unfortunate that this issue was not been fully tested in oral submissions in the usual way.
However I considered it disproportionate to direct a further hearing to consider it, not least because this
issue was not determinative of the Claimant's claims: see, for example, [249] below, which makes clear
that the Claimant's claims succeed even if the return of the passport was lawful


-----

_The Defendant's evidence on this issue_

150. There was no contemporaneous document identifying the officer(s) who had concluded that there
was no legal power to retain ROC's passport. The evidence is inconsistent as to who had reached this
conclusion. Although DI Johnson appeared to accept responsibility for the decision in the complaint
investigation, there are various references to DC Wiltshire, DS Taylor, DI Brown and potentially another
CAIT officer being involved.

151. None of the contemporaneous evidence sets out a rationale for the conclusion as to the legal powers
available to the police.

_Ms Pedreño's evidence on this issue_

152. Ms Pedreño gave unequivocal evidence of her understanding that if a relevant court order is not in
place, and a person requests the return of a passport, the police have no power to keep it: she said this in
her main report, her Part 35 answers and in oral evidence.

153. In closing submissions, Mr Simblet KC contended that Ms Pedreño was not an expert on police
powers as such, but was a solicitor giving evidence about practice in child abduction cases. On a
superficial level this submission did not sit well with the fact that she had been specifically instructed by the
Claimant's solicitor to prepare an expert report addressing “child abduction, police powers and protocols”,
which she had done, and had not expressed any reservations about doing so.

154. That said, the extent of Ms Pedreño's evidence on this issue was the brief statement of her
understanding as set out at [152] above. She did not give any reasons for her view. She was not and did
not hold herself out to be an expert on the detail of police powers in respect of property, nor did she give
any reasons for her view. Indeed, she said in cross-examination that she had no experience of the police
taking possession of a passport rather than a court ordering it to be surrendered. In any event, the parties
agreed that resolution of an issue of English law such as this is a matter for the court.

155. Ms Pedreño is an expert in the practice of child abduction cases, and this includes her experience of
seeing police powers exercised in that context. Her own practice is clearly informed by her understanding
of the legal position: in cross-examination, she said “we know the police cannot keep these passports” and
“we know the passports can be released at any time”. This is why she and her colleagues advise parents
to obtain court orders on an urgent basis.

156. For these reasons I conclude that it would be artificial and inappropriate to regard Ms Pedreño's
evidence on this issue as entirely inadmissible, as Mr Simblet KC contended. However, it cannot be
determinative as Mr Clemens argued, in light of the role of the court on issues of law.

_The initial seizure of the passport from ALK_

157. DS Hassall had advised the uniformed officers that they “needed” to “secure the voluntary surrender”
of ROC's passport from ALK. She separately said that she had “directed the seizure of passport on
voluntary consent”. The CRIS records that the passport had been “taken off” ALK.

158. Although this language could be said to imply that if ALK had not handed over the passport
voluntarily, officers would have seized it from her, they did not need to exercise any police powers at this
point: ALK was co-operative and consented to the officers taking possession of ROC's passport.

159. The Defendant relied on the fact that consent is a defence to a claim in trespass to property: Clerk &
Lindsell on Torts at 16-52. The Claimant did not contend that the Defendant had done anything unlawful at
this stage.

_The retention of the passport after ALK sought its return_

160. The Defendant's position was that once ALK sought the return of the passport, the officers had no
power to retain it. In my judgment there were a number of difficulties with this proposition.


-----

161. First, ALK was not the sole owner of the passport. Rather, the Claimant had an equal right to it: this
much was clear from Ms Pedreño's evidence and the Reunite guidance at [38] above. On that basis, the
Defendant would need to prove that ALK's request for the return of ROC's passport, for the express
purpose of taking ROC out of the country against the Claimant's wishes, and in breach of the law, should
prevail over his right to the passport. The Defendant could point to no reason why this should be the case.

162. Second, just as the Defendant justified the initial seizure of the passport on the basis that if the issue
were ever litigated he would be able to rely on the consent defence, so too could he rely on the ex turpi
_causa defence to justify its retention, on grounds of public policy. This was because there were reasonable_
grounds for believing that to return the passport to ALK would mean it would be used for the criminal
purpose of abducting ROC.

163. In Merseyside Police v Owens _[2012] EWHC 1515 (Admin) at [28], the Divisional Court accepted that_
whether a claim for the return of an item is brought in a civil court or in the Magistrates Court under the
Police Property Act 1897, s.1, the court can refuse to order the item's return if on the facts it can be
established that the return of property would indirectly encourage or assist a person in his criminal act.

164. The Defendant argued that the evidence did not justify the conclusion that to return ROC's passport
to ALK “would” indirectly encourage or assist her in abducting ROC, only that it “might”, which was
insufficient, per _Owens_ at [29]. This was because the CRIS showed that the officers had been justifiably
reassured by ALK's acknowledgement that taking ROC out of the jurisdiction would be a crime; and had
said that she was fearful of committing any such crime.

165. I cannot accept that any such reassurance was justified. Police systems had recorded that ALK had
not only left the house with her son and his passport, but also with suitcases packed with clothing. It was
well known that the Claimant did not agree to her taking the child abroad. She had returned to the police
station just the day after voluntarily handing over the passport seeking its return. She was saying in terms
that she was planning on leaving the country with ROC.

166. Unsurprisingly, Ms Shalaby pointed out that it was “very rare” and “quite unique” in her experience for
the potential abductor to actually tell police that they plan to take the child out of the country. She said it
was “irrelevant” for the police to be having a conversation with ALK about how taking the child might be a
criminal act: rather they “could and should have done something to prevent it”. Ms Pedreño was similarly
unwilling to agree that the officers were justifiably reassured at this point.

167. In all those circumstances the fact that ALK had said, effectively, that she knew it would be an
offence to leave the country can only reasonably have been given very limited weight. It amounted to no
more than a member of the public telling the police that they would not commit a crime and the police
accepting such an assertion at face value.

168. In my judgment given the obvious preparatory steps ALK had taken and the importance of the
passport to her ability to take ROC out of the country, a civil court would be likely to conclude that ROC's
passport should not be returned to her because to do so “would” (not just “might”) indirectly encourage or
assist her in committing the criminal offence of child abduction. This underscores the argument that the ex
_turpi causa defence would have been available to the Defendant and justified the retention of ROC's_
passport.

169. Third, I note that the initial securing of the passport was justified by DS Hassall by reference to the
[need to safeguard ROC. This was likely a reference to the duty on chief officers of police in the Children](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y0C0-00000-00&context=1519360)
_[Act 2004, s.11, to “make arrangements for ensuring that their functions are discharged having regard to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y0C0-00000-00&context=1519360)_
need to safeguard and promote the welfare of children”. The Hague Convention has a “preventive aspect”
as well as making provision for orders to return a child after an abduction has taken place: _X v Latvia_
(2014) 59 EHRR 3 at [35]. The evidence shows that in the specific context of child abduction, it is wellrecognised that “prevention is better than cure”, i.e. that it is better to prevent child abduction happening
than to try and remedy the situation once it has happened. Ms Shalaby said that in situations where there
is a risk of abduction, the police are the “first line of defence”. More generally, a core duty of police officers
is the prevention of crime as well as its detection.


-----

170. These principles reinforce my view that the ex turpi causa defence would have been available to the
officers in this case to justify their continued retention of the passport pending resolution in the family
proceedings. Although neither party addressed this issue, it might even be that these principles generate a
free-standing power to retain a child's passport in scenarios such as this, irrespective of the existence of
the ex turpi causa defence.

171. Fourth, if the Claimant's complaint about potential abduction had been responded to properly through
prompt investigation, the officers could have availed themselves of statutory powers of seizure and
retention.

[172. Most obviously, the Police and Criminal Evidence Act 1984 (“PACE”), s.19(3) permits the seizure of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0Y0-TWPY-Y0VH-00000-00&context=1519360)
an item where there are reasonable grounds for believing that it is “evidence in relation to an offence which

[the officer] is investigating or any other offence”, where it is “necessary to seize it in order to prevent it
being concealed, lost, damaged, altered or destroyed”.

173. The Defendant argued that ALK was not committing an offence because she went to the police
station and not the airport. However the two acts were not inconsistent. ALK had ROC, the passports,
suitcases and clothes with her when she attended the police station on the first occasion, and potentially
also on the second. Moreover, the MERLIN report records her saying on the first occasion that she had
“found the passports today but rather than just leaving [she] wanted to report all [the] incidents to the
police”. This makes clear that she was reporting the allegations while also intending to leave. Ms Pedreño
explained that very often, allegations of violence are made in child abduction cases; and indeed that they
can be made on a “strategic” basis, before removing a child, to improve the parent's prospects of not being
required to return. It is a reasonable inference that if DS Hassall had not directed the officers to obtain
ROC's passport from ALK on 25 September 2013, she would have left the country that day.

174. In my judgment the more realistic assessment of the evidence is that ALK's actions provided
reasonable grounds for believing that she was in the process of committing the offence of child abduction,
or attempting to do so (on the basis that her acts were “more than merely preparatory to the commission of
the offence” under the Criminal Attempts Act, s.1(1)). This was surely a 'Crime in Action' of the sort
envisaged by the NCA guidance: see [34] above.

175. The Defendant sought to rely on the fact that his officers were not in fact investigating any offence at
the time the passport was returned to ALK. An officer was not appointed to investigate the Claimant's
complaint about child abduction until 10.45 am on 27 September 2013. However, given the obvious
urgency of what the Claimant was reporting, the officers should have opened an investigation much earlier,
when DS Hassall advised them to do so shortly after the Claimant's call at 8.48 am of 25 September 2013:

[60] above. The Defendant cannot properly rely on his officers' culpable delay in investigating the
Claimant's complaint to deny the availability of the s.19(3) power.

176. As to the final element of s.19(3), it seems to me at least arguable that as the Claimant had an equal
right to the passport as ALK (see [160] above), seizure of it was justified to avoid it being “lost” to him in the
sense of being taken out of the jurisdiction of England.

177. For these reasons had the Defendant's officers properly conducted an investigation into the
Claimant's concerns, they could have relied on the s.19(3) power to retain the passport notwithstanding
ALK's withdrawal of consent.

178. Alternatively, although neither party addressed this, had the officers arrested ALK for attempted child
abduction (and it seems to me at least arguable that they had reasonable ground to do so), the power
under PACE, s.18(2) to seize and retain any item that “relates to” that offence or “some other indictable
offence which is connected with or similar to that offence” would have been available.

179. Fifth, I do not accept the Defendant's submission that the existence of the powers in family law
proceedings to make orders in respect of passports shows that the police have no general power to retain
a passport in these circumstances. Parliament routinely provides for civil and criminal remedies addressing
the same issue: examples include the civil and criminal regimes addressing harassment, gang behaviour


-----

and **_modern slavery. The powers of the police in their criminal jurisdiction and the ability of the family_**
courts to make parallel orders in their civil jurisdiction in the child abduction context are no different.

_Conclusion on the passport retention issue_

180. I therefore conclude that the officers could have justified the ongoing retention of ROC's passport on
the basis that the Claimant had as good a right to the passport as ALK and/or in the knowledge that the ex
_turpi causa defence would be available to the officers (especially because of the various positive_
safeguarding and preventative duties on police officers) and/or because the criteria in s.19(3) were met.

**7: The HRA claim**

181. Under the HRA, s.6(1) it is unlawful for a public authority such as the Defendant to act in a way which
is incompatible with a Convention right.

182. Article 8 provides for the right to respect for private and family life as follows:

“1. Everyone has the right to respect for his private and family life, his home and his correspondence.

2. There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security,
public safety or the economic wellbeing of the country, for the prevention of disorder or crime, for the
protection of health or morals, or for the protection of the rights and freedoms of others.”

183. Article 8 does not merely compel the State to abstain from arbitrary interference with private or family
life but involves “positive obligations inherent in effective respect for private or family life”, requiring
consideration of “whether the national authorities took the necessary steps to ensure effective protection of
the applicants' right to respect for their private and family life as guaranteed by Article 8”: _Guerra and_
_others v. Italy (1998) 26 EHRR 357 at [58], citing the Airey v Ireland, Judgment of 9 October 1979, Series_
A no. 32, p. 17 at [32].

184. A positive obligation on the State in the context of Article 8 often has two aspects: “(1) to require the
introduction of a legislative or administrative scheme to protect the right to respect for private and family
life: and (2) to require the scheme to be operated competently so as to achieve its aim”: _Anufrijeva v_
_London Borough of Southwark [2003] EWCA Civ 1406; [2004] QB 1124 at [16], per Lord Woolf MR, giving_
the judgment of the Court of Appeal.

185. Whether the negative or positive obligation is in issue, regard must be had to “the fair balance that
has to be struck between the competing interests of the individual and of the community as a whole; and in
both contexts the State enjoys a certain margin of appreciation”: Iglesias Gil and AUI v Spain (2005) 40
EHRR at [48].

**7.1: Were the positive obligations under Article 8 engaged on the facts of this case?**

186. It is well established in case law from the European Court of Human Rights (“the ECtHR”) that (i) the
relationship between a parent and child comes within the sphere of family life under Article 8: Iglesias Gil at

[47]; and (ii) the essential ingredient of family life is the right to live together so that family relationships can
develop normally: Marckx v Belgium (1979-80) 2 EHRR 330 [31].

187. The Defendant submitted that the primary interference with the Claimant's family life had been
caused by the conduct of ALK and not that of the police officers, such that Article 8 was not engaged.
However, the positive obligations on a public authority can apply “even in the sphere of relations between
individuals”: Anufrijeva at [16], quoting Glaser v United Kingdom (2001) 33 EHRR I at [63].

188. I am therefore satisfied that the positive obligations under Article 8 were engaged on the facts of this
case.


-----

189. In Article 8 cases involving child abduction, the Article 8 obligations will be interpreted in light of the
Hague Convention: _Iglesias Gil at [51]. This includes its “preventive aspect”: see [169] above. The_
“decisive issue” for the court in such cases is:

“…whether the fair balance that must exist between the competing interests at stake – those of the child, of
the two parents, and of public order – has been struck, within the margin of appreciation afforded to States
in such matters…taking into account, however, that the best interests of the child must be of primary
consideration and that the objectives of prevention and immediate return correspond to a specific
conception of “the best interests of the child”: X at [95].

**7.2: Did the actions of the Defendant amount to a violation of Article 8?**

**7.2.1: The officers' assessment of the level of risk of abduction**

190. In Anufrijeva at [45], the Court of Appeal held that before maladministration by way of “inaction” can
amount to a lack of respect for private and family life under Article 8 “there must be some ground for
criticising the failure to act. There must be an element of culpability. At the very least there must be
knowledge that the claimant's private and family life were at risk.”

191. The Defendant's SOP had been circulated by a notice dated 28 January 2009, and so had been in
force for over four years at the time of these events. The Defendant's officers were, or should have been,
aware of its provisions; likewise the guidance available from the SOCA/NCA.

192. Mr Simblet KC accurately described the SOP as illustrating that at the material time (i) the problem of
child abduction and police powers to intervene and prevent or mitigate its consequences were well-known;
(ii) the Defendant had a clear and well-defined procedure for both preventative and investigative scenarios,
addressed to all officers; and (iii) there was a clear understanding of what should be done where there was
a “real and imminent” threat of abduction, including immediate steps to create missing person's reports, put
in place port alerts and set up an investigation. Moreover, following the SOP did not require specialist
knowledge or other expert exercise: he rightly submitted that the SOP set out “basic expectations that an
officer exercising reasonable skill and care can and should have followed”. I note that PC Abery and PC
Burroughs both told the complaint investigation that they were unaware of the existence of the SOP and
had received no training on the issue of child abduction.

193. The SOP emphasised that the “key” to police action was whether the threat of abduction was
believed to be “real and imminent”. The central contention advanced by the Defendant was that at the time
ROC's passport was returned to ALK, there was a risk that she would abduct him, but this was not a real
and imminent risk.

194. The Defendant's position that the officers had reached a reasonable and informed assessment of the
risk was unsupported by any contemporaneous evidence. It was admitted that no formal and documented
risk assessment, mandatory under the SOP, was carried out before the decision to return ROC's passport
to ALK was taken. It was also unsupported by any witness evidence.

195. The most direct witness evidence the Defendant was able to rely on was the multiple hearsay
evidence of DI Brown's summary of DC Wiltshire's account to the complaint investigation. He said that she
had said she had rationalised the return of the passport with the following “facts”: “[ALK] was fleeing
domestic violence; there were no welfare concerns in relation to [ROC] and no evidence that [ALK] would
flee the country. [ALK] had engaged with police, jointly owned the marital home, she was employed with
friends locally”.

196. Even if DI Brown's summary is accurate, the factors set out therein which purport to justify the return
of the passport to ALK do not stand up to scrutiny. It was not a “fact” that ALK was “fleeing domestic
violence”: rather, she had reported an allegation of assault. It cannot properly be said that “there were no
welfare concerns in relation to [ROC]”: the Claimant had specifically and repeatedly warned that ALK would
abduct him to Brazil, which would foreseeably lead to separation from his father and thus place his welfare
at risk. It is unsustainable to say that there was “no evidence that [ALK] would flee the country”: she had
said, in fact, that she intended to do so. While she had engaged with police and may well have jointly


-----

owned the marital home as well as worked in England (although the Claimant disputed this), she also had
strong links to Brazil, and they were the focus of what she was saying.

197. I do not accept that the officers could properly have been reassured by ALK's indications that she
understood that to abduct ROC would be a crime, for the reasons given at [163]-[166] above.

198. In my judgment all of the factors set out in the SOP as indicating the level of risk (see [25] above)
illustrated that on the morning of 26 September 2013, just before the return of the passports to ALK, the
risk of her abducting ROC was indeed real and imminent:

(i) ALK had clearly taken several “preparatory steps” including locating ROC's passport and packing their
suitcases with clothes.

(ii) She had “recently” made “threats of removal” including directly to the police, just before the passports
were returned to her.

(iii) The Claimant had called the police on 25 September 2013 to report concerns that ALK would abduct
ROC and had repeatedly emphasised this to officers while in custody. ALK had returned to the police
station the following day, a day after making the assault allegation, apparently for the specific purpose of
retrieving the passports. She was saying she intended to go to Brazil with ROC. She had suitcases and
clothes with her. The officers knew that the Claimant did not agree to this. There was, or should have been,
a sense of urgency. For these reasons, it should have been obvious to the officers that it was “likely” that
she would try and remove ROC “within the next 24 to 48 hours”.

(iv) ALK had “unsupervised access” to ROC. It is not clear where ROC was at the precise moment the
passports were returned to ALK, but it appears that he was with ALK. He was certainly not with the
Claimant who was at the Magistrates Court. ALK also had established “links abroad” in the form of her
family in Brazil.

199. Ms Pedreño said that there were “ample indicators” of a real and imminent risk when ALK sought the
return of the passport. The fact that ALK was talking about returning to her home country where she had
connections was a “real red flag”. The officers should also have been concerned that she had not provided
them with an address (albeit that it was understandable that she might not have wanted the Claimant to
have it). I agree with her that these additional points also pointed to a real and imminent risk of abduction.

200. I therefore find that at the time ROC's passport was returned to ALK the risk of abduction was real
and imminent. Accordingly, in the words of _Anufrijeva at [45], the Defendant's officers knew or ought to_
have known that the Claimant's “private and family life were at risk” by ALK abducting ROC and taking him
to Brazil.

**7.2.2: The officers' actions**

201. The Claimant's case was that the Defendant violated his Article 8 rights generally by not acting in
accordance with SOP and by not taking reasonable steps to address the risk that ROC would be abducted.
At [90] of his Particulars of Claim he set out 24 specific alleged failings by the police, as set out below.

**_(a) The Defendant did not adequately gather or record information_**

**_(b) The Defendant did not create an entry on its “MERLIN” system or open a “CRIS”_**
**_report_**

**_(c) The Defendant's officers did not gather the details set out in its Child Abduction SOP_**
**_under the heading of “Information to obtain from the complainant in all cases” or clearly document the_**
**_answers_**

**_(d) The Defendant did not record sufficiently or at all the actions and decisions taken_**
**_within the body of the CRIS report, including their rationale_**


-----

**_(e) The Defendant failed to adequately or at all gather relevant information about the risk_**
**_of child abduction and failed to record that information which it did gather_**

**_(f) The Defendant's officers failed to document, adequately or at all, its decisions and_**
**_risk assessments_**

**_(g) The failure to gather information sufficient information meant that the none of the_**
**_Defendant's officers carried out adequately informed assessment of risk._**

202. The contemporaneous evidence makes clear that the officers did not do any of the things listed
above in response to the Claimant's complaint of child abduction, as made during his call to police, during
his arrest with PC Abery, while in the custody suite or in the prepared statement he provided DC Wiltshire
during the interview on 25 September 2013. His complaint of child abduction was not recorded or
responded to in accordance with the SOP. Most notably the risk assessment mandated by the SOP was
not conducted and recorded, and the key decision to return ROC's passport to ALK was not documented
(which no doubt led to the confusion among the officers during 27 September 2013 as to where the
passport was).

203. The Defence at [7.6] did not deny these alleged failings. Rather, it was said that they were merely
failings with respect to documentation and were not causative. I cannot accept that: these failings
contributed directly to the officers' flawed assessment that there was not a real and imminent risk of
abduction. An accurate assessment that there was such a risk would have mandated different steps under
the SOP. I therefore find the failings identified at [90](a)-(f), and (g) of the Particulars of Claim made out.

**_(h) The Defendant failed to seek out advice from Reunite_**

204. The SOP and NCA guidance both required officers to seek the advice of Reunite even if (in the case
of the SOP) the risk of abduction was not considered real and imminent: see [28] and [34] above. The
Defendant admitted that the officers did not do this. This alleged failing is therefore made out.

**_(i) The Defendant failed to refer the Claimant to Reunite_**

**_(k) The Defendant failed to advise the Claimant of the necessity, desirability or even_**
**_availability of civil orders, despite knowing that the Claimant was in a dependent position in its custody_**

**_(o) The Defendant did not facilitate the Claimant's being able to take steps of his own to_**
**_secure independent advice on the child abduction matters_**

205. The Defendant contended that it was not for the police officers “to advise the Claimant on family law
matters”.

206. However as noted at [203] above the SOP and NCA were both clear in flagging the need to take
specialist advice from Reunite. As Ms Pedreño highlighted, the SOP required the police to create a CRIS
with all relevant advice sought and received from Reunite. This would have included advice given by
Reunite that a complainant should seek legal advice.

207. More specifically, both the SOP and the NCA guidance were clear that both criminal and civil
remedies needed to be considered together. The SOP dictated that in CAA, s.1 cases (which this was)
SCD5 officers were required to refer the complainant to Reunite “to pursue their civil remedies if
appropriate” and to “liaise with the complainant's solicitor regarding possible action under the Hague and
European Conventions on Child Abduction”. Further, the SOP provided that “[w]here the complainant does
not have a solicitor, they can be referred to 'Reunite' for advice”.

208. Ms Pedreño explained that even prior to the issuing of the NCA guidance in 2019, many police forces
signposted parents to her team to make urgent applications to prevent the wrongful removal of children
from the jurisdiction. She said that they are contacted “weekly” by parents who have received their details
from the police.


-----

209. It was no doubt for these reasons that DS Hassall specifically directed that the Claimant be advised
about his family law rights shortly after his first complaint to the police: see [60] above. The fact that the
failure to record and respond to the Claimant's allegations of child abduction meant that (as far as I can tell)
SCD5 officers did not become involved cannot justify the failure to signpost the Claimant to legal advice
earlier in the process. The thrust of the SOP was clear that this was required. Further, the officers knew
that the complainant in this case was in custody and therefore less able to obtain legal advice that he
would otherwise have been. This added a further layer to the need to ensure he was able to obtain legal
advice.

210. Ms Pedreño was clear in her evidence that the Claimant should have been advised to seek
immediate legal advice at the time he first called the police, when officers attended at his home to arrest
him, when he was being signed in to custody, when he confirmed to DC Wiltshire that he did not consent to
ALK taking ROC to Brazil and when he was interviewed by the police. She made the valid point that this
was all the more important given the widely held view that if ALK had sought the return of the passport, the
police would have had no power to retain it. This fact added an urgency to the need for him to take legal
advice.

211. In these circumstances I find that the matters set out at [90] (i), (k) and (o) of the Particulars of Claim
were necessary and proportionate steps for the officers to have taken for the purposes of Article 8. The
evidence makes clear that these things did not happen. The Defence at [7.7] did not suggest otherwise. I
therefore find all three of these alleged failings made out.

**_(j) The Defendant failed to advise the Claimant of the [fact] that ROC's passport's had_**
**_only been surrendered on a voluntary basis_**

**_(l) The Defendant inaccurately and negligently misstated the effect and durability of_**
**_ROC's passport being in her officers' possession_**

**_(m) The Defendant failed to advise the Claimant accurately or at all that the passport_**
**_might be returned to ALK_**

**_(n) The Defendant failed to inform or otherwise warn the Claimant of the return of ROC's_**
**_passport on 26 September 2013_**

212. All of these allegations were to the effect that the officers misrepresented the position with respect to
ROC's passport to the Claimant. The evidence makes clear that while he was initially told the passport had
been secured and was being held by the police, he was given no indication that the position might change
or that it in fact had.

213. The Defence at [7.8] did not dispute the factual basis of these assertions.

214. However, it was contended with respect to _(j) that it was not necessary for the officers to tell the_
Claimant that the passport had only been surrendered on a voluntary basis. In my judgment it was: this
would have made it clearer to the Claimant that ALK could withdraw her consent to the passport being held
at any time, which made it more likely that the officers might agree to release it. It would have emphasised
to him the need to take legal advice. The Claimant himself identified the difference between the police
having seized the passport and ALK merely agreeing for them to hold it and was concerned that he did not
know which scenario applied.

215. As to allegations (m) and (n), the Defendant submitted that there was no duty to advise or warn the
Claimant that the passport might be or was returned. I respectfully disagree. In Article 8 terms this was a
necessary step to ensure effective protection of the Claimant's rights and a key way of ensuring that the
legal scheme operated competently: it was important information for the Claimant to have, to underscore
the need for him to take urgent family law advice. That this was a reasonable step is illustrated by _Al-_
_Kandari v JR Brown & Co [1988] 1 QB 665, where the Court of Appeal found that solicitors had breached_
their duty of care by failing to warn a mother that her children's passport was no longer in their possession:
see [336] below.


-----

216. Ms Pedreño was clear in her evidence that the Claimant should have been told immediately when
ALK attended at the police station during the morning of 26 September 2013 to collect the passport.

217. Alleged failings (j), (l) and (m) and (n) are therefore made out.

**_(p) The Defendant failed adequately to inquire as ALK's reasons for wanting the passport_**
**_back_**

218. There is no direct evidence of any conversation with ALK as to why she wanted ROC's passport
back, but she was repeatedly telling the officers of her desire to go to Brazil: see [52], [67] and [78] above.

219. The Defence at [7.10] implies that ALK required the passport as proof of ROC's identity as they were
moving to accommodation unknown to the Claimant. However the Defendant did not make clear which
accommodation this related to and pointed to no evidence to corroborate that this was in fact the reason
she gave.

220. Even if that was in fact the reason ALK gave, it is hard to see how it would justify the immediate
return of the passport because (i) it seems unlikely that a refuge for abused women would insist on
verification of a child's identity through provision of a passport, at least in an emergency situation; and (ii) in
any event, ALK had declined the offer of a refuge and said she planned to stay with friends, who
presumably would not require any verification of her identity.

**_(q) The Defendant failed to take adequate or sufficient measures to dissuade ALK from_**
**_taking it or explaining the consequences which would follow if she did insist on its return_**

221. DC Wiltshire suggested to ALK that if she took ROC out of the country without the Claimant's
consent, this “could be construed” as child abduction. It is agreed that such actions would in fact amount to
an offence contrary to the CAA, s.1 as there was no relevant court order in place. On any view, therefore,
DC Wiltshire did not accurately explain to ALK that what she was planning on doing was in fact a criminal
offence. In those circumstances it cannot be said that the officers took adequate or sufficient measures to
dissuade ALK from her plans.

**_(r) The Defendant did not undertake an adequate risk assessment, despite, prior to the_**
**_Claimant's arrest and detention, being aware that ALK had taken steps to leave the jurisdiction by removing_**
**_ROC's passport, and knowing that she had unsupervised access to ROC, extensive connections to Brazil_**
**_and stating that she intended to travel to Brazil_**

**_(t) The criteria defining 'real and imminent' risk for the purposes of the Child Abduction_**
**_SOP were therefore met on the morning of 25 September 2013, yet no sufficient steps were taken_**

**_(w) The Risk assessments on both 25 September and 26 September were not carried out_**
**_adequately, and failed to follow the risk guidance in the Child Abduction SOP, or to take into account_**
**_adequately or at all material risk factors and failed to carry out those assessments with reasonable care_**
**_and skill_**

222. I uphold these alleged failings for the reasons set out at [190]-[199] and [201]-[203] above.

**_(s) Upon the Claimant arriving in custody, officers were aware that threats of removal_**
**_had recently been made and ALK had taken preparatory steps for removal in the short-term_**

**_(u) The Defendant was aware that ALK wanted the passport back and that this was itself_**
**_an indication of risk of abduction_**

223. These assertions are made out on the evidence and were not denied in the Defence. Both these
factors should have been taken into account by the officers in their risk assessment and there is no
evidence that they were.


-----

**_(v) DC Wiltshire and other officers failed properly to understand the rights of parents in_**
**_Child Abduction cases, particularly the limited grounds which could justify removal from the jurisdiction_**
**_without the Claimant's consent_**

224. DC Wiltshire's lack of understanding of the law is made plain by the entry on the CRIS considered in
the context of alleged failing (q) above. More generally, there was no challenge to Ms Shalaby's evidence
as to the ignorance of the law displayed by the officers in her discussions with them, and their failure to
take her advice. The officers' continued misunderstanding of the 28 day rule appeared to influence the
officers in their approach and is likely to have contributed to the decision to return ROC's passport to ALK. I
do not therefore accept the assertion at [7.12] of the Defence that any misunderstanding of the law by the
officers was immaterial. This failing is made out.

**_(x) The Defendant failed to take any or any adequate steps to mitigate the risk of child_**
**_abduction or prevent the removal of ROC from the jurisdiction._**

225. This overarching final allegation needs to be read in conjunction with [91] of the Particulars of Claim,
which averred that had the failings set out in [90] (as detailed above) not occurred, (i) the passport would
have remained in the officers' possession; (ii) the port alert mandated by the SOP would have been put in
place; and/or (iii) the Claimant would have secured court orders of his own preventing ALK from leaving the
country (by a court ordered port alert or PSO).

226. The Claimant's case on this issue is well-founded.

227. Had the officers conducted an accurate risk assessment they would have appreciated that there was
a real and imminent risk of abduction. They would thereby have appreciated the key importance of
retaining ROC's passport (as DS Hassall had done from the outset) and identified a legal basis for doing
so, as discussed in section 6 above.

228. Further, they would have put in place a port alert.

229. The Defendant accepted that if a real and imminent risk of abduction had been identified, as I have
found it should have been, a port alert was mandated by the SOP.

230. Putting in place a port alert does not appear to be a complex step: on the contrary, it seems to have
required no more than the sending of some kind of electronic message: see the reference to “MSS SMG
**PORTWARN” in the SOP and/or circulating the information on internal police systems in the SOP at [27]**
above.

231. Ms Pedreño was clear that a port alert should have been issued at the point when the passport was
returned to ALK. In fact, she was clear that an alert was merited at various stages before then: she
observed that it was “contradictory” for DS Oddy to assess the risk as “amber” and still not put in place a
port alert.

232. Ms Shalaby emphasised that a port alert is something any officer can put in place. She could not
understand why an officer would not this step when faced with a concern about child abduction.

233. Finally, for the reasons given at [205]-[210] above the Claimant should have been signposted to legal
advice and updated as to what was happening with ROC's passport.

234. Had this been done early in the process, as DS Hassall advised, it is more likely than not that a
relevant family court order would have been made during the day of 25 September 2013. Ms Pedreño was
confident that any family solicitor would have advised the Claimant to make an application for a
combination of orders to locate ROC, ensure the transfer of his passport from the police to the Tipstaff (as
explained in the SOP) and put in place a port alert. That such orders can be obtained very quickly is clear
not only from the established Family Court practice in this regard also but from the fact that the Claimant
was eventually able to obtain the necessary order within the same court day: see [44] and [109] above.

235. As to the morning of 26 September 2013, the passport was apparently returned to ALK at some point
between 8.00 am and 11.18 am but it is not clear when: see [79] above.


-----

236. If the transfer occurred before 9.08 am (when the Claimant was still at the police station) it would
have been easy to get him a message telling him what was, or might, happen with the passport. Officers
had already, of course, spoken to him in the corridor leading from the custody suite and in his cell about
these issues, and the Claimant had spoken to the Custody Sergeant about them: see [61]-[64] and [69]
[70] above. Further, the Custody Record notes that prior to his departure with Serco, there were a number
of discussions with him, such as to check the cell he had been in to ensure he had not damaged it.

237. Even if the decision-making about the return of the passport was taking place after 9.08 am (when
the Claimant left the police station with Serco), giving the Claimant the necessary warning would have
required no more than a police officer getting a message to the Claimant at the local Magistrates Court
where it was known he was, attending there in person if need be. Although neither party addressed this in
evidence, it is common knowledge that police officers regularly attend the Magistrates' Court. It is to be
hoped that as the Serco staff were acting as private contractors for the Defendant while transporting his
prisoners to court, the Defendant's officers had some means of contacting them. I cannot therefore accept
the Defendant's post-trial submission (see [328] below) that once the Claimant had left the police station it
would have been “physically impossible” for his officers to have contacted him. Ms Pedreño explained that
even at this later point in the chronology an application could have been made to the court orally to save
time, in case ALK had plans to travel that day (as she in fact did).

238. Accordingly even if the police had not put in place a port alert themselves, the Claimant could have
secured a court order to that effect, with other orders that would assist in preventing ALK from abducting
ROC.

_Conclusion on the violation issue_

239. For these reasons the officers did not take “the necessary steps” to ensure effective protection of the
Claimant's Article 8 rights (Guerra) and did not ensure that the legal and administrative “scheme” that had
been set up to prevent child abduction (most obviously the Defendant's own SOP) was “operated
competently so as to achieve its aim” (Anufrijeva).

240. The Defendant's officers did not strike a fair balance between the competing interests of ROC, ALK,
the Claimant, and the wider interests of the state. They focussed solely on ALK's wishes at the expense of
the Claimant's interests and those of ROC. There is no evidence that they considered what was in ROC's
best interests, let alone made that the primary consideration as required. They failed to appreciate that in
this context, prevention of abduction was in his best interests; and generally failed to ensure regard for the
preventive aspect of the Hague Convention.

241. To the extent that the Claimant's claim was advanced as a negative interference case, in light of my
conclusions on the passport retention issue in section [6] above, I reject the Defendant's case that in
returning ROC's passport to ALK, the officers were acting in accordance with the law and in a way that was
necessary so as to avoid contravening the law for Article 8(2) purposes. Rather, their actions were unlawful
and disproportionate for the reasons given above.

242. Accordingly, I conclude that the Defendant' actions amounted to a violation of the Claimant's Article 8
rights.

**7.3: If so, was there a clear causative link between the violation and the Claimant's**
**losses?**

243. The HRA, s.8(3) provides that no award of damages is to be made unless the court is satisfied that
the award is necessary to afford just satisfaction to the person in whose favour it is made. All the
circumstances of the case must be taken into account, including “(a) any other relief or remedy granted, or
order made, in relation to the act in question (by that or any other court) and (b) the consequences of any
decision (of that or any other court) in respect of that act”.

244. Under s.8(4), in determining whether to award damages or the amount of an award, the court must
take into account the principles applied by the ECtHR in relation to the award of compensation under
Article 41 of the Convention


-----

245. The ECtHR Practice Direction on Just Satisfaction dated 3 June 2022 (“the JSPD”) addresses the
issues of causation at [5], [9] and [10]. These paragraphs make clear that just satisfaction is afforded to
compensate an applicant for actual damage “established as being consequent to” a violation. For
pecuniary loss “a direct causal link must be established between the damage and the violation” found; and
a “merely tenuous or speculative connection is not enough”. Non-pecuniary damage can also only be
compensated for if non-material harm occurs “as a result of” the violation. The need for such a “clear
causative link” was emphasised in Alseran v MOD [2019] QB 1251 at [910].

246. The Defendant contended that the distress and anxiety and financial losses suffered by the Claimant
were not caused by the Defendant's actions, but by ALK's removal of ROC and her later unwillingness to
return him. Further, irrespective of the officers' actions, it was likely that she would have removed ROC by
some means. For these reasons it was said that an award of damages was not necessary to afford just
satisfaction.

247. I cannot accept this argument.

248. ALK's ability to abduct ROC was directly caused by the Defendant's officers returning his passport to
her: it is axiomatic that she would not have been able to abduct ROC without it.

249. Similarly, even if it was acceptable for the officers to have returned the passport to her, they failed to
put in place a port alert. Had they done so, in my judgment, it is more likely than not that ALK would have
been stopped at the airport and prevented from leaving.

250. Ms Pedreño said in terms in her report that if a port alert had been activated, “[ALK] would not have
been allowed to leave the jurisdiction”. In her oral evidence she described port alerts as a “very efficient”
means of ensuring that people are stopped at airports: although the system is not entirely foolproof, its
effectiveness is one of the reasons England is internationally well regarded for its work in preventing child
abduction. Ms Shalaby similarly accepted that port alerts are not “watertight” but said that, in her
experience “incoming” port alerts (i.e. alerts when a child who has been abducted is brought back into
England) are very successful, so she had no reason to consider that “outgoing” ones would be any less so.
Her example of someone evading port alert checks by smuggling a child out of England concealed in the
back of a car was not apposite here, given that ALK abducted ROC by aeroplane. The Defendant provided
no evidence to support any suggestion that ALK could have similarly smuggled ROC on to an aeroplane,
nor do I see how such a suggestion would be realistic.

251. Mr Clemens suggested to Ms Pedreño in cross-examination that ALK had engaged in “devious
subterfuge” by making untrue allegations of violence against the Claimant. He contended that this
illustrated that she would have achieved the removal of ROC from England by some means even without
his passport. She rejected this contention. I consider that she was right to do so. I observe that ALK had
not been particularly sophisticated in her plans: she had told the police in terms that she planned to take
ROC to Brazil.

252. For these reasons I conclude that the Defendant's failures to put in place a port alert and/or to
facilitate the Claimant in securing a court order to the same effect also directly caused the abduction of
ROC.

253. Accordingly by any or all of these routes, the Defendant's actions directly enabled ALK to leave
England and take ROC to a country which is known to be non-compliant with the Hague Convention on the
return of children. The abduction “directly caused” the Claimant to suffer extensive distress and anxiety and
to incur legal and other costs. All these losses suffered by the Claimant were “consequent” to and “as a
result of” the violation and there was a “direct causal link” between the two.

**7.4: Would a declaration alone amount to “just satisfaction” for the purposes of the**
**ECHR?**

254. The JSPD makes clear at [4] that the public vindication of the wrong, in a binding declaratory
judgment, is a powerful form of redress; and the ECtHR is free to conclude that the finding of a violation in


-----

itself constitutes in sufficient just satisfaction, without there being any need to make an award of financial
compensation.

255. It continues by giving certain examples of the sort of circumstances in which the Court is likely to
decide that no award should be made: “…where there is a possibility of reopening of the proceedings or of
obtaining other compensation at domestic level; where the violation found was of a minor or of a
conditional nature; where general measures would constitute the most appropriate redress; or otherwise,
because of the general or specific context of the situation complained of”. I do not consider that any of
these situations apply here.

256. The JSPD makes clear at [8] that the restitutio in integrum principle applies: “the applicant should be
placed, as far as possible, in the position in which he or she would have been had the violation found not
taken place”; see also Smith and Grady v the United Kingdom (Article 41) (2001) 31 EHRR 24 at [18]. The
Claimant has suffered consequences of the violation that involved non-pecuniary and pecuniary losses, as
described in sections 7.5-7.8 below, for which he is entitled to be compensated.

257. Accordingly, I conclude that just satisfaction for the Claimant requires both a declaration, and an
award of financial compensation.

**7.5: If not, what is the appropriate level of compensation for non-pecuniary loss?**

258. The JSPD indicates at [10] that an award for non-pecuniary damage “serves to give recognition to the
fact that non-material harm, such as mental or physical suffering, occurred as a result of a breach”. It
“reflects in the broadest of terms the severity of the damage”. For this reason, “the causal link between the
alleged violation and the moral harm is often reasonable to assume, the applicants being not required to
produce any additional evidence of their suffering”. In _Strand Lobben and Others v Norway_ (2020) 70
EHRR 14, for example, a non-pecuniary loss award was made to a mother to reflect the anguish and
distress that she “must have experienced” as a result of the procedures relating to her claims to have her
child returned and the child welfare services' application to have his adoption authorised.

259. However, it was not necessary to make such an assumption in this case. The Claimant gave clear
and unchallenged evidence of the very significant anguish and distress he has suffered as a result of the
separation from ROC and his protracted but unsuccessful efforts to resolve matters through legal routes.

260. The Claimant said that before ROC was abducted, he and his son were “inseparable”, with their lives
“completely intertwined”. ROC was 3 years old when he was abducted and is now 13. The Claimant has
only seen him in person once, in November 2015, and that was highly supervised as it was part of the
Brazilian court process. Otherwise, his contact with ROC has been limited to “snapshots of him growing up
on Skype”. ROC's grasp of English has now diminished, making their communications more difficult.

261. The Claimant feels “broken” by the absence of his son and feels an “overwhelming sense of loss” at
missing out on ROC's “firsts”, such that he has “lost the sense of being a father”. ROC's abduction has also
impacted the Claimant's wider family, in particular his parents, his older child and ROC's cousins, all of
whom were close to ROC. His relationship with others has also been affected as they struggle to
understand how he feels. It has adversely affected his finances, with the matrimonial home being sold and
his need to expend funds on legal fees. It has affected his ability to focus even on simple tasks and he has
been unable to work for the past few years. This has caused him further anxiety as he cannot make the
financial provision for ROC that he would like to do. His trust in the police has been “incredibly damaged”
and he now worries every time he sees an officer.

262. As Lord Woolf MR emphasised in _Anufrijeva_ at [52], and as the HRA, s.8(4) itself makes clear, in
determining whether to make an award under the HRA and if so, its level, “due regard” has to be given to
the Strasbourg jurisprudence”. The JSPD at [13] makes clear that in exercising its discretion to make an
award of this nature, the Court has regard to its earlier decisions. In Strand Lobben the figure awarded was
€25,000. The same figure was awarded in the similar cases of _Jansen v Norway (app. no. 2822/16) 6_
September 2018, _AS v Norway (app. no. 60371/15) 12 December 2019,_ _Hernehult v Norway (app. no._
14652/16) 10 March 2020 and ML v Norway (app. no. 64639/16) 22 December 2020.


-----

263. Other broadly comparable examples are: (i) _MA v Austria_ (app. no. 4097/13) 15 January 2015),
where €20,000 was awarded to reflect delays by the Austrian courts in facilitating the return of a child to
Italy pursuant to court orders, for approximately 3½ years; (ii) _Severe v Austria (app. no. 53661/15) 21_
September 2017, where €20,000 was awarded to a man who did not see his children for 7½ years after
their mother abducted them from France to Austria; and (iii) _Veres v Spain (app. no. 57906/18) 8_
November 2022, where €24,000 was awarded to a father who only had limited contact with his daughter
after she was abducted from Hungary to Spain by her mother.

264. Uprating for inflation, and applying an appropriate currency exchange rate, these equate to awards
worth between around £21,680 and £28,460 in today's terms. When considering these awards, regard also
needs to be had to the cost of living and relative purchasing power in the state concerned: see Faulkner v
_Secretary of State for Justice [2013] UKSC 23; [2013] 2 AC 254 at [38]._

265. The JSPD at [13] sets out various factors generally considered by the ECtHR when determining the
value of awards. I have considered these. The “nature and gravity of the violation” was that it was very
serious: it involved fundamentally flawed decisions taken by the Defendant's officers, with catastrophic
consequences. The “effects” on the Claimant have been extensive, impacting all his life, and causing a
separation from his son across continents, a situation which is likely to continue to affect him for many
more years, if not for the rest of his life. No domestic award has already been made. I was not told of any
other measures taken by the Defendant that “could be regarded as constituting the most appropriate
means of redress”. For example, the Defendant has made no apology to the Claimant as far as I am
aware; and PS White was unable to locate any records of the “management action” DI Brown had
recommended that several of the officers be given as a result of his findings in the complaint investigation.

266. In light of all these factors I consider that an award towards the top end of the range awarded in
broadly comparable cases, namely a figure of **£28,000, would be just, fair and reasonable in all the**
circumstances of the case.

**7.6: What is the appropriate level of compensation for pecuniary loss?**

267. The Claimant's Schedule of Loss sought two items of past pecuniary loss: (i) £73,220.62 in legal fees
for the proceedings in both England and in Brazil by which the Claimant has sought greater contact with
ROC and ensure his return; and (ii) £3,178.87 in incidental expenses including the cost of the Claimant
flying to Brazil, the cost of sending items on to ROC, telephone calls and other modest items.

268. For the reasons given in section 7.3 above, these losses meet the causation test consistently applied
by the ECtHR.

269. The Claimant provided over a hundred pages of receipts and invoices supporting the sums claimed
and the Defendant agreed these sums. Accordingly I consider that there is no reason to depart from the
_restitutio in integrum principle and the Claimant should be compensated for all the losses he has already_
incurred. An award reflecting them would be “just and appropriate” and “necessary” to afford “just
satisfaction” on an “equitable basis”, which are the critical questions: Anufrijeva at [66].

270. The approach is exemplified by cases such as _Severe, where the ECtHR awarded the applicant_
€3,500 to reflect the costs he had incurred in legal proceedings in Austria aimed at securing the return of
his child.

271. The Defendant submitted that it would be inappropriate and intellectually inconsistent for the court to
award the Claimant his pecuniary losses under Article 8 because they would be irrecoverable in the
negligence claim as too remote and pure economic loss.

272. This argument falls away on the facts of this case in light of my findings at sections 8.6-8.7 below to
the effect that these losses would be recoverable in the negligence claim. Accordingly, such an award
under the HRA is, in this case, consistent with the observations of Leggatt J in Alseran v MOD [2019] QB
1251 at [930]-[932] and the Court of Appeal in _Anufrijeva_ at [74] as to the relevance of domestic law
principles to HRA awards.


-----

273. However, even if I had found these losses irrecoverable in the negligence claim, I would not have
considered such a finding a barrier to recovery of them in the HRA claim. As Lord Woolf MR observed in
_Anufrijeva at [57], the approach to awarding damages under the HRA “should be no less liberal than those_
applied at Strasbourg”. Otherwise, “one of the purposes of the HRA will be defeated and claimants will still
be put to the expense of having to go to Strasbourg to obtain just satisfaction”. Strasbourg principles would
support an award of this kind for the reasons set out at [267]-[268] above.

274. For these reasons the appropriate level of compensation for past pecuniary losses as reflected in the
Schedule of Loss is the total sum claimed, namely £76,399.49.

**7.7: Is the Claimant permitted to advance a future loss claim for $42,000 (£33,600) in**
**relation to future visitation rights?**

275. The Schedule of Loss dated 23 June 2021 related solely so past losses. It noted that at that point the
Claimant's application in Brazil under the Hague Convention was before the Federal Court of Appeals of
the State of São Paulo and that two appeals were outstanding. The sections for future legal fees and
incidental expenses were left blank. By order of Master McCloud dated 13 June 2022 the Claimant's
solicitor was required to update the Defendant on a monthly basis as to the progress of the Brazilian
proceedings which would necessitate changes in the Schedule. I am told that this happened. It appears
that the parties agreed that this was a more constructive process than the Claimant formally updating the
Schedule of Loss (albeit that Master McCloud had made provision for this in her order, and for a final
Defendant's Counter-Schedule, to be provided in June 2022).

276. However, on 17 November 2023 (and so shortly before the trial started) the Claimant's solicitor
received what was described as “unexpected” correspondence from his Brazilian legal representatives,
Gama e Gerace, seeking payment of $42,000. The correspondence was drawn to the attention of the
Defendant and the court during the trial.

277. It was agreed that the manner in which this evidence had emerged and the timing of it was
unfortunate. Given the Defendant's objection to this claim being pursued the Claimant's solicitor was
required to provide a witness statement and further information on this issue which he did. Although it
came very late, the 17 November 2023 letter was consistent with, and the final iteration of, the practice
which the parties had hitherto adopted. The Defendant was afforded time to provide further submissions on
it after the trial. There was no suggestion that there was a need for any cross-examination on the
documents. Accordingly there was no unfairness to the Defendant in the Claimant litigating this claim. In
fact, the Defendant did not suggest in terms that there was: rather his objections to the Claimant advancing
this claim related more to the merits of it, both on the law and the evidence, which I address at section 7.8
below.

278. For these reasons I conclude that the Claimant is entitled to advance this claim.

**7.8: If so, is the same, or any part thereof, recoverable under the HRA?**

279. The Defendant rightly conceded that, in principle, awards for future loss can be made for a breach of
the Convention: the JSPD specifically recognises at [8] that awards for pecuniary loss “can involve
compensation for both loss actually suffered (damnum emergens) and loss, or diminished gain, to be
expected in the future (lucrum cessans)”.

280. Awards to reflect future loss were made in _Smith and Grady (Article 41)_ (2001) 31 EHRR 24. The
applicants had been dismissed from the army on grounds of their sexual orientation, in breach of Article 8
and 13, and had struggled to find comparable work. The ECtHR awarded them £15,000 and £25,000
respectively, to reflect their future loss of earnings, as well as awards to reflect their loss of pension.

281. The Defendant argued that the future loss awards made in Smith and Grady were parasitic upon the
psychiatric injury the applicants had suffered. It was suggested that this reflected a wider principle in the
Strasbourg caselaw to the effect that a psychiatric injury was a necessary precursor to a future loss award;
and that as well as the causation requirements, the ECtHR requires “certainty” in respect of pecuniary
losses


-----

282. This submission was not borne out by the facts of _Smith and Grady. While the first applicant had_
suffered a psychiatric injury, there were a series of other factors which had hampered her search for work:

[15]. There is no suggestion of psychiatric injury in the case of the second applicant: [10] and [16]. Further,
the ECtHR accepted that as well as the emotional and psychological impact on them of the intrusive
investigations into their sexuality and their discharges, there were significant differences between service
and civilian life and qualifications which contributed to the applicants' difficulties in finding comparable
work: [20]. Thus, the Court's awards reflecting future loss were not contingent on the existence of a
psychiatric injury. The Defendant did not point to any other authority in support of such a principle.

283. The more apposite relevance of Smith and Grady to this case is the approach the ECtHR took to the
nature of the evidence of future loss. The Court (i) rejected the Government's contention that no award
should be made in relation to future earnings given the “large number of imponderables”; (ii) accepted that
a precise calculation of the sums necessary to make complete reparation in respect of the pecuniary
losses suffered by the applicants was prevented by the “inherently uncertain character of the damage
flowing from the violations”; (iii) observed that “the greater the interval since the discharge of the
applicants, the more uncertain the damage becomes”; and (iv) concluded that in these circumstances its
role was simply to decide what level of award was “equitable”: [17]-[19]. The approach of the ECtHR in this
case specifically recognises that “certainty” as to the amount of any future loss is not required before an
award is made.

284. The Defendant contended that this claim was ambiguous and speculative; and that the damages
sought were remote, unforeseeable and irrecoverable as pure economic loss.

285. Although the 17 November 2023 letter from Gama and Gerace sought payment of $42,000 “in order
to initiate” legal process on behalf of the Claimant it was clear that some work had already been done on
his behalf, that the work as ongoing, and that extensive future work was likely to be needed. The letter
explained that the most recent appeal had been sent to the Supreme Court on 7 November 2023, but it
was unlikely that this would succeed. This would mean a resumption of the custody proceedings initiated
by ALK and that the Claimant would need to file a fresh claim based on the Hague Convention. The
lawyers were already working on a process to guarantee his visitation rights.

286. The $42,000 was broken down into (i) $10,000 for the Hague Convention claim in relation to visits; (ii)
six appeals at $5,000 each; and (iii) $2,000 in costs to enforce decisions relating to visitation.

287. By a further email dated 30 November 2023, Mr Gerace confirmed that the $10,000 had already been
incurred in relation to work done on the visitation application and was already due from the Claimant.

288. As to the six appeals at $5,000 each, the 17 November 2023 letter referred to appeals relating to
different issues (to prevent paternal visits or to prevent the travel of ROC to England) and being in different
courts (namely the Federal Regional Court, appeals to the Superior Court of Justice and appeals to the
Federal Supreme Court). In his later email, Mr Gerace clarified that there is a “high probability” that the
Claimant will need to pursue a series of different kind of appeal, namely an appeal, interlocutory appeal,
motion for clarification, special appeal, extraordinary appeal, interlocutory appeal in special appeal and
interlocutory appeal in extraordinary appeal. He explained that “the number of appeals in a lawsuit is not
related to the chances of success of the case, but rather to Brazil's own procedural system”.

289. Finally Mr Gerace explained that the $2,000 enforcement fee would be needed if the Claimant
succeeded on any of the applications for visitation, on any occasion when ALK sought to obstruct his
contact with ROC.

290. I do not consider that this evidence involves “imponderables” so significant that no future loss award
should be made, as the Defendant contended. I take the same view as the ECtHR in Smith and Grady in
this respect.

291. I consider that a fair reading of the evidence is that (i) $10,000 has already been incurred by the
Claimant; (ii) there is a “high probability” that he will need to spend a further $30,000 on six appeals; and
(iii) there is a realistic prospect he will need to pay $2,000 in enforcement costs.


-----

292. Any assessment of future loss involves an element of prediction. I consider that Mr Gerace's
evidence is very far from a situation where the claim is “speculative” and “based on future hypothetical
circumstances”. This was the basis on which the ECtHR declined to award the applicant in _Veres the_
$2,000,000 he sought, in part to buy a new house in which to spend time with his daughter: [93]-[95].
Rather, the key figure of $30,000 is the best estimate that can be made at present: Mr Gerace made clear
that there might be “a possible variation to the greater” (such that more than six appeals might be needed)
meaning that the actual costs will be higher than the figures he had given; but equally that the costs might
be lower than he had said.

293. I do not therefore consider it necessary to depart from the restitutio in integrum principle. Rather, the
Claimant should be placed “as far as possible”, in the position in which he would have been had the
violation found not taken place. That requires him to be awarded the full $42,000 or **£33,600 for further**
past, and future, pecuniary loss.

**7.9: Conclusion on the HRA claim**

294. The HRA claim therefore succeeds in full.

**8: The negligence claim**

**8.1: Did the Defendant owe the Claimant a duty of care based on established categories**
**of liability or by taking an “incremental” approach to this novel situation?**

295. As Lord Reed explained in N and another v Poole Borough Council [2019] UKSC 25; [2020] AC 780
at [64], the familiar tripartite test for the existence of a duty of care set out in _Caparo Industries plc v_
_Dickman [1990] 2 AC 605 – namely foreseeability of harm, proximity, and the imposition of a duty of care_
being fair, just and reasonable – is not a universal test. Rather, an “incremental approach” should be taken
to novel situations “based on the use of established categories of liability as guides, by analogy, to the
existence and scope of a duty of care in cases which fall outside them”. The question whether the
imposition of a duty of care would be fair, just and reasonable forms part of the assessment of whether
such an incremental step ought to be taken. This means that, generally, courts should apply established
principles of law, rather than basing their decisions on their assessment of the requirements of public
policy.

296. Lord Reed also emphasised the key distinction in the caselaw between harming a claimant and
failing to protect a claimant from harm (including harm caused by third parties). As to this, public authorities
are generally subject to the same principles of the law of negligence as private individuals and bodies,
except to the extent that the legislation from which their powers or duties are derived requires a departure
from those principles. This means that public authorities do not owe a duty of care at common law merely
because they have statutory powers or duties, even if, by exercising their statutory functions, they could
prevent a person from suffering harm. However public authorities can come under a common law duty to
protect from harm in circumstances where the principles applicable to private individuals or bodies would
impose such a duty, as for example where the authority has created the source of danger or has assumed
a responsibility to protect the claimant from harm, unless the imposition of such a duty would be
inconsistent with the relevant legislation: N at [64]-[65].

297. The Claimant advanced his case that he was owed a duty of care by the Defendant in a series of
ways, which I address in turn.

_(i): Application of Al-Kandari v JR Brown & Co [1988] 1 QB 665_

298. In this case a father had abducted his two children and taken them to Kuwait, but been persuaded to
return to England with them. A consent order was approved, permitting him access to the children, on the
basis that he gave an undertaking to deposit his passport, which included his children's names, with his
solicitors. The solicitors then provided his passport to the Kuwaiti embassy for the purported purpose of
having the children's names removed from it. The father persuaded the embassy staff to release it to him.
He kidnapped and violently assaulted the children's mother and removed the children to Kuwait. The


-----

mother did not see them for several years. She sued the father's solicitors for negligence in respect of their
handling of the passport.

299. French J held that the Defendant solicitors owed the mother a duty of care and had breached that
duty. However, he concluded that it was not foreseeable that the embassy would allow the father to have
the passport, such that her claim failed for want of a causative link between the breach and the damage:

[1987] QB 514.

300. The Court of Appeal upheld the finding that that there was a duty of care and that it had been
breached (albeit on a narrower basis than French J), but held that the damage suffered was indeed
foreseeable such that the mother succeeded in her claim. She was awarded the damages that French J
had assessed. These consisted of (i) £20,000 in general damages for the shock and personal injury she
had suffered by reason of the assault, the kidnapping and the loss of her children; and (ii) £7,668.14 in
special damages in respect of the costs incurred in the attempts made by members of her family and
others to recover the children in Kuwait: [1987] QB 514 at 522A and 526B-C and [1988] 1 QB 665 at 675CE and 678D-E.

301. Al-Kandari was expressly relied on and approved by the Supreme Court in Steel & Anor v NRAM Ltd
_(formerly NRAM Plc) (Scotland)_ _[2018] UKSC 13 at [28] and [32] and the Court of Appeal in Ashraf v Lester_
_Dominic Solicitors Ltd_ _[2023] EWCA Civ 4; [2023] PNLR 14 at [59]-61], primarily for its wider significance in_
holding that solicitors can owe a duty of care to someone other than their own client if they “step outside”
their usual role.

302. The Defendant contended that _Al-Kandari was of limited or no application to the facts of this case_
because it concerned the solicitors' formal undertaking to hold the passport to the order of the court, when
no such situation applied here. This submission was not supported by the facts of Al-Kandari: Bingham LJ
doubted whether the solicitors had, themselves, given any such undertaking to the court. More
fundamentally, the submission was not borne out by the reasoning in Al-Kandari: Bingham LJ held that the
existence of the duty of care was something “separate and different” from any such undertaking: 676G. In
other words, the undertaking was not the basis on which the duty of care was found to exist. Rather, it was
the substance of what the solicitors had agreed to do and why they had agreed to do it that led to the
conclusion that they had thereby assumed responsibilities in law to the mother and the children.

303. As Lord Donaldson MR explained, in voluntarily agreeing to hold the passport, they had “stepped
outside their role as solicitors for their client” and in so doing had “accepted responsibilities towards both
their client, and the plaintiff and the children”. This rendered the plaintiff one of their “neighbours” in the
_[Donoghue v Stevenson [1932] AC 562, 580 sense; and there were no “contra-indications” against finding](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-20X4-00000-00&context=1519360)_
that a duty of care existed: 672D-F.

304. Bingham LJ observed that when the solicitors first took possession of the passport they did so to
“reassure the plaintiff that [the father] would be unable to remove the children from the jurisdiction”: 676B.
The very “purpose” of holding the passport was to “protect her lawful rights”: 676E. He referred to other
scenarios when solicitors are trusted with different roles in litigation, independent of both parties or of
agents of both, such as where they hold a fund pending a decision on its ownership or application. They
were holding the passport as “independent custodians”; and the mother and her advisers had been
“confident that the passport would be as safe with them as in any other independent hands”: 675H-676A-D.

305. In my judgment the facts of this case render it directly comparable to _Al-Kandari. The police had_
secured possession of ROC's passport and were holding it for the specific purpose of preventing ALK from
abducting him. In so doing they were in part seeking to protect the Claimant's “lawful rights”. The police
were acting as “independent custodians” of ROC's passport pending resolution of the issue between the
parents or a court order: DS Hassall's account was clear that the passport would be held in the police
station safe and that the “family law court would ultimately decide upon return and any conditions”: see [59]
above. Shortly after his arrest on 25 September 2013 PC Abery specifically told the Claimant that the
passport would remain in the police's possession for safekeeping and that he could be reassured that ALK
could not take ROC out of the jurisdiction.


-----

306. _Al-Kandari is direct authority for the proposition that private individuals who put themselves in the_
same position as the solicitors in that case would owe a duty of care to the relevant third parties. This is an
established category of liability. Applying the observations of Lord Reed in N at [65] (see [294] above), it is
persuasive authority that the same duty should apply to a public authority that acts in the same way. There
is no legislative impediment to such a duty existing in respect of the police: indeed such a duty would be
consistent with the positive safeguarding and preventative duties set out at [169] above.

307. For these reasons I conclude that the Defendant did owe a duty of care to the Claimant in this case,
based on direct application of Al-Kandari.

308. To the extent that it is necessary to make such a finding, I consider this “incremental” development
justified. I do so in light of the legislative provisions referred in [169] and because, to adopt Lord Donaldson
MR's wording, there are no “contra-indications” against finding that a duty of care existed on policy grounds
for the reasons elaborated at [317] below.

_(ii): Representation and reliance_

309. In Hedley Byrne & Co. Ltd v Heller & Partners Ltd [1964] AC 465it was held that a negligent, though
honest, misrepresentation, spoken or written, may give rise to a claim for damages for the financial loss it
has caused, because the law will imply a duty of care when a party seeking information from a party
possessed of a special skill trusts him to exercise due care, and that party knew or ought to have known
that reliance was being placed on his skill and judgment: [486], [502] and [514]. _Hedley Byrne_ was
considered in _Caparo. The House of Lords held that liability for economic loss due to negligent_
misstatement was confined to cases where the statement or advice had been given to a known recipient
for a specific purpose of which the maker was aware and upon which the recipient relied and acted to his
detriment.

310. Cases involving a representation and reliance are a recognised exception to the general principle that
the police do not owe a duty of care to potential victims of crime. For example, in _Van Colle v Chief_
_Constable of the Hertfordshire Police_ _[2008] UKHL 50; [2009] AC 225 at [135], Lord Brown explained that a_
duty of care might readily arise where the police had “assumed specific responsibility for a threatened
person's safety” by for example, assuring him that “he should leave the matter entirely to them and so
could cease employing bodyguards or taking other protective measures himself”. Similarly, in Michael and
_others v Chief Constable of South Wales Police_ _[2015] UKSC 2, [2015] AC 1732 at [135], Lord Toulson_
posited that if a person is “negligently misled by the police into believing that help is at hand, and acts on
what she has negligently been led falsely to believe”, she would have a potential claim under the Hedley
_Byrne principle._

311. An example of this principle in operation is Sherratt v Chief Constable of Greater Manchester Police

_[2018] EWHC 1746 (QB). The mother of a woman who had died had been fearful that her daughter would_
harm herself and made a number of calls for assistance to the police. The Defendant's call handler gave
assurances that officers were on their way, would check on everything and told the mother to “leave that
with us”. King J upheld the decision of the Recorder to the effect that the Defendant had assumed
responsibility due to the representations given, applying Kent v Griffiths [2001] QB 36, which had involved
calls to an ambulance service. Similarly, in Woodcock v Chief Constable of Northamptonshire Police _[2023]_
_EWHC 1062 (KB), Ritchie J held that a Recorder was wrong to hold that no duty of care had arisen where_
the police had formulated a safety plan to protect a woman from her violent ex-partner, thus representing to
her that they would keep her safe, but had not acted on information from a neighbour that he was outside
the house and warned the Claimant, such that she left the house and was stabbed 7 times.

312. Shortly after the Claimant's arrest on 25 September 2013 PC Abery specifically represented to him
that ROC's passport had been secured, that it would continue to be safe with the police and that ROC's
removal would not be possible otherwise. The Claimant was told nothing to disavow him of this
understanding during 26 September 2013. Through his discussions with the officers during the day of 27
September 2013, he was given further reassurance that the passport was in the hands of the police.


-----

313. Mr Clemens cross-examined the Claimant and suggested to him that he had not relied on what the
police said. The Claimant said the suggestion that he “did not know either way” what the position was in
respect of the passports as time went on was not fair: PC Abery had told him in terms that the passports
had been taken from ALK and he had not been told anything contrary to that. He was “totally uninformed”
apart from what the officers were telling him. He explained in his witness statement that he was concerned
that he had not been shown any proof that the police had the passports but he was nevertheless reassured
by what they told him. He continued to labour under the misapprehension that the passports were in the
custody of the police throughout much of 27 September 2013. That he was of this view is clear from the
note on the Reunite file to that effect when they opened a file for him that day: see [89] above. Likewise, in
_Al-Kandari, Bingham LJ referred to the “false sense of security” that the mother had, as she did not know_
that the passport was no longer in the Defendant's possession: 678A-B.

314. It is plain from the chronology set out at [55]-[56], [70]-[71] and [83]-[119] above that the Claimant
took many steps to try and prevent ROC from being abducted and was desperate to secure advice. He did
so while detained, and even more so once he was released on bail in the early afternoon of 26 September
2013. In my judgment it can safely be inferred that had he understood the gravity of the situation more
clearly, i.e., that at some point in the morning of that day, the officers had returned the passport to ALK, his
efforts would have been all the greater. Indeed at the very time the return of the passport was taking place
the Claimant was at the Magistrates Court and had been in consultation with this solicitor. Had they both
known that the passport was now back with ALK, their discussions would more likely than not have had a
different level of urgency. I am therefore satisfied that the Claimant's reliance on the representations was to
his detriment.

315. In Woodcock at [49(4)], having reviewed the authorities, Ritchie J formulated a list of matters the
courts would examine when considering whether the police owed a duty of care to protect a member of the
public: (i) the foreseeability of harm and the seriousness of the foreseeable harm to the specific member of
the public (the suggested victim); (ii) the reported or known actions and words of the specific alleged
protagonist in relation to the feared or threatened harm; (iii) the course of dealing between the potential
victim, the police and the alleged protagonist focussing on proximity; (iv) the express or implied words or
actions of the police in relation to protecting the victim from attack by the protagonist and the reliance of the
victim (if any) on the police for protection as a result; and (v) whether the public policy reasons for refusing
to impose a duty of care outweigh the public policy in providing compensation for tortiously caused damage
or injury.

316. Applying those factors here, and adopting the same numbering: (i) there was a high foreseeability of
harm to the Claimant, of the most serious kind (namely long-term separation from his young son); (ii) he
had reported concerns about the potential actions of ALK based on the missing passport and suitcases
and she herself had said she intended to go to Brazil; (iii) the officers were well aware of the Claimant's
concerns about the risk of abduction and also that ALK was saying she planned on leaving; and (iv) as
explained above the officers represented to the Claimant that the passport was safe with them and he
relied on those representations.

317. As to (v), my reasoning is very similar to that adopted by Ritchie J in _Woodcock at [109]-[110]._
Children at risk of being abducted and parents facing the risk of lifelong separation from their children
require protection. The duty contended for here is also a “limited and precise” one. There was no evidence
from the Defendant that the costs of taking the steps in question would have been prohibitive. The facts of
this case were stark and are hopefully unique. They certainly stood out for Ms Shalaby when reflecting on
her 30 years' experience. On that basis there should be no concern about “opening the floodgates” by
imposing a duty of care. It should encourage good policing practice and further support the positive
safeguarding and preventative duties on the police set out at [169] above.

318. The Defendant sought to counter the analysis above by reference to the fact that the claim in Caparo
failed. However a key reason why that occurred was that the class of potential recipients of the information
was too wide: the House of Lords held that there was no reason of policy or principle why auditors
providing a statutory report under the Companies Act 1988 should be deemed to have a special
relationship with non shareholders contemplating investment in the company in reliance on the published


-----

accounts. However, that concern does not arise here: the representation was made to a single, known
recipient (the Claimant), for a specific purpose (to reassure him that ROC could not be abducted), of which
the officers were aware, and upon which he relied to his detriment. Further, their Lordships in Caparo did
not overturn Smith v Bush [1990] 1 AC 831, where a surveyor was held liable to the purchaser of a house
for negligently completing the survey: it was known that such a survey would be relied on by the house
purchaser, and was considered fair to impose liability. Those facts are closer to the situation here.

319. The Hedley Byrne criteria, as considered in Caparo, are therefore met in the Claimant's case. In my
judgment the representations made to the Claimant and his reliance on them provide a further, and
alternative or complementary, route to a duty of care for the Claimant.

_(iii): The alleged creation of the risk of the source of the danger by the Defendant_

320. The Claimant also submitted that the officers, by the positive act of returning the passport without
taking other protective measures, had actually created the source of the danger, such that the case fell
within the second of the categories described by Lord in _GN_ at [165] (see [294] above). In _Robinson v_
_Chief Constable of West Yorkshire_ _[2018] UKSC 4, [2018] AC 736, for example, the Defendant was held_
liable in negligence for injuries caused to someone knocked over and injured by the police's actions in
trying to arrest someone else: see, in particular [33], [66]-[68] and [80].

321. In Robinson at [70], Lord Reed JSC confirmed that the police “may be under a duty of care to protect
an individual from a danger of injury which they themselves created, including a danger of injury resulting
from human agency”. He gave as examples of this principle _Dorset Yacht_ [1970] AC 1004and _Attorney_
_General of the British Virgin Islands v Hartwell_ [2004] 1 WLR 1273. In the former case prison officers
brought young offenders on to an island and left them unsupervised, such that they escaped and caused
damage to property. In the latter, police authorities were held to be negligent in entrusting a firearm to an
officer who was still on probation and had shown signs of instability, who then shot and injured two people.

322. In this case, the officers provided ALK with the very thing she needed to abduct ROC, namely his
passport. It was foreseeable in all the circumstances that she would use it to carry out the plan to go to
Brazil that she was describing to the officers. On its face, therefore, this case falls within this category.

323. The Claimant did not suggest that by their positive acts the police caused him an identifiable personal
injury for which he sought damages in negligence. He did contend that their actions caused the abduction
of ROC and his reasonably foreseeable legal costs in seeking his return. Although Lord Reed referred to a
duty of care arising in these circumstances to protect an individual from a risk of “injury”, not “harm” more
generally, the inclusion of _Dorset Yacht as an example of the principle suggests that it can embrace_
damage to property and thus, by extension, financial losses more generally.

324. The Defendant's key objection to this argument was the proposition that ALK was the source of the
danger and not the officers' actions. I have rejected that argument in the course of the HRA claim: see

[245]-[252] above.

325. For all these reasons I conclude that this route provides a further reason for imposing a duty of care
in this case. I do so with some trepidation, having heard relatively little argument on this aspect of the case.
However my clearer conclusions under sections (i) and (ii) above mean that this issue is not determinative.

_(iv): The fact of the Claimant's detention_

326. It is well-recognised that irrespective of the reason for the detention, and even where the detention is
itself lawful, a detaining authority owes a duty to take all reasonable steps to avoid acts or omissions which
it could reasonably be foreseen would be likely to harm the person for whom he is responsible: Kirkham v
_Chief Constable of Greater Manchester Police [1990] 2 QB 283._

327. As set out at [206] above, the thrust of the SOP and NCA guidance was that complainants such as
the Claimant should be signposted to legal advice. The Claimant's status as a detained person posed an
additional impediment to him being able to obtain such advice. DS Hassall was clear at the outset of these
events that it was necessary to advise him of his rights while he was in detention.


-----

328. In my judgment, on the particular facts of this case, a failure to facilitate the Claimant in obtaining
legal advice was an “omission” which it could reasonably be foreseen would be likely to harm the Claimant.
Accordingly, _Kirkham provides another reason why the Defendant's officers owed the Claimant a duty of_
care to ensure he had access to legal advice while he was in custody.

329. After the trial I sought submissions as to how, if at all, the Kirkham duty continued to apply once the
Claimant was transferred to the care of Serco at 9.08 am on 26 September 2013. Relying on Al Medenni v
_Mars_ _[[2005] EWCA Civ 1041 and Jacobs v Chalcot Crescent (Management) Company](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG71-DYBP-P3V7-00000-00&context=1519360)_ _[2024] EWHC 259_
_(Ch) Mr Simblet KC contended that it was impermissible for this issue to be considered, as it was not a_
point that had ever been taken by the Defendant and it was far too late for the Defendant to
(opportunistically) adopt it now. I am not sure that that is the correct analysis. The Defendant having
squarely denied the applicability of the Kirkham duty (albeit on the wider basis that it could not “stretch” to
measures to prevent child abduction), it was for the Claimant to prove that the duty did apply. The
Defendant invited me to consider the issue. On further consideration, I am satisfied that the transfer of the
Claimant to Serco is irrelevant to the duty of care issue. The Claimant remained in the legal custody of the
Defendant until such time as he was released from the Magistrates Court, albeit that the Defendant had
contracted with Serco as his agent to transport the Claimant to court: see Part IV of PACE and cases such
as _Woodland v Essex County Council [2013] UKSC 66, [2014], 1AE 547 at [23] and_ _GB v Home Office_

_[2015] EWHC 819 (QB) emphasising the non-delegable nature of this duty of care. In any event, the duty_
of care derived from issues (i) and (ii) above continued to apply while the Claimant was with Serco.

_Conclusion on the duty of care issue_

330. The Defendant owed the Claimant a duty of care by direct or incremental application of Al-Kandari;
and/or because he relied on the representations made to him by the officers. The fact that the officers
themselves created the source of the danger in returning the passport to ALK and the fact that the
Claimant was a detained person provide additional reasons why a duty of care existed in this case.

**8.2: What is the scope of any duty of care identified above?**

331. The Claimant contended that the special assumption of responsibility in this case was to exercise
reasonable skill and care to protect the Claimant (and ROC) from the risk of child abduction and the direct
consequences thereof; and that was the scope of the duty of care.

332. Specifically, he submitted that the scope of the duty of care included (i) a duty to record, clearly and
accurately, the information about the risk of child abduction and the decisions taken in response to it; (ii) a
duty to advise the Claimant that ALK could secure the passport's return in the absence of a civil court
order; (iii) a duty to take reasonable care to retain the passport in their possession; (iv) a duty to warn the
Claimant of the return of ROC's passport; (v) a duty to refer the Claimant to Reunite for advice; (vi) a duty
to make reasonable provision for the Claimant to instruct solicitors to make an application for civil orders, if
necessary on an emergency basis; and (vii) a duty to re-evaluate the risk of ROC's abduction and take
preventative steps against the risk of his removal from the jurisdiction, including, but not limited to issuing a
port warning, in circumstances where the Claimant could take no timeous action of his own.

333. The Defendant contended that the scope of this pleaded duty of care was too wide. It could properly
be no wider than the SOP. It could not extend, for example, to making reasonable provision for the
Claimant to instruct solicitors.

334. In my judgment the scope of the duty as formulated by the Claimant is appropriate. All of the
elements of it, including the legal advice issue (see [206] above), are derived from the Defendant's own
SOP or the NCA guidance. Accordingly therefore illustrate what was reasonable for the officers to have
done, following on from the assumption of responsibility.

335. However, even if the scope of the duty was the narrower one advanced by the Defendant, and even if
that did not include a duty to facilitate the Claimant in instructing solicitors, the officers breached that duty
by their failures with respect to risk assessment and the absence of a port alert.


-----

336. I note that Lord Donaldson MR in Al-Kandari identified the duty of care in that case as including “quite
clearly a duty not to hand the passport to the husband upon his request” and a responsibility to inform the
mother that the Defendant no longer had possession of the children's passport: 672D-E and 674B-C.
Bingham LJ similarly defined the scope of the duty as one “to take reasonable care to keep the passport in
their possession (save as the plaintiff might otherwise agree, and to inform the plaintiffs if for any reason it
ceases to be in their possession”: 676F-G. Even if the scope of the duty of care was as narrow as this, the
Defendant was in breach of it.

**8.3: Did the Defendant breach the duty of care in the ways set out at [90] of the**
**Particulars of Claim?**

337. The Claimant advanced the same allegations of breach of the duty of care in the negligence claim as
he put forward as allegations of a violation of Article 8. Accordingly for the reasons given under section 7.2
above, I conclude that the Defendant breached the duty of care owed to the Claimant in the ways
advanced at [90] of the Particulars of Claim.

338. There are direct comparisons between this case and Al-Kandari. Lord Donaldson MR concluded that
the Defendant solicitors had been in breach of their duty in respect of failing to inform the mother or her
solicitors that the embassy had retained the passport or that arrangements had been made for the
husband to attend at the embassy on the following day in the absence of any representative of the
Defendant: 67AB-C. Similarly, Bingham LJ held that the solicitors were in breach of their duty by not
informing the mother that the passport was no longer in their possession: she was entitled to know from the
Defendant that the “safeguard…was no longer effected” and the Defendants “fell short of their duty in
failing to pass onto the plaintiff or her solicitors the information they have”: 677D-E.

339. Indeed the facts of this case are more stark than those in _Al-Kandari in that the police officers_
returned the passport to the potential abductor themselves, whereas in Al-Kandari it was not the Defendant
solicitors who did so, but the embassy staff. I note that in Al-Kandari the solicitors' agents had been given
several assurances by the embassy staff that the passport would be safe with them, and yet they were still
found to have been in breach of duty.

**8.4: Were any breaches identified causative and would the Claimant have suffered the**
**removal of his son from the jurisdiction and the financial losses in any event?**

340. I consider that the breaches were causative and that the Claimant would not have suffered the
abduction and losses in any event, for the reasons set out in section 7.3 above.

**8.5: What losses were caused as a result of the breach of that duty?**

341. The Claimant did not seek any damages for personal injury in the negligence claim, no doubt
recognising that “distress”, “upset” and other similar human emotions do not constitute personal injury:
_Brown v Commissioner of Police and CC Greater Manchester Police [2020] 1 WLR 1257 at [13], per_
Coulson LJ.

342. The only losses he claimed related to his legal and other incidental expenses in trying to secure
ROC's return. In my judgment these expenses were caused by the abduction which was in turn caused by
the Defendant's breach of duty, for the reasons given in section 7.3 above.

**8.6: Were the special damages claimed reasonably foreseeable?**

343. A key element of the domestic and international system for the prevention of child abduction is the
ability of aggrieved parents to seek court orders in respect of their children. The SOP and NCA emphasise
the need to consider the civil law regime and for parents to take specialist advice: see [28] and [34] above.
In those circumstances it cannot be said that the costs the Claimant incurred in seeking to enforce his legal
rights after ROC's abduction were not the reasonably foreseeable consequence of the Defendant's
conduct. They were not too remote. I note that neither French J nor the Court of Appeal had any difficulty in
ordering an award in respect of similar expenses in Al-Kandari: see [299] above.


-----

344. Accordingly I conclude that the Claimant's special damages in relation to attempts to secure his son's
return to the UK are recoverable in his negligence claim. Accordingly, had I not awarded him the sum of
£76,399.49 in the HRA claim, he would have recovered it in the negligence claim

**8.7: Are the special damages claimed “pure economic loss” and if so, are they**
**recoverable in principle as falling within the scope of any duty of care?**

345. Even if the Claimant's expenses are properly considered as pure economic loss as the Defendant
contended, they are still recoverable: this is because one of the reasons for the duty of care being imposed
is that the Hedley Byrne criteria are met (see [305]-[315] above), permitting the recovery of such loss.

**8.8: Is the Claimant permitted to recover $42,000 USD (£33,600) in relation to future**
**visitation rights in the negligence claim?**

346. In my judgment the Claimant would, in principle, be able to claim for future losses in the negligence
claim. The future losses claimed relate to expenses of the same nature as the past losses. It is reasonably
foreseeable, given Brazil's status as a non-Hague compliant country and ALK's intransigence, that the
Claimant would be involved in a protracted legal battle to secure ROC's return. The evidence from his
Brazilian lawyers makes clear that that is exactly what has occurred and why the legal proceedings are
more likely than not to continue.

347. For these reasons if I had not awarded the Claimant £33,600 for the future expenses under the HRA
claim, I would have done so in the negligence claim.

**9: Conclusions**

348. This case involved stark and hopefully unique facts. It is hard to imagine the Claimant's distress at
the loss of his relationship with his young son. It is clear it has had wide-ranging impacts on his life and will
continue to do so.

349. The Defendant chose not to call any of his officers to explain their decision-making.

350. Based on all the evidence that was placed before me, for the reasons I have given, I conclude that
the officers violated the Claimant's Article 8 rights and breached their duty of care towards him. Both the
Claimant's claims succeed.

351. He is entitled to a declaration that his Article 8 rights were breached.

352. He is also entitled to just satisfaction under the HRA. As such I award him (a) **£28,000** for nonpecuniary loss; (b) £76,399.49 for past pecuniary loss; and (c) £33,600 for further past and future
pecuniary loss.

353. If the Claimant had succeeded in the negligence claim alone, he would have recovered sums (b) and
(c) above.

354. The total to be awarded to the Claimant is therefore **£137,999.49** to which interest will need to be
added. The calculation of interest is not straightforward for a range of reasons. Mr Simblet KC provided
detailed draft calculations of the sums sought. Despite an extension of time to do so, the Defendant failed
to provide any submissions on this issue, or indeed any other consequential matters, or even a draft order,
before the hand down of this judgment. Reluctantly, I will grant him a modest period of extra time to do so.
Accordingly the issue of interest, and other consequential matters, will be dealt with separately.

355. I reiterate my thanks to all counsel for their considerable assistance with this complex case.

**End of Document**


-----

