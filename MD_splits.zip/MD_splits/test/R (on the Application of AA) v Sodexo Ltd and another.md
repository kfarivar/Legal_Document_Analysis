# R (on the Application of AA) v Sodexo Ltd and another [2023] EWHC 3215
 (Admin)

King's Bench Division, Administrative Court (London)

Kirsty Brimelow KC (sitting as a deputy judge of the High Court)

14 December 2023Judgment

Amanda Weston KC and Greg Ó Ceallaigh (instructed by Turpin Miller) for the Claimant

Jamas Hodivala KC and Toby Fisher (instructed by Devonshires) for the First Defendant

Sian Reeves (instructed by Government Legal Department) for the Second Defendant

Sian Reeves (instructed by Government Legal Department) for the Interested Party

Hearing date: 25 July 2023

- - - - - - - - - - - - - - - - - - - - 
**JUDGMENT**

**KIRSTY BRIMELOW KC :**

**INTRODUCTION**

1. The Claimant (“AA”) is a 20-year-old Portuguese national and mother to a baby, C, born on 22 April
2022 who, at the time of the hearing on 25 July 2023, was serving a sentence of imprisonment at HMP
Peterborough, a private prison (“the Prison”) that is operated by the First Defendant (“Sodexo”).

2. Her claim for judicial review dated 19 May 2023 challenges:

1. A decision, dated 5 January 2023, conveyed on 24 January 2023, by the Secretary of State for the
Home Department (“SSHD”) to treat AA as statutorily ineligible for Home Detention Curfew (“HDC”) due to
its determination that she had been served with a decision to deport.

2. The decision of the Prison and so of Sodexo on 27 February 2023 refusing to exercise their power to
[release her on HDC pursuant to s. 243 of the Criminal Justice Act 2003 (“CJA 2003”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)

3. In summary, the focus of the Claim is upon the legal effect of a combined stage 1 decision letter issued
by the SSHD on 5 January 2023 and whether this actually contains a decision to deport i.e., “a decision to
[make a deportation order” within the meaning of s.259 (a) CJA 2003.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)

**Procedural History and Changes in Circumstances**

3. On 27 June 2023, Vikram Sachdeva KC sitting as a Deputy High Court Judge granted AA permission to
apply for judicial review and ordered that the hearing of the claim be expedited due to the claim concerning
“the liberty of the subject” and “the fact that that question will otherwise become academic soon”.

4. On 29 June 2023 the SSHD made a stage 2 deportation decision under the Immigration (European
Economic Area) Regulations s. 2016 as saved. On the same date AA's application under the EU
Settlement Scheme (“EUSS”) that had been made on 25 December 2020 was refused On 5 July 2023 the


-----

SSHD wrote to AA stating that on any analysis the stage 2 decision was a “decision to make a deportation
order within the meaning of s.259(a) of the CJA 2003” and so invited AA to withdraw her claim. This was
resisted by AA.

5. However, on 12 July 2023 the SSHD withdrew both her stage 2 deportation decision and her EUSS
decision and also withdrew her stage 1 decision.

6. In her letter to AA, dated 14 July 2023, the SSHD sets out her position that there is no decision to
deport AA and so invited AA to withdraw her claim as being academic.

7. On 17 July 2023, the SSHD filed an application to stay the case management directions and to convert
the expedited substantive hearing into a case management hearing due to developments in the case
meaning that her claim was no longer urgent. In short, there no longer was a vulnerable person and her
baby in detention or they were about to be released. The ongoing detention had been the original premise
of the expedition. AA opposed the application arguing that the application concerns the wider liberty of
subjects, albeit no longer AA, and that the hearing should continue in full as directed under the expedited
timetable.

8. AA's conditional release date was 9 August 2023. The Director of the Prison, Ian Whiteside's third
statement, dated 3 August 2023, stated that AA refused proffered accommodation on 21 July and that as
there were fewer than 10 days remaining to AA's conditional release date, the Home Detention Curfew
Policy Framework (“HDC Framework”) required him to refuse an application for HDC. However, the
position remains that there is no decision by Sodexo or by the SSHD to be challenged by AA. All
deportation action against her had ceased by the time of the hearing on 25 July 2023.

9. I ordered that the expedited substantive hearing listed on 25 July 2023 be converted into a case
management hearing to consider whether the claim should be dismissed on the basis that it is academic or
whether to proceed. My reasons were due to the hearing no longer being urgent as SSHD had withdrawn
both its previous decisions and that attempts were being made to find AA a suitable HDC address, the
viability of the proposed address being a matter outside this claim. The case management directions by
Deputy Judge Vikram Sachdeva KC were stayed.

10. On 21 July 2023, pursuant to CPR r.39.2, I ordered anonymity for the Claimant and her child, to
protect the interests of the child and to protect the interests of AA, and permission to rely upon the
statement of Julian Stern, senior immigration caseworker at AA's solicitors, Turpin Miller LLP, in relation to
whether the Claim is academic. The SSHD did not object to reliance on the statement but pointed to the
anonymity within the various cases relied upon by AA as meaning that it could not fully investigate those
cases.

11. During August 2023, further to my directions, I received further written submissions from AA as to why
Sodexo should not become an Interested Party if the Claim proceeds and why dismissal of the Claim
against the SSHD would not result in a dismissal against Sodexo.

**AA and C**

12. AA was born in Portugal. Her mother moved to the UK from Portugal in October 2012 and shortly
afterwards, aged 9 years' old, AA joined her with her father and siblings. AA experienced and witnessed
serious violence within her family home and social services and police were involved during her young life.
In September 2020, AA committed the offence of conspiracy to dishonestly make false representations for
gain.

13. On 5 October 2022, AA was convicted and on 9 December 2022 she was sentenced to one year and
four months' imprisonment. She was transferred to a Young Offenders' Institution and separated from her
baby until her transfer to the Mother and Baby Unit of the Prison on 14 February 2023.

14. AA had been referred to the National Referral Mechanism and on 12 November 2020 a positive
“Reasonable Grounds” decision was made by the Single Competent Authority that she is a victim of
**_[modern slavery under the Modern Slavery Act 2015. On 20 May 2022, this decision was converted into a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

iti C l i G d d i i


-----

15. On 5 January 2023, AA was served with a notice which informed her of her liability to deportation
pursuant to the Immigration (European Economic Area) Regulations 2016 (EEA Regulations 2016). This is
a ICD. 4932 EEA or Stage 1 deportation decision. AA was also served with a “One Stop Notice” requiring
her to give reasons why she should not be deported within 20 days.

16. The heading of the ICD.4932 EEA has two headings in large capital letters:

1. Notice that you may be liable to deportation pursuant to the Immigration (European Economic Area)
regulations 2016 as saved (EEA Regulations 2016)

[2. Decision to deport pursuant to the Immigration Act 1971 and the UK Borders Act 2007.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

17. The letter is described by the SSHD as a combined stage 1 letter which is issued where it is not clear
whether the person is a relevant person pursuant to the Conducive Deportation Guidance. A relevant
person includes a person to whom the EEA Regulations 2016 Immigration apply. This relates to whether
the person has a right of permanent residence under the EEA Regulations 2016 or were exercising Treaty
rights in the UK before 23.00 GMT on 31 December 2020 and have made an in-time application for EUSS
leave which has not been determined or appeal rights have not been exhausted.

18. On 24 January 2023, AA signed a disclaimer indicating her intention to leave the UK voluntarily and
waiving her right to make representations against deportation. She had had no legal advice and had been
detained after sentencing by the Crown Court and then separated from her baby due to commencing her
period of detention at HMP Low Newton, a Young Offenders' Institution for women, which does not have a
Mother and Baby Unit. On 14 February 2023, AA was transferred to the Prison, and she was reunited with
C in the Mother and Baby Unit.

19. On 21 February 2023 all the papers were re-served. The ICD. 4932 noted: “re-served all papers as
_subject stated not previously served and did not know about possible deportation.”_

20. The date of AA's eligibility for release on HDC, pursuant to s.243 of the CJA 2003, was 10 April 2023.
The purpose of HDC, in part, would have been to allow AA to access supported rehabilitation with C in the
community.

21. On 27 February 2023 the Prison notified AA that she was “eligible by law” for HDC but “presumed
unsuitable” due to her unclear immigration status.

22. The Prison, represented by Mr. Hodivala KC, accepts in its amended defence dated 21 June 2023 that
this answer was wrong, and it had been made without reference to the SSHD. No HDC-FNP had been sent
by the Prison to the SSHD. This form is created by the Ministry of Justice and its purpose is described on
the form as being to help determine the prisoner's eligibility and suitability for release on HDC.

23. On 24 March 2023, AA made representations to the Prison on why she should be released on HDC on
the grounds of “exceptional circumstances”, in line with the HDC Framework. The Prison then sent an
HDC-FNP form to the SSHD.

24. On 13 April 2023, the SSHD's Foreign National Offender- Returns Command team completed the
HDC-FNP form and ticked “yes” to the question whether there had been a decision to deport.

25. The immigration enforcement also included a note that:

“Immigration Enforcement is still considering deportation/removal action against her. She has been served
with a stage 1 decision confirming she is liable to deportation. Her representatives have requested a sixweek extension to provide evidence of her residence in the UK, this was agreed by Immigration
Enforcement. So, the reason to refuse the HDC remains correct, as the stage 1 decision simply made
**her liable to deportation, but it is not decided until the stage 2 decision is served so her**
**immigration status is uncertain”**

26.  The SSHD stated in its amended summary of Grounds of Defence, dated 23 June 2023, that this
information was provided in error and its position is that the text highlighted in bold is incorrect and relies
on the “yes” in the box as to whether there had been a decision to deport AA.


-----

27. The form sets out that where the SSHD answers “yes” then the prisoner will be ineligible for HDC. The
Prison relied on the form. AA argues that the note on the form was plainly correct as there remains a twostage process and only when the second stage is concluded has there been a “decision to make a
deportation order” for the purposes of s. 259(a) CJA 2003. AA deprecates reliance being placed on a
“boilerplate sentence” on the form.

28. On 29 June 2023, the SSHD made a stage 2 deportation decision under the EEA Regulations 2016.
On the same date AA's application under EUSS that had been made on 25 December 2020 was refused.

29. On 12 July 2023 the SSHD changed her position and withdrew both her stage 2 deportation decision
and her EUSS decision and also withdrew her stage 1 deportation decision.

30. Nicolas Coddington, Head of the Offender Management Unit and other Units at the Prison confirmed in
a statement dated 19 July 2023 that the Prison was progressing assessment of AA for her release on
HDC. However, she did not have a suitable address and he was awaiting the local authority to propose an
address at a meeting with the Community Offender Manager on 20 July 2023.

31. In a statement dated 3 August 2023, the Director of the Prison, Ian Whiteside stated that AA had
refused offered HDC accommodation on 21 July and therefore, pursuant to the HDC Framework, HDC
would be refused as there were fewer than 10 days until AA's conditional release date on 9 August 2023.

**Issues in the claim**

32. The decisions have been withdrawn. However, AA pursues the Claim. The issue, if the Claim is to
continue, is whether AA was “notified of a decision to make a deportation order against her” for the
purpose of s. 246(4)(f) and 259(a) CJA 2003 and whether that determination now is academic.

**The Legal Framework**

**Power to release on HDC**

33. The Secretary of State for Justice has a discretionary power to release an eligible prisoner before the
end of the custody period of their sentence on HDC pursuant to s.246(1) CJA 2003. This power is subject
to s.246(4) CJA 2003 which provides that s.246(1) CJA 2003 does not apply, amongst other situations, if
“the prisoner is liable to removal from the United Kingdom” (s. 246(4)(f) CJA 2003).

34. Section 259 CJA 2003 defines a person as liable to removal from the United Kingdom if, inter alia, he
is liable to deportation under s.5 of the Immigration Act 1971 and has been notified of a decision to make a
deportation order against him.

35. The exercise of the Secretary of State for Justice's power to release on HDC is delegated to the
Governors or Directors of the prisons. The HDC Framework defines the exercise of this delegated power
(R (Boparan v Governor of HMP Stoke Heath [2019] EWHC 23353 (Admin)). The HDC Framework was
updated on 6 June 2023, but its amendments do not affect this Claim.

36. In relation to a prisoner where the immigration status is unclear, Paragraph 4.2.2(ii) provides that the
prison should send the HDC-FNP form to the Home Office “in order to establish the current position”.

37. Mr. Hodivala emphasises “establish” as importing the approach that the Prison should take to the
information from the SSHD. AA points to the rest of the HDC Framework and its duty pursuant to Secretary
_of State for Education and Science v_ _Tameside Metropolitan Borough Council [1977] AC 1014to satisfy_
itself that it has all the information relevant to the exercise of its discretion in all the material circumstances.
AA states that it is law and fact.

38. Paragraph 4.3.1 of the HDC Framework confirms that foreign national prisoners are statutorily
excluded from HDC if they are “liable to deportation and a decision to deport has been served (i.e., not just
those with a Deportation Order)”.

39. Paragraph 4.3.6 of the 2021 HDC Framework/4.3.7 of the 2023 HDC Framework enables prisoners
considered unsuitable, even if statutorily eligible for HDC, to submit representations to the Director or
Governor as to exceptional circumstances


-----

**Questions**

40. The above informs my consideration of the two questions that I must address:

1. Is the claim academic?

2. If it is academic, are there good reasons in the public interest for it to continue?

**Academic Claim**

41. A claim will be academic “if the outcome does not directly affect the rights and obligations of the
[parties”: R (L) v Devon County Council [2021] EWCA Civ 358 at §62:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6274-6843-GXFD-82VB-00000-00&context=1519360)

“What do we mean when we describe a claim as 'academic'? A claim will be academic if the outcome does
not directly affect the rights and obligations of the parties. The matter has been put in a number of similar
ways in the authorities. In one private law case, _Sun Life Assurance Co. of Canada v. Jervis_ [1944] AC
111, Viscount Simon LC referred to "an academic question, the answer to which cannot affect the
respondent in any way", while in another, Ainsbury v. Millington [1987] 1 WLR. 379, Lord Bridge described
the case as one where "neither party can have any interest at all in the outcome of the appeal". In the
public law case of R v. Board of Visitors of Dartmoor Prison, Ex parte Smith [1987] QB 106, the applicant
was described by this court as "having no interest in the outcome", and similarly in R v Secretary of State
_for the Home Department, Ex parte Abdi [1996] 1 WLR 298, it was said that "the outcome of these appeals_
will not directly affect the applicants."

42. Courts should not opine on academic or hypothetical issues in public law cases other than in
exceptional circumstances where there is good reason in the public interest for doing so (R (Heathrow Hub
_Limited) v Secretary of State for Transport [2020] EWCA Civ 213 at §208). As Lord Slynn of Hadley said in_
_R v Secretary of State for the Home Department ex parte Salem [1999] 1 AC 450(at 456-457):_

“... The discretion to hear disputes, even in the area of public law, must, however, be exercised with
caution and appeals which are academic between the parties should not be heard unless there is good
reason in the public interest for doing so as for example (but only by way of example) where a discrete
point of statutory construction which does not involve detailed consideration of the facts, and where large
number of similar cases exist or are anticipated so that the issue will most likely need to be resolved in the
near future.”

43. Silber J reviews the authorities in R (Zoolife) v Secretary of State for the Environment, Food and Rural
_Affairs [2007] EWHC 2995 (Admin), at §§32-36 and so formulates that academic issues should not be_
determined by courts unless there are “exceptional circumstances”. As to what this means, he considers
two conditions that may be satisfied in this type of application:

“The first condition is in the words of Lord Slynn in Salem (supra) that "a large number of similar cases
_exist or anticipated" or at least other similar cases exist or are anticipated, and the second condition is that_
the decision in the academic case will not be fact-sensitive. If the courts entertained academic disputes in
the type of application now before the court but which did not satisfy each of these two conditions, the
consequence would be a regrettable waste of valuable court time and the incurring by one or more parties
of unnecessary costs.”

44. Silber J also referred to pressures on the Court and the need to apply the overriding objectives of the
CPR:

“These points are particularly potent at the present time where the Administrative Court is completely
overrun with immigration, asylum and other cases and where it would be contrary to the overriding
objectives of the CPR for an academic case to be pursued. After all one of those overriding objectives is
_"dealing with a case justly [which] includes, so far as is practicable ...(e) allotting to it an appropriate share_
_of the court's resources, while taking into account the need to allot resources to other cases"_ (CPR Part
1.1)...”

**Is the Claim academic?**


-----

45. Ms. Weston KC relies upon R v Secretary of State for the Home Department ex parte Salem [1999] 1
AC 450and argues that the Claim is not academic. She contends that AA, with her baby C, were unlawfully
deprived of consideration by the prison for HDC from 10 April 2023. She criticises the deferral of the prison
to the HDC-FNP form. Ultimately, she seeks to maintain that the decision is in place as the SSHD refused
in correspondence to accept that its characterisation of stage 1 deportation decision was unlawful.

46. The SSHD argues that there no longer is a decision to quash as the HNDC-FNP form completed on 13
April 2023 was withdrawn, together with other decisions.

47. The SSHD confirmed to the Prison on 14 July 2023 that there is no longer a deportation decision. It is
clear that there is no decision remaining for the Court to decide upon in relation to AA. Considering
remedies, a withdrawn decision is not one that exists for the Court to quash.

**Are there good reasons in the public interest for it to continue?**

48. This is a more complex consideration. The confusion in decision making by the SSHD is apparent by
its accepted errors.

49. However, Ms. Reeves on behalf of the SSHD argues that, despite the errors, the law in this area is
clear and that a stage 1 deportation decision is a decision that renders a person ineligible for HDC by
operation of s.259 CJA 2003.

50. Ms Reeves in her amended summary Grounds of Defence submitted that there is not a two-stage test
and that the law has changed post the authorities relied upon by AA, namely _R (Mormoroc) v The_
_Secretary of State for Justice_ _[2017] EWCA Civ 989 and_ _R (Serrano) v Secretary of State for Justice &_
_[Anor [2012] EWHC 3216 due to the Immigration Act 2014. She argues that the Court of Appeal's decision](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
in Momoroc is not authority (binding or otherwise) for the proposition that a stage 1 deportation decision is
not a decision to deport as it was decided under a different legal framework.

51. In summary, the position of the SSHD remained that post the _[Immigration Act 2014,which changed](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
appeal rights, the decision to deport was taken at stage 1 whilst the taking of further representations was to
determine whether deportation remained appropriate. Ms. Reeves argued that there is nothing
objectionable to the stage 1 decision letter having two purposes, namely notice of liability under the EEA
[Regulations 2016 and notice of a decision to deport under the Immigration Act 1971 and Borders Act 2007.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

52. In my view, this approach emasculates the appeal rights within the EEA Regulations 2016. It certainly
creates confusion which impacts upon a consistent application of the HDC. Law which becomes arbitrary in
its application loses its grounding in equal justice.

53. Sodexo remains neutral as to the dispute between AA and the SSHD, save that Mr. Hodivala KC does
not accept that wider issues under s.11 Children Act 2004 are within the Claim. He also submitted that,
whatever the decision in relation to the SSHD, there can be no Claim against Sodexo who is required by
the HDC Framework to rely on information from the SSHD when considering eligibility for HDC, exercising
their delegated power from the Secretary of State for Justice.

54. Ms. Weston KC, relying on _Zoolife, argued that this is a case where there are “a large number of_
similar cases” in existence or that are anticipated. She relies on the evidence of Mr. Stern who refers to
information from a Freedom of Information request from the Howard League to the Ministry of Justice. The
prison population of those under 21 years old was 29,791 in 2022 with 12% of the total prison population
comprising foreign national offenders as of March 2023. In principle, therefore, he states that there could
be around 3,000 prisoners eligible for HDC at any one time.

55. The statistic does not provide a break down of those remanded in custody and those serving
sentences. Whilst I do not rely on a figure of around 3,000 people, Mr. Stern refers to having in excess of
200 deportation cases where a stage 1 letter has been served. He states that not all were in custody and
not all would have been eligible for HDC. However, he points to the barriers to those in prison to access
immigration representatives and they are most often instructed in deportation cases months after the Stage
1 or Stage 2 letters have been served. This means that the need to consider HDC is superseded by the
d t ti ti it lf M St i t t ff d b i i th t f di t d HDC


-----

56. Mr. Stern provides examples of six cases from across four different places of detention. The SSHD
complains that the part anonymisation of these cases means that they cannot be investigated. However,
the information provided is sufficient to show that there is confusion as to whether the combined stage 1
letter means that the person is not or no longer eligible for HDC and within the cases there are examples of
bail being used as a work around when a person's pending immigration status prevents their release.

57. One case cited relates to a young person who is an EU national with ADHD and learning difficulties
who received a combined stage 1 letter. The Governor's decision not to release the person on HDC
appears to be because they thought the Home Office was still pursuing deportation. Another case referred
to by Mr. Stern also contained a letter from the prison after the service of a combined stage 1 letter that:
“although you are eligible by law, you are presumed unsuitable for the scheme because your immigration
status is not clear.”

58. Mr. Stern draws conclusions from the cases he reviewed as showing that the effect of Stage 1 letters
on HDC is inconsistent and contradictory and points to a culture whereby uncertainty as to immigration
status automatically excludes the prisoners from HDC. I note that in some of those cases, there is still
consideration of “exceptional circumstances”. However, the confused approach leads to a haphazard
consideration of foreign national offenders' cases, some of whom have specific vulnerabilities, such as in
the case of AA.

59. During the hearing, I was further referred to another case of a judicial review of a Governor's decision
refusing HDC where the SSHD were not pursuing deportation. I received more details of the case
subsequent to the hearing including that the detainee had received a stage 1 decision letter (in a non-EEA
case).

60. Ms. Reeves in oral submissions emphasised that all cases were fact sensitive. In summary, Ms.
Reeves's position is that there are no exceptional circumstances to further consider this Claim.

61. Further, she argues that any further remedy open to AA, such as damages, which have not been
sought in these proceedings, should be pursued in the County Court.

62. The circumstances of the case of AA are worthy of a pause and of highlighting. She was a vulnerable
young woman with a baby, found to be a victim of **_modern slavery and enduring her first experience of_**
detention. The obvious confusion by the SSHD as to whether she was the subject of a deportation decision
or whether she was liable to deportation and so eligible for HDC impacted negatively upon AA's
resettlement outside prison. The Director of the Prison, seeking information from the SSHD on the
immigration status of AA, similarly was confused by the information and made his own errors in the
process.

63. I take into account Mr. Stern's evidence that many similar cases do not reach advice stage and by the
time the decision at the Stage 1 is considered the prospect of HDC has been overtaken by other decisions.
Further the specific confusion arises from the combined letter which addresses the EEA Regulations 2016
[and a decision to deport under the Immigration Act 1971. In addition, this decision making, according to Mr.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
Stern, primarily affects those prisoners who are under 21 years old.

64. These are exceptional circumstances in that they relate to predominately young and vulnerable people
who are being detained, with SSHD and individual prison Governors confused and inconsistent in whether
they are eligible for HDC after the combined stage 1 letter is served on a detainee. I consider that it is in
the public interest for this Claim to continue albeit expedition is no longer required. I agree with
submissions that the SSHD should be given sufficient time to reflect on its position, consider the combined
stage 1 form and submit its Detailed Grounds of Defence and any evidence it seeks to rely upon.

65. In relation to Sodexo, I find force in the arguments advanced, including that AA's pleaded case relates
to the Director's decision in her particular case and so illustrates that this case is one which is fact sensitive
at that point. I do not find the second Zoolife criteria to be satisfied and so stay the Claim against Sodexo.

**End of Document**


-----

