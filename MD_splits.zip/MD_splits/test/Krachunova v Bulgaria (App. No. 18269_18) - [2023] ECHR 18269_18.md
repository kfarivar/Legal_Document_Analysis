# Krachunova v Bulgaria (App. No. 18269/18) [2023] ECHR 18269/18

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE PASTOR VILANOVA (PRESIDENT), JUDGES SCHUKKING, GROZEV, PAVLI, KTISTAKIS, ZÜND,
MJÖLL ARNARDÓTTIR; AND CHERNISHOVA (DEPUTY SECTION REGISTRAR)

3, 31 October 2023

28 NOVEMBER 2023JUDGMENTTABLE OF CONTENTS

**INTRODUCTION** **1**

**THE FACTS** **1**

I. THE APPLICANT'S PERIOD OF SEX WORK 2

II. CRIMINAL PROCEEDINGS AGAINST X 4

A. Pretrial investigation 4

B. Original trial and first appeal 5

C. Retrial and second appeal 6

**RELEVANT LEGAL FRAMEWORK** **8**

I. BULGARIAN LAW 8

A. The offence of trafficking in human beings 8

B. The offence of inciting prostitution 10

C. The offence of earning income in a prohibited or immoral way 10

1. Text of Article 329 § 1 of the 1968 Criminal Code 10

2. Case-law under Article 329 § 1 in relation to prostitution 11

3. Government plans to have Article 329 § 1 repealed 12

4. Constitutional challenge against Article 329 § 1 12

D. Forfeiture of the proceeds of an offence upon conviction 14

E. Tort claims in respect of earnings from an unlawful activity 15

1. In civil proceedings 15

2. In criminal proceedings 15

F. Contracts infringing good morals 16

G. Compensation from the State for the victims of crimes 16

H. Relevant rules of criminal procedure 17

1. Role of the victim in the pretrial investigation 17

2. Role of the private prosecutor in the judicial phase of the proceedings 17

3. Role of a civil claimant in the judicial phase of proceedings 18


I. Reopening of criminal proceedings on the basis of a judgment in which the Court finds a breach of the
Convention


19


II. INTERNATIONAL MATERIAL 19

A. United Nations 19


1. Protocol to Prevent, Suppress and Punish Trafficking in Persons Especially Women and Children (“Palermo
Protocol”)


19


2. Model Law against Trafficking in Persons 20

3. Relevant resolutions and recommendations 20

4. Legislative Guide on the Palermo Protocol 21

5. Basic principles regarding the right to an effective remedy for victims of trafficking in persons 21

B. Council of Europe 21


-----

1. Convention on Action against Trafficking in Human Beings 21

2. Recommendation No. R (2000) 11 22

3. Recommendation 1545 (2002) 22

4. Resolution 1983 (2014) 23

C. Association of South-East Asian Nations 23

III. ELEMENTS OF COMPARATIVE LAW 23


A. Claims for compensation by trafficking victims against their traffickers in respect of lost earnings or unpaid
wages


23


1. Member States of the Council of Europe 23

2. United States of America 28

(a) Federal law 28

(b) State law 29

3. Canada 30

B. Validity and enforcement of sex-work contracts 31

**RELEVANT INTERNATIONAL REPORTS** **31**

**THE LAW** **32**

I. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION 32

A. Admissibility 32

1. The parties' submissions 32

(a) The Government 32

(b) The applicant 33

2. The Court's assessment 34

(a) Compatibility ratione materiae 34

(b) Exhaustion of domestic remedies 34

(c) Conclusion on the admissibility of the complaint 35

B. Merits 35

1. Submissions of the parties and the third party 35

(a) The applicant 35

(b) The Government 36

(c) The third party, GRETA 37

2. The Court's assessment 37

(a) Was the applicant a victim of trafficking in human beings for the purposes of Article 4 of the Convention? 37


(b) Is there a positive obligation under Article 4 of the Convention to enable victims of trafficking in human
beings to claim compensation from their traffickers in respect of lost earnings?


40


(i) General principles guiding the Court's interpretative approach 41

(ii) Interpretation arising from the object and purpose of Article 4 43

(iii) Does that interpretation find support in the relevant international instruments? 45


(iv) Does that interpretation find support in a common approach or developing consensus between the
Contracting States?


46


(v) Conclusion 46

(c) Was the dismissal of the applicant's claim for damages against X in breach of that positive obligation? 47

(i) General principles regarding States' duty to comply with positive obligations 47

(ii) Application of those principles 48

II. APPLICATION OF ARTICLE 41 OF THE CONVENTION 51

A. Pecuniary damage 51

1. The applicant's claim and the Government's comments on it 51

2. The Court's assessment 51

B. Non-pecuniary damage 52

1. The applicant's claim and the Government's comments on it 52

2. The Court's assessment 52

C. Costs and expenses 52

1. The applicant's claim and the Government's comments on it 52

2. The Court's assessment 53


-----

**INTRODUCTION**

1. The case concerns mainly two questions: (a) whether Article 4 of the Convention lays down a positive obligation
to enable the victims of trafficking in human beings to seek compensation in respect of lost earnings from their
traffickers, and (b) whether and in what circumstances such a positive obligation can be avoided in relation to
earnings obtained by the victim through prostitution and taken away by the trafficker.
**THE FACTS**

2. The applicant was born in 1985 and lives in the village of Koshava. She was represented by Ms N. Dobreva, a
lawyer practising in Sofia.

3. The Government were represented by their Agents, Ms I. Nedyalkova and Ms S. Sobadzhieva of the Ministry of
Justice.
_I. THE APPLICANT'S PERIOD OF SEX WORK_

4. Until April 2012 the applicant lived in a village with a population of just below 400 people situated in northwestern Bulgaria, with her parents and older sister. After graduating from secondary school, she briefly worked as a
seamstress. It appears that her relations with her parents were tense.

5. In April 2012, when the applicant was twenty-six years old, an acquaintance of hers put her in touch with X, a
thirty-one-year-old man from Novachene – a village about a 70-kilometre drive north-east of Sofia – whose main
occupation at that time was to drive prostitutes to and from their places of work. According to a report dated 5
March 2013 that was drawn up by a police officer in Novachene during the ensuing criminal proceedings against X,
he had been associating with pimps. According to information also obtained during those criminal proceedings, in
2003 X (a) had entered into a plea bargain with the prosecuting authorities in relation to a charge of aggravated
theft (allegedly committed in 1998), (b) had been arrested in connection with an instance of aggravated theft in
December 2011, (c) had paid social-security contributions for two months in 2006 and for four months in 2008, (d)
in 2012-15 had not declared any income to the tax authorities, (e) by 2016 owned three cars (an Audi A6, a
Volkswagen Golf, and a Renault Megane Scenic), and (f) in April 2016 had bought a one-storey house in
Novachene.

6. Following a row with her parents, the applicant met with X and agreed that she would go and live in his house,
where he lived with his de facto wife and four children. According to the subsequent findings of the Bulgarian courts
(see paragraphs 20 and 27-28 below), the applicant took the initiative in proposing the move. After a few days, X
told the applicant how much money could be earned through sex work on Sofia's ring road, and offered to drive her
there and back every day and let her continue living in his house free of charge. According to the applicant's
subsequent statement to the police (see paragraph 11 below), she agreed “because [she] needed the money and
was curious about whether she would be able to earn as much as the other girls”. X bought her clothes suitable for
sex work, instructed her on the usual prices charged for different sexual acts and on how she should interact with
clients, and told her that he would protect her from problems with clients or the police. It appears that for a brief
period the applicant and X had intimate relations; the applicant gave evidence during the course of X's retrial
indicating that such relations had occurred (see paragraph 23 below).

7. By May 2012, the applicant was working every day on Sofia's ring road. X would drive her there each day at
about 3 p.m. (hiding nearby and warning her of any approaching police cars), and then driving her back to his
house either at about 9 p.m. or after midnight (at about 1.30 a.m.) – depending on the weather. Police officers
patrolling the area briefly arrested the applicant on five occasions – on 15, 29 and 30 May and 16 and 19 June
2012.

8. By July 2012 the applicant wished to quit, but, according to her initial statement to the police (see paragraph 11
below), she was afraid of what X's reaction would be. It is unclear whether he ever threatened her. In that initial
police interview, she said that he had not done so, but at X's retrial (see paragraph 23 below), she stated – in
response to a direct question regarding whether she had ever been subjected to violence or threats – that he had
threatened that he would go to her village and take her back and that he had beaten her Later in July 2012 she


-----

ran away with a client, first to Plovdiv and then Burgas, and in late August 2012 went back to her village. She told
her family that she was working as a salesperson in a clothing shop; they apparently did not suspect the reality of
her situation.

9. Two or three days later X, apparently informed of the applicant's whereabouts by their mutual acquaintance (see
paragraph 5 above), came and, despite her protestations, persuaded her to go back with him to his house. He then
convinced her to resume sex work rather than go back to her parents' home – apparently with the argument that
neither he nor his wife had any other sources of income, apart from the welfare payments that his wife was
receiving from the social services for the children. According to the applicant's initial statement to the police (see
paragraph 11 below), at that time X took away her identity card, telling her that he was doing so in order that she
would not run away from him again. However, she also stated that he had not forced or coerced her to engage in
sex work, but had simply offered the opportunity to do so, and that she had had no choice in the matter.

10. From that point on, until 13 February 2013, the applicant resumed her daily shifts on Sofia's ring road. Police
officers patrolling the area briefly arrested her on seven occasions, on 3 and 12 August, 23 and 27 September, 19
October, 14 November 2012 and 11 February 2013. According to her, throughout that time X would take all her
earnings away from her but would buy the things that she needed and gave her pocket money. She did not tell him
that she wished to quit because she was afraid of him. On the evening of 13 February 2013, when she was again
working on Sofia's ring road, she again ran away (with a lorry driver). The next morning she called X and told him
that she no longer wished to engage in sex work. He threatened her that he would expose her real occupation to
the people in her village, and she agreed to go back to him, fearing in particular that her parents would learn that
she had been engaging in sex work.

11. At about 3 p.m. on 15 February 2013 X dropped the applicant off on Sofia's ring road. Twenty minutes later two
plainclothes police officers passed by in an unmarked police car and approached her. According to a report that one
of the officers drew up the same day and the officers' statements in the ensuing investigation against X, the
applicant told them that X was keeping her against her will and was holding her identity card, and that she no longer
wished to engage in sex work and needed help. The officers drove the applicant to a police station, where she was
interviewed. About an hour later X – after being summoned by the police – came to the station. bringing with him
the applicant's identity card, which he apparently routinely kept with him (the applicant gave evidence to that effect
in response to a direct question during X's retrial – see paragraph 23 below). He explained that the applicant had
given him the card so that it would not be stolen by clients.

12. On the same day, 15 February 2013, the police took the applicant to a crisis shelter in Sofia run by a foundation.
She was later transferred to a crisis shelter in Burgas. In June 2013 she was admitted to a psychiatric hospital for
treatment; she was released at the request of her parents, who took her back to their house.
_II. CRIMINAL PROCEEDINGS AGAINST XA. Pretrial investigation_

13. On 15 February 2013 the police opened a criminal investigation in relation to X.

14. Four days later, on 19 February 2013, the investigator interviewed the applicant in the presence of a judge. The
applicant did not have a lawyer. She stated, among other things, that X had been “protecting [her] from the police
and clients, in case some of them were drunk or drugged”, and he had for that reason retained her identity card, but
that had made her nervous because she had been unable to leave if she felt like it. X had not shouted at her or
forced her, because he had known that she would run away if he did that. He had, however, hit her on occasion: for
instance, the two had once gone out together with X's wife and the applicant had complained about the bar they
had been in and had asked if they could all go to a disco club instead; X had hit her twice after they had all returned
to the house. The applicant also said that she was afraid of X, who had telephoned her after 15 February 2013 to
tell her that he would come to get her again, and that she did not wish to talk to him or to continue working for him.

15. In March 2013 the investigator charged X with trafficking in human beings, contrary to Article 159a § 1 of the
Criminal Code, and with inciting the applicant to engage in prostitution for gain, contrary to Article 155 §§ 1 and 3 of
the same Code (see paragraphs 34 and 38 below).


-----

16. In April 2013 the investigator proposed to the Sofia district prosecutor's office that it indict X on those charges,
and in May 2013 that office did so. It noted that there were no grounds to seek the application of Article 53 of the
Criminal Code, which provides, under certain conditions, for the forfeiture of the proceeds of an offence (see
paragraph 52 below).

17. During the pretrial investigation, the applicant had no lawyer and took no part in procedural steps other than her
being interviewed (see paragraphs 11 and 14 above). The record of her first interview concludes with a statement
by the applicant that she was aware of her rights as a victim (see paragraph 60 below) and that she did not wish to
be acquainted with the material in the case file.
_B. Original trial and first appeal_

18. At the outset of X's trial in the Sofia District Court the applicant lodged an application for leave to join the
proceedings as a private prosecutor (see paragraph 62 below) and to lodge claims for damages against X. Her
claim for compensation for pecuniary damage, amounting to 16,000 Bulgarian levs (BGN – 8,181 euros (EUR)),
was based on the estimated earnings from prostitution that X had allegedly taken away from her. She also sought
BGN 8,000 (EUR 4,090) in respect of non-pecuniary damage. In support of her claim, the applicant stated, _inter_
_alia, that when X had fetched her back in August 2012, he had threatened to expose her to her co-villagers, which_
had caused her a great deal of disquiet. She also stated that she had felt powerless to surmount his influence and
pressure, and had felt worried about her safety when considering how to disengage from sex work a second time.

19. At the first hearing, the Sofia District Court gave the applicant permission to join the proceedings as a private
prosecutor (see paragraph 62 below) and to lodge a claim for compensation for non-pecuniary damage against X,
but stated that her claim for compensation for pecuniary damage could not be accepted for examination since it
concerned money earned through lewd and immoral acts. By law, the court could not award damages in respect of
such earnings. Moreover, the alleged loss was not among the elements of the offences of which X stood accused,
and thus did not have to be proved in the criminal proceedings against him. In the light of the court's remarks, the
applicant withdrew her claim for compensation for pecuniary damage.

20. In June 2014 the Sofia District Court found X guilty as charged. It sentenced him to a suspended term of two
years' imprisonment, imposed on him a fine of BGN 5,000 (EUR 2,556), and ordered him to pay the applicant BGN
2,000 (EUR 1,023) in compensation for non-pecuniary damage (прис. _от 11.06.2014 г._ _по_ _н._ _о._ _х._ _д._ _№ 9403/2013_
_г.,_ _СРС)._

21. The applicant appealed, arguing that X's sentence was too lenient and that the award of compensation for nonpecuniary damage was too low. She submitted, inter alia, that the Sofia District Court had failed to take into account
the fact that she had gone with X owing to her poor financial situation and that she had not consented to the
conditions in which she would engage in prostitution – in particular, that X would take away her earnings and retain
her identity card. Those were aggravating circumstances. Another aggravating factor was X's threat to expose her.

22. In October 2014 the Sofia City Court held that the lower court had failed to give proper and sufficiently
comprehensive reasons for its judgment as whole – both in relation to the witness evidence and in relation to the
elements of the offences of which X stood accused. It was hence necessary to quash its judgment as a whole and
refer the case back to it for re-examination rather than consider specifically the points raised by the applicant (реш.
_№ 1064 от 28.10.2014 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 3592/2014 г.,_ _СГС)._
_C. Retrial and second appeal_

23. In X's retrial, the applicant again applied for permission to join the proceedings as a private prosecutor (see
paragraph 62 below) and to lodge claims for damages against him.

24. She again sought BGN 8,000 (EUR 4,090) in respect of non-pecuniary damage. Her claim was chiefly based on
the anguish that she had allegedly felt on account of the impossibility of extricating herself from her situation, and
on account of the fear that X might punish her or take revenge on her and that her co-villagers might learn of her
having engaged in sex work. She reiterated her assertion that she had felt powerless to resist the influence and
pressure brought to bear by X, and had felt worried about her safety when considering how to disengage from sex
work a second time (see paragraph 18 above)


-----

25. The applicant's claim for compensation for pecuniary damage amounted to BGN 22,500 (EUR 11,504);
according to her lawyer, this was the applicant's lowest estimate of the sum that she had earned in the course of
her nine-month stint of sex work (she contended that she had been earning between BGN 2,500 and BGN 7,500 a
month). She asserted that X had been taking away all her earnings and using them to support himself and his
family, but that he had sheltered, clothed and fed her, and given her pocket money. In support of her claim, the
applicant argued, among other things, that prostitution was not an offence, since it was subject to taxation and had
not been expressly criminalised. That meant that a trafficking victim's earnings from prostitution were lawful and
subject to restitution by the trafficker.

26. The Sofia District Court again gave the applicant permission to join the proceedings as a private prosecutor
(see paragraph 62 below) and accepted for examination both claims for damages.

27. In January 2017 the court convicted X of trafficking in human beings, contrary to Article 159a § 1 of the Criminal
Code, but acquitted him of the additional charge (of inciting the applicant to engage in prostitution for gain) under
Article 155 §§ 1 and 3 of the Code, holding that that charge was encompassed by the main one (see paragraphs 34
and 38 below). It sentenced him to three years' imprisonment; the sentence was suspended but accompanied by
two probation measures (enrolment in professional qualification and community-treatment programmes), and the
court also imposed on him a fine of BGN 4,000 (EUR 2,045). It also ordered X to pay the applicant BGN 8,000
(EUR 4,090) in compensation for non-pecuniary damage (the full amount of her claim), but dismissed the
applicant's claim for compensation for pecuniary damage (прис. _от 12.01.2017 г._ _по_ _н._ _о._ _х._ _д._ _№ 20274/2014 г.,_
_СРС)._

28. The court found that X had (a) recruited the applicant twice, in April May and again in August 2012, (b)
harboured her between April and July 2012 and between August 2012 and 15 February 2013, and (c) been
transporting her between May and July 2012 and between August 2012 and 15 February 2013 with a view to
exploiting her by forcing her to engage in sexual acts. It also found that the applicant had been keeping part of the
money that she had received from clients but had been giving part of it to X, who had used that money as the main
source of income for his family, and that she had throughout that time been hesitant about whether she should be
engaging in prostitution, as this had been causing her discomfort and shame. The court held, _inter alia, that the_
question of whether the applicant had consented to engaging in sex work was irrelevant, in view of the nature of the
charge against X (namely, the basic offence set out by Article 159a § 1 of the Criminal Code – see paragraphs 34
and 36 below). Such consent mattered solely for the purpose of setting his sentence. The witness evidence
suggested that the applicant had been free to quit had she wished to do so – even if she had been somewhat
apprehensive of what X's reaction would be.

29. The court went on to hold that the applicant's claim for compensation for pecuniary damage could not be
allowed, for the following reasons:

“Each contract for sexual services made between the [applicant] and the respective client was void as
infringing good morals – section 26(1) [of the Obligations and Contracts Act 1950 – see paragraph 57 below].
This being so, the [applicant] has no right to receive the sums [stipulated] under those contracts, and there can
be no question of damages, within the meaning of section 45 of [the 1950 Act – see paragraph 53 below],
arising in this connection. This claim must therefore be dismissed.”

30. By contrast, the court found the applicant's claim for compensation for non-pecuniary damage well-founded to
its full extent.

31. The applicant appealed against the dismissal of her claim for compensation for pecuniary damage, reiterating
her submissions in relation to it (see paragraph 25 above). She also stated that the factors that had facilitated her
exploitation by X had included the lack of employment opportunities in her native village, the romantic relations
between the two of them at the outset of their acquaintance, and a hormonal disorder from which she had been
suffering at the time. In an additional written submission, she further argued that the lower court had not duly
substantiated its ruling that prostitution was contrary to good morals, this being a notion requiring a more detailed
analysis, given the circumstances of the case. The applicant further argued that the lower court's ruling that
tit ti i l h d t b ffi i tl b t ti t d b f t it i i th


-----

conservatism of some judges did not reflect the views of society as a whole. Moreover, given the fact that under
Article 53 of the Criminal Code the authorities could confiscate the profits realised by human traffickers (see
paragraph 52 below), trafficking victims were entitled to secure the restitution (to themselves) of such profits. Thus,
the refusal to award her compensation in respect of lost earnings had also been in breach of the Convention, as
construed by the Court.

32. In a final judgment of 5 December 2017 (реш. _№ 1328 от_ _05.12.2017г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 3947/2017 г.,_ _СГС),_
the Sofia City Court upheld the lower court's judgment. It fully agreed with the lower court's analysis of the evidence
and its findings of fact. Moreover, it agreed with the way in which the lower court had categorised the trafficking
offence committed by X. It also noted, however, that X had deceived the applicant and had offered her benefits with
a view to inducing her to engage in prostitution, and that the applicant had been deprived of the possibility to move
freely or to get in touch with her family, and had been hidden away in X's home. The court further held that the
lower court had correctly set the amount to be awarded as compensation for non-pecuniary damage, in view of, in
particular, the intensity of the coercion to which the applicant had been subjected. It also agreed with the lower
court that the applicant's claim for compensation for pecuniary damage was unfounded:

“This court finds that the [lower] court was correct to hold that the compensation for pecuniary damage sought
by the [applicant] in relation to the offence should not be awarded. The [applicant] is claiming from [X] earnings
obtained through lewd acts. It is beyond doubt that [X] benefited from those sums, but they are not to be
returned to the [applicant]. They must instead be forfeited, since Article 53 § 2 (b) of [the Criminal Code – see
paragraph 52 below] provides that the proceeds of the offence to which the conviction relates are liable to
forfeiture, unless [they are] subject to restitution. In the case at hand, those sums are not to be returned to the

[applicant], since they were obtained in an immoral manner that is prohibited by the law, as laid down in Article
329 § 1 of the Criminal Code [see paragraph 40 below].”

33. The court did not, however, make a forfeiture order. The Government explained that it had not been open to it to
do so, since the lower court had not made such an order either, and its judgment had been appealed against only
by the applicant and only in so far as it had concerned the dismissal of her claim for compensation for pecuniary
damage (see paragraph 31 above).
**RELEVANT LEGAL FRAMEWORKI. BULGARIAN LAWA. The offence of trafficking in human beings**

34. Article 159a § 1 was added in 2002 to the 1968 Criminal Code in order to, inter alia, ensure that Bulgaria would
fulfil its duties under Article 5 of the Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially
Women and Children, supplementing the United Nations Convention against Transnational Organized Crime (“the
Palermo Protocol” – see paragraph 67 below), which it had ratified in 2001. Article 159a § 1 made it an offence to
“recruit, transport, harbour or receive persons or groups of persons for the purpose of exploiting them for sexual
acts, forced labour or the removal of organs, or with a view to keeping them in servitude, irrespective of their
consent”. A September 2013 amendment added begging and the removal of bodily tissue, cells or bodily fluids to
the list of purposes featuring in the provision. The offence carries a penalty of two to eight years' imprisonment, plus
a fine ranging from BGN 3,000 to BGN 12,000.

35. Under Article 159a § 2, an offence shall be deemed to be aggravated – and shall carry a penalty of three to ten
years' imprisonment, plus a fine ranging from BGN 10,000 to BGN 20,000 – if the act specified under the first
paragraph of Article 159a has been committed through, _inter alia, (a) coercion or deception, (b) abduction or the_
illegal deprivation of liberty, (c) an abuse of a position of vulnerability, or (d) promising, giving or receiving benefits.
Under Article 66 § 1 of the Code, only a sentence of up to three years' imprisonment may be suspended.

36. In an interpretative decision given in July 2009 (тълк. _реш._ _№ 2 от 16.07.2009 г._ _по_ _тълк._ _д._ _№ 2/2009 г.,_
_ВКС,_ _ОСНК), the Supreme Court of Cassation held, inter alia, that since Article 159a § 1 did not list the means by_
which a victim could be trafficked, an offence under that provision would be deemed to have been committed each
time one of the acts mentioned in it was carried out for one of the purposes specified in that provision. The “means”
referred to in the Palermo Protocol were listed as merely aggravating factors in Article 159a § 2. This meant that the
ambit of the basic offence created by the Bulgarian legislature was wider than that envisaged in the Palermo
Protocol. It also followed that the consent or cooperation of the trafficking victim did not exclude criminal liability for


-----

that trafficking. It was irrelevant how that consent had been obtained – freely or otherwise – or even whether the
victim had been the active party in the trafficking. Under Bulgarian criminal law, trafficking victims therefore included
people who had not been coerced into it through violence or other illegitimate means. The offence under Article
159a § 1 was deemed to have been committed whenever someone enlisted, persuaded or induced a victim to
follow him or her – even if that was achieved without resorting to deception, coercion, abduction, the illegal
deprivation of the liberty of the victim, abusing a position of vulnerability, or the promising, giving or receiving of
benefits. If one of those means had been used, the offence would be deemed to be aggravated, in line with Article
159a § 2. The manner in which the victim's consent had been obtained thus mattered only for the purposes of
determining whether the offence in question was a basic or an aggravated one.

37. If the basic offence of trafficking in human beings – which does not require that the “means” of trafficking be
identified (see paragraphs 34 and 36 above) – involves trafficking across a State border, it likewise carries a
harsher penalty: three to twelve years' imprisonment, plus a fine ranging from BGN 10,000 to BGN 20,000 (Article
159b § 1). If the aggravated version of the offence – that involving the use of “means” (see paragraphs 35 and 36
above) – is a cross-border one, it carries an even harsher penalty: five to twelve years' imprisonment, plus a fine
ranging from BGN 20,000 to BGN 50,000 (Article 159b § 2).
_B. The offence of inciting prostitution_

38. Under Article 155 § 1 of the 1968 Criminal Code, it is an offence to incite someone to engage in prostitution. If
the inciting has been done for gain, the offence shall be deemed to be aggravated (Article 155 § 3).

39. In its interpretative decision (referred to in paragraph 36 above), the Supreme Court of Cassation further held
that the respective offences under Article 159a § 1 and Article 155 §§ 1 and 3 of the Criminal Code overlapped
almost fully, the only difference being that trafficking in human beings was characterised by the lasting nature of the
exploitation, whereas inciting someone to engage in prostitution for gain implied more sporadic occurrences. Thus,
only in intermittent cases was the offence under Article 155 §§ 1 and 3 not encompassed by that under Article 159a
§ 1.
_C. The offence of earning income in a prohibited or immoral way1. Text of Article 329 § 1 of the 1968 Criminal Code_

40. Article 329 § 1 of the 1968 Criminal Code, as originally enacted and as amended in 1975, made it an offence for
an adult not prevented by a handicap from working not to engage for a prolonged period in “socially beneficial”
work, while at the same time obtaining “non-labour-derived” income in a “prohibited or immoral” manner. The
provision appears to have been inspired by the Soviet-law proscription against “social parasitism” (тунеядство);
the early case-law regarding the application of Article 329 § 1 referred to “parasitic life” and “parasitic elements”
(see реш. _№ 283 от 25.05.1972 г._ _по_ _н._ _д._ _№ 210/1972 г.,_ _ВС, II н._ _о.)._

41. At the time that Article 329 § 1 was enacted, Article 73 § 3 of the 1947 Constitution, which had been adopted
shortly after the establishment of the communist regime in Bulgaria, provided that “work [was] a duty and a matter
of honour for each citizen capable of work”, and that “each citizen [was] bound to carry out socially beneficial work
and [to] work in accordance with his or her energies and abilities”. In 1971 that provision was superseded by Article
59 § 1 of the 1971 Constitution, which provided that “every citizen capable of work is bound to engage in sociallybeneficial work in line with his or her abilities and qualifications”. The 1971 Constitution was repealed in July 1991,
following the end of the communist regime. Article 48 §§ 1, 3 and 4 of the 1991 Constitution provides that (a)
everyone has the right to work, (b) each person may freely choose his or her profession and workplace, and (c) no
one may be subjected to forced labour.

42. In a 1984 interpretative decision (тълк. _реш._ _№ 29 от 29.11.1984 г._ _по_ _н._ _д._ _№ 20/1984 г.,_ _ВС,_ _ОСНК), a_
plenary meeting of the Criminal Divisions of the former Supreme Court held, among other things, that work in
prohibited professions – which, as noted in the decision, at that time included entrepreneurship and private
business – was not “socially beneficial” within the meaning of Article 329 § 1 (paragraph 1 of the decision).
Paragraph 2 of the decision noted that, under Article 59 of the 1971 Constitution, work was not only a right but also
a duty for “each Bulgarian citizen”.
_2. Case-law under Article 329 § 1 in relation to prostitution_


-----

43. Point 1 of the operative provisions of the 1984 interpretative decision mentioned in paragraph 42 above stated
that income from prostitution or pimping was “immoral” for the purposes of Article 329 § 1. More recently, in 201012, the Supreme Court of Cassation confirmed that prostitution fell under that provision (see _реш._ _№ 140_ _от_
_29.04.2010 г._ _по_ _н._ _д._ _№ 73/2010 г.,_ _ВКС, III н._ _о.), and held that criminalising it in that way was not contrary to_
Article 8 of the Convention (see реш. _№ 231 от 17.05.2012 г._ _по_ _н._ _д._ _№ 663/2012 г.,_ _ВКС, III н._ _о.)._

44. It appears that between 1990 and the mid-2000s Article 329 § 1 was not resorted to. In more recent years
however, the regional courts in Blagoevgrad, Dobrich, Pazardzhik, Plovdiv, Stara Zagora, Varna and Vratsa have
also found people guilty of the offence under Article 329 § 1 in relation to income earned through engaging in
prostitution (see, among others, реш. _№ 293 от 05.10.2010 г._ _по_ _в._ _н._ _а._ _х._ _д._ _№ 1441/2010 г.,_ _ОС-Варна; реш._
_№ 312 от 21.10.2010 г._ _по_ _в._ _н._ _а._ _х._ _д._ _№ 1450/2010 г.,_ _ОС-Варна; реш._ _№ 321 от 02.11.2010 г._ _по_ _в._ _н._ _а._ _х._
_д._ _№ 1448/2010 г.,_ _ОС-Варна; реш._ _№ 292 от 03.11.2010 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 2331/2010 г.,_ _ОС-Пловдив; реш._
_№ 48 от 16.02.2011 г._ _по_ _в._ _а._ _н._ _д._ _№ 2037/2010 г.,_ _ОС-Варна; реш._ _№ 90 от 17.03.2011 г._ _по_ _в._ _а._ _н._ _д._ _№_
_185/2011 г.,_ _ОС-Варна; прис._ _от 30.03.2011 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 1022/2011 г.,_ _ОС-Стара_ _Загора; реш._ _№ 82_
_от 30.03.2011_ _г._ _по_ _в._ _а._ _н._ _д._ _№ 3116/2010_ _г.,_ _ОС-Пловдив;_ _реш._ _№ 109_ _от 18.04.2011_ _г._ _по_ _в._ _а._ _н._ _д._ _№_
_449/2011 г.,_ _ОС-Пловдив; реш._ _№ 252 от 26.07.2011 г._ _по_ _в._ _а._ _н._ _д._ _№ 928/2011 г.,_ _ОС-Варна; реш._ _№ 396_
_от 08.12.2011 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 1990/2011 г.,_ _ОС-Пловдив; реш._ _№ 57 от 23.02.2012 г._ _по_ _в._ _а._ _н._ _д._ _№_
_1797/2011 г.,_ _ОС-Варна; реш._ _№ 327 от 30.10.2012 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 1137/2012 г.,_ _ОС-Пловдив; реш._ _№_
_163 от 19.06.2013 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 600/2013 г.,_ _ОС-Варна; реш._ _№ 4 от 10.01.2014 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№_
_1309/2013 г.,_ _ОС-Стара_ _Загора; реш._ _№ 149 от 22.05.2015 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 347/2015 г.,_ _ОС-Варна; реш._
_№ 1693 от 24.03.2016 г._ _по_ _в._ _н._ _о._ _х._ _д._ _№ 20/2016 г.,_ _ОС-Благоевград; реш._ _№ 21 от 24.01.2019 г._ _по_ _в._ _а._
_н._ _д._ _№ 1366/2018 г.,_ _ОС-Варна; реш._ _№ 79 от 24.09.2020 г._ _по_ _в._ _а._ _н._ _д._ _№ 384/2020 г.,_ _ОС-Пазарджик, all_
final). In doing so, some of those courts rejected arguments that prostitution did not fall within the ambit of Article
329 § 1 because “companions” (that is, paid sexual partners) were subject to taxation (and that given that it was
subject to taxation, it was illogical for prostitution to be a criminal occupation) (see реш. _№ 25 от 10.04.2014 г._ _по_
_в._ _а._ _н._ _д._ _№ 99/2014_ _г.,_ _ОС-Враца, final), or because that provision did not criminalise prostitution in express_
terms (see реш. _№ 362 от 17.11.2011 г._ _по_ _в._ _а._ _н._ _д._ _№ 1603/2011 г.,_ _ОС-Варна;_ _реш._ _№ 31 от 28.03.2014 г._
_по_ _к._ _а._ _н._ _д._ _№ 71/2014 г.,_ _ОС-Добрич;_ _реш._ _№ 80 от 21.03.2016 г._ _по_ _в._ _а._ _н._ _д._ _№ 380/2016 г.,_ _ОС-Пловдив;_
_реш._ _№ 178 от 28.06.2018 г._ _по_ _в._ _а._ _н._ _д._ _№ 527/2018 г.,_ _ОС-Варна;_ and реш. _№ 260004 от 13.08.2020 г._ _по_
_в._ _н._ _о._ _х._ _д._ _№ 1129/2020 г.,_ _ОС-Стара_ _Загора, all final). In one case, however, a regional court voiced doubts_
that, in view of the repeal of the 1971 Constitution and Article 59 § 1 thereof (see paragraph 40 in fine above), and
in view of the absence of a similar duty under the 1991 Constitution for people to be in employment, Article 329 § 1
of the Criminal Code could be unconstitutional (see реш. _№ 254 от 14.12.2017 г._ _по_ _в._ _а._ _н._ _д._ _№ 1155/2017 г.,_
_ОС-Плевен, final)._
_3. Government plans to have Article 329 § 1 repealed_

45. In May 2020 the Bulgarian government issued a penal-policy concept paper for the period 2020-25 (link). That
paper stated, _inter alia, that, in view of its subject matter, the offence under Article 329 § 1 was unworkable in_
practice and was to be reconsidered with a view to it being repealed or reformulated (p. 11 in fine).
_4. Constitutional challenge against Article 329 § 1_

46. In June 2018 the applicant's lawyer proposed to the Supreme Bar Council that it ask the Constitutional Court to
declare Article 329 § 1 of the Criminal Code (see paragraph 40 above) to be contrary to Article 48 § 1 of the 1991
Constitution (which guarantees the right to work – see paragraph 41 in fine above). She pointed out, inter alia, that
it was often being used as a basis for penalising people trafficked for the purpose of sexual exploitation. In
September 2018 the Supreme Bar Council rejected the proposal.

47. However, in May 2022 the Chief Prosecutor requested the Constitutional Court to declare Article 329 § 1 of the
Criminal Code (see paragraph 40 above) contrary to the 1991 Constitution – in particular, the Constitution's Article
4 § 1 (which enshrines the principle of the rule of law) and its Article 48 § 1 (which guarantees the right to work –
see paragraph 41 in fine above). He argued that Article 329 § 1, which had been enacted under completely different
social and political conditions, was out of line with the notion of work as a right (which flowed from Article 48 § 1 of
the 1991 Constitution and various international-law instruments to which Bulgaria was party). He further submitted
that the notion of the right to work contrasted with the notion of work as a duty and as the sole source of a person's


-----

income; that notion had underpinned Article 73 § 3 of the 1947 Constitution and Article 59 § 1 of the 1971
Constitution and the totalitarian regime under which they had been adopted (see paragraph 41 above). The Chief
Prosecutor further argued that Article 329 § 1 was being used to penalise the victims of human trafficking, and in
this way did not accord with Articles 159a et seq. of the Criminal Code (see paragraphs 34-35 above). The Chief
Prosecutor asserted that Article 329 § 1 served as a basis for persecuting vulnerable people, led to a two-faced
attitude in respect of them, and hampered efforts to protect them under anti-trafficking legislation. Moreover, its
wording was too vague and lent itself to impermissibly wide interpretations.

48. All but one of the third parties invited to intervene in the proceedings before the Constitutional Court – the
Minister of Justice, the Supreme Court of Cassation, the Supreme Bar Council, the Association of Public
Prosecutors, the Bulgarian Helsinki Committee, the Bulgarian Lawyers for Human Rights foundation, and three
academic experts – supported the above-mentioned request of the Chief Prosecutor. Only the Minister of Internal
Affairs opposed it. The Supreme Court of Cassation noted that Article 329 § 1 had been aimed at enforcing a
totalitarian ideology and was out of line with the democratic and human-rights based legal system put in place in
Bulgaria after the end of the communist regime. For her part, the Minister of Justice submitted, inter alia, that the
possibility of prosecuting those engaged in prostitution had to be reassessed, since the people engaging in it were
in reality victims of sexual exploitation, and the law had to protect them.

49. On 27 September 2022 the Constitutional Court acceded to the Chief Prosecutor's request. It noted, inter alia,
that under Bulgarian law prostitution was not criminalised as such, that Article 329 § 1 of the Criminal Code (see
paragraph 40 above) had been enacted under social, political and economic circumstances that no longer
prevailed, and that that provision had sought to give effect to the now defunct constitutional duty to work. By
contrast, under the 1991 Constitution, work was only a right whose exercise could not be compelled. Criminal
sanctions for a failure to exercise that right constituted a far-reaching form of interference with it that could no longer
be constitutionally tolerated. Moreover, the language of Article 329 § 1 (in particular the word “immoral”) was too
vague, in breach of the constitutional requirement that criminal-law provisions be especially clear and predictable in
their application, and opened the way to selective and arbitrary law enforcement. A reference to “morality” was
permissible in other branches of the law, where it could be rendered more specific through settled case-law, but not
in a provision, such as Article 329 § 1, that defined a criminal offence. The court went on to note that the trend in
European and international law – reflected in the domestic provisions criminalising trafficking in human beings (see
paragraphs 34-36 above) – was to see prostitution not as reprehensible conduct by those engaging in it, but as a
form of their being exploited by others and as a breach of their human rights. Article 329 § 1 was based on a
different moral concept, and led to inconsistencies in law enforcement. It in effect gave some respite to those (such
as pimps and human traffickers) who exploited those engaged in prostitution, as it fed into their message to victims
to expect the authorities to punish rather than support them; by contrast, the perception of prostitution as a form of
exploitation would redirect the application of penal measures towards those engaging in such exploitation and
enable its victims to seek and obtain help. On that basis, the court found that Article 329 § 1 as a whole was
contrary to both Article 4 § 1 of the 1991 Constitution (which enshrines the principle of the rule of law) and Article 32
§ 1 of the 1991 Constitution (which guarantees the right to respect for private life) (see реш. _№ 13 от 27.09.2022_
_г._ _по_ _к._ _д._ _№ 8/2022 г.,_ _КС,_ _обн.,_ _ДВ,_ _бр. 79/2022 г.)._

50. One judge dissented in part. In his view, Article 329 § 1 was unconstitutional only in so far as it referred to an
“immoral” manner of obtaining income, since that categorisation rendered the provision impermissibly vague.

51. The Constitutional Court's judgment was published in the State Gazette on 4 October 2022, and, as provided by
Article 151 § 2 of the 1991 Constitution, came into effect three days later, with the result that thenceforth Article 329
§ 1 of the Criminal Code (see paragraph 40 above) ceased to apply.
_D. Forfeiture of the proceeds of an offence upon conviction_

52. Under Article 53 § 2 (b) of the 1968 Criminal Code, upon conviction – irrespective of the main penalty imposed
– the proceeds of the offence to which the conviction relates are liable to forfeiture, unless they are subject to
restitution. Under Article 246 § 2 of the 2005 Code of Criminal Procedure, the prosecuting authorities must
comment in the indictment on whether there are grounds to apply Article 53. In its judgment, the first-instance
criminal court must also (under Article 301 § 1 (9) of the same Code) rule on whether there are grounds to apply


-----

Article 53 of the Criminal Code. If it has not done so in its judgment, it may (under Article 306 § 1 (1) in fine of the
same Code) do so by adopting a supplementary decision.
_E. Tort claims in respect of earnings from an unlawful activity_

53. The general rules of the law of tort are set out in sections 45-54 of the Obligations and Contracts Act 1950.
Under section 45(1), everyone is obliged to make good the damage that he or she has, through his or her own fault,
caused to another. Under section 51(1), compensation is due in respect of all damage that is a direct and proximate
result of a tortious act.
_1. In civil proceedings_

54. In two judgments dating from 1966 and 1972, the former Supreme Court held that damages could be recovered
in tort in respect of lost earnings, but only if those earnings relate to a lawful activity (see _реш._ _№ 2313_ _от_
_08.11.1966 г._ _по_ _гр._ _д._ _№ 1646/1966 г.,_ _ВС, I г._ _о.,_ and реш. _№ 2538 от 23.10.1972 г._ _по_ _гр._ _д._ _№ 1482/1972 г.,_
_ВС, I_ _г._ _о.). In 2011 the Supreme Court of Cassation came to the same conclusion (see_ _реш._ _№ 799_ _от_
_22.06.2011 г._ _по_ _гр._ _д._ _№ 1666/2008 г.,_ _ВКС, I г._ _о.)._

55. In a decision of 25 February 2020, the Sofia District Court held that a claim for damages lodged by a sex worker
against her alleged pimp (who had pleaded guilty to organising a criminal gang engaging in trafficking in human
beings in earlier criminal proceedings) in respect of lost earnings from prostitution was inadmissible because it
concerned sums obtained in breach of Article 329 § 1 of the Criminal Code (paragraph 40 above) and contrary to
good morals (see опр. _№ 50496 от 25.02.2020 г._ _по_ _гр._ _д._ _№ 64718/2019 г.,_ _СРС). It appears that, following an_
appeal by the claimant, the decision was quashed by the Sofia City Court on procedural grounds (see _опр._ _№_
_11868 от 24.07.2020 г._ _по_ _в._ _ч._ _гр._ _д._ _№ 6173/2020 г.,_ _СГС). The Sofia District Court then dismissed the claim on_
the merits, on the same basis (see реш. _№ 20025572 от 29.03.2022 г._ _по_ _гр._ _д._ _№ 64718/2019 г.,_ _СРС). The_
claimant appealed, but the Sofia City Court upheld the lower court's judgment, on the (different) basis that (a) the
pimp had pleaded guilty to organising a criminal gang engaging in the trafficking of human beings rather than the
trafficking itself (the two being distinct offences), and that (b) the claimant had not otherwise made out her assertion
that she had indeed been trafficked personally by the defendant for the purposes of prostitution (see реш. _№ 1971_
_от 19.04.2023_ _г._ _по_ _в._ _гр._ _д._ _№ 5690/2022_ _г.,_ _СГС). It is unclear whether that appellate judgment was in turn_
challenged before the Supreme Court of Cassation.
_2. In criminal proceedings_

56. In July 2014 the Ruse District Court dismissed a claim for damages in respect of lost earnings that a sex worker
had lodged in criminal proceedings for trafficking against her pimp, on the grounds that the money which she had
earned through prostitution and which he had taken away from her was not to be returned to her but forfeited under
Article 53 § 2 (b) of the Criminal Code (see paragraph 52 above), and that she had earned that money in an
immoral and illegal manner, contrary to Article 329 § 1 of the same Code (see paragraph 40 above). The court then
proceeded to order the forfeiture of that money – EUR 11,350 and BGN 250 (see прис. _№ 144 от 17.07.2014 г._
_по_ _н._ _о._ _х._ _д._ _№ 615/2014 г.,_ _РС-Русе). Following an appeal by the sex worker, the Ruse Regional Court upheld_
that ruling, fully endorsing the lower court's reasoning (see _реш._ _№ 160_ _от 30.10.2014_ _г._ _по_ _в._ _н._ _о._ _х._ _д._ _№_
_555/2014 г.,_ _ОС-Русе). The appellate ruling on that aspect of the case (that is to say the question of whether the_
sex worker's claim for damages in respect of lost earnings was to be allowed or dismissed) was not amenable to
further appeal by the sex worker, and the Supreme Court of Cassation did not touch upon that point either (see
_реш._ _№ 170 от 13.05.2015 г._ _по_ _н._ _д._ _№ 308/2015 г.,_ _ВКС, I н._ _о.)._
_F. Contracts infringing good morals_

57. Under section 26(1) of the Obligations and Contracts Act 1950, contracts that are contrary to good morals are
void. It does not appear that, apart from the Sofia District Court's decision in the present case (see paragraph 29
above), the Bulgarian courts have ever ruled on whether a contract between a prostitute and a client in respect of
sex services is void by virtue of this rule. However, in 2013 a legal commentator opined that contracts “relating to
unregulated sexual services” would engage the rule (see М. Димитров, _Основанията_ _за_ _нищожност,_ Сиби,
2013 г., p. 229).


-----

58. Under section 34 of the same Act, each of the parties to a void contract must return to the other everything that
it has received from under that contract. It appears that it is unclear whether that rule (a) applies to contracts whose
performance by one of the parties has consisted in work or a service, or (b) is absolute or may in some situations
be set aside with reference to the Latin maxims “in pari causa turpitudinis cessat repetitio” and “nemo auditor
_propriam turpitudinem allegans” (see М._ Димитров, _Основанията_ _за_ _нищожност, Сиби, 2013 г., pp. 247-49 and_
251-52, and М. Малчев, _Унищожаемост_ _на_ _гражданскоправните_ _сделки,_ Сиела, 2013 г., pp. 244-57). The
latter was the position under the Bulgarian law of obligations as it stood until 1944 (see Б. Белазелков,
_Недействителност_ _на_ _правните_ _сделки, Сиби, 2023 г., p. 81)._
_G. Compensation from the State for the victims of crimes_

59. Under sections 3(3)(1), 13(1) and 14(1)(2) of the Assistance and Financial Compensation of the Victims of
Crime Act 2006 (“the 2006 Act”), a victim of, among other offences, human trafficking can obtain financial
compensation of up to BGN 10,000 (EUR 5,113) in respect of, inter alia, lost earnings. Regulation 20(2) of the 2006
Act's implementing regulations, issued in December 2016, provides that lost earnings may be proved by means of
(a) a sick-leave certificate; (b) a decision issued by a specialised disability-assessment medical commission; (c) a
certificate issued by the employer in respect of the amount of wages paid; (d) a certificate from the tax authorities in
respect of current employment agreements; or (e) a certificate from the social-security authorities in respect of the
level of sick leave indemnity paid. Under section 18(3) of the 2006 Act, a request for compensation must be made
within one year of the final judgment in the criminal proceedings against the offender.
_H. Relevant rules of criminal procedure1. Role of the victim in the pretrial investigation_

60. Article 74 § 1 of the 2005 Code of Criminal Procedure defines the victim of an offence as “the person who has

suffered pecuniary or non‑pecuniary damage as a result of the offence”. The victim may exercise his or her

procedural rights if he or she expresses the wish to take part in the pretrial proceedings (Article 75 § 3). Those
rights include the right to (a) participate in the pretrial investigation (in line with the rules of criminal procedure), (b)
make requests or objections, (c) challenge decisions to discontinue or stay the proceedings, (d) and have the
assistance of a lawyer (Article 75 § 1).

61. The Supreme Court of Cassation has held that determining the legal categorisation of the charges to be brought
in respect of a publicly prosecutable offence is the prerogative of the public prosecutor dealing with the case, and
that the victim is not entitled to influence that determination (see _реш._ _№ 353_ _от 02.10.2012_ _г._ _по_ _н._ _д._ _№_
_1208/2012 г.,_ _ВКС, III н._ _о.). It has also held that, except when the pretrial investigation has been discontinued or_
stayed, the victim cannot challenge before a court the legal categorisation of the offence, as determined by the
public prosecutor (see реш. _№ 460 от 06.11.2009 г._ _по_ _к._ _н._ _д._ _№ 497/2009 г.,_ _ВКС, I н._ _о.)._
_2. Role of the private prosecutor in the judicial phase of the proceedings_

62. Under Article 76 of the 2005 Code of Criminal Procedure, the victims of publicly prosecutable offences who
have suffered damage as a result of those offences are entitled to take part as private prosecutors in the judicial
phase of the criminal proceedings relating to those offences. Their role is to press charges alongside the public
prosecutor (Article 78 § 1), and they may, in particular, lodge requests or objections, and appeal against decisions
of the court if they consider that their rights or legitimate interests have been encroached upon (Article 79). The
1974 Code of Criminal Procedure contained nearly identical provisions (Articles 52, 54 § 1 and 55).

63. The Supreme Court of Cassation has consistently held that since private prosecutors constitute merely an
ancillary party to criminal proceedings alongside the public prosecutor, they cannot seek to determine the
parameters of such proceedings; in particular, they cannot (a) bring additional charges, (b) amend the charges
formulated by the public prosecutor, (c) object to the legal categorisation of the offence given in the indictment
lodged by the public prosecutor and seek a harsher legal categorisation, or (d) appeal in respect of such matters
(see реш. _№ 330 от 28.04.2004 г._ _по_ _н._ _д._ _№ 1031/2003 г.,_ _ВКС, III н._ _о.; реш._ _№ 486 от 22.10.2010 г._ _по_ _н._ _д._
_№ 503/2010 г.,_ _ВКС, III н._ _о.; реш._ _№ 397 от 06.10.2011 г._ _по_ _н._ _д._ _№ 1912/2011 г.,_ _ВКС, I н._ _о.; реш._ _№ 450 от_
_30.11.2011 г._ _по_ _н._ _д._ _№ 2007/2011 г.,_ _ВКС, I н._ _о.; реш._ _№ 557 от 09.01.2012 г._ _по_ _н._ _д._ _№ 2608/2011 г.,_ _ВКС, I_
_н._ _о.; реш._ _№ 240 от 4.06.2014 г._ _по_ _н._ _д._ _№ 634/2014 г.,_ _ВКС, III н._ _о.; реш._ _№ 94 от 12.05.2015 г._ _по_ _н._ _д._ _№_
_1826/2014 г.,_ _ВКС, I н._ _о.; реш._ _№ 417 от 11.12.2015 г._ _по_ _н._ _д._ _№ 905/2015 г.,_ _ВКС, III н._ _о.; реш._ _№ 471 от_
_26 01 2016 г по н д №_ _1415/2015 г_ _ВКС I н о ; реш №_ _73 от 11 04 2016 г по н д №_ _224/2016 г_ _ВКС I н_


-----

_о.; реш._ _№ 127 от 05.07.2019 г._ _по_ _н._ _д._ _№ 454/2019 г.,_ _ВКС, I н._ _о.; and реш._ _№ 62 от 20.05.2021 г._ _по_ _н._ _д._
_№ 158/2021 г.,_ _ВКС, I н._ _о.)._
_3. Role of a civil claimant in the judicial phase of proceedings_

64. Under Article 84 § 1 of the 2005 Code of Criminal Procedure, victims of offences who have suffered damage as
a result of those offences are entitled to take part as civil claimants in the judicial phase of the criminal proceedings
relating to those offences. They may, in particular, present evidence, make requests or objections, and appeal
against decisions of the court that infringe their rights or legitimate interests (Article 87 § 1). All those procedural
rights may, however, be exercised only to the extent necessary to prove the basis and the quantum of the civil claim
(Article 87 § 2). In particular, the civil claimant may appeal against a judgment on the merits of a criminal case only
in so far as it concerns his or her claim for damages (Article 318 § 5). The 1974 Code of Criminal Procedure
contained nearly identical provisions (Articles 60 § 1, 63 §§ 1 and 2, and 317 § 5).

65. The Supreme Court of Cassation has held that as a result of those limitations it is not open to a civil claimant to
appeal against the criminal liability part of a judgment (see реш. _№ 112 от 14.04.2009 г._ _по_ _н._ _д._ _№ 76/2009 г.,_
_ВКС, III н._ _о.) or have a say in the fixing of the sentence (see реш._ _№ 1102 от 9.01.2006 г._ _по_ _н._ _д._ _№ 549/2005_
_г.,_ _ВКС, I н._ _о.)._
_I. Reopening of criminal proceedings on the basis of a judgment in which the Court finds a breach of the Convention_

66. A criminal case may be reopened if a judgment of the Court finds a breach of the Convention that is of “material
importance for the case” (Article 422 § 1 (4) of the 2005 Code of Criminal Procedure). The Chief Prosecutor must
request such a reopening within a month of becoming aware of the Court's judgment (Article 421 § 2 of the Code).
A request for the reopening of a criminal case is to be examined by the Supreme Court of Cassation (Article 424 § 2
of the Code). In a recent judgment, that court reopened a case pursuant to such a request, even though the case
file had been destroyed owing to the expiry of the period during which it had by law to be preserved. It instructed the
relevant lower court to restore the case file and then to re-examine the case (see реш. _№ 237 от 11.02.2019 г._ _по_
_н._ _д._ _№ 1002/2018 г.,_ _ВКС, I н._ _о.)._
_II. INTERNATIONAL MATERIALA. United Nations1. Protocol to Prevent, Suppress and Punish Trafficking in_
_Persons Especially Women and Children (“Palermo Protocol”)_

67. The Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children,
Supplementing the United Nations Convention Against Transnational Organized Crime (“the Palermo Protocol”)
(2237 UNTS 319) was drawn up in 2000 and entered into force in 2003. One hundred and eighty-one States are
currently party to it. The Palermo Protocol is in force with respect to all member States of the Council of Europe.
Bulgaria ratified it in 2001 and it came into force with respect to it in 2003.[1] Article 6 § 6 of the Palermo Protocol
reads:

“Each State Party shall ensure that its domestic legal system contains measures that offer victims of trafficking
in persons the possibility of obtaining compensation for damage suffered.”

68. In interpretative notes on the Protocol, the _ad hoc_ committee that had drawn up the Protocol stated that the
expression “abuse… of a position of vulnerability” in Article 3 (a) of the Palermo Protocol was to be “understood to
refer to any situation in which the person involved has no real and acceptable alternative but to submit to the abuse
involved” (see A/55/383/Add.1, § 63).
_2. Model Law against Trafficking in Persons_

69. Article 28 § 3 (d) of the Model Law against Trafficking in Persons (link), published by the United Nations Office
on Drugs and Crime in 2009 in response to a request by the General Assembly of the United Nations to assist
States to implement the Palermo Protocol, reads:

“The aim of an order for compensation shall be to make reparation to the victim for the injury, loss or damage
caused by the offender. An order for compensation may include payment for or towards:

…


-----

(d) Lost income and due wages according to national law and regulations regarding wages;…”

_3. Relevant resolutions and recommendations_

70. In a December 2008 resolution in respect of trafficking in women and girls, the General Assembly of the United
Nations invited governments to take steps to ensure that trafficked women and girls “have access to… legal
assistance, including the possibility of obtaining compensation for [damage] suffered” (see A/RES/63/156, § 19).

71. In a June 2009 resolution, the United Nations Human Rights Council affirmed that it was “essential to place the
protection of human rights at the centre of measures taken to prevent and end trafficking in persons, and to…
provide access to adequate redress to victims, including the possibility of obtaining compensation from the
perpetrators” (see A/HRC/RES/11/3, § 1).

72. At its fourth meeting, held in October 2011, the Working Group on Trafficking in Persons (set up by the
Conference of the Parties to the United Nations Convention against Transnational Organized Crime to advise and
assist it in the implementation of its mandate with regard to the Palermo Protocol) recommended, _inter alia, that_
“States should consider that court-ordered and/or state-funded compensation may include payment for or
towards… [l]ost income and wages due [under] national law and regulations regarding wages” (see
CTOC/COP/WG.4/2011/8, § 51 (j)(iii)).

73. In a November 2020 document entitled “General Recommendation on trafficking in women and girls in the
context of global migration”, the Committee on the Elimination of Discrimination against Women recommended to
States, _inter alia, that they “[e]nsure that that trafficked women and girls have a legally enforceable right to_
affordable, accessible and timely remedies through the criminal, civil and labour courts and administrative
proceedings, including a right to compensation, back pay and other tailored reparations…” (see CEDAW/C/GC/38,
§ 101).
_4. Legislative Guide on the Palermo Protocol_

74. In 2020 the United Nations Office on Drugs and Crime published an updated legislative guide on the Palermo
Protocol (link). That guide noted (on p. 64) that the Working Group on Trafficking in Persons (see paragraph 72
above) had recommended that State-funded or court-ordered compensation for trafficking victims include payment
towards “[l]ost income and wages due [under] national law and regulations regarding wages”.
_5. Basic principles regarding the right to an effective remedy for victims of trafficking in persons_

75. In 2014 the United Nations Special Rapporteur on trafficking in persons, especially women and children, drew
up a document entitled “Basic principles on the right to an effective remedy for victims of trafficking in persons”
(A/69/269, pp. 18-23). Its purpose was to “promote normative clarity around trafficking and [help] flesh out the
substantive content of key rules and obligations” (A/69/269, p. 8, § 21). Principle B, entitled “Compensation”, reads,
in so far as relevant:

“10. States shall provide victims of trafficking in persons with compensation for any economically assessable
damages as appropriate and proportional to the gravity of the violation and the circumstances of each case.
Mere difficulty in quantifying damage shall not be invoked as a reason to deny compensation.

11. Forms of compensation include, as appropriate:

…

(d) Payment for material damages and loss of earnings, including loss of earning potential, lost income and due
wages according to national law and regulations regarding wages;…”

_B. Council of Europe1. Convention on Action against Trafficking in Human Beings_

76. The Council of Europe Convention on Action against Trafficking in Human Beings (2569 UNTS 33; CETS 197),
was drawn up in 2005. Bulgaria ratified it in 2007,[2 ] and it entered into force in 2008 It is currently in force with
respect to all member States of the Council of Europe and with respect to two non-member States: Belarus and
Israel. Its Article 15 § 3 reads:


-----

“Each Party shall provide, in its internal law, for the right of victims to compensation from the perpetrators.”

77. Paragraph 197 of the explanatory report to that Convention (link) says, in relation to Article 15 § 3:

“Paragraph 3 establishes a right of victims to compensation. The compensation is pecuniary and covers both
material injury (such as the cost of medical treatment) and nonmaterial damage (the suffering experienced).
For the purposes of this paragraph, victims' right to compensation consists in a claim against the perpetrators
of the trafficking – it is the traffickers who bear the burden of compensating the victims. If, in proceedings
against traffickers, the criminal courts are not empowered to determine civil liability towards the victims, it must
be possible for the victims to submit their claims to civil courts with jurisdiction in the matter and powers to
award damages with interest.”

78. Paragraphs 82-84 of the explanatory report elaborate on the “means” that form part of the definition of
“trafficking in human beings” in Article 4 (a) of that Convention:

“82. Fraud and deception are frequently used by traffickers, as when victims are led to believe that an attractive
job awaits them rather than the intended exploitation.

83. By abuse of a position of vulnerability is meant abuse of any situation in which the person involved has no
real and acceptable alternative to submitting to the abuse. The vulnerability may be of any kind, whether
physical, psychological, emotional, family-related, social or economic. The situation might, for example, involve
insecurity or illegality of the victim's administrative status, economic dependence or fragile health. In short, the
situation can be any state of hardship in which a human being is impelled to accept being exploited. Persons
abusing such a situation flagrantly infringe human rights and violate human dignity and integrity, which no one
can validly renounce.

84. A wide range of means, therefore has to be contemplated: abduction of women for sexual exploitation,
enticement of children for use in paedophile or prostitution rings, violence by pimps to keep prostitutes under
their thumb, taking advantage of an adolescent's or adult's vulnerability, whether or not resulting from sexual
assault, or abusing the economic insecurity or poverty of an adult hoping to better their own and their family's
lot. However, these various cases reflect differences of degree rather than any difference in the nature of the
phenomenon, which in each case can be classed as trafficking and is based on use of such methods.”

_2. Recommendation No. R (2000) 11_

79. In point 33 of its Recommendation No. R (2000) 11 on action against trafficking in human beings for the
purpose of sexual exploitation (link), the Committee of Ministers of the Council of Europe recommended to member
States that they “[e]nable the relevant courts to order offenders to pay compensation to victims”.
_3. Recommendation 1545 (2002)_

80. In point 10 decies (d) in fine of its Recommendation 1545 (2002) on the campaign against trafficking in women
(link), the Parliamentary Assembly of the Council of Europe expressed the view that “[o]ffenders should also pay
compensation to the victims of trafficking”.
_4. Resolution 1983 (2014)_

81. In its Resolution 1983 (2014) on prostitution, trafficking and modern slavery in Europe (link), the Parliamentary
Assembly of the Council of Europe expressed, inter alia, the following views:

“2…. It is necessary to step up efforts to curb this scourge [trafficking in human beings], allocating the
necessary resources and efforts towards prevention, investigation and prosecution, while ensuring that freeing
victims from this modern form of slavery and restoring their rights and dignity remain at the centre of actions
undertaken.

3. Although they are distinct phenomena, trafficking in human beings and prostitution are closely linked. It is
estimated that 84% of trafficking victims in Europe are forced into prostitution; similarly, victims of trafficking
represent a large share of sex workers. The lack of precise and comparable data on prostitution and trafficking


-----

makes it difficult to assess with accuracy the impact that different regulations on prostitution may have on
trafficking. However, considering the significant overlap between the two phenomena, the Assembly believes
that legislation and policies on prostitution are indispensable anti-trafficking tools.

…

5. Legislation and policies with regard to prostitution vary across Europe, ranging from legalisation to
criminalisation of prostitution-related activities….

…

8. The Assembly acknowledges that different legal approaches and cultural sensitivities make it difficult to
propose a single model of prostitution regulations that would fit all member States. It believes, however, that
human rights should be the main criteria in designing and implementing policies on prostitution and trafficking.”

_C. Association of South-East Asian Nations_

82. Article 14 § 13 of the Convention Against Trafficking in Persons, Especially Women and Children, of the
Association of South-East Asian Nations (ASEAN), which came into force in 2017, following its respective
ratification or approval by Cambodia, Myanmar, the Philippines, Singapore, Thailand and Vietnam (link), reads:

“Each Party shall ensure that its domestic legal system contains measures that offer victims of trafficking in
persons the possibility of obtaining compensation for damage suffered.”

_III. ELEMENTS OF COMPARATIVE LAWA. Claims for compensation by trafficking victims against their traffickers_
_in respect of lost earnings or unpaid wages1. Member States of the Council of Europe_

83. A 2008 report (entitled “Compensation for Trafficked and Exploited Persons in the OSCE Region”), published by
the Office for Democratic Institutions and Human Rights of the Organization for Security and Co operation in
Europe, noted (p. 39 in fine) that the possibility of compensation being rendered from profits or benefits obtained by
a trafficker was yet to be explored in the countries surveyed (Albania, France, the Republic of Moldova, Romania,
the Russian Federation,[3 ] Ukraine, the United Kingdom and the United States of America), although it was
considered by the United States of America (see, in respect of the latter point, paragraphs 110-113 below).

84. In 2020 GRETA began the third round of its monitoring of the implementation of the Anti-Trafficking Convention
(see paragraph 76 above) by the States Parties to it. That round focuses on the victims' access to justice and the
question of effective remedies. GRETA has so far published reports on twenty-one States Parties: Albania,
Armenia, Austria, Belgium, Bulgaria, Croatia, Cyprus, Denmark, France, Georgia, Ireland, Latvia, Luxembourg,
Malta, the Republic of Moldova, Montenegro, Norway, Portugal, Romania, the Slovak Republic, and the United
Kingdom. Most of those reports touched upon the question of whether trafficking victims could seek compensation
from their traffickers in respect of lost earnings or unpaid wages.

85. GRETA provided further information in respect of five States – Austria, Belgium, Germany, the Netherlands and
Norway – in its third-party submissions in the instant case (see paragraph 143 below), with special reference to
earnings from prostitution. That information has been set out below, in the respective paragraphs relating to each of
those States.

86. The report on Albania noted one first-instance decision in which a civil court had refused to order the trafficker in
question to repay money that the victim had earned for him (see GRETA(2020)09, § 70).

87. The report on Armenia noted that there were no specific criteria in respect of the calculation of compensation for
trafficking, that not a single victim had received compensation through criminal proceedings during the reporting
period, and that no victims had claimed compensation in civil proceedings (see GRETA(2022)05, §§ 71-73).

88. The report on Austria noted that anyone could claim unpaid wages through the Labour and Social Court, but
that GRETA had not been made aware of any such cases. It also cited two criminal cases in which traffickers had
been ordered to reimburse their victims for their earnings from the prostitution into which they had been forced (see
GRETA(2020)05 §§ 87 119 and 126) In its third party submissions (see paragraph 143 below) GRETA noted that


-----

the Vienna Regional Court for Criminal Matters had delivered several judgments, including the two abovementioned criminal cases, in which loss of earnings from exploitation for the purposes of prostitution had been
included in the lump-sum compensation awarded to victims.

89. The report on Belgium noted that the damage suffered by victims of trafficking for the purpose of labour
exploitation could include loss of wages, which was calculated by the labour inspectorate on the basis of the
calculation scale used in Belgium, and that a review of the relevant case-law showed that awards to victims were
sometimes considerable – particularly in respect of pecuniary losses in labour exploitation cases (see
GRETA(2022)11, §§ 79 and 83). In its third-party submissions (see paragraph 143 below), GRETA cited five
criminal cases dating from 2017-19 in which victims had been awarded compensation for unpaid earnings from
exploitation for the purposes of prostitution.

90. The report on Bulgaria mentioned the Sofia City Court's judgment in the present case (see paragraph 32 above)
and the decisions mentioned in paragraphs 55-56 above, and on that basis concluded that victims could not claim
compensation for money that they had been forced to earn from prostitution and then hand over to their traffickers
(see GRETA(2021)04, § 90 and fn. 53).

91. The report on Croatia noted that the authorities had not reported cases in which victims had sought
compensation from traffickers in criminal proceedings (see GRETA(2020)10, § 73).

92. The report on Cyprus noted that by law victims could claim compensation from traffickers, including for unpaid
salaries (see GRETA(2020)04, §§ 55 and 60).

93. The report on Denmark noted that by law victims could claim unpaid wages from traffickers and cited one such
case (see GRETA(2021)05, §§ 60-61 and 65).

94. The report on France noted that by law anyone could seek the payment of unpaid wages through an
employment tribunal, and that GRETA had been informed by civil-society actors that victims of trafficking for the
purpose of sexual exploitation could not claim from traffickers the reimbursement of their earnings from the
exploitation of prostitution because prostitution was not considered to constitute employment; however, the report
also noted that according to the authorities that possibility was not actually excluded by any law or case-law (see
GRETA(2022)01, §§ 81 and 93). In that report, GRETA stated that “to deny victims of sexual exploitation
compensation from traffickers in respect of loss of earnings on that ground would run contrary to the object and
purpose of the international instruments set up to provide effective protection to victims of all forms of human
trafficking, in particular Article 15 of the Anti-Trafficking Convention” (ibid., § 81 _in fine). In its third-party_
submissions (see paragraph 143 below), GRETA cited a September 2020 judgment of the Paris Court of Appeal
that had awarded compensation for pecuniary damage to a victim who had been illegally employed for seven years
as a domestic worker without receiving a salary.

95. The report on Georgia contained no information regarding the question of whether trafficking victims may seek
compensation from their traffickers in respect of lost earnings or unpaid wages (see GRETA(2021)02, §§ 54-59).

96. In relation to Germany, GRETA cited in its third-party submissions (see paragraph 143 below) a 2014 case in
which a criminal court had ordered a trafficker to pay the victim compensation for withheld earnings from
exploitation for the purposes of prostitution.

97. The report on Ireland noted that no victim had received compensation from a trafficker in Ireland owing to the
fact that, until June 2021, no one had ever been convicted for trafficking, Moreover, if victims had not been
employed under a contract, they would not be able to lodge a claim with the adjudication service of the Workplace
Relations Commission, which only dealt with claims by people who were legally employed (see GRETA(2022)12,
§§ 72 and 75-76).

98. The report on Latvia noted that by law victims could claim compensation or the recovery of unpaid wages and
social contributions through civil proceedings, and cited one such pending case. It also cited a pending trafficking


-----

criminal case in which the question of compensation for unpaid wages had been raised (see GRETA(2022)02, §§
66 and 82).

99. The report on Luxembourg noted that according to case-law claims for unpaid wages were apparently excluded
from the jurisdiction of the criminal courts, and that victims thus had to bring such claims before an employment
tribunal. The report also noted that according to the authorities, victims of sexual exploitation could in theory seek
compensation for sums that they had been forced to earn through prostitution and then give to traffickers, but that
there were no examples of judgments on such matters (see GRETA(2022)13, §§ 61 and 64).

100. The report on Malta noted, on the one hand, that no victim of trafficking had ever been awarded compensation
in Malta (be it in criminal or civil proceedings), but that by law a foreign victim in irregular employment could claim
unpaid wages. On the other hand, the report went on to say that victims could seek the payment of unpaid wages in
criminal proceedings, and that during the reporting period victims had successfully sought the back payment of
wages in three sets of criminal proceedings. The report also noted that prostitution was legal in Malta, but that
loitering and soliciting clients were criminal offences (see GRETA(2021)10, §§ 75 and 77-78 and fn. 92).

101. The report on the Republic of Moldova noted that by law pecuniary damage comprised profit lost as a result of
a breach of a right and that the law lay down criteria for assessing compensation for lost salary or income (see
GRETA(2020)11, §§ 74-75).

102. The report on Montenegro noted that thus far no court had ordered any traffickers to pay compensation to their
victims (see GRETA(2021)08, § 69).

103. In relation to the Netherlands, GRETA cited in its third-party submissions (see paragraph 143 below) three
criminal cases dating from 2020 in which traffickers had been ordered to pay their victims substantial compensation
for pecuniary damage in respect of withheld earnings from prostitution; that compensation had been calculated on
the basis of information about the hourly rates that the victims' clients had been charged and the average number of
days per week and per year on which the victims had worked.

104. The report on Norway cited two cases in which victims had been awarded compensation for lost wages, and
noted that under a recently enacted law the Labour Inspection Authority could order the payment of unpaid wages
(see GRETA(2022)07, §§ 74, 90 and 152, and fn. 61). In its third-party submissions (see paragraph 143 below),
GRETA cited a 2016 judgment of the Supreme Court of Norway (Norges Høyesterett) (HR-2016-2491-A) in which it
had allowed claims lodged by victims against traffickers for the repayment to them of their earnings from
prostitution. In that judgment, that court held, with reference to Article 6 of the Palermo Protocol and Article 15 of
the Anti-Trafficking Convention (see paragraphs 67 and 76 above), that it was not decisive that the claims related to
such “a harmful and undesirable activity” as prostitution. The claims did not concern illegal acts, since the sale of
sexual services was not unlawful in Norway. The key point was that the money had been obtained by way of
trafficking. When assessing whether the victims' claims should be upheld, the emphasis had to be on the
interference with their freedom and personal integrity. It was inconsistent with the desire to protect trafficking victims
to preclude them from seeking lost income from their traffickers (judgment cited, §§ 87-92).

105. The report on Portugal noted that claims for compensation could encompass unpaid salaries, as this
constituted material damage suffered on account of exploitation (see GRETA(2022)08, § 80 in fine).

106. The report on Romania noted, without citing specific cases, that by law the compensation for pecuniary
damage that a trafficker could be ordered to pay could comprise unpaid wages, and be awarded when victims had
not been paid or had been paid an unreasonably low amount (see GRETA(2021)09, § 73).

107. In respect of Serbia, GRETA cited in its third-party submissions (see paragraph 143 below) a 2018 firstinstance criminal judgment that had awarded to a victim of the offence of “the facilitation of prostitution” part of the
sums which she had earned as a waitress but which the offender had not paid.

108. The report on the Slovak Republic noted that there was no methodology for calculating compensation in cases
of labour exploitation (see GRETA(2020)05, § 69).


-----

109. The report on the United Kingdom noted that in England and Wales civil claims against an employer
constituted in principle an avenue that was available to victims of forced labour or domestic servitude in respect of
underpaid or unlawfully deducted wages (see GRETA(2021)12, § 117). In its third-party submissions (see
paragraph 143 below), GRETA went on to refer to the case of Hounga v Allen [2014] UKSC 47. In that case, the
Supreme Court of the United Kingdom unanimously allowed a tort claim lodged by a claimant – whom the majority
of the five judges who heard the case saw as a victim of human trafficking – against her employer for abusive
dismissal. The court held that the employer could not rely on the so-called “defence of illegality” (sometimes
expressed through the Latin maxim ex turpi causa non oritur actio) to defeat the claim. The employer's arguments
were based on the fact that the claimant, an alien, had known that she had entered the country on false pretences
and could not remain legally in the country beyond a certain date. It had thus been unlawful for her to take up
employment in the United Kingdom, and that illegality formed a material part of her claim. The majority held that it
would run counter to the United Kingdom's obligations under Article 15 § 3 of the Anti-Trafficking Convention (see
paragraph 76 above) for its law to cause the claim to be defeated by the “defence of illegality”, and that doing so
would run “strikingly counter to the prominent strain of current public policy against trafficking and in favour of the
protection of its victims”. The public policy that supported the application of the “defence of illegality” (to the extent
that that public policy existed at all) had to give way to the public policy against trafficking. In reaching this
conclusion, the majority of the five judges also had regard to the way in which the Court had interpreted and applied
Article 4 of the Convention.
_2. United States of America(a) Federal law_

110. Section 1593 of Title 18 of the United States Code (18 USC 1593), inserted by the Trafficking Victims
Protection Act of 2000, is entitled “Mandatory restitution” and reads:

“(a) Notwithstanding section 3663 or 3663A, and in addition to any other civil or criminal penalties authorized
by law, the court shall order restitution for any offense under this chapter [which include human trafficking].

(b)(1) The order of restitution under this section shall direct the defendant to pay the victim (through the
appropriate court mechanism) the full amount of the victim's losses, as determined by the court under
paragraph (3) of this subsection.

…

(3) As used in this subsection, the term 'full amount of the victim's losses'… shall in addition include the greater
of the gross income or value to the defendant of the victim's services or labor or the value of the victim's labor
as guaranteed under the minimum wage and overtime guarantees of the Fair Labor Standards Act (29 U.S.C.
201 et seq.).”

111. The United States federal courts have held that restitution is mandatory under this provision (see United States
_v. Fu Sheng Kuo, 620 F.3d 1158, 1164 (9th Cir. 2010); In re Sealed Case, 702 F.3d 59, 66 (D.C. Cir. 2012); United_
_States v. Robinson, 508 F. Appx. 867, 870 (8[th ]Cir. 2013); and United States v. Culp, 608 F. Appx. 390, 392 (6[th ]Cir._
2015)). In relation to prostitution, the “value to the defendant of the victim's services” is normally calculated by
multiplying the victim's average daily earnings by the number of days on which the trafficker prostituted the victim
(see United States v. Lewis, 791 F. Supp. 2d 81 (D.D.C. 2011)). The federal courts have also held that since under
section 1593(b)(3) victims are entitled to the “gross income” derived from their trafficking, they may recover the full
sum obtained by traffickers, without offsetting any sums spent by the traffickers on their victims' living expenses
(see United States v. Williams, 5 F. 4th 1295, 1304-08 (11th Cir. 2021)).

112. Applying that provision in United States v. Mammedov, 304 Fed. Appx. 922 (2d Cir. 2008), the United States of
Court of Appeals for the Second Circuit held (at pp. 926-27):

“… Mammedov argues that the District Court's award of restitution was improper because the money earned
by Mammedov's victims, and for which the District Court ordered restitution, was the result of illegal conduct,
_i.e., prostitution. This argument lacks merit for two reasons. First, this argument ignores that, either through_
force, fraud or coercion, or the inducement of a minor, Mammedov _caused_ his victims to engage in illegal
conduct Given Mammedov's guilty plea he knew that 'force fraud or coercion' was 'used to cause [a] person


-----

to engage in a commercial sex act, or that [a] person ha[d] not attained the age of 18 years and [was] caused
to engage in a commercial sex act.' 18 U.S.C. § 1591(a). Even if they engaged in illegal conduct, the women
involved here were still Mammedov's victims. Second, 18 U.S.C. § 1593(a) provides that the court 'shall order
restitution for any offense under this chapter,' which includes sex trafficking as proscribed by 18 U.S.C. § 1591.
18 U.S.C. § 1593(a) (emphasis added). 'The order of restitution under this section shall direct the defendant to
pay the victim… the full amount of the victim's losses,' id. § 1593(b)(1), and those losses 'shall… include the
greater of the gross income or value to the defendant of the victim's services or labor or the value of the
victim's labor as guaranteed under the minimum wage and overtime guarantees of the Fair Labor Standards
Act.' _Id._ § 1593(b)(3). The term 'victim' is defined as 'the individual harmed as a result of a crime under this
chapter,' including sex trafficking. Id. § 1593(c). Thus, the express terms of 18 U.S.C. § 1593 require that the
victims in this case, i.e., persons who engaged in commercial sex acts within the meaning of 18 U.S.C. § 1591,
receive restitution, notwithstanding that their earnings came from illegal conduct….”

113. Applying the same provision in _United States v. Cortes-Castro, 511 Fed. Appx. 942 (11th Cir. 2013), the_
United States Court of Appeals for the Eleventh Circuit held (at p. 947):

“[The trafficker] argues that the order of restitution rewards the victims for their illegal activities, but this
argument is preposterous given that his victims were enslaved and forced to prostitute.”

_(b) State law_

114. In 2013 the National Conference of Commissioners on Uniform State Laws drew up a Uniform Act on the
Prevention of and Remedies for Human Trafficking (link). By March 2023, that model law had been enacted by nine
states (Delaware, Louisiana, Montana, New Hampshire, North Dakota, Pennsylvania, Rhode Island, South Carolina
and West Virginia) and one territory (the United States Virgin Islands). Its section 10, entitled “Restitution”, reads:

“(a) The court shall order a person convicted of an offense under Section 3, 4, or 5 [respectively trafficking,
forced labor and sexual servitude] to pay restitution to the victim of the offense for:

…

(2) an amount equal to the greatest of the following, with no reduction for expenses the defendant incurred to
maintain the victim:

(A) the gross income to the defendant for, or the value to the defendant of, the victim's labor or services or
sexual activity;

(B) the amount the defendant contracted to pay the victim; or

(C) the value of the victim's labor or services or sexual activity, calculated under the minimum-wage and
overtime provisions of the Fair Labor Standards Act, 29 U.S.C. Section 201 et seq.[, as amended,] or [cite state
minimum-wage and overtime provisions], whichever is higher, even if the provisions do not apply to the victim's
labor or services or sexual activity.”

115. An accompanying comment on that section of the model law states:

“At least twenty-one states (Alabama, Arizona, Delaware, Hawaii, Idaho, Illinois, Indiana, Michigan, Mississippi,
Missouri, New Hampshire, New Jersey, New Mexico, North Dakota, Oklahoma, Pennsylvania, Rhode Island,
South Carolina, Tennessee, Vermont, and Wyoming) mandate restitution to the victim of human trafficking.”

116. According to an April 2014 report (link) by AEquitas, a non-profit organisation based in Washington, DC, at that
time twenty-five states had statutes specifically requiring restitution for the victims of human trafficking, and that
restitution was to be calculated on the basis either of the gross income that had accrued to the trafficker from the
victim's services or of the value of the services provided by the victim.
_3. Canada_


-----

117. Under section 18(1)(b) of Alberta's Protecting Survivors of Human Trafficking Act 2020 (link), in respect of an
action brought in respect of trafficking, a court “may… order the defendant to account to the plaintiff for any profits
that have accrued to the defendant as the result of the human trafficking of the plaintiff”.

118. Under section 20(1)(b) of Manitoba's Child Sexual Exploitation and Human Trafficking Act 2012 (link), in an
action for trafficking the court “may… order the defendant to account to the plaintiff for any profits that have accrued
to the defendant as the result of the human trafficking of the plaintiff”.

119. Under section 16(1) of Ontario's Prevention of and Remedies for Human Trafficking Act 2017 (link), “[a] victim
of human trafficking may bring an action against any person who engaged in the human trafficking”. Section
17(1)(b) provides that the court's powers in such proceedings include “order[ing] the defendant to account to the
plaintiff for any profits that have accrued to the defendant as a result of the human trafficking”.

120. Under section 18(1)(b) of Saskatchewan's Protection from Human Trafficking Act 2021 (link), in an action for
trafficking the court “may…[,] with respect to any profits that have accrued to the defendant as a result of human
trafficking[,] (i) order the defendant to account to the plaintiff for those profits; and (ii) make an order in favour of the
plaintiff with respect to the recovery of those profits from the defendant”.
_B. Validity and enforcement of sex-work contracts_

121. A recent comparative-law survey of twenty-eight European legal systems found that, although in the vast
majority of those systems the point had not been directly tested in litigation, a contract between a sex worker and a
client would be certainly or probably unenforceable in twenty-three of them: Belgium, Bulgaria, Croatia, Cyprus, the
Czech Republic, Denmark, England, Estonia, France, Finland, Greece, Ireland, Italy, Lithuania, Malta, Poland,
Portugal, Romania, Scotland, Slovakia, Slovenia, Spain and Sweden. However, in three systems (France, Slovenia
and Spain) the sex worker could possibly obtain payment for the services provided under the rules governing
unjustified enrichment (in Spain, this remedial route would only be available in cases of dependency, abuse or
special vulnerability). In five systems (Austria, Germany, Hungary, Latvia and the Netherlands), the client's
contractual obligation to pay the agreed price for sexual services would most probably be valid and enforceable
(see A. Colombi Ciacchi, C. Mak and Z. Mansoor (eds.), Immoral Contracts in Europe, Intersentia, 2020, pp. 37-126
and 722-23).
**RELEVANT INTERNATIONAL REPORTS**

122. In its 2015 report on the implementation of the Anti-Trafficking Convention (see paragraph 76 above) by
Bulgaria (GRETA(2015)32), GRETA noted, in paragraph 165, that “[t]here [wa]s no information about any civil claim
submitted by a trafficked person before a civil court”.
**THE LAWI. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION**

123. The applicant complained that she had not had at her disposal a legal avenue via which to seek from X
compensation in respect of the earnings from prostitution that he had taken away from her. She relied on Articles 4
and 13 of the Convention.

124. Without yet pronouncing on whether Article 4 of the Convention applies and lays down a positive obligation
along the lines contended for by the applicant – points examined in due course below – the Court finds that the
issues raised by the complaint ought to be addressed from the perspective of that Article alone (see C.N. and V. v.
_France, no. 67724/09, § 113, 11 October 2012; C.N. v. the United Kingdom, no. 4239/08, § 86, 13 November 2012;_
and T.I. and Others v. Greece, 40311/10, § 97, 18 July 2019; see also, mutatis mutandis, S.M. v. Croatia [GC], no.
60561/14, §§ 241-42, 25 June 2020). In such scenarios, the complaints under Article 13 of the Convention are but a
reformulation of those under the substantive provision (see Mosley v. the United Kingdom, no. 48009/08, § 66, 10
May 2011).

125. The relevant part of Article 4 of the Convention reads:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour….”


-----

_A. Admissibility1. The parties' submissions(a) The Government_

126. The Government submitted that Article 4 of the Convention did not apply, that the applicant had not exhausted
domestic remedies, and that the complaint was manifestly ill-founded.

127. In support of those assertions, the Government pointed out that X had been charged with and convicted of the
basic offence of trafficking under Article 159a § 1 of the Bulgarian Criminal Code, which was broader than the
international definition of trafficking, since it did not require that the “means” of trafficking be identified. Only the
aggravated offence under Article 159a § 2 corresponded to the international definition (see paragraphs 34-36
above). A conviction in respect of the basic offence was thus insufficient to engage Article 4 of the Convention. The
Government noted that the applicant had taken part in the criminal proceedings against X, during which she could
have benefited from free legal aid earlier than the point at which she had actually engaged a lawyer (even at the
pretrial stage), but she had not contested how the authorities had classified his offence. Moreover, in those
proceedings the applicant had – apart from stating that X had retained her identity card – not asserted that she had
been subjected to violence or some other form of coercion, taken in the broadest possible meaning of the term. She
had merely claimed that X had taken advantage of her situation. In the light of those observations, it could not be
said that she had properly formulated a complaint under Article 4, or that the dismissal of her claim for damages
against X in respect of lost earnings had engaged that provision.

128. The Government further pointed out that the Bulgarian courts had not found credible the applicant's assertions
that when she had met X she had been unaware of the kind of work he would offer her and that he had threatened
her. Nor was there any evidence that X had deceived the applicant. The fact that he had retained her identity card
did not unequivocally indicate trafficking either. Firstly, although she sometimes asserted that X had done that in
order to prevent her from running away from him, the applicant also on occasion stated that he had done so as a
precaution against a client stealing her handbag. Secondly, since the applicant had not been abroad at the time of
the events in question, the retention of her identity card had not prevented her from leaving X. Nor could it be said
that she had been unable to do so because X had been withholding her earnings. He had been giving her about
BGN 500 per month, which had been more than the minimum wage in Bulgaria at the time, and had covered her
living expenses. Neither the applicant's possible emotional attachment to X nor any mental-health condition from
which she might have been suffering could have made her vulnerable vis-à-vis X – especially since there was no
evidence that he had been aware of any mental-health problems on the part of the applicant, and so could not have
exploited any resulting vulnerability. The applicant's situation had thus not been one of trafficking or forced
prostitution, and Article 4 of the Convention was accordingly not applicable.
_(b) The applicant_

129. The applicant replied that X had used “means” to traffic her: he had abused her position of vulnerability. She
pointed out in this connection that she hailed from a small village in one of the poorest regions of Bulgaria, had
been unemployed when she had met X, had been suffering at the time in question from a bipolar disorder and an
episode of mania (one of whose symptoms was increased libido), and had become emotionally attached to X. He
had taken advantage of the combination of those factors to convince her to engage in sex work.

130. The applicant further argued that it was unreasonable to expect her to have contested the way in which the
authorities had categorised X's offense. She had not had the services of a lawyer during the pretrial investigation
against him, and under the rules of procedure it had been impossible to ask the criminal court trying his case to recategorise the offence as a more serious one. Moreover, the applicant argued, it had been easier to obtain a
conviction for the basic offence rather than the aggravated one. She had nevertheless urged the courts to treat the
means that X had used to get her to engage in sex work for his benefit as constituting an aggravating circumstance.
Furthermore, it was plain that even though X had been giving her pocket money, he had exploited her by, inter alia,
retaining the bulk of her earnings and causing her to work excessive hours in hazardous conditions.

131. In sum, the applicant had been a victim of trafficking, and X's actions with respect to her had engaged Article 4
of the Convention.
_2. The Court's assessment(a) Compatibility ratione materiae_


-----

132. Under the Court's settled case-law, the question of whether a situation involves all elements of trafficking in
human beings – and whether Article 4 of the Convention thus applies – is one of fact, to be examined in the light of
all the circumstances of the case (see S.M. v. Croatia, cited above, § 302; V.C.L. and A.N. v. the United Kingdom,
nos. 77587/12 and 74603/12, § 149, 16 February 2021; and Zoletic and Others v. Azerbaijan, no. 20116/12, § 157,
7 October 2021). An analysis of this point therefore requires a more detailed consideration of the evidence and the
facts.

133. It follows that the Government's objection that Article 4 of the Convention does not apply and that the
complaint is hence incompatible ratione materiae with the provisions of the Convention within the meaning of Article
35 § 3 (a) must be joined to the merits.

134. As for the question of whether the dismissal of the applicant's claim against X in respect of lost earnings
engaged Article 4 of the Convention, it turns on the construction to be put on that provision (see Rantsev v. Cyprus
_and Russia, no. 25965/04, § 211, ECHR 2010 (extracts), and S.M. v. Croatia, cited above, § 238; see also, mutatis_
_mutandis, Calvelli and Ciglio v. Italy [GC], no. 32967/96, § 38, ECHR 2002-I; Vo v. France [GC], no. 53924/00, § 44,_

ECHR 2004‑VIII; Demir and Baykara v. Turkey [GC], no. 34503/97, § 58, ECHR 2008; Tănase v. Moldova [GC], no.

7/08, § 132, ECHR 2010; and _Austin and Others v. the United Kingdom_ [GC], nos. 39692/09, 40713/09 and
41008/09, § 50, 15 March 2012)). It thus also goes to the merits of the case (see, mutatis mutandis, Case “relating
_to certain aspects of the laws on the use of languages in education in Belgium” (preliminary objection), 9 February_
1967, p. 18, Series A no. 5; _Glasenapp v. Germany, 28 August 1986, § 41, Series A no. 104; and_ _Bozano v._
_France, 18 December 1986, § 42, Series A no. 111)._
_(b) Exhaustion of domestic remedies_

135. The applicant does not appear to have exercised her right to take part as a victim in the pretrial investigation
against X, but then participated in the judicial phase of the criminal proceedings against him as a private prosecutor
and civil claimant (see paragraphs 17-19, 23 and 26 above). However, under Bulgarian law none of those roles
gave her a say in the decision regarding what specific charges were to be brought against X (see paragraphs 61,
63 and 65 above). It was, then, not open to her in law to do what the Government reproached her for not doing: to
request that X be charged with the aggravated offence of trafficking under Article 159a § 2 of the Bulgarian Criminal
Code, which covers all three elements of the international definition of trafficking: “action”, “means” and “purpose”
(see paragraphs 34-36 above). It is hence superfluous to examine whether she could have done so in practice. It
suffices to note that she did refer to the means used by X to make her engage in sex work for his benefit – both in
support of her claims for damages (see paragraphs 18 and 24 above), and when she urged the courts dealing with
his case to take into account those means as constituting an aggravating circumstance in relation to the basic
offence under Article 159a § 1 of the same Code (see paragraphs 21 and 34 above). Moreover, though not citing
Article 4 of the Convention, the applicant appealed against the dismissal of her claim against X in respect of lost
earnings on the basis of arguments similar to those that she then raised before the Court in relation to this provision
(see paragraph 31 above and paragraph 138 below). She thus provided the Bulgarian courts with an opportunity to
avoid, or provide redress for, the alleged breach (see, _mutatis mutandis,_ _Chowdury and Others v. Greece, no._
21884/15, § 68, 30 March 2017).

136. The Government's non-exhaustion objection therefore fails.
_(c) Conclusion on the admissibility of the complaint_

137. The complaint is furthermore not manifestly ill-founded (as contended by the Government, whose objection in
this regard must accordingly be dismissed – compare S.M. v. Croatia, cited above, § 239) or inadmissible on other
grounds. It must therefore be declared admissible.
_B. Merits1. Submissions of the parties and the third party(a) The applicant_

138. The applicant submitted that sex work engaged in voluntarily (on the one hand) and the exploitation of
someone for coerced prostitution (on the other hand) were two different things. It was hence irrelevant whether or
not a State had opted to outlaw voluntary sex work. She had fallen victim to an offence that had generated financial
gain for the perpetrator. The salient question was whether Article 4 of the Convention required that someone who
had exploited someone else for the purposes of prostitution should compensate that other person for the unlawful


-----

gains which he or she had derived from that exploitation. As was already the case with Articles 2 and 3 of the
Convention, Article 4 had to be construed as requiring not only an effective investigation into acts falling foul of its
requirements but also providing the possibility of at least seeking compensation for such acts. Although the
applicant was fully satisfied with the criminal-law measures taken against X and with the order that he pay her
compensation for non pecuniary damage, in her view it had also been necessary to allow her claim in respect of lost
earnings against him. However, under the interpretation adopted by the courts that claim had been bound to fail,
and there had been no alternative legal routes.

139. In additional submissions made after the Bulgarian Constitutional Court found Article 329 § 1 of the Bulgarian
Criminal Code unconstitutional (see paragraph 49 above), the applicant noted that that court's judgment had not
remedied her individual situation, as it could not serve as grounds to reopen the proceedings against X. Moreover,
the judgment had not proclaimed in express terms a right to compensation in respect of lost earnings from sexual
exploitation.
_(b) The Government_

140. The Government pointed out that legislation and policies in respect of prostitution varied greatly across
Europe, ranging from criminalisation to full legalisation, depending on how the respective society saw it. There were
States in which, although legal, prostitution was perceived as contrary to public morality. As far as was known, the
courts of only five Contracting States had allowed claims lodged by victims trafficked for the purposes of prostitution
seeking the reimbursement of lost earnings. In view of those differing national approaches, the matter remained
within each State's margin of appreciation and outside the bounds of the positive duties arising from Article 4 of the
Convention. Trafficking victims in Bulgaria could seek compensation for pecuniary and non-pecuniary damage in
other respects, and resort to the mechanism for compensating the victims of crime (see paragraph 59 above).

141. In additional submissions made after the Bulgarian Constitutional Court had found Article 329 § 1 of the
Bulgarian Criminal Code to be unconstitutional (see paragraph 49 above), the Government pointed out that that
court's judgment did not have retrospective effect, and argued that it did not appear to exclude any possibility of
criminalising prostitution either in its entirety or in respect of some of its aspects. But even if that judgment did bar
that possibility, that could not preclude the courts from finding prostitution contracts to be contrary to good morals
and hence void, as they had in the applicant's case. That had been the main reason for dismissing her claim
against X in respect of lost earnings. The Constitutional Court's judgment had not established a duty to give legal
recognition to earnings realised from prostitution. As recognised in various international instruments and by the
Court itself, there was no consensus among the Contracting States regarding the legal framework governing
prostitution.
_(c) The third party, GRETA_

142. The third-party intervener, GRETA, submitted that under several international-law instruments States were
obliged to enable trafficking victims to seek from their traffickers compensation in respect of lost earnings. In most
States Parties to the Anti-Trafficking Convention, victims could claim such compensation under the general law of
tort, and in a number of States victims of forced labour could claim unpaid wages in employment proceedings.
GRETA referred to examples cited in its reports, and several further examples. It deplored the fact that such claims
remained rare and difficult to pursue in practice.

143. According to the information available to GRETA, only two States Parties to the Anti-Trafficking Convention –
Bulgaria and Malta – did not permit victims of trafficking for the purpose of sexual exploitation to seek compensation
from the perpetrators of such trafficking in respect of earnings resulting from prostitution. In Malta, this was
impossible because prostitution was not deemed to constitute employment. By contrast, in at least five States –
Austria, Belgium, Germany, the Netherlands and Norway – the courts had allowed such claims.

144. In GRETA's view, denying the victims of sexual exploitation compensation from their traffickers in respect of
lost earnings (because prostitution was seen as illegal, immoral or undesirable) ran counter to the object and
purpose of the international instruments created to properly protect the victims of all forms of trafficking – in
particular, Article 15 of the Anti Trafficking Convention. The main consideration was not whether prostitution was


-----

legal or illegal, or an undesirable activity harmful to society, but which option would protect trafficking victims more
effectively.
_2. The Court's assessment(a) Was the applicant a victim of trafficking in human beings for the purposes of Article 4_
_of the Convention?_

145. It is settled that trafficking in human beings (both national and transnational) falls within the scope of Article 4
of the Convention (see the above-cited cases of S.M. v. Croatia, § 296; V.C.L. and A.N. v. the United Kingdom, §
148; and Zoletic and Others, § 154). This is so, however, only if all three elements of the definition of trafficking set
out in Article 3 (a) of the Palermo Protocol and Article 4 (a) of the Anti-Trafficking Convention – often described as
“action”, “means” and “purpose”, although the presence of “means” is not necessary in the case of a child – are in
place (see the above cited cases of S.M. v. Croatia, §§ 290 and 296; V.C.L. and A.N. v. the United Kingdom, § 149;
and Zoletic and Others, § 155).

146. As noted in paragraph 132 above, according to the Court's settled case-law the question of whether a situation
involves all these elements is one of fact, to be examined in the light of all the circumstances of the case. The fact
that X was only charged with and convicted of the basic offence under Article 159a § 1 of the Bulgarian Criminal
Code – under which the offence of trafficking is committed even if the “means” element is absent (“action” and
“purpose” being sufficient – see paragraphs 34 and 36 above) – is, then, not decisive. The Court must, on the basis
of all the evidence available to it, including the findings of fact made in the criminal proceedings against X – by
which it is by no means bound or constrained when applying the Convention (see, _mutatis mutandis,_ _Ribitsch v._
_Austria, 4 December 1995, § 32 in fine, Series A no. 336, and Austin and Others, cited above, § 61) – establish for_
itself whether all three elements of the international definition of trafficking were in place in the applicant's case.

147. It is clear that “action” and “purpose” were present. The criminal court that convicted X found, on the basis of
all the evidence in the case, that he had recruited the applicant twice and had continually harboured and
transported her with a view to exploiting her for sexual acts carried out for payment (see paragraph 28 above). The
appellate court later fully endorsed those findings (see paragraph 32 above). Indeed, the presence of those two
elements of the international definition of trafficking in human beings was not disputed by the Government (see
paragraphs 126-127 above).

148. As for “means”, it is true that there is no evidence that X resorted to violence or threats of violence to make the
applicant engage in sex work for his benefit. International law, however, reflects clearly the understanding that
modern-day trafficking in human beings is sometimes carried out by subtler means, such as deception,
psychological pressure, and the abuse of a vulnerability (for the meaning of this latter expression in this context,
see paragraphs 68 and 78 above). These tactics should not be seen in isolation. As clarified in paragraph 84 of the
above-mentioned explanatory report to the Anti-Trafficking Convention (see paragraph 78 above), they reflect
merely differences of degree; indeed, they can and often do overlap. The applicant was a poor and emotionally
unstable young woman hailing from a small village, who apparently had troubled relations with her parents (with
whom she had apparently been living all her life before meeting X – see paragraph 4 above). For his part, X – a
man who was several years older than the applicant, had a criminal record, had been routinely engaging in
professional dealings with sex workers and was apparently deriving all of his income from such dealings, and was
associating with pimps (see paragraph 5 above) – had the applicant living in his house with himself and his wife and
children. Moreover, it was he who instructed the applicant on the practical details of how to engage in sex work, and
posed as her “protector” (see paragraph 6 above). It is not far-fetched to infer from all this that she felt sufficiently
dependent on him to not overtly oppose him.

149. X's taking away a substantial portion of the applicant's earnings (see paragraphs 9 and 28 above) must have
also led to her having a level of dependency on him. Withholding pay in this manner also served as a means of
controlling the applicant (see S.M. v. Croatia, cited above, §§ 143 (viii) and 301). Even if on a practical level she
had enough money to cover her most basic needs, it is not difficult to imagine that X's taking away her earnings left
her with no resources that could facilitate her in establishing herself on her own. This perception must have thus
also locked her, at least for a period, into staying with him.


-----

150. It is also of some significance that for a while X and the applicant apparently had intimate relations (see
paragraph 6 in fine above). It is well known that traffickers sometimes (especially in respect of young or emotionally
vulnerable victims) groom victims exploited for prostitution by luring them into intimate relationships and posing as
their romantic partners – thereby creating a sense of emotional connection and dependence.

151. Significantly, when upholding the first-instance judgment against X, the appellate court noted that he had
deceived the applicant and had offered her benefits with a view to inducing her to engage in prostitution, and that
the applicant had been deprived of the possibility to move freely or get in touch with her family, and had been
hidden in X's home. In assessing the question of non-pecuniary damage, the court also had regard to the intensity
of the coercion to which the applicant had been subjected (see paragraph 32 above).

152. There is, moreover, some evidence that X hit the applicant in another context (see paragraph 14 above).
There is also some evidence that he abused her emotional and social vulnerability to control her behaviour. In
particular, he apparently manipulated her by highlighting his and his family's nearly exclusive dependence on the
income arising from her sex work (see paragraph 9 above). More significantly, he apparently threatened that he
would disclose to her co-villagers the fact that she was engaged in sex work (see paragraph 10 above). In the light
of the applicant's social and family background, such a threat to her reputation can hardly be brushed off as
innocuous (see, mutatis mutandis, Armonienė v. Lithuania, no. 36919/02, § 42, 25 November 2008, and Biriuk v.
_Lithuania, no. 23373/03, § 41, 25 November 2008). From August 2012 onwards X apparently also retained the_
applicant's identity card (see paragraphs 9, 11 and 14 above; see also S.M. v. Croatia, cited above, §§ 143 (vii) and
301)). Even if this latter point carries less significance in the instant case than in cases involving cross border
trafficking, the retention of the applicant's identify card still entailed a significant limitation on her freedom of
movement – especially since identity documents could often be required for various routine tasks (see, _mutatis_
_mutandis,_ _Smirnova v. Russia, nos. 46133/99 and 48183/99, § 97, ECHR 2003-IX (extracts), and_ _Ahmadov v._
_Azerbaijan, no. 32538/10, § 46, 30 January 2020)._

153. The fact that the applicant may have, at least initially, consented to engage in sex work for X's benefit is not
decisive (see, mutatis mutandis, Chowdury and Others, cited above, § 96). In any event, under the Anti Trafficking
Convention's definitions (which pertain to this point as well), such consent is irrelevant if any of the “means” of
trafficking have been used. Nor is it decisive that the applicant could have perhaps broken free from X earlier,
during one of her previous interactions with the police (see paragraphs 7 in fine and 10 above).

154. In the light of all this, the Court is sufficiently persuaded that the “means” element was also present in this
case.

155. It follows that all three elements of the international definition of trafficking in human beings – “action”, “means”
and “purpose” – were in place, and that Article 4 of the Convention applies.

156. This conclusion should naturally not be seen as constituting a finding that X is guilty of the aggravated form of
the offence of trafficking under Article 159a § 2 of the Bulgarian Criminal Code, which likewise requires the use of
“means” (see paragraphs 35-36 above). Firstly, it is not for the Court to rule on any points regarding individual
criminal liability (see Tanlý v. Turkey, no. 26129/95, § 111 in fine, ECHR 2001-III (extracts); M.C. v. Bulgaria, no.
39272/98, § 168 _in fine, ECHR 2003-XII; and_ _Y v. Bulgaria, no. 41990/18, § 94, 20 February 2020). Secondly,_
although the required standard of proof before the Court is that of “beyond reasonable doubt”, that standard is not
necessarily equivalent to that required under the national legal systems which use it (see Merabishvili v. Georgia

[GC], no. 72508/13, § 314, 28 November 2017, with further references).

157. In the light of the conclusion in paragraph 155 above, the Government's objection that the complaint is
incompatible ratione materiae with the provisions of the Convention within the meaning of Article 35 § 3 (a), which
was joined to the merits (see paragraph 133 above), must be dismissed.
_(b) Is there a positive obligation under Article 4 of the Convention to enable victims of trafficking in human beings to_
_claim compensation from their traffickers in respect of lost earnings?_

158. The Court has consistently held that Article 4 of the Convention lays down positive obligations for the
Contracting States (see Siliadin v France no 73316/01 § 89 ECHR 2005-VII; Rantsev cited above §§ 285-86;


-----

and S.M. v. Croatia, cited above, § 306). The general framework of those positive obligations has so far been held
to include: (a) the duty to put in place a legislative and administrative framework that prohibits and punishes
trafficking; (b) the duty, in certain circumstances, to take operational measures to protect victims, or potential
victims, of trafficking; and (c) a procedural obligation to investigate situations of potential trafficking (see _S.M. v._
_Croatia, cited above, § 306)._

159. The duty to put in place a legislative and administrative framework has been held to extend to the way in which
domestic law regulates certain matters. In Siliadin (cited above, § 141-48), C.N. v. the United Kingdom (cited above,
§§ 73-81), L.E. v. Greece (no. 71545/12, § 70, 21 January 2016), Chowdury and Others (cited above, §§ 105-09),
and _T.I. and Others v. Greece_ (cited above, §§ 141-44), it was held to encompass the substantive content of
national criminal law. In _Chowdury and Others_ (cited above, § 108) the Court also reviewed whether national
criminal-procedure law was in line with those positive obligations. More importantly for present purposes, in the
same case the Court noted that Article 15 § 3 of the Anti-Trafficking Convention obliges States to provide in their
domestic law for the right of victims of trafficking to receive compensation from the perpetrators (see paragraphs
76-77 above), and took the low amount of compensation awarded to the applicants as an element leading to the
conclusion that the respondent State had failed to comply with Article 4 of the Convention (see _Chowdury and_
_Others, cited above § 126). In_ _Rantsev_ (cited above, §§ 284 and 291-93), the duty was held to cover the
substantive content of national immigration law, and in L.E. v. Greece (cited above, § 71 in fine), the Court even
examined whether a European Union directive had been properly transposed.

160. As for the duty to take operational measures to protect trafficking victims, it has been held to extend to the
manner in which those victims are treated by the criminal-justice system: in V.C.L. and A.N. v. the United Kingdom
(cited above, § 159), the Court held that that the criminal prosecution of victims or potential victims of trafficking
could sometimes be at odds with that duty. As in the cases of Siliadin and Rantsev (both cited above), when coming
to that conclusion and then laying down the parameters of the positive obligation at issue, the Court had regard
chiefly to the provisions of the specialised international-law instruments in the field of human trafficking, including
the Palermo Protocol and the Anti-Trafficking Convention (see V.C.L. and A.N. v. the United Kingdom, cited above,
§§ 158, 160 and 162).

161. In the instant case, the Court is for the first time confronted with the question of whether there is a positive
obligation under Article 4 of the Convention to enable trafficking victims to claim compensation from their traffickers
in respect of lost earnings.
_(i) General principles guiding the Court's interpretative approach_

162. In assessing whether Article 4 of the Convention does indeed enable trafficking victims to claim compensation
from their traffickers in respect of lost earnings, the Court will have particular regard to three of the canons of
interpretation that normally guide it.

163. The first of these canons is that the object and purpose of the Convention, as an instrument for the protection
of individual human beings, require that its provisions and those of its Protocols be interpreted in a way that renders
the rights that they guarantee practical and effective (see, among other authorities, Artico v. Italy, 13 May 1980, §
33, Series A no. 37; Soering v. the United Kingdom, 7 July 1989, § 87, Series A no. 161; and Demir and Baykara,
cited above, § 66).

164. The second canon is that the Convention and its Protocols should as far as possible be construed in harmony
with the other rules of international law, of which they form a part (see, among other authorities, Al-Adsani v. the
_United Kingdom_ [GC], no. 35763/97, § 55, ECHR 2001-XI; _Bosphorus Hava Yollarý Turizm ve Ticaret Anonim_

_Þirketi v. Ireland [GC], no. 45036/98, § 150, ECHR 2005‑VI; and Hassan v. the United Kingdom [GC], no. 29750/09,_

§§ 77 and 102, ECHR 2014). More specifically, the precise obligations that the substantive provisions of the
Convention and its Protocols impose on the Contracting States are to be construed in the light of relevant
international treaties that apply to the particular sphere in issue (see _Demir and Baykara, cited above, § 69)._
Account should be taken of any relevant rules of international law applicable to the relations between the parties –
in particular, rules concerning the international protection of human rights (see Neulinger and Shuruk v. Switzerland

[GC], no. 41615/07, § 131, ECHR 2010; Nada v. Switzerland [GC], no. 10593/08, § 169, ECHR 2012; and X and


-----

_Others v. Bulgaria [GC], no. 22457/16, § 179, 2 February 2021). Any evolution in those rules must also be taken_
into account (see Demir and Baykara, cited above, § 68, and Al-Saadoon and Mufdhi v. the United Kingdom, no.
61498/08, §§ 115-20, ECHR 2010). Another point that must be considered is how such international rules are being
interpreted by the relevant bodies (see _Demir and Baykara, cited above, § 85;_ _Bayatyan v. Armenia_ [GC], no.
23459/03, § 102, ECHR 2011; and _Fedotova and Others v. Russia, nos. 40792/10 and 2 others, § 176, 13 July_
2021). The Court has already held, in particular, that it must construe Article 4 of the Convention in the light of the
Anti-Trafficking Convention, and that in so doing it ought to be guided by the way in which that Convention has
been interpreted by GRETA – the expert body tasked with monitoring the implementation of that Convention (see
_Chowdury and Others, § 104, and V.C.L. and A.N. v. the United Kingdom, § 150, both cited above). Naturally, when_
referring to the provisions of other international instruments, the Court is not seeking to review compliance with
them as such; it is still examining the case under the Convention or its Protocols (see, mutatis mutandis, Tănase,
cited above, § 176 in fine).

165. The third canon is that when construing the Convention or its Protocols the Court may have regard to
developments in domestic legal systems that indicate a uniform or common approach or a developing consensus
between the Contracting States in a given area (see, among other authorities, Marckx v. Belgium, 13 June 1979, §

41, Series A no. 31; Smith and Grady v. the United Kingdom, nos. 33985/96 and 33986/96, § 104, ECHR 1999‑VI;

and Magyar Helsinki Bizottság v. Hungary [GC], no. 18030/11, § 138, 8 November 2016).
_(ii) Interpretation arising from the object and purpose of Article 4_

166. It is plain that the positive obligations arising from Article 4 of the Convention may extend to the way in which
domestic law regulates certain matters (see paragraph 159 above). As regards more specifically the domestic law
governing the seeking and awarding of damages, the Court has already had occasion to hold that the fact that it is
not possible (under the relevant domestic rules) to lodge claims for certain types of damages is in breach of Article
2 of the Convention (see Movsesyan v. Armenia, no. 27524/09, §§ 72-74, 16 November 2017; Sarishvili-Bolkvadze
_v. Georgia, no. 58240/08, §§ 94-97, 19 July 2018; and Vanyo Todorov v. Bulgaria, no. 31434/15, §§ 56-67, 21 July_
2020). It is not decisive that the text of Article 4 is silent on the question of whether it lays down a positive obligation
to enable victims to sue their traffickers in respect of lost earnings; no such obligation is expressly set out in Article
2 either, and specific obligations – for instance, to pay or to make it possible to seek compensation – have long ago
been read into other provisions that are equally silent on such issues (see _James and Others v. the United_
_Kingdom, 21 February 1986, § 54, Series A no. 98, where the Court held that Article 1 of Protocol No. 1, though_
“silent on the point”, in principle requires compensation reasonably related to the value of a property when that
property is taken in the public interest, and Keenan v. the United Kingdom, no. 27229/95, § 130, ECHR 2001-III,
where the Court held that Article 13 of the Convention – which likewise does not in terms speak of compensation, in
contrast to Article 5 § 5 of the Convention – in principle requires compensation for non-pecuniary damage flowing
from a breach of Article 2 or 3 of the Convention).

167. There are strong arguments in favour of construing Article 4 in much the same manner as Article 2 of the
Convention.

168. Together with Articles 2 and 3, Article 4 enshrines one of the basic values of the democratic societies making
up the Council of Europe (see the above-cited cases of _Siliadin, § 82;_ _Rantsev, § 283; and_ _C.N. v. the United_
_Kingdom, § 65), and trafficking (which threatens the dignity and fundamental freedoms of its victims) is incompatible_
with those values, as expounded in the Convention (see the above-cited cases of Rantsev, § 282; Chowdury and
_Others, § 93; V.C.L. and A.N. v. the United Kingdom, § 161; and Zoletic and Others, § 153). It has, moreover, long_
been accepted that the Contracting States' duties under Article 4 in relation to trafficking must be guided by the
comprehensive approach required under the Palermo Protocol and the Anti Trafficking Convention, and that only a
combination of measures (including measures to protect trafficking victims) can be effective in this respect (see the
above-cited cases of _Rantsev, § 285;_ _L.E. v. Greece, § 65;_ _Chowdury and Others, § 87; and_ _T.I. and Others v._
_Greece, § 135). The Court has also observed that the spectrum of safeguards in domestic law must be sufficient to_
ensure the effective protection of the rights of trafficking victims (see _Rantsev, cited above, § 284). Cases under_
Article 4 nowadays typically relate to compliance with the positive obligations arising from it (see S.M. v. Croatia,


-----

cited above, § 304). It is therefore all the more important to construe those positive obligations in such a way as to
afford effective protection to the rights enshrined in Article 4.

169. To date, the Court's case-law relating to after-the-fact responses to trafficking has focused on investigation
and punishment. However, although essential for deterrence, such measures cannot wipe away the material harm
suffered by the victims of trafficking that has already taken place or practically assist their recovery from their
experiences.

170. Indeed, the recent case of V.C.L. and A.N. v. the United Kingdom (cited above, §§ 159-83) highlighted, albeit
from a different perspective, the need to protect trafficking victims after the fact. That case concerned the criminal
prosecution of trafficking victims; the Court found that such prosecution could be problematic in some situations, on
the grounds that it could be detrimental to their recovery, create an obstacle to their reintegration into society, and
impede their access to the support and services envisaged by the Anti-Trafficking Convention. An analogous line of
reasoning had underpinned the part of the earlier judgment in the case of J. and Others v. Austria (no. 58216/12, §§
110-11, 17 January 2017) concerned with whether the applicants had been duly identified and supported as
trafficking victims.

171. Similar considerations apply in respect of affording compensation to trafficking victims – particularly in respect
of lost earnings. The possibility for them to seek compensation in respect of lost earnings, especially earnings
withheld from them by their traffickers, would constitute one means of ensuring _restitutio in integrum_ for those
victims by making good the full extent of the harm suffered by them. It would also go a considerable way (by
providing them with the financial means to rebuild their lives) towards upholding their dignity, assisting their
recovery, and reducing the risks of their falling victim again to traffickers. This cannot therefore be seen as a
secondary consideration; it must be considered an essential part of the integrated State response to trafficking
required under Article 4 of the Convention. Moreover, redress for the victim should be the overarching consideration
from a human-rights perspective.

172. It is true that this is but one aspect of the State response to the issue of trafficking, and that other measures,
notably those in the field of criminal and sometimes immigration law, are likewise integral to it. But all those
measures are complementary – even from the perspective of the need to deter trafficking, which is often (if not
always) carried out for financial gain. Making it possible for victims to recoup lost earnings from their traffickers
would go some way towards ensuring that those traffickers are not able to enjoy the fruits of their offences, thus
reducing the economic incentives to commit trafficking offences. Indeed, the recent trend in law enforcement more
generally has been to target not only the persons of criminals but also the proceeds of their offences, and then to
use (at least a portion of) those proceeds to compensate victims. This can also reduce the burden on the public
resources sometimes used to support the recovery of trafficking victims. Moreover, it can give victims an additional
incentive to come forward and expose trafficking, thereby increasing the odds of holding human traffickers
accountable and thus preventing future instances of it.

173. In the light of the above, and of the fact that trafficking in human beings as a global phenomenon has
increased significantly in recent years (see Rantsev, cited above, § 278), it can be concluded that Article 4 of the
Convention, construed in the light of its object and purpose and in a way that renders its safeguards practical and
effective, lays down a positive obligation on the part of the Contracting States to enable the victims of trafficking to
claim compensation from their traffickers in respect of lost earnings.
_(iii) Does that interpretation find support in the relevant international instruments?_

174. The above conclusion is reinforced by the relevant international instruments. Those instruments lay down
generally recognised international standards that can be a powerful argument to read into the Convention rights or
obligations not expressly mentioned in its text (compare Harakchiev and Tolumov v. Bulgaria, nos. 15018/11 and
61199/12, § 264, ECHR 2014 (extracts), in relation to Article 3 of the Convention; and _Saunders v. the United_
_Kingdom, 17 December 1996, § 68, Reports of Judgments and Decisions 1996-VI, and Ibrahim and Others v. the_
_United Kingdom_ [GC], nos. 50541/08 and 3 others, §§ 271-72, 13 September 2016, in relation to Article 6 of the
Convention).


-----

175. Both the Palermo Protocol (Article 6 § 6) and the Anti-Trafficking Convention (Article 15 § 3), which are in force
with respect to all forty-six Contracting States, lay down a general duty to enable trafficking victims to seek
compensation. The latter, which post-dates the former by five years, contains more prescriptive language (“shall
provide… for the right… to compensation”, as opposed to “offer the possibility of obtaining compensation for
damage suffered”). It also specifies that the compensation must be “from the perpetrators” – a point that is also
elaborated upon in the explanatory report to the Anti-Trafficking Convention (see paragraphs 67 and 76-77 above;
and also Chowdury and Others, cited above, § 126). The right to compensation is also guaranteed under Article 14
§ 13 of the ASEAN Convention Against Trafficking in Persons, Especially Women and Children (see paragraph 82
above). The right to compensation under Article 6 § 6 of the Palermo Protocol, whose wording is quite general, is
seen as comprising compensation from traffickers for lost earnings; of the bodies within the United Nations system,
the General Assembly, the Human Rights Council and the Committee on the Elimination of Discrimination against
Women have all urged States to enable trafficking victims to obtain compensation for damage suffered (in
particular, from perpetrators), even referring to “back pay” and “lost income and due wages” (see paragraphs 69-75
above). For its part, GRETA was emphatic in its third-party submissions in this case (see paragraph 144 above), as
well as in its report on France mentioned in paragraph 94 above, that the right to compensation under Article 15 § 3
of the Anti-Trafficking Convention likewise comprises a right to compensation from traffickers in respect of lost
earnings. The Parliamentary Assembly of the Council of Europe has also recommended that offenders should pay
compensation to the victims of trafficking (see paragraph 80 above), and, more generally, that restoring victims'
rights and dignity should remain at the centre of actions undertaken with respect to trafficking (see paragraph 81
above).
_(iv) Does that interpretation find support in a common approach or a developing consensus between the_
_Contracting States?_

176. The information available to the Court (see paragraphs 83-120 above) shows that in recent years there has
been a trend, most prominently in the United States of America and Canada, but also in some Contracting States –
Austria, Belgium, Denmark, France, Germany, the Netherlands, Norway and the United Kingdom – towards
enabling trafficking victims to recover from their traffickers the gains that the latter have realised by exploiting them.
In other Contracting States, the matter does not appear to have been addressed expressly (in case-law or
otherwise), but it is significant that, apart from Bulgaria and perhaps Malta (although the information in relation to
Malta appears somewhat contradictory – see paragraphs 100 and 143 above), there is no indication that the law of
any other Contracting State generally bars such claims (compare _Marckx, § 41, and_ _Vanyo Todorov, § 62, both_
cited above). Moreover, the question has arisen in Bulgaria solely in relation to earnings relating to trafficking for
sexual exploitation, not earnings realised under other trafficking scenarios. All this lends further support to the
interpretation adopted in paragraph 173 above.
_(v) Conclusion_

177. The foregoing considerations, taken as a whole, lead to the conclusion that Article 4 of the Convention does
indeed lay down a positive obligation on the part of the Contracting States to enable the victims of trafficking in
human beings to claim compensation from their traffickers in respect of lost earnings. This obligation enhances the
protection of the rights already enshrined in that Article in the light of present-day realities (see, mutatis mutandis,
_Golder v. the United Kingdom, 21 February 1975, § 36, Series A no. 18), and brings this protection into line with the_
increasingly high standard required in this domain (see, mutatis mutandis, Siliadin, cited above, §§ 121 and 148)
and with the changed social context in which that Article now needs to be applied (see, mutatis mutandis, H.F. and
_Others v. France [GC], nos. 24384/19 and 44234/20, § 210, 14 September 2022)._

178. It follows that the manner in which the Bulgarian courts dealt with the applicant's claim for compensation for
pecuniary damage against X in respect of the earnings that he had allegedly taken away from her falls to be
examined under Article 4 of the Convention.
_(c) Was the dismissal of the applicant's claim for damages against X in breach of that positive obligation?_

179. The next question is whether the dismissal of the applicant's claim in respect of lost earnings against X was
contrary to the positive obligation identified in paragraph 177 above. This question must be examined in the light of
the general principles guiding the Court when it reviews whether a Contracting State has complied with its positive
obligations under the Convention or its Protocols


-----

_(i) General principles regarding States' duty to comply with positive obligations_

180. Ever since recognising that certain provisions of the Convention and its Protocols can give rise to positive
obligations (even if those obligations are not explicitly spelled out in those provisions), the Court has accepted that
the Contracting States normally have some choice in respect of how they comply with those obligations, and a
margin of appreciation in relation to that (see, generally, Marckx, cited above, § 31; X and Y v. the Netherlands, 26
March 1985, §§ 23-24, Series A no. 91; and Rees v. the United Kingdom, 17 October 1986, § 35, Series A no. 106;
see also, specifically in relation to Article 2 of the Convention, _Öneryýldýz v. Turkey_ [GC], no. 48939/99, § 107,
ECHR 2004-XII; Lambert and Others v. France [GC], no. 46043/14, §§ 144-48, ECHR 2015; and _Nicolae Virgiliu_
_Tănase v. Romania [GC], no. 41720/13, § 169, 25 June 2019; and, in relation to Article 3 of the Convention, Vinter_
_and Others v. the United Kingdom [GC], nos. 66069/09 and 2 others, §§ 105 and 120, ECHR 2013 (extracts), and_
_Harakchiev and Tolumov, cited above, §§ 246 (b) and 265)._

181. The Court has had regard to this margin of appreciation, as well as to local circumstances and cultural
perceptions, in deciding, with reference to Article 3 of the Convention, whether domestic criminal law ensured
adequate protection against rape; however, it has juxtaposed those considerations against contemporary standards
and trends (see M.C. v. Bulgaria, cited above, §§ 154-66).

182. When determining whether a respondent State has complied with a positive obligation of the sort established
in the present case, the Court takes into account the margin of appreciation enjoyed by that State as to the means
of compliance and whether the arguments put forward by the national authorities for having acted as they did in the
circumstances of the case were reasonable and proportionate (see, for instance, Stanevi v. Bulgaria, no. 56352/14,
§§ 54, 62 and 66, 30 May 2023, with respect to the positive obligation under Article 2 of the Convention to be
awarded compensation for the death of a close relative).
_(ii) Application of those principles_

183. The Bulgarian courts cited two grounds for dismissing the applicant's claim against X in respect of lost
earnings: that she had obtained those earnings through prostitution, contrary to (a) Article 329 § 1 of the Bulgarian
Criminal Code and (b) good morals (see paragraphs 29 and 32 above).

184. With respect to the first ground, it can in principle be accepted that the national courts may deny a remedy to
someone seeking the repayment of money obtained via criminal conduct, and thus refuse to condone such conduct.
In the light of the Bulgarian courts' case-law under Article 329 § 1 of the Bulgarian Criminal Code in respect of
prostitution (see paragraphs 43–44 above), it can also be accepted that at the relevant time in Bulgaria, despite
some hesitation on the part of the domestic courts, earnings from prostitution could be illegal under certain
conditions.

185. In this case, however, the analysis cannot stop there.

186. Firstly, no authority has at any point suggested that the conduct of the applicant met all the constitutive
elements of the offence under Article 329 § 1 of the Bulgarian Criminal Code. She has never been investigated or
prosecuted for such an offence, and any such prosecution would have potentially run counter to the positive
obligation not to prosecute trafficking victims under some circumstances identified in V.C.L. and A.N. v. the United
_Kingdom_ (cited above, §§ 158-59), given that X had coerced her to engage in sex work for money. This raises
obvious issues with the Sofia City Court's intimation, in proceedings not conducted against the applicant, that she
was guilty of an offence under Article 329 § 1 (see, mutatis mutandis, Farzaliyev v. Azerbaijan, no. 29620/07, §§
66-67, 28 May 2020).

187. Secondly, Article 329 § 1 of the Bulgarian Criminal Code was based, as acknowledged by the Bulgarian
authorities themselves, on outdated social attitudes and policy considerations left over from the totalitarian
communist regime, and was incompatible with a constitutional framework based on the rule of law and on respect
for human rights (see paragraphs 47-48 above; also compare _Yordanovi v. Bulgaria, no. 11157/11, § 77, 3_
September 2020). It was precisely for that reason that in September 2022 the Bulgarian Constitutional Court
declared that provision unconstitutional (see paragraph 49 above). That court noted that the current trend in
European and international law (and also in Bulgaria) was to see prostitution not as reprehensible conduct on the


-----

part of those engaging in it, but as a form of their being exploited by others and as a breach of their human rights. It
went on to say that Article 329 § 1 in effect gave some respite to those, such as pimps and human traffickers, who
exploited prostitution, as it fed into their message to victims to expect the authorities to punish rather than support
them, whereas the perception of prostitution as a form of exploitation would redirect penal repression towards those
engaging in such exploitation and would enable its victims to seek and obtain help (see paragraph 49 _in fine_
above).

188. In the light of the above-noted considerations, that first ground for dismissing the applicant's claim – that it
concerned earnings obtained in breach of Article 329 § 1 of the Bulgarian Criminal Code – cannot be accepted as
sufficient in this case.

189. The reasons given by the Bulgarian Constitutional Court are also relevant for the second ground cited for
dismissing the applicant's claim – that the manner in which she had obtained the earnings that she was seeking to
retrieve from X had been immoral.

190. Concerns based on moral considerations must be taken into account in such a sensitive domain as
prostitution, which is approached differently in different legal systems depending on the respective society's
understanding of it (see paragraph 81 above, and S.M. v. Croatia, cited above, § 298). That said, the way in which
domestic law approaches different aspects of the problem must be coherent and permit the various legitimate
interests at play to be adequately taken into account (see, _mutatis mutandis,_ _A, B and C v. Ireland_ [GC], no.
25579/05, § 249, ECHR 2010). Moreover, as noted by the Parliamentary Assembly of the Council of Europe,
human rights should be the main criterion in designing and implementing policies on prostitution and trafficking (see
paragraph 81 in fine above). In the light of the Constitutional Court's remarks about how prostitution was to be seen
– remarks which reflect the submissions made before that court by Bulgaria's Chief Prosecutor and Minister of
Justice (see paragraphs 47 in fine and 48 in fine above) – it is difficult to accept that a decision ordering X to return
to the applicant the earnings that he had taken away from her would have been considered in Bulgaria as an affront
to morality, irrespective of the fact that those earnings had been earned through prostitution.

191. It should not be overlooked in this connection that the applicant was not seeking to enforce, directly or
indirectly, or obtain restitution under, a contract for sex work, or to profit from conduct in which she had engaged
freely, without any coercion. She was claiming the proceeds retained by her trafficker, which proceeds derived from
her unlawful exploitation for coerced prostitution, and with which her trafficker had unjustly enriched himself. Indeed,
the applicant was at pains to emphasise that her complaint did not relate to voluntary sex work, but to exploitation
for the purposes of coerced prostitution (see paragraph 138 above) – which is, as recognised by the Court,
incompatible with human dignity (see V.T. v. France, no. 37194/02, § 25, 11 September 2007, and S.M. v. Croatia,
cited above, § 299).

192. The present case is therefore not concerned with whether contracts for sex work must be recognised as legally
valid in themselves – a point on which there appears to exist a considerable degree of convergence in Europe,
although in the vast majority of legal systems it has apparently not been directly tested in litigation (see paragraph
121 above). Nor is the case concerned, more generally, with whether the Convention precludes prostitution or some
of its aspects from being outlawed.[4 ] The analysis here is limited to whether the positive obligation identified in
paragraph 177 above to enable trafficking victims to claim compensation from their traffickers in respect of lost
earnings could, in this case, be avoided on the grounds that the earnings at issue had been obtained immorally. In
the light of the significant emphasis placed on the rights of victims of trafficking in international instruments (see
paragraph 175 above), as well as in the proceedings before the Bulgarian Constitutional Court, and the reasons
given by that court, it cannot be accepted that a simple reference to the “immoral” character of the applicant's
earnings constituted sufficient justification for failing to comply with that obligation.

193. But even if there existed sound public-policy reasons to dismiss a tort claim relating to earnings obtained
through prostitution (for instance, it could be argued that upholding such a claim might be seen as condoning
prostitution or encourage some people to engage in it), in the present case such reasons came up against the
countervailing and undoubtedly compelling public policy against trafficking in human beings and in favour of


-----

protecting its victims (see paragraph 109 above), to which not only the Court but also the Bulgarian authorities
themselves plainly attach considerable significance (see paragraphs 47-49 above).

194. It does not appear that the applicant had other ways of seeking compensation in respect of the earnings
allegedly taken away by X, or equivalent compensation.

195. In particular, nothing suggests that if the applicant had from the outset lodged such a claim in standalone civil
proceedings against X she would have stood a better chance of succeeding (see paragraphs 54, 55 and 122
above).

196. Nor does it seem that the applicant could have sought and obtained such compensation through the general
scheme for compensating victims of crime. That scheme does envisage compensation in respect of lost earnings,
but it restricts the kinds of evidence by means of which such losses can be proved (the underlying thinking
apparently being that the earnings should stem from a legitimate source unrelated to the offence in question – see
paragraph 59 above). The applicant had a year after the final judgment in the criminal proceedings against X in
December 2017 in which to request compensation under that scheme, and, as noted above, at that time earnings
from prostitution were still seen as contrary to Article 329 § 1 of the Bulgarian Criminal Code. Moreover,
compensation under the scheme is capped at BGN 10,000 (EUR 5,113) per claimant (see paragraph 59 above),
whereas the applicant's claim was for a considerably higher sum (see paragraphs 18 and 25 above).

197. It follows that the decision to dismiss the applicant's claim against X in respect of lost earnings cannot be seen
as striking a fair balance between her rights under Article 4 of the Convention and the interests of the community,
the respondent State's margin of appreciation notwithstanding.

198. There has therefore been a breach of that provision.
_II. APPLICATION OF ARTICLE 41 OF THE CONVENTION_

199. Article 41 of the Convention reads:

“If the Court finds that there has been a violation of the Convention or the Protocols thereto, and if the internal
law of the High Contracting Party concerned allows only partial reparation to be made, the Court shall, if
necessary, afford just satisfaction to the injured party.”

_A. Pecuniary damage1. The applicant's claim and the Government's comments on it_

200. The applicant claimed 22,500 Bulgarian levs (BGN) (11,504 euros – EUR) in respect of pecuniary damage,
noting that this was the amount of the dismissed claim that she had lodged against X in respect of lost earnings. In
the additional submissions that she made after the Bulgarian Constitutional Court found Article 329 § 1 of the
Bulgarian Criminal Code unconstitutional (see paragraph 49 above), the applicant argued that it would be
impossible for the case against X to be reopened pursuant to a finding of a breach of Article 4 of the Convention by
the Court, as the case file was soon to be destroyed owing to the imminent expiry of the period during which it had
by law to be preserved.

201. The Government asserted that the claim had not been corroborated, given that in the proceedings against X
no evidence other than the applicant's assertions had been submitted regarding the total amount of her earnings
from sex work, and given that the Bulgarian courts had made no findings regarding the question of how much the
applicant had earned. Moreover, during the period in question X had covered the applicant's living expenses and
had given her pocket money.
_2. The Court's assessment_

202. There is no room for speculation regarding the question of whether, had the Bulgarian courts found the claim
against X in respect of lost earnings to have a sound basis in law, those courts would have considered the claim
made out on the facts – in particular as regards the specific sum sought by the applicant. The Court is hence not
satisfied that there is a sufficiently direct causal link between the breach of Article 4 of the Convention found in the
case and the pecuniary damage allegedly suffered by the applicant – the amount of her claim against X. It
accordingly dismisses the claim.


-----

203. That said, in the light of the nature of the breach, a reopening of the domestic proceedings and a reexamination of the matter at the national level would in principle constitute an appropriate means of remedying the
breach's pecuniary consequences (see, _mutatis mutandis,_ _Beeler v. Switzerland_ [GC], no. 78630/12, § 121, 11
October 2002, and Todorov and Others v. Bulgaria, nos. 50705/11 and 6 others, § 321, 13 July 2021). Bulgarian
law provides for the possibility of re-opening a case after the finding of a breach of the Convention by the Court, and
the destruction of a case file owing to the expiry of the period during which it had by law to be preserved is
apparently no bar to reopening the case in question (see paragraph 66 above).
_B. Non-pecuniary damage1. The applicant's claim and the Government's comments on it_

204. The applicant claimed EUR 10,000 in respect of non-pecuniary damage. In her view, that sum corresponded to
the nature of the breach.

205. The Government submitted that, given the nature of the breach, the applicant's claim was exorbitant. The
trafficking to which she had fallen victim had been investigated effectively, and her claim for compensation for nonpecuniary damage against X in respect of that trafficking had been fully allowed.
_2. The Court's assessment_

206. The applicant must have experienced some mental suffering on account of the dismissal of her claim for
damages against X in respect of lost earnings. Ruling in equity, as required under Article 41 of the Convention, and
taking into account, in particular, the nature of the breach (see, _mutatis mutandis,_ _V.C.L. and A.N. v. the United_
_Kingdom, cited above, § 219), the Court awards the applicant EUR 6,000, plus any tax that may be chargeable._
_C. Costs and expenses1. The applicant's claim and the Government's comments on it_

207. The applicant claimed either EUR 5,700 or EUR 5,800 (her claim contained inconsistent wording) in respect of
the fees that she asserted had been charged by her lawyer for twenty-six hours of work in respect of the
proceedings against X and thirty-one hours of work in respect of the proceedings before the Court, both at the rate
of EUR 100 per hour. In support of her claim, the applicant submitted a retainer agreement, dated 28 December
2017, between her and her lawyer in relation to the proceedings before the Court, and a timesheet. Under the
retainer agreement's terms, the lawyer would seek payment of her fees only after (and to the extent that) they had
been allowed by the Court, and would not be entitled to any remuneration if the application were to be declared
inadmissible or were not to result in the finding of a violation. The applicant requested that any award under this
head be made directly payable to her lawyer.

208. The Government noted that the retainer agreement had been drawn up only after the conclusion of the
proceedings against X, and on this basis questioned whether the lawyer's fees had actually been incurred. They
also considered the hourly rate charged by the applicant's lawyer excessive.
_2. The Court's assessment_

209. Costs and expenses may be awarded under Article 41 of the Convention if it is established that they were
actually and necessarily incurred and are reasonable as to quantum. Lawyers' fees have been actually incurred if
the applicant has either paid them or is liable to pay them (see, among other authorities, Merabishvili, cited above, §
371).

210. In this case, the retainer agreement submitted by the applicant does not relate to any lawyers' fees incurred in
respect of the criminal proceedings against X. Although the applicant was represented by the same lawyer both in
those proceedings and in the proceedings before the Court, the retainer agreement only concerns the latter. It is
also of some significance in this connection that the agreement was drawn up after the conclusion of the criminal
proceedings against X (see paragraphs 32 and 207 above). There is, then, no basis on which to accept that the
applicant has paid or incurred lawyers' fees incurred in relation to those proceedings. This part of her claim must
accordingly be dismissed.

211. By contrast, the retainer agreement and timesheet submitted by the applicant are sufficient to show that she
has actually incurred lawyers' fees related to the proceedings before the Court. Fees payable under a conditional
fee agreement – such as the agreement between the applicant and her lawyer – are deemed to have been actually
incurred if that agreement is enforceable in the respective jurisdiction which is the case in Bulgaria (see


-----

_Merabishvili, cited above, § 371, and Ivanova and Cherkezov v. Bulgaria, no. 46577/15, § 89, 21 April 2016). No_
doubt arises about the necessity of incurring those fees.

212. The fees are also reasonable as to quantum. The hourly rate charged by the applicant's lawyer (EUR 100) was
the same as that charged and accepted as reasonable in recent cases against Bulgaria of a similar level of
complexity (see Budinova and Chaprazov v. Bulgaria, no. 12567/13, §§ 104 and 108, 16 February 2021; Behar and
_Gutman v. Bulgaria, no. 29335/13, §§ 115 and 120, 16 February 2021; and Y and Others v. Bulgaria, no. 9077/18,_
§ 144, 22 March 2022). In the light of the degree of difficulty of the issues thrown up by the case and the content of
the submissions made on behalf of the applicant, the number of hours claimed (thirty-one) is likewise reasonable.

213. It follows that the applicant is to be awarded EUR 3,100, plus any tax that may be chargeable to her, in respect
of the lawyer's fees relating to the proceedings before the Court.

214. As requested by the applicant, this sum is to be paid directly into the bank account of her lawyer, Ms N.
Dobreva.
**FOR THESE REASONS, THE COURT, UNANIMOUSLY,**

1. _Joins_ to the merits the Government's objection that the complaint under Article 4 of the Convention is
incompatible ratione materiae with the provisions of the Convention, and dismisses it;

2. Declares the application admissible;

3. Holds that there has been a violation of Article 4 of the Convention;

4. Holds

(a) that the respondent State is to pay the applicant, within three months from the date on which the judgment
becomes final, in accordance with Article 44 § 2 of the Convention, the following amounts, to be converted into
the currency of the respondent State at the rate applicable at the date of settlement:

(i) EUR 6,000 (six thousand euros), plus any tax that may be chargeable, in respect of non-pecuniary damage;

(ii) EUR 3,100 (three thousand one hundred euros), plus any tax that may be chargeable to the applicant, to be
paid directly into the bank account of her lawyer, Ms N. Dobreva, in respect of costs and expenses;

(b) that from the expiry of the above-mentioned three months until settlement simple interest shall be payable
on the above amounts at a rate equal to the marginal lending rate of the European Central Bank during the
default period, plus three percentage points;

5. Dismisses the remainder of the applicant's claim for just satisfaction.

Done in English, and notified in writing on 28 November 2023, pursuant to Rule 77 §§ 2 and 3 of the Rules of Court.

1

1   That Protocol's translation into Bulgarian was published in the Bulgarian State Gazette on 6 December 2005 (ДВ,
_бр. 98 от 06.12.2005 г.,_ _стр. 40–44)._

2   That Convention's translation into Bulgarian was published in the Bulgarian State Gazette on 3 August 2007 (ДВ,
_бр. 63 от 03.08.2007 г.,_ _стр. 20-32). A small rectification to the translation was published on 25 November 2008 (ДВ,_
_бр. 101 от 25.11.2008 г.,_ _стр.58)._

3   Until 16 March 2022 the Russian Federation was a member State of the Council of Europe (see _Fedotova and_
_Others v. Russia [GC], nos. 40792/10 and 2 others, § 12, 17 January 2023)._

4   This question has been raised in M.A. and Others v. France (nos. 63664/19 and 4 others), in which people selling
l i l i h h i i li i f h b i f h i i F i f i h i i h d


-----

**End of Document**

Articles 2, 3 and 8 of the Convention. In June 2023 those applications were declared admissible, and the case is now
di h i ( _M A_ _d O h_ _F_ (d ) 63664/19 d 4 h 27 J 2023)


-----

