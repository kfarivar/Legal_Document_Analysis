# R v Henkoma [2023] All ER (D) 76 (Jul)

[2023] EWCA Crim 808

Court of Appeal, Criminal Division

EnglandandWales

Lady Justice Carr, Mrs Justice May and the Recorder of Sheffield (His Honour Judge Jeremy Richardson KC)

14 July 2023

**CRIMINAL LAW – APPEAL – FRESH EVIDENCE**
Abstract

_The Court of Appeal, Criminal Division, ruled on the appellant's appeal against the decisions made in the Crown_
_Court concerning his convictions on offences contrary to the_ _[Firearms Act 1968 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CN10-TWPY-Y0VN-00000-00&context=1519360)_ _[Bail Act 1976. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y1H2-00000-00&context=1519360)_
_appellant sought leave to appeal against those convictions, with applications to adduce fresh evidence and the_
_need for an extension of time. He submitted that he was a victim of trafficking (VOT) and the nexus of the trafficking_
_to the offending been known, the Crown Prosecution Service would or might well not have prosecuted him. His_
_criminality or culpability was significantly diminished and effectively extinguished. Further, he had no realistic_
_alternative but to comply with the dominant force of others. The Crown and/or police did not effect their operational_
_duties under art 4 of the European Convention on Human Rights to investigate his possible status as a VOT and_
_accordingly, his convictions were unsafe as a result. The court held that despite the significant delay in making the_
_applications, in the interests of justice, it granted the necessary extensions of time and leave as necessary. It_
_admitted fresh evidence but only to the extent of: (i) the contemporaneous social services and probation records_
_relating to the appellant; (ii) the conclusive grounds decision; and (iii) the appellant's (unchallenged) witness_
_statement of March 2022 as background to the appeal (despite reservations as to its reliability at least in parts)._
_However, the court dismissed the appeals on the merits and found that the convictions on both firearms offences_
_and the Bail Act offence were safe._
Digest

The judgment is available at: [2023] EWCA Crim 808

**Background**

The defendant, aged 25, was Nigerian. In 2014, then aged 16, he changed his plea in the Crown Court to guilty to
[possessing a firearm without a certificate, contrary to s 1(1)(a) of the Firearms Act 1968 (FA 1968). He also pleaded](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CMY0-TWPY-Y1H5-00000-00&context=1519360)
[guilty to failing to surrender to custody, contrary to s 6 of the Bail Act 1976 (BA 1976) (the Woolwich offences).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0TV-00000-00&context=1519360)

The defendant was sentenced to a four-month detention and training order for the firearm offence, and to seven
days' detention in a young offender institution for failing to surrender, to run concurrently.

Subsequently, the defendant, then aged 19, pleaded guilty to possessing a prohibited firearm and possessing
ammunition without a firearm certificate (the Isleworth offences). He was sentenced to 5 years' detention in a young
offender institution and 12 months' detention respectively, to run concurrently


-----

The defendant sought an extension of time, and leave, to appeal against the convictions. He also applied to adduce
[fresh evidence. He had an appeal as of right in respect of the BA 1976 offence, subject to the need for an extension](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y1H2-00000-00&context=1519360)
of time.

**Issues and decisions**

Whether the defendant should be granted leave to appeal. If so, whether fresh evidence should be admitted; and
whether the convictions were unsafe.

The defendant submitted that: (i) he had been a victim of trafficking (VOT) at the time of the offending, and that, had
his status and the nexus of the trafficking to the offending been known, the Crown Prosecution Service (CPS) would
not (or might well not) have prosecuted him; (ii) his criminality or culpability had been significantly diminished and
effectively extinguished, because he had had no realistic alternative but to have complied with the dominant force of
others; and (iii) the prosecution and/or police had not effected their operational duties under art 4 of the European
Convention on Human Rights (art 4) to investigate the defendant's possible status as a VOT.

The CPS opposed the applications.

In certain circumstances, the convictions of VOTs, following either guilty pleas or trial, might be unsafe on grounds
of abuse of process. An appeal against conviction was not a vehicle for 'restoring' international law rights that were
said to have been infringed. Breaches of art 4 did not, by themselves, render a prosecution unlawful. The focus had
to be on the safety of the conviction (see [33], [35] of the judgment).

The decision to prosecute was, ultimately, for the prosecution, and not the court. Where the prosecution had
applied its mind to the relevant questions in accordance with the applicable CPS guidance, it would not, generally,
be an abuse of process to prosecute, unless the decision to do so had clearly been flawed. The court did not
intervene merely because it disagreed with the ultimate decision to prosecute. It would review the decision by
reference to rationality and procedural fairness (see [37] of the judgment).

There were undoubtedly cases where, even where an applicant had been identified, post-conviction, as a VOT and
vulnerable, the decision to prosecute would have been the same. The gravity of the offending was clearly a material
factor. So much was clear from the Code for Crown Prosecutors in place at the material time for the purpose of
addressing the public interest stage of the prosecutorial decision-making process. It required prosecutors to
consider each of the following questions (in what was a non-exhaustive list): (i) how serious the offence committed
was; (ii) the level of culpability of the suspect; (iii) the circumstances of, and, the harm caused to the victim; (iv)
whether the suspect had been under the age of 18 at the time of the offence; (v) the impact on the community; (vi)
whether prosecution was a proportionate response; and (vii) whether sources of information required protecting. In
relation to question (iv), age, the Code stated that there could be circumstances which meant that, notwithstanding
the fact that the suspect was under 18, a prosecution was in the public interest. Those included where the offence
committed had been serious. The CPS Guidance in force at the time also stated that, where a victim of human
trafficking had been compelled to commit the offence, but not to a degree where duress was made out, it would
generally not be in the public interest to prosecute 'unless the offence [was] serious' or there were other aggravating
factors. Article 4 breaches needed to be considered as relevant factual matrix and part of the prosecutorial
decision-making process (see [40]-[43] of the judgment).

[In the present case, the defendant's convictions sat either side of the entry into force of the Modern Slavery Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
_[2015 (MSA 2015). In relation to the Woolwich offences, a defence under](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_ _[MSA 2015 s 45 (s 45) was, thus, not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
available to him. In relation to the Isleworth offences, possession of a prohibited firearm was an offence listed in
MSA 2014 Sch 4; thus, by reason of s 45(7), a s 45 defence was not available. The only offence to which a s 45
defence might have applied was count two, namely possession of ammunition without a firearm certificate (see [32]
of the judgment).

The question was whether, on the present facts, abuse of process was made out, such as to render the defendant's
convictions unsafe. In answering it, the court proceeded on the basis of what was common ground, namely that
there had been multiple breaches of art 4 affecting the defendant both before and after the relevant offending had


-----

occurred. In particular, there had been multiple occasions when he should have been referred to the 'NRM', and
had not been. However, it was not a case of total inactivity on the part of the social services. Attempts had been
made to move the defendant to safety from time to time, for example, and it was not clear that the defendant,
himself, had always been prepared to do so (see [34], [43] of the judgment).

The present offending had been of the utmost seriousness. The scales were tipped firmly in favour of prosecution in
the public interest. In the prosecution's assessment, prosecution had been entirely proportionate in all the
circumstances. The prosecution had conscientiously revised the decision to prosecute the defendant in light of the
relevant material, and its position that the prosecution would be pursued had not been flawed, let alone clearly so. A
balancing exercise had had to be carried out. Even recognising the defendant's age at the time of the offending,
and the circumstances underlying it, there had been nothing irrational in the view that it had, nevertheless,
remained in the public interest to prosecute. Nor would the court have stayed the prosecutions, had any application
to that effect been made. In short, there had been no abuse of process (see [45]-[49] of the judgment).

Standing back, despite the significant delay in making the present applications, it was in the interests of justice to
grant the necessary extensions of time and leave, as necessary. Fresh evidence would be admitted to the following
extent: (i) the contemporaneous social services and probation records relating to the defendant; (ii) the 'CG
decision'; (iii) the defendant's (unchallenged) witness statement of March 2022 as background to the appeal (see

[55] of the judgment).

[However, the appeal would be dismissed on the merits. The convictions on both firearms offences and the BA 1976](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y1H2-00000-00&context=1519360)
offence were safe. Although the defendant had been a VOT at the time of the offending, and the relevant nexus had
existed, and although he had not been adequately safeguarded by the relevant authorities, there was no proper
basis for going behind the prosecution's positive assertion that it would have maintained both prosecutions, as
being in the public interest (see [56] of the judgment).

_R v GS_ _[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2018] All ER (D) 90 (Aug) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_

_R v AAD and others_ _[[2022] EWCA Crim 106, [2022] 1 WLR 4042 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_

_R v AFU_ _[[2023] EWCA Crim 23 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_

_R v LM_ _[[2010] EWCA Crim 2327, [2010] All ER (D) 202 (Oct) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

_R v AAJ_ _[[2021] EWCA Crim 1278 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_

_R v Horseferry Road Magistrates' Court, ex p Bennett [1994] 1 AC 42, [1993] 3 WLR 90, 98 Cr App Rep 114_
considered

_R v Thakoraka-Palmer_ _[[2023] EWCA Crim 491 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:687T-B893-T0JN-P280-00000-00&context=1519360)_

_R (on the application of Barons Pub Co Ltd) v Staines Magistrates' Court_ _[[2013] EWHC 898 (Admin), [2013] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5879-9FJ1-DYBP-N173-00000-00&context=1519360)_
_[(D) 141 (Apr) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5879-9FJ1-DYBP-N173-00000-00&context=1519360)_

_R v A [2020] EWCA Crim 1408 considered_

Appeal dismissed.

Benjamin Douglas-Jones KC and James Robottom (instructed by Philippa Southwell of Southwell & Partners
Solicitors) for the defendant.

Andrew Johnson (instructed by the Crown Prosecution Service) for the Crown.
Carla Dougan-Bacchus Barrister.


-----

**End of Document**


-----

