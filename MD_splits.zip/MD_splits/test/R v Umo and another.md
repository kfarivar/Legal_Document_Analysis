# R v Umo and another [2020] EWCA Crim 284

Court of Appeal, Criminal Division

Fulford LJ VP, Sweeney and Lambert JJ

28 February 2020Judgment

**Ms Yimi Yangye (instructed by Registrar) for the 1st Appellant**

**Ms Laura Brickman (instructed by Registrar) for the 2nd Appellant**

**Mr Simon Sanford (instructed by CPS Appeals & Review Unit) for the Respondent**

Hearing dates : 12th November 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Fulford:**

**Introduction**

1. As summarised in the table below, on 21 September 2018, at the Crown Court at Woolwich on
indictment T20187185, the appellant Benjamin pleaded guilty to counts 2, 3 and 4; on 17 December 2018,
at the same court, the applicant Umo was convicted by a jury of counts 5, 6 and 7; and on 14 March 2019,
they were sentenced by Judge Miller.

|Count on indictment T21087185|Offence|Sentence|
|---|---|---|
|2|Unlawful wounding (s. 20 Offences Against the Person Act 1861)|Benjamin (guilty plea with 20% discount): 25 months' imprisonment|
|3|Robbery (s. 8(1) Theft Act 1968)|Benjamin (guilty plea with 20% discount): 9 years 8 months' imprisonment concurrent|
|4|Having a firearm with criminal intent (s. 18(1) Firearms Act 1968)|Benjamin (guilty plea with 20% discount): 2 years 11 months' imprisonment concurrent|
|5|Possessing a prohibited firearm (s. 5(1)(aba) Firearms Act 1968)|Umo (conviction): 3 years' detention in a young offender institution|


6


[Assault by beating (s. 39](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YF0-TWPY-Y16Y-00000-00&context=1519360)


Umo (conviction): 3 months' detention in a young offender
institution concurrent


-----

|Col1|Criminal Justice Act 1988)|Col3|
|---|---|---|
|7|Assault occasioning actual bodily harm (s. 47 Offences Against the person Act 1861)|Umo (conviction): 6 months' detention in a young offender institution concurrent|


2. Umo and Benjamin were tried together, and acquitted, on count 1, a charge of wounding with intent.
Umo was acquitted on count 2 (wounding), count 3 (robbery) and count 8 (witness intimidation). The jury
were unable to reach a verdict on count 4 (having a firearm with criminal intent).

3. It follows that the total sentence passed on Benjamin on 14 March 2019 was 9 years and 8 months'
imprisonment. However, he had earlier pleaded guilty at the Inner London Crown Court to an offence that
mirrored count 5 in indictment T21087185 (possessing a prohibited firearm), along with other offences. He
was sentenced at Inner London Crown Court on 4 May 2018, with a discount of 25% for plea in each
instance, to 81 months' imprisonment for the firearm offence and a consecutive sentence of 39 months for
possessing a controlled drug of class A with intent to supply. There were concurrent sentences of 18
months for possessing ammunition without a certificate and 39 months on a further count of possessing a
controlled drug of class A with intent to supply. The total sentence imposed at Inner London Crown Court
was 10 years' imprisonment. The sentences that are the subject of this appeal (viz. those from indictment
T21087185) were ordered to run consecutively to the sentence of 10 years, making a total sentence of 19
years and 8 months' imprisonment. The discounts applied for his various pleas mean that Benjamin's
overall notional sentence after trial for all the offences was 25 years and 4 months' imprisonment.

4. Umo's total sentence was 3 years' detention in a young offenders institution.

5. There were two co-accused on indictment T20187185. Daniel Newton was acquitted on count 1
(wounding with intent). He was convicted on count 2 (wounding) and count 3 (robbery). He was sentenced
to 9 years' imprisonment. Oluwabiyi Ayanwale was acquitted of all counts he faced on the indictment,
counts 1, 2, 3 and 9 (the latter count was possession of an imitation firearm).

6. Before this court, Umo applies for an extension of time, 31 days, to apply for leave to appeal her
conviction, these applications having been referred by the single judge to this court. Benjamin appeals
sentence by leave of the single judge.

7. We grant Umo the necessary extension of time. Significant prosecution material was only served after
her conviction and, in our view, the timing of the service of this material provides a good reason for the
delay, which is not excessive, in advancing the grounds of appeal (albeit it only related to one of the
grounds).

**The Facts**

8. Benjamin was involved in dealing class A drugs, assisted by one of the co-accused, Daniel Newton. On
8 February 2018, Newton was robbed of mobile telephones, money and drugs, which “belonged” to
Benjamin. One of the mobile telephones had been used to contact drug customers.

9. On 16 February 2018, there was an attack on Kyzia Sandiford, the victim in counts 1 – 3. He was
robbed and wounded. Three men ran up to him whilst he was walking through the estate where he lived.
One of them put Sandiford in a choke hold. Another, said to be Benjamin, pointed a revolver at him and
told him to shut up. The third man pulled a second gun out of his bag. The refrain “where's the phone?”
was repeated, and they took his telephone. One of the guns was discharged. Sandiford was forced to the
floor and stabbed in the left leg, causing damage to an artery. After the three attackers then ran off,
Sandiford managed to drag himself up to his flat where he passed out. He came round in an ambulance,
en route to hospital in the early hours of 17 February 2018. He was discharged on 20 February 2018. The
injury led to “foot drop” and in all likelihood he will have suffered permanent nerve damage (the condition
was still evident in July 2018 and ongoing outpatient treatment has been necessary). Sandiford identified


-----

Newton as the man who stabbed him. By his guilty pleas, Benjamin accepted his involvement in this
offending. The other attacker was said by the Crown to be Ayanwale.

10. The prosecution alleged that Benjamin had asked Umo (who was one of his girlfriends) to help trace
the people responsible for the robbery of Newton. It was alleged that Umo provided Benjamin with the
revolver, which she had been hiding on his behalf, to be used in the attack on Sandiford. Although the
prosecution asserted she had been an integral part of the planning, it was not maintained that Umo had
been present when the robbery and stabbing took place.

11. The main elements of the case against Umo can be shortly described. The prosecution alleged she
had tried to use Anouska Maduro, with whom she shared accommodation and who was called as a witness
at trial, to provide or obtain information on the identity of those responsible for the robbery of Newton, as
well as to look after one of the guns used in the attack on Sandiford. Maduro, however, did not assist and
instead contacted the police in May 2018 to complain she had been assaulted by Umo, who she claimed
was angry at her lack of cooperation. She told the police that Umo had been in possession of a gun in
February 2018 (count 5). She had overheard telephone conversations between Umo and a Jamaican
male, whose voice she recognised as a man who visited their address and gave them cannabis. In the first
of these telephone calls, she heard the man tell Umo to bring him the “strap”, following which Umo left the
address and returned some 20 minutes later. Ms Maduro then overheard a second conversation in which
the man told Umo that she needed to collect the gun which had been stashed in some bushes. Umo went
back out and when she returned she showed Ms Maduro a gun. Umo wrapped it in a tea towel. Umo told
her that the Jamaican's friend Tiny had been robbed and that they had been getting pay back (Tiny was the
nickname for Newton). Ms Maduro says that she and Umo stopped speaking after that because Ms
Maduro refused to hold the gun for Umo.

12. In relation to count 6 (assault by beating), her evidence was that Umo knocked on the door of her
accommodation on 14 May 2018. When she opened the door, Umo dragged her to the stairs where she
got on top of her and punched her. Ms Maduro managed to get back to her room, from where she called
the police. Her lip was bleeding. She denied being the aggressor and said that she had been attacked by
Umo because she had failed to provide her with assistance. These events were caught, in part, on CCTV
footage.

13. As regards count 7 (assault occasioning actual bodily harm), she was at Bromley County Court on 28
June 2018 when she said the applicant unexpectedly grabbed her from behind and punched her in the
face. She was then dragged to the floor where she was punched and kicked. The applicant called her a
“snitch”. She suffered a black eye and other bruising. The prosecution case was that the attack was
intended to intimidate Maduro and to dissuade her from cooperating with the police.

14. Rene St Hilaire gave evidence that he worked in the semi-independent living accommodation where
Umo and Ms Maduro had rooms. Umo left the accommodation in May 2018, and there was an inspection
following her departure. He noticed a hole in the base of the divan bed in her room. The bed had been new
when Umo arrived, and the hole had not been there when it was bought. The damage to the bed had not
previously been apparent because it had been covered. Gunshot residue was found in the area of the hole
which could have been deposited by a recently fired gun, spent ammunition, or an item or person
contaminated with gunshot residue. It was sufficiently large to hold a handgun.

15. Benjamin was arrested on 22 February 2018. In a safe at the home of his girlfriend, Stephanie Adiken,
the police found the revolver, ammunition and a large amount of heroin and crack cocaine. These formed
the basis of the offences to which Benjamin pleaded guilty at the Inner London Crown Court. He declined
to answer questions in interview.

16. Umo was arrested on 16 May 2018. She answered “no comment” to the questions put to her in
interview but provided a prepared statement in relation to the alleged assault on 16 May of Ms Maduro
(count 6), in which she indicated she had acted in self-defence. She was re-arrested on 29 June 2018 for
the assault in count 7. On this occasion she answered questions in interview, again said she had acted in
self-defence and denied she had intimidated Ms Maduro.


-----

17. There was telephone evidence – “prison chats” – between Benjamin and Umo, following Benjamin's
remand in custody.

18. Umo gave evidence at trial that she had had a sexual relationship with Benjamin from August 2017
when she was 16 and he was 26. She knew Ms Maduro because they lived in the same shared
accommodation. They had a falling out in February 2018 because Ms Maduro owed money to the applicant
for a haircut. She said she asked Ms Maduro for information on social media about some “boys” who were
connected to a stabbing in Bromley, an incident which was wholly unrelated to the robbery of Newton. She
denied she had been given a gun to hold, or that she provided one to Benjamin on 16 February or at any
other time. Her account was that she had been at her home address on the evening of the 16 February
2018 until about 10.40pm, when she left to attend a party given by Newton. She had been invited by
Benjamin. She said there was no conversation at the party about a stabbing, a shooting or drugs.
Benjamin, she asserted, kept his business to himself. In relation to the telephone conversations between
herself and Benjamin, she said that she had been talking about money, because she looked after cash for
him. She could not account for the hole in the divan bed or the gunshot residue but she did not accept it
was a new bed. In relation to the alleged violence against Ms Maduro, she said that she had acted in selfdefence.

**The Grounds of Appeal: Umo**

**_Conviction_**

19. By way of background, the appellant highlights the importance of Ms Maduro as a witness, who first
gave her account on 16 May 2018, 3 months after the events of 16 February 2018. The first ground of
appeal relates to the suggested bad character of Ms. Maduro.

20. Shortly before 2pm on 21 November 2018, immediately before St Hilaire was due to give evidence, the
prosecution disclosed to Umo's counsel that Ms Maduro had made an allegation of sexual assault against
him (this imputation by Ms Maduro against St Hilaire was made in June 2018, two weeks after she
provided a statement implicating the applicant). Ms Maduro alleged that St Hilaire had pressured her into
having sexual relations with him and that she had been an unwilling participant. She also alleged he was
having sex with another resident, Savannah George. The prosecution disclosed that St Hilaire had been
interviewed in August 2018, when he denied the allegation. In addition, he alleged that Ms Maduro had
tried to blackmail him via a text message, indicating that if he did not give her £2,000, she intended to
allege sexual misconduct against him (this threat by text message appears to have predated the disclosure
of the alleged sexual assault to the police in June 2018). Savannah George, when questioned, denied
having any sexual relationship or encounter with St. Hilaire. Furthermore, Ms Maduro refused to make a
statement about this alleged assault.

21. Somewhat surprisingly, the prosecution did not attempt to look at or copy the text message on St
Hilaire's telephone, notwithstanding the fact that during course of his interview he had handed his mobile
phone containing the message(s) from Ms Maduro to the police. Instead, they provided what was
suggested to be his account of the message he had received.

22.  On receipt of this disclosure, Umo's counsel, Ms Yangye, immediately applied to the judge to be
permitted, by questioning St Hilaire, to introduce evidence of bad character relating to Ms Maduro (viz. that
she was prepared to invent false allegations of a serious criminal nature and to blackmail the intended
victim of those fictitious allegations). It was argued that these events bore marked similarities to Umo's
defence, namely it was suggested that Ms Maduro was lying about Umo because she had fallen out with
her following the incident between them on 14 May 2018 (count 6), which led to the first complaint by Ms
Maduro about the applicant to the police regarding the events on 16/17 February 2018 (count 5). The facts
she sought to adduce were:

i) The nature of the allegation made by Ms Maduro;

ii) St Hilaire's assertion that the allegation was false;


-----

iii) The timing of events, namely that the allegation was made following an unsuccessful attempt to
blackmail St Hilaire; and

iv) The details of the relevant text message.

23. Ms Yangye suggested that the contents of the text message, as described by St Hilaire, potentially
provided a firm basis for the jury to resolve any evidential conflict between Ms Maduro and St Hilaire. She
contended that if the applicant had a credible foundation for establishing that Ms Maduro had tried to
blackmail St Hilaire by seeking a large sum of money as the price of not falsely accusing him of a sexual
offence (the allegation she was to make), that, it was submitted, would tend significantly to undermine her
credibility. The judge, having heard these preliminary submissions, was not prepared to interrupt the
course of the trial and he indicated that St Hilaire could be recalled to be questioned on this issue if Umo's
bad character application was successful.

24. Later on the same day, Ms Yangye submitted a written application to admit this evidence, pursuant to
[section 100 Criminal Justice Act 2003 (“CJA 2003”). She developed her request to question St Hilaire](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)
about the nature of the allegation made by Ms Maduro, his denial and the contents of the text message. Ms
Yangye also applied to adduce the false assertion by Ms Maduro concerning Savannah George, who
seemingly did not support the allegation that she had had sexual relations with St Hilaire. The submission
was repeated that this went to the issue of Ms Maduro's credibility (particularly demonstrating a propensity
to make false allegations) and Ms Yangye suggested that the question for the judge was whether the
misconduct had substantive probative value pursuant to section 100 (1) (b) _[CJA 2003. The section, as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
relevant, provides:

**“100 Non-defendant's bad character**

(1) In criminal proceedings evidence of the bad character of a person other than the defendant is
admissible if and only if—

(a) it is important explanatory evidence,

(b) it has substantial probative value in relation to a matter which—

(i) is a matter in issue in the proceedings, and

(ii) is of substantial importance in the context of the case as a whole,

or

(c) all parties to the proceedings agree to the evidence being admissible.

[…]

(3) In assessing the probative value of evidence for the purposes of subsection (1)(b) the court must have
regard to the following factors (and to any others it considers relevant)—

(a) the nature and number of the events, or other things, to which the evidence relates;

(b) when those events or things are alleged to have happened or existed;

(c) where—

(i) the evidence is evidence of a person's misconduct, and

(ii) it is suggested that the evidence has probative value by reason of similarity between that misconduct
and other alleged misconduct,

the nature and extent of the similarities and the dissimilarities between each of the alleged instances of
misconduct;

(d) where—

(i) the evidence is evidence of a person's misconduct,

(ii) it is suggested that that person is also responsible for the misconduct charged and


-----

(iii) the identity of the person responsible for the misconduct charged is disputed,

the extent to which the evidence shows or tends to show that the same person was responsible each time.

[…]”

25. As to the test to be applied, Ms Yangye submitted this was whether the bad character evidence would
affect Ms Maduro's standing with the jury. She argued that it would be for the jury to determine where the
truth lay, and that the court's role was to decide if the allegation was capable of being believed (or whether
it was demonstrably untrue for the purposes of section 109 CJA 2003 (see below)). By way of a subsidiary
submission, Mr Yangye applied for Umo's case to be severed if the judge determined that there needed to
be further investigation into the allegations made by Ms Maduro before a decision could be made on the
application to introduce bad character evidence.

26.  The judge formulated the question he needed to address as:

“[…] whether the issue is of substantial importance in the context of the case as a whole, and whether the
evidence has substantial probative value in relation to that issue, the issue of credibility. Assuming that
Miss Maduro's credibility is of substantial importance in the context of the case, then the only issue for me
to determine is whether the evidence in question, the allegation that she has fabricated a complaint against
another, does have substantial probative value in relation to that issue.”

27. The judge resolved the application as follows:

“The evidence of a false compliant is no more than evidence of an allegation being made. It is not evidence
that Miss Maduro has made a false complaint. There does not appear to me to be any hard evidence of a
false allegations being made, even though there is a text message from Miss Maduro to Mr St Hilaire
giving her bank details.

In order to rely upon this as a reason to disbelieve Miss Maduro, the jury would have to consider whether
they thought that she has made a false complaint. This would involve a mini trial, probably including
recalling Mr Rene St Hilaire to give evidence about whether indeed he had had an inappropriate sexual
relationship with Miss Maduro. This would amount to what I regard as classic satellite litigation. My
understanding is that Miss Maduro has alleged misconduct against Mr St Hilaire, he has denied it, and he
has made a counter-allegation against her.

[…]

The impossibility of resolving whether this is a false allegation by her or a true allegation by her drives me
to the view that adducing this evidence would not have substantial probative value in relation to the issue
of Miss Maduro's credibility, and on the basis that it is going to be almost impossible to resolve, I take the
view that the evidence of this alleged false allegation does not have substantial probative value in relation
to the issue of Miss Maduro's credibility, in particular, because Miss Maduro's evidence is capable of being
supported by other evidence – for example, cell site evidence, telephone chats, and some forensic,
scientific evidence – so for those reasons the application is refused”

28. The judge did not refer in his ruling to the application to sever the indictment, but it is implicit from his
decision that he did not consider that the evidential dispute between Ms Maduro and St Hilaire was
capable of satisfactory resolution, and it would inevitably follow he was of the view there was no need to
sever the applicant's case in order for further enquiries to be made.

29. In support of this application, Ms Yangye submits that there had been a clear possibility of establishing
this bad character evidence, in particular by way of the content of the text message coupled with St
Hilaire's evidence, the denials of Savannah George and the failure by Ms Maduro to provide a statement. It
is argued that the judge erred in refusing to admit this evidence.

30. The Crown emphasise that the jury had been told of Ms Maduro's previous convictions. It is submitted
that the judge's decision on these cross allegations was correct, not least because they amounted to a
distraction. The hole in the bed and the residue, along with the messages between Umo and Benjamin,
were said to be the critical and, for the applicant, unavoidable evidence. As to the safety of the conviction,


-----

the prosecution suggest there was strong evidence wholly independently of Ms Maduro that Umo was in
possession of the gun.

31. We heard argument on this application during 12 November 2019. On 13 November 2019, the
Registrar sent directions, pursuant to a request from the court, for the respondent to provide certain
materials to assist the court. These included the details of the complaint made by Ms Maduro against St
Hilaire; the record of St Hilaire's interview in August 2018; the exact terms of the blackmail allegation in the
text message; and the detail of the relevant text message or text messages between Maduro and St Hilaire
concerning the allegation of sexual impropriety, the attempted blackmail and any monies owed by social
services to Ms Maduro (the latter constituting her explanation for the text message to St Hilaire). Once
received, the parties were to file supplementary submissions in writing. The respondent, via various routes,
has complied with the main elements of these requests. Although the full interview with St Hilaire has not
been recovered from storage, the summary is relatively comprehensive, certainly as regards the present
context, and we have not required further searches to be conducted. The contents of the telephone were
not “downloaded”, and it was returned to St Hilaire who no longer has it in his possession (he purportedly
disposed of it in a rubbish bin). However, it is now clear that the full alleged blackmail threat, if made, was
during a telephone call. The text message, of which we have been sent a “screenshot”, contained the bank
details and arguably some aspects of the blackmail threat. The telephone which was used to send the text
message was Ms Maduro's and she provided St Hilaire with her bank details. St Hilaire sent a copy of the
relevant text message to his then manager, which has latterly been recovered. It read:

“(Bank account number)

(Sort code)

Miss Anouska Maduro

Sort it

You got TIL 5 done the games

Or police are coming to unit”

32. The credibility of Ms Maduro was clearly a matter in issue in the proceedings and it was of substantial
[importance in the context of the case as a whole (section 100 (1)(b)(i) and (ii) CJA 2003). The important](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)
question, therefore, is whether this material had substantial probative value in relation to the issue of her
credibility. This entails assessing the potential utility of this evidence for the jury, given the issues in the
case. The test in these circumstances was helpfully formulated in _R v Brewster and Cromwell [2010]_
_EWCA Crim 1194; [2010] 2 Cr App R 20 as whether the misconduct relied on is reasonably capable of_
assisting a fair-minded jury to reach a view on whether the evidence of the witness is, or is not, worthy of
belief. It is relevant to note that the judge had ruled that Ms Maduro could be cross-examined about her
previous convictions and cautions for violence (four offences involving affray and battery).

33. This material provided prima facie evidence that Ms Maduro was prepared to blackmail a “key worker”
by threatening to report a false allegation to the police of a sexual nature if he failed to transfer a
substantial sum of money to her bank account. It similarly had the potential to establish that when St Hilaire
failed to comply with Ms Maduro's demands, she was prepared to act on her threat and made the false
report to the police. This allegedly false account against St Hilaire was provided to the police within a
fortnight of the allegations Ms Maduro advanced against the applicant. In both instances, it was suggested
that she was motivated by personal reasons (viz. a grievance against Ms Maduro and personal enrichment
as regards St Hilaire) to invent serious criminal allegations.

34. We have had regard to section 109 CJA 2003, which provides:

“Assumption of truth in assessment of relevance or probative value

(1) Subject to subsection (2), a reference in this Chapter to the relevance or probative value of evidence is
a reference to its relevance or probative value on the assumption that it is true.


-----

(2) In assessing the relevance or probative value of an item of evidence for any purpose of this Chapter, a
court need not assume that the evidence is true if it appears, on the basis of any material before the court
(including any evidence it decides to hear on the matter), that no court or jury could reasonably find it to be
true.”

35. The judge, in our view, erred in concluding that this allegation, founded principally on the account of St
Hilaire and the text message, was not **evidence of a false complaint. To the contrary, this material**
constituted separate strands of direct evidence. In _R v Darren Luckett_ _[[2015] EWCA Crim 1050, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G68-FC71-F0JY-C1R6-00000-00&context=1519360)_
appellant argued that the judge had wrongly refused to permit him to introduce bad character evidence to
the effect – as he intended to testify – that the complainant in the case had been exposed to assault by
others because of his association with drug dealers. As Lloyd Jones LJ put the matter

“25. Moreover, the fact that the only basis for these allegations against the complainant was the account
given by the appellant himself should not, of itself, have been considered a reason for excluding this
evidence; as Miss Samuel, on behalf of the Crown, accepts before us today.

[…]

27. The judge's reason for excluding it seems to have been that the defendant's assertions were not of
substantial probative value. In our view, that is to confuse the concepts. If the allegations were true — and
the assumption is that they were true — then they clearly had substantial probative value in the context of
this case. The fact that the allegation came from the appellant alone was not, of itself, a reason for refusing
the application. We also note that other allegations which were allowed to be made emanated from the
applicant alone, in particular those which had resulted in the appellant reporting matters to the police and
which were then recorded in a police report.”

36. The judge in the present case was concerned that this was simply an “allegation”. In R. v Braithwaite
_2010 EWCA Crim 1082; [2010] 2 Cr App R 18 at [20], Hughes LJ, when addressing the issue of hearsay in_
this context (viz. a report of a complaint), indicated “[i]t might be different if hard evidence of the allegation
were to become available and if that is what the applicant were to seek to adduce”. In the present case, the
account of St Hilaire and the text message were both pieces of “hard evidence”.

37. The judge was right, however, to consider whether the evidential dispute was capable of resolution by
the jury (albeit at the stage of determining admissibility the court will proceed on the basis that the evidence
is “true”: see section 109 CJA 2003 above). This is an important factor when considering applications in
these circumstances. Even allowing for the assumption of the truth of the evidence, it may yet fail to satisfy
the other elements of the admissibility test in s.100(1)(b). Lord Judge CJ addressed this possibility in R. v
Dizaei [2013] EWCA Crim 88; [2013] 1 Cr. App. R. 31, as follows:

“36. […] a fact-specific judgment directed to the statutory conditions in s.100(1)(b) and 100(3) must be
made whether to admit evidence of bad character (within the ambit of s.98(a) of the 2003 Act).Where it
applies, the assumption in s.109 is not determinative of the admissibility question. Rather, it provides the
context in which the admissibility decision falls to be made. In short, the pre-conditions to admissibility
under s.100(1) are not automatically established, and, notwithstanding the evidential assumptions provided
by s.109 at the admissibility stage, the bare fact of an allegation (even if assumed to be true) is not
necessarily conclusive of the question whether it constitutes substantial probative evidence or evidence of
substantial importance in the context of the case as a whole. If it were otherwise, the court would be
obliged to admit evidence of an allegation of a serious crime allegedly committed by the witness, even if it
had been fully investigated by the police, but, because the investigation revealed serious doubts about the
complainant's veracity, on the basis that the complainant continued to insist that the allegation was true.
Accordingly, […] we do not see how the necessary judgment whether the pre-conditions to admissibility
under s.100 are satisfied can be made without a careful examination of all the material which bears on the
question.

37. A trial concerned with whether it is proved that the defendant has committed crime “A” is liable to be
derailed if the jury is required to decide whether a witness has committed the distinct, separate crimes, “B”
and “C”. As we have explained, the evidential assumption in s.109 does not bind the jury, and the


-----

investigation of this evidence at trial may be liable to distract attention from the crucial issue which is
whether the case against the defendant has been proved. If, in the context under discussion, the judge
correctly directs the jury that they must not consider the alleged bad character evidence unless they are
sure that it is true, two trials would be simultaneously in progress before the same jury. First, the trial of the
defendant for the crime alleged against him by the prosecution; and secondly, the crime or misconduct
alleged against the witness.”

38. We note that the judge did not err by refusing to admit this material simply to avoid satellite issues (see
_Burchell_ _[[2016] EWCA crim 1559 at [20]). As set out above, he addressed the issue in the following way:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M06-JNV1-F0JY-C18W-00000-00&context=1519360)_
“(t)he impossibility of resolving whether this is a false allegation by her or a true allegation drives me to the
_view that adducing this evidence would not have substantial probative value in relation to the issue of Miss_
_Maduro's credibility_ […]”. Although he correctly considered whether this evidence would have substantial
probative value in relation to Ms Maduro's credibility, for the reasons set out above we consider he wrongly
determined that the issue was irresolvable. Ms Yangye conceded that without the text message to support
St Hilaire's account, she would not have advanced this application because the jury would have been put in
the position of trying to decide between two conflicting witnesses with no apparent basis to choose
between them. In that situation, evidence of this kind will frequently lack “substantial probative value”
because of the difficulty in assessing the truth of the divergent accounts of the witnesses, certainly without
embarking on a second simultaneous trial, which is a course that needs to be avoided. In this case,
however, as we have set out, there was a clear basis for the _prima facie conclusion that St Hilaire had_
been threatened that a false and serious allegation would be made against him if he failed to pay a
substantial sum of money to Ms Maduro. Furthermore, the evidence on the issue would have been of
appropriately short duration. In those circumstances, we are of the view the judge erred in refusing the bad
character application.

39. The next question is whether the wrongful refusal of the application renders Umo's convictions unsafe.
As to count 5 (possession of a firearm), the respondent submits that the case against the applicant,
independent of the evidence of Ms Maduro, was strong. In particular, there were a number of text
messages that tended to indicate that she had been tracing those responsible for the attack on behalf of
Benjamin; she went to Benjamin's home after the robbery, and stayed with him that night; residue was
found in the hole in the divan bed which was linked to a firearm; and there was a prison call with Benjamin
in which she indicated he should have left the gun (“whap”) with her. For count 6 (assault), the applicant
went to Ms Maduro's room and in relation to count 7 (assault) she was at Bromley County Court in breach
of her bail conditions. Part of the events in count 6 – but not the beginning of the incident – were caught on
CCTV footage.

40. Although these submissions were well made by Mr Sandiford on behalf of the respondent, Ms Maduro
was the central witness against the applicant on counts 5, 6 and 7. As set out above, for count 5 she
overheard the telephone conversations between Benjamin and Umo and she gave evidence that she saw
a gun (which the prosecution suggested had been used during the robbery). She was the alleged victim of
the two assaults in counts 6 and 7, and she said the applicant was the instigator of the violence and was
the aggressor. On count 5, if the jury had doubted Ms Maduro's testimony because – as submitted – of her
preparedness to invent serious allegations for personal reasons, there undoubtedly remained a clear case
for the applicant to answer. But we are unable to conclude that the remainder of the evidence would
necessarily have resulted in her conviction. Although the other elements of the prosecution case on the
count of possession of the firearm were undoubtedly of some real cogency, we are left in doubt as to
whether the applicant was rightly convicted (see Graham (H.K.); Kansal; Ali (Sajid); Marsh [1997] 1 Cr.
App. R. 302 at page 307). Notwithstanding the CCTV footage for count 6, for both counts 6 and 7 Ms
Maduro's evidence was necessary for a conviction. Her evidence alone established she was the victim of
the two assaults. Put otherwise, if Ms Maduro's account is taken out of the equation, we have doubts as to
the safety of the conviction on count 5, and guilty verdicts on counts 6 and 7 would have been impossible.

41. It follows that for these reasons, the applicant's convictions on counts 5, 6 and 7 must be set aside.
There was a second ground of appeal, namely that since the trial it has become apparent that the National
Crime Agency determined that the applicant was the victim of modern slavery, in that she was exploited


-----

for labour by Benjamin. In light of our conclusions on the ground of appeal relating to the bad character
application, it is unnecessary for us to consider this alternative challenge to the safety of Umo's conviction.

42. We grant leave to appeal and quash Umo's convictions on counts 5, 6 and 7.

**The Grounds of Appeal: Benjamin**

**_Sentence_**

43. By way of background, Benjamin, who was aged 28 when he was sentenced at Woolwich Crown
Court, had 8 convictions for 19 offences (largely relating to drugs) in the period spanning 2008 to 2018.

44. After the trial, the judge ordered a pre-sentence report in relation to dangerousness. The author of the
report opined that Benjamin appeared not to accept his responsibility for his offending, and assessed that
he posed a high risk of harm, to both known individuals and the public generally, of further violent
offending. The author invited the judge to consider that assessment when coming to a decision on
dangerousness.

45. In a comprehensive sentencing note to the judge, the respondent asserted that, applying the relevant
Guideline, the robbery (count 3) was a category 1A offence, and thus attracted a starting point of 8 years'
custody, with a range of 7 to 12 years. It was further asserted that the wounding (count 2) was a category
1 offence (and thus attracted a starting point of 3 years' custody, with a range of 2 years 6 months to 4
years). However the respondent recognised that count 3 was a category 1A offence because it involved
both greater harm (the seriousness of the wounding) and higher culpability (premeditation and the joint
enterprise use of both a knife and at least one gun) and that therefore a concurrent sentence was likely to
be imposed on count 2. As to count 4, the respondent accepted that, given the substantial term of
imprisonment imposed for the possession of the same revolver on arrest (6 days after the instant
offences), it was open to the court to find that the imposition of the minimum term of 5 years' custody
would result in an arbitrary and disproproportionate sentence, and that therefore the court could find that
“exceptional circumstances” existed which justified a reduction from the minimum. Finally, the respondent
drew attention, in some detail, to the Guideline in relation to totality, and submitted that, amongst various
options, it was open to the court to impose concurrent sentences for the instant offences - which would run
fron the date of sentence, but could result in an overall sentence of greater length than the sentence
imposed at Inner London Crown Court, provided that it was just and proportionate.

46. In her Response on behalf of Benjamin, Ms Brickman indicated that, on count 4, she would argue that,
given the length of the sentence imposed at Inner London Crown Court for possession of the same gun,
there were “exceptional circumstances” such that imposition of the minimum term would be arbitrary and
disproportionate. As to count 3, Ms Brickman submitted that the Respondent's categorisation of the
offence was too high. On count 2, Ms Brickman submitted that a concurrent term should be imposed. She
also underlined that, overall, the principle of totality applied.

47. In passing sentence on Benjamin, the judge variously observed that:

(i) He was sentencing against the background of Benjamin's admitted drug dealing, and that Benjamin was
the principal offender, who had exercised influence over others.

(ii) It had been a premeditated revenge robbery - in which Benjamin, who had arranged for Umo to look
after the revolver and then to provide it to him, had been armed with that gun (albeit not with intent to
endanger life but only with intent to facilitate the robbery by brandishing it to cause fear) and Newton had
been armed with a knife (although neither he nor Benjamin had intended causing serious harm). Benjamin
had not been charged with any offence in relation to the second gun (which had been brandished by the
third man) and it may have been that gun which was discharged.

(iii) Newton had stabbed Kyzia Sandiford who, as a result, had suffered very serious injury. Benjamin's
was a lesser role in relation to that offence but, because he had been armed with the revolver, he was the
more culpable of the two in relation to the robbery. Thus, given the seriousness of the injuries, a sentence
at the top of the range, namely 12 years' imprisonment, was appropriate for Benjamin which, after 20%


-----

discount for plea, resulted in an ultimate sentence of 9 years and 8 months' imprisonment for that offence.
A concurrent term of 25 months' imprisonment was imposed for the wounding.

(iv) Given that Benjamin had already been sentenced for the possession of the revolver on 22 February
2018, he had to embark upon a calculation of what Benjamin would have received instead, if the additional
factors of taking the revolver out in public and using it with intent to commit an indictable offence had been
taken into account, and he had concluded that it would have been an additional term of 3 years and 9
months' imprisonment, which he imposed concurrently.

(v) The total sentence of 9 years and 8 months' imprisonment was imposed consecutively to the total
sentence of 10 years that Benjamin was already serving.

(vi) He had considered the issue of dangerousness but, notwithstanding the content of the pre-sentence
report, had concluded that Benjamin was not dangerous, given that:

(a) His previous convictions did not demonstrate any history of violence.

(b) He had been acquitted of any intent to cause grievous bodily harm on 16 February 2018, and the use
of the gun had reflected only an inention to cause fear.

(c) Above all else, and even if he was wrong about dangerousness, Benjamin's overall sentence was of
such length that the length of licence to which Benjamin was going to be subject would be sufficient for
public protection purposes.

48. At one stage during his sentencing remarks the judge referred to the sentences previously imposed on
Benjamin at the Inner London Crown Court, and indicated that he would return to them, and their impact on
Benjamin, thereafter. However, he did not do so. Indeed, he made no reference at all to the principle of
totality until, immediately after the sentencing remarks, counsel sought clarification of the sentences that he
had imposed on Benjamin - at which the judge further explained the sentence imposed on count 4,
reducing it at that stage to one of two years and 11 months' imprisonment (still concurrent), and saying that
he had gone below the minimum term of five years because of the principle of totality - given the earlier
sentence in relation to the same gun. Beyond that, the judge declined to permit further submissions in
relation to totality.

49. As to Newton, the judge observed that he had not been prosecuted for joint possession of any gun,
and so would be sentenced on the basis of participation in a robbery in which he had used a knife. The
judge continued that, but for Newton's mitigating factors, namely his relative lack of previous convictions,
and his character references (which persuaded the judge that he had acted out of character), the sentence
imposed on him would have been longer. As indicated above, Newton was sentenced to a total of nine
years' imprisonment.

50. The Grounds of Appeal are that:

(1) The judge took too high a starting point on count 3 (robbery). The appellant did not cause the injury to
the victim. Furthermore, the judge considered it an aggravating feature of count 3 that Benjamin carried a
firearm, despite that being reflected in a separate count on the indictment (count 4).

(2) Newton, who caused the injury to the victim of the robbery, was sentenced to 9 years on count 3
(robbery) after a trial. The appellant's sentence of 9 years 8 months on a plea was comparatively too high.

(3) Either the sentence ought to have been short and consecutive to the sentence passed at Inner London
CC, or the sentences ought to have run concurrent to each other.

51. In her succinct oral submissions on behalf of the appellant, Ms Brickman argued that the overall
notional sentence after trial of 25 years and 4 months was far too long, and that the judge had failed,
whether entirely or sufficiently, to apply the Guideline on totality, which required him to consider what the
sentence length would have been if the court had dealt with both sets of offences at the same time, and to
ensure that the totality of the sentence was just and proportionate in all the circumstances and, if it was
not, to make an adjustment to the sentences imposed for the instant offences.


-----

52. On behalf of the respondent it was variously submitted that the judge was well aware of the sentences
imposed at the Inner London Crown Court, and had had full regard to the principle of totality – which he
had made plain when refusing to hear further submissions about it. The robbery was the most serious
offence and it fell within category 1A of the relevant Guideline. The judge had been entitled to conclude
that Benjamin's was the leading role, and (for the reasons that the judge had explained) there was no
unfair disparity when compared with the overall sentence imposed on Newton. Given the nature of the
robbery, the judge was entitled to conclude that the sentence for it ought to be consecutive to the overall
sentence imposed at the Inner London Crown Court and, in the result, the sentence was neither wrong in
principle nor manifestly excessive.

53. Clearly, this was not a straightforward sentencing exercise. The offences for which Benjamin had
been sentenced at the Inner London Crown Court had all been committed 6 days after the instant offences,
and the firearm offences related to the same revolver. Equally, against a maximum of 10 years'
imprisonment, the notional sentence after trial of 9 years' imprisonment involved in the sentence for the
firearm offence at Inner London Crown Court was a tough one.

54. That said, and in isolation from the overall sentence imposed at Inner London Crown Court, there is, in
our view, no merit in the first Ground. The robbery (count 3) was plainly a category 1A offence. Culpability
was high, given the production of a knife and a firearm to threaten violence, the use of the knife to inflict
violence, and the fact that Benjamin was in a leading role. Harm was also high, given that serious physical
and psychological harm was caused to the victim. In those circumstances, and to avoid double counting, it
was appropriate (from the staring point which the judge identified) to pass an overall sentence on count 3
and concurrent terms on counts 2 and 4.

55. Equally, for the reasons that the judge explained, there was no unfair disparity with the overall
sentence imposed on Newton. Thus the second Ground also fails.

56. However, in our view, there is clear merit in the third Ground. Although the parties underlined, in
advance, the importance of applying the principle of totality, the judge made no reference to it - save in the
context of justifying the reduction from the minimum term in the concurrent sentence imposed on count 4
(the minimum sentence for which could have been imposed concurrently to avoid double counting and
without offence to the principle of totality) and in refusing to hear further submissions on the topic. He
made no attempt to apply the relevant Guideline by considering what the sentence length would have been
if he had dealt with all the offences at the same time, nor to ensure that the totality of the sentence was just
and proportionate in all the circumstances, nor to make any necessary adjustment.

57. In our view, if all the offences had been dealt with at the same time, the appropriate sentence would
have been one of at least 16 years' imprisonment, from which it would have been appropriate to deduct an
overall discount in the order of 22.5%, giving an ultimate overall sentence of a little over 12 years'
imprisonment.

58. Thus it is clear that the overall sentence imposed by the judge in relation to the instant offences was
not just and proportionate, and that we must make the necessary adjustment. In so doing we must bear in
mind that (subject to credit for time on remand) the service of the overall sentence began with the
imposition of the sentence of 10 years' imprisonment at the Inner London Crown Court on 4 May 2019, and
that therefore Benjamin had already served the equivalent of at least 20 months' imprisonment by the time
he was sentenced for the instant offences. Equally, any sentence that we impose in substitution in relation
to the instant offences will run from the date of sentence at Woolwich Crown Court – i.e.14 March 2019.

59. In addition, it is necessary to consider afresh the issue of dangerousness – particularly as the judge
made clear that, if he was wrong to conclude that Benjamin was not dangerous, he was proceeding on the
basis that the length of the overall sentence for all the offences provided sufficient protection to the public.

60. Fortified by the pre-sentence report, we have no doubt that there is a significant risk to members of the
public of serious harm occasioned by the commission by Benjamin of further specified offences. His
possession of the gun and ammunition was in the context of the volatile and dangerous world of
professional drug dealing, in which he had shown himself willing to carry out a planned and armed revenge


-----

attack on a rival. Although that attack did not involve an intention to cause grievous bodily harm, it was a
joint enterprise and serious harm was (all too foreseeably) what resulted from it. In addition, he had kept
the gun and ammunition – giving rise to the obvious inference that he intended to use them in the future in
circumstances involving specified offences and a significant risk of serious harm to members of the public.
Equally, in our view, given the reduction we are about to make in the overall custodial term for all the
offences, this is not a case in which the length of that term alone is sufficient to protect the public.

61. Accordingly, taking all the above matters into account, we quash the sentence imposed on count 3 and
substitute for it an extended sentence of 13 years and 6 months, made up of a custodial term of 10 years
and 6 months and an additional licence period of 3 years. That sentence will be concurrent, rather than
consecutive, to the overall total sentence imposed at the Inner London Crown Court. The sentence of 25
months' imprisonment concurrent on count 2 will remain the same. Although it will make no practical
difference, we see no reason why the minimum sentence should not be imposed concurrently on count 4.
Accordingly, we quash the sentence imposed on that count and substitute for it a sentence of 5 years'
imprisonment concurrent. In our view that results in an overall sentence for all the offences which is just
and proportionate in all the circumstances.

62. Therefore, to the extent that we have indicated, Benjamin's appeal against sentence is allowed.

**End of Document**


-----

