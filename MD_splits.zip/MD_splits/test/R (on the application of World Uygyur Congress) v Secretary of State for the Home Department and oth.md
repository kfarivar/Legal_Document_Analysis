[2023] EWHC 88 (Admin)

# R (on the application of World Uygyur Congress) v Secretary of State for the
 Home Department and others [2023] EWHC 88 (Admin)

King's Bench Division, Administrative Court (London)

Dove J

20 January 2023Judgment

**Jenni Richards KC, Tom Forster KC, Katherine Barnes, Anita Clifford and Russell Hopkins**
(instructed by Bindmans LLP) for the Claimant

**Sir James Eadie KC, David Perry KC and Katherine Hardcastle (instructed by the Government Legal**
**Department) for the Defendant**

Hearing dates: 25-26 October 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on [date] by circulation to the parties or their representatives
by e-mail and by release to the National Archives.

.............................

THE HONOURABLE MR JUSTICE DOVE

**The Honourable Mr Justice Dove :**

1.

Introduction

1. This is an application for Judicial Review in relation to the Defendants' actions in respect of cotton
produced in the Xinjiang Uyghur Autonomous Region (“XUAR”). The Claimant is a non-governmental
organisation (“NGO”) that aims to promote the collective interests of the Uyghur people. The particular
concern of the Claimant which has led to the commencement of this litigation are the crimes and human
rights abuses committed by the government of the People's Republic of China (“the PRC”) in XUAR
against the Uyghur people in the production of cotton which is exported out of China to, amongst other
destinations, the UK.

2. The Defendants are agencies which are concerned, amongst other statutory functions and in so far as
is relevant to the present proceedings, with law enforcement in particular in relation to the supervision of
the borders of the UK. The nature and function of the respective Defendants are as follows. The First
Defendant created what is now known as 'Border Force' (formerly the UK Border Agency) in 2009. Border
Force is a law enforcement command within the Home Office, which has operational responsibility for
customs and revenue work at the border. The Second Defendant is the UK Customs Authority and retains
overall responsibility for customs and revenue policy. However, operational customs activity at the border
is a matter for Border Force whereas the Second Defendant is primarily concerned with customs and


-----

[2023] EWHC 88 (Admin)

taxation matters inland. The Third Defendant is responsible for the investigation of serious and organised
crime in the UK. It conducts such investigations with a view to criminal prosecutions and proceedings for
civil recovery.

3. The Claimant's case has two legal themes. The first two grounds of their case relate to section 1 of the
Foreign Prison-Made Goods Act 1897. Ground 1 is the contention that Defendants' decision not to
investigate potential breaches of section 1 of the 1897 Act is based on a misdirection of law, in that they
have misunderstood what is required in evidential terms to establish a breach of that section. The
Claimant's Ground 2 is the submission that the First Defendant (via Border Force) unlawfully fettered its
discretion to investigate potential breaches of section 1 of the 1897 Act in that its policy is to respond to
evidence on a “reactive basis” only, rather than launching its own proactive investigations.

[4. The second legal theme relates to the provisions of the Proceeds of Crime Act 2002. In particular, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y037-00000-00&context=1519360)
Second and Third Defendants failed to launch investigations under Part 7 of the 2002 Act based upon a
misdirection of law as to the scope of the powers under that part of the Act: this is Ground 3 of the
Claimant's case. Ground 4 is a similar contention in respect of a misdirection of law about the powers of
civil recovery of property under Part 5 of the 2002 Act. In essence, as set out below, the central concern of
the Claimant under both of these grounds is the Defendants' view that there is a need for specific criminal
property to be identified prior to an investigation being launched under the 2002 Act.

5. The Claimant's case under Grounds 1 and 2 were advanced by Ms Jenni Richards KC and Ms
Katherine Barnes; their case in relation to Grounds 3 and 4 were developed by Mr Tom Forster KC, Ms
Anita Clifford and Mr Russell Hopkins. On behalf of the Defendants, the response to the Claimant's case
under Grounds 1 and 2 (including some cross-cutting submissions in relation to evidence) was advanced
by Sir James Eadie KC; the Defendants' submissions in respect of Grounds 3 and 4 were made by Mr
David Perry KC and Ms Katherine Hardcastle. I am very grateful to the legal teams on all sides of the case
for the great care which was brought to bear on the preparation of the papers in the case for the hearing
and for the clear and focussed submissions made both orally and in writing. I mean no discourtesy by only
attributing the submissions in the text of the judgment to either the Claimant or the Defendant (using that
term collectively for all of the Defendants identified above), but have done so for the sake of simplicity and
clarity.

The Background Facts

6. The Uyghur people are an ethnically and culturally Turkic people living in the XUAR or East Turkistan.
Historically there have been tensions between the indigenous inhabitants of the XUAR and the PRC, which
led in 2014 to the PRC launching a “People's War on Terror”, followed by the implementation of large-scale
measures to secure control of the Uyghur and other Turkic people in the XUAR. These measures included
the internment and “re-education” of vast numbers of citizens accompanied by correctional forced labour
alongside birth prevention and family separation. The activities of the extensive cotton and textile industry
in XUAR are integrally involved in the repressive measures implemented by the PRC. The evidence
before the court explains that 30% of the world's production of cotton originates in the PRC, and of that
85% originates in the Xinjiang or XUAR. The repressive measures affecting the Uyghurs include forcing
them to pick cotton, to work in textile factories either inside or adjacent to the internment camps, as well as
forcing them to live and work under coercive conditions in textile industrial parks which are referred to
below both in XUAR and elsewhere in PRC. In addition, the evidence records that prison inmates are
routinely used to provide labour to support cotton production at other parts of the value chain.

7. The Claimant's case draws attention by way of illustration to a sample of evidence which demonstrates
the relationship between the PRC's minority control measures and the Xinjiang Aid programme which is
associated with these measures and the production of cotton in the XUAR. By way of example the
evidence records as a case study Aksu industrial park in the Aksu Prefecture, Xinjiang. This facility
features in reports of research and policy organisations as well as in articles based on investigative
journalism. The Centre for Strategic and International Studies in its report “Connecting the Dots in Xinjiang:
Forced Labor, Forced Assimilation, and Western Supply Chains” describes the Aksu Industrial Park as a


-----

[2023] EWHC 88 (Admin)

“key element of the government's poverty alleviation program” and notes that it is part of an initiative to
reach 100 villages in the Aksu area and build about 1000 factories of over 1 million square meters by 2020.
The Wall Street Journal visited Aksu and reported that in the two years prior to their visit, PRC officials had
gathered up more than 4,000 residents for deradicalization and textile-making courses in “concentrated,
closed-off, military-style management”, in order to meet the labour requirements of the manufacturers.

8. The Aksu Industrial Park also features in the 2021 Xinjiang Cotton Textile Industry Social Responsibility
Report published by the Xinjiang authorities to portray the Minority Control Measures in a positive light.
This report notes that by developing an Industrial City it has brought together the whole industrial value
chain (including spinning, printing, dyeing, weaving and the production of textiles and garments) and
represents an important base for “Xinjiang to drive the transfer of the surplus rural labour force in the four
prefectures in south Tianshan Mountain. Thanks to the cotton textile businesses, a barren desert in the
past has turned into a livable modern industrial city.”

9. The Claimant's evidence sets out that the Industrial Parks which are part of the Xinjiang Aid programme
are supported by forced labour in which Uyghurs and other Turkic people live and work under conditions of
detention. The satellite images of these facilities show buildings which appear to be residential along with
the factory buildings. The Claimant's evidence goes on to describe the Chinese textile companies that are
implicated in the use of Uyghur forced or prison labour in the production and distribution of cotton. One of
these, Huafu, is a company which opened a major production facility in Aksu in 2018. The facility is the
world's largest textile mill for coloured yarns. A report from the CSIS notes that Huafu run a training college
at the Aksu Industrial Park next to its factory, which is said to operate training programmes with
government subsidies “intended to eradicate their extremist thoughts” for workers who are then employed
in the factory.

10. Adrian Zenz, a journalist who has studied the cotton industry in the XUAR, states that Huafu is part of
an official training initiative subjecting Uyghurs to centralised “military drill, thought transformation…and
deextremification”. Entire families, he reports, live in company dormitories whilst the parents work and their
children attend the Huafu school. Large amounts of government subsidies are received by Huafu for
training and employing minorities. Huafu are, therefore, said to play their part in a policy of rounding up
adults from the rural areas, and then conscripting them in training programmes to equip them to work in
cotton industry factories as well as providing them with political indoctrination, before putting them to work
in textile factories.

11. The Claimant's evidence goes on to note that a company with a significant UK presence has listed
Huafu's mainland manufacturing facility in Zhejiang as a supplier, it is presumed on the basis that this
factory is in parallel to, but not tainted by, the cotton manufactured at Aksu. However, the evidence goes
on to observe that Huafu boast of an integrated vertical chain of fabrication and that there are real
difficulties in relying upon any assurances as to cotton being produced in the XUAR.

12. The evidence notes that in the past whilst some global retailers would admit to sourcing cotton from
the XUAR, they would rely upon the assurance of the Better Cotton Initiative (“BCI”) (a not-for-profit
organisation operating a cotton sustainability programme which carries out assurance and licensing
activities in relation to cotton production and manufacture) that forced labour did not taint supply chains
involving cotton from the XUAR. That is no longer the case. In March 2020 BCI announced that it was
suspending its assurance in relation to cotton produced in the XUAR and had commissioned a review of
the situation by an independent expert. In October 2020 BCI announced that in the light of the sustained
allegations of forced labour and human rights abuses in the XUAR it was ceasing all field activities in the
XUAR with immediate effect. There was no production facility or factory in the XUAR which had been
independently verified as not using forced labour. On 29th October 2020 BCI published findings of the
independent expert which concluded that BCI should end all operations and business relationships in the
XUAR as a result, in essence, of the credible evidence of the scale of forced labour in the XUAR, coupled
with the impossibility of conducting assurance activities and the credible evidence of human rights abuses
in the XUAR. As the Claimant's evidence sets out, this follows from extensive problems (including being


-----

[2023] EWHC 88 (Admin)

detained, harassed and threatened) experienced by those attempting to audit the activities of the cotton
industry in the XUAR.

13. In addition to Huafu the Claimant's evidence also highlights the activities of other Chinese companies
in the XUAR, in particular Ruyi Group, Litai Textiles and LuThai Group. It is not necessary for the purposes
of this judgment to set out all of the evidence in relation to these companies, but akin with the approach
taken in the Claimant's skeleton argument it is worthwhile focussing on the position of LuThai Group as an
example of how these companies are implicated in the supply chain for cotton goods.

14. The LuThai Group is a collection of companies which is engaged in the manufacture of high-grade
yarn dyed fabrics, with a complete industrial chain from yarn spinning through to garment making and
marketing. In a report published by the NGO Citizen Power Initiatives for China (“CPI”) LuThai Group are
identified as actively participating in the CCP's textile programmes in the XUAR. The report quotes one of
LuThai's executives explaining their dependence upon the “large surplus of labor in the local rural areas
that can meet the needs of our company.” The annual reports of the company confirm that subsidiaries
based in Aksu City were involved in the planting and processing of cotton for its parent company. Further,
the 2018 LuThai Social Responsibility Report sets out that it has been involved in the construction of a
100,000-spindle cotton spinning project in the Aksu region, increasing their capacity to 228,000 spindles,
and thereby solving various problems “including the employment of local surplus labors without having to
go far” and promoting common development. Other sources confirm the significant increase in production
of cotton by LuThai in the XUAR from 2013 onwards, including in particular the period from 2017 shortly
after the PRC introduced the control measures in the XUAR. For instance, in 2017 itself the sales volume
of cotton recorded in the LuThai annual report increased by 241% compared with the previous year.

15. It appears that the LuThai Group's parent company sold its majority stake in its main XUAR subsidiary
in 2020, potentially as a result of the concerns expressed about conditions in the XUAR by foreign buyers.
Nevertheless, the 2020 annual report continued to account for the same amount of subsidies received for
transferring Xinjiang cotton out of Xinjiang, suggesting strongly that LuThai were continuing to source
cotton from the XUAR company even though it no longer owned it.

16. The Claimant's evidence sets out that the Open Apparel Registry (which lists facilities used by
companies derived from their published supplier lists) states that a number of UK companies have named
LuThai's Shandong factory as amongst their suppliers, the Shandong fabric mill being a manufacturing
facility which uses cotton and lint from the XUAR based on the integrated approach which the company
takes to its operations.

17. The evidence underlying the Claimant's case in relation to the mistreatment of the Uyghur people and
the involvement of abuses in the production of cotton in the XUAR is not the subject of dispute by the
Defendants. The nature of the agreement is underlined by public statements on behalf of the UK
Government. In an oral statement to Parliament on 12 January 2021, the then Foreign Secretary shared
the UK Government's response to the ongoing situation:

"The evidence of the scale and the severity of the human rights violations being perpetrated in Xinjang
against the Uyghur Muslims is now far-reaching, and it paints a truly harrowing picture.

Violations include the extra-judicial detention of over a million Uyghurs and other minorities in political
reeducation camps. Extensive and invasive surveillance targeting minorities. Systematic restrictions on
Uyghur culture, education and indeed the practice of Islam, and the widespread use of forced labour.

The nature and conditions of detention violate basic standards of human rights, and at their worst amount
to torture and inhumane and degrading treatment. Alongside widespread reports of the forced sterilisation
of Uyghur women.

These claims are supported now by a large, diverse and growing body of evidence. That includes:

- first hand reports from diplomats who visit Xinjiang, the first hand testimony from victims who have fled
the region


-----

[2023] EWHC 88 (Admin)

- there is satellite imagery showing the scale of the internment camps, the presence of factories inside
them, and the destruction of mosques

- and there are also extensive and credible third party reports from NGOs such as Human Rights Watch
and Amnesty International, with the UN and other international experts also expressing their very serious
concerns.

In reality, the Chinese authorities' own publicly-available documents also bear out a very similar picture.
They show statistical data on birth control and on security spending and recruitment in Xinjiang. They
contain extensive references to coercive social measures, dressed up as poverty alleviation programmes.

There are leaks of classified and internal documents that have shown the guidance on how to run
internment camps, lists showing how and why people have been detained. Internment camps, arbitrary
detention, political re-education, forced labour, torture and forced sterilisation. All on an industrial scale. It
is truly horrific. Barbarism we had hoped lost to another era, being practised today, as we speak, in one of
the leading members of the international community.

…

Xinjiang's position in the international supply chain network means that there is a real risk of businesses
and public bodies around the world – whether it's inadvertently or otherwise – sourcing from suppliers
which are complicit in the use of forced labour. Allowing those responsible for these violations to profit, or
indeed making a profit themselves by supplying the authorities in Xinjiang.

Mr Speaker, here in the UK, we must take action, to make sure that UK businesses are not part of the
supply chains that lead to the gates of the internment camps in Xinjiang. And to make sure that the
products of the human rights violations that take place in those camps don't end up on the shelves of
supermarkets that we shop in here at home, week in week out.”

18. On 8th July 2021 the House of Commons Foreign Affairs Committee (“FAC”) published its report
“Never Again: The UK's Responsibility to Act on Atrocities in Xianjiang and Beyond”. The report addressed
the link between the cotton industry and human rights violations against Uyghurs in the XUAR. Within the
report, which was wide-ranging in its scope and recommendations, the following was set out:

“39. Many people who 'graduate' from the internment camp system are coerced into state-organised forced
labour programmes. Between 2017-2019 alone, more than 80,000 Uyghurs were forcibly transferred out of
Xinjiang to work in factories across China, under the Xinjiang Aid programme. More recent estimates
suggest that at least 570,000 people from Xinjiang have been forced to pick cotton. Workers are typically
paid little to nothing. Satellite imagery reveals factories surrounded by barbed wire fences, surveillance
cameras, and guard towers. 84% of China's cotton comes from Xingjiang, and China provides a quarter of
the world's cotton products.

40. With these facts in mind, we are seriously concerned that products and materials made from Uyghur
forced labour are making their way into UK value chains. We heard that “virtually the entire” UK textile and
clothing industry is linked to the abuses in Xinjiang…

46. Throughout the course of this inquiry, we have heard that the issue of forced labour in Xinjiang is
pervasive, widespread, and extremely difficult to monitor effectively. Outside auditors are regularly denied
access to Xinjiang factories and forced labourworkers are coerced into silence. Because of this, the United
States announced a ban on cotton products from Xinjiang in January 2021. Certain businesses have taken
similar measures.

47. Private companies such as ASOS, River Island, and NEXT told us they were taking steps to reduce the
risk of using cotton sourced from Xinjiang, although NEXT disclosed at the time that it was “likely” that
there was “some” Xinjiang cotton in their products. On the likelihood of Xinjiang produce being sourced
from forced labour, Primark told us:


-----

[2023] EWHC 88 (Admin)

'Our initial response to the situation in Xinjiang began in October 2019, when we made the decision to end
our relationship with the only factory from which we sourced finished goods in the XUAR…We believe our
position is appropriate and proportionate given the reports which have emerged regarding alleged human
rights abuses and the use of forced labour in Xinjiang, and because we are unable to undertake the due
diligence or auditing that we would normally carry out when such claims emerge.'

48. Unless proven otherwise, the mass incarcerations and connected factories and farms mean it should
be assumed that any product originating from Xinjiang is the product of forced labour. While much focus
has been placed on the textile and apparel sector, other areas such as solar energy, agriculture, and
electronics also bear a substantial risk of forced labour. Until there can be definitive proof that products are
not tainted by forced labour, UK companies and consumers should not be purchasing them. The
Government should explore the possibility of banning the import of all cotton products known to be
produced in whole or in part in the Xinjiang Uyghur Autonomous Region of China, in line with WTO rules.
While we primarily heard evidence on the cotton industry, we believe this ban should be extended to other
industries.”

19. In the light of their ongoing concerns in relation to these issues the Claimant wrote to the Second
Defendant on 22nd April 2020 calling for action in relation to the presence of cotton from the XUAR in the
value chain in the UK. A correspondence ensued over the course of the following 18 months, and for the
purposes of this judgment it is unnecessary to focus in detail upon anything other than the final positions of
the parties reached immediately prior to the commencement of proceedings since these were the focus of
the arguments presented to the court. It should, however, be noted that during the course of the
correspondence the Claimant provided the Defendant with a large amount of evidence concerning the
issues of forced labour and human rights abuses in the XUAR. This was, in essence, the evidence which
has been provided to the court and which has been addressed above. The Defendant took account of and
considered this material in reaching decisions as to any actions in response to it, and the Defendant's
conclusions were informed by it.

20. The correspondence enabled the discussions between the parties to be distilled into two areas for the
purpose of assessing whether the Defendant was acting lawfully in relation to this issue. The first area was
the concern that the Defendant ought to have been actively investigating, and thereafter prohibiting the
importation of, cotton goods with their origin in the XUAR using the powers available under section 1 of the
1897 Act and the associated power under section 139 of the Customs and Excise Management Act 1979.
In relation to this issue the finally resolved position of the Defendant was set out in the letter from their
solicitors dated 10th September 2021 as follows:

“ 14. The Parliamentary intention underlying the introduction of FPMGA was to protect the UK market from
being undermined by under-priced foreign imports. It was not enacted as a measure directed at
safeguarding the welfare of prisoners. Rather the measure sought to strike a balance between the
protection and promotion of international trade. Notably, the prohibition was not directed at prison-made
goods _per se. For instance, no prohibition was enacted by FPMGA in respect of prison-made goods not_
imported for the purposes of trade, or of a description not manufactured in the UK.

15. It is also necessary to note that the standard required by s.1 FPMGA to establish that the relevant
goods are prison-made is high – viz. that it must be proved by evidence tendered to the satisfaction of the
relevant enforcing officer, on the balance of probabilities, that it was in fact made in a foreign prison. This
was no doubt a measure intended to guard against the obvious impediment that would otherwise be
caused to legitimate trade in similar goods. As a consequence of its evidential requirements, however, s.1
FPMGA has long-been recognized as having limited operational value.

…

17. BF's approach to foreign prison-made goods is described in an internal subject area information note
as follows:

“[BF] role: 

-----

[2023] EWHC 88 (Admin)

_The importation of goods made in foreign prisons is prohibited under section 1 [FPMGA]. Border Force_
_operates on a reactive basis in response to intelligence suggesting goods were made in a foreign prison._
_Prison made goods will be seized where they are detected and where reacting to intelligence. … applicable_
_exceptions [are] listed in the 1897 Act.”_

18. The reference to “intelligence” in this context would not be for BF to gather but refers to case specific
intelligence originating from a legitimate source. In practice this is most likely to be intelligence provided by
another agency or Government department.

19. Importantly, s. 1 FPMGA envisages the production of evidence linking a specific consignment of goods
to a specified facility meeting the definition of a foreign prison. It is a necessary requirement to establish
evidentially such a connection between the originating location and a particular shipment of goods. It
follows that it is, in practice, implausible that a conclusion could be reached that s.1 FPMGA had been
contravened based on the nature of goods alone in circumstances where such goods were produced
elsewhere. This is to say nothing of the complex nature of modern international supply chains which
frequently involve multiple stages, not necessarily evident from a customs manifest or other documentary
evidence accompanying the goods being moved.”

21. The second issue which became distilled as a result of the discussions in the correspondence was the
Claimant's contention that the Defendant ought to be investigating under the 2002 Act, on the basis that
cotton goods with their origin in the XUAR could be criminal property and trading in them criminal conduct.
The contention engaged the need for action under Part 7 and Part 5 of the Act (which are set out in detail
below) which the Defendant was failing to undertake. The final position of the Defendants was again set
out in their solicitor's letter dated 10th September 2021, and whilst it did not specifically engage with Part 5
of the 2002 Act, it was clarified in subsequent correspondence that the response dealt with both Parts 7
and 5 of the Act. The letter stated as follows:

“ 31. So far as concerns an alleged failure to investigate possible money laundering offences under POCA,
the Letter Before Claim proceeds on a misapprehension. There is no proper basis for a POCA
investigation.

32. For the purposes of POCA, offences contrary to s.1 of the **_Modern Slavery Act and/or s. 51 of the_**
International Criminal Court Act 2001 are capable of constituting criminal conduct within the meaning of
s.340 POCA. However:

(i) It is a requirement of s.340 POCA that any criminal conduct is clearly and specifically identified and that
the resultant property is specifically identified. It is insufficient, for the purposes of POCA, to deal in
hypothetical scenarios or presumptions. In the absence of identifying a specific consignment of goods that
is the product of the relevant criminality, the requirements of s. 340 are not met and no POCA offence can
arise: see R v GH [2015] UKSC 24.

(ii) Whilst the Letter Before Claim raises both the offences contrary to ss.328 and 329 POCA, it is apparent
that, in the context of a supply chain, s.329 is the apposite offence (namely the acquisition, use and
possession of criminal property, as opposed to entering into an arrangement which facilitates money
laundering). However, it is a defence under s.329(2)(c) for a person to acquire or have possession of
criminal property for adequate consideration. That provision reflects the policy aim of POCA, that it is not
the function of the regime to taint the bona fide purchaser for value. Rather it is to seek the recovery of the
proceeds of crime in the hands of a criminal. To the extent that it may be possible (which is currently
doubted) to identify any specific product as criminal property, and any particular person as engaging in
criminal conduct, within the meaning of s.340, it would nevertheless be the case that if that product has
been the subject of a transaction for adequate consideration, the relevant criminal property would be the
proceeds of that transaction in the hands of the criminal as seller, and not the product in the hands of the
purchaser.”

22. For the purposes of the present application these passages set out the resolved position of the
Defendant and formed the basis upon which the case was argued. In addition to the correspondence the


-----

[2023] EWHC 88 (Admin)

Defendant provided witness evidence from Mr David Huke, who is the Assistant Director and Head of the
Customs Operational Policy Team in Border Force. In his witness statement, amongst other matters, he
addresses the source of the internal subject area information note which is referred to in the
correspondence above. Mr Huke describes the document in which the information about the 1897 Act
appears as an Operational Policy Subject Area Information Note. He produces the whole document and
whilst most of the operational text is redacted the headings which this material covers are not. This
demonstrates that the document provides information in relation to a wide range of subject areas from the
trade in endangered species to the shipment of waste. Mr Huke describes the document as an “internal
document…used by Border Force Customs Operational Policy as a point of reference concerning the
extensive range of controls on goods at the border and provides officers with useful contact information”.

23. He goes on to explain that there have been no seizures or detentions of goods based on the 1897 Act.
He also sets out that in the months of October, November and December 2020 over 1,000,000
consignments of goods that were, or could be considered to be, cotton goods arrived in the UK, and that
there is no reason to assume that these volumes were other than the normal pattern of trade.

The law

24. As set out above, each of the grounds of challenge in this case relate to a contention that the
Defendant was guilty of a misdirection in law in relation to the conduct of investigation in respect of the
Claimant's concerns. This is consistent with the relevant principles of the law in this area, which reflects the
deference which the court must afford to the wide range of considerations that the Defendant has to have
regard to when operating as an agency of law enforcement. These principles were considered in the case
of R(Bermingham and others) v Director of the Serious Fraud Office [2007] QB 727; [2006] EWHC 200, in
which the Divisional Court was being asked to order the Director of the Serious Fraud Office to undertake
an investigation to determine whether the Claimants should be charged and tried in the UK for the offences
for which they were wanted by the authorities in the USA. Dismissing the claim and giving the leading
judgment in the Divisional Court, Laws LJ observed as follows:

“63. I entertain considerable reservation as to the propriety of the courts embarking at all on a challenge to
the Director's decision framed in such terms as these. There is much authority to the effect that the
jurisdiction to conduct a judicial review of a public authority's decision to launch or not to launch a
prosecution, though it undoubtedly exists, is to be exercised sparingly. Where the decision is to prosecute,
this admonition of restraint arises in part at least out of the imperative that criminal proceedings should not
be the subject of satellite proceedings which have the effect of delaying the trial: _R v Director of Public_
_Prosecutions, ex parte C [1995] 1 CAR 136, especially_ _per Kennedy LJ at 141;_ _R v Director of Public_
_Prosecutions, ex parte Kebilene [2000] 2 AC 326 . Where the decision is not to prosecute, there cannot I_
think be a different rule; in any event there will have been expert assessments of weight and balance which
are so conspicuously within the professional judgment of the statutory decision-maker that there will very
rarely be legal space for a reviewing court to interfere.

64. Here, of course, the decision sought to be reviewed is a decision not to investigate .The position as
regards the judicial review jurisdiction is in my judgment _a fortiori a decision whether to prosecute. The_
authority's (here, the Director's) discretion is even more open-ended. It will involve consideration of the
manner in which available resources should be deployed and whether particular lines of inquiry should or
should not be followed: Hill v Chief Constable of West Yorkshire [1989] 1 AC 53 _per Lord Keith of Kinkel at_
59 D–F, summarising R v. Commissioner of Police for the Metropolis, Ex parte Blackburn [1968] 2 QB 118
. It is submitted for the Director that absent bad faith or other exceptional circumstances a decision to
investigate or not to investigate an allegation of crime is not subject to review. That is not quite right. It
looks like an argument to limit the court's jurisdiction of judicial review; but the jurisdiction is as wide or as
narrow as the court holds. The true proposition is that it will take a wholly exceptional case on its legal
merits to justify a judicial review of a discretionary decision by the Director to investigate or not.”

25. A further case in which this issue was considered was the case of _R(Corner House Research) v_
_Serious Fraud Office [2008] UKHL 60, in which Lord Bingham, in a speech with which the other members_


-----

[2023] EWHC 88 (Admin)

of the House of Lords agreed, stated as follows in relation to the role of the court in enquiring into the
manner in which a law enforcement agency has exercised its powers:

“31. The reasons why the courts are very slow to interfere are well understood. They are, first, that the
powers in question are entrusted to the officers identified, and to no one else. No other authority may
exercise these powers or make the judgments on which such exercise must depend. Secondly, the courts
have recognised (as it was described in the cited passage of Matalulu)

“the polycentric character of official decision-making in such matters including policy and public interest
considerations which are not susceptible of judicial review because it is within neither the constitutional
function nor the practical competence of the courts to assess their merits”.

Thirdly, the powers are conferred in very broad and unprescriptive terms.

32. Of course, and this again is uncontroversial, the discretions conferred on the Director are not
unfettered. He must seek to exercise his powers so as to promote the statutory purpose for which he is
given them. He must direct himself correctly in law. He must act lawfully. He must do his best to exercise
an objective judgment on the relevant material available to him. He must exercise his powers in good faith,
uninfluenced by any ulterior motive, predilection or prejudice. In the present case, the claimants have not
sought to impugn the Director's good faith and honesty in any way.”

26. The Claimant's grounds are framed in the light of these authorities: the Claimant contends that the
Defendants misdirected themselves in their approach to the exercise of their powers under the 1897 and
the 2002 Act, and that this is evidenced in the description of how they envisaged these powers operating in
the correspondence set out above. The Claimant's case is not put on a _Wednesbury basis, and it is_
essentially common ground that absent the errors of law contended for there would be no proper basis for
interfering with the Defendant's exercise of discretion in this case: only in wholly exceptional cases could
such an interference be justified for the reasons given in the authorities.

27. Turning to the first of the legal themes of the Claimant's case, section 1 of the 1897 Act provides as
amended as follows:

“1. Prohibition of importation of foreign prison made goods.

The importation of the following goods is prohibited]; that is to say:

Goods proved to the satisfaction of the Commissioners of Customs and Excise by evidence tendered to
them to have been made or produced wholly or in part in any foreign prison, goal, house of correction, or
penitentiary, except goods in transit or not imported for the purposes of trade, or of a description not
manufactured in the United Kingdom or originating or in free circulation in another member State.”

[28. The Customs and Excise Management Act 1979 contains complementary powers for the forfeiture and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y1F1-00000-00&context=1519360)
seizure of goods which have been imported contrary to any prohibitions or restrictions in force in respect of
them. Section 49(1)(b) provides the power to make goods imported contrary to restrictions such as that
created by section 1 of the 1897 Act liable to forfeiture. Section 139(1A) of the 1979 Act entitles a person
authorised under section 139(1) who reasonably suspects that any thing may be liable to forfeiture under
customs and excise Acts to seize or detain that thing as liable to forfeiture.

29. The Claimant contends that part of the misdirection of law for which the Defendant can be criticised is
that they have unlawfully fettered their discretion in relation to the Border Force “Subject Area Information
Note” which is quoted above. In this respect the Claimants rely upon the legal principles which were set out
by Laws and Treacy LJ in their judgment in the case of _R(West Berkshire DC) v Secretary of State for_
_Communities and Local Government [2016] 1 WLR 3923; [2016] EWCA Civ 441 at paragraphs 16 to 18 as_
follows:

“16. …It is important first to notice a distinction in this area of the law which is at the core of the debate in
this appeal. It is between these two principles. (1) The exercise of public discretionary power requires the
decision-maker to bring his mind to bear on every case; he cannot blindly follow a pre-existing


-----

[2023] EWHC 88 (Admin)

policywithout considering anything said to persuade him that the case is an exception. See British Oxygen
_Co Ltd v Board of Trade_ [1971] AC 610, in which Lord Reid and Viscount Dilhorne cited the classic
authority of R v Port of London Authority, Ex p Kynoch Ltd [1919] 1 KB 176, 184 per Bankes LJ.

17. But (2): a policy-maker (notably central government) is entitled to express his policy in unqualified
terms. He is not required to spell out the legal fact that the application of the policy must allow for the
possibility of exceptions. As is stated in De Smith's Judicial Review, 7th ed (2013), para 9-013:

“a general rule of policy that does not on its fact admit of exception will be permitted in most circumstances.
There may be a number of circumstances where the authority will want to emphasise its policy…but the
proof of the fettering will be in the willingness to entertain exceptions to the policy, rather than in the words
of the policy itself.”

18. Both of these principles-the rule against fettering discretion, and the liberty (generally) to express policy
without acknowledging exceptions-apply whether or not the policy-maker and the decision-maker are the
same or different persons. If it were otherwise, neither would have any integrity as a principle.”

30. In the light of the way in which the Defendant responds to this point, there is an additional matter which
needs to be addressed. The Defendant submits that the “Subject Area Information Note” is not a policy or a
piece of guidance in relation to the exercise of the powers under section 1 of the 1897 Act, but no more
than what it says, a note containing information. The question of what amounts to a policy was addressed
in the decision of the Supreme Court in _R(on the application of A) v Secretary of State for the Home_
_Department [2021] UKSC 37 in which Lord Sales and Lord Burnett observed as follows:_

“2. It is a familiar feature of public law that Ministers and other public authorities often have wide
discretionary powers to exercise. Usually these are conferred by statute, but in the case of Ministers they
may derive from the common law or prerogative powers of the Crown, which fall to be exercised by them or
on their advice. Where public authorities have wide discretionary powers, they may find it helpful to
promulgate policy documents to give guidance about how they may use those powers in practice. Policies
may promote a number of objectives. In particular, where a number of officials all have to exercise the
same discretionary powers in a stream of individual cases which come before them, a policy may provide
them with guidance so that they apply the powers in similar ways and the risk of arbitrary or capricious
differences of outcomes is reduced. If placed in the public domain, policies can help individuals to
understand how discretionary powers are likely to be exercised in their situations and can provide
standards against which public authorities can be held to account. In all these ways, policies can be an
important tool in promoting good administration.”

31. The second legal theme of the Claimant's grounds is reliance upon the powers contained within the
2002 Act. Central to those powers, and the offences which are in point derived from Part 7 of the 2002 Act,
is the definition of criminal property which is contained within section 340 of that Act. These provisions
provide as follows:

“340. Interpretation

(1) This section applies for the purposes of this Part.

(2) Criminal conduct is conduct which—

constitutes an offence in any part of the United Kingdom, or

would constitute an offence in any part of the United Kingdom if it occurred there.

(3) Property is criminal property if—

it constitutes a person's benefit from criminal conduct or it represents such a benefit (in whole or part and
whether directly or indirectly), and

the alleged offender knows or suspects that it constitutes or represents such a benefit.

(4) It is immaterial—


-----

[2023] EWHC 88 (Admin)

who carried out the conduct;

who benefited from it;

(c) whether the conduct occurred before or after the passing of this Act.

(5) A person benefits from conduct if he obtains property as a result of or in connection with the conduct.

(6) If a person obtains a pecuniary advantage as a result of or in connection with conduct, he is to be taken
to obtain as a result of or in connection with the conduct a sum of money equal to the value of the
pecuniary advantage.

(7) References to property or a pecuniary advantage obtained in connection with conduct include
references to property or a pecuniary advantage obtained in both that connection and some other.

(8) If a person benefits from conduct his benefit is the property obtained as a result of or in connection with
the conduct.

…

(11) Money Laundering is an act which
(a) constitutes an offence under section 327,328 or 329,

(b) constitutes an attempt, conspiracy or incitement to commit an offence specified in paragraph (a),

(c) constitutes aiding, abetting, counselling or procuring the commission of an offence specified in
paragraph (a),

(d) would constitute an offence specified in paragraph (a), (b) or (c) if it were committed in the United
Kingdom.”

32. There is no question arising in relation to the definition of property for these purposes, as it is widely
defined by section 340(9) of the 2002 Act. One of the key issues in the case depends upon the application
of the definition of criminal property. The offences contained within the 2002 Act and which are relevant to
the issues in this case are as follows. Firstly, under section 327 of the 2002 Act there is the offence of
concealing criminal property. The pertinent provisions of section 327 are as follows:

“327 Concealing etc

(1) A person commits an offence if he—

(a) conceals criminal property;

(b) disguises criminal property;

(c) converts criminal property;

(d) transfers criminal property;

(e) removes criminal property from England and Wales or from Scotland or from Northern Ireland.

(2) But a person does not commit such an offence if—

(a) he makes an authorised disclosure under section 338 and (if the disclosure is made before he does the
act mentioned in subsection (1)) he has the appropriate consent;

(b) he intended to make such a disclosure but had a reasonable excuse for not doing so;

(c) the act he does is done in carrying out a function he has relating to the enforcement of any provision of
this Act or of any other enactment relating to criminal conduct or benefit from criminal conduct.

(2A) Nor does a person commit an offence under subsection (1) if—

(a) he knows, or believes on reasonable grounds, that the relevant criminal conduct occurred in a particular
country or territory outside the United Kingdom, and


-----

[2023] EWHC 88 (Admin)

(b) the relevant criminal conduct—

(i) was not, at the time it occurred, unlawful under the criminal law then applying in that country or territory,
and

(ii) is not of a description prescribed by an order made by the Secretary of State.

(2B) In subsection (2A) “the relevant criminal conduct” is the criminal conduct by reference to which the
property concerned is criminal property.

(2C) A deposit-taking body, electronic money institution or payment institution that does an act mentioned
in paragraph (c) or (d) of subsection (1) does not commit an offence under that subsection if—

(a) it does the act in operating an account maintained with it, and

(b) the value of the criminal property concerned is less than the threshold amount determined under
section 339A for the act.

(3) Concealing or disguising criminal property includes concealing or disguising its nature, source, location,
disposition, movement or ownership or any rights with respect to it.”

33. Secondly, section 328 of the 2002 Act creates an offence of being involved in an arrangement in
relation to criminal property. This offence is defined as follows:

“328 Arrangements

(1) A person commits an offence if he enters into or becomes concerned in an arrangement which he
knows or suspects facilitates (by whatever means) the acquisition, retention, use or control of criminal
property by or on behalf of another person.

(2) But a person does not commit such an offence if—

(a) he makes an authorised disclosure under section 338 and (if the disclosure is made before he does the
act mentioned in subsection (1)) he has the appropriate consent;

(b) he intended to make such a disclosure but had a reasonable excuse for not doing so;

(c) the act he does is done in carrying out a function he has relating to the enforcement of any provision of
this Act or of any other enactment relating to criminal conduct or benefit from criminal conduct.

(3) Nor does a person commit an offence under subsection (1) if—

(a) he knows, or believes on reasonable grounds, that the relevant criminal conduct occurred in a particular
country or territory outside the United Kingdom, and

(b) the relevant criminal conduct—

(i) was not, at the time it occurred, unlawful under the criminal law then applying in that country or territory,
and

(ii) is not of a description prescribed by an order made by the Secretary of State.

(4) In subsection (3)“the relevant criminal conduct” is the criminal conduct by reference to which the
property concerned is criminal property.”

34. Thirdly, the 2002 Act creates an offence of acquisition, use and possession of criminal property. The
terms of section 329 which creates this offence is as follows:

“329 Acquisition, use and possession

(1) A person commits an offence if he—

(a) acquires criminal property;

(b) uses criminal property;


-----

[2023] EWHC 88 (Admin)

(c) has possession of criminal property.

(2) But a person does not commit such an offence if—

(a) he makes an authorised disclosure under section 338 and (if the disclosure is made before he does the
act mentioned in subsection (1)) he has the appropriate consent;

(b) he intended to make such a disclosure but had a reasonable excuse for not doing so;

(c) he acquired or used or had possession of the property for adequate consideration;

(d) the act he does is done in carrying out a function he has relating to the enforcement of any provision of
this Act or of any other enactment relating to criminal conduct or benefit from criminal conduct.

(2A) Nor does a person commit an offence under subsection (1) if—

(a) he knows, or believes on reasonable grounds, that the relevant criminal conduct occurred in a particular
country or territory outside the United Kingdom, and

(b) the relevant criminal conduct—

(i) was not, at the time it occurred, unlawful under the criminal law then applying in that country or territory,
and

(ii) is not of a description prescribed by an order made by the Secretary of State.

(2B) In subsection (2A) “the relevant criminal conduct” is the criminal conduct by reference to which the
property concerned is criminal property.]

(2C) A deposit-taking body, electronic money institution or payment institution that does an act mentioned
in subsection (1) does not commit an offence under that subsection if—

(a) it does the act in operating an account maintained with it, and

(b) the value of the criminal property concerned is less than the threshold amount determined under
section 339A for the act.

(3) For the purposes of this section—

(a) a person acquires property for inadequate consideration if the value of the consideration is significantly
less than the value of the property;

(b) a person uses or has possession of property for inadequate consideration if the value of the
consideration is significantly less than the value of the use or possession;

(c) the provision by a person of goods or services which he knows or suspects may help another to carry
out criminal conduct is not consideration.”

35. The question of proving that particular property is criminal property for the purposes of these offences
has been considered by the courts on several occasions. In the case of R v Montila [2004] 1 WLR 3141;

_[2004] UKHL 50 a number of defendants were charged with offences of concealing, disguising, converting_
or transferring property knowing or having reason to suspect that the property represented another
person's proceeds of criminal conduct or drug trafficking. A preliminary question arose as to whether it was
necessary for the prosecution to prove that the property which was the subject of the charge was in fact the
proceeds of crime. The House of Lords ruled that it was necessary to prove that the property was the
proceeds of crime, and that the property had its origins in criminal conduct, as an essential part of the
actus reus of the offence. Although the particular charges which the defendants faced were not framed
under the 2002 Act, Lord Hope, giving the opinion of the Committee, addressed the language of section
340 of the 2002 Act as well as the international legal instruments which provided the background to the
creation of the legislation. Lord Hope concluded that the expression “criminal property” required the
prosecutor to prove that the property was the proceeds of crime and had its origins in criminal conduct (see
paragraph 41).


-----

[2023] EWHC 88 (Admin)

36. The Claimant also draws attention in relation to these issues to the decision of the Court of Appeal in
the case of _R v Anwoir and others_ [2009] 1 WLR 980; _[2008] EWCA Crim 1354. In that case the_
defendants were charged under section 328 of the 2002 Act, and the question arose as to what the
prosecution needed to prove to establish that the property in question was criminal property within the
meaning of section 340 of the 2002 Act. In giving the judgment of the Court of Appeal Latham LJ stated as
follows at paragraph 21:

“We consider that in the present case the Crown are correct in their submission that there are two ways in
which the Crown can prove the property derives from crime, (a) by showing that it derives from conduct of
a specific kind or kinds and that conduct of that kind or those kinds is unlawful, or (b) by evidence of the
circumstances in which the property is handled which are such as to give rise to the irresistible inference
that it can only be derived from crime.”

37. It is to be noted from Latham LJ's formulation of the requirements that, firstly, there is no need to
identify the specific offence which is relied upon to demonstrate that the property is criminal property.
Further, Latham LJ referred specifically to circumstantial evidence as being material which could be relied
upon if it gives rise to an “irresistible inference” that the property could only be derived from crime.

38. These issues were addressed by the Supreme Court in the case of R v GH [2015] 1 WLR 2126; [2015]
_UKSC 24. The case concerned an arrangement struck between the defendant and a fraudster whereby the_
defendant opened two bank accounts and then gave the associated bank cards and documentation to the
fraudster, who then used them to establish fraudulent car insurance websites. The defendant was charged
with entering into or being concerned in a money laundering arrangement contrary to section 328(1) of the
2002 Act. The case was stopped by the judge at the close of the evidence on the basis that at the time that
the arrangement had been entered into there had not been any criminal property in existence.

39. In giving the judgment of the Supreme Court, with which all other members of the court agreed, Lord
Toulson observed, at paragraph 20, that there was an unbroken line of Court of Appeal authority holding
that it is a prerequisite of the offences created by sections 327, 328 and 329 of the 2002 Act that property
alleged to be criminal property should have that quality or status at the time of the alleged offence. In other
words, criminal property means property obtained as a result of, or in connection with, criminal activity
separate from that which is the subject of the charge itself. On this basis Lord Toulson rejected the
prosecution submission that the same conduct could both cause property to become criminal and also
simultaneously constitute the offence under section 328 of the 2002 Act. Lord Toulson did, however,
accept that it did not matter whether the criminal property existed at the time of entering into the
arrangement to deal with it was made: what mattered was that the property was criminal at the time when
the arrangement operated upon it. In the case being considered what rendered the property criminal
property was not the arrangement between the defendant and the fraudster, but rather that the property
was obtained by the fraudster by the operation of deception upon the victims. Thus it could be legitimately
concluded that the defendant had participated in an arrangement to retain criminal property for the benefit
of another and the judge had been wrong to withdraw the case from the jury.

40. As set out above, there are further provisions in Part 5 of the 2002 Act which create powers for the civil
recovery of the proceeds of crime. Section 240 of the 2002 Act sets out that the purpose of Part 5 is to
enable the recovery in civil proceedings of property which is, or which represents, property obtained
through unlawful conduct, as well as enabling such property to be forfeited in civil proceedings. Section
241 defines unlawful conduct in the following terms:

“241 “Unlawful conduct”

(1) Conduct occurring in any part of the United Kingdom is unlawful conduct if it is unlawful under the
criminal law of that part.

(2) Conduct which—

(a)  occurs in a country [ or territory]1 outside the United Kingdom and is unlawful under the criminal law

[applying in that country or territory] and


-----

[2023] EWHC 88 (Admin)

(b) if it occurred in a part of the United Kingdom, would be unlawful under the criminal law of that part,

is also unlawful conduct.

(2A) Conduct which—

(a) occurs in a country or territory outside the United Kingdom,

(b) constitutes, or is connected with, the commission of a gross human rights abuse or violation (see
section 241A), and

(c) if it occurred in a part of the United Kingdom, would be an offence triable under the criminal law of that
part on indictment only or either on indictment or summarily,

is also unlawful conduct.

(3) The court or sheriff must decide on a balance of probabilities whether it is proved—

(a) that any matters alleged to constitute unlawful conduct have occurred, or

(b) that any person intended to use any property in unlawful conduct.

41. Section 241A provides further definition in relation to what amounts to “gross human rights abuse or
violation” so as to give the provisions extra-territorial effect. Thereafter section 242 provides as follows in
relation to obtaining property through unlawful conduct:

“242 “Property obtained through unlawful conduct”

(1) A person obtains property through unlawful conduct (whether his own conduct or another's) if he
obtains property by or in return for the conduct.

(2) In deciding whether any property was obtained through unlawful conduct—

(a) it is immaterial whether or not any money, goods or services were provided in order to put the person in
question in a position to carry out the conduct,

(b) it is not necessary to show that the conduct was of a particular kind if it is shown that the property was
obtained through conduct of one of a number of kinds, each of which would have been unlawful conduct.”

42. Consequent upon these provisions section 304 of the 2002 Act provides that property which has been
obtained through unlawful conduct is recoverable property, and further that recoverable property obtained
by unlawful conduct may be followed into the hands of a person obtaining it on a disposal either by the
person who through the conduct obtained the property or a person into whose hands it may, as a result of
these provisions be followed. Section 305 and 306 further develop these principles as follows:

“305 Tracing Property, etc

(1) Where property obtained through unlawful conduct (“the original property”) is or has been recoverable,
property which represents the original property is also recoverable property.

(2) If a person enters into a transaction by which
(a) He disposes of recoverable property, whether the original property or property which (by virtue of this
Chapter) represents the original property, and

(b) He obtains other property in place of it,

The other property represents the original property.

(3) If a person disposes of receoverable property which represents the original property, the property may
be followed into the hands of the person who obtains it (and it continues to represent the original property).

306 Mixing property


-----

[2023] EWHC 88 (Admin)

(1) Subsection (2) applies if a person's recoverable property is mixed with other property (whether his
property or another's).

(2) The portion of the mixed property which is attributable to the recoverable property represents the
property obtained through unlawful conduct.

(3) Recoverable property is mixed with other property if (for example) it is used
(a) To increase funds held in a bank account,

(b) In part payment for the acquisition of an asset,

(c) For the restoration or improvement of land,

(ca)   for the discharge (in whole or in part) of a  mortgage, charge or other security,

(d) By a person holding a leasehold interest in the property to acquire the freehold.”

43. It is against the background of these legal provisions that the Claimant's submissions that the stated
position of the Defendant betrays mis-directions of law fall to be evaluated.

Submissions and conclusions

44. In addressing Ground 1 it is worthwhile returning to the Defendant's impugned approach which was set
out in the correspondence rehearsed above. The Defendant noted that “the standard required by s1
FPMGA to establish that the relevant goods are prison-made is high – viz that it must be proved by
evidence tendered to the satisfaction of the relevant enforcing officer, on the balance of probabilities, that it
was in fact made in a foreign prison”. Furthermore, the Defendant, in paragraph 19 of the letter dated 10th
September 2021 to the Claimant, states that “s1 FPMGA envisages the production of evidence linking a
specific consignment of goods to a specified facility meeting the definition of a foreign prison”, and that it
needed to be established “evidentially that such a connection between the originating location and a
particular shipment of goods” could be proved. In practice it would be implausible such a conclusion could
be reached on the basis of the nature of the goods alone in circumstances where such goods were
produced elsewhere. This was prior to giving consideration to the complexities of modern international
supply chains.

45. The Claimant contends that this approach contains a misdirection of law. Firstly, it is submitted that the
statute does not limit the type of evidence which could be taken into account, and therefore circumstantial
evidence could be relied upon to meet the balance of probabilities threshold. Secondly, it is submitted that
the Defendant is in effect imposing a higher threshold in practice than the balance of probabilities: by
requiring that there be proof that there be evidence linking a specific consignment of goods to a particular
foreign prison the Defendant was in reality seeking proof that they were definitely produced there, or at the
very least that it was highly likely that they were produced there. This was not an approach to the test
which was warranted by a proper construction of section 1 of the 1987 Act. All that was required was for
the enforcement officer to be satisfied that the goods in question were more likely than not to have been
made in a foreign prison, and that is a question which could be satisfied on the basis of the available
circumstantial evidence.

46. Although points were made by the Defendant in the correspondence relying upon various extracts
from Hansard, both contemporaneous with the legislation and subsequently, little was made of this material
in the course of argument. In my view this was sensible and little further needs to be said on this topic.
There were two central themes to the submissions of the Defendant in response to the Claimant's
argument. The first point is concerned with the proper construction of section 1 of the 1897 Act; the second
point is concerned with the practical evidential difficulties with the Claimant's case.

47. The Defendant's submissions in relation to the correct interpretation of section 1 of the 1897 Act start
with the contention that the words of the prohibition contained in the section require that the link is proved
between the goods being assessed by the enforcement officer and their manufacture in a foreign prison.
The provisions of the section are said to be clear in requiring proof in respect of the actual consignment


-----

[2023] EWHC 88 (Admin)

under consideration: if there is evidence to support the contention that the goods were not produced in a
foreign prison (bearing in mind the distinction between prison labour, or detained labour, as distinct from
forced labour, a distinction which the Claimant accepts) then the goods will be excluded from the
prohibition.

48. Secondly, the Defendant contends that the section requires proof of an unbroken chain between the
goods and their manufacture in a foreign prison. It is accepted that assessment can include circumstantial
evidence, but there still needs to be a sufficiency of evidence to prove the link. Thirdly, the Defendant
submits that the statistical approach taken by the Claimant on the basis of the available circumstantial
evidence does not amount to proof of the prohibition. If the statistical approach is taken, and the question is
analysed on the basis of, for example, an assumption that the majority of consignments are made in a
foreign prison, then that approach lumps together both prohibited and untainted consignments in a manner
which does not enable the question posed by the section to be answered with integrity. In a similar way,
the Claimant's approach to the balance of probabilities confuses the chance of an event occurring with the
event itself, and is also flawed in a similar fashion to the statistical approach.

49. Fourthly, the effect of the Claimant's submissions is to substitute a requirement that a high proportion
of the consignments presented to the enforcement officer were made in a foreign prison for the correct
requirement that the link is established between the specific consignment being considered and its
manufacture in a foreign prison. On this basis forfeiture could readily occur in relation to consignments
which were not tainted, leading to the serious consequence of legitimate importers being deprived of goods
by confiscation.

50. The Defendant's submissions in relation to the evidential difficulties presented by the Claimant's
approach relate to both this Ground and also Grounds 3 and 4. The Defendant points out that whilst the
evidence which the Claimant has produced goes to the question of whether there is credible evidence of
human rights abuses in the cotton industry in XUAR generally, that material is insufficient to enable
conclusions to be drawn as to the particular or specific circumstances of an individual consignment of
goods. This is not a question of circumstantial evidence: whilst circumstantial evidence of the existence of
a fact may be compelling that is a different from circumstantial evidence of the chance of a fact existing.

51. Furthermore the evidence submitted by the Claimant leaves many important questions unanswered.
For instance, what percentage of the cotton sourced from XUAR is manufactured by prison or detained
labour and what percentage is in fact from forced labour and therefore not within the scope of section 1 of
the 1897 Act. There are further uncertainties in relation to the percentages of the cotton concerned which
has come directly or indirectly from China, and the evidence does not warrant the conclusion that the vast
majority of the cotton consignments are manufactured by detained or prison labour.

52. There are further problems in the evidence. For instance, in relation to the implicated company LuThai,
the Claimant submits that it is reasonable “to infer that the manufacturing of fabric and cotton products in
Shandong makes use of significant amount of cotton materials which were initially produced in LuThai's
XUAR facilities” notwithstanding LuThai having sold its stake in its XUAR subsidiary in 2020. Thus the
Defendant submits that the Claimant must be contending that the sale of the subsidiary was a sham,
further adding to the lack of clarity in the evidential basis for the Claimant's case. The Claimant is unable to
point to any specific instance of criminality, and the circumstantial evidence of statistical risks of criminality
is not a substitute for proof.

53. Ultimately in connection with the evidential difficulties the Defendant contends that the reality of the
Claimant's case is that they are seeking to apply a reverse burden of proof to the situation. That is
unwarranted and in particular is not justified by the correct approach to section 1 of the 1897 Act.

54. Central to the resolution of the issues raised under Ground 1 is, in my judgment, the question of the
correct approach to the construction of section 1 of the 1897 Act and whether that is reflected in the stated
position of the Defendant in the letter of 10th September 2021. In my view, the terms of the definition of the
goods that are prohibited from importation by section 1 of the 1897 Act are clear and straightforward.
Firstly and uncontroversially the burden of proof that the goods are prohibited rests with the enforcement


-----

[2023] EWHC 88 (Admin)

officer; the standard of proof is the balance of probabilities. Secondly, it is clear that the question for the
enforcement officer relates specifically to the goods that are being examined and that it needs to be proved
on the balance of probabilities that those goods were made or produced wholly or in part in a foreign
prison. It was accepted by the Defendant in the course of argument that it would not be necessary to prove
the specific prison in which the goods were manufactured, and this was a sensible concession. However,
the link between a specific consignment of goods and their manufacture in a foreign prison still needs to be
proved for the prohibition under section 1 of the 1897 Act to be made out.

55. This construction of section 1 of the 1897 Act is entirely consistent with the approach outlined in the
Defendant's letter dated 10th September 2021. I am unable to accept the Claimant's contention that this
approach in any way limits the types of evidence to be received and evaluated as part of the application of
section 1. As was accepted by the Defendant in the course of argument, circumstantial evidence can be
brought into account: the real question is whether on the basis of all the available evidence the prohibition
is proved. I am also unable to accept that by requiring evidence linking the specific consignment under
consideration to manufacture by detained or prison labour a higher standard of proof than the balance of
probabilities is being applied. The requirement for evidence linking the consignment being examined to
such manufacture faithfully reflects the requirements of section 1 of the 1897 Act. I have reached the
conclusion that the Defendant's approach is legally sound and not subject to any misdirection. This is
sufficient to dispose of the Claimant's Ground 1.

56. The arguments which ranged beyond this position appear to examine the appropriateness of the
Defendant's evaluation of the available evidence in circumstances where the Claimant has, correctly, been
clear that this is not a challenge based on Wednesbury principles in relation to the failure of the Defendant
to further investigate consignments of cotton hitherto. In any event, I am satisfied that there is some
substance in the misgivings expressed by the Defendant as to the Claimant's approach to proof of the
prohibition under section 1. It is undoubted that there is clear and undisputed evidence of instances of
cotton being manufactured in the XUAR by the use of detained and prison labour as well as by forced
labour in the facilities which have been described above. However, this does not in and of itself satisfy the
proof required by section 1 of the 1897 Act for the reasons given by the Defendant. The relative
proportions of goods derived from detained or prison labour is not ascertainable in detail, nor are the
proportions of good derived from forced labour. Moreover, as the Defendant submits, it is not appropriate
to equate proof of a fact (in this case the manufacture of a specific consignment of goods by prison or
detained labour) on the balance of probabilities with the chance or risk that this may be the case.
Substituting an assessment of the chance or risk of the goods being tainted for an examination of whether
on the balance of probabilities the particular goods were tainted carries with it the obvious potential for not
properly distinguishing between goods which are actually in fact tainted from those which in fact are not,
leading to the forfeiture of goods not properly the subject of the prohibition. This further reinforces the
robustness of the Defendant's analysis of these issues.

57. I turn to the questions raised under the Claimant's Ground 2. This is the contention that the Border
Force note set out above unlawfully fettered the Defendant's discretion to investigate breaches of section 1
of the 1897 Act. As set out above in the correspondence, the text of the document which the Claimant
relies upon is as follows:

“The importation of goods made in foreign prisons is prohibited under section 1 of The Foreign Prison
Made Goods Act 1897. Border Force operates on a reactive basis in response to intelligence suggesting
goods were made in a foreign prison. Prison made goods will be seized where they are detected and
where reacting to intelligence.”

58.  The Claimant contends, firstly, that this is a policy document since it provides guidance as to how the
discretionary powers under the 1897 Act are to be exercised. As such, therefore, applying the principles
set out in the case of A above, it is clear that the document does have the status of policy for public law
purposes. The Claimant's second submission is that the terms of the policy unlawfully fetter the discretion
under section 1 of the 1897 Act in that it has the effect of precluding an officer of Border Force investigating
any potential breach proactively since the officer is directed by the policy to operate solely on a reactive


-----

[2023] EWHC 88 (Admin)

basis and by reacting to intelligence. Even if an investigation were merited by the circumstances of the
case this would be precluded by the terms of the policy.

59. By contrast, the Defendant submits that the document referred to is not a policy. It is submitted that it
is in truth what it describes itself as, and what it is described as by Mr Huke, namely a note containing
information (including contact data) to act as an aide memoir for officers in their role rather than instruct or
guide them in how to undertake their duties. Furthermore, in describing Border Force operating on a
reactive basis it is faithfully reflecting both the legislative provisions of the 1897 Act and also the role that
Border Force plays in practice. The provisions of section 1 refer to the operation of the section depending
upon “evidence tendered to” the enforcement officer satisfying the officer that the goods in question were
manufactured in a foreign prison: the provision therefore describes a process of reacting to evidence
provided to the officer. Border Force in practice carry out their role by responding to intelligence provided to
them in the import or export process by other Government departments or law enforcement agencies. Far
from being a policy the document is contended to simply amount to a note containing information about the
1897 Act.

60. The Defendant goes on to contend that, even were the document to be considered in law to be a
policy, it does not give rise to an unlawful fettering of the discretion of the enforcement officer in exercising
the powers under section 1 of the 1897 Act. As set out in the first submission, the Defendant contends that
the text simply reflects of the provisions of section 1, which do not prohibit the importation of goods or their
seizure on the basis of reasonable suspicion. Guidance which suggested that were possible would,
therefore, be unlawful. On the other hand, the text of the document does not in any way suggest that the
[Border Force officer is not entitled to exercise the investigatory powers available under the Customs and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y1F1-00000-00&context=1519360)
_[Excise Management Act 1979 where appropriate.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y1F1-00000-00&context=1519360)_

61. Having considered these submissions I am not satisfied that the Claimant is correct to characterise the
document in question in this part of the case as a policy. It appears clear to me, both from the terms of the
document and such contextual material as is available to the court, to be simply an information note
designed as nothing more than an aide memoire for Border Force staff. I have reached that conclusion for
the following reasons.

62. Firstly, that is the way in which the document describes itself: it is headed, prior to the headings in
relation to the subject areas, “Subject area information”, and there is no indication that it is intended to
operate as a policy in relation to the conduct of duties under those subject areas. Secondly, it is clear that
the text itself is essentially descriptive rather than prescriptive in relation to the operations of Border Force
in this area. Whilst most of the document was no doubt redacted for good reason, and it would have been
helpful for context to see how the other areas under the headings were treated, judging simply on the basis
[of the text set out above and also the text in the document related to the Proceeds of Crime Act 2002,I am](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y037-00000-00&context=1519360)
satisfied that this is an information sheet and not an operational policy.

63. Thirdly, I have no reason to go behind the evidence of Mr Huke in which he explains, as set out above,
that the document is “a point of reference concerning the extensive range of controls on goods at the
border and provides officers with helpful contact information”. This is inconsistent with the document
containing a policy on the exercise of the powers under section 1 of the 1897 Act. For these reasons I am
satisfied that the document is not a policy in the legal sense set out in A, and that is sufficient to dispose of
the Claimant's case under Ground 2.

64. Notwithstanding this conclusion, in my view there would be no substance in Ground 2 even were it to
be concluded that the document did contain policy on the exercise of the power under section 1 of the
1897 Act, since I am not convinced that even were it to be considered policy that it represents an unlawful
fettering of the Border Force officer's discretion. Firstly, applying the principles set out in the _West_
_Berkshire set out above, the fact that the policy does not specifically admit of exceptions does not mean_
the possibility that there may be exceptions does not exist. This possibility does not have to be spelled out
for the policy to be lawful. Secondly, as pointed out by the Defendant and noted above, the language of the
document does faithfully reflect the terms of section 1 of the 1897 Act and the way in which Border Force


-----

[2023] EWHC 88 (Admin)

operates in practice. As described in the evidence of Mr Huke, the way in which Border Force selects
consignments is as follows:

“13. Border Force may select goods to examine using information gathered from a range of sources. For
example, Border Force may use historical data (of successful examinations and seizures); concerns
identified through an analysis of the declaration (or manifest); and/or information provided by other
Government departments and law enforcement agencies (that could be of a general or specific nature).”

65. Thirdly, and related to the first point of principle which is set out above, the terms of the document do
not suggest that if appropriate the enforcement officer is not permitted to exercise powers provided by the
1979 Act for the purposes of investigaton, such as for instance the power pursuant to section 139(1A) of
that Act to detain any thing which the officer “reasonably suspects…may be liable to forfeiture”. Taking
these points together it appears to me that even if the document were taken to amount to a policy, rather
than fettering the discretion of the enforcement officer it provides a succinct and coherent explanation of
how the power under section 1 of the 1897 Act is exercised.

66. In conclusion, I am not satisfied that any of the concerns of the Claimant in relation to Ground 2 are
made out. It follows that I am unable to uphold either of their complaints which are related to the
Defendant's approach to section 1 of the 1897 Act.

67. Ground 3 relates to the Claimant's contention that the Defendant's approach to the use of the powers
available under Part 7 of the 2002 Act has been driven by a misdirection of law. The submissions under
Ground 4, in relation to the failure to deploy the powers of civil recovery under Part 5 of the 2002 Act, are
related to this contention, in that again the Claimant contends that the approach of the Defendant is
misconceived as a matter of law. As set out above, in the correspondence the Defendant essentially relies
upon the same submissions in relation to both Grounds 3 and 4, and asserts that there is no proper basis
in the Claimant's material for an investigation under the 2002 Act.

68. Whilst the Defendant accepts that for the purposes of the 2002 Act the offences of forced labour
contrary to section 1 of the **_Modern Slavery Act 2015 and crimes against humanity contrary to section_**
51(1) of the International Criminal Court Act 2001 are capable of constituting criminal conduct within
section 340 of the 2002 Act, they submit that further evidence would be required in order for the provisions
of the 2002 Act to be engaged. The essence of the Defendant's approach is to be found in the
correspondence at paragraph 32(i) set out above where it is noted:

“(i) It is a requirement of s.340 POCA that any criminal conduct is clearly and specifically identified and that
the resultant property is specifically identified. It is insufficient, for the purposes of POCA, to deal in
hypothetical scenarios or presumptions. In the absence of identifying a specific consignment of goods that
is the product of the relevant criminality, the requirements of s. 340 are not met and no POCA offence can
arise: see R v GH [2015] UKSC 24.”

69. In respect of the specific offence under section 329 of the 2002 Act, which the Defendant considers
the most apposite offence in relation to a supply chain, as it relates to the acquisition, use and possession
of criminal property, the Defendant notes that under section 329(2)(c) it is a defence for a person to acquire
or have possession of criminal property for an adequate consideration. This is considered by the
Defendant to be a further impediment to the use of the powers under the 2002 Act, although it is conceded
that the offences under section 327 and 328 of the Act are also potentially to be considered.

70. The Claimant takes issue at the outset with the approach taken by the Defendant to the identification
of the criminal property and, in particular, the need for a specific consignment to be identified. Against the
background of the undisputed evidence of the widespread use of forced labour in the XUAR to produce
cotton products, amounting to criminal conduct, then it should be agreed that the proceeds of the sale of
such cotton products are capable of meeting the definition of criminal property in section 340 of the 2002
Act. The Defendant's insistence on proof in relation to a specific consignment of cotton does not
necessarily reflect the emphasis in the authorities on the width of the definition of criminal property, which
for instance does not require the proof of a specific crime or specific criminal conduct. Furthermore, even


-----

[2023] EWHC 88 (Admin)

were a specific consignment to be required in order to satisfy the definition of criminal property, that could
not properly be a requirement before commencing an investigation in relation to money laundering. The
Claimant contends that the provisions of section 340 are well suited to an investigation of value chains
where the goods involved are produced by criminal activity. The approach of the Defendant would imply
that, for instance, in a fraud case it would be necessary for a complainant to provide full details of a bank
account before the authorities could contemplate any investigation of the source of the funds within it.

71. In so far as the Defendant relies upon the provisions in section 329(2)(c) and the exemption from the
offence of those who purchased for adequate consideration, the Claimant submits that this phrase is not
clear and unambiguous in the way suggested by the Defendant. It needs to be understood in context, and
here the context includes other provisions of the 2002 Act, including section 329(3) and its approach to
inadequate consideration, as well as the international instruments relating to possession of criminal
property. A sweeping construction of this provision could lead to the endorsement of a market in goods
produced by modern slavery.

72. Turning to the provisions of Part 5 of the 2002 Act, and the powers of civil recovery, the Claimant
draws attention to the fact that the standard of proof in relation to these powers is the balance of
probabilities and therefore lower than that pertaining to Part 7. Furthermore, the Claimant submits that it is
[significant that the Criminal Finances Act 2017 introduced section 241A of the 2002 Act, which specifically](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5NGW-N8S1-DYCN-C2DX-00000-00&context=1519360)
expanded the definition of unlawful conduct so as to include gross human rights abuses or violations,
further reinforcing the potential for the use of these powers in connection with international value chains
linked to modern slavery of the kind with which this case is concerned.

73. In response the Defendant focusses on the centrality to all of the offences created by sections 327,
328 and 329 of the 2002 Act of the need to demonstrate the involvement of criminal property. The
definition of criminal property requires proof that the property concerned constituted or represented a
person's benefit from criminal conduct (as defined) and also that the alleged offender knew or suspected
that the property constituted such a benefit. The importance of the required connection between the
criminal conduct and the property is reinforced by the provisions of sections 340(4)(5) and (8) of the 2002
Act. The key submission made by the Defendant is that the legislative scheme does not engage with a
case where there is alleged or suspected offending on one hand, and property on the other, but it is not
possible to establish the connection between them. Instead the provisions of the 2002 Act require that
there is specific property which can be identified as having been involved or connected with the kind of
criminal conduct concerned in the case.

74. The Defendant draws attention to the specific requirements of the individual offences, commencing
with that created by section 327 of the 2002 Act. This offence has at its heart certain specified types of
treatment of criminal property in that the establishment of the involvement of criminal property is a central
requirement for proving the commission of the offence. Turning to section 328 of the 2002 Act the offence
has, in effect, a requirement for the proof of a double mens rea: firstly, the mental element involved in
proving that the property concerned is criminal property, and, secondly, proving that the person accused
knew or suspected that they were facilitating the acquisition, retention, use or control of the criminal
property.

75. The provisions of section 329 introduce the additional complexity of the exemption in relation to the
acquisition, use or possession of the property for adequate consideration. The Defendant points out that in
relation to the importation of goods, where the importer is paying market value for the purchased goods
they would not be tainted as a result of the operation of the provision. This approach is supported by the
terms of section 329(3)(a) of the 2002 Act which provide that consideration which is “significantly less than
the value of the property” would amount to inadequate consideration. As a result of these provisions, if a
purchaser has bought a consignment of cotton goods from China bona fide and at a market value any taint
passes to the purchase price and the criminal property remains in China. The Defendant points out that at
any point in such a market supply chain stretching many thousands of miles the chain could be broken by
the use of adequate consideration in any of the transactions involved.


-----

[2023] EWHC 88 (Admin)

76. The Defendant draws attention to the existence of authority in relation to the proper interpretation of
the phrase adequate consideration in the context of section 329(2)(c). The case of Hogan v DPP [2007] 1
WLR 2944; [2007] EWHC 978 (Admin) concerned a defendant who was found in possession of scaffolding
which belonged to his former employer which he had paid £1,100 to acquire. He contended that he had
purchased the scaffolding for adequate consideration. The Magistrate decided that he was entitled to take
the whole of the circumstances of the case, including the fact that the accused knew that the scaffolding
constituted a benefit from criminal conduct, into account when deciding whether consideration had been
adequate. The Divisional Court held that the Magistrate had misdirected himself and that the question of
whether consideration was adequate was an objective one, quite discrete and separate from the question
of the accused knowing or suspecting that the property constituted a benefit from criminal conduct.

77. In giving the leading judgment of the Divisional Court, Irwin J provided as follows:

“16. …Wherever the burden lies and whatever may be the consequential standard of proof, if criminal
property is acquired for “adequate consideration”, then no offence is committed under the Act. I emphasise
that this requirement applies to _criminal property. In other words, if the court concludes that adequate_
consideration has been given for the acquisition of property, then no offence is made out under the 2002
Act, even if the defendant who has acquired the property knows that it was stolen. I pause to observe that,
in circumstances like that, other offences may well be made out, but they will not be offences under this
part of the 2002 Act. I reach this conclusion as a matter of straightforward statutory interpretation.

17. What is the meaning of “adequate consideration”? This must be a question of fact in each case. In
deciding it, my view is that a court is entitled-indeed has an obligation-to look at all relevant circumstances
drawn from the evidence. But the question is an objective one. It is a discrete question from the question of
knowledge, belief or suspicion by the defendant as to whether the property constitutes a benefit from
criminal conduct. Thus, the question is not whether all relevant circumstances may be brought to bear on
the adequacy of consideration. They may. The point is that this is a separate question from the state of
mind of the defendant. It is an inevitable consequence of the way the 2002 Act is drawn that a person who
acquires criminal property which he knows to be stolen, but acquires it for full consideration, will not be
guilty under this part of the 2002 Act.”

78. The Defendant's submission is that in relation to each of the offences under Part 7 of the 2002 Act it is
clear that there is a requirement for specificity in relation to the particular consignment of goods in
question, and a requirement to demonstrate that it is criminal property through proof that the particular
consignment is derived from criminal conduct. An inference or a suspicion that it may be derived from
criminal conduct is not enough. There are additional complexities presented in relation to the requirement
for a double mens rea in respect of the offence under section 328, as well as the exemption in respect of
adequate consideration under the offence created by section 329 of the 2002 Act. So far as either a
criminal or a civil investigation is concerned the Defendant contends that there is little point in commencing
investigations which do not have a realistic prospect of any successful conclusion. The Defendant draws
attention to the inevitable need for co-operation from the PRC authorities which, on the available material,
will not be forthcoming, and the danger of embarking upon investigations which in addition to being
incapable of effective resolution would also carry the risk of allegations of high-handed conduct and abuse
of power.

79. The starting point for determining conclusions in respect of these rival submissions is the position
expressed by the Defendant in correspondence, and the question of whether that position incorporated any
error of law or misdirection which would entitle the Claimant to the grant of relief. The Defendant's position
on the concerns raised related to the powers under the 2002 Act are set out above in paragraphs 32(i) and
(ii) of the letter of the 10th September 2021. Paragraph 32(i) the Defendant records its central point that
“[I]t is a requirement of s340 POCA that any criminal conduct is clearly and specifically identified and that
the resultant property is specifically identified”. In paragraph 32(ii) sets out the Defendant's points in
relation to the exemption in relation to purchase for adequate consideration, and the importance of this
issue in cases dealing with value chains. The Defendant's submissions which are recorded above are


-----

[2023] EWHC 88 (Admin)

grounded in the position set out in the correspondence. Does this approach amount to a misdirection of
law?

80. Having reflected on the respective position of the parties I am not satisfied that there is any legal error
or misdirection in the approach taken by the Defendant to the provisions of the 2002 Act. Commencing with
the provisions contained in Part 7 of the 2002 Act, in my view it is important to note they relate to the
creation of criminal offences, which would need to be proved to the criminal standard. The Defendant is
correct to point out that in relation to each of the offences the starting point must be the identification of
criminal property applying the definition set out in section 340 of the 2002 Act. The requirements of section
340(3) are precise, and in order to prove that a consignment is criminal property it would be necessary to
prove not only that “it constitutes a person's benefit from criminal conduct” but also that “the alleged
offender knows or suspects that it constitutes or represents such a benefit”. It is clear that in order for an
offence to be made out under any of section 327, 328 or 329 these elements must be specifically proved in
relation to specific property. Whilst the Claimant is entitled to draw attention to the extensive volume of
material which evidences the significant concerns in relation to the use of prison and forced labour in the
production of cotton in the XUAR, as the Defendant points out, specific proof rather than suspicion is
required to make out the offences under Part 7 of the 2002 Act. The requirements which the Defendant
stipulates for establishing the offences under this part of the 2002 Act are, in my view, orthodox, accurate
and justify the approach that they have taken to the material provided to them by the Claimant.

81. In essence, the evidential difficulties which have been identified above in relation to Ground 1 are also
pertinent to the issues arising under Grounds 3 and 4. The requirements based on authorities such as
_Montila and GH for criminal property to be established as a prerequisite of money laundering offences, by_
way of criminal conduct separate from the money laundering offence itself, means specific proof in relation
to particular consignments cannot be necessarily inferred from the nature of the available evidence. As the
Defendant points out, the necessary significant detail is not present addressing such issues as where
precisely the criminal conduct occurred in relation to the consignment being examined. Whilst the specific
offence would not be required at the least the kind of criminal activity would need to be known. The details
of when and by whom the conduct was committed would also no doubt be useful information. The available
evidence is unable to fulfil these requirements or provide these details in respect of a specific consignment
and the concerns of the Defendant in connection with them are justified.

82. Whilst not dispositive of these issues, in my view it is useful context to consider the conclusions of the
FAC having examined the evidence presented to them on these matters. This is set out above, and it will
be noted that, in particular, having observed in paragraph 40 of their report that they were “seriously
concerned that products and materials made from Uyghu

83. r forced labour are making their way into UK value chains”, at paragraph 48 of their report in the light
of the available evidence the FAC proposed the imposition of an assumption that any product originating in
the XUAR should be assumed to be the product of forced labour. The presumption could be displaced by
definitive proof that the product was not tainted by forced labour. This recommendation of the FAC was
undoubtedly made in recognition of the difficulties of establishing the necessary proof in relation to a
specific consignment of goods that it was produced by forced, detained or imprisoned labour. Given the
evidential difficulties which the FAC records in relation to monitoring the cotton industry in the XUAR a
reversal of the burden of proof (alongside consideration of an import ban) was the suggested solution. The
adoption of this solution by the FAC underlines the difficulties of deploying the offences in Part 7 of the
2002 Act in this context.

84. Beyond the problems which I accept exist in relation to the proof of criminal property, there are
additional specific problems in pursuing the offences under section 328 and 329 with the material currently
available. In respect of section 328 it would, in addition, to the requirements of proving criminal property, be
necessary to prove that the accused person knew or suspected that the arrangement into which he was
entering facilitated the acquisition, retention use or control of criminal property. The establishing of this
further mens rea of this offence will, as the Defendant points out, create further complexity to proving the
existence of the offence in particular in the context of a lengthy international value chain


-----

[2023] EWHC 88 (Admin)

85. In relation to section 329 there is the added complexity, in particular in the context of a value chain of
the kind under consideration, of the exemption under section 329(2)(c) in relation to the acquisition of the
property for adequate consideration. Whilst the Claimant raises various concerns rehearsed above in
relation to the interpretation of this provision, in my judgment the answer to these submissions is to be
found in the case of Hogan set out above. This authority provides a definitive interpretation which supports
the concerns of the Defendant in respect of the practicality of prosecuting the section 329 offence in
relation to acquisition, use and possession of criminal property in the circumstances under consideration. It
would not only be necessary to show that a consignment was criminal property, but also that, considering
the question objectively, the consignment had been purchased for significantly less than its value or by
some other measure for consideration which was not adequate. This requirement presents difficulties in
the context of the international trading of the goods which are in question in this case, and it appears to me
that the Defendant has set out legitimate and understandable concerns in relation to establishing criminal
liability under section 329 of the 2002 Act in the light of the exemption in section 329(2)(c).

86. In short, having examined the submissions in relation to the 2002 Act I am satisfied that there is no
misdirection evident in paragraph 32 of the Defendant's letter of 10th September 2021. The understanding
of the requirements of section 340 in relation to the proof of criminal property is consistent with authority
and accurate. It was understandable that the focus of paragraph 32(ii) was on section 329 of the 2002 Act
given the nature of the evidence provided to the Defendant bearing upon the value chain in question in this
case, and the observations in relation to the difficulties presented by section 329(2)(c) were again entirely
appropriate and reflected a proper understanding of the relevant legal principles. The focus of paragraph
32(ii) on section 329 was not a misdirection given that the concerns in relation to section 340 set out in
paragraph 32(i) obviously relate to all of the offences under consideration. The letter of the 10th September
2021 therefore demonstrates that the Defendant was correctly directing the assessment of the Claimant's
concerns at the time of reaching the decisions in this case.

87. The Claimant is also critical, in particular in their submissions on Ground 4, of what they contend is a
failure to deploy civil powers of investigation and recovery under Part 5 of the 2002 Act. In my view the
Defendant is entitled to rely upon the same issues and concerns in relation to the specificity of the
evidence in this connection as is relied upon in response to Ground 3. Albeit that the standard of proof is
civil rather than criminal, there is still a need for it to be demonstrated that the specific property which is
being examined was the product of unlawful conduct, along with the necessary particulars of the unlawful
conduct to which it was subject. Similar issues arise in relation to the proof that the specific consignment is
properly to be regarded as meeting the definition of property which is, or which represents, property
obtained by unlawful conduct, even as enlarged by the provisions of section 241A of the 2002 Act.

88. Further, in my view the Claimant's criticisms in relation to the failure to undertake further investigation
need to be set in context. Firstly, it is important to appreciate that the Defendant has not been inert or
unresponsive with regard to the concerns presented by the Claimant. As set out above, all of the material
which is before the court has, prior to these proceedings, been sent to the Defendant for consideration and
evaluation. The Defendant's response was set out in the letter of the 10th September 2021 in the following
terms:

“33. As for the specific questions raised at §49 of the Letter Before Claim concerning the specific steps
taken by the NCA to date concerning specific suppliers in XUAR:

(i) The NCA International Liaison Office in Beijing; the head of the **_Modern Slavery Tactical Advisors_**
Team; and the **_Modern Slavery Intelligence Development Team, have reviewed the information sent by_**
your client to HMRC and passed to the NCA. Their assessment of the matter has not changed.

(ii) The information received from your client to date has consisted of expert opinions, news articles and
committee reports. As noted above, nothing has been identified which provides a concrete allegation of
**_modern slavery upon which the NCA could commence an investigation. The NCA therefore remains at_**
the stage of initial intelligence gathering. No further investigative steps have yet been taken such as are
suggested at §49 of the Letter Before Claim.


-----

[2023] EWHC 88 (Admin)

(iii) The NCA note that your client takes the view that there are suspicions of criminality, however, the
NCA's view remains that there are not currently sufficient grounds to suspect that any identifiable criminal
offence has been committed by identifiable individuals.

(iv) The NCA remains open to the possibility that the intelligence picture may change at any time.

34. In the present circumstances, there is no basis on which to compel any investigation into alleged
money laundering.”

89. It is clear from this paragraph that the material furnished by the Claimant has been the subject of
active examination but, applying the principles set out in paragraph 32 of the same letter, was not
considered to give rise to a basis for further enquiry at that time. The possibility of other information or
intelligence coming to light and requiring investigation was not closed off and remains open.

90. Secondly by way of context, as has been set out above, I accept the Defendant's submissions which
are relevant to Ground 1 as well as Grounds 3 and 4 in relation to the absence of the necessary specificity
in the evidence. That absence of specificity justifies the conclusions reached by the Defendant in relation to
both the 1897 Act and also the 2002 Act, both in relation to the criminal offences it creates and also in
relation to the civil powers which similarly require specific evidence. It also supports the conclusion which
the Defendant reached that there would be little if any purpose to be served by pursuing an investigation
which would not bear fruit in the form of prosecutions or seizures.

91. The third important piece of context is the scope of the court's jurisdiction based on the authorities
such as Corner House, which reflect that the court will be slow to interfere with the exercise of investigatory
and prosecution powers that are vested in parties such as the Defendant in the present case. As was
repeatedly observed on both sides of the case during the hearing, the Claimant does not advance a case
based on _Wednesbury_ unreasonableness, and on the authorities it would be very challenging for the
Claimant to do so. This is a case focussed on alleged misdirections of law, not a challenge to the rationality
of the decisions described in paragraphs 33 and 34 of the letter of 10th September 2021.

92. Once the Claimant's concerns are placed into context then in my view this provides additional support
for the conclusion that there is no substance in the Claimant's Ground 4 and no basis for the grant of any
relief in respect of it.

Conclusions

93. It will be apparent from the examination of the Claimant's grounds set out above that I have reached
the conclusion that none of them are made out and that relief should be refused. It would, however, be
inappropriate to leave this judgment without emphasising the limited role that the court has in relation to a
challenge of this kind. The outcome of the case does not in any way undermine the striking consensus in
the evidence that there are clear and widespread abuses in the cotton industry in the XUAR, involving
human rights violations and the exploitation of forced labour. It is clear that these agreed concerns
continue to trouble the Defendant and are the subject of active policy work and engagement. The task of
the court in this case has been to determine whether the legal tools alighted upon by the Claimant have
been properly understood by the Defendant in taking the approach which they have to the Claimant's
evidence. The conclusion is that there has been no error in the Defendant's analysis. That is not to say that
there may be other tools or measures available to the executive and law enforcement agencies, or other
evidence which they could receive meeting the requirements upon which the Defendant has correctly relied
in this challenge, which could provide an effective basis for tackling the concerns in respect of cotton
production in the XUAR and the exploitation and abuse of the Uyghur people with which it has been
associated.

**End of Document**


-----

