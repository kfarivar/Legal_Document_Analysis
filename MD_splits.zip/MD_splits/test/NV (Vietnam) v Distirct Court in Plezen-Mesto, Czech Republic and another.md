# NV (Vietnam) v Distirct Court in Plezen-Mesto, Czech Republic and another

 [2020] EWHC 409 (Admin)

Queen's Bench Division (Administrative Court)

Nicol J

25 February 2020Judgment

**Florence Iveson (instructed by MW Solicitors) for the Appellant**

**Benjamin Joyes (instructed by Crown Prosecution Service, Extradition Unit) for the Respondents**

Hearing date: 13th February 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

MR JUSTICE NICOL

**Mr Justice Nicol :**

1. This is an extradition appeal brought against the decision of District Judge Griffiths on 30th April 2019 to
order the extradition of the Appellant to the Czech Republic in response to two EAW conviction warrants.

2. No anonymity order had been made previously in this case, but after the hearing and on 20th February
2020 the Appellant's solicitor applied for him to be anonymised in this judgment. In my view that is
appropriate and necessary in view of the evidence about the Appellant's mental condition to which I must
refer.

3. Cutts J. refused permission to appeal on the papers on 30th July 2019, but permission to appeal was
granted by Swift J. after an oral renewal application on 11th December 2019.

4. EAW1 seeks the return of the Appellant to serve all of a 2-year sentence for, people trafficking. All of
this sentence remains to be served. It is based on a single offence, but it involved three events: in two of
them it was alleged that he acted with others; on a third occasion he acted alone. All the events took place
in 2014. He was tried in November 2016 and the judgment became final on 20th December 2016. The
EAW states that he was not present at his trial for these offences, but, following his return, within a
specified time, he will have the right to a re-trial. EAW1 was issued on 17th March 2017 and certified by the
NCA on 14th March 2019.

5. EAW2 seeks the return of the Appellant for an offence of supplying just under 3 kilos of hemp
(cannabis) in 2011. The Appellant was convicted in 2012 after a trial at which he was present. He was
sentenced to 18 months imprisonment of which 187 days remain outstanding. The court's decision became
final on 12th December 2012. EAW2 was issued on 2nd November 2017.


-----

6. At the hearing before the District Judge, the Appellant raised no issues and DJ Griffiths gave an _ex_
_tempore judgment. There is no transcript of what she said, but I have seen a note made by Mr Joyes who,_
then as now, appeared for the Judicial Authorities. Ms Florence Iveson, for the Appellant, takes no issue
with the note as an accurate record of what the District Judge said. Although no issue had been raised, the
District Judge proceeded through the statutory questions which she had to address and, as I have said,
concluded that an order for the Appellant's extradition should be made on both EAWs.

7. With the permission of Swift J., Ms Iveson, now advances two arguments.

i) There is evidence that the Appellant was a victim of trafficking. I also have a report from Dr Juliet Cohen
of the Manor Hospital, Headington, Oxford which is dated 7th November 2019. Ms Iveson submits that this,
taken with all the other circumstances of the case, would have led the DJ to discharge the Appellant on the
grounds that his extradition would be contrary to Article 8 of the European Convention on Human Rights.

ii) Relying on the same material, Ms Iveson alternatively submits that the District Judge would have been
obliged to discharge the Appellant under _[Extradition Act 2003 s.25 because his mental condition is such](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y143-00000-00&context=1519360)_
that his extradition would be oppressive.

8. It is apparent that both grounds of appeal look to the same factual evidence. None of this was available
before the DJ. It makes sense to consider this first before turning to the grounds individually.

**The Appellant's account**

9. In his proof of evidence, the Appellant says that he was born in Vietnam. His family were not wealthy
and got into debt when his mother fell ill and needed treatment. To pay off the loan, he agreed to work for
the lenders whom he describes as mafia. He says he was trafficked to the Czech Republic where he
realised that he would never be free. He was kept prisoner in a basement and beaten regularly. When his
attempts at escape were frustrated, he was abused further. In 2011 he was caught by the Czech police
delivering a package. This was the offence in EAW2. He says that he was unaware that the package
contained cannabis. He was sentenced to 18 months imprisonment, of which he served 12 months.

10. After his release from prison, he was again caught, either by the same gang or by a different one. He
was again forced by them to engage in criminal activities which included people trafficking. This was the
offence in EAW1

11. In 2014 he says that he learned that the leader of the gang wanted to kill him. He tried to escape but
was caught. He says he was starved, beaten, forcibly injected with heroin, stabbed in the chest and left in
the forest to die. He was helped by a Vietnamese family and eventually got back to Vietnam and his family.
His father was involved in opposition politics and, in 2016, his father was arrested and tortured. The
Appellant says that he himself also became involved in politics. He feared for his life and again left
Vietnam. He travelled through Laos and Thailand, then to Russia where he was forced to work for a man
who provided him with a passport. He arrived in the UK in 2018 with other trafficked people who were
forced to stay in a particular house and to work.

12. He was stopped by the police on 26th October 2018 (it seems that this was in connection with a road
traffic matter, he was not arrested on the EAW until March 2019 – see below). He told the police what had
happened to him and led them to the house where he had been held, but all the occupants had fled.

13. He says that he met his girlfriend when they were both trafficked from Russia, though he says that he
had known her for 8 months at the time of his statement. She has been a support for him. He remains in
fear of the traffickers.

14. There was a discrepancy in this regard between his account and that of the girlfriend who said in her
witness statement dated 3rd December 2019 that their relationship had begun in October 2018. The
Appellant's witness statement was signed in October 2019. 8 months earlier would have been February
2019. However, without opposition from Mr Joyes, Ms Iveson adduced a further witness statement of Ms
Hayward, the Appellant's solicitor who said she had seen the Appellant in May 2019 and drafted his
statement on the basis of instructions he then gave. She accepted responsibility for not correcting the


-----

period of time that the Appellant and his girlfriend had known each other before the statement was signed
in October 2019. I accept that this accounts for the apparent discrepancy.

15. The Appellant says that since arriving in the UK he had consulted immigration solicitors who were
helping him to claim asylum and he had been on his way to a Home Office screening interview when he
was arrested under the EAW. We know from the statement of PC Andrew Harman that the Appellant was
arrested on the EAWs on 14th March 2019.

16. At some point after his arrest on the EAWs the Appellant's solicitor made contact with the Salvation
Army who are recognised as being one of the First Responders for the purpose of the National Referral
Mechanism for Victims of Trafficking ('NRM'). The Salvation Army interviewed him on 29th July 2019 and,
on 7th August 2019, submitted to the Home Office, as the Competent Authority, under the NRM that there
were clear indicators that the Appellant was a victim of trafficking. On 8th August 2019 the Home Office
accepted that there were reasonable grounds to conclude that the Appellant was a victim of trafficking. The
next stage in this process is for the Home Office to decide whether there are conclusive grounds to regard
the Appellant as a victim of trafficking. I was told that no such decision has yet been taken.

17. The Appellant also gives an account of his medical problems: feelings of dizziness, being scared and
worried and his fears of being re-trafficked and abused. He says he suffers constantly from flashbacks,
nightmares and panic attacks. He finds it hard to sleep at night. He says that he thinks about harming
himself 'but these are my private thoughts, I will not share this with anyone.' He continues 'If I go back to
the Czech Republic I will die there. I will not let that happen. I would rather die here.'

18. The Appellant says that he was frightened by the court proceedings. Although he was provided with an
interpreter, he did not fully understand what was being said. He says that he only had a short opportunity to
talk to his lawyer. He was under the impression that his lawyer would argue against the extradition, but in
Court he was told he would have to go back to the Czech Republic.

19. On 21st October 2019, the Appellant was seen by Dr Juliet Cohen who has produced a report on him
dated 7th November 2019. Dr Cohen is based at the Manor Hospital, Headington, Oxford. She is Head of
Doctors for the Medical Foundation Medico-Legal Report Service and a fellow of the Faculty of Forensic
and Legal Medicine of the Royal College of Physicians.

20. The Appellant described to Dr Cohen hearing voices telling him to kill himself, though he recognises
this as a symptom, rather than an actual person speaking to him. He told Dr Cohen that he had selfharmed by punching himself and tries to think of ways of killing himself 'but was too scared at the time to
do it.'

21. The Appellant showed Dr Cohen scars which were not recent and which were consistent with his
account of torture and ill-treatment. Dr Cohen said there had been no exaggeration or embellishment in the
account he gave her and there was no indication that this had been fabricated.

22. Dr Cohen diagnosed the Appellant as suffering from Post-Traumatic Stress Disorder ('PTSD') with
features of complex PTSD. He also had severe depression with and was developing symptoms of
psychosis.

23. Dr Cohen says,

'[61] He is at high risk of suicide. Even though he has not made an attempt to date he has multiple risk
factors including: severe mental health conditions, suffering command hallucinations to kill himself, selfharming, being in detention, past traumatic brain injury, being a victim of violence and abuse and suffering
profound fearfulness and hopelessness. His only protective factor appears to be his girlfriend with whom
he is able to make occasional contact.'

24. A little later in her report, Dr Cohen says this,

'[66] risk of suicide and impact of extradition: If [the Appellant] is extradited to the Czech Republic this
would in my opinion have a very serious impact on him. He has a fixed belief that he would be killed there,
that his traffickers would find him and punish him. This belief is a reflection of the experiences described


-----

and the mental health conditions he now suffers of severe and complex PTSD, severe depression and
psychotic symptoms. If returned, or of the belief that he is definitely going to be returned, he would suffer a
severe exacerbation of these conditions. He is already suffering from a high frequency and severity of
distressing symptoms and this would be increased. He is neglecting his self-care, eating little and not
attending to personal hygiene and this would also be exacerbated. In my opinion, because of this, return to
the Czech Republic would seriously diminish the possibility of his recovering from his mental health
conditions, especially if he is imprisoned there. Imprisonment would mean that the specialist therapy he
requires for his PTSD would not be effective, as for this therapy to be effective the person needs to be in a
supportive and stable environment which detention cannot provide. The Royal College of Psychiatrists'
Position Statement on detention details how detention exacerbates conditions including PTSD, psychosis
and depression and that therapy is not possible in the detained setting [citation].

[67] Of great concern is his risk of suicide, which I consider to be already high. Further stress, such as
extradition to the Czech Republic, could cause impulsive action which is difficult to predict and prevent.
Individuals suffering PTSD and depression can suffer from distorted thinking, for example due to delusional
beliefs and high levels of anxiety, and these may impact on their ability to weigh and balance information
given to them. Exacerbation of his conditions for the reasons discussed above would make this more likely
and make it more difficult to resist the impulse to commit suicide. His protective factor at present is his
contact with his girlfriend and losing this would severely escalate his risk of suicide. His mental health is
already so poor that I regard him as extremely vulnerable to impulsive action and further risk factors such
as loss of hope in a future, loss of hope for safety from further violence and abuse, increase in fear and
anxiety would all further impact his ability to resist suicidal impulses.'

25. The Respondents were shown a copy of Dr Cohen's report and asked a series of questions by the
CPS on 12th December 2019. The questions and answers (dated 6th January 2020) were as follows:

'1. Will the Czech authorities provide adequate medical treatment for the Requested Person if he is
extradited? If so, explain how.

Yes, after surrender to the Czech Republic, the RP will be placed into the custody where the Prison
Service will provide him with all the necessary health care and possible medication. With respect to the
health state of persons being in the custody and serving terms of imprisonment the Prison Service cooperates with external institutions (hospitals and other health care centres). Thus the health care for the
person being in the prison facilities is fully ensured because if appropriate medical care cannot be provided
by Prison Service, the imprisoned persons are provided with necessary healthcare and special medical
examination in specialized healthcare facilities.

2. What measures will the Czech authorities take to guard against any further deterioration the RP's
mental health following extradition?

See 1) and serving the term of imprisonment and custody the RP will be under surveillance of the Prison
Service. In case of any indication that his health state would get worse, he would undergo the necessary
medical examinations immediately based on which measures to secure that the RP's life and health will not
be endangered will be taken.

3. What measures will the Czech authorities take to guard against the risk of the RP committing suicide in
transit and following his extradition?

See 1) and 2) and in the custody the RP will not have access to any objects which could endanger his life
and health. During the transit to the Czech Republic the RP will be guarded by the members of the Prison
Service and the Police of the Czech Republic and so it is not possible that he would cause injury to himself.

4. Given the RP's status as a victim of modern slavery, is there any mechanism in Czech law that will
allow his sentence to be reconsidered, either in type (custodial vs non-custodial) or duration?

As already mentioned in the EAW immediately after surrendering the RP to the Czech Republic the final
judgment will be served on him. Since the up-to-now proceedings have been conducted against him as
against a fugitive, he will have the right to file a motion to cancel this final judgment within 8 days after


-----

serving the judgment. In this case the entire criminal proceedings will be conducted from the beginning,
including producing evidence. Therefore, it is possible that in the new proceedings with regards to the new
evidence a milder sentence will be imposed on the RP. Taking into account your medical report it is very
likely that in the possible new proceedings this court will have an expert opinion (psychiatric and
psychological) also so elaborated so that the RP's overall health state would be established as well as a
possible impact of the service of a term of imprisonment on his health state. In case an unconditional
sentence of imprisonment would be imposed on the RP also in the new proceedings and subsequently it
would be found out that he suffers from such mental disease that would exclude temporarily or
permanently, him serving the term of imprisonment, the Court would have to make a decision, upon the
RP's motion, on suspension of serving the term, interruption of serving the term or releasing him from
serving his term. Therefore, even if an unconditional sentence is imposed, the Czech legal order provides
the mechanisms that protect persons suffering from a serious mental disease prior to commencement of
service of the term of imprisonment which could even worsen their health state.

26. Dr Cohen was shown this further information from the Czech authorities. On 12th February 2020 she
responded,

'I do not consider these responses address my opinion that [the Appellant's] mental health is already very
seriously affected and highly likely to get much worse if he is extradited.

The letter proposes that he would be detained, have the possibility of a further medical assessment and
then legal proceedings. Given his medical condition when I assessed him, if he became significantly worse
I would be concerned for his fitness to undergo the legal proceedings.

What he needs is the appropriate treatment now, not at some unspecified point in the future when he is in
a worse condition, which in itself would make recovery take much longer and be less likely to restore him to
health. While assurances are given about protecting him from killing himself, we know that sadly such
measures cannot guarantee a person will not succeed as many suicides take place in detention.'

27. When Swift J. granted permission to appeal, he also directed that the Respondent had permission to
file and serve evidence by 22nd January 2020 regarding the facilities for medical care and/or treatment
likely to be available for the Appellant in the event of his extradition.

28. I also have a letter from Eliza Stachowska dated 1st October 2019 which provides further information
on the system for identifying victims of trafficking and other forms of **_modern slavery and, more_**
particularly, further information on the experiences of Vietnamese nationals in this regard.

29. Swift J. also directed that the Respondent had permission to cross examine the Appellant (a) on the
question of whether he was a fugitive from justice and (b) any further evidence regarding facilities available
in the Czech Republic in the event of his extradition.

30. The Appellant's representative informed the Respondent that they would not be putting forward a
positive case regarding his fugitive status and accepted this point.. In those circumstances, the
Respondent sensibly advised the Appellant that he would not be needed for cross examination.

**Some preliminary matters**

i) The EAWs are both conviction warrants. Although the Appellant will have the right to be re-tried on
EAW1, both parties agreed that for my purposes, I must proceed on the basis that he has been convicted
of the offence in this EAW as well as of the offence in EAW2.

ii) The Appellant has been in custody on remand since his arrest on 14th March 2019. By the date of the
hearing before me, he had spent 337 days in custody. That period will be slightly longer by the time this
reserved judgment is handed down. By Article 26 of the Framework Decision (the EU measure under
which the EAW scheme now operates) the Czech Republic will be obliged to credit time on remand in the
UK against the remaining sentences to be served in the Czech Republic. As I have said, only 187 days
remains to be served of the sentence in EAW2 which means that about 150 days remains to be deducted
from any sentence for EAW1 (I say 'any sentence' because, if the Appellant opts to be re-tried, he may be
itt d f th t ff if i t d h b t d i diff t t h t t th 2


-----

years for the offence in EAW1). Both counsel agreed, however, that it would be for the Czech Republic to
decide how, consistently with Article 26, the time on remand in the UK was to be credited against his
sentences and against which sentence.

iii) I must proceed on the basis that the Appellant has been convicted of the offence in EAW2. His
comment that he was not aware of the nature of the contents of the package must either have been
disbelieved at his trial or not constituted a defence in Czech law.

iv) The Appellant's status in the UK remains undetermined. He has made an application for asylum, but
that has not yet (or not at the date of the hearing of this appeal) been determined by the Secretary of State
for the Home Department. So far as his position as a victim of trafficking is concerned, he has been told by
the Home Office that there are reasonable grounds to believe he is a victim of trafficking, but there has not
so far been a conclusive decision. That said, he has overcome the first stage of the NRM process (the
'reasonable grounds' stage) and his account accords with the experience of many other, especially
Vietnamese, victims of trafficking as Eliza Stachowska of the organisation, Hope for Justice, described in
her letter of 1st October 2019 and its accompanying attachments and, in the opinion of Dr Cohen, his
account is not exaggerated and fits with the scars she observed.

**The s.25 ground of appeal**

31.  Ms Iveson made clear that she relied exclusively on the 'oppression' limb of s.25. She did not, in other
words, argue that by reason of the Appellant's mental ill health it would be 'unjust' to extradite him to the
Czech Republic. I could well understand why she should confine the ground of appeal in that way. There
must be a presumption that the Czech Republic would have procedures in place to determine whether the
Appellant was unfit to be re-tried. That presumption could be rebutted, but there was no evidential basis for
me to conclude that the presumption was inappropriate or inapplicable in this case. Paragraph 2 of Dr
Cohen's letter of 12th February 2020 is not, therefore, of assistance.

32. Ms Iveson did, however, submit that the test of oppression was made out in this case.

33. She relied strongly on the report of Dr Cohen in support of the proposition that extradition would be
damaging to the Appellant's mental health. He suffered severe depression and severe and complex PTSD.
According to Dr Cohen, the Appellant's condition had apparently deteriorated in recent months. He needed
therapy to overcome the trauma he had suffered over many years. According to Dr Cohen, that therapy
could not take place in a custodial setting. The further information from the Respondents spoke of the
possibility of making use of specialized health services but these would still be likely to be in custodial
conditions. Furthermore, Ms Iveson observed, the further information had been provided by a Czech
judge. There was no medical evidence to set against Dr Cohen's report.

34. Furthermore, according to Dr Cohen, the Appellant was at high risk of suicide, a risk which would be
exacerbated by his return to a country where had suffered abuse in the past and feared that his traffickers
would still be able to hurt him. In her report Dr Cohen had spoken of the Appellant hearing voices telling
him to kill himself and the difficulty he would face in resisting those impulses. Extradition would also involve
separation from the protective factor of his girl-friend, Kim-Le. As Dr Cohen had said in her letter of 12th
February 2020, whatever measures the Czech authorities took to prevent suicide, could be overcome by
someone with sufficient determination.

35. In Wolkowicz v Polish Judicial Authority [2013] EWHC 102 (Admin) Sir John Thomas, President of the
Queen's Bench Division, commented at [8]

'In a recent suicide case, _Turner v Government of the USA [2012] EWHC 2426 (Admin) Aikens LJ_
[summarised the propositions which could be derived from these cases [on Extradition Act 2003 s.25 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y143-00000-00&context=1519360)
its equivalent for Part II territories viz. s.91] at [28]:

“(1) The Court has to form an overall judgment on the facts of the particular case.

(2) A high threshold has to be reached in order to satisfy a court that a requested person's physical or
mental condition is such that it would be unjust or oppressive to extradite him.


-----

(3) The court must assess the mental condition of the person threatened with extradition and determine if
it is linked to a risk of a suicide attempt if the extradition order were to be made. There has to be a
'substantial risk that [the appellant] will commit suicide'. The question is whether on the evidence the risk of
the appellant succeeding in committing suicide whatever steps are taken is sufficiently great to result in a
finding of oppression.

(4) The mental condition of the person must be such that it removes his capacity to resist the impulse to
commit suicide, otherwise it will not be his mental condition but his own voluntary act which puts him at risk
of dying and if that is the case there is no oppression in ordering extradition.

(5) On the evidence is the risk that the person will succeed in committing suicide whatever steps are
taken, sufficiently great to result in a finding of oppression?

(6) Are there appropriate arrangements in place in the prison system of the country to which extradition is
sought so that those authorities can cope properly with the person's mental condition and the risk of
suicide?

(7) There is a public interest in giving effect to treaty obligations and this is an important factor to have in
mind.”'

36. Having endorsed this 'succinct and useful summary', Sir John continued in the same case,

'[10] The key issue, as is apparent from propositions (3), (5) and (6), will in almost every case be the
measures that are in place to prevent any attempt at suicide by a requested person with a mental illness
being successful. As Mr Watson [counsel for the Respondent in that case] correctly submitted on behalf of
the respondent judicial authorities, it is helpful to examine the measures in relation to three stages:

i) First, the position while the requested person is being held in custody in the UK is clear. As Jackson LJ
observed in Mazurkiewicz at [45], a person does not escape a sentence of imprisonment in the UK simply
by pointing to the high risk of suicide. The court relies on the Executive branch to implement measures to
[care for the prisoner under the arrangements explained in R v Quazi [2010] EWCA Crim 2759, [2011] Crim](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:51J2-RTB1-F0JY-C4FY-00000-00&context=1519360)
LR 159.

ii) Second, when the requested person is being transferred to the requested state, arrangements are
made by the Serious Organised Crime Agency (SOCA – [now the National Crime Agency]) with the
authorities of the requesting state to ensure that during the transfer proper arrangements are in place to
prevent suicide in appropriate cases. As Collins J. helpfully mentioned in _Griffin at [52], steps would_
ordinarily be taken in such cases to ensure that no attempt is made at suicide and proper preventative
measures are in place. Medical records should be sent with the requested person and delivered to those
who will have custody during transfer and subsequent detention.

iii) Third, when the requested person is received by the requesting state in the custodial institution in which
he is to be held, it will ordinarily be presumed that the receiving state within the European Union will
discharge its responsibilities to prevent the requested person committing suicide, in the absence of strong
evidence to the contrary: see the authorities was set out at [3]-[7] of Krolick v Several Judicial Authorities of
_Poland [2012] EWHC 3157 and [10]-[11] of Rot. In the absence of evidence to the necessary standard that_
calls into question the ability of the receiving state to discharge its responsibilities or a specific matter that
gives cause for concern, it should not be necessary to require any assurance from requesting states within
the European Union. It will therefore ordinarily be sufficient to rely on the presumption.

It is therefore only in a very rare case that a requested person will be likely to establish that measures to
prevent a substantial risk of suicide will not be effective.

[11] Furthermore, it should not ordinarily be necessary at a hearing before the District Judge for him to be
referred to the facts of the other cases: Lord Reed in described them as merely illustrative in Howes. We
would repeat the observation made in Dewani at [73] in relation to s.25 and s.91 of the 2003 Act, that little
help is gained by reference to them.'

37. I make the following observations on the evidence before me:


-----

i) Ms Iveson is entitled to say that the Respondents have not adduced evidence in reply. In this sense, Dr
Cohen's evidence is unchallenged.

ii) Nonetheless, it is important to observe that the Appellant has not so far made any attempt to commit
suicide. This is in stark contrast to one of the cases on which Ms Iveson relied, _Jansons v Latvia_ _[2009]_
_EWHC 1845 (Admin), where the Appellant, on learning of the District Judge's order of extradition, had tried_
to hang himself in Wormwood Scrubs. He was saved by the action of prison staff, but the seriousness of
his attempt was shown by the fact that he then spent 10 days in intensive care.

iii) Dr Cohen attributes the Appellant's intention to commit suicide to a 'fixed belief that he would be killed
there, that his traffickers would find him and punish him.' There is not, though, in this case, an argument
advanced on the Appellant's behalf, that his extradition would be contrary to Article 3 of the ECHR
because, for instance, he had a well-founded fear of being killed or ill-treated by his traffickers or other nonstate agents. I assume that must be because there is not a case to be made that the Czech Republic
would be deficient in its duty to take reasonable steps to protect him against any such attacks.

iv) Dr Cohen says that the Appellant, in addition to his PTSD and depression is manifesting 'psychotic
symptoms' This appears to be a reference (see [56] of her report) to his auditory hallucinations, a voice
commanding him to kill himself. Dr Cohen, though, does not diagnose the Appellant, as yet, suffering
psychotic illness. Further, whatever commands the Appellant believes he is being given by these voices,
the absence of any suicide attempt to date shows that he has so far been able to resist them c.f. Turner at

[28(4)].

v) Looking at the three stages identified by Sir John Thomas in Wolkowicz [10]

a) During his time in detention in the UK, as Sir John said, the court relies on the Executive Branch to
implement measures to care for the prisoner.

b) During any transfer to the Czech Republic, arrangements are usually made between the British police
and the authorities of the requesting state to prevent suicide. The answer to question 3) in the Further
Information provided on 6th January 2020 shows that, in this case, the Czech authorities anticipate similar
arrangements being in place.

c) As Sir John Thomas said in his summary in Turner there is a presumption in the case of a European
Union Member State that, on arrival in the requesting state, proper measures will be taken (among other
things) to prevent the Appellant committing suicide. In this case, the presumption is reinforced by the
answers to questions 1, 2 and 3 in the Further Information of 6th January 2020. Ms Iveson commented that
this information came from a judge and not a doctor. I recognise that. I have already said that the
Respondents have not put in any medical evidence challenging Dr Cohen's report. But, as I understand it,
the purpose of that further information is to explain the institutional arrangements that exist in the Czech
Republic for detainees suffering mental illness. There is no reason to believe that the Judge who signed
the letter of 6th January 2020 was not an appropriate person to convey such information.

vi) Of course, preventative measures can never guarantee that an individual will not succeed in taking his
own life. As Dyson LJ said in J v Secretary of State for the Home Department [[2005] EWCA Civ 629, as
quoted in Jansons v Latvia [2009] EWHC 1845 (Admin) at [7] 'someone who is sufficiently determined to
do so can usually commit suicide'. That is not the issue as Sir Anthony May said in Jansons at [7]. What
matters is that at each stage all reasonable precautions would be taken to prevent a successful attempt at
suicide.

vii) I recognise that the risk of suicide is only part of the reason why Dr Cohen counsels against the
Appellant's extradition. She also clearly believes that, to recover from his earlier ordeals, the Appellant
needs to undergo specialist therapy. She also believes that such therapy cannot be delivered in a custodial
environment since 'the person needs to be in a supportive and stable environment which detention cannot
provide.'. She also says that detention 'exacerbates conditions including PTSD, psychosis and
depression'.


-----

viii) But in this regard, I note firstly that Dr Cohen has not diagnosed the Appellant as suffering from
psychosis (as opposed to showing signs of psychotic symptoms – the voices telling him to kill himself).
Furthermore, Dr Cohen does not say that, if extradited, the Appellant will suffer a severe and permanent
exacerbation of his mental health. Her role as a doctor is to consider what would be good or bad for his
health. My task under _[Extradition Act 2003 s.25 is to consider whether the impact on his mental health](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y143-00000-00&context=1519360)_
would be so severe as to constitute oppression. Dr Cohen said that the Appellant's condition had
deteriorated, but she saw him only once (on 21st October 2019). Her comment, therefore, did not derive
from her own observations.

ix) As Sir John Thomas said in Wolkowicz [8(2)], and again in Turner [8(2)] there is a high threshold to be
reached in order to show that extradition would be oppressive. In my judgment, the Appellant has not done
so.

**Article 8**

38. Ms Iveson described Article 8 as importing a broad discretion to take the Appellant's mental health
problems into account.

39. She contrasted his position following extradition with his position if he remained in the UK. Here, she
submitted he was within the NRM as a victim of trafficking and had received a 'reasonable grounds'
decision in his favour. If he was released, he would be entitled to help. He also had the support of his girlfriend, whom Dr Cohen had described as a strong protective factor. and had access to legal assistance. If
he was extradited, he would lose her support; the therapy which he needed could not be provided as long
as he was in custody. There was also the risk that he would succumb to the voices in his head and the
impulses to commit suicide.

40. The Appellant had served a substantial part of the sentence in the Czech Republic prior to his release
and therefore EAW2 refers only to the balance of 137 days. In the UK, his time on remand could potentially
count against all of the remainder and still leave a substantial 'credit' that would be available to set against
any punishment imposed on EAW1 (assuming that he was convicted). Thus, while these were not minor
offences, they had not gone unpunished.

41. She submitted that the Appellant's extradition would constitute a severe impingement on his mental
health such that, in combination with the other factors, extradition would be disproportionate.

42. In Celinski v Poland _[2014] EWHC 1274 (Admin) Sir John Thomas recommended that a balance sheet_
was drawn up, listing respectively the factors in favour of extradition and those against. Normally it is the
District judge who conducts that exercise, but in this case, since so much turns on evidence which was not
before the District Judge, I must do so.

43. There are the following factors against extradition in this case:

i) The Appellant arrived in the UK in May 2018. Prior to his arrest on the EAWs in March 2019, there is no
evidence that he had committed any offence while here (I disregard the reference to a possible road traffic
violation).

ii) He has a girlfriend here whom he has known for some months prior to his arrest. The report of Dr
Cohen speaks of her being an important protective factor. The apparent discrepancy between his
statement and hers as to how long they had known each other has now been resolved.

iii) Although the Home Office has yet to take a conclusive decision, it has taken the decision that there are
reasonable grounds to believe that he was a victim of trafficking. The account which he has given of his
experiences at the hands of his traffickers is of brutal treatment which was sustained over many years in
many different countries. On his account, the offences which he is alleged to have committed in the Czech
Republic were directly connected with him being the victim of trafficking. Dr Cohen's physical examination
of the Appellant has shown scars consistent with his account. His mental ill health would also not be
surprising in someone who has experienced the traumas he describes.

IMAGE NOT AVAILABLE


-----

iv) The Appellant has served about two thirds of the sentence on EAW2. He has also been in custody on remand
during the extradition proceedings. That period on remand must be credited against his sentence by the Czech
Republic if he is extradited. In total this means that he has spent more time in custody than the remainder of his
sentence on EAW2. He will have the right to be re-tried on EAW1 and, if he is acquitted of that offence, he will have
no more time to serve. If he is convicted, the further information of 6th January 2020 makes clear he must be resentenced and it cannot be assumed that his sentence will be in custody or for as long a period as 2 years.
Because of his time on remand in the UK, there will be a substantial period of 'credit' even after allowing for the
balance of the sentence outstanding on EAW2.

v) Dr Cohen's report shows that the Appellant is suffering from severe PTSD (with signs of complex
PTSD) and also severe depression. If he is extradited, in Dr Cohen's opinion (a) the therapy he needs to
undergo to recover from his ordeal cannot take place in detention and will therefore have to be postponed;
and (b) he will be at high risk of successfully committing suicide.

44. There are the following factors in favour of extradition:

i) The offences are serious. People trafficking is a serious matter as the Appellant, on his own account,
well knows. The supply of cannabis involved a considerable quantity (approximately 3 kilos). The
sentences of 2 years for EAW1 and 18 months for EAW2 show the seriousness with which the Czech
Republic regarded them.

ii) There has been no significant delay. The offence in EAW1 was committed in 2014. The offence in
EAW2 was committed in 2011, leading to a conviction in 2012.

iii) The Appellant has no dependents in the UK or any other caring responsibilities.

iv) The Appellant had lived in the UK for a relatively short time before his arrest and, even on the
reconciled account of their time together, he and his girlfriend had known each other for a relatively short
time.

v) There is a constant and important public interest in maintaining extradition arrangements. That is
particularly so when, as in this case, the Appellant came to the UK as a fugitive from justice.

vi) It is to be presumed that the Czech Republic will have sufficient medical facilities to address the
Appellant's mental health needs. That is now backed up by the Further Information of 6th January 2020.
Even if Dr Cohen is right and the Appellant cannot receive appropriate therapy while in custody, extradition
will mean that his necessary treatment is postponed. Dr Cohen does not suggest that the Appellant will
suffer severe and permanent exacerbation of his mental health if extradition takes place.

vii) It is also to be presumed that the Czech Republic will take all reasonable measures to prevent the
Appellant killing himself. That presumption, too, is now supported by the Further Information.

45. In my judgment, the Appellant's extradition would not be a disproportionate interference with his
private or family life and consequently there would not be a breach of Article 8 of the ECHR if he was to be
extradited. The exercise which I must conduct is not as Ms Iveson described, a broad discretionary one,
but a judgment as to whether the interference which extradition will have with his private life (and arguably
with his family life with his girlfriend) will be disproportionate.

46. As I have already said, while the Appellant will have the right to be re-tried on the offence in EAW1, I
must proceed on the basis that he currently stands convicted of both that offence and the offence in EAW2.
As Mr Joyes argued, these were both serious offences and attracted significant penalties. They are plainly
not examples of the type of offences which sometimes lead to the issue of an EAW where the offences
may border on the trivial.

47. There is, as has been said many times, a constant and important public interest in giving effect to
extradition arrangements, the more so where the requesting state maintains (without opposition from the
Appellant) that the Requested Person was a fugitive.

48. The exercise which I have to conduct for the purpose of deciding whether the interference with the
Appellant's Article 8 rights is disproportionate is different from deciding whether his extradition is barred by


-----

oppression, but many of the elements which I considered in that context are also relevant here. Thus, for
instance, for the purposes of Article 8, I am also entitled and obliged to apply the presumptions that the
Czech Republic will take reasonable steps to provide necessary medical facilities and will take all
reasonable steps to prevent the Appellant from committing suicide. In the Article 8 context as well, Mr
Joyes is entitled to submit that the presumptions are reinforced by the Further Information the Judicial
Authority of 6th January 2020.

**Conclusion**

49. I have found that neither ground of appeal is made out. Consequently, it follows that the appeal is
dismissed.

**End of Document**


-----

