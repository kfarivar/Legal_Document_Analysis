# SH v Waltham Forest London Borough Council [2019] EWHC 2160 (Admin)

Queen's Bench Division, Administrative Court (London)

Clive Sheldon QC (sitting as a deputy judge of the High Court)

6 August 2019Judgment

**Lindsay Johnson (instructed by Hopkin, Murray, Beskine) for the Claimant**

**Millie Polimac (instructed by LB Waltham Forest) for the Defendant**

Hearing date: 30 July 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Clive Sheldon QC:**

**Introduction**

1. SH applies for permission to challenge the Defendant London Borough of Waltham Forest's failure to
comply with the authority's duties under section 193 of the Housing Act 1996 (“the 1996 Act”), and the
failure of the local authority to permit SH entry to its housing allocation scheme. SH also applies for interim
relief. She seeks an order requiring the local authority to accommodate her pending the resolution of her
application for judicial review.

**Facts**

2. SH is a victim of trafficking for sexual exploitation. She is a 29-year-old lone parent of a seven-year-old
child. She travelled to the United Kingdom in 2012, and was granted refugee status in 2014 on the basis
that she was a victim of trafficking and modern slavery for sexual exploitation. She has been diagnosed
with post-traumatic stress disorder, for which she requires therapy. She also suffers from fibromyalgia,
polycystic ovaries, abdominal pain, anxiety and depression.

3. SH and her daughter live in accommodation provided by the Defendant which is in an area where there
is open prostitution, including sexual acts taking place in the garden and public spaces adjacent to the
property. In July 2018, the Defendant accepted that the accommodation was unsuitable for SH and
unreasonable for her and her daughter to continue to occupy. Consequently, she is homeless for the
purposes of Part 7 of the 1996 Act.

4. SH had previously applied to the Defendant as homeless in September 2014. The main housing duty
was accepted on 20th April 2015. She was provided with accommodation in Ilford on 14th May 2016, in a
privately rented property under an assured shorthold tenancy. She was served with notice to quit on that
property on 21st August 2017. SH says that when she was offered this property, she was told that it was
for one year. She says that she cannot remember getting a letter from the Defendant saying that if she
became homeless again within 2 years, she would be “fast forwarded” in any new application: that the full
homelessness duty would apply again.


-----

5. The Defendant says that it cannot locate a copy of the offer letter for the Ilford property, but screenshots
from its case management system and notepad entries show that the property was provided by “LWF”,
which stands for “Lettings Waltham Forest”. In a witness statement from Jonathan Joseph, the Defendant's
Head of Prevention and Assessment, it is stated that at the time when SH was offered the Ilford
accommodation the Defendant had two separate teams to procure and offer accommodation to homeless
people. The Temporary Accommodation Team looked for and offered temporary accommodation; LWF
sourced and offered private sector rented accommodation to discharge the s.193 duty. Mr. Joseph says
that “The two teams are entirely separate and there is no cross over between them”.

6. Mr. Joseph says that he has looked at the notes from SH's housing file and states that it is most likely
that SH was offered a 12 month Assured Shorthold Tenancy “because this is the type of accommodation
that LWF offer”. He refers to the notes which state that on 2nd May 2017 “LL served s.21(6A form) notice
to give vacant possession as he wants to sell”. Mr. Joseph says that “This also indicates that the offer
made in 2016 of the Ilford Accommodation was for a 12 month [Assured Shorthold Tenancy] and was
therefore a PRSO offer”. That is, a Private Rented Sector Offer. Mr. Joseph says that when an offer of
temporary accommodation is made, the relationship of occupation is between the applicant, the council
and the landlord providing the accommodation. With a PRSO however, the council drops out of the picture.

7. The computer records also state that “App was assisted by LWF to secure current accommodation in
May 2016. S193 was not discharged at the time”. In oral argument, Mr. Lindsay Johnson, who represents
SH, submitted that if SH had been offered a PRSO at the time, then this would have discharged the s.193
duty, and so this is an indication that she had not been offered a PRSO.

8. SH was rehoused by the Defendant in Tottenham on 27th August 2017. The offer letter stated that “If
you were to become homeless within two years of accepting this offer and make another application to us
or any other English Local Authority and you are at that time eligible for assistance and have not become
homeless intentionally a new duty to accommodation you will arise under section 193(2).” SH signed a
tenancy for the property on 31st August 2017. Mr. Johnson submits that this letter would not have been
sent to SH saying that she could make a further application if this was the second PRSO. Ms. Millie
Polimac, who represents the Defendant, argued against this, saying that was just a standard letter for a
PRSO, suggesting that it had simply not been adapted to reflect SH's particular circumstances.

9. SH experienced significant difficulties with the property in Tottenham from early on. She complained
about prostitution in the area, that drug use was rife, that people knock on her door at all hours of the day
and night, and that her daughter has been exposed to and witnessed these behaviours, including sexual
intercourse.

10. On 26th July 2018, the Refugee Council wrote to the Defendant on behalf of SH, making a reapplication for assistance under section 195A of the 1996 Act. It was contended that SH was still owed the
full housing duty under section 193(2) of the 1996 Act. The Refugee Council highlighted the effects that
the Tottenham property was having on SH and her daughter. It was said that they were “in danger” and
that the property posed a safeguarding risk to both of them and compromised their welfare”.

11. On 17th September 2018, the Defendant assessed SH's housing circumstances, and prepared a
Personalised Housing Plan for her. On 31st October 2018, the Defendant made an offer of accommodation
which was stated to be in discharge of the Defendant's “relief duty” under section 189B(2) of the 1996 Act.
The accommodation was in Kettering, and was under an assured shorthold tenancy with a private landlord
for a period of at least six months. On 1st November 2018, the Defendant wrote to explain that it did not
owe SH a housing duty under section 193(2) of the 1996 Act.

12. SH requested a review of the suitability of the Kettering offer. The review upheld the suitability of the
offer. The reviewer was satisfied that “the accommodation in Kettering was suitable for the purposes of
fulfilment of section 193(2) of the Housing Act 1996.” This decision was not appealed by SH.

13. In addition to her re-application for assistance, SH has also requested that she should be placed on
the Defendant's housing register. The Defendant stated, in response to a pre-action letter, that SH is not
“eligible to be placed on the Council's Housing Register, she was initially provided with a private rented


-----

sector offer” in the London Borough of Haringey (the Tottenham property), and “households living outside
of Waltham Forest are not eligible to join the Council's housing register”.

14. On 29th July 2019, very shortly before the oral hearing, Mr. Joseph wrote to SH to say that as she had
refused the offer of accommodation in Kettering which the Defendant considers to be suitable, “if any s.193
HA 1996 duty is found to exist we consider that it has ceased by virtue of s.193(5). . . This is without
prejudice to our primary position, which is that no s.193 duty is or was owed to you”.

**Decision**

15. SH has two grounds of challenge:

i) SH contends that the Defendant is unlawfully failing to comply with its housing duty under section 193 of
the 1996 Act: that her application in July 2018 was a re-application for the purposes of section 195A of the
1996 Act;

ii) SH contends that the Defendant has acted unlawfully in failing to permit her entry to its housing
allocation scheme.

16. It seems to me that both grounds of challenge are arguable, and permission to apply for judicial review
is granted in respect of both matters.

17. With respect to the housing allocation scheme, as a homeless person SH falls within one of the
categories of person entitled under statute to have a reasonable preference of an offer under the local
authority's allocation scheme: section 166A(3)(a) of the 1996 Act. In my judgment, it is arguable that the
Defendant's allocation scheme does not afford SH a reasonable preference, as she could only have a
preference if exceptional circumstances applied.

18. With respect to the section 193(2) duty, in my judgment there is an arguable case that the duty is still
owed to SH. Whether or not this duty is still owed to her turns on the status of the offer made to her of the
property in Ilford. If it was a PRSO, then the duty is no longer owed to her. If it was not, then (subject to an
argument made by Ms. Polimac which I deal with below), the duty would still be owed to her. The status of
the Ilford offer is a question of fact, and there is evidence going both ways. This evidence will need to be
evaluated by a judge at a substantive hearing.

19. There is evidence supporting SH's case. First, there is no written evidence to demonstrate that a
PRSO was made for the Ilford property, and SH has said she would have remembered it if she had been
sent such a letter. Second, the language in the Defendant's records might suggest that the offer of the
property in Ilford was not made on a PRSO basis. Third, the wording of the PRSO letter on the Tottenham
property is suggestive of an initial PRSO and not a second PRSO.

20.  On the other hand, there is the evidence from Mr. Joseph about the allocation of responsibilities
between the LWF team and the Defendant's Temporary Accommodation team. If the teams acted in
accordance with their normal arrangements, then the Ilford property would have been offered on a PRSO
basis. Second, SH remembers the offer of the Ilford property being for one year, which may sit more
closely with it being a PRSO.

21. At this stage, I consider that the evidence is finely balanced, but does not tilt in SH's favour. In my
judgment, therefore, I do not consider that SH has a strong prima facie case, which is the threshold that
must be met on an application for interim relief: see De Falco v. Crawley BC [1980] QB 460.

22. Ms. Polimac had argued that even if the Ilford offer was not a PRSO the Defendant's duty under
section 193(2) had been discharged because SH had refused the offer of suitable accommodation in
Kettering. Ms. Polimac relies on section 193(5) of the 1996 Act. This provides that:

The local housing authority shall cease to be subject to the duty under this section if—

(a) the applicant, having been informed by the authority of the possible consequence of refusal or
acceptance and of the right to request a review of the suitability of the accommodation, refuses an offer of
accommodation which the authority are satisfied is suitable for the applicant,


-----

(b) that offer of accommodation is not an offer of accommodation under Part 6 or a private rented sector
offer, and

(c) the authority notify the applicant that they regard themselves as ceasing to be subject to the duty under
this section

23. Ms. Polimac submits that following the letter from Mr. Joseph of 29th July 2019, these conditions have
all been satisfied with respect to the Kettering property. I am not persuaded, however, that this is a “knock
out” point for the Defendant. It seems to me, at least arguable, that section 193(5) does not apply to offers
of “relief” properties, which was what the Kettering property purported to be. There is a different statutory
regime for “relief” properties: section 193A of the 1996 Act. The Defendant's argument on this point will
need to be explored in more detail at the substantive hearing.

24. In these circumstances, therefore, I refuse the application for interim relief. I do acknowledge,
however, the importance of this matter being dealt with as soon as possible given the nature of the
property in Tottenham, and so will direct that the matter should be dealt with expeditiously.

**End of Document**


-----

