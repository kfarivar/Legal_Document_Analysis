# R v Cuthbertson [2020] EWCA Crim 1883

CA, CRIMINAL DIVISION

202001951 A4

Holroyde LJ, Wall J, HHJ Picton

Wednesday 16 December 2020

16/12/2020

1. LORD JUSTICE HOLROYDE: If an offender is convicted in a magistrates' court of a number of offences, and is
sentenced by the magistrates for some of those offences but committed to the Crown Court for sentence on one or
more of them, does section 161A of the _[Criminal Justice Act 2003 require both the magistrates' court and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
Crown Court to order him to pay a surcharge? We pose the question in that way because in this case the relevant
statutory provisions in force at the material time (and accordingly the provisions considered in this appeal) were
contained in section 161A and 161B of the _[Criminal Justice Act 2003. For offenders convicted on or after 1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
December 2020, those provisions have been repealed and replaced by sections 42 and 43 of the Sentencing Code.
So far as the issue which arises in this appeal is concerned, however, those new provisions are in materially the
same terms as those which they replaced.

2. The facts giving rise to the appeal can be very briefly stated. The appellant is now 50 years old. He has a
number of previous convictions, including for offences of violence and motoring offences. At the material time he
did not hold a driving licence. In the early hours of 3 March 2020, after drinking alcohol and in the presence of
children, he attacked his then partner with punches and kicks, and tried to bite her. He then drove away from the
scene. He was stopped by the police. At the roadside, and again at the police station, he refused to provide a
specimen of breath. When interviewed under caution he made no comment.

3. He was charged with three offences: assault occasioning actual bodily harm, contrary to section 47 of the
_[Offences Against the Person Act 1861; driving a motor vehicle otherwise than in accordance with a licence,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)_
contrary to section 87 of the _[Road Traffic Act 1988; and failing to provide a specimen for analysis, contrary to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0SB-00000-00&context=1519360)_
[section 7(6) of the Road Traffic Act 1988.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0SB-00000-00&context=1519360)

4. On 4 March 2020 the appellant pleaded guilty to the Road Traffic Act offences before a magistrates' court. He
also indicated a guilty plea to the ABH offence but put forward a basis of plea which the prosecution did not accept.

5. The magistrates proceeded to sentence forthwith for the Road Traffic Act offences. For the offence of failing to
provide a specimen for analysis, they imposed a sentence of 8 weeks' imprisonment suspended for 12 months and
ordered licence endorsement and disqualification from driving. They also ordered the appellant to pay a surcharge
of £122. They imposed no separate penalty for the driving licence offence, save for licence endorsement. They
[committed the appellant to the Crown Court for sentence on the ABH offence, pursuant to section 3 of the Powers](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1DG-00000-00&context=1519360)
_[of Criminal Courts (Sentencing) Act 2000,and remanded him in custody.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1DG-00000-00&context=1519360)_

6. The record of the magistrates' sentence in respect of the breath test offence includes the words "Urgent result:
domestic violence case". That is the only indication we have as to the possible reason why the magistrates dealt
with the matter as they did, rather than, as might have been expected, using their powers under section 6(2) of the
2000 Act to commit the appellant to the Crown Court to be dealt with also for the Road Traffic Act offences.


-----

7. On 30 June 2020 the appellant appeared before His Honour Judge Fletcher CBE in the Crown Court at Stoke on
Trent. He had by then abandoned the basis of plea which he had previously put forward. He was represented by
Ms Cyples, who also acts for him today. She submitted that it would be unfair to order the payment of a further
surcharge, because all matters should have been dealt with by the Crown Court. The judge expressed his
puzzlement at the decision of the magistrates to sentence for two of the offences rather than to commit all three for
sentence to the Crown Court. He acknowledged that if he were dealing with all matters, he would impose a single
surcharge, namely that appropriate to the ABH, which was the most serious of the offences. He accepted that it
seemed rather unfair that the appellant should have to pay both the surcharge ordered by the magistrates and a
further surcharge. But, he said, the legislation was clear and required him to order the payment of a surcharge.

8. In those circumstances the judge imposed a sentence of 8 months' imprisonment, made a restraining order for 5
years, and ordered the appellant to pay a surcharge of £149.

9. In this appeal, brought by leave of the single judge, no challenge is made to any aspect of the sentencing other
than the order for payment of a surcharge.

10. Section 161A of the 2003 Act provides:

"161A Court's duty to order payment of surcharge

(1) A court when dealing with a person for one or more offences must also (subject to subsections (2) and (3))
order him to pay a surcharge.

(2) Subsection (1) does not apply in such cases as may be prescribed by an order made by the Secretary of State.

(3) Where a court dealing with an offender considers —‑

(a) that it would be appropriate to make one or more of a compensation order, an unlawful profit order and a
slavery and trafficking reparation order, but

(b) that he has insufficient means to pay both the surcharge and appropriate amounts under such of those orders
as it would be appropriate to make, the court must reduce the surcharge accordingly (if necessary, to nil).

(4) For the purposes of this section a court does not 'deal with' a person if it—‑

(a) discharges him absolutely, or

[(b) makes an order under the Mental Health Act 1983 in respect of him.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0F8-00000-00&context=1519360)

(c) In this section—‑

(d) 'slavery and trafficking reparation order' means an order under section 8 of the Modern Slavery Act 2015, and

(e) 'unlawful profit order' means an unlawful profit order under section 4 of the Prevention of Social Housing Fraud
Act 2013."

11. We have set out the section in full in order to show that it imposes on courts a general duty to order payment of
a surcharge, and makes specific provision for certain limited exceptions to that duty. It is unnecessary to examine
the scope of those exceptions, because it is common ground that none of them is applicable in the circumstances of
this case.

12. Section 161B provides:

(a) "161B Amount of surcharge

(1) The surcharge payable under section 161A is such amount as the Secretary of State may specify by order.


-----

(2) An order under this section may provide for the amount to depend on—‑

(a) the offence or offences committed

(b) how the offender is otherwise dealt with (including, where the offender is fined, the amount of the fine)

(c) the age of the offender.

(b) This is not to be read as limiting section 330(3) (power to make different provision for different purposes etc)."

13. At the material time, the amounts payable under section 161A were specified in Schedule 1 to the Criminal
Justice Act 2003 (Surcharge) (Amendment) Order 2019 _[SI 2019/985. For a suspended sentence for a period of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8VPK-GF92-D6MY-P3WR-00000-00&context=1519360)_
imprisonment not exceeding 6 months, the appropriate amount was £122. For a sentence of imprisonment of more
than 6 months but not exceeding 2 years, the appropriate amount was £149. Thus the orders made by the
magistrates and by the judge were correct in amount.

14. Ms Cyples submits that Parliament intended that offences dealt with as part of a single set of proceedings
should attract a single surcharge, and that an offender should not be exposed to a double surcharge simply
because a magistrates' court decides that its sentencing powers are insufficient in relation to one of the offences
but not others. If the magistrates here were in error in not using their powers under section 6(2) of the 2000 Act, the
appellant should not be prejudiced by that error. An offender who had committed more serious offences, such that
the magistrates' sentencing powers were not sufficient for any of them, would be committed for sentence on all
matters and face a single surcharge in the Crown Court. Ms Cyples submits that it is a perverse and unintended
result if a less serious offender is exposed to a double surcharge. She submits that this is a matter of fairness
towards an offender who has pleaded guilty to all the offences on a single occasion.

15. For the respondent, Mr Longworth submits that there were here two sets of proceedings. In one, the
magistrates dealt with the Road Traffic Act offences and were required to impose the appropriate surcharge as they
did. In the other, the Crown Court dealt with the ABH offence and was required to impose the surcharge as the
judge did. Mr Longworth refers to the principle that when a court is dealing with an offender for more than one
offence, the appropriate surcharge is that which applies to the most severe sentence. He submits that if the
appellant's argument were to prevail, the result would be that the appellant was only ordered to pay the surcharge
of £122 for the less serious offences and would escape the higher surcharge for the most serious offence. He
submits that the language of the statute is clear. He points out that in the circumstances of this case, if the
magistrates had committed all matters to be sentenced in the Crown Court, the appellant might well have found that
a short sentence of immediate imprisonment was imposed for the breath test offence and was ordered to run
consecutively to the sentence for the ABH offence. Thus, he suggests, the course taken by the magistrates, though
criticised by the appellant in one respect, may have worked to his advantage in another.

16. Both counsel have referred to Abbott [2020] EWCA Crim 516, in which a constitution of this court headed by
the Vice President of the Court of Appeal, Criminal Division, Fulford LJ, gave comprehensive guidance as to how a
sentencer should calculate the appropriate surcharge in a number of situations which had given rise to difficulties.

At paragraphs 47‑51 Fulford LJ referred to the framework created by section 161A and by the various orders made

pursuant to that section and section 161B. In relation to cases in which an offender was liable to have a suspended
sentence activated or was in breach of a community order, he said at paragraph 82:

(a) "We consider, therefore, that the duty to impose a surcharge under section 161A of the 2003 Act is discharged
when the court first sentences the offender. Section 161A contains no duty or power to order an offender to pay a
second surcharge and, accordingly, the provision is not engaged for a second time when the court 'deals with' an
offender on a second or subsequent occasion. It follows that when the court makes an order activating a
suspended sentence of imprisonment, or taking action upon breach of a community or other order, and at the same
time sentences an offender for new offences, the surcharge should be calculated only by reference to the new
offences."


-----

17. That case, however, was not concerned with circumstances such as arise in this appeal. It is common ground
that neither Abbott nor any other case provides guidance as to the specific issue raised here. It is perhaps
surprising that the point has not previously arisen for decision. The explanation may well lie in the judicious use by
magistrates of their powers under section 6 of the 2000 Act.

18. Ms Cyples does seek to rely on Abbott to this extent, that she suggests a broad analogy between the payment
of a second surcharge in the circumstances referred to by Fulford LJ at paragraph 82, and the order made by the
judge in this case.

19. We are unable to accept that any such analogy can be drawn. In our judgment section 161A plainly did require
the judge to impose a second surcharge. There was no basis on which he could decline to do so. As we have
indicated, the section creates a general duty, which applies whenever a court is dealing with an offender for one or
more offences and which is subject to only limited and specific exceptions. If, as in this case, none of those
exceptions applies, then a court dealing with an offender for one or more offences must order him to pay a
surcharge. If a magistrates' court deals with the offender for some but not all of the offences, by sentencing for
some of the offences, it must order the offender to pay the appropriate surcharge. If one or more offences are
committed for sentence to the Crown Court, then the judge dealing with the offender in the Crown Court by
sentencing him for that offence or those offences must order him to pay the appropriate surcharge, even though
one has already been ordered by the court below in respect of the other offences. We understand why Ms Cyples
seeks to invoke broad considerations of fairness, but the short and conclusive answer to her submissions is that the
wording of the statute is clear and does not permit an exception based on such considerations. It is therefore
irrelevant to the application of section 161A to consider whether the magistrates could or should have dealt with all
offences themselves, or could or should have committed all offences to the Crown Court. It is also irrelevant to
consider whether the various offences all arose out of a single incident or a number of separate incidents, or
whether they might arguably be regarded as "a single set of proceedings".

20. The judge was accordingly correct to order the appellant to pay a surcharge in respect of the ABH offence for
which he dealt with the appellant, and this appeal must be dismissed.

21. Magistrates and advocates will no doubt be alive to the practical implications of this judgment. The prospect
that the offender will have to pay a further surcharge, if dealt with for some offences in the magistrates' court but for
other offences in the Crown Court, will be a relevant factor in the magistrates' decision as to how they exercise their

powers of committal for sentence. The weight to be given to that factor in a particular case will be a facts‑specific

decision for the magistrates.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

