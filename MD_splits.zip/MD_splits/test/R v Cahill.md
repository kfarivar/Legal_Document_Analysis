# R v Cahill [2024] EWCA Crim 756

Court of Appeal, Criminal Division

Lord Justice MacUr, Mrs Justice Cockerill, Mrs Justice Tipples

21 June 2024Judgment

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

MR M McALINDEN appeared on behalf of the Applicant.

_________

**J U D G M E N T**

**MRS JUSTICE COCKERILL:**

1. On 20 December 2023, in the Crown Court at Lewes before Mr Recorder Nicholson‑Pratt, the applicant was

sentenced in respect of the following offences to which he had pleaded guilty.

a. The lead offence was Count 8, being concerned in the production of a Class B drug (Cannabis), contrary to
section 4(2)(b) of the Misuse of Drugs Act 1971, 44 months' imprisonment;

b. Count 2, burglary (non‑dwelling), contrary to section 9(1)(b) of the Theft Act, 15 months' imprisonment

consecutive,

c. Attempted burglary (count 3) and burglary Count 4, no separate penalty.

d. Count 5, burglary (non‑dwelling), contrary to section 9(1)(b) of the Theft Act, 15 months' imprisonment

concurrent;

e. Count 6, attempted theft, contrary to section 1(1) of the Criminal Attempts Act 1981, 6 months' imprisonment
concurrent;

f. Count 7, damaging property, no separate penalty; Count 10, assault occasioning actual bodily harm, contrary to
section 47 of the Offences Against the Persons Act 1861, 21 months' imprisonment consecutive.


-----

g. Counts 11 and 12, assault by beating, contrary to section 39 of the Criminal Justice Act 1988, no separate
penalty.

2. The total sentence imposed was therefore 80 months for three sets of offences as the Learned Recorder

described them ‑ 15 months for the first set, 44 months for the second and 21 months for the third set of offences.

3. No evidence was offered against the applicant on Count 1, holding a person in slavery or servitude and a not
guilty verdict was entered, pursuant to section 17 of the Criminal Justice Act 1967. In relation to Count 9,
possession of a prohibited weapon was ordered to lie on the file against him in the usual terms.

**THE FACTS**

4. The facts for the respective offences can be summarised thus:

**Count 2**

5. On 30 January 2023, a branch of the Co‑Op in Petworth was broken into at around 04:30am. The front door was

forced open and cigarettes were stolen. Staff arriving later that morning found that the door had been forced open.
The metal lock was in pieces on the floor and baskets had been knocked over. The Perspex screen by the counter
had been smashed and the cigarette holder was damaged. CCTV footage showed the applicant and another male
forcing open the door of the store with a crowbar and loading up a bedsheet with cigarettes.

**Count 3**

6. On 31 January 2023, the applicant and another male used an angle grinder to attempt to force access to a
branch of Sainsbury's in Pulborough at around 03:30am. They failed to gain access, they then attempted to kick the
door in but were unable to do so and left without stealing anything..

**Counts 4 & 5**

7. On 6 March 2023, the Co‑op in Petworth was targeted again just after 04:00am. On this occasion the applicant

and another male unsuccessfully attempted to access the ATM using an oxy‑acetylene torch, causing damage.

CCTV footage showed a dark coloured vehicle outside the store. The applicant and another male wearing face
coverings and quilted gilets forcing entry to the store and attempting to break into the tobacco area unsuccessfully.

**Counts 6 & 7**

8. On 15 March 2023 at 05:05am, the police received a number of reports that people were attempting to steal or

rip out a Cash Zone ATM, which was a self‑standing unit, outside a parade of shops in Horsham. No cash was

stolen but metal cassettes containing various paperwork and other ATM material was stolen from the unit, which
was left on the road. Around £5,000 of damage was caused to the machine, which contained around £12,000 in
cash.

**Count 8**

9. On the evening of 9 June 2023, police officers carried a warrant at Slifehurst Wood Farm in West Sussex. That
is a rural smallholding which contains a large barn and an old caravan. It had been leased to males including
someone called “Reece” or “Ryan” about 2 years before. Officers found a substantial cannabis production site with
multiple cannabis plants in various stages of growth and associate growing equipment. Inside the caravan they
found a large amount of herbal cannabis bud. There was only one male present in the caravan, the complainant
(Earl Harris), who was visibly in a poor state and living in squalid conditions.

10. There was a drugs expert's report of three grow rooms. In grow room 1, 37 plants estimated to be 100
centimetres tall nearing maturity; grow room 2, 28 plants, estimated to be 100 centimetres tall nearing maturity;
grow room 3 30 plants again 100 centimetres tall nearing maturity Also contained in grow room 3 were 270 young


-----

plants. The expert stated it would be realistic to expect 243 of these plants to yield female flowering head. A total
yield would have ranged been 9 and 28 kilograms. The price for a kilogram at the time of the offence ranged from
£3,500 to £6,000. Therefore, it is estimated that the production could have achieved between £31,500 and
£168,000 value.

**Counts 10 to 12**

11. The complainant Earl Harris was interviewed and told officers that the applicant and others had mistreated him
in various ways, including threats to hurt his family, making him sleep in the dog kennel on the floor or in the mud,
throwing things at him, verbally abusing him, threatening to “cut him open”, dragging him through dog excrement,
kicking him in his stomach and groin area, knocking out his teeth, starving him, preventing him from going to a
family funeral, hitting him with cups, strangling him until he nearly passed out and beat him to a level where the
complainant thought he had sustained broken ribs as he could not cough. He also said that he was “clumped” to the
face and head while he was in a car. He said he had attempted to escape on numerous occasions which led to
violence being inflicted on him. He said he once attempted to escape by jumping from a moving van. He said he
had remembered being in a corner and being stamped on, kicked, beaten, punched and strangled, beaten with
inanimate objects and not given clean clothes after being dragged through dog excrement and that he had been
given no provisions for personal hygiene. He said he was kicked to the groin and stomach which caused him to
vomit and that he struggled to use the toilet following some of this abuse. He said that he had tended to the
cannabis grow and was held responsible if things did not go well.

**APPLICATION FOR LEAVE TO APPEAL**

12. The Applicant renews his application for leave to appeal following refusal by the single judge. We are most
grateful for the clear and focused submissions of Mr McAlinden, who appeared before and, following refusal,
appears pro bono.

13. The grounds advanced are;

a. The starting point taken on Count 8 was too high and the sentence of 44 months was manifestly excessive. If the
Learned Recorder intended to run this “lead” sentence consecutive to Sets 1 and 3, he should have reduced the
starting point to take into account totality. A starting point of 4 years should have been taken with the sentence then
reduced to 36 months giving the appropriate credit. Set 1 should have been reduced to 12 months and Set 3 should
have been reduced to 15, making a total sentence of 63 months;

b. Secondly, it is said the principle of totality was not sufficiently taken into account and overall, the total sentence
of 80 months was manifestly excessive.

14. Before us this morning Mr McAlinden, in his focused submissions, emphasised in particular the respects in
which he parted company with the single judge. He submitted that the judge's reliance on the conduct in relation to
Mr Harris was inappropriate, as that was reflected in the later counts and that therefore amounted to double
counting and the modern slavery count had been allowed to creep back in although that was allowed to lie on the
file. He submitted that the account of the heavily convicted Mr Harris was never accepted on behalf of Mr Cahill but
had effectively driven the reasoning. He submitted that Mr Cahill did not properly have a leading role and that all of
these factors led to a manifestly excessive sentence on this count. It was also submitted that the overall sentence,
standing back and looking at the groups of convictions, was manifestly excessive at 80 months.

**DISCUSSION**

15. Clear and cogent reasons were given by the single judge, which will have been served on the applicant, and
are not repeated here. We have, of course, read the material provided to us, we have given independent
consideration to the renewed application and to the submissions both in writing and orally. But we agree with the
single judge that it is not arguable that the sentence imposed was manifestly excessive.


-----

16. Firstly, we do not agree that the starting point on count 8 was too high. It may be right that this offence has only
some “leading” features, but there are enough that the judge could legitimately say that the category was borderline
leading/significant. The original starting point was taken at 60 months (misheard by the transcriber as 16) - that is
the top of significant role. It cannot be said that the further uplift to reflect the significant role factors and what was,
on any analysis, supervision if not exploitation of Mr Harris, entirely separate to the counts which were pursued,

was a decision which was not properly open to the judge. Therefore, we consider that the 72‑month figure was

entirely justifiable, albeit that some other judges might well have reached a lower figure.

17. The discount then applied explicitly allows both for mitigation and totality and, while the mitigation was not
insignificant, the deduction overall was one which was fairly generous. It produces, in our judgment, a result,
balancing one against the other, which is not even particularly stern.

18. As for the argument that the totality should have been reflected in reductions to all of the “sets”, this is not
arguable. As is well understood, the purpose of totality is not to give any fixed percentage reduction in any
mandated way but to enable the judge to fairly reflect the totality of the offending behaviour. Here there was a very
considerable amount of offending behaviour, so much so that the sentencing judge had to sensibly group the
offences in “sets”. Each of those sets had some serious features. Although others were involved, the applicant
played a full part. Overall, it was behaviour reflecting a serious consistent pattern of law breaking. Allowance made
for totality in relation to the leading count. We find it not remotely arguable that the sentence imposed overall was
manifestly excessive for the totality of that offending behaviour.

19. Accordingly, this renewed application for leave is dismissed.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 46 Chancery Lane, London WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

