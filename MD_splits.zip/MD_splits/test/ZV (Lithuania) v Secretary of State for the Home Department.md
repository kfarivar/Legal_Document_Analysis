# ZV (Lithuania) v Secretary of State for the Home Department [2021] EWCA
 Civ 1196

Court of Appeal, Civil Division

Underhill VP, Moylan and Dingemans LJJ

30 July 2021Judgment

**Ms Samantha Knights QC and Ms Zoe McCallum (instructed by Duncan Lewis) for the Appellant**

**Mr Tom Brown (instructed by the Treasury Solicitor) for the Respondent**

Hearing date: 4th March 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Underhill :**

**INTRODUCTION**

1. In order to explain the issues on this appeal it is necessary first that I summarise the factual and
procedural history, but it is not necessary that I do so in any detail.

2. The Appellant is a Lithuanian national born on 8 July 1984. She is an established victim of trafficking1.
She was trafficked to this country in late 2009 by a man with whom she had been living to whom I will refer
as DE. Over the next six or so years she was under his close control and was forced to act as a prostitute.
She was frequently beaten by him and he encouraged her addiction to heroin. At his instigation she
regularly engaged in shoplifting: she was convicted on nine occasions and had short terms of
imprisonment. In 2012 she briefly escaped to Lithuania while DE was in prison, but she was found by his
associates and after being abducted and raped she was brought back by them to this country.

3. In early 2017 DE was deported to Lithuania and the Appellant became free from his direct control.
However, in April of that year she was convicted of possession of cannabis and a previous two-month
sentence of imprisonment was activated, which she served at HMP Bronzefield. On 20 June 2017 she
was served with notice of deportation on the basis that she was a persistent offender; and on the expiry of
her sentence on 23 June she was detained under Immigration Act powers. At first she remained at
Bronzefield but on 28 July she was transferred to Yarl's Wood.

4. Also on 28 July 2017 the Secretary of State made a deportation order. The Appellant has appealed
against that decision, but the hearing of the appeal has been deferred pending the outcome of the present
proceedings.

5. On the basis of disclosures made while the Appellant was in detention, on 8 August 2017 her case was
referred under the National Referral Mechanism (“the NRM”), which is the UK machinery for identifying and
supporting victims of **_modern slavery. On 4 October a unit within the Home Office acting as the_**
“Competent Authority” decided that there were reasonable grounds to believe that she was a victim of
trafficking, and thus that she was, in the jargon, a “potential” victim of trafficking. The effect of that decision
was that she became entitled under the NRM to a 45 day “recovery and reflection period” During that


-----

period she could not be removed from the UK, and she was also entitled to various forms of support. The
reasonable grounds decision should have led to her early release from detention, but that did not occur.

6. In the meantime, the Appellant had made an application for asylum on the basis that if she were
returned to Lithuania she would be at risk of persecution by DE. By letter dated 26 September 2017 the
Home Office informed her that her asylum claim was “inadmissible” under paragraphs 326E and 326F of
the Immigration Rules and would not be substantively considered, because as a member state of the EU
Lithuania was regarded as a safe country of return. I will refer to that as “the inadmissibility decision”.

7. On 30 October 2017 the Appellant commenced judicial review proceedings against the Secretary of
State seeking relief under a number of heads. At this stage it is sufficient to say that among other things
she claimed (a) that her continuing detention was unlawful; (b) that she was being denied proper support
as a potential victim of trafficking; and (c) that the inadmissibility decision was unlawful. On 27 November
Yip J granted her permission to apply for judicial review and ordered that she be released within three days
and provided with a package of support. She was duly released on 30 November.

8. The Appellant's claim was heard by Garnham J in Birmingham on 2 and 3 July 2018. Only a few days
before the hearing the Competent Authority made a “conclusive grounds” decision accepting that she is a
victim of trafficking. Partly for that reason, and partly also because of developments in the case-law which
required further submissions, Garnham J did not hand down judgment until 18 October. He had to
consider five grounds of challenge, but we are only concerned with two aspects of his decision, which I can
summarise as follows:

(1) He rejected the Appellant's challenge to the inadmissibility decision.

(2) He rejected her claim that the provision of appropriate support had been both unlawfully delayed and
inadequate.

I should, however, note that he held that the Appellant had been unlawfully detained for a period of 45
days, including the period between 23 October and 30 November 2017.

9. The Appellant sought permission to appeal on four grounds. On 6 November 2019 Irwin LJ refused
permission on grounds 2 and 3 but granted it as regards the dismissal of her challenge to the
inadmissibility decision (ground 1). As for ground 4, which challenged the decision that there had been no
breach of the support duty during the period that she was detained, he ordered that the application for
permission be adjourned to the hearing of the appeal, on the basis that if permission were granted it would
be determined at the same hearing.

10. The Appellant was represented by Ms Samantha Knights QC and Ms Zoe McCallum, and the
Secretary of State by Mr Tom Brown of counsel. The case was well argued on both sides.

11. The Appellant is entitled to anonymity pursuant to section 1 of the Sexual Offences (Amendment) Act
1992.

**GROUND 1: THE INADMISSIBILITY DECISION**

12. I should emphasise by way of preliminary that the Appellant's challenge is concerned specifically and
only with the refusal of the Secretary of State to admit her asylum claim, and the issues which it raises are
limited to the lawfulness of that decision. The Secretary of State accepts that even if the appeal is
dismissed that will not be determinative of the Appellant's appeal against the deportation order or of her
right to seek discretionary leave to remain as a victim of trafficking; and in either context she will be entitled
to raise issues about humanitarian protection, including under article 3 of the European Convention on
Human Rights (“the ECHR”).

THE BACKGROUND LAW

The Refugee Convention


-----

13. The starting-point must be the Refugee Convention 1951. The Convention takes effect in domestic
law by more than one route, but for present purposes I need only note that section 2 of the Asylum and
Immigration Appeals Act 1993 (which is headed “Primacy of Convention”) reads:

“Nothing in the immigration rules … shall lay down any practice which would be contrary to the
Convention.”

Likewise, in _M v Ministervo Vnitra_ _C-391/16 the Grand Chamber of the Court of Justice of the European_
Union (“the CJEU”) confirmed that the provisions of the Convention constitute primary EU law. The
Refugee Convention also underlies _Directive 2011/95/EU,_ the so-called “Qualification Directive”, which
prescribes how member states must decide applications for asylum. (I refer to the Directive for
completeness, but it does not in fact apply to the present case, because it only applies to claims for asylum
by non-EU nationals.)

14. I need not set out the detailed provisions of the Refugee Convention. It is sufficient to say that it
prohibits the return of a person to a country where they have a well-founded fear of persecution. A country
where there is no risk of persecution is referred to in the jurisprudence as a safe country of origin.

15. It is established as a matter of both domestic and EU law that the concept of “persecution” covers not
only persecution by the state from which the putative refugee has fled but also persecution by non-state
actors where the state authorities are unable or unwilling to provide protection against the ill-treatment
which they fear: see Horvath v Secretary of State for the Home Department [2000] UKHL 37, [2001] 1 AC
489, (and article 6 (head (c)) of the Qualification Directive). The effect of that test is explained in the
majority opinion of Lord Hope in Horvath. One of the issues before the House was, as he puts it at p. 494
G-H:

“What is the test for determining whether there is sufficient protection against persecution in the person's
country of origin—is it sufficient, to meet the standard required by the Convention, that there is in that
country a system of criminal law which makes violent attacks by the persecutors punishable and a
reasonable willingness to enforce that law on the part of the law enforcement agencies? Or must the
protection by the state be such that it cannot be said that the person has a well-founded fear?”

As to that, he says at p. 500 F-H:

“[T]he answer … is to be found in the principle of surrogacy. The primary duty to provide the protection lies
with the home state. It is its duty to establish and to operate a system of protection against the persecution
of its own nationals. If that system is lacking the protection of the international community is available as a
substitute. But the application of the surrogacy principle rests upon the assumption that, just as the
substitute cannot achieve complete protection against isolated and random attacks, so also complete
protection against such attacks is not to be expected of the home state. The standard to be applied is
therefore not that which would eliminate all risk and would thus amount to a guarantee of protection in the
home state. Rather it is a practical standard, which takes proper account of the duty which the state owes
to all its own nationals.”

I will refer to that as the Horvath standard.

16. Further guidance about sufficiency of protection appears in the judgment of this Court in _R_
_(Bagdanavicius) v Secretary of State for the Home Department_ _[[2003] EWCA Civ 1605, [2004] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTX1-DYBP-N3FG-00000-00&context=1519360)_
1207. At para. 55 (2)-(6) of his judgment, with which Lord Woolf CJ and Arden LJ agreed, Auld LJ
summarised the applicable principles as follows:

“(2) An asylum seeker who claims to be in fear of persecution is entitled to asylum if he can show a wellfounded fear of persecution for a Refugee Convention reason and that there would be insufficiency of state
protection to meet it; Horvath.

(3) Fear of persecution is well-founded if there is a 'reasonable degree of likelihood' that it will materialise;
_R v. SSHD, ex p. Sivakumaran [1988] AC 956, per Lord Goff at 1000F-G;_


-----

(4) Sufficiency of state protection, whether from state agents or non-state actors, means a willingness and
ability on the part of the receiving state to provide through its legal system a reasonable level of protection
from ill-treatment of which the claimant for asylum has a well-founded fear; _Osman_ [Osman v United
_Kingdom (1998) 29 EHRR 245], Horvath, Dhima [R (Dhima) v Immigration Appeal Tribunal_ _[2002] EWHC_
_80 (Admin)]._

(5) The effectiveness of the system provided is to be judged normally by its systemic ability to deter and/or
to prevent the form of persecution of which there is a risk, not just punishment of it after the event; Horvath;
_[Banomova [Banomova v Secretary of State for the Home Department [2001] EWCA Civ 175], McPherson](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFR1-DYBP-P4TM-00000-00&context=1519360)_

[McPherson _v Secretary of State for the Home Department_ _[[2001] EWCA Civ 1955] and Kinuthia [Kinuthia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG41-DYBP-P0SP-00000-00&context=1519360)_
_v Secretary of State for the Home Department_ _[[2001] EWCA Civ 2100].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFV1-DYBP-P046-00000-00&context=1519360)_

(6)  Notwithstanding systemic sufficiency of state protection in the receiving state, a claimant may still
have a well-founded fear of persecution if he can show that its authorities know or ought to know of
circumstances particular to his case giving rise to his fear, but are unlikely to provide the additional
protection his particular circumstances reasonably require; Osman.”

17. Ms Knights drew our attention to a point made at para. 23 of the Guidelines published by the United
Nations High Commissioner for Refugees (“UNHCR”) in April 2006 on the application of the Refugee
Convention to victims of trafficking (“the UNHCR VoT Guidelines”) to the effect that if administrative
mechanisms are in place to provide protection to victims, but a particular victim is unable to gain access to
those mechanisms, it may be right to treat the state in question for Convention purposes as unable to
provide the necessary protection. Although UNHCR Guidelines are not binding, they should be accorded
considerable weight in interpreting the extent of Convention obligations (see para. 36 of the judgment of
Lady Hale and Lord Dyson MR in Al-Sirri v Secretary of State for the Home Department _[2012] UKSC 54,_

[2013] 1 AC 745), and I have no difficulty with the general proposition advanced by the UNHCR.

18. Finally, I should note, because it is relevant to a submission made by Ms Knights, that article 3 of the
Convention reads:

“The Contracting States shall apply the provisions of this Convention to refugees without discrimination as
to race, religion or country of origin.”

Protocol 24 to the Treaty on European Union (“the Spanish Protocol”)

19. Protocol 24 to (what is now) the Treaty on European Union (“the TEU”), introduced in 1997 by the
Treaty of Amsterdam, provides (in summary) that member states should be treated as “safe countries of
origin” and accordingly their nationals should not, subject to its detailed provisions, be granted asylum by
other member states. I should set it out in full (adding numbers to the recitals for ease of reference):

“THE HIGH CONTRACTING PARTIES,

[1] WHEREAS, in accordance with Article 6(1) of the Treaty on European Union, the Union recognises the
rights, freedoms and principles set out in the Charter of Fundamental Rights,

[2] WHEREAS pursuant to Article 6(3) of the Treaty on European Union, fundamental rights, as guaranteed
by the European Convention for the Protection of Human Rights and Fundamental Freedoms, constitute
part of the Union's law as general principles,

[3] WHEREAS the Court of Justice of the European Union has jurisdiction to ensure that in the
interpretation and application of Article 6, paragraphs (1) and (3) of the Treaty on European Union the law
is observed by the European Union,

[4] WHEREAS pursuant to Article 49 of the Treaty on European Union any European State, when applying
to become a Member of the Union, must respect the values set out in Article 2 of the Treaty on European
Union,

[5] BEARING IN MIND that Article 7 of the Treaty on European Union establishes a mechanism for the
suspension of certain rights in the event of a serious and persistent breach by a Member State of those
values


-----

[6] RECALLING that each national of a Member State, as a citizen of the Union, enjoys a special status
and protection which shall be guaranteed by the Member States in accordance with the provisions of Part
Two of the Treaty on the Functioning of the European Union,

[7] BEARING IN MIND that the Treaties establish an area without internal frontiers and grant every citizen
of the Union the right to move and reside freely within the territory of the Member States,

[8] WISHING to prevent the institution of asylum being resorted to for purposes alien to those for which it
is intended,

[9] WHEREAS this Protocol respects the finality and the objectives of the Geneva Convention of 28 July
1951 relating to the status of refugees,

HAVE AGREED UPON the following provisions, which shall be annexed to the Treaty on European Union
and to the Treaty on the Functioning of the European Union:

Sole Article

Given the level of protection of fundamental rights and freedoms by the Member States of the European
Union, Member States shall be regarded as constituting safe countries of origin in respect of each other for
all legal and practical purposes in relation to asylum matters. Accordingly, any application for asylum made
by a national of a Member State may be taken into consideration or declared admissible for processing by
another Member State only in the following cases:

(a)  if the Member State of which the applicant is a national proceeds after the entry into force of the
Treaty of Amsterdam, availing itself of the provisions of Article 15 of the European Convention for the
Protection of Human Rights and Fundamental Freedoms, to take measures derogating in its territory from
its obligations under that Convention;

(b)  if the procedure referred to Article 7(1) of the Treaty on European Union has been initiated and until
the Council, or, where appropriate, the European Council, takes a decision in respect thereof with regard to
the Member State of which the applicant is a national;

(c)  if the Council has adopted a decision in accordance with Article 7(1) of the Treaty on European Union
in respect of the Member State of which the applicant is a national or if the European Council has adopted
a decision in accordance with Article 7(2) of that Treaty in respect of the Member State of which the
applicant is a national;

(d) if a Member State should so decide unilaterally in respect of the application of a national of another
Member State; in that case the Council shall be immediately informed; the application shall be dealt with on
the basis of the presumption that it is manifestly unfounded without affecting in any way, whatever the
cases [sic] may be, the decision-making power of the Member State.”

20. I need to elucidate the references in conditions (b) and (c) to article 7 of the TEU. Paragraphs (1) and
(2) of article 7 read (so far as material):

“1.  On a reasoned proposal by one third of the Member States, by the European Parliament or by the
European Commission, the Council, acting by a majority of four fifths of its members after obtaining the
consent of the European Parliament, may determine that there is a clear risk of a serious breach by a
Member State of the values referred to in Article 2. Before making such a determination, the Council shall
hear the Member State in question and may address recommendations to it, acting in accordance with the
same procedure.

...

2. The European Council, acting by unanimity on a proposal by one third of the Member States or by the
Commission and after obtaining the consent of the European Parliament, may determine the existence of a
serious and persistent breach by a Member State of the values referred to in Article 2, after inviting the
Member State in question to submit its observations.”


-----

Paragraph (3) goes on to provide for the imposition of sanctions on a member state which is the subject of
a determination under paragraph (2).  The criterion common to both paragraph (1) and (2) is “a serious
breach by a Member State of the values referred to in Article 2”: in the case of paragraph (1) there must be
found to be a “clear risk” of such a breach, and in the case of paragraph (2) such a breach must be found
actually to exist and to be “persistent”. Article 2 reads:

“The Union is founded on the values of respect for human dignity, freedom, democracy, equality, the rule of
law and respect for human rights, including the rights of persons belonging to minorities. These values are
common to the Member States in a society in which pluralism, non-discrimination, tolerance, justice,
solidarity and equality between women and men prevail.”

21. Protocol 24 is generally referred to as “the Spanish Protocol” because it was added to the TEU at the
instance of the Kingdom of Spain, which was aggrieved at the French and Belgian authorities having
granted asylum to members of ETA. It is clear both from that context and from the opening words of the
sole article that its overall purpose is to require member states to decline to entertain applications for
asylum from nationals of other member states (“EU nationals”), on the basis that all EU states are
necessarily safe countries of origin in view of the level of protection of fundamental rights which they are
obliged to observe. However, the Protocol recognises that that rule cannot trump the obligations of
member states under the Refugee Convention and accordingly cannot be absolute. It thus permits
applications by EU nationals to be entertained where one of the four conditions specified at (a)-(d) is
satisfied. Conditions (a)-(c) concern situations where there has been a formal acknowledgment or finding
about the observance of fundamental rights in the country in question. Condition (d), which is what we are
concerned with in this case, is rather different in character, and I will return to it in due course.

22. We were also referred to Declaration 48 of the Conference which adopted the Treaty of Amsterdam.
This provides that Protocol 24 “does not prejudice the right of each Member State to take the
organisational measures it deems necessary to fulfil its obligations under [the Refugee Convention]”.  I am
not sure what the phrase “organisational measures” refers to. On the face of it, it would not appear to
relate to the substantive obligations imposed by the Protocol. But it is unnecessary to reach a concluded
view, since even if it is intended to confirm the primacy of member states' obligations under the Convention
that adds nothing to what is in any event clear from the Protocol itself.

23. The Conference also “took note” of a declaration by the Kingdom of Belgium that:

“In approving [Protocol 24] … in accordance with its obligations under the 1951 Geneva Convention and
the 1967 New York Protocol, it shall, in accordance with the provision set out in point (d) of the sole Article
of that Protocol, carry out an individual examination of any asylum request made by a national of another
Member State.”

Domestic Law

24. The Spanish Protocol was at the dates with which we are concerned directly applicable in this country
as primary EU law. But its terms are also reflected in paragraphs 326E and 326F of the Immigration Rules,
which form part of Part 11 (“Asylum”) and are headed “Inadmissibility of EU asylum applications”. They
read:

“326E. An EU asylum application will be declared inadmissible and will not be considered unless the
requirement in paragraph 326F is met.

326F. An EU asylum application will only be admissible if the applicant satisfies the Secretary of State that
there are exceptional circumstances which require the application to be admitted for full consideration.
Exceptional circumstances may include in particular:

(a)  the Member State of which the applicant is a national has derogated from the European Convention
on Human Rights in accordance with Article 15 of that Convention;

(b)  the procedure detailed in Article 7(1) of the Treaty on European Union has been initiated, and the
Council or, where appropriate, the European Council, has yet to make a decision as required in respect of
the Member State of which the applicant is a national; or


-----

(c)  the Council has adopted a decision in accordance with Article 7(1) of the Treaty on European Union in
respect of the Member State of which the applicant is a national, or the European Council has adopted a
decision in accordance with Article 7(2) of that Treaty in respect of the Member State of which the applicant
is a national.

Paragraph 326C defines “EU asylum application” as an application by

“… a national of a Member State of the European Union who either;

(a)  makes a request to be recognised a refugee under the Refugee Convention on the basis that it would
be contrary to the United Kingdom's obligations under the Refugee Convention for them to be removed
from or required to leave the United Kingdom, or

(b)  otherwise makes a request for international protection.”

25. It will be noted that there is no equivalent in paragraphs 326E-326F to condition (d) under the Spanish
Protocol, but that is no doubt intended to be covered by the general reference to “exceptional
circumstances” in the first sentence of paragraph 326F. The terminology of “exceptional circumstances” in
paragraph 326F is not very illuminating, but plainly the rule must be read so as to give effect to the
Protocol.

26. We were referred to section 5 of the Home Office Asylum Policy Instruction: EU/EEA Asylum Claims
(“the API”), which is headed “Declaring Asylum Claims Inadmissible”. Since the API cannot trump
paragraphs 326E-326F of the Immigration Rules, and still less the Spanish Protocol, I see no value in
summarising it in any detail. Section 5.1 says that a screening interview is not required in the case of an
inadmissible claim. Section 5.2 says that “the claim should be declared inadmissible as soon as it is
made”, but it is made clear that caseworkers must first consider whether any written information provided
discloses “exceptional circumstances” within the meaning of paragraph 326F. Section 5.5 explains what
constitute “exceptional circumstances”, paraphrasing the provisions of the Protocol in detail: it observes
that such circumstances are expected to apply in very few cases. Section 5.4 makes the point that asylum
claims from victims of trafficking who are EU nationals equally fall under those provisions. The API is not
in every respect perfectly worded, but no point is taken on its drafting as part of this appeal.2

THE SECRETARY OF STATE'S DECISION

27. On 18 July 2017, while she was in detention, the Appellant wrote a lengthy statement (referred to
before us as “the 18 July letter”) which was evidently intended for consideration by the authorities in
connection with her threatened deportation and/or her claim to be a victim of trafficking, though it is not
clear to whom it was initially given. Most of it is devoted to explaining how she had been treated by DE
and how she had suffered. But it includes statements that

“I'm really scared to be deported and to come back to the same place where I was for 10 years”;

and

“I'm really scared now again to come back to same life, because I couldn't take this again anymore. I don't
have no one to help me, or support, or to go to live within my country. And he is there, I know he is waiting
for me. That's what he does. That's what he was doing to me for nearly 10 years. ... Please don't give me
into his hands again.”

The letter also recounted the episode in 2012 when she was re-trafficked from Lithuania (see para. 2
above).

28. The letter of 18 July was not initially understood by the authorities to be intended as a claim for
asylum. But on 21 September 2017 the Appellant's solicitors, Duncan Lewis, wrote to the Home Office
requiring that it be treated as such.

29. On 26 September 2017, i.e. less than a week later, the Home Office replied to the effect that the
Appellant's claim for asylum was inadmissible under paragraph 326E. I need not quote the letter in full. It


-----

sets out the three heads of “exceptional circumstances” under paragraph 326F and notes that none of
them applies. Para. 4 reads:

“The information you have provided has been reviewed. However, it does not establish that you would be
at real risk of persecution or harm. Your national authorities are able and willing to provide a sufficiency of
protection and there are appropriate avenues of redress within the State institutions in your country.”

It is clear from that that the decision-maker had appreciated from the letter of 18 July that the application
was based on the Appellant's fear that if she were returned to Lithuania DE would attempt to resume his
control over her; but he or she proceeded on the basis, applying the API and in accordance with the
Spanish Protocol, that the Lithuanian authorities would be able and willing to afford her sufficient protection
against that happening.

THE APPELLANT'S CASE

30. Garnham J held that the Secretary of State was right in law to treat the Appellant's asylum claim as
inadmissible on the basis of the Spanish Protocol (as reflected in paragraphs 326E and 326F of the Rules).
Ms Knights formulated her challenge to that conclusion under four heads. Three of them depend directly
on an issue as to meaning and effect of the Protocol, as it affects the present case, and I propose to
consider that first, addressing Ms Knights' particular submissions in that context. I will return at the end to
the fourth point, which is based on a passage in the Home Office's _Victims of_ **_Modern Slavery –_**
_Competent Authority Guidance published in March 2016 (“the VMS Guidance”)._

THE CORRECT APPROACH TO CONDITION (d)

31. I note by way of preliminary that the Protocol proceeds on the basis that there will be two stages to the
treatment of an application for asylum made by an EU national, as follows:

(1) The first stage is the decision whether to “take [the application] into consideration” or “declare [it]
admissible for processing” (the two phrases evidently mean the same thing): that admissibility threshold is
only passed if one of conditions (a)-(d) is satisfied.

(2) The second stage is the substantive consideration of the application if admitted. In the case of
condition (d) (though not conditions (a)-(c)) the Protocol prescribes what should happen at that stage,
namely (i) that the member state in question should notify the Council [sc. of its decision to admit the claim]
and (ii) that the application should be “dealt with on the basis of the presumption that it is manifestly
unfounded”. At the risk of spelling out the obvious, the presumption referred to is evidently rebuttable.

32. The present case concerns the first stage: the Secretary of State's decision was that the Appellant's
claim did not meet the admissibility threshold. Since conditions (a)-(c) are not in play, that means that her
decision must be justified by reference to condition (d).  I consider first what is required for condition (d) to
be satisfied.

33. Condition (d) is expressed as applying where the state to which the application is made “so decide[s]
unilaterally”. If that phrase is read in isolation it could be construed as meaning that a member state has
an absolute discretion to admit an application by an EU national, with the result that the only constraint
imposed by the Protocol is the adverse presumption required at the second stage (and the requirement to
notify the Council). But that would be inconsistent with both the language and the evident purpose of the
Protocol as a whole. The second sentence of the sole article, which contains the principal operative words,
bites at the first stage: it prevents applications by EU nationals being “taken into consideration”, or
“admitted for processing”, unless one of the four conditions is satisfied. It would make no sense if one of
those conditions recognised an unconstrained right in a member state to admit such applications after all.
Accordingly, there must be some threshold test that the member state has to find to be satisfied before it
admits a claim by an EU national.

34. The nature of that threshold needs to reflect the intended overall effect of the Protocol as identified at
para. 21 above. That in my view necessarily means that a member state should not admit an asylum claim
by an EU national in reliance on condition (d) unless there are compelling reasons to believe that there is a
clear risk that they will be liable to persecution in the country of origin notwithstanding the level of


-----

protection of fundamental rights and freedoms to be expected in an EU member state. Any lower threshold
would mean that the primary purpose of the Protocol would be undermined.

35. That that is the right approach is in my view confirmed by reading condition (d) in the context of
conditions (a)-(c), and more particularly conditions (b) and (c). Those conditions are concerned, to
paraphrase, with situations where a formal process has raised a “clear risk” that the country of origin may
disregard fundamental rights: I take that phrase from condition (b), which is of its nature more easily
satisfied than condition (c)3. Given the formal nature of that process, plainly cogent evidence (typically of
some systemic default4) will be required to justify its initiation. I believe that the threshold for a decision
under condition (d) must be of the same character. That may in fact be implicit in the phrase “so decide”,
but the word “unilaterally” gives a less oblique indication: its force must be that the member state is doing
by itself what would otherwise be done by the relevant EU institutions. The express requirement that the
member state must inform the Council of its decision points in the same direction: it suggests that the
decision is of a similar character to a proposal under article 7 (1).

36. The test which I have articulated may not seem essentially different from that which would apply at the
second stage if the claim were admitted: see para. 31 (2) above. But I do not regard that as an anomaly.
It is unsurprising that the drafters of the Protocol wanted to spell out the height of the threshold that still had
to be satisfied where, exceptionally, a claim is admitted for consideration, but there will obviously be some
difference between the two stages. Evidence presented at the first stage which appears to show a clear
risk of the claimant being persecuted if returned to their country of origin may prove less cogent when
subjected to detailed consideration at the second stage.

37. In a case of the present kind, where what the claimant fears is persecution by non-state actors, the
effect of condition (d), as expounded above, is that there will have to be compelling reasons to believe that
there is a clear risk that the member state in question will be unable or unwilling to afford him or her the
level of protection required by the Refugee Convention, applying the Horvath standard.

38. Those conclusions essentially correspond to the reasoning of Garnham J at paras. 56-59 of his
judgment. Ms Knights submitted that his reasoning was wrong. Her essential submission was that the
effect of the opening words of condition (d) was to recognise that a member state has “a broad discretion”
to admit an application by an EU national, and that in order to exercise that discretion properly it is obliged
to carry out at least an initial inquiry into the validity of their claim, albeit one that might short of the full
consideration that would be required at the second stage. She submitted that that approach was
necessary in order to comply with the Refugee Convention, since it is well established that ordinarily
asylum claims require anxious scrutiny and individualised consideration: in that connection she referred us
both to well-established domestic case-law (Bugdaycay v Secretary of State for the Home Department

[1986] UKHL 3, [1987] AC 514, and Avci v Secretary of State for the Home Department _[[2002] EWCA Civ](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWJ1-DYBP-N46D-00000-00&context=1519360)_
_[977) and to the UNHCR VoT Guidelines at paras. 14 and 45. She pointed out that in the context of returns](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWJ1-DYBP-N46D-00000-00&context=1519360)_
under the Dublin regime the Grand Chamber of the CJEU had held in R (NS (Afghanistan) v Secretary of
_State for the Home Department (C-411/10), [2013] QB 102, that there could be no conclusive presumption_
that member states would in all circumstances observe fundamental rights and that the return of refugees
to another member state under that regime would be contrary to EU law where there were “substantial
grounds for believing that there are systemic flaws in the asylum procedure and reception conditions for
asylum applicants in the Member State responsible, resulting in inhuman or degrading treatment …” (para.
86)5.

39. Subject to the point made in the next paragraph, I do not accept those submissions. There is nothing
contrary to the Convention, or the case-law or guidance relating to it, in the application of a rebuttable
presumption that a particular country of origin is safe; and the presumption is plainly a reasonable one in
the case of a member state of the EU, for the reasons given in the Protocol. Where such a presumption
applies and is not rebutted there is no need for a consideration of the particulars of the claim. The
Convention is concerned with substance, not process: if the country of origin can properly be presumed to
be safe any substantive consideration would be futile. Of course, as I have made clear above, the
presumption required by the Protocol – whether (implicitly) at the first stage or (explicitly) at the second
stage if a claim is admitted is rebuttable The decision of the CJEU in NS in fact supports my


-----

understanding of the effect of the Spanish Protocol in so far as its formulation of the condition necessary to
disapply the requirements of the Dublin regime is broadly in line with my own formulation.

40. One of the points made by Ms Knights in this connection was that in an insufficiency of protection case
– as asylum claims by victims of trafficking will inevitably be – it is unrealistic and unfair to expect claimants
themselves to be able to provide cogent evidence about the effectiveness of protection systems in their
country of origin. She submitted that it was incumbent on the state to which an application is made by a
victim of trafficking from an EU state to consult the information available to it about the effectiveness of
those systems, as it would in an ordinary asylum claim involving a non-EU state. I do not think there can
be any general rule about this. If such inquiries were necessary in every case it would undermine the
presumption of safety which is the basis of the Spanish Protocol. But it is fair to observe that a sufficiency
of protection case is rather different from one based on fear of persecution by the state itself, where the
victim can be expected to be in a position to provide cogent evidence based on their own experience. On
ordinary public law principles the Secretary of State will be expected to take into account information of
which she is aware which casts doubt on the sufficiency of protection in an EU state before making a
decision whether to admit an asylum claim by a national of that country.

41. Ms Knights also submitted that the approach to the Protocol which I have identified would infringe
article 3 of the Refugee Convention (see para. 18 above). There is nothing in this. The application of a
proper presumption that a particular country of origin is safe cannot be regarded as discriminatory against
nationals of that country: their treatment is based not on their nationality but on the objective characteristics
of the country concerned.

APPLICATION TO THE PRESENT CASE

42. The only material put before the Home Office consisted of the letter of 18 July 2017. Although Duncan
Lewis clarified that that letter was intended as an asylum claim they did not themselves add any further
submissions. The letter clearly expresses a fear of an attempt by DE to resume his control of the Appellant
on return. The primary question for us, however, is whether it presented compelling reasons to believe that
there was a clear risk that Lithuania might be unable or unwilling to afford her protection, to the _Horvath_
standard, against any such attempt. It plainly did not. Ms Knights submitted that the Appellant's account of
having been re-trafficked in 2012 showed that the Lithuanian authorities were unwilling or unable to protect
victims of trafficking. I cannot accept that. Shocking though that episode was, it does not justify any
general conclusion of that kind. There is no suggestion in the Appellant's account that she had made
herself known to the authorities on her return or alerted them to any concerns about further ill-treatment by
DE, who was still in the UK: on the contrary, she says that she went back thinking that “everything had
finished”. I do not blame her for that belief, but the only question for the Court is whether what happened
to her required, or indeed could have justified, a conclusion by the Secretary of State that this was an
exceptional case where an EU member state was unable or unwilling to offer proper protection to its
nationals.

43. There remains the question whether the Secretary of State should have appreciated that there was
such a risk even in the absence of any evidence directed to that question provided to her by the Appellant
or her representatives. In her skeleton argument the Appellant made brief reference to a report published
in March 2019 by the Council of Europe's Group of Experts on Action against Trafficking in Human Beings
(“GRETA”) on the implementation of ECAT in Lithuania, from which it could be inferred that an earlier
report had contained some criticisms of the Lithuanian system. On the eve of the hearing the Appellant
sought to have an extract from the 2019 report included in the bundle before the Court. Mr Brown objected
to the admission of this document, which had not been relied on before Garnham J, and in response Ms
Knights made it clear that she placed no reliance on it and did not intend to refer to it. In those
circumstances we need say no more about it. In the absence of material of this character, however, it was
impossible for Garnham J, and would be impossible for us, to find that the Secretary of State must or
should have been aware of the risk of serious failures by Lithuania to provide sufficient protection to victims
of trafficking such that condition (d) might be satisfied.


-----

44. Ms Knights also referred us to para. 16 of the UNHCR Guidelines, which appears to suggest that,
exceptionally, the Refugee Convention may require the grant of asylum, even in the absence of any risk of
renewed ill-treatment on return, if “the persecution suffered during the trafficking experience … was
particularly atrocious and the individual is experiencing ongoing traumatic psychological effects which
would render return to the country of origin intolerable”. Mr Brown did not accept that such a case would
be caught by the terms of the Convention, and I am bound to say that I see force in that submission: there
are more appropriate humanitarian routes for accommodating sufficiently exceptional cases of that
character. But we did not hear substantial argument on the point, and it is sufficient for present purposes
to say that the letter of 18 July did not raise a case that would have justified the Secretary of State
entertaining the Appellant's application notwithstanding the strong presumption that Lithuania was a safe
country of origin.

THE VMS GUIDANCE

45. The VMS Guidance sets out at p. 71 the steps which the Home Office, if it is the Competent Authority,
should take in “live immigration cases following a positive Conclusive Grounds decision”. The passage
says, among other things:

“The Home Office should not make [a] negative decision on an asylum claim whilst a person is being
considered under the NRM process. Once a conclusive grounds decision has been taken, any outstanding
claim for asylum should be decided.”

In this case the inadmissibility decision was made in the interval between her referral into the NRM and the
eventual conclusive grounds decision. Ms Knights submits that that is a plain breach of the Secretary of
State's published policy and accordingly unlawful.

46. I do not accept that submission. In my view it is reasonably clear, as Garnham J held at para. 61 of
his judgment, that the policy stated in the Guidance refers to admissible claims, which will require
substantive consideration. As Mr Brown submitted, a claim for asylum cannot naturally be described as
“outstanding” if the Secretary of State is debarred from properly considering it.  The thinking behind the
policy which I have quoted is not entirely clear to me, and was not elucidated during the hearing; but it is
plainly derived in one way or another from the fact that deciding whether a person is a victim of trafficking
and whether they are entitled to asylum under the Convention are likely to involve overlapping inquiries.
But where the asylum claim is inadmissible in the first place no such inquiry will occur.

47. Ms Knights drew our attention to another case in which Duncan Lewis acted for a Latvian asylum
claimant (referred to as “DK”). They argued in pre-action correspondence that her claim had been
declared inadmissible while she was still in the NRM process, and the Secretary of State agreed (in August
2019) to withdraw the decision apparently on that basis. She submitted that that was inconsistent with the
stance being taken by the Secretary of State in these proceedings. Mr Brown was not able to suggest any
real difference between the two cases and in the end simply submitted that the concession made in DK's
case was wrong. In my view that is indeed the case. I can well understand why Ms Knights seeks to rely
on this episode, and it must be galling for Duncan Lewis, having once had the point accepted, now to find
the Secretary of State changing her position. But an error made in one case (in pre-action
correspondence) cannot commit her to take the same stance in other cases.

**GROUND 4: BREACH OF THE SUPPORT DUTY**

THE CLAIM

48. Ground 4 in the Appellant's Grounds of Claim reads as follows:

“The Defendant unlawfully failed to discharge his obligation to provide the Claimant with assistance and
support on receipt of a Reasonable Grounds decision under Articles 11(2) and (5) Directive 2011/36/EU
and his published policy. That is so because (a) the Claimant's medical and welfare needs _required her_
release from detention and yet Defendant unlawfully failed to discharge her, (b) the psychological support
the Claimant required was not provided to her in detention; (c) the Defendant made no adequate


-----

assessment of the Claimant's medical and welfare needs until her release from detention on 30 November
2017; and (d) the Claimant did not receive adequate mental health treatment whilst in detention.”

It will be seen that the Appellant relies on two sources of the alleged duty to provide her with “assistance
and support”. I take them in turn.

49. As for the EU Directive referred to, this is the so-called “Anti-Trafficking Directive” (which of course had
direct effect in the UK at the date with which we are concerned). The effect of the Directive is discussed in
some detail at paras. 54-69 of the judgment of the Court in _MN v Secretary of State for the Home_
_Department_ _[2020] EWCA Civ 1746, [2021] 1 WLR 1956. For present purposes we are concerned only_
with article 11, which is headed “Assistance and Support for Victims of Trafficking in Human Beings”. The
paragraphs relied on by the Appellant read:

“(2) Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable-grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3.

…

(5)  The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
_subsistence through measures such as the provision of appropriate and safe accommodation and material_
_assistance, as well as necessary medical treatment including psychological assistance, counselling and_
_information, and translation and interpretation services where appropriate [emphasis supplied].”_

The effect of the reference in paragraph (2) to a person having been “subjected to any of the offences
referred to in Articles 2 and 3” is to their being victims of trafficking. (Paragraph (1), referred to in
paragraph (5), is concerned with a cognate obligation to provide support to victims of trafficking who are
co-operating in the investigation of offences committed by their traffickers.)

50. As for the Secretary of State's “published policy”, that is a reference to the documents setting out the
NRM, being the “VMS Guidance” to which I have already referred. The avowed intention of the NRM,
which is described in the Guidance as “a victim identification and support process”, is to give effect to the
relevant parts of the UK's obligations under the Council of Europe Convention on Action against Trafficking
in Human Beings (“ECAT”). The Guidance says, at p. 25:

“Potential victims of human trafficking (ie those with a positive reasonable grounds decision) are entitled to
45 days supported recovery and reflection period. First responders and Competent Authority staff must
ensure that this support is provided following a positive reasonable grounds decision. This provision is
extended to all potential victims of **_modern slavery in England and Wales with a positive reasonable_**
grounds decision.”

The Home Office has entered into a contract with the Salvation Army to provide support in accordance with
that policy (in England and Wales).

51. The VMS Guidance itself does not specify the nature of the required support, but since the NRM is
avowedly intended to give effect to the UK's obligations under ECAT it is appropriate to refer to article 12
(“Assistance to Victims”). This reads (so far as material) as follows:

“(1) Each Party shall adopt such legislative or other measures as may be necessary to assist victims in
their physical, psychological and social recovery. Such assistance shall include at least:

(a) standard of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

(b)  access to emergency medical treatment;

(c)  translation and interpretation services, when appropriate;

(d)  counselling and information, in particular as regards their legal rights and the services available to
them, in a language that they can understand;


-----

(e)  assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

(f)  access to education for children.

(2)  Each Party shall take due account of the victim's safety and protection needs.

(3)   In addition, each Party shall provide necessary medical or other assistance to victims lawfully
resident within its territory who do not have adequate resources and need such help.

(4)  Each Party shall adopt the rules [sic, but I think 'the' must be a slip] under which victims lawfully
resident within its territory shall be authorised to have access to the labour market, to vocational training
and education.

(5)-(6) …

(7)  For the implementation of the provisions set out in this article, each Party shall ensure that services
are provided on a consensual and informed basis, taking due account of the special needs of persons in a
vulnerable position and the rights of children in terms of accommodation, education and appropriate health
care.”

That does not distinguish between potential and established victims, but it must be read with article 13,
which provides for the “recovery and reflection period”, which will typically (as it did here) occur before a
conclusive grounds decision is made. Article 13 (2) reads:

“During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2.”

Accordingly paragraphs (3) and (4) of article 12 do not apply to potential victims of trafficking such as the
Appellant.

52. It will be seen that there is a broad correspondence between the requirements of the Directive and of
ECAT as regards potential victims of trafficking, but, as noted in MN (see para. 56), they are not identical.

53. As appears from the pleading, the respects in which the Secretary of State is said to have breached
the support duty relate to the treatment that she received in relation to her mental health. I will return to the
details of her case later.

THE DECISION OF THIS COURT IN EM

54. In R (EM) v Secretary of State for the Home Department _[2018] EWCA Civ 1070, [2018] 1 WLR 4386,_
this Court considered the extent of the duty of the Secretary of State under paragraphs (2) and (5) of article
11 of the Trafficking Directive. The claimant was a Nigerian potential victim of trafficking who, like the
Appellant in this case, claimed that she had not received sufficient support while in immigration detention.
The only substantive judgment was given by Peter Jackson LJ, with whom Arden and Sharp LJJ agreed.

55. At paras. 18-30 of his judgment Peter Jackson LJ reviews the provisions of ECAT, the Directive and
the VMS Guidance establishing the support duty as regards potential victims of trafficking, essentially as I
have done above. At para. 31 he says:

“Synthesising these sources, the core obligation defining the support duty arises from Arts. 11(2) and (5) of
the Directive, which (emphasising words directly relevant to the present claim) mandate that **assistance**
**and support must be provided to PVoTs on a consensual and informed basis, and shall include at least**
standards of living capable of ensuring victims' subsistence through measures such as the provision of
appropriate and safe accommodation and material assistance, as well as necessary medical treatment
**including psychological assistance, counselling and information, and translation and interpretation**
services where appropriate.”

He observes that the real issue in the case is the true meaning of the emphasised words.

56. That question is addressed at paras. 65-68 of Peter Jackson LJ's judgment, under the heading “What
is the nature and scope of the support duty?”. These read:


-----

“65. The general duty on the State under Arts. 11(2) and (5) of the Directive is to provide assistance and
support to a PVoT by mechanisms that at least offer a subsistence standard of living through the provision
of

o appropriate and safe accommodation

o material assistance

o necessary medical treatment including psychological assistance, counselling and information, and

o translation and interpretation services.

66. As to that element of the duty that requires the provision of necessary medical treatment including
psychological assistance, counselling and information, the treatment provided must respond to the welfare
needs of the individual, objectively assessed in each case. The obligations arising under the Directive and
Guidance, read alongside the Convention, do not extend to a requirement that the assessment or
treatment must be provided by specialists in trafficking, or that it be targeted towards one aspect of an
individual's needs (the consequences of trafficking) as opposed to his or her overall psychological needs.
The support duty calls for the provision of support, not the accomplishment of physical, psychological or
social recovery. There is nothing in the Convention, Directive, or Guidance to warrant the extended
interpretation of the duty argued for by the Claimant. That interpretation would require significant additions
to the texts to prescribe specific obligations that would undoubtedly have been spelt out, had they been
intended.

67. Nor do the Claimant's submissions gain strength from a comparison between services that are
provided in the community and those provided in IRCs. The position of a PVoT who is detained is different
from the position of one who is not, and it is lawful for the State to decide to provide support in different
ways. A PVoT living in the community may well not have access to any of the four forms of support
mentioned at paragraph 65 above, while all four will automatically be available to a detained PVoT. The
way in which psychological treatment is provided may take account of the inherent uncertainty about the
length of detention, and the ready availability of on-site medical care for a person who is in any case under
close observation. The evidence filed on behalf of the Claimant is in my view more effective in
demonstrating the way in which the support duty is satisfactorily discharged in the community than in
establishing any breach of legal duty towards detained PVoTs. The fact that different, or better, provision
might be made for those not in detention does not of itself equate to a breach of duty.

68.  I also consider that, when considering whether the support duty has been discharged, it is
appropriate to look at the level of assistance and support that has been provided to the PVoT at all stages
in the process, and not just at support provided during the 45-day reflection period.”

GARNHAM J's REASONING

57. At paras. 119-128 of his judgment Garnham J rejects the Appellant's case that she had not received
sufficient support during her detention for what he identifies as four reasons.

58. First, he holds that, as a potential victim of trafficking, the Appellant was only entitled to what he
described at para. 122 of his judgment as the “modest levels of assistance” required by article 11 of the
Directive and article 12 of ECAT – “measures, for example, capable of ensuring her subsistence and to
_emergency medical support [emphasis supplied], rather than to the more sophisticated support treatment_
for which Ms Knights contends”. At para. 123 he quotes para. 65 of Peter Jackson LJ's judgment in EM,
underlining the phrase “subsistence standard of living”. At para. 121 he says that the position in EM was in
fact different because the claimant in that case was an established victim of trafficking. That was a slip on
his part because in EM too the claimant was only a potential victim of trafficking: I return to this below.

59. Second, at para. 124 he holds, following para. 68 of Peter Jackson LJ's judgment in _EM, that “it is_
necessary to consider the assistance and support provided throughout the relevant period” and not just in
the 45-day recovery and reflection period.

60. Third, at para. 125, he finds that


-----

“… the support and treatment the Claimant in fact received in detention, as itemised by Mr Brown, met the
minimum requirements imposed by the Directive and ECAT. That support and treatment responded to the
need that had been recognised and assessed by those who had the Claimant in their care in detention. In
my judgment, the support and treatment provided in detention provided more than a 'subsistence standard
of living' in each of those respects.”

The reference to “support and treatment … as itemised by Mr Brown” is to a list compiled by Mr Brown
from the Appellant's records while in detention, until 29 July 2017 at Bronzefield and thereafter at Yarl's
Wood: the records were before Garnham J (and also before us). He summarised what they showed at
para. 118 of his judgment:

“[The Appellant] was seen by a nurse on 28 July 2017, her need for methadone was addressed on 28 July;
she was offered but did not attend a GP appointment on 31 July 2017; she attended a mental health
assessment on 2 August 2017 and a triage later that day; she was invited to attend a wellbeing services
Kaleidoscope following a referral from healthcare; she saw a doctor on 8 August 2017, she was offered but
did not attend appointments on 14, 16 and 17 August 2018; she was offered but did not attend an
appointment with the substance misuse team on 21 August 2017; she saw a GP on 24 August 2017; she
was offered but did not attend an appointment on 30 August 2017; she had an appointment with the GP on
4 September 2017; on 5 September 2017, she was booked for CBT; on 6 September 2017, she had a
psychological wellbeing assessment; on 7 September 2017, she had a mental health assessment; she saw
a doctor on 21 September 2017; on 28 September 2017, she had a psychological wellbeing assessment;
on 29 September 2017, she had a mental health review; she saw a GP on 5 October 2017 and 12 October
2017; a primary mental health care plan was created on 16 October 2017; a psychological wellbeing
assessment was carried out on 18 October 2017; she saw a GP on 19 October 2017 and 26 October 2017;
and after her release, she had access to, and attended, counselling sessions.”

The reference in that summary to “substance misuse” refers to the fact that the Appellant, as already
noted, had a heroin addiction: this was being treated by prescriptions of methadone. Although that
summary ends on 26 October the records which we have seen show that the Appellant continued to have
both appointments with a nurse and with a GP up to very shortly before her release. The notes show that
there was a focus on reducing the levels of methadone that she was taking.

61. At para. 126 he quotes paras. 66-67 from the judgment of Peter Jackson LJ in EM, continuing, at para.
127:

“The Trafficking Directive and the Guidance do not prescribe the manner in which assistance and support
are to be provided in different circumstances. The Trafficking Convention applies to all 47 states of the
Council of Europe and the Directive to the 28 states of the European Union. Individual states must design
systems to achieve the required result. The obligation to provide support does not translate into an
obligation to secure psychological recovery and the obligation does not have to be met in identical ways
inside and outside detention.”

62. Fourth, at para. 128 he says:

“The expert on whom the Claimant relies, Dr Obuaya, recognised that it was necessary first to treat the
Claimant's drug dependency before psychosocial treatment could be introduced effectively. That treatment
continued throughout her detention.”

THE APPEAL

63. Ground 4 reads:

“In dismissing ground 4 of the Claimant's claim and holding that the Defendant had discharged his duty to
provide the Claimant with assistance and support as a potential victim of trafficking, the Court erred in (a)
interpreting the duty imposed by article 11 of the Directive and article 12 ECAT as restricted to 'emergency
medical support' and (b) incorrectly applying the decision of the Court of Appeal in [EM]”.

That ground is developed in short supporting submissions but I need not reproduce them.


-----

64. As already noted, Irwin LJ did not himself give permission on this ground. That was because it was
anticipated that the issues which it raised would be considered in a pending appeal to this Court from the
decision in H v Secretary of State for the Home Department _[2018] EWHC 2191 (Admin). In the event that_
appeal was compromised. In those circumstances I would grant permission.

65. In the Appellant's skeleton argument ground 4 is developed under four heads. I will take the first two
in turn but the third and fourth together.

(1)          The error about the facts of EM

66. The first head depends on Garnham J's error about the claimant in EM being an established victim of
trafficking: see para. 58 above. It is impossible now to establish how the error occurred, but I am satisfied
that it is a mere slip which did not affect his approach to the actual issues. So far from distinguishing EM,
he went on in the following paragraphs to quote passages from Peter Jackson LJ's judgment and apply his
reasoning.

(2)         “Emergency medical support”

67. Ms Knights' second head of challenge is directed at Garnham J's description of the support to which
the Appellant was entitled as “emergency medical support”: see at para. 122 of his judgment quoted
above. She points out that the phrase in article 11 (5) of the Directive specifying the required level of
medical support as “necessary medical treatment”. It may be that Garnham J had in mind the phrase
“emergency medical treatment” in article 12 (1) (b) of ECAT (although he used the word “support” rather
than “treatment”), but it is the Directive which was binding on the Secretary of State; and at para. 31 of his
judgment in _EM Peter Jackson LJ correctly used its language. Ms Knights submits that the concept of_
“necessary medical treatment” is wider than what would normally be understood as “emergency medical
support”. She referred us to _R (K) v Secretary of State for the Home Department_ _[2018] EWHC 2951_
_(Admin), [2019] 4 WLR 92. That was a case about financial rather than medical support, but she relied on_
para. 30 of Mostyn J's judgment, where he expressly disagrees with Garnham J's overall characterisation
of the levels of support required by the Directive as “modest”: the passage in question is the same as
where he uses the phrase “emergency medical support”.

68. I agree that it would have been better if Garnham J had not used the phrase “emergency medical
support”. I am not in fact convinced that there is any substantive difference between the requirements of
article 12 (1) (b) of ECAT (if that is indeed what he had in mind) and of article 15 (2) of the Directive if both
are read purposively and in context. But it can be dangerous to depart from the language of the relevant
legislation, and I accept that the phrase “emergency medical support/treatment” could be taken to be rather
narrower in scope than “necessary medical treatment”.

69. It does not, however, follow that Garnham J misdirected himself in substance. As Mr Brown pointed
out, he quotes at least three passages from EM using the terminology of “necessary medical treatment”,
without any suggestion that he regards these as having any different effect from his own summary at para.
122. And it was common ground before him (as before us) that the Appellant was entitled to psychological
or psychiatric treatment to help her cope with her mental health problems (whether attributable to her
experiences as a victim of trafficking or otherwise), without imposing any requirement that that treatment
be characterised as “emergency” in character. The Secretary of State has always acknowledged that
potential victims of trafficking are entitled to support/treatment of that kind, and it can be seen from the
summary quoted at para. 60 above that various forms of mental health support and treatment were
extended to the Appellant during her detention. She contends that these were inadequate in certain
specific respects which are the subjects of the other heads of challenge. I consider her criticisms below,
but I see no sign that Garnham J's rejection of them was influenced by some perceived distinction between
“emergency” and “necessary” treatment.

(3)/(4) Inadequacy of medical support

70. As we have seen, Garnham J considered the full records of the medical and psychological support
available to the Appellant in detention: see para. 118 of his judgment quoted above. In the Appellant's


-----

skeleton argument Ms Knights submitted that the records “provide clear evidence that there had been no
provision of adequate support or assistance other than some anti-depressants”; but only three specific
respects in which the support given is said to have been inadequate are identified. These were:

(a) that no adequate “individualised assessment” of her needs as a victim of trafficking was carried out;

(b) that no “rule 34 examination” was carried out when she arrived at Yarl's Wood; and

(c) that she had not received (because it was inappropriate while she remained in detention) the kind of
psychological therapy which had been recommended by a psychiatrist, Dr Obuaya, who had written a
report on her case dated 23 October 2017.

When asked in the course of her oral submissions whether she had any other specific criticisms, Ms
Knights added that although the Appellant had, as Garnham J notes, been booked in early September
2017 for cognitive behavioural therapy there is no record of her having received it.

71. The starting-point must be that Garnham J's decision on the adequacy of the medical and/or
psychological support afforded to the Appellant is a decision of fact, with which we should only interfere if
we are satisfied that it was wrong. I do not believe that it was. I take Ms Knights' criticisms in turn.

72. As regards (a) – absence of individualised assessment – as Peter Jackson LJ says in EM (see para.
66 of his judgment), “the provision of necessary medical treatment including psychological assistance,
counselling and information, … must respond to the welfare needs of the individual, objectively assessed in
each case”. Typically when a reasonable grounds decision is made the potential victim will be referred to
the Salvation Army, and they will complete an “Initial Needs Based Assessment Form”, which involves a
full individualised assessment. That did not occur in the Appellant's case because she was being held in
immigration detention. Many of her immediate needs, such as accommodation and subsistence, were of
course catered for as long as she remained in detention. As regards her medical and psychological needs,
Garnham J was entitled to take the view that a distinct formal assessment was not required in
circumstances where she was already under the care of the professional staff, first at Bronzefield and then
at Yarl's Wood. In EM (see para. 53) counsel for the claimant conceded that there was nothing in ECAT
that required there to be an “individualised assessment” (by which I take him to have meant such a distinct
formal assessment) and the Court evidently regarded that concession as correctly made: see para. 67, as
quoted above. What matters is the substance of the support provided rather than matters of formal
process. I note that Sir Stephen Silber makes essentially the same point, albeit in a slightly different
context, in R (Galdikas) v Secretary of State for the Home Department _[2016] EWHC 942 (Admin), [2016] 1_
WLR 4031, at paras. 99-103.

73. As regards (b), rule 34 (1) of the Detention Centre Rules 2001 provides:

**“Every detained person shall be given a physical and mental examination by the medical practitioner (or**
another registered medical practitioner in accordance with rules 33(7) or (10)) within 24 hours of his
admission to the detention centre.”

It was accepted before Garnham J that no such examination took place when the Appellant was
transferred to Yarl's Wood on 28 July 2017. However, the point made in the previous paragraph applies
equally here: what matters is the substance of the support that the Appellant in fact received. I would add
that at that date there was no indication that she was a victim of trafficking (still less any reasonable
grounds decision), and at para. 77 of his judgment Garnham J found that if a rule 34 examination had
occurred at that time there was no reason to suppose that evidence that that was the case would have
emerged.

74. As regards (c), the point based on Dr Obuaya's report was expressly addressed by Garnham J at
para. 128 of his judgment (see para. 62 above). What he says there fairly reflects Dr Obuaya's
recommendation.

75. Finally, it does not appear that it was suggested before Garnham J that the Appellant did not receive
the CBT for which the notes show that she was referred, and there are no findings on the point. It is hard
in any event to see that any delay in affording her this treatment even if culpable would be likely to be a


-----

sufficient basis for a finding of a breach of the duty to provide necessary medical treatment or
psychological support.

ARTICLE 4 OF THE ECHR

76. In both the skeleton argument and her oral submissions Ms Knights argued that the obligation to
provide proper medical support which she said had been broken arose not only under the Directive and the
Secretary of State's policy embodied in the VMS Guidance (giving effect to ECAT) but also under article 4
of the ECHR. The European Court of Human Rights (“the ECtHR”) has in a series of decisions following
_Rantsev v Cyprus and Russia (2010) 51 EHRR 1 held that the very general language of article 4 must be_
construed as imposing certain positive duties on member states in the field of trafficking. The history is
summarised at paras. 14-17 of my judgment in _R (TDT) v Secretary of State for the Home Department_

_[2018] EWCA Civ 1395, [2018] 1 WLR 4922. At para. 17 I summarise the effect of those authorities as_
identifying positive duties of three kinds:

“(a) a general duty to implement measures to combat trafficking – 'the systems duty';

(b) a duty to take steps to protect individual victims of trafficking – 'the protection duty' (sometimes called
'the operational duty');

(c) a duty to investigate situations of potential trafficking – 'the investigation duty' (sometimes called 'the
procedural duty')”.

It was Ms Knights' contention that the protection duty included an obligation to support victims of trafficking
corresponding to the duty under article 12 of ECAT: she referred us to the recent decision of the ECtHR in
_V.C.L. v United Kingdom (77587/12), where at para. 154 the Court says:_

“Protection measures include facilitating the identification of victims by qualified persons and assisting
victims in their physical, psychological and social recovery (see [Chowdury v Greece (21884/150) [2017]
ECHR 300], §110).”

The significance of the point for the Appellant in this case is that breach of an obligation under the ECHR
would found a claim for damages under section 8 of the Human Rights Act 1998; but it may also be
important in cases arising following “IP completion date”, i.e. 31 December 2020, when the Directive no
longer has any application in the UK, so that entitlement to support for victims of trafficking would otherwise
depend on ministerial policy.

77. Mr Brown challenged that submission. He reminded us that not all the provisions of ECAT
automatically read across into positive obligations under article 4 of the ECHR: see TDT at paras. 30-31,
citing Secretary of State for the Home Department v Hoang Minh _[[2016] EWCA Civ 565.  He submitted](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
that neither V.C.L. nor Chowdury was concerned with the provision of support of the kind with which we are
concerned in this case.

78. Since, for the reasons given above, Garnham J was entitled to find that there was no breach in this
case of the duty to give adequate medical and/or psychological support to the Appellant, it is unnecessary
for us to decide whether that duty arose under article 4 of the ECHR as well as under the Directive and the
Guidance, and I prefer not to do so. The question was not considered by Garnham J and does not appear
to have been argued before him. Nor indeed is any claim under the 1998 Act, relying on article 4, within
the terms of ground 4 as pleaded, and although it is fair to say that Mr Brown did not object to its being
raised it was not at the forefront of the argument before us. In my view it would be better for the issue to
be determined in the context of a case where it is determinative; and that would have the advantage that
the Court would have the benefit of any further decisions of the ECtHR in this developing area.

**DISPOSAL**

79. I would grant permission to appeal on ground 4 but dismiss the appeal on both grounds.

**Moylan LJ:**

80 I


-----

**Dingemans LJ:**

81. I also agree.

**End of Document**


-----

