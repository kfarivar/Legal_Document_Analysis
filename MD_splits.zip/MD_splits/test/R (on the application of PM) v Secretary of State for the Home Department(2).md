# R (on the application of PM) v Secretary of State for the Home Department

## [2023] EWHC 1551 (Admin)

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 23/06/2023

# Catchwords & Digest

## IMMIGRATION ~ FINANCIAL SUPPORT ~ CLAIMANT BOTH AN ASYLUM SEEKER AND A VICTIM OF MODERN SLAVERY

 The King’s Bench Division allowed in part the claimant asylum seeker’s judicial review claim of the defendant Secretary of State’s decision for withdrawing trafficking support payments for the claimant as a victim of modern slavery for initial accommodation and for reinstating the payments at a reduced rate a month later. The proceedings concerned the final support the claimant had received while still considered a potential victim of modern slavery and while still being assessed for support pursuant to s 98 of the Immigration and Asylum Act 1999. The claimant submitted that the Secretary of State: (i) had unlawfully failed to pay the correct financial support under s 98 of the Act in accordance with s 15.37 of the ‘Modern Slavery Act 2015 – Statutory Guidance for England and Wales’ (the guidance) which raised the question of what type of financial support the claimant was entitled to; (ii) had unlawfully failed to make appropriate inquiries when reinstating financial support in accordance with an amended version of the guidance (the amended guidance); and (iii)had failed to give the financial support to meet the claimant’s essential living costs. The court held that, on the evidence, the Secretary of State had met the claimant’s essential living needs but that the Secretary of State had failed to make adequate financial support in a timely manner and had failed to make appropriate inquiries. Applying R (on the application of JB (Ghana)) v Secretary of State for the Home Department [2022] All ER (D) 73 (Oct) (JB) if a potential victim of trafficking was also an asylum seeker and receiving asylum support, a further payment was to be made to make a total (including the asylum support) of £65 per week and that applied despite the fact that the claimant in the present case was supported throughout the relevant period under s 98 and not s 95, as was the case in JB. Further, the amended guidance was unlawful on the basis that the failure to consult outside bodies, or to gather any information as to the impact that a de facto 27% reduction in trafficking support would have on the recovery of victims, breached the ‘Tameside duty’ of reasonable inquiry.

# Cases referring to this case

R (on the application of FH) v Secretary of State for the Home Department 04/06/2024

AdminCt


-----

_[[2024] EWHC 1327 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C69-BT43-RRSM-B27J-00000-00&context=1519360)_
Considered

# Cases considered by this case

R (on the application of CB) v Secretary of State for the Home Department

_[[2022] EWHC 3329 (Admin), [2023] 4 WLR 28, [2023] All ER (D) 12 (Jan)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:679C-T693-CGX8-01FR-00000-00&context=1519360)_
Applied

R (on the application of JB (Ghana)) v Secretary of State for the Home Department

_[[2022] EWCA Civ 1392, [2022] All ER (D) 73 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66PS-0Y43-CGX8-037G-00000-00&context=1519360)_
Applied

MD and another v Secretary of State for the Home Department

_[[2022] EWCA Civ 336, [2022] PTSR 1182, [2022] All ER (D) 71 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-HXX3-CGX8-004D-00000-00&context=1519360)_
Explained

R (on the application of JB) v Secretary of State for the Home Department

_[[2021] EWHC 3417 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64B0-MGX3-GXF6-83VK-00000-00&context=1519360)_
Considered

JM v Secretary of State for the Home Department

_[[2021] EWHC 2514 (Admin), [2022] PTSR 260, [2021] All ER (D) 59 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63WD-VJP3-GXF6-8443-00000-00&context=1519360)_
Applied

DVP v Secretary of State for the Home Department and other cases

_[[2021] EWHC 606 (Admin), [2021] 4 WLR 75, [2021] All ER (D) 78 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627T-8033-GXFD-81RX-00000-00&context=1519360)_
Applied

VCL and another v United Kingdom

_[[2021] ECHR 77587/12, [2021] All ER (D) 87 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:622N-S9J3-GXFD-841G-00000-00&context=1519360)_
Applied

R (on the application of A and another) v South Kent Coastal CCG and other
companies

_[[2020] EWHC 372 (Admin), [2020] All ER (D) 159 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y98-HW43-GXFD-818W-00000-00&context=1519360)_
Applied

R (on the application of JP) v Secretary of State for the Home Department; R (on the
application of BS) v Secretary of State for the Home Department

_[[2019] EWHC 3346 (Admin), [2020] 1 WLR 918, [2020] All ER (D) 65 (Jan)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y1K-3F63-CGXG-03S4-00000-00&context=1519360)_
Applied

R (on the application of Campaign Against Arms Trade) v Secretary of State for
International Trade (Amnesty International and others intervening)

_[[2019] EWCA Civ 1020, [2019] 1 WLR 5765, [2019] All ER (D) 146 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VV7-8352-D6MY-P07S-00000-00&context=1519360)_
Applied

R (on the application of Balajigari) v Secretary of State for the Home Department and
other appeals

_[[2019] EWCA Civ 673, [2019] 4 All ER 998, [2019] 1 WLR 4647, [2019] INLR 619,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_

_[[2019] All ER (D) 134 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W0H-B402-8T41-D41B-00000-00&context=1519360)_
Considered


21/12/2022

AdminCt

25/10/2022

CACivD

16/03/2022

CACivD

17/12/2021

AdminCt

04/10/2021

AdminCt

17/03/2021

DC

16/02/2021

EctHR

21/02/2020

AdminCt

10/12/2019

AdminCt

20/06/2019

CACivD

16/04/2019

CACivD


R (on the application of K and another) v Secretary of State for the Home Department 08/11/2018


-----

_[[2018] EWHC 2951 (Admin), [2019] 4 WLR 92, [2018] All ER (D) 50 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TPV-5BX1-DYBP-N303-00000-00&context=1519360)_
Explained

R (on the application of ZV) v Secretary of State for the Home Department

_[[2018] EWHC 2725 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5THF-NB01-F0JY-C2JK-00000-00&context=1519360)_
Considered

R (on the application of EM) v Secretary of State for the Home Department

_[[2018] EWCA Civ 1070, [2018] 1 WLR 4386, [2018] All ER (D) 113 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCR-C3C1-DYBP-N2GW-00000-00&context=1519360)_
Considered

R (on the application of JK) v Secretary of State for the Home Department

_[[2017] EWCA Civ 433, [2017] 1 WLR 4567, [2017] All ER (D) 166 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NX0-TXV1-DYBP-N12H-00000-00&context=1519360)_
Applied

R (on the application of Ghulam and others) v Secretary of State for the Home
Department

_[[2016] EWHC 2639 (Admin), [2016] All ER (D) 06 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2T-YN91-DYBP-N3B8-00000-00&context=1519360)_
Applied

R (on the application of Tigere) v Secretary of State for Business, Innovation and Skills

_[[2015] UKSC 57, [2016] 1 All ER 191, [2015] 1 WLR 3820, [2015] ELR 455, [2015] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
_[ER (D) 304 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GJG-V641-DYBP-N52S-00000-00&context=1519360)_
Applied

R (on the application of Plantagenet Alliance Ltd) v Secretary of State for Justice

_[[2014] EWHC 1662 (Admin), [2015] 3 All ER 261, [2015] LGR 172, [2014] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_
_[194 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C8C-DW91-DYBP-N386-00000-00&context=1519360)_
Considered

R (on the application of Refugee Action) v Secretary of State for the Home Department

_[[2014] EWHC 1033 (Admin), [2014] PTSR D18, [2014] All ER (D) 69 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BY5-VXP1-DYBP-N0GJ-00000-00&context=1519360)_
Applied

R (on the application of LH) v Shropshire Council

_[[2014] EWCA Civ 404, [2014] PTSR 1052, [2014] All ER (D) 06 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C3P-2T51-DYBP-N260-00000-00&context=1519360)_
Considered

Tesco Stores Ltd v Dundee City Council

_[2012] UKSC 13, [2012] PTSR 983, [2012] 13 EG 91, 2012 SC (UKSC) 278, 2012 SLT_
[739, [2012] All ER (D) 163 (Mar), 2012 Scot (D) 17/3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:557G-YC61-DYBP-N3CC-00000-00&context=1519360)
Considered

R (on the application of Cheshire East Borough Council) v Secretary of State for
Environment Food and Rural Affairs

_[[2011] EWHC 1975 (Admin), [2011] All ER (D) 80 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53K1-G7S1-DYBP-N00X-00000-00&context=1519360)_
Considered

Rantsev v Cyprus and Russia (Application 25965/04)

_[[2010] ECHR 25965/04](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_
Considered

R (on the application of Khatun) v Newham London Borough Council

_[[2004] EWCA Civ 55, [2005] QB 37, [2004] 3 WLR 417, [2004] LGR 696, (2004) Times,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4GNT-N020-TWP1-N195-00000-00&context=1519360)_
[27 February, [2004] All ER (D) 386 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JXK1-DYBP-N481-00000-00&context=1519360)
Applied


AdminCt

18/10/2018

AdminCt

15/05/2018

CACivD

22/06/2017

CACivD

24/10/2016

AdminCt

29/07/2015

SC

23/05/2014

DC

09/04/2014

AdminCt

04/04/2014

CACivD

21/03/2012

SC

26/07/2011

AdminCt

07/01/2010

EctHR

24/02/2004

CACivD


Thlimmenos v Greece (Application 34369/97) 06/04/2000

EctHR


-----

_[[2000] ECHR 34369/97](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4N9-00000-00&context=1519360)_
Considered
Inco Europe Ltd v First Choice Distribution (a firm)

_[[2000] 2 All ER 109, [2000] 1 WLR 586, [2000] 1 All ER (Comm) 674, 74 ConLR 55,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-6089-00000-00&context=1519360)_
[(2000) Times, 10 March, [2000] Lexis Citation 2604, [2000] All ER (D) 305](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG81-DYBP-P3YX-00000-00&context=1519360)
Explained

Associated Provincial Picture Houses Ltd v Wednesbury Corpn

[[1948] 1 KB 223, [1947] 2 All ER 680, 177 LT 641](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60M0-00000-00&context=1519360)
Considered

**End of Document**


09/03/2000

HL

10/11/1947

CA


-----

