# Highlights: October 2022

The Supreme Court has given its decision in Harpur Trust v Brazel _[[2022] IRLR 867 on calculating holidays under](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824V-00000-00&context=1519360)_
working time legislation for part-time workers who work for only part of the year but have a continuing contract
throughout that year. The claimant was a part-time music teacher who worked during term-time only (around 32
weeks) on a zero hours contract. She, and other part-time contract workers, was entitled to 5.6 weeks of paid
annual leave. As Lady Rose and Lady Arden's judgment explains: “The issue is whether their leave entitlement is
calculated on the same principle, proportionally, as full-time employees (which would mean that the weeks that they
do not work reduce their entitlement) or whether their leave must be calculated ignoring those weeks. The latter
would leave them with an entitlement which proportionally exceeds that of other employees. Nonetheless, the Court
of Appeal held that the proper construction of the domestic law led to that result and further that such a construction
was consistent with the applicable EU law.” The Supreme Court agrees with the Court of Appeal: “the amount of
leave to which a part-year worker under a permanent contract is entitled is not required by EU law to be, and under
domestic law is not, prorated to that of a full-time worker.” Accordingly, the claimant was entitled to the 5.6 weeks'
paid annual leave to which full-time employees are entitled. Her employer was not permitted to base the holiday pay
entitlement pro rata in respect of only the weeks the claimant actually worked. Therefore, the claimant's entitlement
was to be calculated by identifying a “week's pay” in accordance with the Employment Rights Act 1996 and
multiplying this by 5.6. The result is that the claimant, if she worked a 32-week year, was entitled to be paid holiday
at a rate of 17.5% of her earnings rather than 12.07%.

The Court of Appeal has allowed the employer's appeal in Union of Shop, Distributive and Allied Workers v Tesco
_Stores Ltd_ _[[2022] IRLR 844 against the decision of the High Court to grant declaratory relief and an injunction to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824S-00000-00&context=1519360)_
union restraining the employer from using a practice of “fire and rehire”, terminating the contracts of employment of
warehouse workers who had a contractual entitlement to “retained pay” and offering to re-engage them on terms
which did not include this benefit. Retained pay was offered to these workers in 2007, following negotiations with
USDAW, as an incentive to move location during a reorganisation rather than take redundancy. The employer had
given repeated assurances that the entitlement was “permanent”, “for life” and would remain for as long as the
employees were employed by Tesco in their current role. In 2021, however, Tesco announced that retained pay
would be phased out. Employees were offered a lump-sum payment. Those who did not accept were told that they
would be dismissed and offered re-engagement on an identical new contract, but without the retained pay element.
The High Court said that the word “permanent” should be construed, to mean for as long as the relevant employee
is employed by the defendant in the same substantive role, and that it was necessary to imply into the contract of
employment of each affected employee a term to the effect that “the defendant's right to terminate the contract on
notice cannot be exercised for the purpose of removing or diminishing the right of that employee to retained pay.”
The Court of Appeal, however, holds that the High Court was wrong to find that both parties intended that the
entitlement should be permanent in the sense that the contracts would continue for life, or until normal retirement
age, or until the closure of the workplace, or that it was the mutual intention of the parties that the circumstances in
which the employer could terminate the contracts should be limited. This leads the Court of Appeal to conclude that
the express terms of the contracts “should be interpreted in accordance with what the judge rightly found to be their
natural and ordinary meaning, namely that Tesco would have the right to give notice in the ordinary way, and that
the entitlement to retained pay would only last as long as the particular contract.” The Court of Appeal goes on to
hold that “even if the judge had been right to find for the claimants on liability, that could not have justified the grant
of an injunction.” Giving the only reasoned judgment allowing the appeal and discharging the injunction, Lord
Justice Bean notes that counsel “could not point to, and I am not aware of, any case in which a court has granted a
final injunction to prevent a private sector employer from dismissing an employee for an indefinite period ”


-----

Section 103A of the Employment Rights Act 1996 as amended makes dismissal for the principal reason that the
employee made a **protected disclosure automatically unfair. In determining the employer's reason, the courts**
have applied the EAT's decision in the victimisation case of _Martin v Devonshire Solicitors and treated as an_
exception “cases where an employer has dismissed an employee (or subjected him to some other detriment) in
response to the doing of a protected act … but where he can, as a matter of common sense and common justice,
say that the reason for the dismissal was not the complaint as such but some feature of it which can properly be
treated as separable.” Kong v Gulf International Bank (UK) Ltd _[[2022] IRLR 854 is the latest authority to consider](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824T-00000-00&context=1519360)_
this question of “separability” in the context of a whistleblowing claim. The claimant was employed as Head of
Financial Audit. She made a number of protected disclosures relating to compliance issues in respect of the bank's
use of a financial compliance template. Some of these were made at a meeting with the bank's Head of Legal. The
Head of Legal was upset by this and considered that her professional integrity was being questioned, although an
employment tribunal found that it was her legal awareness or competence that the claimant questioned. The Head
of

Legal said she could no longer work with the claimant. This led to the claimant's dismissal. Rejecting an automatic
unfair dismissal claim, an employment tribunal found that the principal reason for the claimant's dismissal was not
the protected disclosure but that she had questioned the Head of Legal's professional awareness/integrity, and that
this was a separate reason related to her conduct and not her protected disclosures. The EAT dismissed the
claimant's appeal. Intervening in the case in the Court of Appeal, Protect, the whistleblowing charity, submitted that
the separability principle is being applied too broadly. If it was legitimate for the tribunal to say the claimant was not
dismissed for making protected disclosures but because she criticised a colleague who was upset by that, and this
is separable, then effective protection for whistleblowing would be seriously undermined. Only if the claimant's
conduct constituted wholly unreasonable behaviour or serious misconduct should it be properly separable from the
making of the protected disclosure. However, a Court of Appeal with a strong employment law composition,
including two former Presidents of the EAT, dismissed the appeal. Giving the leading decision, Mrs Justice Simler
says that the “separability principle” is “simply a label that identifies what may in a particular case be a necessary
step in the process of determining what as a matter of fact was the real reason for impugned treatment. Once the
reasons for particular treatment have been identified by the fact-finding tribunal, it must evaluate whether the
reasons so identified are separate from the protected disclosure, or whether they are so closely connected with it
that a distinction cannot fairly and sensibly be drawn. Were this exercise not permissible, the effect would be that
whistleblowers would have immunity for behaviour or conduct related to the making of a protected disclosure no
matter how bad, and employers would be obliged to ensure that they are not adversely treated, again no matter
how bad the associated behaviour or conduct.” She adds: “In a proper case, even where the conduct of the
whistleblower is found not to be unreasonable, a tribunal may be entitled to conclude that there is a separate
feature of the claimant's conduct that is distinct from the protected disclosure and is the real reason for impugned
treatment.” In this case, the tribunal was entitled to conclude that what motivated the employer's decision to dismiss
was not the claimant's protected disclosures but her “lack of emotional intelligence and insensitivity …” In a
concurring judgment, Lord Justice Underhill says: “I do not see our decision as turning on any question of principle
or as opening any general breach in whistleblower protection.” Perhaps not in principle. But in practice there is quite
a distinction between using separability to justify disallowing a claim based on false allegations by a mentally ill
employee as in _Martin and using separability to disallow a claim by a dismissed whistleblower because of the_
manner in which they raised their concerns even though their conduct in so doing was found not to be
unreasonable. For all the Court of Appeal's protestations to the contrary, Kong is likely to have a chilling effect on
whistleblowing claims.

Section 108(4) of the Employment Rights Act 1996 as amended provides that the two-year qualifying period for
claiming unfair dismissal does not apply “if the reason (or, if more than one, the principal reason) for the dismissal
is, or relates to, the employee's **political opinions or affiliation.” The decision of the EAT sitting in Scotland in**
_Scottish Federation of Housing Associations v Jones_ _[[2022] IRLR 822 is the first reported case construing these](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824N-00000-00&context=1519360)_
provisions, which were introduced in 2013 following the decision of the European Court of Human Rights in
_Redfearn v United Kingdom. The claimant was Head of Membership and Policy for the respondent, which_
represents housing associations in Scotland. Her terms of employment included a clause relating to “political
activity”. This precluded the claimant from having a “formal role” of a political nature. In October 2019, the claimant


-----

informed the employer that she wished to stand as a candidate for Scottish Labour at the next General Election.
The employer's board did not consent to the claimant standing and she withdrew her candidature. A month later,
however, the claimant was dismissed, ostensibly for a variety of reasons, which did not include her request for
permission to stand. An employment tribunal held that if the claimant could show that she had been dismissed
because she sought to stand for election, she could rely on s.108(4). The tribunal took the view that a requirement
to be politically neutral was a requirement that “relates to” someone's political opinions or affiliations. The tribunal
concluded that the words “relates to” in s.108(4) meant that even though her political opinions and affiliation to the
Labour Party had nothing directly to do with her dismissal, they were nevertheless related to her dismissal since
without such opinions and affiliation she would not have sought to stand as a candidate. Her opinions and affiliation
with Scottish Labour had an indirect relationship with her dismissal but this was sufficient to bring her within
s.108(4). Allowing an appeal in respect of the unfair dismissal claim, the EAT says that s.108(4) has no application
“where the content of the employee's opinions or the identity of the party she wishes to stand for do not form part of
the reasoning leading to dismissal …” According to Lord Summers: “I consider that the subsection does not deal
with the dismissal of employees who are dismissed because they lack neutrality or who propose to act in a way that
threatens their political neutrality. Neutrality is the antithesis of the issue addressed by s.108(4). I consider that it
was designed to address the mischief of dismissals arising from the content of a person's political opinions or the
identity of the party with which the person is affiliated.” Although but for her candidacy for Scottish Labour the
claimant would not have been dismissed and in that sense her dismissal was related to her opinions and affiliation,
“the scope of the words 'relates to' must be interpreted in light of the purpose Parliament was seeking to achieve.
While a literal interpretation would I accept bring the claimant within the subsection I am not persuaded that a literal
construction is appropriate. I do not accept that the relationship between her dismissal and her political opinions
and affiliation was sufficiently proximate to the purpose of the subsection to come within its scope. Her political
opinions and affiliation were not the reason or principal reason for dismissal. If she was dismissed because she had
expressed a desire to be a political candidate and the reason for dismissal did not involve her membership of
Scottish Labour or political opinions, the only possibility left is that she was dismissed because she was not willing
to keep politically neutral. That state of affairs is in contrast to the terms of

s.108(4).” However, the EAT upheld the employment tribunal's finding that the claimant's belief that “those with the
relevant skills, ability and passion should participate in the democratic process” was a protected philosophical belief
within the meaning of s.10 of the Equality Act 2010. Thus, if the employer dismissed the claimant because she
wished to “participate in the democratic process”, she would have a claim under s.10.

There is a controversy between those who hold gender-critical views, believing in biological sex and sex-based
rights, and followers of gender identity theory who believe in gender fluidity and self-identification. This dispute is
increasingly being fought out on social media. Edward Lord is a lay member of the Employment Appeal Tribunal,
using the designation Mx. Mx Lord is “a bi/queer non-binary person” who has expressed strong views on Twitter
opposing gender-critical views and equating them with transphobia. Kristie Higgs was employed by Farmor's
School as a pastoral administrator and work experience manager. She was summarily dismissed for gross
misconduct after the school's attention was drawn to the fact that she had re-posted two articles on Facebook. One
of these criticised teaching in schools that gender is “a matter of choice”, to which Mrs Higgs added “they are
brainwashing our children”. The second reposting referred to the far left insisting on “cramming their perverted
vision of gender fluidity down the throats of unsuspecting school children.” Mrs Higgs brought a claim under the
Equality Act 2010, submitting that she had been discriminated against because of her lack of belief in “gender
fluidity” or that “someone could change their biological sex/gender”. An employment tribunal concluded that the
dismissal was not on the ground of the claimant's beliefs but was instead because the employer had taken the view
that someone reading the posts might consider that the claimant was hostile to the LGBT community and trans
people in particular. An appeal to the EAT was listed before a panel including Mx Lord. Before _Higgs v Farmor's_
_School_ _[[2022] IRLR 827 could be heard, the claimant made an application that Mx Lord should recuse themselves.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824P-00000-00&context=1519360)_
It was argued that Mx Lord's publicly stated views could give rise to a perception of bias in relation to the issues
raised by the appeal. Mrs Justice Eady accepts that there was apparent bias applying the test that a fair-minded
and informed observer, having considered the facts, would conclude that there was a real possibility that the
tribunal was biased.” On the evidence of the tweets relied on, “a doubt would inevitably arise in the mind of the fairminded and informed observer as to whether the lay member would in fact be able to approach the task required of


-----

the Employment Appeal Tribunal with an entirely open mind.” Accordingly, Mx Lord would be recused from the
hearing.

Two decisions are reported this month on aspects of immunity from legal liability. In _Basfar v Wong_ _[[2022] IRLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824W-00000-00&context=1519360)_
_[879, a national of the Philippines worked as a domestic worker in the household of a member of the diplomatic staff](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824W-00000-00&context=1519360)_
of the Kingdom of Saudi Arabia in the UK. She claimed to have been trafficked to the UK and forced to work for the
diplomat and his family in conditions of **_modern slavery. She brought an employment tribunal claim against the_**
diplomat for unpaid wages and breaches of employment rights. The diplomat sought to have the claim struck out on
the ground that he has diplomatic immunity from suit. An employment tribunal declined to strike out the claim on
the assumed facts. The EAT allowed an appeal but granted permission for a leapfrog appeal directly to the
Supreme Court. Under Article 31(1)(c) of the Vienna Convention on Diplomatic Relations 1961, diplomatic agents
are generally immune from the civil jurisdiction. There is, however, an exception for civil claims relating to “any
professional or commercial activity exercised by the diplomatic agent in the receiving State outside his official
functions”. The central issue before the Supreme Court in this case was whether exploiting a domestic worker in the
manner alleged constitutes “exercising” a “commercial activity” within this exception. The Supreme Court ruled by
three to two that if the assumed facts were proved, there would be no diplomatic immunity. According to the
majority (Lords Briggs, Leggatt and Stephens), “exploiting the labour of a domestic worker for financial gain is a
commercial activity exercised by the diplomatic agent outside his official functions.” It is not comparable to ordinary
employment. In this case, on the assumed facts, the diplomat “made a substantial financial gain from his
exploitation of Ms Wong's labour, albeit not in cash but in money's worth.” The judgment of the employment tribunal
refusing to strike out the claim was reinstated.

In contrast to diplomatic immunity at issue in _Basfar, which covers individual diplomats, the doctrine of_ **state**
**immunity provides for the immunity of foreign states from the jurisdiction of the domestic courts. The rule applies in**
employment if an employment claim arises out of an inherently sovereign or governmental act of the foreign state.
The two claimants in Webster v United States of America _[[2022] IRLR 836 were civilian employees at United States](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66C9-VW33-GXF6-824R-00000-00&context=1519360)_
airforce bases in Britain. Mrs Webster was a records manager, Miss Wright was a firefighter. They sought to bring
employment tribunal claims against the US Government. The tribunal held that both claimants were prevented from
bringing their claims by the doctrine of state immunity. As HH Judge James Tayler explains dismissing the appeals,
“there will be some roles that inherently involve sovereign or governmental functions, some that inevitably do not
(such as domestic workers) and others which may or may not, depending on an analysis of whether the functions
that are actually undertaken by the individual are sufficiently close to governmental functions …” In this case, the
roles and functions of the claimants put them in that middle category. “Determining which side of the line an
employee in the middle category falls is inherently a matter of factual assessment that is for the employment
tribunal … I do not consider that the claimants are able to establish that the employment judge erred in his analysis
of whether state immunity applied. He reached a factual determination that was open to him.”

_Michael Rubenstein_

_Michael@Rubensteinpublishing.com_

**End of Document**


-----

