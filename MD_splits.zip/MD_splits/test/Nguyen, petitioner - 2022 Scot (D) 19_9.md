# Nguyen, petitioner 2022 Scot (D) 19/9

[2022] CSOH 70

Outer House, Court of Session

Lord Ericht

30 September 2022

**Scotland – Immigration – Asylum seeker – Judicial review – Shortage Occupation List ('SOL') – Refusal of**
**permission to work in occupations not specified in SOL**
Abstract

_Scotland – Immigration – Asylum seeker – Judicial review – Shortage Occupation List ('SOL'). Court of Session:_
_Dismissing a judicial review petition in which an asylum seeker challenged a decision to refuse him freedom to work_
_in occupations not specified in the SOL, the court held that the petitioner was seeking to bring under review the_
_same matter which was considered in R (on the application of Rostami) v Secretary of State for the Home_
_Department, where the restriction that employment could only be taken up if the relevant job was included in the_
_SOL was found to be lawful, and as there was no material change of circumstances which would permit the court to_
_depart from Rostami, that decision remained an accurate statement of the law and should be followed: the_
_respondent had considered all the circumstances the petitioner presented in his application and concluded,_
_consistent with her policy, that there were no exceptional circumstances such that she should grant him permission_
_to work beyond that envisaged in the Immigration Rules which she had already granted to him; that was a matter for_
_her discretion, it was a conclusion she was entitled to reach and she left nothing out of account in doing so._
Digest

The petitioner wished to work while awaiting the respondent's determination of his asylum application. The
respondent granted him permission to work, restricted to the list of occupations on the Shortage Occupation List
('SOL'), but refused him permission to work in occupations not specified in that list. The petitioner sought reduction
of that refusal. On 7 April 2021 the petitioner's solicitors applied on his behalf for permission to work as follows:
'Please note this client has been waiting over 12 months for a decision on his asylum case. Please now grant him
permission to work . . . Our client is finding failure to work is impacting on his mental health . . . He is in a state of
anxiety. He is a victim of trafficking. He was forced to work in China. He bears scars on his head from beatings he
received. He has none of the skills required for the Shortage Occupation List. Further to this, we would be grateful if
he could be afforded the opportunity to work outside of the Shortage Occupation List . . .' On 5 October 2021 the
respondent replied as follows: 'You have asked whether you may take employment while your application for
asylum is being considered. This letter is a grant of permission to work in principle pending you obtaining the
appropriate Application Registration Card . . . Please note that employment is restricted to posts listed on the
Migration Advisory Committee's (MAC) Shortage Occupation List (SOL) . . .' By letter dated 16 November 2021 the
petitioner's solicitors asked the respondent to reconsider the grant of permission to work in the decision dated 5
October, stating: 'In our submission the decision to restrict the grant of permission to work to the Shortage
Occupation List (SOL) is unlawful . . . By restricting the grant of permission it is submitted that the Secretary of
State has failed to pay attention to the particular circumstances of our client . . . The Secretary of State has failed to
adequately consider our client's history and the effect his trafficking experience has had on him, and the benefit he
would receive were he afforded permission to work outside of the SOL. In our submission the Secretary of State's
failure to grant discretionary leave to remain as a victim of trafficking/ modern slavery is also unlawful . . .' The


-----

respondent replied on 29 November 2021 stating: '. . . (i) We have spoken to the relevant team and they have
advised that they have decided not to exercise discretion in order to grant your client Permission to Work outside
the [SOL]. They have advised that despite your client's claim to have been trafficked and the impact this has had on
him, his circumstances are not different from other Asylum seekers, and do not justify a grant of Permission to Work
outside the [SOL]. (ii) Please find attached a copy of the decision letter dated 26 November 2021 setting out full
reasons for this decision. (iii) Consequently the decision to restrict your client's grant of Permission to Work to the

[SOL] is maintained.' The decision letter of 26 November 2021 stated: 'I have considered whether or not discretion
should be exercised in the applicants favour to grant permission to work (PTW) unrestricted to occupations on the
Shortage Occupation List (SOL). The Immigration Rules are designed to provide for the vast majority of those who
request permission to work, whilst their asylum claim is outstanding. Where the criteria under Paragraph 360 of the
Immigration Rules is not met, it will normally be justifiable to refuse such a request. However, the Secretary of State
has the ability to exercise discretion within such a consideration and the Secretary of State has the power to grant
permission to work unrestricted to occupations on the SOL . . . You assert that as the applicant is a victim of
trafficking, and due to the effect that his trafficking experience has had on him, he should be afforded permission to
work outside the SOL. The Mental Health Foundation report of 2016 entitled “Fundamental Facts About Mental
Health” states “A 2015 study found that one third of trafficked boys and girls had experienced physical or sexual
violence (or both) and, of those, 23% had sustained a serious injury. Mental health issues were common: more than
half of young trafficked survivors (56%) screened positive for depression, a third (33%) for an anxiety disorder and a
quarter (26%) for PTSD. 12% reported that they had tried to harm or kill themselves in the month before the
interview, while 15.8% reported having suicidal thoughts in the past month.” (page 44). Therefore, distressing as the
applicants situation is, this does not distinguish him from any other asylum seeking applicant who asserts they are a
victim of trafficking . . . Whilst it is noted that you assert that the trafficking experience has had an impact on him, it
is considered that the applicant is able to volunteer to work . . . Therefore PTW unrestricted to the SOL is refused . .
.' In this judicial review the petitioner sought reduction of the decision dated 26 November 2021. The list of shortage
occupations was set out in an appendix to the Immigration Rules. The list specified certain posts which required
particular qualifications or skill (eg engineers, scientists, programmers and software professionals). It also contained
occupations for which a high level of qualification or skill was not required (eg care assistant and care worker). The
respondent had a residual discretion to permit an asylum seeker to work in a job not specified on the SOL and had
published guidance to Home Office staff about handling requests for permission to work (Permission to work and
volunteering for asylum seekers, 4 May 2021). In relation to the residual discretion to permit asylum seekers to work
in a job not specified on the SOL, the guidance stated: 'Application of discretion. Where the Immigration Rules are
not met, it will be justifiable to refuse an application for permission to work unless there are exceptional
circumstances raised by the claimant . . . What amounts to exceptional circumstances will depend upon the
particular facts of each case. A grant of permission to work on a discretionary basis is expected to be rare and only
in exceptional circumstances. In cases involving victims and potential victims of trafficking the primary objectives of
the Council of Europe Convention on Action against Trafficking in Human Beings 7 (ECAT) will be a relevant
consideration, particularly with regards to their physical, psychological and social recovery . . .'

The petition would be dismissed.

The petitioner's main ground of challenge was directed at asylum seekers not being permitted to work while
awaiting an asylum decision. There was also a challenge to the reasons for the decision in this particular case. The
petitioner sought to bring under review the same matter which was considered in R (on the application of Rostami)
_v Secretary of State for the Home Department, namely: 'Under domestic rules, once an application has been_
pending for a year, an asylum seeker may apply to the Secretary of State for permission to take up employment.
However, if permission is granted, it is subject to the restriction that employment can only be taken up if the relevant
job is included on a list of specific occupations published by the Secretary of State from time-to-time (“the Shortage
Occupation List”, or “the SOL”).' That restriction was examined in detail in Rostami and found to be lawful. Counsel
for the petitioner sought to persuade the court that the increase in numbers of asylum seekers and the delay in
making decisions since the Rostami case constituted a change of circumstances which made it necessary that the
policy of restriction of permission to SOL be reviewed. However, that was a political issue which fell within the
province of the respondent. It was not a legal issue for a decision by a court. The law as set out in Rostami
remained the law. An increase in numbers of asylum seekers or delay in dealing with applications made no


-----

difference to the reasoning set out in _Rostami_ as to the public interest objectives of the restriction, or the wide
margin of appreciation enjoyed by the state in those matters of high policy. As there was no material change of
circumstances which would permit the court to depart from Rostami, that decision remained an accurate statement
of the law and should be followed. A further criticism of the restriction counsel for the petitioner made was that few
asylum seekers had the skills for the posts in the SOL. That was not a ground on which the court could depart from
_Rostami. There was nothing new in that criticism: it also applied at the time of Rostami. Indeed, since the date of_
_Rostami,_ it had become easier for asylum seekers to find a post in the SOL: the list had been expanded by the
addition of care jobs which required little by way of formal qualification. Counsel submitted that that made no
difference as asylum seekers would be excluded from those jobs because it would not be possible to obtain from
their home countries the information about criminal records needed for protection of vulnerable group checks in the
United Kingdom to obtain those jobs. That was patently not the case for all asylum seekers: in another judicial
review which the court had considered recently an asylum seeker was able to obtain employment as a carer
(Bakushev v Secretary of State for the Home Department _[2022] CSOH 67,_ _[2022 Scot (D) 12/9). Despite the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66R5-02X3-CGX8-02F7-00000-00&context=1519360)_
extensive arguments criticising the SOL restriction in r 360 of the Immigration Rules, the actual decision being
challenged in this judicial review was not made under r 360. It was a decision made in exercise of the respondent's
residual discretion to grant permission to work outwith r 360. The respondent's guidance made clear that the
residual discretion could be exercised in exceptional circumstances. What amounted to exceptional circumstances
would vary depending on the particular facts of each case. A grant of permission to work on a discretionary basis
was expected to be rare and only in exceptional circumstances. The petitioner wished the discretion to be exercised
in his favour due to the effect that his trafficking experience had on him. The respondent was entitled to find that
that did not distinguish him from any other asylum seeker who asserted that they were a victim of trafficking. The
quotation in the Mental Health Foundation 2016 report in the decision letter demonstrated that mental health issues
were common in trafficked boys and girls. The inclusion of that particular paragraph might have been an error by
the respondent, as the petitioner was an adult. However that error was not material, as the other paragraphs in the
same page of the report from which the quotation was taken made clear that mental health issues were common
among asylum seekers. The court did not accept the petitioner's argument that the respondent erred in looking for
exceptional circumstances in a cohort which was all the same. It was not the respondent but the petitioner who fell
into that error. The circumstances which the petitioner sought to categorize as exceptional (ie mental health issues)
were in fact not exceptional at all but were common. As mental health issues were common, the respondent was
entitled not to exercise the discretion which she had indicated would only be used in rare and exceptional
circumstances. The decision letter went on to explain that the petitioner was permitted to do voluntary work, which,
according to the letter, allowed the same benefits to mental health and helped with integration into society. Counsel
for the petitioner took issue with that and sought to draw a distinction between paid and unpaid work. The court did
not accept the proposition that work gave dignity and mental health benefits only if it was paid for. Useful work could
be of benefit to mental health whether or not it was paid. In any event, there was no evidence before the respondent
when the decision was made, nor before the court, that this particular petitioner's mental health would improve only
if he did work which was paid and not if he did work which was unpaid. The petition did not disclose any error of law
by the respondent. She considered all the circumstances the petitioner presented in his application. She concluded,
consistent with her policy, that there were no exceptional circumstances such that she should grant him permission
to work beyond that envisaged in the Immigration Rules which she had already granted to him. That was a matter
for her discretion, and was a conclusion she was entitled to reach. She left nothing out of account in doing so.

[R (on the application of Rostami) v Secretary of State for the Home Dept [2013] EWHC 1494 (Admin), [2013] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58NW-1681-DYBP-N0C9-00000-00&context=1519360)
_[(D) 130 (Jun) followed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58NW-1681-DYBP-N0C9-00000-00&context=1519360)_

**End of Document**


-----

