# R v BYA [2022] EWCA Crim 1326

Court of Appeal, Criminal Division

Simler LJ, Cheema-Grubb and Cockerill JJ

13 October 2022Judgment

**Benjamin Douglas-Jones KC for the Appellant**

**Andrew Johnson for the Respondent**

**Interpreter Ms Nancy Whitfield**

Hearing dates: 15 September 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**This judgment is deemed to have been handed down remotely on 13 October 2022 at 10.30 am**

**Lady Justice Simler:**

**Introduction**

1. This is an application for leave to appeal against a conviction on 17 November 2009, in the Crown Court
at Canterbury, following the applicant's guilty plea to an offence of possession of a false identity document
with intent, contrary to section 25(1)(c) Identity Cards Act 2006. She was sentenced to a term of 12
months' immediate imprisonment on the same day. That sentence resulted in deportation proceedings and
on 3 March 2010, she was served with a deportation order.

2. On 16 June 2010 the applicant claimed asylum and in an interview on 14 July 2010, she was found to
be a potential credible victim of trafficking. Her case was referred through the National Referral Mechanism
framework to the Competent Authority. On 18 November 2010 the Competent Authority concluded that
there were reasonable grounds to believe that she had been a victim of trafficking, and a subsequent
decision on 9 December 2010, found on the balance of probabilities, that there were conclusive grounds to
believe that she was a victim of trafficking. On 13 July 2011 it was agreed by the Secretary of State for the
Home Department that the applicant's deportation should not be pursued and on 25 July 2011, she was
granted three years' discretionary leave to remain. She subsequently pursued challenges to the grant of
limited discretionary leave by appealing to the First-tier and Upper Tribunals of the Immigration and Asylum
Chamber.

3. The applicant now seeks a lengthy extension of time (approximately ten years and ten months) for
leave to appeal against conviction. Her applications have been referred to the full court by the Registrar. Mr
Douglas-Jones KC has appeared on her behalf. The application is resisted by Mr Johnson on behalf of the
prosecution. We are grateful to both counsel for their assistance in resolving these applications, and for
the helpful written and oral submissions we received.

4. The applicant's case in summary is that she committed the offence against a background of being
smuggled from Ghana to the Netherlands to escape female genital mutilation by men who placed her into


-----

a position of debt bondage and thereby trafficked her. She was trafficked in the Netherlands for sexual
exploitation; re-trafficked to Spain to work as a prostitute after she had given birth to a child who was
removed from her by her traffickers; and forcibly further re-trafficked to the United Kingdom to work as a
prostitute. The commission of the index offence, at a time when she was seeking to escape her traffickers,
(men known as James and Komsoon) was borne out of the dominant force of compulsion of her trafficking
situation. Had the Crown Prosecution Service (“the CPS”) been aware of her trafficked status at the time of
the prosecution, the prosecution would or might well not have been maintained and her prosecution was
therefore an abuse of process of the court and her conviction is unsafe.

5. In pursuing this application, the applicant seeks to rely on fresh evidence (within section 23 Criminal
Appeal Act 1968) in the form of the First-tier Tribunal (“FTT”) and Upper Tribunal (“UT”) decisions relating
to her status as a victim of trafficking. The evidence comprises decisions of the FTT (Judge Baptiste) dated
22 December 2011; the FTT (Judge Saffer) dated 30 November 2016; and the UT dated 23 June 2017.
These decisions include evidence of the Competent Authority decisions, which are also relied upon. The
applicant also relies on Gogana statements, made by her and dated 10 August 2020, and made by
Philippa Southwell, dated 7 October 2020. We have read all the material de bene esse and are satisfied
that the nature and circumstances of the application lead to the conclusion that the criteria for receipt of
this evidence are all made out.

6. The respondent accepts there is credible evidence that the applicant is a victim of trafficking, and that
there is no proper basis on which to invite the court to depart from the Competent Authority's decision.
However, the respondent does not accept that she was subject to a level of compulsion such as to
effectively extinguish, or significantly diminish, her culpability. In particular, the respondent's case is that
although the nexus of compulsion to flee her traffickers was strong, the nexus of compulsion to leave the
UK and flee to the Netherlands was not. There was no evidence to suggest that she would have been
safer in the Netherlands than in the UK. The respondent accordingly invited the court to dismiss the
applications.

7. At the conclusion of the hearing we announced our decision to grant the extension of time sought and
leave to introduce the fresh evidence in this case. We allowed the appeal and quashed the conviction.

8. These are our reasons for reaching those decisions.

**The legal framework**

9. There is no dispute about the legal framework and principles applicable in this case.

10. The UK's international obligations in relation to the treatment of victims of trafficking and **_modern_**
**_slavery derive from the Council of Europe Convention on Action against Trafficking in Human Beings 2005_**
(referred to as “ECAT”) and the EU Directive on Preventing and Combating Trafficking in Human Beings
and Protecting its Victims 2011/36/EU (“the Directive”). The relevant obligations under ECAT and the
Directive (in particular, article 26 of ECAT and article 8 of the Directive) have been implemented
[domestically by the enactment of the Modern Slavery Act 2015 (“the 2015 Act”). Section 45 of the 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Act came into force with effect from 31 July 2015 and provides a defence for victims of slavery or trafficking
who commit certain offences under compulsion attributable to slavery or relevant exploitation.

11. Before section 45 came into force, and in the absence of any domestic statutory implementation of the
UK's international obligations under ECAT and the Directive, victims of trafficking who committed criminal
acts as a result of compulsion arising from trafficking were protected through CPS guidance on the
prosecution of offences by suspected victims of trafficking (and in particular, when and in what
circumstances a prosecutor could decline to proceed against such an individual); through the common law
defence of duress or necessity (where applicable); and through the court's abuse of process jurisdiction
enabling it to review CPS prosecutorial decisions and to stay proceedings as an abuse in an appropriate
case.

12. The law in this area has been set out in numerous cases. The core principles that apply were said in R
_v VSJ_ _[2017] EWCA Crim 36, [2017] 1 Cr App R 33 (“VSJ”) to be derived from R v LM [2010] EWCA Crim_


-----

2327, [2011] 1 Cr App R 12 (“LM”); R v N, R v Le _[2012] EWCA Crim 189; and R v L_ _[2013] EWCA Crim_
_991 (“L”). They were summarised in VSJ at [20]._

13. The appeals in LM concerned alleged failures of the CPS (proven in the case of some appellants in
_LM) to apply the CPS published guidance on the prosecution of victims of human trafficking, and the_
application of article 26. The effect of the special guidance issued to prosecutors by the CPS before 31
July 2015 was to require a three stage exercise of judgment: first, to consider if there is reason to believe
that the person has been trafficked; if so, secondly, where there is clear evidence of a credible common
law defence the case will be discontinued in the ordinary way on evidential grounds; thirdly, and
importantly, even where there is no such evidence but the offence may have been committed as a result of
compulsion arising from the trafficking, prosecutors should consider whether the public interest lies in
proceeding to prosecute or not: see to this effect LM at [10].

14. The CPS guidance emphasised the duty of the prosecutor to be proactive in causing enquiries to be
made. Factors bearing on the public interest were identified as including: whether there was a credible
suspicion that the suspect might be a trafficked victim; the nature and extent of his or her role in the
criminal offence; whether the offence was committed as a direct consequence of their trafficked situation;
whether there was violence, threats or coercion used on the trafficked victim to procure the commission of
the offence; and whether the suspect/victim was in a vulnerable situation or put in considerable fear.

15. This court has emphasised in all these cases that the protection obligation under article 26 of ECAT
does not require blanket immunity from prosecution for victims of trafficking. There is normally no reason
not to prosecute, even if the victim of trafficking has previously been a trafficked victim, if the offence
appears to have been committed without any reasonable nexus of compulsion (in the broad sense)
occasioned by the trafficking: LM at [14(iv)].

16. However, in cases where there is some nexus with the trafficking, then prosecution will generally
depend on factors including the gravity of the offence, the degree of continuing compulsion and the
alternatives reasonably available to the defendant. Each case is inevitably fact specific and these
questions are to be approached with the greatest sensitivity.

17. The question is the extent to which the offence with which the trafficked victim is charged is integral to
or consequent on the exploitation of which he or she was the victim. As to that, in L, this court said:

“33. We cannot be prescriptive. In some cases the facts will indeed show that he was under levels of
compulsion which mean that in reality culpability was extinguished. If so when such cases are prosecuted,
an abuse of process submission is likely to succeed. That is the test we have applied in these appeals. In
other cases, more likely in the case of a respondent who is no longer a child, culpability may be diminished
but nevertheless be significant. For these individuals prosecution may well be appropriate, with due
allowance to be made in the sentencing decision for their diminished culpability. In yet other cases, the
fact that the respondent was a victim of trafficking will provide no more than a colourable excuse for
criminality which is unconnected to and does not arise from their victimisation. In such cases an abuse of
process submission would fail.”

18. In R v GS [2018] EWCA Crim 1824, [2019] 1 Cr App R 7 (“GS”), the relevant principles were
summarised at [76] and this court made clear that there is no closed list of factors bearing on the
prosecutor's discretion to proceed, emphasising that generalisation is best avoided:

“(iv) There is no closed list of factors bearing on the prosecutor's discretion to proceed against a victim of
trafficking. Generalisation is best avoided. That said, factors obviously impacting on the discretion to
prosecute go to the nexus between the crime committed by the defendant and the trafficking. If there is no
reasonable nexus between the offence and the trafficking then, generally, there is no reason why (on
trafficking grounds) the prosecution should not proceed. If there is a nexus, in some cases the levels of
compulsion will be such that it will not be in the public interest for the prosecution to proceed. In other
cases, it will be necessary to consider whether the compulsion was continuing and what, if any, reasonable
alternatives were available to the victim of trafficking. …”

19 The question for this court was encapsulated in paragraph 76 (v) in the following terms:


-----

“(v) As always, the question for this court goes to the safety of the conviction. However, in the present
context, that inquiry translates into a question of whether in the light of the law as it now is (this being a
rare change in law case) and the facts now known as to the applicant (having regard to the admission of
fresh evidence) the trial court should have stayed the proceedings as an abuse of process had an
application been made. This question can be formulated indistinguishably in one of two ways which
emerge from the authorities: was this a case where either: (1) the dominant force of compulsion, in the
context of a very serious offence, was sufficient to reduce the applicant's criminality or culpability to or
below a point where it was not in the public interest for her to be prosecuted? or (2) the applicant would or
might well not have been prosecuted in the public interest? If yes, then the proper course would be to
quash the conviction. …”

20. Accordingly, when dealing with victims of trafficking, the existence and extent of any nexus between
the offence in question and the trafficking and exploitation to which the defendant has been subject is an
important consideration. Where prosecution authorities have applied their minds to the relevant questions
in accordance with the applicable CPS guidance, it is not generally likely to be an abuse of process to
prosecute unless the decision to do so is clearly flawed, and courts will be more reluctant to intervene in
such circumstances. By contrast, where this question has not been considered by the prosecution at all,
the court may be readier to intervene.

21. The fact that the prosecution was an abuse of process is one of the categories of case in which it is no
[bar to a successful appeal that the defendant pleaded guilty: see R v T [2022] EWCA Crim 108 at [160]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)
and R v AAD [2022] EWCA Crim 106 at [156].

**The basic facts of the offence and events post-conviction**

22. On the evening of 31 October 2009, the applicant was stopped by French immigration officers
conducting document checks at the Channel Tunnel in Folkestone. During the check the applicant
presented the officers with an authentic Dutch identity card in the name of Comfort Yaa Addae, with a date
of birth of 14/06/83. It was apparent that the applicant bore little resemblance to the photograph. She was
detained and officers from Kent Police were contacted and attended. They asked the applicant for her
name to which she responded by providing them with her true name and a date of birth. She was arrested
and made no reply to caution.

23. The applicant was interviewed under caution on 1 November 2009. It appears from the custody record
of 1 November 2009 that “Malcolm Wilkinson” was “contacted and asked to attend for [9.30 hours]”. The
applicant was recorded as having had a consultation with her legal representative before her interview
under caution at 10.15am. In interview she had a legal representative present. She said that she
presented the document to the French officer knowing that she was not entitled to it and that it did not
belong to her. It was her intention to deceive and she was sorry for what she had done. She declined to
answer any further questions regarding the offence or her status in the UK.

24. The applicant was charged with possessing a false identity document with intent and appeared before
the Magistrates Court on 2 November 2009. The justices sent her to Canterbury Crown Court for trial. She
appeared before HHJ van der Bijl on 17 November 2009 and pleaded guilty to the offence charged.

25. Criminal papers (including transcripts of proceedings) regarding the applicant's case have been
destroyed. She was represented in the Crown Court by Laura Preston-Hayes, a solicitor-advocate,
instructed by Martyn Hewett Solicitors. In response to McCook enquiries, the solicitors have said they are
no longer in possession of any papers. The respondent is also no longer in possession of any papers. As a
result, there is no record of the instructions the applicant gave her lawyers at the time or the advice she
received.

26. On 3 March 2010 the applicant was served with a deportation order. On 16 June 2010 she claimed
asylum. On 14 July 2010, the applicant was interviewed in connection with her asylum claim. On 18
November the Home Office acting as Competent Authority found that there were reasonable grounds to
believe that she was a victim of trafficking. On 9 December 2010 the Competent Authority found that on


-----

the balance of probabilities there were conclusive grounds to believe that the applicant was a victim of
trafficking. The reasons for these decisions are set out in decision minutes, but these too, are not available.

27. On 13 July 2011 it was agreed by the Secretary of State for the Home Department (“the SSHD”) that
the applicant's deportation should not be pursued and on 25 July 2011 she was granted three years'
discretionary leave to remain. On 20 September 2011 the SSHD accepted that the applicant was a victim
of trafficking but not that she would be at risk if returned to Ghana. The applicant had submitted that she
feared being forced back into prostitution if she returned and was fearful of the stigma and persecution if it
were discovered that she had been forced to work as a prostitute in Europe.

28. The applicant appealed that decision. There was a hearing in the FTT at which the applicant gave
evidence and was cross-examined. The FTT (Judge Baptiste) made clear that he “fully accept[ed] [her]
account as to her experience in terms of being trafficked”. He concluded, however, that she had not shown
substantial grounds that she would face a real risk of serious harm, as a result of her trafficking and
prostitution, if she were to return to Ghana. As a result, he dismissed her asylum and humanitarian
protection appeals.

29. On 23 July 2014 the applicant made a human rights application for an extension of her leave to remain
in the UK on the basis of her private life and the fact she was a victim of trafficking. The SSHD refused the
application on 24 March 2016. The applicant appealed again. Her appeal was dismissed by the FTT
(Judge Saffer) on 30 November 2016. However, notwithstanding that decision, Judge Saffer expressly
accepted her account of being trafficked and re-trafficked and granted her anonymity on the basis that she
had been a victim of trafficking.

30. On 28 March 2017 the applicant was granted permission to appeal to the UT, but on 23 June 2017,
the UT (Judge Hanson) dismissed the appeal and found that there had been no material error of law in the
FTT's decision. Again, the judge accepted notwithstanding, that she was a victim of trafficking.

31. Ms Southwell is the solicitor with conduct of the applicant's case. She has set out in a witness
statement, the detailed chronology of events that followed the applicant's conviction and explained the
difficulties and delays in progressing her case. In a subsequent statement she explained that Howells
were instructed as the applicant's immigration solicitors and also gave advice on appeal against conviction.
They advised negatively in 2015 and closed the criminal file but continued to act in the immigration
proceedings. The conviction continued to impact the applicant's life, including on her ability to work, and
her case was referred to Birds Solicitors and to Ms Southwell to look again at the conviction in 2018.

32. Birds Solicitors have complied with their professional duties in accordance with the guidance in
_McCook. The applicant waived privilege. Questions were asked of all those understood to have appeared_
on her behalf in the criminal proceedings, and of the firm at which Mr Wilkinson worked. However, Martyn
Hewitt responded that paper files prior to 2010 were not retained by the firm, and there is no electronic
material held in the applicant's case.

**Evidence of the applicant**

33. The applicant seeks to rely on fresh evidence set out in two witness statements she has made. In the
first statement she seeks to make corrections to answers given in her asylum screening interview and in
her substantive asylum interview (neither of which are now available). In relation to her conviction, she
states, “I have one conviction for having a false identity document. I only used the document because I was
_not happy with James and Komsoon and I wanted to get away from them. I was told by James and_
_Komsoon that if I tried to reveal anything to the police they would arrest me and they would put me in_
_prison so I was scared. I was going to them for help.”_

34. In her second statement, dated 15 September 2020, prepared for the purposes of the appeal, she
gave a short summary of her account of how she came to be in, and then came to see to leave, the UK:

“ They had originally brought me to Holland, then Spain and then brought me to the UK. I was being
exploited in Holland as a prostitute. They told me that I was not making them enough money and they were
going to bringing me to the UK. They said that I would need to work when we arrived. They had been


-----

violent towards me and beat me previously. They beat me many times in Holland. I also got pregnant and
gave birth whilst in Holland.

When we got to the UK, I continued to pay them money, but they still said that I owed them, and the debt
never went, they said I owed them €45,000. I couldn't cope anymore with the sexual exploitation and I
could not make enough money to pay them back, they were using me as a prostitute.

They bought me to the UK by car. I had been in London for 6 months before I escaped. I was living in a
property that they had provided. During this period, I did not go anywhere. I was allowed to go to the shops
to buy food if they directed. They always took my money. They would bring men to the house up to five
times a day. The only time I could leave was to go to the shops to get food. They would give me money for
this, and I was to come straight back. They told that if I went to the police or told anyone that they would
bring me back to the home country. I was frightened as I had initially run away from my home village as
they wanted to cut my genitals, this is why I tried to leave. I was also afraid that I would bring shame on my
family for what I was being made to do.

I travelled by coach and was arrested at Dover. I had the passport that they had provided on me when we
travelled to the UK.”

35. In relation to the criminal proceedings, the applicant states that she has no recollection of being
advised about “anything to do with human trafficking or **_modern slavery law” and was unaware of the_**
possibility of being able to appeal until she was referred to specialist appellate solicitors by her immigration
solicitors. She says that the conviction has an ongoing impact on her life, in particular in relation to her
ability to obtain employment, to regularise her immigration status and to restore her family ties. She also
anticipates that her conviction will hinder any future application she might seek to make to obtain British
citizenship.

36. The applicant's account of her trafficking (as set out above) was tested in evidence before the FTT and
accepted. She gave evidence with the assistance of a Twi interpreter.

37. The applicant also gave evidence at the hearing before this court. She did so again with the assistance
of an interpreter. She speaks Twi and even now, understands and speaks very little English.

38. Her evidence was consistent with the accounts she has given previously. She explained that she was
brought to the Netherlands by James and Komsoon and forced to work as a prostitute. She did not try to
escape then or later in Spain, though she told James and Komsoon that she was going to report them, and
they told her they were the people who could report her. In England they said she would be arrested if she
went to the police. She knew nobody in England and did not know her way around. She spoke and
understood no English when she got here.

39. As for events leading to her arrest, she explained that she found the identity card in the house a week
before her escape. It was not her card but it was the one used by James and Komsoon to bring her into
the Netherlands. They kept the card, but she found it shortly before her attempted escape. She was given
money by James and Komsoon from time to time, to go shopping for food in the UK. She decided to use
the card, and the money for the shopping to escape. She was trying to go to the Netherlands because she
believed her child was there and she knew a few people there as well. She did not go to the police or
authorities having been warned that if she reported James and Komsoon to the police, she was the one
who would be arrested.

40. In cross-examination, the applicant explained that she walked to Milton Keynes coach station, which
was nearby. She asked for a ticket to Holland and paid using the shopping money. She could not recall
how much it cost because of the passage of time.

41. She explained that the other reason she wanted to go to Holland was because she was “also very tired
_of working as a prostitute”. She agreed that looking for her child was the main reason for wanting to go to_
Holland but she repeated that “also being a prostitute, I was very tired of working for those people, working
_as a prostitute”. She had been exploited in Holland but at the time all she thought about was getting there._
She said she “knew some people there and they would be able to help me”. They were people met


-----

through prostitution and though they had not helped her before, she was going to tell them what she was
going through and “then maybe they might be able to help me”. She had not met people through
prostitution in the UK who might help in the same way.

42. She used the Netherlands identity document, to get into Holland, Spain and the UK. This was the only
document that had been used by or for her.

43. Having read and heard the applicant's fresh evidence, we are satisfied that this is a case where it is
necessary to admit the new evidence. The accounts given by the applicant are credible and the criteria in
section 23 Criminal Appeal Act 1968 are satisfied. We have applied the guidance concerning the
circumstances when an appeal against conviction can be allowed following a guilty plea, and this case
comes within the categories when an appeal is possible. We consider it appropriate to allow the applicant
to advance what are, in effect, fresh instructions about the facts of the offending for the purposes of this
appeal.

**Submissions of the parties**

44. Mr Douglas-Jones KC for the applicant submitted that the applicant was a victim of trafficking but her
status as such was ignored or overlooked by the police and CPS. No or no sufficient steps were taken to
address the manifestly apparent indicators of human trafficking so that she entered a guilty plea without
her status as a potential credible victim of trafficking being explored in the context of the regime that then
existed. Had the CPS been aware of the applicant's full history and the full context of the offence, they
would or might well not have pursued the prosecution. Either the dominant force of compulsion was
sufficient to reduce the applicant's culpability to a point where it was not in the public interest for her to be
prosecuted, or she would or might well not have been prosecuted in the public interest. She was using the
identity document of someone else to return to the Netherlands to escape her trafficking situation in the
UK. The commission of the offence was borne out of the dominant force of compulsion of her trafficking
situation.

45. He relied on all the fresh evidence material to support of these submissions. In particular, her account
of having left the family home in Ghana because she was fearful of being forced to undergo female genital
mutilation and the trafficking and forced prostitution that followed. The FTT and UT decisions show that
the applicant was a victim of trafficking by virtue of the debt bondage into which she was placed,
associated with her travel to the Netherlands. They show she was re-trafficked in the Netherlands as a
prostitute (for sexual exploitation), and again in Spain (after her child – the product of rape – was removed
from her by her traffickers) and again in the UK. The offence was committed to remove herself from her
trafficking circumstances. The nexus of compulsion was very strong.

46. Mr Johnson resisted the appeal. He submitted that the conviction is safe. He accepted that there is
credible evidence that the applicant was a victim of trafficking and in light of the immigration tribunal
decisions made in her case, the respondent does not consider that there is a proper basis on which to
invite the court to depart from the Competent Authority's decision that she is a victim of trafficking. He did
not accept, however, that she was subject to a level of compulsion such as to effectively extinguish, or
significantly diminish, her culpability. He relied on the absence of any compelling evidence from the
applicant about why her efforts to escape her traffickers compelled her to seek to leave the UK. A desire to
travel back to the Netherlands because that was a country where she knew people, as set out in the first
FTT judgment, was not sufficient for the court to conclude that her culpability was so extinguished or
diminished. The same was true of her expressed desire to return there to seek her son. While the nexus of
compulsion to flee her traffickers was strong, he submitted that the nexus of compulsion to leave the UK
was not. There was no evidence to suggest that she would have been safer in the Netherlands (especially
since she had been forced to work there as a prostitute) than in the UK. The requisite level of compulsion
could not be made out and therefore the applications should be refused. He submitted that if, however, the
court held that the relevant nexus and compulsion were established, the public interest would not have
required a prosecution in any event.


-----

47. With regards to the extension of time, he accepted that the conviction appears to have some impact
upon the applicant's ability to obtain employment and her immigration status but submitted that the extent
of the impact is insufficient to amount to a substantial injustice.

**Our analysis and conclusions**

48. We have considered the applicant's evidence for ourselves, together with the decision of the
Competent Authority and the findings made by the immigration tribunals in her case. Judge Baptiste fully
accepted the applicant's account of being trafficked, having heard her evidence and seen it tested. We too
accept her account and are satisfied that the applicant is a victim of trafficking by virtue of the debt
bondage into which she was placed, associated with her travel to the Netherlands. She was re-trafficked in
the Netherlands, in Spain, and in the UK for sexual exploitation. She was sexually exploited and subjected
to sexual abuse (including daily rapes) over a lengthy period, having fled her family home because of the
threat of female genital mutilation.

49. Next we must consider whether or to what extent she was acting under compulsion when she used a
false identity document to remove herself from the UK and, if so, whether there was a sufficient nexus
between that conduct and the slavery or exploitation to which she had been and was then being subjected.

50. From both her written and oral accounts of her experiences it is clear that right up to the time of her
escape the applicant was under the control of the traffickers who had brought her to this country (via the
Netherlands and Spain) and forced her to work as a prostitute in each jurisdiction for over six years. As she
explained, she was physically abused, threatened and compelled to stay at the house they maintained for
prostitution. The effect of these experiences upon her must have been to cause significant trauma. When
she came to this country she knew nobody save for her traffickers, to whom she was in debt bondage. She
spoke no English and had very little understanding of English. She must have felt isolated and alone. She
was obviously vulnerable. She knew nobody in the UK to whom she could turn for help. The traffickers
told her that if she went to the police, she was the one who would be arrested.

51. This is not a paradigm case in the sense that the compulsion the applicant was under did not lead
directly to the offending. On any view however, the offence was committed in the course of her forced
prostitution and was a consequence of it. There was a strong nexus of compulsion to flee her traffickers (as
the respondent conceded) and Mr Johnson conceded that there was a nexus between her trafficking and
the offence.

52. The question is whether on her account, the level of compulsion reached the threshold such that her
culpability or criminality was significantly diminished or extinguished. We accept the evidence given by the
applicant that the identity card she used was kept by her traffickers, but she found it a week before the
escape. With money given to her to do the shopping, she found her way on foot to the coach station at
Milton Keynes and bought a coach ticket to the Netherlands to escape the traffickers. It is true that in
deciding to escape, the applicant decided to travel to the Netherlands, in part to look for her son. Her
evidence was frank on this point. But she made clear, in evidence that was unrehearsed and rang true, that
in seeking to go to the Netherlands, she was also seeking to escape her traffickers, her debt bondage and
her forced prostitution. Her decision to escape her traffickers by travelling out of the jurisdiction to the
Netherlands must be viewed realistically in light of her particular circumstances as we have described
them.

53. As we have said, the applicant feared arrest if she went to the police. She was frightened of her
traffickers. She knew nobody in this country as we accept, and she spoke little or no English. On the other
hand, she had been to the Netherlands before, and although she had been exploited there, her traffickers
were now in the UK. In that sense, we can see that she might have thought she would be safer in the
Netherlands than here in the UK. Moreover, we have no reason to doubt her evidence that as a result of
her forced working as a prostitute in the Netherlands when she was first trafficked, she had come to know
people in the Netherlands who she believed might help her. Her child's location therefore provided only
part of the reason for going to the Netherlands; and any attempt to escape her traffickers by leaving the
jurisdiction for any other location must have involved that document. The Dutch identity card she used was


-----

the only identity card she had ever used (and it had been used successfully by the traffickers to bring her
into the Netherlands in the first place).

54. This was a woman who had been subjected to daily rape and other sexual abuse over a period of
years, and the exploitation was continuing at the point of her attempted escape. Her vulnerability and
isolation meant that she had little or no realistic options for seeking help. Although her decision to go to the
Netherlands was also strongly motivated by the fact she believed her son to be there, nonetheless, we are
satisfied that there was a strong nexus between the crime and the trafficking in this case, which
considerably diminished the applicant's culpability. The compulsion arose directly from her trafficked
circumstances and not just the trafficking. This is a case where compulsion caused her to act to remove
herself from forced sexual exploitation by fleeing to the Netherlands. There was a direct nexus between the
two on the facts of this case.

55. We recognise that the delay in these proceedings has hampered the respondent's ability to investigate
what contemporaneous consideration was made of trafficking or the public interest in this case. However,
the speed with which she was processed, interviewed by police and then prosecuted following her arrest
gives rise to the inference that there was no such, or at least, inadequate consideration in our view. The
circumstances of her arrest, as a woman from Ghana travelling on a false identity card, should have raised
alarm bells. While the applicant may well have hidden her trafficked status at the time of her arrest, it is
likely that indicators of human exploitation and/or trafficking would have existed when she was introduced
into the criminal justice system. A proactive approach to identification is required to identify possible
credible victims of trafficking as victims of trafficking. There is nothing to indicate that a proactive approach
was adopted here. If these matters were considered at all, there was no referral to the Home Office (under
the National Referral Mechanism) and any consideration would have been without the benefit of what is
now known about the applicant's history, the abuse to which she had been subjected and the effect it had
on her. Accordingly, we consider it open to this court to consider the public interest question without
trespassing on territory already appropriately considered by the prosecuting authority.

56. Whether it would have been in the public interest to prosecute the applicant for this particular offence if
the full circumstances had been known is inevitably a fact sensitive question that must be approached,
“with the greatest sensitivity”. We have concluded that her culpability was significantly diminished. The
offence was relatively minor: the card was used to leave the UK on a single occasion and in the
circumstances described. She had no previous convictions and there was no evidence of any previous
unlawful activity. If what is now known about the applicant's status as a victim of trafficking had been
known by the CPS during the criminal process in 2009, we consider that the CPS “would or might well” not
have prosecuted her because her criminality, or culpability was significantly diminished, and in the
circumstances of her case, involving exploitation for prostitution, there was no realistic alternative available
to her. The public interest did not require a prosecution of this particular offence on the facts of this case.

57. It is common ground that this is a change in law case: see GS at [59]. The change in the law relates to
the way in which it was understood that the international instruments relating to trafficking would be
applied. In light of the conclusions we have reached thus far, and having regard to the chronology of
events since the applicant's conviction and the statements of the applicant and Philippa Southwell, we
consider that leave should be granted notwithstanding the lengthy extension of time sought. The conviction
in this case was secured in consequence of an inadvertent breach of international law protections that
should have been afforded to the applicant. This in itself constituted a substantial injustice and the impact
of her conviction continues to cause substantial injustice to her to this day.

58. In relation to the application for anonymity, the normal rule is open justice. Anonymity orders can only
be justified where strictly necessary. We have scrutinised this application carefully in light of the principles
summarised most recently in _R v AAD. The applicant is accepted to be a victim of trafficking with the_
inevitable specific risk of harm that goes with such a finding. Anonymity orders have been made by the
immigration tribunals in her case. We are satisfied that there are no less restrictive means (short of an
anonymity order) of addressing the risk of harm. Balancing all considerations, we concluded that it is
appropriate to grant the applicant anonymity, as ordered provisionally by the Registrar.


-----

59. In all the circumstances, the conviction is unsafe, notwithstanding the guilty plea. We grant leave to
appeal out of time and allow the appeal. The conviction is quashed.

**End of Document**


-----

