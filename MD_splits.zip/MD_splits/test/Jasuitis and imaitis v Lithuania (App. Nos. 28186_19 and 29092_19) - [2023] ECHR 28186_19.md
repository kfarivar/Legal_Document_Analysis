# Jasuitis and Šimaitis v Lithuania (App. Nos. 28186/19 and 29092/19) [2023]
 ECHR 28186/19

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE BÅRDSEN (PRESIDENT), JUDGES ILIEVSKI, KŪRIS, KOSKELO, KRENC, SÂRCU, DERENČINOVIĆ;
AND BAKÝRCÝ (SECTION REGISTRAR)

21 NOVEMBER 2023

12 NOVEMBER 2023JUDGMENTINTRODUCTION

1. The case concerns the applicants' complaint that their conviction on charges of trafficking in human beings had
not been foreseeable and had therefore been in breach of Article 7 of the Convention.
**THE FACTS**

2. The applicants were born in 1988; they live in Šiauliai. They were represented by Mr G. Danėlius, a lawyer
practising in Vilnius.

3. The Government were represented by their Agent, Ms K. Bubnytė Širmenė.

4. The facts of the case may be summarised as follows.

5. As specified by the Government (referring to a decision delivered by the Šiauliai Regional Court on 16 January
2017; see also paragraphs 11-18 below), on an unspecified date the applicants placed the following job
advertisement online:

“Web model job offer for attractive girls – can be main or additional job, with a [flexible] schedule; there are no
special requirements – just need to be communicative, have the basics of English, [and] know how to and to
want to communicate with people. [T]he nature of the work: online communication with people from different
countries of the world in English. Send a short résumé with a photograph by e-mail to ewbmodels@gmail.com;
salary depends on your desire and efforts, [and] ranges from LTL 2,000 [approximately EUR 580] to LTL 5,000

[approximately EUR 1,450]; the job is only for persons aged 18 and up).”

6. Between September 2012 and August 2013 the applicants hired a number of young women to work as “web
models”.

The women were hired to communicate with clients over the Internet. The applicants signed contracts with the
women and provided some of them with computers, video cameras and other equipment. All the women worked in
Lithuania – some from their own apartments, others from apartments which were rented by the applicants and
provided to them. The applicants paid the women in cash or by bank transfer.

7. On 19 April 2013 one of those women, P.Ch., born in 1994 – who at the time in question was still a high school
student – lodged a complaint with the police, stating that in January 2013 she had seen the online advertisement
and had then made contact via Skype with one of the applicants, who had explained to her the nature of the job –
namely, to communicate with persons online while appearing in front of the camera. Initially, she had agreed and
had then been taken to an apartment in Panevėžys. Two weeks later she had been asked by the applicants to show
her clients her naked body, to dance striptease, to use sex toys and to do everything the clients requested. She had


-----

refused, but the applicants, by threatening her and by using psychological violence, had forced her to undertake
those actions. P.Ch. asked that the suspects be brought to justice.

8. On 21 April 2013 the police opened a pre-trial investigation based on the suspicion that a crime of trafficking in
human beings, set out in Article 147 of the Criminal Code (see paragraph 57 below), had been committed.

9. As summarised by the Government, who referred to the bill of indictment, the Šiauliai Regional Court's judgment
and the Supreme Court's ruling (see paragraphs 49-53 below), in the course of the pre-trial investigation into the
alleged trafficking in human beings the pre-trial investigation had identified the following women.

P.Ch., born in 1994, had just turned 18 when she was recruited by the applicants. At the relevant time she was in
her final year in high school and had been living separately from her parents, who had been undergoing a divorce.
Following her recruitment, she had been threatened and required to work longer hours than had been agreed;
owing to the treatment to which she had been subjected to, she had become desperate and had tried to commit
suicide; she had subsequently been treated in a psychiatric facility.

D.D., born in 1993, had been offered the possibility of sharing (with other “web models”) an apartment which that
would be rented by the applicants for work; she had been screamed at when she had not made enough effort to
undress and flirt with her clients.

V.T., born in 1993, had been raising a child alone, had lacked money to buy essentials, and had often argued with
her mother.

S.S., born in 1992, had been in a difficult financial situation, as had J.Š., born in 1990, whose mother had been sick,
and who had had two minor siblings who had needed her help.

J.A., born in 1989, had had a poorly paid job and had been living in an apartment provided under a social
assistance scheme.

T.M., born in 1993, had been raising her two-and-a-half-year-old child alone; she had given birth while still in high
school and had been short of money with which to buy essentials. When she had been working for the applicants,
she had been monitored; the applicants had several times visited her and had urged her to work more – shouting at
her and humiliating her, including in front of her child. They had also demanded that she pay back the money that
she owed to the applicants; she had repaid that money and then ceased to work for them. In addition, they had
offered her work as an escort girl abroad, which she had refused. When the police had started their investigation,
T.M. had been contacted by the first applicant, who had been trying to meet up with her, but she had refused,
because she had been afraid of the applicants.

V.R., born in 1989, had started to work in an apartment that had been rented in T.M.'s name. The applicants had
been asked to earn at least 350 US dollars (USD) per week and when both of them had made that amount in a
couple of hours and had stopped working the applicants had come to their apartment and had demanded that the
continue to work; they had threatened T.M. and had shouted at her. V.R. had also been offered the possibility of
participating in the recording of pornographic video clips. When T.M. had informed the applicants that she would not
be working for them anymore they had tried to obtain information from V.R. about T.M.'s private life.

R.G., born in 1985, had been raising three children on her own and had had no job, and had lacked money for
essentials. She had found out about the above-mentioned offer of a job as a “web model” on the Internet and had
been tempted by the salary offered; she had accordingly contacted the applicants and had subsequently met the
first applicant. She had started work but had soon realised that she wouldn't actually receive the promised sum;
moreover, she had found it intolerable that the first applicant had been instructing her on how to dress and how to
behave, and she had decided not to work for the applicants anymore. When the first applicant had noticed that she
was no longer online he had contacted her and had been angry, speaking in a raised tone, so she had simply hung
up. Afterwards she had received several threatening text messages from the first applicant, indicating that he was
aware where she lived. R.G. had told him that she had not been paid for the work that she had performed.


-----

A.M., born in 1994, had been contacted through a dating site (in her profile section she had received an
advertisement for a job as a “web model”). She had met the second applicant, who had told her that the job would
only involve having conversations with people over the Internet. After she had started to work she had realised that
the work would involve pornography, so she had refused to continue with the work and had paid back all the money
that she had received.

10. According to an internal police memorandum (tarnybinis pranešimas) dated 14 August 2013, the police started
an additional pre-trial investigation as they had received a complaint from one of the victims, V.R., who earlier that
month had received telephone calls from two different telephone numbers during which she had been asked to
meet and to discuss her testimony in connection with the above-mentioned pre-trial investigation into alleged
trafficking in human beings.

It appears from the police memorandum, V.R. had been given a recording device by the police.

V.R. had then met with the person who had made the telephone call, notably the first applicant, who had told victim:
“Now this is going to happen: you will tell the police that there has been no violence, that you have not been
showing your naked body, and that you have not been beaten.” The first applicant had then given V.R. 200
Lithuanian litas LTL ( 60 euros (EUR)) in order to persuade her to change her testimony. The police considered that
in this manner both applicants had sought to influence the victim V.R. to change her testimony. Their actions had
constituted the crime of influence on a victim, under Article 233 § 3 of the Criminal Code (see paragraph 57 below).
_I. THE ŠIAULIAI REGIONAL COURT_

11. On 16 January 2017 the Šiauliai Regional Court found the applicants guilty of trafficking in human beings
(Article 147 § 2 of the Criminal Code, see paragraph 57 below), and of exploitation for the provision of forced labour
or services (Article 147[1 ]§ 1 of the Criminal Code), as well of using a person's forced labour or services (Article 147[2 ]

§ 1 of the Criminal Code, see paragraph 57 below).

12. The applicants were also found guilty of several other criminal acts: unlawful use of an electronic means of
payment (Article 215 § 1 of the Criminal Code), influence on a victim (Article 233 § 1 of the Criminal Code; see
paragraph 57 below), and possession of pornographic material (Article 309 § 1 of the Criminal Code).

In their applications before the Court, the applicants did not contest the lawfulness of those convictions.

13. The Šiauliai Regional Court established that the applicants, acting in an organised group and operating in
various towns in Lithuania between September 2012 and August 2013 – had agreed (i) to recruit (verbuoti) young
women to work as “web models” on a pornographic website by providing services of a pornographic nature to users
of that website, and (ii) to profit from those services, so that those women would be exploited for the purpose of
providing pornographic services. They had then (i) recruited D.D., S.S., A.M., G.Z. P.Ch., V.T., T.M., V.R., J.Š. J.A.
and R.G., and (ii) forced (vertė) P.Ch., V.T., T.M., V.R., J.Š., J.A. and R.G. (who had already been recruited) to
provide pornographic services, had made use of those services by receiving pecuniary advantage from those
services, and had produced and distributed pornographic material.

14. The trial court also found it established that the applicants had recruited the victims to work as “web models” by
using deceit – that is, giving the victims to understand that the job was legal, even though the applicants (i) had
themselves understood that the work involved pornography and that the recruits could only earn money by
performing pornographic actions, (ii) had not revealed (neatskleisdami) that to the victims, and (iii) had – taking
advantage of the victims' naivety and trust (naivumas ir patiklumas), and their inability to assess the danger of
pornography and its negative consequences – made untrue promises regarding good pay.

15. The court specifically found it proven that the victims had been vulnerable and dependent on the applicants, and
had suffered abuse at their hands. For example, R.G. had lived in her home with three small age children, had been
watched by the applicants over the Internet, and had been instructed on how to go about her work; she had thus
been pressured into feeling indebted to the applicants and working to repay them for the job they had found for her.
When at certain point she had refused to continue performing her work, which had included showing her intimate
parts over the webcam and performing intimate actions upon herself, the applicants had used psychological


-----

violence and had persuaded her to continue providing pornographic services. The applicants had received the
money earned by R.G. for the services that she had provided on the websites.

The court furthermore determined that two of the victims, A.M. and G.Z., had also been deceived by the applicants'
failure to reveal to them the true nature of the job. They had been employed as “web models”, and the applicants
had paid part of the rent money for the apartment in Klaipėda that A.M. and G.Z. had rented out; one of the women
had been provided with webcams, but, having learned that they would be required to provide pornographic services
online, they had refused to work.

The court likewise established the element of deceit in case of T.M., who had not been informed of the true nature
of the job. The applicants had rented her an apartment in Telšiai, where she had stayed with a small child and
another victim (V.R.). By giving T.M. money to cover basic needs the applicants had made her feel that she was in
their debt and that she should work to repay that money; she had been watched by the applicants, who had
supervised how she worked and had given her suggestions regarding how to act while performing in front of the
webcam. The applicants had also used psychological violence against T.M. so that she would continue working.

V.R. had also been deceived into providing pornographic services by the applicants; she had been given money
and had been made to feel that she was in the applicants' debt; she had also been controlled by them, and they
had persuaded her to continue in the job.

Another victim, P.Ch., who had been at high school at the time of the events in question, and had been naïve and
trusting (naivumas ir patiklumas), had been given a webcam and the use of an apartment in Panevėžys that the
applicants had rented, thus rendering her financially dependent on them. The applicants had monitored her over the
Internet while she worked, and they had given her orders (nurodymus) regarding how she should work; they had
also suggested that she drink alcohol, and they had employed psychological violence against her so that she would
continue in the work.

The applicants had also deceived D.D. regarding the true nature of the job by not revealing that it was related to
pornography and by not explaining that she could not earn the considerable sums of money that they had promised
her if she did not engage in pornographic activity. The applicants had rented an apartment in Panevėžys, where
D.D. had lived with P.Ch. When D.D. had started to work, but had refused to engage in pornographic activity, the
applicants had screamed at her and mocked her (ėmė _rėkti ir_ _tyčiotis) of the fact that she was earning so little_
money; the applicants had expected that D.D. would start engaging in pornographic performances, but she had
refused to continue working as a “web model”.

V.T. had also been deceived: she had been vulnerable, naïve and gullible, and the applicants had exploited her
precarious financial situation and the fact that she had been raising a small child. The applicants had persuaded
V.T. to come to live in another town, Šiauliai, they had paid her travel costs. In Šiauliai she had been initially placed
with the child to live in a hotel, then the applicants had rented her an apartment, given her money to cover basic
needs, a computer and a webcam, thus making her feel indebted to them. They had monitored over the Internet
how she worked and had given her instructions how to act; she had been under their control. Having exploited her
vulnerability and dependence on them, the applicants had threatened her and her family with physical violence.

S.S. had also been deceived as to the nature of the job. The applicants had rented an apartment for her; however,
once she had realised that without engaging in pornographic activity it would be impossible for her to earn money,
she had refused the job.

J.Š. had been equally deceived: the applicants had made use of her vulnerability, which had stemmed from her
difficult financial situation and her wish to help her ill mother. She had been given a computer and a webcam, she
had been monitored and controlled by the applicants over the Internet, when performing intimate actions with
herself in an apartment rented out by her in Vilnius.

J.A. had also been the victim of the applicants' deception: the applicants had given her a computer and a webcam,
thus making her feel that she was indebted to them; the applicants had monitored her work, and had suggested
how she should work. She had worked in her apartment in Visaginas.


-----

16. Regarding the question of whether the elements of the crime of trafficking in human beings under Article 147 §
2 had been made out in respect of the applicants' actions, the Šiauliai Regional Court noted that the two applicants
had used deceit (apgaulė) in respect of the victims; they had also exploited the victims' vulnerability in order to
recruit them and then to use them to provide services of a pornographic nature. According to that court, the victims'
vulnerability had manifested itself (pasireiškė) because of their naivety, trustfulness, inability to properly assess the
nature of the proposed work and its consequences, and their precarious financial situation (they had had no
employment). Under those circumstances the victims had had no choice but to give in to the applicants' influence
(poveikis), which the latter had made use of. The court also held that the applicants, by inflicting psychological
violence on the victims, had forced (vertė) them to provide services of a pornographic nature. Accordingly, the
applicants, in order to exploit (išnaudoti) – by means of deceit – the victims' vulnerability, had recruited and
controlled the victims, restricting their freedom.

17. The Šiauliai Regional Court's more detailed reasoning regarding the applicants' conviction for trafficking in
human beings is reflected in paragraphs 49-52 below, the Supreme Court having upheld the Šiauliai Regional
Court's findings.

18. The Šiauliai Regional Court also established that the applicants, acting as an organised group, had between 11
and 14 August 2013 attempted to pressurise V.R. and T.M. into perjuring themselves in the criminal case regarding
trafficking in human beings (see paragraph 10 above); the applicants had persuaded V.R. (in a telephone call) to
meet them. During that meeting, the second applicant had surveyed the surroundings in order to be sure that no
police were present. The first applicant had met V.R. and had instructed her to give false testimony – specifically, to
say that she had never undressed during her interactions with customers over her webcam, and that no violence
had been used against T.M.; the first applicant had told V.R. to meet T.M. and to persuade her to give false
evidence, too – namely to say that she had never worked as a “web model”, and had done nothing more than sign a
contract. The first applicant had given V.R. LTL 200 (EUR 60) in return for her anticipated perjury, but had told her
to give LTL 100 (from that sum) to T.M.
_II. THE COURT OF APPEALA. The applicants' appeal_

19. On 6 February 2017 the applicants appealed, arguing, inter alia, that the trial court had failed to properly assess
the alleged contradictions in the victims' testimony regarding the applicants' behaviour and actions which the victims
had perceived as threatening and as the psychological violence, and regarding their use of deceit, the victims
having been forced to engage in pornographic activities, the discrepancy between the respective levels of the
victims' expected and actual pay, their vulnerability, their dependence on the applicants, and the fact that the
victims had been manipulated psychologically.

20. The applicants further disputed the lawfulness of their conviction under Article 147 § 2 of the Criminal Code.
They considered that their actions had lacked the element of deceit; they further submitted that the assertion that
the victims had been vulnerable and controlled by the applicants had not been properly established, that the victims
had not been exploited. The applicants argued that, on the contrary, they had taken care of the victims by assisting
them to find apartments in which to live, by contributing to their rent, and by providing the victims with money; in
short, the victims' upkeep had largely covered by the applicants, who had thus contributed to the victims' well-being.
The victims' interests had therefore not been undermined; moreover, the applicants had allowed them to leave their
jobs when they had so wished, and had acted in a civil manner.

21. In their twenty-eight-page-long appeal, drafted by their advocate, G.D., the applicants had not argued that
conditions similar to slavery had been an indispensable element of the crime of tracking in human beings (see also
paragraph 92 below), and that without such conditions a crime could not be committed. In fact, the appeal had
made no reference whatsoever to the element of slavery-like conditions.

22. Lastly, the applicants had contested their conviction of exploitation in the form of forced labour or services and
of the use of a person's forced labour or services, under Articles 147[1 ] § 1 and 147[2 ] § 1 of the Criminal Code
respectively (see paragraph 11 above).
_B. The Court of Appeal ruling_


-----

23. By a ruling of 22 February 2018 the Court of Appeal acquitted the applicants of trafficking in human beings, of
exploitation in the form of forced labour or services, and of the use of a person's forced labour or services. The
appellate court found that the data in the case had been properly gathered and acknowledged as evidence;
however, it found that the first-instance court had erred in assessing the factual circumstances of the case.
_1. As to Article 147 of the Criminal Code_

24. On the facts, the Court of Appeal firstly noted that the applicants had searched for women wishing to work as
“web models” by placing an advertisement on the Internet. It was from that advertisement that five of the victims
had learned of the job offer. The other six victims had learned of the job from friends, who had either been already
contracted to engage in that activity, or who intended to take up that activity. All those women had become
interested in the job offer because they wished to make more money, they were not happy with the money they had
been earning or they did not have any source of income of any kind.

25. Secondly, it had been established by the victims' testimony that during their first conversations with the victims
the applicants would tell them about the nature of the work: they had given some of them more details – that for that
work they would need to undress and to behave erotically; to others the applicants would only give a hint and
emphasise that the decision regarding whether to accept the job offer would be the women's own choice. During
those conversations the applicants would note that the women's pay was dependent on the number of hours
worked.

26. Thirdly, even though three of the women asserted that they had been subjected to psychological violence in an
effort to force them to work as much as possible, it was clear from the victims' testimony that the threats had been
related to the applicants urging the women to work more hours and to lure more clients. Nevertheless, those three
victims had confirmed that once they had refused to do that work, they had received no threats or instigation
(grąsinimai ar raginimai); they had only been urged to return the borrowed computers and webcams.

27. Fourthly, there was nothing in the case file to indicate that the applicants had had recourse to any unlawful
means of preventing the women who no longer wished to work from leaving. Four of the victims had refused the job
the moment that they had understood its nature; other victims had refused the job within a month or more of starting
it. Not a single victim had stated that she had come under pressure to continue working in the job; however, the
applicants had demanded that the victims return the equipment that they had given them and repay money that
they had lent to them for renting a flat or to cover other expenses.

28. Fifthly, none of the victims had testified that the applicants had controlled their activities and their daily life,
except for the hours that they had spent working. All the victims had stated that the applicants had not had keys to
the places where they had lived, and had almost never visited those apartments (except for one victim); some of the
victims had not even met the applicants in person.

29. The Court of Appeal then referred to the definition and elements of trafficking in human beings under Article 147
of the Criminal Code: the applicants had been convicted because they had committed the crime (i) by virtue of one
action (veiksmas) – recruitment (verbavimas), and (ii) in two ways (būdai) – exploiting the victims' vulnerability, and
engaging in deceit – that is, untruthfully promising a high rate of pay and disguising the real nature of the job.

30. The Court of Appeal noted that, within the meaning of Article 147 of the Criminal Code, the purpose of the
recruitment had been not only to obtain the victims' agreement to engage in certain activities, but also to have the
possibility of controlling the victim in the future. It was true that there had been cases in the past where a person
had been convicted only in respect of recruitment (the Court of Appeal referred to the Supreme Court's ruling no
2K-565-139/2015); nevertheless, even in such cases the aim of restricting the victims freedom, and of controlling
and exploiting the victim still had to be proved.

31. The appellate court acknowledged that the applicants had performed certain actions that had constituted
objective elements of trafficking in human beings – namely, they had withheld certain information about the true
nature of the work in question and had promised those women who had responded to the advertisement a high
salary the level of which would depend solely on the number of hours worked. Indeed, the applicants' recruitment of
women to communicate with men online for pay had not appeared to constitute an invitation to enter an ordinary


-----

form of employment and could have raised suspicions that the victims might be exploited. Even so, a necessary
element of trafficking in human beings was that it was contrary to human freedom, and involved the exertion of a
certain malign influence on the victim in question (by means of violence, deceit, or exploiting that person's
vulnerability) that would allow that person's will to be overcome and controlled or would render that person
vulnerable to some form of exploitation in the future (the Court of Appeal referred to the Supreme Court's ruling 2K551-788/2015).

32. Even though some of the victims had been vulnerable owing to serious financial and social problems, the
material in the case file did not indicate that the applicants had taken advantage of that vulnerability. Nor did any of
the case-file material indicate that the applicants had forced the victims to continue working after they had been
initially working it of their own free will. Some of the women had taken up the work not because of any bad financial
situation, but because they had wanted to live separately from their parents, or because of other circumstances.
Those personal characteristics of the victims that the first-instance court had referred to – their naivety, an inability
to properly assess the nature of the work, and other weaknesses – could not be considered as sufficient to amount
to vulnerability. It was also important that the material in the case file did not allow a finding that the applicants had
purposely (kryptingai) sought specifically vulnerable individuals, or that they had sought to recruit precisely only
such persons. There was no basis for holding that the applicants had created a situation wherein the victims had
had no other real or acceptable course of action other than to give in to abuse.

33. Regarding the issue of deceit as an element of the crime of trafficking in human beings, such deceit could take
the form of providing false information or remaining silent in respect of the truth. Deceit regarding an offer of
employment or the conditions thereof was a typical element of trafficking in human beings, whereby the exploitation
of the victim was disguised by some kind of “agreement” between the victim and the accused. Deceit, as a means
to influence the victim, was a feature of “voluntary slavery”. The first-instance court had correctly stated that the
applicants – neither in the job advertisement nor during the conversations that they had had with the women – had
not provided the victims with full information regarding pay and the nature of the work, and the victims had therefore
not been entirely capable of making an informed decision [regarding whether to take the job]. Yet the subsequent
actions of which the victims had themselves spoken of in their testimony allowed the conclusion to be reached that
their freedom of will _de facto_ had not been breached because of certain circumstances not revealed to them
beforehand. In other words, the victims' freedom of will (valios laisvė) to choose to perform that work or not to had
not been restricted: they had been able to freely decide themselves upon a course of action; indeed, four of the
victims had immediately refused to work. It was true that the applicants had repeatedly (pastoviai) persuaded four
other victims to work longer hours and to “show more skin” – otherwise the money that they had been given in
advance to pay the rent would have to be returned; but even so, those four victims could still have refused to work.
The women had not received any threats when they had decided to discontinue their work, and neither had they
been intimidated into not changing their minds to leave. According to the Court of Appeal, the applicants' demand
for the return of the money and the computers, should the victims refuse to work, had been justified and had
corresponded to the applicants' expectations, for they had incurred certain expenses; moreover, the victims had
been told of the conditions attached to the advance payment.

34. Under the Lithuanian Criminal Code, trafficking in human beings fell within the category of crimes against
human liberty (nusikaltimai žmogaus laisvei). Liberty, as a protected value, was to be understood in two aspects:
physical liberty, entailing a person's freedom of movement; and liberty of will, which meant the possibility to choose
a course of action (pasirinkti elgesio _variantą). Control that would restrict freedom was usually manifested in the_
form of taking away identity documents, limiting possibilities to escape from the network of abuse, control of
freedom of movement or control of daily life, obstructing social contacts, or imposing debt that had be repaid. In the
applicants' case, none of the victims had testified that the applicants had controlled their actions or daily lives. In the
light of the factors noted above, the Court of Appeal considered that, even though there had been certain
characteristics of a recruitment process in the applicants' actions, in the applicants' case the necessary objective
element of the crime – namely, a breach (restriction) of the victims' physical freedom, or freedom of will, as a result
of which the victims could not have freely decided upon a course of action – had not been proved.


-----

35. As it has not been established that the victims' physical freedom had been restricted or that the applicants had
bent them to their will, the applicants' actions did not fall within the scope of Article 147 of the Criminal Code.
Accordingly, the applicants were to be acquitted of trafficking in human beings.
_2. As to Article 147[1 ]of the Criminal Code_

36. The Court of Appeal found that the trial court had not properly reasoned the application of that provision in the
applicants' case: when a person was forced to perform unlawful activity, the perpetrators' actions would be
categorised under Article 147 of the Criminal Code as trafficking in human beings; in the event that the activity in
question was not unlawful, it would be qualified under Article 147[1]. In the present case the applicants, using the
victims' services, produced pornography – an activity that could not be considered as lawful under Lithuanian law.
The application of Article 147[1 ]to the applicants' actions thus raised serious doubts. Besides, in order to qualify the
actions as trafficking in human beings, or as the exploitation of forced labour or services, it was very important to
establish the criterion of control that had restricted the liberty of the person in question. In the light of the arguments
presented above (see paragraphs 28 and 34 above), precisely that element had not been established in the case.
The applicants' conviction under Article 147[1 ]§ 1 therefore had to be quashed.
_3. As to Article 147[2 ]of the Criminal Code_

37. The Court of Appeal likewise held that the trial court had erred in applying that Article, which had been aimed at
establishing the criminal liability of persons who had used the services of a trafficking victim. It would be therefore
wrong to apply Article 147[2 ] to the applicants, since they were not the perpetrators (subjektai) of such criminal
activity. The Court of Appeal thus acquitted the applicants of that crime.
_4. As to the remaining criminal acts_

38. The Court of Appeal nevertheless upheld the applicants' conviction under Article 215 § 1 (only in respect of the
first applicant), Article 214 § 1, Article 309 § 1 and Article 233 § 1 of the Criminal Code (see paragraph 12 above).
They were sentenced to ninety days of arrest, but as they had already been in pre-trial detention since 2013, it was
deemed that they had already served their sentence.
_III. THE SUPREME COURT_

39. The prosecutor and one of the victims appealed, arguing, _inter alia, that the Court of Appeal had wrongly_
assessed the issue of the victims' alleged vulnerability, dependency and deceit.

40. By a final ruling of 27 November 2018 the Supreme Court overturned the appellate court's verdict, found the
applicants guilty of trafficking in human beings (Article 147 § 2), and sentenced them to five years of imprisonment.

41. The Supreme Court observed that the Court of Appeal, when examining the lawfulness and reasonableness of
the trial court's judgment, had undertaken an evaluation of evidence: it had questioned the eleven victims, and
during that questioning had not established any other (previously unestablished) or additional circumstances; it had
then in its ruling held that the witnesses' testimony met the requirements of evidence, and that that testimony could
therefore be relied on when establishing circumstances important to the case. However, the appellate court, not
having refuted the veracity of victims' testimony, had assessed it differently than had the first-instance court and
had reached the opposite conclusion in respect of the applicants' actions under Article 147 of the Criminal Code.

42. The Supreme Court found that (i) the Court of Appeal ruling had lacked analysis of other evidence that had
been examined and assessed by the first-instance court, namely the telephone conversations and text messages,
data relating to Skype conversations, and other written evidence, and (ii) that other evidence had not been
compared with the victims' testimony and no reasoning had been given as to why that other body of evidence had
been disregarded. The Supreme Court accordingly concluded that, contrary to the Šiauliai Regional Court, the
Court of Appeal, when acquitting the applicants, had assessed certain evidence separately from the evidence as a
whole, without giving any explanation for why it had not relied on some of that evidence. For the Supreme Court,
the Court of Appeal had made an essential breach of the standards of criminal procedure, related to the
assessment of evidence and to the content of the appellate court's judgment. Accordingly, the grounds on the basis
of which the Court of Appeal had assessed the applicants' actions under Article 147 § 2 of the Criminal Code
differently than had the trial court could not be held to be well-founded.


-----

_A. The constitutive elements of the crime of trafficking in human beings under Article 147 of the Criminal Code_

43. Regarding the merits of the applicants' conviction, the Supreme Court firstly observed that Article 147 § 1 of the
Criminal Code specified different ways in which a person could be exploited: that could entail prostitution,
pornography, or other forms of sexual abuse, forced labour or criminal activity (nusikalstama veika). For criminal
liability to arise, only one such alternative type of action was sufficient.

44. The Supreme Court then referred to its earlier case-law on the subject of trafficking in human beings, in which it
had held that by its very nature the crime entailed various transactions in which the subject of the trafficking was a
human being – for example selling, buying, recruiting, transporting a human being, and transactions concluded for
the purpose of exploitation. A required characteristic of the crime was that it deprived a human of his or her
freedom; that characteristic had to be linked to a certain malign form of influence exercised in respect of the victim,
notably in the form of violence, deceit, or abusing the victim's vulnerability, which allowed to that person's will to be
bent, that person to be controlled and involved (įtraukti) that person in exploitation (Supreme Court ruling 2K 173693/2018).

45. Another indispensable element of the crime of trafficking in human beings was the restriction of the liberty of the
person in question, which included the restriction of that person's will. It was for that reason that Article 147
contained a provision regarding the person that controlled the victim: the fact of that such control was exerted was
sufficient to hold that the freedom of the person in question had been breached. Restriction of liberty (or a breach
thereof) did not have to amount to the complete impossibility on the part of the affected person to move or to decide
on a course of action; it sufficed that that person by only partially so restricted. Moreover, whether or not the victim
had given consent was irrelevant, as consent obtained by deception or obtained as a result of the victim's
vulnerability (particularly in cases where violence or threats had been used) could not be considered to have been
voluntary (Supreme Court ruling 2K 43-942/2016).

46. Recruitment was understood as meaning giving encouragement (through persuasion, or making promises or
propositions) so that a human being would perform certain actions (such as giving consent to something, or going
abroad) with a view to being exploited; this would afterwards permit such an individual to be exploited in conditions
in which that person's liberty would be restricted. Recruitment could be either open – that is, the prospect of future
exploitation was not hidden – or disguised (Supreme Court ruling 2K-43-942/2016). Such recruitment could be
achieved by means of placing advertisements in newspapers or on the Internet, or through illegal travel agencies or
labour agencies.

47. Deceit was understood to mean that the individual in question was been intentionally misled so that he or she
would act in accordance with the perpetrator's intentions. Deceit could take the form of providing untrue information
or not revealing the truth (Supreme Court ruling 2K-43-942/2016).

48. Making use of the victim's vulnerability – was understood to mean the making of a bad faith offer to an individual
who, because he or she had been in a difficult situation, had no real or acceptable choice other than to accept such
an offer. Trafficking in human beings could therefore be acknowledged to have occurred in a situation where a
person had become involved in an enterprise in order to escape poverty or some other complicated economic or
social situation (Supreme Court rulings 2K-290/2014, 2K-432/2014 and 2K-173-693/2018). Making use of a
person's vulnerability could take the form of the perpetrator of the crime abusing the victim's vulnerability, which
could stem from material or some other form of dependence on the perpetrator. Dependency could be established
where the victim entirely or partially lost the possibility to effectively counter (pasipriešinti) the perpetrator's actions.
_B. Whether the applicants' actions fell within the crime of trafficking in human beings under Article 147 of the_
_Criminal Code_

49. The Supreme Court referred to the first-instance court's findings that an advertisement had been placed on
various webpages offering young women jobs as “web models”, which would involve communicating over the
Internet with individuals from different countries. The advertisement had not specified [any] exceptional
requirements (it stipulated only an ability to communicate, a command of basic English and an attractive
appearance), yet it had offered a salary of between LTL 2,000 and LTL 5,000 per month. Thus, the applicants had


-----

not revealed the true nature of the job in question – namely, the women would be required to engage in
pornographic acts in front of the webcam; rather, they had, in an underhand manner (užmaskuotai), offered legal
work that did not involve any special requirements in return for a high level of remuneration. In their conversations
with the victims about the job, the applicants had also assured them that the job would not involve the provision of
pornographic services and had asserted that the working conditions would indeed be as they had been presented
in the online advertisement. The trial court's judgment of conviction had also properly taken into account the fact
that the victims, trusting the information provided by the applicants, had signed contracts [with the applicants'
company] in which the provision of services and other related conditions had been described in English and in small
font; the women had not known that they had committed themselves to engaging in pornographic actions and that
all the pornographic material produced would be the property of the applicants' company. In the light of those
factors, the first-instance court had justifiably concluded that the applicants had engaged in deceit in their dealings
with the victims, and had not revealed the actual nature and essential conditions of the work.

50. The Supreme Court also pointed out that the first-instance court's judgment had stated that the applicants had
recruited the victims to provide pornographic services, taking advantage of their vulnerability owing to their poor
material situations, as well their naivety, gullibility, inability to properly assess the nature of the work offered, and the
consequences thereof. The poor material situation of certain individual victims had been due to the fact that [some
of them] had been unemployed, had been raising children alone and had lacked money. There was no doubt that
given those conditions, the women had been tempted by the large sums of money that had the job advertisement
had promised in return for their performing work of an ostensibly uncomplicated nature. Contrary to the view taken
by the appellate court, the Supreme Court deemed that both the content of the advertisement and the
conversations between the applicants and the victims, whose poor material circumstances had been known to
them, about the work indicated conclude that the applicants had been intending to employ women who, because of
their difficult material situations, could subsequently be persuaded to engage in pornographic services and who
could “be controlled”. According to the first-instance court, all of the victims had been young and essentially without
any kind of work experience or with limited work experience, so they had gullibly and naively trusted the applicants
and had believed that that the job offered would indeed meet their expectations. All this had led the first-instance
court to reasonably hold that the victims had been in a vulnerable position.

51. The actions undertaken by the applicants (placing the advertisement on the Internet and persuading the women
to take the job referred to in the advertisement) had been reasonably regarded by the first-instance court as
constituting recruitment within the meaning of Article 147 of the Criminal Code, because they had been undertaken
with the aim of overriding the victims' will and to bringing them under the convicted persons' control. That
conclusion had been confirmed by the applicants' subsequent conduct, as established by the first-instance court:
when some of the victims had begun to “work” – that is to say they had been required to carry out sexual acts in
front of the webcams in their apartments or in the apartments rented to them by the applicants, the latter would
monitor the victims' work over the Internet and would give instructions regarding how to earn as much money as
possible from the victims' clients. When the victims had attempted to discontinue this line of work, the applicants
would persuade them to change their attitudes. In addition, the applicants had used psychological violence against
the victims, in order to pressurise the victims into spending as much time as possible on engaging in sexual acts in
front of the webcam, in order to maximise earnings. For example, the first instance court had found that, the second
applicant, acting under a pseudonym, had urged (during conversations via Skype) one of the victims, P.Ch., to work
intensively; he had indicated what minimum sum of money she was supposed to earn each day in order to be able
to pay the rent for the apartment leased for her by the applicants. The applicants' intention to control the victims
was also confirmed by the content of the recordings of telephone conversations obtained in the case. For example,
in a telephone conversation of 16 May 2013, the applicants had discussed how T.M. had been told that they were
investing money in their “business” in order to make a profit; accordingly, the victim had been urged to try to put
effort in her work; otherwise – given that she was on her own, without an education and with a child to support –
she would have no other opportunity to find a well-paid job. In their telephone conversations the applicants had
been discussing their hope that V.T. would obtain the maximum material benefit from her French client, thus making
it possible for the applicants to profit. The applicants had also overseen V.T.'s communication with that client
(describing to her how she should act, asking her to ask that client to buy her a computer, and monitoring (sekė)
them, thus demonstrating that they had felt that they had the right to intrude (kištis) on her private life). During one


-----

of the telephone conversations with S.S. the second applicant had informed her that she had to tell another victim,
V.T., that if the latter did not contact the applicants within a week, they would subject her to physical violence. It
followed that the applicants had sought to profit from the provision of pornographic services by the victims, and thus
had an interest in controlling the intensity of their work and preventing the victims from discontinuing such activities.
In order to achieve such an aim, the applicants had taken steps that had partially restricted the victims' freedom as
regards their private life – a step that had gone beyond the scope of an employment relationship. It was also
important to note that, at the time in question, the victims had been not only vulnerable, but also materially
dependent on the applicants: the necessary computer equipment had been made available to the victims in order
that they could engage in their sexually-related activities, and for some of the victims the applicants had rented
apartments and had lent them money, thus placing the victims under a sense of obligation. Against that
background, in the view of the Supreme Court, the conclusion reached by the first-instance court (namely, that the
applicants' intention had been to restrict the victims' choice to freely decide whether or not they wished to provide
pornographic services) had been justified. In order to classify an act under Article 147 of the Criminal Code, it was
not necessary to establish that the victim had been totally deprived of his or her liberty; accordingly, even though
the Court of Appeal had established that the applicants had not exercised full control over the victims' daily lives
and had not entirely restricted their decisions when choosing any particular course of action, it was nevertheless
undisputed that they had committed the crime of trafficking in human beings.

52. The Supreme Court held that the Court of Appeal had also placed too much emphasis on the fact that some of
the victims (D.D., S.S., A.M. and G.Z.) had refused to work, once they had realised what kind of services were
requested from them. The Supreme Court observed that the commission of the crime of trafficking in human beings
is classified as “formal”– the time of the commission of the crime did not relate to the occurrence of criminal
consequences, but rather to the act itself, such as the act of recruitment. As established by the trial court, the
applicants had recruited all of the victims under the same criminal scheme, for the purpose of exploitation,
specifically, to provide pornographic services. The criminal offence committed by the applicants, within the meaning
of Article 147 of the Criminal Code, had to be regarded as having come to an end at the moment of the victims'
recruitment for the purposes of fulfilling the applicants' criminal intentions. Consequently, for the purposes of
classifying the criminal offence under Article 147, it was irrelevant that some of the victims had subsequently failed
to obey the applicants, and had not begun providing pornographic services.

53. The Supreme Court thus concluded that the first-instance court had correctly interpreted and applied the
provisions of Article 147 § 2 of the Criminal Code and had reached the reasonable conclusion that the applicants'
actions had corresponded to the constituent elements of the crime of trafficking in human beings.
_C. The applicants' conviction of and acquittal of other criminal acts_

54. The Supreme Court upheld the applicants' conviction under Article 215 § 1 (only in respect of the first
applicant), Article 214 § 1, Article 309 § 1 and Article 233 § 1 of the Criminal Code.

55. At the same time, the Supreme Court upheld the acquittal of the applicants of the crime of exploitation for forced
labour or services (Article 147[1 ]§ 1) and of using a person's forced labour or services (Article 147[2 ]§ 1), holding that
no acts amounting to crimes had been committed.
**RELEVANT LEGAL FRAMEWORK AND PRACTICEI. DOMESTIC LAW**

56. The Criminal Code, in the wording that applied between 30 June 2005 and 12 July 2012, in so far as relevant
read:

**Article 147. Trafficking in Human Beings**

“1. One who sells, purchases or otherwise transfers or acquires a human being or [who] recruits, transports or
holds in captivity a human being by means of physical violence or threats, or by otherwise depriving [that
individual] of the possibility of resistance or by taking advantage of the victim's dependency or vulnerability or
by resorting to deception ..., where the offender is aware of or seeks the involvement of the victim in
prostitution or [seeks] to gain profit from that individual's prostitution or by using [that individual] for
pornographic purposes or forced labour,


-----

shall be punished by imprisonment for a term between two and ten years.

2. One who commits the act provided in paragraph 1 of this Article in respect of two or more victims or by
participating in an organised group ...,

shall be punished by imprisonment for a term of four up to twelve years. ....”

**_147 straipsnis. Prekyba žmonėmis_**

_“1. Tas, kas pardavė, pirko ar kitaip perleido arba įgijo_ _asmenį, arba verbavo, gabeno ar laikė_ _nelaisvėje_ _žmogų_
_panaudodamas_ _fizinį_ _smurtą ar grasinimus arba kitaip atimdamas_ _galimybę priešintis, arba pasinaudodamas_
_nukentėjusio asmens priklausomumu ar pažeidžiamumu, arba panaudodamas_ _apgaulę, arba_ _sumokėdamas_
_pinigus ar suteikdamas_ _kitokią_ _turtinę_ _naudą asmeniui, kuris faktiškai kontroliuoja_ _nukentėjusį_ _asmenį, jeigu_
_kaltininkas žinojo arba_ _siekė, kad_ _nukentėjęs asmuo_ _būtų_ _įtrauktas_ _į_ _prostituciją ar_ _būtų pelnomasi iš šio_
_asmens prostitucijos arba jis_ _būtų išnaudojamas pornografijai ar priverstiniam darbui, baudžiamas_ _laisvės_
_atėmimu nuo dvejų iki dešimties metų._

_2. Tas, kas šio straipsnio 1 dalyje numatytą_ _veiką_ _padarė dviem ar daugiau_ _nukentėjusiems asmenims, arba_
_dalyvaudamas organizuotoje grupėje, ..._

_baudžiamas laisvės_ _atėmimu nuo ketverių iki dvylikos metų.”_

57. The Criminal Code, which was valid at the time of the events of the instant case (in force as of 13 July 2012), in
so far as relevant, read:

**Article 147. Trafficking in Human Beings**

“1. One who sells, purchases or otherwise transfers or acquires a human being or [who] recruits, transports or
holds in captivity a human being by means of physical violence or threats, or by otherwise depriving [that
individual] of the possibility of resistance or by taking advantage of the victim's dependency or vulnerability, or
by or by resorting to deception ..., where the offender is aware of or seeks that the victim, whether he [or she]
agrees or not, would be exploited under the conditions of slavery or under conditions similar to [those of]
slavery, for [the purposes of] prostitution, pornography or other forms of sexual exploitation, forced labour or
services ..., or for other purposes of exploitation,

shall be punished by imprisonment for a term between two and ten years.

2. One who commits the act provided in paragraph 1 of this Article against two or more victims, ... or by
participating in an organised group, ...

shall be punished by imprisonment for a term between four and twelve years. ...”

**_147 straipsnis. Prekyba žmonėmis_**

_“1. Tas, kas pardavė, pirko, kitaip perleido ar įgijo, verbavo, gabeno ar laikė_ _nelaisvėje_ _žmogų panaudodamas_
_fizinį_ _smurtą ar grasinimus arba kitaip atimdamas_ _galimybę priešintis, arba pasinaudodamas_ _nukentėjusio_
_asmens priklausomumu ar pažeidžiamumu, arba panaudodamas apgaulę, arba priimdamas ar sumokėdamas_
_pinigus, arba gaudamas ar suteikdamas_ _kitokią_ _naudą asmeniui, kuris faktiškai kontroliuoja_ _nukentėjusį_
_asmenį, jeigu kaltininkas žinojo arba siekė, kad nukentėjęs asmuo, nesvarbu, ar jis sutiko, būtų išnaudojamas_
_vergijos ar panašiomis_ _į_ _vergiją_ _sąlygomis, prostitucijai, pornografijai ar kitoms seksualinio išnaudojimo_
_formoms, priverstiniam darbui ar paslaugoms, ... arba kitais išnaudojimo tikslais,_

_baudžiamas laisvės_ _atėmimu nuo dvejų iki dešimties metų._

_2. Tas, kas šio straipsnio 1 dalyje numatytą_ _veiką_ _padarė dviem ar daugiau nukentėjusiems asmenims ..., arba_
_dalyvaudamas organizuotoje grupėje, ..._


-----

_baudžiamas laisvės_ _atėmimu nuo ketverių iki dvylikos metų.”_

**Article 147[1]. Exploitation for Forced Labour or Services**

“1. One who, through the use of physical violence, threats, deception or other means listed in Article 147 of this
Code, unlawfully forces another human being to perform certain work or to provide certain services, including
begging,

shall be punished by a fine or by restriction of liberty or by arrest or by a custodial sentence of up to three
years.

2. One who commits an act indicated in paragraph 1 of this Article by forcing another human being to perform
work or to provide services under conditions of slavery or under other inhumane conditions

shall be punished by arrest or by a custodial sentence of up to eight years.

...”

**Article 147[2]. Use of a Human Being's Forced Labour or Services**

“1. One who uses another human being's work or services, including prostitution – while being aware or having
to be or likely to be aware that the human being performs that work or provides those services – as a result of
employing against him [or her], for the purposes of [that human being's] exploitation, physical violence, threats,
deception or other means listed in Article 147 of the Code,

shall be punished by a fine or by restriction of liberty or by arrest or by a custodial sentence of up to two years.

...”

**Article 233. Influence on a Witness, Victim ..**

“1. One who, in any manner, seeks to influence a witness, victim ... so that they would give false testimony ...
during a pre-trial investigation or in court ...

shall be punished by community service or by a fine or by restriction of liberty or by arrest or by a custodial
sentence for a term of up to two years. ...”

_II. INTERNATIONAL LAWA. United Nations instrumentsProtocol to Prevent, Suppress and Punish Trafficking in_
_Persons, Especially Women and Children (“the Palermo Protocol”)_

58. The United Nations Convention against Transnational Organized Crime (UNCTOC) forms part of the central
legal framework concerning trafficking in persons under international law. It represents the “parent instrument” to a
specialised protocol on the matter – namely the Palermo Protocol.

59. The UNCTOC was signed by the parties thereto between 12 and 15 December 2000 and entered into force on
29 September 2003. There are 191 States parties to this Convention, which was ratified by Lithuania on 9 May
2002.

The Palermo Protocol was signed on 15 November 2000 and entered into force on 25 December 2003. There are
181 States parties to this Protocol, which was ratified by Lithuania on 23 June 2003.

60. The purpose of the UNCTOC is to promote cooperation with a view to preventing and combating transnational
organised crime more efficiently (Article 1). The scope of this Convention is subject to three prerequisites: firstly, the
offence in question must have a transnational aspect; secondly, it must involve an “organized criminal group”; and
thirdly, the offence must constitute a “serious crime” (Article 3). However, Article 34 § 2 of the UNCTOC provides:

“The offences established in accordance with articles 5, 6, 8 and 23 of this Convention shall be established in
the domestic law of each State Party independently of the transnational nature or the involvement of an


-----

organized criminal group as described in article 3, paragraph 1, of this Convention, except to the extent that
article 5 of this Convention would require the involvement of an organized criminal group.”

61. For its part, the Palermo Protocol aims to: (i) prevent and combat trafficking in persons, paying particular
attention to women and children; (ii) protect and assist the victims of such trafficking, with full respect for their
human rights; and (iii) promote cooperation among States Parties in order to meet those objectives (Article 2). The
provisions of the UNCTOC apply, mutatis mutandis, to the Palermo Protocol, unless provided otherwise (Article 1 §
2).
_(a) Definition of trafficking in human beings_

62. Trafficking in human beings has been defined for the first time under international law in the Palermo Protocol
as follows (Article 3 (a)):

“Trafficking' in persons shall mean the recruitment, transportation, transfer, harbouring or receipt of persons, by
means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse
of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the
consent of a person having control over another person, for the purpose of exploitation. Exploitation shall
include, at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced
labour or services, slavery or practices similar to slavery, servitude or the removal of organs ...”

63. The crime of trafficking in persons has three constituent elements: (i) an action (what is done: that includes
recruitment, transportation); (ii) the means (how it is done: that includes such means as threat or use of force or
other forms of coercion, deception, the abuse of power or of a position of vulnerability or of the giving or receiving of
payments or benefits to achieve the consent of a person having control over another person); (iii) an exploitative
purpose (why it is done: that includes at a minimum, the exploitation of the prostitution of others or other forms of
sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude). A combination of
the three constituent elements is necessary in order for the crime of trafficking to be established as regards adult
victims (UNODC, Combating Trafficking in Persons: A Handbook for Parliamentarians, March 2009, No. 16-2009,
pp. 13-14).

64. Article 3 (b) clarifies that if one of the means set forth in Article 3 (a) is used, it is irrelevant whether the person
expressed his/her consent or not.

65. The terms “exploitation of the prostitution of others” and “sexual exploitation” have been intentionally left
undefined in the Palermo Protocol to allow States, irrespective of their domestic policies on prostitution, to ratify the
Protocol. This was highlighted in the Interpretative notes for the official records (travaux préparatoires) of the
negotiation of the Palermo Protocol in the following manner (paragraph 64, p. 12):

“[T]he Protocol addresses the exploitation of the prostitution of others and other forms of sexual exploitation
only in the context of trafficking in persons and ... the terms 'exploitation of prostitution of others' or 'other forms
of sexual exploitation' are not defined in the Protocol, which is therefore without prejudice to how States Parties
address prostitution in their respective domestic laws.”

66. However, in the _Model Law against Trafficking in Persons_ (pp. 13-15 and 19), UNODC defined “sexual
exploitation” as the obtaining of financial or other benefits through the involvement of another person in prostitution,
sexual servitude or other kinds of sexual services, including pornographic acts or the production of pornographic
materials. It should also be noted that as regards “forced labour or services”, the UNODC explained that “initial
recruitment can be voluntary and the coercive mechanisms to keep a person in an exploitative situation may come
into play later.”

67. Furthermore, in a document entitled “Joint UN Commentary on the EU Directive – A Human Rights-Based
Approach” (2011), issued by the relevant United Nations bodies (the Office of the High Commissioner for Human
Rights (OHCHR); the UN Refugee Agency (UNHCR); UNICEF; UNODC; UN Women; and the International Labour
Organisation), the following was noted (p. 104):


-----

“Exploitation of prostitution of others and sexual exploitation are not defined in international law. The terms
have been intentionally left undefined in the Protocol in order to allow all States, independent of their domestic
policies on prostitution, to ratify the Protocol. While the Protocol draws a distinction between exploitation for
forced labour or services and sexual exploitation, this should not lead to the conclusion that coercive sexual
exploitation does not amount to forced labour or services, particularly in the context of trafficking. Coercive
sexual exploitation and forced prostitution fall within the scope of the definition of forced labour ...”

_(b) Scope of the Palermo Protocol_

68. According to Article 4, the scope of the Palermo Protocol is as follows:

“This Protocol shall apply, except as otherwise stated herein, to the prevention, investigation and prosecution
of the offences established in accordance with article 5 of this Protocol, where those offences are transnational
in nature and involve an organized criminal group, as well as to the protection of victims of such offences.”

69. According to the Model Law against Trafficking in Persons prepared by UNODC (p. 8), although Article 4 limits
its applicability to offences that are transnational in nature and involve an organised criminal group, those
requirements are not part of the definition of the offence and therefore national laws should establish trafficking in
persons as a criminal offence, independently of the transnational nature or the involvement of an organised criminal
group. In this connection, reference is made to Article 34 § 2 of UNCTOC (see paragraph 60 above, see also S.M.
_v. Croatia [GC], no. 60561/14, §§ 107-14, 25 June 2020)._

70. The fifth global report on trafficking in persons (2020), issued by the UNODC, notes the following (page 119 of
the report):

**TRAFFICKERS USE OF THE INTERNET; DIGITAL HUNTING FIELDS**

“As the world continues to transform digitally, internet technologies are increasingly being used for the
facilitation of trafficking in persons. With the rise of new technologies, some traffickers have adapted their
_modus operandi_ for cyberspace by integrating technology and taking advantage of digital platforms to
advertise, recruit and exploit victims.

Everyday digital platforms are used by traffickers to advertise deceptive job offers and to market exploitative
services to potential paying customers. Victims are recruited through social media, with traffickers taking
advantage of publicly available personal information and the anonymity of online spaces to contact victims.
Patterns of exploitation have been transformed by digital platforms, as webcams and livestreams have created
new forms of exploitation and reduced the need for transportation and transfer of victims.

With the help of the internet, traffickers have learnt to adapt their strategies to effectively target specific victims,
by actively 'hunting' those who they deem as vulnerable to falling victim to trafficking, or passively 'fishing' for
potential victims by posting advertisements and waiting for potential victims to respond.”

_B. Council of Europe1. Convention on Action against Trafficking in Human Beings (“the Anti-Trafficking_
_Convention”)_

71. The Anti-Trafficking Convention entered into force on 1 February 2008. It was ratified by Lithuania on 26 July
2012, and entered into force in respect of Lithuania on 1 November 2012.

72. The Anti-Trafficking Convention is a comprehensive treaty which aims to prevent and combat trafficking in
human beings, while guaranteeing gender equality; to protect the human rights of the victims of trafficking, design a
comprehensive framework for the protection and assistance of victims and witnesses, while guaranteeing gender
equality, as well as to ensure effective investigation and prosecution; and to promote international cooperation on
action against trafficking in human beings (Article 1).

73. Article 39 of the Anti-trafficking Convention states that it does not affect the rights and obligations deriving from
the Palermo Protocol, that it was intended to enhance the protections afforded by the Protocol and to develop the
standards contained therein.


-----

_(a) Definition of trafficking in human beings_

74. The definition of trafficking in human beings under Article 4 (a) is identical to Article 3 (a) of the Palermo
Protocol and consists of the same three components (see paragraphs 62 and 63 above). The Anti-Trafficking
Convention reads:

**Article 4 – Definitions**

“For the purposes of this Convention:

a 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person, for the purpose of exploitation.

Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs;

b The consent of a victim of “trafficking in human beings” to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

c The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered 'trafficking in human beings' even if this does not involve any of the means set forth in
subparagraph (a) of this article;

d 'Child' shall mean any person under eighteen years of age;

e 'Victim' shall mean any natural person who is subject to trafficking in human beings as defined in this article.”

75. In the Explanatory report to the Anti-Trafficking Convention it is pointed out that trafficking in human beings is a
combination of these constituents and not the constituents taken in isolation. Thus, as in the Palermo Protocol, for
there to be trafficking in adult human beings, ingredients from each of the three categories must be present
together.

76. As regards terminology, the Explanatory report clarifies that “recruitment” includes recruitment by using new
information technologies like the Internet (see further, the Council of Europe publication “Trafficking in human
beings: Internet recruitment Misuse of the Internet for the recruitment of victims of trafficking in human beings” EGTHB INT (2007) 1), and that “transport” does not need to be across a border to be a constituent of trafficking in
human beings.

77. It also highlights the fact that fraud and deception are frequently used by traffickers, as victims are led to believe
that an attractive job awaits them rather than the intended exploitation. The term “abuse of vulnerability” means
“abuse of any situation in which the person involved has no real and acceptable alternative to submitting to the
abuse”. It this connection it is further held as follows:

“The vulnerability may be of any kind, whether physical, psychological, emotional, family-related, social and
economic. The situation might, for example, involve insecurity or illegality of the victim's administrative status,
economic dependence or fragile health. In short, the situation can be any hardship in which a human being is
impelled to accept being exploited.”

78. The terms “exploitation of the prostitution of others” and “other forms of sexual exploitation” are not defined in
the Anti-Trafficking Convention. The Explanatory report states that this is so as not to prejudice how State parties
deal with prostitution in domestic law.

79. Article 4 (b) reads as follows:


-----

“The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used.”

80. According to the Explanatory report the approach adopted in Article 4 (b) is in line with the approach to consent
in the Court's case-law.

81. The scope of the Anti-Trafficking Convention is clearly meant to include “all forms of trafficking in human beings,
whether national or transnational, whether or not connected with organized crime” (Article 2) (see S.M. v. Croatia,
cited above, §§ 152-62).
_(b) Group of Experts on Action against Trafficking in Human Beings (GRETA)_

82. The following are extracts from the GRETA report concerning the implementation by Lithuania of the Council of
Europe Convention on Action against Trafficking in Human Beings, first evaluation round (adopted on 20 March
2015 and published on 5 June 2015) (“the GRETA First Report”):

_(i) “1. Overview of the current situation in the area of trafficking in human beings in Lithuania_

10. Lithuania is mostly a country of origin of victims of trafficking in human beings (THB), but also to a certain
extent a country of destination. According to information provided by the Ministry of the Interior, the number of
identified victims of THB was 22 in 2011, 14 in 2012 and 47 in 2013. All but two of the identified victims were
Lithuanian nationals. ... While most of the victims identified in 2011 and 2012 were trafficked for the purpose of
sexual exploitation, in 2013 the majority of victims (28) were trafficked for the purpose of exploitation in criminal
activities. The number of identified victims of THB for the purpose of labour exploitation was four in 2012 and
four in 2013.

11. GRETA notes that the above figures do not reveal the full scale of human trafficking in Lithuania as little
attention is paid to trafficking taking place within Lithuania and there are shortcomings in the identification of
victims of trafficking for different forms of exploitation.

_(ii) 2. Overview of the legal and policy framework in the field of action against trafficking in human beings_

12. At the international level, in addition to the Council of Europe Convention on Action against Trafficking in
Human Beings, Lithuania is Party to the United Nations Convention against Transnational Organised Crime
(ratified in 2002), its Protocol to Prevent, Suppress and Punish Trafficking in Persons, especially Women and
Children and its Protocol against the Smuggling of Migrants by Land, Sea and Air, supplementing the United
Nations Convention against Transnational Organized Crime (both ratified in 2003). Lithuania is also Party to
the UN Convention on the Rights of the Child and its Optional Protocol on the Sale of Children, Child
Prostitution and Child Pornography (ratified in 1992 and 2004, respectively), the Convention on the Elimination
of All Forms of Discrimination against Women (ratified in 1994), as well as conventions elaborated under the
International Labour Organisation (ILO). Further, Lithuania is Party to a number of Council of Europe
conventions in the criminal field which are relevant to action against THB.

13. As regards domestic legislation, the offence of trafficking in human beings for the purpose of sexual
exploitation was introduced into the Lithuanian Criminal Code (CC) in 1998. Following the adoption of the new
CC in 2003, THB for the purpose of different types of exploitation is criminalised under Article 147 of the CC...
In June 2012, the CC was amended through Law No. XI-2198, which brought changes to Articles 147, 147[1 ]...
and introduced the criminalisation of the use of services of a victim of THB (Article 147[2]).

...

_2. III. Implementation of the Council of Europe Convention on Action against Trafficking in Human Beings by_
_Lithuania_

**1. Integration of the core concepts and definitions contained in the Convention in the internal law**

a. Human rights-based approach to action against trafficking in human beings


-----

...

30. THB constitutes an offence to the dignity and fundamental freedoms of the human being and thus a grave
violation of human rights. GRETA emphasises the obligations of States to respect, fulfil and protect human
rights, including by ensuring compliance by non-State actors, in accordance with the duty of due diligence. A
State that fails to fulfil these obligations may, for instance, be held accountable for violations of the European
Convention on Human Rights and Fundamental Freedoms (the ECHR). This has been confirmed by the
European Court of Human Rights in its judgment in the case of Rantsev v. Cyprus and Russia, where the Court
concluded that THB within the meaning of Article 3(a) of the Palermo Protocol and Article 4(a) of the AntiTrafficking Convention, falls within the scope of Article 4 of the European Convention on Human Rights (which
prohibits slavery, servitude and forced or compulsory labour). The Court further concluded that Article 4 entails
a positive obligation to protect victims or potential victims, as well as a procedural obligation to investigate
trafficking.

The Convention on action against trafficking in human beings requires States to set up a comprehensive
framework for the prevention of THB, the protection of trafficked persons as victims of a serious human rights
violation, and the effective investigation and prosecution of traffickers. Such protection includes steps to secure
that all victims of trafficking are properly identified...

33. The Lithuanian authorities have indicated that human rights which are violated in cases of trafficking are
protected by the Lithuanian Constitution (the right to life, the right to liberty, the inviolability of the person, the
protection of dignity of the human being, the prohibition of torture, the inviolability of the private life and the
prohibition of forced labour). THB as a criminal offence is included in Chapter XX of the CC entitled “Crimes
against Human Liberty”, which, according to the authorities, would suggest that THB is considered as a
violation of human rights. In its ruling of 29 December 2004, the Lithuanian Constitutional Court stated that “the
majority of especially dangerous crimes, for example, terrorism, trafficking in people, criminal trade in weapons
and drugs, money laundering, financial crimes and crimes related to corruption, are often committed by
organised criminal groups (syndicates). If organised crime were not prevented and the organised criminal
groups (syndicates) were not prosecuted, the constitutional values, _inter alia, the rights and freedoms of the_
person, the legal basis of society entrenched in the Constitution, the State as an organisation of the entire
society and the entire society would be under threat.

...

b. Definitions of “trafficking in human beings” and “victim of THB” in Lithuanian law

_i. Definition of “trafficking in human beings”_

36. In accordance with Article 4(a) of the Convention, trafficking in human beings includes three components:
an action (“the recruitment, transportation, transfer, harbouring or receipt of persons”); the use of certain means
(“threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or
of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a
person having control over another person”); and the purpose of exploitation (“at a minimum, the exploitation of
the prostitution of others or other forms of sexual exploitation, forced labour or services, slavery or practices
similar to slavery, servitude or the removal of organs”). ...

...

39. The definition of THB under Article 147 of the CC contains the elements of action, means and purpose, as
defined by Article 4 of the Convention. As regards the means, GRETA notes that “fraud” and “abduction” are
not specifically mentioned in Article 147 of the CC. The Lithuanian authorities have explained that “fraud” is
covered by the Lithuanian word “apgaulę” which has been translated as “deceit”, and that there are no
separate words for “fraud” and “deception” in Lithuanian. ...


-----

40. GRETA notes with satisfaction that the types of exploitation included in [Article] 147 ... of the CC [is] ... in
conformity with Article 4 (a) of the Convention, while remaining open-ended, thus allowing that THB for any
new types of exploitation is covered by this definition. Further, GRETA notes that [Article] 147 ... specifically
state[s] that the consent of a victim of THB to exploitation is irrelevant for establishing the offence of THB...

...

52. GRETA was informed of emerging trends, such as THB for labour exploitation, including within Lithuania,
as well as reports of trafficking for forced criminality and forced begging, often involving children. The age of
the victims is becoming lower. ... Many of these cases were not recognised as THB in the countries where they
occur, which was one of the difficulties in identifying victims and investigating the offences.

...

**4. Implementation by Lithuania of measures concerning substantive criminal law, investigation,**
**prosecution and procedural law**

...

c. Investigation, prosecution and procedural law

...

167. GRETA urges the Lithuanian authorities to strengthen their efforts to ensure that THB offences leading to
different types of exploitation are proactively investigated and effectively prosecuted. In this context, the
Lithuanian authorities should develop the training and specialisation of investigators, prosecutors and judges to
tackle this complex crime with a view to ensuring that all human trafficking offences for different types of
exploitation lead to effective, proportionate and dissuasive sanctions.

...

**5. Concluding remarks**

175. GRETA welcomes the steps taken by the Lithuanian authorities to combat trafficking in human beings,
through the adoption of legislation and the setting up of co-ordination structures and specialised units. The ...
emphasis on awareness raising and training of relevant professionals are positive features of Lithuania's antitrafficking action.

...

177. GRETA also draws attention to the need to address emerging trends in trafficking in human beings in
Lithuania, in particular trafficking for the purpose of labour exploitation and internal trafficking...

178. Strengthening the effectiveness of investigations and prosecutions of human trafficking offences, with a
view to securing proportionate and dissuasive sanctions is another area where further action is needed in order
to fully apply the human rights based and victim-centred approach promoted by the Convention.

179. All professionals who may come into contact with victims of human trafficking need to be continuously
informed and trained about the need to apply a human rights-based approach to action against human
trafficking on the basis of the Convention and the case law of the European Court of Human Rights.”

83. The following are extracts from the GRETA report concerning the implementation by Lithuania of the Council of
Europe Convention on Action against Trafficking in Human Beings, second evaluation round (adopted on 22 March
2019 and published on 21 June 2019) (“the GRETA Second Report”):

“3. Substantive criminal law


-----

**a. Criminalisation of THB (Article 18)**

157. The three elements of the definition of THB under the Convention are included in the Lithuanian definition
of THB under Article 147 of the CC.

...

**b. Criminalisation of the use of services of a victim (Article 19)**

159. As already mentioned in the first report, Article 147[2 ]of the CC establishes as a criminal offence the use of
forced labour or services, including sexual services, when a person using them knew or should have known
that these services were obtained as the result of exploitation of a victim of trafficking. The Lithuanian
authorities informed GRETA that one person was convicted under Article 147[2 ] of the CC in 2017 by a first
instance court.

160. GRETA welcomes the criminalisation of the use of services of victims of trafficking in human beings, with
the knowledge that the person is a victim, and considers that the Lithuanian authorities should ensure the
effective application of this legal provision in practice.

...

**4. Investigation, prosecution and procedural law**

**a. Measures related to effective investigations (Articles 1, 27 and 29)**

170. The Lithuanian authorities have reported that law enforcement bodies initiated criminal proceedings for
THB-related offences (Articles 147, 147[1], 147[2 ]and 157 of the CC) in 24 new cases in 2014, 27 cases in 2015
and 29 cases in 2016. The number of prosecutions under these articles of the CC was 40 in 2014, 53 in 2015,
67 in 2016 and 35 in 2018.

171. According to information provided by the authorities, 15 persons were convicted of THB-related offences
in 2014, 14 in 2015, 23 in 2016 and 20 in 2017. Among the perpetrators convicted in 2014-2016, 61 were male
and 11 female, all being Lithuanian nationals. The penalties ranged from three to 12 years' imprisonment. Two
judgments in 2014 and four in 2016 resulted in confiscation of criminal assets. In 2015-2017 there were seven
cases of acquittals, confirmed on appeal. Representatives of the Prosecutor's Office indicated that cases when
investigations into THB are re-qualified are rare and concern offences comparable in gravity.

...

**177. GRETA considers that the Lithuanian authorities should continue their efforts to proactively**
**investigate THB offences for all types of exploitation, and ensure their prompt and effective**
**prosecution, leading to proportionate, effective and dissuasive sanctions, including the confiscation of**
**criminal assets.**

...

**IV. Conclusions**

199. Since the adoption of GRETA's first report on Lithuania in March 2015, progress has been made in a
number of areas related to combating trafficking in human beings.

...

207. GRETA also welcomes the significant number of investigations, prosecutions and convictions in human
trafficking cases, and the application of the provisions establishing criminal liability of legal persons for
trafficking offences. ...”

**THE LAWIII PRELIMINARY REMARKS**


-----

84. The Court observes that the applications in question concern solely the issue of the compatibility with the
Convention of the applicants' conviction under Article 147 § 2 of the Criminal Code (see paragraphs 11 and 12
above). It will therefore abstain from making an assessment of the applicants' conviction under other Articles of the
Criminal Code (see paragraphs 12 and 38 above), unless that other conviction bears some relation with the
applicants' conviction for trafficking in human beings.
_IV. JOINDER OF THE APPLICATIONS_

85. Having regard to the similar subject matter of the applications, the Court finds it appropriate to examine them
jointly in a single judgment.
_V. ALLEGED VIOLATION OF ARTICLE 7 OF THE CONVENTION_

86. The applicants complained that in finding them guilty of trafficking in human beings, the Šiauliai Regional Court
and the Supreme Court had interpreted expansively (plečiamai) the definition of that criminal act. The applicants
considered that that interpretation had been in breach of Article 7 of the Convention, which reads:

“1. No one shall be held guilty of any criminal offence on account of any act or omission which did not
constitute a criminal offence under national or international law at the time when it was committed. Nor shall a
heavier penalty be imposed than the one that was applicable at the time the criminal offence was committed.
...”

_A. Admissibility1. The parties' submissions(a) The Government_

87. The Government considered that the applicants had been lawfully convicted of trafficking in human beings, in
conformity with the standards of Article 7 of the Convention, and that the applications should therefore be declared
inadmissible as manifestly ill-founded.
_(b) The applicants_

88. The applicants noted that they had been convicted under the domestic criminal law by the national courts of two
instances, which had imposed and subsequently upheld a criminal sentence. The applicants suggested that their
conviction under Article 147 § 2 of the Criminal Code had been unclear, and that the domestic courts' reasoning in
respect of their case had not corresponded to the domestic case-law regarding the subject in question. Accordingly,
their complaint under Article 7 § 1 of the Convention was admissible.
_2. The Court's assessment_

89. The Court notes that the applications are neither manifestly ill-founded nor inadmissible on any other grounds
listed in Article 35 of the Convention. They must therefore be declared admissible.
_B. Merits1. The parties' submissions(a) The applicants_

90. At the outset, and referring to the Court's case-law on Article 7 of the Convention, the applicants argued that
they had been convicted in breach of Article 7 § 1 of the Convention, in the light of the lack of clarity of the relevant
legislation and because of the vague and unpredictable judgments of the national courts against them. They
considered that the Supreme Court's interpretation of the constitutive elements of the crime of trafficking in human
beings had been too expansive (aiškino _plečiamai) in so far as notions such as recruitment, deceit, control, the_
victims' dependency and vulnerability were concerned, those factors being necessary elements of a crime under
Article 147 of the Criminal Code.

91. In the applicants' view, there had been a disagreement between them and the Government over the content of
Article 147 of the Criminal Code, in so far as the necessary elements of the crime of trafficking in human beings
were concerned. The applicants also asserted that Article 147 § 1 of the Criminal Code had a particularly complex
linguistic structure. The formulation of that Article consisted of three different elements, among which additional
features were included, and all that was presented in one sentence.

92. The applicants laid much emphasis on the element of slavery or slavery-like conditions, which they saw as an
indispensable element, without which the crime of trafficking in human beings could not be established. Given that
that element had not been present, they should not have been prosecuted. In the applicants' case, none of the
national courts had ruled on the question of whether the victims had been exploited for the purposes of their


-----

engaging in pornographic activities in conditions of slavery or in slavery-like conditions; in fact, the courts had not
assessed that aspect of the alleged criminal act at all. Quite the reverse: in the applicants' case it was established
that the victims had been adults, had been working in their home country, had had a good command of their mother
tongue, had been educated, had been used to using the Internet, had not belonged to a vulnerable social grouping,
had not been experiencing poverty or difficult economic conditions (prior to their recruitment), and had had all the
necessary social skills. The applicants had simply placed an advertisement online and the girls contacted them
voluntarily. Besides, the victims had not been deprived of their liberty: they had worked in places of their own
choosing – some in their homes, some in rented apartments. The victims had been free to plan their working hours,
and the applicants had exerted no influence on their organisation of their own leisure time. The victims had not
been required to work for a specific period of time, and those of them who had not liked the work of a “web model”
had immediately stopped working and had not suffered any negative consequences or threats as a result. The rest
of the victims, unhappy with their earned income, had quit the job sometime later. The applicants thus considered
that the actual circumstances of their case had been significantly different from those examined by the Court in
_Siliadin v. France, no. 73316/01, §§ 113-18, ECHR 2005-VII, which had indeed concerned slavery-like conditions._
Furthermore, in the applicants' case the girls would receive pay – either via bank payment or in cash. They had all
worked for differing amounts of time per week, and all of them had ceased working of their free will, just as they had
started.

93. The applicants acknowledged that there could be situations where traffickers might cover up their illegal
activities and enter into fictitious employment or service contracts with the victims. The applicants also agreed with
both Lithuanian domestic and international practice to the effect that where the crime of trafficking in human beings
was concerned, the victim's consent to being trafficked did not preclude the perpetrator's liability. However, in cases
where a potential victim had agreed to work before taking up a particular job, in order for such a person to be
objectively recognised as a victim of trafficking, it was necessary to establish the extent of the victim's dependence
on the employer's will: factors taken into consideration could include an objectively low salary, restriction of freedom
of movement, the misappropriation of identity documents, the blocking of social contact, and the transportation of
the victim to a foreign State.

The applicants argued that that had not been the situation in the instant case.

94. The applicants also noted the fact that they had placed an advertisement online and had not confined their
search for potential victims to a specific social grouping. The victims had not lived in conditions of poverty; rather,
they had only wished to improve their living standards – to buy nicer clothes, to move out from parents' home, and
to have more money for their leisure time. That meant that their material situation essentially had not forced them to
take up any kind of work for economic survival. The women's young age could not constitute a basis for holding that
they had been incapable of understanding the nature of the work: the victims had lived in towns and townships, had
had an education, had the used Internet and had thus had sufficient social skills to comprehend the nature of
Internet work.

95. Regarding any assertions that they had engaged in deceit, the applicants wished to point out that, before the
women had started to work, they would inform them that their real pay would be dependent on the number of hours
that they worked; contrary to the Supreme Court's findings, that could not be seen as constituting deceit. The
applicants also denied having used violence towards the victims or having controlled them, and noted that they had
had no keys to the victims' apartments. Contact was maintained between the applicants and the women mainly
electronically.

96. The applicants could be understood as having suggested that, in the light of the foregoing considerations, they
had been victims of an arbitrary interpretation of criminal law, which lacked necessary precision, to avoid any risk of
arbitrariness and to enable individuals to anticipate the consequences of their actions (they referred to _Žaja v._
_Croatia, no. 37462/09, § 103, 4 October 2016). Such unlimited discretion on the part of judges to interpret the_
features of the composition of a criminal act had led to the courts delivering arbitrary decisions and to the
supremacy of personal interests over the principle of justice.


-----

97. In sum, the applicants considered that they could not have foreseen their conviction for trafficking in human
beings under Article 147 § 2 of the Criminal Code, that crime having been expansively interpreted in their case by
the Supreme Court.
_(b) The Government_

98. At the time when the criminal acts had been committed by the applicants, they had constituted the crime of
trafficking in human beings under national criminal law, construed in line with international standards. Combating
that crime was a priority for the Lithuanian Government and the case-law on trafficking in human beings was widely
developed.

99. Firstly, at the time that the acts in question had been committed, Article 147 of the Criminal Code had not
contained any provisions restricting trafficking in human beings to situations where the victims were trafficked to
foreign countries – Article 147 applied equally to situations in which trafficking took place within the territory of one
State. This coincided with the Court's approach in S.M. v Croatia (cited above, §§ 294-96).

100. Secondly, the applicants had been convicted of trafficking in human beings by means of recruiting through
deception and by taking advantage of the victims' dependency and vulnerability, for the purpose of exploitation and
providing pornographic services. All those elements of the crime had already been comprised by the definition of
the crime in 2005; under a subsequent amendment of 2012 another element – important for the present case,
indicating that the consent of the victim to being exploited was irrelevant, had been added. The criminal law had
been amended in 2005 with the aim of ratifying the Palermo Protocol, which was considered to contain the first
agreed, internationally binding definition of trafficking in human being; that definition had been subsequently
included in the Council of Europe Convention on Action against Trafficking in Human Beings.

101. The wording of the relevant provision of the Criminal Code stemmed from Lithuania's obligation to bring its
standards regarding trafficking in human beings into line with international law, under which trafficking in human
beings included three components: an action (in the applicants' case the process of “recruitment”); the use of
certain means (in the case at issue “deception, [and] taking advantage of the victims' dependency and
vulnerability”); and the purpose of the exploitation in question (in the applicants' case “the pornography”). The
Lithuanian legal system at the time in question ensured practical and effective protection against modern forms of
slavery, being in conformity with the international standards. The case at issue should be read alongside these
lines.

102. The Government disputed the applicants' argument (see paragraph 92 above) that, for Article 147 of the
Criminal Code to apply, a victim had to have been exploited under conditions of slavery or slavery like conditions.
That element had been plainly absent in the applicants' case and had not been referred to in any of the court
decisions convicting the applicants. The Government submitted that it was true that, in order to find that the actions
had constituted trafficking in human beings, “ingredients” from each of the three above-mentioned categories
(action, means, purpose) had to be present together (they referred to Article 4 of the Council of Europe Convention
on Action against Trafficking in Human Beings, see paragraph 74 above). The Government nevertheless underlined
that the purpose of exploitation both under relevant domestic law provision, and in the international documents, was
indicated as alternatives – e.g., slavery or under conditions similar to slavery, prostitution, pornography or any other
forms of sexual exploitation, forced labour or services (including begging), the commission of a criminal offence, or
any other exploitative purpose. Accordingly, slavery (or conditions similar to slavery) was just one of those
alternatives. Therefore, the applicants' allegations were totally unsubstantiated, because suggested by them
reading of the Criminal Code would require that in all cases of alleged trafficking in human beings the victims would
be held in slavery or under conditions similar to slavery, whereas the objectives of the effective protection against
trafficking in human beings were completely different and were related to the aspiration to ensure proper protection
from all the forms of exploitation.

103. In respect of the facts of the case, the Government referred in detail to the Šiauliai Regional Court's and the
Supreme Court's findings and reasoning, subscribing to those courts' conclusion that the applicants' actions had
constituted the prerequisite constituent elements of the crime of trafficking in human beings, which were provided in


-----

the criminal law at the time of the commission of the crime. The applicants' conviction had therefore been lawful,
within the meaning of Article 7 of the Convention.

104. The Government also pointed out that in the case of S.M. v. Croatia the Court had acknowledged that there
was _prima facie_ evidence of trafficking in human beings in a similar situation, where the applicant had been
contacted via social media and had been promised a job but had subsequently been forced into prostitution by the
use of force, threats, monitoring, making the necessary arrangements for communicating with clients online and
lending money. The Court had also been of the view that, owing to problems in her family, the applicant had been in
a vulnerable position, given that vulnerability may take any form, be it physical, psychological, emotional, familyrelated, social or economic. Such a situation could be caused by any hardship as a result of which a human being
was impelled to accept being exploited.

105. The Government wished to note that to date the very limited case-law of the Court on Article 4 of the
Convention had largely followed the same approach as that of international and regional instruments in the field of
trafficking in human beings – that is, a rather broad approach to the interpretation of the characteristics of trafficking
in human beings. The specific context of the applicants' case – the fact that the victims' work had taken place
online, which had also dictated the nature of their interaction with the perpetrators and of how of how their work was
overseen, should not lead to a weaker protection of such victims in the light of the identified characteristics not only
of Lithuanian but also of international law. The Government also referred to the Court's case-law, which held that
the States had a positive obligation to ensure the proper protection of victims of modern slavery and to ensure the
criminal persecution of perpetrators (they cited Siliadin, cited above, § 89, 26 July 2005). The interpretation followed
by the domestic courts in the applicants' criminal case had contributed to the effective protection of victims, in line
with the main objectives of the international standards of the fight against trafficking in human beings.

106. The fight against trafficking in human beings had been a priority for the Lithuanian Government for a long time;
they had implemented various programmes and action plans, including measures to identify potential victims; those
programmes and plans had also contributed to the foreseeability of the constituent elements and the essence of
that particularly heinous crime.

107. Lastly, taking into account the fact that in Lithuania human trafficking had been and still was largely undertaken
for the purpose of sexual exploitation, and that most of the identified victims were women, at the time of the events
of the instant case extensive domestic case-law had already been developed which scrutinised various aspects
relating to the establishment of the features of trafficking in human beings, thereby providing an authoritative
interpretation of the relevant features of this crime.

108. To sum up, the applicants had been lawfully convicted of committing the crime of trafficking in human beings in
conformity with the standards of Article 7 of the Convention.
_2. The Court's assessment(a) General principles(i) Article 7 of the Convention_

109. The general principles regarding Article 7 of the Convention have been summarised in _Vasiliauskas v._
_Lithuania ([GC], no. 35343/05, §§ 153, 154, 157 and 160 in limine, ECHR 2015, and recently in Yüksel Yalçýnkaya_
_v. Türkiye [GC], no. 15669/20, §§ 237-42, 26 September 2023, with further references)._

110. In particular, the Court has held that Article 7 embodies, inter alia, the principle that only the law can define a
crime and prescribe a penalty (nullum crimen, nulla poena sine lege) and the principle that the criminal law must not
be extensively construed to an accused's detriment, for instance by analogy. From these principles it follows that an
offence must be clearly defined in the law. This requirement is satisfied where the individual can know from the
wording of the relevant provision and, if need be, with the assistance of the courts' interpretation of it, what acts and
omissions will make him criminally liable. When speaking of “law” Article 7 alludes to the very same concept as that
to which the Convention refers elsewhere when using that term, a concept that comprises statutory law as well as
case-law and implies qualitative requirements, notably those of accessibility and foreseeability (see _Cantoni v._
_France, 15 November 1996, § 29, Reports of Judgments and Decisions 1996-V, and Parmak and Bakýr v. Turkey,_
nos. 22429/07 and 25195/07, § 58, 3 December 2019).


-----

111. The Court has acknowledged in its case-law that however clearly drafted a legal provision may be, in any
system of law, including criminal law, there is an inevitable element of judicial interpretation. There will always be a
need for elucidation of doubtful points and for adaptation to changing circumstances. Again, whilst certainty is highly
desirable, it may bring in its train excessive rigidity and the law must be able to keep pace with changing
circumstances. Accordingly, many laws are inevitably couched in terms which, to a greater or lesser extent, are
vague and whose interpretation and application are questions of practice. The role of adjudication vested in the
courts is precisely to dissipate such interpretational doubts as remain (see Kafkaris v. Cyprus [GC], no. 21906/04, §
141, ECHR 2008, and Huhtamäki v. Finland, no. 54468/09, § 45, 6 March 2012). Article 7 of the Convention cannot
be read as outlawing the gradual clarification of the rules of criminal liability through judicial interpretation from case
to case, “provided that the resultant development is consistent with the essence of the offence and could
reasonably be foreseen” (see Kafkaris, cited above, § 141, with further references).

112. The Court also reiterates that, in principle, it is not its task to take the place of the domestic jurisdictions. Its
duty, in accordance with Article 19 of the Convention, is to ensure the observance of the engagements undertaken
by the Contracting Parties to the Convention. Given the subsidiary nature of the Convention system, it is not the
Court's function to deal with errors of fact or law allegedly committed by a domestic court, unless and in so far as
they may have infringed rights and freedoms protected by the Convention and unless that domestic assessment is
arbitrary or manifestly unreasonable (see, inter alia, Moreira Ferreira v. Portugal (no. 2) [GC], no. 19867/12, § 83,
11 July 2017, and Alparslan Altan v. Turkey, no. 12778/17, § 110, 16 April 2019).

113. However, the Court's powers of review must be greater when the Convention right itself, Article 7 in the
present case, requires that there was a legal basis for a conviction and sentence. Article 7 § 1 requires the Court to
examine whether there was a contemporaneous legal basis for an applicant's conviction and, in particular, it must
satisfy itself that the result reached by the relevant domestic courts was compatible with Article 7 of the Convention.
To accord a lesser power of review to this Court would render Article 7 devoid of purpose (see Kononov v. Latvia

[GC], no. 36376/04, § 189, ECHR 2010, and _Rohlena v. the Czech Republic_ [GC], no. 59552/08, § 52, ECHR
2015).

114. The Court must therefore verify that at the time when an accused person performed the act that led to his
being prosecuted and convicted there was in force a legal provision that made that act punishable, and that the
punishment imposed did not exceed the limits fixed by that provision. While the text of the Convention is the
starting-point for such an assessment, the Court may have cause to base its findings on other sources, such as the
_travaux préparatoires. Having regard to the aim of the Convention, which is to protect rights that are practical and_
effective, it may also take into consideration the need to preserve a balance between the general interest and the
fundamental rights of individuals and the notions currently prevailing in democratic States (see Coëme and Others
_v. Belgium, nos. 32492/96 and 4 others, § 145, ECHR 2000-VII)._
_(ii) Article 4 of the Convention_

115. The general principles regarding human trafficking, within the context of Article 4 of the Convention, including
the States' positive obligations under that provision, have been summarised in S.M. v. Croatia (cited above, §§ 276320).
_(b) Application of the general principles to the instant case_

116. The Court notes that the applicants were found guilty of trafficking in human beings, having, committed that
crime in aggravated circumstances – in respect of two or more persons and having acted in an organised group –
and thus having committed a crime of trafficking in human beings, defined in Article 147 § 2 of the Criminal Code in
its version as in force as of 13 July 2012 (see paragraphs 11 and 57 above).
_(i) Accessibility_

117. It has not been disputed by the parties that the aforementioned provision of the criminal law was in force at the
time of the commission of the applicants' acts. Besides, as noted by GRETA, the offence of trafficking in human
beings for the purpose of sexual exploitation was introduced into the Lithuanian Criminal Code as early as in 1998
(see point 13 in paragraph 82 above). In view of the foregoing, the Court finds that trafficking in human beings, as
such, was clearly recognised as a crime under domestic law at the relevant time, the applicants having committed


-----

the acts in question between September 2012 and August 2013. Given those circumstances, the Court finds that
the domestic law prohibiting trafficking in human beings was sufficiently accessible to the applicants.

118. That being so, the Court notes that the main question in the present case concerns what the applicants saw as
arbitrary judicial interpretation, namely whether the applicants' conviction of trafficking in human beings on the
grounds that their actions, when placing the advertisement for “web models” and the applicants' subsequent
interaction and conduct with those young women had been consistent with the essence of that offence and could
reasonably have been foreseen by the applicants at the time of their participation in the events in 2012 and 2013.
_(ii) Foreseeability_

119. In the light of the above-noted principles concerning the scope of its supervision (see paragraphs 112-114
above), the Court considers that its task in the present case is to examine whether the relevant law was foreseeable
– that is, whether the applicants' acts, at the time when they were committed, constituted a crime defined with
sufficient precision by the domestic law (see, mutatis mutandis, Korbely v. Hungary [GC], no. 9174/02, § 73, ECHR
2008) as to be able to guide the applicants' behaviour and prevent arbitrariness. In so doing the Court must
ascertain whether the applicants could have known from the wording of the relevant provision – and, if need be,
with the assistance of the domestic authorities' interpretation of it and with informed legal advice – what acts or
omissions would render them liable to prosecution for the criminal offence. Given that foreseeability also requires
that a rule afford a measure of protection against arbitrary interferences by the public authorities (see _Centro_
_Europa 7 S.r.l. and Di Stefano v. Italy_ [GC], no. 38433/09, § 143, ECHR 2012), the Court must also ascertain
whether the relevant law was sufficiently clear to provide, in accordance with the object and purpose of Article 7 of
the Convention, effective safeguards against arbitrary prosecution, conviction or punishment (see Žaja, cited above,
§ 93, and the case-law cited therein).
_(α) Whether the wording of the relevant provision was sufficiently clear_

120. The Court notes that the definition of trafficking in human beings under Article 147 of the Criminal Code, under
which the applicants were convicted, contains the elements of action (which includes recruitment); means (which
includes, inter alia, deception and making use of victims' vulnerability); and exploitative purpose (which includes the
aim of using the victim for the purpose of providing pornographic services) (see paragraph 57 above). The Court
refers to the findings of GRETA – namely, that the definition of trafficking in human beings, as set out in Article 147
§ 1 of the Criminal Code, contains the elements of action, means and purpose, as defined by Article 4 of the
Council of Europe Convention on Action against Trafficking in Human Beings (see paragraph 74 above), that treaty
having been ratified by Lithuania in 2012 (see paragraph 71 above). Those same three elements are present in
Article 3 (a) of the Palermo Protocol, ratified by Lithuania in 2003 (see paragraphs 59 and 62 above). That being so,
and contrary to the applicants' suggestion (see paragraph 91 above), the Court is unable to find that the wording of
the relevant domestic law provision gives rise to uncertainty or ambiguity as to the elements of the crime of
trafficking in human beings (contrast Žaja, cited above, § 97).

121. The Court cannot but note that the applicants placed much emphasis on the notion of slavery or slavery-like
conditions, mentioned in Article 147 § 1 of the Criminal Code. In the applicants' view, that element had been a
necessary prerequisite for the establishment of the crime of trafficking in human beings, and yet that element had
been absent in their case (see paragraph 92 above).

122. The Court finds, firstly, that although the notion of slavery or slavery-like conditions is indeed mentioned in
Article 147 § 1 of the Criminal Code, that appears to be only one of several alternative forms of exploitation, which
include prostitution, exploitation for pornography – the latter having been established in the applicants' case (see
paragraph 16 above), or other forms of sexual exploitation. This has also been argued by the Government, and also
finds support in international law, namely – the explanatory reports on the Palermo Protocol (see paragraphs 65
and 66 above), which, as has been pointed by the Government, had been the inspiration for the drafting of Article
147 of the Criminal Code (see paragraph 100 above). The Court also accepts the Government's argument (see
paragraph 102 above) that, given the States' positive obligation to combat trafficking in human beings (see also
_Rantsev v. Cyprus and Russia, no. 25965/04, §§ 267 and 271, ECHR 2010 (extracts)), it would be too restrictive to_
interpret that crime in such a manner that slavery or slavery-like conditions would be an indispensable constitutive
element thereof. In the present case, the Court finds that the interpretation of Article 147 of the Criminal Code


-----

whereby exploitation of a human being may take one or more of several forms, of which slavery or slavery-like
conditions is one but not an indispensable element, was foreseeable and consistent with the essence of the offence
in question (see, mutatis mutandis, Huhtamäki, cited above, § 51, and the case-law cited therein).

123. Secondly, the Court cannot overlook that the applicants have not raised with the domestic courts the issue of
whether slavery or slavery-like conditions were a necessary element of the crime under Article 147 § 1 of the
Criminal Code. Although it is understandable that they would not have raised it with the Supreme Court, given that
they had been acquitted by the Court of Appeal, there was nothing to discourage the applicants from raising the
matter with the Court of Appeal, given that they had been contesting their conviction by the Šiauliai Regional Court.
However, their twenty-eight-page-long appeal to the Court of Appeal made no reference of the slavery criterion
whatsoever; rather, to a large extent it concentrated on what the applicants saw as an erroneous assessment of
evidence (see paragraphs 19-22 above). That being so, the Court finds that absence of slavery or slavery-like
conditions, in and of itself, did not preclude the trial and cassation courts from convicting the applicants of trafficking
in human beings and, in the light of that sole fact, did not make their conviction unforeseeable. The Court reiterates
that Article 7 of the Convention cannot be read as outlawing the gradual clarification of the rules of criminal liability
through judicial interpretation from case to case, provided that the resultant development is consistent with the
essence of the offence and could reasonably be foreseen (see Streletz, Kessler and Krenz v. Germany [GC], nos.
34044/96 and 2 others, § 50, ECHR 2001-II). Moreover, it is not the Court's task to deal with the questions relating
to the interpretation and application of national law by national courts unless there has been a flagrant nonobservance or arbitrariness in the application of that law. This being so, in the instant case, the Court is unable to
find such non observance or arbitrariness in the present case (see Huhtamäki, cited above, § 52, and the case-law
cited therein).
_(β) Whether the Šiauliai Regional Court's and the Supreme Court's interpretation of the crime of trafficking in human_
_beings was foreseeable in the applicants' case, so as to cover the applicants' acts_

124. The Court has held that the question of whether a particular situation involves all the constituent elements of
“human trafficking” (action, means and purpose) is a factual question that must be examined in the light of all the
relevant circumstances of the case in question (see S.M. v. Croatia, cited above, § 302).

125. In the present case, the criminal investigation into suspicions that the crime of trafficking in human beings had
been committed was opened on the basis of a complaint lodged by one of the victims (see paragraph 7 above;
regarding the States' positive obligation to investigate and prosecute actions amounting to trafficking in human
beings, see Zoletic and Others v. Azerbaijan, no. 20116/12, §§ 180-84, 7 October 2021).

126. The Court will now turn to the constitutive elements of the crime of trafficking in human beings – it must
ascertain whether the domestic courts' interpretation that those elements had been present in the applicants'
actions was consistent with the essence of that offence and was foreseeable within the meaning of Article 147 § 1
of the Criminal Code.

_‒ Action_

127. The Court observes that, under Article 147 § 1 of the Criminal Code, “action” includes such acts as the sale,
transfer, acquisition, recruitment and transportation of a person or holding that person captive (see paragraph 57
above). Those elements essentially correspond to the definition of the crime of trafficking in human beings under
international law, including the Palermo Protocol and the Anti-Trafficking Convention (see respectively paragraphs
63 and 74 above).

128. In the applicants' case it had been the recruitment that the prosecutor and the trial and cassation courts
established had constituted the “action”. Namely, it was established by courts at two instances, and not contested
by the applicants, that the applicants had placed an advertisement online that “web models” were being sought for
what the Supreme Court later found to be an unrealistically well-paid job (see paragraphs 5, 13, 46, 49-51 above;
the fact that new information technologies are used for recruitment having been underlined by the Explanatory
report to the Anti Trafficking Convention, see paragraph 76 above). The Court also does not overlook that whilst the
applicants' conviction appears to have rested mainly on one kind of action, that is, recruitment, their activities also
appear to have contained other, alternative, actions noted by the Lithuanian authorities, such as transportation –


-----

having arranged one of the victim's – V.T.'s – arrival to another town in Lithuania and her placement in a hotel, with
her child (see paragraph 15 above; regarding the fact that transportation does not need to be cross border, see
paragraph 76 above). Indeed, not only did the applicants arrange webcams and computers for most of the victims
(see paragraph 15 above), but they also found accommodation for many of them in order that those victims could
provide pornographic services, which suggests the element of “harbouring” – one of the constituent “actions” of
trafficking (see paragraphs 9, 15 and 51 above, see also _S.M. v. Croatia, cited above, § 330). Some of the_
applicants lived in those apartments together – some even with a child (see paragraph 15 above).

129. Given the above considerations, the Court finds that the applicants could have foreseen that by placing the
advertisement on the web, this being exacerbated by their aforementioned subsequent acts, they had been
committing the “action” of recruitment, which is a criminal action within the meaning of Article 147 § 1 of the
Criminal Code.

_‒ Means_

130. The Court refers to Article 147 § 1 of the Criminal Code, which defines “means” as the use of physical violence
or threats, or otherwise depriving the victim of the possibility to resist, or taking advantage of the victim's
dependency or vulnerability, or resorting to deception (see paragraph 57 above).

131. As established by the Šiauliai Regional Court, the victims' personal situation suggested that they had could
have been considered as belonging to a vulnerable group. Although the applicants asserted that they had merely
contributed to the well-being of the victims', who had taken the job only to gain money for leisure activities (see
paragraphs 20 and 94 above), the Court does not lose sight of the trial court's findings that, _inter alia, several_
victims (R.G. and T.M.) had been raising small children alone (see paragraph 15 above), and one of the victims
(J.Š.) had wished to help her ill mother and had younger siblings (see paragraphs 9 and 15 above). The Court also
notes that several of the victims had been very young (one of them, P.Ch., having been eighteen years old and still
been in high school; a few other – D.D., V.T. and T.M. having been nineteen years old, see paragraph 9 above),
which had rendered them vulnerable owing to their lack of life experience, the victims' naivety and gullibility having
been noted by the trial and the cassation courts (see paragraphs 14, 49 and 50 above). It was therefore not
unreasonable to hold, as did the trial and cassation courts, that the applicants were capable of assuming a
dominant position over them and abusing their vulnerability in order to exploit them for the purpose of providing
pornographic services (see paragraphs 15, 16, 48 and 50 above). In this connection, the Court also refers to the
Explanatory report to the Anti-Trafficking Convention which indicates that the term “abuse of vulnerability”
comprises abuse of any hardship situation, be it psychological, emotional, family-related, social or economic, which
makes the victim impelled to accept being exploited (see paragraph 77 above).

132. Further, the means used by the applicants, the victims having responded to an online “job” advertisement, is
also indicative as means of trafficking, it being noted that, with the rise of new technologies, some traffickers have
adapted their modus operandi for cyberspace by integrating technology and taking advantage of digital platforms to
advertise, recruit and exploit victims (see paragraphs 5 and 70 above).

133. The Court also does not lose sight of the victims' explanation that the applicants had initially assured them that
they had no reason for concern as to the legality of the proposed job; however the applicants had eventually
insisted that they provide pornographic services (see paragraphs 14, 15 and 49 above; see also S.M. v. Croatia,
cited above, § 329, and paragraph 77 _in limine_ above). The domestic courts eventually found that to constitute
deceit, as one of the constituent “means” of trafficking (see paragraphs 14-16, 47 and 49 above; see also S.M. v.
_Croatia, cited above, § 326)._

134. The Court next turns to the element of control, the applicants having pleaded that the victims had been free to
leave the job when they so wished, and indeed, some of them had left before they had even started or immediately
afterwards (see paragraphs 9 (A.M.), 15 (S.S.), 20 _in fine, 52_ _in limine_ and 92 above). In this context, the Court
finds it important to underline that “force” may encompass the subtle forms of coercive conduct identified by the
Court's case-law in respect of Article 4, as well as by the International Labour Organisation and other international
material (see S.M. v. Croatia, cited above, §§ 141-44, 281-85 and 301).


-----

135. Firstly, the Court refers to the domestic courts' findings that the applicants had lent money to the victims in
order that they could rent apartments and afford basis subsistence, this required a careful and subtle assessment of
the “means” element of human trafficking for the purpose of exploitation for prostitution, and raised an issue of
possible debt bondage as “means” of trafficking (see paragraphs 15 (regarding victims R.G., T.M., V.R., V.T. and
J.A.) and, although only theoretically, acknowledged by the Court of Appeal, see paragraph 34 above; see also
_S.M. v. Croatia, cited above, § 330). The trial and cassation courts did not accept the applicants' submission that_
they had lent the victims the money in their role as benefactors, only as a means of helping them improve their level
of well being (see paragraphs 15, 16, 48, 50 and 51 above), and the Court sees no valid arguments to hold
otherwise (see also point 36 in paragraph 82 above).

136. Secondly, the Court refers to the UNODC Model Law against Trafficking in Persons, wherein it is noted that
“initial recruitment can be voluntary and the coercive mechanisms to keep a person in an exploitative situation may
come into play later” (see paragraph 66 above). Although in the present case the applicants had suggested that the
victims had taken up the “web model” job voluntarily (see paragraph 92 above), it is also plain that afterwards the
applicants not only started exerting pressure on the victims by means of closely monitoring them over the Internet,
suggesting to them how they might work more effectively (see paragraphs 9, 15 and 51 above), but they also
resorted to the use of psychological force, verbal abuse and threats, including of physical violence, in respect of the
victims and/or their family members (see paragraphs 7, 9, 15, 16, 45, 49 and 51 above). The Court also gives
particular weight to the fact that the applicants were found guilty not only of trafficking in human beings, but also of
exerting influence on a victim (see paragraphs 10, 12, 18 and 38 above).

137. Thirdly, the Court refers to the trial and the Supreme Court's findings, based on its consistent case-law, that
restriction of liberty could be understood as both physical and psychological, and that in the applicants' case those
courts had indeed indicated that the victims had felt obliged to continue working for the applicants, by whom they
had been controlled (see paragraphs 15, 16, 45, 49 and 51 above), the Supreme Court having also underlined that,
in order for Article 147 of the Criminal Code to apply, it was not necessary to establish that the victim had been
totally deprived of her liberty (see paragraph 51 in fine above), which had been the situation in the present case.

138. In the light of the above, the Court finds that the applicants could reasonably have foreseen that their pattern of
behaviour would fall within the constitutive elements of the “means” listed in Article 147 § 1 of the Criminal Code.

_‒ The purpose of exploitation_

139. The Court lastly notes that Article 147 § 1 of the Criminal Code provides criminal liability in respect of
exploitation, which includes prostitution, pornography or any other forms of sexual exploitation. In the applicants'
case, it was the victims' exploitation for the purpose of providing pornographic services that was established to have
taken place, the applicants having unlawfully earned money from the provision of pornographic services by the
victims (see paragraphs 7, 9, 13, 14, 15, 43 and 49-52 above), which is, in itself, a prohibited form of conduct under
Article 4 of the Convention (see _S.M. v. Croatia, cited above, § 331). In this regard the Court also refers to the_
GRETA report, which (i) observed emerging trends, such as trafficking in human beings for labour exploitation,
including within Lithuania (see also paragraph 67 above), and (ii) referred to reports of trafficking for the purposes of
forcing victims to engage in criminality, GRETA having urged the Lithuanian authorities to strengthen their efforts to
ensure that offences involving the trafficking in human beings that led to different types of exploitation would be
investigated and prosecuted (see points 52 and 167 in paragraph 82 above). In the Court's view, the general
context described in that report is relevant for the assessment of the facts of the case (see, _mutatis mutandis,_
_Zoletic and Others, cited above, § 195)._
_(γ) Conclusion as to foreseeability_

140. In sum, the Court finds that the wording of Article 147 § 1 of the Criminal Code did not give rise to uncertainty
or ambiguity, and that the interpretation of that provision by the Šiauliai Regional Court and the Supreme Court was
not at the time in question inconsistent and did not lack the required precision, also given the need for the human
rights-based and victim-centred approach to action against human trafficking (see points 177-179 in paragraph 82
above). The Court also finds that, contrary to the analysis by the Court of Appeal (on its erroneous assessment of
evidence, as established by the Supreme Court, see paragraphs 41 and 42 above), but consonant with the spirit of
the Palermo Protocol and the Anti Trafficking Convention the Šiauliai Regional Court and the Supreme Court saw


-----

the applicants' actions against the backdrop of the constituent elements of trafficking in human beings, taken in
combination (see paragraph 75 above). It follows that the applicants were, if necessary, with the benefit of informed
legal advice, able to distinguish between permissible and prohibited behaviour and thus able to foresee, with the
degree of certainty required by Article 7 of the Convention, that recruiting the victims by deceit, and by exerting
control over them, in order to profit from them providing pornographic services, would constitute a criminal offence
under Article 147 § 2 of the Criminal Code. The Court is also unable to find that a room would have been left to the
Šiauliai Regional Court and the Supreme Court for the interpretation and application of Article 147 of the Criminal
Code, that would have been too expansive to provide effective safeguards against arbitrary prosecution, conviction
or punishment (contrast Žaja, cited above, § 106).
_(iii) Overall conclusion_

141. There has accordingly been no violation of Article 7 of the Convention.
**FOR THESE REASONS, THE COURT, UNANIMOUSLY,**

1. Decides to join the applications;

2. Declares the applications admissible;

3. Holds that there has been no violation of Article 7 of the Convention.

Done in English, and notified in writing on 12 December 2023, pursuant to Rule 77 §§ 2 and 3 of the Rules of Court.

**End of Document**


-----

