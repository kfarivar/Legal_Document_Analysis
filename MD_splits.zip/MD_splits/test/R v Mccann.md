# R v Mccann [2022] EWCA Crim 702

Court of Appeal, Criminal Division

Popplewell LJ, Turner J, HHJ Sloan QC

11 May 2022Judgment

Mr. J. Hedworth appeared on behalf of the Applicant.

The Crown were not represented.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

MR JUSTICE TURNER:

1 On 3 November 2021 in the Crown Court at Newcastle, the appellant pleaded guilty to an offence of
holding a person in slavery or servitude, contrary to s.1 (1)(a) of the **_[Modern Slavery Act 2015. On 9](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
February 2022 in the same court he was sentenced to 33 months' imprisonment. He appeals against that
sentence with the leave of the single judge.

2 The victim in this case, Andras Varga, was a Hungarian national who spoke and understood very little
English. He arrived in this country in around 2007, following the breakdown of his marriage. For about
seven years he was doing menial work at various locations in the south of England. When that work dried
up, he ended up living on the streets. After two years, he met a man he knew only as Mike, who gave him
odd jobs for which he was modestly paid. One day, Mike took Varga to meet the appellant in Wales. It is
difficult to escape the conclusion that he was being transferred as if he were a chattel. The appellant
arrived at the meeting point in a yellow, flatbed van which was toeing a caravan. Mike told Varga to put his
belongings in the appellant's vehicle, and the appellant then drove him off to Blyth Beach in
Northumberland. There he stayed for about two weeks in a tent pitched next to the appellant's caravan in
a car park. Varga was not allowed to sleep or wash in the caravan. He had only a bowl to wash in.

3 On 12 October 2017, a Traveller Liaison Officer called on the tent and spoke to Varga, who looked

dishevelled and dirty. The officer was concerned for his well‑being, so he contacted the police. The police

arrived later that morning. They did not see Varga, but they spoke to the appellant who told them that he
was a member of the travelling community and that he would be moving on within the next 24 hours.

4 On 18 October 2017 the Traveller Liaison Officer visited 52 Chestnut Avenue, which was the address of

the appellant's long‑term partner. The officer saw the appellant's caravan outside the address. He also

saw the appellant arrive in a transit van and instruct Varga to unload it Varga was then housed in a metal


-----

hut or outhouse in the garden. Electricity was supplied to the structure by an extension cable from the
house, but the only times Varga entered the house was when he took groceries there or helped with some
decorating. The outhouse contained a television set, a bed and a kettle. There was no sink, no bath, no
shower and no toilet. Varga was not given access to the toilet in the house, so he had to use the toilet in
the local supermarket. He was not able to wash his clothes. The appellant put the claimant to work in a
number of different menial roles. He got the work by cold calling, and at the end of the working day Varga
would be collected by the appellant and taken back to the outhouse. The complainant was paid a meagre
sum, between £10 and £20 per day, for his work. The work included pressure washing driveways,
gardening and repairing a wooden shed. The appellant told Varga he would be moving him into the
wooden shed once the work on it was complete.

5 On 30 November 2017 police officers went to the address and spoke to the appellant. He told them,
untruthfully, that he had found the complainant living in a tent at the docks in Blyth, and had brought him
back to his address. He said that he had offered Varga a place to sleep in, but rather than sleep in the
house Varga said he preferred to sleep in the outhouse. Police checked the outhouse but Varga was not
there, so they left. They returned at midnight and found him there. His appearance was dishevelled. He
was wearing several layers of clothing and appeared to be drunk. He was taken to a police station, and
the appellant and his partner were arrested.

6 The appellant was interviewed twice. The first interview was on 1 December 2017. On this occasion he
said, again untruthfully, that he had found Varga in a skip in Blyth. He said he had taken pity on him and
fed him well. He took him home and allowed him to sleep in the outhouse, which he described as being
well equipped. His intention was to take him to the local authority to see if they could find him a flat. The
appellant said the shed had a lock on it and Varga had the only key, but this was contradicted in interview
by his partner, who said there was no lock on the outhouse. The appellant also went on to say that the
complainant was provided with a daily evening meal and that he came into the house to use the toilet and
to wash. He said that Varga had an aversion to taking a bath. All of this was also contradicted by the
appellant's partner, who said in her interview that the complainant never came into the house. The
appellant said that Varga only worked with him a few times because he was often drunk. He believed that
the complainant was an alcoholic. In his second interview in March 2018 the appellant prepared a
statement in which he maintained his account from his first interview, and answered “no comment” when
he was asked specific questions.

7 When he pleaded guilty very much later, the appellant accepted his guilt on a full prosecution facts
basis. In the following year Varga died from causes unrelated to the circumstances of this case.

8 The grounds of appeal contend: (1) the sentence imposed was manifestly excessive. (2) It was wrong in
principle for the judge to have concluded that the offending fell into Category 4B in the guidelines. The
offending fell into Category 4C, with a starting point of 26 weeks' imprisonment. (3) The judge failed to
have proper regard to the appellant's mitigation. (4) The judge did not allow the appellant sufficient credit
for his guilty plea. (5) The sentence of imprisonment ought to have been suspended.

9 This was offending to which the "Slavery, servitude and forced or compulsory labour/Human trafficking"
guideline applied. The judge found this to be a Category B, medium culpability case. The appellant had
played a significant role, and there was some planning, evidenced by the meeting with Mike in Wales,
before he took Varga to the North East. This was done in the hope of at least some material advantage.

10 We can find no fault in this analysis. The judge found that the categorisation of harm was more
difficult. There was no evidence of direct physical harm or any financial loss, which was likely to be
relatively modest, if at all, within the scope of Category 4. Nevertheless, the lack of autonomy, the risk of
hypothermia, and risk of psychological harm combined to introduce elements of Category 3. The starting
point for Category 3B was six years, and that for 4B was three years.

11 We consider that this was a fair approach and the suggestion that this was a Category 4C case is
without merit. In his sentencing remarks, the judge fully and fairly set out all mitigating features relied upon
in support of this appeal. These included the fact that the appellant had no previous convictions for any
similar offence although we note he had at 19 previous convictions for 51 offences spanning from January


-----

1972 to August 2014, including eleven theft and other similar offences, nine fraud and similar offences, and
three offences against the person. The judge also took into account the appellant's learning difficulties and

ill‑health, and the fact that the conditions in which he himself lived fell short of what most people would find

comfortable. The probation report assessed him as presenting a low risk of offending.

12 Against this background, the judge said that after trial he would have passed a sentence of three years.
In our view, this figure effectively takes into account the mitigating features, without which a figure of
between three and six years to reflect the common elements of categories 3B and 4B would, have been
appropriate.

13 We can find no compelling reason why the appellant, who was always fit to plead, would not have been
able to understand the case against him sufficiently so as not to be able to enter an earlier guilty plea.
Indeed, the case had been first listed for trial as long ago as 11 May 2020, the appellant already having
pleaded not guilty at the plea and trial preparation hearing. Varga died in Hungary, and the appellant
vigorously but unsuccessfully resisted the prosecution application to adduce his evidence as hearsay. It
was only on the second day of the relisted trial that the appellant pleaded guilty. It is clear to us that right
up until that date he had over a long period determined that he would persist in his not guilty plea, and he
capitulated only when the prosecution offered to proceed no further against his partner with whom he had
hitherto been jointly charged.

14 Accordingly, this appeal is dismissed.

_______________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

