# JOHN MILLER against HER MAJESTY'S ADVOCATE 2019 S.C.C.R. 78

[2019] HCJAC 7

High Court of Justiciary, Appeal Court

23 January 2019

**Appeal against Conviction**

**Statutory offence — Human trafficking and exploitation — Meaning of servitude — Whether requires**
**restriction on movement — Human Trafficking and Exploitation (Scotland) Act 2015 (asp.12), s.4(1)(a) —**
**European Convention on Human Rights, art.4**

**Solemn procedure — Judge's charge — Servitude — Requirements of charge — Human Trafficking and**
**Exploitation (Scotland) Act 2015 (asp.12), s.4(1)(a) — European Convention on Human Rights, art.4**

**Sentence — Holding in servitude for period of two months — Whether seven years' excessive**

**Words — "Slavery”, “Servitude”**

Section 4(1)(a) of the Human Trafficking and Exploitation (Scotland) Act 2015 makes it an offence to hold a person
in slavery or servitude in circumstances in which he knew or ought to have known that he was so held. Slavery and
servitude are to be construed in accordance with ECHR. Section 4(3) requires that in determining whether a person
is so held particular regard is to be had to any personal circumstances which make him vulnerable.

Article 4 of ECHR provides that no one shall be held in slavery or servitude. Slavery has been defined by the
European Court of Human Rights as the status or condition of a person over whom powers attaching to rights of
ownership are exercised, and servitude as involving an obligation to provide one's services imposed by coercion,
including an obligation to live on another person's property and the impossibility of altering that condition, and also
including the idea that the person so held feels that the situation is permanent and he cannot change it, where
those feelings are engendered and kept alive by the person responsible for the situation.

The appellant was charged with a contravention of s.4(1) (a) of the Act, in that he held the complainer in slavery or
servitude for a period two months, forced him to live on his farm and refused to allow him to leave, and forced him
to carry out work for little or no pay and that he ought to have known that he was so held (charge (29)). He was also
charged with abducting and assaulting the complainer (charge (28)). He was sentenced to seven years'
imprisonment on charge (29), concurrently with an extended sentence of nine years with a custodial element of
seven years on charge (28). The complainer, who was aged 20, gave evidence that

**[*79]**

he was mentally unstable, that he was slapped about or locked in a shed if his work was not satisfactory, that he
wanted to leave, but was threatened by the appellant that he would be skinned alive if he left, that he was paid


-----

erratically at a rate of £20 a day for four days a week, although he worked every day, that what he would get paid
was never certain, and that sometimes he was not paid at all. He was provided with accommodation in a caravan
owned by the appellant. On one occasion he had managed to escape and had got to York, where the appellant
traced him, threatened him with violence if he did not return, forced him into a car and took him back to Scotland.
He had then contacted the police by mobile phone and had met them in town. There was also evidence that he was
a regular in a local pub and free to move around as he pleased. The Crown did not rely on the complainer's
vulnerability.

The trial judge withdrew the element of slavery from the charge. She directed the jury on the meaning of servitude,
and its distinction from slavery and forced labour. The jury convicted the appellant of charge (28) under deletion of
an averment of locking him in, and of charge (29) under the further deletion of an averment of refusing to allow him
to leave. The appellant appealed to the High Court against his conviction on charge (29) on the grounds of
misdirection, in that (i) the removal of slavery and the further deletion were inconsistent with a finding of servitude,
rather than of forced labour, with which the appellant was not charged; and (ii) by advising them that that a
vulnerability of the complainer, namely his mental health difficulties, was a relevant factor without directing them
that they would have to be satisfied that the appellant had been aware of the vulnerability at the time. He also
appealed against sentence.

_Held (1) that if a person is forced to live under another's control on that person's property, held against his will and_
forced to carry out work for little or no money, he is being kept in a state of servitude, and that a simple direction to
that effect might have sufficed (para.20);

(2)   that it was not disputed that there was sufficient evidence that the appellant had kept the complainer
in a state of servitude, that that would seem clear from the periodic confinement of the complainer and a
requirement upon him to work for little reward; all fenced by threats of violence, and that there was no need
for the judge to explain the distinction between servitude and forced labour, which might have served only
to confuse, as the appellant was not charged with forcing labour on its own (para.22);

(3)   (i) that the evidence that the complainer was a regular in the local pub and shops was before the jury,
and the judge did not require to remind them of this, as no doubt that had just been done in the defence
speech, that the jury would have understood this, hence their deletion of the reference to refusing to allow
the complainer to leave (para.23);

(ii)   that the point was not that he could not leave, it was that he was compelled to come back, live on site
and perform the required labour, that that was presumably the economic motivation behind keeping him in
serfdom and that his ability to wander about the local village and countryside did not change his servitude
status, that the jury's deletion of the words "refuse to allow him to leave" was not fatal in a situation where
the person considered that he had no option but to stay or that, if he left, he would, as occurred in this
case, be found and brought back; and that the first ground of appeal accordingly fell to be rejected
(para.23); and

**[*80]**

(iii)   that s.4 somewhat unnecessarily expressly required the accused to be aware that the complainer is
being held in a state of servitude, but that was all, that the provision relative to taking into account any
vulnerabilities of the complainer might be seen as obvious, and that, equally, whether the appellant was
aware of them might have been a consideration which the jury might have had regard to, if the appellant
had professed ignorance of them but that, in circumstances in which the Crown were not founding upon an
abuse of a vulnerable person (a fact which would have to have been libelled) there was no need for a
specific direction on the point, that whether, at the time, the complainer had mental health difficulties was
not a material part of the case, although it might be ventured that without the existence of some
vulnerabilities it was difficult to conceive of a situation where keeping a person in servitude could persist for
long, and that the second ground of appeal also fell to be rejected (para.24); and appeal against conviction
refused; and

(4)   that a significant sentence of imprisonment was inevitable, although that selected on charge (29) was
at the high end of the spectrum, given the limited timescale and the complainer's relative freedom of


-----

movement, and that in all the circumstances, and in the absence of evidence that the appellant was aware
of the complainer's mental problems, the court would reduce the sentence on charge (29) to one of six
years, to run concurrently with the same custodial term on charge (28) (para.27).

**Cases referred to in the opinion of the court:**

_Attorney General's Reference (Nos. 2, 3 4 and 5 of 2013) (Connors and others), 2013] EWCA Crim 324; [2013] 2_
Cr. App. R. (S.) 71

_CN v France, 11 October 2012, App No 67724/09_

_Prosecutor v Kunarac et al, IT-96-23 and 23/1, 12 June 2002 (International Tribunal for the Former Yugoslavia)_

_R v K_ _[2011] EWCA Crim 1691; [2013] Q.B. 82; [2012] 3 W.L.R. 933; [2012] 1 All E.R. 1090_

_R v Zielinski, [2017] EWCA Crim 758_

_Rantsev v Cyprus and Russia, [2010] ECHR 22; (2010) 51 E.H.R.R. 1_

_Reid v Scott of Harden (1687) Mor. 9505_

_Siliadin v France, [2005] ECHR 545; (2006) 43 E.H.R.R. 16_

_Van Droogenbroeck v Belgium, (1982) E.H.R.R. 443; (1980) Series B No. 44; App No 7906/77, Commission_
decision of 5 July 1979, DR 17.

John Miller was convicted of the charges set out in the opinion of the court on 9 February 2018,after trial in the High
Court at Glasgow before Lady Stacey and a jury. He appealed to the High Court on the grounds referred to in the
opinion of the court.
The appeal was heard on 23 January 2019 by the Lord Justice General (Carloway), Lord Menzies and Lord
Drummond Young.

For the appellant: O'Rourke QC, Considine, Solicitor advocate, instructed by Faculty Appeals Service, for Bridge
_Litigation, Solicitors, Glasgow._

For the respondent: Prentice QC, AD.

On 23 January 2019 the appeal against conviction was refused. The Lord Justice General subsequently delivered
the following opinion of the court.

**LORD JUSTICE GENERAL**
**[*81] Introduction**

[1]

On 9 February 2018, at the High Court in Glasgow, the appellant was convicted, along with Robert McPhee, of two
charges, as follows:

'(28) [O]n 29 and 30 December 2016 at an address in York…and Curryside Piggery, Deas Road, Shotts
you…did abduct (KDW)…and did force him into a motor vehicle…detain him against his will, and did
assault…(KDW), convey him to…Curryside Piggery, all to his injury; and

(29) between 1 November…and 30 December 2016…at Curryside Piggery…you…did hold another person,
namely (KDW)…in servitude in that you did force him to live under your control at…Curryside Piggery and hold
him against his will, force him to carry out work for little or no pay, and the circumstances were such that you
knew or ought to have known that…(KDW) was so held: contrary to the Human Trafficking and Exploitation
(Scotland) Act 2015, section 4(1)(a).'


-----

In returning their verdict on charge (28) the jury deleted the words “and lock him in a trailer”. On charge (29), the
jury deleted the words “refuse to allow him to leave”. The trial judge had already removed a libel of “slavery” and the
words “keep him in squalid conditions” from the jury's consideration. On 15 March 2018, the judge imposed an
extended sentence of nine years' imprisonment (six years custodial) in respect of charge (28) and seven years
concurrent on charge (29).
**Evidence**

[2]

The appellant is the son-in-law of his co-accused, Mr McPhee. They ran businesses involving tarring and paving
and, in the appellant's case, developing a site for caravans. All were members of the travelling community, who
lived sometimes in caravans and sometimes in houses. The complainer, namely KDW, was a young and vulnerable
man. He was aged 20. He had only recently been released from detention and was on licence. Early in crossexamination about his criminal record, the complainer said that he suffered from mental instability and had
previously been compulsorily detained because of this. On being asked about the nature of his instability, he had
said that he had a split personality disorder, depression, anxiety, PTSD, ADHD and drug-induced psychosis. The
complainer was not a member of the travelling community, but had worked with another travelling person in
England. When work became scarce with that person, it was arranged that the complainer should go and work for a
relative of the person, namely Mr McPhee.

[3]

According to the complainer, everything went well for a short time. Matters took a turn for the worse. He would be
slapped about or locked in a shed if his work was not satisfactory. The complainer said that he wanted to leave, but
could not do so. He was threatened by the appellant that he would be skinned alive if he left. He regarded the
appellant as the person who controlled where he lived and worked and what he was paid. The complainer said that
he was paid erratically; £20 per day for four days, although he worked every day. What he would get paid was
never certain. Sometimes he was not paid at all. He was provided with accommodation in a caravan owned by the
appellant.
**[*82]**

[4]

At Christmas 2016, the complainer was staying in York with a girlfriend and her family. He had gone to York to get
away from the appellant and Mr McPhee. He had left the caravan by climbing out of the window and persuading his
father to pay his train fare to York. The appellant had found out where he was and had threatened him with violence
if he did not return to Scotland. The appellant and Mr McPhee went to York, located the complainer, forced him into
a car, and took him back to Scotland against his will. There were recordings of telephone calls between the
complainer and the appellant when the appellant was looking for the complainer in York. The trial judge described
these as “chilling”. The appellant said, for example, “You had better come out…I will skin you alive” and “I'm coming
to get you, just tell me where you are…”. Mr McPhee was present in the car when these conversations were going
on and could be heard in the background.

[5]

Soon after he had been taken back to Scotland, the complainer contacted the police and told them of his
whereabouts. He was able to do this as he had a mobile phone. He arranged to hand himself in for a breach of bail
charge in England. He had climbed out of the caravan window again to go into town and meet the police.

[6]

The appellant gave evidence essentially to the effect that nothing had been against the complainer's will. He had
been allowed to leave the caravan and go to the local pub and shops. There was independent testimony to support
this. The complainer could come and go as he pleased. Had he had any difficulties about anything, he could have
spoken to people in the community or to the authorities without any difficulty. The complainer had gone to York at
Christmas for a few days. He had asked the appellant to collect him, which he had done. At some point the
complainer said that he wanted more time in York and had refused to tell the appellant where he was. The appellant
had lost his temper because he thought that the complainer was “mucking him about”. He denied threatening him or
forcing him to return to Scotland against his will.


-----

**The judge's charge**

[7]

The trial judge defined assault and abduction for the jury. Her directions in that respect were not under challenge.
What was under challenge were the directions in respect of charge (29); holding a person in a state of servitude,
contrary to s.4(1)(a) of the 2015 Act. In this regard the judge had also to define slavery or servitude, contrary to the
Criminal Justice and Licensing (Scotland) Act 2010, s.47(1)(a), which had been the subject of an earlier charge
(22), pre-dating the 2015 Act, and involving Mr McPhee and another complainer.

[8]

The trial judge said this:

'What does 'slavery or servitude' mean? In both Acts of Parliament, Parliament has laid down that they are to
be construed in accordance with the European Convention on Human Rights. The words 'slavery or servitude'
are not given any special definition for the purposes of these Acts, so they are ordinary words in the English
language, but in my telling you what they mean I am told that I have got to have regard to the European
Convention on Human Rights and the law that has been developed under that Convention.

… (T)he Convention says that no one is to be held in slavery or servitude, and it does, in the cases that have
been decided under the Convention, give

**[*83]**

the definition of slavery and it is 'the status or condition of a person over whom any or all of the powers
attaching to the rights of ownership are exercised'. So the definition of slavery involves…rights of ownership.

The definition of servitude is where there is an obligation to provide one's services imposed by the use of
coercion, including an obligation to live on another person's property and the impossibility of altering that
condition. And the law says that this definition includes the idea that the person who is held in servitude…feels
that his situation is permanent and he can't change it. It is enough that those feelings are engendered and kept
alive by the person who is responsible for the situation….'

[9]

The trial judge directed the jury that there was no evidence upon which they could hold that the complainer had
been held in a state of slavery. She continued:

'The situation is different for servitude. I do not say for a moment that the evidence proves people were held in
servitude because…it's for you to decide what is proved, but I do say that you could decide…on the evidence,
depending on the view that you take of the facts, that people were held in servitude in terms of these charges.

…Obviously there are plenty of people who work, for example, in hotels, and… live in for their jobs, and of
course they're not held in servitude. They go to their work, they stay there overnight and they get paid. That
does not mean that they are held in servitude. And the reason for that is that the definition includes an element
of coercion, which means people being forced to work by some means. Now it's a very wide definition, and so
the forcing could be physical force, or the threat of it, or it could be more subtle than that. It could be not getting
paid the right amount that you think you're due. It could be not getting fed if they don't work.

… (T)he definition also imports into it a feeling of the person concerned not being able to alter the situation.'

[10]

The trial judge gave an example of a young girl being brought to the UK and forced to work in a house. This was
derived from Siliadin v France. She then continued:

'…As regards…charge (29)…it's got the two extra bits where you have to consider any personal attributes of
the person that make him more vulnerable than other people, personal circumstances of the person and
examples are given in the act of being a child, or the person's age, or the person's family relationships or
health They are examples They are not exclusive there could be other things but these are examples to give


-----

you the flavour of the sorts of things you've got to consider…so that's the first thing, the personal
circumstances. And the second one is the consent of a person to any of the acts does not preclude a
determination that he…is held in servitude.

Now what does that mean? Well, it could mean that if the set -up is such that a person feels that he is coerced
to work, that he has to stay in the property where he is sleeping, if he feels, with some basis, not in imagination,
but with some basis that he can't get out, then it may not be necessary for him to be threatened and reminded
of that every morning first thing, because it may be that that's the set-up and some threat of violence now and
again would suffice.

**[*84]**

… (S)o…a matter of fact and degree in light of all the evidence…the fact that somebody actually does get away
doesn't mean that they've never been held in servitude…

So it's all a matter of fact and a matter of degree for you to decide. Now, of course, you know what counsel
says…that this is ridiculous, because the evidence showed that people were free to come and go…

So various counsel have said how can you be in servitude if you're out and about? You're either canvassing at
people's houses or you're laying tarmac or monoblocs and you can just walk away.

…But, in this case, what is being suggested here is that these people in these two charges, (22) and (29), were
held in servitude because they felt threatened if they didn't, and you've got to consider all of the evidence in the
case, as I've told you several times, and so the suggestion is that their evidence is to the effect that they
thought that they had to work, they got paid some times and not other times, they weren't very sure how much
they were supposed to be paid. They could walk away but they thought there were consequences if they did.
They thought that they would be found and brought back, and they thought that there would be violence visited
on them if they did that.

…[I]t's a matter for you to decide whether or not you feel that that amounts to being held in servitude in the way
in which I have defined it for you. As I said to you, it's not straightforward. Now, it requires quite a bit of thought
and, as regards the second one, that's charge (29), because that's a later Act, 2015, it's got the two extra bits
where you have to consider any personal attributes of the person that make him more vulnerable than other
people, personal circumstances of the person and examples are given in the Act of being a child, or the
person's age, or the person's family relationships or health. They are examples. They're not exclusive, there
could be other things….'

**SubmissionsAppellant**

[11]

The grounds in the note of appeal against conviction were that the trial judge misdirected the jury: (1) by failing to
give adequate directions on what was required to constitute servitude; and (2) by advising that a vulnerability of the
complainer, namely his mental health difficulties, was a relevant factor without directing the jury that they would
have to be satisfied that the appellant had been aware of the vulnerability at the time. On the first element, the
contention, as developed in oral submission, shifted from there being a misdirection to a suggestion that the judge's
removal of “slavery” and the jury's deletion of “refuse to allow him to leave” were inconsistent with a finding of
servitude, but more akin to forced labour.

[12]

The offences of keeping a person in a state of slavery or servitude or of compulsory or forced labour were subtly
different. Forcing a person into a state of slavery was an offence under the Roman Lex Fabia (Digest 48.15.6.2
(Callistratus)) and in early Scots law (Reid v Scott of Harden (the “tumbling lassie”)). Indicia of slavery included
“control of someone's movement, control of physical environment, psychological control, measures taken to prevent
or deter escape, force, threat of force or coercion, duration, assertion of exclusivity, subjection to cruel treatment
**[*85]**

and abuse, control of sexuality and forced labour” (Prosecutor v Kunarac, at para.119).


-----

[13]

Servitude had to be construed in accordance with art.4 of the Convention. In terms of _Siliadin v France (at_
paras.123 and 124), what was prohibited was a

'particularly serious form of denial of freedom'. It included, in addition to the obligation to perform services, the
obligation for the serf to live on another person's property and the impossibility of altering his condition (Van
_Droogenbroeck v Belgium (1980) at paras. 78–80 and [1979] at para.59). Servitude meant an obligation to_
provide services imposed by the use of coercion and was linked with the concept of slavery (see also _CN v_
_France at para.91;_ _Attorney General's Reference (Nos.2, 3 and 5 of 2003)_ (Connors and others)). Servitude
embraced the totality of the status or condition of a person. It was distinguishable from slavery in that it did not
involve ownership but less extensive forms of restraint. It meant an obligation to provide services imposed by
the use of coercion (see R v K (S) at para.7).

[14]

Accordingly, servitude was defined as requiring that a person was coerced into living on another person's property
in order to perform services for him or others in circumstances in which he was made to feel that it was impossible
for him to alter his status. Put another way, servitude was an obligation to provide services imposed by the use of
coercion and was linked with the concept of slavery. It was less restrictive than slavery, but more restrictive than
forced or compulsory labour. It differed from slavery in that slavery represented ownership. Servitude was a less
extensive form of restraint but, in addition to the performance of services, it required the person to live on another's
property in circumstances in which it was impossible for the person to alter his condition.

[15]

Although the trial judge's definition of servitude was consonant with its definition under art.4 of the European
Convention, she had not explained the distinction between servitude and forced or compulsory labour. That was a
significant omission because the jury ought to have been directed that this was not a case where the allegation was
merely that there was forced or compulsory labour. There had to be an element of control. There was evidence,
which the judge did not mention during the crucial part of her directions, that the complainer was a regular in a local
pub and free to move around as he pleased. The jury had deleted part of the indictment involving the appellant
refusing to allow the complainer to leave. The jury received no directions as to how to proceed if they found that the
complainer was free to come and go as he pleased (Rantsev v Cyprus and Russia at para.276).

[16]

The judge also misdirected the jury regarding the significance of the appellant's personal circumstances; that is to
say his vulnerability. The evidence regarding his mental health vulnerability had come spontaneously from the
complainer when he was in the witness box. The trial judge ought to have directed the jury that they could only take
into account personal circumstances where there was evidence that the appellant knew or ought to have known
about them. The international treaties suggested that knowledge of a person's vulnerability went to criminal intent. A
person with the relevant knowledge could use it to manipulate or control the vulnerable person (Palermo Protocol to
the UN

Convention against Transnational Organised Crime 2000, art.3; Gallagher, The

_International Definition of “Trafficking in Persons…” pp.88–92 in Kotiswaran, Revisiting the Law and Governance of_
_Trafficking, Forced Labour and_ **_Modern Slavery). If that factor was relevant, knowledge had to be proved. The_**
Crown had not founded upon any vulnerability, but it had arisen in the evidence and the trial judge ought to have
dealt with it.
**[*86]**

There had been no evidence that the appellant had been aware of the complainer's mental health problems.
_Crown_

[17]


-----

The advocate depute maintained that the trial judge had correctly directed the jury on servitude having regard to
_Siliadin v France and CN v France). There was a hierarchy of severity in relation to compulsory labour, servitude_
and slavery (Attorney General's Reference (Nos.2, 3, 4 and 5 of 2013) at para.7, citing Clayton and Tomlinson,
_Human Rights (2nd edn), paras.9.17–9.20). Slavery involved being in the legal ownership of another. Servitude_
embraced the totality of the person's condition or status, but it did not involve ownership. It meant an obligation to
provide services by the use of coercion. It was different from compulsory labour as it also included the obligation to
live on the other's property and the impossibility of changing the situation. The focus of the appeal had been on the
deletion of that part of the libel relating to refusing to allow the complainer to leave. This was not destructive of the
charge.

[18]

The trial judge had not been asked to direct the jury that the personal circumstances of the complainer were
relevant only if the appellant knew of them. The section only provided that in assessing whether a person had been
a victim, the court had to have regard to his vulnerabilities (see also UN Office, Drugs and crime issue paper –
abuse of a position of vulnerability at pp.13–14). S.4(3) of the 2015 Act sets out an objective test about the personal
circumstances of the complainer. Whether the appellant had been aware of them was irrelevant. Vulnerability had
not been founded upon by the Crown and there had been no suggestion that the appellant had been aware of the
complainer's mental health problems.
**Decision**

[19]

The essence of the offence in s.4(1)(a) of the Human Trafficking and

Exploitation (Scotland) Act 2015 and its predecessor, s.47(1)(a) of the Criminal Justice and Licensing (Scotland)
Act 2010, is that the accused “holds another person in slavery or servitude”. The two terms are thereby
distinguished despite, as the trial judge astutely recognised, the fact that both _Chambers and the_ _Shorter Oxford_
_Dictionary define “servitude” as the state or condition of being a slave. The section also distinguishes between_
servitude and being required to perform forced or compulsory labour. All of these terms are to be found in art.4 of
the ECHR. S.4(2) of the Act directs that they are to be construed “in accordance with” the article. Regard is to be
had to “any personal circumstances…that make the person more vulnerable than other persons”. The statute thus
introduces certain somewhat complicating features into what might otherwise be a straightforward question in a
case such as the present.

[20]

The broad question for the jury was whether the appellant deliberately kept the complainer “in servitude”. The
circumstances giving rise to that state were libelled as being that the appellant: (1) forced the complainer to live
under his control at the Piggery; (2) held him against his will; and (3) forced him to carry out work for little or no pay.
Although it is compulsory, in terms of ss.4(2) and (3), to construe the reference to servitude in accordance with art.4
of the European Convention and to have regard to any vulnerabilities of the complainer, it is difficult to conceive
**[*87]**

of a person not being in a state of servitude if, as the jury found in fact, the three elements of the libel were
established. If a person is forced to live under another's control on that person's property, held against his will and
forced to carry out work for little or no money, he is being kept in a state of servitude. A simple direction to that
effect may have sufficed.

[21]

The trial judge nevertheless took time to explain the wider meaning of servitude, first, by distinguishing it from
slavery; consideration of which she withdrew from the jury. As the judge correctly reasoned, slavery carries with it
connotations of ownership, which might not be present in servitude. This is suggested by the classic definition of
slavery in the Slavery Convention 1927 (see, Siliadin v France at para.122).

Servitude, according to _Siliadin (at para.123), involves “a particularly serious form of denial of freedom (Van_
_Droogenbroeck v Belgium (1982) at para.58), including: “in addition to the obligation to provide certain services to_
th th bli ti th ' f' t li th th ' t d th i ibilit f h i hi t t ” (V


-----

_Droogenbroeck v Belgium, Commission report at para.79). Servitude means (ibid., para.124): “an obligation to_
provide one's services that is imposed by the use of coercion, and is to be linked to the concept of 'slavery'…”.
Servitude involves “aggravated” forced or compulsory labour in which the person feels that his “condition is
permanent and…unlikely to change” (CN v France at para.91). It is sufficient if the person's understanding is
brought about or kept alive by those responsible for the situation (ibid).

[22]

It was not disputed that there was sufficient evidence that the appellant had kept the complainer in a state of
servitude. That would seem clear from the periodic confinement of the complainer and a requirement upon him to
work for little reward; all fenced by threats of violence. The trial judge had, as her report reveals, carefully
considered the Convention jurisprudence. She directed the jury accordingly, using the guidance and the specific
words provided by Siliadin v France; Van Droogenbroeck v Belgium; and CN v France. There was no need for the
judge to explain the distinction between servitude and forced labour. That may have served only to confuse. The
appellant was not charged with forcing labour on its own.

[23]

The evidence that the complainer was a regular in the local pub and shops was before the jury. The judge did not
require to remind the jury of this, as no doubt that had just been done in the defence speech. The jury would have
understood this, hence their deletion of the reference to refusing to allow the complainer to leave. The point was not
that he could not leave, it was that he was compelled to come back, live on site and perform the required labour.
That was presumably the economic motivation behind keeping him in serfdom. His ability to wander about the local
village and countryside did not change his servitude status. The jury's deletion of the words “refuse to allow him to
leave” was not fatal in a situation where the person considered that he had no option but to stay or that, if he left, he
would, as occurred in this case, be found and brought back. The first ground of appeal accordingly falls to be
rejected.

[24]

Section 4 somewhat unnecessarily expressly requires the accused to be aware that the complainer is being held in
a state of servitude, but that is all. The provision
**[*88]**

relative to taking into account any vulnerabilities of the complainer might be seen as obvious. Equally, whether the
appellant was aware of them may have been a consideration which the jury might have had regard to, if the
appellant had professed ignorance of them. However, in circumstances in which the Crown were not founding upon
an abuse of a vulnerable person (a fact which would have to have been libelled) there was no need for a specific
direction on the point. Whether, at the time, the complainer had mental health difficulties was not a material part of
the case, although it might be ventured that without the existence of some vulnerabilities it is difficult to conceive of
a situation where keeping a person in servitude could persist for long. The second ground of appeal also falls to be
rejected.

[25]

The appeal against conviction is according refused.
**Sentence**

[26]

Leave to appeal was granted only in respect of the seven years imposed on charge (29). The basis for the appeal is
that the period is excessive having regard to the duration of the libel (two months). The trial judge noted the
appellant's record of previous convictions, which extended from 2004 to 2017 and included an offence in England in
2004 of threatening behaviour and a conviction at Falkirk Sheriff Court in 2005 for assault and abduction, albeit in a
domestic context. The Criminal Justice Social Work Report described the appellant as a married man with five
children. He had been involved in developing a caravan site, where he lived with his family, for holiday use. The
judge considered that the charges, of which the appellant had been convicted, showed that his attitude was that he
was entitled to tell the complainer what to do and where to live. He backed up his instructions with violence. The
judge regarded keeping a man in servitude for a period of two months as a serious matter. In selecting the sentence


-----

of seven years, it would appear that the trial judge took into account the complainer's mental instability as a
vulnerability.

[27]

The court is conscious of the words of Lord Judge CJ in Attorney General's Reference Nos.2, 3, 4 and 5 of 2013 (R
_v Connors), cited by Davis LJ in R v Zielinski at para.18) that:_

'10. Sentences in this class of case must make clear, not merely that the statutory minimum wage should not
be undermined, but much more important, that every vulnerable victim of exploitation will be protected by the
criminal law, and they must also emphasise that there is no victim, so vulnerable to exploitation, that he or she
somehow becomes invisible or unknown to or somehow beyond the protection of the law. Exploitation of fellow
human beings in any of the way criminalised by the legislation represents deliberate degrading of a fellow
human being or human beings. It is far from straight forward for them even to complain about the way they are
being treated, let alone to report their plight to the authorities so that the offenders might be brought to justice.
Therefore when they are, substantial sentences are required, reflective, of course, of the distinctions between
enslavement, serfdom, and forced labour, but realistically addressing the criminality of the defendants.'

A significant sentence of imprisonment was inevitable, although that selected on this charge was at the high end of
the spectrum, given the limited timescale and
**[*89]**

the complainer's relative freedom of movement. In all the circumstances, and in the absence of evidence that the
appellant was aware of the complainer's mental problems, the court will reduce the seven years selected and
substitute six years, to run concurrently with the same custodial term on charge (28).

_[2019 S.C.C.R. 78](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V80-R1C2-8T41-D3N9-00000-00&context=1519360)_
**COMMENTARY**

There is little to add to the opinion of the court. The court at least implicitly approved the removal of the element of
slavery from the charge. No one can be held in slavery in the UK. The more general use of the term nowadays is an
example of what might be called rhetorical hyperbole, of a kind frequently encountered in the press but hardly
appropriate in legal terminology.

The case also makes it clear that servitude can exist even where the complainer has a certain amount of freedom
to come and go.

**End of Document**


-----

