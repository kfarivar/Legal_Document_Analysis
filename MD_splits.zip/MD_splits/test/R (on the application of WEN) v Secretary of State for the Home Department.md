# R (on the application of WEN) v Secretary of State for the Home Department

 [2019] EWHC 2104 (Admin)

Queen's Bench Division, Administrative Court (London)

Margaret Obi (sitting as a deputy judge of the High Court)

31 July 2019Judgment

Grace Capel (instructed by Duncan Lewis Solicitors) for the Claimant

Eric Metcalfe (instructed by Government Legal Department) for the Defendant

Hearing date: 18 June 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Margaret Obi:**

**Introduction**

1. This is an application for judicial review. The Claimant challenges the Defendant's decision, dated 11
December 2018, in which he determined that there are no reasonable grounds to conclude that she is a
victim of human trafficking. The Claimant complains that the decision is in error of law, irrational and
procedurally unfair. The Claimant also challenges the reasonableness of the Defendant's conclusion that
she was fit to fly as set out in the decision letters dated 8, 15 and 17 January 2019. There is a separate
challenge to the letter, dated 17 January 2019, on the basis that it is in error of law and irrational.

2. The Claimant seeks an order quashing the decisions and any other order the court thinks fit.

3. The reasonable grounds decision is of critical importance to the Claimant. A negative decision means
that there is no impediment to removal from the UK. Although a positive decision does not automatically
grant a right to remain in the UK, recognition as a victim of trafficking attracts various protective rights
including the right, in certain circumstances, to be issued with a renewable residence permit.

**Background**

4. The Claimant is a 30-year-old Brazilian national. She has two children who live with their paternal aunt
in Brazil.

5. On 21 June 2018, the Claimant left Brazil and flew to Portugal. On 29 June 2018, she left Portugal and
flew to Dublin. On 4 July 2018, the Claimant entered the UK on a valid Brazilian passport via a ferry from
the Republic of Ireland. She was granted leave to enter as a visitor for three months. The leave to enter
was valid until 4 October 2018 and prohibited the Claimant from undertaking paid employment.

6. On 28 September 2018, immigration officials encountered the Claimant working in the kitchen of an
Italian restaurant in West London. The Claimant was interviewed with the assistance of a Portuguese
interpreter, in which she admitted that she had been working in the restaurant for two months, for which
she was paid £300 per week. During the interview she made no mention of being exploited or trafficked.


-----

She also stated that she did not have any medical problems and did not take any medication. Following the
interview, the Claimant was arrested and served with a RED.0001 notice (removal notice for overstayers,
illegal entrants and persons in breach of their conditions) and a RED.0003 notice (statement of additional
grounds). The Claimant was assessed as (i) not falling within the Adults at Risk (AAR) policy and (ii) being
at high risk of absconding due to her illegal working.

7. The Claimant was detained at Yarl's Wood Immigration Removal Centre ('Yarl's Wood'). On 1 October
2018, the Claimant was assessed by health care workers at Yarl's Wood. She stated that she was not
taking any medication, had not self-harmed or attempted suicide in the last 12 months and had no suicidal
thoughts or thoughts of self-harm.

8. On 2 October 2018, the Claimant disclosed that '…she had come to the UK because an individual
_asked her to come here to marry him but once here she found out this was not going to happen and he has_
_been threatening her.' The Defendant's officer considered that '…the issues she has raised are serious_
_enough that I believe that she needs to report them to the police and I will arrange that SERCO get the_
_police to come and interview her.'_

9. On 5 October the Claimant was served with removal directions. That same day she self-harmed and an
Assessment Care in Detention and Teamwork (ACDT) plan was opened. On 6 October 2018, the Claimant
claimed asylum. On 7 October 2018 the removal directions were deferred.

10. On 11 October 2018, in a review of the Claimant's detention, the reviewing officer stated that she had
considered the AAR policy and noted that, '…there is no evidence (explicitly claimed or implied) of any risk
_indicators and the subject is not therefore considered to be at risk of vulnerability.' The reviewing officer_
also considered that the Claimant's asylum claim was considered suitable to be progressed while she
remained in detention.

11. On 12 October 2018 the Claimant's Screening Interview took place. The Claimant stated that the basis
of her asylum claim was fear for her life. She stated, 'My ex-husband has threatened to kill me.' The
interviewing officer was male. Amongst other things the Claimant was asked, 'Have you ever been
_exploited or reason to believe you were going to be exploited?'. Her response was 'no'. She was also_
asked if she would prefer to be interviewed by a man or a woman at her asylum interview. Her response
was 'no preference'. The Defendant's General Cases Information Database records that on the same date
information the claimant's case was raised at an 'individual needs meeting' and 'there was information
_received about the applicant where she stated that a person had photos of her on [his] phone and is_
_making threats to disclose these photos.' The case notes record that 'the applicant has been advised to_
_report this to the police and SERCO are helping her to do this.' On 13 October 2018, the Claimant was_
examined by a GP, Dr Thompson. The Claimant told Dr Thompson that she had been the victim of
domestic violence by her ex-partner in Brazil. Dr Thompson noted scarring on her chin, abdomen and
thumb which the Claimant attributed to the domestic violence. Dr Thompson declined to issue a Rule 35
(victim of torture) report on the basis that the Claimant was not 'powerless to leave'.

12. On 19 October 2018, the Defendant received information that the Claimant had been assisted to report
her 'partner' to the police and an appointment with the police was scheduled for 21 October 2018. The
ACDT was closed but the Defendant was advised that '…if removal directions were to be set I would ask
_that the Duty Operations Manager be informed prior to issuing them.'_

13. On 23 October 2018, the Defendant received information from an officer at Yarl's Wood that the
Claimant stated '…if […] she was forced to go back to Brazil then she would kill herself here as she would
_be dead if returned.' She also stated that '…she has no thoughts about suicide now.' The officer stated_
'…she will need to be on constant supervision' if given bad news.

14. On 26 October 2018, the Claimant's substantive asylum interview took place. During that interview she
disclosed an account of serious and sustained domestic violence by her ex-partner in Brazil. She also
disclosed that she feared Mr LU (also known as OQ) whom she said had paid for her ticket to the UK. The
Claimant explained that prior to travelling to the UK she had only communicated with Mr LU via WhatsApp
and Facebook. She stated that he had offered to marry her, but it was only when she arrived in the UK that


-----

she discovered that he was a prisoner in Wormwood Scrubs. She visited him 4 or 5 times in prison. He
would call her at 2 or 3 o'clock in the morning using a camera on his smartphone and '…he would make

_[her] take [her] clothes off to check if [she] had been with any man.' The Claimant reported that she initially_
stayed at a house paid for by Mr LU but when they fell out, he stated that he was no longer going to pay
her rent and told her to find a job. One of the Claimant's roommates took her to the restaurant in West
London where she was given work. According to the Claimant's account Mr LU subsequently demanded
that she repay the £4,000 airline ticket that he had purchased on her behalf. When the Claimant refused to
visit him in prison, he threatened to kill her. At the conclusion of the interview the Claimant was asked if
she was feeling fit and well. Her response was 'no'. She stated that she was experiencing headaches,
difficulty sleeping and eating and was tearful. She also stated that '…if they book me to go I am going to
_hang myself in here.'_

15. On 1 November 2018, the Claimant's legal representatives (not her current representatives) wrote to
the Defendant offering corrections and clarifications in relation to the Screening Interview record and
providing further information regarding her claim. The representatives requested that the Defendant
facilitate access to the Claimant's mobile phone held at reception at Yarl's Wood which contained '…audio
_recording of threats made by [OQ].'_

16. On 15 November 2018, the Claimant's asylum application was refused and certified as 'clearly
_unfounded' under s94 of the Immigration and Asylum Act 2002. Both before and after the asylum refusal_
the detention records reveal concerns with regard to the Claimant's 'reactive mild depressive episode', selfharm and suicidal ideation.

17. On 24 November 2018, the Modern Slavery Helpline and Resource Centre (MSHRC) made a request
that the Claimant be referred to the National Referral Mechanism (NRM) as a potential victim of trafficking.
In the NRM referral form the Claimant stated for the first time that she had been forced to give her salary
from the restaurant to one of Mr LU's associates.

18. On 28 November 2018, the Claimant was interviewed via an interpreter in relation to the NRM referral.
The Claimant stated that Mr LU obtained her telephone number through a friend and they 'started to have
_regular conversations over the telephone as a couple.' He 'told [her] that he was going to marry [her]' and_
'provide [her] with a comfortable life.' He sent her money to apply for a passport and bought her ticket to
the UK. She was assisted by several of his friends and relatives at each stage of her journey to England
via Portugal, Ireland and Wales. She was taken to a pre-arranged address, where she was given a room.
Mr LU initially claimed to be working in Scotland and would telephone her '…at 2-3 o'clock in the morning
_using a video-link for [her] to confirm that she did not have sex with another man.' At some point after she_
arrived in the UK, she learned that he was a serving prisoner and she visited him 4-6 times. The Claimant
stated that '…after that things started to sour and he told [her] that [she] will need to look for a job.' A man
living at the same address as the Claimant took her to the restaurant where she worked washing dishes.
When the Claimant refused to visit Mr LU in prison, he threatened her by stating, '…you'd better come or I
_will kill you.' She subsequently moved to another property because of the threat. The interviewer then_
explored the circumstances in which the Claimant was working. Amongst other things the Claimant stated
she was allowed to leave the house and the restaurant to travel freely by herself.

19. On 30 November 2018, a physician at Yarl Wood, Dr Khan, issued a Rule 35 report in respect of the
Claimant noting that her account of domestic violence was consistent with her scars and she could be a
victim of torture. On 4 December 2018 the Defendant considered the Rule 35 report and assessed the
Claimant to be Level 2 under the AAR policy but decided against release on the basis that her removal was
imminent, she was at risk of absconding and the doctor had not indicated that a period of detention would
worsen her symptoms.

20. Between 6 December 2018 and 13 December 2018 (when the negative reasonable grounds decision
was served on the Claimant during a Multi-Disciplinary Review Meeting) there were various causes for
concern. On 6 December 2018 the Claimant '…barricaded herself in her room by placing her mattress in
_front of the door' following service of removal directions and on 7 December 2018 information was received_
that she was subject to constant supervision following an incident where she had tried to tie a ligature to a


-----

banister. Later that day the Claimant remained on an ACDT with hourly observations. On 9 December
2018 the Defendant received a letter from the Claimant stating '…if you give me the ticket to Brazil, I'll hang
_myself in here.' She included a drawing which depicted her hanging herself and in a coffin. On 10_
December 2018 a request was made that the Defendant liaise with SERCO and Healthcare before issuing
removal directions as '…[the Claimant] is currently on ACDT but stressing she will only go back to Brazil in
_a coffin.' The Claimant attended an ACDT review meeting on 11 December 2018 'due to concerns over_

[her] unpredictable behaviour' and on the same day it was reported that '…due to …[the Claimant's] threats
_and current mental state, it will be in the best interests for safety and safety of others to have a full escort_
_team and a medic accompanying her to Brazil.'_

21. On 19 December 2018 the Claimant was served with removal directions and placed in segregation.
Force was used to relocate her to segregation. However, on 24 December 2018 the removal directions set
for 26 December 2018 were cancelled because the Claimant had not been given the required 5 days'
notice, taking into account the Christmas holiday period. The Claimant was released from segregation.

22. The Claimant was seen by Nurse Bernard Gbeki on 24 December 2018 and 28 December 2018. On
both occasions the Claimant denied any intent to self-harm or suicidal ideation. On 4 January 2019 the
Claimant was seen by Nurse Gbeki for an assessment of her fitness to fly. He stated that the Claimant was
fit to fly but recommended that she be placed in segregation prior to her removal date and that she be
removed with a medical escort.

23. On 9 January 2019 the Defendant served a notice of removal window. The removal window opened on
17 January 2019 and closed on 31 January 2019, after which the Claimant could be removed without
further notice.

24. On 14 January 2019 the Claimant was assessed over the telephone by Dr Amy Chisholm and the
counselling team at the Latin American Women's Rights Service (LAWRS).

25. On 23 January 2019 the Claimant was released on immigration bail.

**The Decisions**

Decision: 11 December 2018

26. The decision letter, dated 11 December 2018, sets out the Claimant's immigration history, summarises
the 'salient points' of her asylum and trafficking interviews and outlines the indicators of trafficking identified
in the NRM referral made by MSHRC. Extracts from ECAT and the Guidance are quoted. Included within
the decision is a summary of objective evidence regarding **_modern slavery in Brazil and the UK. The_**
Defendant noted that the material cited confirmed that modern slavery was prevalent in Brazil and it is a
country where women are subject to exploitation.

27. The Defendant concluded, on the basis of the material that was available on 11 December 2018, that
there are no reasonable grounds for considering that the Claimant is a victim of trafficking. The rationale for
the decision can be summarised as follows:

i) The 'highly significant' fact that the Claimant did not disclose upon arrest that she had been subjected to
exploitation and made no mention of exploitation during her screening interview.

ii) The Claimant had not been subjected to an 'act' of transportation, recruitment, harbouring or receipt
because she 'travelled to the UK willingly' and had 'freedom of movement' in the UK.

iii) Mr LU did not control her via any of the 'means' set out in the trafficking definition because she was
'…free to move out of…' the accommodation he originally provided for her and was able to '…get a job.'

iv) There were discrepancies in the Claimant's account regarding whether she had given all or part of her
salary to Mr LU, via a third party.

v) There was no evidence that the Claimant had a mental health condition '…which would preclude [her]
_from recalling the details of [her] claim.'_

Decision: 8 January 2019


-----

28. On 23 December 2018, the Claimant's solicitors wrote to the Defendant requesting a deferral of the
removal directions for 26 December 2018 pending a full assessment of her mental health. A medical report
from a Professor Cornelius Katona, dated 22 December 2018, was enclosed. The letter indicated that the
negative reasonable grounds decision would be formally challenged in due course.

29. The Defendant's letter in response dated 8 January 2019 stated that the 'fitness to fly' issue was now
academic as the removal had been cancelled. However, the Defendant stated that it would be seeking to
re-schedule the Claimant's removal and that it was likely to take place within a reasonable time. The
Defendant noted that Professor Katona had not conducted an interview with the Claimant in person and
indicated that although the report had been considered it had been afforded little weight. The Defendant
stated that based on the reasoning within the asylum refusal letter, dated 15 November 2018, the
correspondence from healthcare and safeguarding measures in place to facilitate removal, the Claimant is
fit to fly and could seek medical assistance in her country of origin. The letter went on to state that Rule
353 of the Immigration Rules had been applied. Rule 353 states that when a human rights or asylum claim
has been refused and any appeal relating to that claim is no longer pending, the decision maker will
consider any further submissions and, if rejected, will then determine whether they amount to a fresh claim.
The Defendant stated that the asylum decision would not be reversed and that the representations made
on her behalf did not amount to a fresh claim.

Decision: 15 January 2019

30. The Claimant's solicitors wrote to the Defendant on 9 January 2019 and 12 January 2019. The letter,
dated 9 January 2019, requested time to provide evidence from a trafficking expert. The solicitors stated
that, in the absence of any assurances, a letter before action would be sent. The letter, dated 12 January
2019, is the letter before action.

31. The Defendant's response, dated 15 January 2019, expanded on the reasoning provided in the letter
dated 8 January 2019. The Defendant stated that the Claimants behaviour had improved, and the risk of
suicide had reduced. It was not accepted that the Claimant had a well-founded fear of return to her country
of origin. Her claim to be a victim of modern slavery was also not accepted '…due to the credibility issues
_within her account and…because she did not meet the definition.' The Defendant stated that the Claimant_
is fit to fly with a medical escort. The Defendant reiterated that the asylum claim would not be reversed and
that the representations did not amount to a fresh claim.

Decision:17 January 2019

32. The Claimant's solicitors sent an email to the Defendant's on 16 January 2019 to advise that judicial
review proceedings would be issued. The solicitors requested a deferral of the Claimant's removal. An
interim report from Dr Chisolm, dated 16 January 2019, a preliminary trafficking report from Ms Elisabeth
Flint, also dated 16 January 2019 and a letter, dated 15 January 2019, from the counselling team at
LAWRS were enclosed.

33. The Defendant's letter in response, dated 17 January 2019, contrasted the preliminary telephone
assessment conducted by Dr Chisolm with the assessment conducted by a doctor and Nurse Gbeki within
the detention centre. The Defendant's noted that Ms Flint's report was also a preliminary assessment and
concluded that it '…simply disagrees with the Secretary of State's decision dated 11 December 2018 in
_which it was explained that there were no reasonable grounds for believing that [the Claimant] is a victim of_
**_modern slavery…'. The Defendant's letter reiterated that the asylum claim would not be reversed and that_**
the representations did not amount to a fresh claim.

**The Legal and Policy Framework**

The Anti-Trafficking Convention

34. The Council of Europe Convention on Action Against Trafficking (ECAT) came into force in the UK on
1 April 2009. The ECAT required Competent Authorities to determine whether an individual had in fact
been the victim of trafficking.

35 Article 10 of ECAT provides that:


-----

(1) _Each party shall provide its competent authorities with persons who are trained and qualified in_
_preventing and combating trafficking in human beings, in identifying and helping victims, including children,_
_and shall ensure that the different authorities collaborate with each other as well as with relevant support_
_organisations, so that victims can be identified in a procedure duly taking into account the special situation_
_of women and child victims and, in appropriate cases, issued with residence permits under the conditions_
_provided for in Article 14 of the present Convention._

(2) Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
_appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure_
_that, if the competent authorities have reasonable grounds to believe that a person has been victim of_
_trafficking in human beings, that person shall not be removed from its territory until the identification_
_process as victim of an offence provided for in Article 18 of this Convention has been completed by the_
_competent authorities and shall likewise ensure that that person receives the assistance provided for in_
_Article 12, paragraphs 1 and 2._

The Anti-Trafficking Directive

36. The EU Directive 2011/36/EU on preventing and combating trafficking in human beings and protecting
its victims [the Anti-Trafficking Directive] came into force in the UK on 14 October 2011 and has had direct
effect from 6 April 2013.

37. Article 2 of the Anti-Trafficking Directive provides that:

(1) _Member States shall take the necessary measures to ensure that the following intentional acts are_
_punishable:_

_The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or_
_transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of_
_abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or_
_receiving of payments or benefits to achieve the consent of a person having control over another person,_
_for the purpose of exploitation._

(2) A position of vulnerability means a situation in which the person concerned has no real or acceptable
_alternative but to submit to the abuse involved._

(3) Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of
sexual exploitation, forced labour or services, including begging, slavery or practices similar to slavery,
servitude, or the exploitation of criminal activities, or the removal of organs.

(4) The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual,
shall be irrelevant where any of the means set forth in paragraph 1 has been used.

38. Article 11(2) of the Anti-Trafficking Directive provides that:

_Member States shall take the necessary measures to ensure that a person is provided with assistance and_
_support as soon as the competent authorities have a reasonable-grounds indication for believing that the_
_person might have been subjected to any of the offences referred to in Articles 2 and 3._

European Convention on Human Rights

39. Article 4 of the ECHR provides that:

(1) No one shall be held in slavery or servitude.

_(2) No one shall be required to perform forced or compulsory labour._

40. The ECHR has held that Article 4 imposes a duty to provide practical and effective protection of the
rights of victims of trafficking [see the leading case of Rantsev v. Cyprus and Russia [2010] 51 EHRR 1 at
§284]. It includes the connected and prior duty to investigate and identify victims of trafficking. The duty to
identify victims of trafficking was considered by the Court of Appeal in _TDT v. Secretary of State for the_
_Home Department_ _[2018] EWCA Civ 1395 [§18], where it was stated that,_


-----

'…the duty is triggered, as we have seen from para 286 of Rantsev, where it is “demonstrated that the
_State authorities were aware, or ought to have been aware, of circumstances giving rise to a credible_
_suspicion that an identified individual had been, or was at real and immediate risk of being trafficked”._

Domestic Policy

41. The UK did not implement ECAT or the Trafficking Directive via legislation. For the purposes of
identifying victims of trafficking it sought to satisfy the obligations by establishing the NRM and issued
policy guidance for decision makers within the Competent Authorities. There are two competent authorities,
the UK Human Trafficking Centre, operated by the National Crime Agency, and units or hubs within the
Home Office. This claim relates only to the systems operated by the Home Office.

42. The NRM is a three-stage process:

     - Stage One – Referral of potential victims by a 'First Responder' to a Competent Authority.

    - Stage Two – The Competent Authority will determine whether there are 'reasonable grounds' to believe a
person is a victim of trafficking – 'the reasonable grounds decision'. If a positive reasonable grounds
decision is made then the person will be given 45 days of recovery, reflection and associated support.

    - Stage Three – The Competent Authority will determine conclusively whether the person is a victim of
trafficking – the conclusive grounds decision'. If a positive conclusive grounds decision is issued, then the
Competent Authority will consider whether to grant a period of leave to remain.

43. The Home Office has published guidance on the operation of the NRM, entitled 'Victims of **_modern_**
**_slavery – Competent Authority Guidance' [the Guidance]. The Guidance in force at the time of the_**
reasonable grounds decision in this case was updated on 27 September 2018. The Guidance sets out
three criteria which must be satisfied for an adult to qualify as a victim of trafficking:

_Action_

_To be a victim of human trafficking, the person needs to be subjected to the act_

_of either: -_

     - recruitment

     - transportation

     - transfer

     - harbouring

     - receipt

… …

_Means_

_An adult victim of human trafficking must have been subject to a 'means' – the threat or use of force or_
_other form of coercion to achieve the consent of a person having control over another person._

_The apparent consent of a victim to be controlled and exploited is irrelevant when one or more of the_
_following has been used to get that consent:_

     - the threat or use of force

     - abduction

     - fraud

     - deception

     - the abuse of power or of a position of vulnerability

     - the giving or receiving of payments or benefits


-----

_Exploitation_

_To be a victim, someone must have been trafficked for the purpose of 'exploitation' which may take the_
_form of either:_

- sexual exploitation

- forced labour or services

- slavery or practices similar to slavery

- servitude

- forced criminality

- removal of organs (also known as organ harvesting)

… …

44. In relation to sexual exploitation and forced labour the Guidance states:

**_Female victims of sexual exploitation_**

_There is no typical experience of people who have been trafficked for sexual exploitation. some are held_
_captive, assaulted and violated. others are less abused physically, but are psychologically tormented, and_
_live in fear of harm to themselves and their family members. the way in which people describe their_
_experiences means you must not rely on victims to self-identify in explicit or obvious ways._

**_Trafficking: exploitation – forced labour_**

_Forced labour is not restricted to a particular sector of the labour market but cases have been identified in_
_these sectors:_

- manufacturing

- food processing

- agriculture

- hospitality

_As with other forms of trafficking related exploitation, a high level of harm and control or coercion is needed_
_to trigger the UK's obligation under the Council of Europe Convention on Action against Trafficking in_
_Human Beings._

_Forced labour represents a severe violation of human rights and is a restriction of human freedom._

_The International Labour Organisation (ILO) defines forced work as:_

_'All work or service which is exacted from any person under the menace of any penalty and for which the_
_person has not offered himself voluntarily'._

_This definition is a useful indication of the scope of forced labour for the purposes of human trafficking._
_Siliadan v France 2005 (Application no. 73316/01) European Court of Human Rights took this as the_
_starting point for considering forced labour threshold and held that for forced labour, there must be work:_

- exacted under the menace of any penalty which is performed against the will of the person concerned,
_that is, for which the person has not offered themselves voluntarily_

_Forced labour cannot be equated (considered) simply with either:_

- working for low wages and/or in poor working conditions

- situations of pure economic necessity, as when a worker feels unable to leave a job because of the real
_or perceived absence of employment alternatives_

… …


-----

45. The Guidance goes on to provide instructions in relation to the assessment of the credibility of a
claimant. For the purposes of the present case the important elements of the Guidance are firstly under the
heading 'Assessing credibility –detail and consistency”. The Guidance provides as follows:

_Consistency_

_It is…reasonable to assume that a potential victim who has experienced an event will be able to recount_
_the central elements in a broadly consistent manner. A potential victim's inability to remain consistent_
_throughout their written and oral accounts of past and current events may lead you to disbelieve their_
_claim. However, before you come to a negative conclusion, you must first refer back to the first responder_
_or other expert witnesses to clarify any inconsistencies in the claim._

_Due to the trauma of human trafficking there may be valid reasons why a potential victim's account is_
_inconsistent or lacks sufficient detail._

46. The Guidance in relation to credibility goes on to consider gender and culture and notes that 'women
_may be unable to disclose relevant details due to cultural and social norms.' The Guidance also provides_
particular guidance in relation to mitigating circumstances which are pertinent to trafficking claims and
pertinent to the consideration of credibility in trafficking claims. The Guidance provides as follows:

**_Assessing Credibility - mitigating circumstances_**

_Competent Authority staff need to know about the mitigating circumstances which can affect a potential_
_victim's account of human trafficking or modern slavery is credible._

_When the Competent Authority assesses the credibility of a claim, there may be mitigating reasons why a_
_potential victim of trafficking or_ **_modern slavery is incoherent, inconsistent or delays giving details of_**
_material facts. The Competent Authority must take these reasons into account when considering the_
_credibility of a claim. Such factors may include, but are not limited to, the following:_

- trauma (mental, psychological, or emotional)

- inability to express themselves clearly

- mistrust of authorities

- feelings of shame

- painful memories (particularly those of a sexual nature…

**_Delayed disclosure_**

_A key symptom of post-traumatic stress is avoidance of trauma triggers, or of those things that cause_
_frightening memories, flashbacks or other unpleasant physical and psychological experiences. Because of_
_these symptoms a person may be unable to fully explain their experience until they have achieved a_
_minimum level of psychological stability. The Competent Authority must not view a delay in disclosing of_
_facts as necessarily manipulative or untrue. It may be the result of an effective recovery period and the_
_establishment of trust with the person to whom they disclose the information._

Domestic Law

47. The key legal principles are as follows:

i) As the UK has adopted a policy, in relation to the treatment of claims by persons who have potentially
been trafficked, it is an error of law to depart from the guidance unless a reasonable explanation is
provided - Lumba v SSHD _[2011] UKSC 12; [2012] 1 AC 245._

ii) The Guidance includes specific warning provisions in relation to the approach and assessment of
trafficking claims, particularly in relation to inconsistent account and delayed disclosure. The features of
credibility which are addressed in the Guidance must be considered and examined before reaching an
adverse credibility finding - R (SF) v SSHD _[2015] EWHC 2705 (Admin)._


-----

iii) A high standard of reasoning is required from the Competent Authority given the nature and extent of
the guidance. Furthermore, if an adverse decision is based on an assessment of credibility the Competent
Authority must demonstrate that a careful and conscientious analysis of the relevant factors has been
undertaken - R (M) v SSHD [2015] EWHC 2467.

**Grounds and Submissions**

48. Ms Capel advanced the Claimant's case on the basis of four grounds:

Ground 1 – The fitness to fly decisions were insufficiently reasoned and irrational

49. Ms Capel submitted that there was no rational reason for the Defendant to prefer the assessment of
fitness to fly by Nurse Gbeki on 4 January 2019 to the psychiatric report of Professor Katona, dated 23
December 2018, and the psychological report of Dr Chisholm, dated 15 January 2019. Professor Katona
and Dr Chisholm both concluded that: (i) the Claimant was exhibiting symptoms of serious mental illness;
(ii) there was a significant risk of self-harm or suicide on removal and/or on arrival in Brazil; (iii) she
exhibited high levels of agitation and disruptive behaviour when distressed; (iv) she was not likely to be fit
to fly (applying Civil Aviation Authority/IATA Guidelines) and (v) further assessment by a psychiatrist was
required. Ms Capel submitted that the Defendant could not rationally reject their reports in favour of Nurse
Gbeki on the sole basis that they assessed the Claimant by telephone rather than in person. Ms Capel
further submitted that although the medical records contain a short entry made by Nurse Gbeki, dated 4
January 2019, the full assessment has not been disclosed and neither has the doctor's review of that
assessment. She contended that there was no indication that Nurse Gbeki had reviewed the available
records when he conducted his assessment and his short entry makes no reference to the criteria that he
applied.

50. Mr Metcalfe's primary submission was that Ground 1 is academic and of historical interest only as the
Claimant's removal window has been deferred. He stated that the Claimant's fitness to fly, at some date in
the future, will be assessed by reference to her circumstances and the evidence available at that time. As
to the reasonableness of the conclusion that the Claimant was fit to fly with a medical escort in January
2019, Mr Metcalfe submitted that the Defendant was entitled to prefer the conclusions of Nurse Gbeki, as
he is a medical professional who had seen the Claimant face to face on several occasions. He contended
that neither Professor Katona nor Dr Chisolm stated in terms that the Claimant was fit to fly; only that she
'may' be unfit to fly or was 'unlikely' to be fit to fly. He submitted that both Professor Katona and Dr Chisolm
acknowledged that conducting the assessment by telephone was a limiting factor which precluded them
from providing a definitive opinion.

Ground 2 – The negative reasonable grounds decision was reached by an unfair process

51. Ms Capel submitted that the Guidance cautions against interviewing at the reasonable grounds stage,
as this stage is: (i) meant to act as an 'initial filter' where prime facie indicators of trafficking are sufficient
and (ii) undertaken before the 45-day reflection and recovery period which creates conditions conducive to
full disclosure of the claim. She contended that there was no evidence that the Defendant had regard to the
Guidance and the relevant factors that ought to be taken into account. Ms Capel submitted that the
Defendant had sufficient information both to make a referral to the NRM and to make a positive reasonable
grounds decision. She stated that the information was contained within the MSHRC referral dated 24
November 2018, the substantive asylum interview, an entry in the case records made by an immigration
officer dated 2 October 2018, and in the individual needs meeting on 12 October 2018. In addition, Ms
Capel was critical of the Defendants delay in referring the matter to the police and the failure to informing
the Claimant during the NRM interview that she could request a female interviewer.

52. Mr Metcalfe submitted that the Guidance does not 'caution against' interviewing at the reasonable
grounds stage other than to note that an interview might not be possible in light of the 'limited 5 working
_days timescale'. He further submitted that the Defendant was not required to record relevant factors_
governing his decision to interview the Claimant. In addition, he suggested that the Defendant was entitled
to rely on the Claimant's asylum screening interview in which she stated that she had 'no preference' when
asked 'Do you have a preference whether you are interviewed by a man or an woman at your asylum


-----

_interview?' He stated that the Claimant was informed that she could change her mind later and that in any_
event it did not prevent her from providing non-sensitive details such as the fact that she was free to move
from the accommodation provided by Mr LU.

Ground 3 – The negative reasonable grounds decision is in error of law, fails to apply policy guidance,
fails to have regard to relevant considerations and is irrational

53. Ms Capel was critical of various aspects of the reasonable grounds decision letter dated 11 December
2018. She submitted that the trafficking definition in ECAT and the Guidance makes clear that the
Claimant's apparent consent is irrelevant where any of the means of threat or use of force, coercion,
abduction, fraud, deception or abuse of power or vulnerability are present. She submitted that it was a
clear misdirection for the Defendant to conclude that the Claimant was not subject to an 'act' of
transportation, recruitment, harbouring or receipt because she 'travelled to the UK willingly' and had
'freedom of movement' in the UK. She contended that the Claimant gave an account of (i) the 'means' of
'deception' which was the 'boyfriend method' of grooming; (ii) 'coercion' by exerting psychological control;
and (iii) 'abuse of a position of vulnerability' as she had 'no real or acceptable alternative' than to comply
with her trafficker. She further submitted that the there is no requirement in law or policy that the Claimant
be under the physical control of her trafficker. Ms Capel contended that there were clear indicators of
sexual exploitation which the Defendant failed to identify and that he also failed to identify and consider the
mitigating circumstances which might explain (i) the timing of the Claimant's disclosure, and/or (ii) the
inconsistencies in her claim. She submitted that the Defendant's overall approach to the question of
whether the reasonable grounds threshold was met was flawed in the manner identified in _HAM v_
_Secretary of State for the Home Department [2015] EWHC 1725. In addition, Ms Capel invited the court to_
conclude that the Defendant failed to apply the definition of forced labour as set out in _Siliadin v France_

[2005] EHRR 545 and adopted in the Guidance.

54. Mr Metcalf submitted that the decision letter, dated 11 December 2018, clearly set out the basis upon
which the Defendant concluded that the Claimant's account did not meet any of the criteria for human
trafficking or **_modern slavery. He conceded, during his oral submissions, that the Claimant had been_**
transported. This concession had not been made in his written submissions. However, he submitted that
the Claimant otherwise travelled freely. He stated that the Defendant was not satisfied that the Claimant
had been subject to any threat, coercion or exploitation. He contended that it was unclear what deception
was involved or the extent to which Mr LU was able to exert control and, in any event, 'deception', in and of
itself, is not sufficient for a finding of human trafficking. Mr Metcalfe submitted that the fact that the
Defendant did not refer to specific mitigating factors did not explain the admissions which undermined the
Claimant's account. He further submitted that the Claimant's asylum claim (based on her fear of domestic
violence) was refused inter alia because the Brazilian authorities could provide sufficient protection against
such threats and to the extent that she feared her ex-partner, it was reasonably open to her to relocate to
another part of Brazil. He invited the court to conclude that the domestic abuse in Brazil did not amount to
a position of vulnerability such that she had no 'real or acceptable alternative' but to accept Mr LU's offer.
He stated that the Claimant's ability to leave the accommodation, find work of her own accord and retain
the majority of her wages was a sufficient basis upon which the Defendant could reasonably conclude that
any attempt to exert psychological control had been unsuccessful. He suggested that Ms Flint's report was
generic in nature and did not provide direct support for the Claimant's claim.

Ground 4 – The decision of 17 January 2019 is in error of law, fails to apply policy guidance and is
irrational

55. Ms Capel contended that in the decision letter, dated 17 January 2019, the Defendant does not
consider whether or not to exercise his discretion to reconsider the reasonable grounds decision. She
submitted that instead the Defendant treated the Claimant's request as further representations on asylum
or human rights grounds to be assessed against Rule 353. Ms Capel further submitted that the criticism
that Ms Flint's report fails to subject the Claimant's account to critical scrutiny and the rejection of the
evidence of Professor Katona and Dr Chisolm is irrational.


-----

56. Mr Metcalfe submitted that (i) the Defendant had already considered and refused the Claimant's
asylum claim and was reasonably entitled to conclude that further material in relation to her fitness to fly
and the NRM decision did not give rise to a realistic prospect of success before an immigration judge; (ii)
the Defendant was entitled to prefer the assessment of the Yarl Wood's staff who had seen and examined
the Claimant over a period of time as against the preliminary conclusions of medical experts who had only
spoken to her on the telephone; (iii) the Defendant was entitled to maintain his reasonable grounds
decision on the basis that the Claimant had failed to meet the necessary threshold and criteria; (iv) the
Defendant's assessment that Ms Flint took the Claimant's account at face value was not unreasonable and
he was entitled to conclude that the tenor of the report proceeds on the basis that the Claimant's account is
true without any discussion or analysis of the 'inconsistencies and discrepancies' to which she refers.

**Discussion**

Overview

57. The court's role is not to determine for itself whether there are reasonable grounds for suspecting that
the Claimant is a victim of trafficking. It is to decide whether the Defendant's reasonable grounds decision
is fair, whether there are any errors of law and whether it is based on a rational application of the
Guidance. The Guidance has to be applied within the context of its protective purpose, its status as an
initial filter to identify potential victims and the gateway it provides to a 'recovery and reflection' period. The
decision maker must not lose sight of the low threshold for the reasonable grounds test – 'I suspect but I
_cannot prove' and the traumatic effects of trafficking when assessing the timing of disclosures and previous_
inconsistent accounts.

58. Ms Capel commenced her oral submissions with a detailed critique of the reasonable ground's
decision made on 11 December 2018 – Ground 3. The force of her submissions on Ground 3 were
primarily based on the observations made by Helen Mountfield QC (sitting as a Deputy High Court Judge)
in the case of _HAM v Secretary of State for the Home Department._ In _HAM the Judge stated that the_
question for the Competent Authority at the reasonable grounds stage is:

'…an objective question: the question is whether the evidence provides grounds upon which a reasonable
_observer could believe that this person is a trafficking victim, applying the low threshold of suspicion but not_
_proof, and bearing in mind the non-exhaustive list in the Guidance of possible reasons for absence of detail_
_or inconsistency._

59. The Judge emphasised that:

'…at this preliminary stage of enquiry, there could be both reasonable grounds upon which a reasonable
_person could believe that a person could be a victim of trafficking and reasonable grounds for believe that_
_they might not be. (That may particularly be so in circumstances where there are inconsistencies or gaps in_
_the evidence, but also features of the account which suggest possibly plausible psychological or other_
_reasons to explain those lacunae.) In such circumstances, the question of whether there are "reasonable_
_grounds" for suspecting that a person is a victim of trafficking must be answered in the affirmative._
_Provided there are reasonable grounds for belief, then the question of whether there are also reasonable_
_grounds for disbelief is irrelevant. The further question of whether the grounds for disbelief outweigh the_
_grounds for belief is not one for determination at that stage: it is a matter which will fall for determination by_
_a decision-maker making a Conclusive Grounds decision at a later date (after the reflection/recovery period_
_and if necessary after extra enquiries).'_

60. Ms Capel went on to make submissions in relation to Ground 2 followed by Grounds 4 and Ground 1.
Ms Capel was right to start with Ground 3 and I have followed the same order. I have not addressed every
point that was made by Ms Capel or by Mr Metcalfe in response; only such matters which have enabled
me to conclude whether the decisions are lawful.

**Ground 3 – 11 December 2018 Decision: error of law; procedural impropriety and irrationality**

61. The Defendant concluded that the Claimant's account was not credible based on inconsistencies in
her account and her delayed disclosure. The Defendant was entitled to form that view and to conclude that,


-----

as consequence, there are no reasonable grounds to suspect that the Claimant is a victim of trafficking.
However, the Defendant is required to set out in detail and with a high standard of reasoning how and why
he arrived at his decision.

62. In my judgment, the decision letter betrays an erroneous approach for the following interrelated
reasons:

i) Inconsistencies on their own are not enough to justify a negative reasonable grounds decision. The
Guidance requires the Defendant to assess all information critically and objectively whilst recognising that
there may be valid reasons why a putative trafficking victim's initial account may appear to contradict a
subsequent account. In addition, the Defendant is required to recognise potential reasons for delayed
disclosure. Potential barriers to disclosure at the time of the Claimant's arrest and at her screening
interview were clearly evident. She had a history of serious and sustained domestic violence by an expartner in Brazil, in respect of which there was independent supporting evidence. She expressed fear of
the immigration authorities and the police based on the threats that had been made against her and her
family by Mr LU. However, there is no reference to the possible traumatic effects of the experiences the
Claimant described or the potential impact on her recollection of the events. The reference to 'mitigating
circumstances' is limited to whether the Claimant was suffering from '…any mental health conditions which
_would preclude her from recalling the details of her claim.' There is no meaningful attempt to evaluate the_
identifiable mitigating factors, as required by the Guidance, and no assessment of the Claimant's diagnosis
of depression, nor the risk of self-harm or suicide.

ii) The decision states that the Claimant has not been subject to an 'act' of transportation, recruitment,
harbouring or receipt. It would appear that this conclusion was reached primarily on the basis that the
Claimant had travelled to the UK 'willingly' and had '…freedom of movement in Brazil and the UK'. During
his oral submissions, Mr Metcalfe conceded that the fact that Mr LU paid for the Claimant's travel
arrangements to the UK was sufficient to amount to 'transportation'. He was right to make this concession,
and in so doing, implicitly acknowledged that the failure to identify a key component of the definition of
trafficking, in the decision letter, is an error.

iii) The Defendant, in concluding that the Claimant came to the UK 'willingly' and '…enjoyed freedom of
_movement', does not appear to have considered the Guidance which clearly states that apparent consent_
of a victim is irrelevant when one or more of the 'means' has been used to obtain that consent. I accept Ms
Capel's submission that based on the information that was available to the Defendant deception, coercion
and abuse of a position of vulnerability ought to have been considered. Although Mr Metcalfe correctly
stated that the Defendant is entitled to conclude that any attempt to exert psychological control was
unsuccessful, there is no indication that at the time the decision letter was drafted any consideration was
given to the Claimant's account that Mr LU's control over her was psychological.

iv) In the case summary the Defendant, refers to the Claimant's account of the telephone calls she
received from Mr LU in the early hours of the morning. The Claimant stated in the asylum interview on 26
October 2018, that Mr LU would call her and make her take her clothes off and in the NRM interview on 26
November 2018 she stated that he would call her and ask her to confirm that she had not had sex with
another man. However, there is no evidence that the Defendant identified these calls as a possible sign of
sexual exploitation. There is also no mention of the individual needs meeting which took place on 12
October 2018. During that meeting the Claimant stated that a person had photos of her on his phone which
he was threatening to disclose. These are indicators of sexual exploitation and ought to have been
considered by the Defendant.

v) It is apparent from decision letter that the Defendant considered the issue of exploitation primarily in
relation to the definition of forced labour and concluded that the Claimant's account was not internally
consistent. Although the Defendant refers to the fact that the Claimant obtained her job independently, was
able to travel to and from work unaccompanied and paid Mr LU only part of her salary there is no explicit
consideration as to whether the work was carried out _'under menace of penalty' such that it cannot be_
considered 'voluntary'. As stated above inconsistencies are not enough. The Claimant in seeking to
establish that she has been the victim of trafficking is entitled to know that a full and proper analysis of her


-----

claim has been undertaken and that can only be achieved if the decision demonstrates how general
principles have been specifically applied to her claim.

vi) In essence, the decision of 11 December 2018, is a list of the factors which undermine the Claimant's
account rather than an assessment of the indicators which might constitute reasonable grounds for
suspecting that the Claimant was a victim of trafficking. It would appear that on the basis of the
discrepancies, gaps and the adverse inferences that could be drawn from the Claimant's account, the
Defendant simply rejected her account and concluded that her credibility was sufficiently limited to justify
finding no reasonable grounds to suspect that the Claimant could be a victim of trafficking.

63. Although the correct test, the relevant definitions of human trafficking and the three components
necessary for it to be established are cited in the decision letter, the material omissions and the limited
consideration of the 'mitigating circumstances' constitutes a failure to follow the Guidance and is an error of
law. It may be that a full and detailed analysis of the evidence and the Claimant's credibility may lead to a
conclusion that she was not trafficked, but in my judgment, it is irrational in the _Wednesbury sense, to_
contend that her evidence cannot lead to that conclusion.

**Ground 2 – 11 December 2018 Decision: unfair process**

64. Ms Capel primarily based her submission in relation to Ground 2 on the Guidance relating to
interviews. Under the heading 'The 2 Stage National referral Mechanism consideration process' the
Guidance states:

'At the Reasonable Grounds stage, the decision may be more likely to be based on evidence gathered
_from the first responder rather than through an interview process given the limited 5 working days_
_timescale in which the Competent Authority is expected to make a decision where possible which might not_
_allow time for interviews. in some cases that might also be an appropriate time to carry out a formal_
_interview.'_

65. The suggestion by Ms Capel that the Guidance 'cautions against' interviewing at the reasonable
grounds stage is overstated. I accept the submission made by Mr Metcalfe that the Guidance simply notes
that it may not be possible to conduct an interview within the expected timescale. The additional guidance
Ms Capel referred to, during her written and oral submissions, is under the heading 'Making a Conclusive
_Grounds decision'. She submitted that the Defendant had failed to direct himself to the relevant factors in_
the Guidance in deciding whether to interview. This submission was misplaced. The guidance in relation to
a conclusive grounds decision cannot be migrated across to become equally applicable to the reasonable
grounds decision. Therefore, this ground fails, to the extent that Ms Capel submitted that the Defendant
had not followed his own policy in relation to the decision to interview the Claimant.

66. Although there is no specific guidance on interviews at the reasonable grounds stage, the
considerations under the heading 'Making a Conclusive Grounds decision' such as, delaying the interview,
permitting a support provider to be present and/or enquiring whether the victim would prefer a male or
female interviewer, are all matters that a reasonable decision maker is likely to take into account. I do not
accept the submission made by Mr Metcalfe that the Defendant was entitled to rely on the fact that the
Claimant expressed no preference when she was asked, during her asylum interview, if she would prefer a
male or female interviewer. As Mr Metcalfe acknowledged the asylum and trafficking processes are
entirely separate. In my view, the Defendant ought to have enquired whether the Claimant would prefer a
male or female interviewer. However, this omission on its own would not have been enough to quash the
decision. Therefore, this aspect of Ground 2 also fails.

67. Ms Capel further submitted that there was sufficient information to make a referral to the NRM and to
justify a positive reasonable grounds decision prior to the Claimant's interview. It was not suggested on the
Claimant's behalf that she was unfit to be interviewed. However, Ms Capel submitted that it is no answer to
the Claimants' criticisms that she stated she felt fit and well enough to be interviewed. As stated above, a
full and detailed analysis of the evidence and the Claimant's credibility may lead the Defendant to the
conclusion that she was not trafficked. It is a decision which the Defendant was entitled to reach either
before or after conducting an interview provided that the Guidance was applied, and an assessment of the


-----

Claimant's credibility took place with careful consideration of the evidence and factors supporting her
account balanced against the evidence and factors contradicting or undermining her account. Therefore,
this aspect of Ground 2 also fails. The failure to undertake a detailed analysis of the relevant evidence and
factors has already been considered under Ground 3.

**Ground 4 - 17 January 2019 Decision: error of law, fails to apply policy guidance and is**
irrational

68. The Defendant's decision letter, dated 17 January 2019, was in response to the Claimant's letter,
dated 16 January 2019 and has to be seen within that context. The second paragraph of the Claimant's
letter stated:

_'As the SSHD has repeatedly refused our requests to cancel her removal window it is necessary for us to_
_issue judicial review proceedings. We have made repeated attempts to request for the deferral of her_
_removal arrangements as we intended to get significant further evidence to support her claim. These_
_requests have been refused.'_

69. Although previous letters indicated that the reasonable grounds decision would be challenged, the
letter dated 16 January 2019, was very urgent as it requested a response by 9.30 the following day and did
not expressly state that the Claimant was seeking a re-consideration of the trafficking claim. If that was
what the Claimant was seeking that should have been made clear. In the absence of a clear declaration of
the type of review that was being sought and given the Claimant's liability to be removed as a failed asylum
seeker, it was not unreasonable to consider the further representations under Rule 353.

70. Nonetheless, the Defendant did go on to address the additional information that was provided by Dr
Chisolm, Ms Flint and LAWRS. The Claimant takes issue with the Defendant's assessment of the reports
of Ms Flint report and Dr Chisolm. The Defendant accepts Ms Flint's expertise, but her report cannot be a
trump card. The Defendant is the primary decision-maker whose function is to determine whether a
claimant is a victim of trafficking under ECAT. Identifying victims of trafficking is an executive task and is
not a matter of expert opinion. The Defendant's consideration of Ms Flint's report was not erroneous. Nor
is there any error of law in the Defendant's treatment of Dr Chisolm's report. The failure to undertake a
detailed analysis of the relevant evidence and factors has already been considered under Ground 3.
However, the Defendant was entitled to prefer the assessment of the medical staff at Yarl's Wood who
have seen and examined the Claimant, as against the preliminary conclusions of a medical expert that had
only spoken to the Claimant over the telephone. Therefore, this aspect of Ground 4 also fails.

Ground 1 - Fitness to fly Decisions: insufficiently reasoned and irrational.

71. On 22 February 2019, Karen Steyn QC (sitting as a Deputy High Court Judge) observed that the
Claimant's removal window had lapsed following the Claimant's release from detention on 23 January
2019, and on that basis, refused the Claimant permission to proceed with her second ground of challenge
(as originally drafted) on the basis that, '…that aspect of the Claimant's challenge is academic.'

72. I accept the submission made by Mr Metcalfe that Ground 1 is also academic. Any future removal
window will have to be based on the Claimant's circumstances at that time and the available up to date
evidence. However, for completeness I did go on to consider the merits of Ground 1. In my judgment the
Defendant was entitled to rely on the conclusions of Nurse Gbeki who had seen the Claimant on three
occasions. The Defendant was also entitled to prefer Nurse Gbeki's assessment to the 'preliminary'
conclusions of Professor Katona and Dr Chisolm.

Conclusion

73. The claim succeeds on the basis of Ground 3 only. The relief sought is that the reasonable grounds
decision be quashed and remitted for reconsideration.

74. In my judgment, the decision should be reconsidered. The Defendant's decision should set out all
relevant factors which have been taken into account including how they impact upon the claim that the
exploitation took the form of forced labour and sexual exploitation. Whether the trafficking claim succeeds


-----

or fails the Claimant is entitled to know that her specific circumstance has been critically and properly
analysed.

75. No submissions have been made regarding costs. Any consequential applications are to be dealt with
in writing.

Addendum

76. Following circulation of my draft judgment I received a written application from the Claimant's
representatives requesting anonymisation. The application was based on the nature of the claim and the
risk that the Claimant could be traced by her alleged trafficker.

77. The request for anonymisation is granted. Additional anonymisation was made to protect the
Claimant's identity.

**End of Document**


-----

