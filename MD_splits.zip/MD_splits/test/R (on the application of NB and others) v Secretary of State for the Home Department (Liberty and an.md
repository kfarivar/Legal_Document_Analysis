intervening) [2021] EWHC 1489 (Admin)

# R (on the application of NB and others) v Secretary of State for the Home Department (Liberty and another intervening) [2021] EWHC 1489 (Admin)

Queen's Bench Division, Administrative Court (London)

Linden J

3 June 2021Judgment

**Mr Tom Hickman QC and Ms Leonie Hirst (instructed by Deighton Pierce Glynn) for the First to Fourth**
Claimants

**Ms Shu Shin Luh and Ms Antonia Benfield (instructed by Matthew Gold & Co) for the Fifth and Sixth**
Claimants

**Ms Lisa Giovannetti QC and Mr David Manknell (instructed by the Government Legal Department) for**
the Defendant

**Ms Zoe Leventhal, Mr Ben Amunwa and Mr Admas Habteslasie (instructed by Liberty) for the First**
Intervener

**Ms Sonali Naik QC and Mr Ali Bandegani (instructed by the Joint Council for the Welfare of Immigrants)**
for the Second Intervener

Hearing dates: 14 and 15 April 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

_Covid-19 Protocol: This judgment was handed down remotely by circulation to the parties' representatives_
_by email, release to BAILII and publication on the Courts and Tribunals Judiciary website. The date and time for_
_hand-down is deemed to be 10.30am_

**MR JUSTICE LINDEN:**

**INTRODUCTION**

[1. Section 95 of the Immigration and Asylum Act 1999 (“IAA 1999”) requires the Defendant to provide](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
_“support” to asylum seekers who appear to be destitute or to be likely to become destitute. In appropriate_
cases, that support must include accommodation which, subject to certain minimum requirements, she
judges to be adequate for the needs of the supported person.

2. In September 2020 the Defendant decided, in the context of an increase in demand for accommodation
for asylum seekers, that they could and should be accommodated in Penally and Napier military barracks.
These Claims are solely concerned with the latter, which are on a site on the outskirts of Folkestone in
Kent (“the Barracks”). The management of the Barracks for this purpose was placed in the hands of
Clearsprings Ready Homes Limited (“Clearsprings”), although they, in turn, subcontracted out aspects of
its operation.


-----

intervening) [2021] EWHC 1489 (Admin)

3. The Barracks were known to be _“basic and slightly run down” and they are surrounded by an 8-foot_
fence which is topped by barbed wire. Residents would be required to sleep in dormitories with shared
bathroom and toilet facilities. The advice of Public Health England (“PHE”) was therefore that the Barracks
were not suitable to be used to accommodate asylum seekers given the coronavirus pandemic but that, if
they were, steps should be taken to reduce the risk of Covid-19 infection. The extent to which those steps
were taken, and the effectiveness of the steps which were in fact taken is in issue in these proceedings.
The Defendant recognised, however, that conditions at the Barracks were such that they would only be
suitable for healthy adult males, and she introduced suitability assessment criteria which were intended to
be used to identify asylum seekers who should not be accommodated there because of their particular
circumstances, including their mental or physical health and other vulnerabilities arising from experiences
before coming to the United Kingdom.

4. From 22 September 2020, the number of asylum seekers living in the Barracks grew rapidly. By 1
October 2020 there were 155 residents, and the numbers rose to a peak of 414 in mid-November 2020.
The residents were generally sleeping 12-14 to a dormitory. Plywood partitioning divided the sleeping
spaces, albeit this did not reach from floor to ceiling, and sheets and/or curtains were used to cover the
entrance to each space so as to achieve a degree of privacy. For this and other reasons, according to a
report of the Crown Premises Fire Safety Inspectorate (“CPFSI”), dated 30 November 2020, the
arrangements at the Barracks failed to protect the occupants from serious or significant risk of harm and
action was required to ensure their safety.

5. On the evidence, it was inevitable that there would be a major outbreak of Covid-19 infections at the
Barracks. This happened in mid-January 2021. At this stage there were around 380 residents on site. In
response to the outbreak, approximately 100 residents were moved out of the Barracks during the fourth
week of January 2021 and the population continued to reduce thereafter.

6. On 15 January 2021, the residents were told that they were not to leave the site _“under any_
_circumstance”. That instruction was reiterated on 28 January 2021 and it remained in place for more than a_
month. Tensions rose within the Barracks and, on 29 January 2021, there was a major disturbance and a
fire was started in one of the accommodation blocks.

7. The six Claimants are all asylum seekers who were transferred to the Barracks from accommodation in
hotels. In the case of five of them, they were transferred there in September 2020. The sixth, OMA, was
transferred in November/December 2020, although the precise date is unclear. M was moved out on 29
January 2021 and the other Claimants were moved out on 3 or 4 February 2021. OMA therefore lived at
the Barracks for 2-3 months and the other Claimants lived there for nearly 4.5 months.

8. The evidence in relation to all of the Claimants is that they experienced people trafficking and/or torture
prior to their arrival in the United Kingdom and there is evidence in a number of their cases that they had
pre-existing mental health issues as a result of their experiences. Under the Defendant's suitability
assessment criteria, these factors ought to have disqualified them from transfer to the Barracks. All of them
say that they experienced a deterioration in their mental health as a result of their stays at the Barracks
and all of them have been formally diagnosed as suffering from recognised mental health conditions
including Post Traumatic Stress Disorder and depression. All were transferred out of the Barracks, but only
after legal proceedings were threatened or initiated, based on the contention that the Barracks were
unsuitable accommodation for them. In the cases of NB, XD and OMA they were transferred by order of
the court made on an interim basis. Further details of the circumstances of each Claimant are set out in the
Annex at the end of this judgment.

9. On 17 and 18 February 2021 an inspection of the Barracks was carried out by a team comprising
inspectors from the Independent Chief Inspector of Borders and Immigration (“the ICIBI”) and Her
Majesty's Chief Inspector of Prisons (“HMCIP”). ICIBI/HMCIP provided the Defendant with initial findings on
23 February 2021 which made serious criticisms of the arrangements at the Barracks and the Defendant
responded on 2 March 2021. The initial findings were published on 8 March 2021 and the full report was


-----

intervening) [2021] EWHC 1489 (Admin)

submitted to the Defendant on 21 March 2021 (“the HMCIP report”). The full report remained highly critical
of the decision making in relation to the Barracks and the conditions there.

**THE ISSUES IN THE CLAIMS        .**

10. At issue in the present case is the Defendant's decision in each of the Claimants' cases that they
should be accommodated at the Barracks. The Claimants advance four grounds of challenge. They allege
that:

i) The accommodation at the Barracks did not and does not comply with section 96 IAA 1999 read with
Directive 2013/9/EC, which sets out _“minimum standards” for reception of asylum seekers (“the RCD”),_
and/or it breached the Defendant's own representations that the accommodation conformed to her general
standards for such accommodation set out in the Asylum Accommodation and Support Services contract
(“the AASSC”).

ii) The process for applying the Defendant's criteria for selecting people to be accommodated at the
Barracks was and is flawed and unlawful, both in relation to (a) the initial decision to transfer asylum
seekers to the Barracks, and (b) the monitoring or review of suitability post transfer. This ground is based,
in particular, on fulfilment of the **Tameside duty and the Public Sector Equality Duty (“PSED”) under**
[section 149 of the Equality Act 2010 (“EA 2010”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)

iii) Accommodating the Claimants at the Barracks, and the conditions to which they were subject whilst
[there, breached their rights under Articles 2, 3 and/or 8 of Schedule 1 to the Human Rights Act 1998 (“HRA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[1998”), contrary to section 6 and 7 of that Act.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_

iv) There were periods during which the restrictions on the Claimants' movement amounted to false
imprisonment at common law and/or breach of Article 5 of Schedule 1 to the HRA 1998. In particular, they
allege that there was a 10pm to 6am curfew in place at all material times prior to the instruction on 15
January 2021 not to leave the Barracks at all, and they say that that instruction itself amounted to
imprisonment and deprivation of liberty. But they also say that there was a particular instance of detention
of OMA between 18 and 25 January 2021 and they refer to other alleged instances of detention on 26
October, 23-25 November and 28 December 2020.

11. The Claimants' pleaded fifth ground – breach of the PSED - was abandoned as a free-standing
ground.

12. The Claimants seek various forms of declaratory relief, and damages for breach of their human rights
and false imprisonment.

**THE PROCEEDINGS**

13. Proceedings were issued in each of the six cases between 27 January and 4 February 2021 and an
expedited permission hearing was directed by Chamberlain J. That hearing took place on 16 February
2021.

14. The grant of permission was initially resisted by the Defendant and the first witness statement of Mr
Lawrence Williams, dated 11 February 2021, was filed for this purpose. However, I understand that at the
beginning of the permission hearing the court was informed that the Defendant withdrew her objection to
permission and Ms Giovannetti QC very properly indicated that she did not feel able to place reliance on
Mr Williams' statement. He has since filed a second witness statement, dated 18 March 2018, which
corrects certain inaccuracies in his first one, and both are now relied on by the Defendant given that
corrections have been made to the first statement.

15. Having given permission, Chamberlain J directed that there be an expedited hearing of the Claims
given that there are cases which have been stayed behind this one and given that the Defendant continues
to make use of the Barracks to accommodate asylum seekers. He also directed that Clearsprings be
served in case they wished to participate in the proceedings. However, they have apparently elected not to
play any direct part in the proceedings whether by submitting a witness statement or otherwise


-----

intervening) [2021] EWHC 1489 (Admin)

16. With the permission of Lang J, Liberty and The Joint Council for the Welfare of Immigrants (“JCWI”)
intervened by way of written submissions. The JCWI intervention included a witness statement from its
Legal Director, Ms Nicola Burgess.

17. The Defendant's Detailed Grounds of Defence and evidence in support were served on 18 March
2021. Various witness statements in response were then served on behalf of the Claimants on 30 March
2021, and further information was provided by the Defendant on 12 April 2021 pursuant to CPR Part 18,
followed by a second witness statement from Ms Philomena Creffield on 13 April 2021.

18. The hearing of the Claim took place over the course of two days on 14 and 15 April 2021. At 5.04pm
on 13 April 2021, the Defendant disclosed the HMCIP report to the Claimants' solicitors, together with the
Defendant's response to the initial ICIBI/HMCIP findings, dated 2 March 2021, and a covering letter for the
HMCIP report from Mr David Bolt, the outgoing ICIBI, dated 21 March 2021. This letter confirmed Mr Bolt's
view that the HMCIP report was _“both accurate and fair”. Mr Bolt was also highly critical of the decision_
making and the arrangements in relation to the Barracks. The email to the Claimant's solicitors, attaching
the HMCIP report and Mr Bolt's covering letter, explained that they had been provided to the Defendant's
legal team on Sunday 11 April 2021 and that urgent instructions had then been sought. But no explanation
for the delay in providing these, obviously relevant, documents to the Defendant's legal team was provided
at that stage, nor when the issue of late disclosure was raised at the hearing itself. I was assured, however,
that the documents had not been deliberately held back.

19. On 13 May 2021, the Defendant then applied to admit a witness statement of Ms Fiona Mackie who is
Head of the pre-Inspection team at the Home Office. This explains that the standard practice is for the
Home Office to fact-check a report of this nature and it exhibits a schedule containing a series of fairly
minor “corrections” which the Defendant proposes should be made to the HMCIP report. Whether they are
made is a matter for the HMCIP.

20. The Defendant's application has been resisted by the First to Fourth Claimants by letter dated 13 May
2021, and by the Fifth and Sixth Claimants by letter dated 17 May 2021. Unsurprisingly, they point out that
the Defendant's comments of 2 March 2021, which challenge aspects of ICIBI/HMCIP's initial findings, are
before the court, that there has been no explanation of why the proposed corrections could not have been
prepared between 21 March 2021 and the hearing in mid-April 2021, that there has still been no
explanation for the late disclosure of the HMCIP report and Mr Bolt's covering letter, and that it is unusual
to admit evidence after a hearing has been concluded.

21. Having considered the arguments on both sides, I decided to take Ms Mackie's witness statement and
the schedule into account in coming to my decision. In my view it is fair to do so given that I propose to
place reliance on some of the findings in the HMCIP report and one of Mr Bolt's observations in his
covering letter. In considering the HMCIP report it is helpful that I should be made aware of which, if any, of
the findings of fact in the HMCIP report are disputed by the Defendant. That does not mean that I would
automatically accept that a given proposed correction is accurate: I agree with the Claimants that limited
weight can be given to the proposed corrections themselves given that Ms Mackie does not say what
checks were carried out, when or by whom. I therefore have no means of assessing the reliability of the
Defendant's account where an issue is identified on the schedule.

22. The Claimants also asked that, if Ms Mackie's statement and exhibit are admitted in evidence, I should
also admit the minutes of a meeting of the All Parliamentary Group on Immigration Detention on 17 March
2021. They wish to rely on some contextual comments about the HMCIP report which were noted as
having been made to the meeting by the leader of the HMCIP inspection team when providing an oral
commentary on its report. I decided not to take account of this material. In my view the written report
represents the formal position of the HMCIP and should be treated as speaking for itself.

**MY APPROACH TO FACT FINDING IN THIS CASE        .**

23. The process of finding the facts has been more difficult in this case than in typical judicial review
proceedings because there are a number of points of detail and the facts are not clear in various respects


-----

intervening) [2021] EWHC 1489 (Admin)

and/or are in dispute, although there are areas of agreement between the parties. In relation to a number
of points the evidence is vague or inconsistent and/or the documentation is incomplete or unexplained.
There was also no application by any of the parties for any witness to be called for the purposes of cross
examination which might have clarified the factual position.

24. The evidence submitted on behalf of the Claimants included various statements from them which
related their experiences of being transferred to the Barracks, the conditions whilst they were there, and
their transfer out, albeit in differing levels of detail. They also submitted statements from their legal
representatives, representatives of NGOs and other concerned people, some of whom had visited the
Barracks themselves during the period in which the Claimants were resident there but some of whom had
not. There was also expert medical evidence from Professor Richard Coker (Emeritus Professor of Public
Health at the London School of Hygiene and Tropical Medicine) on the subject of the public health risks
posed by accommodation in the Barracks in the context of the Covid-19 pandemic, and from Dr
Galappathie (Consultant Forensic Psychiatrist) who examined NB, F and OMA and from Dr Lisa Wootton,
also a Consultant Forensic Psychiatrist, who examined XD and YZM.

25. The Claimants also derived considerable support from the findings of the ICIBI/HMCIP inspection team
based on a two day visit during which they saw the situation for themselves, spoke to people on site, and
carried out a survey, albeit at a point when the population of the site had been reduced to around 100. The
ICIBI carried out a further visit on 4 March 2021 and Mr Bolt's letter of 21 March 2021 states that his views
are based on his visits to Penally and Napier Barracks as well as conversations with residents and former
residents of both sites, local stakeholders and third sector organisations. In my view, the findings of
ICIBI/HMCIP deserve considerable weight given their functions and expertise, albeit they were inspecting
after the events of January 2021 and were, themselves, relying on what they were told to a significant
extent. Indeed, the schedule exhibited to Ms Mackie's witness statement tends to support this view in that it
appears from it that the Defendant is not in a position materially to dispute the factual basis of the HMCIP
report, albeit some of the conclusions in that report are challenged or addressed in her letter of 2 March
2021.

26. In the case of the evidence submitted on behalf of the Defendant, the distinct impression given is that
little attention was paid at a senior level to what was happening at the Barracks until the events of mid to
late January 2021 occurred and litigation was threatened. This accords with the finding of the HMCIP that:

_“Home Office staff were rarely present at either site. There were fundamental failures of leadership and_
_planning by the Home Office, which had led to dangerous shortcomings in the nature of the_
_accommodation and poor experiences for the residents.”_

27. The Barracks fell within Mr Williams' remit from 1 October 2020 as part of his responsibility for
managing the performance of Clearsprings in Wales and the south of England. However, he apparently did
not visit, although he was given a “virtual tour” of parts of the Barracks on 17 March 2021. The Barracks fell
within Mr Sean Palmer's remit when he became the Defendant's Director with overall responsibility for the
asylum accommodation and support system on 30 November 2020, and he visited on 5 March 2021. Ms
Creffield was brought in on 7 February 2021 as part of the management of what was deemed to be a
_“critical incident”, shortly after proceedings had been issued and after the Claimants had been moved out._
It appears that she visited the Barracks for the first time on 26 February 2021. Ms Chittenden did not visit.

28. Whether or not the Defendants' witnesses should have visited, or should have done so earlier, in
making their statements they were therefore dependent on what they were told by Clearsprings and others
about the arrangements and the conditions in the Barracks and, more importantly, about what they had
been during the time which is material to these Claims. Whether because of haste or because the matters
were not within the deponent's knowledge, or otherwise, significant aspects of the evidence of the
Defendant's witnesses were vague and/or not explained.

29. In some instances, documents were not exhibited or commented on by a witness on behalf of the
Defendant who might have been expected to do so. In other instances a document was exhibited,
apparently because it was considered that the duty of candour required that it be disclosed given that it


-----

intervening) [2021] EWHC 1489 (Admin)

assisted the Claimants' case, but the document was not referred to by the witness, still less explained or
put into context, as the duty of candour also required (see R (Citizens UK) v Secretary of State for the
**Home Department [2018] 4 WLR 123[106(3)]). Particularly on the issue of the Covid and fire safety of the**
Barracks, these omissions indicated to me that the Defendant's witnesses found it difficult to defend
aspects of the decisions which were taken whilst, at the same time, complying with their duties to the court
and to the public. This approach also affected the weight which could be given to some aspects of the
Defendant's evidence and it meant that in some instances there was no witness evidence to contextualise
or contradict the story which certain documents appeared to tell.

30. Ms Giovannetti emphasised that the case was prepared in the context of expedited proceedings. I
accept that this is a relevant consideration when evaluating the evidence, and have taken it into account,
but I note that the use of the Barracks and the situation there have been controversial for some time. The
first Pre-Action Protocol letter raising the issues in these proceedings was dated 11 January 2021. The
Defendant also apparently considered that she had a sufficiently good understanding of the facts to resist
permission, i.e. to take the stance that the Claims were not realistically arguable, when the
Acknowledgments of Service were filed on 11 February 2021. Moreover, the hearing of the Claims was
listed at the start of the Easter term, as the Defendant argued it should be, rather than during the preceding
term as the Claimants suggested. Nearly two months elapsed between the permission hearing on 16
February 2021 and the full hearing. The Defendant had a month to prepare her evidence in response and
she then served rebuttal evidence, in the form of the 2nd witness statement of Ms Creffield, as late as 13
April 2021.

31. There was also no witness statement from Clearsprings, PHE or the CPFSI. These organisations have
direct knowledge of important matters in the case and might therefore have been able to assist in this way
if the Defendant's witnesses were overstretched, or uncertain of the facts. There was, in my view, ample
time for them to do so. Indeed, for reasons which will become apparent, the lack of any statement from
PHE or the CPFSI is telling.

32. I have borne these considerations in mind in making my findings, and others should do the same in
relation to the reliance which can be placed on them for purposes other than these particular Claims.
However, as Mr Hickman QC submitted, I am entitled and indeed required to seek to establish the facts for
present purposes. I have done this by looking at the evidence as a whole and, where appropriate,
interpreting the documents and drawing inferences.

33. Where there is a specific or direct conflict of evidence, the applicable legal principles are those set out
in R (McVey and Others) v Secretary of State for Health [2010] EWHC 437 (Admin) at [35] where Silber
J stated:

_“In my view, the proper approach to disputed evidence is that: -_

_i) The basic rule is that where there is a dispute on evidence in a judicial review application, then in the_
_absence of cross examination, the facts in the defendants' evidence must be assumed to be correct;_

_ii) An exception to this rule arises where the documents show that the defendant's evidence cannot be_
_correct; and that_

_iii) The proper course for a claimant who wishes to challenge the correctness of an important aspect of the_
_defendant's evidence relating to a factual matter on which the judge will have to make a critical factual_
_finding is to apply to cross-examine the maker of the witness statement on which the defendant relies.”_

34. In McVey the factual issue was as to the date on which the Secretary of State had made a particular
decision: see [22]. This was obviously within the knowledge of the Secretary of State and it was therefore
unsurprising that, absent compelling evidence to contradict what they said on this issue, the evidence of
the Secretary of State was to be accepted.

35. The passage from **McVey, cited above, was approved by the Court of Appeal in** **R (Safeer) v**
**Secretary of State for the Home Department** _[2018] EWCA Civ 2518 [16]-[19], and it was noted by_


-----

intervening) [2021] EWHC 1489 (Admin)

Nicola Davies LJ that the test in relation to (ii) is a high one: see [19]. There, the factual issue was whether
the claimant had submitted a Current Appointment Report from Companies House with his application for
leave to remain as a Tier 1 entrepreneur. The defendant's records stated that he had not done so. Again,
the question what had or had not arrived with the claimant's application was within the knowledge of the
defendant, and the defendant's evidence was to be accepted.

36. The present case raises a wider range of factual issues in relation to the Barracks than a simple,
binary, factual question which is critical to the determination of the case. It is therefore closer to the sort of
situation which arose before Cavanagh J in **R (Soltany & Others) v SSHD [2020] EWHC 2291 where**
there were various disputed claims about conditions at the Brook House Immigration Removal Centre,
although I note that in that case there was direct evidence from G4S, the contractor which was in charge of
Brook House at the material time, as to the conditions there. Cavanagh J said this at [88]:

_“Faced with a number of disputes of fact, in these circumstances, I think that the correct approach is that_
_summarised by the authors of Auburn, Moffett and Sharland, Judicial Review, Principles and Procedures,_
_1st Ed, 2013, at paragraph 27-98: “…. [the Court] will generally proceed on the basis of the facts as stated_
_in the defendant's written evidence. This is because, as the claimant bears the burden of proof, if there is_
_no reason to doubt the defendant's version of the facts, the claimant will have failed to discharge the_
_burden on him or her. As the defendant's witnesses will not have been cross-examined, there will be little_
_basis for the court to reject their evidence. However, in certain cases there may be something about the_
_defendant's evidence (e.g. where it is internally contradictory, inherently implausible, or inconsistent with_
_other incontrovertible evidence) which will lead the court not to accept it.”_

37. This is the approach which I have adopted. With respect, essentially it requires a common-sense
approach to the evaluation of the evidence as a whole, applying the burden of proof and taking into
account the fact that there has been no “live” evidence or cross examination. In my view, as part of this
exercise it is permissible to take into account the quality of the evidence on a given point, and whether that
evidence is within the knowledge of the deponent and, if not, the source of their information. In the case of
exhibits, it is permissible to consider such evidence as the deponent provides to explain its contents and as
to the source and reliability of the information which it contains.

**THE FACTS IN MORE DETAIL**

**The Barracks**

38. The Barracks were built at the end of the 19th/beginning of the 20th century. They are located on the
outskirts of Folkestone, as I have said, near other barracks and a new housing development. They are a
bus ride away from the centre of Folkestone and a 10-minute walk away from the nearest shop, a large
supermarket.

39. The area of the Barracks is 3.79 hectares and, as noted above, it is surrounded by an 8-foot fence
which is topped by barbed wire. The Barracks comprise two rows of eight red brick, single storey,
accommodation blocks. There are other buildings on site including administrative buildings, an officer's
mess, a sergeant's mess and canteen, a drill hall, a dining hall with capacity for up to 200 people, and
various storerooms.

40. The Barracks have the capacity to accommodate 523 people but, for the purposes of accommodating
asylum seekers, capacity was reduced to 431 purportedly to allow for social distancing. It is difficult to get
an absolutely accurate picture from the evidence but, in broad terms, 15 of the 16 blocks could
accommodate up to 28 people. Blocks 1-12 did so in two wings or dormitories, each for 12-14 people, with
shared toilet and bathroom facilities for each block. The basic structure and capacity of Blocks 13-16 was
the same, but the internal configurations of the wings are slightly different: two of these blocks (13 and 15)
were divided into rooms and one (14) is a combination of dormitories and rooms. Block 16 had capacity for
up to 23 people and was divided into rooms. It was originally intended that this block be used for Covid-19
isolation purposes but, in the event, it was used for accommodation when numbers of asylum seekers in
the Barracks increased.


-----

intervening) [2021] EWHC 1489 (Admin)

41. At the material time the Barracks were used by regular, reserve and cadet units as well as the police. I
gather from the HMCIP report that they would accommodate military personnel for periods of one or two
weeks whilst they were on training exercises. The facilities are variously described in the Defendant's
documents as providing: _“a very basic standard of accommodation”… “slightly run down and basic_
_environment but facilities although basic are in sound working order”… “probably….in the middle to lower_
_quartile of the accommodation we currently use”. These documents also recognise that the surrounding_
fence: “does create a perception of an austere environment (detained)” (emphasis added).

**The increase in demand for accommodation for asylum seekers**

42. The role of Ms Chittenden's witness statement was to explain the reasons for the decision to make use
of the Barracks and the decision-making process in relation to this issue. She states that, from March 2020
onwards, there was a substantial increase in demand for accommodation for asylum seekers. The key
causes of this were the decision, announced by the Minister for Immigration Compliance and the Courts on
27 March 2020 for reasons related to the pandemic, to pause the requirement for asylum seekers to leave
their accommodation once there had been a final determination of their claim or appeal (“the 27 March
decision”). This led to a fall in turnover of dispersal accommodation and, consequently, a shortage of
accommodation into which applicants for asylum could be moved. At the same time there were relatively
high numbers of people entering the United Kingdom and making asylum claims. Whereas there were
approximately 48,000 people in receipt of asylum support accommodation as at the end of March 2020, by
the end of September 2020 this had risen by approximately 25%.

43. On 11 September 2020, the Minister's 27 March 2020 decision was reversed but this did not materially
affect the levels of demand, at least in the short term. This was, in part, because the numbers of arrivals to
the United Kingdom also increased from around 360 per week on average between March and September
2020 to around 600 a week in September and October 2020. There were several days in September when
there were more than 300 arrivals per day.

44. The measures which the Defendant took to address this situation included attempts to increase levels
of available dispersal accommodation as well as increased use of hotels to accommodate asylum seekers
on an interim basis (“contingency accommodation”). By September/October 2020 there were
approximately 9,100 asylum seekers accommodated in hotels across the United Kingdom. For various
reasons, however, the Defendant regarded the use of hotels as problematic and civil servants were
therefore given a “very clear steer to eliminate the use of hotels for contingency accommodation”.

**The decision to make use of the Barracks**

45. It was in this context that the possibility of using “Ministry of Defence sites that were no longer in use
_or had available… housing” came under discussion in August 2020 and the possibility of using the_
Barracks to accommodate asylum seekers was identified. On 3 September 2020 there was a Home Office
visit to the Barracks which reviewed the accommodation against the specification in the AASSC. A _“Site_
_visit checklist” set out the features of the Barracks and concluded that:_

_“Site is basic but fully functioning and could be occupied in its current state, but to be viable the dormitories_
_either need to be used as now with socially distanced bed layout or adapted to single room-with resultant_
_cost and delay in occupation potential”_

46. That evening Ms Tina Rea, Operations Director, raised various questions about the Barracks which
were discussed between civil servants by email. A key topic in this discussion was the feasibility of
accommodating asylum seekers in dormitories given the Covid-19 pandemic. There was also discussion
about quarantining, and about the fact that the ratio of bathroom facilities to inhabitants was below the level
normally required by the Defendant. Following on from this email discussion there is an email from Ms
Melanie Johnson, Local Authority Engagement Team, UKVI that night which says that, in her view, _“this_
_kind of estate is ideally suited to our needs although there are some issues and sensitivities” and then sets_
out certain points on which urgent clarification was needed, including as to the adequacy of the bathroom
facilities and the appropriateness of the use of dormitories given the pandemic These emails are exhibited


-----

intervening) [2021] EWHC 1489 (Admin)

to the witness statement of Ms Chittenden, but she does not refer to or comment on them. Ms Johnson did
not provide a statement.

47. From the emails it is apparent that there was to be a workshop about the various issues on 4
September 2020. Although there is no witness evidence about what was discussed at this workshop, and
although she does not refer to it, Ms Chittenden exhibits a copy of version 2 of a “Home Office Additional
_Asylum Accommodation Specification” dated 4 September 2020 (“the Specification”) which has_
amendments tracked, and which states that what was being sought was:

_“accommodation for single males who can be accommodated in a COVID secure manner in a House of_
_Multiple Occupancy (HMO) or hostel style accommodation”. (emphasis added)_

48. The Specification goes on to say that:

_“We are primarily looking for accommodation which can accommodate large numbers of people in a hostel_
_style environment but are also interested in any self-contained accommodation units…_

_Dormitories which can be adapted to be Covid-19 compliant are acceptable_

_Bathrooms should ideally be within accommodation however sites with external shower and toilet blocks_
_which can be made Covid-19 compliant are acceptable” (emphasis added)_

49. In the _“Detailed criteria” section of the Specification, it was stated that the accommodation was_
required to be capable of being “configured to offer as a minimum… Individual bedrooms or the ability to
_reconfigure dormitories to comply with social distancing” …._

50. On 4 September 2020, Ms Johnson emailed Dr Ruth Milton, Senior Medical Adviser and Consultant in
Public Health in the Emergency Response Department of PHE. She told Dr Milton that she needed Dr
Milton's help _“in giving us some guidance on the minimum position we can take on Health grounds”_
(emphasis added). Again, although the email exchanges between them are exhibited to Ms Chittenden's
statement, they are not referred to by her. But it does appear from the Specification, and this request, that
the civil servants appreciated that the accommodation needed to comply with generally applicable
requirements and standards in relation to Covid-19 safety. There were, of course, also legal requirements,
which I will come to.

51. Dr Milton indicated that PHE would be happy to advise and, later that afternoon, she tracked her
comments into the Specification by way of a series of comment boxes. In summary, Dr Milton's position
was that the proposal was problematic from a public health point of view. She commented that seeking to
accommodate groups of 200 or more people on one site was a “significant problem”:

_“Presumably there is a cost implication of fewer people but this is a significant problem as the entire_
_accommodation would need to be tested and probably isolated in single rooms with single bathroom_
_facilities in the case of any outbreak which is the problem we're faced with in both Birmingham and_
_Wakefield. Do we want to repeat it?”_

52. The reference to Birmingham and Wakefield was apparently to two smaller asylum support
accommodation centres, where there had recently been significant outbreaks of Covid-19 infections. Dr
Milton expressed doubts about how dormitories could be “COVID compliant” but said that she would check.
In relation to the reference in the Specification to configuring dormitories to comply with social distancing,
she drew attention to the then current guidance on youth hostels which stated, amongst other things, that
dormitory rooms would be closed except for groups from the same household or support bubble, as would
other indoor shared facilities.

53. An email from Ms Johnson to Dr Milton on 7 September 2020 then proposed a telephone conversation
to discuss Dr Milton's comments on the Specification. Ms Johnson stated that she was aware that the
Ministry of Defence “are continuing to use [dormitories] in a socially distanced way and while appreciating
_that our service users present more risk given their journeys, I wonder if that is a principle we could use?”._


-----

intervening) [2021] EWHC 1489 (Admin)

54. There is then an email summary, dated 9 September 2020, of a conversation which apparently took
place between Ms Johnson and Dr Milton on 7 September 2020. This states:

_“Summary of the conversation I had with PH England on 7th September with Ruth Milton_

_Public Health advice is just that – we don't have to follow it but the fall out should we choose not to and_
_then have an outbreak of covid the fall out would be significant._

_Their advice is that dormitories are not suitable but that if we must use them as such, we must have a_
_minimum of 2m between each bed._

_Ideally if we have say 6 to a dormitory, they should be treated as one “bubble” and kept together and away_
_from others as much as possible_

_We need to make sure we have facilities to enable completion of the 14-day quarantine period. This could_
**_be tricky._**

_We need to have rigorous cleaning in place, hand sanitisers, as much natural ventilation as possible. I_
_think we need to build extra cleaning into any contractual arrangements to manage this._

_We need to make sure service users understand the restrictions and how to socially distance etc We need_
_to make sure workers do the same_

_We need to have a track and trace system in place – sign in/out sort of thing. They're happy to come on_
_any site visits with us – resources and time allowing.” (underlining added)_

55. Mr Williams summarised the advice set out in this email at paragraph 11 of his witness statement for
the purposes of resisting permission. I note that although he clearly had the email in his possession he did
not refer to, or exhibit, it and his summary did not include any reference to the first underlined paragraph of
the email, which suggested that PHE advice need not be followed but warned about the fall out if there was
then an outbreak of Covid-19 infections. Ms Chittenden, whose statement is intended to explain the
decision making process which led to the use of the Barracks, does exhibit the email but makes no
reference to it, nor to the advice or views of Dr Milton, although there is passing reference to the views of
PHE in her statement which I will come to.

56. As I have noted, there is also no witness statement from Ms Johnson or PHE to explain precisely what
its advice was, still less to say that PHE regarded the arrangements at the Barracks as safe or even
acceptable. It appears, however, that PHE did not regard the use of dormitories as even capable of being
“COVID-19 compliant” or of satisfying even a “minimum position we can take on Health grounds”. I also
note that PHE gave advice as to the approach which should be taken if, contrary to its advice, the Barracks
were to be used. There could be _“say” six to a dormitory and the six would then form a bubble. This_
appears to have been inspired by the so called “rule of six” which, at that time, meant that, by law, no more
than six people from different households could gather, whether indoors or outdoors, unless they fell within
a relevant exception: see regulation 5, The Health Protection (Coronavirus Restrictions) (No 2) (England)
Regulations 2020/674. In the event, there were 12-14 asylum seekers per dormitory at the Barracks with
two dormitories per block, sharing the indoor bathroom facilities, and four dormitories sharing additional
portacabin facilities.

57. HMCIP also found that:

_“Public Health England further advised that if the accommodation was still to be used, the ability to isolate_
_positive cases and/or establish small cohorting arrangements was essential to contain a COVID-19_
_outbreak.” (emphasis added)_

58. In other words, there had to be bubbling in groups of six to minimise the risk of infection, and there had
to be the ability to isolate or “cohort” residents if any of them tested positive.

59. Finally, I note that there is no reference in Ms Johnson's email summary of 9 September 2020 to the
MOD approach to shared accommodation at that time despite this approach having been suggested by her
as a possible a for ard and something hich she anted to disc ss ith Dr Milton on 7 September


-----

intervening) [2021] EWHC 1489 (Admin)

2020. It appears, therefore, that it is not the case that PHE approved the proposed arrangements on the
basis that they were consistent with the MOD's approach. Ms Chittenden says, at paragraph 18 of her
witness statement dated 18 March 2021:

_“The MOD has continued to utilise multiple occupancy accommodation throughout the last 12 months,_
_primarily for transit accommodation whilst using the defence training estate for recruits undergoing phase 1_
_training. Alongside this, a small proportion of trained service personnel are housed in multiple occupancy_
_accommodation. It is my understanding that the guidance applied by the MOD is that if personnel are in_
_multi-occupancy rooms: they must adhere to effective bed spacing (minimum of 2m between beds/heads);_
_they should reduce the occupancy of multi-room accommodation where necessary to minimise the impact_
_of isolating subsequent 'household-contacts'; they should ensure there is adequate room ventilation; and_
_consideration should be given to the creation of cohorts/teams by room. While we recognised that_
_dormitory style accommodation was not recommended by PHE, we understood, from discussions with_
_PHE, that if we needed to use it then we should implement those same COVID safe measures e.g._
_minimum 2m distance between beds, creation of 'bubbles' to constitute a household, regular cleaning_
_regimes etc. By following these guidelines for COVID safe environments and given that dormitories were_
_allowed within the AASC contracts, I was of the understanding that we had a viable option.” (emphasis_
added)

60. However, I note that she does not say that the MOD approach was or is approved by PHE. Nor does
she say where her understanding of the guidance applied by the MOD is derived from or exhibit any
documentary evidence of the MOD's approach to this issue. Nor does she say for example whether, under
the MOD's approach, there was or is any limit to the number of people who may share a multi-occupancy
room or for how long. The details of the MOD's approach may, of course, have varied over time according
to the level of risk posed by the pandemic but there is no evidence about this. Nor does Ms Chittenden
mention, when she refers to “bubbles” or at all, that PHE appear, from Ms Johnson's 9 February 2020
email, to have been contemplating a maximum of six per dormitory, rather than 12-14, and that they would
then form a bubble. Nor is there reference to PHE's advice on cohorting. These considerations, of course,
would have had a highly material impact on the capacity of, and therefore the economics of using, the
Barracks.

61. Ms Chittenden also makes the point in her statement that no one would be transferred into the
Barracks less than 14 days after arrival in this country, “thereby mitigating the risk that they had arrived in
_this country with COVID-19”. She says that they were optimistic, given the then current rates of Covid-19_
and the reversal of the 27 March 2020 decision, that levels of demand for asylum support accommodation
would return to normal. But, in fact, rates of infection were rising in September 2020 and continued do so
thereafter. As Mr Hickman points out, Ms Chittenden does not suggest that any thought was given to
whether these arrangements would comply with the law on coronavirus restrictions which was applicable at
the time, and nor is there any other evidence that this was considered at any stage.

62. The basis for Ms Chittenden's understanding that “we had a viable option” is therefore inadequately
explained given the views of PHE and the legal restrictions on gatherings between different households
which were then applicable. The lack of detail in relation to this aspect of Ms Chittenden's evidence
suggests that there is not even a compelling case to be made that the approach adopted by the MOD and
the approach taken to asylum seekers in the present case are truly comparable. If there were, I have little
doubt that the position would have been set out in detail. There certainly was time for Ms Chittenden to do
so. It is perhaps for this reason that Ms Giovannetti did not seek to develop an argument that the
Defendant's approach was comparable to that of the MOD and therefore adequate.

63. An email from Ms Johnson on the morning of 14 September 2020 indicates that the proposal was that
asylum seekers would only be accommodated in the Barracks if they had quarantined for more than the 14
day period since their arrival in the United Kingdom although there was “Ministerial pressure to go straight
_to MoD site”. The email also states Ms Johnson's understanding that the length of stay would be_ _“a few_
_weeks while dispersed accommodation is found”. Ms Johnson also asks:_


-----

intervening) [2021] EWHC 1489 (Admin)

“can we be clear who has taken the decision to proceed with the room sharing? I'm just conscious I haven't
_seen anything specific from the Minister, but I may have missed it? I think this is quite important for our_
_audit trail” (emphasis added)._

64. This appears to be further evidence that officials appreciated that there was significant risk in going
against the advice of PHE and that the fall-out from doing so would at least potentially be significant. The
reply from Ms Chittenden was that the issue of room sharing should be put in a note to the Minister.

65. Ms Chittenden's submission to the Defendant, dated 15 September 2020, states:

**_“6 We have sought Public Health England/Wales advice on how we can make best use of this_**
**_accommodation whilst minimising risks from covid-19_** _. Public Health_
_advice is that, to minimise risk of transmission, service users should be accommodated in single rooms_
_with en suite facilities. It is not possible to follow this advice in these sites given their configuration. We_
_therefore intend to follow the model which the MOD has adopted which is to continue to use the_
_dormitories as shared rooms but to limit occupancy ensuring a minimum distance between beds of at least_
_2 metres. This will be complemented by a range of additional safety measures including increased cleaning_
_of surfaces, availability of hand sanitisers, a track and trace system and extensive communications with_
_residents around covid-19 control measures. We are engaged with both Public Health Wales and local_
_public health officials in Folkstone, both groups are working with us and will attend site to review what we_
_have in place. Implementing these necessary health measures reduces our capacity across 2 sites to_
_c650…” (emphasis in the original)_

66. The review which PHE and local public health officials were to conduct has not been disclosed and
there has been no evidence about it from the Defendant. I note that this passage does not actually say in
terms that the PHE advised that dormitories were not suitable accommodation. Nor does the reference to
the approach of the MOD actually say whether this approach complies with PHE advice. Nor does the
passage say whether there are any limits placed by the MOD on numbers per room and the length of stay,
and nor does it say whether these will be comparable under the proposal for asylum seekers to be
accommodated at the Barracks.

67. The submission later says:

**_“9. Given the dormitory configuration of both sites it is not possible to provide appropriate_**
**_quarantine facilities without reducing the maximum Covid compliant capacity to an uneconomic_**
**_level. We therefore recommend that we continue to make use of existing IA or other facility where single_**
_rooms can be provided to manage the quarantine period. If you agree, we will ensure a system where_
_service users complete their screening process at one of our Intake Units, transfer to an IA, or other facility_
_where single rooms can be provided to complete the remainder of their 14 day quarantine period and on_
_completion of the 14 days, if showing no signs of covid-19, they are transferred to one of the MOD sites._

**_10. This system would also enable us to group service users into bubbles so that they can be_**
**_transferred as one bubble to the MOD site and be accommodated together as one bubble within_**
**_each dormitory, thus enabling further management of the risks around covid-19 transmission_**
_. We are also considering whether testing of asylum seekers prior to moving them to MOD facilities might_
_further mitigate the risk of an outbreak.” (emphasis in the original)_

68. Again, the submission does not state that PHE had advised that, if dormitories were to be used, there
should be a limit of six per dormitory and that they should form a bubble. In my view this is because it was
never any part of the proposal to use the Barracks that this would be the approach. The reality was that the
numbers which it was intended to accommodate at the Barracks did not permit a limit of six per dormitory.
Although the Defendant's witnesses do not address this point a _“Contingency Asylum Accommodation_
_Ministry of Defence sites Factsheet” dated October 2020 states that the plan was that 234 asylum seekers_
would be accommodated in Penally and 431 at the Barracks. As noted above Ms Chittenden's submission
gave a figure of c650 after Covid risk reduction measures and, indeed, there were 414 residents by mid
November 2020. An approach based on six per dormitory would have reduced the capacity of the Barracks


-----

intervening) [2021] EWHC 1489 (Admin)

below half of this number. The need for there to be bubbles of six and the ability to cohort in the event of
residents becoming infected therefore appear to be further key aspects of the advice given by PHE which
would not be followed.

69. Moreover, on the evidence it is not the case that asylum seekers were transferred from quarantine to
the Barracks. They were not transferred within 14 days of arrival in the United Kingdom, but they were
transferred more than 14 days after arrival. All but one of the Claimants were transferred six weeks or more
after arrival (it was 4 weeks in the other case), all having been accommodated in hotels from which they
could come and go as they pleased. They were not quarantined for 14 days before transfer and nor were
they tested before they were transferred, although there is evidence that those who arrived in September
2020 had their temperature taken.

70. Nor is there any evidence that there were pre-existing bubbles of asylum seekers who were
transferred into the Barracks and remained in their bubble during their stay there as the submission
proposed. The evidence of the Claimants is that the residents arrived at different times, as individuals or
small groups, and they joined other asylum seekers who were already living in their blocks. I address the
Defendant's suggestion that, once at the Barracks, residents were formed into bubbles of 24-28, which did
not mix with residents of other blocks, below.

71. Mr Williams states that on 17 September 2020 there was ministerial approval of the plans to make use
of the Barracks, although I have not seen documentary evidence of the decision itself other than the
submissions. I note that Ms Chittenden's submission of 20 September 2020 stated that there were risks
associated with the decision:

_“These risks relate primarily….2) to the wellbeing and health of service users …While we are mitigating the_
_risks we have identified; we are not in control of all the drivers as you are well aware”._

72. The first asylum seekers were transferred into the Barracks on 22 September 2020, as I have noted.

**The conditions at the Barracks.**

73. There are various points of contention in relation to the conditions at the Barracks and these are of
varying degrees of importance. It has been difficult to gain a clear and representative picture from the
evidence given that the situation appears to have varied over time. The Claimants' evidence is to a
significant degree focussed on the position after the Covid-19 outbreak in mid-January and/or the
disturbance and the fire at the end of that month. At that point the site had been locked down, communal
areas had been closed, conditions may well have been at their worst and tensions were at their highest.
There are also critical reports based on inspections carried out after the Covid-19 outbreak including, of
course, the HMCIP report. But these do not necessarily reflect the position at all material times and there is
evidence which paints a more positive picture in October and November 2020. I have therefore had to do
the best I can on the available evidence.

74. Access to the site was through a main gate which was controlled by security guards and, until on or
about 26 February 2021, was padlocked. There was also a logbook which the residents were required to
use to record the times of their exits from, and entries to, the Barracks. I accept that these features, the
perimeter fence and the overall nature of the accommodation and lay out of the site, meant that the
Barracks felt, as M put it, “like a detention centre or prison camp”. This is a clear theme in the Claimants'
evidence.

75. The dormitories were divided up so that the beds were at least 2 metres apart and each resident had a
bed and a locker. The spaces were divided by plywood partitions which were approximately 1.9 metres in
height. There was a curtain at the entrance to each section. There is a dispute between the parties as to
whether this was a fire-retardant curtain, or a sheet placed there by the residents themselves. It appears
that initially – XD says for at least the first two months and YZM says around three months - the residents
may have put up their own sheets to act as curtains. A document prepared by the CPFSI, and dated 25
February 2021, suggests that fire retardant curtains were put in but that residents were in the habit of


-----

intervening) [2021] EWHC 1489 (Admin)

putting up additional sheets to enhance their privacy. This practice appears to have been “clamped down
_on” by that date._

76. I accept that the dormitories were noisy, and, in practice, they were not well ventilated because the
windows were not opened. The ventilation point is, of course, relevant to the issue of Covid risk as well as
the general comfort and well-being of the residents. There was centrally controlled strip lighting which
meant that, when it was switched on, the whole of the dormitory would be lit. There was also a lack of
privacy given that the partitioning did not reach from floor to ceiling and the entrance to each space was
shielded by a curtain rather than a door. These features meant that people could enter a resident's space
without warning, conversations and music etc could be overheard, sleep was disrupted, and residents
suffered from insomnia. There is also evidence that relations between residents were sometimes strained
and that there was verbal and physical aggression between them from time to time.

77. The Claimants' case is that the dormitories were not adequately heated and/or that the heating system
did not work. I accept that there may well have been occasions when it did not work, and the dormitories
were therefore cold, but on the whole, it appears that the blocks were adequately heated. For example, a
report by a Countrywide Safeguarding Adults Service Manager, dated 12 February 2021, states that the
blocks were centrally heated and “felt warm during the visit”. The HMCIP report also says that “All billets
_were double glazed, and the heating system kept them at a comfortable temperature”. The Claimants'_
evidence on this issue is also not entirely consistent, as Ms Giovannetti points out.

78. There is also an issue as to how often the dormitories were cleaned. A report following an infection
prevention visit on 20 January 2021 states that _“dormitories are cleaned twice per day” and that other_
areas such as the prayer room were cleaned once per week, albeit this may well have been what the
author was told rather than what she saw. Residents were not provided with cleaning equipment at the
time of her report although there is evidence that this was addressed subsequently. The HMCIP report
states that there had been an increase in cleaning to twice a day since the outbreak _“but despite this_
_cleaning practices were inadequate. Many areas were filthy”._

79. There was also disputed evidence about bathroom facilities. The broad picture was that each block of
2 dormitories had one shared bathroom, each with 6 sinks, 4 showers, 2 toilets and a bank of urinals.
Portacabin facilities were therefore placed between blocks in order to increase capacity. As I understand it,
once this was done there is no real room for complaint in terms of the ratio of facilities to residents. The
Claimants do point out, however, that the showers in the blocks were designed to be shared and that there
were no doors or screens which would enable them to shower in private. This, they say, would potentially
be particularly humiliating in the case of an asylum seeker who, say, was scarred as a result of having
been tortured. I accept this point, but I also accept that they could seek to mitigate this difficulty. Ms
Willman says in her first witness statement that, for reasons of privacy, residents would queue up to use
the shower one at a time. Residents could also take a shower at a quiet time of day, or they could take a
shower in the portacabin facilities which contained individual showers with curtains. I accept that the
portacabins would be cold in cold weather, but I also accept the Defendant's case that, overall, the
showering arrangements at the Barracks would not result in undue hardship or, at least, they were
“adequate”.

80. The Claimants also say that the bathroom facilities were dirty. A Human Applications report of 2
November 2020 indicates that, as one would expect, the newly installed portacabin facilities were good
quality facilities, and very clean at that stage, but the report by a Countrywide Safeguarding Adults Service
Manager, referred to above, is less complementary about the bathing facilities overall. Under the heading
_“An unsafe, unhygienic, or overcrowded environment” the author states:_

_“Evidence of poor hygiene was visible in communal ablution areas. These included toilet and shower_
_blocks, both incorporated within the barrack buildings and ancillary temporary/portable shower facilities_
_located behind accommodation blocks. Some toilet cubicles had faecal matter, tissue, and urine in the_
_pans or on the floor around the pedestals. In the temporary facilities a drain was visibly blocked in a_


-----

intervening) [2021] EWHC 1489 (Admin)

_shower tray, with water sitting in the pan…. Evidence of significant mould accumulation was visible on the_
_ceilings of shower rooms indicative of poor ventilation.”_

81. The Claimants also say that toilets were often broken. Toilets may well have been out of order from
time to time, but the evidence is not such as to establish that this was a very significant problem. From the
pictures I have seen, including those exhibited by the Claimants, the toilet and washing facilities were
basic, and were less than pristine but, generally, they do not appear to have been squalid or unusable.
Taken as a whole, it was open to the Defendant to take the view that they were “adequate”. I also accept
Ms Creffield's evidence that, by the time of her visit in 26 February 2021, the bathrooms were almost all
clean.

82. It appears that the residents had access to a laundry and to two social rooms which had televisions,
two pool tables and games equipment. They also played football in the areas outside the blocks and there
is evidence of other social and educational activities being organised from time to time, although it appears
that this was not very often and it is not clear how many residents were able to participate.

83. The Barracks had internet access which the Claimants were able to use, and there was mobile phone
reception.

**Covid safety measures at the Barracks**

84. In his first witness statement Mr Williams says, at paragraph 38, that the Defendant engaged with PHE
and local public health officials “from the outset, on how best to manage and minimise the risk of infection
_at the site” (emphasis added:_

_“A COVID risk assessment was carried out to understand the risks associated with COVID at the site, and_
_to set out the measures required to reduce the risk to as low as reasonably practicable for both residents_
_and members of staff. A copy of the risk assessment is exhibited at [DL/16-26]. CRH also developed an_
_infection control policy [DL/12-15], a COVID outbreak plan [DL/27-36] and Napier Outbreak Standard_
_Operating Procedure [DL/37-53]. CRH is in the process of updating all risk assessment and guidance_
_following the COVID outbreak on the site in January 2021. These are not yet complete.”_

85. He did not seek to correct this passage in his second witness statement. However, examination of the
exhibits to which he refers reveals that it gives a more favourable impression than is justified by the
evidence:

i) The risk assessment to which he refers was carried out on 30 January 2021. So, the first Covid risk
assessment actually took place after the outbreak in mid-January 2021 rather than _“at the outset” as he_
implies.

ii) The “infection control policy” to which he refers is undated and appears to be directed to the protection
of staff, and therefore to provide guidance to them as to steps to be taken for their own protection, rather
than that of asylum seekers. It is not clear that it relates to the Barracks, although it may do as it refers to a
“camp”.

iii) The “COVID outbreak plan” is also undated and does not appear to relate to the Barracks at all.

iv) The “Napier Outbreak Standard Operating Procedure” is in fact called “Asylum Seeker Accommodation
_Covid-19 Joint SOP” and it is applicable, as the title suggests, to all such accommodation including hotels_
and the Barracks. It is in draft, undated (although it appears to post-date the mid-January 2021 outbreak
given that it refers to the dining hall being closed, and food being delivered to the dormitories) and it is in
any event unfinished. It appears that it may be a generally applicable policy which someone had begun to
amend so that it also covered the Barracks.

86. Mr Williams then goes on to say, at paragraph 39, that there were various other measures in place
before the outbreak in mid-January 2021. These included the induction process, the provision of face
masks and of hand sanitiser at locations around the site as well as hot water and soap and pocket-sized
hand sanitiser at the gates. He says that there was signage in English, Arabic and in pictorial form. He


-----

intervening) [2021] EWHC 1489 (Admin)

refers to the lay out of the dormitories as designed to minimise risk and he says that they were cleaned
regularly. He says that mealtimes were staggered, and the queue supervised, that there was a COVID
officer on site to ensure compliance and that there was a track and trace system at the gate. He also says
that the individual showers and wash basins were sealed off although it is quite clear, from photos which I
have seen, that they were not. The authority of these aspects of his evidence is further undermined by the
fact that he admits in his second statement that he confused Penally and Napier in his first statement, and
that the information in his first statement was in any event what he had gathered from Clearsprings and
others under “very difficult time pressures....I was not able to make detailed checks in the time available”.

87. It is noteworthy that Mr Williams does not suggest that there was bubbling in operation as a
preventative measure. He says that a block was set aside with rooms in which symptomatic residents
could self-isolate, and that there was a protocol which was followed in this regard, although he does not
exhibit it. The documents which he does exhibit do not refer to bubbling as a preventative measure either,
although the draft _“Asylum Seeker Accommodation Covid-19 Joint SOP” does refer to the possibility of_
cohorting dormitories which were being used for quarantining residents who had tested positive or were
exhibiting symptoms.

88. Nor is there any suggestion of bubbling in the induction pack exhibited by Mr Palmer. This makes
various references to Covid-19 and sets out precautionary measures such as social distancing, hand
cleansing and mask wearing, but it does not state that residents must remain in any particular group and
not have contact with any residents outside that group. Similarly, the “Contingency Asylum Accommodation
_Ministry of Defence sites Factsheet” dated October 2020 gives an account under the heading “What Covid-_
_19 guidance and measures are in place?”. It refers to staggered mealtimes but makes no reference to_
bubbling. Nor is there evidence of bubbling in any of the posters which were put up around the Barracks
which I have seen in photos exhibited by the Claimants and the Defendants. Indeed, a notice in one of
those photos, which said that there was a limit of 50 people in the recreation room at any one time, would
seem to be entirely inconsistent with any form of bubbling.

89. I therefore read the Covid-19 audit of 2 November 2020, which was apparently carried out by a third
party organisation known as Human Applications, and on which Ms Giovannetti placed reliance, with some
scepticism where it claims that Covid related risk was managed by forming two blocks into a bubble which
worked like a household and did _“not mix with other bubbles indoors for any reason”. The same report_
suggests that access to the dining hall and indoor recreation facilities was “on a strict rota with the facilities
_being cleaned between each use” and paragraph 7.15 is to similar effect, with it being said that there were_
households of 24 which never mixed with others on the site. Although there are also references to bubbling
in a “Napier Inspection Report” dated 13 November 2020, which Mr Palmer says was carried out by Home
Office staff, neither document refers to the fact that each block shared portacabin toilets and showering
facilities with another block so that 48-56 residents were sharing them.

90. In any event, the suggestion that there was separation of blocks does not accord with the other
evidence in the case, including aspects of the Defendant's own evidence as I have pointed out. It may be
true, as the 2 November audit suggests, that a dormitory was isolated or cohorted on one occasion before
the audit, as a result of an infection. But that is not the same as bubbling so as to prevent infection. The
Claimants are quite clear that, before the mid-January 2021 outbreak, they could come and go as they
pleased on site, that mealtimes were not staggered – they could choose when and with whom they ate –
and that residents mingled freely in the dining and recreational areas, in the prayer room and, indeed,
throughout the site. I accept this evidence for the reasons which I have given.

91. It is not clear how bubbling two dormitories would work anyway, let alone four. Apart from the point
that the residents were free to come and go from the Barracks, and the point about the shared portacabin
facilities, as the Human Applications report itself observes at para 7.16 “It suited Napier to make a
_“household” of 24, but it is not clear that this is permissible within a strict interpretation of the PHE_
_guidance”. Nor is it clear that this arrangement complied with the law, as Mr Hickman pointed out, although_
this was not a pleaded ground of challenge and I do not need to reach a firm view on it in any event.


-----

intervening) [2021] EWHC 1489 (Admin)

92. The Human Applications audit goes on to point out that the second lock down was to begin on 5
November 2020. This would mean that, by law (regulations 8 and 9 regulation 5, The Health Protection
(Coronavirus Restrictions) (No 4) (England) Regulations 2020/1200), households could not even mix out of
doors, although meeting one on one between members of households would be permitted. The audit
rightly observes that “Based on what was observed during the audit, this will be much harder to manage at
_this site”. There is no evidence which suggests that any steps were taken to address the stricter_
requirements of the second lockdown, nor indeed the modified restrictions subsequently imposed by
statutory instrument on 2 and then 20 December 2020, and then for the purposes of the third lockdown on
6 January 2021, as Mr Hickman points out.

93. As for other Covid safety measures, I have made the point that there was little or no ventilation in the
dormitories. There is some evidence that the residents were provided with masks, but that these were
frequently not worn at least before the outbreak in mid-January. There were hand sanitiser stations located
around the Barracks. Some of the evidence suggests that these were generally functioning but there is
other evidence that they were frequently empty. There was signage but, until the outbreak in January 2021,
this was translated into only 2 or 3 of the languages which were spoken in the Barracks. There is also
evidence that one-way systems and/or social distancing indoors were not feasible and were not in
operation owing to lack of space.

94. Overall, however, I need not reach firm views on the minutiae of these matters in the light of the key
points, which I have addressed above, and in the light of the condemnation of the arrangements by those
with expertise in these matters, which I summarise below. The “bottom line” is that the arrangements at the
Barracks were contrary to the advice of PHE and did not even implement key aspects of the risk mitigation
measures which the Defendant herself apparently regarded as desirable and feasible. The precautions
which were taken were completely inadequate to prevent the spread of Covid-19 infection, and there was
no real dispute before me that the outbreak which occurred in mid-January 2021 was inevitable. Moreover,
having gone against PHE advice, it was not feasible to deal with the outbreak on site because of the
number of residents. More than 100 residents therefore had to be transferred out at short notice and the
population of the Barracks drastically reduced over the following weeks.

**Fire safety.**

95. Ms Creffield touches on the question of fire safety at the Barracks in her first witness statement, dated
18 March 2021:

i) At paragraph 4 she says that Clearsprings _“is” working with the Crown Premises Fire Safety_
Inspectorate “who have been to site on various occasions”, most recently on 25 February 2021, and she
identifies and exhibits the report which resulted from the first CPFSI inspection, which took place on 24
November 2020. That report is dated 30 November 2020. She does not then explain the contents of the
report or what steps were taken to implement its recommendations/requirements other than to say that
_“there have been two fire drills recently”. She adds that the CPFSI are monitoring the progress of work on_
the site and Clearspring's compliance with its own fire risk assessments and she says that she was notified
that the remedial works identified in the Clearprings fire risk assessments were scheduled to start on 15
March 2021. She says that, on 18 March 2021, the CPFSI “confirmed [to her] that overall, they have seen
_a marked improvement in compliance”._

ii) At paragraph 5, she says that “the provider has confirmed that the on-site staff have received fire
_awareness training. I am aware that Fire risk assessments had previously been carried out when the site_
_opened”._

96. Ms Creffield also deals briefly with the consequences of the fire on 29 January 2021 and the presence
of asbestos on the site which, she says, has been assessed as presenting a medium to very low risk. She
states that she has requested the schedule of works and list of completed actions from Clearsprings.

97. In her second witness statement, dated 13 April 2021, Ms Creffield says that the CPFSI carried out an
investigation on 1 February 2021 following the fire, and a follow-up inspection on 25 February 2021. She


-----

intervening) [2021] EWHC 1489 (Admin)

exhibits a spreadsheet which, she says, sets out remedial works required by the CPFSI following the
inspection. She adds:

_“I have also looked into the position as regards previous fire risk assessments to the extent that I have_
_been able to do so in the limited time available. I can also confirm that [the CPFSI] carried out a site visit_
_and hazard inspection prior to occupancy, although this was not a full inspection and that Clearsprings also_
_commissioned updated fire risk assessments in September 2020”._

98. Although the witness statements of Mr Williams, Mr Palmer and Ms Creffield cover the disturbance
and the damage resulting from the fire on 29 January 2021 relatively fully, only Ms Creffield provided
evidence with any level of detail on the subject of fire safety measures prior to the fire and, with respect to
her, it is not particularly detailed. Ms Giovannetti explained that this was because fire safety was not one of
the pleaded issues (though the 29 January fire features in a number of the statements on which the
Claimants rely) and because of the lack of time available to prepare for the hearing although, of course, Ms
Creffield appears to have appreciated that this question was relevant to the adequacy of the
accommodation at the Barracks when she submitted her first statement, and she submitted a second
witness statement dated 13 April 2021. Apparently appreciating the relevance of the issue, Mr Williams
also said that fire and other risk assessments had been carried out at paragraph 16 of his 11 February
2021 witness statement, which is a point to which I will return.

99. Again, I have therefore had to interpret the documents as best I can in the light of such witness
evidence as there is.

100. There is a statement in the “Site visit checklist”, dated 3 September 2020, referred to at paragraph

[45] above, that “Site complies with all fire and smoke detection legislation”. But, other than this, there is no
documentary evidence that I can see of fire inspections in or about September 2020 or for the purposes of
ensuring that the Barracks were safe to accommodate asylum seekers in the numbers and conditions in
which they were intended to be accommodated. Even if inspections or visits were carried out, it appears
that this was before Clearsprings began to manage the site and/or asylum seekers had been moved in. As
will be seen, the fact that the asylum seekers were accommodated 12-14 to a dormitory in spaces which
were divided by combustible materials, and the actual operation of the Barracks whilst they were there,
were relevant to the issue of fire risk. The only actual assessments which I have seen are those to which I
refer below.

101. Starting with the CPFSI report of 30 November 2020, this took the form of a letter which confirmed
the Inspector's:

_“…. opinion that the identified individuals or groups of people would be at risk in case of fire. You will need_
_to take action to ensure their safety._

_In the event that a permanent solution cannot be implemented immediately, you will need to introduce_
_interim measures to reduce the level of risk whilst longer term measures are being prepared.”_

102. The letter goes on to say that the Inspector had stated that their initial enforcement decision was to
allow an opportunity to comply in a timely manner, rather than immediately serve an enforcement notice. It
was therefore necessary to develop an action plan, and that “given the level of risk involved” an informal
approach could only be maintained if there was evidence of commitment and ongoing progress towards
compliance.

103. The letter attached a Schedule which assessed the arrangements at the Barracks against the
requirements of the Regulatory Reform (Fire Safety) Order 2005 under the headings _“General Fire_
_Precautions”,_ _“Fire Safety Management” and_ _“Fire Safety Maintenance”. It identified 3 areas of_ _“serious_
_risk” -_ _“reducing the risk of fire”,_ _“cooperation and coordination” and_ _“maintaining equipment in efficient_
_working order”. There were also six areas of “significant risk” - “reducing risk of spread of fire”, “warning of_
_fire”, “means of escape”, “emergency procedures and instructions”, “fire training and drills” and “day-to-day_
_management of safety”. With one exception, the scoring system indicates that in respect of General Fire_


-----

intervening) [2021] EWHC 1489 (Admin)

Precautions there was either _“no action planned” or_ _“inadequate action planned” to deal with the failings_
identified.

104. The picture which emerges from this CPFSI report is that, whatever assessments may or may not
have taken place earlier, the Inspector considered that the arrangements in the dormitories did not provide
adequate protection from the serious risk of fire presented by “an excessive level of combustible materials

_[which were] present in shared spaces”. This is clearly a reference to the plywood dividers and the curtains_
which were being used by the residents to cover the entrance to their spaces. In light of the Defendant's
claim that each entrance was covered by a fire retardant curtain, rather than a sheet which was placed
there, I note that the example given was _“The service users are using combustible material as a way of_
_providing privacy for their space”. As noted above, and consistently with this observation, the Claimants_
say that for the first two or three months they put up sheets to give themselves privacy. It appears from the
CPFSI spreadsheet of 25 February 2021 that they then used sheets to enhance the level of privacy
provided by the curtains which had been put in but that this practice had been clamped down on by this
date.

105. In addition to this, it was said by the CPFSI that people were smoking in the blocks. Fire detectors
were not correctly located or installed so as to ensure a sufficiently early warning of fire. Emergency doors
were secured in a manner which prevented them from being easily and immediately opened in an
emergency. Fire notices were in English only. There had been no fire drills. The “Site Responsible Person”
had not been provided with suitable information about the effectiveness, or rather lack of effectiveness, of
the fire precautions. There had been a failure to ensure that the premises and any fire precautions
equipment were maintained in an efficient state, in efficient working order and in good repair.

106. HMCIP's interim findings of 8 March 2021 record that as at the time of their inspection on 17-18
February 2021:

_“The CPFSI informed us of serious concerns about fire safety at Napier that had not been fully addressed_
_at the time of [our]… visit.”_

107. The 25 February 2021 CPFSI spreadsheet does, however, indicate that some progress had been
made at this point, although the CPFSI assessed the position as Amber 2 (i.e. “significant risk – inadequate
_action planned”) in respect of “reducing the risk of fire”, “emergency procedures and instructions”, and also_
Amber 2 in respect of _“fire training and drills” and_ _“monitoring the internal fire safety management_
_arrangements”. The spreadsheet then sets out a lengthy and detailed list of works identified after the_
incident on 29 January 2021, in respect of each of the blocks, the canteen and the recreation block which
were required to be carried out, with deadlines for this to be done.

108. I note that on 30 November 2020 the first CPFSI report was sent to the Home Office Nationwide
Accommodation Services Limited (“NACCS”) and copied to various people including Mr Williams. On 2
March 2021 he then emailed CPFSI - _“Picking up upon another piece of work about Napier” - to ask_
whether they had been supplied with “specific details” about resolving the issues in the report. It appears
from his email that he was doing so in connection with the approaching deadline for service of the
Defendant's evidence in these proceedings. He was told, in a reply that day:

_“I have been to site on various occasions subsequently, the latest visit was last Thursday._

_Work is progressing and finally they seem to be taking the Fire Safety more seriously, but I will be_
_continually monitoring it._

_After the fire more resources have been thrown at the site, the detection has been serviced and repaired_
_after a significant amount of it was vandalised during the disturbance._

_Emergency lighting has been repaired and is functioning._

_Staff training is happening again on the 4th, but staff questioned last week showed a good basic_
_knowledge._


-----

intervening) [2021] EWHC 1489 (Admin)

_I have requested confirmation of the standards and testing of the Fire Alarm, Emergency Lighting and_
_training._

_Smoking is still happening in the blocks and the fire doors have not yet been repaired._

_The Fire Risk Assessments are being reviewed currently. Routine meetings between Ready Homes and_
_NACCS have not focused on fire safety but on Covid, which has to change, I know Covid has been a major_
_issue on the site but Fire Safety cannot be ignored._

_No Fire Drill has yet been undertaken.” (emphasis added)_

109. Ms Creffield exhibits this email to her first witness statement but does not refer to it, other than as
showing that there had been a CPFSI visit on 25 February 2021 and that the situation was being monitored
by them. It appears from the last entry in the email that the fire drills referred to in Ms Creffield's witness
statement therefore took place after 2 March 2021 and more than a month after there had been an actual
fire.

110. Mr Williams says in his 11 February 2021 witness statement that “Fire and other risk assessments
_were carried out to ensure that the site was safe and secure” but he does not exhibit or refer to the 30_
November CPFSI report in this, or his second, witness statement. This is surprising given that he was a
recipient of the CPFSI report at the time it was produced and given that he chased up the question whether
there had been any progress on 2 March 2021, apparently for the purposes of these proceedings. Nor
does he refer to or exhibit the reply to his email referred to above. The persuasiveness of Ms Creffield's
evidence that she did not have sufficient time to provide more detail on the issue of fire safety
arrangements is somewhat undermined when this point is taken into account.

111. There is then a “Fire Risk Assessment and Action Plan” relating to Block 1 exhibited to Ms Creffield's
first witness statement although she does not refer to or explain this document. It records a fire risk
assessment in relation to Block 1 which was apparently carried out on 5 March 2021 although it is not clear
by whom. This assesses the position by reference to a matrix of the likelihood, and likely severity of, a fire,
and scores the risk as 9, thus placing it in the range 8 to 12 which corresponds with “High Risk-Implement
_interim measures immediately and for controls within three months” (emphasis added). The rubric explains_
that _“High” means_ _“Large scale damage to property. Complete evacuation required. Occupants required_
_hospitalisation.” The next step up is 15-25 “Extreme Risk-Cease use of area until additional controls have_
_been applied”._

112. My conclusion, having assessed these materials in the context of the evidence as a whole, is that
there is no reason to suppose that the position in terms of fire safety was any better between the Barracks
coming into use on 22 September and 24 November 2020, than the CPFSI found it to be on the latter date.
Furthermore, I have not been shown any specific evidence of any steps being taken to address the
concerns in the 30 November 2020 report prior to the fire of 29 January 2021, although I accept that that
does not necessarily mean that none at all were taken. There is evidence that steps were taken after the
fire, and that progress had been made by 25 February 2021, as I have pointed out, and it was certainly
contemplated that further steps would be taken thereafter although, again, I have little evidence about this.

113. In terms of the legal issues, it seems to me that it is reasonable to proceed on the basis that,
whatever improvements may have been made after 24 November 2020, from their arrival at the Barracks
until at least that date the accommodation provided to the relevant Claimants exposed them to an
unacceptable fire risk. In terms of the magnitude of that risk, Ms Giovannetti rightly points out that the
CPFSI did not consider that it was sufficiently serious or immediate to warrant an immediate enforcement
notice but is it is clear that they expected immediate action.

114. Although Ms Giovannetti says that the CPFSI appears to have monitored the situation – and by 2
March 2020 had been to the site on “various occasions” and did not at any point feel it necessary to issue
such a notice - I have very little evidence about this. I infer from the evidence that I have, including the
statement in the CPFSI's 2 March 2021 email, that “work is progressing and finally they seem to be taking
_the Fire Safety more seriously_ _After the fire more resources have been thrown at the site_ _” from the_


-----

intervening) [2021] EWHC 1489 (Admin)

fact that there is no evidence that the sleeping arrangements in the dormitories were altered until the end
of January 2021 when numbers of residents were reduced, and from the failure to take basic steps such as
the carrying out of a fire drill immediately, that the likelihood is that the position in terms of fire safety did
not significantly alter from the 30 November CPFSI report until after the 29 January 2021 fire. It then began
to be addressed more vigorously as a reaction to what had happened and to growing public concerns
about the situation in the Barracks. The position described in the CPFSI report of 30 November 2020
therefore represented the state of affairs for the whole, or virtually the whole, of the Claimants' stays at the
Barracks.

**The Covid-19 outbreak in mid-January 2021**

115. In early January 2021 a group of residents began to sleep outside, apparently as a protest about
conditions and the risk of Covid-19 infection. The Claimants also say that there was a hunger strike. Two of
them, M and F, say they were involved in these activities.

116. On 15 January 2021, six residents tested positive for Covid-19. At this stage there were 381
residents on site. A letter was written to all residents which told them that they should not leave the site
under any circumstances and this was reiterated to them orally through interpreters where necessary (“the
15 January letter”). I return to this letter when I consider Ground 4, the issue of detention, below.

117. On 17 January 2021, the first mass testing of residents was carried out and this produced 123
positive results out of 234 tests. On 19 January 2021, 289 tests produced positive results for 128 residents
and 9 staff. The staff included 5 of the cleaners and 2 catering staff. There were 100 residents who tested
negative and other results were inconclusive or awaited. 92 residents were refusing to take the test.

118. An Outbreak Control Group (“OCG”) led by Kent County Council Public Health Team was set up and
there was an increase in the number of multi-agency forum meetings to manage the situation. These
meetings were led by Mr Roy Millard, Head of Partnership at the South East Strategic Partnership for
Migration (“SESPM”) and the forum included representatives of Kent Police, NHS England and local health
care providers. A number of the members of these bodies were very critical of the way in which the known
risk of Covid-19 infection had been managed or, rather, not managed. There are notes of some of these
meetings in the bundle and it is not necessary to summarise them in any detail, but key points which
emerge are as follows:

i) Gail Locock, Director of Infection Prevention and Control at Kent and Medway Clinical Commissioning
Group carried out an inspection and prepared a report dated 20 January 2021. At a SESPM meeting that
day she expressed the view that the outbreak had been “inevitable” given the number of people, their living
conditions and the arrangements on site, and given the lack of any effective measures on site to address
the risk of infection. No one appears to have disagreed with her and nor did any of the Defendant's
witnesses or Ms Giovannetti challenge this view, as I have noted.

ii) There were residents who had tested positive in every single block and too many people in each block
to allow adequate social distancing and prevent the spread of infection. In addition to this, there was not
enough space on site to allow people to move around safely. “Nowhere on the site [was] Covid secure”.

iii) There was a number of clinically vulnerable people on site. The age range of the residents was 19 to
over 60 but there were also people who were clinically vulnerable because of particular conditions. There
are references to cases of diabetes, leukaemia and tuberculosis in the documents, but I do not have any
detail about this. As at 20 January 2021 it was estimated by the nurse that there were 10-20 who were in
the clinically vulnerable group, but he was in the process of compiling a list. An email from Dr Mah, a local
GP, later that day, suggests that there were 10 with health conditions.

iv) There were high levels of anxiety amongst residents which were exacerbated by the fact that they were
not permitted to leave site.

v) Given the numbers on site and the numbers of infections, the only way forward was to transfer
substantial numbers of residents out of the Barracks.


-----

intervening) [2021] EWHC 1489 (Admin)

119. The decision was therefore taken that it would be necessary to move groups of residents out. The
evidence on how this was approached is, again, not entirely clear but it appears that those who were
clinically vulnerable and who had tested negative were transferred to hotels between 23 and 28 January
2020. There were around 103 in total moved out of the Barracks in this period. This left a group of around
270 who had either tested positive or refused to be tested. Dr Mah's email set out a proposal to move
various groups out and suggested that the group left behind may be “still too big to care for safely at the
_barracks?”. Whether in the light of this or otherwise, there were then further reductions in the population of_
the Barracks so that it stood at 103 by mid – February 2021.

120. All communal facilities were closed, and, on 28 January 2021, some residents were required by letter
to move into reconfigured groups and to continue to self-isolate in these new bubbles. The period of selfisolation was extended for 10 days. I return to this letter in relation to Ground 4, below.

**Fire on 29 January 2021**

121. On 29 January 2021 there was major disturbance in the Barracks involving a small number of
residents, apparently sparked by being told that the instruction not to leave the Barracks was to be
extended for a further 10 days. A fire was deliberately started in Block 7 and the kitchens were put out of
use. Although no one was injured, this appears to have made conditions in the Barracks significantly
worse. The residents in blocks 6-8 were apparently displaced and around 60 had to find somewhere else in
the Barracks to sleep. It also appears that there were tensions between residents and HMCIP reports
evidence of abuse, threats, intimidation and assault. NB describes the Barracks as feeling “like a warzone”
at this point, with security guards and riot police keeping order.

122. As noted above, on 7 February 2021 Ms Creffield took on responsibility for the Barracks in the
context of the management of what had been designated a critical incident by the Defendant. There were
then various inspections and visits to the Barracks including the HMCIP inspection and Ms Creffield's visit
on 26 February 2021. She prepared a document which set out improvements which required to be made
and gave various other instructions as to what was to be done, and I accept that there had been some
improvements in conditions at the time of the hearing before me and that the work was on going in this
regard. Whether these improvements will address the fundamental issues in relation to the use of the
Barracks to accommodate asylum seekers remains to be seen.

123. On 6 March 2021, the Covid-19 outbreak was declared closed as there had been no reported new
infections on site in the preceding 28 days.

124. As at 15 March 2021, there were 42 residents on site. I am told that the site was emptied at the
beginning of April but that, in the week of 9 April 2021, more asylum seekers were transferred in. The
position of the Defendant, as set out in her Part 18 Information dated 12 April 2021 is that: _“The SSHD_
_proposes to make such use of the site at Napier as is lawful and appropriate in light of the evolving_
_circumstances”._

125. As Ms Creffield herself very properly points out in her second witness statement, however, the view
of Gail Locock is that it is not possible to provide a Covid safe environment at the Barracks if dormitory
style accommodation is to be used. Similarly, Ms Sarah Vaux, Director of Nursing, Quality and Medicines
Optimisation at NHS Medway Clinical Commissioning Group also considers that another outbreak would
be inevitable if significant numbers were to be housed there in dormitories. As Ms Creffield acknowledges:

_“[Ms Vaux] articulates a concern shared by a number of other stakeholders that the site can never be made_
_Covid secure”._

**GROUND 1        .**

126. This Ground has two main limbs. The Claimants' contentions are that:

i) The accommodation at the Barracks did not comply with section 96 IAA 1999 read with the RCD in that
it fell below the minimum standard required by the RCD. They submit that this is a matter for the Court but,


-----

intervening) [2021] EWHC 1489 (Admin)

alternatively, insofar as any of the relevant matters were within the discretion of the Defendant she acted
irrationally. Allied to this argument is the Claimants' contention that the accommodation in the Barracks
breached the AASSC between the Defendant and Clearsprings which, the Claimants argue, sets out what
the Defendant considers to be adequate; and/or

ii) The accommodation at the Barracks breached the Government's representations that it complied with
the AASSC, and therefore the Claimants' legitimate expectations in this regard.

**Legal framework        .**

[The IAA 1999.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)

127. Section 95 IAA 1999 provides, so far as material, as follows:

_“95. — Persons for whom support may be provided._

_(1) The Secretary of State may provide, or arrange for the provision of, support for—_

_(a) asylum-seekers, or_

_(b) dependants of asylum-seekers,_

_who appear to the Secretary of State to be destitute or to be likely to become destitute within such period_
_as may be prescribed.”_

_(2) …_

_(3) For the purposes of this section, a person is destitute if—_

_(a) he does not have adequate accommodation or any means of obtaining it (whether or not his other_
_essential living needs are met); or_

_(b) he has adequate accommodation or the means of obtaining it, but cannot meet his other essential living_
_needs…. (emphasis added)_

[128. Pursuant to section 95(5)(a), Regulation 8 Asylum Support Regulations (SI 2000/704) prescribes](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-99F0-TX08-H0Y1-00000-00&context=1519360)
matters to which the Secretary of State must have regard when considering whether the existing
accommodation of a person applying for accommodation under section 95 is adequate. Under Regulation
8(3) these matters include:

_“(a) whether it would be reasonable for the person to continue to occupy the accommodation;_

_…. (c) whether the accommodation is provided under section 98 of the Act, or otherwise on an emergency_
_basis, only while the claim for asylum support is being determined…”_

129. Section 96(1) IAA 1999 provides, so far as material:

_“96. — Ways in which support may be provided._

_(1) Support may be provided under section 95—_

_(a) by providing accommodation appearing to the Secretary of State to be adequate for the needs of the_
_supported person and his dependants (if any);_

_(b) by providing what appear to the Secretary of State to be essential living needs of the supported person_
_and his dependants (if any); …._

_(2) If the Secretary of State considers that the circumstances of a particular case are exceptional, he may_
_provide support under section 95 in such other ways as he considers necessary to enable the supported_
_person and his dependants (if any) to be supported.”_

130. Section 98 provides for the provision of temporary support to asylum seekers pending a decision
under section 95 where it appears to the Secretary of State that they may be destitute.


-----

intervening) [2021] EWHC 1489 (Admin)

The Reception Directive.

131. The RCD of 27 January 2003 laid down certain minimum standards for the reception of asylum
seekers. This Directive remains relevant notwithstanding the United Kingdom's withdrawal from the
European Union for reasons I will come to.

132. Recital (5) to the RCD states:

_“This Directive respects the fundamental rights and observes the principles recognised in particular by the_
_Charter of Fundamental Rights of the European Union. In particular, this Directive seeks to ensure full_
_respect for human dignity and to promote the application of Articles 1 and 18 of the said Charter.”_
(emphasis added)

133. Recital (7) notes:

_“Minimum standards for the reception of asylum seekers that will normally suffice to ensure them a_
_dignified standard of living and comparable living conditions in all Member States should be laid down.”_
(emphasis added)

134. Under the heading “Purpose” Article 1 RCD states:

_“The purpose of this Directive is to lay down minimum standards for the reception of asylum seekers in_
_Member States”_

135. Under Article 2(f) “material reception conditions” are defined as follows:

_“'material reception conditions' shall mean the reception conditions that include housing, food and clothing,_
_provided in kind, or as financial allowances or in vouchers, and a daily expenses allowance;”_ (emphasis
added)

136. Article 13 sets out “General rules on material reception conditions and health care”. Articles 13.1 and
13.2 provide as follows:

_“1. Member States shall ensure that material reception conditions are available to applicants when they_
_make their application for asylum._

_2. Member States shall make provisions on material reception conditions to ensure a standard of living_
_adequate for the health of applicants and capable of ensuring their subsistence. Member States shall_
_ensure that that standard of living is met in the specific situation of persons who have special needs, in_
_accordance with Article 17, as well as in relation to the situation of persons who are in detention.”_
(emphasis added)

137. Article 17 provides, as a “General principle” as follows:

_“1. Member States shall take into account the specific situation of vulnerable persons such as minors,_
_unaccompanied minors, disabled people, elderly people, pregnant women, single parents with minor_
_children and persons who have been subjected to torture, rape or other serious forms of psychological,_
_physical or sexual violence, in the national legislation implementing the provisions of Chapter II relating to_
_material reception conditions and health care._

_2. Paragraph 1 shall apply only to persons found to have special needs after an individual evaluation of_
_their situation.” (emphasis added)_

138. In the particular case of the provision of material reception conditions in the form of housing, Article
14 provides, under the heading “Modalities for material reception conditions”:

_“1. Where housing is provided in kind, it should take one or a combination of the following forms:_

_(a) premises used for the purpose of housing applicants during the examination of an application for_
_asylum lodged at the border;_

_(b) accommodation centres which guarantee an adequate standard of living;_


-----

intervening) [2021] EWHC 1489 (Admin)

_(c) private houses, flats, hotels or other premises adapted for housing applicants……_

_5. Persons working in accommodation centres shall be adequately trained and shall be bound by the_
_confidentiality principle as defined in the national law in relation to any information they obtain in the_
_course”. (emphasis added)_

139. It is on the basis of Article 14.1 (b) that the Claimants concede that in principle it was open to the
Defendant to provide accommodation in the form of an accommodation centre rather than individualised
accommodation.

140. Article 15 of the RCD provides, under the heading “Health care”:

_“1. Member States shall ensure that applicants receive the necessary health care which shall include, at_
_least, emergency care and essential treatment of illness._

_2. Member States shall provide necessary medical or other assistance to applicants who have special_
_needs.”_

141. I also note Article 14.8:

_“8. Member States may exceptionally set modalities for material reception conditions different from those_
_provided for in this Article, for a reasonable period which shall be as short as possible, when:_

_— an initial assessment of the specific needs of the applicant is required,_

_— material reception conditions, as provided for in this Article, are not available in a certain geographical_
_area,_

_— housing capacities normally available are temporarily exhausted,_

_— the asylum seeker is in detention or confined to border posts._

_These different conditions shall cover in any case basic needs.” (emphasis added)_

142. Mr Hickman relied on this provision to submit that the standard of adequacy contemplated by the
RCD is therefore higher than merely covering basic needs. For her part, Ms Giovannetti confirmed that she
did not rely on Article 14.8.

The Reception Conditions Regulations.

143. In the United Kingdom the RCD was implemented in part through existing health, education and
community care provisions, with amendments to policy, and in part through the Asylum Seekers
[(Reception Conditions) Regulations 2005 SI 2005/7 (“the 2005 Regulations”). By Regulation 5, the powers](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-MPB0-TX08-H185-00000-00&context=1519360)
to provide support under sections 95 and 98 became duties if the asylum seeker is considered to be
eligible and, in the case of section 95 applies, for support. Reflecting Article 17 RCD, Regulation 4
provides:

**_4.— Provisions for persons with special needs_**

_(1) This regulation applies to an asylum seeker or the family member of an asylum seeker who is a_
_vulnerable person._

_(2) When the Secretary of State is providing support or considering whether to provide support under_
_section 95 or 98 of the 1999 Act to an asylum seeker or his family member who is a vulnerable person, he_
_shall take into account the special needs of that asylum seeker or his family member._

_(3) A vulnerable person is–_

_(a) a minor;_

_(b) a disabled person;_

_(c) an elderly person;_


-----

intervening) [2021] EWHC 1489 (Admin)

_(d) a pregnant woman;_

_(e) a lone parent with a minor child; or_

_(f) a person who has been subjected to torture, rape or other serious forms of psychological, physical or_
_sexual violence;_

_who has had an individual evaluation of his situation that confirms he has special needs._

_(4) Nothing in this regulation obliges the Secretary of State to carry out or arrange for the carrying out of an_
_individual evaluation of a vulnerable person's situation to determine whether he has special needs.”_
(emphasis added)

144. Regulations 4(3) and (4) were intended to reflect Article 17.2 RCD and they are relevant to Ground 2.

[The standard of review in relation to section 96 IAA 1999.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1MX-00000-00&context=1519360)

145. There is an issue as to the standard of review in relation to section 96 IAA 1999, which is essentially
as follows. The parties agree that, until 31 December 2020, under section 96(1)(b) provision for the
essential living needs of the supported person other than accommodation could not fall below the minimum
required by the RCD. If it did, this would be unlawful and irrational notwithstanding that the section
specifically entitles the supported person only to such support as appears to the Secretary of State to be
essential. This was the effect of the decision of Popplewell J (as he then was) in **R (Refugee Action) v**
**Secretary of State for the Home Department** _[2014] EWHC 1033 (Admin) (“the Refugee Action case”)._
Ms Giovannetti submits, however, that this principle has been recognised in relation to section 96(1)(b)
only and/or that there is no basis for holding that the approach in the Refugee Action case is applicable to
section 96(1)(a) given the withdrawal of the United Kingdom from the European Union, and given the terms
[of the European Union (Withdrawal) Act 2018 (“the EUWA”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SNC-4N71-DYCN-C32Y-00000-00&context=1519360)

146. In the Refugee Action case, the complaint was that the Secretary of State had decided that the level
of support provided in cash to meet the essential living needs of asylum seekers for the financial year
2013/2014 should remain frozen at the rates which had applied since 2011. The relevant ground of
challenge for present purposes was that this decision was incompatible with the RCD and irrational. The
Secretary of State was said not to have conducted a sufficient investigation into the level of support
necessary to meet essential living needs, and to have failed to take into account relevant essential needs.

147. At [85] Popplewell J said:

_“…. The Marleasing principle requires national legislation to be interpreted in a manner which is consistent_
_with and gives effect to EU Directives. The content of the duty imposed upon the Secretary of State, by a_
_combination of section 95 of the 1999 Act and Regulation 5 of the AS Regulations 2005, is informed by the_
_European law obligations imposed by the Reception Directive. Provision for essential living needs must_
_therefore be interpreted as including, as a minimum, provision of the minimum reception conditions_
_required by the Directive. The minimum standard of living for which provision is required by the Directive is_
_not a matter for the Secretary of State's subjective judgment but an objective standard. To this extent it is_
_not open to her to treat essential living needs as having a lesser content than the objective minimum_
_required by the Directive. Section 95 and 96 must be interpreted in such a way as to place such a view_
_outside the range of reasonable judgments in order to be compatible with and give effect to the Reception_
_Directive. If the Secretary of State were to make a judgment which treated essential living needs as_
_something less than the minimum standard of living required by the Directive, it would be both irrational_
_and unlawful.” (emphasis added)_

148. At [87] he held that:

_“…the Reception Directive requires that:_

_(1) asylum support be set at a level which promotes, protects and ensures full respect for human dignity,_
_so as to ensure a dignified standard of living: Recitals (5) and (7) and Article 1 of the Charter;_


-----

intervening) [2021] EWHC 1489 (Admin)

_(2) ….;_

_(3) asylum support be provided which is adequate to ensure asylum seekers can maintain an adequate_
_standard of health and meet their subsistence needs: Article 13.1 of the Directive; and_

_(4) the special needs of vulnerable people are provided for so as to meet            this minimum_
_standard of living: Article 13.2 and Article 17 of the Directive.”_

149. At [88] he said:

_“88. These requirements of the Directive contain the minimum content of the essential living needs criterion_
_under the 1999 Act. The Secretary of State must make provision under s.95 and 96 which is sufficient to_
_meet this minimum standard of living, if and to the extent that such provision is not otherwise being made_
_by another organ of the State. In assessing whether the levels of asylum support allow asylum seekers to_
_maintain this standard of living, the length of time which they spend on asylum support, and the uncertainty_
_of that period, is potentially relevant. It is one thing to spend a short period coping with severe poverty,_
_another to have to cope with it for an uncertain period of years….”_

150. At [91] he said:

_“91 An assessment of what is essential and the extent to which something is a need involves a value_
_judgement. The function of making that value judgement is conferred by Parliament on the elected_
_government, in the person of the Secretary of State. Subject to compliance with the minimum content_
_required by the Directive, her judgment on whether goods or facilities constitute a need which is essential_
_is only open to review on the high threshold of Wednesbury unreasonableness or other established public_
_law grounds.” (emphasis added)_

151. It was therefore permissible for the court itself to adjudicate, against the standards set in the RCD,
whether a given category of need was necessarily an essential need. Indeed, at [117] Popplewell J held
that in setting allowances for asylum seekers the Secretary of State had failed to take into account certain
categories of essential need including essential household goods such as washing powder, cleaning
materials and disinfectant; nappies, formula milk and other special requirements of new mothers, babies
and very young children and non-prescription medication. She had also failed to consider whether other
categories, such as travel by public transport to meet legal advisers were essential living needs.

152. However, Popplewell J did not then set the amount which should have been paid to asylum seekers,
as this was a matter for the Secretary of State. As he said at paragraph 3:

_“It is worth emphasising at the outset that the question is not what the Court considers to be the_
_appropriate amount to meet the essential living needs of asylum seekers. That judgment does not lie with_
_the unelected judges, but is vested by Parliament in the elected government of the day. The latter's_
_decision can only be challenged on well recognised public law principles.”_

153. The approach of Popplewell J was endorsed and adopted by the Court of Appeal in R (JK (Burundi))
**v SSHD [2017] 1 WLR 4567, a case which concerned the quantification of cash payments to meet the**
essential needs of the children of asylum seekers: see [86]-[88] in particular. The Court of Appeal also held
that the standard to be applied was one of subsistence rather than the welfare of the child or what is
desirable. For example, at [59] Gross LJ said this:

_[“59 Thus, the aim of section 95 of the IAA 1999 is averting destitution. So too, all of sections 95, 96 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61R0-TWPY-Y0HB-00000-00&context=1519360)_
_122 speak of the provision of “essential living needs”. The language of the RCD is likewise plain: it is to_
_ensure “minimum standards” for the reception of asylum seekers that will “normally suffice to ensure them_
_a dignified standard of living” and “adequate for the health of claimants and capable of ensuring their_
_subsistence”: see recital (7) of the Preamble, article 1 and article 13(2). ……. Accordingly, at least as a_
_matter of language, the standard set is one of subsistence rather than anything more.”_

154. Turning to Ms Giovannetti's argument, it is true that the present case concerns accommodation under
section 96(1)(a) IAA 1999, but this seems to me to be a distinction without a difference and, indeed, the


-----

intervening) [2021] EWHC 1489 (Admin)

point was not one which she developed orally. The principle in the **Refugee Action case is equally**
applicable to section 96(1)(a) given that housing is expressly included in the definition of _“material_
_reception conditions” under Article 2(f) of the RCD, given that section 96(1) as a whole is concerned with_
_“support” – accommodation and provision for essential needs are examples of such support - and given_
that section 96(1) represents the United Kingdom's implementation of the RCD. Indeed, as will have been
noted from the passages from the **Refugee Action case which I have cited at paragraphs [147]-[152]**
above, the principle was said by Popplewell J to apply to sections 95 and 96, and to “support”, rather than
to support under section 96(1)(b) specifically. There is also no sensible reason why the principle would
apply to one type of support only given that the RCD is concerned with material reception conditions
generally, that Articles 13 and 17 expressly purport to lay down general rules applicable to material
reception conditions and that these are expressly stated, by Article 2(f), to include housing.

155. It is also true, as Ms Giovannetti submits, that there may be an analogy to be drawn between the
amount of an allowance in respect of essential needs and the quality of accommodation, having accepted
that accommodation is an essential need. However, at the hearing it appeared to be common ground that
insofar as the RCD applied to section 96(1)(b) the scope of the Defendant's discretion was circumscribed
in that she could not take the view that accommodation which fell below the minimum standard required by
the RCD, in terms of its quality, was nevertheless adequate. That minimum standard was as stated in
Article 13 i.e. it had to “ensure a standard of living adequate for the health of the applicant and be capable
_of ensuring their subsistence”._

156. Ms Giovannetti appeared to accept that the “health of the applicant” referred to their mental as well
as their physical health. She also accepted that the physical safety of the applicant would be an aspect of
_“health” when I asked her about the issue of fire risk, to which I will return._

157. It was also common ground that, by reason of section 1A of the EUWA the RCD continued to apply
until 31 December 2020, and therefore so did the analysis in Refugee Action and JK (Burundi). But Ms
Giovannetti submitted that thereafter it ceased to do so. This issue turns on the interpretation of sections
4(1) and 4(2)(b) EUWA which provide as follows:

_“4. Saving for rights etc. under section 2(1) of the ECA_

_(1) Any rights, powers, liabilities, obligations, restrictions, remedies and procedures which, immediately_
_before [IP completion day] —_

_(a) are recognised and available in domestic law by virtue of section 2(1) of the European Communities Act_
_1972, and_

_(b) are enforced, allowed and followed accordingly,_

_continue on and after [IP completion day] to be recognised and available in domestic law (and to be_
_enforced, allowed and followed accordingly)._

_(2) Subsection (1) does not apply to any rights, powers, liabilities, obligations, restrictions, remedies or_
_procedures so far as they— …_

_(b) arise under an EU directive (including as applied by the EEA agreement) and are not of a kind_
_recognised by the European Court or any court or tribunal in the United Kingdom in a case decided before_

_[IP completion day] (whether or not as an essential part of the decision in the case).” (emphasis added)_

158. Section 4(2) therefore makes clear that section 4(1) does not apply to rights and obligations which
arise under EU directives and are not _“of a kind” which had previously been recognised by any court or_
tribunal in the United Kingdom. Ms Giovannetti submits that there is no authority which recognises any
specific right derived from the RCD in respect of the adequacy of accommodation provided under section
96(1)(a) IAA 1999. The right contended for in the present case is not “of a kind” which was recognised in
the **Refugee Action case. I reject this argument for the reasons which I have given at paragraph [154]**
above. The right which was recognised in the **Refugee Action case was to** _“support” under section 95_


-----

intervening) [2021] EWHC 1489 (Admin)

which met the minimum requirements of the RCD whether that support be in the form of accommodation or
other provision for other essential needs, and whether in cash or in kind.

Other points on the construction of section 96(1)(a)

159. Ms Giovannetti also submitted that the fact that the accommodation is temporary is relevant to the
question whether it is adequate in the sense that what may not be adequate on a long-term basis may be
adequate on a temporary or short term basis. In this regard she relied on section 97 IAA 1999, **R (A) v**
**National Asylum Support Service [2004] 1 WLR 752CA [54] and [59] and, more generally, Ali & Others**
**v Birmingham City Council [2009] 1 WLR 1506UKSC. This principle was not disputed by Mr Hickman.**

160. Nor, however, did it appear to be in dispute that accommodation, which was once adequate, may
cease to be adequate, whether because of changes in the circumstances of the accommodation or
changes in the needs of the occupant.

**Discussion and conclusions on the first limb of Ground 1**

161. I accept that the hurdle for the Claimants is a high one. They must show that the accommodation at
the Barracks failed to meet the minimum standard required by the RCD i.e. it failed “to ensure a standard
_of living adequate for the health of [the Claimants] and capable of ensuring their subsistence” and/or that_
insofar as the accommodation appeared to the Defendant to be adequate for their needs, her view was
irrational. On either argument the standard of “adequacy” is a low one.

162. Having said that, a certain amount is conceded by the Defendant. In particular, she has accepted that
the accommodation at the Barracks is not suitable for asylum seekers who fail the tests in her suitability
criteria discussed in relation to Ground 2 below, i.e. who have vulnerabilities related to their history and/or
their physical or mental health. She has also accepted that, even for those who do not have such
vulnerabilities, the Barracks are not suitable for _“long term” accommodation although she does not say,_
specifically, what that means. Moreover, as Mr Hickman has pointed out, none of the Defendant's
witnesses has actually given evidence in their statements that the Defendant or they, or anyone else,
consider or considered the accommodation at the Barracks to have been adequate for the needs of any of
the Claimants. On the contrary, all six were moved out of the Barracks after legal challenges which were
made on the basis that the Barracks were unsuitable for them, albeit an order of the court was required in
three of these cases.

163. It seems to me that an important starting point in assessing the arguments is that the Claimants are
not supposed to be detained. What is at issue here is accommodation in which they were supposed to live
voluntarily pending a determination of their applications for asylum. When this is considered, a decision
that accommodation in a detention-like setting - a site enclosed by a perimeter fence topped with barbed
wire, access to which is through padlocked gates guarded by uniformed security personnel - will be
adequate for their needs, begins to look questionable.

164. The concern increases when one adds the living conditions in the Barracks into the picture. The fact
that they are basic and run down is less than ideal, but I accept that, because the standard is one of
adequacy, this of itself would not be sufficient for the accommodation necessarily to fall below the required
standard. The same is true of the complaint that the bathroom facilities were either shared and lacking in
privacy or cold in cold weather. It would also be true about the standard of cleanliness given that this was
capable of being improved. But it is of particular concern that there were fairly large numbers living in the
dormitories. They were overcrowded when the question of risk of Covid-19 infection is taken into account,
and the partitioning arrangements meant that they were overcrowded in terms of the levels of noise and
the lack of privacy. The descriptions of the dormitories in the evidence, which also refer to the lack of
ventilation and centralised strip lighting, show that it is hardly surprising that sleep was disturbed and that
the mental health of some of the residents was undermined. This has a direct bearing on the question of
the adequacy of the accommodation for the health and the needs of the Claimants given their
vulnerabilities.


-----

intervening) [2021] EWHC 1489 (Admin)

165. Subject to the circumstances of the particular individual, and subject to the questions of Covid and
fire risk being satisfactorily addressed, these concerns might not be sufficient, in themselves, for an asylum
seeker to succeed if their stay was only to be a short one and they were reliably informed that this was the
case, so that they had the comfort of knowing that their stay was finite. But, here, Ms Giovannetti accepted
that the Barracks were being used pursuant to section 95 IAA 1999 rather than purely as temporary
accommodation pursuant to section 98, pending a section 95 decision.

166. The Defendant's case is that, as a matter of fact, the intention was that the residents would be moved
to other section 95 accommodation whilst they awaited the outcome of their applications for asylum. But I
was not provided with evidence that it was part of the Defendant's decision in September 2020 that there
was any particular limit to how long a resident could be accommodated at the Barracks, nor of any system
for moving residents out after they had been there for a particular period of time, nor of any time limit being
placed on the stay of any of the Claimants in the light of their particular circumstances. And, of course,
although they were told that they would be there for shorter periods, all bar one of the Claimants were
accommodated there for at least 4 months. The findings of HMCIP suggest that this was typical, and that
the residents which they spoke to had been there for longer. There is also no evidence of any specific
decision or intention to transfer the Claimants out until lawyers intervened and argued that the Barracks
were unsuitable for them. Realistically, given the “very clear steer” from Ministers not to make use of hotel
accommodation, and given the levels of demand for accommodation to which Ms Chittenden refers, once a
person was transferred into the Barracks they were likely to be there for a matter of months rather than
days or even weeks, all other things being equal.

167. As to other matters which are relevant considerations in relation to the issue of adequacy, obviously
the circumstances of the individual Claimants matter given that the standard is measured against their
needs. Here, the likely effect of the arrangements at the Barracks on the mental health of the Claimants
was highly material. Given the experiences of many asylum seekers, and particularly those who had
travelled here over land and in small boats, as many of the asylum seekers who were transferred to the
Barracks had, the likelihood was that they would be more vulnerable in terms of their mental health, and
therefore more likely to be undermined by the conditions there. I deal with this topic in greater detail in
relation to Ground 2 but, even those who were transferred there after a careful and accurate application of
the Defendant's suitability assessment criteria were potentially at greater risk in this regard. In the case of
the Claimants, as I have noted, there is evidence that they had been tortured and/or trafficked, that they
had mental health issues and that they were therefore more susceptible to their mental health being
undermined by conditions in the Barracks, as indeed happened on the evidence. Whilst no formal
concession has been made that the Claimants were moved out of the Barracks because it was accepted
that they were unsuitable for them and whilst, of course, they may merely have become unsuitable during
their stay there, it is striking that all six were moved out after interventions by lawyers and/or by the court.

168. In addition to the likely effect of the accommodation at the Barracks on the mental health of the
residents, its likely effect on their physical health is relevant. Here, in my view the fact that the decision to
make use of the Barracks entailed failing to apply fundamental aspects of the advice of PHE – not to use
dormitory style accommodation but, if they did, to keep numbers down to six per dormitory which would
then form a bubble – meant that the Defendant failed to ensure _“a standard of living adequate for the_
_health of [the Claimants]” whether the point is taken in isolation or cumulatively with the other features of_
the accommodation at the Barracks which I have summarised above. It was also irrational, in itself, to
depart from the advice of the government body charged with providing advice to the public on Covid safety
in such a fundamental way without good reason, and to send the Claimants to the Barracks when the
measures which the Defendant herself regarded as appropriate – e.g. transferring asylum seekers from
quarantine and in bubbles - were not in place. As I have said, the Defendant has not established that a
comparable approach was taken for MOD personnel but, if it was, I would also find that unacceptable.

169. Ms Giovannetti points out that there were no deaths from Covid-19 in the Barracks, and that there is
no evidence of hospitalisations, but this is self-evidently an argument based on hindsight. The effect of the
Defendant's decision was that it was virtually inevitable that large numbers of residents would contract


-----

intervening) [2021] EWHC 1489 (Admin)

Covid-19, a disease which was capable of causing hospitalisation and long-term harm and/or death. There
is no evidence of her calculating the degree of risk to residents in relation to this issue and then deciding
that it was low enough to be acceptable. Moreover, the issue is not merely one of physical health. As noted
above, there is evidence that fear of contracting Covid-19, given the cramped conditions, was causing
anxiety amongst residents.

170. The position is _a fortiori when one adds the evidence about the fire risk in relation to the_
arrangements at the Barracks. Again, this is of central relevance to the question of adequacy for the health
of the residents. Again, it does not appear that the question of fire safety was considered in relation to the
proposed numbers of residents and the way in which they would be accommodated: e.g., in spaces divided
by wooden partitioning. Again, this point in itself seems to me to mean that the accommodation did not
comply with the minimum standards required by the RCD and/or that it would be irrational to decide that
the accommodation was adequate for the Claimants' needs.

171. Whether on the basis of the issues of Covid or fire safety taken in isolation, or looking at the
cumulative effect of the decision making about, and the conditions in, the Barracks, I do not accept that the
accommodation there ensured a standard of living which was adequate for the health of the Claimants.
Insofar as the Defendant considered that the accommodation was adequate for their needs, that view was
irrational. The Defendant's proposition has to be that she met the minimum standards of the RCD and
reached a rational view that the Barracks were adequate despite the Claimants' heightened vulnerability as
asylum seekers which subsequently led to them being transferred out, despite the fact that the Barracks
were reminiscent of a detention centre, despite the living conditions, which were basic at best, and the
number of others who were to be resident there, despite the fact that they were likely to stay there for
months, and despite the fact that they would be running risks of Covid-19 infection and death or injury from
fire which the PHE and CPFSI respectively regarded as unacceptable. That is not a proposition which I can
accept.

172. I emphasise that my view is based on the conditions whilst the Claimants were resident at the
Barracks, albeit I have considered a wider evidential timeframe for the purposes of reaching conclusions
about this. Mr Hickman invited me to rule on the then current position at the time of hearing in mid-April
and/or to rule that the Barracks could never be used to accommodate asylum seekers. I decline to do so.
Even if it were appropriate to adopt a more wide ranging approach, which I do not accept, the
circumstances of the particular asylum seeker are relevant, as I have pointed out, and much depends on
the conditions at the time when they are or were there, and for how long they were there. I have not been
given a sufficiently reliable evidential basis to form firm views about the present position or to address
hypothetical cases in which, say, small numbers were accommodated for short periods, having been
carefully screened, and in which Covid and other risks were managed to the satisfaction of the relevant
bodies.

173. I also note that my conclusions have been reached without relying on Mr Hickman's arguments that
the arrangements in the Barracks fell below the standards required of Clearsprings by the AASSC. The
flaws in his argument that these standards represent the Defendant's view of what is “adequate”, and that
any decision to apply lower standards therefore necessarily rendered any decision that the accommodation
was adequate irrational, are, firstly, that there does not appear to have been a decision to apply lower
standards at the Barracks: the fact that the contract imposed the relevant requirements on Clearsprings
indicates that the decision was that those standards were required to be met. Secondly, the contractual
standards do not necessarily represent what the Defendant regards as the minimum required by law to
achieve the standard of adequacy. Thirdly, the arguments do not add anything given my conclusions above
and in relation to the legitimate expectation argument below.

**The legitimate expectation argument**

174. This argument was added, with the permission of Chamberlain J, by way of an amendment to the
Statement of Facts and Grounds. Here Mr Hickman argues that:


-----

intervening) [2021] EWHC 1489 (Admin)

i) The Defendant has made various statements that the accommodation is in line with the specifications in
the AASSC and this gave rise to a substantive legitimate expectation on the part of the Claimants that they
would comply with those specifications.

ii) There has been a breach of that legitimate expectation in that the standards of the accommodation fell
below the requirements of the AASSC.

175. The statements relied on by Mr Hickman include, for example:

i) A statement in the UKVI _“Contingency Asylum Accommodation, Ministry of Defence Sites Factsheet”,_
dated October 2020, that: “The accommodation is safe, habitable, fit for purpose and correctly equipped in
_line with existing asylum accommodation standards contractual requirements.”_

ii) A statement in a Contingency Asylum Accommodation Stakeholder briefing pack, dated January 2021,
in response to the question: _“Is the accommodation suitable?” that:_ _“The accommodation, which until_
_recently was used by the MOD is safe, habitable, fit for purpose and correctly equipped in line with existing_
_asylum accommodation standards, contractual requirements and is Covid-19 secure.”_

iii) Statements by Mr Chris Philp MP to the same effect, for example in written answers on 18 December
2020, 15 January and 18 January 2021 as well as in letters dated 22 and 23 December 2020.

176. These were not promises to the Claimants or any other asylum seekers, nor statements as to how
the Defendant would act in the future. They were statements of the Defendant's position or understanding,
and they were made at a high level of generality. Nor did any of the Claimants give evidence that they were
aware of these statements or relied on them in any subjective sense. The material obligations referred to
are also obligations of the private contractor, Clearsprings. Although the section 95 duty is non delegable, I
agree with Ms Giovannetti that the Defendant cannot, and has not, promised that the contractor will never
break the contract. Another oddity with Mr Hickman's argument is that, unlike in the conventional case in
which it is said that the public body has resiled from fulfilling the expectation which it generated, the
Defendant is not seeking to resile from her statements. It remains her position that the standards at the
Barracks met the requirements of the AASSC.

177. Ms Giovannetti and Mr Manknell, at my request, put in helpful additional written submissions on this
issue, and particularly the question whether the party which relies on a given promise or statement must
have been aware of it. These submissions are dated 19 April 2021 and Mr Hickman has not sought to reply
to them. They submit, and I accept, that following the decision of the Supreme Court in **Re Finucane**

[2019] HRLR 7 the law is not settled as to whether, for there to be a substantive legitimate expectation
based on a promise or statement, the claimant must have relied on it to their detriment, but that the
balance of views is that this is not a necessary element. They submit, and I agree, that I should decide the
issue on the basis of the rationale for holding a public body to a legitimate expectation, namely that there
would otherwise be unfairness amounting to an abuse of power: e.g. **R (Bhatt Murphy, a firm) v**
**Independent Assessor** _[2008] EWCA Civ 755 [50]. On the facts, they submit, that standard is not met_
here.

178. I agree. The points which I have made above, including that there was no promise of future action,
that the Claimants were unaware of the statements on which they now rely and that the Defendant does
not seek to resile from her statements, all indicate that there is no unfairness or abuse of power in the
relevant sense. Whilst the conditions in the Barracks may have been unfair in a broad sense, no additional
unfairness to the Claimants was occasioned by the fact that the Defendant had said that they complied
with the AASSC and/or were safe, habitable, fit for purpose etc when, on the Claimants' case, they are not.

179. In addition to this, I am doubtful about a number of the breaches of the AASSC relied on by Mr
Hickman. He complains about the ratio of service users to bathrooms (Annex B 13.1) but my
understanding is that it is common ground that the contractual standard was met when the portacabin
facilities are taken into account. He submits that the AASSC prohibits the sharing of sleeping quarters in
the present circumstances, but in my view it does not. Annex C states in terms that the provider may make
such arrangements with the authority or consent of the Defendant There are other obligations such as to


-----

intervening) [2021] EWHC 1489 (Admin)

keep the common parts clean (B12.1.7) and proactively to monitor the needs of service users (Schedule 2
clause 1.2.5.2) which are, in my view, not sufficiently clear or unambiguous and devoid of relevant
qualification to found a legitimate expectation: see **R v Inland Revenue Commissioners ex parte MFK**
**Underwriting Agents Ltd [1990] 1 WLR 1545. There may well have been a breach of the obligation to**
comply with fire safety standards (B3.1.7 and B9) but, even if there were a legitimate expectation in this
regard, I am not clear how this would add anything given my overall conclusion.

**GROUND 2        .**

**Overview**

180. The essential point under this heading is that the Defendant has accepted that the Barracks are not
suitable to accommodate asylum seekers who are, in broad terms, vulnerable. For this reason, she has,
from the outset, had suitability assessment criteria which are intended to screen out those for whom the
Barracks are unsuitable. That being so, the Claimants argue, it was incumbent on her to have an effective
system for ensuring that those who were unsuitable were not accommodated there. This entailed
identifying such persons, both at the point of allocation and after an asylum seeker has been transferred.
The former required a screening process which specifically assesses the candidate's suitability for the
accommodation in the Barracks. The latter entailed having a system in place to spot those who may have
been missed at the initial screening stage or who, whilst they may initially have been suitable, had become
unsuitable through a deterioration in their physical or mental health, whether or not caused by the
conditions at the Barracks. The Claimants say that the system at both stages was inadequate and, as a
result, there were many cases which were missed at the point of transfer and whilst at the Barracks.

181. As noted above, the basis for the Claimants' alleged duty was chiefly the Tameside principle and the
PSED under section 149 Equality Act 2010 with particular reference to the question of disability, although
the free-standing claim under this provision was abandoned. Other bases were contended for in the
Claimants' skeleton argument but, in the oral submissions on behalf of the Claimants, Ms Hirst limited the
additional considerations to the duty under Article 4 ECHR, the Council of Europe Convention on Action
against Trafficking (“ECAT”) and the Anti-Trafficking Directive (2011/36/EU) to ensure early identification of
potential victims of people trafficking and to provide appropriate accommodation and support pending
determination of their claims. She also emphasised the need for the Defendant to have a system which
ensured that the accommodation did not breach Article 3 or 8 ECHR. All of these duties, she said,
combined to inform the question whether the system for the application of the suitability assessment
criteria was reasonable. Ms Hirst submitted that, whilst there was no complaint about the Defendant's
suitability assessment criteria themselves, the evidence demonstrated that they were not applied
effectively, either in deciding who should be transferred to the Barracks or once an asylum seeker was
resident there.

182. For her part, Ms Giovannetti pointed out that, regulation 4(4) of the 2005 Regulations, which is set out
at paragraph [143] above, expressly provides that there is no obligation on the Defendant to carry out an
assessment of whether a given asylum seeker has special needs. She correctly submitted that, therefore,
Regulation 4(4) itself could not provide a basis for the duty contended for by the Claimants as they had
argued in their skeleton argument. She did not dispute that the Tameside duty applied but she submitted
that the Defendant had complied with this duty. She submitted that the Defendant had had “due regard” to
the relevant considerations pursuant to section 149 Equality Act 2010 in that it had carried out an Equality
Impact Assessment and had introduced suitability criteria. Similarly, the other legal bases for the duty
contended for by the Claimants did not add anything: the measures in the present case were not the full
extent of the Defendant's measures to address the issue of people trafficking and to discharge her duties in
this regard. The accommodation at the Barracks did not breach Articles 3 and 8 ECHR but, in any event,
adequate steps had been taken to ensure that those for whom the Barracks were unsuitable were not sent
there and/or were transferred out in the event that they were unsuitable.

183. Ms Giovannetti accepted that there may have been mistakes in some cases but submitted that this
did not establish breach of the Tameside duty. She relied on R (BF (Eritrea)) v SSHD [2020] 4 WLR


-----

intervening) [2021] EWHC 1489 (Admin)

38[63] where Underhill LJ said that a published policy which said that the Defendant may treat a person
claiming to be a child as an adult if immigration officials thought that he or she very strongly looked
significantly over 18 would be unlawful if, but only if, the way that it was framed created a real risk of a
more than minimal number of children being detained: “the policy should not be held to be unlawful only
_because there are liable, as in any system which necessarily depends on the exercise of subjective_
_judgment, to be particular “aberrant” decisions—that is, individual mistakes or misjudgements made in the_
_pursuit of a proper policy”._

184. Ms Giovannetti also pointed out that the Defendant had made improvements to the way in which she
applied the suitability assessment criteria since the Barracks first came into use in September 2020.

**Legal Framework**

185. R (Balajigari) v Secretary of State for the Home Department [2019] 1 WLR 4647CA [70] contains
a useful summary of the **Tameside duty drawing on the summary provided by Haddon-Cave J in** **R**
**(Plantagenet Alliance Ltd) v Secretary of State for Justice** _[[2015] 3 All ER 261, [99] –[100]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_

_“…. First, the obligation on the decision-maker is only to take such steps to inform himself as are_
_reasonable. Secondly, subject to a Wednesbury challenge (Associated Provincial Picture Houses Ltd v_
_Wednesbury Corpn [1948] 1 KB 223), it is for the public body and not the court to decide upon the manner_
_and intensity of inquiry to be undertaken: see R (Khatun) v Newham London Borough Council [2005] QB_
_37, para 35 (Laws LJ). Thirdly, the court should not intervene merely because it considers that further_
_inquiries would have been sensible or desirable. It should intervene only if no reasonable authority could_
_have been satisfied on the basis of the inquiries made that it possessed the information necessary for its_
_decision. Fourthly, the court should establish what material was before the authority and should only strike_
_down a decision not to make further inquiries if no reasonable authority possessed of that material could_
_suppose that the inquiries, they had made were sufficient. Fifthly, the principle that the decision-maker_
_must call his own attention to considerations relevant to his decision, a duty which in practice may require_
_him to consult outside bodies with a particular knowledge or involvement in the case, does not spring from_
_a duty of procedural fairness to the applicant but rather from the Secretary of States duty so to inform_
_himself as to arrive at a rational conclusion. Sixthly, the wider the discretion conferred on the Secretary of_
_State, the more important it must be that he has all the relevant material to enable him properly to exercise_
_it.”_

186. It is not necessary for me to set out the other provisions relied on by the Claimants. I accept that the
court should have the overall legal context, including section 149 Equality Act 2010 and the particular
position of victims of people trafficking, in mind when considering whether the **Tameside duty has been**
complied with. The particular characteristics of the relevant group of people, and the legal duties owed to
them, will have a bearing on what is reasonable in terms of steps to ensure that an informed decision is
made. But, as I have noted, no free-standing allegation of breach of particular duties within the applicable
legal framework was made by the Claimants.

**The facts.**

The context

187. As far as the overall context for this issue is concerned I did not understand it to be in dispute that, as
a group, asylum seekers are likely to be more vulnerable as a result of their experiences and their
situation, and to have more complex physical and mental health care needs. This was the evidence of Ms
Jennifer Blair (Co-Head of Legal Protection at the Helen Bamber foundation) and it was pointed out by
various other people with expertise in the field in witness statements and in letters which were written to
the Defendant.

188. It is also obvious that, as Ms Giovannetti accepts, accommodation in a setting which resembles
detention will potentially undermine the mental health of asylum seekers. As it was put in a joint letter to the
Defendant, dated 26 November 2020, from the Chair of the Medical Ethics Committee of the BMA, the


-----

intervening) [2021] EWHC 1489 (Admin)

President of the Royal College of Psychiatrists, the President of the Faculty of Public Health and
representatives of Doctors of the World UK, Freedom from Torture and the Helen Bamber Foundation:

_“From a clinical perspective, this type of accommodation is highly inappropriate for survivors of captivity,_
_human trafficking, or torture, who are very unlikely to regard a military camp as a safe place and for whom_
_this environment is more likely to trigger a trauma response and further deterioration in mental health and_
_welfare”_

189. I also accept Ms Blair's evidence that other features of the Barracks increased the risk of
deterioration in the mental health of asylum seekers who were accommodated there for any significant
period of time. These include the shared living spaces with limited privacy which are described above, the
substantial numbers of residents, the noise, the disruption of sleep and the (well-founded) perception of a
high risk of Covid-19 infection. And in this case the risk was heightened by the way in which the asylum
seekers were transferred – at short notice and without being told where they were going – and the
uncertainty as to how long they would be there. I also accept that a substantial number of those who were
transferred to the Barracks had come to the United Kingdom via Libya, where there is a high incidence of
people trafficking.

190. In relation to allocation decisions, Mr Arnold, Head of Refugee Support at the British Red Cross
states in his report of January 2021 – “Reducing vulnerability risks and improving residents' experiences”,
and I did not understand this to be disputed, that:

_“The nature of trauma and traumatic experiences is such that these can lay dormant for some considerable_
_time, sometimes articulated through behaviour rather than disclosure at interview. Hence any information_
_within assessments may be scant, incomplete, or misleading for people have not been able to articulate_
_traumatic experiences._

_There are also lots of reasons why people seeking asylum may choose not to disclose information,_
_especially to authorities in a timely way early on in the asylum process. This is particularly the case if_
_people are not given effective support to disclose information, are not engaged in specialist health_
_services, and are not aware of the implications around any disclosure. As a result, there are significant_
_challenges with effectively trying to reduce vulnerability risk factors to identify any “suitable” people to live_
_in such accommodation forms.”_

191. All of these matters tend to underscore the importance, not only of having suitability assessment
criteria but also of ensuring that they were applied effectively both at the point of the initial decision whether
to transfer a given individual to the Barracks, and whilst they were resident there.

The initial allocation decision

192. The process for making the initial allocation decisions is addressed by Mr Williams in his first witness
statement. He says, at [35] that:

_“Asylum seekers accommodated at Napier would typically have been screened and accommodated for a_
_period of time before being routed to Napier. There would have been several opportunities to disclose_
_relevant issues and indicators to the Home Office and/or CRH, who also manage other asylum_
_accommodation. The Secretary of State took the view that the consideration of the asylum registration_
_questionnaire, together with the subsequent application for s.95 support, and the information recorded on_
_the Home Office's Case Information Database (“CID”) and CRH system would, therefore, provide a_
_reasonable mechanism for the identification of any significant health and vulnerability issues.” (emphasis_
added)

193. The development of the suitability criteria applied by the Defendant is addressed by Mr Palmer. He
states that, in recognition of the fact that the Barracks were not suitable for all individuals, a screening
process was established in September 2020. He points to a process map which was developed in
conjunction with version 1 of the suitability criteria document entitled _“Suitability Assessment for MOD_
_Camp Site Accommodation”. The former is illegible, and I was told that I did not need to be able to read it._


-----

intervening) [2021] EWHC 1489 (Admin)

The latter sets out the criteria for assessment and there is then guidance to case workers as to how to
access the relevant parts of an asylum seekers file.

194. From the suitability assessment criteria document, it is apparent that the candidate had to have
undergone a screening interview and to have been in the country for more than 14 days, so as to have
completed post-arrival quarantining. Those who satisfied these requirements would then potentially be
deemed unsuitable on a number of grounds, including if they were potential victims of trafficking, or had
other vulnerabilities or were safeguarding cases or there were any medical concerns “even if it sounds very
_minor or low level-risk”. There were other circumstances which would render them unsuitable, such as_
being aged under 18 or over 65. Mr Palmer points out that the categories were quite broad, and he says
that caseworkers were advised to take a cautious approach. It is clear from a “Suitability Assessment Desk
_Guide” at the end of the document that the key documents which the caseworker was required to consult_
were the ASL 3211, which I deduce is the “Initial Contact and Asylum Registration Questionnaire”, and the
ASF 1, which is the application form for section 95 support.

195. Mr Palmer then points to version 6 of the suitability assessment criteria, which was apparently
applicable from 21 December 2020, and is entitled _“Suitability Assessment for Contingency_
_Accommodation”. This is a fuller document which states that it is required to be read in conjunction with the_
Defendant's Allocation of Accommodation Policy and the Healthcare Needs and Pregnancy Dispersal
Policy. Version 6 states that the services provided at the Barracks are materially the same as those
provided at other full board accommodation but that “the sleeping arrangements may consist of communal
_dormitory style rooms” which may make the accommodation unsuitable for some. Caseworkers were told:_

_“It is important to look at individual cases to ensure that they are appropriate to be housed in communal,_
_dormitory style accommodation if being moved to this accommodation type._

_SUs with medical ailments that are not severe, or complex can be supported here, however, if you are_
_unsure, please discuss with a manager and refer to Healthcare Needs and Pregnancy Dispersal Policy at_
_4.16._

_The caseworker should investigate all of the evidence available to them when considering whether_
_someone will be suitable to reside in this accommodation. Information that should be considered during_
_this stage includes Screening interviews; ASF1s; CID/ ATLAS information; supporting correspondence_
_from applicant or their representative; and any other relevant information held on the applicant's case. “_

196. The Suitability Assessment Desk Guide at the end of the document reflected this guidance in that it
made clear that the minimum documentary evidence required to make an assessment was the ASL 3211
and the ASF 1. The criteria for unsuitability were, by now, significantly narrower than the September
version, so that more asylum seekers were potential candidates for transfer to the Barracks. The
unsuitable cases included unscreened cases, potential victims of trafficking, those falling within the
definition of _“a vulnerable person” under Regulation 4(3) of the 2005 Regulations (see paragraph [143],_
above), safeguarding cases, those aged over the age of 65, those with physical disabilities and those with
severe or complex health needs including: _“ii Active tuberculosis and Infectious / active communicable_
_diseases; iii. Serious mental health issues where there is a high risk of suicide, serious self-harm or risk to_
_others; iv. Chronic disease, e.g. kidney disease – the patient requires regular dialysis, etc; v. HIV.”._

197. The evidence about precisely which forms are filled in, and at what stage of the process of the
reception of an asylum seeker, was vague. However, as far as the screening interviews are concerned, the
decision of Fordham J in R (DA & Others) v Secretary of State for the Home Department _[2020] EWHC_
_3080 (Admin) on 13 November 2020 shows that, from 30 March 2020, an abridged screening interview_
process was introduced, as a result of the pandemic, whereby the Defendant conducted most screening
interviews by telephone and they were truncated. The interviews lasted 15 to 18 minutes and they did not
include certain standard questions which are relevant to the identification of potential victims of people
trafficking. Fordham J made an interim order that the asking of these questions should be resumed.


-----

intervening) [2021] EWHC 1489 (Admin)

198. I was shown the _“Initial contact and asylum registration questionnaire”_ (“the registration
questionnaire”) to which Mr Williams refers in the passage from his witness statement which I have quoted
at paragraph [192] above and which, I understand to be form ASL 3211 and the basis of the screening
interview. This sets out an introductory text which is apparently read to the applicant via an interpreter
where appropriate, and then a standard series of questions which are to be asked with, in some cases,
guidance to the questioner as to follow up questions. The introductory text states that:

_“The officer is going to ask you some questions about your identity, family, background, travel history and_
_some health and welfare questions. The officer will only ask you for a brief outline of why you are claiming_
_asylum today. The officer will not be making a decision on your asylum claim.” (emphasis added)_

199. The form then requires the applicant to be told that they may be sent a Preliminary Information
Questionnaire (“PIQ”), in which case it will be important for them to complete it so that their claim can be
considered. The applicant is told _“If appropriate, at a later date you will be sent a letter inviting you to_
_attend an asylum interview which you will be able to give full details of your experiences and fears.”._
(emphasis added)

200. Part 2 of the registration questionnaire contains a series of questions about “Health/special needs”
and the interviewer is required to read out the following:

_“It is important that you tell us, as early as possible, of any information relating to your health including any_
_possibility of contagious diseases. It will not negatively affect your claim. Any medical information you_
_disclose may help you with accessing health services.”_

201. The applicant is then asked questions including “Is there anything else you would like to tell me about
_your physical or mental health?” and “Have you ever been exploited or reason to believe you are going to_
_be exploited?”. The form requires the questioner to explain:_ _“By exploitation we mean things like being_
_forced into prostitution or other forms of sexual exploitation, being forced to carry out work, or forced to_
_commit a crime”._

202. Part 3 of the registration questionnaire is headed “Travel and Third country”. Questions 3.1 and 3.3
were omitted in the truncated version of the screening interview and Fordham J ordered that they be
restored. Question 3.1 asks “Why have you come to the UK?”. Question 3.3 is “Please outline your journey
_to the UK?”. Guidance to the questioner includes the following: “(including as appropriate date left country_
_of origin, where from, countries travelled from/to, transport used, documentation used, if assisted or how_
_organised, date of arrival in UK, how entered the UK…)”. Fordham J considered that these questions were_
key to discovering evidence that the applicant was a potential victim of trafficking at the screening stage.

203. Part 4 of the registration questionnaire asks the applicant “BRIEFLY explain ALL of the reasons why
_you cannot return to your home country?”. There is then a series of questions about what the applicant_
fears. The applicant is also asked whether they have a preference for being interviewed by a man or a
woman at their asylum interview. The applicant is not required specifically to be asked about torture, rape
or other serious forms of psychological, physical or sexual violence.

204. All of the Claimants arrived during the period when the truncated version of the screening interview
was in operation. In the case of NB, the Defendant's Part 18 Information states that he did not undergo any
screening interview at all.

205. I was also shown the “Asylum Support Application Form (“ASF 1”)”. Section 14 of this form asks the
applicant to “Provide details of your individual circumstances” including by ticking or crossing the following
boxes: _“Victim of trafficking… Mental health problems…. Physical health problems… Victim of domestic_
_violence… Other”. This section then asks for a “brief description”, for any supporting documents and_
whether the individual is currently registered with a doctor in the United Kingdom. Section 15 then asks the
applicant to _“Provide details with evidence about any specific accommodation requirements you or your_
_dependents have?”._


-----

intervening) [2021] EWHC 1489 (Admin)

206. Apart from OMA, who filled it in on 1 November 2020, the Claimants filled in the ASF1
August/September 2020 and before the decision to make use of the Barracks had been taken by the
Defendant. All of the Claimants were assisted by Migrant Help but, apparently, they dealt with each other
over the phone. None of them raised any issue under Sections 14 and 15, save for YZM who said he had a
stomach-ache.

207. Mr Palmer says that in the light of the fact that there had been truncated screening interviews for
arriving on small boats, it was recognised that the screening process should be revised in order to elicit
information about whether a candidate was a _“person who has been subjected to torture, rape or other_
_serious forms of psychological, physical or sexual violence.”. Migrant Help were therefore directed to ask_
an additional question as part of the process of applying for asylum support namely:

_“In making decisions about the allocation of asylum support accommodation, the Home Office has regard_
_to the specific situation of vulnerable persons such as minors, unaccompanied minors, disabled people,_
_elderly people, pregnant women, single parents with minor children and persons who have been subjected_
_to torture, rape or other serious forms of psychological, physical or sexual violence. Do any of these apply_
_to you?” If so, what?”_

208. The Part 18 Information served by the Defendant and dated 12 April 2021 states that this question
began to be asked from 9 December 2020 i.e. after the Claimants had been transferred to the Barracks.

209. Finally, I was also shown the PIQ which, the registration questionnaire indicates, is filled in at a later
stage of the application process, although no evidence was given about this. The PIQ asks a number of
questions which would potentially elicit information which is relevant to the question of the suitability of the
Barracks as accommodation for the asylum seeker. However, it is not referred to by Mr Williams as one of
the documents to which the Defendant decided that the caseworkers must have regard in applying the
suitability assessment criteria. Nor is it identified in the suitability assessment criteria documents which I
have referred to above. As I have noted, the key reference documents for the case workers appear to have
been the ASF1 and the ASL 3211. As Fordham J noted in R (DA & Others) v Secretary of State for the
**Home Department, the PIQ is expressly required to be filled out in English. This was one of the reasons**
why he rejected a submission that that the PIQ provided a sufficient safeguard against the risk that
potential people trafficking cases would not be identified in the course of the truncated screening interview.

210. It also it appears that only 2 of the 6 of Claimants submitted a PIQ. Their forms were prepared by
legal representatives. In the case of NB he appears to have submitted a PIQ on or before 10 September
2020 but it does not appear to have been considered until after 29 October 2020, apparently because of a
filing error. In the case of M, he was transferred to the Barracks before the 1 October 2020 deadline for the
return of the PIQ and did not submit it until 5 January 2021 in any event.

211. For all of these reasons, I do not propose to take the PIQ into account as an integral part of the
system for deciding who should, and who should not, be transferred to the Barracks. Indeed, as I
understood it, the reason why Ms Hirst showed me the PIQ was to demonstrate that although it was filled
out by two of the Claimants, and although they submitted information which strongly indicated that the
Barracks were not suitable for them, they were nevertheless transferred and remained there.

212. Mr Palmer acknowledges that the system _“has not always been effective at identifying those who_
_should not be accommodated at Napier” and he gives the example of the claimant OMA which, he says, is_
a case in which OMA was identified as unsuitable but was then sent to the Barracks as a result of mistaken
identity. He could have added NB as an example of a mistaken transfer given that he did not have a
screening interview and, therefore, the _“Suitability Assessment Desk Guide” provided that he was not_
suitable for transfer.

213. I also note that, in the case of OMA, he had provided information which was consistent with trafficking
and torture in his screening interview in October 2020 but that this was not reflected in his ASF1. Similarly,
the PIQs submitted for NB and M contain evidence which is consistent with torture but this is not reflected
in their ASF1s, possibly because this form did not specifically ask about torture but quite possibly because


-----

intervening) [2021] EWHC 1489 (Admin)

it was not appreciated that the applicant might be provided with the sort of accommodation which was
available at the Barracks.

214. In her second witness statement, Ms Creffield says at [3] that it would be wrong to suggest that the
suitability criteria were not generally applied with care. And she says that this is illustrated by the fact that
she is told that since the Barracks became operational only 20-35% of all single males over the age of 18
who have been in the United Kingdom for 14 days have been deemed as suitable for accommodation
there. The data on which the statistic is based are not identified and the reason for the range is not
explained, but it appears that this must be an estimate. She also says that she has been informed by
“colleagues” that a review of 416 files in March resulted in 80 cases meeting the suitability criteria. She
explains that a process of Clearsprings sending lists to the Home Office has been undertaken and that
these have then been checked against the criteria but, again, it is not easy to know what to make of this
evidence given, with respect, its vagueness. Ms Giovannetti said that it showed that the criteria were being
applied, albeit mistakes were occasionally made.

215. Mr Bolt's covering letter of 21 March 2021 states:

_“Secondly, from my discussions with medical professionals and those providing health services, as well as_
_with residents and former residents of both camps, it was evident that whatever assessments had been_
_made of the physical and mental health of the men selected as suitable to be moved to Penally and Napier,_
_they were wholly inadequate…... At both camps, a number of men were identified as suffering from serious_
_underlying physical and mental health conditions, including one case of active TB at Napier.” (emphasis_
added)

The position after transfer to the Barracks

216. As far as the position after the transfer of an asylum seeker to the Barracks is concerned, Mr Palmer
acknowledges that there may be circumstances in which it becomes apparent that a resident no longer
meets the suitability criteria. He says that _“systems are in place to ensure that there is an ongoing_
_assessment of individuals' suitability”. He says that there are a number of ways in which an individual or_
third party may raise a concern and, where appropriate, be assessed as a result. He points to the Induction
Briefing, which he exhibits, and which explains how to book medical appointments, how to report issues
and complaints and how to deal with personal safety issues. There is also information in the Briefing about
how to phone Migrant Help and how to seek legal assistance. The Claimants say that they were not
provided with this document and I note that Mr Palmer does not say when the Briefing came into existence
or give evidence that it was provided to any of the Claimants. However, HMCIP found that:

_“Induction took place on arrival, but residents were given no private interview for staff to identify_
_vulnerability. Useful written induction information was given to residents which included NHS information_
_on COVID-19 safety translated into five commonly spoken languages. The advice was useful, but not_
_specific to the Barracks environment. Apart from the occupancy agreement, all other information was also_
_translated into the five most common languages.”_

217. It may therefore be that these materials were not available to those who arrived in September 2020,
but I accept that they were provided by the time of the HMCIP inspection. I note that HMCIP also found
that residents were not screened on arrival to assess their physical or mental health and nor was there a
private interview in which issues of vulnerability might have been raised.

218. Mr Palmer also refers to onsite staff including: “CRH contracted welfare officers, security personnel,
_cleaners and other facilities staff, onsite medical professionals and a Community Support Worker_
_employed by Migrant Help offering advice and support services.” He says that the Community Support_
worker had received safeguarding training from Migrant Help before he started on site in late November
2020, albeit this service was suspended between the Covid-19 outbreak which took place in mid-January
and March 2021. He says that these members of staff could be approached by residents at any time.

219. Mr Palmer says that the asylum seekers are registered at a local GP surgery and points out that
there is a n rse on site as ell as there being a 24/7 Migrant Help telephone helpline albeit there is


-----

intervening) [2021] EWHC 1489 (Admin)

evidence that waiting times for calls to be answered were long. He notes that in September 2020 Kent
County Council Adult Social Care had set up a system to deal with referrals from the Barracks, albeit there
were no referrals as, he says, asylum seekers were transferred out of the Barracks if their case reached a
level of safeguarding concern which warranted local authority intervention. He also refers to the availability
of a process of referral to the Home Office Safeguarding Team albeit he acknowledges that staff on site
were not aware of this, nor of the suitability assessment criteria, until the week commencing 22 February
2021.

220. With respect to him, Mr Palmer's evidence is not particularly clear on these issues. As I have noted,
the Barracks have only been within his remit since 30 November 2020. He says that since then he has
attended various multi agency forums and that he led the response to the critical incident on 29 January
2021. But it also appears from what he says that he did not actually visit the Barracks until 5 March 2021.
His witness statement is dated 18 March 2021 and there are aspects of his account which appear to be
reporting the position as at that date. Where his evidence is different to, or in conflict with, other evidence
in the case, this may be why. But other evidence in the case tends to paint a picture which is less positive
than he portrays.

221. It is true that there was a nurse on site, but he worked 9am-5pm on weekdays. Although the findings
of HMCIP were that he was doing a good job in meeting the general health needs of the residents, the
witnesses for the Defendant do not mention that, according to the Human Applications audit of 2 November
2020, the intention had been to appoint a full time GP. Nor do they mention that in the 17 December 2020
_“lessons learned” meeting it was said that “Whilst the presence of an onsite nurse has been invaluable,_
_experience has shown that a team rather than a single person is needed”. There is no evidence that any_
steps were taken to address this point. And there is also evidence that on 11 January 2021 the nurse told
the SESPM meeting that he had seen a deterioration in the mental health of the residents in the preceding
weeks and that he was struggling to deal with their mental health needs despite doing his best. There was
no specialist mental health support on site.

222. It may well be true that the asylum seekers were registered with a GP, but they all say, and I accept,
that they were not aware of this. Access to the GP was via the onsite nurse who triaged cases.

223. As to safeguarding processes, the Countrywide Safeguarding Adults Service Manager's report of 12
February 2021 found in relation to residents “displaying signs of mental ill-being” or of being a suicide risk
that:

_“A positive reflection was that staff and leadership appeared to be responding intuitively to needs_
_reportedly presented by [residents]. However, these safeguards did not appear to be informed or_
_underwritten by any prescribed procedure or framework”._

224. HMCIP also found that the on-site staff were mostly security guards:

_“We observed pleasant, respectful interactions with residents, but staff were ill-equipped to deal with the_
_complex issues they faced”._

225. Extraordinarily, there was very little awareness amongst staff of the suitability assessment criteria or
of the process for making referrals to the Home Office safeguarding team. The HMCIP report says that:

_“Systems intended to safeguard residents did not ensure that vulnerability was always identified and acted_
_on promptly. Safeguarding expertise was provided by the national safeguarding team of Clearsprings_
_Ready Homes, who were based off site. We saw evidence that they engaged actively with residents'_
_safeguarding needs when identified. However, they relied on information provided by on-site staff, who had_
_little awareness of trafficking and other safeguarding needs…... With the exception of the one Migrant Help_
_worker, none of the staff we spoke to had any knowledge of the eligibility requirements for Napier Barracks_
_and could not reliably identify residents who were not suitable.” (emphasis added)_

226. Ms Creffield says in her first witness statement:


-----

intervening) [2021] EWHC 1489 (Admin)

_“It was also clear that those I spoke with did not have knowledge of our Suitability Criteria, however they_
_understood safeguarding. On 22nd February I shared the suitability criteria with the onsite nurse and the_
_provider, and requested it be shared with Migrant Help. This was to ensure that staff could identify people_
_who they consider no longer met the criteria and raise such cases with the Home Office.” (emphasis_
added)

227. This was after Ms Creffield had recommended in her _“Review of Service User Welfare” dated 27_
January 2021 that “With immediate effect, the Home Office should share the suitability criteria with
_providers, so they understand the selection process for MOD sites”, albeit the final report was not agreed_
until 15 March 2021. Ms Creffield also says that she identified a need to ensure that all staff on site had
safeguarding training.

228. As far as numbers of residents who were living in the Barracks despite this being unsuitable
accommodation for them are concerned, Mr Palmer also says that at a “SESPM lessons learned meeting
_on 17 December 2020 it was said that there were a few cases where individuals with a long term health_
_challenge were accommodated at the site, including those in need of specialist mental health needs (sic)_
_such as PTSD or survivors of torture”. In fact, the minutes of that meeting say:_

_“There had also been assurance that no one with a long-term health challenge would be brought to the site_
_but there have been a few cases where this has proved not to be the case. In particular, several service_
_users are in need of specialist mental health needs need such as PTSD or survivors of torture.” (emphasis_
added)

229. HMCIP found that:

_“31 residents had been transferred from the Barracks to more suitable accommodation after health and_
_safeguarding concerns were identified. More had been transferred following legal intervention, although_
_managers were unable to tell us how many.”_

230. In her third witness statement, dated 30 March 2021, Ms Willman, a solicitor at Deighton Pierce
Glynn (“DPG”) who represent the First to Fourth Claimants, states that her firm is aware from its own
caseload, and from information provided by other firms of solicitors, that over 80 individuals with underlying
vulnerabilities were only transferred out of the Barracks after legal proceedings were threatened or issued.
She exhibits a schedule which includes 109 of these cases. I treat this evidence with caution for a number
of reasons. It appears that Ms Willman has reasonably detailed information about the first 53 cases, but it
appears that she has very little in relation to the rest, and I agree with Ms Giovannetti that it would be unfair
to give the additional cases any real weight on this issue. Even in relation to the 53, all are anonymised
although there are case numbers for 8 of them. Other than in the cases of the Claimants, the documents
are not before the court and the Defendant has not had a fair opportunity to respond to the suggestion that
the individuals were transferred out of the Barracks because of interventions by lawyers based on there
being evidence of trafficking and/or torture and/or significant mental health issues. The timing of many of
the transfers is equally consistent with a decision to reduce the population of the Barracks because of the
Covid-19 outbreak. But what I do take from the schedule is that it is further evidence that there was a large
number of asylum seekers accommodated in the Barracks who ought not to have been there if the
suitability assessment criteria were applied.

231. The HMCIP report also makes a number of findings which indicate the inadequacy of the
safeguarding arrangements at the Barracks. For example:

_“A third of the residents responding to our survey said they had experienced mental health problems. All_
_residents who responded said they had felt depressed during their stay at the Barracks…._

_….In one case, the Home Office decided that a resident was a potential victim of trafficking, but he_
_remained at the Barracks for a further 10 weeks before being transferred out in February 2021….The_
_Home Office did not inform the resident's legal representative or Migrant Help of the decision despite their_
_repeated subsequent requests for an NRM referral……_


-----

intervening) [2021] EWHC 1489 (Admin)

_…. Data suggested that seven residents had self-harmed and seven others had threatened suicide since_
_the barracks had opened. Some self-harm incidents had been serious. A third of the residents who_
_responded to our survey said they had felt suicidal at the Barracks…._

_More vulnerable residents were moved to a single room in the decrepit and wholly unsuitable conditions of_
_the 'isolation block'…. This included residents who said they were children and one at imminent risk of_
_harm who was subject to constant watch by staff. Residents on the block did not have a radio or television_
_and had little means of distracting themselves. They were watched by security guards with no training in_
_managing safeguarding and self-harm risk. A nail protruding from the door frame afforded an obvious_
_ligature point and staff did not carry anti-ligature knives._

_An actively suicidal resident had remained on the site for more than a month……. He was taken off_
_constant supervision following a conversation between the site manager and a security guard who had_
_been watching him. The following day he was found hanging and required overnight hospital treatment. He_
_was transferred out of the Barracks three weeks later, following a further incident in which staff intervened_
_to prevent him from self-harming. There had been no review in this case to learn lessons…._

_Two residents had been transferred to the care of social services for an age assessment. In the first of_
_these cases, the resident was accommodated in the Barracks for 17 days before being transferred,_
_following legal intervention._

_In the second case, the resident remained at the Barracks for more than two months, before being placed_
_in the care of social services… (I note that the Defendant says this was 5 weeks)_

_In the absence of any formal care planning managers at the Barracks could supply little documentary_
_evidence of the support provided to these residents…”_

232. As I have noted, the evidence in all six of the Claimant's cases suggests that they were not suitable
to be transferred there under the September 2020 suitability assessment criteria, and ought not to have
been living there according to the December 2020 suitability assessment criteria. The findings in the Annex
at the end of this judgment also show that the Defendant was slow to move them out when the evidence of
their unsuitability was drawn to her attention, albeit the pandemic may have contributed to this.

**Discussion and conclusions on Ground 2**

233. I accept the Claimants' contention that the system which the Defendant operated when they were
transferred to the Barracks, and whilst they were there, fell below the fairly low standard required by the
application of the **Tameside principle. As I have pointed out, the particular context was one which the**
Defendant herself recognised that there was a relatively high risk of physical and mental vulnerability
amongst asylum seekers and that the Barracks therefore were not suitable, even, for all adult male asylum
seekers.

234. It was not sufficient simply to put suitability criteria in place; there also had to be a reasonable system
for gathering the information to which those criteria would be applied. As I have pointed out, the screening
interviews were truncated at the time when the Claimants were transferred to the Barracks and, indeed,
until the second part of November 2020. They therefore left out questions which were highly relevant to the
assessment of whether the case was potentially one which had involved trafficking. Even if the full
interview had been carried out, it was not designed to elicit information for the purposes of decisions about
what accommodation might or might not be suitable for the applicant. It did not ask specific questions
which were directed at the suitability criteria and the applicant was given the impression that they only
needed to give initial information and would be able to provide a more detailed account at a later stage. I
also accept that, at this point in the process, there was a real risk that sensitive issues might not be
disclosed by the applicant.

235. The Defendant herself effectively acknowledged that the ASF 1 form was flawed as a basis for
gathering information about suitability for accommodation at the Barracks when, as I have noted, a more
specific question – directed to aspects of the suitability criteria - was introduced with effect from 9


-----

intervening) [2021] EWHC 1489 (Admin)

December 2020. As I have also pointed out, this was after the Claimants had transferred to the Barracks.
When the Claimants filled in the ASF 1, there was the additional problem that it could not have been
appreciated by them or Migrant Help that the questions in sections 14 and 15 of the form would have a
bearing on whether they would or would not be sent to accommodation in the form of military barracks
which had the features which I have outlined above, and was therefore more likely to have an adverse
impact on their mental health. Had they known of this fact they might have raised issues with any such
proposal when the form was filled in.

236. I accept that the cumulative effect of the registration form and the ASF1 should be taken into account,
as well as the possibility that there may have been information available to caseworkers from other
sources. But, in my view, even on this approach the initial assessment process was inadequate until, at the
earliest, the ASF 1 was supplemented on 9 December 2020. This conclusion tends to be confirmed by the
views of HMCIP cited above and by the other evidence, in the HMCIP report and elsewhere, that there
were significant numbers of people living at the Barracks for whom such accommodation was unsuitable as
defined in the suitability assessment criteria. On the evidence, the levels went beyond a few aberrant
cases which resulted from human misjudgement or error, as Ms Giovannetti argued.

237. I appreciate, of course, that the number of “unsuitable” people who were living in the Barracks is not
necessarily an indication that the initial assessment of suitability was wrong. They may have been suitable
at the point of transfer into the Barracks, but their mental health may then have deteriorated for one reason
or another. But this tends to underline the point that the system for ensuring that only those who were
suitable were living in the Barracks had to be considered as a whole. Thus, it might well be that the
combination of the approach from 9 December 2020 with well trained and well-informed Migrant Help or
other workers to assist, and effective access to equally well trained and well-informed staff whilst in the
Barracks, would be sufficiently effective. But, as I have pointed out, throughout the time that the Claimants
were living at the Barracks there appears to have been barely anyone on site, not even the nurse, who was
aware of the suitability assessment criteria and the possibility of referrals to the Home Office Safeguarding
Team, let alone trained in the application of the criteria or to identify cases where the person was not
suitable. In addition to this, as I have pointed out, the evidence indicates that the staff were pleasant, and
no doubt doing their best, but untrained and inexperienced where the relevant issues are concerned, and
that excessive demands were being placed on the nurse.

238. These are not the hallmarks of a Tameside compliant, rational, system to ensure that the Defendant
was reasonably well informed as to the suitability or otherwise of the Barracks to accommodate a given
asylum seeker, whether at the point of allocation or on a continuing basis. Again, my conclusions relate to
the period during which the Claimants were at the Barracks and are based on the evidence which was
before me. It may be that since the intervention of Ms Creffield, and in the context of greater awareness of
the issues in these Claims and reduced numbers of residents, the system for assessment and monitoring
has materially improved. I do not know.

239. It will have been noted that the subject matter of Grounds 1 and 2 is complementary: if the Barracks
are to continue to be used there clearly need to be substantial improvements in the conditions there, and
lower numbers of asylum seekers living there for significantly shorter periods, with measures to reduce the
risk of Covid infection which are consistent with PHE advice. But there also needs to be a better system for
identifying those for whom such accommodation is not suitable and for detecting cases where, although
suitable when initially transferred, it ceases to be during the course of their stay. The better the system of
assessment and monitoring, the more likely it is that improvements in conditions at the Barracks will mean
that it will be adequate accommodation in a given case.

240. I therefore uphold Ground 2.

**GROUND 3        .**

Overview


-----

intervening) [2021] EWHC 1489 (Admin)

241. The Claimants allege breach of Articles 2, 3 and/or 8 of the European Convention on Human Rights
(“ECHR”). However, greatest emphasis was placed on Article 3.

**Article 2 ECHR        .**

Legal framework

242. Article 2 provides that: “Everyone's right to life shall be protected by law”. It was common ground that
this may place a positive duty on the state to take appropriate steps to prevent a person's life from being
avoidably put at risk: **Savage v South Essex Partnership NHS Trust [2009] 1 AC 681[50] and [65]. In**
**Osman v United Kingdom 29 EHRR 245, 305 the European Court of Human Rights (“the Court”) said:**

_“116. In the opinion of the Court where there is an allegation that the authorities have violated their positive_
_obligation to protect the right to life… it must be established to its satisfaction that the authorities knew or_
_ought to have known at the time of the existence of a real and immediate risk to the life of an identified_
_individual or individuals…and that they failed to take measures within the scope of their powers which,_
_judged reasonably, might have been expected to avoid that risk….”_

243. The threshold of _“real and immediate risk to life” is a high one. These words were explained by_
Weatherup J in **Re W's Application** _[[2004] NIQB 67 as follows:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4F8J-14X0-TWP1-H19J-00000-00&context=1519360)_ _“… a real risk is one that is objectively_
_verified, and an immediate risk is one that is present and continuing”. In Re Officer L [2007] 1 WLR 2135,_
Lord Carswell said that this is a criterion which will not readily be satisfied and that, for a risk to be “real”, it
must be objectively well-founded (at [20]).

244. As the Court said in Slimani v France (2004) 43 EHRR 1068, however at [24]:

_“The obligations on Contracting States take on a particular dimension where detainees are concerned_
_since detainees are entirely under the control of the authorities. In view of their vulnerability, the authorities_
_are under a duty to protect them.”_

Assessment

245. Breach of Article 2 was not argued in detail or with great conviction by the Claimants. The basis for
such an argument is essentially the risk posed by the lack of sufficient safeguards in relation to Covid-19
infection and the risk of fire. I agree that both considerations, at least in principle, gave rise to a risk to life.
But I am not persuaded that that risk was sufficiently real and immediate to give rise to a breach of Article
2. In the case of Covid-19, Professor Coker's evidence suggests that the risk of death for under 50-year
olds is less than 1%. In relation to the fire risks identified by the CPFSI, these were serious but not serious
enough to warrant an immediate enforcement notice, as Ms Giovannetti points out. Thankfully, no resident
lost his life as a result of a Covid-19 infection contracted at the Barracks or through fire.

246. I therefore dismiss this claim.

**Article 3 ECHR        .**

Legal framework

247. Article 3 provides that “No one shall be subjected to torture or to inhuman or degrading treatment or
_punishment”. There was no dispute that Article 3 may give rise to positive obligations on the state. It was_
also common ground that, as the 1998 Act requires a claimant to be a “victim” of the breach alleged, the
success or otherwise of this claim would depend on the experience of each of the Claimants during the
time that they were accommodated at the Barracks.

248. Paragraph 52 of the decision of the Court in Pretty v United Kingdom (2002) 35 EHRR 1 usefully
explains the key concepts in Article 3 for present purposes. The overarching principle is that there must be
_“ill-treatment that attains a minimum level of severity and involves actual bodily injury or intense physical or_
_mental suffering”. At [50] the Court also referred to a duty to refrain from inflicting “serious harm”. In MSS v_
**Belgium and Greece (2011) 53 EHRR 28 the Court appeared to regard this as an explanation of the term**
_“inhuman” when it said, at [220] “The Court considers treatment to be “inhuman” when it was,_


-----

intervening) [2021] EWHC 1489 (Admin)

_“premeditated, was applied for hours at a stretch and caused either actual bodily injury or intense physical_
_or mental suffering”._

249. The word _“degrading” was explained in_ **Pretty [52] as follows:** _“Where treatment humiliates or_
_debases an individual showing a lack of respect for, or diminishing, his or her human dignity or arouses_
_feelings of fear, anguish or inferiority capable of breaking an individual's moral and physical resistance, it_
_may be characterised as degrading”. It may be sufficient that the victim is humiliated in his own eyes, even_
if not in the eyes of others: eg **Tyrer v United Kingdom (1979–80) 2 E.H.R.R. 1 at [32]. In considering**
whether treatment is _“degrading” the court should_ _“have regard to whether its object is to humiliate and_
_debase the person concerned and whether, as far as the consequences are concerned, it adversely_
_affected his or her personality in a manner incompatible with Article 3. However, the absence of such a_
_purpose cannot conclusively rule out a finding of a violation of Article 3”: e.g. Elmi and Abubakar v Malta_
Application Nos 25794 & 28151/13 [99].

250. Unsurprisingly, the assessment of whether the minimum level of severity has been reached _“is_
_relative; it depends on all the circumstances of the case, such as the duration of the treatment, its physical_
_and mental effects and, in some cases, the sex, age and state of health of the victim”: Ireland v United_
**Kingdom (1979–80) 2 E.H.R.R. 25 at [162]. The court also has to look at the cumulative effect of the**
circumstances.

251. In **MSS the Court acknowledged the difficulties, burden and pressure which the reception of large**
numbers of asylum seekers may cause to the authorities. However, it emphasised that the absolute nature
of Article 3 means that this cannot absolve a state of its obligations under this provision: [223]. On the
contrary, the fact that the test is “relative”, rather than the standard being a uniform one, means that the
particular vulnerabilities of an asylum seeker may be relevant to the assessment. In **MSS and** **Elmi the**
Court expressly took into account that “the applicant, being an asylum seeker, was particularly vulnerable
_because of everything he had been through during his migration and the traumatic experiences he was_
_likely to have endured previously.” Elmi [232]._

252. I was referred to a number of cases about the application of Article 3 to people who are in prison or
detention. These are illuminating, in terms of the sorts of considerations which the Court has regarded as
relevant or compelling in this context, but the fact that the individuals were on any view detained has to be
born in mind in considering attempts to make factual comparisons with the present case. This is because,
as the Court has recognised there is an “inevitable element of suffering and humiliation connected with a
_legitimate deprivation of liberty” (Testa v Croatia (2008) 47 EHRR 29 [44]). That is therefore a key factual_
feature which is built into these cases. Those who are detained are inevitably more vulnerable in that they
have very little agency and are entirely subject to the control of the state and dependent on it for their wellbeing. There is therefore a duty to protect them: **Rooman v Belgium Application 18052/11 [143]. In the**
present case, for the bulk of their time at the Barracks the Claimants were, at least in principle, free to
come and go, at least during the day. They were largely dependent on the state for their well-being, but
they had a greater degree of agency than if they were prisoners. On the other hand, the fact that prisoners
have committed crimes may mean that a certain degree of ill treatment is justified when it might not
otherwise be. As the Court said in Feilazoo v Malta (Application no 6865/19), which concerned conditions
in a detention centre: “In that light, the Court found it difficult to consider such conditions as appropriate for
_persons who have not committed criminal offences but who, often fearing for their lives, have fled from_
_their own country”. [84]_

253. With this caveat, Ananyev v Russia App Nos 42525/07 and 60800/08 contains a useful review of
what is and is not relevant in Article 3 cases, albeit in the context of imprisonment. In that case, the Court
emphasised that _“extreme lack of space in a prison cell weighs heavily as an aspect to be taken into_
_account” in relation to the question whether conditions are “degrading”. Having considered whether there_
was overcrowding, the Court considered _“access to outdoor exercise, natural light or air, availability of_
_ventilation, adequacy of heating arrangements, the possibility of using the toilet in private, and compliance_
_with basic sanitary and hygienic requirements” [149] et seq. I note that in Ananyev the position was that_
prisoners were spending 23 hours out of 24 in a cramped cell for a period of 3 years They ate their meals


-----

intervening) [2021] EWHC 1489 (Admin)

there and they could only go to the toilet in the cell in front of the other prisoners, with whom they shared
the cell, and warders. Prisoners were only able to shower once a week, which was considered insufficient,
and they had to shower as a group.

254. As far as health is concerned, the Court in Pretty added:

_“The suffering which flows from naturally occurring illness, physical or mental, may be covered by Article 3,_
_where it is, or risks being, exacerbated by treatment, whether flowing from conditions of detention,_
_expulsion or other measures, for which the authorities can be held responsible.” [52]_

255. The decision in Rooman emphasises, albeit in the context of detention, and an applicant with severe
mental illness, the particular vulnerabilities of detainees with mental disorders. A court should consider the
effect of the manner of the detention, as well as the conditions in which such a person is detained, and
should be alive to the possibility of exacerbation of existing conditions and the potential inability of the
prisoner to raise issues about their mental health. In this connection, the court is also entitled to take
account of the adequacy of the medical assistance and treatment available to the prisoner, which must be
comparable to that which the state authorities have committed to provide to the population as a whole,
although it need not be of the standard of the best care available to that population: [144]-[148].

256. In Feilazoo the Court touched on the specific issue of coronavirus at [92], albeit in a very different
factual context. It said:

_“92. Furthermore, the Court is concerned about the assertion, not rebutted by the Government, that_
_following this period the applicant was moved to other living quarters where new arrivals (of asylum_
_seekers) were being kept in Covid-19 quarantine. The Court notes that there is no indication that the_
_applicant was in need of such quarantine – particularly after an isolation period – which moreover lasted for_
_nearly seven weeks. Thus, the measure of placing him, for several weeks, with other persons who could_
_have posed a risk to his health in the absence of any relevant consideration to this effect, cannot be_
_considered as a measure complying with basic sanitary requirements.” (emphasis added)_

257. But, in any event, it is clear that exposing a detainee to the risk of illness is a relevant consideration.
Thus, in Staykov v Bulgaria App No 49438/99 [80] the Court took into account the fact that tuberculosis
was endemic in the Bulgarian prison system, the inadequacy of the prevention efforts of the authorities and
the inadequacy of their attendance to the needs of prisoners who contracted the disease.

258. In **Kalashnikov v Russia (2003) 36 EHRR 34, in finding that the applicant's living conditions**
amounted to a breach of his Article 3 rights, the Court took into account a number of factors including the
fact that his sleep was disrupted by overcrowding, constant light and noise. Albeit in a more extreme
factual context, the Court said, at [97], that _“the resulting deprivation of sleep must have constituted a_
_heavy physical and psychological burden on the applicant”._

259. The Claimants placed particular emphasis on the decision of the Court in **Elmi and Abubakar v**
**Malta App Nos 25794 & 28151/13. This was one of a series of cases about conditions in which asylum**
seekers were being held by the Maltese authorities at Safi Barracks. These conditions had been criticised
by a number of international bodies as being inhuman and degrading and/or “appalling”. The applicants in
**Elmi were being held in a warehouse which was not intended to accommodate people. They were sharing**
with around 290-320 other people, i.e. around 50% more than the capacity of the warehouse. The Court
emphasised, as it had in various cases, that extreme lack of space is a particularly weighty consideration
where the issue is whether conditions can be described as “degrading”. The applicants were also there in
the heat of the summer months. There was limited light and ventilation and the sanitary facilities were
described as being in a “deplorable state”. They said that there was a tense and violent atmosphere, that
they had been bullied and victimised by fellow detainees, that they had not been able to access medical
care for illnesses which they had suffered and that they were not able to communicate because they only
spoke Somali.

260. Ultimately, I did not find that Elmi gave as much support to the Claimants' case as was suggested on
their behalf The living conditions appear in that case to have been considerably worse than in the present


-----

intervening) [2021] EWHC 1489 (Admin)

case. It is also clear that the Court based its conclusion that there had been a breach of Article 3 on the
fact that the applicants were minors and had been detained for a period of 8 months so that the cumulative
effect of these and the other features of the case amounted to a breach: see [111]-[114]. Obviously, the
present case concerns adults who were not detained and who were resident in the Barracks for a
considerably shorter time than the applicants in Elmi.

261. Similarly, it is striking that, having considered the conditions at Safi Barracks in general in the
**Feilazoo case, the Court ultimately decided that there had been a breach of Article 3 on the basis of the**
particular circumstances of the applicant. He had been held alone in a container for nearly seventy-five
days without any access to natural light or air and, during the first forty days, had had no opportunity to
exercise [89]. He had then been put in with detainees who were quarantining in relation to Covid-19 as
noted above.

Assessment

262. It is superficially attractive to move from my conclusion that during the relevant period the Barracks
did not “ensure a standard of living adequate for the health of the applicants”, and/or could not rationally be
viewed as adequate for their needs, to the conclusion that therefore accommodating the Claimants at the
Barracks amounted to inhuman and degrading treatment of them. But Mr Hickman rightly accepted that the
latter does not follow from the former: the threshold which the Claimants have to cross under Article 3 is a
higher one.

263. I accept that, as the Claimants submit, the decision of the Divisional Court in R ((1) Detention Action
**and (2) Ravin) v Secretary of State for the Home Department** _[2020] EWHC 732 (Admin) is_
distinguishable from the present case. There, the Court found that the increased risk of Covid-19 infection
in the context of immigration detention did not give rise to seriously arguable claims under Article 2 or 3
ECHR given the steps which the Defendant was taking to ensure that the arrangements in detention
centres were safe. The Court considered that these measures were likely to work effectively. By contrast,
the present setting is not supposed to be one of detention, the accommodation is in dormitories and the
measures which the Defendant took, I have found, were inadequate and ineffective. The residents of the
Barracks were therefore at an unnecessarily heightened risk of contracting the disease.

264. However, I note that in the Detention Action case the court took into account the fact that the risk of
serious harm to the detainees in the event of their contracting Covid-19 infections had not been shown to
be higher than that of the population in general. In the present case, Professor Coker makes the point that
there was evidence that men, and those who are from ethnic minority backgrounds, tend to have worse
outcomes from Covid-19 infection than others, but he also points out that there are numerous other
variables including age and other comorbidities. _“Predicting who, on an individual basis, will develop_
_infection after exposure, who will develop disease after infection, how serious that disease will be…is a_
_challenge”. As I have noted in relation to Article 2, basing himself on a study in June 2020 he says that less_
than 1% of the under 50s will die from the condition. On the basis of another June 2020 study, he says that
around 10% of patients who test positive are ill for more than 3 weeks and a smaller proportion are ill for
months. In the present case, the Claimants are young and there is no evidence that they had any relevant
medical conditions; four of the six Claimants tested positive and one had symptoms which were consistent
with being infected. None was hospitalised.

265. Looking at matters in the round, whilst I have been critical of the conditions at the Barracks, and of
the Defendant's willingness to put the health and safety of the residents at risk, I do not consider that the
treatment of the Claimants was “inhuman” or “degrading”. The conditions at the Barracks were not as poor
as in the cases summarised above, as I have noted. And up until 15 January 2021 the Claimants were
able, if they wished, to leave the Barracks, at least during the day. Their position therefore was not truly
comparable to that of the successful applicants in those cases. I accept that at least four of the Claimants
suffered actual bodily injury in the sense that they had symptomatic Covid-19 infections. I accept that there
was a significant degree of suffering amongst the residents in the Barracks and that there is evidence that
the mental health of the Claimants deteriorated whilst they were living there. But I do not accept that the


-----

intervening) [2021] EWHC 1489 (Admin)

treatment of the Claimants was “premeditated….applied for hours at a stretch” in the relevant sense, nor
that there was sufficiently “intense physical or mental suffering” over and above that which is inherent in
being an asylum seeker in a foreign land, to cross the high threshold under Article 3.

266. The high point of the Claimant's case on Article 3 was in relation to the period after the Covid-19
outbreak, when they were not permitted to leave the Barracks, they were obliged to share dormitories with
several infected people and conditions and the atmosphere in the Barracks appear to have deteriorated
significantly. Paragraph 92 of **Feilazoo, cited above at paragraph [256], therefore requires particular**
consideration. But in that case the Court rolled the Covid issue into its overall finding rather than holding
that moving the applicant into quarantine with others was itself a breach of Article 3. It did say that this
_“could not be considered a measure complying with basic sanitary requirements”, which was a relevant_
factor (see Ananyev), but the Court's jurisprudence emphasises that the relevant considerations should be
assessed by reference to their cumulative effect. The Court also emphasised that the step of quarantining
the applicant in that case was unnecessary given that he had effectively been in solitary confinement,
whereas that is not clear in the present case – some of the Claimants may already have been infected and it emphasised that the quarantining lasted nearly seven weeks, whereas it lasted for around two weeks
in the case of the Claimants, as they were transferred out of the Barracks at the end of January/beginning
of February 2021.

267. Similarly, nor do I accept that there was “treatment which humiliated or debased [the Claimants]
_showing a lack of respect for, or diminishing, their human dignity or arousing feelings of fear, anguish or_
_inferiority capable of breaking an individual's moral and physical resistance.” I accept that the conditions in_
the Barracks were highly problematic from their points of view in the ways that I have identified, and that
their mental health deteriorated, but in my view accommodating them there did not involve humiliating or
debasing them or breaking their moral and physical resistance.

268. I therefore reject the claim under Article 3.

**Article 8 ECHR        .**

Legal Framework

269. Article 8 provides:

_“Right to respect for private and family life_

_1. Everyone has the right to respect for his private and family life, his home and his correspondence._

_2. There shall be no interference by a public authority with the exercise of this right except such as is in_
_accordance with the law and is necessary in a democratic society in the interests of national security,_
_public safety or the economic well-being of the country, for the prevention of disorder or crime, for the_
_protection of health or morals, or for the protection of the rights and freedoms of others.”_

270. The Claimants point out that the concept of _“private life” is a broad one and is not susceptible to_
exhaustive definition. It may, depending on the circumstances, cover the moral and physical integrity of the
person, and Article 8 may therefore afford protection in relation to conditions during detention which do not
attain the level of severity required for a breach of Article 3: Rannien v Finland (1997) 26 EHRR 563 at

[63]. I note, however, that in Rannien the applicant failed under both Articles 3 and 8 in a case where he
had been handcuffed in public. At [64] the Court said that:

_“it had not been shown that the handcuffing had affected the applicant physically or mentally or had been_
_aimed at humiliating him. In these circumstances, the Court does not consider that there are sufficient_
_elements enabling it to find that the treatment complained of entailed such adverse effects on is physical or_
_moral integrity as to constitute an interference with the applicant's right to respect for private life as_
_guaranteed by Article 8.”_


-----

intervening) [2021] EWHC 1489 (Admin)

271. Wainwright v United Kingdom (2007) 44 EHRR 40 was a case in which the Court held that a strip
search did not breach Article 3. The treatment undoubtedly caused the applicants distress, but this did not
reach the minimum level of severity required. It did, however, breach Article 8. At [43] the Court said:

_“Where a measure falls short of Art.3 treatment, it may, however, fall foul of Art.8 of the Convention, which,_
_inter alia, provides protection of physical and moral integrity under the head of respect for private life._
_There is no doubt that the requirement to submit to a strip-search will generally constitute an interference_
_under the first paragraph of Art.8 and require to be justified in terms of the second paragraph…”._

272. Since the manner in which the search was carried out was unnecessarily invasive and humiliating it
was held not to be “justified”.

273. Whilst I accept that the degree of distress which may found an Article 8 claim is lower than that which
would be required for a breach of Article 3, it seems to me that a claimant has to point to aspects of the
treatment which engage Article 8 in particular i.e. those which relate to privacy and interfere with the moral
and physical integrity of the person. Wainwright is a classic Article 8 case in that, on any view, the privacy
of the applicants was interfered with. In the course of her oral submissions, I asked Ms Luh which aspects
of the conditions in the Barracks gave rise to issues under Article 8 in particular, anticipating that she might
point to the showering and toilet facilities or, perhaps, the lack of privacy in the blocks. She said, however,
that she relied on all of the conditions in the Barracks.

274. I note that in R (Soltany and others) v Secretary of State for the Home Department (referred to at
paragraph [36] above) there was a complaint related to in-room toilets which had no door. Although there
was no breach of Article 8 on the facts, Cavanagh J accepted, at [301] that _“ECtHR case law…clearly_
_establishes that a failure to provide bodily privacy can result in a violation of Article 3 and Article 8”. Whilst_
Cavanagh J found that the toilet arrangements were _“sub-optimal”, the fact that_ _“the configuration of the_
_room was such that detainees did not need to be visible whilst they were on the toilet” meant that there_
was no breach of Article 8. This contrasted with the position of the applicant in Szfranski v Poland, (2017)
64 EHRR 23 who “would inevitably be visible”.

Assessment

275. In my view the evidence does not establish breaches of the Claimants' rights under Article 8,
essentially for the reasons which I have given.

276. In relation to toilets and showers, all of the Claimants were able to go to the toilet in private in the
relevant sense. In relation to showering, XD perfectly understandably raised concerns about the lack of
privacy. Those concerns were based on his Muslim faith and the fact that he has scarring as a result of
torture. As I have said, however, it was possible for him to shower in private, either by timing any shower
which he took in the facilities in the block, or by using a towel or by using the facilities in the portacabin. I
appreciate that this was less than ideal, but it meant that this aspect of life in the Barracks did not inevitably
infringe his Article 8 rights.

277. XD also raised concerns about changing in his space in the dormitory given that there was no door,
and the Claimants raised concerns about the lack of privacy in relation to conversations being overheard
and noise more generally. Again, without being unsympathetic, it was open to the Claimants to take steps
(e.g. putting up a notice about not entering their space without warning or going outside to hold a sensitive
conversation) which meant that their privacy was sufficiently respected.

278. Beyond these particular points, I did not immediately see where it was that the Claimants could
potentially fail under Article 3 and yet succeed under Article 8.

**GROUND 4        .**

**Outline of the arguments.**


-----

intervening) [2021] EWHC 1489 (Admin)

279. The Claimants' arguments in relation to Ground 4 were also presented by Ms Luh. She helpfully
made clear that the allegation of false imprisonment at common law and/or breach of Article 5 ECHR is
based on two periods of time:

i) At all material times up to the 15 January 2021 letter, when the imprisonment and/or deprivation of
liberty was by reason of the alleged curfew and therefore between the hours of 10pm and 6am. The
pleaded argument that there was also imprisonment by reason of a two-hour limit on the period of time
which any resident was permitted to spend away from the Barracks was not pursued.

ii) At all material times thereafter until 22 February 2021 at the earliest, when the imprisonment and/or
deprivation of liberty was by reason of the instruction not to leave the Barracks. The detention of each
Claimant ended when each was transferred out of the Barracks.

280. In the case of OMA there is also an allegation that he was detained in the recreation room between
on or around 18 and 25 January 2021 when he tested positive for Covid-19.

281. The Claimants' skeleton argument refers, at paragraph 156, to three further incidents of detention
about which XD and YZM, although not the other Claimants, give evidence. It is said that:

i) On 26 October 2020 the gates to the Barracks were closed from 1pm until the next morning, apparently
because of concerns about the activities of a volunteer charity worker, Mr Adam Yassir;

ii) The gates to the Barracks were closed between 23 and 25 November 2020 because of concerns about
security guards outside the Barracks;

iii) They were closed again for the same reason on the day of 28 December 2020.

282. However, the Claimants' skeleton argument goes on to acknowledge that these instances are
_“perhaps relatively minor in the context of this claim as whole” and to suggest that_ _“they are at least_
_indicative of the reality” that the Claimants were under the effective authority and control of the guards_
_“rather than being free”. These instances are disputed on the facts by Mr Palmer. They were not_
specifically pleaded in the Statements of Facts and Grounds of any of the Claimants, still less pleaded as
specific instances of false imprisonment or deprivation of liberty, although there are broad allegations that
the guards locked the gates “on several occasions” pleaded by XD and YZM. In the light of these
considerations, and the way that the case was argued on both sides at the hearing, I therefore propose to
treat these allegations as contextual evidence as opposed to free standing claims. In any event, had I
treated these incidents as claims, I would have preferred the evidence of Mr Palmer, applying **McVey**
principles, there being no clear reason to reject it.

283. There was no dispute between the parties as to the law. The issues were essentially ones of fact. On
the two main points, Ms Giovannetti submitted that:

i) There was no curfew – there was merely an expectation that asylum seekers would be in the Barracks
overnight from 10pm onwards;

ii) The 15 January 2021 letter may have been strongly worded, and not as clear as it might have been, but
it was doing no more than to remind, or advise, the residents to abide by the Covid rules. That is illustrated
by the fact that the letter provided links to relevant guidance on this subject. Residents were not prevented
from leaving the Barracks, as is apparent from the fact that some did so during the relevant period. Insofar
as some were then arrested and/or subjected to fixed penalty notices, that was as a result of operational
decisions of the Kent police for which the Defendant was not responsible or, at least, could not be held
liable. In any event none of the asylum seekers had any legitimate reason to leave the Barracks and any
award of damages should therefore be nominal only.

284. In relation to the specific instance of alleged detention in the case of OMA, Ms Giovannetti invited me
to accept the Defendant's evidence and, accordingly, to find that these events did not involve imprisonment
or deprivation of liberty.


-----

intervening) [2021] EWHC 1489 (Admin)

285. Ms Giovannetti made clear that if I held that the Defendant did imprison the Claimants or any of them
or deprive them of their liberty for the purposes of Article 5, the Defendant was not advancing any
argument that this was lawful or justified.

286. Although it appeared from Ms Giovannetti's skeleton argument that there may be an issue as to
whether the Defendant was vicariously liable for the actions of others, including the contractors and the
police insofar as they amounted to detention, ultimately she did not dispute that the Defendant would be
liable for the actions of Clearsprings. To my mind, this was consistent with her Detailed Grounds of
Defence which did not appear to take issue in relation to this point and, indeed, specifically pleaded that, in
writing the 15 January 2021 letter, Clearsprings were acting with the authority of the Defendant: see
paragraph 128.

**Legal principles**

287. The relevant legal principles for present purposes are helpfully set out in two key decisions. As far as
false imprisonment at common law is concerned, the Claimants rely on R (Jalloh) v Secretary of State for
**the Home Department [2020] 2 WLR 413UKSC. In Jalloh the Secretary of State served the claimant with**
a notice of restriction under which a curfew was imposed on him pending his deportation. The notice, which
contained an express warning of criminal liability in the event of breach, provided that the claimant was
required to be present at a particular address between the hours of 11.00 pm and 7.00 am every day and
was to be monitored by electronic tagging. The Supreme Court held that this amounted to imprisonment.
Since there was no power to impose the curfew, the imprisonment was unlawful.

288. At [24] Baroness Hale, with whom Lords Kerr, Carnwath, Briggs and Sales JJSC agreed said this:

_“24 As it is put in Street on Torts, 15th ed (2018), by Christian Witting, p 259, “False imprisonment involves_
_an act of the defendant which directly and intentionally (or possibly negligently) causes the confinement of_
_the claimant within an area delimited by the defendant.” The essence of imprisonment is being made to_
_stay in a particular place by another person. The methods which might be used to keep a person there are_
_many and various. They could be physical barriers, such as locks and bars. They could be physical people,_
_such as guards who would physically prevent the person leaving if he tried to do so. They could also be_
_threats, whether of force or of legal process.” (emphasis added)_

289. She went on to say, at [25], that on the facts there was no doubt that between 11pm and 7am the
claimant was imprisoned.

_“There was no suggestion that he could go somewhere else during those hours without the defendant's_
_permission”._

290. At [26]-[27] she said:

_“26 The fact that the claimant did from time to time ignore his curfew for reasons that seemed good to him_
_makes no difference to his situation while he was obeying it. Like the prisoner who goes absent from his_
_open prison, or the tunneller who gets out of the prison camp, he is not imprisoned while he is away. But_
_he is imprisoned while he is where the defendant wants him to be._

_27 There is, of course, a crucial difference between voluntary compliance with an instruction and enforced_
_compliance with that instruction. The Court of Appeal held that this was a case of enforced not voluntary_
_compliance and I agree. It is not to be compared with those cases in which the claimant went voluntarily_
_with the sheriff's officer. There can be no doubt that the claimant's compliance was enforced. He was_
_wearing an electronic tag which meant that leaving his address would be detected. The monitoring_
_company would then telephone him to find out where he was. He was warned in the clearest possible_
_terms that breaking the curfew could lead to a £5,000 fine or imprisonment for up to six months or both. He_
_was well aware that it could also lead to his being detained again under the 1971 Act. All of this was_
_backed up by the full authority of the state, which was claiming to have the power to do this. The idea that_
_the claimant was a free agent, able to come and go as he pleased, is completely unreal.”_


-----

intervening) [2021] EWHC 1489 (Admin)

291. The Supreme Court also rejected an argument that the concept of imprisonment at common law
should be aligned with the concept of deprivation of liberty under Article 5 ECHR. At [29] Baroness Hale
noted the following definition of this concept in Guzzardi v Italy (1980) 3 EHRR 333, [92]:

_“In order to determine whether someone has been deprived of his liberty            within the meaning_
_of article 5, the starting point must be his concrete situation and account must be taken of a whole range of_
_criteria such as the type, duration, effects and manner of implementation of the measure in question.”_

292. She went on to say:

_“The ECHR distinguishes between the deprivation and restriction of liberty and the court emphasised that_
_this was a matter of degree rather than nature or substance (para 93). This multi-factorial approach is very_
_different from the approach of the common law to imprisonment.”_

293. In relation to Article 5, the Claimants also rely on **AP v Secretary of State for the Home**
**Department [2011] 2 AC 1which considered whether subjection to a control order pursuant to section 2,**
_[Prevention of Terrorism Act 2005,amounted to deprivation of liberty and held that it did. The order](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C690-TWPY-Y013-00000-00&context=1519360)_
subjected the controlee to a 16-hour curfew and electronic tagging, together with a number of other
restrictions on association and communication. He was required to move to an address in a Midlands town
some 150 miles away in order to make it more difficult for him to see his extremist associates. However,
his mother was not able to visit him at all, and his brother only visited twice after he moved to the Midlands,
owing to their personal circumstances. The judge held that the overall effect of the 16-hour curfew and the
controlee's social isolation, particularly through being separated from his family, constituted a deprivation of
liberty in breach of Article 5. He therefore quashed the obligation to live in the Midlands.

294. The Supreme Court agreed. At [1] Lord Brown noted that in **Secretary of State for the Home**
**Department v JJ [2008] AC 385, by a majority of three to two, the House of Lords had held that:**

_“deprivation of liberty might take a variety of forms other than classic detention in prison or strict arrest . . ._
_the court's task was to consider the concrete situation of the particular individual and, taking account of a_
_whole range of criteria including the type, duration, effects and manner of implementation of the measures_
_in question, to assess their impact on him in the context of the life he might otherwise have been living . . .”_

295. At [2] Lord Brown noted that in the context of control orders:

_“the judge has to decide as a matter of judgment, whether the restrictions overall deprive the controlee of,_
_rather than merely restrict, his liberty.” (emphasis added)_

296. At [3] he said that the duration of a curfew was not the sole criterion of loss of liberty and at [4] he
added:

_“I nevertheless remain of the view that for a control order with a 16-hour curfew (a fortiori one with a 14-_
_hour curfew) to be struck down as involving a deprivation of liberty, the other conditions imposed would_
_have to be unusually destructive of the life the controlee might otherwise have been living.”_

**Findings on Ground 4**

The overall context.

297. Ms Giovannetti agreed that I should take into account the overall context when interpreting the
evidence as to what was said to the Claimants, what happened and what impact it had. The context, in my
view, includes the conditions in the Barracks as well as the fact that their being surrounded by a fence with
barbed wire _“does create a perception of an austere environment (detained)”, as the Defendant_
acknowledged when considering their proposed use. It is also relevant that the residents were asylum
seekers and therefore in an inherently insecure position and less likely to be willing to challenge what they
saw as the authorities. The fact that there were gates which were padlocked and that entry to, and exit
from, the Barracks required the residents to ask a uniformed security guard to unlock, and to sign in and
out using a log book, is bound to have added to the feeling that they were subject to control of their
movements in and out of the Barracks


-----

intervening) [2021] EWHC 1489 (Admin)

298. I agree with Mr Hickman that it is also relevant that there were restrictions on visitors to the Barracks.
Ms Sally Hough of Care4Calais Folkestone gives evidence that, from 9 November 2020, charities and
other visitors were required to seek permission in advance. Mr Palmer accepts that there were times when
access to the Barracks was, as he puts it, _“blocked” albeit he says that this was a response to protest_
activity outside the gates. In a particularly striking piece of evidence, Ms Hough says that Clearsprings also
attempted to introduce a requirement to sign a “Confidentiality Agreement for External Parties”. This
deemed charity and NGO workers to be representatives of Clearsprings and bound them to secrecy in
relation to any information provided directly or indirectly to them by Clearsprings which concerned,
amongst other things, conditions in the Barracks and any resident. The person signing was required to
acknowledge and accept that the _“Official Secrets Acts 1911-1989” applied to these matters. The_
workers/volunteers refused to sign, and the requirement was withdrawn, but this is a further indication of
the control which Clearsprings believed it was entitled to exert over the residents.

299. It is not necessary for me to explore the question whether Clearsprings had any lawful authority for
these aspects of its approach. I make these points simply to highlight that the context for considering the
particular allegations of false imprisonment/deprivation of liberty in this case is one in which the Barracks
already felt to the residents “like a detention centre or prison camp”. Others have made a comparison to an
open prison. On the evidence, it is understandable that they should do so even if the formal position was
that they were free to come and go. HMCIP also found that:

_“A number of residents described feeling trapped in poor conditions and feared that if they moved out they_
_would jeopardise their only source of support, and potentially their asylum cases. Some told us they had_
_been shouted at and intimidated by members of the public who did not want them there and that this made_
_them reluctant to leave the camp before the COVID-19 outbreak.”_

The alleged curfew

300. The Claimants' case is that the residents were told that they had to be in the Barracks between 10pm
and 6am on pain of being locked out and treated as an absconder. The claim that there was a curfew is
also supported by some of the Defendant's documents. In particular:

i) The _“Contingency Asylum Accommodation Ministry of Defence sites Factsheet” dated October 2020_
states that the residents “are not being detained and so are free to come and go but are expected to be on
_site overnight”._

ii) The email dated 1 October 2020 from Alex Kane, AS Compliance Officer at UKVI, to Clare Dale G7
Asylum Support Contracts (ASC) Operations UKVI states “There is a curfew time of 10pm for SUs who are
_off the site. They can otherwise come and go as they please but must sign in and out. There is a process_
_of chasing up SUs who have not returned on time.”. (emphasis added)_

iii) The “Napier Inspection Report”, dated 13 November 2020, states that “The gates are locked at 10pm.
_Any SU who is not back by this time is telephoned. If they do not answer, they are marked as absconded_
_the following day” (emphasis added)._

iv) The Induction Briefing exhibited to Mr Palmer's witness statement states, under the heading _“Time_
_away from the property and leave of absence”_

_“UKVI do not authorise time (overnight) away from the Initial Accommodation…._

_If you do stay away without consent, we will report you to UKVI as absconded._

_Should you then wish to return to the accommodation you will need to re-apply to UKVI via Migrant Help.”_
(emphasis added)

301. Mr Palmer says in his witness statement that:

_“There is an expectation (not a requirement) that asylum seekers are on site overnight and they are_
_requested to return to site by 10pm or to make their intentions known.”_


-----

intervening) [2021] EWHC 1489 (Admin)

302. He goes on to say:

_“In practice there is no consequence to returning to the site after 10pm other than a phone call to the_
_individual to check that they are safe, there may be also be additional questions when they arrive back at_
_site to ensure that the individual is a resident at Napier. The site management have informed me that on_
_some occasions individuals have returned late at night intoxicated and allowed on to the site but asked not_
_to enter their dormitories until they sober up a little.”_

303. He accepts that _“communication has not always been clear and consistent” and he refers to Alex_
Kane's email of 1 October 2020 and the Napier Inspection Report dated 13 November 2020, apparently as
examples of this. However, he acknowledges that he had not spoken to Alex Kane about his email
although he had apparently spoken to the manager of the team which carried out the inspection who
confirmed to Mr Palmer that ““curfew” is used as a loose term that refers to a general expectation that
_individuals would return to the site by a given time and akin to a “coming home time” rather than a_
_requirement”._

304. Mr Palmer does not directly comment on the passage from the Induction Briefing referred to above,
although this document is exhibited later in his statement for the purposes of supporting the Defendant's
case that arrivals at the Barracks are provided with information about services related to their health and
well-being. However, it may be that the Induction Briefing is what Mr Palmer had in mind when he
asserted, at paragraph 10 that “Some of the documentation provided to individuals is unclear on this matter
_and incorrectly states that being absent overnight may result in the individual being classed as an_
_absconder, in practice those processes do not commence if an individual is away for a single night.”_

305. With respect to Mr Palmer, his evidence is to some extent at odds with the documentary evidence
referred to at paragraph [300] above. The furthest he goes in addressing that evidence is to offer a
potential explanation of the use of the word “curfew” in Alex Kane's email of 1 October 2020. This does not
address the statement in that email that “They can otherwise come and go as they please” but, more
importantly, it does not begin to address the statement in the 13 November 2020 Inspection Report, nor the
passage in the Induction Briefing, neither of which uses the word “curfew” but both of which purport to state
the factual position in terms of what is required of the residents, and the consequences if they do not
comply.

306. However, HMCIP found:

_“Residents had previously been allowed to leave the site unaccompanied and could stay away for 24_
_hours, though they were required to sign in and out. If they remained out after 10pm, site staff contacted_
_them to check on their welfare. Staff and residents told us that there was a degree of flexibility in the_
_agreed return time as long as they had contacted the site. Many residents told us they did not go out. Logs_
_were not always legible, but some showed that residents regularly left the site.” (emphasis added)_

307. The evidence of the Claimants themselves is also thin on this issue, although other witnesses report
that they were told that there was a curfew or had the impression that there was one. Three of the
Claimants make no reference at all to a requirement to be in the Barracks overnight. M mentions in passing
that “we were allowed outside until 10pm” but says no more on the subject. XD and YZM do say there was
a curfew between 10pm and 6am and that they were told that they would not be allowed back in if they
returned after 10pm. YZM says that this actually happened to a friend but neither XD nor YZM appear to
have put this to the test themselves. The effect of their evidence is that they had to be back by 10pm if they
wanted to sleep at the Barracks, but that is not the same as a requirement to be at the Barracks overnight.
Mr Hickman also made clear that the Claimants did not place reliance on the Induction Briefing because
they were unaware of it.

Conclusion on the alleged curfew

308. On balance, I therefore prefer the Defendant's case on this issue. There clearly was an expectation
that those who wished to sleep overnight at the Barracks would be back by 10pm and, perhaps, that they
o ld be there o ernight in an e ent B t the act al Claimants' e idence is not to the effect that the ere


-----

intervening) [2021] EWHC 1489 (Admin)

told that they would automatically be treated as having absconded if they did not return, nor suffer any
sanction other than being locked out for the night. The Defendant's documentary evidence is not entirely
consistent as to the position but, aside from the Induction Briefing, the furthest it goes is that they would be
treated as absconders from the next morning if they did not answer the phone call from the Barracks. The
HMCIP's finding, set out above, is broadly consistent with this position and I note that it is based on
conversations with residents. Overall, then, I do not consider that the curfew was a rule which was
enforced by the sanction of being treated as an absconder; on the evidence, it was an expectation which
might lead to sanctions if there was reason to believe that the resident had absconded.

309. I therefore reject this claim at common law and under Article 5.

The 15 January instruction

310. Mr Palmer's witness statement explains that the context for the 15 January 2021 letter was that there
were very real concerns about the Covid-19 outbreak in the Barracks. These concerns included that
residents would leave the site when they ought to be self-isolating and/or would spread infection in the
local community and that this, in turn, would increase existing tensions in the local community. The advice
from health agencies was that the whole site should be asked to self-isolate and all residents should be
treated as having tested positive, or as having been in close contact with someone who had tested
positive. The police also asked that the gates remain padlocked and that they be notified of anyone leaving
site whilst they were in the process of establishing a presence outside the gates to the Barracks.

311. It appears that before the letter of 15 January 2021, groups of 20 and then 16 residents left the site
that day, although they were told not to. The police were about to ring their patrols about this. Tensions
were running high. However, the plan was “to lockdown the site and now communicate the message about
_this and compliance.”_

312. The letter of 15 January 2021 stated, so far as material:

_“Dear Service Users,_

_We have been advised that someone you live with may have symptoms that could be linked to COVID-19_
_therefore we have had no choice but to put the camp into isolation._

_Before and after this outbreak we have reiterated the importance of complying with the Public Health_
_Guidance. It is a legal requirement that everybody follow the law._

_There are now restrictions in place at the site. You are not to leave the site under any circumstance. The_
_Police are aware of the situation and if you have been found to disregard this advice, the Police may issue_
_you with a Fixed Penalty Notice or you may be arrested._

_It is therefore essential that for your own safety and to prevent further transmission of the virus, you comply_
_with the law by not leaving the site._

_Please help us to help you._

_To help you keep safe we intend to begin mass testing on site imminently and we will keep you fully_
_informed of this. ….._

_The following links will also assist you._

_…. [links to Doctors of the World and to government guidance on the stay at home policy, on social_
_distancing and for vulnerable people and on the national lockdown were then provided] …_

_If you require further advice please contact NHS Direct on 111, and if you need any assistance with this_
_please ring Migrant Help and ask for your Housing Officer to call / visit you - 0808 8010 503 …”_

313. On 18 January 2021, a local vicar wrote to Mr Millard of SESPM to say that he had heard that there
had been an outbreak at the Barracks and that no attempts were being made to segregate the residents.
Mr Millard assured him that steps were being taken to address the situation and that “The site is now


-----

intervening) [2021] EWHC 1489 (Admin)

_required to isolate and residents are therefore required to stay on site……Asylum seekers have been_
_advised of the legal obligation not to leave the site – this is set out in writing (to be translated) and_
_explained through interpreters” (emphasis added). Mr Millard repeated this message in an email to all_
relevant NGOs on the same day.

314. Mr Palmer exhibits the logbook for 16 January 2021 which appears to show a small number of
residents leaving site that day. Ms Giovannetti also relied on the notes of the SESPM meeting on 18
January 2021 which record that a Jess Harman, of the FHDC Community Safety Unit, had been to the site
and had been told that 45 residents had been off site (although it is not clear whether this was on one day
or since the outbreak) and that 15 were still absent when she was there. The notes of 19 January 2021
record that someone had said that residents were continuing to leave site to go to shops for minor items
and that this was not a sufficient reason to do so. A negative test did not mean that they could leave site,
but 19 residents had done so. The police had been called but it was onerous for the site management to
keep doing this. The notes of the meeting on 21 January 2021 record the following statement from one of
the attendees: “Staff constantly advise not to leave the camp, but they still choose to do that. They cannot
_be locked on site”._

315. A further letter to residents dated 28 January 2021 stated, so far as material:

_“If you are asked to move, please cooperate, and follow the instructions of the site managers. –_

_Because there are still some people with Covid-19 infections on the site and in line with government_
_COVID regulations it is extremely important that you continue to self-isolateand do not leave the site…._

_Once the moves have taken place you will be in a new 'bubble' with those that you are living with, in a_
_block. It is important that you do not mix with people outside of that 'bubble'. …. If there are no new cases_
_within your 'bubble' we will be able to end the period of self-isolation after 10 days. If there are further_
_cases, you will be kept informed of any change to the date that self-isolation ends…._

_…We will notify you when your period of self-isolation has ended. When you receive this notification_
_from us, you will be allowed to leave the site for a limited number of reasons in line with national law that_
_applies to everyone…. (underlining added)_

316. It appears to be this letter which led to the disturbances on 29 January 2021.

317. HMCIP found that:

_“…Residents at both sites were usually able to come and go. The exception was during the major COVID-_
_19 outbreak at Napier, when over a hundred people were confined to their billets for approximately four_
_weeks and unable to go outside except to use the mobile toilets or showers. They were warned that they_
_might be arrested if they left the camp. In at least one case, a resident was forcibly returned to the camp by_
_the police.”_

318. On 26 February 2021 Ms Creffield visited the Barracks, as noted above. She instructed that the
padlocks be removed from the gates. Pursuant to an undertaking which Chamberlain J had required to be
given to the court at the permission hearing, as a condition for delaying the full hearing to the Easter Term,
on 28 February 2021 a letter was sent to residents which made clear that they were not detained, and were
free to come and go, but asked them to sign in and sign out for their own safety. The letter also explained
to them the true position in terms of the then Covid regulations i.e. that it was permissible to leave home for
certain reasons which were set out in the letter. Ms Creffield also sent an email to Clearsprings which
emphasised that the residents were not detained and were not subject to a curfew. Ms Creffield also raised
concerns about what was said in the induction materials about there being a curfew and put in train a
process which she intended to result in the offending passages being amended.

Discussion and conclusion on the 15 January instruction.

319. Mr Hickman developed arguments that the Defendant was not entitled to require the residents to selfisolate because the letter of 15 January 2021 did not constitute valid notification of the duty to self-isolate


-----

intervening) [2021] EWHC 1489 (Admin)

under penalty of law for the purposes of Regulation 2(1), Health Protection (Coronavirus, Restrictions) (Self
Isolation) (England) Regulations 2020/1045. He said that this was because it did not notify them that they
or a particular person of whom they were a close contact had tested positive, and because it was not a
notification by the Secretary of State for Health and Social Care as, he argued, was required. Ms
Giovannetti disputed these arguments but she also pointed out that the key issue was whether the 15
January 2021 letter had the effect of imprisoning the Claimants or depriving them of their liberty given that,
if it did, she was not seeking to argue that this was lawful.

320. Assuming for the sake of argument that the letter of 15 January 2021 did constitute a valid notification
under Regulation 2(1), the duty to self-isolate permitted a person to leave the place where they would
otherwise be required to remain, where necessary, for various purposes which are potentially relevant in
this case. These included to seek medical assistance including dental services and services relating to
mental health, to avoid a risk of harm, to obtain basic necessities for a member of their household and to
access critical public services: see Regulation 2(3)(b). However, the letter did not point any of this out.
Rather, it clearly instructed the residents not to leave the Barracks under any circumstances. This was said
to be the residents' legal obligation when in fact it was not. They were also threatened with arrest or a
fixed penalty notice if they disobeyed. The impression which this gave was reinforced by a police presence
outside the gate, and by residents seeing people arrested as they tried to leave. The Claimants also report
seeing residents being prevented by security guards from leaving and YZM says that he himself was
prevented from doing so. The instruction of 15 January 2021 and the impression which it gave were further
reinforced by the letter of 28 January 2021.

321. The terms and the effect of the 15 January 2021 letter therefore went beyond merely advising the
residents of their legal duty to self-isolate as Ms Giovannetti argues. The letter instructed the residents to
remain in a particular place, stated that the instruction was underpinned by law and threatened that the
instruction would be enforced by legal process. And it did so in a context in which the overwhelming
likelihood was that the contents of the letter would be taken at face value and that the majority of residents
would not be willing to challenge what was said.

322. It seems to me to be no answer for the Defendant to say, particularly in the context which I have
outlined above, that if the residents had researched the matter by clicking on the links which the 15
January 2021 letter provided, they might have discovered that the terms of the letter were inaccurate and
unlawful and then chosen to ignore or challenge it. The instruction in the letter was clear, as was the threat
of enforcement by legal process, and residents were aware from what they saw that this was not an idle
threat.

323. Nor, in my view, is it an answer to say that there were examples of residents choosing to leave the
Barracks. In the case of the particular Claimants in these proceedings it appears that, although they may
not all have read the 15 January letter itself, their understanding was consistent with its contents. Other
than in the case of YZM, there is no evidence of them doing anything other than taking the position at face
value and remaining in the Barracks as instructed. No evidence has been presented, for example, of any of
them successfully leaving the Barracks during the lockdown period. Given that it appears from Mr Palmer's
evidence that the logbook has been examined for the purposes of this aspect of the Claimants' claim one
would have expected evidence of this to be produced if it existed.

324. The reality, it seems to me, is that the residents understood that they were being held in the Barracks
and they were right. That is one of the key reasons why there were the disturbances in late January 2021.
Some residents may have chosen to defy the order, but that does not affect the position of those who
obeyed it. I therefore uphold this claim in the case of each of the Claimants at common law and under
Article 5.

325. As to Ms Giovannetti's submission that I should rule that the Claimants are entitled to nominal
damages only on the basis that they had no lawful cause to leave the Barracks in any event, I see the force
of the point but prefer to leave this issue open at this stage. The question of quantum in the event that the
Claimants succeeded on any of their claims was not an issue to be determined at this stage and I am


-----

intervening) [2021] EWHC 1489 (Admin)

unwilling to shut the Claimants out on this issue without them being given the opportunity to present
evidence. Certainly, in the case of NB he was prevented by the Defendant from leaving the Barracks,
ostensibly on the grounds of the lockdown, and his release therefore had to be ordered by Mr Clive
Sheldon QC (see, further, the Annex below). His, then, would not seem to be a case for nominal damages
only.

The alleged detention of OMA between c18 and 25 January 2021.

326. I note that this allegation relates to the specific treatment of OMA during the post 15 January period.
In his first witness statement, dated 28 January 2021, OMA recounted how he developed Covid-19
symptoms and then tested positive on 11 January 2021. He said that, on 18 January 2021, he was told to
move to the games room which now had no furniture, other than some cupboards, and eight mattresses on
the floor. The doors were locked, there were security guards on the door and no residents were allowed to
go in or out. “For the first few days there wasn't even access to a toilet and it never had a shower. I don't
_remember when exactly but after some time they brought toilets that we could use but no showers”._
(emphasis added)

327. Mr Palmer consulted the site manager, who disputed this account. Mr Palmer set out the manager's
version of events at paragraph 16 of his witness statement which, in summary, agreed that the recreation
room was reconfigured to serve as a place for residents who had tested positive to self-isolate but said that
there were 21 sets of beds and lockers. The recreation building has six toilet cubicles, four urinals and
three sinks. There were also shower pods allocated to the building which gave access to four showers
outside the door of the building. There were two security guards – OMA agrees on a rota basis - but the
doors were not locked, and people were allowed to leave; indeed, they were encouraged to use the space
in the front of the block for exercise.

328. OMA then served a statement in response, dated 30 March 2021, which stated that the passage in
his first witness statement which said _“I don't remember when exactly but after some time they brought_
_toilets that we could use but no showers” is in fact a translation error. They did bring showers. He did not_
suggest that the statement that _“For the first few days there wasn't even access to a toilet..” was a_
translation error but he accepted, without acknowledging the change in his evidence, that there were toilets
and sinks albeit he remembered fewer than Mr Palmer said there were. He also confirmed Mr Palmer's
evidence that shower pods were brought to the building and located outside the door, albeit with some
quibbles as to timing, number and precise location. He went on to say that the showers were guarded by a
fence which prevented the residents from escaping from the recreation room and that he was only
permitted to leave the room to use the toilet facilities. He also alleged that there were 7 or 8 beds, rather
than 21 as Mr Palmer said.

329. Ms Creffield responded to this evidence in her second witness statement dated 13 April 2021, the
position having been checked again with NACCS and Clearsprings. She confirms the essentials of the
account given to Mr Palmer. NACCS have confirmed that when the recreation room was reconfigured, two
sets of 11 beds were put in on 14 January 2021 (so 22, not 21). The room was not locked. Two of the
doors had “push bars” and could therefore readily be opened. The role of the guard was to ensure that no
unauthorised person entered, and to be available if needed by the residents of the block. There was
fencing placed around the showers (which I gather was about 4 feet high) but this was to prevent them
from being used by others. The fencing was later removed.

330. In my view the evidence relied on by the Defendant is to be preferred on this issue. There was no
application to cross examine Mr Palmer or Ms Creffield and I see no reason to conclude that their evidence
is unreliable on this point. Indeed, their account is consistent, and it is unlikely that anyone would be lying,
for example, about the number of beds or toilets. On this footing, aspects of OMA's account are materially
inaccurate. Moreover, OMA's initial account of not having access to a toilet _“for the first few days” was_
inaccurate by his own admission and rendered at least his initial account highly implausible. I also note that
he states that he was “very ill” with Covid-19 at the material time, which may account for the inaccuracies
in his evidence.


-----

intervening) [2021] EWHC 1489 (Admin)

331. I therefore dismiss this claim at common law and under Article 5.

**OVERALL CONCLUSION AND RELIEF**

332. I therefore allow the Claims on Grounds 1 and 2 and I allow them in part on Ground 4. The other
Grounds and claims are dismissed.

333. The parties should seek to agree appropriate declarations and directions for the quantification of
damages.

**ANNEX**

**OUTLINE FINDINGS IN RELATION TO EACH CLAIMANT**

**NB**

334. NB is an Eritrean national aged 24. There is evidence in his case of a history of torture and
trafficking/forced labour in Libya en route to the United Kingdom.

335. NB entered the United Kingdom in August 2020 on a lorry and claimed asylum. He was initially
accommodated in a hotel in London for around six weeks before being transferred to the Barracks in
September 2020.

336. NB was referred to his solicitors, DPG, on 7 January 2021, by Care4Calais. DPG sent a pre-action
letter to the Defendant on 11 January 2021.

337. Shortly after this, NB developed symptoms of Covid-19.

338. On 17 January 2021, Dr Galappathie provided a psychiatric report which diagnosed NB as suffering
from depression, generalised anxiety disorder and PTSD with severe symptoms. Dr Galappathie's opinion
was that NB's mental health had deteriorated whilst living at the Barracks and he recommended that NB be
transferred to alternative accommodation as a matter of urgency. His report was sent to the Defendant on
18 January 2021.

339. On 19 January 2021, the Defendant accepted that “there are indicators that suggest [the] client may
_be a victim of modern slavery” and agreed to transfer NB to alternative asylum support accommodation_
based on his individual circumstances. However, he was not transferred.

340. On 27 January 2021, proceedings were issued.

341. On 28 January 2021, there was a positive 'reasonable grounds' trafficking decision in NB's case.
However, on 29 January 2021, the Defendant declined to move him out of the Barracks because “Napier is
_currently under a lockdown following an outbreak of Covid-19. Accordingly, moving your client during this_
_time is not possible.”._

342. NB's transfer out of the Barracks was therefore ordered by Mr Clive Sheldon QC, sitting as a Deputy,
following an oral hearing on 2 February 2021. Mr Sheldon said:

_“I am told that the Secretary of State's policy is not to accommodate at Napier persons who are vulnerable,_
_including those with serious mental health issues. The evidence that I have seen strongly suggests that NB_
_falls into that category. He has been diagnosed as having severe mental health problems which, in the_
_opinion of a consultant psychiatrist, are being exacerbated by the conditions of his accommodation at_
_Napier.”_

343. He went on to find that:

_“On the available evidence, and in particular that from Dr Galappathie, NB will be at risk of harm if he_
_continues to stay at Napier. In my judgment, the evidence clearly satisfies one of the exceptions set out in_
_the Self-Isolation Regulations and so, in my view, there is no legal impediment to NB's removal”._

344. NB was transferred to alternative accommodation on 3 February 2021.


-----

intervening) [2021] EWHC 1489 (Admin)

**M**

345. M is a Sudanese national aged 21. His case history includes evidence of oppression by Sudanese
government militia, as well as torture and forced labour in Libya on his journey to the United Kingdom.

346. M arrived in the United Kingdom by boat on 1 September 2020 and claimed asylum shortly
thereafter. He was initially accommodated in a hotel in London for around four weeks before being
transferred to the Barracks in September 2020.

347. M was one of a number of residents who began sleeping outside in early January in protest at the
conditions including the lack of Covid-19 precautions in the Barracks. M also began a hunger strike.

348. On 5 January 2021 M's solicitor requested that he be referred to the NRM as a potential victim of
**_modern slavery._**

349. On 10 January 2021 Migrant Help referred M to the Home Office Safeguarding Team on the basis of
his hunger strike and because he was expressing suicidal ideation.

350. On 18 January 2021, Care4Calais referred M to the NHS safeguarding team in the light of concerns
that he posed a high risk of suicide. The referral was declined by the NHS on the basis that “we are unable
_to meet social care and housing needs”._

351. On 20 January 2021, a pre-action letter was sent by DPG followed by a second one on 26 January
2021. These letters informed the Defendant that he was subjected to forced labour whilst in Libya and that
a referral had also been made by Care4Calais to the NHS safeguarding team as they were worried that he
was at high risk of suicide.

352. On 29 January 2021, proceedings were issued.

353. On 30 January 2021, M was arrested following the disturbance and fire at the Barracks. He was not
charged but he was transferred to Tinsley House IRC. He continued to express thoughts of suicide. Whilst
at Tinsley House, M was assessed by Medical Justice who diagnosed him as suffering from moderately
severe depression and PTSD.

354. M was eventually transferred to alternative accommodation on 23 February 2021.

**F**

355. F is a stateless “Bidoun” born in Kuwait on 16 June 1985. There is evidence in his case history that in
2014 he was detained and tortured by the police following protests.

356. F arrived in the United Kingdom by boat in July 2020 and claimed asylum. He was initially
accommodated in a hotel in London, for around six weeks, before being transferred to the Barracks in
September 2020.

357. F was also amongst the residents who began to sleep outside in early January 2021, and, from 13
January 2021, he was refusing food.

358. F tested positive for Covid-19 on 17 January 2021.

359. On 20 January 2021, a pre-action letter was sent by DPG and, on 29 January 2021, proceedings
were issued.

360. On 31 January 2021, F was assessed by Dr Galappathie who diagnosed him as suffering from
depression, anxiety disorder and PTSD and noted that his mental health appeared to have worsened
significantly since being accommodated at the Barracks. He recommended that F be transferred urgently
to alternative accommodation in the community.

361. F was transferred out of the Barracks to hotel accommodation on 4 February 2021.

362. On 5 March 2021 he was transferred to dispersal accommodation in Liverpool.


-----

intervening) [2021] EWHC 1489 (Admin)

**OMA**

363. OMA is a national of Sudan. His date of birth is 14 September 1996. His case history includes
evidence that he was arrested and detained for alleged anti-government activities and was beaten,
electrocuted and waterboarded. He travelled to Libya but was detained by traffickers and subjected to
forced labour and torture for several months before he escaped.

364. OMA arrived in the UK on or around 20 October 2020 and claimed asylum on 21 October 2020. He
was then accommodated in a hotel in London.

365. OMA was transferred to the Barracks in November/December 2020 although the precise date was
unclear at the time of this judgment and was being investigated by the Defendant. He was told it would be
a temporary move and that he would be moved again soon.

366. OMA was initially sharing a 14-bed room. He was later moved to a single room in accommodation
block.

367. As noted above, on or around 10 January 2021 OMA began to experience symptoms of Covid-19
and tested positive. He was then moved to the games room where he stayed until 25 January 2021. OMA
underwent a second test for Covid-19 which was positive on 25 January 2021, but he was moved back to
his previous room on the same day.

368. On 21 and 26 January 2021, pre-action letters were sent by DPG.

369. On 1 February 2021 Dr Galappathie diagnosed OMA as suffering from severe depression, anxiety
disorder and PTSD and noted that his mental health had deteriorated since being accommodated at the
Barracks. He recommended that OMA be urgently transferred to alternative accommodation in the
community.

370. On 5 February 2021 Chamberlain J ordered that the Defendant transfer OMA to alternative
accommodation by 8 February 2021.

**XD**

371. XD is a Palestinian national, aged 30. His case history includes evidence that he was a victim of
domestic violence and persecution in Gaza from a young age, was detained and tortured by Fatah and has
scars from his torture.

372. He entered the United Kingdom by boat on 31 July 2020, claimed asylum on 1 August 2020 and was
screened that day. He was then accommodated in a hotel in Slough. On 23 September 2020, he was
moved to the Barracks.

373. On 8 January 2021, he informed Doctors of the World that he has physical injuries as a result of
torture.

374. On 14 January 2021, Matthew Gold & Co sent a letter before action to the Defendant requesting that
XD be moved to suitable accommodation. That request was refused by the Defendant on 1 February 2021.

375. On 20 January 2021, XD tested positive for Covid-19.

376. On 3 February 2021, Martin Spencer J ordered that XD be moved to alternative adequate
accommodation within 24 hours. XD was then moved to a hotel in Newham, London on 4 February 2021.

377. On 3 March 2021, XD attended a psychiatric assessment with Dr Lisa Wootton, Consultant Forensic
Psychiatrist, who diagnosed him as suffering from PTSD, complex PTSD and severe depressive disorder.

**YZM**

378. YZM is a Sudanese national from Darfur, aged 21. His case history includes evidence that he was
arrested, detained and tortured in Darfur and subject to electrocution. He fled Sudan through Libya, where
he was threatened, beaten and forced to work in conditions strongly indicative of modern slavery.


-----

intervening) [2021] EWHC 1489 (Admin)

379. YZM arrived in the United Kingdom by boat on 30 July 2020. He was detained on arrival and
screened on 1 August 2020 at Yarl's Wood He was then accommodated in a hotel until 23 September
2020, when he was transferred to the Barracks.

380. In December 2020, Care4Calais referred YZM to the Salvation Army as a potential victim of
trafficking. YZM was informed by Migrant Help that he had been accepted by the Home Office as such, but
he had not been provided with a reasonable grounds' decision at the time of the hearing.

381. On 15 January 2021, Matthew Gold & Co wrote to the Defendant requesting that YZM be moved
from the Barracks.

382. On 22 January 2021, the Defendant agreed to move YZM based on his individual circumstances but
failed to set out a proposal for his transfer or to transfer him.

383. On 23 January 2021, YZM tested positive for Covid-19.

384. On 4 February 2021, YZM issued these proceedings with an application for urgent consideration and
interim relief. On the same day, the Defendant moved YZM to a hotel in Newham, London.

385. On 3 March 2201, YZM was assessed by Dr Lisa Wootton, Consultant Forensic Psychiatrist who
determined that he would have met the diagnostic criteria of PTSD and severe depression while at the
Barracks but that that his condition had improved since his transfer.

**End of Document**


-----

