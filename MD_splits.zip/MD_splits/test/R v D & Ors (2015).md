# R v D & Ors (2015) [2015] EWCA Crim 2079

CA, CRIMINAL DIVISION

1505565 B1,1505563 B1, 1505566 B1

Davis LJ, Turner J and Common Serjeant

15/12/2015

[Neutral Citation Number: [2015] EWCA Crim 2079](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J6C-R591-F0JY-C3JK-00000-00&context=1519360)

No: 201505563 B1; 201505566 B1; 201505565 B1

**IN THE COURT OF APPEAL**

**CRIMINAL DIVISION**

Royal Courts of Justice

Strand

London, WC2A 2LL

Tuesday 15th December 2015


**R E S T R I C T E D  A C C E S S**

**B e f o r e:**

**LORD JUSTICE DAVIS**

**MR JUSTICE TURNER**

**THE COMMON SERJEANT**

**HIS HONOUR JUDGE MARKS QC**

(Sitting as a judge of the Court of Appeal Criminal Division)

**R E G I N A**

v

**"R", "P" & "D"**

Computer‑Aided Transcript of the Stenograph notes of

WordWave International Ltd trading as DTI

8th Floor 165 Fleet Street London EC4A 2DY


-----

Tel No: 020 7404 1400 Fax No: 020 7831 8838

(Official Shorthand Writers to the Court)

**Mr R H Christie QC & Mr N Karbhari appeared on behalf of the Applicant "R"**

**Mr D Harounoff appeared on behalf of the Applicant "P"**

**Mr R S Gioserano appeared on behalf of the Applicant "D"**

**Mr C Tehrani QC & Mr S Grattage appeared on behalf of the Crown**

J U D G M E N T

(As Approved by the Court)

Crown copyright©

1. LORD JUSTICE DAVIS: Section 71 reporting restrictions continue to apply to this judgment until further order.

2. In view of the urgency with which this matter has come before the court, we think it appropriate to announce our
decision first, we having considered all the arguments advanced to us, and we will then give our reasons.

3. The conclusion that all three members of this court have reached is as follows. We have previously granted
permission to appeal. We allow the appeal of the Crown insofar as it relates to the first defendant, "R". We dismiss
the appeal of the Crown insofar as it relates to the second and third defendants, "P" and "D". We will now give our
reasons for that conclusion.

4. Human trafficking, most notoriously perhaps in historic terms represented by the slave trade, has been going on
for many centuries. It has taken and continues to take many forms. In the present case the three defendants,
respondents to this appeal, are the subject of a single charge of conspiracy to arrange travel within the United
Kingdom for exploitation, the charge being by reference to an offence under section 4(2) of the Asylum and
Immigration (Treatment of Claimants, etc) Act 2004. On the prosecution case, the victims of the exploitation were
Hungarian workers, lured to the United Kingdom by, so it is said, false representations made in Hungary as to pay
and conditions and were thereafter the subject of exploitation whilst working for the Kozee Sleep group, a group of
companies with which each of the three defendants are connected and in respect of which the first defendant, R, is
essentially the controlling director and shareholder. It is said that some of such workers worked up to 18 hours a
day, sometimes for seven days a week, for derisory pay and being provided with squalid and overcrowded
accommodation. The gang masters, as it were, were alleged to be two Hungarians called Orsos and Illes.

5. The trial commenced in the Leeds Crown Court on 6th October 2015. The trial judge is His Honour Judge
Christopher Batty.

6. On 8th December 2015, at the close of the prosecution evidence and after receiving lengthy submissions, the
judge acceded to a submission of no case to answer made on the part of all three defendants. That ruling, if
justified, would have had the effect of terminating the entire proceedings.

7. The prosecution now seek to appeal against that ruling under the provisions of section 58 of the Criminal Justice
Act 2003. In the meantime, the trial has stood adjourned. The jury has not been discharged. Thus it is that the
matter has come before this court as one of urgency.

8. The principal questions which have been said to arise are whether the judge correctly construed the relevant
provisions of section 4(2) of the 2004 Act by reference to which the conspiracy was alleged to relate, and whether
he was justified in ruling that there was no case to answer on the evidence adduced by the prosecution as applied
to the provisions of the 2004 Act, correctly interpreted. However, it is right to say that the arguments before us have
matured somewhat and the focus increasingly has been on the issue of conspiracy, which is the offence charged.


-----

9. As we have indicated, we have previously today granted permission to appeal. The matter has proceeded as
the substantive appeal, all parties being ready and equipped to deal with the matter on a substantive basis. We
should record that the respondents, and particularly Mr Christie QC on behalf of the first respondent, had advanced
a number of asserted procedural irregularities and delays in pursuit of the application for permission to appeal. We
have taken them into account but were not dissuaded from granting permission to appeal simply by reason of those
matters.

10. It is appropriate to turn straight away to the provisions of section 4 of the 2004 Act:

"Trafficking people for exploitation

(1) A person commits an offence if he arranges or facilitates the arrival in the United Kingdom of an individual (the

'passenger') and ‑

(a) he intends to exploit the passenger in the United Kingdom or elsewhere, or

(b) he believes that another person is likely to exploit the passenger in the United Kingdom or elsewhere.

(2) A person commits an offence if he arranges or facilitates travel within the United Kingdom by an individual (the

'passenger') in respect of whom he believes that an offence under subsection (1) may have been committed and ‑

(a) he intends to exploit the passenger in the United Kingdom or elsewhere, or

(b) he believes that another person is likely to exploit the passenger in the United Kingdom or elsewhere.

(3) A person commits an offence if he arranges or facilitates the departure from the United Kingdom of an

individual (the 'passenger') and ‑

(a) he intends to exploit the passenger outside the United Kingdom, or

(b) he believes that another person is likely to exploit the passenger outside the United Kingdom.

(4) For the purposes of this section a person is exploited if (and only if) ‑

(a) he is the victim of behaviour that contravenes Article 4 of the Human Rights Convention (slavery and forced
labour),

(b) he is encouraged, required or expected to do anything as a result of which he or another person would commit
an offence under the _[Human Organ Transplants Act 1989 (c. 31) or the Human Organ Transplants (Northern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHJ0-TWPY-Y0HF-00000-00&context=1519360)_
Ireland) Order 1989 (S.I. 1989/2408 (N.I.21)),

(c) he is subjected to force, threats or deception designed to induce him ‑

(i) to provide services of any kind

(ii)to provide another person with benefits of any kind, or

(iii)to enable another person to acquire benefits of any kind, or

(d) he is requested or induced to undertake any activity, having been chosen as the subject of the request or

inducement on the grounds that ‑

(i) he is mentally or physically ill or disabled, he is young or he has a family relationship with a person, and


-----

(ii)a person without the illness, disability, youth or family relationship would be likely to refuse the request or resist
the inducement.

(5) A person guilty of an offence under this section shall be liable ‑

(a) on conviction on indictment, to imprisonment for a term not exceeding 14 years, to a fine or to both, or

(b) on summary conviction, to imprisonment for a term not exceeding twelve months, to a fine not exceeding the
statutory maximum or to both."

11. It may be noted that that section is entitled "Trafficking people for exploitation", but the word "trafficking" in fact
plays no part in the substantive provisions of section 4.

12. In addition, we have been referred to and have had regard to the provisions of section 5 of the 2004 Act, which
contain certain supplemental provisions. Although Mr Christie advanced brief arguments before us that they may
be of real materiality to this particular case, that is not a view which evidently the trial judge shared; and we
ourselves see no present reason for thinking that they have any real materiality to the circumstances of the present
case.

13. Some other points should perhaps be recorded at the outset.

[14. First, section 4 of the 2004 Act was substantially amended and recast by the Protection of Freedoms Act 2012](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JD-N4J1-DYCN-C16J-00000-00&context=1519360)
with effect from April 2013. However, it is common ground that, by reference to the dates of the alleged conspiracy,
the 2004 Act was to be applied to the circumstances of this case in its original form. Furthermore, the 2004 Act has
itself now been entirely superseded with effect from 31st July 2015 by the **_[Modern Slavery Act 2015,which has](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
significantly different, and in some respects rather more precise, wording as compared to the wording of the 2004
Act. It may be that having regard to the different wording of and definitions contained in the 2015 Act, some of the
problems thrown up by the present case possibly will not arise in the future so far as concenrs prosecutions brought
under the 2015 Act. But that is by the way.

15. The overall structure of section 4 of the 2004 Act is clear enough. Section 4(1) relates to arrival in the United
Kingdom. Section 4(2) relates to travel within the United Kingdom. Section 4(3) relates to departure from the
United Kingdom. So the focus of the section is, consistently with the notion of trafficking, on the movement of
passengers concerned.

16. In our view, it is important to bear in mind that this case has been charged as a conspiracy. The indictment, as
currently framed, reads as follows:

"STATEMENT OF OFFENCE

CONSPIRACY TO ARRANGE OR FACILITATE TRAVEL WITHIN THE UNITED KINGDOM FOR EXPLOITATION,
[Contrary to section (1) of the Criminal Law Act 1977.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)

**PARTICULARS OF OFFENCE**

[R, P & D] between the 1st day of January 2011 and the 1st day of December 2013 conspired together with Janos
Orsos, Ferenc Illes and other persons unknown to arrange or facilitate travel within the United Kingdom by
individuals in respect of whom they believed that an offence contrary to s.4(1) of the Asylum and Immigration
(Treatment of Claimants etc) Act 2004 may have been committed with intent to exploit those individuals in the
United Kingdom or elsewhere."

17. It is further important to bear in mind the provisions of section 1(1) of the Criminal Law Act 1977, by reference
to which the indictment is framed. The provisions of section 1(1) of the 1977 Act are as follows:


-----

"Subject to the following provisions of this Part of this Act, if a person agrees with any other person or persons that
a course of conduct shall be pursued which, if the agreement is carried out in accordance with their intentions,

either ‑

(a) will necessarily amount to or involve the commission of any offence or offences by one or more of the parties to
the agreement, or

(b) would do so but for the existence of facts which render the commission of the offence or any of the offences
impossible,

he is guilty of conspiracy to commit the offence or offences in question."

18. Two points flow from that. The first is that the essence of conspiracy is the agreement to commit the criminal
act. Actual participation thereafter in the commission of that act is not a statutory requisite, even though commonly
of course the prosecution will seek to adduce evidence of involvement and participation of the defendants in order
to help establish the existence of a conspiracy to which such defendant is party. Furthermore, as is elementary, if
there is participation, the roles of the conspirators may frequently differ and, yet further, different conspirators may
join a conspiracy at different times.

19. The second particular point to note is by reference to the decision of the House of Lords in the case of Saik

[2007] 1 AC 18, [2006] UKHL 18. By virtue of that decision, it becomes a requirement, by reference to section 1(1)
of the Criminal Law Act 1977, that the prosecution show knowledge or intent with regard to the relevant offence;
belief, let alone suspicion, is not enough. This last point may not perhaps necessarily have been appreciated by the
prosecution when these proceedings were first initiated. At all events, it is now common ground that the indictment
will require amendment, not least so as to delete the reference to the words "believe" and to substitute the word
"knew" in the particulars of the offence.

20. It therefore follows that the prosecution had and has to be in a position to prove against each defendant whose
case the jury will be considering at least the following: first, that such defendant had been party to an agreement to
arrange or facilitate the travel of passenger or passengers within the United Kingdom; second, that such defendant,
being a party thereto, knew that an offence under section 4(1) had been committed by some person; third, that such
defendant, being a party thereto, had himself an intention to exploit such passenger or passengers. As the
defendants have pointed out on this appeal, each such element has to be established with regard to each such
defendant; the separate elements cannot, as it were, be pooled as between the three defendants.

21. The background facts have been helpfully summarised in the various detailed written grounds put in before us.
For present purposes, and acknowledging that this by no means reflects the totality of the evidence thus far
adduced, the prosecution case has been this. It was alleged that the defendants had engaged Orsos and his
organisation to source for them cheap labour to work in their factories. In this context it may be noted that the
business concerned was a business called, putting it broadly, the Kozee Sleep group, comprising a number of
separate companies, albeit all closely connected with the first defendant R.

22. In 2013 West Yorkshire Police had started an investigation into the trafficking of Hungarian nationals from
Hungary to the United Kingdom for exploitation. The investigation revealed that the between 2011 and 2013, a
large number of Hungarian nationals, who were desperate for work due to the economic situation in Hungary, were
being encouraged to accept employment in the United Kingdom, with, so it was alleged, false promises that
included undertakings about employment on offer and the terms of employment. It is said that the false
representations included representation of good wages, the provision of accommodation and food once in the
United Kingdom and so on.

23. In the case of the majority of those who were to give evidence, Orsos, a Hungarian national and the principal
person behind this particular operation, would in the main arrange with others for the Hungarian nationals to enter
the United Kingdom and then their transportation within the UK to various parts of Yorkshire, and thence on to the


-----

various businesses where they were put to work, which included the Kozee Sleep business. Illes was closely
involved in these travel arrangements.

24. The reality is, according to the prosecution, that what the Hungarians faced in the United Kingdom was very
different from what had been represented to them. They found themselves in shared, cramped and overcrowded
and squalid accommodation. They were made to work at the respective businesses for long hours, sometimes
between ten and 18 hours a day, for up to seven days a week, and for the most part not receiving anything like the
wages which they had been promised. Indeed, the majority of the wages which they did earn were collected and
for the most part retained by Orsos and or Illes, who would collect the wages from the employer businesses and
then dole out relatively small sums to the individual workers. In addition, it was said that many of the workers were
required to do private work at weekends and sometimes in such spare time as they had. It is said that this was a
very lucrative business at least so far as Orsos was concerned.

25. The investigations of the police led them to, amongst others, the first defendant, Mr R, who was the managing
director and majority shareholder of a company called Hick Lane Bedding Limited, which would trade under the

name of Kozee Sleep. The two co‑accused, P and D, were two employees of Hick Lane Bedding Limited. Quite

what role and status they had as employees was in issue; certainly, the third defendant D was presented as being,
in effect, something of a "gofer".

26. There were various companies within the Kozee Sleep operation operating at addresses in West Yorkshire.
The prosecution's case was that the group was in very significant financial trouble and was seeking to ameliorate its
financial difficulties by the engagement of very cheap labour.

27. R had a controlling shareholding in Hick Lane Bedding Limited and was also the managing director. Members
of his family apparently worked within the organisation.

28. When the prosecution opened its case to the jury, the emphasis was very much on the alleged exploitation on
the part of Kozee Sleep so far as the Hungarian workers were concerned. The emphasis was on the very poor
rates of pay that they received, the conditions in which they worked, their living conditions and matters such as that,
and there was considerable emphasis on the deception which had been practised upon them which was said to
constitute the exploitation in this case.

29. Thus, the whole emphasis of the prosecution, as presented to the jury in opening, had been on the issue of
exploitation. But the defendants were to say that this represented a failure to focus on the specific requirements of
section 4(2) by reference to which the alleged conspiracy had been framed. In particular it was said that the
prosecution had failed sufficiently to focus on the ingredient of there being an agreement to arrange or facilitate
travel within the United Kingdom. It is said that the word "travel" within the United Kingdom barely featured, if at all,
in the prosecution opening, and indeed it played no part in the extensive interviews of any of the three defendants.

30. Mr Christie, in particular, on behalf of the first defendant, has accused the prosecution of "flip‑flopping". He has

said that the prosecution case has changed from time to time and that the defence has never really known precisely
how the case is being put. He further points out that the prosecution had told the jury in opening that the various
defendants were not charged with any criminal agreement to bring individual workers from Hungary itself. What
was then said was: "it's what happened to them when they arrived in the United Kingdom that matters". It may be
that this particular approach on the part of the prosecution explains why none of the defendants had been charged
with a conspiracy by reference only to section 4(1) of the 2004 Act.

31. It may be that the Crown case has, from time to time, changed or matured in the course of the trial, but that is
by no means an uncommon occurrence. So long as the Crown case as ultimately presented corresponds with the
statement and particulars of offence contained in the indictment, and so long as the defence sufficiently know the
case that they have to meet, that is not in itself a fatal objection; and we should record that, notwithstanding all the
vigorous complaints made during the proceedings below, and indeed on occasion to us, about the changes in the
prosecution case, there was no submission made to the trial judge that the defendants could not receive a fair trial
and there was no suggestion made to the trial judge that there has been any kind of abuse of process. As it seems


-----

to us, this court must proceed on the footing of the case as ultimately it was advanced to the judge and has since
been advanced to us.

32. One other point should also be made. Both Orsos and Illes have been charged on a separate indictment with
conspiracy to traffic individuals with intent to exploit, as well as other charges. Apparently these defendants were
not named on that particular indictment. Each of Orsos and Illes had, as we were told, pleaded guilty in the
Teesside Crown Court on 13th May 2014 and have received custodial sentences. However, it should be recorded
that in the present case the trial judge, in his discretion, has refused to allow the prosecution to adduce evidence of
those pleas of guilt in this trial.

33. Turning then to the course of trial, this, as we have indicated, has undergone some vicissitudes. At all events,
by the time the prosecution evidence was coming to its conclusion, as we gather, the trial judge was himself
querying just how the prosecution was proposing to put its case by reference to the offence as charged. The matter
was the subject of very detailed written submissions, including various written submissions sequentially put in by
the prosecution, as well as lengthy oral submissions. We gather that the submissions lasted overall the best part of
three days, separated by a weekend.

34. The judge in due course was to give a lengthy written ruling. In the course of that ruling he was to describe the
central submission of Mr Tehrani QC, appearing for the prosecution, as follows:

"He submitted that requesting workers as and when they were needed was arranging in the facilitation of travel. He
accepted that this put the defendants as end users of trafficked labour as there was no evidence that they
themselves had arranged or facilitated the travel but he argued that as end users they were covered by s 4(2)."

And again the judge ascribed to Mr Tehrani a similar submission in paragraph 46 of his ruling.

35. We should note that after the judge had delivered his ruling, Mr Tehrani submitted to him in writing that those
paragraphs had not in fact reflected the actual submissions of the Crown; and Mr Tehrani has made the like
submission to us. We simply note that the judge clearly was not sufficiently impressed by that point to alter his
ruling in this regard in any way.

36. We should state that the judge's ruling is conspicuously thorough and conspicuously carefully prepared; it has
all the hallmarks, if we may say so, of a very conscientious trial judge who is entirely on top of all the evidential
issues that had arisen in this complex case.

37. The ruling itself is structured in three distinct parts, after setting out at length the relevant factual background
and competing arguments. First, the judge dealt at paragraphs 39 to 62 of his ruling with the issue of whether the
prosecution had adduced sufficient evidence to enable a properly directed jury properly to conclude that the
defendants were party to an agreement to arrange or facilitate travel within the United Kingdom of the Hungarian
workers for the purposes of section 4(2) of the 2004 Act. On this aspect of the matter the judge found in favour of
all three defendants.

38. Second, as an alternative basis for his ruling, the judge went on to consider whether the prosecution had
adduced sufficient evidence to enable a properly directed jury properly to conclude that each of the defendants
knew that a section 4(1) offence had been committed.

39. Third, the judge went on to consider whether there was sufficient evidence to enable a properly directed jury
properly to conclude that each defendant intended to exploit the passenger or passengers.

40. On these last two aspects, that is to say knowledge and intent, the judge concluded that there was sufficient
evidence (in his phrase, "just enough evidence") of knowledge and intent on behalf of the first defendant and the
second defendant. But with regard to the third defendant, that is to say D, he concluded that there was insufficient
evidence both of such knowledge and of such intent on the part of the third defendant. That therefore was an
alternative basis for upholding the submission of no case to answer on the part of the third defendant.


-----

41. We think it is convenient to deal with this alternative approach of the judge first. In this context the judge had
directed himself properly in law, applying the Galbraith principles. He asked himself, entirely appropriately, whether
a jury, properly directed, properly could infer guilt, and he noted that it was not necessary for the prosecution to
[have to disprove at that stage all other possible alternatives: see, for example the case of Khan [2013] EWCA Crim](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5900-BRN1-F0JY-C0N0-00000-00&context=1519360)
_[1345. Since in our view the judge had directed himself properly on the applicable law and appropriate legal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5900-BRN1-F0JY-C0N0-00000-00&context=1519360)_
principles, the only issue for us, having regard to the provisions of section 67 of the Criminal Justice Act 2003, is
whether or not such ruling was one which it was not reasonable for the judge to have made.

42. We have received extensive written arguments on this point, supplemented by oral arguments before us today
on the evidence. We do not propose to set out the details of such evidence here in the interests of time. We have
borne all the points made in mind.

43. One point, however, should be noted. The first defendant, R, and the second defendant, P, do attack the
judge's ruling on the issue of knowledge and intent (namely that there was sufficient evidence for them to have a
case to answer on these points). But, on the face of it, section 58 of the Criminal Justice Act 2003 is directed only
at an appeal by the prosecution against a terminating ruling. It is not directed at cross appeals by defendants.

44. However, this particular point has been addressed by a constitution of the Court of Appeal in the case of K, B
[and A [2007] 2 Cr App R 15, [2007] EWCA Crim 971: see in particular at paragraphs 39 and 40 of the judgment](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SPK-6KT0-TWP1-70J2-00000-00&context=1519360)
delivered by the then President of the Queen's Bench Division, Sir Igor Judge. Applying that approach, this court
has jurisdiction.

45. In our view, it is appropriate for this court to consider whether or not the judge was entitled to rule as he did

against the first and second defendants on this issue for two reasons, both inter‑related. First, the judge was

making one overall ruling on the question of no case to answer. Self‑evidently, his ruling was to be read as a

whole, even if it contained certain alternative bases of reasoning. Secondly, each of Mr Christie and Mr Harounoff
(for the second defendant) have, perfectly properly, stated that if the appeal were otherwise to be allowed this
alternative part of the decision should be considered on the issue of whether it is necessary in the interests of
justice for it to be ordered that the proceedings be resumed. In our view, if one is to deal with that submission, this
court must have regard to the entirety of the judge's ruling; and in particular we must have regard not only to their
criticisms of the judge's decision on this aspect, but, in the alternative, we should have regard to their emphasis that
the judge had stated there only was "just enough evidence" on the issue of knowledge and intent. Accordingly, we
think it appropriate to rule upon that alternative finding of the judge with regard to all three defendants.

46. It is to be borne in mind that the judge had closely and carefully reviewed all the relevant evidence and all the
relevant arguments on those points at length. Our conclusion is that it was entirely reasonable for him to conclude
as he did. We refer in particular, without setting out, to paragraphs 72 and 73 and 82 and 83 of his ruling. We
reject the arguments raised on behalf of the first defendant, R, and the second defendant, P, to the contrary. In our
view, he was entitled to decide that these were matters for the jury.

47. Dealing with the third defendant D, where the judge reached a conclusion different from the conclusion which
he reached with regard to the first and second defendants, it is quite plain on the evidence, and as the judge
spelled out, that D's role and involvement was undoubtedly of a much lesser order than that of the other two
defendants for the reasons that the judge gave. The overall conclusion, in our view, that he reached in the case of
D, that is to say that there was no sufficient case to answer on these issues was, in our view, a reasonable
conclusion. As we have indicated, we think that the opposite conclusion that the judge reached with regard to the
first and second defendants, namely that the position was different from D, was simply to be explained by reference
to the different facts on the evidence thus far adduced.

48. Accordingly, insofar as the judge ruled in favour of the prosecution with regard to those two defendants, we do
not think that decision can be attacked as unreasonable. Equally, we do not think the prosecution can successfully
attack as unreasonable the judge's decision on these aspects as against the third defendant, D. That being so, the
case against D necessarily has to fail.


-----

49. All that having been said, we then turn to the first basis of the judge's ruling, which of course related to all three
defendants.

50. The relevant section of the judge's ruling essentially begins at paragraph 39 of the ruling. That states as
follows:

"S 4(2) of the Act is entitled trafficking people for exploitation. A conspiracy to commit such an offence requires the
prosecution to prove that these defendants had some involvement in the arrangement or facilitation in the travel of
the trafficked Hungarian workers."

51. Having so stated, the judge then went on to find in paragraph 40, amongst other things, that:

"None of the defendants are said to have any direct involvement in any of their [that is to say, the workers] travel or
arrangements for it."

52. The core of the judge's reasoning on this particular aspect of the case is contained in paragraphs 55 to 61 of
his ruling. It is necessary to set them out:

"55. Mr Tehrani says that this is not complicated. The court should go back to basics and consider the primary
material namely the statute. The court must then give the words of the statute their ordinary meaning. He suggests
that if one does that it would then be absurd to suggest that the arrangement or facilitation of travel did not include
employing people who you know have been trafficked. I disagree. The words of the statute are clear. In order to
be involved in an offence under s 4(2) a person must have arranged or facilitated in a person's travel. Simply
employing someone knowing that they have been trafficked even if you intend to exploit them yourself cannot in my
view come within s 4(2). A conspiracy to commit an offence under that section involves a conspiracy to arrange or
facilitate the person's travel.

56. There is no evidence that these defendants were involved in such an agreement. A request for a worker to
come to work for you and thereafter employing that person is not in my view arranging or facilitating the travel of
that person for the purposes of this section.

57. There is no evidence here that any of these defendants played any part in the travel of the Hungarian
complainants. They were brought to England by Orsos and or Illes. They were transported to Dewsbury by Orsos
Or Illes or one of his men. They were brought to work by Orsos or Illes or one of his men. They were recruited by
Orsos. They were made available by Orsos to the factory as workers and taken there by Orsos and his men.

58. The prosecution have tried at the 11th hour to suggest a greater involvement in the recruitment of the
Hungarian workers suggesting that they had been specifically recruited in Hungary to work at one of the factories.
This came at a time when it appeared to the prosecution that the submissions made on Friday about the legislation
being designed to cover those who employed trafficked labour did not appear to carry favour with the court. This
much was said by Mr Tehrani. The change of position is not supported by the evidence for the reasons that Mr
Christie outlined. It is clear from analysis of the evidence of the Hungarian complainants that Orsos recruited from
Hungary people to work at a number of different premises amongst which were an underlay factory, a metal coating
factory, another bedding factory in Dewsbury also featured. It is from this pool of trafficked workers that people
were drawn to then work at Kozeesleep or Lazeesleep when needed.

59. The most the evidence supports is the contention that the agreement was that Orsos and others with him would
supply labour when it was requested by someone at the factory. The prosecution is not able to say who made
those requests. A request for a worker in those circumstances does not constitute being involved in the
arrangement or facilitation of that person's travel.

60. If it were to be thought that this was enough it could only ever apply to [R]. There is no evidence that [P] or [D]
were party to such an arrangement in the first instance. It is not sufficient for the prosecution to suggest that
knowledge of this arrangement and keeping the workers in the position that they are in could be said to be evidence


-----

that they were a party to this agreement. There is no evidence that they procured any complainant in this case.
There is no evidence that they controlled who was employed there.

61. The prosecution has throughout attempted to shoehorn the facts into the legislation. I am told by Mr Tehrani
that this is the first time that those who have themselves had no involvement in the travel of trafficked workers have
been prosecuted. The fact that the prosecution has had so many goes to get the facts of this case to fit rather
highlights the problems with the facts of this case. This is a case about the employment of trafficked workers. It is
not about their trafficking."

53. We do, with all respect to the judge, have significant concerns about this approach. It may be that in some
respects the judge had been misled as to the Crown's approach, with the judge understanding that the Crown were
setting out to prove the actual involvement of each of these defendants in the actual arrangements or facilitation of
travel within the United Kingdom. Mr Tehrani has said to us that that had never been the Crown's position; on the
contrary, the Crown had always been seeking to emphasise that what they were seeking to establish was a
_conspiracy: precisely as was alleged on the indictment. The Crown had simply been seeking to respond to the_
judge's concerns about the involvement, or lack of it, of these defendants in the arrangement or facilitation of travel
within the United Kingdom.

54. Our own concern is that, as really will be self‑evident from numerous passages from this section of the

judgment, much of it reads as though the judge were focusing on the issue of whether or not there was some kind
of joint enterprise by reference to which each of these defendants, along no doubt with Orsos and Illes, were
actually involved in the substantive offence under section 4(2) of the 2004 Act: whereas of course what was being
alleged was a conspiracy.

55. The point of actual involvement is not the entire point of this case. It is not the entire point of this case just
because what had been charged here was a conspiracy. The question therefore which was the one to be asked
was whether there was evidence that the respective defendants were party to an agreement for the arrangement or
facilitation of such travel within the United Kingdom.

56. It has not been disputed before us that there was very clear prima facie evidence that Orsos and Illes, at least,
had arranged such travel within the United Kingdom of these Hungarian workers and had (as requested by Kozee
Sleep) delivered them on occasion to the Kozee Sleep factory or factories; that is to say, there was clear prima
facie evidence that there had been a substantive offence committed by at all events Orsos and Illes under section
4(2) of the 2004 Act. Further, there was prima facie evidence that the workers had been exploited at the Kozee
Sleep factory. It also can be said that, likewise, the inference could properly be drawn that at least one of the
respective defendants on behalf of Kozee Sleep had been party to an agreement that Orsos and Illes would so
arrange or facilitate such travel: that being one particular role of Orsos and Illes in this regard, along no doubt with
other roles as well, they having been requested to supply the labour. Nor does it matter that this was not the sole
purpose of the conspiracy. The point is that, by reference to section 1(1) of the Criminal Law Act 1977, the
implementation of the agreement as planned would necessarily involve the commission of the offence under section
4(2).

57. It is true, as has been pointed out to us today, that in the first sentence of paragraph 56 of his ruling, the judge
did direct himself that there was no evidence that the defendants were "involved in such an agreement". It is said
that there, as in passages elsewhere, the judge had indeed been focusing on the issue of agreement. But, with all
respect to the judge, in our view, such a passage, and a few other such passages to corresponding effect, are
vitiated by the focus otherwise being on the need to show actual involvement of the defendants in the actual
arrangement or facilitation of travel within the United Kingdom: as is illustrated by the judge's extensive exposition
in paragraphs 55, 57 and 58 of his ruling.

58. In short, the judge seems to have been focusing on whether or not there was a joint participation in the
substantive offence, as opposed to focusing on the necessary issue of whether there was participation in an
agreement with the relevant knowledge and intent.


-----

59. Moreover, it will be borne in mind that in paragraph 56 of his ruling (reflected also in the last sentence of
paragraph 59), the judge had said this:

"A request for a worker to come to work for you and thereafter employing that person is not in my view arranging or
facilitating the travel of that person for the purposes of this section."

We do not think that that can be taken, as a broad and generalised proposition, as a correct statement of the law.
In our view, one rather has to consider the particular circumstances of each case. It all depends.

60. Before us today, Mr Tehrani has accepted that mere employment by a defendant of someone who has been
trafficked does not, in itself, constitute an offence for the purposes of section 4(2). He accepts that there must be
something more. In our view, the point was neatly put by Mr Gioserano in his written submissions on behalf of the
third defendant, where he said this:

"A mere 'end user' or recipient of a person's services cannot, in law, be said to have arranged or facilitated that

person's travel ‑ more is required, such as actively procuring the services of a worker."

61. Mr Tehrani would say: that is precisely the position here. In our view, this is simply acknowledging that one has
to have regard to all the circumstances of the particular case; and the "something more" may in an appropriate case
indeed be found in, for example, the making of a request in circumstances where the arrangement or facilitation of
travel within the United Kingdom is necessarily an accompaniment to that request.

62. In our view, the evidence here thus was sufficient to enable an inference properly to be drawn to the effect that
here there was "something more" than mere employment of these workers at the factory.

63. The question which we then have to address is who was party to making such request and was party to that
"something more".

64. We interject that we were addressed at some length as to what the true interpretation of the words "arranges or
facilitates" in section 4 actually meant. In our view, as we see it, it may not perhaps be of great importance to
determine that point given that what is charged here is a conspiracy; although we accept that it may fall for direction
to the jury in the context at least of the evidence that Orsos and Illes had arranged or facilitated travel within the
United Kingdom.

65. We do, of course, entirely understand the defence point that these words are to be linked to the words "travel
within the United Kingdom" and that the subsection is to be read as a whole. Our view is that the words "arranges
or facilitates" are words of designedly wide import. That said, it seems to us that it is better not to seek to gloss or
explain such words. It may be that the word "facilitate" might appropriately be the subject of brief explanation to a
jury; the word "arranges" barely needs any explanation at all, it is a common word of English language. We were
referred to the provisions of the United Nations Protocol of 2000 relating to trafficking and in particular to
paragraphs 3(a), 5 and 9 of that protocol. We were also referred to the subsequent description contained in section
2(3) of the **_Modern Slavery Act 2015, which indeed to a considerable extent replicates some of the wording_**
contained in the 2000 Protocol.

66. In our view, however, it would be wise for a trial judge having to direct a jury by reference to section 4 of the
2004 Act in its unamended form, not to engage in any extended gloss on the words actually used; and it would, we
respectfully suggest, be positively unwise to start bringing in the definitions or descriptions contained in the 2000

Protocol or section 2(3) of the 2015 Act, which of course post‑dates the 2004 Act. In our view, it is much better

simply to let the jury focus on the words "arranges or facilitates" actually used without any further extended gloss.

67. We revert to the question still remaining to be asked: who on behalf of the Kozee Sleep can be said to have
committed the "something more"? In this context we should revert to what the judge said in paragraphs 59 and 60,
and in particular paragraph 60, where, we repeat, he said this:


-----

"If it were to be thought that this was enough it could only ever apply to [R]. There is no evidence that [P] or [D]
were party to such an arrangement in the first instance. It is not sufficient for the prosecution to suggest that
knowledge of this arrangement and keeping the workers in the position that they are could be said to be evidence
that they were a party to this agreement, there is no evidence that they procured any complainant in this case.
There is no evidence that they controlled who was employed there."

68. Mr Tehrani submitted that in this aspect the judge had wrongly appraised the position with regard to P and D
and had, in effect, entered into the jury arena. However, that paragraph has to be put into context with the various
other findings which the judge had made; we repeat, this being a judge who clearly had got to very close grips with
the entirety of the evidence in this case.

69. We think that the judge was entitled, with regard to P and D, to rule as he did in paragraph 60. He gave ample
reasons for that conclusion with regard to P and D. Indeed, the great majority of Mr Tehrani's arguments before us
today focused on the position of the first defendant, Mr R. R's position was clearly different. R had controlled the
Kozee Sleep operation. R had accepted in interview that he had in effect retained Orsos as a recruitment agency;
R had telephone contact with Orsos; R had, on the prosecution case, entrusted Orsos with the task of having the
workers delivered to the factory as and when needed.

70. Mr Tehrani did, nevertheless, also submit that the telephone calls evidence in particular did also sufficiently
implicate at least P (if not D) in being party to an agreement of the relevant kind. However, the judge was clearly
alive to that point. It may be noted that the schedule of telephone calls on which Mr Tehrani relied was simply that:
it showed telephone calls being made, it did not record the contents of them, and, as we gather, there was no
evidence of any relevant, let alone incriminating, texts at all. We do note the judge's finding on the evidence that
the prosecution was unable to say who had made the actual request. That, it should be added, needs to be put into
the context, so far as R is concerned, of the various admissions that the first defendant had made in interview,
which we need not summarise further here, and which are to be contrasted with the position of P as well as D.

71. Our overall conclusion is that we see no sufficient reason to depart from the judge's assessment on that
particular aspect of the case, as found by him in paragraph 60.

72. In saying that, we should record that we have hesitated somewhat in view of the judge's later finding, so far as

P was concerned, that there was sufficient prima facie evidence of him ‑‑ as well as R ‑‑ having the relevant

knowledge and intent. But even so, we think that that of itself is not enough; there has to be evidence of him having
been party to the conspiracy. And, as we have said, we think the judge was entitled to conclude as he did. By way
of contrast, the differentiations with the position of R (who also, and importantly, was alleged to have the knowledge
and intent) are clear and were spelled out by the judge and spelled out before us by Mr Tehrani.

73. It is for those reasons that we have concluded that there was here a case to answer as against the first
defendant R, but not (and as found by the judge) against the second and third defendants, P and D.

74. We think that, with respect, the error of the judge with regard to R involved an error of law, namely failing to
focus sufficiently on the ingredients of a conspiracy as opposed to the ingredients of the substantive offence under
section 4(2); and this in consequence caused the judge to make a ruling that it was not reasonable for him to make.
We therefore reverse that ruling with regard to the first defendant.

75. The question then remains with regard to the first defendant as to whether or not it is necessary in the interests
of justice for the trial proceedings to be resumed, they currently, as we have said, standing adjourned. Mr Christie
has addressed us on this and has advanced arguments as to why, he says, it is not necessary in the interests of
justice for these proceedings to be resumed.

76. We take a different view of the matter. We think it is necessary. This has been a long running trial, the jury are
waiting to come back and the charge is one of potential importance. We think it would be quite wrong, in the
circumstances, for this court not to order that the proceedings be resumed.


-----

77. We add only this. This case has been charged by reference to a conspiracy relating to section 4(2) of the 2004
Act. Precisely how matters of this kind are to be charged are a matter for the discretion of the prosecution. It is
noticeable that there is no provision, at least currently, in this kind of legislation corresponding to the provisions of
section 21 of the Immigration, Nationality and Asylum Act 2006, which, put broadly, make it an offence for the
purposes of immigration control for an employer knowingly to employ someone who is in breach of immigration
control. For better or worse, there is no such explicit statutory provision in this particular context. However, we
should record that in some cases prosecutors may think it sufficient to charge those who are deemed to be involved
by reference to breaches of the relevant employment legislation, by reference to breaches of the relevant health
and safety legislation or by references to breaches of the relevant tax legislation, or a combination of those
offences. However, in the present case, the Crown has elected to proceed by charging a conspiracy by reference
to section 4(2) and we simply note that as the position.

78. LORD JUSTICE DAVIS: Now, you understand where you are going from here?

79. MR TEHRANI: Yes.

80. LORD JUSTICE DAVIS: So the matter will be back before the judge on Thursday.

81. MR TEHRANI: On Thursday.

82. LORD JUSTICE DAVIS: And Mr R alone, because we should order therefore that acquittals be entered with
regard to the second and third defendants, we are required to order that.

83. MR TEHRANI: Thank you.

84. LORD JUSTICE DAVIS: Now, for the future, what will happen will happen, but this is not going to be an easy

summing‑up.

85. MR CHRISTIE: No.

86. LORD JUSTICE DAVIS: As you may have gathered, our present view is that actually arranges or facilitates
may not be the problem here, but the judge is going to need a lot of help on the issue of exploiting and obviously he
is going to need help on marshalling the evidence whereby the prosecution say the inference as to participation in
the agreement is to be drawn. These matters will need to be very carefully marshalled and the judge will need help
on this. He will not be helped by both sides trying to knock spots off each other, all right. That is not a criticism, we
understand it is a highly adversarial case, but the judge is going to need assistance here. More than that we are
unable to say, but arranges or facilitates is not going to be the difficulty, probably.

87. Any other matters arising?

88. MR CHRISTIE: Can I just raise one matter, just so that we are clear. My Lord, in passing, expressed an
observation on the present indictment. May I take it that that is the matter for the learned judge to rule on as to

precisely how it should be framed. Your Lordship is not seeking to prescribe how that should be dealt with ‑‑

because there is a slight issue between us about that.

89. LORD JUSTICE DAVIS: We are not. The indictment has got to be amended because it is common ground
now that belief is not sufficient. At the very least the indictment should be amended to put that right. If there is a
dispute about on that, then you will have to raise the matter with the judge.

90. MR CHRISTIE: There is no dispute about that, it is just how it is framed thereafter, but I am inviting your
Lordships, unless you expressly want to express an opinion upon it, that we leave that for the learned trial judge,

rather than for your Lordships. Your judgment might be interpreted in one way ‑‑

91. LORD JUSTICE DAVIS: Certainly. I was only intending to record you were both agreed that the indictment
needed to be amended at least to cover the point of knowledge as opposed to belief.


-----

92. MR CHRISTIE: Indeed. Thank you very much.

93. LORD JUSTICE DAVIS: Are there any other points?

94. MR TEHRANI: No, thank you.

95. LORD JUSTICE DAVIS: All the teams, and that is including junior counsel as well as leading counsel, have
obviously worked extremely hard indeed to get this ready in time, and for those defendants who have succeeded,
you have succeeded, but those who have not succeeded, that is through no want of skill and preparation on your
part.

96. MR CHRISTIE: Thank you for that observation.

97. LORD JUSTICE DAVIS: Likewise, Mr Tehrani, you and your junior have obviously worked very hard indeed.

98. MR TEHRANI: Thank you, my Lord.

99. LORD JUSTICE DAVIS: Let us hope that the trial can proceed in a relatively normal way.

**End of Document**


-----

