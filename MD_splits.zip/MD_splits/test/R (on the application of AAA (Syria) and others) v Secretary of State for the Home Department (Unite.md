High Commissioner for Refugees intervening) and ot....

# R (on the application of AAA (Syria) and others) v Secretary of State for the
 Home Department (United Nations High Commissioner for Refugees
 intervening) and other cases [2023] EWCA Civ 266

Court of Appeal, Civil Division

Underhill VP LJ

14 March 2023Judgment

**Raza Husain KC,** **Christopher Knight,** **Rayan Fakhoury,** **Emmeline Plews,** **Will Bordell and** **Tim**
**Johnston (instructed by Duncan Lewis) for the Appellants inAAA and others and HTN (Vietnam)**

**Neil Sheldon KC,** **Edward Brown KC,** **Mark Vinall and** **Sian Reeves** (instructed by the Treasury
**Solicitor) for the Respondent inAAA & Ors and HTN (Vietnam)**

**Laura Dubinsky KC and** **David Chirico (instructed by** **Baker McKenzie) for the** **Intervener in** **_AAA &_**
**_Ors_**

**Richard Drabble KC, Alasdair Mackenzie, and David Sellwood (instructed by Wilson Solicitors LLP)**
for the Appellant inRM (Iran)

**Neil Sheldon KC,** **Edward Brown KC,** **Mark Vinall and** **Sian Reeves** (instructed by **the Treasury**
**Solicitor) for the Respondent inRM (Iran)**

**Sonali Naik KC and** **Isaac Ricca-Richardson** (instructed by BHD Solicitors) for the **Appellant inAS**
**_(Iraq)_**

**Neil Sheldon KC,** **Edward Brown KC,** **Mark Vinall and** **Sian Reeves** (instructed by **the Treasury**
**Solicitor) for the Respondent inAS (Iraq)**

**Anthony Metzer KC, and** **Sharaz Ahmed** (instructed by no. 12 Chambers) for the **Appellant inAB**
**_(Albania)_**

**Neil Sheldon KC,** **Edward Brown KC,** **Mark Vinall and** **Sian Reeves** (instructed by **the Treasury**
**Solicitor) for the Respondent inAB (Albania)**

**Manjit Gill KC, Tony Muman and Harjot Singh (instructed by Twinwood Law Practice Limited) for the**
**Appellant inSAA (Sudan)**

**Neil Sheldon KC, Edward Brown KC, Robin Hopkins, Mark Vinall and Sian Reeves (instructed by the**
**Treasury Solicitor) for the Respondent inSAA (Sudan)**

**Richard Drabble KC and Leonie Hirst (instructed by Wilson Solicitors LLP) for the Appellant inASM**
**_(Iraq)_**

**Neil Sheldon KC,** **Edward Brown KC,** **Mark Vinall and** **Sian Reeves** (instructed by **the Treasury**
**Solicitor) for the Respondent inASM (Iraq)**


-----

High Commissioner for Refugees intervening) and ot....

**Charlotte Kilroy KC and Michelle Knorr (instructed by Leigh Day) for the Appellant inAsylum Aid**

**Neil Sheldon KC,** **Edward Brown KC,** **Mark Vinall and** **Sian Reeves** (instructed by **the Treasury**
**Solicitor) for the Respondent inAsylum Aid**

Hearing date: 6 March 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 14 March 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Lord Justice Underhill :**

INTRODUCTION

1. In this judgment I consider a number of applications for permission to appeal against decisions made by
the Divisional Court (Lewis LJ and Swift J) in claims for judicial review of what I can for present purposes
refer to loosely as “the Rwanda scheme”. Eight such claims were heard over two hearings, in September
and October 2022: I will refer to them as AAA, HTN, RM, ASM, AS, AB, SAA and Asylum Aid. The parties
to the claims, as they now stand, appear in the title to this judgment. All the eleven individual Claimants
are asylum-seekers whom the Government proposed to remove to Rwanda under the scheme: in _AAA_
three organisations were originally also claimants but permission to appeal in their cases has already been
refused. The United Nations Commissioner for Human Rights (“UNHCR”) was given permission to
intervene in AAA.

2. So far as relevant for the purposes of these applications, the primary decisions challenged were
threefold:

(a) an “inadmissibility decision”, by which an individual's asylum claim was decided not to be eligible for
consideration in the UK pursuant to paragraph 345A of the Immigration Rules;

(b) a “removal decision”, by which it was decided to remove him (all the Claimants are men) to Rwanda
under the terms of a “Migration and Economic Development Partnership” (“the MEDP”) between the UK
Government and the Government of Rwanda (“the GoR”) (which comprises a Memorandum of
Understanding (“the MoU”) and a number of _Notes Verbales), on the basis that Rwanda is a safe third_
country for the purpose of paragraph 345C of the Rules;

(c) a “human rights decision”, under which the Secretary of State certified the individuals' claims that their
removal was in breach of their rights under the European Convention on Human Rights as “clearly
unfounded”, pursuant to section 94 of the Nationality, Immigration and Asylum Act 2002.

The inadmissibility and removal decisions were made in the same letter in each case, but the human rights
decision was made in a separate letter and by a different decision-maker, though on the same date (or,
rather, dates – see para. 4 below). (I should mention, because it is mentioned below, that the
inadmissibility and removal decisions were also the subject of certificates by the Secretary of State under
paragraph 17 of Schedule 3 to the Asylum and Immigration (Treatment of Claimants, etc) Act 2004 that
Rwanda was, to put it broadly, a safe country for the Claimant in question to be removed to; but that is not
directly relevant to any of the applications which I have to consider.)

3. By a judgment handed down on 19 December 2022 the Divisional Court rejected what it characterised
as the “generic” grounds of challenge to the relevant decisions and also to the procedural fairness of the
system generally; but it found that there were legal flaws in the decision-taking in all of the individual cases.


-----

High Commissioner for Refugees intervening) and ot....

In five of the claims (involving nine claimants) – AAA, HTN, ASM, SAA and AB – all three of the relevant
decisions were quashed, but in RM and AS only the human rights decision was quashed.

4. I should note one point from the judgment of the Divisional Court which is of relevance to one aspect of
what follows. In all the cases the Secretary of State had in fact made the relevant decisions twice. The
first round of decisions was between late May and early June. However, in each case she re-made all
three decisions on 5 July 2022, in response to further materials which she had received in the meantime.
The Divisional Court held, plainly rightly, that notwithstanding that they referred back to the earlier
decisions it was the later decisions which were the operative decisions and were the proper focus of the
Claimants' challenge.

5. All the Claimants sought permission from the Divisional Court to appeal on the issues on which they
had failed. At a hearing on 16 January 2023 the Court gave permission to appeal on all or some of the
grounds advanced in each of the individual cases save SAA and AB. In ASM and Asylum Aid permission
was granted on all grounds. I attach an Annex setting out the grounds for which it granted permission in
each case: it will be seen that there is a substantial degree of overlap.

6. Appellant's Notices have been filed in all eight cases. In the case of the four where the Divisional Court
granted permission to appeal on only some grounds, the Claimants have sought permission from this Court
to appeal on the remaining grounds. In the cases of SAA and AB permission to appeal is required on all
grounds.

7. I initially reviewed the applications for permission to appeal on the papers in accordance with CPR 52.5
(1). I refused permission to appeal on several grounds: my reasons are given in the orders in question.
However, there were a number of grounds in respect of which I directed an oral hearing in accordance with
CPR 52.5 (2). That hearing took place on 6 March 2023. A large number of counsel attended, as listed in
the title to this judgment. I am grateful for their assistance and that of the solicitors instructing them. It was
not possible for me in the time available to reach decisions on the applications for permission to appeal
and I accordingly reserved judgment. The hearing was also an occasion to review the arrangements for the
substantive hearing. I do not deal with those in this judgment, save to record that that hearing is now listed
for four days between 24th and 27th April 2023.

8. In this judgment I give my decisions, with reasons so far as appropriate, in each of the applications for
permission. Because these are decisions on permission to appeal and have no status as authority in other
cases I have expressed myself more economically than in a full judgment. Among other things, I have not
set out the terms of the relevant legislation and rules, and I have generally referred to passages in
documents without quoting them or in some cases explaining the status of the documents in question.

9. I should deal with one point by way of preliminary. Most of the grounds on which the Divisional Court
granted permission relate to generic issues: in other words, if the challenge is well-founded the reasoning
will apply not only to the decisions taken in the case of the Claimant in question but also to those taken in
the cases of all the other Claimants in whose case the relevant circumstances apply. The Divisional Court
only permitted one counsel for one party to address it on any particular generic ground, with counsel for the
other parties adopting their submissions. In their appeals to this Court, not all the parties have pleaded all
the generic grounds, on the basis, as I understand it, that it was sufficient that they be pleaded by the
parties whose counsel argued them below. That is a sensible course, but I took the opportunity to confirm
with Mr Sheldon, who appeared for the Secretary of State, that she accepted that if the appeal succeeded
on any of the generic issues it would be treated as covering any Claimants to whom the relevant reasoning
applied.

_AAA                and HTN_

10. The Claimants in AAA and HTN are represented by the same solicitors and counsel. Substantially the
same issues arise in both and their grounds of appeal are identically pleaded. Permission is sought on
grounds (1)-(3) and (5).

11 Gro nds (1) (3) read


-----

High Commissioner for Refugees intervening) and ot....

“(1) The Court erred in its interpretation and application of the _Ilias test when determining whether the_
SSHD conducted a sufficiently 'thorough examination' of the adequacy of Rwanda's asylum system,
including by (i) effectively conflating the _Ilias duty with the_ _Tameside duty, and (ii) adopting the wrong_
approach in law to the SSHD's evidence, the evidence of UNHCR, and the unsworn material provided by
the Government of Rwanda.

(2): The Court erred in concluding that the Assessment Document and/or the applicable inadmissibility
decisions were based on a Tameside sufficient inquiry, including by (i) failing to have regard to the proper
point in time at which to assess the SSHD's compliance with that duty, and (ii) concluding that the SSHD
could make a reasonable decision in relation to future refoulement risk without at least attempting an
assessment of past violations.

(3): The Court erred in its interpretation and application of the Soering test in determining whether asylumseekers relocated to Rwanda faced a real risk of refoulement or other Article 3 ill-treatment.”

12. I propose to give permission on those grounds (although I made it clear to Mr Husain, the Claimants'
leading counsel, that the phrase “including by” in grounds (1) and (2) did not open the door to any
arguments not already identified in his skeleton argument). I do so essentially because I regard them as
raising issues which are liable to overlap substantially with those raised by ground (4), on which the
Divisional Court has already granted permission. If, as it held, there was a compelling reason to give
permission on that ground I believe there is a compelling reason to give permission on grounds which may
not be easily separable in practice.

13. Ground (5) reads:

“The Court erred in failing to address the question of whether asylum-seekers removed to Rwanda would
be accorded their rights under the Refugee Convention as a matter of vires as opposed to rationality.”

As pleaded that is rather opaque, but the nature of the challenge is clearly explained in paras. 51-58 of the
Claimants' skeleton argument. I need not summarise those paragraphs here save to say that the central
contention is that the obligations of which the Secretary of State is said to be in breach arise under section
2 of the Asylum and Immigration Appeals Act 1993 rather than simply as a matter of public law rationality.
Whether or not this ground has a real prospect of success, as to which I have not found it necessary to
reach a concluded view, the Court will in any event have to consider the effect of section 2 of the 1993 Act
in ASM (see ground 1B, on which the Divisional Court gave permission), and although the particular issues
may be different I think it desirable for both to be before the Court. I accordingly grant permission.

_RM_

14. We are concerned with two grounds of appeal, (6) and (7), which I will take in turn.

15. Ground (6) reads:

“Ground 6: the Court failed to consider adequately or at all:

(i) Whether the existence of 'significant vulnerabilities', as set out in (among other things) the SSHD's
Standard Operating Procedures, was a criterion for whether a person should be considered ineligible
and/or unsuitable for transfer to Rwanda; and/or

(ii) Whether the SSHD had lawfully applied that criterion to RM's circumstances when considering whether
he should be transferred to Rwanda.”

16. The background to this ground can be sufficiently summarised as follows. The Immigration
Enforcement Unit in the Home Office had at the relevant date issued a Standard Operating Procedure
(“SOP”) for “Referring small boat arrivals into Detained Asylum Casework (DAC) and Migration and
Economic Development Partnership (MEDP)”. The introductory section to the SOP, headed “Background”,
sets out what are described as “criteria” for consideration of whether individuals arriving by small boat may
be suitable for relocation to Rwanda under the MEDP. One of these is that:


-----

High Commissioner for Refugees intervening) and ot....

“The individual has no significant vulnerabilities or safeguarding concerns and meets the criteria for onward
detention under current Detention Gatekeeper procedures.”

17. It was RM's case in the Divisional Court that he did in fact have significant vulnerabilities which meant
that the “criterion” referred to in that quotation was not satisfied in his case and that the removal decision
had been procedurally unfair because he had not been given the opportunity to draw those vulnerabilities
to the Home Office's attention and/or that they had not been taken into account properly or at all.

18. It was the Secretary of State's case that the words which I have quoted from the SOP did not state or
reflect any policy that no-one would be transferred to Rwanda if they had “significant vulnerabilities or
safeguarding concerns” (for short, “with vulnerabilities”). The definitive statement of her policy was to be
found in the Inadmissibility Guidance, which says only that decisions as to whether relocation to a third
country is safe and appropriate for a particular individual will be judged on case-by-case basis having
regard to their individual circumstances. The reference in the SOP on which RM relied merely reflected the
fact that in the initial stages priority was to be given to individuals who could be held in detention, which,
because of the rules governing detention, would necessarily exclude those with vulnerabilities. That case
was stated in full and clear terms at paras. 11.93-100 of the Secretary of State's skeleton argument below
and supported by a witness statement from Mr Ruaridh MacAskill, the Acting Head of the Home Office
Third Country Unit.

19. The Divisional Court addressed this issue at para. 357 of its judgment, where it said:

“The inadmissibility decision was not unlawful. The position is as follows. Save for the procedural fairness
issue, the only specific ground of challenge was that the Home Secretary had failed to consider the
medical evidence and RM's vulnerability. We do not consider that the policy documents establish that a
person will not be relocated to Rwanda if he can establish that he is vulnerable. It will be a question for the
Home Secretary to consider, case by case. In this case the Home Secretary did consider the medical
evidence available at the time of the decision on 5 July 2022 ... She did not act unreasonably in not
making further inquiries. The grounds of claim in relation to the 5 July 2022 inadmissibility decision,
therefore, fail”

20. I would refuse permission on this ground. It is fair to say that the Divisional Court does not explain its
implicit conclusion at para. 357 that the SOP does not amount to a policy. But I see no real prospect that if
the issue were considered on appeal this Court would reach any different conclusion. The starting-point is
that the SOP, being an internal document giving operational guidance to officials, is less likely to be a
source for policy than the carefully considered and public Inadmissibility Guidance. But in any event when
the passage in question is read in the context of the document as a whole, and in the light of the evidence
of Mr MacAskill, which there is no reason to impugn, the Secretary of State's explanation is in my view
entirely convincing. There is nothing inherently implausible about her having a policy which would permit
the removal of persons with vulnerabilities if the criteria in the Inadmissibility Guidance were met; and Mr
Sheldon pointed out that there were detailed provisions in the MEDP documents about the treatment of
such individuals in Rwanda which would be redundant if it was contrary to her policy to transfer them in the
first place.

21. Mr Drabble submitted that Mr MacAskill's evidence was inadmissible to contradict an unambiguous
statement in the SOP. I do not agree. The SOP, when read as a whole, is not in my view unambiguous;
and I can see no basis for excluding Mr MacAskill's evidence. Parts of it are, as Mr Drabble pointed out,
hearsay because he says he has derived it partly from discussions with other officials; but that is not
objectionable in principle.

22. I turn to ground (7). This concerns a decision of the Immigration Enforcement Competent Authority
(“IECA”) – which is an entity within the Home Office established as part of the National Referral Mechanism
(“NRM”) procedure – that there were no reasonable grounds to conclude that RM was a victim of modern
**_slavery (to which I will refer because there is no material difference in this context, as “trafficking”). RM_**
sought judicial review of that decision as part of his claim. The Court dismissed that challenge. RM
contends that it was wrong to do so


-----

High Commissioner for Refugees intervening) and ot....

23. I need not set out in full the definition of trafficking to which IECA works, which derives from the
European Convention on Action against Trafficking. For present purposes I need only say that it has three
elements, conventionally summarised as: (a) the act (“recruitment, transportation, transfer, harbouring or
receipt” – for short, “transporting”); (b) the means (broadly, coercion of any kind); and (c) that the act is “for
the purpose of exploitation”. “Exploitation” is defined as including forced labour, which is defined by the
International Labour Organisation as “all work or service which is exacted from any person under the
menace of any penalty and for which the person has not offered himself voluntarily”: Mr Drabble also
referred me to Basfar v Wong _[2022] UKSC 20, [2022] 3 WLR 208._

24. RM's evidence, principally set out in the witness statement submitted to IECA but also contained in the
record of his screening interview and the document making the reference to the NRM, can be sufficiently
summarised as follows. He is a Kurd of Iranian nationality, now aged 26. He arrived in the UK in a small
boat on 14 May 2022. He left Iran because he believed that he was suspected by the authorities of
Kurdish separatist sympathies. His uncle paid people smugglers to arrange his journey to the UK. In the
course of the journey he was subjected to various kinds of threats and ill-treatment by the smugglers, but
what he relies on specifically is the fact that he was on occasions required by them to perform what he
characterises as forced labour. This was of two kinds:

(1)   He was required to do various tasks in return for food. At paras. 45-46 of his witness statement he
says:

“45. … Between Turkey and France I was promised by the smugglers that if I did certain tasks I would
receive payment. For this, I was told to take boxes here and there, which I did. I was asked to give them
cigarettes and other items the agents wanted, which I did. I was asked to wash their clothes, which I did.
But there was no payment. They just gave me a bit of food for this. They said we will pay you but they
didn't. I had no choice so I did what I was told or ordered to do.

46. The smugglers were clear that the money was paid for them for the journey in my situation but they
told me that money for food was not settled, so for this I had to do these jobs for them. That is why I would
get a little bit of food in return for these jobs. I therefore had to work to earn the right to 'buy' my food from
smugglers, without keeping any money from them. … I did not have any money myself and they knew
this.”

(2) He was forced to help carry into the water the boat in which he crossed the Channel. I need not quote
the full account from his witness statement, but the gist is that the smugglers used threats and blows to
force him and a few others to carry the boat, though he was unwilling to do so both because he was now
frightened of making the journey and also because he had an injured shoulder.  He says that he did not in
fact help carry the boat but stood under it “pretending to carry it otherwise I would have been beaten up or
worse”. The NRM referral also contained a reference to him having “tried to sabotage the mission”.

25. IECA's “no reasonable grounds” decision is dated 15 July 2022. It made the point that peoplesmuggling as such is not a form of trafficking: its purpose is not the exploitation of the people being
smuggled but their illegal transportation, for reward, to another country, at which point the transaction ends.
It observed that the fact that the smugglers in RM's case used threats and force in the course of the
journey was not for the purpose of exploitation but “as a catalyst to complete the task”. As for the
submission that he had been made to carry out forced labour, its conclusions were:

(1) As regards the various tasks that he described, RM was not acting under the menace of any penalty or
in response to threats but in exchange for food, “due to pure economic necessity and a requirement for
survival”, which was not a situation falling within the definition of forced labour;

(2) As regards carrying the boat, this was not forced labour “as you entered this situation voluntarily after
your uncle paid the smugglers, and you tried to sabotage the journey”. Earlier in its reasons it amplifies the
reference to sabotaging the journey by saying that RM “only pretended” to carry the boat.

26. The Divisional Court records Mr Drabble's criticisms of that reasoning at paras. 347-348. At paras.
353-354 it says:


-----

High Commissioner for Refugees intervening) and ot....

“353. The trafficking decision did not fail to have regard either to RM's account of events or to any relevant
policy. Nor did it rest on any error of law. The Home Secretary was fully entitled to reach the conclusion
she did. The third element of the definition of modern slavery concerns whether the individual was being
transported for the purpose of exploitation. That looks to the purpose for which the individual is being
transported to the United Kingdom. It is primarily concerned with what will happen to the individual after he
arrives in the United Kingdom. The Home Secretary was entitled to conclude that there was nothing to
suggest that RM was transported in order to be exploited after he arrived in the United Kingdom. He was
transported here because his uncle had paid for him to be taken to the United Kingdom.

354. So far as events on the journey are concerned, the Home Secretary was fully entitled to conclude
that RM being told that he would be paid, or given food, if he completed certain tasks did not involve forced
labour. Similarly, she was entitled to conclude that when he was told to help carry the boat which was to
take him and others to the United Kingdom, that did not involve RM being transported for the purposes of
exploitation and did not involve forced labour. The reality is that this was part and parcel of the journey to
the United Kingdom that his uncle had paid the agents to arrange, not any form of exploitation of RM by the
agents. There is no flaw in the reasoning underlying the decision that there were no reasonable grounds
for concluding that RM was trafficked. …”

(That reasoning does not refer to IECA's point about RM having only pretended to carry the boat: the point
which the Court does make is obviously the one that counts.)

27. Mr Drabble's skeleton argument focuses on IECA's reasoning about the tasks which RM says he had
to carry out in order to obtain food. He submits that in characterising that as “economic necessity” IECA
failed to have regard to the context. RM was in the power of the smugglers, who had made threats of
violence, and he had no opportunity to work anywhere else: in practice if he was to get food to survive he
had to do the work. He emphasises that IECA was not concerned with a definitive finding that RM had
been a victim of trafficking but only with whether there was “credible suspicion”; also that at this stage I am
concerned only with whether this ground of appeal is arguable. The skeleton argument does not address
the issue about carrying the boat, and in his oral submissions Mr Drabble accepted that that was the
weaker of the two bases.

28. I do not believe that if this ground went to a full appeal there is a real prospect that IECA would be held
to have made any error of law. Although its decision was indeed only concerned with whether there were
credible grounds to believe that RM was a victim of trafficking, it had before it the entirety of the available
evidence and it was in a position to reach a firm conclusion on the basis of RM's own account. As to that,
his witness statement certainly says that the smugglers did on occasion use threats and violence, but his
account of why he undertook the tasks in question (other than carrying the boat) does not refer to any such
threats: he agreed to work because he needed to eat. But even if it is arguable that in some circumstances
such a transaction could amount to “forced labour” in the relevant sense it is not enough for him to show
that he suffered exploitation: the act of transportation has to be done “for the purpose of” that exploitation.
That was plainly not the case. It is quite unrealistic to think that part of the smugglers' purpose in
transporting RM to the UK was to get him to perform the kind of incidental tasks that he describes –
carrying boxes to and fro and washing their clothes.  As I understand it, this is the point being made by the
Divisional Court at para. 354. As regards his being made to carry the boat the same point is even more
obvious: RM was not being transported in order to help carry a boat.

29. I accept, of course, that it is always important to have regard to the context, and I have no reason to
doubt RM's account that his experience of his journey, including his treatment by the smugglers, was
harrowing. But people smuggling is not the same as people trafficking, and IECA's task was to establish
whether there was anything in RM's account that meant that he was being transported “for the purpose of
exploitation”. I can see no arguable error in its conclusion that there was not.

30. I accordingly refuse permission to appeal on ground (7).

_AS_


-----

High Commissioner for Refugees intervening) and ot....

31. AS seeks permission on five grounds which I take in turn. Each ground is pleaded in the form of a
short headline, followed by several paragraphs of exposition for each, in addition to the skeleton argument.

32. Headline ground 1A reads:

“R's policy was procedurally unfair, as R failed to disclose to A the criteria applied to select individuals for
inadmissibility and removal, preventing A from making informed representations on those criteria, and the
court erred by concluding otherwise.”

As the expository paragraphs confirm, this ground rests on an alleged criterion for removal to Rwanda that
the individual in question has no significant vulnerabilities.

33. For the reasons given above in relation to RM's ground (6), there is no real chance that if the appeal
were to proceed this Court would accept that proposition. Ms Naik, representing AS, drew my attention to
two entries in his GCID notes in May 2022 recording that there were no safeguarding concerns or
vulnerabilities; but since he was in detention that is wholly consistent with the Secretary of State's
evidence.

34. The Secretary of State in her para. 19 representations makes the further point that in any event AS
had the opportunity to, and did, make representations about his medical condition prior to the decision of 5
July 2022 and that they were expressly considered in the inadmissibility decision letter. Specifically, the
letter refers to representations from his solicitors, a rule 35 report dated 28 May 2022 which referred to
mental health issues, and a psychiatric report from a Dr Olowookere dated 9 June 2022 which diagnosed
him as suffering from moderate depression and PTSD. Ms Naik responded that that was not the same
point, because AS's representations had not been directed to a specific criterion appearing from the SOP;
but that is not an answer if, as I believe is clear, there is no such criterion. (I note in passing that the terms
of AS's decision letter tend to confirm the Secretary of State's position that she will take an individual's
medical condition into account as part of her consideration of all the circumstances but will not treat
vulnerability as a criterion preventing removal.)

35. Headline ground 1B reads:

“R's policy was procedurally unfair, as the timeframes operated by R offered no adequate opportunity for
detection of medical vulnerabilities relevant to R's decision making, and the Court erred by concluding
otherwise.”

36. I do not believe that this ground is arguable. As noted above, AS did have an opportunity to, and did,
draw the Secretary of State's attention to his medical vulnerabilities and they were considered in the
decision letter of 5 July. Ms Naik's point is that that letter says that an inadmissibility decision is being
made for the reasons given in it “and in the previous letter”, i.e. the letter conveying the “first-round”
decision referred to in para. 4 above, which in AS's case was dated 3 June (although sometimes referred
to as dated 2 June); that at the earlier date no proper opportunity to make representations had been made;
and that accordingly the later decision remained tainted by the earlier unfairness. I see no prospect that
this Court would accept that argument. The operative decision is that of 5 July. Since the Secretary of
State considered the medical evidence submitted in that letter, any failure to consider such evidence first
time round is irrelevant.

37. Headline ground 1C reads:

“R's process by which A's individual vulnerabilities were disclosed to Rwanda prior to acceptance for
removal there were inadequate and insufficient to avoid risk of an Article 3 ECHR breach on removal to
Rwanda for him and further invalidated R's inadmissibility decision in his case.”

The point being made here, as expanded in the expository paragraph and skeleton argument, is based on
paragraph 5.2 of the MoU. This requires the UK Government when seeking the consent of the GoR to the
transfer of an individual under the MEDP to provide it with specified information, including (at 5.2.2) “any
health issues it is necessary for Rwanda to know before receiving [them]”. On the eve of the hearing in the
Divisional Court the Secretary of State disclosed the form sent to Rwanda on 13 May 2022 in purported


-----

High Commissioner for Refugees intervening) and ot....

discharge of that obligation. This says nothing about any health issues experienced by AS. His point is
that that created a real risk that he would not receive proper treatment in Rwanda for his mental health
problems, and consequently of a breach of article 3.

38. I note that at the date that the form was sent the Secretary of State did not have the medical evidence
that was considered in her decision of 5 July, though I appreciate that AS would say that that was because
he had not had the opportunity to supply it. However, even if the failure to supply the information at that
stage was culpable that does not mean that it could not be supplied later. In fact, the Secretary of State
says in terms in her decision letter that on transfer she will notify the Rwandan authorities of AS's medical
needs so that they can be catered for on arrival, and there is no reason to suppose that that would not
have occurred if his transfer had proceeded. That notification would in principle ensure that he was in a
position to receive any necessary care (subject to any question about the standards of healthcare available
in Rwanda – but that is not the issue being raised as regards this ground).

39. That being so, the allegation that the UK Government was in breach of the MoU goes nowhere. I am
not in fact sure that the failure to supply the information to the GoR in advance of its decision to accept AS
was a breach of para. 5.2.2. But, even if it was, such a breach would be a matter between the two
governments: the MoU is an international treaty and can confer no rights on individuals who may be
transferred under it.

40. For those reasons ground 1C has no real prospect of success.

41. Headline ground 2 reads:

“R's inadmissibility decision was unlawful and flawed in circumstances where the human rights decisions,
and consequently A's proposed removal to Rwanda, were found to be unlawful and the Court erred in
upholding it.”

As already noted, in AS's case only the human rights decision was quashed: the inadmissibility and
removal decisions stand. In fact, the Divisional Court quashed not only the decision of 5 July 2022 but the
earlier decision of 3 June. AS's case is that the inadmissibility and human rights decisions in his case are
inter-related so that they must stand or fall together. In that connection Ms Naik referred me to the second
paragraph on p. 22 of the Inadmissibility Guidance, which reads:

“If a claimant makes detailed representations regarding a risk of serious harm or refoulment from the
country of removal, they will need to be considered as part of the inadmissibility claim and as a human
rights claim under Article 3 of the European Convention on Human Rights. In such cases where the issues
overlap, they must be properly considered and decided consistently between decisions. It may be
appropriate in such cases to delay the inadmissibility decision, to share decision-making with the Barrier
Casework Team and to ensure that certificates under the relevant provisions of Schedule 3 to the Asylum
and Immigration (Treatment of Claimants, etc) Act 2004 are applied appropriately.”

42. It is clear from the expository paragraphs (and the skeleton argument) that the alleged interrelationship between the inadmissibility and human rights decisions consists in the fact that the human
rights decision of 3 June was quashed because the decision-maker had failed to have regard to the rule 35
report in AS's case. That report, Ms Naik says, was relevant to the question of whether Rwanda was a
safe third country, because the mental condition which it evidenced meant that he might suffer “article 3
harm” if relocated there. She points out that the inadmissibility decision of the same date cross-refers to
the human rights decision.

43. I do not believe that this argument has any real prospect of success. The operative human rights
decision is that of 5 July not 3 June. Although it too was quashed, that was not for the same reason as the
earlier decision: as noted earlier, by that time the Secretary of State had had, and considered, the rule 35
report. Rather, the reason was the Secretary of State had failed to take into account a witness statement
from AS's son, who lives in the UK, giving evidence about his relationship with his father. AS advances no
argument for any inter-relationship between that ground of invalidity and the issue of whether he would
suffer article 3 harm in Rwanda; and clearly there is none


-----

High Commissioner for Refugees intervening) and ot....

44. Headline ground 3 reads:

“The Court was wrong to conclude that R's inadmissibility policy on removals to Rwanda was not unlawful
either under the conventional _Gillick test or under a_ _Gillick test necessarily modified in cases involving a_
real risk of Article 3 ECHR breach.”

45. The Divisional Court addressed the Claimants' case based on Gillick at para. 72 of its judgment. As I
read it, it rejected that case essentially on the basis that the Inadmissibility Guidance merely gave effect to
the relevant Immigration Rules in the context of a lawful decision that Rwanda was a safe third country.
But if the Claimants succeed on their other grounds of appeal that basis disappears, and it would in my
view be arguable that the Inadmissibility Guidance required case-workers to act unlawfully to the extent
that it required them to treat Rwanda as a safe third country.

46. I accordingly give permission to appeal on this ground. I can at present see no basis for the argument
that the test in Gillick, as explained in A, should be modified in cases involving a potential breach of article
3 of the Convention (nor indeed why that proposition is likely to be necessary to AS's case); but it would
not be straightforward to try to excise it at this stage.

47. For those reasons I refuse permission on grounds 1A-1C and 2, but grant it on ground 3.

_AB_

48. There are two outstanding grounds of appeal in AB's case – (c) and (d), which raise issues about,
respectively, the procedural fairness of the system and the Tameside duty. The Divisional Court refused
AB permission to appeal on those grounds on the basis that at the hearing in September 2022 the grounds
which he had been permitted to advance were limited to two quite different grounds (namely (1) whether
the Secretary of State had erred in law by failing to publish certain guidance and (2) discrimination): see
para. 43 of the consequentials judgment. As I understand it, this restriction reflected the fact that certain
aspects of his challenge had been stayed because IECA had decided that AB was a victim of trafficking,
which meant that his position would have to be reconsidered.

49. I explored the position with Mr Ahmed, who represented AB at the hearing, and also with Mr Sheldon.
I was at that stage attracted by the argument that, since the Court had in some of the other appeals found
that permission to appeal should be granted on (essentially) grounds (c) and (d), AB was entitled to
permission on those grounds also. On reflection, however, I think that the Divisional Court was right. This
is not a case where a party had a right to argue a point below but chose to adopt the submissions on that
point made on behalf of other parties: the effect of the Court's order was that as a result of the stay AB did
not have the right to advance these points at all at the hearing in September.

50. I would accordingly refuse permission to appeal on both grounds. AB is not disadvantaged by this. As
I pointed out to Mr Ahmed, even if he (or Mr Metzer KC, who has signed AB's skeleton argument) had
been instructed to appear, they would almost certainly not have had the opportunity to make substantive
submissions because this Court, like the Divisional Court, will only allow submissions on generic grounds
to be made by one counsel, being one who had argued the ground in question below. And of course, as
noted at para. 9 above, he will have the benefit of any success by other parties on the generic grounds that
is relevant to the circumstances of his case.

_SAA_

51. Three grounds of appeal by SAA were initially to be considered at the hearing. One – ground 6 – fell
away because SAA did not comply with a condition that he supply copies of the documents necessary for
me to consider it. Ground 4 was in two parts. As regards one part I refused permission earlier on the
papers. As regards the other, which appeared to adopt wholesale all other generic grounds advanced by
other Appellants, I understood Mr Gill, who appeared for SAA, to have confirmed at the hearing that he no
longer wished to pursue it, on the understanding noted at para. 9 above. I have recently received an email from SAA's solicitors the effect of which appears to be that that was a misunderstanding. I will make
no order in that regard until the position has been clarified


-----

High Commissioner for Refugees intervening) and ot....

52. The third ground – ground 3 – challenges the Divisional Court's dismissal of SAA's case below that the
relevant decisions were unlawful because they involved breaches by the Secretary of State of her
obligations under the data protection legislation: see paras. 127-149 of its judgment. The basis on which it
dismissed SAA's case was that even if the Secretary of State had committed the breaches alleged none of
them was of a character which rendered the substantive decisions unlawful: although it went on to consider
whether the breaches had in fact occurred, it avowedly did so on a summary basis. The pleaded ground
simply avers that the Court was wrong to take that approach and to fail to treat SAA's case as to breach
adequately, but that case is elaborated in detail over some sixteen pages in the skeleton argument.

53. I am far from persuaded that this ground is arguable. But in the end I have concluded that the issues
which it raises, which are of a rather different character from the others that I have had to consider, are
such that I cannot fairly refuse permission on the basis of the submissions which were possible at last
week's hearing. I believe that the right course is to defer SAA's application on this ground to the full
hearing in April. If the Court decides to grant permission, it may proceed to determine it on that occasion,
and the parties should be prepared for that eventuality, but it may decide that it is better not to do so, in
whole or in part. Mr Gill indicated that if permission to appeal were given he might want to reconsider parts
of his skeleton argument. Although I have not granted permission to appeal, I will give him permission to
submit a revised skeleton argument, on the understanding that it will not raise new points, and for the
Secretary of State to submit a skeleton argument in response, within the same time limits as have been set
for the Claimants in whose case permission to appeal has been granted.

ANNEX

GROUNDS ON WHICH PTA GRANTED BY DIVISIONAL COURT

_AAA                    and HTN_

(4) The Court erred in its application of the Othman test in determining whether the assurances contained
in the MOU and the _Notes Verbales provide a sufficient guarantee to protect relocated asylum-seekers_
from the risk of refoulement and other Article 3 ill-treatment.

(6)  The Court erred in finding that inadmissibility and/or removal to Rwanda did not constitute a penalty
for the purposes of Article 31 of the Refugee Convention.

(7)  The Court erred in concluding that the SSHD's use of the certification power in Part 5 of Schedule 3 to
the Asylum and Immigration (Treatment of Claimants etc.) Act 2004 was intra vires in circumstances where
the Assessment Document created a presumption of safety which circumvented the statutory scheme.

(8)   The Court erred in concluding that the Rwanda Removal Policy was not systemically unfair, including
by finding that procedural fairness did not require that each claimant have an opportunity to make
representations in relation to the matters set out in paragraph 345B(ii)-(iv) of the Immigration Rules

_RM_

1. The Court misdirected itself in concluding that Articles 25 and 27 of the Procedures Directive
(2005/85/EU) had ceased to be 'retained EU law' by virtue of s.1 and Schedule 1 to the Immigration and
Social Security Co-ordination (EU Withdrawal) Act 2020 ('ISSCA 2020'); in particular (i) the Court
misdirected itself as to the correct interpretation and application of ISSCA 2020 and (ii) its conclusion that
the Procedures Directive was no longer retained EU law was contrary to binding Supreme Court authority
in G v G [2022] A.C. 544, and the Court's reasons for departing from that authority were not adequate.

2.  As regards procedural fairness, the Court was wrong:

(i) to find that the process for determining whether an individual should be transferred to Rwanda was
procedurally fair, either generally or in RM's specific circumstances;

(ii) in particular, to find that fairness did not require applicants to be provided with the material on the basis
of which the Respondent had determined that Rwanda would generally comply with its non-refoulement
obligations and/or to have an opportunity to make representations directed to that issue, in circumstances


-----

High Commissioner for Refugees intervening) and ot....

where the Respondent, when deciding whether to certify individual asylum claims and/or human rights
claims as clearly unfounded, (a) was herself entitled to take account of general information about Rwanda
but (b) was found by the Court to have made no irrebuttable assessment as to the safety of Rwanda;

(iii) alternatively, if it was correct to find it unnecessary for applicants to be given an opportunity to make
representations on the general safety of Rwanda, to conclude from that that the process was fair, either
generally or in RM's specific circumstances;

(iv) in particular, to find that the process provided RM, at material times, with a fair opportunity to make
representations on his individual circumstances, especially as regards (a) why he had not claimed asylum
in France, either upon being turned back from the UK border on 9 May 2022 or otherwise, (b) his mental
health and/or cognitive difficulties, (c) whether he was potentially or actually a victim of trafficking and/or (d)
whether there were aspects of the Rwandan refugee status determination system which meant that it was
not a safe country for him personally; and/or

(v) to find that the Respondent's inadmissibility decision in RM's case did not fall to be quashed on the
basis of his procedural unfairness and/or a failure to take account of the evidence of his vulnerability.

3. As to whether Rwanda met the conditions in para 345B of the Immigration Rules, the Court was wrong:

(i) to find that it required 'compelling evidence' to go behind the assessment of HM Government that
Rwanda would honour its commitments under the MEDP;

(ii) further or alternatively, to find that there was no such compelling evidence;

(iii) in any event, to find that the SSHD's failure to take account of the Israel-Rwanda arrangement and/or
the extradition cases was not a material error of law; and/or

(iv) to find, with respect to RM's specific case and/or generally, that the refugee status determination
system envisaged in Rwanda by the MOU and Notes Verbales, even if taken at its highest, was adequate
to avoid a risk of unlawful onward refoulement, given (a) the deficiencies in the Refugee Status
Determination Committee, (b) the Government of Rwanda's misunderstanding of the requirements of the
Refugee Convention, (c) the lack of provision for medico-legal expert reports, (d) the lack of access to
adequate country information, including relevant expert evidence, (e) the lack of evidence of the availability
of suitable interpretation facilities and (f) the lack of evidence on the effectiveness of the right of appeal.

4. The Court was wrong to find, for the purposes of Article 31 of the Refugee Convention, that the removal
of RM, before his asylum claim would have been considered, to a third country with which he has no prior
connection, with the avowed aim of deterring them or others from seeking asylum in the UK after arriving
by unlawful means, did not constitute a penalty and therefore was consistent with s.2 of the Asylum and
Immigration Appeals Act 1993.

_ASM_

1.  The Court misdirected itself in concluding at [118] that Articles 25 and 27 of the Procedures Directive
(2005/85/EU) had ceased to be 'retained EU law' by virtue of s1 and Schedule 1 to the Immigration and
Social Security Co-ordination (EU Withdrawal) Act 2020.

2.  The Court erred in concluding at [126] that the MEDP Scheme as set out in paragraphs 345A-D of the
Immigration Rules was consistent with the Refugee Convention and therefore not ultra vires s2 of the 1993
Act.

_AS_

The Court erred in its application of the test for measuring the reliability of assurances laid down by the
ECtHR in Othman (App No. 8139/09) and the legal test as to procedural duties on D relating to enquiries
into safety and conditions in Rwanda.

_Asylum Aid_


-----

High Commissioner for Refugees intervening) and ot....

1:  The Court erred in rejecting Asylum Aid's grounds of claim and concluding that the Rwanda Removal
Policy was not systemically unfair, including by finding that procedural fairness did not require the provision
of information relating to, or the opportunity to make representations on the matters set out in §345B(ii)-(iv)
of the Immigration Rules.

2:  The Court is wrong to conclude that fairness does not require access to lawyers to make
representations.

3:  Even if the scope of the duty to allow an opportunity to make representations were as limited as the
Court has concluded, the Court is still wrong to conclude that seven days is enough time to make
representations.

4:  The Court is wrong to conclude that the common law does not require individuals to have access to the
SSHD's provisional conclusions against them.

5:  The Court erred in concluding that the Court's reasons for dismissing AA's procedural fairness
arguments mean that AA's access to justice argument 'falls away'.

6:  The Court's analysis of the Immigration Rules and para 17 of Schedule 3 to the 2004 Act is flawed.

**End of Document**


-----

