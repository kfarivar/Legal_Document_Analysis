# R v Mohammed [2019] EWCA Crim 1881

CA, CRIMINAL DIVISION

2018/04502/A3

Simon LJ, William Davis J, Sir Kenneth Parker

25 October 2019

25/10/2019

Friday 25[th] October 2019

**LORD JUSTICE SIMON: I shall ask Mr Justice William Davis to give the judgment of the court.**

MR JUSTICE WILLIAM DAVIS:

1. The appellant, Zakaria Mohammed, is now aged 22. At the time of the offending with which we are concerned,
he was just 21. When aged 17, he was convicted in the Youth Court of an offence of robbery and made the subject
of a referral order. He has no other convictions.

2. On 24[th] September 2018, in the Crown Court at Birmingham, on the day of trial, he pleaded guilty to four
offences of conspiracy to supply a controlled drug (counts 1, 2, 3 and 4) and to five offences of arranging or
facilitating the travel of another person with a view to exploitation, contrary to section 2(1) of the Modern Slavery
Act 2015 (counts 5, 6, 7 8 and 10).

3. On 4[th] October 2018, he was sentenced to concurrent terms of six years' imprisonment in relation to the
conspiracies to supply a controlled drug and to concurrent terms of eight years' imprisonment in relation to the
offences contrary to the **_Modern Slavery Act. The two sets of sentences were ordered to run consecutively,_**
making a total of fourteen years' imprisonment. Ancillary orders were made with which we are not concerned.

4. The appellant now appeals against sentence with the leave of the single judge.

5. The conspiracies set out in Counts 1 to 4 were pairs of conspiracies. Counts 1 and 2 related to the supply of
crack cocaine and heroin over a period between the beginning of December 2017 and 13[th] February 2018. Counts
3 and 4 reflected the supply of the same drugs from December 2017 through to 7[th] April 2018.

6.  The Modern Slavery Act offences related to three different children. We shall refer to the circumstances of the
children and the dates of the offences as we outline the facts.

7. The appellant was a drug dealer who used children aged 14 and 15 to deal crack cocaine and heroin. The
children came from Birmingham. They were taken by the appellant to Lincoln to live in poor accommodation, from
which they supplied the drugs, both from the accommodation itself and on occasion on the streets of Lincoln. The
supply was organised by a county drugs line known as "Castro". The line was used within four different mobile
telephones over a period of around four months at the end of 2017 into early 2018. The appellant was one of those
who used the line.


-----

8. Although the two conspiracies to which the appellant pleaded guilty reflected two different periods of activity, the
reality is that his drug dealing and trafficking carried on unabated for a period from just before Christmas 2017 until
6[th] April 2018, which is when he was arrested.

9. The children with whom this case is concerned have been made the subject of lifetime anonymity orders.
Therefore, we shall refer to them by letter.

10. "H" was a boy aged 15. On the afternoon of 23[rd] December 2017, he left his home in Birmingham, saying that
he would be back by 11pm. In fact, that afternoon H met the appellant. He was driven in the appellant's Seat car
from Birmingham to Lincoln. H spent the next month in Lincoln, living at an address in Foster Street from where he
supplied crack cocaine and heroin. On one occasion in the middle of January 2018, he was seen by police with the
appellant and an unidentified man close to Foster Street.

11. H's family were hugely concerned for his safety. There was evidence that, during the time he was away from
home, his father took two weeks off work to look for his son.

12. After about 4 weeks H was taken back to Birmingham by the appellant. When he arrived home on 23[rd] January
2018, H was thin, his hair and nails were long, and his clothes were filthy.

13. It was not long before H was taken again from Birmingham to Lincoln by the appellant in his car. This was on
30[th] January 2018. He was reinstated at the Foster Street address. He resumed dealing in Class A drugs.

14. The day before H was taken back to Lincoln, the appellant took another 15 year old boy, "A", from Birmingham
to Hartlepool. Then on 6[th] February 2018, the appellant drove to Hartlepool, collected A and went from Hartlepool
to Birmingham via Lincoln. He left A in Lincoln at the Foster Street address. A sold Class A drugs, both from that
address and on the streets of Lincoln. During the period that A was in Lincoln, A's family were able to make contact
with him via Facetime or Skype (or similar). The family thought that A must have been on drugs of some kind,
because his eyes were red, his voice was shaky and he looked "terrible".

15. It is of note that on 6[th] February 2018, the appellant was stopped by the police as he came off the motorway
close to Birmingham, having left A in Lincoln. His Seat car was seized, together with a mobile phone which in due
course was found to have housed the Castro number. This left the appellant without a car for a period, and it
required a change of number for the county line.

16. The appellant was not detained (or at least not kept in custody for any length of time). Nonetheless, this was
an obvious indication to him that the police were interested in his activity. He carried on regardless.

17. On 8[th] February 2018, a new number was introduced to the county line. Text messages were sent to over 50
contacts, trying to obtain business. It was that same day that A was seen by police dealing Class A drugs on a
street in Lincoln. Also on that day, a telephone number being used by H contacted the appellant.

18. On 12[th] February, the appellant made a return journey by taxi from Birmingham to Lincoln, at a cost of £170.
He visited Foster Street and he met H.

19. Later that day, the address at Foster Street was searched. It turned out to be a flat in poor and dangerous
condition. H and A were at the address. Recovered from the flat were weapons, mobile phones and wraps of crack
cocaine and heroin. H and A were returned to their homes in Birmingham. Happily for him, that was the last
involvement of H in drug dealing.

20. The day after the search of Foster Street, of which the appellant must have been aware, he bought a new car.
Over the following weeks, he made numerous journeys to different towns. By this time, a new mobile number was
being used for the Castro line. The movement of this number, as later tracked, matched journeys made by the
appellant's car.

21. On 26[th] March 2018, the appellant took A, with whom he had previously been involved, and now "D", a 14 year
old girl, by train from Birmingham to Lincoln. They were placed in a new address in Hermit Street. Foster Street by


-----

now was recognised as no longer safe to use. From their arrival in Lincoln, up until 6[th] April, A and D sold crack
cocaine and heroin as part of the county line operation. On at least one occasion during that time, the appellant
drove from Birmingham to Lincoln with the Castro line telephone in his possession as he did so.

22. On 6[th] April 2018, a search warrant was executed at Hermit Street. A and D were at the flat. Wraps of Class A
drugs, weapons, mobile phones and around £900 in cash were found at the flat. One of the mobile phones had on
it images of D and A (apparently in Lincoln) with large amounts of cash.

23. On that same day the appellant was arrested in his car. He was en route from Birmingham to Lincoln. He had
with him a mobile telephone, which earlier in that day had been using the Castro number. When interviewed, he
made no comment to all questions.

24. As we have indicated, the appellant pleaded guilty on the day of trial. He tendered his pleas on a written basis.
That basis was not the subject of any Newton hearing. It was in these terms:

"i) It is accepted that he falls into significant role.

ii) His role was that of a trusted informed lieutenant.

iii) It is accepted he was a trusted driver who was also tasked to drive and accompany the children. It is accepted
that he had an operational/management role.

iv) There were others more senior to him who would often liaise with the children using the drugs phone (from
Birmingham), and make the arrangements for the [appellant] and the children to meet.

v) The [appellant] was told where to go and what to do. He was in receipt of instructions from the other more
senior individuals.

vi) Sometimes the [appellant] would hold the drugs line.

vii) It is accepted that the [appellant] had a degree of control over the children as they were prepared to go with him
as required. However, he did not use any force against them on any occasion.

viii) He did not actually enter the flat [at] Foster Street, albeit he went into the entrance.

ix) He was doing this in order to pay off a debt.”

25. The basis of plea involved multiple factors indicating significant culpability. He was very clearly someone in
whom those organising the drugs conspiracies and the concomitant trafficking offences placed substantial trust.
Whether there was direct financial reward to the appellant from the offending or writing off a debt, the appellant's
involvement in the offences was designed to provide him with a financial gain.

26. There were character references from the appellant's parents and sister, and also from two local community
leaders. They all spoke highly of him.

27. In sentencing, the judge first rehearsed the facts as we have set them out. He then turned to consider the
guidelines in so far as they applied to this case, namely, the Sentencing Council guideline in respect of drug
offences. He said this:

"… I take account of the Sentencing Council Guidelines so far as counts 1 to 4 are concerned. For a category 3,
significant role, which yours was, the starting point is four and a half years' imprisonment, with a range of four and a
half to seven years. Here the aggravating feature is that you have used a person under 18 to deliver the drug. On
balance, there were the feature that you have no relevant previous convictions and are still quite young; you are 21
and were 21 at the time of the offences.

I do remind myself that you are before me for four conspiracies …"


-----

The judge could have pointed out, as indeed was the fact, that there were multiple characteristics of a significant
role which would have justified an upward adjustment within the category range. The category of harm was
identified because this was a case of selling direct to users. The judge had to take account of the fact that this
selling occurred in the context of a long-running conspiracy.

28. In respect of the Modern Slavery Act offences, there was no guideline to assist the judge. He said this:

"This is not a case of slavery or servitude. There is no evidence that you used any force or threat of force on any of
these children. There is no suggestion that you forced or tricked them into travelling with you. The essence of the
case is that all these children were very vulnerable. …

Your contribution was to enhance their vulnerability. You took them a hundred miles or more from their home; you
delivered them to an address in Lincoln, which apparently you did not witness but which turned out to be squalid,
lacking proper bedding, damp, cold, stinking of mould. The children had no proper clothing or food. In one address
there was a smell of urine. You were delivering them into what was a situation potentially fraught with danger.
These children were kept away from their homes not just overnight but for weeks."

29. Having identified the factors relating to the Modern Slavery Act offences, the judge turned to the structure of
his sentence. He noted that a statutory aggravating factor in relation to the drugs offences was the fact that
children were used to supply the drugs. He restricted the effect of that aggravating factor simply to that fact. He
separated and distinguished the circumstances in which the children came to supply the drugs. He indicated that
he bore in mind totality and then said this:

"On count 1 to 4 there will be a sentence of six years' imprisonment reduced from seven years to reflect your plea
of guilty at a late stage; that will be concurrent on all counts.  On counts 5 to 8 and count 10, I had considered
imposing consecutive sentences of 32 months reduced from three years to reflect your pleas of guilty in respect of
each child but I have decided that the appropriate sentence is one of eight years' imprisonment, consecutive to the
six years.

Individually, these counts [the Modern Slavery Act counts] would normally justify a sentence of at least five years'
imprisonment."

30. The grounds of appeal are threefold: first, that the sentence of eight years' imprisonment for the offences of
exploitation under the Modern Slavery Act was manifestly excessive; second, that if eight years' imprisonment was
the appropriate sentence, the sentence for the drugs conspiracies should have been reduced; third, a total
sentence of fourteen years' imprisonment failed to reflect totality and the mitigation available to the appellant.

31. In relation to the first ground of appeal, our attention has been drawn to three decisions of this court: Attorney
_[General's Reference No 2 of 2013 [2013] 2 Cr App R(S) 71; R v Connors [2013] EWCA Crim 1165; R v Zielinski](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58X2-N631-F0JY-C3J3-00000-00&context=1519360)_

[2017] EWCA Crim 758. Each of these cases involved vulnerable adults being cajoled and/or bullied into
undertaking forced labour for the offenders, with violence being used or threatened to maintain the subjugation of
the victims.

32. In Attorney General's Reference No 2 of 2013, the offenders were convicted of a conspiracy to require persons
to perform forced labour. That was a different offence to that with which we are concerned, the maximum sentence
being fourteen years' imprisonment. However, the court set out factors which were relevant to the assessment of
the seriousness of such an offence:

(a) the nature and degree of the deception or coercion involved in persuading the worker to join the organisation
and the nature and degree of subsequent exploitation after arrival at the workplace;

(b) the conditions at the workplace, together with the level and methods of control, to ensure that the individual
remained trapped within the organisation;

(c) the level and extent of his vulnerability and the degree of harm (physical, psychological and financial) suffered
by the individual;


-----

(d) the nature and extent of the organisation, the financial objectives and profits actually achieved, the number of
those exploited within the organisation, and the individual offender's role within it. Those factors are relevant to a
greater or lesser extent in relation to the children in this case. The nature of the exploitation was very serious. The
children were housed in very poor conditions. The children were very vulnerable and, by reference to the evidence
of the parents, suffered significantly. The appellant had a significant role in the exploitation.

33. Further consideration was given to the appropriate level for such sentences in _Connors, where it was_
emphasised that _Attorney General's Reference No 2 of 2013_ was not to be regarded as a guideline case. As is
apparent from our analysis thus far the factors as set out in the Attorney General's Reference No 2 of 2013 were
considerations that can apply to cases such as these.

34. Much more recently, in Zielinski (another Attorney General's Reference) the court considered the offence under
the **_Modern Slavery Act with which we are concerned. It was charged in conjunction with conspiracy to require_**
another to perform forced labour. The victims in that case were Polish nationals who had been brought to this
country on a false promise, required to live in squalid conditions, and forced to work for a pittance. Violence was
used if the victims tried to leave. In Zielinski this court increased the sentence of four years' imprisonment imposed
by the judge in the Crown Court, to one of seven years' imprisonment.

35. On behalf of the appellant, Miss Stuart-Smith submits that these cases have limited relevance. We agree, but
not necessarily for the reasons she suggests. She argues that the forced labour cases have features which make
them more serious than the facts of this case. To the extent that those cases involve the threat and/or use of
violence and the exploitation of people over a prolonged period (many months, if not years), such a proposition is
correct. However, those cases did not involve children. They did not involve the victims being required to commit
serious criminal offences. In this case the appellant's offending meant that children aged 14 and 15 were exposed
to the trade in Class A drugs. Such a trade is dangerous to those who are involved in it, never mind those buying
the drugs. It is for those reasons that we are not greatly assisted by the forced labour cases. This case involved
factors, as we have set out, which significantly increased the seriousness of the offending.

36. Miss Stuart-Smith argues that the appellant did not create the vulnerability of H, A or D; that the children had
been groomed and exploited prior to his involvement. That may be so, but the appellant knowingly took full
advantage of the position. The fact that the children were prone to go missing – which in the grounds of appeal it is
said that they were – does not improve the appellant's case. It simply emphasises their vulnerability.

37. Just as the court in Attorney General's Reference No 2 of 2013 did not engage in setting a guideline for the
offence with which it was concerned, so it is not for us to do so for the offence under section 2 of the **_Modern_**
**_Slavery Act. What we can do, as the court did in the_** _Attorney General's Reference, is to identify relevant_
considerations. First, where the other person whose travel is arranged with a view to exploitation is a child, then the
offence inevitably will be more serious than a case where the person is an adult. Second, where the exploitation of
itself involves the commission of serious criminal offences, the exploitation offence will be especially grave. Third,
the number of children whose travel is facilitated or arranged will be of importance. Fourth, the offence will be
aggravated if the same child is the subject of travel with a view to exploitation more than once. We note that all of
those features are present on the facts of this case.

38. In our judgment, of themselves the sentences imposed by the judge for the offences contrary to the Modern
**_Slavery Act were entirely appropriate. His approach of aggregating the sentences so that concurrent sentences_**
were imposed on each count was the correct approach. We shall return shortly to whether, in the overall
circumstances of the appellant, it was appropriate to impose sentences of eight years' imprisonment.

39. The second ground of appeal is that, given the aggregate sentence imposed for the **_Modern Slavery Act_**
offences, there should have been some reduction in the sentences imposed in relation to the drug offences. To
have force, this proposition depends on a conclusion that the sentences for those drug offences were not tailored to
take account of the eight years' imprisonment imposed for the Modern Slavery Act offences.

40. Part of that argument depends on the proposition that there was double-counting involved in the sentence. The
judge recognised that there was a statutory aggravating factor of the supply of drugs by children under 18 He


-----

indicated that he took it into account in relation to the drugs offence. However, he stated that, save to this limited
extent, nothing in terms of the aggravating features involved in the **_Modern Slavery Act offences affected his_**
sentence for the drug offences. We consider that there is nothing in his reasoning to indicate otherwise. The judge
determined by reference to the definitive guideline that the conspiracies fell within category 3 of the guideline,
because they involved street dealing. That gave the starting point of four and a half years' custody with a category
range up to 7 years' custody. He then had to consider these matters:

(1) The offending involved two kinds of Class A drugs;

(2) There were two conspiracies based at two quite separate addresses;

(3) This was a county lines case. Such cases, as was said in R v Ajayi [2017] EWCA Crim 1011, carry with them
the hallmarks of professional crime above and beyond ordinary street dealing. The facts of this case demonstrate
that very clearly.

(4) The offending was spread over a number of months so that the quantity of drugs involved must have been
significant.

41. Taken by themselves, we are quite satisfied that, for the drugs offences, a total sentence well in excess of six
years' imprisonment, even after credit for the late guilty plea, would have been justified. Thus, the overall sentence
on the face of it made proper allowance for totality. We are quite satisfied that the judge was entitled to impose
consecutive sentences. The Modern Slavery Act offences were distinct, with separate elements requiring separate
recognition.

42. The third ground of appeal is that the overall sentence of fourteen years' imprisonment, on standing back, did
not take sufficient account of the principle of totality. Further, it failed sufficiently to reflect the mitigation available to
the appellant. That mitigation consisted principally of his age and his relative lack of criminal history. It is the latter
factor which has given us cause for concern. We have concluded that the sentence imposed did not allow
sufficiently for the appellant's youth or for his personal background.

43. The sentence imposed on the appellant was equivalent to a sentence after trial of fifteen and a half years'
imprisonment. That is a very long sentence for a 21 year old without any real criminal history. We do not in any
way shrink from the fact that a man who becomes involved in offending such as this, even if he does not play the
leading role, must recognise that he is involved in very serious criminality. Anyone who commits offences which
involve the exploitation of children to sell Class A drugs in the circumstance we have outlined must expect condign
punishment. Had the appellant been older, and had he had any kind of significant criminal history, there would
have been absolutely nothing wrong with the sentences imposed. Arguably, in such circumstances, they might
even have been longer.

44.  But we have reflected on the appellant's relative youth. The general principles set out in Clarke and others

_[2018] EWCA Crim 185 in relation to offenders who have achieved notional adulthood but who cannot be described_
as being of full maturity apply to some extent to this appellant. His criminality was sustained and had the hallmarks
of professional crime. Thus, the warning against treating the age of eighteen as a cliff edge carries less weight than
it does in relation to offences committed on the spur of the moment. Equally, someone of the appellant's age and
prior criminality cannot be treated in the same way as a mature adult. Standing back. we have come to the
conclusion that, given the age and background of the appellant, the sentences imposed were too long.

44. We take the view that the overall sentence, rather than fourteen years' imprisonment, should have been one of
twelve years' imprisonment. We shall achieve that by taking the same approach as did the trial judge, namely, by
imposing the more significant sentence in relation to the Modern Slavery Act offences, concurrent on each count,
and a slightly lesser sentence in relation to the drugs offences.

45. Therefore, we quash the sentences of eight years' imprisonment in relation to each of the Modern Slavery Act
offences and substitute in their place sentences of seven years' imprisonment. Likewise, we quash the sentences


-----

for conspiracy to supply Class A drugs, and substitute in their place sentences of five years' imprisonment. That
will lead to a total sentence of twelve years' imprisonment. Accordingly, and to that extent, this appeal is allowed.

46. We emphasise, before we leave the appeal, that these were very grave offences. Anybody who becomes
involved in such offending will receive a long sentence by way of deterrence. For a man of 21, without a criminal
history, twelve years' imprisonment justifies that description.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

# R v Mohammed [2022] EWCA Crim 713

Court of Appeal, Criminal Division

Edis LJ, Farbey J, and HHJ Potter

8 April 2022Judgment

NON-COUNSEL APPLICATION

_________

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

1. JUDGE POTTER: On 12 March 2021 in the Crown Court at Isleworth, before His Honour Judge Ferris,
the applicant was convicted after trial of offences of requiring a person to perform forced or compulsory
labour, contrary to section 1(1)(b) of the **_Modern Slavery Act 2015 (count 1), two offences of being_**

concerned in the supply of class A drugs, contrary to section 4(3)(b) of the _[Misuse of Drugs Act 1971](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)_ ‑

these two offences related to the supply of heroin and cocaine respectively (counts 2 and 3 on the
indictment).

2. On 22 June 2021 before the same constitution the applicant was sentenced to an extended determinate
sentence of 14 years in respect of count 1, the custodial term of which was 12 years, the extended licence
period being two years, pursuant to section 279 of the _[Sentencing Act 2020 and concurrent determinate](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)_
sentences of 12 years' imprisonment in respect of counts 2 and 3. He was also ordered to pay a surcharge
order.

3. The applicant renews his application before us for leave to appeal against sentence and for a
representation order after refusal by the single judge.

The facts

4. Following an incident on 15 October 2019, the police conducted inquiries the following day at the home
address of a man called Brian Bates in Brabazon Road, Hounslow, Greater London. That home address

was a flat within multi‑occupied premises. At the address the police found that Mr Bates was absent, but

subsequently were able to contact him. He then agreed to assist the police with providing their enquiry
with an Achieving Best Evidence interview which subsequently took place on 25 October 2019. In that
interview Mr Bates stated that the applicant and others had been dealing heroin and cocaine at his address
and that they had also forced him under threat of violence to sell the drugs over a considerable period from


-----

the flat. He had suffered violence from the applicant and his associates and witnessed others in a similar
position to his being subjected to violence as well. This had been happening for several years. He said he
felt like a prisoner in his own home. Mr Bates had been a user of class B drugs. The applicant and others
had converted him to heroin use and he had become addicted. As a result he had fallen under the control
of the applicant and his associates. On a typical day about 30 people would call at Mr Bates' flat to buy
heroin and cocaine and on average he would sell about £1,200 to £1,400 worth of these drugs. He would
hand that money over to the applicant and others.

5. Mr Bates said the applicant and his associates were in control of the operation and would cut up drugs
at his flat. Mr Bates was compelled to keep his mobile phone active at all times and always had to answer
all calls at his door. He was frightened of the applicant and his associates.

6. The applicant was arrested on 16 December 2019 and in interview denied all matters. He was born on
26 June 1982. He had 22 previous convictions for 31 offences between 2002 and 2018. They included
possession of class B drugs, theft, common assault, possession of class A drugs with intent to supply,
affray and failing to surrender to bail. In October 2013 the applicant was sentenced to 32 months'
imprisonment for two counts of supplying class A drugs.

The sentence

7. The applicant was sentenced with the assistance of a pre‑sentence report. In that report the applicant

was assessed by the author as posing a high risk of serious harm to known adults. The sentencing judge
also had access to a letter provided to him by the applicant and to two character references.

8. The judge's sentencing remarks make it plain that he considered carefully where within the guidelines
the applicant's offending fell to be sentenced. He correctly considered and applied the criteria within the
dangerousness provisions and the principle of totality.

9. In seeking leave to appeal against the sentence imposed upon the applicant, the applicant relies upon
the following grounds:

1. The sentence imposed was too high considering that the applicant did not have any convictions for
offences involving any kind of a violence (sic) and it was not alleged that he had used violence in the
matter before the court.

2. His good character and personal mitigation were not sufficiently taken into account by the judge.

10. Refusing leave to appeal sentence, the single judge gave the following reasons:

i. "I have considered the papers in your case and your grounds of appeal.

ii. You had 22 previous convictions for 31 offences, including assault in 2004 and 2006 and supplying
heroin and cocaine in 2013. You forced your enslaved victim to keep, package and sell drugs from his
home by threats of violence. He was a vulnerable person, being a drug user and previous offender. The
drug supply operation was on a large scale and carried on for three years. The enslavement continued for
at least seven months. The judge had the benefit of presiding over your trial. He placed the drugs offences
in Category 2 and found you took a leading role. The starting point for those offences under the Definitive

Guideline was 11 years and the range was 9‑13 years. The seriousness of the offences was aggravated by

your previous conviction for supplying Class A drugs. You remained in denial of any wrong‑doing. The

Pre‑Sentence Report writer assessed that you posed a high risk of serious harm due to the nature of your

offences and the impact on your victim and having regard to your offending history, lifestyle, abuse of
drugs and alcohol and associates.

iii. The judge was entitled to find that you were a dangerous offender and the sentence for the totality of
your offending fell within the appropriate range. It is not arguable that your sentence was manifestly
excessive."

Decision


-----

11. We agree entirely with the single judge for the reasons he gave. The sentencing judge correctly
applied the guidelines to the applicant's offending and made an appropriate assessment of the applicant
within the dangerousness criteria. The applicant's arguments are without merit. He does have previous
convictions for violence and there was evidence in this case that the applicant once more participated in
violent offending to enslave his victim. Such personal mitigation as was available to the applicant was
considered by the sentencing judge. The sentence he imposed could not possibly be viewed as manifestly
excessive.

12. We therefore refuse leave to appeal in this case and the application for a representation order.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

