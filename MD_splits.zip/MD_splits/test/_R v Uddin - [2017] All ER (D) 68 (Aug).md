# *R v Uddin [2017] All ER (D) 68 (Aug)

[2017] EWCA Crim 1072

Court of Appeal, Criminal Division

EnglandandWales

Hallett VP, Green J and Judge Taylor

26 July 2017

**Criminal law – Domestic violence – Causing or allowing death of child or vulnerable adult**
Abstract

_Criminal law – Domestic violence. The words 'or otherwise' in the definition of 'vulnerable adult' in s 5(6) of the_
_Domestic Violence, Crime and Victims Act 2004, had created a separate third category, which could simply be_
_defined as: a cause (other than physical or mental disability or illness or old age) which had the effect on the victim_
_of significantly impairing his ability to protect himself from violence, abuse or neglect. Accordingly, the Court of_
_Appeal, Criminal Division, dismissed the defendant's appeal against a conviction for an offence of causing or_
_allowing the death of a vulnerable adult, contrary to s 5 of the Act._
Digest

The judgment is available at: [2017] EWCA Crim 1072

Section 5(6) of the Domestic Violence, Crime and Victims Act 2004 provides: 'In this section … 'vulnerable adult'
means a person aged 16 or over whose ability to protect himself from violence, abuse or neglect is significantly
impaired through physical or mental disability or illness, through old age or otherwise.'

**Background**

The present appeal focused upon the interpretation of the phrase 'or otherwise' in the definition of 'vulnerable adult'
in s 5(6) of the Domestic Violence, Crime and Victims Act 2004 (for the full provision of s 5, see [16] of the
judgment).

The deceased was one of eight children. She and her two sisters were treated badly by their mother and removed
from her care. In 2010, their oldest brother, SU, and his wife, SB, were awarded custody of the three girls. The
deceased also lived with other members of the family, including the defendant older brother.

In October 2014, when the deceased was 19 years of age, she was beaten to death (55 separate areas of injury
were found). Police inquires revealed a lengthy history of isolation and sustained physical and emotional abuse of
the deceased. SU and SB had believed in discipline of an extreme kind that included beatings on a regular basis
and degrading punishments. The other members of the family, including the defendant, were either active or
complicit in the beatings and punishments.

In December 2015, the defendant stood trial with six members of his family, two were charged with murder (SU and
SB) and all were charged with an offence contrary to s 5 of the Act. SB was convicted of murder. SU was acquitted
of murder and convicted of causing or allowing the death of a vulnerable adult, contrary to s 5 of the Act. The


-----

defendant was also convicted of causing or allowing the death of a vulnerable adult, contrary to s 5 of the Act. The
defendant appealed against conviction.

**Issue and decision**

Whether the judge had been wrong to find that there was evidence from which the jury could conclude that the
deceased had been a 'vulnerable adult' within the meaning of s 5(6) of the Act and, therefore, had been wrong to
reject a submission of 'no case to answer' on the s 5 offence.

The Act imposed a new and positive duty on members of the same household to protect from serious physical harm
children or vulnerable adults, whose ability to protect themselves was significantly impaired. There may have been
many causes of significant impairment, but in the definition of 'vulnerable adult', the Act expressly identified only two
categories: disability or illness (the first category) and old age (the second category). The categories were clearly
distinct given the repetition of the word 'through'. The words 'or otherwise' envisaged a third category, other than
and different from the first and second categories.

Common to all the three categories, a causal link existed between the conditions described in each category and
the significant impairment of the ability to protect oneself against violence, abuse or neglect. Accordingly, by reason
of that causal link, the third category (encompassed by 'or otherwise') could simply be defined as: a cause (other
than physical or mental disability or illness or old age) which had the effect on the victim of significantly impairing his
ability to protect himself from violence, abuse or neglect.

Whilst the first and second categories were conditions intrinsic to the victim through which the ability to protect
himself was impaired, the cause of such conditions (other than old age) could be either intrinsic or external, for
example the mental or physical trauma suffered in an accident. The natural meaning of 'otherwise' did not
necessitate that the cause be intrinsic. It could be an external cause, through which the victim's ability to protect
himself was impaired.

In principle, there was no limit to the facts and circumstances that might lead to the victim finding himself in a state
of impaired ability to obtain protection. None of the categories were closely defined. In the first category, any illness,
physical or mental disability, provided there was evidence that it caused significant impairment, would suffice. The
concept of illness and physical and mental disability was a broad one. The illness or disability did not have to be a
'recognised medical condition' (as, for example, in the Homicide Act 1967). The jury would decide if the victim was
suffering from an illness or disability and if so, its impact on the adult's ability to protect himself. The concept of old
age in the second category was also not limited. The jury would be left to determine what constituted old age and
whether it caused a significant impairment.

Similarly, the jury would have to determine whether a victim fell into the third category. The inquiry the court would
have to perform was fact and context sensitive. The causes of vulnerability may be physical, psychological and/or
[they may arise from the victim's circumstances as in R v Khan ([2009] 4 All ER 544). However, the third category](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G1HW-00000-00&context=1519360)
was not limited to cases of 'utter dependency' as postulated in _Khan. A victim of sexual or domestic abuse or_
**_modern slavery, for instance, might find himself in a vulnerable position, having had suffered long term physical_**
and mental abuse leaving them scared, cowed and with a significantly impaired ability to protect themselves (see

[32], [37]-[40] of the judgment).

In the present case, the judge had referred to the 'emotional and/or psychological damage' that the deceased had
suffered through the way she had been treated in the household as the identified set of circumstances leading to
her vulnerability. In particular, the deceased was subjected to long term bullying and beatings. She had been
punished in bizarre and degrading ways for the most innocuous of alleged misbehaviour. She had had her liberty
curtailed. She had had her ability to communicate with others restricted. She was subjected to powerful cultural and
family pressure. Notes she had written had suggested the family's controlling and cruel behaviour had left her
feeling that it had been her fault that she was beaten and punished. When she had confided in a friend and that
intelligence had gotten back to the family she had been punished, thereby deterring her again from reporting her
ordeal to third parties and preventing her from taking steps to protect herself. Accordingly, the deceased had been,


-----

in a very real and tangible way, vulnerable to the violence inflicted upon her and the control exerted over her by her
family. The judge, therefore, had been right not to withdraw the case from the jury.

The case was exactly the kind of circumstances Parliament had intended to cover in creating the new duty. There
was nothing undesirable as a matter of law or social policy in holding to account someone in the position of the
defendant. He had been a member of the same household and had had frequent contact with his younger sister. He
had to have known how she was being treated; he had known or ought to have known of the significant risk of
serious physical harm to her; and she had been killed in an unlawful act in circumstances of the kind he had
foreseen or should have foreseen. Far from taking steps to protect her, at the very least, he had condoned the
treatment of her and, at the worst, he had been actively involved in it and/or encouraged it (see [46]-[49] of the
judgment).

_R v Khan_ _[[2009] 4 All ER 544 explained.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G1HW-00000-00&context=1519360)_

Appeal dismissed.

David Etherington QC (instructed by Faradays Solicitors Ltd) for the defendant.

Stuart Trimmer QC (instructed by the Crown Prosecution Service) for the Crown.
Manveer Cheema Barrister.

**End of Document**


-----

