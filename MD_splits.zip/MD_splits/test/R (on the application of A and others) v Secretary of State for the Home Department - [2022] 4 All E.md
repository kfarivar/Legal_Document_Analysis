# R (on the application of A and others) v Secretary of State for the Home
 Department [2022] 4 All ER 615

[2022] EWHC 360 (Admin)

QUEEN'S BENCH DIVISION (ADMINISTRATIVE COURT)

FORDHAM J

1, 18 FEBRUARY 2022

**Parliament — Privilege — Consultation — Consultation process to inform decision-making as to design of**
**primary legislation — Judicial review challenge to decisions made regarding design of consultation**
**process on grounds of indirect discrimination and failure to comply with common law requirements of**
**lawful consultation — Whether justiciable — Equality Act 2010, ss 19, 29(6), 149, Sch 3, para 2, Sch 18, para**
**4.**

The claimants sought to challenge the consultation process that the defendant Secretary of State had employed as
part of the development of a 'New Plan for Immigration' presented to Parliament and leading to the introduction of
the Nationality and Borders Bill, in particular the decisions not to have translations of consultation documents in
languages beyond English and Welsh, not to make invitation-only engagement sessions available more widely, and
not to give greater clarity in the description of proposals in the consultation documents. They sought a declaration
that the arrangements for consultation were indirectly discriminatory contrary to s 29(6)[a] read with s 19 (definition of
[indirect discrimination) of the Equality Act 2010, that in deciding on those arrangements the Secretary of State had](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
breached s 149[b] of the 2010 Act (the public sector equality duty, 'PSED') and that the Secretary of State had failed
to comply with the common law requirements of a lawful consultation, as well as a mandatory order requiring the
Secretary of State to re-open the consultation for a further fixed period and damages for breach of s 19 of the 2010
Act. The claimants relied on the common law requirements for a lawful consultation derived from R v Brent London
_BC, ex p Gunning (1985) 84 LGR 168, that (i) consultation had to be at a time when proposals were still at a_
formative stage; (ii) the proposer had to give sufficient reasons for any proposal to permit of intelligent consideration
and response; (iii) adequate time had to be given for consideration and response; and (iv) the product of
consultation had to be conscientiously taken into account in finalising any statutory proposals. Their application for
permission for judicial review was initially refused, on the grounds, inter alia, that the court could not grant the relief
sought without offending against the principle that the court could not interfere with a

1

minister's decision to lay a Bill before Parliament, or seek to prevent Parliament from considering a Bill, that para
2(1)[c] of Sch 3 to the 2010 Act stated that s 29 of the Act did not apply to preparing, making or considering an Act of

a Section 29(6) provided: 'A person must not, in the exercise of a public function that is not the provision of a service to the
public or a section of the public, do anything that constitutes discrimination, harassment or victimisation.'

b Section 149, so far as material, provided: '(1) A public authority must, in the exercise of its functions, have due regard to the
need to—(a) eliminate discrimination, harassment, victimisation and any other conduct that is prohibited by or under this Act; (b)
advance equality of opportunity between persons who share a relevant protected characteristic and persons who do not share it;
(c) foster good relations between persons who share a relevant protected characteristic and persons who do not share it.'

**[*616]**


-----

Parliament or a Bill for an Act of Parliament and para 4[d] of Sch 18 to the 2010 Act excluded functions in connection
with proceedings in the House of Commons from the scope of s 149 of the 2010 Act. The claimants renewed their
application. They accepted that there was a principle of non-justiciability rooted in the Bill of Rights and reflected in
case law, but argued that the judicial review court could, in principle, entertain a judicial review challenge tailored to
impugning a decision about process (whether relating to standards of legally adequate consultation or the
application of the PSED), and tailored to seeking a declaration of a breach of the law in the conduct of the process,
and could do so without the claim, the analysis by the court, or the remedies granted by the court involving any
'vitiation' or 'interference' so far as concerned the substantive decision. They submitted that decisions as to the
design of a consultation and engagement process were acts which were distinct from decisions made in
consequence of a consultation and engagement process. They also submitted that the decision-making process in
designing a consultation process was a public function to which the prohibition on indirect discrimination and the
PSED applied.

**Held – The court's supervisory jurisdiction on judicial review did not extend to the court policing the** _Gunning_
standards in the context of a consultation which was concerned with 'delivering effective legislative change', and
whose culminating substantive decision necessarily entailed the design of a Bill of primary legislation to be
introduced into Parliament. It was not possible to treat the _Gunning standards as being legally applicable to_
'process decisions' about 'the design of the decision-making process', in a manner which was distinct from and
insulated from the substantive decision-making as to the design of the Bill. Consultation was really about
'participation in' a 'decision-making' process. Whether or not a judicial review claimant was seeking declaratory
relief only, and whether or not the judicial review court tailored or refused remedies, it was the legal logic of a court
holding that the procedure that led to a substantive decision was unlawful, that the substantive decision was in law
'vitiated'. A declaration that an applicable legal standard was breached in the consultation and engagement process
culminating in the operative decisions as to the design of a Bill to introduce into Parliament, would clearly constitute
a breach of Parliamentary privilege and the constitutional separation of powers. Such a declaration would raise
questions about whether some step ought to be taken as a result. If government did decide to respond, that would
stand to disrupt the Parliamentary timetable, and, even if it did not, the court's judgment might cast a legal 'shadow'
over the product of the consultation which would itself stand, in the circumstances of the present case, as an
interference in the Parliamentary process. It was not arguable, with a realistic prospect of success, that the Gunning
standards were legal standards engaging the supervisory jurisdiction of the judicial review court where government
had chosen to undertake a 'consultation and engagement process', for the purposes of 'delivering effective
legislative change', where the outcome would necessarily be substantive decisions as to

2

the design of a Bill to be introduced into Parliament. The 2010 Act duties invoked by the claimants in the present
case were also inapplicable to the function of designing the 'consultation and engagement' process which was the
focus of the present case. Impugning decisions taken as to the design of the 'procedure' would entail the court
being invited to hold that 'the procedure that led to legislation being enacted was unlawful', which had been
identified in case law as impermissible in the context of understanding the reach of the PSED. Moreover, if 'the
taking of decisions about procedure' relating to the 'design of a consultation' which culminated in a substantive
decision about the design of the Bill of primary legislation to be introduced into Parliament was not a 'function' for
the purposes of the PSED, then it had to equally not be a 'function' for the purposes of remediable indirect
discrimination. The same conclusion could be reached by the alternative route of para 2 of Sch 3 and para 4 of Sch
18 to the 2010 Act. The case law made clear that decisions relating to primary legislation – which included 'the
procedure that led to legislation being enacted' and 'the actions of a Government Department leading up to the
making of delegated legislation' – were parts of a function 'in connection with' proceedings in the House of
Commons or the House of Lords or of 'preparing … a Bill' within the meaning of those provisions and therefore ss

c Paragraph 2, so far as material, is set out at [30], below.

d Paragraph 4, so far as material, is set out at [30], below.

**[*617]**


-----

29 and 149 were not applicable. The responsibility for considering 'standards', and 'accountability' in relation to
those standards, was a responsibility falling within the domain of Parliament and its process. The court did not have
a role of identifying legal standards, and enforcing them so as to identify procedural impropriety in the lead-up to
primary legislation, for the purpose of informing Parliament or members of Parliament or informing public debate.
That would be an act of 'interference' which the court was inhibited from undertaking. There was no viable claim for
judicial review having a realistic prospect of success in the present case and, accordingly, permission for judicial
review would be refused (see [21]–[31], [48], below); R (on the application of Adiatu) v HM Treasury _[[2021] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8452-00000-00&context=1519360)_
_[484 applied;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8452-00000-00&context=1519360)_ _R (on the application of LH) v Shropshire Council [2014] PTSR 1052and_ _Warsama v Foreign and_
_Commonwealth Office (Speaker of the House of Commons, interested party)_ _[[2020] 4 All ER 486 distinguished; R v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:612X-6X83-GXFD-83T1-00000-00&context=1519360)_
_Brent London BC, ex p Gunning_ _[(1985) 84 LGR 168,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PN7-SXW0-TXX5-505B-00000-00&context=1519360)_ _R (on the application of Wheeler) v Office of the Prime_
_Minister_ _[2008] EWHC 1409 (Admin), R (on the application of Moseley) v Haringey London BC_ _[[2015] 1 All ER 495,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F64-03Y1-DYBP-M0VK-00000-00&context=1519360)_
_R (on the application of Help Refugees Ltd) v Secretary of State for the Home Dept (Centre for Advice on_
_International Rights in Europe intervening) [2018] 4 WLR 168and R (on the application of Police Superintendents'_
_[Association) v HM Treasury [2021] EWHC 3389 (Admin) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:649J-F0D3-GXF6-82SH-00000-00&context=1519360)_
**Notes**

For substantive grounds for judicial review: consultation, see Halsbury's Laws JUDICIAL REVIEW vol 61A (2018)
para 28.

[For the Equality Act 2010, ss 19, 29(6), 149, Sch 3, para 2, Sch 18, para 4, see Halsbury's Statutes vol 7(1) (2022](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72TB-00000-00&context=1519360)
reissue) 1296, 1312, 1484, 1568, 1661.
**Cases referred to**

_Bank Mellat v HM Treasury (No 2)_ _[[2013] UKSC 39, [2013] 4 All ER 533, [2014] AC 700, [2013] 3 WLR 179.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_

_British Railways Board v Pickin_ _[[1974] 1 All ER 609, [1974] AC 765, [1974] 2 WLR 208, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KN0-TWP1-60TT-00000-00&context=1519360)_
**[*618]**

_[Prebble v Television New Zealand Ltd [1994] 3 All ER 407, [1995] 1 AC 321, [1994] 1 LRC 122, [1994] 3 WLR 970,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61JM-00000-00&context=1519360)_
PC.

_R (on the application of Adiatu) v HM Treasury_ _[2020] EWHC 1554 (Admin),_ _[[2021] 2 All ER 484, [2020] PTSR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8452-00000-00&context=1519360)_
[2198, [2020] IRLR 658, DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60M3-BPX3-CGXG-02XG-00000-00&context=1519360)

_R (on the application of Bloomsbury Institute Ltd) v Office for Students_ _[[2020] EWCA Civ 1074, [2020] ELR 653.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60KG-4XX3-GXFD-81CP-00000-00&context=1519360)_

_R (on the application of C (A Minor)) v Secretary of State for Justice_ _[2008] EWCA Civ 882, [2009] QB 657, [2009] 2_
WLR 1039.

_R (on the application of Help Refugees Ltd) v Secretary of State for the Home Dept (Centre for Advice on_
_International Rights in Europe intervening)_ _[[2018] EWCA Civ 2098, [2018] 4 WLR 168, [2018] All ER (D) 17 (Oct).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TD9-SHN1-DYBP-N09W-00000-00&context=1519360)_

_R (on the application of LH) v Shropshire Council_ _[2014] EWCA Civ 404, [2014] PTSR 1052._

_R (on the application of Moseley) v Haringey London BC_ _[[2014] UKSC 56, [2015] 1 All ER 495, [2014] 1 WLR 3947,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F64-03Y1-DYBP-M0VK-00000-00&context=1519360)_

_[[2014] LGR 823, [2014] PTSR 1317.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DRR-JPR1-DYBR-34Y0-00000-00&context=1519360)_

_[R (on the application of Police Superintendents' Association) v HM Treasury [2021] EWHC 3389 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:649J-F0D3-GXF6-82SH-00000-00&context=1519360)_

_R (on the application of Roudham and Larling Parish Council) v Breckland Council_ _[2008] EWCA Civ 714, [2009]_
[LLR 545, [2009] 2 Costs LR 282.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:585S-8D21-F152-J196-00000-00&context=1519360)

_R (on the application of UNISON) v Secretary of State for Health_ _[[2010] EWHC 2655 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-MTT1-F0JY-C09J-00000-00&context=1519360)_


-----

_R (on the application of Wheeler) v Office of the Prime Minister_ _[[2008] EWHC 1409 (Admin), [2008] All ER (D) 333](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SVC-5KH0-TWP1-70NG-00000-00&context=1519360)_
_[(Jun), DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SVC-5KH0-TWP1-70NG-00000-00&context=1519360)_

_R v Brent London BC, ex p Gunning_ _[(1985) 84 LGR 168, [1985] Lexis Citation 944.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PN7-SXW0-TXX5-505B-00000-00&context=1519360)_

_R v Secretary of State for Health, ex p US Tobacco International Inc_ _[[1992] 1 All ER 212, [1992] QB 353, [1991] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-605D-00000-00&context=1519360)_
WLR 529, DC.

_Warsama v Foreign and Commonwealth Office (Speaker of the House of Commons, interested party) [2020] EWCA_
_[Civ 142, [2020] 4 All ER 486, [2020] QB 1076, [2020] 3 WLR 351.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:612X-6X83-GXFD-83T1-00000-00&context=1519360)_
**Judicial review**

The claimants, A, J, K, B and F, renewed their application for permission for judicial review seeking a declaration
that the consultation arrangements that the defendant, the Secretary of State for the Home Department, had made
on a 'New Plan for Immigration' presented to Parliament leading to the introduction of the Nationality and Borders
Bill were indirectly discriminatory and in breach of common law requirements for a lawful consultation. Permission
had been refused on the papers by Lang J on 11 November 2021.

_Chris Buttler QC and Eleanor Mitchell (instructed by Duncan Lewis) for the claimants._

_Joanne Clement and Raphael Hogarth (instructed by the Government Legal Department) for the Secretary of State._

_Judgment was reserved._

18 February 2022. The following judgment was delivered.

**FORDHAM J.**
**I. Introduction**

**[[1] This is a case about common law standards of legally adequate consultation, and statutory duties in the Equality](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)**
_[Act 2010 ('EA 2010'), sought](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
**[*619]**

to be applied to a consultation and engagement process undertaken to inform decision-making as to the design of a
Bill of primary legislation to be introduced into Parliament. The case comes before the Court as a renewed
application for permission for judicial review, such permission having been refused on papers by Lang J on 11
November 2021 (see para [8] below). The question with which I have to grapple is whether to grant permission for
judicial review. In their submissions on the viability of the claim, Counsel addressed me on justiciability and
arguability. I will address both topics below. Although this is only the permission stage there is quite a lot which it is
appropriate to explain, including about the factual context and about the legal context so far as justiciability is
concerned.

**[2] This was a half-day hybrid hearing, for which I gave directions. What happened was this. One of the Counsel in**
the case had tested positive for COVID but they continued to feel well and were able, unhampered, to view, listen
and address the Court remotely. Everyone else associated with the parties was in the court-room. I gave
permission for the use of mobile phones so that the remote-Counsel's team could communicate with Counsel by the
electronic equivalent of a 'note' or verbal exchange which is the practice when Counsel is in the court-room. There
were some technical issues at Counsel's end – the commonly encountered 'frozen screen' – but we simply paused.
The hearing worked well. Nothing was missed by anyone.
**II. Context**

**[3] On 24 March 2021 the Defendant ('the Secretary of State') presented to Parliament a 'Policy Statement' entitled**
'New Plan for Immigration'. The Policy Statement included seven substantive chapters with these titles: 'Protecting
Those Fleeing Persecution, Oppression and Tyranny'; 'Ending Anomalies and Delivering Fairness in British
Nationality Law'; 'Disrupting Criminal Networks and Reforming the Asylum System'; 'Streamlining Asylum Claims
d A l ' 'S ti Vi ti f M d **_Sl_** ' 'Di ti C i i l N t k B hi d P l S li '


-----

and 'Enforcing Removals Including Foreign National Offenders'. In a short chapter, entitled 'Engagement and
Consultation', the Policy Statement said this:

'To inform the proposals set out in this policy statement and to ensure we can deliver effective legislative
change across the system, we are initiating a comprehensive consultation and engagement process which will
commence from 24 March. The process will be delivered in partnership with an insight and strategy firm, in line
with established principles, as well as taking into account any other relevant statutory duties. As part of this
process, we want to listen to a wide range of views from stakeholders and sectors, as well as members of the
public.

Further details about this process as set out in the information accompanying this publication.'

It was therefore explicit that the purpose of the engagement and consultation was to 'deliver effective legislative
change'. And 'legislative' meant primary legislation. And so it was, on 6 July 2021, that the Nationality and Borders
Bill was introduced in the House of Commons. Substantive Parts of the Bill were concerned with these topics:
'Nationality'; 'Asylum'; 'Immigration Offences and Enforcement'; 'Modern Slavery' and 'Miscellaneous'. The Bill was
accompanied by 84 pages of Explanatory Notes, prepared by the Home Office.
**[*620]**

Subsequently, on 22 July 2021, the Secretary of State presented to Parliament a 22-page document constituting
the 'Government Response' to the 'Consultation on the New Plan for Immigration'.

**[4] The 'consultation' strand of the 'consultation and engagement process' ran for six weeks from 24 March 2021,**
ending on 6 May 2021. It and the other strands are described as follows in the Secretary of State's pleaded
'summary grounds of resistance' (supported by a statement of truth):

'The Secretary of State proactively chose to consult and has considered carefully how to conduct this
consultation and engagement exercise. She was aware that these proposals would require primary legislation
and that, as well as the consultation and engagement exercise … anyone with an interest in the proposals
would be able to raise their views in the ordinary way through their elected representatives as the Bill
progressed through Parliament. The final form of any proposals requiring primary legislation will, ultimately, be
a matter for Parliament. In this light, the Secretary of State decided to structure the consultation exercise by
combining targeted consultation and engagement with stakeholders, with a wider consultation with any
members of the public who may wish to contribute. The Secretary of State engaged “Britain Thinks”, an insight
and strategy consultancy, to advise on, and deliver, the consultation and targeted engagement plan. Britain
Thinks was commissioned as an independent research partner to facilitate core elements of the consultation.
The consultation was extensively publicised, and allowed for multiple opportunities, and methods, for
participation. A list of relevant stakeholders who are likely to have interest and expertise in the proposals was
drawn up, to include relevant oversight and accountability bodies, government agencies and public bodies,
industry and suppliers with an interest, professional bodies and academia, Parliamentary bodies and NGOs.
Many of these NGOs themselves have built up the experience and expertise to represent the views of those
with lived experience of the system.

There were four strands to the consultation. First, a consultation questionnaire. The questionnaire was
delivered via a bespoke platform hosted by CitizenLab on the website domain
www.newplanforimmigration.com. The website included a summary of the objectives for the New Plan for
Immigration, and information about taking part in the consultation. It also included downloadable PDFs of the
New Plan policy statement and UASC family reunion information sheet, plus a questionnaire response form.
PDFs were provided in English and in Welsh. The questionnaire was designed with advice from Britain Thinks
in order to facilitate the fullest responses. It consisted of 26 closed and 19 open questions relating to different
chapters of the New Plan, the UASC Information Sheet, and potential qualities or vulnerabilities impacts of the
proposals. There were no character or word limits for the open text questions, as the Secretary of State is keen
to ensure full and varied feedback is provided …


-----

Second, “stakeholder deep dives”. This consisted of 8 events, each covering one of the following topics: Safe
and legal routes (protection and adult family reunion); Integration; UASC family reunion; Asylum reform; Onestop process; Streamlining appeals and judicial processes; Modern slavery; Equalities and vulnerabilities. The
events took place in April 2021.

**[*621]**

Between 8 and 19 stakeholders were invited to each session, based on those sessions that were most relevant
to the stakeholders' area of expertise. The sessions were divided into breakout groups of up to 6 stakeholders
per group. Each session focused on specific proposals in the Plan (save for the UASC family reunion session,
which gathered stakeholders' broader views) … The Home Office and the Ministry of Justice also held a series
of stakeholder consultation events covering the more technical aspects of the proposals, eg around reform to
British nationality law, rules on expert evidence, legal aid etc …

Third, focus groups with members of the public. Six online focus groups were held, split by age and socioeconomic group, and ensuring there was a spread by location across the UK. The online focus groups focused
on the five main topics in the New Plan and its overall objectives. The following topics were discussed across
the public focus groups: Key objectives of the New Plan, UASC family reunion, safe and legal routes, asylum
reform, views on streamlining asylum claims and appeals, views on disrupting criminality and increasing
removals of those with no right to be in the UK. These events took place between 17 and 19 April 2021.

Fourth, the “lived experience” forum. A series of in-depth interviews and discussion groups were held with
those who have lived experience of the UK asylum system, including those with experience seeking asylum in
the UK and victims of **_modern slavery … These sessions were planned from the outset. The Home Office_**
identified the groups of participants they would particularly like [to] hear from, who had experience of those
parts of the process that would be most likely impacted by the reforms. The Home Office liaised with a number
of NGOs who have existing “lived experience” networks, to identify suitable participants and to obtain their
support in organising such sessions. These networks included British Red Cross' VOICES network, (an
independent organisation run by refugees to help make the transition into British life easier and give refugees
and people seeking asylum a platform for speaking up about their own experiences), Freedom from Torture's
One Strong Voice (a network of individuals and organisations based in the UK with direct lived experience of
the UK immigration and asylum system) and Survivors Speak OUT network, as well as the Salvation Army
(who are responsible for providing specialist support for all adult victims of **_modern slavery in England and_**
Wales). The Home Office was aware of a reluctance on the part of some with lived experience of the system to
discuss matters with the Home Office. The sessions were accordingly conducted by Britain Thinks. Individuals
were assured that all findings would be kept anonymous, Home Office representatives would not be present in
the session and would not be provided with any details about who had taken part in the session that would
enable anyone to be identified. The lived experience sessions took place after the online consultation
questionnaire had closed as it took more time than anticipated to liaise with the NGOs to identify suitable
participants for the focus group and to agree the logistics of the sessions with the NGOs concerned. Five online
focus groups were conducted with those with experience seeking asylum in the UK. Each of these sessions
lasted 90 minutes, with 5–7 participants per group. 3 online focus groups were held with individuals identified
through the VOICES network. 2 online focus groups were held with individuals identified by Freedom from
Torture. Four in-depth interviews were also conducted with

**[*622]**

victims/survivors of **_modern slavery. Participants were recruited via the Salvation Army's network. Where_**
needed, interpreters for these lived experience sessions were arranged by the Home Office or by the relevant
network. Interpreters were requested on two occasions (for Arabic and Edo). The NGOs facilitating the
sessions confirmed that all other participants preferred to participate in English. Where required, support
workers were welcome to attend in a supportive capacity.'

**[5] During the consultation process, on 21 April 2021, the Claimants' solicitors had written a letter which posed a**
series of questions. The first of these was:


-----

'What provision has been made for details of the Policy [Statement] and the consultation to be available and
accessible in any languages other than English? If so, which languages and where are they accessible?'

On 28 May 2021 the Claimants' solicitors filed this claim for judicial review. The 'decision' which was impugned in
the claim form was:

['Consultation on the New Plan for Immigration through arrangements that were: indirectly discriminatory (ss.19](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
and _[29(6) EA 2010); in breach of s.149 EA 2010; in breach of common law requirements for a lawful](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)_
consultation.'

The details of the 'remedies' sought in the claim were:

'1. A declaration that (i) the Secretary of State's arrangements for consulting on the New Plan for Immigration
[were indirectly discriminatory contrary to s.19 EA 2010 (or Article 14 ECHR taken with Article 8); (ii) in deciding](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
on those arrangements, the Secretary of State breached s.149 EA 2010; and (iii) in consulting on the New Plan
for Immigration, the Secretary of State failed to comply with the common law requirements of a lawful
consultation.

2. A mandatory order requiring the Secretary of State to re-open the consultation for a further fixed period.

3. Damages for breach of s.19 (or Article 14 ECHR).'

I say no more about art 14 of the European Convention on Human Rights ('ECHR'), since it was relegated to a
footnote in the Claimants' skeleton argument for the hearing before me and was unmentioned in Mr Buttler QC's
oral submissions. Within the grounds for judicial review (para 13) it was said that the Claimants were requesting a
prompt decision on permission and an expedited substantive hearing, proposing a 21/2 day substantive hearing to
be listed by the end of September 2021.

**[6] The Claimant's pleaded grounds for judicial review said this about the value and purpose of standalone**
declaratory relief (at para 124):

'The Claimants emphasise that, even if a mandatory order were not ultimately granted, declaratory relief would
be of significant value to them and others in their position. This is because, in the event that the Secretary of
State decides to proceed with one or more of the proposals affecting the Claimants, these will be transposed
into a draft bill for consideration by Parliament. It is appropriate and desirable that, if that bill were the product
of an unlawful consultation exercise, the Claimants (and the public at large) should be able to bring this to their
local MPs' attention in order for Parliament to consider what weight to attach to the consultation exercise.'

**[*623]**

Thus, a declaration of unlawfulness in relation to the consultation process was intended by the Claimants to inform
'Parliament', in dealing with the Bill, about what 'weight' to attach to the (unlawful) consultation exercise.

**[7] The focus of the claim, for which permission is sought, rests squarely upon the following: (1) the fact that**
consultation documents were published only in English and Welsh; (2) the fact that certain engagement sessions
were invitation-only and did not allow wider participation (including by the Claimants themselves); and (3) a series
of eight points in the grounds for judicial review (three of which were emphasised in the Claimants' skeleton
argument) on which it is said that the consultation materials breached the principle known as 'Gunning (ii)'. Gunning
(ii) is the second of a suite of four public law standards of legally adequate consultation, derived from _R v Brent_
_London BC, ex p Gunning (1985) 84 LGR 168, and endorsed in_ _R (on the application of Moseley) v Haringey_
_London BC_ _[[2014] UKSC 56, [2015] 1 All ER 495, [2014] 1 WLR 3947(at para [25]) as 'a prescription for fairness'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F64-03Y1-DYBP-M0VK-00000-00&context=1519360)_
(sub-paragraphs added):

'(i) First, that consultation must be at a time when proposals are still at a formative stage. (ii) Second, that the
proposer must give sufficient reasons for any proposal to permit of intelligent consideration and response. (iii)


-----

Third … that adequate time must be given for consideration and response and, finally, (iv) fourth, that the
product of consultation must be conscientiously taken into account in finalising any statutory proposals.'

So as to avoid any confusion, it is worth explaining the phrase 'statutory proposals' in the formulation of Gunning
(iv). What the phrase meant was 'proposals put forward in the exercise of a statutory function'. It did not mean
'proposed primary legislation'. _Gunning_ was a judicial review challenge impugning a local authority's decision to
propose (to the Secretary of State) that a school be closed, in a context where the statute (the Education Act 1944)
made provision regarding the making of such proposals. So far as concerns consultation and 'legislative' functions,
it is well established that 'secondary' legislation – although laid before Parliament – can be impugned on the ground
that it (and the decision to make it) is vitiated by a legally inadequate consultation or unfair procedure. An example
of this is R v Secretary of State for Health, ex p US Tobacco International Inc _[[1992] 1 All ER 212, [1992] QB 353,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-605D-00000-00&context=1519360)_
discussed in Bank Mellat v HM Treasury (No 2) _[[2013] UKSC 39, [2013] 4 All ER 533, [2014] AC 700(at para [146]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_
Equally, it was common ground before me that primary legislation, introduced as a Bill in Parliament (and the
decision to introduce it), cannot be impugned on the ground that it is vitiated by a legally inadequate consultation.

**[8] Lang J's reasons for refusing permission for judicial review were as follows:**

'In my judgment, the Claimants have not established arguable grounds which have a realistic prospect of
success. In March 2021, the Defendant presented her “New Plan for Immigration” Policy Statement to
Parliament which set out a range of policy proposals, most of which require primary legislation. In Chapter 9
the Plan announced a “comprehensive consultation and engagement process” to obtain “a wide range of views
from stakeholders and sectors, as well as members of the public”. An extensive consultation was conducted.
There were over 8,500 responses to the consultation questionnaire, and extensive engagements with

**[*624]**

stakeholder groups, public focus groups, and those with “lived experience” of the asylum system and modern
**_slavery. On 6 July 2021, the Defendant introduced the Nationality and Borders Bill to Parliament._**

In my judgment, this claim cannot succeed because, even if the criticisms of the consultation procedure were
well-founded, the Court could not grant the relief sought, namely, to declare that the consultation was unlawful
and order the Defendant to re-open it, without offending against the principle that the Court cannot interfere
with a minister's decision to lay a bill before Parliament, or seek to prevent Parliament from considering a bill.
The Claimants also face obstacles in pursuing their claims of indirect discrimination, contrary to section 29 of
the … _[EA 2010,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_ and breach of the public sector equality duty in section 149 EA 2010. Paragraph 2(1) of
[Schedule 3 to EA 2010 states that section 29 EA 2010 does not apply to preparing, making or considering an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)
Act of Parliament or a Bill for an Act of Parliament. Paragraph 4 of Schedule 18 to EA 2010 excludes functions
in connection with proceedings in the House of Commons from the scope of section 149 EA 2010.

In any event, I do not consider that the criticisms of the consultation procedure do give rise to arguable grounds
of challenge. The Claimants, who are asylum seekers from El Salvador, Sudan, Yemen and Eritrea, complain
that: (i) they could not participate in the consultation because they do not read English, and the Defendant did
not provide translations in their native languages; (ii) they were not invited to feedback sessions; (iii) the
Defendant's proposals were too vague and there was insufficient time given to respond, so even solicitors and
pressure groups who act for asylum seekers could not provide informed and meaningful responses. The
authorities are clear that it is for the public body charged with performing the consultation to determine how it is
to be carried out, subject only to review on conventional public law grounds. On considering the evidence, in
my view, the Claimants do not have any realistic prospect of success in establishing that the consultation
process was so unfair as to be unlawful. Whilst non-English speakers were at a disadvantage, it was justifiable
for the Defendant to address that difficulty by structuring the consultation so as to encourage engagement from
bodies who represent asylum seekers, and also to engage directly with those who had “lived experience” of the
asylum system and **_modern slavery. The Claimants have not been able to identify any arguable breach of_**
ECHR rights, and so Article 14 is not engaged.'

**III. Justiciability**


-----

**[9] Article 9 of the 1689 Bill of Rights provides: 'That the freedom of speech and debates or proceedings in**
Parliament ought not to be impeached or questioned in any court or place out of Parliament'. Both Counsel cited R
_(on the application of Wheeler) v Office of the Prime Minister_ _[[2008] EWHC 1409 (Admin), [2008] All ER (D) 333](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SVC-5KH0-TWP1-70NG-00000-00&context=1519360)_
_[(Jun). In that case the Divisional Court (at paras [46]–[47]) cited passages from earlier authorities in which the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SVC-5KH0-TWP1-70NG-00000-00&context=1519360)_
Courts had articulated the following points: the principles on which the law of Parliamentary privilege is based
involve 'the requirement of mutual respect by the Courts for the proceedings and decisions of the legislature and by
the legislature (and the executive) for the proceedings and decisions of the Courts'; one of the principles on which
the law of Parliamentary privilege is based is 'the principle of the separation of powers, which in our Constitution …
**[*625]**

requires the executive and the legislature to abstain from interference with the judicial function, and conversely
requires the judiciary not to interfere with or to criticise the proceedings of the legislature'; 'the courts exercise a
self-denying ordinance in relation to interfering with the proceedings of Parliament'; and 'it behoves the courts to be
ever sensitive to the paramount need to refrain from trespassing upon the province of Parliament or, so far as this
can be avoided, even appearing to do so'. Article 9 and these points set the scene for the consideration of
justiciability of the present claim.
_The Claimants' position: 'vitiation' and 'interference'_

**[10] In the course of his submissions, Mr Buttler QC for the Claimants has accepted each of the following. (1) There**
is a principle of non-justiciability, rooted in the Bill of Rights (a constitutional statute), and reflected in the case-law.
(2) It would offend that principle of non-justiciability for the Courts to entertain a challenge, or express any
reasoning, involving: (i) any 'vitiation' of a decision to lay a Bill before Parliament; or (ii) any 'interference' with the
laying of a Bill of primary legislation before Parliament. (3) Impermissible 'vitiation' would be exemplified by a legal
challenge whose target, or subject matter, involved impugning a decision as to the design of primary legislation,
including where that decision has been arrived at following a process of consultation and engagement. (4)
Impermissible 'interference' would be exemplified by a legal challenge whose substantive content, or claimed
remedy, involved impeding or delaying the introduction of a Bill or primary legislation into Parliament (or conversely
which involved dictating that a Bill, or the design of a Bill, be introduced into Parliament). (5) The reach of the
[statutory duties found in EA 2010 fall to be analysed against the backcloth of the principle of non-justiciability, so](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
understood (as is reflected in R (on the application of Adiatu) v HM Treasury _[[2020] EWHC 1554 (Admin), [2021] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8452-00000-00&context=1519360)_
_[All ER 484, [2020] PTSR 2198(at paras [229]–[238])). (6) The statutory duty not indirectly to discriminate (EA 2010](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8452-00000-00&context=1519360)_
_[s 29(6), read with s 19) would not apply to the 'function' of making a substantive decision as to the design of a Bill of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)_
primary legislation to be placed before Parliament; nor would the public sector equality duty ('PSED') (EA 2010 s
149). (7) Nor could the _Gunning principles, as to legally adequate consultation, be invoked to impugn such a_
substantive decision.

**[11] Against that backdrop – which in Mr Buttler QC's submission is as far as the authorities take the principle of**
non-justiciability – he emphasises the following. (1) The appropriateness and importance of characterising as a
distinct act and function of a public authority, and a distinct 'target' for a judicial review claim, decisions regarding
the design of a consultation process. (2) Such decisions would include: process decisions about into what
languages consultation documents are translated; which persons and organisations are invited to engagement
meetings; and what degree of clarity and specificity is used to describe policy proposals in a consultation document.
(3) A claimant for judicial review is entitled to select as the 'target' for judicial review, such decisions as to the
design of the consultation process, with the claim extending no further than that. (4) The judicial review claimant is
entitled to restrict the remedy sought, to a declaration that legal standards applicable to the design of the
consultation process have been breached. (5) Where Government chooses to embark on a consultation process,
designed to inform a substantive decision as to the design of a Bill, common law standards of legally adequate
consultation are in principle applicable and enforceable through the
**[*626]**

supervisory jurisdiction of the judicial review Court, invoked by a claimant who has restricted their claim in these
ways. (6) On the legally correct interpretation of the _[EA 2010,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_ there is in the process decision-making about the
design of the consultation process a 'public function' (see s 31) to which the following can be invoked as applicable
(again by a claimant who has restricted their claim in these ways): the duty not indirectly to discriminate (s 29(6)


-----

read with s 19), with the consequential availability of a declaration of unlawfulness and damages (s 119, read with s
114(1)(a)); and the PSED (s 149), with the consequential availability of a declaration of unlawfulness.

**[12] That approach, says Mr Buttler QC, is consistent with the authorities, including** _Adiatu_ (see paras [18]–[21]
below). It is, moreover, supported by the following points. (1) Decisions as to the design of a consultation and
engagement process are acts which are distinct from decisions made in consequence of a consultation and
engagement process. (2) In public law, a first unlawful act may mean – but does not necessarily mean – that a
second and subsequent act is vitiated and unlawful. (3) A judicial review claimant (like the judicial review Court
itself) can tailor and restrict the scope of the analysis. That means that a judicial review claimant which does not put
before the Court arguments as to a 'vitiating' or 'interfering' consequence is, in deciding not to do so, necessarily
preventing the Court from 'trespassing' in any such way. (4) Where in the authorities there is reference to an
inappropriateness of impugning the legality of a 'process' in relation to a decision to introduce a Bill into Parliament,
such a reference can (if correct) only be to the 'Parliamentary process' of the introduction of the Bill: 'proceedings in
Parliament'. (5) But even if and insofar as any (correct) reference did extend to the inappropriateness of impugning
the legality of a 'prior' process – a process culminating in the substantive decision as to whether a Bill (and if so with
what design) should be introduced in Parliament – that could only (if correct) be because the judicial review
claimant has failed to restrict the nature of the challenge and the remedy sought, to involve 'vitiation' or
'interference'.

**[13] Based on all of this, says Mr Buttler QC, the issues raised in the present case are justiciable and the common**
law _Gunning_ (ii) principle and _[EA 2010 duties are properly invoked as applicable legal obligations in the present](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_
case, restricted to impugning the process decision-making as to the design of the consultation and engagement
process, and supporting the grant by the judicial review Court of a declaration that applicable legal duties were
breached in the design of that process (together with consequential damages arising from the indirect
discrimination). The Claimants' contentions that the consultation engagement process unlawfully denied
participatory rights, by reason of the languages of the consultation document and the restricted nature of the
invitation-only engagement sessions, and by reason of the lack of clarity in the consultation document proposals
involve no inappropriateness, no infringement of the principle of non-justiciability. Since that is at least arguable with
a realistic prospect of success, permission should not be refused on non-justiciability grounds. That, as I see it, is
the essence of the analysis put forward by Mr Buttler QC. Is it right?
_Some basics_

**[14] It will assist the legal analysis to start with some basic observations of my own. (1) Generally speaking, the**
substantive decision of a public authority will involve a process by which that substantive decision is arrived at.
Sometimes, the relevant action of a public authority in judicial review
**[*627]**

proceedings will be the failure to make a substantive decision, in which case there may also be a failure to have any
process by which any decision would have been arrived at. (2) Generally speaking, a process by which a
substantive decision is arrived at will involve a decision or decisions about the nature of the process. An example of
a decision about the nature of the process would be a decision not to convene an oral hearing to inform the
substantive determination about downgraded-classification or release-outcome regarding a prisoner. The
substantive decision about classification, risk or release would involve the decision-making process. The decision
about whether to convene an oral hearing would be a distinct procedural decision. (3) In the same way, in the
context of carrying out a consultation process, the public authority performing the consultation is described as
having the function of determining how the consultation is carried out, including its manner and extent, with those
process decisions being reviewable by a Court on conventional judicial review grounds: see R (on the application of
_Help Refugees Ltd) v Secretary of State for the Home Dept (Centre for Advice on International Rights in Europe_
_intervening)_ _[2018] EWCA Civ 2098, [2018] 4 WLR 168(at para [90](v)). (4) The process, by which a substantive_
decision is arrived at, is likely to be the responsibility of the substantive decision-maker. (5) The design and
implementation of the process is, moreover, likely to be intimately linked to the public authority decision-maker's
thinking about the substantive decision. There is a link between decision-making process and reasoning process.
The link between process and substantive thinking is exemplified in the following: cases concerned with the nature
of the 'sufficiency of the enquiry' undertaken by a decision maker; cases about the substantive decision maker


-----

eliciting informed representations; cases about legally adequate consultation; cases about ensuring that all (but
only) 'relevant considerations' are taken into account; cases about the need for a legally adequate evidential basis
for conclusions; and cases about whether statutory duties of regard (or – as in the case of the PSED – due regard)
are discharged. (6) In the context of the PSED, the link between substantive thinking and process is illustrated by
the description of the PSED as being concerned with 'procedure' rather than with 'outcome' (see eg Adiatu at para

[204]), in the making of 'policy decisions' (see eg Adiatu at para [206]). (7) Legal standards relating to process, and
decisions about process, are linked to the public authority's thinking about the substantive decision and to the
substantive outcome itself. (8) However, those legal standards, and those process decisions, may have a value –
concerned with due process, inclusion and participation – which is independent and free-standing from the way in
which they serve to influence the decision-maker's thinking and the substantive decision. That independence and
freestanding value may be seen in the following: cases about oral hearings; cases about consultation; cases about
eliciting informed representations; and cases about equality considerations. (9) As has memorably been said in
public law, 'context is everything', and it is generally wise 'never to say never'.
_Design of a process: a disability example_

**[15] Mr Buttler QC gave examples (see para [46] below) designed to test the logic of justiciability, in the context of a**
process intended to culminate in a substantive decision as to the design of a Bill of primary legislation to introduce
into Parliament. To his examples, this one of my own can be added. Suppose that a Secretary of State is
contemplating designing a Bill of primary legislation relating to disability rights, and has announced a consultation
and
**[*628]**

engagement process, including public meetings at which relevant ideas will be explained and discussed. Suppose
now that the implementation of the process of consultation and engagement regarding those public meetings
involves decisions to use venues which are inaccessible to wheelchair users. Mr Buttler QC would submit that a
[legal challenge based on the EA 2010 by way of judicial review (or in the county court), seeking a declaration and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
damages, impugning the legality of the decision-making about the process, by which wheelchair access to the
public meetings was denied, would in principle be justiciable. The force and attractiveness of that submission are
obvious. Mr Buttler QC would submit that, if that is so, the same must be true in the present case, regarding: the
decision not to have translations of consultation documents in languages beyond English and Welsh; the decision
not to make invitation-only engagement sessions available more widely; and the decision not to give greater clarity
in the description of proposals in the consultation documents.
_The LH case_

**[16] In R (on the application of LH) v Shropshire Council** _[2014] EWCA Civ 404, [2014] PTSR 1052a 63-year-old_
user of Hartley's Day Centre in Shrewsbury brought a claim for judicial review of the local authority's substantive
decision to close the Day Centre. The grounds for claiming judicial review were breach of the legal standards
regarding consultation (see para [19]) and breach of the PSED (see para [33]). The remedies sought included a
declaration of breach of applicable duties, and a mandatory order that the substantive decision to close the Day
Centre should be reconsidered, after a proper consultation process (see paras [19](vii), [35]). The claim succeeded
in the Court of Appeal, on the basis that there had been an unlawful failure to consult service users and relatives,
before making the substantive decision to close the Day Centre (see para [31]). There was no separate breach of
the PSED (see para [34]). However, in circumstances where the Day Centre had by now closed and all the staff
had been dispersed, the Court of Appeal declined to quash the substantive decision or to order a consultation, as
not being 'consonant to good administration' (see para [36]). The Court nevertheless considered it appropriate to
grant a declaration, formally recording that the failure to consult had resulted in the local authority acting unlawfully
(see paras [37]–[38] and [2014] PTSR 1052 at 1065). Mr Buttler QC relies on LH as illustrative of the fact that the
judicial review Court could, in principle, entertain a judicial review challenge tailored to impugning a decision about
process (whether relating to standards of legally adequate consultation or the application of the PSED), and tailored
to seeking a declaration of a breach of the law in the conduct of the process. It could do so without the claim, the
analysis by the Court, or the remedies granted by the Court involving any 'vitiation' or 'interference' so far as
concerns the substantive decision. He submits that this logic follows through to a case in which the substantive


-----

decision concerns the design of a Bill of primary legislation to be introduced into Parliament, and its introduction into
Parliament.
_Purposes of seeking a declaration in this case_

**[17] Asked about the purpose of the present claim for judicial review proceeding to a substantive hearing, Mr Buttler**
QC emphasised two strands which he submitted demonstrated that the claim is appropriate and has a proper utility.
One strand was the idea of 'vindication' as to the rights and
**[*629]**

position of the Claimants, they having been disadvantaged by the design of the process. That 'vindication' would
come through the Court recognising the unlawfulness of that disadvantageous treatment and, in the case of indirect
[discrimination (EA 2010 s 29(6) read with s 19), through the Court awarding them damages. Mr Buttler QC likens](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)
that to the 'vindication' of the claimant in LH, through the grant of the declaration of unlawfulness in that case. Mr
Buttler QC's other strand was the idea of providing relevant legal clarity 'for the Secretary of State' and 'for
Parliament'. Mr Buttler QC told me that the purpose of declarations of unlawfulness in this case would lie in:

'… making clear to the Secretary of State and to Parliament what was and wasn't lawful in the consultation
process, thereby giving Parliament a free choice to act …'

This strand was reflected in the passage in the pleaded grounds for judicial review which addressed the purpose of
a standalone declaration (see para [6] above), describing it as:

'… appropriate and desirable that, if [a] bill were the product of an unlawful consultation exercise, the Claimants
(and the public at large) should be able to bring this to their local MPs' attention in order for Parliament to
consider what weight to attach to the consultation exercise.'

_The Adiatu case_

**[18] One key question which emerged from the arguments in the present case concerns an important passage in**
the judgment in Adiatu. Here, the Divisional Court was addressing the question whether the PSED (EA 2010 s 149)
was applicable to 'decisions that are given effect by primary legislation'. The challenge on this part of the case was
to the decision to amend the scheme for statutory sick pay ('SSP') by virtue of regulations (see Adiatu at para [33])
in response to the COVID pandemic without at the same time removing the lower earnings limit ('LEL') (see para

[36](2)(c)), something which would necessitate an amendment to primary legislation. The claimants in Adiatu were
arguing that the decision-making relating to amendment of the SSP scheme had not involved the due regard
required by the PSED, that being a duty concerned with 'procedure' (see para [204]). The Court concluded (at para

[238]) that the PSED did not apply to a decision which was a matter requiring primary legislation. In the course of its
reasoning, the Court described the challenge as being 'to a decision to invite Parliament to amend primary
legislation' (see para [230]). The key passage in the judgment was as follows:

**'Does the PSED apply to decisions that are given effect by primary legislation?**

[229] This question arises in relation to the LEL. The current position, namely that SSP is payable only where
an employee earns over the LEL, is set out in primary legislation … Its removal would, therefore, necessitate
an amendment to primary legislation.

[230] In our judgment, the position is different where the challenge is to a decision to invite Parliament to
amend primary legislation. The making of primary legislation is the quintessential Parliamentary function. In our
view it would be a breach of Parliamentary privilege and the constitutional separation of powers for a court to
hold that the procedure that led to legislation being enacted was unlawful. The consequence of this would be

**[*630]**

that the legislation itself would be ultra vires and void (even though the Claimants in this stage seek declaratory
relief only). The court has no power to declare primary legislation void on a basis such as this.

[231] Article 9 of the 1689 Bill of Rights provides:


-----

“That the Freedom of Speech, and Debates or Proceedings in Parliament, ought not to be impeached or
questioned in any Court or Place out of Parliament.”

[232] In [Wheeler] … the Divisional Court dismissed the claimant's claim that the Prime Minister was bound by
a promise made in Parliament, and repeated outside Parliament, that the people would be consulted, by means
of a referendum, on whether to ratify the Lisbon Treaty.

[233] At para [49], Richards LJ said:

“[49] In our judgment, it is clear that the introduction of a Bill into Parliament forms part of the proceedings
within Parliament. It is governed by the Standing Orders of the House of Commons (see, in particular, standing
order 57(1)). It is done by a Member of Parliament in his capacity as such, not in any capacity he may have as
[a Secretary of State or other member of the government. [Prebble v Television New Zealand Ltd [1994] 3 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61JM-00000-00&context=1519360)
_[ER 407, [1995] 1 AC 321] … supports the view that the introduction of legislation into Parliament forms part the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61JM-00000-00&context=1519360)_
legislative process protected by Parliamentary privilege. To order the defendants to introduce a Bill into
Parliament would therefore be to order them to do an act within Parliament in their capacity as Members of
Parliament and would plainly be to trespass impermissibly on the province of Parliament. Nor can the point be
met by the grant of a declaration, as sought by the claimant, instead of a mandatory order. A declaration
tailored to give effect to the claimant's case would necessarily involve some indication by the court that the
defendants were under a public law duty to introduce a Bill into Parliament to provide for a referendum. The
practical effect of a declaration would be the same as a mandatory order even if, in accordance with longstanding convention, it relied on the executive to respect and give effect to the decision of the court without the
need for compulsion.”

[234] In R (on the application of UNISON) v Secretary of State for Health _[[2010] EWHC 2655 (Admin), at para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-MTT1-F0JY-C09J-00000-00&context=1519360)_

[9], Mitting J said that:

“The courts cannot question the legitimacy of an Act of Parliament or the means by which its enactment was
procured: see British Railways Board v Pickin [1974] AC 765, and as to proceedings in Parliament, Article 9 of
the Bill of Rights.”

[235] The starting point, therefore, is that the courts cannot question the legitimacy of an Act of Parliament (or
an amendment to an Act of Parliament). It is against this background that the scope of s 149 must be
examined.

[236] In our judgment, it is clear that the “functions” of a public authority, referred to in s 149(1), do not include
the preparation and promotion of an Act of Parliament or an amendment to an Act of Parliament. The making of
primary legislation is a matter for Parliament and not the Executive. The passage from the Court of Appeal
judgment in [R (on the application of C (A Minor)) v Secretary of State for Justice [2008]

**[*631]**

EWCA Civ 882, [2009] QB 657, [2009] 2 WLR 1039], set out at para [219] above, makes clear that there is a
difference between delegated or secondary legislation, on the one hand, and primary legislation, on the other,
in terms of the scope for challenge. Whilst the actions of a Government Department leading up to the making of
delegated legislation are separate from the proceedings of Parliament itself, and so may be the subject of a
challenge on procedural impropriety grounds, the same does not apply to the actions of a Government
Department leading up to an amendment to primary legislation: the responsibility for the primary legislation
rests with Parliament itself, and so any procedural impropriety in the lead-up to the amendment does not
render ultra vires or invalidate the amended legislation.

[237] Another way of arriving at the same conclusion is that para 14 of Sch 18 to the EA 2010 excludes
decisions relating to primary legislation from the scope of s 149, because they are part of a function in
connection with proceedings in the House of Commons or the House of Lords.


-----

[238] Accordingly, the PSED does not apply to the decision not to remove the LEL from SSP, as this was a
matter that required amendment of primary legislation.'

**[19] So, in this part of the judgment in Adiatu the Divisional Court unmistakeably reasoned (at para [230], emphasis**
added) that:

'… it would be a breach of Parliamentary privilege and the constitutional separation of powers for a court to
hold that the procedure that led to legislation being enacted was unlawful. …'

And the Court (at para [234], emphasis added) cited this from Mitting J in UNISON:

'The courts cannot question the legitimacy of an Act of Parliament or the means by which its enactment was
procured …'

Then, against this as part of the 'background' (para [235]), the Court concluded (para [236]): that the PSED was
inapplicable to 'the preparation and promotion of an Act of Parliament or an amendment to an Act of Parliament';
that it would be applicable to 'the actions of a Government Department leading up to the making of delegated
legislation …'; but that it would be inapplicable (para [236], emphasis added) to—

'the actions of a Government Department leading up to an amendment to primary legislation.'

**[20] Mr Buttler QC submitted that, in this analysis in Adiatu, the phrase 'the procedure that led to legislation being**
enacted' is to be taken as being a description of proceedings 'in Parliament' (see the Bill of Rights: para [231]). That
means Parliamentary procedure; and the Parliamentary standards applicable to the actions regarding a Bill of
primary legislation in Parliament. Mr Buttler QC submitted that Parliamentary process was the subject-matter of the
_Pickin case, referred to in the quotation from UNISON (at para [234])._

**[21] I cannot accept that this submission is, even arguably, correct. In my judgment, it is clear from the analysis of**
the Divisional Court in _Adiatu that the Court's reference to 'the procedure that led to legislation being enacted' at_
para [230] did not have Mr Buttler QC's suggested narrow focus, on 'Parliamentary procedure'. My reasons are
these:
**[*632]**

(i)   The Court was considering the PSED as a legal standard, which it had recognised was a standard
concerned with 'procedure' (see para [204]), and which involved 'advance consideration' in the making of a
substantive 'policy' decision (see para [206]).

(ii)   The Court was concerned in Adiatu with substantive decision-making which had led to the making of
regulations amending SSP (para [33]) but unaccompanied by any amendment to the primary legislation to
remove the LEL (para [36](2)(c)). The question in _Adiatu_ was whether the PSED was applicable to the
process of substantive decision-making that had produced the response taken by way of the regulations
but – critically – which had not produced the response of any amendment to the primary legislation. That
was the relevant decision-making 'procedure', to which the PSED would have applied, had it been in law
applicable.

(iii)   What the Court clearly meant by 'the procedure that led to legislation being enacted' – and in Adiatu
the procedure that led to amending primary legislation not being enacted – was the prior decision-making
procedure, culminating in a substantive decision relating to substantive design of amendments to
legislation. That prior decision-making procedure is also clearly what the Court was describing as 'the
actions of a Government Department leading up to an amendment to primary legislation' (see para [236]).
It was that decision-making procedure that could involve what the Court called 'procedural impropriety in
the lead-up to the amendment' (see para [236]), but 'any procedural impropriety' of that nature would be
part of the responsibility of Parliament (see para [236]).

(iv)   Moreover, it is noteworthy that the Court wove into its analysis its citation from the UNISON case, in
which passage Mitting J was addressing an issue concerning prior consultation. Consultation was, as Mr
Buttler QC accepted, what Mitting J was describing as 'the means by which … enactment was procured'.


-----

**[*633]**


So, UNISON was a case about a prior process, of consultation, addressed in a passage which the Court in
_Adiatu was therefore specifically applying (see para [234]) in considering the applicability of the PSED to_
the 'procedure' and 'actions of a Government Department leading to' legislation being enacted or amended
(or in the case of Adiatu not enacted or amended).

(v)   It follows that the Divisional Court reached the conclusion that the PSED was not an applicable
standard in relation to the 'procedure' of decision-making regarding the design of primary legislation; and
the Divisional Court reached that conclusion because it reached the prior conclusion that Parliamentary
privilege and the constitutional separation of powers did not permit the Court to hold to have been unlawful
the 'procedure' of decision-making regarding the design of primary legislation (or put another way, the
'actions of a Government Department leading up to' primary legislation, including any 'procedural
impropriety').

(vi)   Finally, what is also clearly the case is that the Divisional Court did not regard the 'point' as being
capable of being 'met by the grant of a declaration'. As to that, it cited the passage from Wheeler which had
rejected declaratory relief on the basis that it 'would necessarily involve some indication by the court' as to
'a public law duty' in the context of introduction of a Bill into Parliament. The Divisional Court in _Adiatu_
clearly concluded that that same answer was applicable to a declaration that the PSED had been breached
in the decision-making procedure that

had led to a substantive decision about whether and how to design primary legislation. After all, in Adiatu
itself where the claimants were arguing that the PSED had been breached in the decision-making, they
were seeking 'declaratory relief only' (see para [230]).


Mr Buttler QC accepted that there would be no basis on which this Court could or would depart from the analysis of
[Parliamentary privilege and the constitutional separation of powers or the reach of the EA 2010 in Adiatu. I agree.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
Even for the purposes of permission for judicial review, I should proceed on the basis that the conclusions and
material reasoning in Adiatu are legally correct.
_The PSA case_

**[[22] Both Counsel cited R (on the application of Police Superintendents' Association) v HM Treasury [2021] EWHC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:649J-F0D3-GXF6-82SH-00000-00&context=1519360)**
_[3389 (Admin) ('PSA'), where para [230] of Adiatu was considered and applied by Heather Williams J: at para [156]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:649J-F0D3-GXF6-82SH-00000-00&context=1519360)_
(where it was cited) and para [214] (where it was applied). The latter passage was obiter (see para [207]), because
the defendant had evidently treated the grant of permission for judicial review as meaning the issues as to unlawful
consultation and breach of the PSED (see para [6]) were justiciable or at least appropriate for the Courts to
determine on their substantive legal merits (see para [4]). The case was about impugned public service pension
scheme closures (see para [1]), involving a Bill introduced into Parliament. Heather Williams J addressed the
question whether it could be appropriate to grant a declaration of unlawfulness, including a declaration that the
consultation had been unlawful (see para [207]). She said this (at para [214]) (I have inserted numbering for ease of
cross-reference):

'[i] A declaration that the closure decision was unlawful, would be tantamount to saying that the decision
embodied in Clause 76 of the Bill is unlawful. Yet, the form of primary legislation is a matter for Parliament and
not for the courts … [ii] Furthermore, Parliamentary privilege would be breached if a Court were to declare that
the procedure leading to legislation being enacted was unlawful … However, that would be the effect of
granting a declaration that the consultation preceding the Bill was unlawful. [iii] It would also entail disruption to
the Parliamentary timetable in the sense that the Defendant would be under a public law duty to then do
something about the consultation. Declaratory relief is sought in these proceedings precisely because the
Claimant wants to influence the course of the Bill.'

In this passage, point [i] exemplifies Mr Buttler QC's 'vitiation' point; while point [iii] exemplifies his 'interference'
point. As to point [ii], which was squarely based on para [230] of _Adiatu, Mr Buttler QC submits that Heather_
Williams J misunderstood that _Adiatu para [230] was concerned only with the narrow question of Parliamentary_


-----

procedure in the introduction of a Bill before Parliament. As I have explained already, I cannot agree. In my
judgment, for the reasons I have given, Heather Williams J's point [ii] was a correct reading of Adiatu para [230].
_Justiciability and the Gunning principles_

**[23] Three grounds for judicial review are advanced in this case, as reflected in the declaration sought (see para [5]**
above). In reaching my conclusions on justiciability, I will start with ground three: the _Gunning principles and_
common
**[*634]**

law consultation (see para [7] above). It is well established that in principle when a public authority decides to
conduct a consultation the Gunning standards are applicable: see PSA at para [122]. It is also well established that
in principle when a public authority reaches a substantive decision arising out of a decision-making process in
which the Gunning standards have been breached, the substantive decision is 'vitiated'. Whether or not a judicial
review claimant is seeking declaratory relief only, and whether or not the judicial review Court tailors or refuses
remedies, it is the legal logic of a Court holding that the procedure that led to a substantive decision (including the
introduction of a measure), that the substantive decision (or measure) is in law 'vitiated'. It would be the same with a
substantive decision made without an oral hearing, or without hearing representations, and where the Court
concludes that the procedure was unfair. It is that inescapable 'vitiating' logic, of a finding of unlawfulness as to the
procedure, which demonstrates the inappropriateness of the judicial review Court being invited to hold that the
procedure that led to legislation being enacted was unlawful. That was the substance of the point that was being
made by the Divisional Court in Adiatu at para [230].

**[24] The justiciability question in the present case is this: does the Court's supervisory jurisdiction on judicial review**
extend to the Court policing the _Gunning standards, in the context of a consultation which was concerned with_
'delivering effective legislative change', and whose culminating substantive decision necessarily entails the design
of a Bill of primary legislation to be introduced into Parliament? In my judgment, the answer to that question – based
on the authorities – is clearly, and beyond reasonable argument, 'no'. In the first place, the 'vitiating' consequence of
breach of the _Gunning_ standards – as seen throughout public law wherever those standards are policed by the
judicial review Court – can have no place in the present context. Mr Buttler QC accepts that, which is why he strives
to confine his claim to declaratory relief, and to confine the target for his claim to the decision as to process, in the
design of the consultation. Mr Buttler QC relies on the LH case (see para [16] above) as supporting the contention
that the legal focus can properly be so confined. In my judgment, that is not so. The LH case was one in which the
Court was expressly accepting that there had been a 'vitiating' failure to consult. It was a failure which 'did result in

[the local authority] acting unlawfully'. The judgment of the Court in LH recognised that the substantive decision to
close the Day Centre had been legally vitiated, as a matter of public law. The Court's refusal to grant any remedy,
beyond a declaration of unlawfulness, was borne out of the practical realities. Remedies in judicial review are
always discretionary. The Day Centre had been closed. But, unmistakeably, that decision to close the Day Centre
was vitiated in law. It had been arrived at in breach of applicable public law standards, where procedure and
substance are linked.

**[25] It is not possible, in my judgment, to treat the** _Gunning standards as being legally applicable to 'process_
decisions' about 'the design of the decision-making process', in a manner which is distinct from and insulated from
the substantive decision-making as to the design of the Bill. Consultation is really about 'participation in' a 'decisionmaking' process. That is how Lord Reed put it in Moseley at paras [38]–[39]. To see the point, one need only look at
_Gunning (iv), by which the judicial review Court polices the standard of legally adequate consultation which requires_
that—
**[*635]**

'the product of the consultation must be conscientiously taken into account when the ultimate decision is taken.'

The Court could not do this, without accepting that the supervisory jurisdiction extends to scrutinising the 'ultimate
decision' and the way in which it has been approached. Turning the point around, once it is accepted that it could
not be appropriate for the judicial review Court to scrutinise the reasoning and thinking behind the 'ultimate decision'
– here, as to the design of a Bill of primary legislation to be introduced into Parliament – it must follow that Gunning


-----

(iv) is not a legal standard which can properly be enforced by the judicial review Court. In my judgment, it is wholly
unconvincing then to seek to rescue other aspects of the Gunning principles, so as to disconnect those from their
legal logic, consequence and effect, so as to leave a 'freestanding' issue for the supervisory jurisdiction of the
judicial review Court which asks an 'isolated', and 'insulated' question, as to the clarity of proposals in a consultation
document (Gunning (ii)).

**[26] A declaration that an applicable legal standard was breached, in the consultation and engagement process**
culminating in the operative decisions as to the design of the Bill to introduce into Parliament, would, in my
judgment, clearly constitute a breach of Parliamentary privilege and the constitutional separation of powers, as
these are clearly described by the Divisional Court in the Adiatu case. A declaration from a judicial review Court,
declaring that the consultation which preceded the Bill and informed its design was unlawful would – even if the
Court bent over backwards to make very clear that that was the scope and extent of its judgment and its declaration
– clearly raise questions about whether some step ought to be taken in light of that conclusion of law by the Court.
There are two points to make about this:

(i)   First, Ms Clement convincingly submits that a responsible Government would be likely to respond to
such a finding of breach of an applicable public law duty by needing to 'do something about it'. She
emphasises that this is not a 'practical impossibility' scenario as in LH. She submits that if Government did
indeed respond to such a finding by reference to 'doing something about it', that would stand to disrupt the
Parliamentary timetable. These points echo what Heather Williams J said in PSA at para [214] (see para

[22] above) about granting a declaration. They link to _Wheeler_ at para [49], cited in _Adiatu at para [233]_
(see para [18] above).

(ii)   Secondly, there is this. Let it be assumed that the Court's conclusion did not involve any 'step' being
taken by Government. Suppose instead that the Court's judgment instead cast a legal 'shadow' over the
product of the consultation. That shadow would, in my judgment, itself stand – in the circumstances of the
present case – as an interference in the Parliamentary process. The Court would, unmistakeably, have
concluded that the 'product' of the consultation was legally 'tainted'. The Court would have held that the
product had been arrived at in breach of a relevant, material and applicable legal standard. In the present
case, the Claimants' pleaded grounds for judicial review, in my judgment, demonstrate this 'shadow' point
very clearly when they address the purpose of a freestanding declaration (paras [6], [17] above). The very
consequence for which the Claimants hope, and which they intend, through the bringing of this claim for
judicial review and the seeking of a declaration of breach would, in a real sense, be seeking to 'influence
the course of the Bill' (to echo the

**[*636]**

phrase in PSA at para [214]). Otherwise, how could the judgment be affecting the thinking of 'Parliament'
(as it is put), or thinking of those involved in the Parliamentary process?

**[27] In conclusion, it is not – in my judgment – arguable, with a realistic prospect of success, that the** _Gunning_
standards are legal standards engaging the supervisory jurisdiction of the judicial review Court in these following
circumstances: where Government has chosen to undertake a 'consultation and engagement process', for the
purposes of 'delivering effective legislative change', where the outcome would necessarily be substantive decisions
as to the design of a Bill to be introduced into Parliament. That is this case.

_[Justiciability and the EA 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_

**[28] I turn to the applicability of the statutory duties within the** _[EA 2010. I have found that these are brought into](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_
sharp focus by the disability example to which I have referred (see para [15] above).

(i)   I start with the PSED. The Claimants' difficulties are these. First, once it is recognised that the
description in _Adiatu of it being a breach of Parliamentary privilege and the constitutional separation of_
powers 'for a court to hold that the procedure that led to legislation being enacted was unlawful' (Adiatu
para [230]), which then leads to the conclusion that 'actions of a Government Department leading up to' the
making of primary legislation are not within the 'functions' of a public authority to which the PSED applies
(Adiatu para [236]) it is immediately extremely difficult to see what room there could be for the PSED to


-----

**[*637]**


apply to the 'function' of the public authority in 'determining how a consultation is to be carried out' (see
_Help Refugees at para [90](v): see para [14](3) above). The logic would have to be that although the PSED_
is inapplicable to impugn the 'procedure' by which a 'policy' decision concerning the design of primary
legislation is taken, the PSED is nevertheless applicable to impugn 'decisions' taken as to the design of
that very 'procedure'. That very slender distinction unravels when examined. If the PSED were applicable
in that way in the present case, the same two points (see para [26] above) about the consequences of a
declaration of unlawfulness would apply, in relation to the Claimants achieving that declaration in relation to
the PSED. In particular, the unmistakable and deliberate 'shadow' would still be cast over the progress of
the Bill in Parliament, as is illustrated by the Claimant's pleaded purpose in seeking such a declaration
(paras [6], [17] above). Impugning decisions taken as to the design of the 'procedure' would entail the
Court being invited to hold that 'the procedure that led to legislation being enacted was unlawful', which is
what has been identified as impermissible in the context of understanding the reach of the PSED (Adiatu
para [230]).

(ii)   I turn to the statutory duty not indirectly to discriminate. As Ms Clement submits, if 'the taking of
decisions about procedure', relating to the 'design of a consultation' which culminates in a substantive
decision about the design of the Bill of primary legislation to be introduced into Parliament, is not a
'function' for the purposes of the PSED (EA 2010 s 149), then it must equally surely not be a 'function' for
[the purposes of remediable indirect discrimination (EA 2010 s 29(6), read with s 19). In the context of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)
indirect discrimination too, as in the context of the _Gunning principles and unlawful consultation and the_
PSED, the same two points (para [26] above) arise as to the effect of a declaration, including the

purposes which the grant of remedies would stand to have, in (deliberately) casting a legal 'shadow' within
the Parliamentary process on the steps which had preceded the Bill as on the product of the pre-Bill
process of consultation and engagement.



**[[29] In my judgment, beyond reasonable argument, the EA 2010 duties invoked by the Claimants are inapplicable](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)**
to the function of designing the 'consultation and engagement' process which is the focus of the present case.

**[30] In Adiatu, the Divisional Court referred to there being 'Another way of arriving at the same conclusion' (para**

[237]), so far as the inapplicability of the PSED was concerned. That alternative route was within Sch 18 to the EA
2010, by which (see Sch 18, para 4(3)(a)) there are excluded from the PSED – in the case of persons who are not
public authorities but by whom public functions are exercisable (Sch 18, para 4(1)) – a function 'in connection with'
proceedings in the House of Commons or the House of Lords. The Divisional Court evidently treated it as going
without saying that any 'public authority' function of that kind was equally excluded. The Divisional Court treated that
provision as indicating an alternative route, on the basis that decisions relating to primary legislation – which
included 'the procedure that led to legislation being enacted' and 'the actions of a Government Department leading
up to the making of delegated legislation' – are parts of a function 'in connection with' proceedings in the House of
Commons or the House of Lords. In relation to indirect discrimination (s 29(6) read with s 19), there is a similar
alternative route. It is to be found within Sch 3 para 2 to the EA 2010. That provision states (Sch 3, para 2(1)(b))
that s 29 does not apply to 'preparing, making or considering … a Bill for an Act of Parliament'. This language
('preparing') matches the phrase used in Adiatu at para [236], which spoke of acts relating to the 'preparation', as
well as the promotion, of a Bill. There is, in my judgment, at least as much cogency in the invocation of this
alternative route ('preparing … a Bill'), to 'the procedure that led to legislation being enacted' and 'the actions of a
Government Department leading up to the making of delegated legislation', as the Divisional Court recognised there
would be in the invocation of the PSED exclusion ('a function in connection with proceedings in the House of
Commons or the House of Lords'), as 'another way' of arriving at the same conclusion.
_Not 'what', but 'who'_

**[31] A key point worthy of emphasis is this. These conclusions on justiciability are not conclusions as to the**
absence of 'standards' against which actions can be scrutinised. The Court's conclusion on justiciability does not
mean there is no 'standard': concerned with whether 'insufficient reasons have been given for a proposal to permit
of intelligent consideration and response'; or concerned with whether 'the product of consultation has not been
i ti l t k i t t i th lti t d i i ' f lli th d i f Bill d ith h th


-----

consultation and engagement process, or the measure arising out of that process, has been designed without
appropriate 'regard' to 'the need to eliminate discrimination, advance equality of opportunity and foster good
relations'; or concerned with whether these were designed as involving some 'provision or practice' which
'unjustifiably places persons with protected characteristics at a particular disadvantage'. The Court is not saying that
such considerations are, in principle, irrelevant to 'the actions of a Government Department leading up to the
making of delegated legislation', or 'the procedure that led to legislation'. All of that is
**[*638]**

about 'what'. It is all inextricably linked to the making of primary legislation, which is a Parliamentary function. The
approach in the case-law to justiciability is recognising that the responsibility for considering 'standards' and
'accountability' in relation to those standards is a responsibility falling within the domain of Parliament and its
process. That is the 'who'. The Court does not have a role of identifying legal standards, and enforcing them – albeit
that they would be identified and enforced in the context of decision-making culminating in delegated legislation –
so as to identify what Adiatu called 'procedural impropriety in the lead-up to' primary legislation, for the purpose of
informing Parliament or members of Parliament or informing public debate (as is the Claimants' wish). That would
be an act of 'interference' which – on the authorities – the Courts' chosen, self-denying ordinance, based on the
Courts' perception and delineation of the constitutional principle of the separation of powers, alongside the Courts'
perception and delineation of the constitutional principle of the rule of law, inhibits the Courts from undertaking.
**IV. Arguability**

**[32] I have dealt, at some length, with the question of justiciability. The first question which arises is whether, in light**
of my conclusions, I should stop there. The position at this permission-stage hearing was that the Court received full
written and oral argument about justiciability, but it also received full written and oral argument about whether the
claim for judicial review (if justiciable) would be properly arguable. Ms Clement, on behalf of the Secretary of State,
specifically asked the Court – whatever its conclusion on justiciability – to go on to address the question of
arguability (if justiciable). The Secretary of State – having put forward non-justiciability – was not concerned about
any inappropriateness of the permission-stage Court then 'expressing a view' about arguability of the legal issues,
adopting a premise of justiciability. I have been persuaded by the Secretary of State to address the issue of
arguability (if justiciable), having heard full submissions about it. I do so in case I am wrong about justiciability. That
would include the prospect of some shift or development in the law – perhaps at higher judicial altitude – perhaps in
revisiting Adiatu (possibly in PSA), or in explaining the law differently from the way in which I have understood it and
sought to be faithful to it. So, what follows is my analysis of arguability, on the premise that the claim is justiciable.
In doing so, I will take the grounds in the same sequence as they have been presented by the Claimants, as
reflected in the declaration sought (see para [5] above). I am able to deal with this topic more concisely than I have
found possible with the topic of justiciability.
_Indirect discrimination_

**[33] The essence of the Claimants' analysis on ground one (indirect discrimination pursuant to** _[EA 2010 s 29(6)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)_
read with s 19), as I see it, is as follows. In the public function of the consultation and engagement process, and
specifically the decision-making as to the design of that process, the unavailability in languages other than English
and Welsh of the consultation documents – which operated alongside the limited scope of the invitation-only
engagement sessions – constituted a 'provision, criterion or practice' which placed at a 'particular disadvantage'
persons sharing the protected characteristic of 'race' (which includes non-British nationals), constituting indirect
discrimination for which a declaration and damages are the
**[*639]**

appropriate remedy. Ultimately, that is because the Secretary of State cannot discharge the onus, which is on her,
of showing that the provision, criterion or practice was a 'proportionate means of achieving a legitimate aim', striking
'a fair balance'. It is true that speed and simplicity – that is, the avoidance of delay and complexity – would
constitute 'a legitimate aim'. But in the absence of some step identifying the effect for speed and simplicity (delay
and complexity) of providing further translations of consultation documents (by way of an example, having them
translated into a 'top five' relevant languages beyond English and Welsh) – and/or for providing open or greater
access to engagement sessions for those wishing to share their lived experience – the Secretary of State cannot
discharge that onus In fact the Secretary of State would need to show this: that she could not have had the


-----

consultation documents translated more widely – and/or the engagement sessions open or more widely accessible
– without creating undue complexity and delay. Further, it is not sufficient for the Secretary of State simply to point
to invitation-only engagement sessions as 'mitigating steps' in the context of the absence of translated versions of
the consultation documents. At this permission stage, there is no evidence from the Secretary of State. There
needs to be evidence. The threshold is one of arguability and it is crossed.

**[34] I am not able to accept these submissions. This consultation and engagement process included a six-week**
consultation exercise reflecting the degree of urgency in promoting the legislation in this field, as assessed by the
Secretary of State. The consultation and engagement process was designed to have its various interrelated
strands. They were significant. Among those interrelated strands was the engagement with bodies who represent
asylum seekers. Also among those interrelated strands was the lived experience forum, the series of in-depth
interviews and discussion groups specifically held with those who had lived experience of the UK asylum system.
Those sessions, planned by the Home Office, included the provision of interpreters arranged by the Home Office or
the relevant network, where interpreters were needed. The detailed description of all of this is set out in the
summary grounds of resistance. It is accompanied by a statement of truth. It stands evidenced by that and by the
documents which are before the Court. As Lang J explained in her detailed reasons for refusing permission for
judicial review (see para [8] above), in addition to the over 1,500 responses to the consultation questionnaire there
were the extensive engagements with stakeholder groups, public focus groups, and those with 'lived experience' of
the asylum system and **_modern slavery. She went on to explain that: whilst non-English speakers were at a_**
disadvantage, it was justifiable for the Secretary of State to address that difficulty by structuring the consultation so
as to encourage engagement from bodies who represent asylum seekers, and also to engage directly with those
who had lived experience of the asylum system and **_modern slavery. Beyond argument, in my judgment, the_**
Secretary of State can already show, assuming all other stages of the argument in the Claimants' favour, that the
'provision, criterion or practice' in the language of the consultation documents – and/or the scope of the invitationonly engagement sessions – whose linguistic or invitational expansion would self-evidently have involved
substantially reduced speed and simplicity (increased delay and complexity), was a proportionate means of
achieving the legitimate aim of ensuring such speed and simplicity, and struck a fair balance. It follows that there is
no properly arguable basis (having a realistic prospect of success) for claiming a declaration of unlawfulness, or for
claiming damages for indirect
**[*640]**

discrimination. Since this is the only ground of the three engaging damages, the claim for that remedy cannot on
this basis succeed. Nor would there be a basis for transferring any damages claim to the county court.
_Breach of the PSED_

**[35] The essence of the Claimants' analysis on ground two (breach of the PSED pursuant to s 149 of EA 2010) is,**
as I see it, this. In the public function of the consultation and engagement process, and specifically the decisionmaking as to the design of that process, with the unavailability in languages other than English and Welsh of the
consultation documents – which operated alongside the limited scope of the invitation-only engagement sessions –
there was a failure by the Secretary of State to have 'due regard' to 'the need to eliminate discrimination, to
advance equality of opportunity between persons sharing a relevant protected characteristic and persons not
sharing it, and to foster of good relations between persons who share a relevant protected characteristic and those
who do not'. The relevant protected characteristic is race (including non-British nationals). The disadvantages in
participation with the consultation process not only stood to constitute discrimination (see ground one) but were
detrimental to equality of opportunity and to fostering good relations. In circumstances where the Defendant has
throughout denied the applicability of the PSED it is particularly unconvincing for her to submit that she complied
with it. The fact that strands of the consultation and engagement process included engagement from bodies
representing asylum seekers and directly included some individuals who had 'lived experience' of the asylum
system and **_modern slavery does not of itself mean that 'due regard' was had so as to discharge the PSED._**
Evidence is needed and there is no satisfactory evidence of due regard. This ground is at least arguable.

**[36] I am not able to accept those submissions. I accept the Secretary of State's submission, as it is put in the**
summary grounds of defence: that it was 'manifestly obvious' that those who do not speak English including nonBritish nationals who might want to respond to the consultation exercise may find it more difficult to respond to the


-----

consultation questionnaire; and that it was in that context that the Secretary of State structured the consultation and
engagement process, so as to encourage engagement from stakeholder bodies including many who represent
groups affected by the proposals, and so as to encourage direct engagement with those having lived experience of
the asylum system including direct experience of **_modern slavery. It bears repeating in context that the lived_**
experience forum included the provision of interpreters arranged by the Home Office or the relevant network. The
steps and their design are evidenced before the Court. It is not, in my judgment, arguable with a realistic prospect of
success that the decision-making in the design of the consultation and engagement process, and specifically in
relation to language versions of the consultation documents and the scope of and numbers included in the
invitation-only engagement sessions, constituted a breach of the 'due regard' duty in the PSED.
_Breach of Gunning (ii)_

**[37] The essence of the Claimants' analysis on their ground three (legally inadequate consultation by reference to**
_Gunning (ii)) is, as I see it, as follows. Having chosen to conduct a consultation and engagement process (in an_
announcement which recognised applicable 'established principles': see para [3] above), the Secretary of State
failed through the lack of clarity and specificity
**[*641]**

in the consultation documents to discharge her common law duty: to give reasons for proposals sufficient to permit
intelligent consideration and response. This, moreover, was a context involving proposals some of which stood to
involve the deprivation of existing rights or advantages. That called for high standards of procedural fairness in the
consultation process. By reference to eight topics set out in the grounds for judicial review – three of which are
further discussed in the Claimants' skeleton argument, and one of which was the subject of oral submissions –
there was a breach of this important duty. The breach is exemplified by the fact that the description in the
consultation document relating to the reintroduction of 'fast-track appeals' made no reference to any proposal
regarding 'loss of appeal rights', yet such a proposal was indicated to a non-governmental organisation (the Public
Law Project) at a subsequent engagement session. The breach of _Gunning (ii) is also strongly supported by the_
reactions of responsible stakeholder bodies (engagement with whom the Secretary of State so strongly
emphasises). ILPA (the Immigration Law Practitioners' Association) described proposals in the consultation
documents as 'confusing' and being 'at such a high level of generality' that it was 'difficult to provide meaningful
comments'. The Bar Council described the consultation documents as 'deeply confused' and commented that 'in the
absence of any detail at all' there was 'little that could be said'. Liberty described the proposals as 'worryingly
unclear and imprecise'. The Law Society said that 'further consultation' would be necessary given the 'lack of detail'.
Refugee Action said it was 'impossible' to respond because 'no real information' had been provided. The vagueness
in the proposals rendered the consultation 'so unfair as to be unlawful' (as the test has been put: see _R (on the_
_application of Bloomsbury Institute Ltd) v Office for Students_ _[[2020] EWCA Civ 1074, [2020] ELR 653 (at para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60KG-4XX3-GXFD-81CP-00000-00&context=1519360)_

[69])). It is at least arguable that there was a breach of Gunning (ii).

**[38] I am not able to accept those submissions. The question of what Gunning (ii) requires of a public authority's**
consultation process is 'fact-specific and can vary greatly from one context to another': see Help Refugees at para

[90](iii). The nature of consultation will be related to the context and purpose for which it is carried out, and a
mechanistic approach to the requirements of consultation should be avoided: see Moseley at para [36]. In order for
consultation to be found to be unlawful, clear unfairness would need to be shown, and the starting point is that it is
for the public authority charged with performing the consultation to determine how it is to be carried out, including
'the manner' of the consultation: see _Help Refugees at para [90](v). Key points, convincingly identified by the_
Secretary of State in her summary grounds of resistance, are these: that the scope of any duty to consult varies
greatly, depending on the policies in question and the context and purpose of the consultation, as well as the
degree of urgency required by the nature of the decision-making; that the proposals which were contained in the
Policy Document in this case were proposals which would require primary legislation; that the nature and content of
any duty to consult arises and must be considered against the backcloth that there would be an opportunity for
views to be made known on legislative proposals as these progressed through Parliament; that the consultation
was on policy proposals set out in the Policy Document; that the Secretary of State was not consulting on the terms
of proposed legislation which had yet to be designed; and that this was not in the nature of a consultation on a draft
Bill. I can see no realistic prospect of this Court at a substantive hearing concluding that, applied in the context and

**[*642]**


-----

circumstances and by reference to the aim of this consultation, the common law standard of specificity and clarity in
_Gunning (ii) was breached by the terms of the consultation documents, whether by reference to the eight examples_
in the judicial review grounds, the three emphasised in the skeleton argument, or the one which was emphasised as
illustrative in the oral submissions of Mr Buttler QC.
_Conclusion_

**[39] For all these reasons, had I proceeded on the basis that the claim raises justiciable legal standards and**
applicable legal duties which it is the proper function of the judicial review Court to supervise and enforce, I would
have refused permission for judicial review on grounds of lack of arguability, in agreement with Lang J.
**V. Other points**

**[40] A number of other topics were raised and addressed in submissions in this case, which it is appropriate to**
address. The first is this. In his oral submissions, Mr Buttler QC identified this 'fallback' argument. Even if the policy
proposals outlined in the consultation documents were predominantly envisaged to be incorporated within a suitably
designed Bill of primary legislation to be introduced into Parliament, that is not true universally. There are particular
instances of topics and proposals whose implementation would not require primary legislation, but which would be
the subject of other arrangements. Insofar as there is any non-justiciability 'shield', it could not apply to these, and
permission should therefore be granted. I reject this as a basis for granting permission. The plain focus of this claim
for judicial review, from the outset, has been on the consultation and engagement process adopted for the purposes
of delivering effective legislative change. At no stage – in the judicial review grounds, in the permission stage reply,
or in the skeleton argument – was this narrower fallback argument identified or articulated. On grounds of
'procedural rigour' alone, I would refuse to entertain a last-ditch line of argument of this kind, advanced for the first
time orally at a permission renewal hearing. But nor, in my judgment, was Mr Buttler QC able convincingly to
identify any specific proposal falling within the area of implementation through means other than primary legislation,
with which any of the Claimants had expressed any concern. One was identified which one of them had mentioned,
to express support for it. If and insofar as any person or body having a sufficient interest wished (or wishes), in
proceedings promptly pursued, to seek to impugn any decision to implement any proposal by means other than
primary legislation, on the basis of breach of an applicable legal duty (having, moreover, a 'vitiating' effect for that
substantive decision), they could always have done so.

**[41] Mr Buttler QC in writing and orally submitted that the claimant's abandonment of the mandatory order sought in**
the claim form was attributable to delays within the Administrative Court Office in dealing with the papers filed on 28
May 2021. The true position is that the mandatory order originally sought, requiring a further period of consultation,
would plainly have constituted an interference with the timetable in which a Bill could be introduced into Parliament.
As Mitting J put it in UNISON at para [11]: 'The … challenge … if successful … would require the Secretary of State
to defer or delay introducing the … Bill until [she] had consulted …' The mandatory order sought, from the start,
offended against the 'interference' principle which Mr Buttler QC has in the event accepted (see para [10] above).
**[*643]**

**[[42] Reference was made by the parties to two specific statutory duties arising by virtue of s 3(3) of the Immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-01B1-00000-00&context=1519360)**
and Social Security Co-ordination (EU Withdrawal) Act 2020 and _[s 33 of the Immigration and Asylum Act 1999.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y118-00000-00&context=1519360)_
These were 'relevant statutory duties' referred to in the Policy Statement (see para [3] above). By s 3(3) of the 2020
Act Parliament imposed a statutory duty on the Secretary of State to ensure a 'review' of the ways in which
protection claimants who are in EU member states are able to enter the United Kingdom lawfully and, in relation to
one aspect of that review, to consider, with 'a public consultation', the position of unaccompanied children in
member states who are protection claimants and are seeking to come to the UK to join relatives here. By s 33 of the
1999 Act Parliament imposed a statutory duty on the Secretary of State to 'consult' persons considered by her to be
appropriate, before issuing a 'code of practice' (laid before Parliament) to be followed by persons operating systems
for preventing the carriage of clandestine entrants. I asked Mr Buttler QC whether either of those statutory duties
cast any light on the legal logic so far as concerns questions of justiciability and non-justiciability. His answer was
that these were 'slim strands' of the consultation and engagement process, did not assist the analysis in this claim
and had nothing to do with the claim. I was not shown how either of these duties engage any proposal within the
design of primary legislation. If they did, the Court may need to reconcile Parliamentary privilege and the
enforcement of a specific and applicable statutory (and therefore necessarily an applicable legal) obligation Neither


-----

Counsel submitted that the contours and implications of that question were relevant to my decision on justiciability. I
have therefore done what they did: put the two specific statutory duties to one side.

**[[43] I asked Mr Buttler QC whether the answer to the question of justiciability in the context of the EA 2010 statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)**
duties would simply be a question of statutory interpretation as to the reach and applicability of the provisions of that
Act. In response, he said that was not the way the Claimants put their case. His submissions acknowledged that the
[case-law proceeds on the basis that the reach and applicability of the EA 2010 statutory duties is to be approached](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
against the backcloth of the Bill of Rights (which Mr Buttler QC accepts is a 'constitutional statute') and principles of
parliamentary privilege and the constitutional separation of powers. That is certainly supported by _Adiatu paras_

[230]–[235]. However, as I have explained, the Court in that case (Adiatu para [237]) identified express provision of
[the EA 2010 as 'Another way of arriving at the same conclusion' (see para [30] above). In the circumstances, I need](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
say no more.

**[44] Both Mr Buttler QC and Ms Clement sought to derive assistance from para [242] of** _Adiatu, where the_
Divisional Court described as the exercise of a public authority's function, for the purposes of s 149(1) of EA 2010,
one which 'consists of the implementation of the measures that the public authority decides upon'. Mr Buttler QC
relied on this passage in support of a contention that Adiatu was therefore a case in which there was 'no function'
because there was no decision to amend (but rather a decision not to amend) the primary legislation. Ms Clement
relied on this passage in support of a contention that the PSED applies only to 'implementation' and not to a
'decision-making function'. In my judgment, they each sought to derive from para [242] a proposition which cannot
be so derived. That paragraph in _Adiatu was doing no more than explaining that due regard in the PSED is_
concerned with due regard to the implications of those steps which the public authority intends
**[*644]**

to take, not with any other steps which it is not taking or even considering. This was not a passage in my judgment
which materially assisted either side on either of these points.

**[45] Ms Clement reminded me of the statutory duty on the permission-stage Judge, having been asked to do so by**
a judicial review defendant, to consider whether the 'outcome for the Claimants' would have been 'substantially
different' if the 'conduct complained of had not occurred': _[s 31(3C) of the Senior Courts Act 1981. If not, she](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y172-00000-00&context=1519360)_
reminded me of the duty – except in case of involving reasons of 'exceptional public interest' – to refuse permission
(s 31(3D)–(3F)). Had Mr Buttler QC persuaded me that it was appropriate to focus solely on 'decisions about
process' and about the 'design of the consultation and engagement process', and had he persuaded me that any of
the three grounds for judicial review was properly arguable with a realistic prospect of success, I would not have
refused permission for judicial review in the application of these statutory duties. That is because the legal logic –
which on this premise I would have accepted – would logically have followed through. The focus would, in my
judgment, then have been on whether the 'outcome' as to the 'design of the consultation process' would have been
substantially different 'for the Claimants'. That design could have involved language versions of the consultation
documents; it could have involved a different approach to invitation only engagement session; and it could have
involved differently formulated proposals to elicit responses requiring to be conscientiously taken into account by an
open-minded decision-maker considering the design of a proposed Bill. Viewed in this way, I would not have
concluded that my faithful application of the statutory duties imposed on me by Parliament would have the
consequence of shutting out this claim at the permission stage.

**[46] As I have mentioned (see para [15] above), Mr Buttler QC suggested illustrative examples to test the Secretary**
of State's position on justiciability. I have given my own disability example (para [15] above). Mr Buttler QC's first
example was about whether the adjudication of a charge of payment of a bribe during the consultation and
engagement process would have fallen within the Crown Court's jurisdiction competence. There was a second
example about whether a false accusation in a consultation document or response during the consultation and
engagement process would have fallen within the civil court's jurisdictional competence in defamation proceedings.
Had such examples been set out at any stage in writing, there could have been analysis to see what they assumed
and whether they assisted. I was not, in the circumstances, assisted by them. The third example was closer and
clearer. This was an example about a design of the consultation and engagement process which was 'white people
only' But Mr Buttler QC accepted that the no less striking example of a decision to design a Bill which purported


-----

[to confer protection on 'white people only' would not be justiciable by reference to any EA 2010 duty or common law](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
public law duty. The same would be true of any 'white people only' step regarding Parliamentary process or
proceedings in Parliament. This is classic 'who' rather than 'what' territory (see para [31] above), as would be the
conventional common law example involving the exclusion of 'red-haired people'.

**[47] Finally, Mr Buttler QC sought in the context of justiciability to rely on Warsama v Foreign and Commonwealth**
_Office (Speaker of the House of Commons, interested party)_ _[[2020] EWCA Civ 142, [2020] 4 All ER 486, [2020] QB](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:612X-6X83-GXFD-83T1-00000-00&context=1519360)_
1076. That case, about the interrelationship between the _[Human Rights Act 1998 and art 9 of the Bill of Rights,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
involved the reach of Parliamentary privilege in the
**[*645]**

context of an Inquiry Report which was to be (and had now been) published in Parliament pursuant to the
Parliamentary process known as Motion for an Unopposed Return. The Court of Appeal (on 11 February 2020)
decided that Parliamentary privilege protected 'the content and conclusions of the Report itself' (para [78]), recorded
that no privilege applied 'in relation to the preparation of the report' and that privilege 'could not … have been relied
on to prevent … a judicial review challenge … to a decision taken during the course of the Inquiry as to what
procedure to adopt' (para [71]). The Court of Appeal clearly had in mind that challenges to 'procedural decisions' of
the Inquiry – it gave examples of judicial reviews of such decisions during the course of the Saville Inquiry and the
Leveson Inquiry – would not constitute an interference with proceedings in Parliament even if they would delay the
publication of the Inquiry Report and so the date on which it would come to be published in Parliament. That alone
shows that there is no safe analogy. As Mr Buttler QC accepts, and as Mitting J found in _UNISON, a procedural_
challenge which stands to delay the timing regarding the introduction of a Bill of primary legislation into Parliament
would be non-justiciable. UNISON was not considered in Warsama. In turn, Warsama was not considered in Adiatu.
These lines of authority are presumably 'ships passing in the night', for the good reason that they are on different
parts of the map.
**VI. Conclusion and Consequentials**

**[48] I am grateful to the parties and their teams for the assistance which they have given to the Court. It has**
enabled me to come to clear conclusions, applying the permission threshold of arguability. Those conclusions, the
reasoning behind them, and the setting and context in which they have arisen have taken some time to explain. But
for the reasons which I have explained, there is in this case, in my judgment, no viable claim for judicial review
having a realistic prospect of success. In those circumstances, and in agreement with Lang J (see para [8] above),
permission for judicial review is refused.

**[49] Two consequential matters were raised. The first was the Secretary of State's invitation, to which I accede, to**
record the grant of permission to cite this permission judgment in light of the discussion of justiciability.

**[50] The second concerns costs. The Claimants' representatives asked me to direct a short period of further time**
for 'focused submissions' to challenge Lang J's order summarily assessing at £10,000 the costs of the Secretary of
State's Acknowledgment of Service ('AOS'). The Secretary of State resisted any further rounds of submissions and
asked me to uphold Lang J's order. In my judgment it is neither necessary nor appropriate to allow a further round
of submissions. Lang J made a Court Order which (a) required the Claimants to file within 14 days any 'written
representations' for challenging her costs order and (b) made clear that the Judge dealing with the renewal hearing
would make a final determination on costs based on those representations. Those representations were made. That
was the opportunity for 'focused submissions'. The sole issue is the reasonable costs of the AOS. There has been
no application by anyone relating to the costs of the hearing before me. Further, the parties were on clear and
adequate notice that the Court would deal with consequential matters in its Order to accompany hand-down. That
course enables reasoned rulings on consequential matters within the handed-down judgment. There is no good
reason to allow further delay. The Claimants had the opportunity to make clear submissions and have done so.
**[*646]**

**[51] As to the summary assessment of the costs of the AOS, the starting point is that the £21,912 claimed by the**
Defendant was disproportionate and unreasonable, far exceeding the costs applications normally made at the
permission stage, including claims far more extensive and complex than this one. Lang J reached and expressed all


-----

of these conclusions and I agree with her about them. In inviting the Court to reduce to £3,000 the order which Lang
J made, the Claimants have invoked this guidance and illustration:

'In R (Roudham and Larling Parish Council) v Breckland Council _[[2009] 2 Costs LR 282, the Court of Appeal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:585S-8D21-F152-J196-00000-00&context=1519360)_
noted that the [AOS] should contain only a summary of the grounds on which the claim is resisted. If a party
wishes to go further than that at the permission stage, it does so at its own expense (§26). In that case, the
Court of Appeal awarded £5,000 of the £17,000 claimed, in circumstances where the claimant was a public
authority and the AOS in issue was filed by a private company.'

The Secretary of State does not contest that description of that guidance or that case. She submits that there were
a number of legal issues which required more legal research and detailed drafting than is standard in preparing an
AOS, and asks me to uphold the £10,000 assessed by Lang J.

**[52] I have reconsidered the summary grounds of resistance within the Secretary of State's AOS. They were an 18-**
page (single-spaced) document dealing comprehensively with fact, law and submissions. They set out in some
detail factual matters (accompanied by a statement of truth) on which Lang J and I were able to rely. However, had
those factual matters been in an accompanying permission-stage witness statement, I would not have been
allowing them as AOS costs. The summary grounds addressed the law in some detail – as have I – which assisted
Lang J and me. It was open to the Secretary of State to instruct Sir James Eadie QC as well as Ms Clement; to
provide so thorough and comprehensive a summary grounds document; and then to provide a 12-page skeleton
argument 'incorporating by reference' key sections within the summary grounds. However, having regard to all the
circumstances and to the Roudham guidance – which has not been challenged – I am satisfied that it is appropriate
to reduce the summarily assessed AOS costs, in all the circumstances, to £7,500.

Permission refused.

Wendy Herring Barrister.

**End of Document**


-----

