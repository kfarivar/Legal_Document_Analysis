# R (on the application of BVN) v Secretary of State for the Home Department

 [2022] EWHC 1159 (Admin)

Queen's Bench Division, Administrative Court (London)

Bourne J

16 May 2022Judgment

**Chris Buttler QC and Gayatri Sarathy (instructed by Duncan Lewis Solicitors) for the Claimant**

**Robin Tam QC and Benjamin Tankel (instructed by Government Legal Department) for the Defendant**

Hearing date: 5th April 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**The Hon. Mr Justice Bourne:**

INTRODUCTION

The claim

1. This judicial review claim concerns the treatment of a migrant who has been identified as a potential
victim of human trafficking, and the lawfulness of statutory guidance issued by the Defendant under section
49 of the Modern Slavery Act 2015.

2. The claim raises two distinct questions or topics:

(1) Is the Defendant's statutory guidance unlawful because it permits a potential victim of trafficking to
withdraw from the National Referral Mechanism (“NRM”) without imposing a requirement of informed
consent (and/or was it therefore unlawful for the Defendant to take steps to remove the Claimant from the
UK following such a withdrawal)?

(2) If the High Court grants unconditional bail to a person in immigration detention, is it lawful for the
Secretary of State then to impose a condition on the person's release requiring them to report periodically
to a specified location?

The legal provisions relating to human trafficking.

3. The UK is a signatory to the European Convention Against Trafficking (“ECAT”). ECAT is an
unincorporated treaty which is not enforceable in the domestic courts. However, it is common ground
between the parties that the Defendant has published a policy commitment to give effect to articles 10-13
of ECAT. The Claimant's position, that an unjustified departure from that policy would be unlawful, has
been accepted by the Defendant in previous cases: see the references in MS (Pakistan) v SSHD _[2020]_
_UKSC 9, [2020] 1 WLR 1373 at [20] per Baroness Hale. The Defendant does not contest the point in this_
Court but reserves her position if the case is appealed to a higher Court.


-----

4. Of central importance under ECAT is an obligation on contracting States to identify potential and actual
victims of “modern slavery”, which includes human trafficking and slavery, servitude and forced labour.
That is reflected in the UK by section 49 of the Modern Slavery Act 2015, which provides:

“(1)  The Secretary of State must issue guidance to such public authorities and other persons as the
Secretary of State considers appropriate about –

(a)  the sorts of things which indicate that a person may be a victim of slavery or human trafficking;

(b)  arrangements for providing assistance and support to persons who there are reasonable grounds to
believe may be victims of slavery or human trafficking;

(c)  arrangements for determining whether there are reasonable grounds to believe that a person may be
a victim of slavery or human trafficking.”

5. The Defendant has accordingly issued guidance under section 49 which is applicable in England and
Wales (“the Guidance”). The Guidance has been amended from time to time. The parties agree that the
most recent edition, version 2.8 which was published in March 2022, does not differ materially from the
version which was in force at the time of the relevant events. It is therefore convenient for this judgment to
refer to the current version.

6. Under the Guidance, “First Responder Organisations” (including law enforcement agencies, local
authorities and immigration officials) and other public authorities who encounter potential victims of
**_modern slavery are required to refer those individuals to the NRM, which is the UK's framework for_**
identifying and supporting victims of modern slavery.

7. Following a referral, decision-making is carried out by the “Single Competent Authority” (“SCA”) in two
stages.

8. Within 5 days of an individual's referral to the NRM, the SCA should make a “reasonable grounds”
(“RG”) decision, i.e. whether the decision-maker suspects but cannot prove that the individual is a victim of
**_modern slavery. If that decision is positive, the individual should be given a “recovery and reflection_**
period” of at least 45 days, during which they cannot be removed from the UK and must be given support
of various kinds. An individual who is in immigration detention will normally be released unless there are
“public order” reasons to do otherwise.

9. The second stage is a “conclusive grounds” (CG”) decision as to whether, on the balance of
probabilities, the individual is a victim of modern slavery. A CG decision requires evidence gathering and
although there is a target of making such a decision within 45 days, in practice there are long delays, often
of over a year. A positive CG decision could provide a basis for the individual to make applications under
the immigration system e.g. for asylum, leave to remain and/or family reunion.

10. Individuals who have been referred to the NRM receive support and assistance in different ways,
depending on whether they are at liberty or in immigration detention.

11. For those not in detention, support is provided under the **_Modern Slavery Victim Care Contract_**
(“MSVCC”) delivered by the Salvation Army. Paragraph 8.22 of the Guidance states that those who
consent to enter this support:

“… will receive advocacy to access this support. This will usually be provided by a support worker in
**_Modern Slavery Victim Care Contract accommodation or a support worker engaged in outreach support.”_**

12. The range of types of support is listed at paragraph 8.28 of the Guidance:

“• Accommodation and Emergency Accommodation

- Financial support and material assistance

- Translation and interpretation services

- Information on rights and services

Medical treatment assistance and counselling


-----

     - Assistance during criminal proceedings

     - Access to the labour market, vocational training and education

     - Access to legal representation and legal aid

    - Pursuing compensation

     - Travel to appointments

     - Assistance to return to home country if not a UK national and

Discretionary Leave

     - Support in transitioning to alternative support services.”

13. Annex F of the Guidance explains in more detail that support workers in MSVCC accommodation or
engaged in outreach support “should be able to provide potential victims ... with information on the rights
and services available to them” and that this should be in a language which the potential victim can
understand and, where possible, in writing (Annex F, paragraphs 15.51-53)

14. Those in detention, however, do not enter the MSVCC and are not assisted by its support workers.
They are supported by way of the existing facilities in each Immigration Removal Centre (“IRC”) or other
place of detention. In _R (EM) v SSHD [2018] EWCA Civ 1070, [2018] 1 WLR 4386, the Court of Appeal_
(per Peter Jackson LJ at [40]) found that the regime at IRCs provides:

“(1) Accommodation, catering facilities, leisure and recreation facilities,

religious arrangements, education classes, opportunities for paid work, and access to social and legal
visits.

(2) Health screening of all detainees on arrival, and thereafter healthcare

provision equivalent to the primary community healthcare services provided to the general public.

(3) A range of psychological services according to need.

(4) The right to legal advice. Libraries in immigration removal centres

contain a range of reference materials and resources. Detainees are entitled to keep a mobile phone.
Weekly legal surgeries are held.

(5) Telephone interpretation is available to help staff speak to detainees.”

The background facts

15. According to the Claimant, a Vietnamese national, he first arrived in the UK via Russia in the back of a
lorry in 2009. On arrival he was discovered and detained for 14 days and then, a day after his release, he
was captured by traffickers. In 2013 he escaped and returned to Vietnam. In 2018 he was again brought to
the UK in the back of a lorry and was taken to a warehouse where he was required to tend cannabis
plants. In January 2019 he was arrested, made allegations of having been trafficked and was referred by
police to the NRM, using an alias. The NRM made a positive reasonable grounds (“RG”) decision on 17
January 2019 but a negative conclusive grounds (“CG”) decision on 11 March 2019.

16. He pleaded guilty to cannabis production and on 16 July 2019 was sentenced to 8 months in prison.
Having spent that time on remand, he was taken into immigration detention on the same date. On 18 July
2019 he was served with a Stage 1 deportation notice.

17. On 16 August 2019 the Claimant was moved to an IRC and was referred to the NRM for a second
time, now under his real name. On 4 September 2019 he received a positive RG decision, but the
Defendant voided the referral because it duplicated the referral made under a different name in January
2019.


-----

18. On 19 December 2019 the Single Competent Authority (“SCA”) agreed to reconsider the previous
negative CG decision within 3 months, having regard to submissions by the Claimant and to the
information contained in the duplicate referral. However, no new CG decision was made.

19. Following commencement of a judicial review claim, the Claimant was released from detention on 17
January 2020. It is agreed that, at that time, he will have been given the assistance of a support worker.

20. However, he was reported missing on 13 February 2020, having once again been trafficked and forced
to grow cannabis.

21. On 4 September 2020 he was found, arrested and remanded in custody. On or around 30 September
2020 he was referred to the NRM for a third time.

22. At this time he was represented by solicitors (not Duncan Lewis who represent him in this claim) in the
criminal proceedings. On 9 October 2020 he and his solicitor had a “lengthy discussion” (according to the
solicitor's attendance note) by video, with an interpreter. He told his solicitor that he did not want to avail
himself of the NRM scheme and just wanted to plead guilty and be deported to Vietnam as soon as
possible. The solicitor recorded giving him advice that the NRM referral could help him in the criminal case,
but no other advice about the NRM referral.

23. The Claimant says that he was in regular telephone contact with his wife in Vietnam at this time. She
said that the traffickers were threatening to harm her, and him if he returned. He was suffering from poor
mental health, felt suicidal and believed that “I was likely to be dead whatever I chose to do”.

24. On 11 November 2020 he pleaded guilty to growing cannabis, and was sentenced to only 5 months in
view of being a victim of forced criminality. The custodial part of the sentence ended a few days later, on
19 November 2020. However, he continued to be detained by the Defendant under immigration powers at
HMP Nottingham.

25. On 25 November 2020 he submitted a request to speak to an Immigration Officer about returning to
Vietnam. A conversation took place, assisted by an interpreter. The Claimant says that he was told simply
that if he withdrew his trafficking and asylum claims, he would be able to return to Vietnam quickly.

26. The Claimant did not request any further legal advice during this period.

27. On 3 December 2020, during a legal visit and with an interpreter present, the Claimant signed forms
withdrawing both his asylum claim and the third NRM referral.

28. The NRM withdrawal form is very brief. It states: “I agree that I wish to withdraw from the NRM
process. This means that I no longer wish the Single Competent Authority (SCA) to consider my referral.”
That is followed by the individual's NRM reference number, name and signature and the date.

29. The Claimant was then transferred to an IRC on 19 December 2020. On 8 January 2021 he was
served with a deportation order. On or around 11 January 2021 he applied for the Facilitated Return
Scheme to Vietnam.

30. On 15 January 2021, Duncan Lewis solicitors, who had previously represented him in the immigration
and trafficking matters, were told that he had been found. They now resumed advising him. In February
2021 there was correspondence under the pre-action protocol. By a letter from Duncan Lewis on 12
February 2021, he requested reinstatement of his asylum and trafficking claims.

31. However, on 5 March 2021 the Defendant informed him that his first and third NRM referrals had been
merged and treated as withdrawn and so there was no outstanding CG decision.

32. This claim was issued on 10 March 2021, together with an application for urgent interim relief
contending that, because he had a positive RG decision, his continued detention was unlawful in the
absence of public order grounds justifying it.

33. A hearing took place on 18 March 2021 before David Elvin QC, sitting as a Deputy High Court Judge.
The Deputy Judge expressed the view that there was at least a strong prima facie case that the Claimant
had indeed requested a new referral into the NRM. He also indicated that any suggestion that the Claimant


-----

posed a risk of absconding or re-offending (save under coercion from others) was contradicted by the
sentencing remarks in the criminal proceedings. Counsel for the Defendant (not Mr Tam QC who appeared
before me) conceded that the balance of convenience was in favour of release and did not advance public
order reasons for detention to continue.

34. The Deputy Judge decided to grant interim relief in the form of bail rather than an injunction, observing
that this was “the simplest way in which conditions can be attached”. He had earlier indicated that
conditions would be needed, not to restrict the Claimant's liberty but to protect him from the risk of retrafficking. There was some debate about the conditions but the Defendant did not request a reporting
condition.

35. On 23 March 2021 the Claimant was released to Salvation Army safe house accommodation in
accordance with the Deputy Judge's order. However, he was given a form by the Defendant's officials
stating that he must comply with a condition of reporting in person every week to an immigration official in
Leeds (“the reporting condition”). That was not one of the conditions which the Deputy Judge had imposed.

36. On 31 March 2021 the Defendant confirmed that the Claimant's trafficking claim was reinstated and he
would now, once again, be treated as having a positive RG decision with a pending CG decision. No CG
decision has yet been made.

37. Following commencement of this claim and a further interim relief application, on or around 10 June
2021 the Defendant varied the bail condition to require only reporting by telephone rather than in person.

38. On 29 June 2021, Lavender J granted permission for judicial review on the two grounds raising the
issues set out above.

39. On 8 July 2021 the Claimant was notified that his reporting condition was now entirely withdrawn.

40. On 24 August 2021, he was reported missing to Police. Nothing more has been heard from him and
his legal team suspect that he has again been re-trafficked. His solicitors have written authorisation to
continue to act in his best interests in the event they are unable to contact him.

THE INFORMED CONSENT GROUND

Is this ground of challenge academic?

41. Mr Robin Tam QC, representing the Defendant, first submits that the informed consent ground (and
indeed the second ground, to which I shall come) is academic because the Claimant has now been readmitted to the NRM and so, notwithstanding his disappearance, is once again awaiting a CG decision. Mr
Tam therefore invites me to consider whether the pursuit of this ground is an appropriate use of the Court's
time and resources. In oral submissions he did not strongly urge me not to proceed, but he urged me to
proceed with caution if at all.

42. The short answer, in my judgment, is that this question was aired before Lavender J in an oral hearing
on 29 June 2021, at the conclusion of which he granted permission. The parties have therefore complied
with the directions which were given on that occasion and have prepared for the substantive hearing of this
ground.

43. The only factual change since Lavender J made that decision is the loss of contact with the Claimant.
As Mr Chris Buttler QC said on behalf of the Claimant, the relevant facts had all crystallised before he
disappeared. In R (TDT (Vietnam)) v SSHD [2018] EWCA Civ 1395, [2018] 1 WLR 4922(“TDT”), the Court
of Appeal proceeded with an appeal in a trafficking case in which the claimant had had no contact with his
solicitors since the day his claim was issued, though in that case the Secretary of State did not object. In
these circumstances, the Claimant's disappearance does not persuade me to depart from the order
previously made. The issue raised by ground 1 is of public importance. Proceeding with due caution as Mr
Tam suggests, I do not consider that the circumstances of this case are such as to interfere with the
Court's ability to resolve the issue.


-----

44. Of course, if a challenge succeeds at a time when it has no practical consequences for the successful
Claimant, that can be a reason for the Court not to grant any relief, but that is a different question. In this
case, the only relief sought is a declaration which in practical terms would add little if anything to the
declaratory effect of a judgment.

The Claimant's case

45. Mr Buttler confirmed that his position is that the Guidance and the Defendant's decision in this
individual case stand or fall together. In other words, the Defendant's decision was unlawful because it was
made by the application of unlawful guidance. No other submissions are advanced in the challenge against
the individual decision.

46. The challenge is to paragraphs 14.243, 245 and 246 of the Guidance which provide for an individual's
NRM referral to be terminated by simply writing a letter or signing a form, with no requirement for the
individual to receive advice or information at that point:

“14.243. An adult may decide they want to leave the NRM before they receive a Reasonable Grounds or
Conclusive Grounds decision. Sometimes those adults are leaving the UK via a voluntary return, or
sometimes adults choose to withdraw consent for other reasons.

…

14.245. If an adult wishes to withdraw from the NRM after they receive a positive Reasonable
Grounds decision (or if they are in the UK and wish to withdraw prior to receiving this decision)
they should write to the relevant competent authority expressing their wish to withdraw or use a consent to
withdraw from the NRM template form.

14.246. The relevant competent authority should notify the organisations listed above of the decision to
withdraw. A person who withdraws from the NRM will not receive any further decisions or support from the
NRM and their case will be regarded as concluded. This does not prevent a person being re-referred to the
NRM in the future.”

47. By contrast, the Guidance makes clear that an adult's entry into the NRM requires informed consent:

“5.30. Adult victims need to give informed consent to enter the NRM and access the MSVCC support
specifically available to victims of modern slavery.

5.31. It is important that, where the individual has the capacity to consent, that they understand what they
are consenting to. First Responders should ensure that victims understand that by entering the NRM they
are consenting to a Reasonable Grounds and Conclusive Grounds decision being made. First Responders
should inform the victims of the support that they may be able to receive as set out in the Why enter the
National Referral Mechanism? section of this guidance. This may require the assistance of an appropriate
interpreter.

5.32. When a person is referred into the NRM it is the responsibility of the First Responder to ensure that
the person is informed how their data will be processed by the Home Office for the purpose of determining
if they are a victim of **_modern slavery and to provide them with support via the_** **_Modern Slavery Victim_**
Care Contract (if support is required). The First Responder must refer the person to the NRM Privacy
Information Notice found here.

5.33. First Responders are required to record that they have obtained consent when completing a referral
through the Modern Slavery Portal.”

48. It should be noted that an individual's wish to return voluntarily to their country of origin does not
prevent entry into the NRM in the first place. To the contrary, paragraph 15.172 states:

“A desire to return home is not a barrier to entering the NRM. Where victims express a desire to return,
they should still be informed about the NRM and the immediate support available through it, including the
option of a voluntary return.”


-----

49. Mr Buttler referred me to the test to be applied in a challenge to the lawfulness of guidance and other
policy documents. The Supreme Court in R (A) v SSHD [2021] UKSC 37, [2021] 1 WLR 3931decided that
the correct test had been identified in _Gillick v West Norfolk and Wisbech AHA_ [1986] AC 112HL. Lord
Sales and Lord Burnett CJ (with whom the other Justices agreed) summarised it in these terms:

“38. … does the policy in question authorise or approve unlawful conduct by those to whom it is directed?
… the court will intervene when a public authority has, by issuing a policy, positively authorised or
approved unlawful conduct by others …

41. The test … is straightforward to apply. It calls for a comparison of what the relevant law requires and
what a policy statement says regarding what a person should do. If the policy directs them to act in a way
which contradicts the law it is unlawful. …

46. In broad terms, there are three types of case where a policy may be found to be unlawful by reason of
what it says or omits to say about the law when giving guidance for others: (i) where the policy includes a
positive statement of law which is wrong and which will induce a person who follows the policy to breach
their legal duty in some way … ; (ii) where the authority which promulgates the policy does so pursuant to a
duty to provide accurate advice about the law but fails to do so, either because of a misstatement of law or
because of an omission to explain the legal position; and (iii) where the authority, even though not under a
duty to issue a policy, decides to promulgate one and in doing so purports in the policy to provide a full
account of the legal position but fails to achieve that, either because of a specific misstatement of the law
or because of an omission which has the effect that, read as a whole, the policy presents a misleading
picture of the true legal position.”

50. Mr Buttler seeks to show that this is a case of type (ii) or type (iii) described in A, in that the Guidance
fails to reflect legal requirements found in or by reference to (1) Article 4 of the ECHR, (2) the policy
commitment to comply with the relevant provisions of ECAT and (3) the requirements of a rational policy at
common law.

51. ECHR Article 4 requires that no one shall be held in slavery or servitude or required to perform forced
or compulsory labour. The Court of Appeal in TDT held (per Underhill LJ) at [17]:

“… the duties which the court has held to be imposed by article 4 as regards human trafficking can be
classified under three headings: (a) a general duty to implement measures to combat trafficking – 'the
systems duty'; (b) a duty to take steps to protect individual victims of trafficking – 'the protection duty'
(sometimes called 'the operational duty'); (c) a duty to investigate situations of potential trafficking – 'the
investigation duty' (sometimes called 'the procedural duty').”

52. Strasbourg cases to which the Court referred in _TDT_ show that the protection duty arises when
authorities are aware of circumstances giving rise to a credible suspicion that an individual has been
trafficked or is at real and immediate risk of being trafficked. The ECtHR in _Chowdury v Greece_
(CE:ECHR:2017: 0330JUD002188415) ruled at [88] that in such circumstances there will be a breach of
Article 4 “where the authorities fail to take appropriate measures within the scope of their powers to remove
the individual from that situation or risk”.

53. There has been some debate about whether the duty does necessarily arise in every case where a
person may have been trafficked in the past. Underhill LJ in TDT at [41] said that, even if there must in fact
be some risk of future trafficking to trigger the duty, the authorities “will in any event have to conduct a
careful assessment” before deciding that a past victim of trafficking is no longer at real and immediate risk
of being re-trafficked.

54. As the courts have recognised in cases such as _TDT, this positive operational duty is of the same_
broad kind as the positive duty to avoid a breach of Article 2 which protects the right to life. In the context of
that duty, the House of Lords in In re Officer L [2007] UKHL 36, [2007] 1 WLR 2135said (per Lord Carswell
at [21]):

“… the applicant has to show that the authorities failed to do all that was reasonably to be expected of
them to avoid the risk to life. The standard accordingly is based on reasonableness, which brings in


-----

consideration of the circumstances of the case, the ease or difficulty of taking precautions and the
resources available. In this way the state is not expected to undertake an unduly burdensome obligation
…”.

55. Mr Buttler's core submission on Article 4 is that, by promulgating Guidance which enables a potential
victim of trafficking to give up the support and protection available under the NRM without being informed
about the effect on his or her rights of doing so, the Defendant has done less than could reasonably be
expected to avoid the risk of trafficking.

56. Turning to ECAT, Mr Buttler submits that enabling a potential victim to leave the NRM on the basis of
consent which is not fully informed is incompatible with provisions of Articles 12 and 13 with which the
Defendant has made a policy commitment to comply.

57. The material parts of Articles 12 and 13 provide (with emphasis added):

“Article 12 – Assistance to victims

1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

a. standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b. access to emergency medical treatment;

c. translation and interpretation services, when appropriate;

d. counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e. assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f. access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.

…

5. Each Party shall take measures, where appropriate and under the conditions provided for by its internal
law, to co-operate with non-governmental organisations, other relevant organisations or other elements of
civil society engaged in assistance to victims.

6. Each Party shall adopt such legislative or other measures as may be necessary to ensure that
assistance to a victim is not made conditional on his or her willingness to act as a witness.

7. For the implementation of the provisions set out in this article, each Party shall ensure that services are
provided on a consensual and informed basis, taking due account of the special needs of persons in a
vulnerable position and the rights of children in terms of accommodation, education and appropriate health
care.

**Article 13 – Recovery and reflection period**

1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in their territory.


-----

2. During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2.  … ”

58. ECAT was published by the Council of Europe on 16 May 2005. It was accompanied by an
Explanatory Report containing commentary on its provisions. The commentary on Article 12 includes the
following:

“159. Sub-paragraphs d. and e. deal more specifically with assistance to victims in the form of supply of
information: two common features of victims' situation are helplessness and submissiveness to the
traffickers due to fear and lack of information about how to escape their situation.

160.  Sub-paragraph d. provides that victims are to be given counselling and information, in particular as
regards their legal rights and the services available to them, in a language that they understand. The
information deals with matters such as availability of protection and assistance arrangements, the various
options open to the victim, the risks they run, the requirements for legalising their presence in the Party's
territory, the various possible forms of legal redress, how the criminal-law system operates (including the
consequences of an investigation or trial, the length of a trial, witnesses' duties, the possibilities of
obtaining compensation from persons found guilty of offences or from other persons or entities, and the
chances of a judgment being properly enforced). The information and counselling should enable victims to
evaluate their situation and make an informed choice from the various possibilities open to them.

161.  Such advice and information, even though it has to do 'in particular [with] their legal rights', is to be
distinguished from free legal aid by an appointed lawyer in compensation proceedings, which is dealt with
specifically in Article 15, paragraph 2.”

59. Mr Buttler also drew my attention to the commentary on article 13 and to these words (with emphasis
added):

“174. The other purpose of this period is to allow victims to come to a decision 'on co-operating with the
competent authorities'. By this is meant that victims must decide whether they will cooperate with the lawenforcement authorities in a prosecution of the traffickers. From that standpoint, the period is likely to make
the victim a better witness: statements from victims wishing to give evidence to the authorities may well be
unreliable if they are still in a state of shock from their ordeal. 'Informed decision' means that the victim
must be in a reasonably calm frame of mind and know about the protection and assistance measures
available and the possible judicial proceedings against the traffickers. Such a decision requires that the
victim no longer be under the traffickers' influence.”

60. In short, Mr Buttler submits that in relation to withdrawal from the NRM, the Guidance is inconsistent
with Article 12.1.d, 12.2, 12.7 and 13.1 of ECAT and in those respects is an unlawful departure from the
Defendant's policy. That is by reason of a failure to ensure the necessary provision of information,
especially having regard to the vulnerability of potential victims of trafficking. That vulnerability is expressly
recognised in the Guidance, which explains that those who have experienced the trauma of **_modern_**
**_slavery may be reluctant or unable to self-identify, have difficulty recalling facts (paragraphs 6.1-6.2), be_**
affected by stigma attached to trafficking, fear reprisals against themselves or their families, be distrustful
of authorities (Annex D, paragraph 13.11) and avoid talking about their trauma (Annex D, paragraph
13.12).

61. An alternative submission that, in this regard, the Guidance is incompatible with obligations of the state
under ECHR Article 4 and/or under ECAT to complete a criminal investigation of the victim's trafficking,
with or without their consent, was not pursued before me.

62. Finally, Mr Buttler submits that the same conclusion of unlawfulness is reached by application of
common law principles.

63. In _Secretary of State for Work and Pensions v Johnson [2020] PTSR 1872, the Court of Appeal_
decided that the scheme adopted by the Secretary of State (in regulations) to calculate Universal Credit
was irrational because one aspect of it operated in many cases in a way which was “antithetical to one of
the principles of the overall scheme” (per Rose LJ at [106]).


-----

64. Mr Buttler submits that the same is true of the provisions in the Guidance enabling potential victims to
leave the NRM without being properly informed, because this undercuts the fundamental purpose of
supporting and protecting such vulnerable individuals.

65. In the alternative, Mr Buttler submits that for support to a vulnerable individual to be terminated by a
choice made otherwise than on a properly informed basis is procedurally unfair.

66. The facts of this case, Mr Buttler submits, precisely illustrate how the defect in the Guidance risks
undermining the purpose of the scheme.

67. When the Claimant signed the withdrawal form on 3 December 2020, it was some time since he had
last been referred to the NRM. He was in HMP Nottingham and did not have assistance under the scheme
from a support worker, as he would have had in the community. Nor did he have access to resources
available to those held in IRCs such as a mobile telephone, a library containing reference materials and
weekly legal surgeries. He was not in touch with the solicitors who represent him now and who previously
represented him in relation to trafficking matters.

68. Documents disclosed by the Defendant show that the Claimant told officials that he wanted to return to
Vietnam as quickly as possible. According to his own witness statement, he was struggling with his mental
health and was suicidal. There is no evidence that, at the time of signing the withdrawal form, he was told
anything about the consequences of withdrawal, or the consequences of a positive CG decision if he
awaited and then received one, including (1) entitlement to support with his psychological recovery in the
UK, (2) an obligation on the Defendant to consider granting him leave to remain in the UK or (3) that he
would qualify for protection in Vietnam if he returned after being identified as a victim of trafficking.

69. The evidence suggests that the Claimant's decision to withdraw was an ill-informed decision because,
as soon as he received advice from his present solicitors, he changed his mind and re-entered NRM.
Whilst the effect of his withdrawal was therefore reversed, it could have had grave consequences because
its immediate effect was that his asylum and trafficking claims were withdrawn and he was served with a
deportation order.

70. In summary, Mr Buttler submits that the Guidance regarding withdrawal from the NRM is misleading
because it misstates or omits to explain the legal requirements arising from ECHR Article 4 and/or from the
Defendant's policy on ECAT and/or at common law. It therefore fails the test in A.

71. Remedying this defect, Mr Buttler submits, would not impose an unreasonable burden on the
Defendant. All that would be required is to provide that an individual proposing to withdraw from the NRM
must be given information about the consequences of withdrawal. In the community that could easily be
done by a support worker. Different arrangements would have to be made in the comparatively few cases
where a person in receipt of a positive RG decision remains in detention.

The Defendant's case

72. In response, Mr Tam resists the suggestion that “informed consent” is needed for an individual to
withdraw from the NRM. He draws a contrast between the positions of a person entering the NRM and a
person leaving it.

73. Mr Tam points out that ECAT requires the provision of information of two types. Article 12.1.d refers
especially to information or advice about legal rights while the individual is in the NRM. Article 12.7,
conversely, emphasises the need for informed consent to be given for the provision of any service which is
to be provided to the individual, such as medical treatment. That is reflected by the Guidance, which
explains that individuals must “understand what they are consenting to” (paragraph 5.31) and must be
informed of how their data will be processed (paragraph 5.32). That reflects the need for individuals to
consent before processes are applied to them, and the fact that consent may be vitiated if it is not based
on proper information.

74. By contrast, Mr Tam submits that the Defendant has neither a duty nor a power to stop an individual
from withdrawing a trafficking claim (or an asylum claim), nor to advise or persuade an individual not to do
h th th ithd l i bj ti l d b d id A h i h t l th NRM i


-----

free to do so, regardless of their state of mind. To put it another way, once the individual has withdrawn
consent, then services under the NRM cannot be forced upon them.

75. Accordingly, the notion of “informed consent” to withdraw is misplaced. If an individual has withdrawn
consent, for example for medical treatment, that is the end of the matter. A failure to provide them with
information before their withdrawal might have other consequences, but it cannot mean that they will be
regarded as continuing to consent to the treatment.

76. So in the present case, Mr Tam emphasises the Claimant's determination to withdraw and the various
sources of information to which he had access before, during and after that decision. He was fully informed
about the NRM at the point of his referral in 2019, in the course of which (and until he was re-trafficked in
February 2020) he was represented by Duncan Lewis. He will have been re-informed about it when rereferred on 30 September 2020. By 9 October 2020 he told his criminal solicitors that he did not want to
avail himself of the NRM. There is evidence that concern about him as a victim of trafficking was expressed
by both his defence team and the prosecution ahead of the sentencing on 11 November 2020. He
maintained that he wished to return to Vietnam at a meeting with an immigration officer in prison on 25
November 2020. The withdrawal forms were signed on 3 December 2020. He then reiterated his position
at another interview on 19 December 2020, with an Engagement Officer at an IRC, when he was told of the
duty solicitor scheme and that he had the right to contact his Embassy or Consulate, and that help was
available at the IRC's Welfare department. The notice served with the Detention Order on 8 January 2021
also stated: “If you wish to seek legal advice you must do so now.”

77. Mr Tam therefore characterises this ground of claim as, in reality, asserting that the Defendant was
under a duty to ensure that advice in the nature of legal advice was provided before any withdrawal. The
Claimant's case, he says, is not really based on a perceived lack of information about the NRM at the time
of signing a withdrawal form; rather it is based on a perceived failure to advise the individual about the pros
and cons of the withdrawal. That, says Mr Tam, is different from the kinds of information which ECAT
requires to be provided.

78. If that is the right categorisation of what should be provided, then Mr Tam submits that the system
does not fail to provide it. Those with trafficking claims, and asylum claims, have ready access to
independent legal advice, and at all material times the Claimant had access to it. Advice of that kind should
indeed be provided independently and not by or on behalf of the Defendant.

79. Mr Tam notes that Mr Buttler now appears to place primary reliance on ECHR Article 4. In response,
he submits:

1. It would be surprising if Article 4 imposed more demanding duties than ECAT, given that Article 4 has a
more general reach whilst ECAT makes detailed provision in the field of trafficking.

2. The protection duty arises only where there is a credible suspicion that a person is at risk of trafficking
within the jurisdiction (even if they have already been trafficked: see TDT at [41]). That threshold was not
reached in the present case, given that the Claimant was in detention and would leave detention only to
return to Vietnam.

3. The Defendant cannot prevent a person from leaving the NRM and leaving the UK, even if leaving
creates a risk of re-trafficking.

4. The Guidance in fact makes reasonable provision to ensure that those who enter the NRM are provided
with sufficient information about the protection that it provides, and provides further protection by stating
that those who leave the NRM can be re-referred, a possibility of which the Claimant in fact availed himself
within a short time.

80. So far as the lawfulness of the Guidance is concerned, Mr Tam reminds me of the limits of what is
required by the test in _A, by reference to the decision of the Supreme Court (on the same day) in_ _BF_
(Eritrea) _v SSHD_ _[2021] UKSC 38, [2021] 1 WLR 3967. In response to a submission that a policy was_
unlawful because it did not sufficiently remove a risk that immigration workers might make mistaken


-----

decisions (in assessing the age of asylum seekers claiming to be children), Lord Sales and Lord Burnett CJ
said at [51-52]:

“51. In our view, this submission involves a misinterpretation of what was said in _Gillick and cannot be_
sustained. As we explain in our judgment in the A case, the meaning of the formula used by Lord Scarman
is much narrower than suggested by Mr Hermer. It involves comparing two normative statements, one
being the underlying legal position and the other being the direction in the policy guidance, to see if the
latter contradicts the former. Mr Hermer's submission as to the effect of _Gillick distorts this test by_
comparing a normative statement with a factual prediction, i.e. comparing the underlying legal position with
what might happen in fact if the persons to whom the policy guidance is directed are given no further
information. If correct, this would involve imposing on the person promulgating the guidance a very
different, and far more extensive, obligation than that discussed in Gillick. It would transform the obligation
from one not to give a direction which conflicts with the legal duty of the addressee into an obligation to
promulgate a policy which removes the risk of possible misapplication of the law on the part of those who
are subject to a legal duty. There is no general duty of that kind at common law.

52. Whenever a legal duty is imposed, there is always the possibility that it might be misunderstood or
breached by the person subject to it. That is inherent in the nature of law, and the remedy is to have
access to the courts to compel that person to act in accordance with their duty. An asylum seeker has the
same right to apply to the courts as anyone else. Save in specific contexts of a kind discussed below and
in our judgment in the A case, there is no obligation for a Minister or anyone else to issue policy guidance
in an attempt to eliminate uncertainty in relation to the application of a stipulated legal rule. Any such
obligation would be extremely far-reaching and difficult (if not impossible in many cases) to comply with. It
would also conflict with fundamental features of the separation of powers. It would require Ministers to take
action to amplify and to some degree restate rules laid down in legislation, whereas it is for Parliament to
choose the rules which it wishes to have applied. And it would inevitably involve the courts in assessing
whether Ministers had done so sufficiently, thereby requiring courts to intervene to an unprecedented
degree in the area of legislative choice and to an unprecedented degree in the area of executive decisionmaking in terms of control of the administrative apparatus through the promulgation of policy.”

81. Finally Mr Tam resists the suggestion that the Guidance is irrational in that it does not give effect to its
broad purpose. He refers to _R (KTT) v SSHD [2022] EWCA Civ 307 in which the Court of Appeal_
overturned a ruling that the Defendant's policy was inconsistent with ECAT by not requiring any grant of
leave to remain in the UK for those with a positive RG decision despite the context of long delays in making
CG decisions. Underhill LJ, with whom Vos MR and Dingemans LJ agreed, rejected a submission that this
omission was inconsistent with the “primary purpose” of facilitating victims' recovery:

“This submission is in my view wrong in principle. It is not the effect of ECAT that state parties are required
to take any step that might be conducive to its overall objectives. Its provisions impose specific obligations,
and, if the Secretary of State's policy is to comply with ECAT, she is only required to adhere to those
provisions. For the reasons given I do not regard article 10.2 (or indeed any other provision of chapter III)
as imposing the obligation contended for.”

82. Mr Tam submits that the same reasoning applies to the allegation that an omission from the Guidance
is inconsistent with its primary purpose of implementing certain provisions of ECAT.

Discussion

83. This ground of challenge depends on the proposition that the Defendant's Guidance is legally obliged
to provide for an individual to be given information or advice before withdrawing from the NRM. It therefore
depends on identifying the source of such an obligation.

84. In my judgment, no such obligation can be found in the relevant provisions of ECAT or, therefore, in
the Defendant's policy commitment to implement them.


-----

85. Article 12.1.d, read with Article 13.2, means that individuals, during their recovery period, must be
provided with counselling and information, in particular as regards their legal rights and the available
services, to the extent necessary to assist them in their recovery.

86. I do not consider it implicit (or explicit) in that requirement that any specific “counselling and
information” will be necessary if and when the individual decides to withdraw. Rather, if an individual is
given sufficient counselling and information to enter the NRM on a sufficiently informed basis, it seems to
me that that individual will be armed with sufficient information to decide whether or not to withdraw.

87. There may of course be cases when, at the point of a decision to withdraw, particular advice, e.g.
about the pros and cons of withdrawal, would be valuable. As Mr Buttler suggested, it could be more
valuable in a case where a long time had elapsed since the person's entry into the NRM. It could have
particular value in cases where individuals might be under the influence of their former traffickers.

88. The Guidance in its present form does not prevent such advice from being given. Nor, in my judgment,
does it encourage any official not to give advice. At worst, paragraphs 14.243, 245 and 246 do not remind
officials that such advice could have value.

89. I also do not consider that the case can be founded on Article 12.7, which requires that the relevant
services must be provided “on a consensual and informed basis”. That in my judgment means what it says.
There must be consent, which must be informed consent, meaning that the individual must know and
understand what they are consenting to.

90. Mr Buttler sought to persuade me that a requirement of informed consent on entry to the NRM should
be mirrored by a similar requirement on exit. However, I agree with Mr Tam that that proposition is not
sound, for two reasons.

91. The first reason is that the rationale, or the need, for informed consent is not the same in the case of
both entry and exit. When individuals enter the NRM, they are authorising certain things to happen.
Important decisions about them will be made, and they will or may be the subject of intervention such as
medical treatment. Without consent, such interventions are unauthorised. And, in this area of the law as in
others, consent may be vitiated if it is not properly informed. Exit from the NRM, by contrast, does not
authorise any intervention or commit the individual to anything. For that reason there is not the same
potential issue of whether authorisation was on a sound basis.

92. The second reason is that consent either is or is not in place. When it appears to be in place, it may
yet turn out not to be legally effective because it was not given on a properly informed basis. But the
converse is not true. If an individual withdraws consent, even on a basis which is not properly informed, the
provider of a service cannot assert that consent to the service should nevertheless be deemed to have
remained in place.

93. Nor do I consider that the Claimant's case can be founded on the reference in Article 13.1 to the need
for a potential victim “to take an informed decision on cooperating with the competent authorities”. Those
words do show that the taking of an informed decision on whether to cooperate is one of the purposes of
the measures specified in these Articles. I will also assume for present purposes that cooperation in this
context includes cooperation with the process of reaching a CG decision (and not just with the process of
any criminal investigation of the trafficking, which is perhaps the more natural meaning of the words in
context). Nevertheless, it seems to me that, in order properly to reflect Article 13.1, the Guidance needed
to provide for all appropriate information and advice being made available to individuals entering the NRM.
It has not been suggested that the Guidance is deficient in that respect. If that obligation is performed, then
I cannot perceive in Article 13.1 a specific requirement for further or other information to be given, or
repeated, at the point of deciding to leave.

94. As this case approached its substantive hearing, the focus to some degree switched from ECAT
towards ECHR Article 4, on which Mr Buttler laid particular emphasis. The focus in respect of Article 4 also
switched from the investigation duty to the protection duty.


-----

95. I work on the assumption that the protection duty did arise in respect of the Claimant, whether or not
that would be the case for all individuals in receipt of a positive RG decision, and also that he or someone
in a position analogous to his should be treated as being at risk of re-trafficking. That is reflected in Article
13.1 of ECAT, which identifies one of the purposes of the recovery and reflection period as escaping the
influence of traffickers. An unwise decision to leave the NRM logically could increase that risk. The issue is
now whether paragraphs 14.243, 245 and 246 represent a failure by the Defendant to do all that can be
reasonably expected of her to avoid that risk.

96. This question must be considered alongside that posed by any challenge to the lawfulness of
Government policy, applying A and BF (Eritrea). I must decide whether the omission from the Guidance of
any requirement to give or offer further information or advice is such as effectively to mislead the
Defendant's officials about their legal obligations.

97. In my judgment Article 4 cannot be interpreted as mandating any specific steps to be taken when an
individual indicates a wish to leave the NRM. That is not least because of the difficulty of identifying the
necessary steps. Mr Buttler agreed that there is a range of possible steps and that the choice will depend
on the facts of individual cases.

98. At most, therefore, Article 4 might oblige officials, on learning that an individual wishes to leave the
NRM, to consider whether any other steps or any other enquiries are appropriate. But I do not consider that
any other specific requirement, e.g. to remind the individual of the advantages of remaining in the NRM,
could have general application. It could be apposite in some cases but no doubt would be inapposite in
others.

99. Nor, for completeness, do I consider that any other obligation is imposed by the common law duty of
rationality. That really follows from my ruling in relation to ECAT, because the purpose of the Guidance is
to implement those particular treaty provisions. In any event, I do not consider that paragraphs 14.243, 245
and 246 of the Guidance run contrary to any of its fundamental purposes.

100. There is also nothing in the point about procedural unfairness. The decision to leave the NRM is a
decision by the potential victim, not by the Defendant, and it must always be for that individual to give or
withhold consent.

101. In my judgment, the Guidance in its present form might be improved by reminding officials to ask
themselves the question of whether any further steps are appropriate, but it does not prevent them from
asking it. Nor, in my judgment, does it discourage them from asking it. It follows that the Guidance does not
misstate the law or mislead officials, either positively or by omission.

102. Mr Buttler drew my attention to paragraph 47 of the judgment of Lords Sales and Burnett CJ in A,
which referred to a category (iii) case i.e. where an authority, though not under a duty to issue a policy,
nevertheless promulgates one which purports to provide a full account of the legal position. Such a policy,
it was said, need not go into full detail about how a discretion should be exercised in every case, but it
“may be sufficiently congruent with the law if it identifies broad categories of case which potentially call for
more detailed consideration”. Mr Buttler suggests that this is such a case.

103. It seems to me that the present case falls into category (ii) rather than category (iii) because the
Guidance is issued under a statutory duty imposed by section 49 of the 2015 Act. More importantly,
however, I do not understand paragraph 47 of A as stating that policies in general are required to identify
“broad categories of case which potentially call for more detailed consideration”. Rather that paragraph
merely explains that policies are not necessarily obliged to go into detail about how discretions are to be
exercised.

104. That paragraph therefore does not dissuade me from my conclusion that the Guidance does not
mislead officials about the legal position by omitting to refer to a specific requirement of ECHR Article 4. A
ruling to the contrary, in my judgment, would fall into the category identified in BF (Eritrea) as imposing “an
obligation to promulgate a policy which removes the risk of possible misapplication of the law”.

105. The first ground therefore fails.


-----

THE REPORTING CONDITION GROUND

Is this ground of challenge academic?

106. The question is whether the Defendant was entitled to impose the reporting condition on the Claimant
after the High Court made a grant of bail which did not include that condition.

107. About 5 weeks after Lavender J granted permission to apply for judicial review, the Defendant
withdrew the reporting condition. And since then, of course, contact with the Claimant has been lost. A
decision on this second ground therefore will have no practical significance for the Claimant. As in the case
of the first ground, Mr Tam invites me not to proceed, or to proceed only with caution.

108. Although I do not know how often in practice a conflict may arise between bail conditions imposed by
the High Court and by the Defendant, it seems to me that the potential for such conflict makes it important
to resolve this question about the Defendant's powers. The Defendant has at all times maintained that she
acted within her powers. The parties have prepared fully. There is no doubt as to any of the relevant facts,
and the issue is one of pure law. If the Court will not resolve such an issue where it becomes academic,
then any future challenge of this kind may be sidestepped by withdrawal of the offending bail condition. In
my judgment it is in the public interest to decide this ground of challenge.

The legal framework

109. Schedule 3 to the Immigration Act 1971 empowers the Defendant to detain individuals who are
subject to immigration control in a number of specific situations. At the time of his bail application on 10
March 2021, the Claimant was being detained under paragraph 2(3) which provides that where a
deportation order is in force against any person, he may be detained pending his removal or departure
from the UK.

110. The _[Immigration Act 2016,by section 61 and schedule 10, created a new concept known as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
“immigration bail”. Schedule 10 provides so, far as material:

“1 (1) The Secretary of State may grant a person bail if—

…

(b) the person is being detained under paragraph 2(1), (2) or (3) of Schedule 3 to [the 1971] Act (detention
pending deportation),

…

(2) The Secretary of State may grant a person bail if the person is liable to detention under a provision
mentioned in sub-paragraph (1).

(3) The First-tier Tribunal may, on an application made to the Tribunal for the grant of bail to a person,
grant that person bail if—

…

(b) the person is being detained under paragraph 2(1), (2) or (3) of Schedule 3 to that Act,

…

(4) In this Schedule references to the grant of immigration bail, in relation to a person, are to the grant of
bail to that person under any of sub-paragraphs (1) to (3) or under paragraph 10(12) or (13) (release
following arrest for breach of bail conditions).

(5) A person may be granted and remain on immigration bail even if the person can no longer be detained,
if—

(a) the person is liable to detention under a provision mentioned in sub
paragraph (1), or


-----

(b) the Secretary of State is considering whether to make a deportation order against the person under
section 5(1) of the Immigration Act 1971.

(6) A grant of immigration bail to a person does not prevent the person's subsequent detention under a
provision mentioned in sub-paragraph (1).

…

(9) This paragraph is subject to paragraph 3 (exercise of power to grant immigration bail).

2 (1) Subject to sub-paragraph (2), if immigration bail is granted to a person, it must be granted subject to
one or more of the following conditions—

(a) a condition requiring the person to appear before the Secretary of State or the First-tier Tribunal at a
specified time and place;

(b) a condition restricting the person's work, occupation or studies in the United Kingdom;

(c) a condition about the person's residence;

(d) a condition requiring the person to report to the Secretary of State or such other person as may be
specified;

(e) an electronic monitoring condition … ;

(f) such other conditions as the person granting the immigration bail thinks fit.

(2) Sub-paragraph (3) applies in place of sub-paragraph (1) in relation to a person who is being detained
under a provision mentioned in paragraph 1(1)(b) or (d) or who is liable to detention under such a
provision.

(3) If immigration bail is granted to such a person—

(a) subject to sub-paragraphs (5) to (9), it must be granted subject to an

electronic monitoring condition,

(b) if, by virtue of sub-paragraph (5) or (7), it is not granted subject to an

electronic monitoring condition, it must be granted subject to one or more of the other conditions mentioned
in sub-paragraph (1), and

(c) if it is granted subject to an electronic monitoring condition, it may be

granted subject to one or more of those other conditions.

(4) Immigration bail granted in accordance with sub-paragraph (1) or (3) may also be granted subject to a
financial condition (see paragraph 5).

3 (1) The Secretary of State or the First-tier Tribunal must have regard to the matters listed in subparagraph (2) in determining—

(a) whether to grant immigration bail to a person, and

(b) the conditions to which a person's immigration bail is to be subject.

(2) Those matters are—

(a) the likelihood of the person failing to comply with a bail condition,

(b) whether the person has been convicted of an offence (whether in or outside the United Kingdom or
before or after the coming into force of this paragraph),

(c) the likelihood of a person committing an offence while on immigration bail,

(d) the likelihood of the person's presence in the United Kingdom, while on immigration bail, causing a
danger to public health or being a threat to the maintenance of public order,


-----

(e) whether the person's detention is necessary in that person's interests or for the protection of any other
person, and

(f) such other matters as the Secretary of State or the First-tier Tribunal thinks relevant.

…

6 (1) Subject to this paragraph and to paragraphs 7 and 8, where a person is on immigration bail—

(a) any of the conditions to which it is subject may be amended or removed, or

(b) one or more new conditions of the kind mentioned in paragraph 2(1) or (4) may be imposed on the
person.

(2) The power in sub-paragraph (1) is exercisable by the person who granted the immigration bail, subject
to sub-paragraphs (3) and (4).

(3) The Secretary of State may exercise the power in sub-paragraph (1) in relation to a person to whom
immigration bail was granted by the First-tier Tribunal if the Tribunal so directs.

(4) If the First-tier Tribunal gives a direction under sub-paragraph (3), the Tribunal may not exercise the
power in sub-paragraph (1) in relation to the person.”

111. The order made by the Deputy Judge on 18 March 2021 was not a grant of immigration bail. The
power exercised by the Deputy Judge arose because, when there is a pending application for leave to
apply for judicial review, the High Court has an inherent jurisdiction to grant bail as part of its powers to
grant ancillary orders: _R v Secretary of State for the Home Department ex p Turkoglu [1988] QB 398 at_
401B, per Sir John Donaldson MR. Such a grant can be made subject to conditions. The order can remain
in effect only during the lifetime of the judicial review proceedings.

The Claimant's case

112. Mr Buttler emphasises that at the conclusion of the interim relief hearing, the Deputy Judge, with the
assistance of the parties, identified bail conditions for the purpose of protecting the Claimant from further
trafficking, including a requirement to reside at safe house accommodation which the Defendant was
required to provide. That was the only restriction imposed on the Claimant's liberty. The Defendant did not
ask for further conditions to be imposed. The Defendant was free at any time to apply to vary or discharge
the order.

113. Five days later, on 23 March 2021, the Defendant served on the Claimant a copy of a “Bail Form
201”. It imposed a different type of condition on the Claimant, instructing him that, every week, “You must
REPORT to an immigration official at: Leeds Waterside Reporting Centre”. The form stated that: “Failure to
comply with any of the above conditions may lead to arrest … and/or your detention”; and 14 that “Failure
to comply with any of the above conditions, without reasonable excuse, is also a criminal offence which
may be punished by a fine or a prison sentence”.

114. For the first 3 weeks of April 2021 the Claimant reported as required. The issue then became of
practical significance because he was having to travel a long distance from safe house accommodation
each week to report. His solicitors pointed out that this increased his risk of being re-trafficked. The
reporting condition was suspended by agreement until late May 2021. The Claimant then sought interim
relief to suspend the condition until determination of the claim. On 10 June 2021, Ellenbogen J ordered that
reporting could be by telephone until further order. Permission was granted for this ground of challenge on
29 June 2021. As I have said, the Defendant eventually lifted the reporting condition on 8 July 2021.

115. When challenged, the Defendant's representatives asserted that the conditions imposed by this Court
were not technically “bail conditions” but were “conditions for release under the High Court's inherent
power to order release” and that the Defendant was separately entitled to impose bail conditions.

116. Mr Buttler refers me to _Stellato v Ministry of Justice [2010] EWCA Civ 1435. In that case, which_
concerned detention pursuant to a sentence for a criminal offence, the Court of Appeal explained that a
grant of bail is not an order for a person's detention but is instead a grant of liberty and that bail conditions


-----

do not impose obligations but qualify the grant of liberty (per Stanley Burnton LJ at [23-24]). A breach of
[bail conditions in a criminal case is an offence only because the Bail Act 1976 makes separate provision to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y1H2-00000-00&context=1519360)
that effect.

117. So, Mr Buttler submits, the grant of conditional bail by the Deputy Judge granted the Claimant his
liberty, qualified only to the extent of the residence condition. In particular it made the Claimant free to
remain at his residence address at all times, with no obligation to travel to Leeds or anywhere else.

118. Mr Buttler further submits that the Defendant's power to grant immigration bail, and therefore the
power (or duty) to attach conditions to it, is entirely parasitic on the Defendant's statutory power to detain.
Whilst paragraph 1(5) of schedule 16 to the 2016 Act provides that immigration bail can be granted even
when the power to detain cannot be exercised, it nevertheless can be granted only to a person who is in
principle liable to be detained under one of the statutory powers including paragraph 2 of schedule 3 to the
1971 Act.

119. It is common ground between the parties that, while the Deputy Judge's grant of bail was in force, the
Defendant's continuing statutory power to detain the Claimant could not be exercised because it would be
inconsistent with the Court order. Mr Buttler submits that the same applies to the Defendant's continuing
statutory power to grant conditional immigration bail.

120. In particular, Mr Buttler submits, the grant of bail by the High Court circumscribed the Defendant's
power to grant conditional bail by the order of the Court. That is because the Court's order was a grant of
liberty and an exercise of the statutory power would interfere with that order.

121. Mr Buttler relies on R (Von Brandenburg) v East London & City NHS Trust [2003] UKHL 58, [2004]
AC 280where Lord Bingham said at [8] that “the rule of law requires that effect should be loyally given to
the decisions of legally-constituted tribunals in accordance with what is decided”, and that “no one may
knowingly act in a way which has the object of nullifying or setting at nought the decision of such a
tribunal”.

122. In an immigration bail context, Mr Buttler also refers to AR v SSHD [2016] UKUT 00132, where the
Upper Tribunal considered whether the Defendant had the power to discontinue a bail condition of
electronic monitoring imposed by the First-tier Tribunal (under the regime for bail which pre-dated the 2016
Act). Lord McCloskey P said at [29] that to allow the Defendant:

“… to interfere with an order of the FtT … would be inimical to the rule of law. The executive, absent
unambiguous legislative authority, cannot tamper with the order of a court or tribunal.”

An appeal was allowed on a different ground, i.e. that the FtT's order had ceased to have effect at the
relevant time, but with no adverse comment on the ruling quoted above.

123. Mr Buttler then refers to R (Majera) v SSHD [2021] 3 WLR 1075, another case which pre-dates the
2016 Act. There, a person detained under immigration powers applied to the FtT for bail. The Defendant
sought a condition prohibiting him from undertaking unpaid employment. The FtT declined to impose that
condition, and instead only prohibited him from paid employment. Nevertheless, the Defendant then gave
him a notice purporting to impose the further condition. He sought judicial review. The Defendant argued
that the FtT's order was legally defective because it had not complied with all of the statutory requirements
for such an order at that time. The Supreme Court ruled that a court or tribunal's order, whether valid or
invalid, had to be obeyed unless and until it was set aside by a court or tribunal or overruled by legislation.
The Defendant had therefore been obliged to comply with the order and had failed to do so.

124. So in the present case, Mr Buttler submits, where there was not even any defect in the High Court's
order, the Defendant plainly could not impose a bail condition which encroached on the liberty granted by
the Deputy Judge.

The Defendant's case


-----

125. Mr Tam responds that the case of Brandenburg, quoted at paragraph 121 above, imposes a high test
for a challenge such as this one, and that what is prohibited is not any inconsistency with the order of a
court or tribunal, but only such inconsistency as would “nullify or set at nought” the order.

126. His case is essentially that the reporting condition simply sat alongside the Deputy Judge's order and
did not interfere with it, let alone nullify it. That was permissible because, at all material times, the High
Court and the Defendant had parallel powers. There was at all times a continuing power to detain and,
although that power could not be exercised once the High Court had granted bail, the power to grant
conditional immigration bail under the 2016 Act was expressly preserved in those circumstances by
paragraph 1(5) of schedule 10.

127. Mr Tam seeks to distinguish _Majera because there, the issue decided by the FtT was what bail_
conditions to impose and the FtT had refused to impose precisely the bail condition which the Defendant
then purported to impose. Thus the Defendant's action was expressly inconsistent with what the FtT had
decided. In this case, however, Mr Tam submits, the issue in the judicial review claim at that time was the
lawfulness of detention and the grant of bail was purely ancillary to that challenge. In those circumstances
the Defendant's addition of a reporting condition was not inconsistent in the Majera sense, and it was also
a reasonable condition to impose.

128. In the alternative, Mr Tam seeks to distinguish both AR and Majera because the competing power to
grant bail in those cases, under the statutory precursor to the 2016 Act, was a power concurrently held by
the Defendant and by the FtT. In those circumstances, Mr Tam concedes, the power could not be
exercised inconsistently by its co-owners. But the present case, he submits, is different because it
concerns the exercise of separate, co-existing powers by the High Court and by the Defendant.

Discussion

129. I asked Mr Tam whether the Defendant could have imposed the reporting condition if it had been
sought from, and refused by, the Deputy Judge. His slightly Delphic answer was that that would make his
case more difficult.

130. I also asked Mr Tam whether the Defendant would have been empowered to vary any of the
conditions which were imposed by the Deputy Judge, and he conceded that she would not. He also
accepted that it was at all material times open to the Defendant to apply to the High Court to vary the bail
conditions.

131. In my judgment, such an application was the only remedy open to the Defendant if she wished to
impose an additional condition such as the reporting condition which restricted the Claimant's liberty.

132. The authorities make it quite clear that the rule of law requires the executive to abide by the orders of
courts or tribunals, save where permitted to do otherwise by further such orders or legislative intervention. I
do not read the case of Brandenburg as narrowing that principle in any way. The question in every case is
whether the executive's action is inside or outside the scope of what the court or tribunal's order permits.

133. This also reflects the need for certainty, so that parties know what the effect of a court order will be,
even where powers are shared. I note in passing that the 2016 Act recognises the same need. Thus
paragraph 1(6) of schedule 10 makes it express that the Defendant may re-detain an individual after a
grant of immigration bail by the FtT, whilst paragraph 6, on the other hand, stipulates that bail conditions
may only be changed by the body that granted bail (or only by the Defendant if the FtT directs that she may
change the conditions which it imposed).

134. I agree with Mr Buttler that the principles in Stellato apply to a grant of conditional immigration bail.
The correct analysis is therefore that the order is a grant of liberty, qualified only to the extent of any
conditions imposed.

135. It follows that the reporting condition was clearly inconsistent with the order of 18 March 2021. It
reduced the scope of the liberty granted by that order, by requiring the Claimant to be in a specified place
on a specified day in every week. It was a restriction of a kind which the Deputy Judge could have imposed


-----

but did not impose. The Defendant's omission to request such a condition from the Deputy Judge did not
empower her to supplement his order by imposing it herself.

136. The second ground therefore succeeds.

Conclusion

137. The first ground is dismissed. There will be judgment for the Claimant and a declaration on the
second ground.

**End of Document**


-----

# R (on the application of BVN) v Secretary of State for the Home Department

## [2022] EWHC 1159 (Admin), [2023] QB 425, [2022] 3 WLR 610

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 16/05/2022

# Catchwords & Digest

## IMMIGRATION – HUMAN TRAFFICKING – WHETHER INDIVIDUAL COULD WITHDRAW FROM NATIONAL REFERRAL MECHANISM WITHOUT INFORMED CONSENT

 The Administrative Court in part allowed the Vietnamese national’s claim for judicial review of: (i) guidance issued by the defendant Secretary of State, under s 49 of the Modern Slavery Act 2015, which had permitted the claimant to withdraw from the National Referral Mechanism (NRM) without imposing a requirement of informed consent; and (ii) the defendant’s decision to impose a reporting condition on the claimant’s release after the High Court had granted unconditional bail. As to the former, the court held that: (i) the European Convention Against Trafficking had not placed a obligation on the defendant to implement guidance which provided for an individual to be given information or advice before withdrawing from the NRM; (ii) the requirement of informed consent on entry to the NRM should not have been mirrored on exit from the NRM, which does not authorise intervention or commit the individual to anything; and (iii) At most art 4 of the European Convention on Human Rights might have obliged officials to consider whether further steps or enquiries were appropriate. Second, by applying the principles in Stellato v Ministry of Justice [2011] 3 All ER 251, the court held that the reporting condition had been inconsistent with the High Court’s order in that it had reduced the scope of the claimant’s liberty in a way that the High Court had chosen not to.

# Cases considered by this case


EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v
Secretary of State for the Home Department

_[[2022] EWCA Civ 307, [2023] QB 351, [2022] 3 WLR 353, [2022] INLR 213, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
_[ER (D) 70 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
Considered

R (on the application of Majera (formerly SM (Rwanda)) v Secretary of State for the
Home Department

_[[2021] UKSC 46, [2022] AC 461, [2022] 2 All ER 305, [2021] 3 WLR 1075, [2022] INLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6573-WYW3-CGX8-02X8-00000-00&context=1519360)_


17/03/2022

CACivD

20/10/2021

SC


-----

[67, [2021] All ER (D) 65 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63WM-GKN3-CGX8-003R-00000-00&context=1519360)
Considered
R (on the application of A) v Secretary of State for the Home Department

_[[2021] UKSC 37, [2022] 1 All ER 177, [2021] 1 WLR 3931, [2021] All ER (D) 115 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_
Considered

R (on the application of BF (Eritrea)) v Secretary of State for the Home Department

_[[2021] UKSC 38, [2022] 1 All ER 213, [2021] 1 WLR 3967, [2021] INLR 586, [2021] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833G-00000-00&context=1519360)_
_[ER (D) 116 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6385-6RC3-GXFD-80FV-00000-00&context=1519360)_
Considered

Secretary of State for Work and Pensions v Johnson and others

_[[2020] EWCA Civ 778, [2020] PTSR 1872, [2020] All ER (D) 117 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:606D-8KG3-CGXG-0369-00000-00&context=1519360)_
Considered

MS (Pakistan) v Secretary of State for the Home Department

_[[2020] UKSC 9, [2020] 3 All ER 733, [2020] INLR 460, [2020] All ER (D) 111 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60J0-VFB3-GXFD-805F-00000-00&context=1519360)_
Considered

R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State
for the Home Department (Equality and Human Rights Commission intervening)

_[[2018] EWCA Civ 1395, [2018] 1 WLR 4922, [2018] All ER (D) 38 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
Applied

R (on the application of EM) v Secretary of State for the Home Department

_[[2018] EWCA Civ 1070, [2018] 1 WLR 4386, [2018] All ER (D) 113 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCR-C3C1-DYBP-N2GW-00000-00&context=1519360)_
Considered

Stellato v Ministry of Justice

_[[2010] EWCA Civ 1435, [2011] QB 856, [2011] 3 All ER 251, [2011] 2 WLR 936, (2011)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:536Y-G2J1-DYBP-M204-00000-00&context=1519360)_
[Times, 28 February, [2010] All ER (D) 171 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:51PS-1J31-DYBP-N49F-00000-00&context=1519360)
Applied

Officer L, Re

_[[2007] UKHL 36, [2007] NI 277, [2007] 4 All ER 965, [2007] 1 WLR 2135, (2007)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RBD-VMM0-TWYV-M0XT-00000-00&context=1519360)_
[Times, 1 August, [2007] All ER (D) 484 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTT1-DYBP-N3M1-00000-00&context=1519360)
Considered

R (on the application of Von Brandenburg (aka Hanley)) v East London and the City
Mental Health NHS Trust

_[[2003] UKHL 58, [2004] 2 AC 280, [2004] 1 All ER 400, [2003] 3 WLR 1265, 76 BMLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-601W-00000-00&context=1519360)_
_[168, (2003) Times, 14 November, [2003] All ER (D) 174 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FNG-MXN0-TWW8-X0NH-00000-00&context=1519360)_
Considered

R v Secretary of State for the Home Department, ex p Turkoglu

[[1988] QB 398, [1987] 2 All ER 823, [1987] 3 WLR 992, (1987) Times, 23 May](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-6050-00000-00&context=1519360)
Considered

Gillick v West Norfolk and Wisbech Area Health Authority

[[1986] AC 112, [1985] 3 All ER 402, [1985] 3 WLR 830, [1986] LRC (Const) 715,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-607K-00000-00&context=1519360)

_[[1986] 1 FLR 224, 2 BMLR 11](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G1GJ-00000-00&context=1519360)_
Considered

**End of Document**


30/07/2021

SC

30/07/2021

SC

22/06/2020

CACivD

18/03/2020

SC

19/06/2018

CACivD

15/05/2018

CACivD

14/12/2010

CACivD

31/07/2007

HL

13/11/2003

HL

19/05/1987

CACivD

17/10/1985

HL


-----

