# R v AGM [2022] EWCA Crim 920

Court of Appeal, Criminal Division

Males LJ, McGowan J and Judge Michael Chambers QC (Recorder of Wolverhampton)

5 July 2022Judgment

**Benjamin Newton (instructed by Birds Solicitors) for the Appellant**

**Andrew Johnson (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date: 29 June 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**This judgment will be handed down by the Judge remotely by circulation to the parties'**
**representatives by email and release to The National Archives. The date and time for hand-down is deemed**
**to be 10.30 a.m. on Tuesday 5 July 2022.**

WARNING: The appellant in this case is entitled to anonymity. This judgment is not subject to any reporting
restriction, but nothing may be published which will disclose the appellant's true identity. A person who breaches
this order is liable to a fine and/or imprisonment.

**Lord Justice Males:**

1. On 8th October 2014, in the Crown Court at Bournemouth before His Honour Judge Johnson, the
applicant, a Vietnamese national then aged 40, pleaded guilty to being concerned in the production of
cannabis. On 15th December 2014 she was sentenced to 18 months' imprisonment. Her application for an
extension of time (2,514 days) in which to seek leave to appeal against conviction and leave to call fresh
evidence has been referred to the full court by the Registrar.

2. The ground of appeal is that the applicant's conviction on her own plea is unsafe because, if it had been
known that she was a victim of trafficking, either she would not have been prosecuted or the proceedings
(which took place before the passing of the **_[Modern Slavery Act 2015) would have been stayed as an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
abuse of process.

3. There is now a conclusive grounds decision dated 3rd September 2018, in which the Home Office, as
the competent authority under the 2005 Council of Europe Convention on Action against Trafficking,
determined that the applicant is a victim of modern slavery. It appears that she did not claim to be a victim
of trafficking during the criminal proceedings and that this question was not referred to the Home Office for
consideration. When it was first referred, after the applicant made an asylum claim on 1st April 2015, the
Home Office did not accept her claim. A negative reasonable grounds decision was made on 8th May 2015
and it was only after proceedings in the First tier and Upper Tribunal Immigration and Asylum Chamber
that the applicant's claim to be a victim of trafficking was finally accepted.

4. In the light of the Home Office's acceptance that the applicant is a victim of trafficking, and having
regard to the principles summarised in R v L; R v N _[[2017] EWCA Crim 2129 at [7] to [13], it is appropriate](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_


-----

to grant the applicant anonymity, as ordered provisionally by the Registrar. We direct that she be referred
to as “AGM”.

**The abuse of process jurisdiction**

5. Section 45 of the Modern Slavery Act 2015 came into force with effect from 31st July 2015. It provides
a substantive defence for victims of slavery or trafficking who commit certain offences under compulsion
attributable to slavery or relevant exploitation. Before the coming into force of this section, the United
Kingdom sought to comply with its obligations under the Convention in cases where the common law
defence of duress was not available by a combination of (1) Crown Prosecution Service guidance as to the
circumstances in which victims of trafficking should be prosecuted and (2) the court's power to stay a
prosecution as an abuse of process. R v Joseph _[2017] EWCA Crim 36, [2017] 1 WLR 3153confirmed that_
this remains the applicable regime for cases heard at first instance before the coming into force of section
45. More recently _R v AAD_ _[[2022] EWCA Crim 106 at [110] to [143] has held that the abuse of process](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
jurisdiction remains available in principle in all victim of trafficking cases following the 2015 Act, while
emphasising the exceptional nature of such applications in cases to which the Act applies (i.e. where in
principle the section 45 defence is available).

6. _AAD emphasised also at [144] to [154] that, under section 45, it is not enough that a defendant is a_
victim of trafficking. It must also be shown (or more accurately, an issue must be raised, which it is then for
the prosecution to disprove: _R v MK_ _[2018] EWCA Crim 667, [2019] QB 86) that an adult defendant is_
compelled to do the act which constitutes the offence and that this compulsion is attributable to (i.e. is
directly caused by) slavery or relevant exploitation. This was in part the result of interpreting the statutory
language, which refers expressly to compulsion, but was also held to coincide with the United Kingdom's
international obligations under (among other things) the 2005 Convention. Consistently with this view, CPS
guidance and the pre-Act cases referred to the need for “compulsion arising from the trafficking” and for “a
nexus of compulsion” (e.g. R v M(L) _[[2011] EWCA Crim 2327, [2011] 1 Cr App R 12 at [10] and [14]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:542M-MGR1-F0JY-C214-00000-00&context=1519360)_

7. The courts' approach to appeals against conviction in trafficking cases on the ground that the
proceedings were an abuse of process was developed in a series of cases before the coming into force of
the 2015 Act. In R v LM _[2010] EWCA Crim 2327, [2011] 1 Cr App R 12 and again in R v N_ _[2012] EWCA_
_Crim 189, [2013] QB 379 at [12] this court rejected any proposition that once it is demonstrated that an_
individual has been or may have been trafficked, he or she should not be prosecuted for crimes committed
within that context. There is no “blanket immunity” for victims of trafficking. Rather, there was an obligation
on the prosecuting authority to apply its mind conscientiously to “the question whether public policy calls for
a prosecution and punishment when the defendant is a trafficked victim and the crime has been committed
when he or she was in some manner compelled (in the broad sense) to commit it”. Lord Judge CJ
summarised the essential principles in N as follows:

“21. Summarising the essential principles, the implementation of the United Kingdom's Convention
obligation is normally achieved by the proper exercise of the long established prosecutorial discretion
which enables the Crown Prosecution Service, however strong the evidence may be, to decide that it
would be inappropriate to proceed or to continue with the prosecution of a defendant who is unable to
advance duress as a defence but who falls within the protective ambit of Article 26. This requires a
judgment to be made by the CPS in the individual case in the light of all the available evidence. That
responsibility is vested not in the court but in the prosecuting authority. The court may intervene in an
individual case if its process is abused by using the 'ultimate sanction' of a stay of the proceedings. The
burden of showing that the process is being or has been abused on the basis of the improper exercise of
the prosecutorial discretion rests on the defendant. The limitations on this jurisdiction are clearly
underlined in R v LM. The fact that it arises for consideration in the context of the proper implementation of
the United Kingdom's Convention obligation does not involve the creation of new principles. Rather, well
established principles apply in the specific context of the Article 26 obligation, no more, and no less. Apart
from the specific jurisdiction to stay proceedings where the process is abused, the court may also, if it
thinks appropriate in the exercise of its sentencing responsibilities implement the Article 26 obligation in the


-----

language of the article itself, by dealing with the defendant in a way which does not constitute punishment,
by ordering an absolute or a conditional discharge.”

8. It is apparent, therefore, that in accordance with well established principles, there may be cases where
it is not in the public interest for a prosecution to take place even where the evidence against the defendant
is strong, so that there would be good prospects of securing a conviction; and that these principles may
apply in trafficking cases.

9. The approach to be taken and the way in which trafficking may affect culpability were discussed further
by Lord Judge in R v L(C) _[2013] EWCA Crim 991, [2013] 2 Cr App R 23:_

“13. It is surely elementary that every court, whether a Crown Court or magistrates' court, understands the
abhorrence with which trafficking in human beings of any age is regarded both in the United Kingdom and
throughout the civilised world. It has not, however, and could not have, been argued that if and when
victims of trafficking participate or become involved in criminal activities, a trafficked individual should be
given some kind of immunity from prosecution, just because he or she was or has been trafficked, nor for
that reason alone, that a substantive defence to a criminal charge is available to a victim of trafficking.
What, however, is clearly established, and numerous different papers, reports and decided cases have
demonstrated, is that, when there is evidence that victims of trafficking have been involved in criminal
activities, the investigation and the decision whether there should be a prosecution, and, if so, any
subsequent proceedings, require to be approached with the greatest sensitivity. The reasoning is not
always spelled out, and perhaps we should do so now. The criminality, or putting it another way, the
culpability, of any victim of trafficking may be significantly diminished, and in some cases effectively
extinguished, not merely because of age (always a relevant factor in the case of a child defendant) but
because no realistic alternative was available to the exploited victim but to comply with the dominant force
of another individual, or group of individuals.”

10. More recently, the applicable principles were summarised by Lord Justice Gross in _R v GS_ _[2018]_
_EWCA Crim 1824, [2018] 4 WLR 167 at [76]. They include the need for “the careful and fact sensitive_
exercise by prosecutors of their discretion as to whether it is in the public interest to prosecute a VOT” and
the relevance of “a reasonable nexus” between the crime and the trafficking:

“There is no closed list of factors bearing on the prosecutor's discretion to proceed against a VOT.
Generalisation is best avoided. That said, factors obviously impacting on the discretion to prosecute go to
the nexus between the crime committed by the defendant and the trafficking. If there is no reasonable
nexus between the offence and the trafficking then, generally, there is no reason why (on trafficking
grounds) the prosecution should not proceed. If there is a nexus, in some cases the levels of compulsion
will be such that it will not be in the public interest for the prosecution to proceed. In other cases, it will be
necessary to consider whether the compulsion was continuing and what, if any, reasonable alternatives
were available to the VOT.”

11. Lord Justice Gross described the question for this court in the following terms at [76(v)]:

“As always, the question for this court goes to the safety of the conviction. However, in the present context,
that inquiry translates into a question of whether in the light of the law as it now is (this being a rare change
in law case) and the facts now known as to the applicant (having regard to the admission of fresh
evidence) the trial court should have stayed the proceedings as an abuse of process had an application
been made. This question can be formulated indistinguishably in one of two ways which emerge from the
authorities: was this a case where either: (1) the dominant force of compulsion, in the context of a very
serious offence, was sufficient to reduce the applicant's criminality or culpability to or below a point where it
was not in the public interest for her to be prosecuted? or (2) the applicant would or might well not have
been prosecuted in the public interest? If yes, then the proper course would be to quash the conviction …”

12. It is apparent from these and other authorities that, when dealing with victims of trafficking, the
existence and extent of any nexus between the offence in question and the trafficking and exploitation to
which the defendant has been subject will always be an important consideration. However, if the
prosecution authorities have applied their minds to the relevant questions in accordance with the applicable


-----

CPS guidance, it will not generally be an abuse of process to prosecute unless the decision to do so is
clearly flawed. The courts will be reluctant to intervene in such circumstances as the decision whether to
prosecute is for the CPS and not the court.

13. Conversely, if the question whether a defendant is a victim of trafficking has not been considered by
the prosecution at all, the courts will be readier to intervene. Again, the existence and extent of any nexus
between the offence and the trafficking and exploitation in question will be an important consideration,
albeit not necessarily decisive in every case. Depending on the facts, it may be necessary to consider
broader questions such as whether it was in the public interest to prosecute this particular defendant for
this particular crime. Much may depend upon the circumstances and history of the defendant and the
seriousness of the defendant's participation in the crime in question.

14. It is therefore possible to envisage circumstances where an abuse of process argument in a pre-Act
case may succeed even though, if the Act had applied, a defence under section 45 would have failed for
insufficient evidence of compulsion directly caused by slavery or exploitation as required by the section.
That is because it may still be relevant to consider whether, even if a prosecution could have succeeded, it
is in the public interest for the prosecution to be brought. Indeed AAD expressly recognised the continuing
existence of the abuse of process jurisdiction even in a case to which section 45 of the 2015 Act applies.
The court distinguished at [119] and [120] between (1) cases “where the CPS has taken into account the
relevant prosecutorial guidance and has taken into account any conclusive grounds decision (and has a
rational basis for departing from a conclusive grounds decision if it has been favourable to the prospective
defendant)”, in which case “there is simply no basis for an abuse of process challenge at all”; and (2) cases
where “the CPS has failed unjustifiably to take into account the CPS Guidance or … has no rational basis
for departing from a favourable conclusive grounds decision”, in which case there is scope to stay a
prosecution on the ground of abuse of process.

15. That the prosecution was an abuse of process is one of the categories of case in which it is no bar to a
successful appeal that the defendant pleaded guilty, as held in _T_ _[[2022] EWCA Crim 108 at [160] and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
affirmed in AAD at [156].

**CPS Guidance**

16. The CPS Guidance on human trafficking, smuggling and slavery as at 9th September 2011 (which was
current at the time of the proceedings below) drew attention to the frequency of trafficking in (among other
cases) cultivation of cannabis plants. It required prosecutors to be alert to the possibility that a suspect may
be a victim of trafficking and to take steps to ensure that appropriate enquiries were made when there was
a credible suspicion or realistic possibility that a suspect had been trafficked; prosecutors were required to
advise the police to consider a reference through the national referral mechanism to the Home Office as
the competent authority under the 2005 Convention. If evidence or information obtained supported the fact
that the suspect had been trafficked and committed the offence while they were coerced, prosecutors were
instructed to consider whether it was in the public interest to continue prosecution. The guidance
emphasised the duty of the prosecutor to be proactive in causing enquiries to be made, in accordance with
the judgment of this court in R v O _[[2008] EWCA Crim 2835. Factors bearing on the public interest were](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_
identified, including:

     - is there a credible suspicion that the suspect might be a trafficked victim?

     - the role the suspect has in the criminal offence?

     - was the criminal offence committed as a direct consequence of their traffic situation?

     - were violence, threats or coercion used on the trafficked victim to procure the commission of the offence?

     - was the victim in a vulnerable situation or put in considerable fear?

**The basic facts**


-----

17. On 30th May 2014 police officers searched a house at an address in Poole and discovered a cannabis
factory. A neighbouring property was also searched and over 800 cannabis plants were recovered from the
two properties. The applicant and her co-accused, a Vietnamese man called Tran, were arrested nearby.

**The proceedings**

18. In interview, the applicant initially relied on a prepared statement in which she stated that she had
been in the property for less than a week. She had been given a cleaning job that involved living and
sleeping in the property. When she took the job, she was unaware that she would be working in a cannabis
factory. She had watered the plants on two occasions, but they did not belong to her and she received no
money.

19. During the interview the applicant interrupted the reading of the prepared statement and, after a break
to receive legal advice, she decided to answer police questions. She said that she arrived in the United
Kingdom by lorry in 2009. She still owed money to the people responsible for bringing her into the country.
She was taken to the house by “the boss of the boat” approximately six days before her arrest, but had not
known that it was a cannabis factory. Two men were present. She did not want to stay, because the house
was very dirty, but was told to be patient. They offered her £200 per week to clean, which would be used to
pay off her debt. She had not received any money and had not been threatened by the two men. She
cleaned the house and watered the plants on two occasions. She did not know they were cannabis. Tran
had arrived approximately four days before their arrest. She did not talk to him about the plants. It was his
job to water them.

20. Initially the applicant pleaded not guilty. However, she then indicated that she would plead guilty on the
basis that (1) she entered the United Kingdom in 2009 as an illegal immigrant, (2) she owed her smugglers
£20,000, (3) she had worked for them to reduce her debt, (4) she was in a sexual relationship with Tran,
who asked her to come to the property that she learned on arrival was a cannabis factory, and (5) she
helped water the plants and clean up discarded soil. The plants had already been harvested when she
arrived.

21. This basis of plea was not accepted by the prosecution. The issue was not whether the applicant was
a victim of trafficking (it was not suggested on her behalf that she was), but whether she was motivated by
financial gain, specifically whether she was paid to work knowing the property to be a cannabis factory.
The significance of that issue was whether, as the prosecution contended, she had for sentencing
purposes a significant role, or whether, as was contended on her behalf given her basis of plea, she had
only a lesser role.

22. Accordingly a Newton hearing was held. The applicant gave evidence through an interpreter and was
cross examined. She said that she was from a small village in Vietnam. She came to the United Kingdom
in a lorry and incurred £20,000 in debt, of which £6,000 remained outstanding. She had worked as a
childminder and cleaner and her income was used to pay her debt. She met Tran two years before her
arrest and had started a sexual relationship with him approximately three months before her arrest. One of
her friends, whom she described as “the boss of the boat”, took her to the house five days before her arrest
and Tran arrived two days later. She believed that she would be a cleaner and did not know about the
cannabis. She only learned that the plants were cannabis when Tran told her. She wanted to leave, but
was told that she must stay a week, at which point she would be taken somewhere else. In crossexamination, she accepted that she was not controlled by Tran and that she watered the plants, but that
was only as a favour rather than as part of her job.

23. On the basis of her evidence, the applicant's counsel disclaimed any suggestion of trafficking. He said
that she was an economic migrant who “was not trafficked in any way because she obviously consented to
come and consents to stay”. He submitted that she should be sentenced on the basis of having had a
lesser role.

24. The judge did not accept the applicant's account. He concluded that the applicant was “slightly more
culpable than Tran” (who had also pleaded guilty), but he did accept that she played a lesser role in a
substantial commercial enterprise. She was subject to “some degree of pressure”, but had been trusted by


-----

the owners of the plants (the house key had been found in her bag). He sentenced her to two years'
imprisonment.

25. The solicitors and counsel representing the applicant in the criminal proceedings have been unable to
shed any light at all on why it was conceded that no question of trafficking arose.

**The applicant's account of being trafficked**

26. Following her release from prison in February 2015, the applicant was transferred to immigration
detention. In March 2015 she claimed that she was a victim of human trafficking and in April 2015 claimed
asylum.

27. In support of her claim she made a statement in which she gave the following account.

28. The applicant was born in Vietnam and entered into an arranged marriage when she was 18. She was
very poor and a victim of domestic violence from her husband. She had three children with him.
Neighbours put her in contact with people who said that they could help her to find a job in the United
Kingdom, where she would work in a restaurant and earn good money to support her family. She was told
that this would cost her £20,000. Her mother-in-law handed over the deeds to their house as security for
the loan. She understood that these creditors had since taken over the house, but that £6,000 remained
outstanding and her family were constantly being harassed to pay it.

29. She left Vietnam in 2006, thinking that she would come directly to the United Kingdom. In fact her
passport was taken from her and she travelled through several countries before arriving in Germany. She
claimed asylum on the instruction of her traffickers, and was told by them what to say. She was too scared
to disregard their instructions. Her claim for asylum was refused, but she remained in Germany for what felt
like a long time. She was threatened that she would be killed if she disobeyed the traffickers, so she never
attempted to escape them. She was taken to various places, always accompanied and under their control,
and was made to work as a prostitute in a brothel.

30. She was then taken to France and kept in a remote place, where she was forced to have sex with
different men, sometimes with a group of men at once. When she tried to resist, she was beaten or
punched. On one occasion her face was burned by what she believed to be acid thrown in her face, which
left a scar. Her nipples were burnt by cigarette butts by men with whom she was forced to have sex.

31. She had not mentioned any of this sexual abuse before, because she was so ashamed of what she
had been forced to do.

32. Eventually she was put in a lorry to come to the United Kingdom. She was put in a bin bag where she
nearly suffocated. When the lorry stopped, two men travelling with her ran off. She jumped off the lorry, but
was stopped by the police. She was interviewed at a police station, but was too scared to say anything.
She gave a false name and false date of birth, as she had been instructed to do. She was released the
next day and left on the streets, but felt that she had no choice but to stay with the two men who had been
arrested and released with her. The men took her to a house where she was forced to have sex with them
and with another Vietnamese man. She stayed at this house for approximately a year. When the men went
out, she was locked in.

33. After about a year she was permitted to contact her family with a mobile phone, but only under
supervision. She was so ashamed that she did not want to tell her family what she had been through. The
only time she was allowed to leave the house was when she was taken to different houses to clean and
look after children for Vietnamese families.

34. At the end of 2012, the applicant was taken to a brothel and was kept there for approximately three
months. She was forced to have sex several times a day. Again she was told that if she tried to escape,
she would be killed. However, she did try to escape, trying doors and windows whenever she got the
chance. One day, at the time of Chinese New Year, the back door to the basement where the applicant
was being kept was left unlocked and, when she discovered this, she decided to take the risk of escaping
as she could no longer cope with living in the way she was forced to. She found a police officer, who took
h t Vi t f il h h f th i ht


-----

35. Having been taken in by this Vietnamese family, the applicant met Tran, who came from the same part
of Vietnam. Initially they spoke on the telephone, but eventually she met Tran in Birmingham. After a while
they started a consensual sexual relationship. Tran would ask her if she was working and, when she said
that she was not, offered her a job cleaning at his house and looking after some plants. She was told that
she would be paid £200 at the end of the week, and did not ask questions. Tran's friend picked her up and
took her to the house. She arrived on a Sunday evening and was arrested on the following Friday, Tran
having arrived in the meanwhile.

36. When she was arrested, the applicant had a key to the house in her bag, together with £250. She said
that Tran had told her to put the house key in her bag and that he had given her £100 of the money which
she had, the rest being money she had saved. She said that Tran had told her to plead guilty in order to
get a shorter sentence.

**The psychological report**

37. In May 2015, while the applicant was in immigration detention, a Rule 35 Report by Dr Rebecca Ward
concluded that the applicant might be a victim of trafficking and that she demonstrated expressive
language difficulties, comprehension difficulties, PTSD and associated memory problems. She was seen
by Dr Laura Kemmis, a clinical psychologist, who diagnosed her as suffering from PTSD and Major
Depressive Disorder, which would have significantly impacted upon her ability to understand and give a
comprehensive account in her asylum interview.

**The conclusive grounds decision**

38. When the applicant made her asylum claim the Home Office did not accept that she was a victim of
trafficking. On 8th May 2015 a negative reasonable grounds decision was issued and her asylum claim
was refused. The applicant appealed to the First tier Tribunal and a hearing was held on 30th January
2017. As a result of psychological evidence it was decided that the applicant would not give oral evidence.
Instead she relied on a written statement to the effect summarised above.

39. The First tier Tribunal allowed the appeal, finding the applicant to be a refugee and also allowing her
appeal under Article 3 ECHR. Her appeal against deportation was also allowed. The Tribunal Judge
observed that there was a very solid body of medical evidence and no evidence to suggest that her
cognitive problems resulted from anything other than severe PTSD. The First tier decision was
unsuccessfully appealed to the Upper Tribunal, but the Upper Tribunal's decision of 8th March 2018 was
set aside by the Court of Appeal on 2nd January 2019 and remitted to the Upper Tribunal. On 5th August
2020 the Official Solicitor was appointed as the applicant's litigation friend. Eventually, on 3rd September
2020, the decision of the First tier Tribunal was confirmed.

40. Meanwhile the Home Office determined that the applicant was a victim of trafficking. She received a
positive reasonable grounds decision on 3rd March 2018 and a conclusive grounds decision on 3rd
September 2018. On 9th October 2019 she was granted five years' limited leave to remain.

**The application for an extension of time**

41. With some hesitation, we are prepared to grant the necessary extension of time, despite the length of
time involved. It is understandable that this application could not be made until after the positive conclusive
grounds decision made in September 2018, at which time the immigration and asylum proceedings were
still continuing. The applicant's current solicitors were not instructed until May 2020, after which there was
much work to be done and matters proceeded with reasonable dispatch, but it is not altogether apparent
why this application could not have been made earlier. Nevertheless, having regard to the issues involved,
we are persuaded that it is in the interests of justice to grant the necessary extension of time.

**The application to adduce new evidence**

42. The applicant seeks to adduce new evidence on appeal, namely:

(1) the applicant's statements dated 27th January and 2nd August 2016;


-----

(2) documents leading up to and including the 2018 positive conclusive grounds decision;

(3) the judgments of the First tier and Upper Tribunal; and

(4) the applicant's medical records and psychological report.

43. The criteria for the admission of new evidence on appeal are set out in section 23 of the Criminal
Appeal Act 1968. The test is whether it is necessary or expedient in the interests of justice to receive such
evidence. In considering that evidence it is necessary to have regard to whether the evidence appears to
be capable of belief, whether it appears that it may afford any ground for allowing the appeal, whether it
would have been admissible in the proceedings below, and whether there is a reasonable explanation for
the failure to adduce the evidence below. In the context of trafficking cases, it is established that a
conclusive grounds decision is admissible on appeal (always assuming that it is necessary or expedient to
receive such evidence) notwithstanding that such a decision would not be admissible at trial (see _R v_
_Brecani_ _[2021] EWCA Crim 731, [2021] 1 WLR 5851, and AAD at [79] to [82] and cases there cited)._

44. AAD goes on at [83] to explain, citing R v AAJ _[[2021] EWCA Crim 1278 at [39], that:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_

“The decision of the competent authority as to whether or not a person has been trafficked for the purpose
of exploitation is not binding on the court, but, unless there is evidence to contradict it or significant
evidence that has not been considered, it is likely that courts will respect the decision.”

45. However, this is only a general approach, and in some cases the account given by an appellant may
require testing by way of appropriate questioning (AAD at [84]).

46. In the present case we are satisfied that it is necessary to admit the new evidence. Understandably,
the prosecution has not sought to cross examine the applicant on the account given in her latest
statements as summarised above. The prosecution does not necessarily accept all of what is said, but
broadly speaking the statements appear to be capable of belief. They tell a story which, although horrifying,
is sadly all too familiar.

**Submissions**

47. Mr Benjamin Newton for the applicant submitted that there was a failure by the police and CPS to
consider whether the applicant was a victim of trafficking and that, if the prosecution had been aware of the
applicant's full history, it is inevitable that she would not have been prosecuted; or, if she had been, the
judge would have been obliged to stay the proceedings as an abuse of process. He submitted, adopting
the formulation in GS at [78], that this was a case where either (1) the dominant force of compulsion was
sufficient to reduce the applicant's culpability to a point where it was not in the public interest for her to be
prosecuted, or (2) she would or might well not have been prosecuted in the public interest. Accordingly her
conviction is unsafe.

48. Mr Newton relied in particular on the applicant's account in interview and in the Newton hearing to the
effect that she had been taken to the cannabis factory by “the boss of the boat” and that she had been told
that the £200 per week which she would be paid would be used to pay off her debt. He submitted that this
demonstrated that the applicant was still acting under compulsion and was still in debt bondage and under
the control of her traffickers. But, recognising that this was not the account given in the applicant's 2016
statements made for the purpose of her asylum claim, he submitted also that it would not have been in the
public interest to prosecute the applicant as there was in any event a sufficient nexus between the conduct
which constituted the offence and the trafficking and exploitation to which she had been subjected.

49. Mr Andrew Johnson for the prosecution submitted that the conviction is safe. The prosecution did not
seek to challenge the finding that the applicant was trafficked, but submitted (also echoing GS at [78]) that
her account does not reveal “a nexus of compulsion such that culpability for the offending was effectively
extinguished or substantially diminished to the point that she should not have been prosecuted”. On her
account, there was no nexus between her trafficking and her offending. Mr Johnson pointed out that this
case is unusual because the applicant's account had been tested and rejected in the _Newton hearing._
There was no reason to doubt the findings of the judge in the Crown Court which, on the issue of
l i t ff t d b f th l t id


-----

**Victim of trafficking**

50. We accept, having considered the applicant's evidence for ourselves and following the approach
described in AAJ at [39] and approved in AAD at [83] of respecting the decision of the competent authority
unless there is reason not to do so, that the applicant is more likely than not to be a victim of trafficking.
That, however, is only the first step.

**Acting under compulsion**

51. It remains to consider whether or to what extent the applicant was acting under compulsion when she
carried out the conduct which constituted the offence of being concerned in the production of cannabis
and, if so, whether there was a sufficient nexus between that conduct and the slavery or exploitation to
which she had been subjected.

52. We consider first the applicant's account given in the course of the criminal proceedings. It is true that
she referred to being in debt and to being offered the opportunity to earn money to pay off her debt, but
she also said that she had not been threatened. She referred to “the boss of the boat”, but she also
described him as a friend. She accepted that she was not controlled by Tran, and that a key to the house
had been found in her bag. This evidence contained some indications (principally continuing debt bondage
to her original traffickers) that the applicant was a victim of trafficking acting under compulsion, but falls
somewhat short of showing that she was acting under compulsion as a direct consequence of having been
a victim of slavery or relevant exploitation. It is of some note, moreover, that the applicant's account was
not accepted by the judge. That has been a troubling feature of this case, but we also bear in mind that the
judge did not have anything like the full account of the applicant's circumstances which we now have and
that issues of trafficking and abuse of process were not raised before him, the question being how the
applicant's role should be characterised for the purpose of the sentencing guidelines.

53. Turning to the applicant's later evidence in her 2016 statements, there is no evidence there that she
was acting under compulsion. On the basis of that account, this appears to have been a period in her life
when she was not under the control of the traffickers who had brought her to this country and forced her to
work in a brothel. Rather, she had managed to escape and was in a consensual relationship with her
boyfriend, Tran. She went willingly with him to the house in Poole, which turned out to be a cannabis
factory. She was not physically abused, threatened or compelled to stay there. She cleaned the house and
looked after the plants essentially as a favour to her boyfriend and in order to earn some money. Mr
Newton submitted that it was not surprising that there is no mention in the statements of acting under
compulsion or of “the boss of the boat”, as these statements were prepared for a different purpose, namely
the applicant's asylum claim. We cannot accept this. Such matters would have been highly relevant.

[54. Considering the evidence now before us as a whole, we conclude that if the Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
had applied, the applicant would have been unable to make good (or strictly, the prosecution would have
been able to disprove) any defence under section 45. On the facts of this case, that defence would not
have been available unless the applicant was acting under compulsion which was (in the terms of
subsection (3)(b)) “a direct consequence” of having been a victim of slavery or relevant exploitation. That
was not the position here. It appears that the applicant was tricked and exploited by her boyfriend Tran, but
there was not a direct causal nexus between the fact that she had previously been a victim of slavery and
exploitation and the commission of the offence. The fact that the Act would not have afforded the applicant
a defence is not necessarily critical, because the Act did not apply, but it is in our judgment a relevant
consideration when applying the criteria for an abuse of process argument.

**Abuse of process**

55. Accordingly the question whether it would have been in the public interest to prosecute the applicant if
what is now known had been known at the time must be approached on the basis that, if the applicant
were to be prosecuted, she would in all probability be convicted as her offending was not directly
attributable to her previous abuse, albeit that (as the judge found) she was subject to “some degree of
pressure” when looking after the cannabis plants.


-----

56. In the present case it appears that the question whether the applicant was a victim of trafficking and, if
so, how that affected the further question whether it was in the public interest to prosecute her for this
offence, was not considered. If it was considered at all, there was no referral to the Home Office under the
national referral mechanism and any consideration was without the benefit of what is now known about the
applicant's history, the abuse to which she had been subjected and the effect which it had on her.
Accordingly it is open to this court to consider the public interest question without trespassing on ground
which has been appropriately considered by the prosecution authorities.

57. Even though the applicant's position as a victim of trafficking, including the sexual slavery and physical
violence to which she had been subjected over a period of years, would not have afforded her a
substantive defence, it was a highly relevant consideration. This was a woman who had been subjected to
horrific abuse over a period of years, who was severely traumatised by her experiences, and who was
suffering from PTSD and Major Depressive Disorder. Inevitably she was extremely vulnerable to further
exploitation and that vulnerability had been exploited. She spoke no English and was therefore isolated,
with limited if any realistic options for seeking help. Her family was still vulnerable to the threats of their
creditors in Vietnam and her debts had not gone away. In these circumstances if the question of
compulsion is considered “in the broad sense” (see N at [12], referred to at [7] above), the conclusion that
there was “a reasonable nexus” (GS at [76], referred to at [9] above) between the crime and the trafficking
is almost inevitable. This goes a considerable way to diminish, if not to extinguish, the applicant's
culpability.

58. The offence, being concerned in the production of cannabis, was a serious matter and this was
production on a large scale, but the applicant had played only a limited role, and for a short time. She had
no previous convictions and there was no evidence of any previous unlawful activity.

59. Whether it would have been in the public interest to prosecute this defendant for this particular offence
if the full circumstances had been known is inevitably a fact sensitive question. It needs to be approached,
as Lord Judge said in L(C), “with the greatest sensitivity”. On the facts here, we conclude that it would or
might well have been concluded that prosecution was not in the public interest.

**Conclusion**

60. Accordingly, applying the principles which we have described, the applicant's conviction is unsafe. We
grant leave to appeal and allow the appeal. The conviction is quashed.

**End of Document**


-----

# R v AGM

## [2022] EWCA Crim 920, [2022] All ER (D) 23 (Jul)

 Court: Court of Appeal, Criminal Division Judgment Date: 05/07/2022

# Catchwords & Digest

## CONVICTION – PRODUCTION OF CANNABIS – APPEAL AGAINST CONVICTION

 The Court of Appeal, Criminal Division, allowed the defendant’s appeal and her conviction was quashed. The defendant pleaded guilty to being concerned in the production of cannabis. She was sentenced to 18 months’ imprisonment. The ground of appeal was that the applicant’s conviction on her own plea was unsafe because, if it had been known that she was a victim of trafficking, either she would not have been prosecuted or the proceedings, which took place before the passing of the Modern Slavery Act 2015, process. The court held, among other things, that the defendant was more likely than not to be a victim of trafficking. However, there was not a direct causal nexus between the fact that she had previously been a victim of slavery and exploitation and the commission of the offence. Therefore, the defence under s 45 of the Act was not available. Turning to the abuse of process argument, the court concluded that whether it would have been in the public interest to prosecute the defendant for that particular offence if the full circumstances had been known was inevitably a fact sensitive question. On the facts, the court decided that it would or might well have been concluded that prosecution was not in the public interest. Therefore, the defendant’s conviction was unsafe.

# Cases referring to this case

R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

# Cases considered by this case


20/01/2023

CACrimD


R v Tredget 08/02/2022

CACrimD


-----

_[[2022] EWCA Crim 108, [2022] 4 WLR 62](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
Considered
R v AAD and others

_[[2022] EWCA Crim 106, [2022] 1 WLR 4042](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
Followed

R v AAJ

_[[2021] EWCA Crim 1278](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_
Followed

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Considered

R v Jobey

_[[2021] EWCA Crim 127](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:621J-TCV3-GXFD-80SS-00000-00&context=1519360)_
Considered

R v GS

_[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2019] 1 Cr App Rep 84, [2018] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
_[(D) 90 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
Considered

R v MK (also known as D); R v Gega (also known as Maione)

_[[2018] EWCA Crim 667, [2019] QB 86, [2018] 3 All ER 566, [2018] 3 WLR 895, [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_
[2 Cr App Rep 210, [2018] All ER (D) 10 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5S2J-3TH1-DYBP-N4PT-00000-00&context=1519360)
Considered

R v L (2017)

_[[2017] EWCA Crim 2129](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
Considered

R v Joseph

_[[2017] EWCA Crim 36, [2017] 1 WLR 3153, [2017] 1 Cr App Rep 486, [2017] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_
_[(D) 100 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_
Considered

R v L

_[[2013] EWCA Crim 991, [2014] 1 All ER 113, [2014] 3 LRC 1, [2013] 2 Cr App Rep](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_
[247, (2013) Times, 03 October, [2013] All ER (D) 216 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58RB-D6B1-DYBP-N1KF-00000-00&context=1519360)
Considered

R v N; R v E

_[2012] EWCA Crim 189, [2013] QB 379, [2012] 3 WLR 1159, [2012] 1 Cr App Rep 471,_
[(2012) Times, 10 April, [2012] All ER (D) 128 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5513-TB01-DYBP-N1F7-00000-00&context=1519360)
Considered

ATTORNEY-GENERAL'S REFERENCE NO 35 OF 2011 (R v Oakes)

_[[2011] EWCA Crim 2327](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:542M-MGR1-F0JY-C214-00000-00&context=1519360)_
Considered

R v LM

_[[2010] EWCA Crim 2327, [2011] 1 Cr App Rep 135, [2010] All ER (D) 202 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_
Considered

R v O

_[[2008] EWCA Crim 2835 (2008) Times](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_ [2 October [2008] All ER (D) 07 (Sep)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4TC3-5930-TWP1-7054-00000-00&context=1519360)


03/02/2022

CACrimD

29/07/2021

CACrimD

19/05/2021

CACrimD

15/01/2021

CACrimD

31/07/2018

CACrimD

28/03/2018

CACrimD

23/11/2017

CACrimD

09/02/2017

CACrimD

21/06/2013

CACrimD

20/02/2012

CACrimD

29/07/2011

CACrimD

21/10/2010

CACrimD

02/09/2008

CACrimD


-----

Applied

**End of Document**


-----

