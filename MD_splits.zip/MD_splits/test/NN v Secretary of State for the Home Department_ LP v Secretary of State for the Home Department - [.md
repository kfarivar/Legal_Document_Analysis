ER (D) 172 (Mar)

# NN v Secretary of State for the Home Department; LP v Secretary of State for
 the Home Department [2019] All ER (D) 172 (Mar)

[2019] EWHC 766 (Admin)

Queen's Bench Division, Administrative Court (Birmingham)

Julian Knowles J

28 March 2019

**Immigration – Trafficking – Support**
Abstract

_Immigration – Trafficking. The claimants would be granted interim relief which had the effect of maintaining their_
_current level of support as victims of modern slavery/people trafficking until further order. The Administrative Court_
_held that, when set against the potential harm to the claimants, both of whom had been accepted by the defendant_
_Secretary of State as having been trafficked and very badly mistreated, the balance of prejudice came down in_
_favour of the grant of relief._
Digest

The judgment is available at: [2019] EWHC 766 (Admin)

**Background**

The claimants were victims of **_modern slavery/people trafficking and had been recognised as such by the_**
defendant Secretary of State in conclusive grounds decisions. They sought judicial review of the Secretary of
State's policies: (i) providing for a package of support until 45 days after the positive conclusive grounds decision;
and (ii) that an application for Council of Europe Convention on Action against Trafficking in Human Beings leave
would be determined at the same time as a conclusive grounds decision, unless the individual had claimed asylum,
in which case the leave decision would be deferred until the asylum decision had been taken. The present
proceedings concerned the claimants' applications for interim relief, seeking orders that the Secretary of State not
reduce the level of their financial and other support pursuant to the support duty pending the outcome of their
claims.

Application allowed.

**Issues and decisions**

Whether interim relief should be granted.

The claimants had good arguable cases on the grounds of challenge as presented. They would suffer irremediable
prejudice if their current levels of support were not maintained pending the outcome of the claims (see [14], [16] of
the judgment).

There would be financial consequences for the Secretary of State from the grant of interim relief. However, when
set against the potential harm to the claimants, both of whom had been accepted by the Secretary of State as


-----

ER (D) 172 (Mar)

having been trafficked and very badly mistreated, the balance of prejudice came down in favour of the grant of
relief. Accordingly, interim relief would be granted which had the effect of maintaining the claimants' current level of
support until further order (see [18], [19] of the judgment).

Chris Buttler and Miranda Butler (instructed by Duncan Lewis) for the claimants.

Emily Wilsdon (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

