# JR147's Application to Apply for Judicial Review [2023] NIKB 67

KING'S BENCH DIVISION

COLTON J

26 MAY 202326 MAY 2023

**Immigration — Asylum seeker — Claim for asylum — Determination of age — Refusal of asylum claim —**
**Respondent obtaining evidence of data provided by Applicant to authorities in other countries**
**contradicting Applicant's claimed date of birth — Respondent deciding Applicant not being child at time of**
**making asylum claim — Respondent contending age issue ought to be dealt with by First Tier Appeal**
**Tribunal — Whether court to exercise jurisdiction in circumstances where matter can be dealt with by**
**specialist Immigration Appeal Tribunal — Whether exceptional circumstances — Whether procedure used**
**to assess age fair — Whether court to determine Applicant's age to be as asserted**

**COLTON J:**

**_Introduction_**

**[1] I am obliged to counsel for their able written and oral submissions in this application. They were of great**
assistance to the court.

**[2] This application has had a protracted history. Proceedings were issued initially in March 2021 in respect of a**
request made by the Respondent under art 34 of Regulation (EU) No: 604/2013 to obtain information and personal
data relating to the Applicant and the subsequent retention and proposed use of that data. Before that application
could be heard the court determined the same issue in separate proceedings involving a different applicant and,
therefore, the court did not have to determine that issue in these proceedings.

**[3] As part of the original application the Applicant also challenged “an ongoing failure to consider his claim for**
asylum.” Part of this complaint also involved a challenge to an interview conducted with the Applicant in respect of
his asylum claim.

**[4] As matters developed, before the court could consider those issues, the Respondent made a final asylum**
decision on 18 November 2022 which refused the Applicant's claim.

**[5] Another unusual feature of this case was that a previous decision had been made refusing the Applicant asylum**
on 3 December 2020, but this was exceptionally done on a “without prejudice basis.” At that time he was also given
a period of discretionary leave to remain in the UK.

**[6] The Applicant exercised his automatic right of appeal against that decision.**

**[7] After receiving the 18 November 2022 decision the Applicant then amended his Ord 53 challenge, in effect,**
challenging the refusal of asylum. At the same time he made an emergency application for interim relief asking the
court to issue an order of mandamus compelling the Respondent to provide discretionary relief in the form of leave
to remain in the UK.


-----

**[8] The matter came before the court on an emergency basis. Having heard arguments in respect of interim relief**
the court refused the application.

**[9] It also refused his application for leave to challenge the decision to refuse asylum on the grounds that he should**
exercise his right of appeal to the First Tier Tribunal.

**[10] However, the court was persuaded to grant the Applicant leave in respect of two issues raised in the final**
Amended Ord 53 Statement. The first was the Respondent's decision on the Applicant's age whereby the
Respondent determined that it did not accept that the Applicant was a child at the time of his asylum claim.

**[11] Secondly, the Applicant was granted leave in respect of the Respondent's decision that the Applicant was not**
a victim of trafficking.

**[12] At the hearing it emerged that, in fact, a “conclusive grounds” decision had been taken by the Single**
Competent Authority which also concluded that the Applicant was not a victim of trafficking. Since that decision
superseded the decision under challenge it was not necessary to deal with this aspect of the challenge.

**[13] Therefore, the sole issue to be determined by the court was whether to grant judicial review of the**
Respondent's decision in respect of the Applicant's age. It will be apparent from the brief summary set out above
that the court has been dealing with a “rolling judicial review.” This is not a desirable state of affairs, and such
applications should normally be discouraged or prohibited.

**[14] It is the court's experience that “rolling” reviews are not uncommon in asylum claims because of the very**
substantial delays in making decisions. This has the unfortunate consequence that an applicant may be granted
leave in respect of a decision/omission, only to find that by the time of the substantive hearing the situation on the
ground has changed. This can often result in an Amended Ord 53 Statement challenging the new state of
affairs/decisions. In such circumstances the court could dismiss the original application and await a new application.
This could have a consequence of unnecessarily increasing costs. Therefore, it may be more desirable to permit
the amendment and to deal with the case on that basis, given that much of the background material will be
available to the court. Whilst the court is conscious of the risk of becoming involved in a rolling administrative
decision-making process, it has adopted a pragmatic and flexible approach tailored to the particular circumstances
of this case.

**[15] In addition to the general scenario presented above, this case had individual features which undoubtedly**
contributed to the delay and the rolling nature of this application.

**[16] Before analysing the Applicant's challenge it is necessary to set out some further background material.**

**_The applicant_**

**[17] The Applicant avers that he is a Kuwaiti Bidun. He entered the United Kingdom on 31 October 2019, and**
claimed asylum.

**[18] He avers that his date of birth is 17 April 2003. If that is his correct date of birth, he was 16 years old when he**
claimed asylum. For these reasons the Applicant was granted anonymity when proceedings were issued. This is a
matter which the court will keep under review.

**[19] As part of the claim the Applicant disclosed that he had travelled through Europe under the control of people**
traffickers.

**[20] As a result on 8 November 2019 a referral was made to the Single Competent Authority (SCA) to make a**
decision as to whether the Applicant was a victim of modern slavery/trafficking. As appears from the summary set
out above the SCA has now rejected this claim.

**[21] Because the Applicant was an unaccompanied asylum-seeking child, he was referred to the Gateway Team at**
the Belfast Trust who appointed a social worker and independent guardian to look after his interests.


-----

**[22] On 9 April 2020, on an application by the Trust, the Applicant was made the subject of a care order issued by**
District Judge Henderson in Belfast Family Proceedings Court. The order referred to his date of birth being 17 April
2003.

**[23] Thereafter, the Applicant was treated as a child in this jurisdiction by the relevant authorities.**

**[24] The Applicant's substantive asylum interview was delayed due to restrictions arising from the Covid-19**
pandemic. The Applicant requested that his application for asylum be examined on the papers, as happened with
other similar young people during this time.

**[25] Whilst he was awaiting his interview the Respondent made requests for information about the Applicant under**
art 34 of Regulation 604/203/EU. As appears from the summary above this was the subject matter of the initial
judicial review challenge in this application.

**[26] The art 34 requests were responded to by the various countries between 31 July 2020 and 7 September 2020.**
The responses highlighted that the Applicant gave the following names, ages, and nationalities when present in
these EU member states:

- Greece – JR147 (i), DOB: 7 April 1998, Iraqi - the Applicant was granted asylum in Greece using this identity.

- Germany – JR147 (ii), DOB: 17 April 1998, from Najaf in Iraq.

- Belgium – JR 147 (iii), DOB: 17 April 2002, born in Jarrah, Kuwait.

- The Netherlands – JR147 (iv), DOB: 17 April 1998, Iraqi.

**[27] The records indicate that the Applicant submitted a nationality certificate in support of his identity to the Dutch**
authorities.

**[28] Thus, the Respondent was understandably concerned about whether the Applicant had given a correct date of**
birth as part of his asylum application. This issue was considered as part of wider credibility issues in the context of
the Applicant's history, his identity and nationality.

**[29] As a consequence the Respondent considered that a substantive interview was necessary before determining**
the Applicant's claim.

**[30] In or around this time it became clear that the Applicant had significant mental health issues. The Respondent**
entered into discussions with the Applicant's then legal advisers, The Children's Law Centre, about how best to
conduct an interview. At one stage it was suggested that a language assessment be established to determine that
the Applicant could speak a variety of Arabic found in Kuwait, which would go some way to establishing his
nationality and potentially satisfy the Respondents. This was not accepted by the Applicant's legal representatives
given that, on his account, the Applicant had left Kuwait aged 14.

**[31] Equally, in and around this time the Respondent sought to engage with the Applicant's social worker in terms**
of whether it was intended to conduct an age assessment of the Applicant.

**[32] On 22 December 2020, Ms Elaine Sommerville, Assistant Director of Children and Young People Care**
Services wrote to Ms Carol Murtala, the DM Team Leader, employed by the Respondent replying to an email dated
10 November 2020 requesting an age assessment of the Applicant.

**[33] This is an important document. Ms Sommerville was replying to the specific queries raised on behalf of the**
Respondent. She was fully sighted of and referred to the information obtained via the Eurodac enquiries. Having set
out that material she replied in the following terms:

“This information is not 'new' in nature. JR147 advised the Home Office in his asylum statement that he had
travelled throughout Europe for a considerable period of time before reaching Northern Ireland. The full details


-----

of his period in Europe, forms a separate investigation by the Home Office's Trafficking Unit and the PSNI, in
relation to the likelihood that JR147 was subject to human trafficking and potentially extensive harm during that
period.

JR147 also provided information to the Home Office in his asylum statement that he was travelling on an Iraqi
passport that had been provided to him by people smugglers. He also provided this information in his
statement of evidence form. In April 2020, JR147 gave permission to share his asylum statement with social
services.

As a Trust we are unclear of the basis on which the age assessment has been requested, given the above
details. It would appear clear, however, the date of birth that attaches to a false document is irrelevant.

As highlighted in the ADCS Guidance:

'Age assessment should only be carried out where there is a significant reason to doubt the claimant is a child
(ADCS, 2015 p5, para [1]).

The 'benefit of the doubt' principle (the principle that doubt should always be exercised in the most favourable
manner) is also dealt with in the ADCS Guidance:

'Age assessments cannot be concluded with absolute certainty as there is not any current method that can
determine age with 100% accuracy. The only exception to that is if there is definitive documentary evidence,
such as a clear history of birth, school records, or other documentation which you accept as valid and
authentic. Where definitive evidence is not available, the benefit of the doubt should be granted to children and
young people presenting as such.

… In accordance with the EU Directive on Trafficking in Human Beings and the Modern Slavery Act, particular
care should be given where there is any possibility that a child or young person has been trafficked, and in
these cases the presenting child or young person should be presumed to be under 18 years of age.'

I am not sure what would be hoped to be achieved by an age assessment. It is JR147 himself who has
disclosed the details of the document from the outset and the fact that it was false. I cannot see how the age
that attaches to a false document could be justification for submitting a young person to a process that has
been recognised as being detrimental to their welfare.

Further to the above, JR147 has been in the care system in Northern Ireland for 14 months. During this time
dozens of experienced residential care staff who were trained in child development have worked with him, as
have several different social workers. None of these experienced professionals have raised any doubts about
JR147 being the age that he states.

The only reason that this is being raised now is because of Eurodac hits related to different DOBs. It is, in the
experience of the Trust and other services working with UASC and trafficked children, common for them to
travel across Europe on false documents with false DOBs. This is also common for children who travel on adult
documents. Children travelling alone are often detained and unable to continue their journey,
smugglers/traffickers know this and so they provide young people with documents giving adult DOBs to enable
them to continue travelling unhindered.

In this matter JR147 is a suspected victim of trafficking, who has from the outset voluntarily disclosed to the
Home Office and Social Services that he travelled extensively throughout Europe for a considerable period of
time on a false passport. The question is therefore, whether the additional information that the false passport
records an older date of birth, constitutes a 'significant reason to doubt that he is a child.' Given the
circumstances of this case it is the view of the Trust that it does not and the Trust will not be progressing an
age assessment.”


-----

**[34] For some reason in an unsworn affidavit filed on behalf of the Respondent, by Nicole Gray, Senior Case**
Worker, filed on 9 July 2021, it is averred at para [22] that as far as she was aware no response was received to the
email from Ms Murtala of 10 November 2020.

**[35] This was clearly a reasoned and substantive response in relation to the question of the Applicant's age.**

**[36] In relation to the Applicant's vulnerability, a medical report was obtained from Dr Elaine Harrison in November**
2020 diagnosing the Applicant with PTSD and providing her opinion on the potential of the Applicant to be harmed
during the interview process. In her report she said:

“It would be my opinion that he is currently not in a fit psychological state to be interviewed, and to do so at this
juncture would potentially prove harmful and might exacerbate his already challenging psychological
presentation and yield information likely of poor quality.”

**[37] However, the impasse in relation to progressing the matter failed to be resolved. Eventually it was agreed that**
the Applicant would attend for asylum interview on 24 March 2022.

**[38] Prior to that interview a medical report was obtained from Dr Pat Bracken, Consultant Psychiatrist, dated 2**
March 2022, which was obtained for the purposes of assessing the Applicant's fitness for interview, diagnosing his
current mental health state, and providing a framework for keeping him safe during the interview process.

**[39] The report confirmed the Applicant's fitness to be interviewed but recommended safeguards to be put in place**
during the interview having regard to his mental health difficulties and to help ensure accurate information for the
purposes of assessing his claim.

**[40] The interview took place over two days on 24 March 2022 and 29 March 2022.**

**[41] To put it mildly it does not appear that the interview was a success.**

**[42] The Applicant's then solicitor, Barbara Muldoon, of the Children's Law Centre, sent a 32-page letter of**
complaint on 11 April 2022 to the Respondent.

**[43] The tenor of the complaint is apparent from the “Preface to Complaint” in Ms Muldoon's letter which reads as**
follows:

“I have been involved in providing legal services to asylum seekers and refugees since 2002. I have attended a
large number of asylum interviews over the course of the last 20 years. I have generally found the interviewers
to be professional and courteous. I have generally found the interviewers to be largely respectful of the role
played by the legal representatives and others and generally respectful of the applicant. Any issues that have
arisen I have generally felt that there was an opportunity and space to raise them orally, both during and at the
end of the interview. Insofar as there was ever any departure from that general position, I have never
experienced clear hostility at interview, towards both myself or the applicant.

I have sometimes had cause to feel that a Home Office interviewer had approached an interview with varying
degrees of scepticism and disbelief in relation to an applicant's claim. However, I have never previously felt that
an interview was conducted in a manner that indicated the matter had been absolutely pre-determined prior to
the interview taking place and where I was of the view that the interviewer had closed their mind entirely to all
possibility that any part of the applicant's account might be true and, furthermore, where I felt that any time that
the applicant made remarks that might show his account to be true, the questions on that matter ended
abruptly.

Previously, I have not always felt that all conduct, questions and manner was “fair” during asylum interview,
however, I have never felt that an interview slipped outside of the general framework, where it was so unfair, as
to be, in my clear view, unlawful.

I have never previously lodged a complaint in relation to the conduct of a Home Office asylum interview.


-----

I consider that what took place during the two parts of this interview, on 24 and 29 March 2022 was far outside
the boundaries of what could be deemed to be acceptable conduct by a public body. I felt that it departed from
Home Office guidance on policy in a manner that was utterly extraordinary and where I have no experience of
this happening anywhere near that degree previously. In particular, I felt that it was in stark contravention of
s55 and all of the safeguarding duties, policies, and procedures designed to give it effect and totally
disregarded the Home Office Modern Slavery Guidance in relation to dealing with those suspected of being
Victims of Trafficking. I feel that the interview completely disregarded (other than by disparaging it) the
psychiatric report by a knowledgeable and experienced psychiatrist that had been obtained for the purposes of
safeguarding the vulnerable applicant during the process. I felt that it showed an entirely reckless disregard for
the welfare, well-being, and safety of the applicant, to such a degree that my considered view is that the
interviewers conduct amounted to misfeasance in public office.”

**[44] The letter went on to make specific criticisms of the conduct of the interview which are too numerous to set out**
in this judgment. Importantly, Ms Muldoon in her letter proffers the opinion that:

“This meant that the applicant was offered no proper opportunity to establish that the basis of disputes
regarding his age and nationality, are as a result of having been under the control of human traffickers, rather
than as a result of him having practiced deception.”

**[45] The complaint by the Applicant's then solicitor, was also supported by a separate letter from the Applicant's**
guardian, dated 4 April 2022, in which she also raised concerns regarding how the asylum interview was
conducted.

**[46] The letter of complaint was preceded by a letter from Ms Muldoon on 8 April 2022 making comments about**
the interview and seeking a copy of the audio of the interview.

**[47] There followed a series of emails about the audio, but ultimately, what was provided was only a record of what**
the interviewer said. The responses of the Applicant appear not to have been recorded.

**[48] Eventually, a response to the complaint was received on 23 August 2022, in which it was indicated on behalf**
of the Respondent “I am partially upholding your complaint.”

**[49] As indicated in the summary above this interview and its potential use became the subject matter of the**
judicial review challenge, but ultimately, this was superseded by the actual decision of 22 November 2022 which is
now under appeal.

**[50] That decision is a comprehensive, detailed, and lengthy one, containing 147 paragraphs.**

**[51] The key paras in relation to the age dispute are paras [58]-[73] which are as follows:**

“Age dispute - it is not accepted that you were a child at the time of your asylum claim

58. You have asserted to the authorities in the UK that you date of birth is 17/04/2003.

59. There have been concerns about your age because of objective evidence from three European Union
member states confirming that you presented yourself as being born on 17/04/1998, which is five years older
than the date of birth used in your asylum claim in the United Kingdom (GR, DE, NL). Additionally, objective
evidence from a further European Union member state confirms you presented yourself as being born on
17/04/2002, one year older than the date of birth used in your asylum claim in the United Kingdom (BE).

60. On 15/10/2017 when you claimed asylum in Greece you would have been approximately 14 years and 6
months old if as claimed your date of birth is 17/4/2003, however, if your date of birth was 17/4/1998 as
recorded by the Greek authorities you would have been approximately 19 years and 6 months old. It is unlikely
(although not impossible) the Greek authorities would have accepted a 14 year old as an adult.


-----

61. By the time you claimed asylum in the UK on 04/12/ 19 you would have been approximately 21 years and 8
months old using the date of birth provided to the Greek, German and Dutch authorities.

62. As the evidence you provided to the Greek, German and Dutch authorities contradicted what you told both
the Belgian and then you gave a further different version to the British authorities, it was considered that there
was significant evidence to question your claimed date of birth.

63. You had supplied the Dutch authorities with a document which supported your claimed date of birth of 17/4/
1998 and thus you were referred to South Eastern Health and Social Care Trust for an age assessment.
However, it was not completed.

64. On 16/ 12/2020, judicial review proceedings were initiated based on delay and a request to destroy all
Article 34/Eurodac evidence as part of that litigation. As part of that litigation the Home Office provided
background to all steps taken in an attempt to conclude your asylum claim, including an affidavit from the
Home Office. Some 8Y2 months after that litigation began, a letter was handed in to Drumkeen House on
02/08/2021 from Elaine Somerville at South Eastern Health and Social Care Trust advising that an Age
Assessment was not needed. That letter was dated 22/12/2020.

65. The letter details the various identities, issues and dates of birth presented by you to member states but
ignores the fact you were granted asylum and therefore permission to reside in Greece as an adult. You would
have been entitled to documentation from the Greek authorities as proof of your age and identity as a result.
Ms Somerville stated:

“As a Trust we are unclear of the basis on which the age assessment has been requested, given the above
_details. It would appear clear, however, that a date of birth that attaches to a false document is irrelevant.”_

Unfortunately Ms Somerville's letter failed to engage with the evidence and that you had provided the same
adult date of birth in several countries previously and that one, having applied due diligence, which would have
involved an interview and inspection of your identity document, granted you obtained Refugee Status as an
adult.

South Eastern Health and Social Care Trust have maintained their unwillingness to engage in an age
assessment to assist your claim. On the basis of the date of birth you have provided in the UK, you are now
over age of 18. We have taken into account that the Trust considers you have to have been a child when they
first encountered you in the UK. However, they do not appear to have considered evidence in a way that would
satisfy the requirements set out in Merton.

Consideration has been given to Home Office guidance which states –

“In the absence of documentary proof of age, it is Home Office policy to give prominence to a Merton compliant
_age assessment and it is likely that in most cases the Merton compliant age assessment will be determinative._
_However, all available relevant sources of information must be considered and an overall decision made in the_
_round. Account may be taken of the overall credibility of the claimant, established for example through the_
_asylum interview, though care must be taken in doing so). All available relevant sources of information should_
_have been taken into account by the party completing the Merion compliant age assessment. Where there is_
_reason to believe that the assessment has not taken all the evidence into account, you must immediately_
_request clarification from the party which undertook the assessment and, where it is confirmed that they did not_
_do so, request that they review their assessment. The Age assessment joint working guidance must be referred_
_to when considering conflicting evidence.”_

Further consideration has also been given the general principles set out in Age Assessment Guidance:
Guidance to assist social workers and their managers in undertaking age assessments in England. It does not
extend to Northern Ireland, so I have had to take that into account. It is a means of resolving age assessment
disputes across agencies and has been effectively used since 2015. At its heart, its primary purpose is to give
social workers the tools to complete age assessments in a child-friendly way, using best social work practice


-----

and ethics and utilising the knowledge of all agencies involved in the life of the child to inform the holistic
assessment of a young person's age. It states:

“Age assessments should only be carried out where there is significant reason to doubt that the claimant is a
_child. Age assessments should not be a routine part of a local authority's assessment of unaccompanied or_
_trafficked children.”_

“There may be occasions where you do not feel that an age assessment is necessary but where the Home
_Office requests an assessment before it will treat the young person as a child in the immigration process. In_
_these circumstances you may need to negotiate with the Home Office to explain why the young person should_
_be treated as a child without further assessment or conduct an assessment sufficiently comprehensive that it_
_enables the Home Office to be assured that the assessment is case-law compliant.”_

The evidence in this case plainly raises significant reason to doubt the date of birth given in the UK. Therefore,
making a request for a formal age assessment was appropriate in the circumstances. The Home Office would
have benefited from such an assessment, as would you. It is unfortunate it was not provided . The Home Office
has no authority to compel the Trust to undertake an age assessment, therefore we have had to proceed on
the information available to us.

70. You have previously given three sets of immigration officials your date of birth as 17/04/1998 and this has
been demonstrably accepted.

71. When asked about the different dates of birth and what you could provide by way of proof or assistance you
stated that you are a Kuwaiti Bidoon, you have no documents, and you were told your age by your mother
(AIRl 137-138).

72. In Rawofi _[2012] UKUT 00197 (IAC) the Upper Tribunal found that where age is disputed in the context of_
an asylum appeal before the Tribunal (in contrast to age assessment in judicial review proceedings), as with
other asylum cases before the Tribunal: the burden is on the appellant, the standard of proof is the lower
standard - the 'reasonable degree of likelihood'. In age assessment judicial review proceedings, there is no
burden of proof on either party and the Court's task is to decide the issue on the 'balance of probability' in light
of all the evidence.

73. Taking a view of the evidence as a whole, the Home Office is not satisfied you were a child when you
entered the UK. Your date of birth is more likely to be that provided to and accepted by the Greek authorities
(and provided to other countries by you).”

**_Age dispute_**

**_The applicant's challenge_**

**[52] By these proceedings the Applicant seeks to challenge the Respondent's determination in relation to his age.**

**[53] The Respondent's primary answer to this challenge is that this matter should not be considered by the court.**
Mr Henry argues that it ought to be dealt with in a different forum namely the FtT Appeal Tribunal which can fully
deal with the age issue. The Applicant has lodged an appeal to the FtT. That appeal has been adjourned pending
the outcome of this decision. He refers to reported examples of tribunals dealing with age disputes including the
following:

- Rawofi [2012] UKUT 000197, in which guidance was given on the burden and standard of proof to be applied in
age dispute cases in the tribunal. The headnote states:

“Where age is disputed in the context of an asylum appeal (in contrast to age assessment in judicial review
proceedings), the burden is on the appellant and the standard of proof is as laid down in R v Secretary of State
_for the Home Department Ex parte Sivakumaran [1988] AC 958and R (Karanakaran) v Secretary of State for_
_the Home Department [2000] EWCA Civ 11.”_


-----

- TV v SSHT, 23/5/17, 040452015, a decision from the President of the Immigration and Asylum Chamber of the
Upper Tribunal, Lane J, in which he set aside the FtT's decision on age.

**[54] In short, it is argued that the specialist Immigration Appeal Tribunal is the appropriate and best placed forum to**
deal with the age dispute. In developing this argument, he points out that the tribunal will have the opportunity to
hear oral evidence which can be tested by all parties appearing at the tribunal. In judicial review proceedings, such
as here, the court only has written materials and at best affidavit evidence. In this case the tribunal would have the
opportunity, if the Applicant so chooses, to hear evidence from the social workers and Trust representatives who
have dealt with the Applicant and made assessments in relation to his age.

**[55] Mr Henry submits that immigration judges have expertise in dealing with issues concerning individuals**
travelling through the immigration system which often includes age disputes and the particular complexities
concerning evidence from those who may have been the victims of trafficking. A further example relates to the FtT's
powers to compel the Applicant to provide for example social media content which can often be illuminating in terms
of revealing dates of birth.

**[56] Thus, it is argued that the tribunal is best placed to test the evidence in relation to the age dispute and come to**
a more informed conclusion.

**[57] In England and Wales there is a specific power available to the administrative court to transfer age**
[assessment cases to the Upper Tribunal under s 31A(iii) of the Senior Courts Act 1981, as inserted by s 19 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0M2-00000-00&context=1519360)
Tribunals, Courts and Enforcement Act 2007.

**[58] In R (FZ) v LV Croydon [2011] EWCA Civ 59 the Court of Appeal was dealing with the age assessment of a**
claimant who was an unaccompanied asylum seeker claiming to be a child. The judgment dealt with the correct
approach of the court at permission stage of age dispute judicial review claims.

**[59] It had also decided on the facts of that case:**

“that, such a judicial review claim involved a factual determination of the claimant's age on contested evidence,
which the administrative Court did not habitually and was not equipped to decide, it was appropriate that the
[matter be transferred to the Upper Tribunal under section 31A(iii) of the Senior Courts Act 1981.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0M2-00000-00&context=1519360)

**[60] That this is considered to be the appropriate direction of travel is confirmed by Part IV of the Nationality and**
Borders Act 2022 which has introduced provisions, not yet commenced, which will bring all age disputes before the
FtT as a matter of statutory course, regardless of how they have arisen.

**[61] There is no dispute that the court has jurisdiction to determine an applicant's date of birth when his age is in**
dispute see for example the Supreme Court decision A v Croydon [2009] 1 WLR 2557and R (Evans) v AG [2015]
AC 1787.

**[62] In deciding the appropriate date of birth the court will consider the weight of evidence in favour of each of the**
competing possibilities.

**[63] Determination of a person's age in the context of immigration has important implications. Section 55 of the**
Borders, Citizens and Immigration Act 2009 provides that relevant statutory immigration functions must be
discharged:

“… [having] regard to the need to safeguard and promote the welfare of children in the United Kingdom.”

**[64] Thus, engagement of s 55 depends upon whether someone is a child.**

**[65] Whilst art 8 ECHR is “a broad term not susceptible to exhaustive definition” (Pretty v United Kingdom [2002]**
35 EHRR at [61] a person's date of birth can be considered an aspect of a person's private life. Thus, in _R (WA_
_(Palestinian Territory)) v Secretary of State for the Home Department_ [2021] 1 WLR 2117 at [77] the court
determined that art 8 entitles a person to have their date of birth correctly recorded in official documentation


-----

**[66] Should the court, in its discretion, exercise it jurisdiction in this case to decide to rule on the age issue, given**
the impending FtT hearing which can make a finding on the Applicant's age?

**[67] In this regard Mr Lavery refers the court to the decision in** _Miss Behavin' Ltd v Belfast City Council [2007]_
_UKHL 19 where the House of Lords held that where a Convention right is in issue the court should be the primary_
decision-maker:

“31. The first, and most straightforward, question is who decides whether or not a claimant's Convention rights
have been infringed. The answer is that it is the court before which the issue is raised. The role of the court in
human rights adjudication is quite different from the role of the court in an ordinary judicial review of
administrative action. In human rights adjudication, the court is concerned with whether the human rights of the
claimant have in fact been infringed, not with whether the administrative decision-maker properly took them into
account. …”

**[68] In making such a decision the court should give weight to the views of the decision-maker. Ultimately,**
however, when the court embarks on the exercise it must, as has been recognised by both parties, make the best
decision it can based on the evidence available to it.

**[69] Complementary to the court's jurisdiction to determine the age of a claimed child is its jurisdiction to determine**
whether the procedure used to assess age has been fair.

**[70] There are two important decisions which deal with the procedure for assessing age and which are regularly**
relied on in litigation on this issue.

**[[71] In R (B) v Merton LBC [2003] 4 All ER 280 the court was dealing with a claimant who was an unaccompanied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)**
asylum seeker who claimed to be seven years old. The Defendant local authority interviewed him in order to assess
whether he was a child in need. The interview was conducted by a social worker in person, with an interpreter
available on the telephone. The social worker considered there were a number of inconsistencies in the Claimant's
account of his history which led her to doubt his credibility, but she did not put those inconsistencies to the
Claimant. She determined that, while in need, the Claimant was aged at least 18. He sought judicial review of that
determination.

**[72] The court gave guidance as to the requirements of a lawful assessment under Part III of the Children Act 1989**
for the purposes of a local authority in the context of a duty to provide such a person with accommodation.

**[73] The headnote reads as follows:**

“The assessment of age in borderline cases was a difficult matter, but not a complex one. It was not an issue
which required anything approaching a trial, a judicialisation of the process was to be avoided. It was a matter
which could be determined informally, provided safeguards and minimum standards of inquiry and of fairness
were adhered to. Except in clear cases, the decision-maker could not determine age solely on the basis of the
appearance of the applicant. In general, the decision-maker had to seek to elicit the general background of the
applicant, including his family's circumstances and history, his educational background, and his activities during
the previous few years. Ethnic and cultural information might also be important. If there were a reason to doubt
the applicant's statement as to his age, the decision-maker would have to make to an assessment of his
credibility, and ask questions designed to test credibility. There was no onus of proof on the applicant, the
authority had to make its assessment of the material available to and obtained by it. There should be no
predisposition, divorced from the information and evidence available to an authority, to assume that an
applicant was an adult, or conversely that he was a child. A local authority could not simply adopt a decision
made by the Home Office on an application for asylum. It might take into account information obtained by the
Home Office, but it had to make its own decision, and for that purpose had to have available to it adequate
information. Medical reports were not likely to be helpful; for someone close to the age of 18 there was no
reliable medical or other scientific test to determine whether he was over or under that age. It was not
necessary for an authority to provide support for a period of some weeks to give the opportunity for others to
observe the applicant if the information available was sufficient for a decision to be made Where an interpreter


-----

was required, it was generally preferable for him to be present during the interview to avoid a risk of
misunderstandings. Although it was not necessary as a matter of law for there to be verbatim notes of the
interview, such a note would enable the court to be more confident of its accuracy and to address any
suggestion that the interviewer had put words into the mouth of the applicant by asking leading questions. If the
decision-maker formed the provisional view that the applicant was lying as to his age then the applicant had to
be given the opportunity to address the matters that had led to that view, so that he could explain himself if he
were able to. Following an interview and any other inquiries, an authority was obliged to give adequate reasons
for its decision refusing support under the 1989 Act. The consequences of such a decision might be drastic for
the applicant, and he was entitled to know the basis for it, and to consider whether the decision was a lawful
one. Nevertheless, the reasons did not need to be long or enamoured. It would be sufficient to state that the
decision was based on the appearance and behaviour, or demeanour, of the applicant and the matters which
led the authority to conclude that the applicant was not truthful. In the instant case, the possibility that the
claimant might have been able to rectify any misunderstanding, the matters relied upon by the defendant in
coming to his decision it would be put to him, meant that the defendant had not satisfied the onus of
establishing that, even if, they had been put to the claimant, the same decision would inevitably have been
made. There was no evidence that there had been a suitable alternative complaint or review procedure
available to the claimant to challenge the defendant's decision. Accordingly the defendant's decision would be
set aside. The defendant was to reconsider the age of the claimant using the information presently available to
it.”

**[74] This important decision has been the touchstone for age assessments carried out by the authorities in relation**
to asylum seekers. Frequent reference is made to a Merton compliant assessment when carrying out assessments
of asylum seekers claiming to be children.

**[75] In the case of** _R (HAM) v Brent London Borough Council_ [2022] PDSR 1779 the administrative court in
England and Wales was dealing with the age assessment of a claimant claiming to be an unaccompanied child
asylum seeker. The local authority carrying out the age assessment concluded he was an adult, and the issue was
whether the assessment was procedurally unfair. The Claimant successfully challenged the assessment of the local
authority. The court held:

“(1) That the question whether an asylum seeker was under 18, so as to attract the local authority's statutory
duty under _Part III of the Children Act 1989 to provide accommodation and support, was a question of_
jurisdictional fact ultimately for determination by a relevant court and not a question to be determined as a
matter of reasonable assessment by the local authority subject only to the requirements of public law legality;
that did not diminish the requirement for fairness in the authority's own assessment; that where the authority's
decision had been taken by a process not considered to meet the legal standard of fairness, or which failed to
adhere to the local authority's own policy, it was open to challenge on that ground alone, independent of its
substantive merit; that in reaching the decision as to age (i) there is no burden of proof and so no assumption
either way, each assessment having to be undertaken in its terms, (ii) a decision had to be based on
reasonable inquiry, so the local authority had to take the steps reasonable in each case to obtain the
information needed to make the decision, and whether that requirement was fulfilled would depend on the
circumstances of the case, (iii) any interview or other form of inquiry undertaken as part of the process had to
be undertaken fairly and, importantly, any issue arising as to the individual's credibility had to be dealt with
openly and directly during the interview process so that, in particular, where a local authority was minded to
conclude that a person claiming to be a child was lying, the reasons for that view ought to be explained and an
opportunity to respond given before a final decision was taken, (iv) although there might be a range of things
which a local authority could do to ensure that the process was fair, it would be wrong to regard each item as a
requirement of fairness which ought to be applied in every case, fairness being a matter of substance not
merely form; and that, further, the public authority had adopted a policy on how it would undertake age
assessments, it ought to be held to that policy unless on the facts of the case there was sufficient reason to
depart from it.

(2) That there was no binding determination to the effect that an assessment undertaken by a single social
worker could not for that reason alone meet the legal standard of fairness


-----

(3) That there was no 'one size fits all' approach which required an appropriate adult to be present …

(4) That the supposed distinction between a full 'Merton-compliant' age assessment and a 'short-form
assessment' was legally irrelevant; that the correct approach in all cases started with the principles of a
reasonable investigation and a fair process, the particular requirements of which would depend on the
circumstances of the case and the individual; and in an obvious case a reasonable inquiry might be brief while
other cases would require further investigation; that the obligation on a local authority was therefore one of
reasonable investigation specific to the circumstances.”

**[76] The critical failure in the HAM case was the failure to put to the Claimant the matters which caused it to doubt**
his credibility and thereafter give him time to respond before making a decision as to his age. Thus, the required
legal standard of fairness had not been met in that case.

**[77] From these authorities it can be seen that the court has a wide-ranging and important jurisdiction in the**
context of challenged age assessments.

**[78] In my view the court should be slow to exercise that jurisdiction in circumstances where the matter can be**
dealt with by a specialist tribunal, which is normally best placed to come to decisions on matters of factual dispute.

**[79] That said I am persuaded this is an exceptional case where the court should exercise its jurisdiction. I say so**
for the following reasons.

**[80] There has been significant delay in this case. Irrespective of the cause of that delay it is clear that it has had a**
significant impact on the Applicant's mental health as is apparent from the medical evidence. It is not necessary for
the FtT to determine the Applicant's age when coming to a final conclusion in relation to his asylum application.
Clearly it will be an important consideration. It is obvious, however, from the decision of November 2022 that the
tribunal will have many substantive issues to consider in determining the application.

**[81] Most importantly, however, the court considers that the evidence available overwhelmingly points in favour of**
the Applicant and against the Respondent on the specific issue of the assessment of his age.

**[82] In coming to this conclusion I accept that the Eurodac information gives rise to a legitimate issue about the**
accuracy of the Applicant's age and one which the Respondent was entitled to investigate further.

**[83] Whilst the Respondent was clearly entitled to take the Eurodac information into account it is also important to**
acknowledge the contents of the Home Office policy applicable in England and Wales entitled “using information
obtained through the Dublin Regulations and Eurodac for age assessment purposes” which states that:

“A degree of caution should be exercised when using information obtained from Eurodac and Article 34 of the
Dublin Regulations for age assessment purposes. With the loss of access to the information sharing process
under Article 34 of the Dublin III Regulations, the UK can no longer use Article 34 to verify any information
previously obtained through Eurodac or the Dublin III Regulations or to obtain further information.”

**[84] In this context it is important that the Applicant claims to be a victim of** **_modern slavery/trafficking and_**
explained that he had travelled through Europe under the control of traffickers. It is well recognised that in such
circumstances traffickers may well have their own incentives to encourage victims to claim to be adults and to
provide false information to support such documentation. The Eurodac information simply confirms that the Greek
authorities treated him as an adult by granting him asylum. We do not know the circumstances in which this
decision was made or what material was available to the Greek authorities.

**[85] In this context the decision-maker in relation to age assessment must also take into account other material**
available.

**[86] In this regard a fundamental consideration is the fact that a court in this jurisdiction has made a Care Order in**
respect of the Applicant. That order records the Applicant's age as being 17 April 2003. As a starting point the court
in accordance with the well-known legal principle of the presumption of regularity starts from the proposition that


-----

that is in fact the Applicant's date of birth. The authorities in this jurisdiction should be entitled to rely on such orders
as being accurate and reliable.

**[87] I accept that the order itself is not determinative of this issue. We do not know precisely what information was**
available to the district judge who made the order. It is reasonable to assume that it was made on the basis of the
assessment of those employees of the Trust who were dealing with the Applicant at the relevant time. The
Respondent was not on notice of the proceedings and took no part in them. The district judge did not have the
Eurodac information available to her when making the order.

**[88] Without more, the court is entitled to expect that those who brought the application did so in good faith and**
based on an honest and reliable assessment of the Applicant's age. For example, it would be clear that there would
be safeguarding issues in the event that the Trust would seek to place an adult in any residence which was
provided solely for children.

**[89] Importantly, in this application when the Trust was made aware of the issue raised by the Eurodac information**
its employees were unequivocal in their assertion about the Applicant's age.

**[90] In this regard I refer again to the important email from Elaine Somerville, an Assistant Director from Children**
and Young People Care Services in the South Eastern Health and Social Care Trust dated 22 December 2020. She
was firm in her view that all the key professionals who had worked with the Applicant since his arrival in Northern
Ireland decided that an age assessment was not needed as they deemed him to be a child and treated him
accordingly.

**[91] That opinion has been reinforced by the independent guardian acting on behalf of the Applicant where she**
writes on 26 April 2023:

“I am writing as the independent guardian for the above referenced young person. I was appointed as this
young person's independent guardian in November 2019, and I have been in regular contact with him since
this time. He has been cared for by two different Health and Social Care Trusts, lived in two residential
children's homes and a supported living facility. He has worked with dozens of different Health and Social Care
professionals over the last 3.5 years. To my knowledge not one of those professionals has ever raised any
doubts as to this young person's age.”

**[92] Although not expressly addressing the issue of age assessment it is also noted that the medical experts Dr**
Bracken and Dr Harrison took no issue with the Applicant's date of birth as being 17 April 2003.

**[93] Thus, as per the decision in** _HAM_ (see above) the Trust concluded, in the court's view rationally and
consistently, that no further age assessment was required and that there was no doubt that he was a child. The
evidence and opinion of the Trust is compelling.

**[94] The decision maker, in the court's view, has not given proper consideration to this compelling evidence and**
opinion. The decision maker erred, in the court's view, when he asserted at para [65] that “Ms Sommerville's letter
failed to engage with the evidence and that you had provided the same adult date of birth in several countries
previously …” In the court's view, Ms Sommerville did engage with this evidence.

**[95] Furthermore, the decision maker has assumed that the authorities in Greece “having applied due diligence,**
which would have involved an interview and inspection of your identity document, granted you obtained refugee
status as an adult.” Neither the decision maker nor the court is properly informed as to what took place in Greece.

**[96] The decision maker asserts that the Trust did not appear “to have considered evidence in a way that would**
satisfy the requirements set out in Merton.” Having regard to the analysis set out above the court considers that,
again, the decision maker fell into error in this assertion. The Trust, for the reasons set out above, were fully
satisfied that the Applicant was a child when he arrived in the UK and acted accordingly.

**[97] The decision maker appears to have simply relied on the evidence provided to authorities in other countries at**
a time when the Applicant asserts he was the victim of trafficking and under the control of other adults In the court's


-----

view the decision maker has failed to give appropriate weight to the compelling expert evidence submitted on behalf
of the Trust.

**[98] A further factor in favour of the court's intervention is that if the Respondent is wrong in its assessment of the**
Applicant's age, I consider that the court should protect him from the unfairness and injustice that arises from this
error, rather than compel him to go through the stages of a hearing and then a potential limited right of appeal. I
consider that he is entitled to have his rights vindicated in relation to this aspect of his claim at this stage. I consider
that the facts of this case give rise to exceptional circumstances justifying an intervention by the court.

**[99] Having taken all these matters into consideration I have come to the firm conclusion that the court should**
determine the Applicant's age to be as asserted namely 17 April 2003.

**[100] Mr Henry posed the question as to what the FtT should do with any declaration by the court in this regard. I**
refer him to the Home Office's own guidance in relation to judicial review findings on age. It states:

“A declaration by the court as to the individual's age should be considered as credible and clear documentary
evidence of age.”

**[101] The court therefore makes the following order:**

i An order of certiorari quashing the Respondent's decision that the Applicant's date of birth is 17 April 1998; and

ii A declaration that the Applicant's date of birth is 17 April 2003.

Judgment accordingly.

**End of Document**


-----

