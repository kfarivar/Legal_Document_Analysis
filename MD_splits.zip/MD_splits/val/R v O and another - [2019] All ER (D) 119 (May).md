# R v O and another [2019] All ER (D) 119 (May)

[2019] EWCA Crim 752

Court of Appeal, Criminal Division

EnglandandWales

Macur LJ, Russell J and Judge Leonard QC (sitting as a judge of the Court of Appeal Criminal Division)

9 May 2019

**Criminal law – Victim of trafficking – Nexus and compulsion**
Abstract

_Criminal law – Victim of trafficking. There had been nexus and compulsion associated with the second defendant's_
_status as a victim of trafficking and his conviction for cultivation of cannabis, such that the conviction was quashed._
_However, the Court of Appeal, Criminal Division, dismissed the first defendant's appeal against conviction and_
_sentence, as her victim of trafficking status did not establish nexus or compulsion with her conviction for controlling_
_prostitution for gain._
Digest

The judgment is available at: [2019] EWCA Crim 752

**Background**

Two cases were heard together because they both sought a retrospective review of decisions to prosecute the
defendants who claimed to have been the victims of trafficking (VOT). In the second case, the defendant, N, had
raised the issue at the outset, but had then pleaded guilty to cultivation of cannabis, was sentenced and had served
his custodial term. The registrar referred N's case to the full court. N sought an extension of time to do so and
permission to rely on fresh evidence relating to his status as a VOT.

In the first case, the defendant, O, did not raise the issue until serving a custodial sentence of five years, having
been convicted by a jury of two offences of controlling prostitution for gain. The judge had granted an extension of
time and leave to her to appeal sentence. The judge had referred O's application for an extension and permission to
appeal against conviction, which had to rely on fresh evidence relating to her status as a VOT.

**Issues and decisions**

(1) Whether N's conviction was unsafe.

There was no hesitation in finding that N had been a VOT. There was no doubt that that would have to have been
disclosed in any contested hearing. It coincided with the final assessment of the national referral mechanism. There
was no basis upon which to question the national referral mechanism finding. N had been consistent in his accounts
of restriction of his autonomy and there was objective corroboration for the material aspects of his account in that
respect (see [33] of the judgment).


-----

There had also been nexus and compulsion associated with the trafficking. The prosecution's arguments required
the undoubted fact of N's isolation by virtue of his inability to communicate in English and his geographical
ignorance to be ignored (see [34] of the judgment).

In all the circumstances, public interest had not required prosecution. The conviction was unsafe. Time would be
extended, it would be found to be unjust not to allow N to rely on the fresh evidence and the appeal would be
allowed. The conviction would be quashed (see [35] of the judgment).

(2) Whether O's conviction was unsafe.

While there were some misgivings regarding O's status as a VOT, she would be given the benefit of the doubt on
that issue. However, that status did not establish nexus or compulsion at the relevant time. If O had been a VOT on
arrival in the UK, there was no doubt that she had been complicit in trafficking others thereafter and not by reason
of coercion. Even on her own eventual account, there had been a significant time interval between her own arrival
and significant geographical distance of her alleged 'operator' at the relevant time of the offences. O had
demonstrated free will in the operation of her 'business' as sex worker, an ability to accumulate money and, she had
said, produce a simple accounting system for the earnings of other prostitutes (see [63] of the judgment).

In any event, public interest had required prosecution. The judge would rightly have dismissed any abuse of
process argument suggesting otherwise and, since the offences had preceded its enactment, the jury would not
[have been able to consider the defence afforded by s 45 of the Modern Slavery Act 2015. The conviction was safe](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
(see [64] of the judgment).

Further, the judge's assessment of the culpability withstood the finding that O had been a VOT. The offences had
been aggravated offences. There had been no nexus between O's status as VOT and offending as charged. There
had been no flaw in the sentencing exercise conducted by the judge. The sentence had not been manifestly
excessive and the appeal against sentence would be dismissed (see [65] of the judgment).

Daniel Bunting (instructed by Birds Solicitors) for the defendants.

James Marsland (instructed by the Crown Prosecution Service) for the Crown.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

