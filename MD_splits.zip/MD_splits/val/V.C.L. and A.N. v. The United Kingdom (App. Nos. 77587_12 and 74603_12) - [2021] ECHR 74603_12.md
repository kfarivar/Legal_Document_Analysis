# V.C.L. and A.N. v. The United Kingdom (App. Nos. 77587/12 and 74603/12)

 [2021] ECHR 74603/12

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE GROZEV (PRESIDENT), JUDGES EICKE, VEHABOVIĆ, MOTOC, HARUTYUNYAN, VILANOVA,
SCHUKKING AND TAMIETTI (SECTION REGISTRAR)

12 JANUARY 2021

16 FEBRUARY 2021JUDGMENTINTRODUCTION

1. The present applications concern the prosecution of the (then) minor applicants, both of whom were recognised
as victims of trafficking by the designated Competent Authority, for criminal offences connected to their work as
gardeners in cannabis factories.
**THE FACTS**

2. The applicants were born in 1994 and 1992 respectively and live in Middlesex and London. The applicant in
application no.77587/12 (hereinafter, “the first applicant”), who had been granted legal aid, was represented by
Birds Solicitors, a law firm based in London. The applicant in application no. 74603/12 (hereinafter, “the second
applicant”) was represented by the AIRE Centre, a legal charity based in London.

3. The Government were represented by their Agent, Mr J. Gaughan of the Foreign and Commonwealth Office.

4. The facts of the cases, as submitted by the parties, may be summarised as follows.
_I. THE FIRST APPLICANT'S CONVICTION AND SENTENCING_

5. On 6 May 2009 the first applicant was discovered by police at an address in Cambridge during the execution of a

drug warrant. The address was a four‑bedroomed house which had been converted into a sophisticated cannabis

factory containing 420 cannabis plants with a street value in excess of GBP 130,000. The first applicant was found
alone in the property, in possession of a mobile telephone, with credit, and GBP 100 in cash.

6. Following his discovery, the first applicant was interviewed in the company of a legal representative and
appropriate adult. He claimed that he was fifteen years old (a fact which the Government now accept to be correct),
that he had been smuggled into the United Kingdom by his adoptive father, that upon arrival he had encountered
two Vietnamese nationals who took him to the address in Cambridge, and that while he realised cannabis was
being grown there, he hadn't known that it was illegal. He was charged with being concerned in the production of a
controlled drug.

7. Social services assessed the first applicant's age and concluded that he would turn eighteen in January 2010. A
district judge in the Magistrate's Court subsequently found as a matter of fact that he was at least seventeen years
old.

8. At a preliminary hearing before the Crown Court on 21 May 2009, the case was adjourned for a plea and case
management hearing. A few days later Refugee and Migrant Justice, a legal advice and representation charity,
informed the first applicant's then representative of concerns that he may have been the victim of human trafficking,
and that the point had been “flagged up” by social services. They further indicated that social services might raise


-----

discontinuance with the Crown Prosecution Service (hereinafter, “the CPS”) but if not the matter ought to be taken
up at court.

9. On 13 August 2009 the first applicant had a conference with counsel. There was no record of any exploration of
the trafficking issue. The first applicant initially gave “not guilty” instructions and indicated that he was scared, but
on receiving counsel's advice he confirmed that he intended to plead “guilty”.

10. On 20 August 2009, following the conference with counsel, the first applicant pleaded guilty to the production of
a Class B drug.

11. On 4 September 2009, at a conference at which the first applicant was not assisted by an appropriate adult,
different counsel advised him that he could apply for leave to vacate his guilty plea on the ground that he had been
trafficked and subjected to forced labour. However, the first applicant instructed counsel that he was not in fear of
the alleged traffickers. Nevertheless, sentencing was adjourned to await receipt of a report from social services on
whether he was deemed to be the victim of trafficking.

12. On 14 October 2009 the CPS reviewed their decision to prosecute and concluded that there was no credible
evidence that the first applicant had been trafficked. The following day, however, the CPS received a letter from the
United Kingdom Border Agency (hereinafter, “UKBA”) indicating that the circumstances of the first applicant's case
had been considered by one of the two Competent Authorities (see paragraph 75-76 below) which concluded that
there were reasonable grounds for believing that he had been trafficked. He was therefore granted a forty-five day
“reflection period” and his case was adjourned on the basis that this was in his best interests.

13. On 27 November 2009 UKBA sent a letter to the first applicant's representative. It noted that the traffickingrelated criminal investigation was still on-going but found that the first applicant's circumstances raised the following
trafficking indicators: he had been found at a cannabis factory highlighting criminality involving adults; he was not
enrolled in school; and he was not allowed to leave the property. It further stated that in light of his “credible
account” – which had remained consistent in the various meetings he had had with social services – it was
considered that he had been trafficked to the United Kingdom.

14. On 8 December 2009 the case was reviewed by the CPS lawyer but the Chief Crown Prosecutor subsequently
confirmed that it should be prosecuted. Although no official reasons were given for this decision, in a letter to a
Member of Parliament of 10 December the then Director of Public Prosecutions explained that the prosecution had
not been discontinued because the offences were extremely serious, there was no defence of duress and no clear
evidence of trafficking.

15. At a hearing on 14 December 2009 the CPS argued that to be a victim of trafficking was not a defence; rather,
the decision to prosecute was taken in light of information they had and had to be kept under review. To apply to
vacate would be pointless as duress was not a viable defence. The judge, however, indicated that an application to
vacate was well-founded and set a timetable for listing in early 2010 if the application was to be made. In the cells
afterwards the first applicant indicated that he wished to change his plea.

16. On 16 December 2009 defence counsel indicated to the first applicant's solicitors that social services were
“outrageous” in advocating a change of plea. He reiterated his view that the fact that the first applicant was not
frightened and was looking after the plants in return for help in finding his family made the issue irrelevant.

17. At a hearing on 19 January 2010 the first applicant maintained his plea. It appears that this decision followed a
meeting with his solicitors in which he was advised that the finding that he had been trafficked had not been
definitively confirmed; that in any case the CPS were not required – and did not intend – to withdraw the
prosecution; and that although the decision to prosecute could be challenged in the High Court, it was a lengthy
process which had little prospect of success. In the Crown's submission, the evidence suggested that the first
applicant was not a trafficked person. Counsel for the Crown went through the facts in detail, noting in particular
that he was found in an ordinary house with a mobile phone, credit and money; in the trafficking assessment he had
indicated that his family in Vietnam was not under threat; there were no debts owed to anyone in Vietnam; and he
had not been abused prior to his arrest. They therefore found “no reason whatever” to revise their initial assessment


-----

that the first applicant should be prosecuted in the public interest. The first applicant was sentenced to twenty
months detention in a young offenders' institution.
_II. THE SECOND APPLICANT'S CONVICTION AND SENTENCING_

18. On 21 April 2009 police officers attended a residential premises in London following reports of a suspected
burglary. They had been informed that a large body of men had been seen in the gardens to the rear of the
premises, forcing their way in. When they got there, they discovered a very sophisticated cannabis factory. The
second applicant, together with a number of other Vietnamese nationals, was found close to the premises, hiding
from the marauders. They were all arrested.

19. Upon his arrest, GBP 70 was found on the second applicant. With the assistance of an interpreter, he was
interviewed at a police station. As he initially gave his year of birth as 1972, he was treated as an adult (it was later
accepted that his actual year of birth was 1992).

20. During the police interview he indicated that upon leaving Vietnam he had travelled to the United Kingdom via
the Czech Republic. Soon after his arrival, he met some Vietnamese people, including a man (“H”) who gave him
accommodation, clothes and food for a week. While he was staying at the house he was told that it was “best for
him not to go out”; however, when asked if he was held there against his will, he said no. After a week, he was
taken to the cannabis factory in a vehicle which was “covered up”. According to the second applicant, the windows
of the factory were bricked up, the only door was locked from the outside and he believed that the factory was
guarded. His work included watering the plants and cooking. He slept, ate and worked in the factory, and he was
not paid for his work.

21. The second applicant claimed that in the beginning he did not know that the plants in the factory were illegal.
However, he became suspicious and wished to leave as he was frightened. In or around this time H allowed him to
leave the factory with some others for a few days, but when he told H, in the course of a telephone call, that he did
not wish to return, H told him that he might be killed if he stopped working. He and the others were then picked up
and returned to the factory.

22. Following the interviews the applicant was charged with being concerned in the production of a controlled drug
of Class B, namely cannabis.

23. At a hearing before the Magistrates' Court on 30 April 2009 the second applicant gave his year of birth as 1992.
The case was thereafter approached on the basis that he was seventeen years old.

24. The prosecution conducted a file review on 1 June 2009. They appear to have considered that the second
applicant had been smuggled into the United Kingdom, since his parents had funded his journey to what was hoped
would be a life with better prospects.

25. The second applicant was granted legal aid. There is a note in the instructions to his counsel indicating that he
had been “trafficked into the UK”, although the source of that entry was not traced and the applicant later accepted
that he had not used that term.

26. Counsel saw the second applicant in conference on 1 July 2009, taking instructions directly from him with the
assistance of a translator. He told counsel that he had fled his home in Vietnam and come to the United Kingdom
illegally via the Czech Republic. Upon arrival he contacted a cousin in London. While looking for work, some
Vietnamese people had introduced him to H, who provided him with accommodation, food and money. He was then
taken to work in the factory, which he initially thought was producing herbal medicine. He was mainly locked in the
factory and was unable to go out. After approximately ten days he discovered that the plants were cannabis and
asked to leave. He was threatened that if he left he could or would be killed. Although on one occasion he went with
some co-workers to the home of one of their relatives, H contacted them there and as a result of further threats they
returned to the factory.


-----

27. As the second applicant accepted that he could have run away from the house of his co-worker's relative,
counsel did not believe that a plea of duress would be likely to succeed. The second applicant pleaded guilty in July
2009.

28. Following his “guilty” plea, a pre-sentence report was prepared by a member of the Youth Offending Team. The
report indicated that the second applicant regretted his decision to accept the offer to work in the factory. He
accepted that his motivation had been “financial gain”, which was neither acceptable nor justifiable. He accepted
responsibility for his decision to act and displayed a level of remorse.

29. On 25 September 2009 the second applicant was sentenced to an eighteen-month detention and training order.
He was given credit for his guilty plea, and account was taken of his young age, the fact that he left Vietnam to
make a better life for himself and his “excellent progress” in custody.
_III. SUBSEQUENT FINDINGS REGARDING THE SECOND APPLICANT'S STATUS AS A VICTIM OF_
_TRAFFICKING_

30. In April 2010 the second applicant's new solicitor referred his case to the National Society for the Prevention of
Cruelty to Children National Child Trafficking Advice and Information Line (hereinafter, “NSPCC NCTAIL”).

31. In an interview with a social worker from NSPCC NCTAIL, the second applicant indicated that his family had
paid for him to travel to the Czech Republic after he was assaulted by police and almost arrested during an antigovernment protest in Hanoi. He flew alone to the Czech Republic, where he was met by a man who took his
passport from him. He stayed in the man's house for around two weeks, during which time he had to stay in his
room unless he was washing or cleaning. Together with two women, he was then transported to London by lorry.
Upon arrival a man picked the three passengers up and drove them to the women's house. From there he called his
mother to obtain the contact details of his cousin in London. He then contacted his cousin and the women he
travelled with took him to meet her at a market. They told him to return to the meeting point the next day and they
would arrange work for him. The second applicant stayed with his cousin for one night but as he did not know her
well – and did not know her husband at all – he did not want to intrude any further. He therefore went back to the
meeting point, where he met H.

32. Based on the interview, the social worker concluded that there were reasonable grounds for considering the
second applicant to be a victim of child trafficking from Vietnam to the United Kingdom. In particular, she noted that:
there appeared to be clear links between the people who arranged his travel out of Vietnam, those who held him in
the Czech Republic and moved him to the United Kingdom, and those who exploited him for work in the cannabis
factory; he was either not allowed out of or was locked in the premises where he was harboured or exploited by
agents; he was not informed of the criminal nature of the work in the cannabis factory; he was locked into the
cannabis factory and told he would be killed if he left; and he was forced to live in unhealthy conditions at the
factory, without payment.

33. The second applicant's case was subsequently considered by one of the two Competent Authorities (see
paragraph 75-76 below). On 16 November 2010 UKBA notified him that the Competent Authority had concluded
that he had been trafficked. While it considered that certain aspects of his claim to have been trafficked undermined
his credibility – the fact that he was allowed to leave the agents' supervision and stay with his cousin for one night,
the fact that he had not been consistent regarding the existence of telephones in the cannabis factory, and the fact
that he was allowed out of the cannabis factory – it was accepted that on the balance of probabilities there were
grounds to believe that he had been trafficked into the United Kingdom. In its view, the account of the second
applicant's recruitment and movement from Vietnam to the United Kingdom satisfied the definition of trafficking
under the Anti-Trafficking Convention for the purposes of labour exploitation. It also considered there to be a link
between those who arranged his travel out of Vietnam, those who held him in the Czech Republic and brought him
to the United Kingdom, and those who put him to work in the cannabis factory, and that he was in a position of
dependency and vulnerability, which could go some way to explaining why he was allowed out of the factory and
why he returned. As for the work he was doing, he was found in a place of exploitation, which was guarded and
locked from the outside and the living and working conditions were consistent with those found in exploitative
situations.


-----

34. However, as he had turned eighteen and was not receiving any counselling, it was not accepted that he was a
person “in need”. As such, he was no longer considered to be a victim of human trafficking and was not eligible for
a residence permit.

35. The second applicant's solicitor also instructed a psychologist, who prepared a report in March 2011. The report
was based on the account that the applicant provided to the NSPCC NCTAIL interviewer. The psychologist
concluded that he was suffering psychological distress as a result of multiple traumatic experiences as a minor,
including an assault by the police in Vietnam and being trafficked to the United Kingdom. His symptoms met the
criteria for a diagnosis of post-traumatic stress disorder (hereinafter, “PTSD”) and a major depressive disorder. In
the psychologist's opinion, his symptoms were consistent with his account of his history. Furthermore, the
psychologist considered that the account given by the second applicant to the NSPCC interviewer was “broadly
consistent” with the account given to the police, and the minor inconsistencies could be explained by his PTSD. In
view of his history with the police in Vietnam, he would have been scared, angry and confused following his arrest.
In contrast, the NSPCC NCTAIL interview was carried out in a less distressing context, by a professional
experienced in dealing with child victims of human trafficking.

36. On 28 June 2011 a Special Casework Lawyer from the CPS reviewed the second applicant's case in light of
updated guidance from the CPS and the conclusions of NSPCC NCTAIL and UKBA. Having particular regard to the
fact that the second applicant was a child of mature years, the inconsistencies in the accounts he had given, the
fact that he had a mobile phone and could have summoned help, the fact that he was allowed to see his cousin and
was not held on the factory against his will, the absence of physical injury to him or any of the other “gardeners”, the
fact that he had a sum of money on him when he was recovered, and the possibility that he could have escaped
from the cannabis factory, she remained firmly of the view that he was not a victim of trafficking and the public
interest would require a prosecution. In reaching this conclusion she considered that the second applicant's initial
accounts (see paragraph 20 and 21 above) were probably nearest to the truth.

37. On 7 November 2011 NSPCC NCTAIL produced a supplemental report. In it, the social worker who prepared
the previous report had regard to further documentation primarily related to the criminal proceedings and
considered whether it was necessary to change the opinion set out in the earlier report (see paragraphs 31-32
above). She concluded that there was no new material in these documents which would cause her to change her
professional opinion. In fact, she considered that the material in some of the documents combined with her
increased experience in the area of child trafficking strengthened her conclusion that the second applicant was a
victim of trafficking at the time of his arrest. In this regard, she pointed out that accounts given by potential child
victims of trafficking to different professionals, in different contexts, were rarely entirely consistent with each other.
_IV. THE APPLICANTS' APPEAL AGAINST CONVICTION AND SENTENCE_

38. The first applicant sought permission to appeal – out of time – against conviction and sentencing. He argued
that he should have been advised to vacate his plea and an application to stay the proceedings should have been
made because he was a credible victim of trafficking and, as such, should not have been prosecuted. He also
complained that there was no appropriate adult present when he decided not to change his plea, and that the CPS
failed to confirm why it was in the public interest to prosecute.

39. As it was one of the first cases in which the problem of child trafficking for labour exploitation was raised
following the coming into force of the Council of Europe Convention on Action Against Trafficking in Human Beings
(“the Anti-Trafficking Convention”), permission was granted. The court commented

“…it does appear to the court that there are two matters of potential concern. First, there is an appearance that
something has gone wrong when one arm of the State (the Home Office) has accepted that a person has been
trafficked, but another arm of the State (CPS) has reached the opposite conclusion seemingly without
knowledge of the former. It is arguable that as a matter of public law once the government, through the Home
Office, has accepted that a person has been trafficked, the CPS ought to proceed on the same basis unless
there is some strong reason to do otherwise. Secondly, the applicant appears not to have been given adequate
advice about his position, which was an unusual one.”


-----

40. The second applicant also sought permission to appeal out of time against his conviction and sentence. In his
perfected grounds of appeal against conviction he argued, inter alia, that his conviction was unsafe because as a
minor and victim of trafficking and forced labour contrary to Article 4 of the Convention he had been entitled to
protection rather than prosecution. In particular, he argued that the CPS should have carried out a much greater
investigation into whether he had been trafficked into the United Kingdom and exploited in a cannabis factory. He
relied in part on the evidence of a Children's Services Practitioner at NSPCC NCTAIL who, referring to guidance
published by the CPS and the Association of Chief Police Officers (hereinafter, “ACPO” – see paragraph 74 below),
argued that the appropriate response in the second applicant's case would have been for the police to have made a
referral to the local authority children's services as soon as he was recovered from the cannabis factory. The police
should then have shared as much information as possible to help children's services undertake the appropriate
trafficking assessment and other welfare needs should have been identified and responded to within a safeguarding
and child protection context. The grounds of appeal also referred to a report by the Child Exploitation and Online
Protection Command (hereinafter, “CEOP”, a National Crime Agency – see paragraphs 81-83 below) which
indicated that in spite of the fact that any child identified in a cannabis factory was likely to be a victim of trafficking,
there had been a trend towards prosecution rather than protection of Vietnamese children found on these factories.

41. The second applicant further argued that the common law defence of duress was unsuitable to cases
concerning child trafficking victims, since a trafficked child could not in law consent to his or her own trafficking.

42. Permission was granted and his appeal was joined to that of the first applicant.

43. In a judgment handed down on 20 February 2012, the Court of Appeal found that Article 26 of the Anti
Trafficking Convention (the so‑called “non-punishment provision” – see paragraph 103 below) was directed at

sentencing decisions as opposed to prosecutorial decisions and could not, therefore, be interpreted as creating
immunity for victims of trafficking who had become involved in criminal activities; nor could it extend the defence of
duress by removing the limitations inherent in it. Summarising the essential principles derived from recent case-law,
it noted that the implementation of the United Kingdom's obligations under the Anti-Trafficking Convention was

“normally achieved by the proper exercise of the long established prosecutorial discretion which enables the
Crown Prosecution Service, however strong the evidence may be, to decide that it would be inappropriate to
proceed or to continue with the prosecution of a defendant who is unable to advance duress as a defence but
who falls within the protective ambit of Article 26. This requires a judgment to be made by the CPS in the
individual case in the light of all the available evidence. That responsibility is vested not in the court but in the
prosecuting authority. The court may intervene in an individual case if its process is abused by using the
'ultimate sanction' of a stay of the proceedings. The burden of showing that the process is being or has been
abused on the basis of the improper exercise of the prosecutorial discretion rests on the defendant. … The fact
that it arises for consideration in the context of the proper implementation of the United Kingdom's Convention
obligation does not involve the creation of new principles. Rather, well established principles apply in the
specific context of the Article 26 obligation, no more, and no less. Apart from the specific jurisdiction to stay
proceedings where the process is abused, the court may also, if it thinks appropriate in the exercise of its
sentencing responsibilities implement the Article 26 obligation in the language of the article itself, by dealing
with the defendant in a way which does not constitute punishment, by ordering an absolute or a conditional
discharge.”

44. The court identified the principal issue in the appeals to be whether the process of the court was abused by the
decision of the prosecuting authority to prosecute. However, having fully considered the facts of the applicants'
cases, the court dismissed their appeal against conviction.

45. In respect of the first applicant, the court stated that:

“Opening the case for the Crown, counsel focused on the evidence which suggested that the appellant could
not be described as a trafficked person. He was found with cash on him. He was provided with a mobile phone
and credit for use with that phone. The house was an ordinary house, far from a make-shift prison, where the
defendant said he had been left and provided with groceries at weekly intervals. The account given by the


-----

appellant in interview in which he said that he arrived seeking an adoptive father was contrasted with what he
said in the Trafficking Assessment. When asked questions to identify who this adoptive father might be, he was
unable to provide any comprehensible explanation. His movements about the country after his arrival, and his
allegedly accidental presence in Cambridge, when he had simply bumped into two further co-nationals who
offered him the opportunity of going to Cambridge was inconsistent with having been the victim of trafficking.
Over the months the account had developed of some 'mild pressure or threats' being put to the defendant but
the Trafficking Assessment itself provided information that the appellant was clear that his family in Vietnam
was not under threat, that there were no debts owed to anyone in Vietnam, and that he had not been abused
prior to his arrest. The Crown examined the facts in detail and had come to the conclusion that there was no
'reason whatever to revise their initial assessment of the public interest that the appellant' was someone who
should be prosecuted.

Given the meticulous care and detailed examination of all the relevant evidence made both by counsel for the
Prosecution and the Crown Prosecution Service, and the fair and balanced approach taken by Judge [C]
throughout these protracted proceedings, the prospects for this appeal were unpromising.

In essence, the argument advanced by [counsel] proceeds on the basis that given the information available to
the defence at the time when the case proceeded to sentence, an application should have been made to
vacate the guilty plea. However, as he accepts, there was nothing to suggest that the plea could be considered
a nullity, or that the theoretical defence of duress would have had any realistic prospect of success.
Nevertheless if the application to vacate the plea had been made, and then granted, on the basis of the
appellant's youth and the findings in his favour in relation to trafficking, the judge would then have been invited
to consider an application to stay the prosecution, and presumably, that [sic.] if such an application had been
made, the judge would have granted it. This is all entirely speculative, and does not address the reality. Even if
the judge might have been persuaded to allow the appellant to vacate his plea for the argument in support of
an order for the stay of proceedings to be mounted, the inevitable outcome of any such hearing would have
been that the decision to continue the prosecution was fully justified. On the facts, the decision to prosecute
was amply justified. That would have been the view formed by Judge [C], and it is the unhesitating conclusion
which we have reached.”

46. The Court did, however, allow the first applicant's appeal against sentencing as it found that, given his age and
guilty plea, a twelve month custodial sentence would have been sufficient.

47. With regard to the second applicant, it noted that in taking the decision to prosecute him, the CPS did not have
the advantage of UKBA's finding that he was a child victim of human trafficking. However, even if that report had
been available, UKBA and the CPS exercised different responsibilities and neither could bind the other. The court
made the following remarks:

“In essence, the argument in support of the contention that the conviction is unsafe was, at any rate to begin
with, based on the stark proposition that everyone involved in the case missed the real point, that the appellant
fell squarely within the provisions of Article 26 of the Convention, and that he had been trafficked into the
country. [Counsel] argued that the Crown Prosecution Service should have carried out a much greater
investigation into the question whether the appellant had been trafficked into this country and exploited in the
cannabis factory; that those who acted for the appellant should have alerted the Crown Prosecution Service to
the same problem and invited them to conduct further investigations; and indeed at one stage that the judge
herself had been remiss in failing to recognise the problem and requiring its further investigation.

[Counsel] advanced sustained submissions critical of the process of which the sentence was the culmination.
In part he relied on the contemporaneous Guidance and Codes of Practice which form part of the publications
noted earlier in the judgment. On close analysis his submissions appeared to mean the many thousands of
individuals who might, in the course of their duties, become involved in the investigation and prosecution of
offences should be deemed to know and fully appreciate the ambit and potential impact of every single
publication offering guidance or advice whenever an individual who may possibly fall within the Convention is
arrested. This is somewhat unrealistic. Although there must, inevitably, be broad understanding of the way in


-----

which different bodies vested with these responsibilities are operating, the CPS, or ACPO, or indeed each
other responsible body, cannot immediately appreciate every item of guidance or advice issued by every other
body. In this particular case, for example, the Child Exploitation and On Line Protection Centre representing
ACPO issued its report on the very day on which [the applicant] himself was interviewed after his arrest. In any
event, it appears to us that in the initial stages after the implementation of the Convention the primary focus of
attention was the distinction between those who were 'smuggled' into the country and those who were
'trafficked' into it. But, more important, the criticisms ignore the facts, and in particular the impact of the
appellant's accounts in interview, to his lawyers, and the writer of the Pre-sentence Report about the
circumstances in which he became an immigrant into this country and worked in the cannabis factory. These
accounts were, it must be emphasised, the instructions and the explanations provided by the appellant himself.
The evidence available to those who were acting for him, that he had been 'smuggled' as a volunteer, was
unanswerable. Moreover it appeared that he made the choice to start working with [H] rather than find work at
or near the safe home provided by his cousin, and that he chose to work, at first without apparent difficulty.
Thereafter the appellant's period of work in the cannabis factory before his arrest was very short lived. It had
been interrupted by a not insignificant break. He was in possession of cash. After his arrest he had continued in
communication with his family in Vietnam and his cousin in England, without suggesting that he had made any
complaint or expressed any concern.

Despite [Counsel's] efforts to persuade us to the contrary view, at this date there was no evidence before the
Crown Court, or for that matter the CPS or indeed the defence, which suggested that the appellant had been
trafficked into this country, or that he fell within the protective ambit of Article 26. Rather the effect of the
evidence was that he was a volunteer, 'smuggled' into this country to make a better life for himself and that he
had a home with a family member to which he could have gone and where he would have been welcome. The
essential point in mitigation, correctly taken on the basis of the appellant's instructions, was that he was very
young, and in a vulnerable position as an illegal immigrant, and that in his short time working in the cannabis
factory, like his co-defendants, he had been exploited by others. That provided real mitigation, but in the light of
the facts as they appeared to be, and on the basis of the Guidance to Prosecutors then current, the decision to
prosecute rather than to conduct further investigations did not involve any misapplication of the prosecutorial
discretion sufficient to justify the conclusion that this prosecution constituted an abuse of process on the basis
of a breach of Article 26 of the Convention.”

48. The court also expressed doubts about the value of the expert evidence which came to light following the
second applicant's conviction and sentence (see paragraphs 30-37 above). This was not to impugn the good faith
of the experts, but rather an acknowledgment of the fact that their conclusions were dependent on the second
applicant's account of events. In addition, the new material did not support the contention that he was a victim of
forced labour. On the contrary, it suggested that he chose to work in the cannabis factory when he had available to
him a safe home with a family member, and the evidence suggesting that he was “compelled” to work in those
conditions was at best “nebulous”. Consequently, his conviction could not be said to be unsafe.

49. However, in view of the second applicant's young age, his guilty plea and the extremely short period he was
working in the cannabis factory, the court indicated that it should have reduced his sentence to a four month
detention and training order.

50. In conclusion, the Court stated that:

“Just because the issues in cases which involve Article 26 of the Convention are often extremely sensitive, we
have examined a vast bundle of post-conviction evidence, much of which is, on analysis, repetitive. We have
also examined numerous publications and considered all the expert evidence. In the context of fresh evidence
we shall identify a series of considerations of broad general effect.

…

d) It has been made plain in numerous decisions of this court, that a defendant is provided with one opportunity
to give his or her instructions to his legal advisors. His defence is then considered and advanced and he is


-----

advised about his plea in the light of those instructions. It is only in the most exceptional cases that the court
would consider it appropriate to allow a defendant to advance what in effect would amount to fresh instructions
about the facts for the purposes of an appeal against conviction. There is no special category of exceptionality
which arises in the context of Article 26.”

51. Both applicants applied for leave to appeal to the Supreme Court. The first applicant asked that the following
points of law be certified: whether the exercise of discretion by the CPS as to whether to prosecute a child found by
the Competent Authority to be the victim of trafficking exhausted the United Kingdom's obligations under domestic
and international law for that child; and on what standard of proof the CPS had to find the child a credible victim of
trafficking for the child not to be prosecuted. The second applicant invoked Article 4 of the Convention and
submitted that the facts of the case raised a question concerning the extent to which the CPS should give weight to
the positive findings of those given the responsibility for determining the status of a child who may have been
trafficked.

52. The applications for permission to appeal to the Supreme Court were refused.
_V. SUBSEQUENT PROCEEDINGSA. Reconsideration of the first applicant's Conclusive Decision_

53. On 22 January 2014 the Treasury Solicitors asked that the first applicant's Conclusive Decision (see paragraph
13 above) be reconsidered based on the information contained in the CPS file and the comments made by the
judge in sentencing him.

54. In a decision dated 31 July 2014 the Competent Authority indicated that the Conclusive Decision would be
maintained. In its opinion, the information provided did not change the key points of the case which were that the
first applicant was found inside a cannabis factory when he was a minor. According to the Palermo Protocol and the
Anti-Trafficking Convention, in order to be considered a victim of human trafficking three constituent elements
usually had to be present: the person had to be subject to the act of recruitment, transportation, transfer, harbouring
or receipt (action); by means of threat of force or other form of coercion (means); for the purpose of exploitation,
including, inter alia, forced labour or services (purpose). However, the “means” element was not required where the
individual was a child as they could not give informed consent. In the first applicant's case, he worked for other
people as a gardener so he was recruited. In addition, he was locked in the property which was considered to
constitute harbouring. Finally, the work that he did was illegal, therefore the benefits that he received for doing it
were not proportionate to the work that he was required to do. Therefore, in the view of the Competent Authority it
was very clear that the first applicant had been trafficked. Insofar as the judge at his criminal trial had doubted that
he was trafficked, his findings relating to credibility related to peripheral issues that did not go to the core of the
elements that made up the definition of trafficking.
_B. The first applicant's further appeal_

55. On 13 December 2013 the first applicant sought a review of his conviction based on new evidence and new
legal arguments. The former constituted fresh medical evidence indicating that the first applicant had, on the
balance of probabilities, Asperger's Syndrome together with symptoms of PTSD and, as a consequence, was likely
to have been socially naïve and vulnerable to exploitation. In respect of the latter, the first applicant argued that the
Prosecution's failure to conduct a trafficking investigation was in breach of Article 4 of the Convention and rendered
the decision to prosecute unlawful. Furthermore, the Prosecution had failed to give any proper consideration to the
fact that the first applicant was a minor who had been assessed by both UKBA and social services as having been
trafficked.

56. On 14 April 2016 the Criminal Cases Review Commission (hereinafter, “the CCRC”) decided to refer the first
applicant's case back to the Court of Appeal on the following grounds: there was new evidence available to show
that he should have been recognised by the CPS as a credible child victim of trafficking and was compelled to
commit a criminal offence as a direct consequence of his trafficked situation; that there was a real possibility that
the Court of Appeal would vacate his guilty plea and find that it was an abuse of process to prosecute him without
due regard to the United Kingdom's obligations under Article 26 of the Anti-Trafficking Convention; and that there
was therefore a real possibility that his conviction would be quashed. It noted, in addition, that the 2009 CPS


-----

guidance appeared to be defective; while it made reference to the degree of duress or coercion to which child
victims may be subject, it failed to underline that compulsion to commit an offence was not required.

57. The first applicant's appeal was heard together with five other appeals in which convicted defendants argued
that they should not have been prosecuted as there was a nexus between their crimes and their status as victims of
trafficking.

58. The first applicant's grounds of appeal were (i) that if the information which subsequently came to light had been
known by the CPS prior to the decision to prosecute, and had the Article 26 guidance been applied to those facts,
the CPS and/or the Court of Appeal would not have concluded that it was in the public interest to prosecute him; (ii)
that the Crown misdirected itself by importing the requirement of force/coercion into the question of whether he was
a trafficked child within the meaning of Article 26; (iii) that the Crown, in assessing whether he was an exploited
child, took into account immaterial considerations and failed to take into account material considerations; (iv) that
the Crown failed to grasp the central relevance of whether he had been trafficked to the public interest in his
prosecution; and (v) that the decision to prosecute him and to preclude the application of Article 26 was rendered
unlawful by the failure to prompt a criminal investigation into whether he was trafficked or not – as required by
Article 4 of the Convention – which would have informed the public interest decision.

59. Prior to the hearing the first applicant's representatives prepared a note on Competent Authorities to assist the
Court of Appeal in considering the interplay between the Competent Authority's identification of a potential victim
under the National Referral Mechanism and how this fitted within the criminal justice framework. It noted that there
was a procedural obligation on the State – which constituted a procedural obligation under Article 4 of the
Convention – to investigate situations of potential trafficking. Both the Competent Authority and the Local Authority
had assessed and identified the first applicant as a trafficked child. This information had triggered a positive
obligation on the police and the Crown to conduct an Article 4 compliant investigation into the allegation of child
trafficking. They both had a number of opportunities to discharge that obligation but failed to do so. Both the
Competent Authority and the Local Authority had, however, acted in accordance with their responsibilities. The
Crown should not, as a result, be able to pray in aid their Article 4 failings, and those of the police, to undermine the
assessments of the Competent Authority and the Local Authority.

60. Before the Court of Appeal Anti-Slavery International submitted, as interveners, that in order to comply with
international conventions the court should develop the law of duress so that persons who could not avail
[themselves of section 45 of the Modern Slavery Act 2015 (which reflected the “non-punishment provision” in the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
Anti-Trafficking Convention – see paragraph 103 below) because it was not in force at the relevant time would be in
the same position as those who could rely on it.

61. Judgment was handed down on 9 February 2017. The Court of Appeal took the view that even prior to the
[coming into force of the Modern Slavery Act 2015 the law operated in practice in a way entirely consistent with the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
United Kingdom's international obligations. It therefore rejected any suggestion that the current approach –
particularly in respect of the defence of duress – should be revised for cases not covered by the 2015 Act. In the
case of minors, the court reiterated that once it was established that a child was the victim of trafficking for the
purposes of exploitation, the relevant question was whether there was a sufficient nexus between the trafficking and
the offence; it was not necessary to show there was compulsion to commit the offence (as would be required in the
case of an adult). Although the court accepted that this was not clear from the 2009 CPS guidance, both the 2011
and the 2015 guidance were more explicit.

62. With regard to the relationship between the Competent Authority (see paragraphs 75-76 below) and the CPS,
the court noted that the latter was not bound by a decision of the former. It continued:

“Where there is an issue as to whether a person is a victim of trafficking for the purposes of exploitation whilst a
prosecution is being considered or is in progress, the CPS and police are able to refer to the Competent
Authority the case of a person in respect of whom there may be evidence of that person being a victim of
trafficking. Provision is made in the Guidance to the Competent Authority for cooperation with the police and
CPS in all cases before the conclusion of the prosecution. We were told that the cooperation has been


-----

developed so that during the procedures for considering prosecution every effort is made to reach a common
view on whether the evidence points to the person being a victim of trafficking. That is plainly of the greatest
importance, as the cogency of the evidence which may be relied on by the Competent Authority must be
subject to thorough forensic examination when the CPS is considering the question of nexus and whether it is
in the public interest to prosecute.

However, in respect of a person claiming after conviction to be a victim of trafficking, there is no clear guidance
on or process in respect of co-operation with the CPS or in obtaining court documents. These appeals have
shown that it would [be] desirable for much clearer guidance and processes to be developed between the CPS
and the Competent Authorities in cases where the claim to be a victim of trafficking is made after conviction. It
is important to appreciate a court will bear the Competent Authority's conclusion very much in mind but will
examine the question of the cogency of the evidence on which the Competent Authority relied and subject the
evidence to thorough forensic examination. It does not follow from the fact than an individual 'fits the profile' of
a victim of trafficking that they are necessarily the victim of trafficking. A careful analysis of the facts is required
including close examination of the individual's account and proper focus on the evidence on the nexus between
the trafficking and the offence with which they are charged.”

63. In the first applicant's case, the Court of Appeal was satisfied that his criminality or culpability had not been
extinguished or significantly reduced to such a level that he should not have been prosecuted in the public interest.
It said:

“This same ground of appeal albeit differently expressed was at the heart of the appeal on the last occasion in
2012. As we have set out, the court held that the decision to prosecute was amply justified. This is not a case
therefore where the court or a defendant's lawyers have missed the opportunity to review an offender's status
as a possible victim of trafficking and the nexus with the offence. This was an issue explored with great care
and in great detail at the Crown Court and by this court.

It would require a compelling piece of fresh evidence or line of argument to persuade us to re-tread welltrodden ground. In the appellant's case, there is in truth very little by the way of fresh evidence or fresh
argument. The Home Office's determination that the appellant has been trafficked was before the Crown Court
and the Court of Appeal.

The only "fresh evidence" is the medical report that the appellant is on the Asperger's spectrum and is socially
naïve. The submissions to us have made what can be made of that evidence, but we bear in mind the
observations of this court in the earlier appeal … as to the limited assistance given by expert reports that rely
so heavily on the account given by the applicant where it differed from earlier accounts. In our judgement,
neither the medical report nor its support for the Home Office's conclusion is enough to undermine the
appellant's plea of guilty or the court's conclusions on the last occasion that the decision to prosecute in the
public interest was amply justified.

The appellant, who was very nearly an adult, stayed in a house as a gardener of cannabis plants. He was not a
prisoner, he had a significant quantity of cash (for no obvious reason) and he had access to a telephone. His
explanation of his presence at the house was unsatisfactory and his account of how he got there far from
consistent. On those facts, it was open to the Crown to decide that the prosecution should continue as the
relevant nexus in the case of a child victim of trafficking had not been established.

We reject the assertion that the Court on the last occasion applied the wrong test as to the compulsion required
in the case of a child. The judgment begins with a clear statement of all the relevant principles in relation to
trafficking including the relevant principles as far as child victims are concerned. The court did not proceed on
the basis the appellant had to establish compulsion before his plea could be vacated. … [T]he paragraph in
which reference is made to compulsion and which is the subject of criticism did not relate to this appellant. In
paragraph 90 of its judgment on the earlier appeal the court was addressing a particular issue in relation to the
co-accused as we have explained. The Crown and this court on the last appeal considered the nexus between


-----

the trafficking and the offence on the correct basis; it did not suggest that there had to be evidence of
compulsion.”

64. The first applicant applied to the Court of Appeal for a certificate that points of law of general public importance
were involved in the decision of 9 February 2017 which ought to be considered by the Supreme Court. Those points
concerned how the prosecuting authorities and the courts should approach the decision as to whether it is in the
public interest for a prosecution to proceed where it is alleged that the suspect is a victim of trafficking; whether the
CPS and the criminal court should be bound by a finding of the Competent Authority unless it would be
unreasonable on the facts for them to be so bound; and whether the requirement of “compulsion” should be omitted
in the case of child victims of trafficking.

65. That application was refused on 21 March 2017.

**[RELEVANT LEGAL FRAMEWORK AND PRACTICEI. DOMESTIC LAW AND PRACTICEA. Modern Slavery Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)**
_[2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

[66. The Modern Slavery Act 2015 (“the 2015 Act”), which came into force on 31 July 2015, made comprehensive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
provision in respect of human trafficking.

67. Section 45 sets out the conditions which have to be satisfied for a defence to arise where there is a nexus
between trafficking and a crime committed:

“45. Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant characteristics
would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of slavery or
a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant characteristics
would do that act.

(5) For the purposes of this section—


-----

“relevant characteristics” means age, sex and any physical or mental illness or disability;

“relevant exploitation” is exploitation (within the meaning of section 3) that is attributable to the exploited person
being, or having been, a victim of human trafficking.

…”

68. Prior to the coming into force of the relevant provisions of the 2015 Act, there was no statutory provision in the
United Kingdom which transposed into domestic law the State's obligations under international conventions towards
those victims of human trafficking who committed crimes where there was a nexus between the crime and the
trafficking. Therefore, in cases where the defence of duress was not likely to be applicable, it was left to the
judiciary and to the Crown/CPS to develop a legal regime in which the State's international obligations were given
effect.
_B. Relevant guidance1. The Government_

69. In 2007 the Government published “Safeguarding Children who may have been Trafficked”. The publication
provided the following definitions:

“The most common terms used for the illegal movement of people – 'smuggling' and 'trafficking' – had very
different meanings. In human smuggling, immigrants and asylum seekers pay people to help them enter the
country illegally, after which there is no longer a relationship. Trafficked victims are coerced or deceived by the
person arranging their relocation. On arrival in the country of destination, the trafficked victim is forced into
exploitation by the trafficker or the person into whose control they are delivered or sold.”

70. The publication also drew attention to the (then current) Code for Crown Prosecutors, which provided that
children coerced into criminal activity were victims of abuse and should not be criminalised. Even when the defence
of duress would not be available, the decision whether it was in the public interest for the child to be prosecuted
was directly engaged.

71. The United Kingdom Government “Trafficking Toolkit” was published in October 2009. Referring to the definition
of trafficking found in Article 4 of the Anti-Trafficking Convention, it underlined the difference between trafficking and
smuggling, both by reference to the nature of the crime and the relationship between the person organising the
entry of the migrant and the migrant himself. Specific attention was drawn to the Anti-Trafficking Convention and the
measures designed to protect victims of trafficking, including “the possibility of not imposing penalties on victims for
their involvement in unlawful activities, if they were compelled to do so by their situation”.
_2. The CPS_

72. In December 2007 the CPS published guidance on the “Prosecution of young defendants charged with offences
who might be trafficked victims”. It highlighted the cultivation of cannabis plants as an offence likely to be committed
by child victims of trafficking. According to the guidance, prosecutors should be alert to the possibility that in such
circumstances a young offender could actually be a victim of trafficking and have committed the offences under
coercion. Where there was clear evidence that a youth had a credible defence of duress, the case should be
discontinued. Where the information concerning coercion was less certain, further details should be sought from the
police and youth offender teams so that the public interest in continuing a prosecution could be considered
carefully. Any youth who might have been trafficked should be afforded the protection of child care legislation if
there were concerns that he or she had been working under duress or if his or her wellbeing was threatened.

73. The CPS Guidance on Human Trafficking and Smuggling (which was last updated, prior to the applicants'
arrest, on 4 February 2009) identified two offences highlighted by recent cases as likely to have been committed by
child trafficking victims, one of which was the “cultivation of cannabis plants”. It continued:

“Prosecutors should be alert to the possibility that in such circumstances a young offender may actually be a
victim of trafficking and have committed the offences under coercion.


-----

Children who have been trafficked may be reluctant to disclose the circumstances of their exploitation on arrival
into the UK for fear of reprisals by the trafficker or owner, or out of misplaced loyalty to them. This reluctance to
disclose the real circumstances in which they have arrived into the country may have implications for a number
of youth criminal justice processes.

The child may have been coached by their trafficker to not disclose their true identity or circumstances to the
authorities. In some cases, they may have been coached with a false version of events and warned not to
disclose any detail beyond this as it will lead to their deportation.

In a similar way to adults, children may have been subject to more psychological coercion or threats, such as
threatening to report them to the authorities; threats of violence towards members of the child's family; keeping
them socially isolated; telling them that they/their family owes large sums of money and that they must work to
pay this of; or through juju or witchcraft practices.

Where there is clear evidence that the youth has a credible defence of duress, the case should be discontinued
on evidential grounds. Where the information concerning coercion is less certain, further details should be
sought from the police and youth offender teams, so that the public interest in continuing a prosecution can be
considered carefully. Prosecutors should also be alert to the fact that an appropriate adult in interview could be
the trafficker or a person allied to the trafficker.

Any youth who might be a trafficked victim should be afforded the protection of our childcare legislation if there
are concerns that they have been working under duress or if their wellbeing has been threatened. Prosecutors
are also alerted to the DCSF and Home Office Guidance Safeguarding children who may have been trafficked.

…

The UK Human Trafficking Centre (UKHTC) will make relevant enquiries to establish whether they may be a
potential trafficking victim. When information reveals the possibility that they may be trafficked the prosecutor
and officer in charge of the case will be contacted to ensure that policy guidance has been followed and the
evidence re-reviewed in the light of new information. This guidance reflects the judgment in _R v. O_ _[[2008]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_
_[EWCA Crim 2835.”](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_

_3. The Association of Chief Police Officers (“ACPO”)_

74. On 16 August 2010 the ACPO Child Protection and Abuse Investigation Group issued a document entitled
“Position from ACPO Lead's on Child Protection and Cannabis Cultivation on Children and Young People
Recovered in Cannabis Farms”. It provided, insofar as relevant:

“1. Police should be alert to the possibility that any person, adult or child, identified in a cannabis farm could be
a victim of trafficking. CEOP strategic assessments, made up of intelligence submitted by the police, UKBA,
children's services and NGOs, highlight cases of children and young people being trafficked into the UK and
exploited in cannabis farms. The intelligence indicates that sometimes, as a consequence of the need for more
awareness of the problem, young persons are not identified as victims, statutory defences are not recognised
and the individuals end up being charged, prosecuted and convicted of offences committed whilst being
exploited. This is contrary to police protection obligations where the young person has been a victim of crime. It
is also contrary to responsibilities in respect of child trafficking as enumerated under the Council of Europe
(COE) Convention on Action Against Human Beings, which indicates that any person under the age of 18
years cannot consent to their own trafficking. The ACPO Lead on Child Protection and Abuse investigation,
and the ACPO Lead on Cannabis Cultivation have endorsed the following approach.

2. In line with the 'Safeguarding Children Who May Have Been Trafficked' guidance, police should work with
local authorities to ensure early identification of trafficked victims before entering any suspected cannabis farm.
In the planning stage of any proactive operations or other police interventions on cannabis farms, dual
operational planning should focus not only on the recovery of illegal drugs and the arrest of members of
criminal enterprises, but also on the safeguarding of any children who are being exploited on the premises.
Inter-agency strategies and protocols for early identification and notification should be set in place to advance


-----

in collaboration with local children's services and UKBA representatives. The police team leading on the
preparation of the proactive operation should consult with the force Child Protection team and, where it is
anticipated that child victims of trafficking may be present, utilise Child Protection officers in the operation to
ensure that safeguarding actions take place.

3. Every individual identified as, or claiming to be, a child or young person in a cannabis farm should be
assessed on a case by case basis to ascertain whether they may have been trafficked. Where circumstances
give rise to reasonable suspicion that they are being exploited or abused, a child welfare response should be
taken.

4. No decision to progress charges against such individuals should be made until all relevant assessments
have been undertaken. Prosecutors and Duty Solicitors have a duty to make full and proper enquiries in
criminal prosecutions involving individuals who may be victims of trafficking and to be proactive in establishing
if a suspect is a potential victim of trafficking. Therefore, information about concerns of trafficking should be
fully shared with the CPS. Cases of individuals claiming to be under 18 when they are not for tactical purposes
are common. However, in cases of doubt, the young person should be given the benefit of that doubt in
accordance with the COE Convention until information to the contrary is available. Where official records, or
other reliable evidence, are not available to confirm age, a Merton compliant age assessment should be carried
out by the local authority.

5. On recovery of any young person in a cannabis farm s/he should be taken to a place of safety immediately.
A check on PNC or UKBA CID (central Intelligence Database) should be undertaken to ensure that police use
all available resources to find information about the young person.

6. A referral should be made to the local authority children's services for the appropriate assessments.
Children's services should be prepared for this referral, having been involved in the planning stages before
entry into the premises. The local authority representative should be informed of the circumstances in which
the young person was identified and the concerns around trafficking. The police should share as much
information as possible to help children's services undertake the appropriate assessments. A local authority
representative should attend the police station (or other place of safety where the young person is taken) within
an hour of notification to undertake a joint assessment and to produce a protection plan designed to keep the
young person safe. This would require an interpreter who is able to safely communicate with the young person
in their own language.

7. The overall aim of the local authority and police should be to assure the young person that they are safe …

8. Any other welfare needs should be identified and responded to within a safeguarding and child protection
context.

9. All assessments undertaken are to be decided between the local authority and the local police. The
assessments used should be in accordance with existing child protection standards and use the multi-agency
framework which is set out in the 'Working Together to Safeguard Children' guidance (2010). The assessments
will be carried out by the appropriate child protection trained person in the relevant authority and should be
carried out on an ongoing basis. Local authority, police and UKBA leads should meet within five days of initial
joint assessment to discuss debrief of the young person, ongoing strategy and their protection plan.

10. Once the young person is safe and within a more stable environment, the local authority children's services
should conduct a trafficking assessment. … Where a concern of trafficking is confirmed by the assessment, a
referral should be made to the relevant competent authorities within the National Referral Mechanism. …
Safeguarding and child protection processes should be put into place in accordance with the young person's
needs.

… … …


-----

12. If it is suspected that the young person is a potential victim of trafficking, it is the duty of the police, with
assistance from local authorities, to investigate the trafficking allegations according to section 47 of the
Children's Act. It is important that offenders are prosecuted for trafficking crimes in order to protect future
children from exploitation, and to act as a deterrent to others.”

_C. National Referral Mechanism and Competent Authorities_

75. On 1 April 2009, to coincide with the coming into force of the Anti‑Trafficking Convention (see paragraph 102

below) the Government created the National Referral Mechanism (hereinafter, “the NRM”) to provide the framework
for identifying and referring potential victims of modern slavery and ensuring they receive the appropriate support.
To be referred to the NRM, potential victims of trafficking must first be referred to one of the United Kingdom's two
Competent Authorities which are responsible for making conclusive decisions on whether a person has been
trafficked for the purpose of exploitation. The Competent Authorities are the United Kingdom Human Trafficking
Centre, within the National Crime Agency, and the Home Office.

76. The Competent Authorities first make a “reasonable grounds” decision. The threshold for this decision is “I
suspect but cannot prove”, and a positive decision triggers a forty-five day recovery and reflection period. Following
this period, the same Competent Authority should make a “conclusive grounds” decision for which the threshold is a
“balance of probabilities”, that is, that “it is more likely than not” that the person was trafficked.

_[D. Relevant case-law1. R v. O [2008] EWCA Crim 2835](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_

77. The minor appellant in this case had pleaded guilty to an offence of possessing a false identity card with the
intention of using it as her own and was sentenced to eight months' imprisonment less sixteen days spent on
remand. Although “The Poppy Project” (an organisation which supports vulnerable women who have been
trafficked into England and forced into prostitution) alleged that she was a victim of a sex trafficking organisation,
her legal representatives proceeded on the basis of her instructions without regard to the information provided by
The Poppy Project. They did not consider whether she might have been the victim of trafficking or what the
consequences of her true age might be. Her representatives were also unfamiliar with two protocols on the
prosecution of young offenders and defendants charged with immigration offences who might be trafficked victims;
and on prosecution of young offenders charged with offences who might be trafficked victims (see paragraphs 7273 above), even though both protocols were incorporated into the Code for Crown Prosecutors.

78. The appellant appealed against conviction and her appeal was unopposed. In allowing the appeal the court
said:

“There was in this case material before the defence which should plainly have raised at least the apprehension
that this appellant had been trafficked to the United Kingdom for the purposes of prostitution. The defence had
information from her suggesting that she was at most 17, as counsel indeed submitted to the court, and
perhaps only 16. From the custody record the Crown should have appreciated that she might have been a very
young person.

No steps were taken by the defence to investigate the history. No consideration was given by the defence as to
whether she might have a defence of duress. The possibility that she might have been trafficked was ignored.
There is nothing in the transcript to suggest that any thought had been given to the State's possible duty to
protect her as a young victim. Nobody considered that if she was 17 or less, she should not have been in the
Crown Court at all. Counsel for the defence thought it right to refer to 'an inevitable prison sentence'. The judge
passed what she described as an 'inevitable prison sentence' of 8 months. If the appellant was 17 or less, a
sentence of imprisonment as such was unlawful. For good measure the judge sentenced her without a report.

This appeal against conviction must obviously be allowed. We would put it most simply on the footing that the
common law and Article 6 of the European Convention on Human Rights alike require far higher standards of
procedural protection than were given here. There was no fair trial. We hope that such a shameful set of
circumstances never occurs again. Prosecutors must be aware of the protocols which, although not in the text
books are enshrined in their Code. Defence lawyers must respond by making enquiries, if there is before them


-----

credible material showing that they have a client who might have been the victim of trafficking, especially a
young client. Where there is doubt about the age of a defendant who is a possible victim of trafficking, proper
inquiries must be made, indeed statute so required.”

_2. R. v. M(L) [2010] EWCA Crim 2327_

79. In this case, which pre-dated the **_[Modern Slavery Act 2015,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_** the Court of Appeal considered three distinct
appeals concerned with alleged failures to implement Article 26 of the Anti-Trafficking Convention (being the “nonpunishment provision” – see paragraph 103 below). The court made the following comments:

“The United Kingdom has taken extensive steps to discharge its obligations under this convention. There are in
existence criminal offences of trafficking. So far as Article 10 is concerned, a number of bodies, whose purpose
is the identification and assistance of victims, have been established. The United Kingdom Human Trafficking
Centre (UKHTC) is a multi-agency centre, one of whose functions is the identification of those who are or may
be trafficked victims. A National Referral Mechanism (NRM) also exists as a mechanism through which public
bodies, including criminal justice bodies, can refer individual's cases for consideration. In addition there are a
number of third sector organisations whose object is the identification of those who are or may be victims of
trafficking. One such is the Poppy Project, a charity largely funded by the government substantially for this
purpose. There now exist also the Gangmaster's Licensing Authority and a number of other bodies.

These agencies are charged with the identification of persons who have 'reasonable grounds for being treated
as a victim of trafficking'. That test is derived directly from Article 10. When a person is identified as meeting
that threshold test, he or she will be eligible for a number of forms of assistance, including a period of not less
than 30 days for recovery and reflection during which no steps may be taken to repatriate or remove him.
Because it is the trigger for the assistance to victim provisions, the test of reasonable grounds establishes a
comparatively low threshold. If it is met, that does not mean that it has been determined that the person
concerned actually is a victim of trafficking, but rather that there are reasonable grounds to believe that they
may be.

**The application of Article 26**

In England and Wales the implementation of Article 26 is achieved through three mechanisms. First, English
law recognises the common law defences of duress and necessity ('duress of circumstances'). Second,
specific rules have been made for the guidance of prosecutors in considering whether charges should be
brought against those who are or may have been victims of trafficking. Thirdly, in the event that the duty laid on
the prosecutor to exercise judgment is not properly discharged, the ultimate sanction is the power of the court
to stay the prosecution for what is conveniently, if not very accurately, termed 'abuse of process'.

The defences of duress and/or necessity ('duress of circumstances') may be in question where an offence has
been committed by a trafficked victim whose case is that she was coerced into committing it. There is no
special modification of the general law relating to these defences. There are important limitations to both
defences. Duress is a defence (except to murder and attempted murder) if the offence has been committed as
the direct (not indirect) result of a threat of death or serious injury aimed at the defendant or someone
sufficiently close to him. But the defence is not established if there was evasive action which the defendant
could reasonably be expected to take, including report to the authorities, and nor can it be established if the
defendant has voluntarily associated with people in circumstances which amount to laying himself open to the
compulsion to commit offences. For these broad propositions see _R v Z [2005] 2 AC 467. The separate but_
allied defence of necessity or 'duress of circumstances' is available only where the commission of a crime was
necessary or was reasonably believed to be necessary to avoid or prevent death or serious injury where,
objectively viewed, commission of the crime was reasonable and proportionate having regard to the evil to be
avoided or prevented and the crime would not have been committed without that necessity…

The special guidance to prosecutors issued by the CPS in order to comply with the convention imposes on
them a duty which includes but is wider than consideration of these common law defences.


-----

…

The effect of that [guidance] is to require of prosecutors a three-stage exercise of judgment. The first is: (1) is
there a reason to believe that the person has been trafficked? If so, then (2) if there is clear evidence of a
credible common law defence the case will be discontinued in the ordinary way on evidential grounds, but,
importantly, (3) even where there is not, but the offence may have been committed as a result of compulsion
arising from the trafficking, prosecutors should consider whether the public interest lies in proceeding to
prosecute or not.

The first step is not limited to reacting to any assertion of trafficking. Article 10 makes clear that States must
take active steps to consider the question whenever it is a realistic possibility. For obvious reasons, one of the
consequences of trafficking, especially far from home, may be to inhibit the victim from complaining. The vital
additional third obligation is consistent with the requirements of Article 26, which, it is clear, uses the word
'compelled' in a general sense appropriate to an international instrument, and is not limited to circumstances in
which the English common law defences would be established.

…

It is necessary to focus upon what Article 26 does and does not say. It does not say that no trafficked victim
should be prosecuted, whatever offence has been committed. It does not say that no trafficked victim should be
prosecuted when the offence is in some way connected with or arises out of trafficking. It does not provide a
defence which may be advanced before a jury. What it says is no more, but no less, than that careful
consideration must be given to whether public policy calls for a prosecution and punishment when the
defendant is a trafficked victim and the crime has been committed when he or she was in some manner
compelled (in the broad sense) to commit it. Article 26 does not require a blanket immunity from prosecution for
trafficked victims.

It follows that the application of Article 26 is fact-sensitive in every case. We attempt no exhaustive analysis of
the factual scenarios which may arise in future. Some general propositions can perhaps be ventured.

i) If there is evidence on which a common law defence of duress or necessity is likely to succeed, the case will
no doubt not be proceeded with on ordinary evidential grounds independent of the convention, but additionally
there are likely to be public policy grounds under the convention leading to the same conclusion.

ii) But cases in which it is not in the public interest to prosecute are not limited to these: see above.

iii) It may be reasonable to prosecute if the defendant's assertion that she was trafficked meets the reasonable
grounds test, but has been properly considered and rejected by the Crown for good evidential reason. The fact
that a person passes the threshold test as a person of whom there are reasonable grounds to believe she has
been trafficked is not conclusive that she has. Conversely, it may well be that in other cases that [sic] the real
possibility of trafficking and a nexus of compulsion (in the broad sense) means that public policy points against
prosecution.

iv) There is normally no reason not to prosecute, even if the defendant has previously been a trafficked victim,
if the offence appears to have been committed outwith any reasonable nexus of compulsion (in the broad
sense) occasioned by the trafficking, and hence is outside Article 26.

v) A more difficult judgment is involved if the victim has been a trafficked victim and retains some nexus with
the trafficking, but has committed an offence which arguably calls, in the public interest, for prosecution in
court. Some of these may be cases of a cycle of abuse. It is well known that one tool of those in charge of
trafficking operations is to turn those who were trafficked and exploited in the past into assistants in the
exploitation of others. Such a cycle of abuse is not uncommon in this field, as in other fields, for example that of
abuse of children. In such a case, the question which must be actively confronted by the prosecutor is whether
or not the offence committed is serious enough, despite any nexus with trafficking, to call for prosecution. That
will depend on all the circumstances of the case, and normally no doubt particularly on the gravity of the


-----

offence alleged, the degree of continuing compulsion, and the alternatives reasonably available to the
defendant.”

_3. R. v. L(C) [2013] EWCA Crim 991_

80. In this appeal, brought by three children and one adult who were trafficked by criminals and themselves
prosecuted and convicted, the Court of Appeal indicated that

“the distinct question for decision once it is found that the defendant is a victim of trafficking is the extent to
which the offences with which he is charged, or of which he has been found guilty are integral to or consequent
on the exploitation of which he was the victim. We cannot be prescriptive. In some cases the facts will indeed
show that he was under levels of compulsion which mean that in reality culpability was extinguished. If so when
such cases are prosecuted, an abuse of process submission is likely to succeed. That is the test we have
applied in these appeals. In other cases, more likely in the case of a defendant who is no longer a child,
culpability may be diminished but nevertheless be significant. For these individuals prosecution may well be
appropriate, with due allowance to be made in the sentencing decision for their diminished culpability. In yet
other cases, the fact that the defendant was a victim of trafficking will provide no more than a colourable
excuse for criminality which is unconnected to and does not arise from their victimisation. In such cases an
abuse of process submission would fail.”

_E. Relevant reports1. The Child Exploitation and Online Protection Command (“CEOP”): First “scoping report”_

81. CEOP Command is a command of the United Kingdom's National Crime Agency (the United Kingdom's lead
agency against organised crime) which works both nationally and internationally to bring online child sex offenders
before the national courts.

82. Its first “scoping report” published in June 2007 identified Vietnamese boys and girls as a specific vulnerable
group. It noted that some of these children had been found being exploited in cannabis factories while others were
suspected to have been trafficked for the purposes of sexual exploitation. It noted that at least four children
registered in the data set appeared to have been exploited in cannabis factories but were not identified as victims of
trafficking and were arrested for cannabis cultivation. According to the report, if these children had in fact been
trafficked then “this unfortunate consequence” could be attributed to the lack of awareness and capacity in some
forces and CPS areas to recognise the indicators of child trafficking
_2. CEOP: Child Trafficking in the United Kingdom Strategic Threat Assessment (2009)_

83. According to this threat assessment which was published in April 2009, Vietnamese children had the highest
probability of being trafficked than any other profile encountered in the study. The Vietnamese children identified by
CEOP were primarily involved in the cultivation of cannabis. Many were arrested in police raids on cannabis
factories and some were charged, prosecuted and convicted for offences relating to the cultivation of cannabis and
illegally obtaining an electricity supply. Although CEOP noted that both the ACPO and the CPS had issued
guidance on the treatment of children found in such criminal enterprises to ensure that no child was brought before
the courts where the crime committed was a direct result of trafficking, there remained concerns by NGOs that
children were being prosecuted when it was neither appropriate nor in the public interest. It continued:

“[l]ow awareness amongst law enforcement conducting raids could be a factor in the lack of screening for child
trafficking within these situations. … A more targeted focus by police and prosecuting authorities needs to be
placed on those who use children to work in these factories, rather than the children themselves; and forces
should avail themselves of the guidance and tools already available to identify child trafficking when
investigating such cases.”

_3. CEOP: Strategic Overview 2009-10_

84. In this overview CEOP identified the trafficking of Vietnamese children into and within the United Kingdom as
one of the most significant trends during the relevant period. Most of these children were boys aged between
thirteen and seventeen who were exploited as “gardeners” in cannabis factories. According to CEOP, many
Vietnamese minors had been charged, prosecuted and sentenced for the production and supply of cannabis but
there had been no convictions of Vietnamese criminals who trafficked the children into the United Kingdom.


-----

_4. CEOP: Child Trafficking in the United Kingdom Strategic Threat Assessment (2010)_

85. In this report CEOP noted:

“In many cultures, children are expected to work at a young age, often foregoing education. Parents and
children alike may therefore gladly take an opportunity to work abroad in order to earn more money for their
family. The child may even be aware of the conditions, pay and risks involved. The child is unlikely to know
about child protection and human rights legislation in the destination country. It is important for statutory
agencies to recognise that any child working in illegal conditions, no matter how trivial, may potentially be in a
situation of exploitation.”

86. COEP further noted the existence of regional differences between the profiles of trafficking victims. In its
experience, some Vietnamese children were told upfront that they would be working in cannabis factories, and
some stated that they did not know that cannabis was illegal, instead believing that they were entering legitimate
work. It also observed from the dataset many similarities between victim background accounts, which could be an
indication of coaching. In this regard, victims were often coached to provide a vague background story to the
authorities, who would then assume he or she was an economic migrant and thus discount the possibility of
trafficking. This was in itself a measure of control, as the intent was to stall the authorities long enough to return the
victim to the trafficker. The information concerning payment also varied; while some victims stated that they were
not paid, others were able to wire money home to their families. For example, one boy stated that he was paid GBP
100 for one or two months' work at a cannabis factory.

87. The report further stated that there had been

“an increased concern that children are being prosecuted and sentenced for the production and supply of
cannabis, but to date, there have been no convictions (for trafficking offences) of criminals who have trafficked
or exploited these children.”

88. The testimonies of Vietnamese victims suggested similarities in the route taken to the United Kingdom. Many
flew with an agent to Russia and were then transported via lorry to the Ukraine, Poland, the Czech Republic,
Germany and France.

89. Within the United Kingdom the most frequently identified destinations were the West Midlands, East Midlands
and Greater London.

90. All of the children identified in cannabis factories worked as “gardeners”, tending and watering the cannabis
plants. They were often locked in the premises alone and even slept there. Many said that they remained in the
premises for the entirety of their exploitation while those who did venture outside stated that they would be
accompanied by a member of the criminal network.

91. The report further noted that Vietnamese victims tended to be extremely wary of the authorities and
communicated very little about their experiences or their captors. This could have been because they were fearful
for family members or distrustful of the authorities, based either on their experiences in Vietnam or on what their
captors told them.

92. In respect of the prosecution of Vietnamese trafficking victims, CEOP made the following comments:

“Despite the increased awareness raising by CEOP, various children's services, NGOs and other lobbying
groups, children found in cannabis farms are still being treated as offenders rather than victims. The ACPO
Child Protection and Abuse Investigation, in conjunction with CEOP, has produced guidance for procedures to
be taken when a child is found in such a farm, along with age assessment guidance which puts the protection
of the child at the front. Trafficking and age assessments where necessary need to be carried out as a priority,
yet CEOP has evidenced that this does not always occur. Despite having ACPO approval, the guidance is not
mandatory – it is up to individual police forces to adhere to the recommended procedures.”

_5. CEOP: “Police response to recovering a child or young person from a cannabis farm” (2010)_


-----

93. In this report, which was also published in December 2010, CEOP indicated that any child identified in a
cannabis factory was likely to be a victim of trafficking. However, it noted that in spite of this recognition the trend
towards prosecution and not protection of such children had been continuing. Between March 2009 and February

2010 it had identified thirty‑seven Vietnamese children and two Chinese children who were trafficked to the United

Kingdom for the purposes of cannabis cultivation. At least twenty-six had been charged directly for production,
cultivation or supply of cannabis. The cases against thirteen were discontinued but eight of the remaining sixteen
children were found guilty of at least one offence. Six were sentenced to between eighteen months and two years in
young offenders' institutions.
_II. RELEVANT INTERNATIONAL LAW AND PRACTICEA. United Nations Convention against Transnational_
_Organised Crime, 2001 (“the Palermo Protocol”)_

94. Article 3 of the Palermo Protocol, ratified by the United Kingdom on 9 February 2006, provides that:

“For the purposes of this Protocol:

(a) Trafficking in persons' shall mean the recruitment, transportation, transfer, harbouring or receipt of persons,
by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the
abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve
the consent of a person having control over another person, for the purpose of exploitation. Exploitation shall
include, at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced
labour or services, slavery or practices similar to slavery, servitude or the removal of organs;

(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph (a) of
this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered 'trafficking in persons' even if this does not involve any of the means set forth in subparagraph
(a) of this article;

(d) Child' shall mean any person under eighteen years of age.”

_B. United Nations Convention on the Rights of the Child 1989_

95. This Convention, which was ratified by the United Kingdom in 1991, provides as relevant:

“Article 3

1. In all actions concerning children, whether undertaken by public or private social welfare institutions, courts
of law, administrative authorities or legislative bodies, the best interests of the child shall be a primary
consideration.

…

Article 32

1. States Parties recognize the right of the child to be protected from economic exploitation and from
performing any work that is likely to be hazardous or to interfere with the child's education, or to be harmful to
the child's health or physical, mental, spiritual, moral or social development.

2. States Parties shall take legislative, administrative, social and educational measures to ensure the
implementation of the present article. To this end and having regard to the relevant provisions of other
international instruments, States Parties shall in particular:

(a) Provide for a minimum age or minimum ages for admission to employment;

(b) Provide for appropriate regulation of the hours and conditions of employment;


-----

(c) Provide for appropriate penalties or other sanctions to ensure the effective enforcement of the present
article.

Article 33

States Parties shall take all appropriate measures, including legislative, administrative, social and educational
measures, to protect children from the illicit use of narcotic drugs and psychotropic substances as defined in
the relevant international treaties and to prevent the use of children in the illicit production and trafficking of
such substances.

…

Article 35

States Parties shall take all appropriate national, bilateral and multilateral measures to prevent the abduction
of, the sale of or traffic in children for any purpose or in any form.

Article 36

States Parties shall protect the child against all other forms of exploitation prejudicial to any aspects of the
child's welfare.”

96. Article 3 of the Optional Protocol to the Convention on the Rights of the Child on the sale of children, child
prostitution and child pornography, which was ratified by the United Kingdom in February 2009, provides that:

“1. Each State Party shall ensure that, as a minimum, the following acts and activities are fully covered under
its criminal or penal law, whether such offences are committed domestically or transnationally or on an
individual or organized basis:

(a) In the context of sale of children as defined in article 2:

(i) Offering, delivering or accepting, by whatever means, a child for the purpose of:

…

c. Engagement of the child in forced labour;

…

3. Each State Party shall make such offences punishable by appropriate penalties that take into account their
grave nature.

4. Subject to the provisions of its national law, each State Party shall take measures, where appropriate, to
establish the liability of legal persons for offences established in paragraph 1 of the present article. Subject to
the legal principles of the State Party, such liability of legal persons may be criminal, civil or administrative.”

_C. International Labour Organisation (“ILO”) Forced Labour Convention, 1930 (No. 29)1. ILO Forced Labour_
_Convention_

97. The ILO Convention was ratified by the United Kingdom in 1931. It provides, insofar as relevant:

**Article 1**

“Each Member of the International Labour Organisation which ratifies this Convention undertakes to suppress
the use of forced or compulsory labour in all its forms within the shortest possible period.”

**Article 2**


-----

“1. For the purposes of this Convention the term forced or compulsory labour shall mean all work or service
which is exacted from any person under the menace of any penalty and for which the said person has not
offered himself voluntarily.

…”

**Article 25**

“The illegal exaction of forced or compulsory labour shall be punishable as a penal offence, and it shall be an
obligation on any Member ratifying this Convention to ensure that the penalties imposed by law are really
adequate and are strictly enforced.”

_2. Protocol of 2014 to the ILO Forced Labour Convention, 1930 (P029)_

98. Article 4 of the Protocol provides that:

“1. Each Member shall ensure that all victims of forced or compulsory labour, irrespective of their presence or
legal status in the national territory, have access to appropriate and effective remedies, such as compensation.

2. Each Member shall, in accordance with the basic principles of its legal system, take the necessary measures
to ensure that competent authorities are entitled not to prosecute or impose penalties on victims of forced or
compulsory labour for their involvement in unlawful activities which they have been compelled to commit as a
direct consequence of being subjected to forced or compulsory labour.”

_3. The ILO indicators of forced labour_

99. The ILO has developed indicators of forced labour which are derived from the theoretical and practical
experience of the ILO's Special Action Programme to Combat Forced Labour. These indicators are based upon the
definition of forced labour specified in the ILO Forced Labour Convention and provide a valuable benchmark in the
identification of forced labour. They are:

1. Threats or actual physical harm to the worker.

2. Restriction of movement and confinement to the work place or to a limited area.

3. Debt bondage: where the worker works to pay off a debt or loan, and is not paid for his or her services. The
employer may provide food and accommodation at such inflated prices that the worker cannot escape the debt.

4. Withholding of wages or excessive wage reductions, that violate previously made agreements.

5. Retention of passports and identity documents, so that the worker cannot leave, or prove his/her identity and
status.

6. Threat of denunciation to the authorities, where the worker is in an irregular immigration status.

_D. ILO: Worst Forms of Child Labour Convention, 1999 (No. 182)_

100. This Convention, which was ratified by the United Kingdom on 22 March 2000, provides as relevant:

**Article 1**

“Each Member which ratifies this Convention shall take immediate and effective measures to secure the
prohibition and elimination of the worst forms of child labour as a matter of urgency.”

**Article 2**

“For the purposes of this Convention, the term child shall apply to all persons under the age of 18.”

**Article 3**


-----

“For the purposes of this Convention, the term the worst forms of child labour comprises:

(a) all forms of slavery or practices similar to slavery, such as the sale and trafficking of children, debt bondage
and serfdom and forced or compulsory labour, including forced or compulsory recruitment of children for use in
armed conflict;

(b) the use, procuring or offering of a child for prostitution, for the production of pornography or for
pornographic performances;

(c) the use, procuring or offering of a child for illicit activities, in particular for the production and trafficking of
drugs as defined in the relevant international treaties;

(d) work which, by its nature or the circumstances in which it is carried out, is likely to harm the health, safety or
morals of children.

…”

**Article 6**

“1. Each Member shall design and implement programmes of action to eliminate as a priority the worst forms of
child labour.

2. Such programmes of action shall be designed and implemented in consultation with relevant government
institutions and employers' and workers' organizations, taking into consideration the views of other concerned
groups as appropriate.”

**Article 7**

“1. Each Member shall take all necessary measures to ensure the effective implementation and enforcement of
the provisions giving effect to this Convention including the provision and application of penal sanctions or, as
appropriate, other sanctions.

2. Each Member shall, taking into account the importance of education in eliminating child labour, take effective
and time-bound measures to: (a) prevent the engagement of children in the worst forms of child labour;

(b) provide the necessary and appropriate direct assistance for the removal of children from the worst forms of
child labour and for their rehabilitation and social integration;

(c) ensure access to free basic education, and, wherever possible and appropriate, vocational training, for all
children removed from the worst forms of child labour;

(d) identify and reach out to children at special risk; and

(e) take account of the special situation of girls.

3. Each Member shall designate the competent authority responsible for the implementation of the provisions
giving effect to this Convention.”

_E. ILO: Worst Forms of Child Labour Recommendation, 1999 (No. 190)_

101. The provisions of this Recommendation supplement the 1999 Convention and should be applied in conjunction
with them. It provides, insofar as relevant:

“2. The programmes of action referred to in Article 6 of the Convention should be designed and implemented
as a matter of urgency, in consultation with relevant government institutions and employers' and workers'
organisations, taking into consideration the views of the children directly affected by the worst forms of child
labour, their families and, as appropriate, other concerned groups committed to the aims of the Convention and
this Recommendation. Such programmes should aim at, inter alia:


-----

(a) identifying and denouncing the worst forms of child labour;

(b) preventing the engagement of children in or removing them from the worst forms of child labour, protecting
them from reprisals and providing for their rehabilitation and social integration through measures which address
their educational, physical and psychological needs;

(c) giving special attention to:

(i) younger children;

(ii) the girl child;

(iii) the problem of hidden work situations, in which girls are at special risk;

(iv) other groups of children with special vulnerabilities or needs;

(d) identifying, reaching out to and working with communities where children are at special risk;

(e) informing, sensitizing and mobilizing public opinion and concerned groups, including children and their
families….

9. Members should ensure that the competent authorities which have responsibilities for implementing national
provisions for the prohibition and elimination of the worst forms of child labour cooperate with each other and
coordinate their activities.

…

12. Members should provide that the following worst forms of child labour are criminal offences:

(a) all forms of slavery or practices similar to slavery, such as the sale and trafficking of children, debt bondage
and serfdom and forced or compulsory labour, including forced or compulsory recruitment of children for use in
armed conflict;

(b) the use, procuring or offering of a child for prostitution, for the production of pornography or for
pornographic performances; and

(c) the use, procuring or offering of a child for illicit activities, in particular for the production and trafficking of
drugs as defined in the relevant international treaties, or for activities which involve the unlawful carrying or use
of firearms or other weapons.”

_F. Council of Europe Convention on Action against Trafficking in Human Beings, 2005 (“the Anti-Trafficking_
_Convention”)_

102. In addition to adopting the same definition of trafficking in human beings as the Palermo Protocol (see Article
4), Article 10 of the Anti-Trafficking Convention, which came into force in respect of the United Kingdom on 1 April
2009, provided:

“1 Each Party shall provide its competent authorities with persons who are trained and qualified in preventing
and combating trafficking in human beings, in identifying and helping victims, including children, and shall
ensure that the different authorities collaborate with each other as well as with relevant support organisations,
so that victims can be identified in a procedure duly taking into account the special situation of women and
child victims and, in appropriate cases, issued with residence permits under the conditions provided for in
Article 14 of the present Convention.

2 Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure that,
if the competent authorities have reasonable grounds to believe that a person has been victim of trafficking in
human beings that person shall not be removed from its territory until the identification process as victim of an


-----

offence provided for in Article 18 of this Convention has been completed by the competent authorities and shall
likewise ensure that that person receives the assistance provided for in Article 12, paragraphs 1 and 2.

3 When the age of the victim is uncertain and there are reasons to believe that the victim is a child, he or she
shall be presumed to be a child and shall be accorded special protection measures pending verification of
his/her age.

4 As soon as an unaccompanied child is identified as a victim, each Party shall:

A provide for representation of the child by a legal guardian, organisation or authority which shall act in the best
interests of that child;

b take the necessary steps to establish his/her identity and nationality;

c make every effort to locate his/her family when this is in the best interests of the child.”

103. Article 26 contained the following “non-punishment provision”:

“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.”

104. Article 35 provides that:

“Each Party shall encourage state authorities and public officials, to co-operate with nongovernmental
organisations, other relevant organisations and members of civil society, in establishing strategic partnerships
with the aim of achieving the purpose of this Convention.”

_G. Organization for Security and Cooperation in Europe (“OSCE”): Ministerial Declaration on Combating All Forms_
_of Human Trafficking (Vilnius, 6 – 7 December 2011)_

105. The Declaration provides, insofar as relevant:

“8. We promote and support multidisciplinary co-operation, cross-sectoral training and multilateral partnerships.
We commend the initiatives taken by the OSCE Special Representative under the auspices of the Alliance
against Trafficking in Persons and take note of the 2010 Alliance against Trafficking in Persons Conference on
Unprotected Work, Invisible Exploitation: Trafficking for the Purpose of Domestic Servitude; as well as the 2011
Alliance against Trafficking in Persons Conference on Preventing Trafficking in Human Beings for Labour
Exploitation: Decent Work and Social Justice; and Joint OSCE/UNODC Expert Seminar on Leveraging AntiMoney Laundering Regimes to Combat Human Trafficking.

9. We recognize the need to enhance the criminal justice responses to human trafficking, including the
prosecution of traffickers and their accomplices, while ensuring that victims are treated in a manner that
respects their human rights and that they are provided with access to justice, to legal assistance, and to
effective remedies and other services as applicable. We will explore investigative techniques such as financial
investigations, improve information sharing relating to organized crime groups, and promote cross-border lawenforcement and judicial collaboration to identify effectively both traffickers and potential victims of human
trafficking.

10. We recognize that adequate measures should be taken to ensure that, where appropriate, identified victims
of human trafficking are not penalized for their involvement in unlawful activities to the extent that they have
been compelled to do so. We urge participating States to implement comprehensive and appropriate measures
on assistance to victims of trafficking in persons.”

_III. RELEVANT EU LAW_

106. Directive 2011/36 on preventing and combatting trafficking in human beings of 5 April 2011 (“the AntiTrafficking Directive”), provides as relevant:


-----

“Recital (14) Victims of trafficking in human beings should, in accordance with the basic principles of the legal
systems of the relevant Member States, be protected from prosecution or punishment for criminal activities
such as the use of false documents, or offences under legislation on prostitution or immigration, that they have
been compelled to commit as a direct consequence of being subject to trafficking. The aim of such protection is
to safeguard the human rights of victims, to avoid further victimisation and to encourage them to act as
witnesses in criminal proceedings against the perpetrators. This safeguard should not exclude prosecution or
punishment for offences that a person has voluntarily committed or participated in.

**Article 2**

**Offences concerning trafficking in human beings**

“1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or transfer
of control over those persons, by means of the threat or use of force or other forms of coercion, of abduction, of
fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of
payments or benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation.

2. A position of vulnerability means a situation in which the person concerned has no real or acceptable
alternative but to submit to the abuse involved.

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, including begging, slavery or practices similar to slavery, servitude, or
the exploitation of criminal activities, or the removal of organs.

4. The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual, shall be
irrelevant where any of the means set forth in paragraph 1 has been used.

5. When the conduct referred to in paragraph 1 involves a child, it shall be a punishable offence of trafficking in
human beings even if none of the means set forth in paragraph 1 has been used.

6. For the purpose of this Directive, 'child' shall mean any person below 18 years of age.”

**Article 8**

**Non-prosecution or non-application of penalties to the victim**

“Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties on
victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2.”

**Article 9**

**Investigation and prosecution**

“1. Member States shall ensure that investigation into or prosecution of offences referred to in Articles 2 and 3
is not dependent on reporting or accusation by a victim and that criminal proceedings may continue even if the
victim has withdrawn his or her statement.

2. Member States shall take the necessary measures to enable, where the nature of the act calls for it, the
prosecution of an offence referred to in Articles 2 and 3 for a sufficient period of time after the victim has
reached the age of majority.


-----

3. Member States shall take the necessary measures to ensure that persons, units or services responsible for
investigating or prosecuting the offences referred to in Articles 2 and 3 are trained accordingly.

4. Member States shall take the necessary measures to ensure that effective investigative tools, such as those
which are used in organised crime or other serious crime cases are available to persons, units or services
responsible for investigating or prosecuting the offences referred to in Articles 2 and 3.”

107. Member States were required to bring into force the laws, regulations and administrative provisions necessary
to comply with the Directive by 6 April 2013.
**THE LAWI. JOINDER OF THE APPLICATIONS**

108. Having regard to the similar subject matter of the applications, the Court finds it appropriate to examine them
jointly in a single judgment.
_II. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION_

109. The first applicant complained under Article 4 of the Convention that the Crown Prosecution Service (“CPS”)
failed adequately to protect him in the aftermath of the trafficking, and that there was a failure properly to implement
Article 26 of the Anti-Trafficking Convention. He later revised his complaints to argue that during the criminal
proceedings the police and the CPS had failed to conduct an Article 4 compliant investigation into whether he had
been trafficked; and that there had been a failure to adopt operational measures to protect him.

110. The second applicant complained that his prosecution violated Article 4 of the Convention because there was
a failure by the police, prosecutors and judiciary to identify him as a victim of trafficking prior to his criminal
conviction, which prevented the authorities from providing him with the protection he required; that the legal
framework in place at the time coupled with the limited availability of judicial intervention deprived him of the
protection he was entitled to as a victim of trafficking; and that his prosecution, conviction and incarceration meant
that until he was identified as a victim of trafficking after his conviction, he was deprived of the protection to which
he was entitled and of the possibility of seeing his traffickers investigated and brought to justice. He later revised his
submissions to further argue that the United Kingdom failed to comply with its duty to investigate his traffickers; that
it failed in its duty to identify him as a victim of trafficking when he first came to the attention of the authorities; that it
failed to apply the appropriate test to identify a child victim of trafficking, and that the Court of Appeal applied a test
of compulsion which was prohibited by law; and that it failed to honour the non-criminalisation of victims of
trafficking for status-related offences.

111. Article 4 of the Convention reads, insofar as relevant:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

_A. The scope of the present complaints_

112. It is important at the outset to clarify the scope of the Article 4 complaint before the Court. The applicants'
principal complaint is that by prosecuting them for criminal offences connected to their work in the cannabis
factories the State failed in its duty to protect them as victims of trafficking. They do not contend that the State failed
to prohibit or punish trafficking, and while they have suggested that the measures taken to investigate and punish
their traffickers were themselves inadequate, no such complaint has been ventilated by either applicant before the
domestic courts and as such it cannot now be considered by the Court.

113. In support of their claims the applicants have relied heavily on Article 26 of the Anti-Trafficking Convention,
which requires Contracting States to provide for the possibility of not imposing penalties on victims of trafficking for
their involvement in unlawful activities to the extent that they have been compelled to act as they did (see
paragraph 103 above). In particular, they argue that the respondent State failed to comply with that duty and that
the CPS and the domestic courts wrongly looked for evidence that they had been compelled to commit the criminal
offences, even though both the Anti-Trafficking Convention and the Anti-Trafficking Directive clearly state that
children may be recognised as victims of trafficking in the absence of any means of compulsion. For the Court,


-----

however, the issue in the present case is not that the State did not make provision for not punishing victims of
trafficking, or that, having accepted that the applicants were victims of trafficking, the authorities did not consider
that they had been compelled to commit the criminal offences. Rather, the issue is that the CPS, in its original
decisions to prosecute and/or in subsequent reviews of those decisions, disagreed with the conclusions of the
Competent Authority and found that the applicants were not in fact victims of trafficking, and this conclusion was
held by the Court of Appeal to have been amply justified. Therefore, in the Court's view the aforementioned issues
do not, in fact, arise on the facts of the cases at hand. In any case, the Court's jurisdiction is limited to the European
Convention on Human Rights. It has no competence to interpret the provisions of the Anti-Trafficking Convention or
to assess the compliance of the respondent State with the standards contained therein (see, _mutatis mutandis,_
_National Union of Rail, Maritime and Transport Workers v. the United Kingdom, no. 31045/10, § 106, ECHR 2014)._

114. The Court will therefore confine itself to considering whether, on the facts of the cases at hand, the respondent
State complied with its positive obligations under Article 4 of the Convention.
_B. Admissibility1. Victim status(a) The parties' submissions_

115. The Government argued that the applicants could not claim to be “victims” of the alleged violation since the
domestic courts supported the finding of the CPS that they were not credible victims of trafficking or, in the case of
the second applicant, a credible victim of forced labour.

116. The applicants, on the other hand, pointed out that they had been recognised as credible victims of trafficking
by the Competent Authority. Moreover, this finding did not deprive them of their victim status because the State's
positive obligation went beyond a duty to recognise them as victims of trafficking.
_(b) The Court's assessment_

117. The applicants were both discovered on or near cannabis factories in April/May 2009. The first applicant was
discovered during the execution of a drug warrant (see paragraph 5 above), while the second applicant was
discovered after police were called to the property (see paragraph 18 above). At the time, there appears to have
been clear evidence to indicate that the cultivation of cannabis plants was an activity commonly carried out by child
trafficking victims. Both the guidance published by the CPS in December 2007 and its Guidance on Human
Trafficking and Smuggling (which was last updated, prior to the applicants' arrest, on 4 February 2009) highlighted
the “cultivation of cannabis plants” as an offence likely to be carried out by child victims of trafficking (see
paragraphs 72-73 above). Moreover, the first “scoping report” of the Child Exploitation and Online Protection
Command (“CEOP”), which was published in June 2007, identified Vietnamese boys and girls as a specific
vulnerable group. It noted that some of these children had been found being exploited in cannabis factories while
others were suspected to have been trafficked for the purposes of sexual exploitation (see paragraphs 81-82
above). In a further threat assessment published in April 2009 CEOP indicated that Vietnamese children had the
highest probability of being trafficked than any other profile encountered in the study. The Vietnamese children
identified by CEOP were primarily involved in the cultivation of cannabis and many were arrested in police raids on
cannabis factories. Significantly, CEOP noted in the report that both the Association of Chief Police Officers
(“ACPO”) and the CPS had issued guidance on the treatment of children found in such criminal enterprises to
ensure that no child was brought before the courts where the crime committed was a direct result of trafficking (see
paragraph 83 above).

118. There does not appear to have been any doubt that the first applicant was a minor; on the contrary, the only
dispute over his age concerned whether he was fifteen or seventeen years old when he was discovered (see
paragraphs 6 and 7 above). In view of the fact that he was a minor discovered during a planned raid on a cannabis
factory, the Court considers that from the very outset the police and subsequently the CPS should have been aware
of the existence of circumstances giving rise to a credible suspicion that he had been trafficked.

119. Upon discovery near the cannabis factory, the second applicant gave his year of birth as 1972 (see paragraph
19 above). However, nine days later, after he had already been charged with being concerned in the production of a
controlled drug of Class B, he gave his year of birth as 1992 at a hearing before the Magistrates' Court. The case
was thereafter approached on the basis that he was seventeen years old (see paragraph 23 above). From this


-----

point, at the very latest, the CPS should have been aware of the existence of circumstances giving rise to a credible
suspicion that he had been trafficked.

120. Therefore, in both cases a positive obligation to take operational measures to protect the applicants as
potential victims of trafficking arose shortly after they were discovered. Furthermore, in view of the fact that the
potential scope of this obligation extends beyond their identification as victims of trafficking (see paragraph 153
below), neither applicant was deprived of his “victim status” within the meaning of Article 34 of the Convention by
the decision of the Competent Authority.

121. Therefore, the Court will now consider whether, in all the circumstances of each applicant's case, the State
fulfilled its duty under Article 4 of the Convention to take operational measures to protect him.
_2. Other grounds for inadmissibility_

122. The Government further contended that the applicants' complaints are manifestly ill-founded, since they turn
entirely on factual issues which have been resolved fairly by the domestic courts.

123. However, the Court is of the opinion that the applicants' Article 4 complaints raise sufficiently complex issues
of fact and law, so that they cannot be rejected as manifestly ill-founded within the meaning of Article 35 § 3 (a) of
the Convention. It is further satisfied that they are not inadmissible on any other ground. They must therefore be
declared admissible.
_C. Merits1. Submissions of the parties(a) The first applicant_

124. The first applicant submitted that the CPS stance was in direct conflict with the Competent Authority's
identification of him as a child victim of trafficking for criminal exploitation and the separate and distinct trafficking
assessment undertaken by the Local Authority, which also found that he had been trafficked for criminal
exploitation. The Competent Authority was the body designated by the Government to meet its obligations to
identify victims of trafficking and in the first applicant's view in light of its findings any assertion that he was not a
victim of trafficking was wholly misconceived. Although the CPS supposedly considered the reports from the local
authority and the Competent Authority which found that he had been trafficked, it came to a contrary view without
any significant evidence capable of displacing the conclusion of the Competent Authority. There were no
contemporaneous written records of these reviews and no witness statements were filed by the reviewing lawyers
in the appellate proceedings.

125. He further contended that the CPS and police had failed to undertake any Article 4 compliant investigation or
review which would have justified its departure from the Competent Authority's decision. In particular, despite there
having been a high expectation that victims of trafficking would be encountered at the cannabis factory, there was a
failure to anticipate the need to include child protection experts and social services in order to receive and protect
any children recovered; a failure to route the first applicant into a safeguarding-led process which would have
enabled him to assist and engage with a criminal investigation into the circumstances of his trafficking; and a failure
to analyse the evidence gathered in light of known trafficking methods of control.

126. In the first applicant's submission, the facts of the case were indicative of a much larger problem, namely the
poor identification process adopted by the criminal justice authorities resulting in the continued punishment of
victims for crimes committed as a direct consequence of trafficking. In his view, the Government had not adopted
specific legislation or measures to implement Article 26 of the Anti-Trafficking Convention so as to give effect to the
non-punishment principle and the domestic measures that were in place were insufficient to protect trafficking
victims.

127. According to the first applicant, it was incumbent on the responsible bodies within the criminal justice system
and the prosecutorial decision-making process to ensure that an effective investigation took place which was
capable both of prosecuting the responsible individuals and identifying genuine victims of trafficking; that protective
measures were put in place when a suspected or actual victim of trafficking was encountered in order to safeguard
his or her welfare; that State agents were appropriately and adequately trained to identify and respond to instances
of trafficking without relying on the victim self-identifying; and that a framework of laws, policies and procedures was


-----

in place to ensure that the principle of non-prosecution of victims of trafficking was made real and effective rather
than theoretical and illusory.
_(b) The second applicant_

128. The second applicant argued that there was an implicit duty under Article 4 of the Convention to identify
victims of trafficking, since failure to identify a trafficking victim correctly would probably result in the victim being
denied his or her fundamental rights, and the prosecution being denied a necessary witness in the prosecution of
the perpetrator. It was the second applicant's contention that he was deprived of the protection to which he was
entitled as a victim of trafficking on account of the failure by the police, prosecutors and judiciary to identify him as
such prior to his criminal conviction, despite the fact that at the date of his arrest police and prosecutors were well
aware that many Vietnamese children had been trafficked to and within the United Kingdom for the purposes of
exploitation in the production of cannabis. In the second applicant's view, based on the available evidence,
including the statements he himself had made following his arrest, the police and prosecutors involved in his case
ought to have been aware of circumstances giving rise to a credible suspicion that he had been trafficked. The fact
that the second applicant did not himself claim to be a victim of trafficking was irrelevant as victims of trafficking
could not be expected to self-identify.

129. As he was a minor, he argued that the obligation to identify was particularly crucial as police, prosecutors and
judges could not respect the principle of the best interests of the child if they had not properly identified the child as
a victim of trafficking.

130. The second applicant contended that the legal framework in place at the time for protecting potentially
trafficked children was inadequate. First of all, the guidance on the use of prosecutorial discretion was not
sufficiently robust to ensure the identification of trafficking victims accused of offences, with a view to ceasing
prosecution in circumstances where prosecution was inconsistent with the accused's human rights; and the
restrictive review applied by the Court of Appeal when examining challenges to the exercise of that discretion was
too limited adequately to protect victims of trafficking. Secondly, domestic law did not criminalise internal trafficking
within the United Kingdom, with the result that prosecutors wrongly focussed only on whether he was smuggled or
trafficked into the United Kingdom, whilst failing to pay any regard to whether he was a victim of internal trafficking
for the purposes of exploitation in the cannabis factory or a victim of forced labour or slavery per se.

131. On the facts of his case, he contended that as there were clear indicators of trafficking on his arrest the police
and prosecutor should have referred him into the National Referral Mechanism (“NRM”), and that the trial judge
should not have convicted or sentenced him. Their failure to do so had important consequences for him, since his
conviction would likely prevent him from accessing lawful employment and otherwise enjoying a safe and secure
existence in the respondent State.
_(c) The Government(i) As concerns the first applicant_

132. The Government submitted that the case turned entirely on factual issues which had been resolved fairly by
the domestic courts. The CPS had taken the view that the first applicant was not a victim of trafficking and the
relevant nexus was not established between the offence and any trafficking. The appeal courts had endorsed that
view. The first applicant had not sought to persuade the Crown Court that he was a victim of trafficking or that there
was a nexus between trafficking and the offence, but even if he had the Court of Appeal had reached the
“unhesitating conclusion” that the argument would have been rejected on the facts.

133. In fact, it was the Government's contention that the starting point in the case was that the Court of Appeal, on
two successive occasions, had carefully considered the first applicant's case and decided that the CPS had been
entitled to reach the view that it had, which was that he was not a victim of trafficking and that the relevant nexus
between the offence and his possible status as a child victim of trafficking had not been established. This
conclusion was not reached by interpreting the law to his disadvantage but because of the factual circumstances of
his case.

134. In the Government's view, the approach taken by the domestic authorities complied both with the domestic
and international legal framework. The first applicant was flagged as a potential victim of trafficking notwithstanding


-----

that neither he nor the lawyers representing him in the criminal proceedings asserted that this was the case. He
was then given the benefit of a forty-five day reflection period during which no action was taken in his prosecution.
The reports in which the Competent Authority concluded that he was a victim of trafficking were considered by the
CPS. The decision to prosecute had regard to specific CPS guidance which recognised the vulnerability of victims –
and especially child victims – of trafficking and recognised that if a person had been trafficked it might affect both
whether there was sufficient evidence to prosecute and whether it was in the public interest to do so. After the initial
charging decision, the case was reviewed by a lawyer and counsel following receipt of the trafficking assessment; it
was further reviewed by the principal reviewing lawyer assigned to the case after receipt of the reasonable grounds
decision; and her decision was subsequently approved by the Chief Crown Prosecutor for Cambridgeshire. The
procedures followed in the Crown Court afforded the first applicant and his lawyers ample time and the express
opportunity to raise arguments based on his identification as a victim of trafficking, both before and after he entered
his plea. Finally, the case was considered twice by the Court of Appeal on the basis that a child should not be
prosecuted for an offence where there was a sufficient nexus between trafficking for the purposes of exploitation
and the offence, and that it was not necessary to go so far as to show there was compulsion to commit the offence.

135. Insofar as the first applicant sought to frame his argument on the basis of a failure by the domestic authorities
to investigate, the Government submitted that the domestic authorities in fact took all the appropriate investigative
steps. He was assessed by the Border Agency and recognised by them as a victim of trafficking; on this basis and
as a vulnerable unaccompanied child he was given support; operational measures were put in place to arrange
accommodation, education, immigration help and to protect him from exploitation in the event that he was released
from prison; the police and prosecution liaised with other Government agencies; and the position was kept under
review. However, the prosecution were not bound by the determination of the Border Agency.

136. Finally, the Government argued that it would be wrong for the Court to import Article 26 of the Anti-Trafficking
Convention wholesale into Article 4 of the Convention, or to interfere with the conclusions of the courts as to which
body has ultimate power, in domestic law, to consider the factual position in order to give effect to the rights
protected under the Convention. The latter would be particularly so where the courts had given detailed
consideration to the issue, aware that in doing so they were departing from a decision of the Competent Authority
that a defendant was a victim of trafficking.
_(ii) As concerns the second applicant_

137. The Government submitted, at the outset, that as the second applicant had only complained before the
domestic courts that his conviction was unsafe because he should not have been prosecuted as a victim of
trafficking, the Court's consideration of his complaint should be so limited. He did not complain domestically about
any failure to conduct an adequate criminal investigation into the circumstances of his alleged trafficking; nor did he
contend that either the substantive criminal law or applicable procedure was incompatible with Article 4 of the
Convention.

138. As with the first applicant, the Government further argued that the CPS had been entitled to reach an
independent view from that of the Border Agency regarding whether or not an individual was a victim of trafficking,
and to form the view that in an individual case, taking into account the seriousness of the offending and all of the
surrounding circumstances, it was in the public interest to prosecute. Consequently, the decision taken by the
Border Agency did not undermine the factual determination of the domestic courts, either at first instance or on
appeal, and it followed that the second applicant had not been prosecuted for any offence committed in
circumstances protected by Article 4 of the Convention.

139. In this regard, the Government submitted that the CPS, on two successive occasions, and thereafter the Court
of Appeal, which had before it the explanation given by NSPCC NCTAIL for the pattern of inconsistencies in the
second applicant's account, had carefully considered his case and had been entitled to take the view that he was
not a victim of trafficking and that it was in the public interest to prosecute him.

140. In the Government's view, while Article 4 did not operate in a vacuum, and regard could be had to the
definitions in the Anti-Trafficking Convention and the Palermo Protocol, it did not follow that specific procedural
commitments in other international instruments, such as the non-prosecution clause in Article 26 of the Anti

-----

Trafficking Convention, should be understood as forming part of the Convention itself. On the contrary, all that was
required under the Convention was that any investigation and prosecution should be approached on a basis which
demonstrates respect for the freedoms guaranteed by Article 4. According to the Government, in the second
applicant's case the authorities' manifestly did so. First of all, the CPS had a discretion whether or not to prosecute
him and this decision was based not only on the evidence against him but also on consideration of whether, in light
of the surrounding factual circumstances, it was in the public interest to proceed against him. Secondly, it was open
to the second applicant to challenge the decision to prosecute him, either by making representations to the CPS, by
arguing that the proceedings were an abuse of process, or by seeking to judicially review the decision. Thirdly, upon
the determination by the Border Agency being communicated to the CPS, it commissioned an ex post facto review
by a Special Casework Lawyer who considered both the evidence that had been available at the time of the
prosecution and that which was obtained subsequently and reached a reasoned decision that the initial accounts
given by the second applicant were nearest to the truth and that there was no credible suspicion that he was a
victim of trafficking. Finally, the Court of Appeal considered his case with care before concluding that the CPS had
been entitled to reach the decision that it did.

141. Insofar as the second applicant complained about a failure to investigate, his situation as a potential victim of
trafficking was scrutinised by the Competent Authority, his legal representatives, the expert witnesses such as the
NSPCC witness and the psychiatrist, the CPS and the domestic courts.
_2. Submissions of the third party interveners(a) Group of Experts on Trafficking in Human Beings (“GRETA”)_

142. GRETA stressed that in order to protect and assist trafficking victims, it was of the utmost importance to
identify them correctly. Nevertheless, despite the guidance provided by the Association of Chief Police Officers
(“ACPO”) on how to safeguard children found on cannabis factories, there had been cases in the United Kingdom of
victims of trafficking being arrested, prosecuted and convicted in relation to cannabis cultivation. In GRETA's view
this hinged on the fact that they were not identified as possible victims by the relevant professionals with whom they
were in contact. In particular, it appeared that duty solicitors often advised children involved in cannabis cultivation
to plead guilty as a way of spending less time in detention. In its first report on the United Kingdom, GRETA had
called on the State to ensure that the ACPO guidance was fully applied in order to avoid the imposition of penalties
on identified victims of trafficking for their involvement in unlawful activities to the extent that they were compelled to
do so.

143. It further indicated that the aim of Article 26 of the Anti-Trafficking Convention was to safeguard the human
rights of victims and avoid further victimisation. Criminalisation of victims contravened the State's obligation to
provide services and assistance to them, and discouraged them from coming forward and cooperating with the
investigation into those responsible for their trafficking.
_(b) Anti-Slavery International_

144. Anti-Slavery International argued that Article 4 of the Convention had to be interpreted in light of the
respondent State's obligations under international treaties such as the Council of Europe Anti-Trafficking
Convention, the EU Anti-Trafficking Directive and the Convention on the Rights of the Child. This meant that there
were special and enhanced obligations towards trafficked children, whose best interests should be determinative in
any decision-making procedure. In this regard, child trafficking victims should be given enhanced protection against
punishment, since it was difficult to conceive of a case where it would be in the best interests of a trafficked child to
be punished.

145. Moreover, when assessing whether a person is a victim of trafficking, credibility must be viewed through the
trafficking perspective; so-called “traditional” adverse credibility factors may not be relevant and may even operate
to the opposite effect. For example, it was a widely discredited “myth” that a person is not coerced if he or she did
not take an opportunity to escape. There were multiple reasons why a person may not have escaped, as the Home
Office Guidance on trafficking itself recognised.
_(c) Liberty_

146. Liberty submitted that the positive obligation under Article 4 should be construed in light of Article 26 of the
Anti-Trafficking Convention and the EU Anti-Trafficking Directive to include a positive duty on the State to introduce


-----

legislative and other measures that specifically and effectively protect trafficked individuals against unlawful
punishment for trafficking-related crimes. These measures should be capable of dealing with the whole criminal law
chain, including the police, the prosecution and the courts. In the absence of such measures all State actors should
remain under a positive obligation under Article 4 of the Convention to act having regard to the need to prevent
trafficked individuals from unlawful punishment for trafficking-related crimes. This was necessary to protect
trafficking victims from further harm.

147. In Liberty's view, there were significant lacunae in the procedural safeguards in the United Kingdom's criminal
justice system. The United Kingdom had not implemented any specific measure directed at the non-punishment of
victims of trafficking, and while there was comprehensive guidance for prosecutors, no comparable measures were
directed at the police, who were likely to be the first to encounter potential victims of trafficking. Identification at an
early stage could, however, ensure that a trafficked individual never enters the criminal justice system. Similarly,
there was no explicit duty on the courts to make inquiries into defendants' potential victim status when they were
first brought before them on a criminal charge or thereafter. Moreover, the abuse of power jurisdiction was
inadequate as it was heavily dependent on an application being made on the defendant's behalf and in cases
where the defendant had pleaded guilty it was no longer possible for the court to stay the proceedings. While a
procedure existed for vacating a guilty plea, it was also dependent on the defendant making the application.
_3. The Court's assessment(a) General principles(i) The scope of Article 4 of the Convention_

148. It is now well-established that both national and transnational trafficking in human beings, irrespective of
whether or not it is connected with organised crime, falls within the scope of Article 4 of the Convention (see S.M. v.
_Croatia [GC], no. 60561/14, § 296, 25 June 2020). As such, it is not necessary to identify whether the treatment of_
which the applicant complains constitutes “slavery”, “servitude” or “forced [or] compulsory labour” (see Rantsev v.
_Cyprus and Russia, no. 25965/04, § 282, ECHR 2010 (extracts))._

149. Impugned conduct may give rise to an issue under Article 4 of the Convention only if all the constituent
elements of the definition of trafficking contained in Article 3(a) of the Palermo Protocol and Article 4(a) of the AntiTrafficking Convention (often described as “action”, “means”, and “purpose”, although it is not necessary to show
“means” in the case of a child) are present (see paragraphs 94 and 102 above). The question whether a particular
situation involves all of the constituent elements is a factual question which must be examined in the light of all the
relevant circumstances of a case (see _S.M. v. Croatia, cited above, § 302). Similarly, the question whether an_
individual offers himself for work voluntarily is a factual question which must be examined in the light of all the
relevant circumstances. However, the Court has made it clear that where an employer abuses his power or takes
advantage of the vulnerability of his workers in order to exploit them, they do not offer themselves for work
voluntarily. In this regard, the prior consent of the victim is not sufficient to exclude the characterisation of work as
forced labour (see Chowdury and Others v. Greece, no. 21884/15, § 96, 30 March 2017).
_(ii) The State's positive obligations under Article 4_

150. The member States' positive obligations under Article 4 of the Convention must be construed in light of the
Council of Europe's Anti-Trafficking Convention and be seen as requiring not only prevention but also victim
protection and investigation. The Court is guided by the Anti-Trafficking Convention and the manner in which it has
been interpreted by GRETA (see Chowdury and Others, cited above, § 104).

151. Article 4 entails a specific positive obligation on member States to penalise and prosecute effectively any act
aimed at maintaining a person in a situation of slavery, servitude or forced or compulsory labour (Siliadin v. France,

no. 73316/01, §§ 89 and 112, ECHR 2005‑VII). In order to comply with this obligation, member States are required

to put in place a legislative and administrative framework to prevent and punish trafficking and to protect victims
(see Rantsev, cited above, § 285).

152. As with Articles 2 and 3 of the Convention, Article 4 may, in certain circumstances, require a State to take
operational measures to protect victims, or potential victims, of trafficking. In order for a positive obligation to take
operational measures to arise in the circumstances of a particular case, it must be demonstrated that the State
authorities were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion that an
identified individual had been, or was at real and immediate risk of being, trafficked or exploited within the meaning


-----

of Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti-Trafficking Convention. When this is the case,
there will be a violation of Article 4 of the Convention where the authorities fail to take appropriate measures within
the scope of their powers to remove the individual from that situation or risk (see Rantsev, cited above, § 286, with
further references).

153. As for the type of operational measures which might be required by Article 4 of the Convention, the Court has
considered it relevant that the Anti-Trafficking Convention calls on the member States to adopt a range of measures
to prevent trafficking and to protect the rights of victims. The preventive measures include measures to strengthen
coordination at national level between the various anti-trafficking bodies and to discourage the demand for all forms
of exploitation of persons. Protection measures include facilitating the identification of victims by qualified persons
and assisting victims in their physical, psychological and social recovery (see Chowdury, cited above, § 110).

154. However, bearing in mind the difficulties involved in policing modern societies and the operational choices
which must be made in terms of priorities and resources, the obligation to take operational measures must be
interpreted in a way which does not impose an impossible or disproportionate burden on the authorities (see
_Rantsev, cited above, § 287)._

155. Like Articles 2 and 3, Article 4 also entails a procedural obligation to investigate situations of potential
trafficking. The requirement to investigate does not depend on a complaint from the victim or next-of-kin: once the
matter has come to the attention of the authorities they must act of their own motion (see Rantsev, cited above, §
288).

156. It follows from the above that the general framework of positive obligations under Article 4 includes: (1) the
duty to put in place a legislative and administrative framework to prohibit and punish trafficking; (2) the duty, in
certain circumstances, to take operational measures to protect victims, or potential victims, of trafficking; and (3) a
procedural obligation to investigate situations of potential trafficking. In general, the first two aspects of the positive
obligations can be denoted as substantive, whereas the third aspect designates the States' (positive) procedural
obligation (see S.M. v. Croatia, cited above, § 306).
_(iii) The prosecution of victims and potential victims of trafficking_

157. To date, the Court has not had the opportunity to consider a case concerning the prosecution of a victim, or
potential victim, of trafficking. Consequently, this is the first occasion on which it has been called upon to consider if
and when such a prosecution may raise an issue under Article 4 of the Convention.

158. It is clear that no general prohibition on the prosecution of victims of trafficking can be construed from the AntiTrafficking Convention or any other international instrument. Indeed, the “non-punishment” provisions in Article 26
of the Anti-Trafficking Convention, Article 8 of the Anti-Trafficking Directive and Article 4(2) of the 2014 Protocol to
the ILO Forced Labour Convention (see, respectively, paragraphs 103, 106 and 98 above) all contain two important
qualifications: the victim of trafficking must have been compelled to commit the criminal activity; and, where that is
the case, the national authorities should be entitled, but are not obliged, not to prosecute. While compulsion does
not appear to be necessary to bring a child within the scope of either Article 26 of the Anti-Trafficking Convention or
Article 8 of the Anti-Trafficking Directive, there is nothing in either instrument which could be interpreted as
precluding the prosecution of child trafficking victims in any circumstances.

159. Nevertheless, the Court considers that the prosecution of victims, or potential victims, of trafficking may, in
certain circumstances, be at odds with the State's duty to take operational measures to protect them where they are
aware, or ought to be aware, of circumstances giving rise to a credible suspicion that an individual has been
trafficked. In the Court's view, the duty to take operational measures under Article 4 of the Convention has two
principal aims: to protect the victim of trafficking from further harm; and to facilitate his or her recovery. It is
axiomatic that the prosecution of victims of trafficking would be injurious to their physical, psychological and social
recovery and could potentially leave them vulnerable to being re-trafficked in future. Not only would they have to go
through the ordeal of a criminal prosecution, but a criminal conviction could create an obstacle to their subsequent
integration into society. In addition, incarceration may impede their access to the support and services that were
envisaged by the Anti-Trafficking Convention.


-----

160. In order for the prosecution of a victim or potential victim of trafficking to demonstrate respect for the freedoms
guaranteed by Article 4, his or her early identification is of paramount importance. It follows that, as soon as the
authorities are aware, or ought to be aware, of circumstances giving rise to a credible suspicion that an individual
suspected of having committed a criminal offence may have been trafficked or exploited, he or she should be
assessed promptly by individuals trained and qualified to deal with victims of trafficking. That assessment should be
based on the criteria identified in the Palermo Protocol and the Anti-Trafficking Convention (namely that the person
was subject to the act of recruitment, transportation, transfer, harbouring or receipt, by means of threat of force or
other form of coercion, for the purpose of exploitation) having specific regard to the fact that the threat of force
and/or coercion is not required where the individual is a child (see paragraphs 94 and 102 above).

161. Moreover, given that an individual's status as a victim of trafficking may affect whether there is sufficient
evidence to prosecute and whether it is in the public interest to do so, any decision on whether or not to prosecute a
potential victim of trafficking should – insofar as possible – only be taken once a trafficking assessment has been
made by a qualified person. This is particularly important where children are concerned. The Court has
acknowledged that as children are particularly vulnerable, the measures applied by the State to protect them
against acts of violence falling within the scope of Articles 3 and 8 should be effective and include both reasonable
steps to prevent ill-treatment of which the authorities had, or ought to have had, knowledge, and effective
deterrence against such serious breaches of personal integrity (see, for example, Söderman v. Sweden [GC], no.
5786/08, § 81, ECHR 2013; _M.P. and Others v. Bulgaria, no. 22457/08, § 108, 15 November 2011; and_ _Z and_

_Others v. the United Kingdom [GC], no. 29392/95, § 73, ECHR 2001‑V). Such measures must be aimed at ensuring_

respect for human dignity and protecting the best interests of the child (see Söderman, cited above, § 81). Since
trafficking threatens the human dignity and fundamental freedoms of its victims (see Rantsev, cited above, § 282),
the same is also true of measures to protect against acts falling within the scope of Article 4 of the Convention.

162. Once a trafficking assessment has been made by a qualified person, any subsequent prosecutorial decision
would have to take that assessment into account. While the prosecutor might not be bound by the findings made in
the course of such a trafficking assessment, the prosecutor would need to have clear reasons which are consistent
with the definition of trafficking contained in the Palermo Protocol and the Anti-Trafficking Convention for
disagreeing with it.
_(b) Application of these principles to the present cases(i) The first applicant_

163. The Court has already noted that as the first applicant was discovered by police at a cannabis factory during
the execution of a drug warrant, the authorities should have been alert to the possibility that he – and any other
young persons discovered there – could be a victim of trafficking. Nevertheless, despite there not being any
apparent doubt that he was a minor (see paragraphs 6 and 7 above), neither the police nor the CPS referred him to
one of the United Kingdom's Competent Authorities for an assessment. Instead, he was charged with being
concerned in the production of a controlled drug (see paragraph 6 above).

164. Social Services, having conducted an age assessment, appear to have “flagged up” concerns that he might be
a victim of trafficking, and some three weeks after his discovery Refugee and Migrant Justice informed his legal
representatives of these concerns (see paragraphs 7-8 above). Nevertheless, without any assessment by the
Competent Authority having taken place, in August 2009 he pleaded guilty to the offence charged on the advice of
his legal representative (see paragraph 10 above). However, sentencing was adjourned to await a trafficking
assessment (see paragraph 11 above).

165. At this point, the CPS reviewed the decision to prosecute but concluded that there was no credible evidence
that the first applicant had been trafficked (see paragraph 12 above). No further reasons for that decision have been
shared with the Court.

166. Following the Competent Authority's “Conclusive Decision”, in which it found that the first applicant had been
trafficked (see paragraph 13 above), the CPS again reviewed the case and once again confirmed the decision to
prosecute (see paragraph 14 above). No official reasons were given for this decision but in a letter to a Member of
Parliament the CPS explained that the prosecution had not been discontinued because the offences were very
serious, there was no defence of duress and there was no clear evidence of trafficking (see paragraph 14 above).


-----

In spite of the CPS's objections, the trial judge gave the first applicant the opportunity to make an application to
vacate his guilty plea (see paragraph 15 above). However, again apparently on the advice of Counsel, who
considered the suggestion “outrageous”, he decided to maintain his “guilty” plea (see paragraph 16 above). That
advice was based at least in part by the fact that the CPS did not intend to withdraw the prosecution (see paragraph
17 above).

167. Although the first applicant was later granted permission to appeal out of time against conviction and sentence
(see paragraphs 38-39 above), in February 2012 his appeal was dismissed as the Court of Appeal concluded that
the decision to prosecute was amply justified. In those proceedings, the Crown focussed on evidence which in its
view suggested that the first applicant was not a victim of trafficking, including the fact that he was found with cash
and had a mobile phone, the factory was in a house and not a “makeshift prison”, the first applicant was provided
with weekly groceries, and there were some inconsistencies in his account (see paragraph 45 above).

168. However, almost two years later the Competent Authority reconsidered its decision in light of the material in
the CPS file but concluded that that information did not change its Conclusive Decision. In particular, it found that
the information provided by the CPS did not change the fact that the two key elements of the definition of
“trafficking” which were required in the case of a minor (being “action” and “purpose”) were present. In its view, the
first applicant had been recruited and harboured in the property (action) for the purpose of exploitation (purpose).
Coercion (means) was not required in the case a minor as he could not give informed consent. According to the
Competent Authority, the factors relied on by the judge in the criminal trial related merely to peripheral issues and
did not go to the core of the elements that made up the definition of trafficking (see paragraphs 53-54 above).

169. The first applicant's case was subsequently referred back to the Court of Appeal but again his appeal was
dismissed. On this occasion the court found that in view of the applicant's age, the fact that he was not a prisoner
and had a significant quantity of cash and a telephone, and the existence of some inconsistencies in his account, it
had been open to the Crown to decide that the prosecution should continue as the relevant nexus had not been
established between the trafficking and the offence (see paragraphs 55-63 above).

170. However, the Crown did not consider that the relevant nexus had not been established between the trafficking
and the criminal offence; rather, it repeatedly found that there was no clear evidence that the first applicant had
been trafficked (see paragraphs 12, 14 and 45 above). Moreover, at no stage did it put forward any clear reasons
for reaching a different conclusion from that of the Competent Authority, and in so far as any reasons can be
gleaned from the information provided to the Member of Parliament (see paragraph 14 above) and to the Court of
Appeal (see paragraph 45 above), as the Competent Authority itself pointed out they related to peripheral issues
and did not go to the core of the elements necessary to establish “trafficking” (see paragraphs 53-54 above). The
Court of Appeal, in twice dismissing the first applicant's appeal, appears to have relied on the same reasons (see
paragraphs 45 and 55-63 above).

171. At the time of the first applicant's arrest, Vietnamese minors had already been identified as a specific
vulnerable group (see the guidance published by the CPS in December 2007 and on 4 February 2009, set out at
paragraphs 72-73 above; CEOP's first “scoping report” published in June 2007, set out at paragraphs 81-82 above;
and CEOP's threat assessment of April 2009 set out at paragraph 83 above). Moreover, as the CPS indicated in its
guidance published in February 2009, trafficked children could be reluctant to disclose the circumstances of their
exploitation either for fear of reprisals, out of misplaced loyalty to their traffickers, or because they have been
coached. They could also be subject to more psychological coercion or threats, such as threatening to report them
to the authorities, threatening their families, or by keeping them socially isolated (see paragraph 73 above).
Consequently, the fact that the first applicant had cash and a mobile phone, that the factory was not itself a prison,
that he was provided with groceries and that his account was at times inconsistent could not, without more, negate
the conclusion that he was trafficked.

172. It would have been open to the CPS – on the basis of clear reasons which were consistent with the definition
of trafficking contained in the Palermo Protocol and the Anti-Trafficking Convention – to have disagreed with the
Conclusive Decision. Had it accepted that the first applicant was a child victim of trafficking, it may also have been
open to it to prosecute him if it considered – in the language used by the Court of Appeal – that there was no nexus


-----

between the offence and the trafficking. However, neither of those two things happened here. Instead, despite the
first applicant being discovered in circumstances which themselves gave rise to a credible suspicion that he was a
victim of trafficking, his case was not referred to the NRM. Instead, he was charged with a criminal offence to which
he pleaded guilty on the advice of his legal representative. Even though he was subsequently recognised by the
Competent Authority as a victim of trafficking, the CPS, without providing adequate reasons for its decision,
disagreed with that assessment and the Court of Appeal, relying on the same inadequate reasons, twice found that
the decision to prosecute him was justified.

173. In light of the foregoing, the Court considers that the State cannot be said to have fulfilled its duty under Article
4 of the Convention to take operational measures to protect the first applicant, either initially, as a potential victim of
trafficking, and subsequently, as a person recognised by the Competent Authority to be the victim of trafficking.

174. Accordingly, it finds that there has been a violation of Article 4 of the Convention.
_(ii) The second applicant_

175. On 21 April 2009 the second applicant was discovered by police close to a cannabis factory (see paragraph 18
above). He was treated as an adult because he initially gave his year of birth as 1972, which would have made him
thirty-seven years old (see paragraph 19 above). Given that he was in fact seventeen years old, it is not clear how
credible his claim to be thirty-seven actually was. In any event, even if the police had no reason to doubt that he
was an adult, the account that he provided in his first police interview should have given rise to some cause for
concern. In particular, he claimed that the door was locked from the outside and he believed the factory was
guarded; that he was not paid for his work; and that he might be killed if he stopped working (see paragraphs 20
and 21 above). Nevertheless, no referral was made to a Competent Authority. Instead, he was charged with being
concerned in the production of a Class B drug (see paragraph 22 above).

176. On 30 April 2009, at a hearing before the Magistrates' Court, he gave his year of birth as 1992. From this point
on it was accepted that he was seventeen years old (see paragraph 23 above). In view of what was known about
the situation of Vietnamese youths working as gardeners in cannabis factories (see paragraphs 72-73 and 81-83
above), the Court considers that from this point, at the very latest, the CPS should have been aware of the
existence of circumstances giving rise to a credible suspicion that he had been trafficked (see paragraph 119
above). However, although the CPS conducted a file review on 1 June 2009, in which it concluded that the second
applicant had been smuggled into the United Kingdom as his parents had funded his journey (see paragraph 24
above), he was only referred to the National Society for the Prevention of Cruelty to Children National Child
Trafficking Advice and Information Line (“NSPCC NCTAIL”) in April 2010 (see paragraph 30 above); and he was
only assessed by the Competent Authority in November that same year (see paragraph 33 above).

177. In the meantime the second applicant pleaded guilty to the offence with which he had been charged (see
paragraph 27 above). Although he also informed counsel that he was locked in the factory and threatened that if he
left he would be killed, counsel did not believe that a defence of duress would be successful as he had the
opportunity to run away and did not take it – a factor which the Competent Authority subsequently considered could
be explained by the fact that he was in a position of dependency and vulnerability (see paragraphs 27 and 33
above).

178. On 28 June 2011 a Special Casework Lawyer from the CPS reviewed the second applicant's case in light of
the conclusions of NSPCC NCTAIL and the Competent Authority. Having particular regard to certain
inconsistencies in his account, the fact that he could have escaped, the fact that he was found with some money
and the fact that he had not been physically injured, she concluded that he was not a victim of trafficking (see
paragraph 36 above). However, nearly all of these factors were addressed by the Competent Authority when it
accepted, on the balance of probabilities, that the second applicant was a victim of trafficking (see paragraph 33
above) and the CPS lawyer does not appear to have explained why she believed that they justified reaching the
opposite conclusion. Moreover, on 7 November 2011 NSPCC NCTAIL produced a supplemental report in which the
social worker had regard to the documentation produced in the criminal proceedings. If anything, she stated that her
conclusion that the second applicant was a victim of trafficking at the time of his arrest had been “strengthened”. In


-----

doing so, she pointed out that accounts given by potential child victims of trafficking to different professionals in
different contexts were rarely consistent (see paragraph 37 above).

179. In dismissing his appeal, the Court of Appeal held that criticism of the process which culminated in the second
applicant being sentenced ignored the fact that he himself had provided accounts suggesting that he had been
“smuggled” into the United Kingdom. It therefore considered that there was no evidence before the Crown Court,
the CPS or the defence which would have suggested that he had been trafficked into the United Kingdom (see
paragraphs 47-48 above).

180. With all due respect to the Court of Appeal, this finding is difficult to reconcile with the CPS's own guidance
published in February 2009, which indicated that trafficked children might be reluctant to disclose the circumstances
of their exploitation and as a consequence prosecutors should themselves be alert to the possibility (see paragraph
73 above). Similar guidance was set out by the Court of Appeal itself in the case of _R. v. O., in which it clearly_
stated that prosecutors must be aware of the protocols and defence lawyers should make enquiries if there is
credible material showing that their client may have been a victim of trafficking (see paragraphs 77-78 above). It is
also difficult to reconcile with the finding by both NSPCC NCTAIL and the Competent Authority that the second
applicant had in fact been trafficked into the United Kingdom (see paragraphs 32, 33 and 37 above).

181. In this regard, the Court has already held that from the point when the second applicant was discovered,
certain aspects of his account should have raised concerns that he might have been a victim of trafficking (see
paragraph 175 above). These concerns should only have intensified when it became apparent that he was a minor
(see paragraph 176 above). From this point on, the State had a positive obligation to take operational measures to
protect him. Instead, the criminal proceedings were allowed to proceed, with the second applicant entering a guilty
plea on the advice of his legal representative. Even though he was subsequently recognised both by NSPCC
NCTAIL and the Competent Authority as a victim of trafficking, the CPS disagreed with that assessment without
providing clear reasons for its decision which went to the core of the elements necessary to establish “trafficking”,
and the Court of Appeal, relying on the same reasons, found that the decision to prosecute was not an abuse of
process.

182. In light of the foregoing, the Court considers that the State cannot be said to have fulfilled its duty under Article
4 of the Convention to take operational measures to protect the second applicant, either initially, as a potential
victim of trafficking, and subsequently, as a person recognised by the Competent Authority to be a victim of
trafficking.

183. Accordingly, it finds that there has been a violation of Article 4 of the Convention.
_III. ALLEGED VIOLATION OF ARTICLE 6 § 1 OF THE CONVENTION_

184. The applicants complained that as a result of the State's breach of its positive obligation under Article 4 they
were denied a fair trial within the meaning of Article 6 of the Convention.

185. Article 6 § 1 of the Convention provides, insofar as relevant:

“In the determination of … any criminal charge against him, everyone is entitled to a fair … hearing … by [a] …
tribunal …”

_A. Admissibility_

186. The Court notes that the applicants' Article 6 complaints are neither manifestly ill-founded nor inadmissible on
any other grounds listed in Article 35 of the Convention. They must therefore be declared admissible.
_B. Merits1. The parties' submissions(a) The first applicant_

187. The first applicant argued that his guilty plea did not in and of itself extinguish his fair trial rights. In his view, it
was not tenable to suggest that a trafficking victim's fair trial rights could be waived simply by a guilty plea. This
appears to have been recognised by the CPS, which in updated guidance cautioned against early guilty pleas in
potential trafficking cases.


-----

188. On the facts of the case the first applicant argued that he had been deprived of a fair trial because the police
had failed to undertake an investigation capable of providing him with exculpatory evidence, even though there was
a credible suspicion that he had been trafficked; and the CPS's assessment of the case was fundamentally flawed
because it conducted its first review before the Competent Authority had concluded its assessment, it subsequently
attached too little weight to that assessment and throughout the process it ignored the indicators of trafficking which
were present. In light of these failings, it was no answer to say that the first applicant should have applied to vacate
his plea or initiate an abuse of process.
_(b) The second applicant_

189. The second applicant argued that he had pleaded guilty on the provision of bad legal advice from his original
lawyers. He was never advised that he might be a victim of trafficking and no steps were taken by his own lawyers
or by the CPS to investigate his case, even in the face of the findings of NSPCC NCTAIL and the Competent
Authority. As he was a child, his case should have been referred automatically into the NRM as a childsafeguarding response. However, there was no process in place for such a referral to be made and as a
consequence he could not be said to have waived his right to a fair trial. Although there was a wealth of objective
evidence that pointed to the likelihood that he might be a victim of trafficking there was no recognition of this by any
State actor prior to the date of his criminal conviction.
_(c) The Government_

190. The Government argued that the first applicant had waived his right to argue that he should not have been
prosecuted by virtue of the combination of (i) his failure to raise any argument that he should not have been
prosecuted, by way of abuse of process or judicial review, notwithstanding that he had been advised of the
possibility; (ii) his plea of guilty; and (iii) his subsequent decision not to take advantage of the opportunity, expressly
offered by the domestic court, to argue that he should be permitted to withdraw his guilty plea in order to raise any
matter arising from his identification by the Competent Authority as a victim of trafficking.

191. In addition, the Government argued that the process as a whole had been fair. The first applicant had the
benefit of two separate appeals, each of which was heard before the Lord Chief Justice of the day. His arguments
were examined thoroughly, including arguments about abuse of process and the adequacy of his legal
representation. However, the Court of Appeal held that even if he had raised abuse of process in the court below it
would not have been successful. His hearing was therefore entirely fair under Article 6 § 1 of the Convention.

192. The Government also argued that the second applicant, by virtue of his guilty plea, had waived his right to a
determination of guilt or innocence by the domestic courts.

193. In any event, the Government submitted that he had the benefit of free and independent legal advice together
with an interpreter; and he had the benefit of a significant period of time, between his arrest on 21 April 2009 and
his plea in early July 2009, in which to reflect on the position. However, at this stage the detailed account which he
gave to his lawyers was factually incompatible with trafficking and forced labour. Nonetheless, in an appeal before
the Lord Chief Justice he was allowed to argue that his plea had not been fairly entered and to introduce a
substantial quantity of material based on a new factual account.
_2. The Court's assessment_

194. In determining whether there has been a violation of Article 6 § 1 of the Convention, the Court must answer the
following questions: first of all, did the failure to assess whether the applicants were the victims of trafficking before
they were charged and convicted of drugs-related offences raise any issue under Article 6 § 1 of the Convention;
secondly, did the applicants waive their rights under that Article by pleading guilty; and finally, were the proceedings
as a whole fair?
_(a) Did the failure to investigate whether the applicants were the victims of trafficking before they were charged and_
_convicted of drugs-related offences raise any issue under Article 6?_

195. The Court has repeatedly underlined the importance of the investigation stage for the preparation of the
criminal proceedings, as the evidence obtained during this stage determines the framework in which the offence
charged will be considered at the trial (see _Salduz v. Turkey [GC], no. 36391/02, § 54, ECHR 2008,_ _Dvorski v._


-----

_Croatia [GC], no. 25703/11, § 108, ECHR 2015). It has also recognised that an accused often finds himself in a_
particularly vulnerable position at that stage of the proceedings, the effect of which is amplified by the fact that
legislation on criminal procedure tends to become increasingly complex, notably with respect to the rules governing
the gathering and use of evidence. In most cases, this particular vulnerability can only properly be compensated for
by the assistance of a lawyer (see Salduz, cited above, § 54). The fairness of proceedings requires that an accused
should be able to obtain the whole range of services specifically associated with legal assistance. In this regard,
counsel has to be able to secure without restriction the fundamental aspects of that person's defence: discussion of
the case, organisation of the defence, collection of evidence favourable to the accused, preparation for questioning,
support for an accused in distress and checking of the conditions of detention (see Dvorski, cited above, § 108).

196. Although victims of trafficking are not immune from prosecution, an individual's status as a victim of trafficking
may affect whether there is sufficient evidence to prosecute and whether it is in the public interest to do so (see
paragraph 161 above). Evidence concerning an accused's status as a victim of trafficking is therefore a
“fundamental aspect” of the defence which he or she should be able to secure without restriction.

197. In the present cases, it is true that the applicants' representatives could themselves have referred the
applicants to the NRM. Both applicants were legally represented from the outset, a factor generally considered by
the Court to be an important safeguard against any unfairness in the proceedings. The second applicant was
publicly funded (see paragraph 25 above) and although there is no evidence to this effect before the Court, it is
likely that – at least initially – the first applicant also had the benefit of legal aid. Even so, in both cases the
applicants' representatives appear to have dismissed out of hand the possibility that they were victims of trafficking.
In the case of the first applicant, the possibility that he was a victim of trafficking was raised both by Social Services
and Refugee and Migrant Justice (see paragraph 8 above); however, even after he received the Competent
Authority's Conclusive Decision his lawyer considered the suggestion that he change his plea to be “outrageous”
since in his view the first applicant had not been trafficked (see paragraph 16 above). While the second applicant's
lawyer appears also to have been alerted to the possibility that he was trafficked (see paragraph 25 above), this
does not seem to have resulted in any further action by the lawyer.

198. Nevertheless, while criminal defence lawyers should undoubtedly be alert to indicators of trafficking, their
failure to recognise or act upon such indicators cannot by itself absolve the State and its agents of their
responsibility to do so. As already noted, at least one of the applicants was publicly funded and the Court has held,
albeit in the context of Article 6 § 3 (c) of the Convention, that the competent national authorities are required to
intervene in the event of a manifest failure by legal aid counsel to provide effective representation (see _Daud v._

_Portugal, 21 April 1998, § 38, Reports of Judgments and Decisions 1998‑II). Although neither applicant has invoked_

that Article, it is clear from this line of jurisprudence that the State cannot hide behind the shortcomings of legal aid
counsel where those shortcomings amount to a “manifest failure to provide effective representation”.

199. In the cases at hand it is not necessary to determine whether the aforementioned shortcomings of the
applicants' legal representatives reached this high threshold. In the context of Article 4 of the Convention, it is the
State which is under a positive obligation both to protect victims of trafficking and to investigate situations of
potential trafficking and that positive obligation is triggered by the existence of circumstances giving rise to a
credible suspicion that an individual has been trafficked and not by a complaint made by or on behalf of the
potential victim (see paragraphs 152 and 155 above). The State cannot, therefore, rely on any failings by a legal
representative or indeed by the failure of a defendant – especially a minor defendant – to tell the police or his legal
representative that he was a victim of trafficking. As the 2009 CPS guidance itself states, child victims of trafficking
are a particularly vulnerable group who may not be aware that they have been trafficked, or who may be too afraid
to disclose this information to the authorities (see paragraph 73 above). Consequently, they cannot be required to
self-identify or be penalised for failing to do so.

200. The Court has already found that the authorities' failure to conduct a timely assessment of whether the
applicants had in fact been trafficked amounted to a breach of their positive obligations under Article 4 of the
Convention (see paragraphs 174 and 183 above). In the context of Article 6 of the Convention it considers that the
lack of such an assessment prevented them from securing evidence which may have constituted a fundamental
aspect of their defence


-----

_(b) Did the applicants waive their rights under Article 6 of the Convention?_

201. It is true that neither the letter nor the spirit of Article 6 of the Convention prevents a person from waiving of his
own free will, either expressly or tacitly, the entitlement to the guarantees of a fair trial. However, such a waiver
must, if it is to be effective for Convention purposes, be established in an unequivocal manner; it must not run
counter to any important public interest; and it must be attended by minimum safeguards commensurate with its
importance (see _Poitrimol v. France, 23 November 1993, § 31, Series A no. 277-A;_ _Hermi v. Italy [GC], no._

18114/02, § 73, ECHR 2006‑XII; _Sejdovic v. Italy [GC], no. 56581/00, § 86, ECHR 2006‑II; and_ _Dvorski, cited_

above, § 100). In addition, it must not be tainted by constraint (see Deweer v. Belgium, 27 February 1980, §§ 52-54,
Series A no. 35). In the context of plea bargains, the Court has held that by not contesting a criminal charge, an
applicant may waive his right to have the criminal case against him examined on the merits. However, a decision to
accept a plea bargain should be accompanied by the following conditions: (a) the bargain must be accepted in full
awareness of the facts of the case and the legal consequences and in a genuinely voluntary manner; and (b) the
content of the bargain and the fairness of the manner in which it had been reached between the parties must be
subject to sufficient judicial review (Natsvlishvili and Togonidze v. Georgia, no. 9043/05, § 92, ECHR 2014
(extracts)).

202. In the cases at hand, the applicants' guilty pleas were undoubtedly “unequivocal” and as they were legally
represented they were almost certainly made aware that there would be no examination of the merits of their cases
if they pleaded guilty. However, in the absence of any assessment of whether they were trafficked and, if so,
whether that fact could have any impact on their criminal liability, those pleas were not made “in full awareness of
the facts”. Furthermore, given that trafficking threatens the human dignity and fundamental freedoms of its victims
and is not compatible with a democratic society and the values expounded in the Convention (see Rantsev, cited
above, § 282), in the absence of any such assessment any waiver of rights by the applicants would have run
counter to the important public interest in combatting trafficking and protecting its victims.

203. It is true that following receipt of the Conclusive Decision the trial judge gave the first applicant an opportunity
to apply to vacate his plea (see paragraph 15 above), and that the first applicant decided not to do so. This decision
was taken on the advice of his legal representative, who told him that even if such an application was successful
the CPS would not withdraw the prosecution. He was also told that any judicial review of the decision to prosecute
would have little prospect of success (see paragraph 17 above). In the Court's view, the first applicant, being a
minor who was arrested and prosecuted within a foreign criminal justice system, who had already pleaded guilty to
a criminal offence in circumstances which did not amount to a waiver of his Article 6 rights, cannot be said to have
subsequently waived those rights by deciding not to pursue applications against the robust advice of his legal
representative.

204. The Court does not, therefore, consider that the applicants waived their rights under Article 6 § 1 of the
Convention.
_(c) Whether the fairness of the proceedings as a whole was prejudiced_

205. As the Court has found on numerous occasions, compliance with the requirements of a fair trial must be
examined in each case having regard to the development of the proceedings as a whole and not on the basis of an
isolated consideration of one particular aspect or one particular incident, although it cannot be ruled out that a
specific factor may be so decisive as to enable the fairness of the trial to be assessed at an earlier stage in the
proceedings (see, for example, Beuze v. Belgium [GC], no. 71409/10, § 121, 9 November 2018).

206. In this regard, the Court observes that even though the applicants had pleaded guilty to the offences charged,
the CPS nevertheless reviewed its decision to prosecute them after the Competent Authority recognised them as
victims of trafficking. In addition, they were both subsequently granted permission to appeal out of time and the first
applicant's case was referred back to the Court of Appeal by the CCRC for a further appeal.

207. However, as the Court has already noted, in respect of both applicants the reasons given by the CPS for
disagreeing with the Competent Authority were wholly inadequate. Insofar as any reasons were given, they were


-----

not consistent with the definition of trafficking contained in the Palermo Protocol and the Anti-Trafficking Convention
(see paragraphs 170, 172 and 177-181 above).

208. Moreover, on both occasions the Court of Appeal was primarily concerned with whether there had been a
misapplication of prosecutorial discretion sufficient for the decision to prosecute to have been an abuse of process,
and in dismissing the applicants' appeals it relied on the same reasons which were advanced by the CPS, and
which the Court has already found to be inconsistent with the definition of trafficking in international law (see
paragraphs 170, 172 and 177-181 above). Although the applicants invoked Article 4 of the Convention it did not
consider their cases through the prism of the State's positive obligations under that Article. On the contrary, it
restricted itself to a relatively narrow review; in dismissing the appeals by both applicants the Court of Appeal made
it clear that a defendant is provided with one opportunity to give his instructions to his legal advisors and that it
would only be “in the most exceptional cases” that the court would consider it appropriate to allow the defendant to
advance fresh instructions about the facts for the purposes of an appeal against conviction (see paragraph 50
above). In the Court's view, such an approach would in effect penalise victims of trafficking for not initially identifying
themselves as such and allow the authorities to rely on their own failure to fulfil their duty under Article 4 of the
Convention to take operational measures to protect them. Consequently, the Court does not consider that the
appeal proceedings cured the defects in the proceedings which led to the applicants' charging and eventual
conviction.

209. The foregoing considerations are sufficient to enable the Court to conclude that in respect of both applicants
the proceedings as a whole could not be considered “fair”.

210. There has accordingly been a violation of Article 6 § 1 of the Convention.
_IV. ALLEGED VIOLATION OF ARTICLE 14 READ TOGETHER WITH ARTICLE 6 OF THE CONVENTION_

211. The second applicant also complained that there had been a breach of Article 14 read together with Article 6 of
the Convention. In this regard, he contended that as a victim of trafficking exploited for the purposes of producing
illegal drugs he was treated differently from victims of trafficking exploited for other criminal purposes.

212. However, this complaint was not raised either expressly or in substance before the domestic courts and as
such, domestic remedies cannot be said to have been exhausted.

213. This complaint must therefore be declared inadmissible pursuant to Article 35 §§ 1 and 4 of the Convention.
_V. APPLICATION OF ARTICLE 41 OF THE CONVENTION_

214. Article 41 of the Convention provides:

“If the Court finds that there has been a violation of the Convention or the Protocols thereto, and if the internal
law of the High Contracting Party concerned allows only partial reparation to be made, the Court shall, if
necessary, afford just satisfaction to the injured party.”

_A. Damage_

215. The first applicant claimed compensation for non-pecuniary damage in the form of loss of liberty, mental
anguish and distress.

216. The second applicant claimed the sum of 75,000 euros (EUR) for non-pecuniary damage, in particular the
distress and practical issues connected with having a past criminal conviction and the prolonged uncertainty with
regard to his status as a child victim of trafficking.

217. In respect of both applicants the Government argued that the finding of a violation of Articles 4 and/or 6 of the
Convention should constitute sufficient just satisfaction in the case.

218. The Court notes at the outset that the first applicant has not quantified his claim for non-pecuniary damages.
Although Article 41 does not itself impose on applicants or their representatives before the Court any procedural
requirements, on the basis of the Rules of Court and The Practice Direction on Just Satisfaction Claims (issued by
the President of the Court in accordance with Rule 32 of the Rules of Court on 28 March 2007) it is the Court's


-----

prevailing practice that applicants should articulate a “claim” for just satisfaction during the communication stage of
the proceedings. Nevertheless, the Court has applied a degree of flexibility in respect of non-pecuniary damage and
has in practice agreed to examine claims for which applicants did not quantify the amount, “leaving it to the Court's
discretion” (see Nagmetov v. Russia [GC], no. 35589/08, § 72, 30 March 2017 and cases cited therein). It therefore
considers that it can make an award in respect of non-pecuniary damage even though the first applicant has not
quantified his claim.

219. In respect of both applicants the Court refers to its finding that there has been a violation of Articles 4 and 6 of
the Convention on account of the failure of the respondent State to fulfil its positive obligations under Article 4 to
take operational measures to protect the victims of trafficking. The Court has no doubt that the applicants suffered
distress on account of the criminal proceedings and have faced certain obstacles on account of their criminal
records. However, it must also bear in mind that the aforementioned violations were essentially procedural in nature
and as such the Court has not had to consider the merits of the decisions to prosecute the applicants. The Court
therefore considers it appropriate to grant to each of the applicants the sum of EUR 25,000 in respect of nonpecuniary damage, plus any tax that may be chargeable.
_B. Costs and expenses_

220. The first applicant claimed 39,660.62 British pounds (GBP) for the costs and expenses incurred before the
Court, a figure which included the fees of four counsel and one solicitor.

221. The second applicant claimed GBP 19,810.00 for the costs and expenses incurred before the Court.

222. The Government argued that the number of hours claimed by the first applicant's solicitor were excessive, as
were the professional costs of counsel.

223. According to the Court's case-law, an applicant is entitled to the reimbursement of costs and expenses only in
so far as it has been shown that these were actually and necessarily incurred and are reasonable as to quantum. In
the present case, regard being had to the documents in its possession and the above criteria, the Court considers it
reasonable to award, for the proceedings before it, EUR 20,000 to each applicant, plus any tax that may be
chargeable to them.
_C. Default interest_

224. The Court considers it appropriate that the default interest rate should be based on the marginal lending rate of
the European Central Bank, to which should be added three percentage points.
**FOR THESE REASONS, THE COURT**

_1. Decides, unanimously, to join the applications;_

_2. Declares, unanimously, the applicants' complaints concerning Articles 4 and 6 § 1 of the Convention admissible_
and the remainder of the applications inadmissible;

_3. Holds, unanimously, that there has been a violation of Article 4 of the Convention;_

_4. Holds, unanimously, that there has been a violation of Article 6 § 1 of the Convention;_

_5. Holds,_

(a) by five votes to two, that the respondent State is to pay, within three months from the date on which the
judgment becomes final in accordance with Article 44 § 2 of the Convention, EUR 25,000 (twenty-five thousand
euros) to each applicant, plus any tax that may be chargeable, in respect of non-pecuniary damage, to be
converted into the currency of the respondent State at the rate applicable at the date of settlement:

(b) unanimously, that the respondent State is to pay, within three months from the date on which the judgment
becomes final in accordance with Article 44 § 2 of the Convention, EUR 20,000 (twenty thousand euros) to
each applicant, plus any tax that may be chargeable to the applicants, in respect of costs and expenses;


-----

(c) unanimously, that from the expiry of the above-mentioned three months until settlement simple interest shall
be payable on the above amounts at a rate equal to the marginal lending rate of the European Central Bank
during the default period plus three percentage points;

_6. Dismisses, unanimously, the remainder of the applicants' claim for just satisfaction._

**End of Document**


-----

