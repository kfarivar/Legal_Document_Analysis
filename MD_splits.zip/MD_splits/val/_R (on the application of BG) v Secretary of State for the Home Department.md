# *R (on the application of BG) v Secretary of State for the Home Department

 [2016] EWHC 786 (Admin)

Queen's Bench Division, Administrative Court (London)

Cranston J

12 April 2016Judgment

**Parosha Chandran and Claire Physsas (instructed by Duncan Lewis Solicitors) for the Claimant**

**Catherine Rowlands (instructed by the Government Legal Department) for the Defendant**

Hearing dates: 15/03/2016 and 16/03/2016

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Cranston:**

**I INTRODUCTION**

**1. This judicial review raises issues about the definition of human trafficking and its application to the**
claimant; the relationship between the Dublin Regulation for the return of asylum seekers within the EU on
the one hand and international human trafficking instruments, Article 4 of the European Convention on
Human Rights (“ECHR”) and the Secretary of State's policies on the other; and whether the claimant and
her child ought to be returned to Italy in light of conditions there, an assurance by the Italian authorities
about how families will be treated on return, and a pending appeal on returns to Italy under the Dublin
Regulation.

**II LEGAL AND POLICY BACKGROUND**

2. The Council of Europe agreed the _Convention on Action against Trafficking in Human Beings (“the_
Trafficking Convention”) in 2005. The scope of the Convention in Article 2 such that it applies equally to
national as well as transnational trafficking. In defining trafficking in persons Article 4 of the Convention
replicates Article 3 of the UN Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially
_Women and Children 2000, supplementing the_ _UN Convention against Transnational Organised Crime_
_2000 (“the Palermo Protocol”). Article 4 is as follows:_

“a. “Trafficking in human beings” shall mean the recruitment, transportation, transfer, harbouring or receipt
of persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs;


-----

b. The consent of a victim of “trafficking in human beings” to the intended exploitation set forth in
subparagraph (a) of this article shall be irrelevant where any of the means set forth in subparagraph (a)
have been used…”

Article 10 of the Convention provides for the identification of victims of trafficking. Article 10(2) reads:

“2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the
competent authorities…”

3. Under Article 13 the Parties to the Convention must provide a recovery and reflection period of at least
30 days, if there are reasonable grounds to believe that the person concerned is a victim of trafficking so
that he or she can recover and escape the influence of traffickers and/or to take an informed decision on
cooperating with the competent authorities. During this period Article 13 states that it is not possible to
enforce any expulsion order against that person and the Parties must authorise the persons concerned to
stay in their territory. Those found to be victims are to be issued with residence permits under the
conditions provided for in Article 14 of the Convention.

4. The Explanatory Report on the Convention states that trafficking in human beings consists of a
combination of the three basic components given in the definition,

- the action of “recruitment, transportation, transfer, harbouring or receipt of persons”;

- by means of “the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of
the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person”; and

- for the purpose of exploitation, which includes “the exploitation of the prostitution of others or other forms
of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the
removal of organs”: [74].

The Explanatory Report continues:

“75. Trafficking in human beings is a combination of these constituents and not the constituents taken in
isolation. For instance, “harbouring” of persons (action) involving the “threat or use of force” (means) for
“forced labour” (purpose) is conduct that is to be treated as trafficking in human beings... Similarly
recruitment of persons (action) by deceit (means) for exploitation of prostitution (purpose).

76. For there to be trafficking in human beings ingredients from each of the three categories (action,
means, purpose) must be present together…”

5. As to actions and means, the Explanatory Memorandum states, inter alia:

“78. The actions the Convention is concerned with are “recruitment, transportation, transfer, harbouring or
receipt of persons”. The definition endeavours to encompass the whole sequence of actions that leads to
exploitation of the victim…

80. As regards “transportation", it should be noted that, under the Convention, transport need not be across
a border to be a constituent of trafficking in human beings…

83. By abuse of a position of vulnerability is meant abuse of any situation in which the person involved has
no real and acceptable alternative to submitting to the abuse. The vulnerability may be of any kind, whether
physical, psychological, emotional, family-related, social or economic. The situation might, for example,
involve insecurity or illegality of the victim's administrative status, economic dependence or fragile health.
In short, the situation can be any state of hardship in which a human being is impelled to accept being
exploited. Persons abusing such a situation flagrantly infringe human rights and violate human dignity and
integrity, which no one can validly renounce.”


-----

6. The Explanatory Memorandum continues that a wide range of means must be contemplated including
violence by pimps to keep prostitutes under their thumb and taking advantage of a person's position of
vulnerability. It adds that the various cases reflect differences of degree rather than any difference in the
nature of the phenomenon: [84]. Trafficking can occur before the exploitation of a person begins: [87].

7. In commenting on Article 13 the Explanatory Report states that a victim must not be removed from a
Party's territory during the recovery and reflection period, and each Party must provide victims, without
delay, with the relevant documents authorising them to remain on its territory during that period.

8. In the European Union Directive 2011/36/EU on preventing and combating trafficking in human beings
and protecting its victims (“EU Trafficking Directive”) was adopted on 5 April 2011. It replaced Council
Framework Decision 2002/629/JHA. The Directive adopts and expands upon the obligations and
definitions contained in the Palermo Protocol and the Trafficking Convention. It is concerned in the main
with the criminalising of trafficking in human beings. However Article 11, supported by recital (18), requires
Member States to take the necessary measures to establish appropriate mechanisms aimed at the early
identification of those trafficked and to provide assistance to and support for victims: see _R_
_(Gudanaviciene) v. Director of Legal Aid Casework_ _[2014] EWCA Civ 1622 [2015] 1 W.L.R. 2247._

9. Article 4 of the European Convention on Human Rights provides for freedom from slavery, servitude
and forced labour. In _Rantsev v._ _Cyprus_ _[[2010] ECHR 25965/04; 28 EHRC 313, the Strasbourg Court](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_
interpreted it as extending to human trafficking. In assessing whether there had been a violation of Article
4, the Court said in familiar language that national legislation had to ensure the practical and effective
protection of the rights of victims or potential victims of trafficking. In addition to criminal law measures to
punish traffickers, the Court said, Article 4 required member states to take operational measures to protect
victims, or potential victims, of trafficking and to investigate potential cases of trafficking. The Court referred
to the Palermo Protocol and the Trafficking Convention: [279]-[289].

10. The UK ratified the Trafficking Convention on 17 December 2008 and it entered into force on 1 April
2009. This led to the creation of the UK's National Referral Mechanism (“the NRM”) in 2009. The
Convention is implemented in the UK by means of the Secretary of State's policies on human trafficking in
the form of Home Office Guidance. There was no submission before me that the Secretary of State's
policies are inconsistent with the provisions of the Trafficking Convention or with Article 4 ECHR.

11. First is the Home Office Guidance, Victims of human trafficking – competent authority guidance (“the
HO competent authority guidance”). The version relevant in the present claim was valid from 24 October
2013, although there is no material difference in the current guidance as regards this case. The guidance
explains that the NRM is a victim identification and support process designed to make it easier for the
agencies involved in trafficking cases to cooperate. There are two “competent authorities” to administer
the NRM, the UK Human Trafficking Centre which is the competent authority for UK or European Economic
Area nationals, and the Home Office for third-country nationals such as the claimant.

12. The guidance reproduces the three components of human trafficking – action, means and purpose –
set out in paragraph 74 of the Explanatory Report on the Convention. It also quotes from the guidelines of
the Office of the United Nations High Commissioner for Refugees (“UNHCR”) on international protection,
that trafficking is a process comprising a number of interrelated actions rather than a single act at a given
point in time.

“Once initial control is secured, victims are generally moved to a place where there is a market for their
services, often where they lack language skills and other basic knowledge that would enable them to seek
help. While these actions can all take place within one country's borders, they can also take place across
borders with the recruitment taking place in one country and the act of receiving the victim and the
exploitation taking place in another. Whether or not an international border is crossed, the intention to
exploit the individual concerned underpins the entire process.”

As regards deception, the Home Office competent authority guidance states that an example would be a
recruiter who has provided the worker with maliciously false, inaccurate, or misleading information, for


-----

example, a person who ends up being exploited through prostitution may have been under the impression
originally that there were legitimate education or employment opportunities.

13. The guidance contains a number of questions to help uncover whether someone has been coerced:
whether the person was able to leave the residence or place whenever they wanted; whether they had
been outside the house or work place on their own; whether they had their own key to the residence; and
whether they had bought the SIM card for their mobile telephone themselves. The guidance states: “The
way in which different people describe their experiences means you must not rely on victims to self-identify
in explicit or obvious ways.” Set out later in the guidance are “myths about human trafficking”. Three
examples are that the person did not take opportunities to escape so is not being coerced; crossing a
border is required in order to be trafficked; and it cannot be human trafficking when organiser and victim
are related, married and living together or lovers. The commentary to the latter is that there are numerous
incidents where “boyfriends” have groomed women into sexual exploitation.

14. The two-stage process for identifying victims of trafficking – the reasonable grounds and conclusive
grounds stage – is spelt out in the guidance. The first is an initial filter before the conclusive decision is
taken. The reasonable grounds test considers whether the statement “I suspect but cannot prove that the
person is a victim of trafficking” holds true. If a reasonable grounds decision is positive the individual is
given a 45-day reflection and recovery period, which can be extended. During that period, the person is
granted temporary admission or temporary release.

15. The second stage is the conclusive grounds decision. The standard of proof for it is on the balance of
probabilities. Where the decision is positive and the person does not meet the criteria for any of the other
leave or protection categories, the guidance states that it may be appropriate to grant a victim of trafficking
discretionary leave to remain if the personal circumstances are compelling, for example, to complete a
course of medical treatment before their return home.

16. A second Home Office guidance is entitled Victims of trafficking guidance for frontline staff (“the HO
frontline guidance”); valid from 24 January 2013 has again been replaced, although nothing turns on that.
When addressing identification, the guidance states that once frontline staff identify a potential victim they
must refer the person to the competent authority, which has specially trained staff to make an assessment.
The guidance states that any frontline staff may identify victims of trafficking, but among those who must
be particularly alert are the Border Force and detention centres. The guidance states that only
organisations classed as first responders can refer a potential victim into the NRM. Listed among first
responders are the Home Office and the Poppy Project. Potential victims must be referred to a competent
authority by completion of an NRM referral form. Adult victims must give their consent to a referral.

17. Among those whom the Home Office's Enforcement Instructions and Guidance as a general rule
regards as suitable for detention in only very exceptional are persons identified by the competent
authorities as victims of trafficking: paragraph 55.10.

18. In order to ensure full compliance with the obligations contained in the EU Trafficking Directive, the UK
[made changes to the Sexual Offences Act 2003 and the Asylum and Immigration (Treatment of Claimants,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)
_[etc.) Act 2004 through sections 109 and 110 of the Protection of Freedoms Act 2012. These two](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1HF-00000-00&context=1519360)_
provisions have in turn been replaced by section 2 of the **_Modern Slavery Act 2015, which criminalises_**
human trafficking.

**III CLAIMANT'S IMMIGRATION HISTORY**

19. The claimant is from Albania and her date of birth is 8 January 1991. She arrived in the UK on 20 April
2013 by train at St Pancras railway station. She was travelling on her own passport but without a visa.
There was a Brussels to Lille ticket in her handbag. She had taken advantage of what has been known as
the Lille loophole. Her passport showed that she had arrived in Milan on 17 April 2013.

20. At St Pancras she applied for asylum. There was a screening interview that evening by a female
official. When asked why she had come to the UK the claimant said for protection. She stated that she
met a boy at University. Her family were against it. She thought they were serious. In July 2012 they went


-----

to live in Tirana. By October 2012 he told her they had no money. The boyfriend started to shout and
mistreat her and told her to work as a prostitute, which she did. He threatened the claimant and her family
as well. She met a client who funded her trip to the UK. She would not give details of either the boyfriend
or the elderly client. She stated that she knew no-one in the UK. She flew from Tirana to Malpensa, Italy;
someone had waited for her with a car outside the airport and drove her to Belgium. She then travelled to
the UK. After the interview, the claimant was detained.

21. A Home Office file note the following day, 21 April 2013, recorded that the claimant had claimed
asylum by stating that her life and her family's were in danger from a boyfriend back in Albania. It recorded
that it was a possible third-country case under the Dublin Regulation for return to Italy. There was an email
dated 23 April 2013 from the Poppy Project suggesting that the claimant may have been trafficked into the
UK, but acknowledging that it had limited information since at that stage it had only spoken to her solicitors.
The Poppy Project was part of a charity providing support, advocacy and accommodation for trafficked
women. On 24 April 2013, solicitors acting for the claimant requested her temporary admission. This was
refused so that checks could be made.

22. On 26 April 2013, the female official who had interviewed the claimant at St Pancras received an email
from a deputy immigration manager suggesting that, as the first responder, she should have referred the
matter to her competent authority since some of the responses were indicative (so the Poppy Project had
said) of trafficking. The St Pancras officer replied that the decision was taken not to refer the claimant to
the NRM since she did not believe the claimant was a victim of trafficking. She gave no details of either
the boyfriend or the client, stated she knew no-one in the UK and showed no emotion in the interview.
There were several file notes dated 26 April 2013: there had been contact with the Poppy Project and the
Poppy Project said it would obtain the claimant's consent and make a referral themselves if they decided it
was appropriate. One file note stated that the case was a third-country unit case.

23. The claimant was interviewed by the Poppy Project on 2 May 2013 and they decided not to refer the
claimant to the NRM. The claimant's solicitors later recorded that while the Poppy Project accepted that
her account of being forced into sex work in Tirana was credible, the project's view was that “the issue was
the credibility of her account regarding how she arrived in the UK from Albania.”

24. The claimant applied for bail on 9 May 2013 on the basis that she had a friend in the UK who would
accommodate her. Bail was opposed on the basis that the claimant had been deceptive in stating that she
did not know who paid for her trip, was an absconding risk and because checks of her sureties had proved
unsatisfactory. The immigration judge refused bail: he was not satisfied with her sureties (two family
friends in the UK) or with the accommodation, and refused.

25. Italy accepted responsibility for the claimant's case under the Dublin Regulation on 9 May 2013. On
13 May 2013 the Secretary of State refused the claimant's asylum claim and certified it on the basis she
could be returned to Italy as a safe third-country which would examine her asylum claim regarding Albania.
On 16 May 2013 the claimant was refused leave to enter the UK. Removal directions were set for the
claimant's return to Italy.

26. On 21 May 2013, the claimant's solicitors wrote to the Poppy Project acknowledging that they had
decided not to make an NRM referral but asking them to revisit their decision. The solicitors retold her
account of being forced into sex work in Tirana by an abusive former boyfriend, then being “assisted to
leave the country by a “client” who then arranged for another man in Italy to pass her through to the UK.
This gent gave her no control over where to seek safety and protection.”

27. That same day the claimant's solicitors sent a pre-action protocol letter to the Secretary of State asking
that the claimant be referred to the NRM. That letter also made a claim for breach of Article 3 ECHR on
the basis that her removal to Italy would expose her to poor reception conditions there. The letter also
challenged the decision to remove her on the basis that she was a potential victim of trafficking.

28. Removal directions set for 28 May 2013 were cancelled on receipt of a pre-action protocol letter from
the claimant's new, her current, solicitors. The claimant was notified of this on 23 May 2013. The claim for
judicial review was lodged on 24 May 2013 and coupled with an application for urgent consideration. The


-----

grounds challenged the decision to certify the asylum claim without regard to the claimant's status as a
potential or actual victim of trafficking, her removal to Italy based on the conditions there, the failure of the
Secretary of State to exercise discretion under Articles 3(2) and 15 of the Dublin Regulation to take charge
of the claimant's asylum claim, the ongoing failure to refer the claimant to the NRM, and the claimant's
detention. Leggatt J refused this on 24 May 2013. He commented that the application for urgent
consideration was wholly unjustified when removal directions had been cancelled.

**29. On 30 May 2013 the claimant again sought temporary admission to the UK. The Secretary of State**
decided to maintain detention on 31 May 2013 until a sealed copy of the judicial review form had been
received. The claimant was released on 4 June 2013. The form IS.96 of that date gave her temporary
admission as a person who was liable to be detained and stated: "You have NOT been given leave to enter
[the United Kingdom within the meaning of the Immigration Act 1971." On 14 June 2013, the Secretary of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
State wrote to the claimant's solicitors that a decision had been made to refer her to the NRM and
proposing that her claim be stayed by consent.

**IV THE TRAFFICKING DECISION**

30. The Secretary of State sent a draft NRM referral form to the claimant's solicitors on 18 June 2013,
commenting that it was very brief because the claimant had provided limited information, but inviting
additions to the draft and suggestions by the claimant.

31. The claimant's solicitors wrote to the Secretary of State six months later, on 29 January 2014, in
support of the trafficking claim. They attached a report from Abigail Stepnitz, as an independent human
trafficking expert, dated 16 September 2013, and a psychological assessment report prepared by Dr
Joycelyn Blumberg, a chartered clinical psychologist, dated 13 January 2014. Ms Stepnitz had worked for
the Poppy Project for several years and has published reports on trafficking. The claimant signed the NRM
referral form. The only indication on the standard form which was ticked was “threats against the individual
or their family member”. By way of a consent order the judicial review was stayed.

32. Ms Stepnitz met the claimant once. Her report began by breaking down what she characterised as the
claimant's trafficking experience into three: trafficking within Albania for sexual exploitation, travel from
Albania to Italy to escape sexual exploitation and travel from Albania to the UK as a result of previous
sexual exploitation. On the issue of the claimant's recruitment and the negation of consent, she said that
the boyfriend, K's, “behaviours (sic) are indicators of 'grooming'”. She stated that exploitation of a position
of vulnerability was perhaps the least understood but often the most important means of recruitment as it
spoke to the victim's overall susceptibility to trafficking. She added:

“I can see how the indicators of trafficking in this case can potentially be misidentified as simply a severe
form of domestic abuse, in which a man forces his girlfriend into prostitution to earn money. However the
fact that K stopped all pretence of a relationship with [the claimant] once the exploitation began may speak
to a more sinister intention to exploit her all along, as opposed to opportunistically when he felt they
needed more money. This is critical, of course, to the definition of trafficking as it is clear that in trafficking
the movement of the person must be done for the purpose of exploitation. Meaning that for [the claimant's]
experiences to meet with the definition it is important to recognise K's intentions all along.”

33. Ms Stepnitz also considered that the money K was profiting from per month was in excess of the
average yearly wage in Tirana, which “speaks to” his intention to traffic all along. In her opinion, all of the
trafficking indicators were present and she should have been positively identified as a victim of trafficking
for sexual exploitation. Ms Stepnitz opined that the claimant could be at considerable risk of re-trafficking.
There had been a failure by the Secretary of State to investigate the claimant's claim, indicative of a
catalogue of errors and failures to implement basic procedural guidance. Ms Stepnitz concluded:

“147. She was subjected to the following means during the recruitment part of her trafficking experience:

**Coercion: She was in a relationship with K and believed he loved her. She was afraid of the implications if**
her strict, traditional family knew she had a boyfriend.


-----

**Deception: She was made to believe that moving to Tirana with K 1) was a genuine opportunity to migrate**
and live with him; 2) she would be able to return to school to complete her studies; and 3) she would have
the possibility to be reunited with her family.

**Abuse of vulnerability: Her naïveté regarding relationships, her sheltered upbringing and her lack of**
experience negotiating complex social situations.

**148. [The claimant's] experiences obviously meet the transfer part of the trafficking definition as she was**
moved from Shkodra to Tirana. On a micro level she was moved nightly from the flat to a street, and then
repeatedly to different hotels.

**149. Finally, [the claimant] experienced exploitation in prostitution, meeting the exploitation portion of the**
definition. All constituent elements of the trafficking definition are present in her claim.”

34. In preparing her psychological report, Dr Blumberg had interviewed the claimant for three hours with
an interpreter. The claimant told her that if returned to Albania she and her family would be in danger from
K, since: “I have done many things of which they would not be proud and will never accept.” She was
being supported by a family friend, Artan, and his wife. Midway through the interview, she told Dr
Blumberg that she was seven months pregnant. (The child was born on 9 March 2014.) The father, she
explained, was a friend of Artan: the evening of her release from detention they had celebrated, she had
been very drunk and they had sexual intercourse outside the restaurant. The friend denied that it was his
child. In the opinion section of her report, Dr Blumberg concluded that the claimant was a very vulnerable
young woman suffering from PTSD and major depression.

35. The Secretary of State issued its reasonable grounds decision on 4 June 2014: there were reasonable
grounds to believe that the claimant was trafficked. The letter stated that during the 45-day period until the
making of the conclusive grounds decision the claimant would be granted a further temporary admission
into the UK. To make a conclusive grounds decision the Secretary of State requested relevant information
on the claimant's current circumstances, relevant to her trafficking experiences, in particular information on
the father of her child. In fact, no further information was forthcoming.

36. On 27 July 2014 the competent authority issued its conclusive grounds decision: on the balance of
probabilities the claimant did not met the definition of a victim of trafficking for the purposes of the
Trafficking Convention. By reference to a US Department of State report, it accepted that trafficking is
prevalent in Albania. The letter then referred to the action, means and purpose elements of the definition
of trafficking in the Palermo Protocol and the Trafficking Convention but asserted that in the claimant's
case they did not occur in conjunction with each other.

37. The decision letter in effect accepted the claimant's story. Until meeting the man who assisted her
departure from Albania, this was as follows:

“The claimant was born in a village in the Shkoder district in Albania of a strict, conservative and
emotionally distant family. In the third year of her university degree, she started a relationship with a man
called K. She fell in love with him. Due to the fact that her family would disapprove, she ran away to
Tirana with him. Life in the first few months was good. He went to work from 8am to 4pm in a café he said
he owned. She had a set of keys and was able to leave the flat. Apparently only a few of his friends
visited and he did not introduce her to his parents. She obtained a passport in July for the planned
honeymoon. At the end of September, he began complaining of her housework and took away her mobile
telephone. He then said he had no money and said she would have to work as a prostitute. She tried to
refuse but he started threatening to kill her and harm her family. Between October 2012 and March 2013
she was forced into sex work in Tirana. She was given drugs and alcohol to force her to comply with his
wishes.”

38. The claimant's account of coming to the UK was, in essence, as follows:

“In January 2013 a man who was a regular client took an interest in her and asked her why she did the job.
She confessed that she did not have a choice and that she was forced to do it. She asked him for help to
get her out of the situation. The man came again to see her in March 2013 and told her to have her


-----

passport ready for the next week. As promised, he met her one week later and took her to his flat where
she stayed until 17 April 2013. That day he gave her an aeroplane ticket and took her to Tirana airport. He
stated that a man would be waiting for her in Malpensa airport, Italy. In Malpensa airport another man
approached her and asked whether her name was [B]. She confirmed that this was correct. He took her to
his car. She fell asleep and when she woke up they were in Belgium. They stayed in Brussels for one night
and the man then handed her the train ticket to the UK via France. She did not know where she was going,
but she followed his instructions.”

39. After summarising the essential facts, the decision letter then analysed these in detail under the
heading “Consideration”. In doing so it addressed the points made by Ms Stepnitz and Dr Blumberg. The
decision letter stated that over the two and a half months from July 2012 the boyfriend, K's, behaviour was
equally to be taken as indicative of a perfectly normal relationship, rather than grooming. Financial
difficulties appeared to have triggered the "existential crisis" in the relationship which led to the prostitution.
These were strong indicators that the claimant was a victim of severe domestic abuse but not of human
trafficking. The decision letter continued:

“3. [F]rom the Stepnitz report it appears that K's negative change in attitude to you, came about as result of
his financial difficulties (in late September/early October 2012). This is when he began to criticise your
domestic work (cooking, ironing, etc.) rather than expect you to perform sexual favours with strangers for
money. Again, had this been the purpose of the move to Tirana, by K, this would be more consistent with
an act of recruitment, transport and transfer for the purpose of sexual exploitation.

4. The Stepnitz Report attempts to address this problematic issue… by claiming that the amount of money
that K was earning from prostituting you was far more than was economically “necessary” to live in Tirana.
However, this line of argument does not resolve the crucial “when” i.e. time aspect of the exploitation, as
opposed to the “why” (reasons behind) question. If that earning potential was already clear to [the
claimant's] ex-boyfriend before moving to Tirana, why did he only seek to exploit this several months later
and at a time when he was clearly in financial difficulties. In addition, Ms Stepnitz's explanation does not
factor in the possibility that when your ex-boyfriend K saw the potential earnings which could be made from
sexually exploiting you, it was probably greed that became the dominating factor. In any event, the timeline
provides a strong objective indicator of severe domestic abuse resulting from financial difficulties, rather
than pre-meditated trafficking for sexual exploitation purposes.

5. The fact that is at this time you had relative freedom of mobility, a set of keys for the apartment available
to you and you were provided with a new mobile phone and SIM card, which does not have appear (sic) to
have barred outgoing calls, confirms that you were not being held against your will. Even up to the time of
the change in K's behaviour – e.g. when he began staying out as opposed to keeping regular hours etc.,
there is no indication that you were locked in or physically restrained when he was not present. This again
seems to strongly indicate that it was a financial crisis, and not an (sic) premeditated trafficking intention
which motivated K's later actions.

6. This situation appears to have changed dramatically after K began exploiting you, as the Stepnitz report
indicates that “you were “locked for long periods in the house alone.”…

7. …[T]he time the passport was issued in early July 2012, your ex-boyfriend clearly had no problems with
you holding a passport.”

40. The “Consideration” part of the decision letter went on to comment adversely on why the claimant had
not sought assistance in Italy, France or Belgium. It said: “[O]n the balance of probabilities, you were not
transferred or transported to Tirana by your ex-boyfriend specifically for the purposes of sexual
exploitation.” Then under the heading “Decision”, the letter stated that on the balance of probabilities not
all of the constitutive elements necessary to meet the trafficking definition were present. Further, the
claimant had not been trafficked in the UK and had not had any contact with her alleged trafficker in more
than 13 months. Therefore she was not considered to have been under his influence at or since the time
of the NRM referral in February 2014.


-----

41. In January 2015, the claimant's solicitors served a supplementary report from Ms Stepnitz, which
critiqued the conclusive grounds decision. She reasserted her belief that the claimant had been groomed.
To attribute the boyfriend's behaviour to the financial crisis was hindsight analysis and not a reasonable
way to interpret a trafficker's behaviour. The mere threat of taking the claimant out of her home and forcing
her into prostitution would constitute trafficking.

**V GROUNDS OF CHALLENGE**

42. Following the conclusive grounds decision in July 2014, the claimant's solicitors applied to file
amended grounds of claim. Delay in the litigation occurred as a result of challenges in other cases
involving returns to Italy under the Dublin Regulation. There were a number of interlocutory applications
which need not detain us, but eventually the claimant filed amended grounds for judicial review on 14 April
2015.

43. On 11 June 2015 HHJ Karen Walden-Smith, sitting as a Judge of the High Court, granted permission
on two of the amended grounds, ground 1, that the conclusive grounds decision was arguably unlawful and
_Wednesbury unreasonable in concluding that the claimant was not transferred or transported to Tirana for_
the purpose of sexual exploitation; and ground 5, that her detention from 20 April 2013 to June 2013 was
arguably unlawful since she had not been timeously referred to the NRM.

44. The Judge refused permission on grounds 2-4 of the claimant's amended grounds: ground 2, that the
Secretary of State's decisions in May 2013 were unlawful in certifying the claimant's asylum claim for her
return to Italy under the Dublin Regulation and refusing her leave to enter since Italy was unsafe because
of her particular vulnerability; ground 3, that there was a real risk of a breach of Article 3 ECHR given her
poor mental health; and ground 4, that the decisions were contrary to her duty to the claimant's child under
section 55 of the Borders, Citizenship and Immigration Act 2009 (“the 2009 Act”). The claimant renewed
her application for permission to apply for judicial review on these three grounds.

45. On 10 February 2016, the Secretary of State served a further decision refusing and certifying the
claimant's claim under Article 3 ECHR relating to her return to Italy. It referred to the Strasbourg decision,
_Tarakhel v. Switzerland, Application No. 29217/12, [2014] ECHR 1185 and stated that what was needed as_
a result of it with the return of vulnerable children was a satisfactory assurance from the Italian authorities
prior to removal. Such an assurance about accommodation had been received although, the claimant's
judicial review being outstanding, a specific facility would not be identified until a confirmed transfer date.
The letter also dealt with the claimant's mental health: that did not mean that she could not be removed to
Italy but steps would be taken to manage any risk. The letter concluded with a section addressing section
55 of the 2009 Act and the claimant's capacity to care for her daughter.

46. On 2 March 2016 the claimant sought permission to amend the grounds to challenge the decision of
10 February. The challenge was on the same basis as in ground 2-4 of the amended grounds. There
were further amended grounds on 14 March 2016 introducing an argument based on Article 9.1 of the
Dublin Regulation. At the hearing, the way the claimant's case as advanced underwent further
development. No objection was taken by the Secretary of State to have all issues in the case resolved. I
agreed, although it was not by any means an ideal way to conduct litigation and there was truth in Ms
Rowland's point that she faced a moving target.

47. The various grounds in the re-amended claim can be dealt with under the following heads:

**Trafficking and the conclusive grounds decision**

48. The claimant's claim in this regard is that the Secretary of State unreasonably and unlawfully delayed
making a referral to the NRM. Consequently, she was unlawfully detained until released on the application
for judicial review. Then, contrary to a proper understanding of the nature of human trafficking, the
Secretary of State's competent authority decided that the claimant had not been trafficked. In fact her
account, which in effect the Secretary of State accepted, was consistent with the definition of trafficking
and the background material. The boyfriend's behaviour was indicative of grooming and the claimant had


-----

been harboured and moved in Tirana for the purposes of sexual exploitation. There is no need for
trafficking to occur across borders and she had quite clearly been trafficked within Albania.

49. I accept Ms Chandran's approach to the meaning of trafficking in the Trafficking Convention, Article 4
ECHR and the Secretary of State's policies.  Any one or more of the actions of recruitment, transportation,
transfer, harbouring or receipt of a person, achieved by any one or more of the identified means by which
the action is achieved will constitute trafficking if the relevant action is done with the intention of exploiting
that person. Whatever the position in the criminal law, the requisite actions in the Trafficking Convention,
Article 4 ECHR and the Secretary of State's policies are not confined to transportation or transfer but
encompass as well recruitment, harbouring or receipt of a person. In its ordinary meaning, recruitment is
the process of finding new persons and enlisting them in a role. Harbouring is not an everyday concept but
I accept that it includes accommodating or holding a person at the place of exploitation or at a place prior
to the exploitation.

50. In the claimant's case to the competent authority, as advanced through Ms Stepnitz's report, the action
component seemed to be constituted by transportation or transfer from her home town to Tirana. The case
depended crucially on there not being a genuine relationship which turned sour, but the boyfriend having
the intention to prostitute the claimant all along. As Ms Stepnitz recognised in the passage quoted earlier,
the transportation from the home town to Tirana had to be for the purpose of exploitation. Ms Stepnitz
focused on the boyfriend's intention in the earlier part of the relationship. In this regard, however, Ms
Stepnitz was far from definite: his behaviour was “indicative” of grooming, there “may” have been an
intention to exploit her all along and the profit he later made from prostituting her “speaks to” that intention.
Similarly, with the means part of the definition, Ms Stepnitz's consideration of coercion and deception in the
passages quoted earlier turned on the boyfriend's true position: she thought he loved her, she was
deceived that there were new opportunities in Tirana and he took advantage of her vulnerability.

51. In submissions before me, Ms Chandran rowed back to an extent from transportation or transfer to add
recruitment and harbouring as the action components in the definition of trafficking. Along with Ms
Stepnitz, she mentioned transportation within Tirana as the claimant was moved nightly to her
appointments. In the report, that was very much a passing reference. I do not accept that, by itself, fulfils
the definition. Trafficking a person and simply facilitating their prostitution by transporting them to
appointments are distinct. Ms Chandran rightly emphasised the role of grooming in trafficking, underlining
it by reference to recent cases in this country involving the sexual exploitation of young girls. The written
submissions refer to the 'lover-boy syndrome' whereby traffickers create a romantic relationship with a
vulnerable girl or woman with the aim of abusing their vulnerability to press them into sexual exploitation.
Following the hearing Ms Chandran and Ms Physsas submitted a helpful note on the recent notorious
human trafficking cases in Rochdale, Oxford and Rotherham.

52. For present purposes, however, the crucial point is how the claimant's case was advanced before the
competent authority. Admittedly, the competent authority had to exercise its own judgment in the matter
but unsurprisingly, in light of Ms Stepnitz's experience in trafficking and work with the Poppy Project, the
competent authority engaged with her interpretation of events. The decision letter analysed the events
over the two and a half months, from the claimant moving to Tirana in July, and concluded that it was a
case not of premeditated abuse but of domestic violence, with the claimant being forced into prostitution by
her boyfriend in October 2012, following financial difficulties. The decision letter in paragraphs 5 and 6,
quoted above, track the factors referred to in the Home Office competent authority guidance: for several
months the claimant was free to come and go as she pleased in Tirana, and had keys to the flat, her own
mobile telephone and her own passport.

53. It is not my role to choose Ms Stepnitz's interpretation over that of the competent authority's or to
characterise one rather than the other as right or wrong. It may have been that after October 2012 it was
open to analyse the facts as trafficking through harbouring, but that was not the way the matter was
presented to the competent authority by Ms Stepnitz. The issue for me, as HH Judge Walden-Smith rightly
recognised in granting permission, is whether the decision was unlawful or Wednesbury unreasonable.


-----

54. Generally speaking, the competent authority will be expected to act in accordance with the Secretary
of State's policies on trafficking unless there is a good reason not to do so: see R (Lumba) v. Secretary of
_State for the Home Office_ _[2011] UKSC 12; [2012] 1 AC, 245, [26], per Lord Dyson. In her oral_
submissions, Ms Chandran criticised the competent authority's understanding of the meaning of trafficking
by reference to its focus on transportation, contending that it had therefore acted unlawfully. But, as I have
said, that was how the claimant's case was presented and it seems clear to me that, taken in the round, the
decision letter demonstrates a clear understanding of what trafficking encompasses. It quoted the Palermo
Protocol definition and referred expressly to the three components of the definition in the Trafficking
Convention, including recruitment, harbouring and receipt in the action component, in addition to
transportation or transfer. Receipt was specifically mentioned as regards the claimant's case in paragraph
3 of the Consideration section in the decision letter, along with transport and transfer. In my view, the
competent authority directed itself correctly as to the definition of trafficking.

55. By reference to _R (on the application of FM) v._ _Secretary of State for the Home Department [2015]_
_EWHC 1725 (Admin), [4], citing R (on the application of SF) v. Secretary of State for the Home Department_

[2015] EWHC 2715 (Admin), [104], Ms Chandran submitted that the standard of review of the competent
authority's application of the policy is anxious scrutiny, and that the court needs to be satisfied that the
decision shows by its reasoning that every factor which might tell in favour of an applicant has been
properly taken into account. That, with respect, needs some explanation.

56. The intensity of judicial review always varies with the context. Here the subject matter and the
possible engagement of a person's Article 4 ECHR rights mean that this is an area where the intensity of
review is high. Anxious scrutiny has been used as the term to characterise that standard. But anxious
scrutiny must be applied in a realistic manner, taking account of the decision-making context. As Munby J
expressed it on one occasion, anxious scrutiny does not mean that the court “should strive by tortuous
mental gymnastics to find error in the decision under review when in truth there has been none”: R (on the
_application of Sarkisian) v. Immigration Appeal Tribunal_ _[[2001] EWHC Admin 486, [18]. Moreover, anxious](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_
scrutiny can work both ways and the cause of those genuinely trafficked is not helped, for example, by
undue credulity towards those advancing contrived or inconsistent stories: cf. R (on the application of YH
_(Iraq)) v. Secretary of State for the Home Department_ _[2010] EWCA Civ 116; [2010] 4 All E.R. 448, [24],_
per Carnwath LJ .

57. In this case the complaint is not about the Secretary of State's policies but about how policies
compliant with Article 4 ECHR were applied in the claimant's case. So anxious scrutiny is used in
considering the grounds on which the decision itself may be reviewable. In _R (AA) (Iraq) v._ _Secretary of_
_State for the Home Department [2012] EWCA Civ 23 the Court of Appeal considered whether a trafficking_
decision was flawed on the Wednesbury ground of review: [62], [67]. From the outset, Wednesbury review
has been applied with variable intensity, depending on the subject matter. It is also hornbook law that a
decision-maker must take into account relevant considerations. That was recognised in Wednesbury itself:
_Associated Provincial Picture Houses Ltd v._ _Wednesbury Corporation [1948] 1 KB 223, 233-234. This_
ground of review means the decision-maker must take into account considerations which are _legally_
relevant, not every consideration.

58. In R (on the application of YH (Iraq)) v. Secretary of State for the Home Department Carnwath LJ (with
whom Moore-Bick LJ and Etherton LJ agreed) said that the standard of anxious scrutiny meant “the need
for decisions to show by their reasoning that every factor which might tell in favour of an applicant has
been properly taken into account”: [24]. That passage was invoked in R (FM) and R (SF). In my view this
is nothing more than a traditional ground of judicial review, but applied with anxious scrutiny. Carnwath LJ
refers to factors “properly” taken into account, in other words those legally relevant. It is not the law that a
decision is flawed because every single factor in a party's favour, however trivial or incidental, has not been
taken into account. Rather, what a competent authority must do in this type of case is to take into account
relevant considerations expressly identified in the policies as well as those which, albeit not expressly
identified, are obviously material to a person's case.

59. The present decision was one on the facts. Ms Chandran did not dispute the facts set out in the
decision letter indeed she adopted them It was a decision in my view well within the range of decisions


-----

which a rational decision-maker could make. Ms Stepnitz's interpreted the facts differently from the
competent authority. The competent authority engaged carefully with her interpretation of events,
reasoning towards its conclusion. Both interpretations were possible, but the important point legally is that
the competent authority's interpretation cannot be said to be irrational. Further, the decision letter
addressed the relevant factors set out in the guidance, for example those referred to in paragraphs 5 and 6
in the Consideration section, and other obviously material factors in the claimant's favour. Overall,
applying anxious scrutiny to a consideration of the grounds of judicial review I am not persuaded that the
decision of the competent authority in this case is flawed through irrationality or a failure to take into
account legally relevant factors or for other reasons.

60. To the objection more recently raised, that the 16 May 2013 decision to certify the claimant's case on
safe third country grounds was flawed when later there was a decision to refer her to the NRM, the obvious
riposte is that prior to certification, on 2 May 2013, the Poppy Project had interviewed the claimant and
decided not to refer her to the NRM. In any event a decision to certify is not retrospectively flawed
because there is a later decision on trafficking in a claimant's favour. As in this case, the claimant was not
denied the protection of the Secretary of State's policies on trafficking because her case had been certified
on Dublin Regulation grounds.

**Human trafficking and the Dublin Regulation**

61. The Dublin Regulation establishes the principle within the European Union that only one Member State
is responsible for examining an asylum application by a third party national. It sets out the criteria for
determining which that Member State is. Once a Member State accepts that it must take charge of a
person under the Dublin Regulation and process her asylum application that triggers the obligation of the
Member State where she is to transfer her to the first Member State. The relevant Dublin Regulation in this
litigation is Regulation (EC) No. 343/2003 of 18 February 2003, known as Dublin II. A recast Dublin
Regulation (EU) No. 604/2013, Dublin III, entered into force in July 2013.

62. In the recently amended grounds, modified yet further in oral submissions, the claimant's case became
that the Secretary of State's obligations under the Trafficking Convention, Article 4 ECHR and her own
policies overrode the provisions of Dublin II. Ms Chandran expressed the argument this way: from the
moment that there were indicators that the claimant was a victim of trafficking, as raised in her screening
interview on arrival at St Pancras on 20 April 2013, the operation of Dublin II should have been suspended
pending a referral to the NRM. Further, once the positive reasonable grounds decision was issued on 4
June 2014 the Dublin Regulation ceased to apply. From that date the Secretary of State had responsibility
for the claimant as a potential, not simply a claimed, victim of trafficking and at that point the claimant was
entitled to an enhanced form of temporary admission to the UK and protection from removal.
Consequently, the Secretary of State's decision to certify the claimant's asylum claim on safe third-country
grounds prior to a consideration of the trafficking claim was unlawful.

63. In support of these submissions Ms Chandran referred first to the Secretary of State's discretion under
Article 3.2 of Dublin II to take charge of a claim which is not her responsibility, citing Case C-411/10 and
Case C-493/10, NS (European Union Law) [2013] QB 1021374. In her submission, the Secretary of State
should have exercised that discretion to comply with her obligations under the Trafficking Convention and
Article 4 ECHR. She referred to R (ZAT and Others) v. Secretary of State for the Home Department _[2016]_
_UKUT 61 (IAC), where it was said that if Dublin II and the ECHR pull in different directions, “the_
fundamental question for the decision maker or judicial organ will be whether to give precedence to, or
confer exclusivity on, the EU regime operates to infringe one or more of the protected Convention rights of
any affected person” [51]. Ms Chandran submitted that this was a stronger case than _ZAT, since it_
concerned the absolute rights under Article 4 ECHR, not the qualified rights under Article 8 ECHR.

64. Secondly, Ms Chandran invoked Article 9.1 of Dublin II, which provides:

“Where the asylum seeker is in possession of a valid residence document, the Member State which issued
the document shall be responsible for examining the application for asylum.”


-----

She contended that under the Trafficking Convention and the Secretary of State's policies the claimant had
or at least should have had a UK valid residence document after the reasonable grounds finding in her
favour, reflecting a special protection-related form of temporary admission. As a result the UK was
responsible for examining her application for asylum, including the trafficking claim.

65. Neither the Trafficking Convention nor Article 4 ECHR can affect the operation of the Dublin
Regulation. The Trafficking Convention is an international treaty which has not been incorporated by
legislation into UK law. Although an unincorporated treaty may assist in interpreting UK legal instruments,
it imposes no legal duties on the Executive nor does it confer rights on individuals: JH Rayner (Mincing
Lane) Ltd _v. Department of Trade and Industry [1990] 2 AC 418, 499–500;_ _Ahmed_ v. _Her Majesty's_
_Treasury (Justice intervening) (Nos 1 and 2)_ _[2010] UKSC 2; [2010] 2 A.C. 534, [109];_ _R (Public Law_
_Project) v. Lord Chancellor [2015] EWCA 1193, [2016] 2 WLR 995, [27]. The Trafficking Convention has_
been given effect through the Secretary of State's policies but cannot be invoked as a source of freestanding rights and duties. The Dublin Regulation has direct legal effect in the UK and trumps any rights
and duties derived from the Secretary of States' policies.

66. As for Article 4 ECHR, there was no suggestion that the Secretary of State's policies are not compliant
with her obligations as explained in _Rantsev v._ _Cyprus_ _[[2010] ECHR 25965/04, 28 EHRC 313. Those](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_
policies contain detailed provisions as to the identification of trafficking victims, highlight these for front line
staff and list the first responders who are able to refer potential victims to the NRM. In the claimant's case,
having arrived first in the EU in Italy, she was treated as a third-country unit case. It was only after the
Poppy Project (at the time a named first responder) decided not to refer her to the NRM that she was
certified on safe third-country grounds. Once judicial review proceedings were launched, she was referred
to the NRM. The conclusive grounds decision being negative, there was no reason for the Secretary of
State to reconsider the safe third party certification.

67. In oral submissions, Ms Chandran suggested that Article 4 imposes on Convention states the
obligation to grant an enhanced form of temporary admission to those exhibiting signs of having being
trafficked, certainly to those where a reasonable grounds determination is made in their favour. In my
view, the judgment in _Rantsev cannot be read as requiring Convention states to grant specific types of_
temporary admission which Convention states must give under their laws to persons while their trafficking
cases are being examined. There is nothing in the language of the judgment to support it and such
specificity would be surprising, to say the least, given the margin of appreciation which Convention states
have.

68. The Article 9.1 argument has no purchase in this case for two reasons. First, _CK (Afghanistan)_ v.
_Secretary of State for the Home Department_ _[2016] EWCA Civ 166 affirms a line of authority that the_
provisions of the Dublin Regulation cannot be invoked by individuals but governs the allocation of duties
and responsibilities between Member States. In written submissions following the hearing Ms Chandran
disclaimed an intention to rely on Article 9.1 on an individual rights basis, but submitted that the UK would
be acting in breach of its obligations as a Member State of the EU. If so that is the end of the matter, since
the issue is not justiciable in this court.

69. Secondly, residence document in Article 9.1 is defined in Article 2(j) of the Regulation:

“'residence document' means any authorisation issued by the authorities of a Member State authorising a
third-country national to stay in its territory, including the documents substantiating the authorisation to
remain in the territory under temporary protection arrangements or until the circumstances preventing a
removal order from being carried out no longer apply, with the exception of visas and residence
authorisations issued during the period required to determine the responsible Member State as established
in this Regulation or during examination of an application for asylum or an application for a residence
permit.”

70. Under the Secretary of State's policies, and consistently with Article 13 of the Trafficking Convention,
those referred to the NRM are granted temporary admission to the UK. That is admission under
_Immigration Act 1971, Schedule 2, paragraph 21; it is not limited leave to enter or remain in the UK, which_
was made clear when the claimant was released on 4 June 2013 This type of temporary admission falls


-----

within the qualification in Article 9 as an authorisation issued during examination of an application for a
residence permit. That is because under the policies if a person is found to be a victim of trafficking they
may be granted discretionary leave to remain, i.e. a residence permit. Article 9.1 does not on its face
apply.

**Unlawful detention**

71. The claimant's case is that her detention for the period of 45-days from 20 April 2013 until 4 June 2013
was unlawful. A potential victim of trafficking, she was clearly unsuitable for detention, the detained fasttrack process and subsequently, it would appear, on the grounds that she was to be removed to Italy. Ms
Chandran invoked Chapter 55.10 of the Enforcement Instructions and Guidance, which states that those
identified as victims of trafficking are generally considered unsuitable for detention. Instead, the
submission continued, the Secretary of State certified the claimant's asylum claim on third country grounds.
So she was detained unlawfully, as she could not be removed. Had she been referred timeously into the
NRM on 20 April 2013, following her screening interview, she would have been entitled to receive a
reasonable grounds decision by 25 April 2013 and release from detention.

72. These submissions are based on a number of premises which I cannot accept. First, it cannot be said
that it was in breach of policy or irrational not to refer the claimant to the NRM on her arrival at St Pancras.
Her account may have contained several indicators of trafficking but, in as much as it concerned her arrival
in the UK, it lacked credibility. That was also the conclusion when the Poppy Project, experts in the field,
when they interviewed her 12 days later on 2 May. Certainly, the solicitors had agitated trafficking from 23
April but, given the holes in her story, it is unsurprising that the Secretary of State decided to detain her
until the Poppy Project provided a considered view.

73. Once the Poppy Project decided not to refer her to the NRM on 2 May, her continued detention was
patently lawful. Before me, Ms Chandran said that Ms Stepnitz in her report suggested that the Poppy
Project might have been precluded from referring to the NRM cases of domestic trafficking (in this case,
within Albania). Ms Stepnitz's report stated that the Poppy Project only supported those trafficked into or
within the UK, and that it would have been irresponsible for it to refer a case to the NRM which it could not
support. If that were the position there is nothing in the evidence to suggest that the various decisionmakers were aware that this was the policy of the Policy Project and that was why it had not referred the
claimant into the NRM.

**Return to Italy**

74. The claimant has renewed her application for permission on grounds 2 – 4 of the amended grounds.
In this respect, Ms Chandran contends that the Secretary of State ought to have exercised her discretion
not to return the claimant and her child to Italy because, on return, there is a real risk of a breach of their
human rights. In particular, the reception conditions in Italy are such that there will be a breach of Article 3
ECHR and Articles 1 and 4 of the EU Charter of Fundamental Rights. Even if there were suitable facilities
in Italy, the claimant is so traumatised that she would not be able to access the care for her mental health
required. Further, the duty imposed under section 55 of the Borders, Citizenship and Immigration Act 2009
regarding the claimant's child has not been met.

75. In respect of the claimant's human rights claim, Ms Chandran's submission is that the Secretary of
State wrongfully certified the claim as clearly unfounded under paragraph 5(4) of part 2 to Schedule 3 to
the Asylum and Immigration (Treatment of Claimants etc.) Act 2004 (“the 2004 Act”) both in the 2013
decision and more recently on 10 February 2016. This, she submitted, is not a challenge bound to fail:
_Kosovo v. Secretary of State for the Home Department [2009] 1 WLR 348, [23]. Applying anxious scrutiny_
to the Secretary of State's decision, the court should quash the decisions since on a legitimate view an
appeal could succeed.

76. Challenging the return of persons to Italy under the Dublin Regulation has been a hardy perennial in
the European and domestic courts. Ms Rowlands for the Secretary of State directed me to five cases in
the European Court of Human Rights, all unsuccessful on admissibility, two involving a mother with a child
or children; Hussein v Netherlands [2013] 57 EHRR SE1; Daybegova et al v Austria [2013] 57 EHRR


-----

SE12. The Strasbourg Court referred to the principles from _MSS v._ _Belgium and Greece_ [2011] ECHR
108, at [25] and NS, at [28]. A leading case in Strasbourg is Tarakhel v. Switzerland [2014], Application
No. 29217/12, ECHR 1185. It concerned an Afghan family, parents and six children, who contended that
the Swiss authorities breached Article 3 and 8 ECHR in failing to give adequate consideration to the
reception conditions in Italy and the best interests of their children in proposing to return them there. The
Grand Chamber held:

“120. In the present case, as the Court has already observed (see paragraph 115 above), in view of the
current situation as regards the reception system in Italy, and although that situation is not comparable to
the situation in Greece which the Court examined in _MSS, the possibility that a significant number of_
asylum seekers removed to that country may be left without accommodation or accommodated in
overcrowded facilities without any privacy, or even in insalubrious or violent conditions, is not unfounded. It
is therefore incumbent on the Swiss authorities to obtain assurances from their Italian counterparts that on
their arrival in Italy the applicants will be received in facilities and in conditions adapted to the age of the
children, and that the family will be kept together…

122. It follows that, were the applicants to be returned to Italy without the Swiss authorities having first
obtained individual guarantees from the Italian authorities that the applicants would be taken charge of in a
manner adapted to the age of the children and that the family would be kept together, there would be a
violation of Article 3 of the Convention.”

77. In this court, Dublin Regulation returns to Italy have been considered in recent years in a number of
cases. Thus in _Tabrizagh v._ _Secretary of State for the Home Department [2014] EWHC 1914 Elisabeth_
Laing J considered in depth the evidence available concerning the situation in Italy. She held that the
presumption of compliance which operates especially in the EU among Member States meant that the
challenge to the Secretary of State's safe third country human rights certificate failed. She applied R (on
_the application of EM (Eritrea)) v. Secretary of State for the Home Department_ _[2014] UKSC 12; [2014] AC_
1321. The Court of Appeal refused permission to appeal her decision: Tabrizagh v. Secretary of State for
_the Home Department [2014] EWCA 1398._

78. In MS v. Secretary of State for the Home Department [2015] EWHC 1095 (Admin), Lewis J had three
claimants suffering from severe depressive disorders and classed as being at risk of suicide. As with
Elisabeth Laing J, Lewis J considered the evidence in depth. In a thorough judgment he concluded that
there was no evidence that the Italian authorities were leaving asylum seekers in a situation of
homelessness on a widespread scale such as to amount to substantial operational problems which
rebutted the presumption of compliance. That conclusion was supported by reports from organisations
such as the Office of the United Nations High Commissioner for Refugees and Amnesty International.
Lewis J examined Tarakhel v. Switzerland Application No. 29217/12, [2015] 60 EHRR 28 and held that it
did not mean that specific assurances were required to avoid a breach of Article 3 in relation to other
potentially vulnerable asylum seekers than families, such as the claimants. The Court of Appeal has given
permission to appeal the judgment, and the case is to be heard in late July 2016. In the meantime, the
Court of Appeal has indicated that it will stay cases involving Dublin Regulation returns to Italy which raise
the same issues as in the pending appeal.

79. Ms Chandran took me to the US Department of State's Trafficking in Persons Report, July 2015, which
refers to third party nationals in Italy being forced into prostitution by Romanian and Italian gangs, and to a
country report in Italy dated December 2015 by an NGO, AIDA (Asylum Information Database), which in
relation to Dublin returns refers to the lack of available places in reception structures and to the proposals
for new building. Ms Chandran also submitted that a consideration of the claimant's judicial review should
be stayed until the outcome of the MS appeal.

80. In my view, no matter how relevant and persuasive this new evidence about Italy is, it is superseded
because the Italian authorities have provided written assurances to their EU partners that, further to the
judgment in _Tarakhel_ v. _Switzerland, families will be accommodated together upon return in facilities_
adapted to the family and the age of the children. Member States are requested to inform the Italian
authorities 15 days in advance of transfer so that specific accommodation can be arranged. The


-----

assurances explain that the facilities are integrated facilities, offering information, guidance, assistance,
and language and job training. Ms Chandran submitted that there needed to be specific assurances from
the Italian authorities in line with Tarakhel and thus the claimant and her child should not be removed. In
my view a specific assurance is unnecessary, indeed unworkable. It would be futile for the Italian
authorities to allocate a place to the claimant and her child, given the heavy demands, while this case is
ongoing. In accordance with the assurances, a specific facility will be determined where the claimant and
her child will be accommodated once there is a confirmed transfer date.

81. As to the claimant's mental state, Dr Blumberg's evidence is stale: in any event, it and section 55 in
relation to the claimant's child are properly and adequately addressed in the Secretary of State's decision
of February 2016.

82. With respect to a stay, this court is bound by R (on the application of AB (Sudan)) v. Secretary of State
_for the Home Department_ _[2013] EWCA Civ 921. That was an appeal against a refusal of this court to_
grant a stay pending the Supreme Court appeal in _R (on the application of EM (Eritrea))_ v. Secretary of
_State for the Home Department_ _[2014] UKSC 12, [2014] AC 1321. It was a case of a Dublin Regulation_
return to Italy, where the claim for judicial review was based on the conditions likely to be faced there.
CMG Ockelton, sitting as a Deputy High Court judge, refused to grant a stay and referred to the need to
take the court's own interest into consideration in exercising the discretion to grant stays.

83. On appeal, Jackson LJ agreed with this analysis. Referring to the power to stay cases under CPR 3.1
(2)(f), 54.10(2) and 52.7, and its application in the context of immigration cases, Jackson LJ continued:

“[30] Sometimes it is obviously necessary to grant such a stay, because the anticipated appellate decision
will have a critical impact upon the proceedings in hand. There is also, however, a need for realism. In the
world of immigration it is a fact of life that the law which the judge applies is liable to change in the future,
quite possibly in the near future. This cannot usually be a reason for staying proceedings…

[32] In my view the power to stay immigration cases pending a future appellate decision in other litigation is
a power which must be exercised cautiously and only when, in the interests of justice, it is necessary to do
so. It may be necessary to grant a stay if the impending appellate decision is likely to have a critical impact
on the current litigation. If courts or tribunals exercise their power to stay cases too freely, the immigration
system (which is already overloaded with work) will become even more clogged up.”

Davis LJ delivered a concurring judgment and Elias LJ agreed with both judgments.

84. To my mind there is no basis for a stay in this case and the interests of justice do not demand it.
Whatever the Court of Appeal decides in _MS will not have critical impact upon this case. The general_
assurances from the Italian authorities which apply to the claimant and her daughter, given following
_Tarakhel_ v. Switzerland, are a feature distinguishing this case from _R (on the application of MS)_ v. _The_
_Secretary of State for the Home Department [2015] EWHC 1095 (Admin), where there were no assurances_
from the Italian authorities about the claimants' mental health problems. Since the Court of Appeal is very
likely to apply the other features of Tarakhel v. Switzerland and the Strasbourg court's other jurisprudence,
which Lewis J carefully applied in MS, I simply cannot see the justice in staying a case which already has
taken an exorbitant time to wend its way through the system. I refuse a stay.

**Conclusion**

85. For the reasons I have given I reject the challenges to the decision of the competent authority that the
claimant was not trafficked and to her detention after her arrival in this country. I refuse permission to
renew on grounds 2 – 4 in relation to both the 2013 and 2015 decisions to certify her case on human rights
grounds that it was safe to return her to Italy. I refuse a stay.

86. I should note that after the hearing the claimant's solicitors informed me that they had learnt that the
claimant was pregnant again and expecting the child in early April. They had not known of the fact until she
had approached them to have her reporting conditions relaxed because of the pregnancy. The solicitors
have told me that they are instructed that the father is the same man who is the father of her first child. (I
have described her account of the earlier pregnancy in the judgment.) The claimant instructs them that she


-----

is not in a relationship with him and takes full responsibility for the children and does not rely on him.
Despite the solicitors' submission to the contrary, I do not regard these new facts as being relevant to the
outcome of this judicial review.

**End of Document**


-----

