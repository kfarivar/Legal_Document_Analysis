# R (on the application of KTT) v Secretary of State for the Home Department

 [2021] EWHC 2722 (Admin)

Queen's Bench Division, Administrative Court (London)

Linden J

12 October 2021Judgment

**Mr Chris Buttler QC and Ms Zoe McCallum (instructed by Duncan Lewis) for the Claimant**

**Mr Robin Tam QC and Mr William Irwin and Ms Emily Wilsdon (instructed by the Government Legal**
**Department) for the Defendant**

Hearing dates: 20, 21 July 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

Covid-19 Protocol: This judgment was handed down remotely by circulation to the parties' representatives by
email, release to BAILII, if appropriate, and/or publication on the Courts and Tribunals Judiciary website. The date
and time for hand-down is deemed to be

at 10.30am on Tuesday 12 October 2021

**MR JUSTICE LINDEN:**

**Introduction**

1. The Claimant is a Vietnamese national aged 33. She has a complex immigration history, a brief
chronology of which is set out in Annex A to this judgment. But the essential points for present purposes
are as follows.

2. For a period of approximately six months in 2016, the Claimant was forced to work as a prostitute in
Vinh City before being brought to this country by people traffickers in November 2016. Her journey took her
through various countries where she was also forced to work as a prostitute and, for a period of
approximately 21 months after her arrival here, she was subjected to further forced labour including as a
prostitute and on cannabis farms. On 17 April 2018 a positive reasonable grounds decision was made in
her case and, on 31 October 2019, the Defendant accepted that she was “a victim of modern slavery in
_Vietnam, Russia, Ukraine, unconfirmed countries, France and the UK during 2015-2018 for the specific_
_purposes of sexual exploitation, forced labour forced criminality” (“the conclusive grounds decision”)._

3. Meanwhile, on 22 January 2019, the Claimant made claims for asylum and human rights protection in
this country. Those claims were based on a fear of being trafficked again if she was returned to Vietnam.
They had yet to be determined at the time of the conclusive grounds decision. In accordance with her then
policy (the so-called “scheduling rule”) which was set out in Version 2 of “Discretionary Leave for Victims of
**_Modern Slavery” (“the MSL Policy”), dated 10 September 2018, on 31 October 2019 the Defendant also_**
decided that any decision as to the grant of discretionary leave – which is referred to in the authorities as
ECAT leave but which I will call **_modern slavery leave, or “MSL” - would be postponed until after the_**


-----

determination of her claim for asylum/protection. In the light of the judgment of Murray J in R (JP and BS)
**v Secretary of State for the Home Department [2020] 1 WLR 918, however, the decision on MSL was**
brought forward and, on 21 July 2020, the Claimant's application was refused. The Defendant then
reviewed her decision in response to arguments set out in the Claimant's pre-action protocol letter dated 22
July 2020 but, on 17 August 2020, the refusal was maintained. The Defendant's decision of 17 August
2020 (“the Decision”) is the subject of this Claim.

4. On 23 April 2021, the Claimant's asylum and human rights claims were refused. That decision is the
subject of an appeal to the First Tier Tribunal (“the FTT”) which was lodged on 17 May 2021. It is estimated
by the Claimant's solicitor that it will take until October 2022 for the appeal to be decided by the FTT.

**Outline of the issues**

5. There are now four pleaded grounds of challenge:

i) The way in which Ground 1 is put has undergone some refinement, partly in the light of the Defendant's
arguments. But, as expressed in the Claimant's skeleton argument dated 6 July 2021, at least, Ground 1
alleges that the MSL Policy is contrary to Article 14 of the Council of Europe Convention on Action Against
Trafficking in Human Beings 2005 (“ECAT”) “because it fails to permit the grant of [MSL] to a victim on the
_ground that she has to remain in the UK to advance an asylum/protection claim” based on the fear of being_
re-trafficked if she is returned to her country of origin. On this basis, the refusal of leave in the Claimant's
case is said to have been inconsistent with Article 14(1)(a) ECAT and therefore unlawful. Permission was
granted in respect of this Ground by Mostyn J on the papers on 23 November 2020. He also adjourned the
application for permission in respect of Grounds 2 and 3 to the substantive hearing of Ground 1.

ii) Ground 2 alleges that the MSL Policy is contrary to Article 4, European Convention on Human Rights
(“ECHR”). The Claimant's skeleton argument indicated that this Ground is not pursued.

iii) Mr Buttler QC confirmed that Ground 3 is advanced in the alternative to Ground 1. As refined in Mr
Buttler's oral submissions, Ground 3 alleges that the Decision was unlawful because the decision-maker
failed to take account of, or to address, an argument that the Claimant's mental health would be
ameliorated by the grant of MSL and would help her to engage with the therapy which is available here. Mr
Buttler confirmed in the course of his submissions that it was also contended that the decision was
irrational because one of the premises for the Decision was that the medical assistance needed by the
Claimant was available to her in Vietnam, whereas her intention was to remain in this country pending the
outcome of her asylum/human rights claims.

iv) Ground 4 alleges, in effect, that the effect of Article 10.2 ECAT was that the Claimant was entitled to
MSL from the date of the reasonable grounds decision i.e. 17 April 2018. Permission to add this Ground
was granted by Mostyn J on 10 May 2021. It is based on his decision in R (EOG) v Secretary of State for
**the Home Department** _[2020] EWHC 3310 (Admin) which is currently before the Court of Appeal. Mostyn_
J therefore stayed Ground 4 pending the determination of that appeal.

6. The key provision of ECAT for present purposes is Article 14. This states:

“Article 14 – Residence permit

_1. Each party shall issue a renewable residence permit to victims, in one or other of the two following_
_situations or in both:_

_(a) the competent authority considers that their stay is necessary owing to their personal situation;_

_(b) the competent authority considers that their stay is necessary for the purpose of their co-operation with_
_the competent authorities in investigation or criminal proceedings.” (emphasis added)_

_2 The residence permit for child victims, when legally necessary, shall be issued in accordance with the_
_best interests of the child and, where appropriate, renewed under the same conditions._

_3 The non-renewal or withdrawal of a residence permit is subject to the conditions provided for by the_
_internal law of the Party._


-----

_4 If a victim submits an application for another kind of residence permit, the Party concerned shall take into_
_account that he or she holds, or has held, a residence permit in conformity with paragraph 1._

_5 Having regard to the obligations of Parties to which Article 40 of this Convention refers, each Party shall_
_ensure that granting of a permit according to this provision shall be without prejudice to the right to seek_
_and enjoy asylum.”_

7. As Murray J said in R (JP and BS) (supra):

_“18. ECAT leave is a temporary form of leave that enables a victim of trafficking to receive support (through_
_access to the labour market, education and mainstream benefits) to facilitate recovery from trafficking_
_and/or to facilitate co-operation with a criminal investigation into trafficking. It is generally granted for a_
_period of 30 months, although it can be granted for a longer or shorter period in individual cases. It is not a_
_route to settlement in the UK.”_

8. Under Ground 1, the Claimant's broad case is that she should have been granted MSL in accordance
with Article 14(1)(a) ECAT on the basis that it is necessary for her to remain in this country owing to her
personal situation i.e. in order to pursue her asylum and human rights claims based on her fear of being retrafficked if she is returned to Vietnam. This, she argues, is the effect of Article 14.1(a) ECAT as a matter of
construction. As, she says, the Defendant's stated policy is to comply with Article 14, the refusal of leave in
her case was unlawful.

9. The evidence is that the Claimant has significant mental health issues as a result of her experiences of
being trafficked, including Post Traumatic Stress Disorder and Anxiety and Depressive disorder, for which
she takes anti-psychotic and anti-depressant medication. MSL would mean that she was eligible for
Universal Credit which, she calculates, is worth more than six times the payments she currently receives.
She would also have access to the labour market and to education and training, all of which, she says,
would assist to recover from her experiences of trafficking. There is also evidence that her insecure
immigration status is contributing to the issues with her mental health.

10. As matters stand, although sections 77 and 78 Nationality, Asylum and Immigration Act 2002 prevent
the Defendant from removing the Claimant until the final determination of her asylum and human rights
claims, and although victims of trafficking are exempted from the NHS charging regime (see Regulation
17(1) National Health Service (Charges to Overseas Visitors) Regulations 2015), the effect of the refusal to
grant the Claimant MSL is that she is subject to the so-called hostile immigration environment underpinned
[by the Immigration Act 2014. As Underhill LJ noted in R (Balajigari) v Secretary of State for the Home](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
**Department [2019] 1 WLR 4647 at [81]:**

_[“It is…. a criminal offence to be in the UK without leave to remain: see section 24 of the Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)_
_1971. As regards practical consequences, a person without leave faces severe restrictions on their right to_
_work (see section 24B of the 1971 Act), to rent accommodation (section 22 of the 2014 Act), to have a_
_[bank account (section 40 of the 2014 Act) and to hold a driving licence (sections 97,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DG0-TWPY-Y082-00000-00&context=1519360)_ _[97A and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5D0K-XT71-DYCN-C0CC-00000-00&context=1519360)_ _[99 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DG0-TWPY-Y0JC-00000-00&context=1519360)_
_Road Traffic Act 1988)…..”._

11. Mr Buttler also advanced an un-pleaded secondary argument under Ground 1 that Version 2 of the
MSL Policy, although not the subsequent versions, was internally inconsistent in that the scheduling rule
prohibited a decision on whether to grant leave pursuant to Article 14 ECAT until an asylum decision had
been taken, whereas the Defendant's stated policy was to implement her obligations under ECAT.

12. Mr Tam QC's case in relation to Ground 1 was essentially four-fold:

i) He argued that on the basis of the decision of the Supreme Court in R (SC) v Secretary of State for
**Work and Pensions** _[2021] UKSC 26, [2021] 3 WLR 428which was handed down on 9 July 2021, Ground_
1 is misconceived and/or not justiciable because it is essentially a complaint that the United Kingdom has
failed to comply with obligations under an international treaty, ECAT, which has not been incorporated into
our law. Various decisions of the Administrative Court and the Court of Appeal, starting with R (Atamewan)
**v Secretary of State for the Home Department [2014] 1 WLR 1959, which have considered and**
adjudicated the question whether the stated policy of the Defendant was consistent with ECAT were per


-----

incuriam and wrongly decided. This point was taken for the first time in the Defendant's skeleton argument
dated 13 July 2021 but, rightly in my view, Mr Buttler did not object to it being considered given the timing
of the SC decision and given that the issues now raised in relation to SC are issues of law.

ii) Mr Tam's argument in relation to SC was developed further in oral submissions, in particular in that he
submitted, as part of his argument that the Claimant was relying directly on ECAT, that the MSL Policy
does not contain a commitment to make decisions as to MSL in accordance with Article 14 ECAT. As will
be seen, this argument was also contrary to concessions which had been made by the Defendant in earlier
cases.

iii) In the alternative, Mr Tam submitted that Ground 1 is based on a misinterpretation of Article 14(1)(a)
ECAT. His main argument under this head was that, reading Article 14(1)(a) in accordance with Vienna
Convention principles, the question is whether the residence permit is required in order to facilitate a stay
which is necessary for the stated purposes but would not otherwise be possible. Such a permit is not
required by Article 14(1)(a) in a case where a victim of people trafficking is claiming asylum/protection in
this country, because they are protected from removal by sections 77 and 78 Nationality, Asylum and
Immigration Act 2002 in any event. Moreover, the Claimant's reading would put victims of people trafficking
in a better position than other asylum seekers without there being any principled reason to do so.

iv) The Claimant's secondary argument that the MSL Policy was internally inconsistent and irrational was
not pleaded and was in any event denied.

13. Mr Tam's case in relation to Ground 3 was that permission should be refused, or alternatively this
Ground should be dismissed, on the basis that there are no grounds for complaint about the Decision.

**The Hearing**

14. The following points should be noted about the Hearing.

i) First, I was told that the hearing of the appeal in the EOG case was originally scheduled for 14 or 15 July
2021. However, the Defendant had taken the SC point in that case, as a result of which the time estimate
for the appeal had been increased to 3 days and the hearing had been postponed to a date which had not
yet been fixed at the time of the hearing before me. In the light of this information I sought confirmation
from the parties that neither was inviting me to stay these proceedings until the decision of the Court of
Appeal, and both confirmed that this was their position. I understand that the hearing of the appeal in EOG
has now been fixed for a 3-day hearing by the Court of Appeal, starting on 8 February 2022.

ii) Second, given that Mr Tam was asking me to depart from previous decisions of the Administrative Court
and the Court of Appeal on the basis that they were per incuriam and wrong, and given that the justiciability
of the question whether the Defendant's policies in relation to ECAT were consistent with ECAT itself had
been conceded in some of the authorities which I will consider below, I asked for further assistance in
writing on the questions of the scope of the doctrine of per incuriam and when a point of law which was
conceded will or will not be binding. In response to this request I received helpful Notes from both sides
dated 21 July 2021, for which I am grateful.

iii) Third, on 30 July 2021, and therefore after the Hearing, the Supreme Court handed down its decisions
in **R (A) v Secretary of State for the Home Department** _[2021] UKSC 37 and_ **R ((BF) Eritrea v**
**Secretary of State for the Home Department** _[2021] UKSC 38. These addressed the scope for_
intervention by the Court where it is alleged that a policy issued by a public body is likely to lead to unlawful
decisions (what might be called **Gillick challenges). On 13 September 2021, and from an abundance of**
caution given that no point of the nature at issue in A and BF (Eritrea) had been taken by Mr Tam, I invited
the parties to make any observations or submissions which they wished to make in the light of these
decisions. In response, I received helpful written submissions from both sides dated 17 September 2021:

a) Mr Buttler's position was that the Claimant does not contend that the MSL Policy was vitiated by a
**Gillick error. He usefully summarised the issues, in the light of the arguments at the Hearing at least, as**
follows:


-----

_“The Claimant's primary submission at the hearing was that (a) the Policy committed the Defendant to_
_complying with Art 14 ECAT, and (b) the Defendant breached the Policy in the Claimant's case (and does_
_so generally) because she has misconstrued the meaning of Art 14 ECAT …The Defendant contended that_
_she had not breached her Policy because (a) the Court was precluded from construing the meaning of Art_
_14 ECAT, (b) the Policy did not commit the Defendant to complying with Art 14 ECAT and/or (c) Art 14_
_ECAT should not be construed in the way contended for by the Claimant. The issue between the parties_
_was not about the lawfulness of the Policy. The issue was the alleged failure to comply with the Policy. A_
_and BF Eritrea have nothing to say about this.”_

b) Mr Buttler also said that his secondary internal inconsistency point was a complaint that the MSL Policy
was irrational.

c) Mr Tam's position was that the decisions in A and BF (Eritrea)“(in the strict sense) do not appear to
_affect the outcome of the present case” although they did underline the distinction between policy and law,_
and this distinction reinforced the Defendant's “primary argument” on Ground 1 based on SC.

**The justiciability issue**

Relevant case law before the decision of the Supreme Court in SC.

_JH Rayner (Mincing Lane) Limited v Department for Trade and Industry [1990] AC 2AC 418_

15. The key authority on the legal status of international treaties in domestic courts for present purposes is
**JH Rayner (Mincing Lane) Limited v Department for Trade and Industry [1990] AC 2AC 418 in which**
Lord Oliver stated two related principles on which Mr Tam relied. I will call these “the Rayner principles”:

i) First: “It is axiomatic that municipal courts have not and cannot have the competence to adjudicate upon
_or to enforce the rights arising out of transactions entered into by independent sovereign states between_
_themselves on the plane of international law…. On the domestic plane, the power of the Crown to conclude_
_treaties with other sovereign states is an exercise of the Royal Prerogative, the validity of which cannot be_
_challenged in municipal law.” (499E-H)_

ii) Second: “..as a matter of the constitutional law of the United Kingdom, the Royal Prerogative, whilst it
_embraces the making of treaties, does not extend to altering the law or conferring rights upon individuals or_
_depriving individuals of rights which they enjoy in domestic law without the intervention of Parliament._
_Treaties, as it is sometimes expressed, are not self-executing. Quite simply, a treaty is not part of English_
_law unless and until it has been incorporated into the law by legislation. So far as individuals are_
_concerned, it is res inter alios acta from which they cannot derive rights and by which they cannot be_
_deprived of rights or subjected to obligations….” (500B-D)_

16. Lord Oliver went on to point out that this did not mean that the courts will never be entitled to construe
an international treaty. At 500D-H he gave examples of where this will be permissible, namely:

i) Where the treaty is directly incorporated into English law by an act of Parliament;

ii) Where a statute is enacted to give effect to the United Kingdom's obligations under a treaty, in which
case interpretation of the treaty may be necessary to resolve any ambiguity or obscurity as to the meaning
or scope of the statute;

iii) Where parties have entered into a contract which incorporates the terms of the treaty;

iv) Where legislation expressly or impliedly requires recourse to a treaty in order to construe its terms;

v) In very rare cases in which the exercise of the Royal Prerogative directly effects an extension or
contraction of the jurisdiction without the constitutional need for internal legislation.

17. As is well known, ECAT is an unincorporated international treaty. A number of authorities have
therefore addressed the question of the effect of the Rayner principles in the context of challenges to the
Defendant's policies on people trafficking where the challenge alleges failure to comply with ECAT. These
authorities include the following.


-----

_R (Atamewan) v Secretary of State for the Home Department [2014] 1 WLR 1959_

18. In Atamewan, one of the issues was whether the Defendant's “Guidance for Competent Authorities”
on the subject of people trafficking correctly interpreted ECAT in stating the test for a “victim of trafficking”.
Applying this Guidance, the decision-maker had decided that although the claimant had been trafficked into
the United Kingdom there were no reasonable grounds to believe that she remained a victim of trafficking.
This approach was said by the claimant to be contrary to Articles 4, 10.2 and 13 ECAT. In relation to this
issue the Divisional Court (Aikens LJ and Silber J) noted at [55] that Mr Eadie QC (as he then was)
submitted that:

_“…the key question was whether the policy set out in the guidance (particularly in relation to “historic”_
_trafficking cases) was sufficient to comply with the UK's international obligations under CAT. He accepted,_
_at least in this court, that although CAT had not been transposed into domestic law by legislation and so_
_did not have “direct effect”, in so far as the guidance purported to give effect to the terms of the CAT and_
_failed to do so, that would be a justiciable error of law. He also accepted that to the extent that the NRM_
_decision was itself based on the terms of the guidance, if they were, in turn, based on an erroneous_
_interpretation of the CAT, then the NRM decision could be challenged by judicial review because that_
_decision would then have been based on a misdirection as to the legal basis for the relevant wording of the_
_guidance.” (emphasis added)_

19. Aikens LJ went on to note, at [68], that in the light of the arguments of the parties the issues which
required to be decided included whether the United Kingdom's policy as described in the Guidance was
unlawful because it misinterpreted the relevant articles of ECAT. At [69] he found that:

_“The guidance sets out UK government policy in certain respects on the issue of trafficking in human_
_beings and, in particular, in relation to those who are victims of trafficking. The guidance purports to set out_
_this policy in a manner consistent with the provisions of the CAT.” (emphasis added)_

20. He noted Mr Eadie's concession and he went on to hold that the Guidance had, indeed, misinterpreted
ECAT and was therefore unlawful. It is clear from the passages cited above that the Divisional Court
proceeded on the basis that where a public body states, in effect, that its policy is to reach decisions on a
given issue in accordance with its obligations under an international treaty, the source of any public law
obligation to do so is the policy statement rather than the treaty itself. In my view the Court positively
considered and accepted this point. This view is reinforced by a passage at [89] where, addressing an
argument that the Defendant had also failed to comply with the duty under Article 27(1) ECAT to take steps
to initiate effective investigations Aikens LJ said:

_“89 Two obligations on the UK authorities are involved. First, there is the obligation of the UK in article_
_27(1) of the CAT. As already noted (see note 6), in his written submissions Mr Eadie took the points that,_
_first, an unincorporated international treaty cannot be relied on in domestic courts to fill an alleged lacuna in_
_government policy and, secondly, that the guidance does not purport to transpose any possible positive_
_duty under article 27(1) of the CAT to provide for the referral of a victim of trafficking's case to the police in_
_circumstances where the police have not already been alerted._

_90 I accept those propositions….” (emphasis added)_

21. Note 6 recorded that:

_“6. In his written submissions, Mr Eadie argued that an unincorporated international treaty could not be_
_relied upon in domestic courts to fill a lacuna in government policy and he referred to J H Rayner (Mincing_
**_Lane) Ltd v Department of Trade and Industry [1990] 2 AC 418and_** **_R (Campaign for Nuclear_**
**_Disarmament) v Prime Minister [2002] EWHC 2777 (Admin); The Times, 27 December 2002. This point_**
_was not developed orally.”_

22. It is therefore clear that both Mr Eadie and the Divisional Court had the **Rayner** principles in mind.
They recognised that there is a distinction between a case where the stated policy of a public body
purports to give effect to a given provision in an international treaty by indicating that decisions will be
taken in accordance with that provision, on the one hand, and a case where the policy does not do so and


-----

the complaint of failure to comply with the provision therefore relies directly on the international treaty itself
to fill the lacuna, on the other. In the former case, the policy is the source of the relevant obligation and the
court is entitled to interpret the treaty in question to decide whether the impugned parts of the policy
correctly state the position under the treaty and/or whether a given decision is in accordance with the
commitment to comply with the treaty. In the latter case, the treaty is, in effect, the source of the obligation
and court's interpretation of the treaty is therefore irrelevant.

_R (Galdikas) v Secretary of State for the Home Department [2016] 1 WLR 4031_

23. In Galdikas, the claimants' challenge included an argument that the Defendant's support regime failed
to comply with Article 12 ECAT. On behalf of the Defendant it was submitted, amongst other things, that
the Rayner principles meant that the claimants could not rely on any provision of ECAT because it had not
been incorporated into English law: see [46] and [58]-[59]. Sir Stephen Silber held, at [48]-[52], that he was
not bound by the concession made by Mr Eadie QC in Atamewan given that it was made “at least in this
_court” and given, he held, that it was merely assumed to be correct. In this connection, I note that_ **R**
**(Khadim) v Brent London Borough Council Housing Benefit Review Board [2001] QB 955, discussed**
below, does not appear to have been cited to him.

24. Sir Stephen therefore determined the issue himself.

i) At [59(B)] he held that whilst ECAT imposes no duties on the executive and confers no rights on
individuals it _“can be given effect through SSHD's policies rather than as a source of freestanding rights_
_and duties”._

ii) At [60] he noted the argument on behalf of the claimants, relying on Mandalia v Secretary of State for
**the Home Department [2015] 1 WLR 4546[29] and R (WL (Congo)) v Secretary of State for the Home**
**Department [2012] 1 AC 245[26] that they were entitled to rely on the principle that a public body is**
obliged to abide by its published policy unless there is good reason to depart from it. Per Lord Dyson JSC,
this was “a basic public law right” and, the claimants argued, “expressed in this way, this claim does not
_offend the principles set out in Rayner's case because the claimants are not seeking to enforce ECAT, but_
_instead are requiring the SSHD to abide by her current policy unless there are good reasons to depart from_
_it.” ._

iii) At [61] Sir Stephen accepted this argument, adding that: “Assuming for a moment that the Government
_adopts a policy based wholly or partially on an unimplemented treaty, I do not see any good reason why_
_this approach cannot apply just because the policy replicates what appears in the unimplemented treaty. In_
_other words, Lord Dyson JSCs principle could apply to a policy which is identical to that in an_
_unimplemented treaty, which has a different source from the unimplemented treaty, namely the practice_
_which the executive has propounded in, for example, formal guidance.” ._

iv) He went on to say that: “That raises the next question, which is whether the policy of the SSHD has
_been to incorporate or to adopt as her policy the entire ECAT or article 12 of it and, if so, for what_
_purposes.” [61]._

v) At [65] Sir Stephen held that it was the policy of the Defendant to apply Article 12 ECAT when
considering applications for discretionary leave to remain from those who are accepted to be victims of
trafficking.

vi) He went on, at [66] to reiterate that:

_“The statements in_ **_Rayner's case [1990] 2 AC 418do not… preclude the claimants from relying on the_**
_guidance which specifically adopts ECAT or parts of it where it has been accepted as the policy of the_
_SSHD in the guidance.”_

25. It will be noted that Sir Stephen's decision in **Galdikas was entirely consistent with the approach in**
**Atamewan. He recognised a distinction between direct reliance on the provisions of an international treaty**
as the source of the relevant obligations and reliance on a stated policy that decisions will be taken in
accordance with the relevant articles of an international treaty. His approach also involved the application
f ll t bli h d bli l i i l t th ff t f bli h d li i I h littl d bt th t M


-----

Eadie had precisely the same reasoning in mind when he made his concession of law in Atamewan and
so did the Divisional Court when it accepted that concession and agreed with his submission that
international treaties could not be relied on directly to fill lacunae in stated policies. And Sir Stephen
recognised that, subject to any concession, it would be a matter for the court to determine, as a matter of
construction, whether the policy document did indeed adopt the relevant treaty article and/or commit to
making the relevant decisions in accordance with the terms of that article.

_R (PK (Ghana)) v Secretary of State for the Home Department [2018] 1 WLR 3955_

26. In **PK (Ghana) it was argued by the claimant that the Defendant's then guidance as to when**
competent authorities should grant discretionary leave to victims of trafficking – set out in _“Victims of_
_human trafficking – competent authority guidance” Version 1 - was consistent with Article 14(1)(a) ECAT._
The guidance said that this might be appropriate _“if their circumstances are compelling” and the need to_
finish a course of medical treatment was given as an example of where this might be the case. A link to the
then discretionary leave policy, which also applied a compelling personal circumstances approach was
embedded. At first instance (before Picken J [2016] 4 WLR 25) it was common ground that the Guidance:

_“was intended to, and purported to, give effect to [ECAT]; and that, if it failed to give effect to [ECAT], then_
_that would be a justiciable error of law.”_

27. Before the Court of Appeal, at [34], Hickinbottom LJ (with whom Singh and Patten LJJ agreed)
recorded that:

_“Before us, after some consideration and after taking instructions, Miss Bretherton, who also appeared for_
_the Secretary of State below, confirmed that concession.”._

28. **Atamewan** was cited in argument and the concession in **PK (Ghana) was consistent with the**
concession in that case. I also note that two things were conceded by the Defendant in PK (Ghana):

i) first, that as a matter of fact the policy of the government was to make decisions as to discretionary
leave in accordance with Article 14 ECAT, and that this was reflected in the documents under
consideration including the discretionary leave policy; and

ii) second, that as a matter of law failure to give effect to Article 14 would therefore be a justiciable error of
law.

29. Given these concessions, Hickinbotton LJ went on to note, at [39], that the narrow issue before the
Court of Appeal was therefore whether “in adopting the compelling circumstances criterion, the Secretary
_of State's guidance fails properly to reflect Article 14(1)(a) of [ECAT]”. He then considered the correct_
interpretation of Article 14(1)(a) and concluded that the Defendant's guidance was not consistent with it. I
will return to this aspect of the decision in PK (Ghana) below.

_R (JP and BS) v Secretary of State for the Home Department [2020] 1 WLR 918_

30. In the JP case, the issue specifically related to the compatibility of the terms of the MSL Policy (i.e.
Version 2 of the policy which is in issue in the present case), and in particular the scheduling rule, with
Articles 12 and 14 ECAT. At [12] Murray J referred to paragraph [34] of PK (Ghana) and noted that:

_“In her detailed grounds of defence for each claim in this case, the Secretary of State stated that “the_
_published policies came into being to give effect to [articles 10, 12 and 14] of ECAT”, which the claimants_
_say is consistent with the Secretary of State's concession on justiciability of ECAT in_ **_PK (Ghana). The_**
_Secretary of State's position in this case is that she is constrained to follow this concession, but she_
_reserves her position for the future. In any event, she maintains that her published policies are consistent_
_with the United Kingdom's obligations under ECAT and that they give proper effect to those obligations.”_
(emphasis added)

31. Again, I note that the concession in JP was two-fold. First, it was positively pleaded that as a matter of
fact the MSL Policy gave effect to Article 14 ECAT, amongst others. Second, the legal proposition


-----

conceded in PK (Ghana) was conceded again on the basis that the Defendant was constrained to do so,
presumably because she accepted that that decision was binding.

_Other cases which consider the effect of ECAT_

32. Mr Buttler identified other cases in which the point was made and/or conceded that, in the light of the
Defendant's policy of giving effect to ECAT, failure to give effect to ECAT is a justiciable error of law. It is
not necessary to examine the details of these decisions here, but see:

i) R (FM) v Secretary of State for the Home Department _[2015] EWHC 844 (Admin) where, at [11(i)], Mr_
Philip Mott QC, sitting as a Deputy High Court judge, noted as established principles, even before
**Galdikas and PK (Ghana), both the factual and the legal concessions referred to above. He also reflected**
the Defendant's policy commitment to make decisions in accordance with ECAT when he said:

_“Insofar as the Guidance purported to give effect to the terms of the CAT and failed to do so, that would be_
_a justiciable error of law. In general, it is not disputed, as I found in the case of R (E) v SSHD [2012] EWHC_
_1927, that the Defendant has adopted the CAT in her published Guidance. The exception in Atamewan in_
_respect of Article 27 of the CAT no longer applies because of changes in the wording of the Guidance, as_
_set out below, which clearly now purport to give effect to Article 27 of the CAT, as the Defendant accepts.”_

ii) H v Secretary of State for the Home Department _[2018] EWHC 2192 (Admin) [52] and K and AM v_
**Secretary of State for the Home Department [2019] 4 WLR 92[7], both of which proceeded on the basis**
that the decision in PK (Ghana) is correct.

_MS (Pakistan) v Secretary of State for the Home Department [2020] 1 WLR 1373_

33. The cases referred to above, and the policy commitment of successive governments to adopt and
comply with ECAT and the international legal framework relating to people trafficking more generally, are
also reflected in the following passage at [20] of the judgment of Baroness Hale (with which the other
Supreme Court Justices agreed) in MS (Pakistan):

_“ECAT as such has not been incorporated into UK law. Its obligations have been implemented by a variety_
_of measures. The NRM is designed to fulfil the obligations in articles 10, 12 and 13; immigration rules have_
_[been modified in the light of article 14; and various criminal offences are created by the Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
_[Act 2015. The NRM does not, however, give private law rights to individuals. There is no right of appeal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
_against an adverse decision or against a failure to provide the expected assistance. The only remedy lies_
_in judicial review. However, the Secretary of State has consistently accepted that the NRM should comply_
_with ECAT. In R (Atamewan) v Secretary of State for the Home Department [2014] 1WLR 1959, para_
_55, it was accepted that it would be a justiciable error of law if the NRM Guidance did not accurately reflect_
_the requirements of ECAT and a decision based on that error would accordingly be unlawful. The same_
_was common ground in_ **_R (PK (Ghana)) v Secretary of State for the Home Department [2018] 1WLR_**
_3955.”_

34. Although the issue was of a different nature in MS, it is of note that in this passage the Supreme Court
did not question the concession in earlier cases that where a measure or guidance is intended to
implement ECAT it will be a justiciable error of law for it to do so incorrectly.

_R (EOG) v Secretary of State for the Home Department [2020] EWHC 3310 (Admin)_

35. Finally, in the EOG case Mostyn J also relied on PK (Ghana) and [20] MS (Pakistan). In view of the
fact that it is not necessary for me to do so, and EOG is currently before the Court of Appeal, with respect
to him I do not propose to comment or rely on Mostyn J's summary of the position at [2] and [3] in coming
to my decision. My references to “the PK (Ghana) line of cases” below therefore do not include EOG or,
indeed, MS (Pakistan) given that the latter was not concerned with the issue in the present case.

Provisional conclusion on the justiciability issue

36. Subject to the arguments about SC, I would have little hesitation in holding that Galdikas was correctly
decided for the reasons which Sir Stephen Silber gave and that the concessions of law as to the question


-----

of justiciability, referred to above, were correctly made by the Defendant and accepted by the courts in
those cases. The critical point in the PK (Ghana) line of cases is that the source of the public law obligation
contended for was the declared policy of the Defendant rather than ECAT itself. In each case it was
decided or conceded that, as a matter of fact - this was in fact the Defendant's policy - and construction this is what her policy documents said - the Defendant had committed to making the relevant decision in
accordance with the requirements of the relevant article(s) of the ECAT. It was therefore permissible for the
court, applying conventional public law principles, to consider what the requirements of those articles were
with a view to deciding whether the policy correctly stated their effect and whether a given decision, taken
in accordance with that policy, was lawful. This did not involve direct enforcement of an unincorporated
treaty as the treaty was not the source of the obligation contended for. Nor did it involve the filling of
lacunae, as Mr Tam submitted, given that the claimants in those cases relied on what was said in the
policy documents.

37. At the same time the other point made by Mr Eadie, and accepted by the Divisional Court
inAtamewan, that an international treaty cannot be used to fill a lacuna in a statement of policy, is
important. This is an example of direct reliance on the international treaty, which is not permitted. I
therefore also agree with Sir Stephen Silber that for the Claimant to succeed in the present case she must
also show that, on its true construction, the MSL Policy was intended to commit the Defendant to making
decisions as to MSL in accordance with Article 14(1)(a), ECAT before going on to show that the Defendant
has done so incorrectly and that the decision in the Claimant's case is therefore in breach of the MSL
Policy and unlawful.

**R (SC) v Secretary of State for Work and Pensions** _[2021] UKSC 26, [2021] 3 WLR 428_

38. The issue in SC was, broadly, whether the so-called “two-child limit” on child tax credit for a child born
on or after 6 April 2017, under section 9 of the Tax Credits Act 2002 as amended by section 13 of the
Welfare Reform and Work Act 2016, was compatible with various articles of the ECHR including Article 14.
The claims were brought by adult and child claimants. In relation to the Article 14 claims, a seven Justice
Supreme Court held, amongst other things, that there was a prima facie case of indirect discrimination
against the child claimants but that the Court would not go behind the view of Parliament that the two child
limit was a proportionate means of achieving a legitimate aim.

39. In addressing the “justification” issue under Article 14 ECHR, Lord Reed, with whom the rest of the
Court agreed, said that where the issue concerns a child, the best interests of the child would be a relevant
consideration but that it was not appropriate for the court to apply the United Nations Convention on the
Rights of the Child (“UNCRC”) in reaching its determination, or to make a decision as to whether, in
adopting the two-child limit, the United Kingdom had complied with its obligations under that Convention,
given the fundamental principle of constitutional law that an unincorporated treaty does not form part of the
law of the United Kingdom. Nor was there any basis in the case law of the ECHR for any departure from
[that rule where the claim is brought under the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

40. At [73], Lord Reed identified three issues of some importance which were raised by the case and Mr
Tam relies on what he said about the first of these, namely:

_“…. whether it is appropriate for our domestic courts to determine whether the United Kingdom has violated_
_its obligations under unincorporated international law when considering whether a difference in treatment is_
_justified under the Human Rights Act.”_

41. At [74] Lord Reed then noted that:

_“According to the statement of facts and issues agreed between the parties, the issue which has to be_
_determined, in relation to the question of justification, is “whether the UK's obligations under the UNCRC_
_have been breached in the present case, and if so whether in the circumstances the two child limit is_
_compatible with Convention rights”. The primary question for the court to decide is therefore supposed to_
_be whether, by introducing the limitation on entitlement to child tax credit, the United Kingdom has_
_breached its obligations under the UNCRC.”_


-----

42. At [75], he said that this approach was mistaken for reasons which he went on to explain. But
essentially this because the UNCRC is an unincorporated international treaty and the approach suggested
in framing the issue in this way was therefore contrary to the Rayner principles, which principles had been
endorsed by an 11 Justice court in **R (Miller) v Secretary of State for Exiting the European Union**

[2018] AC 61.

43. Lord Reed then considered whether the _[Human Rights Act 1998 had given domestic legal effect to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
unincorporated treaties and noted that clearly it had not. The only treaty to which the 1998 Act gives effect
is the ECHR. He then noted that a misunderstanding appeared to have arisen from the fact that the
European Court of Human Rights frequently has regard to other international treaties when interpreting the
ECHR. It does so for a number of reasons including, so far as possible, to achieve a consistency of
approach as between international treaties and to reflect any consensus on a given issue insofar as it is
evidenced by Council of Europe texts and other materials [80]. But when it does so the European Court is
not treating those treaties as if they were directly incorporated into the ECHR itself so as to impose specific
obligations on contracting states.

_“Nor does [the Court] refer to international materials for the purpose of determining whether contracting_
_states have complied with their obligations under unincorporated international treaties, recognising that it_
_possesses no jurisdiction to make such a determination.” [83]._

44. At [84] Lord Reed concluded that:

“There is, accordingly, no basis in the case law of the European court, as taken into account under the
_Human Rights Act, for any departure from the rule that our domestic courts cannot determine whether this_
_country has violated its obligations under unincorporated international treaties.”_

45. He then went on to analyse X v Austria (2013) 57 EHRR 14, in which the European Court of Human
Rights considered the UNCRC in the context of the issue of justification under Article 14 ECHR, but he
emphasised that [85]:

“The case is an example of the court's treating international instruments as relevant to its application of the
_Convention, rather than of its directly applying or “passporting” the UNCRC.” (emphasis added)_

46. He added, at [86]:

_“The judgment does not suggest that domestic courts should approach the question of justification by_
_applying the provisions of the UNCRC, or by deciding whether, in adopting the measure in question, the_
_national authorities complied with their obligations under the UNCRC. That approach has, however, been_
_adopted, obiter or in dissenting judgments, in a number of domestic cases.”_

47. Lord Reed then considered certain decisions of the Supreme Court, including Mathieson v Secretary
**of State for Work and Pensions [2015] 1 WLR 3250, in which parts of the reasoning came close to**
treating the question of the compatibility of a given measure with the UNCRC as determinative of the issue
of justification under Article 14 ECHR. He said that such an approach would be wrong and per incuriam:

_“As I have explained, for a United Kingdom court to determine whether this country is in breach of its_
_obligations under an unincorporated international treaty, and to treat that determination as affecting the_
_existence of rights and obligations under our domestic law, contradicts a fundamental principle of our_
_constitutional law.” [91] (emphasis added)_

48. Mr Tam relied on passages from SC, including the ones which I have set out at paragraphs [40-41],

[44] and [46-47] above, to submit that **SC decided that it is impermissible to interpret an unincorporated**
treaty with a view to deciding whether a given approach is consistent with its terms or in breach of them,
and/or to treat such a determination as _“affecting” the existence of rights and obligations. However, with_
respect, his argument ignored the context for Lord Reed's remarks. Lord Reed was not suggesting that it is
never permissible to interpret an international treaty, or to consider whether a given act or decision is
consistent with the terms of a treaty, absent legislative incorporation. Nor would it have been consistent
with **Rayner or subsequent cases on the status of international treaties for him to do so. The passages**
which I have cited above actually show that his point was that the issue for the Court in SC was


-----

“justification” under Article 14 ECHR, and that there was no basis in law or in fact for equating this issue
with the question whether the introduction of the measure in question was or was not consistent with the
obligations of the United Kingdom under the UNCRC. Such an approach would give direct effect to an
unincorporated treaty and was therefore impermissible.

49. It is also worth noting that SC was concerned with the approach to the question of justification under
Article 14 ECHR in the case law of the European Court of Human Rights, and the relationship between that
issue and the UNCRC. The Supreme Court therefore was not considering the question addressed in the
**PK (Ghana) line of cases as to the compatibility with** **Rayner principles of considering the meaning and**
effect of an unincorporated treaty where a public body has committed itself in a published policy document
to make a given decision in accordance with the terms of that treaty. As I have said, in such a case the
source of the alleged obligation is the policy statement rather than the treaty itself: there is a basis for
equating the issue of compatibility with the relevant international treaty obligation with the issue in the case.
There is no “passporting” and the relevant articles of the treaty are not given direct effect. There therefore
does not appear to me to be any inconsistency between the PK (Ghana) line of cases and SC.

50. Mr Tam also argued at the Hearing that the second **Rayner principle, that the Royal Prerogative**
cannot alter the law or create rights and obligations unless incorporated by legislation, is also infringed by
the approach in the **PK (Ghana) line of cases. Incorporation by policy statement will not do. I reject this**
submission. As Lords Sales and Burnett point out at [3] of their judgment in A“Policies are different from
_law. They do not create legal rights as such.”. They may, however, be enforceable in the context of judicial_
review. A policy statement that decisions will be taken in accordance with a given international treaty does
not incorporate the treaty into law. It identifies the approach which will be taken to the relevant type of
decision subject to there being valid reasons not to do so and/or any change of policy.

51.  Insofar as Mr Tam's written submissions were arguing that in A and BF (Eritrea) the Supreme Court
was holding that statements of policy cannot found claims in public law unless they are setting out the
position in law (whereas ECAT is not domestic law), their Lordships clearly were not addressing this issue.
As Mr Buttler submitted at the Hearing, in the MSL Policy, the Defendant has stated the approach which
she will take to exercising her statutory powers to grant or refuse discretionary leave to remain to victims of
**_modern slavery. Conventional public law principles establish that a claimant is entitled to complain that a_**
given decision does not comply with the stated policy of a public body.

Conclusion as to the effect of SC on the PK (Ghana) line of cases

52. For all of these reasons, then, I do not accept that the decision in SC renders the question raised by
Ground 1 non justiciable or even casts doubt on the correctness of the principles which underpin the
decisions in the PK (Ghana) line of cases. I agree with Mr Buttler that SC was a straightforward application
of the Rayner principles in the context of a materially different legal issue to the present one. It is important
to bear in mind the constraints which the Rayner principles place on the Claimant in advancing Ground 1,
and the aspects of SC discussed above serve as a useful reminder of these. But, with respect, they do no
more than this in the context of the present case.

Precedent

53. Although Mr Buttler did not wish me to decide the SC point on the basis of precedent alone, and I have
not done so, I regard myself as bound to follow **Galdikas and** **PK (Ghana) in any event. In relation to**
**Galdikas, Mr Tam did not dispute Mr Buttler's submission that I should only depart from Sir Stephen**
Silber's decision if I was persuaded that he was _“clearly wrong”:_ **R v Greater Manchester Coroner ex**
**parte Tal [1985] QB 67. However, he did not come close to meeting that test.**

54. In relation to **PK (Ghana), there was no issue before me that the concession of law made by the**
Defendant was essential to the decision in that case and therefore formed part of the ratio. The question
was whether the concession was assumed to be correct in the relevant sense, and therefore was not
binding. The principle stated by Browne Wilkinson VC in re Hetherington [1990] Ch 1, 10 is well known:


-----

_“In my judgment the authorities therefore clearly establish that even where a decision of a point of law in a_
_particular sense was essential to an earlier decision of a superior court, but that superior court merely_
_assumed the correctness of the law on a particular issue, a judge in a later case is not bound to hold that_
_the law is decided in that sense.” (emphasis added)_

55. However, as is also well known, it is open to a court to accept a concession of law or reject it and/or to
reserve its position as to the correctness of such a concession. I therefore would not lightly accept that a
previous court has failed to apply its mind to the correctness or otherwise of a concession particularly
where, as here, the concession was expressly made and recorded in the judgment of the previous court.
My reluctance to do so is heightened in the present case given the Defendant's repeated concessions on
one of the central (potential) issues in the cases referred to above and given the distinguished judges who
decided PK (Ghana). In R (Khadim) v Brent London Borough Council Housing Benefit Review Board
(supra) the Court of Appeal considered the relevant authorities, including In Re Hetherington, and held at

[33]:

_“not without some hesitation, that there is a principle stated in general terms that a subsequent court is not_
_bound by a proposition of law assumed by an earlier court that was not the subject of argument before or_
_consideration by that court.” (emphasis added)_

56. However, at [38] Buxton LJ said:

_“Like all exceptions to, and modifications of, the strict rule of precedent, this rule must only be applied in_
_the most obvious of cases, and limited with great care. The basis of it is that the proposition in question_
_must have been assumed, and not have been the subject of decision. That condition will almost always_
_only be fulfilled when the point has not been expressly raised before the court_ **_and there has been no_**
_argument upon it….And there may of course be cases, perhaps many cases, where a point has not been_
_the subject of argument, but scrutiny of the judgment indicates that the court's acceptance of the point went_
_beyond mere assumption. Very little is likely to be required to draw that latter conclusion: because a later_
_court will start from the position, encouraged by judicial comity, that its predecessor did indeed address all_
_the matters essential for its decision.” (emphasis added)_

57. I do not accept that the Defendant's concession of law in **PK (Ghana) was merely assumed by the**
Court of Appeal to be correct and was not the subject of consideration by the Court. As I have pointed out,
the implications of the Rayner principles were considered by both Mr Eadie and the Court in Atamewan
and this decision was cited in argument in PK (Ghana). It is also clear that the question whether the point
was conceded was expressly addressed before the Court of Appeal and instructions on the matter were
taken before the concession was confirmed. I am confident that if the Court had doubts about the
correctness of the concession it would have said so.

58. Given my views about SC, expressed above, the issue of per incuriam does not arise because there is
no inconsistency between the decision in SC and the PK (Ghana) line of decisions. Mr Tam was, in effect,
using SC as a “hook” to run the per incuriam argument but, in truth, the relevant aspects of the decision in
**SC did no more than apply the well-established** **Rayner principles of which the Court was well aware in**
**Atamewan,** **Galdikas and, no doubt,** **PK (Ghana). There is no question of these decisions having been**
taken in ignorance or forgetfulness of any relevant principles of law or, more broadly, through lack of care.
And, even assuming that the doctrine of per incuriam may be relied on where a decision is made
subsequently, Mr Tam did not persuade me that had the courts in the **PK (Ghana) line of cases been**
referred to SC they “must” have reached a different decision (Duke v Reliance Systems Limited [1988]
QB 108, 113) or that their decisions were _“demonstrably wrong” in the light of_ **SC (Morelle v Wakeling**

[1955] 2 QB 379, 406). In truth, Mr Tam needed to establish that **SC had, in effect, overruled the** **PK**
**(Ghana) line of cases and he did not do so.**

59. For all of these reasons, then, I consider that the question whether the Defendant's decision was
compatible with Article 14(1)(a) ECAT is potentially justiciable provided that the Defendant's stated policy
was to make decisions in relation to discretionary leave in accordance with the requirements of that
provision. It is to this question that I now turn.


-----

**Was it the Defendant's stated policy to make decisions as to discretionary leave in**
**accordance with Article 14(1)(a) ECAT        ?**

60. As I have noted, the general proposition that the policy of the government is to comply with its
obligations under ECAT was never in doubt in the PK (Ghana) line of cases. Indeed, Mr Tam emphasised
at the beginning of his submissions that this remains the policy of the Defendant, albeit this policy is
achieved by a range of measures.

61. Following on from this, in the **PK (Ghana) line of cases, with the exception of** **Galdikas, it was**
conceded by the Defendant that, as a matter of fact the policy statements under consideration were
intended, and purported, to commit the Defendant to make the relevant decisions in accordance with
ECAT. Indeed, specifically in relation to Article 14(1)(a) and the MSL Policy, the point was conceded in PK
**(Ghana) and positively pleaded and relied on in the** **JP case. Nor was this point put in issue in the**
Defendant's pleaded case in the present proceedings. Indeed, whilst the Defendant's skeleton argument
took the SC point, paragraph 3.2 stated:

_“ECAT is a multilateral international treaty that has not been incorporated into the United Kingdom's_
_domestic law. ECAT obligations are given effect by the SSHD's policy and not by domestic legislation –_
_see MS (Pakistan) v Home Secretary [2020] UKSC 9, [2020] 1 WLR 1373 at [20]”_

62. It therefore was not apparent that the Defendant was withdrawing the concession which it had made in
previous cases, which concession is expressly noted at MS (Pakistan) [20], as I have pointed out above.
But it emerged in Mr Tam's oral submissions that he was indeed submitting that the MSL Policy did not in
fact state that it was giving effect to Article 14 ECAT. This issue therefore arises for determination.

63. As noted above, the version of the MSL Policy which was in force at the time of the decision to
postpone the determination of the Claimant's application for MSL was Version 2. In JP Murray J held that it
was in principle permissible to postpone decisions on MSL until the outcome of the applicant's asylum
application. However, the fact that there were, in practice, substantial delays between the making of a
positive conclusive grounds decision and the determination of the victim's application for asylum/protection
gave rise to a material risk that, in a significant number of cases, victims would lose basic trafficking
support and be reduced for a considerable period of time to support from the National Asylum Support
Service, the level of which was not consistent with the United Kingdom's obligations under Articles 12(1)
and (2) and 14(1) ECAT.

64. In response to the JP decision, the MSL Policy was amended to modify the scheduling rule, although
not until 9 October 2020 (Version 3). The relevant version at the time of the Decision under challenge in
these proceedings is therefore Version 2. The Policy was amended again on 10 December 2020 (Version
4).

65. Mr Tam accepted that, in addressing the question whether the MSL Policy adopted Article 14(1)(a), I
should apply a domestic law, objective, approach to interpretation. I should therefore construe the words of
the Policy in context and from the stand point of the reasonable reader of the document, whether that be a
caseworker who was required to determine an application for MSL or a member of the public who wished
to understand the approach which the Defendant would adopt to her application.

66. For reasons which will become apparent, in my view a relevant part of the context is what the Court of
Appeal said about the interpretation of Article 14(1)(a) ECAT in PK (Ghana). At [44] Hickinbottom LJ said:

_“Necessary”, in this context, means required to achieve a desired purpose, effect or result…. In article_
_14(1)(a), the purpose is not express: but the provision is deep within the Trafficking Convention which (as_
_Miss Bretherton rightly accepted) must be construed purposively. Thus, “necessary” in article 14(1)(a) has_
_to be seen through the prism of the objectives of the Convention: and the competent authority has to_
_consider whether the person staying in the country is necessary in the light of, and with a view to_
_achieving, those objectives.” (emphasis added)_

67. At [50] he held that:


-----

_“Article 14(1)(a) of the Convention requires the identification of the individual's relevant personal_
_circumstances, and then an assessment by the competent authority of whether, as a result of those_
_circumstances and in pursuance of the objectives of the Convention, it is necessary to allow that person to_
_remain in the United Kingdom. Leaving aside the Convention purposes of facilitating the investigation of_
_criminal proceedings and/or a civil claim by the victim…., the only relevant objective of the Convention is_
_the protection and assistance of victims of trafficking. As I have described, this is one of the primary_
_objectives of the Convention, as expressed in the Preamble and article 1…. Whether the claimant's_
_personal circumstances were such as to make it necessary for him to stay in the United Kingdom could_
_only be assessed by reference to that objective.” (emphasis added)_

68. The problem with the relevant policy was stated at [51] as follows:

_“…the Secretary of State's guidance is entirely silent as to the purpose for which it must be necessary for_
_the victim to remain. That is understandable if the Secretary of State shares the view set out in Miss_
_Bretherton's submissions that article 14(1)(a) gives the competent authority an open-ended discretion._
_However, in my view it is fatal if, as I consider, the provision does not give an open-ended discretion, but_
_rather requires an assessment of whether it is necessary for the purposes of protection and assistance of_
_the victim of trafficking (or one of the other objectives of the Convention) to allow him to remain in the_
_country. In this case, the Secretary of State's guidance neither requires nor prompts any such engagement._
_As a result, in my view, it does not reflect the requirements of article 14(1)(a) and is unlawful.” (emphasis_
added)

69. Turning to the text of Version 2 of the MSL Policy, the purpose of the guidance is explained in its first
paragraph as follows:

_“This guidance explains the circumstances in which it may be appropriate to grant discretionary leave to_
_remain (DL) to individuals confirmed as victims of_ **_modern slavery by the National Referral Mechanism_**
_(NRM), and the considerations that must be made before such a decision is made. It also deals with_
_extending DL or curtailing leave as necessary. The term “modern slavery” includes human trafficking,_
_slavery, servitude and forced or compulsory labour.”_

70. On the same page there is then a section headed “Changes from last version of this guidance”
which states:

_“Clarification that section 4 of the Human Trafficking and Exploitation (Scotland) Act 2015 replicates_
_[section 1 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C212-00000-00&context=1519360)_ **_Modern Slavery Act 2015 (England and Wales) and section 1 of the Northern Ireland_**
_legislation.”_

71. And there is then a section headed “Related external links” which contains the following links:

_“PK (Ghana) v SSHD_

_Council of Europe Convention on action against trafficking in human beings”_

72. The section entitled “When to consider a grant of discretionary leave” identifies three categories of
case where discretionary leave may be considered in relation to a victim of modern slavery and they are
not eligible for any other form of leave. These categories are:

- “leave is necessary owing to personal circumstances

- leave is necessary to pursue compensation

- victims who are helping police with their enquiries”

73. Under the heading “Leave is necessary owing to personal circumstances” the following passage
then appears:

_“When deciding whether a grant of leave is necessary under this criterion an individualised human rights_
_and children safeguarding legislation - based approach should be adopted. The aim should be to protect_
_and assist the victim and to safeguard their human rights. In seeking to do so decision makers should_
_primarily:_


-----

_• assess whether a grant of leave to a recognised victim is necessary for the UK to meet its objective under_
_the Trafficking Convention - to provide protection and assistance to that victim, owing to their personal_
_situation” (emphasis added)_

74. Examples are then given of the circumstances in which MSL may be appropriate and there is then a
discussion of cases where the application for MSL is based on the need for medical assistance in this
country. The relevant passage includes the following:

_“In terms of needing to stay in the UK to have such treatment you may wish to consider that the UK's_
_international obligations do not extend to a requirement that treatment must be provided by specialists in_
_trafficking, or that it be targeted towards one aspect of an individual's needs (the consequences of_
_trafficking) as opposed to his or her overall psychological needs as set out in the case of EM v SSHD….”_
(emphasis added)

75. It seems to me to be inescapable that the _“Leave is necessary owing to personal circumstances”_
category in the Version 2 of the MSL Policy is intended to reflect Article 14(1)(a) ECAT, although I discuss
whether it does so accurately below. Moreover, the passage which explains how this issue is to be
approached was clearly intended to reflect Article 1(b) ECAT which states that one of the purposes of the
Convention is:

_“to protect the human rights of the victims of trafficking, design a comprehensive framework for the_
_protection and assistance of victims and witnesses, while guaranteeing gender equality, as well as to_
_ensure effective investigation and prosecution”_

76. It also reflects what Hickinbottom LJ said about Article 14(1)(a) at [44] and [50] of his judgment in PK
**(Ghana), cited above, and it seeks to address the criticism made at [51]. This is apparent from the words of**
the passage, which echo the words of Hickinbottom LJ, but it is also apparent from the provision of a link to
**PK (Ghana) itself. The reasonable reader would, in my view, conclude from this, and from the inclusion of**
a link to ECAT, that the Defendant's policy was to comply with the law relating to people trafficking
(whether international or domestic) and that these materials were provided as a reference point in the
event that a case worker wished to look at the relevant sources in more detail. The impression that the
Policy is intended to ensure that decisions are taken in accordance with the law relating to people
trafficking, and to assist decision-makers in doing so, is also reinforced by the references to the United
Kingdom meeting its objective under the Trafficking Convention and to relevant legislation and international
obligations which I have highlighted at paragraphs [70] and [73]-[74], above.

77. These points also need to be seen in the wider context of the fact that it is indeed the Defendant's
policy to comply with ECAT and other international law relating to people trafficking, as Mr Tam confirmed.
Pursuant to this policy other guidance has been issued which, in the **PK (Ghana) line of cases, the**
Defendant accepted and indeed contended was seeking to give effect to those obligations and did give
effect to them. The Defendant has also issued statutory guidance pursuant to section 49, Modern Slavery
Act 2015, dated March 2020, which is clearly intended to reflect domestic and international law, including
ECAT, and which refers the reader to the MSL Policy for “full guidance” in relation to the issue of support
available for adult victims of modern slavery (see paragraph 15.156), as its predecessor guidance did. It
would therefore be surprising if, exceptionally, the intention was that ECAT did not apply under that
particular Policy.

78. The factual concession made in PK (Ghana) and pleaded in JP is therefore unsurprising and, in my
view, correct. In coming to this view, I have considered Mr Tam's submission that it would require a very
clear commitment or, indeed, explicit reference to Article 14 ECAT for Mr Buttler's argument to run. I am
not sure why this is so. It seems to me that the question is one of interpretation in respect of which the
approach is as set out at paragraph [65], above. There was an interesting discussion at the Hearing as to
whether it made a difference if the treaty was written out in full in the form of a policy document, at one
extreme, or simply stated that the policy of the government was that decisions as to discretionary leave
would be taken in accordance with ECAT, on the other. My view is that the form does not matter. What
matters is the question whether the stated policy conveys to the reasonable reader that this is the
approach which will be taken


-----

79. Given that this is the approach, however, as Sir Stephen Silber recognised in **Galdikas, it is in**
principle possible for a court to conclude that the policy in question provides that decisions will be taken in
accordance with some aspects of an international treaty but not others. If, therefore, the policy document
makes statements as to the approach which will be taken which are inconsistent with an international
treaty, it is also open to a court to conclude that a deliberate decision has been taken to depart from the
requirements of the treaty – on an objective construction of the document as a whole the approach is to be
as stated rather than as per the treaty - and the claim is then likely to fail. I have taken this point into
account in coming to my conclusions given, for example, the inconsistency of the scheduling rule with
ECAT. But in my view the MSL Policy document, read in context, overwhelmingly demonstrates a
commitment to take decisions as to discretionary leave in accordance with ECAT albeit, for reasons which I
will explain, the requirements of Article 14 have not been fully appreciated.

80. I therefore turn to the question of the effect of Article 14(1)(a) ECAT before considering whether the
Decision in the present case was taken in accordance with its terms.

**The correct interpretation of Article 14(1)(a) ECAT**

81. It was common ground that in interpreting ECAT itself I should apply the approach stated in Nautical
**Challenge Ltd v Evergreen Marine (UK) Ltd [2021] 1WLR 1436where, at [38], Lords Briggs and**
Hamblen JJSC said that international conventions should be interpreted by reference to _“broad and_
_general principles of construction rather than any narrower domestic law principles”:_

_“39 Such general principles include the general rule of interpretation set out in article 31.1 of the Vienna_
_Convention on the Law of Treaties 1969, which provides that: “A treaty shall be interpreted in good faith in_
_accordance with the ordinary meaning to be given to the terms of the treaty in their context and in the light_
_of its object and purpose.”_

82. Mr Buttler submits that Article 14(1)(a) “mandates” the grant of MSL in the Claimant's case. He points
out that the wording of Article 14(1) is mandatory. A residence permit “shall” be issued where the case falls
within either or both of the categories identified in limbs (a) and (b). Both limbs raise the question whether
the “stay” is necessary for the specified reason or purpose. If it is, the permit is required to be issued. As a
matter of language, Article 14(1) does not require consideration of whether _the issue of the permit is_
necessary and it is therefore nothing to the point to argue, as Mr Tam does, that such a permit is
unnecessary where the victim of trafficking will not be removed in any event, as is the effect of sections 77
and 78 of the Nationality, Asylum and Immigration Act 2002.

83. On Mr Buttler's case, the only question is whether a need to stay in order to pursue a claim for
asylum/protection falls within the phrase “necessary owing to their personal situation”. He submits that this
will be the case where the applicant for asylum is a victim of people trafficking and their asylum/protection
claim is based on fear of re-trafficking if they were to be returned to their country of origin. This, he says, is
consistent with the purposive approach which was recognised to be required at [44] and [50]-[51] of **PK**
**(Ghana) namely to promote the objectives of ECAT and, in particular, the protection and assistance of**
victims of trafficking.

84. Mr Buttler's argument that his construction of Article 14(1)(a) is consistent with the aims of ECAT is
also based on the contrast, noted above, between the benefits and advantages available to the victim of
trafficking if MSL is granted and what is available to them if it is not. He emphasises the delays in
processing asylum applications and points out that it took 2 years and 3 months for a decision to be made
on the Claimant's application and will, his solicitor estimates, take until at least October 2022 to conclude
the appeals process. He also relies on evidence which, he says, shows that the additional security in terms
of immigration status which is afforded by the grant of MSL is beneficial to the mental health of the victim.
And he relies on evidence that access to the labour market, education and training is also beneficial to the
well-being of victims of trafficking and may assist with their recovery and enable them to engage fully with,
and benefit from, such therapeutic care as is available. He relies for this last point on evidence from
Professor Katona which, he says, was accepted in Murray J in **JP at [81] and [138] in holding that the**
scheduling rule was not compatible with Article 14 ECAT.


-----

85. Mr Buttler also seeks to garner support from the Explanatory Memorandum to ECAT, the decision in
the EOG case and a broader survey of Chapter III ECAT including Article 16:

i) He points out that in paragraph 183 of the Explanatory Memorandum to ECAT it is suggested that the
test under Article 14(1)(a) is whether _“the victim's personal circumstances [are] such that it would be_
_unreasonable to compel them to leave the national territory” and he argues that the Defendant effectively_
accepts that this is the position where a claim for asylum has been made given the statutory bar on
removal under sections 77 and 78 of the 2002 Act. He also points out that paragraph 184 of the
Explanatory Memorandum states that _“The personal situation requirement takes in a range of situations,_
_depending on whether it is the victim's safety, state of health, family situation or some other factor which_
_has to be taken into account.”. Thus, he submits, a broad and purposive approach is required._

ii) He says that although he does not need to rely on the decision in the EOG case (supra), this bolsters
his argument. In EOG Mostyn J held that, where a positive reasonable grounds decision has been made,
the person should be given interim leave to remain pending the outcome of the conclusive grounds
determination albeit on such terms, to be determined by the Defendant, as are appropriate both to their
existing leave positions and to the likely delay that they will face [48]. Mr Buttler's submission was, in effect,
that the position where a positive conclusive grounds decision has been made is a fortiori.

iii) He relies on various points about the text of Articles 10-14 ECAT to which I will return. In relation to
Article 16, he argues that this contemplates that the person will be returned to the country of which they are
a citizen and/or where they have a right of permanent residence subject to safeguards being in place. The
scheme of ECAT does not contemplate a halfway house, he argues, between a victim of trafficking being
lawfully in the receiving country and them being removed, whereas the effect of sections 77 and 78 of the
2002 Act, without leave to remain, is just such a halfway house.

86. Mr Tam argues that there is nothing in Article 14 ECAT to suggest that a stay in order to pursue a
claim for asylum based on fear of re-trafficking is “necessary” so as to require the issuing of a residence
permit. Mr Buttler's argument is that the fact that such a claim is being pursued is, of itself, sufficient to
require a permit to be issued and the argument assumes that there may be no other reason for them to
remain in the United Kingdom, such as for the purposes of trauma related treatment. The argument
therefore requires such a permit to be issued even where the applicant is in materially the same position as
any other asylum seeker save for their history of being trafficked. Mr Buttler's argument therefore seeks to
put victims of trafficking into a more privileged position than other asylum seekers who are awaiting the
outcome of their applications for asylum. Even in the case of victims of trafficking who rely on the fact that
they have been trafficked, and the risk of re-trafficking, argued Mr Tam, there is no warrant for treating
them differently to other asylum seekers who may have suffered at least as much, if not more, albeit in
ways not amounting to trafficking.

87. Mr Tam argued that Mr Buttler's interpretation is based on an inappropriately expansive and technical
analysis of Article 14 ECAT and he accused Mr Buttler of _“parsing sub-paragraphs (a) and (b) so as to_
_disengage the adjective 'necessary' from the primary obligation to issue a residence permit”. He submitted_
that, applying the approach required by Article 31.1 of the Vienna Convention, the clear intention of Article
14(1) is to require the issuing of a residence permit “in order to facilitate a stay which is necessary for one
_of the reasons set out in sub-paragraphs (a) or (b) but will be possible only if a residence permit is issued.”_
A residence permit therefore is not required where the victim has statutory protection from removal, as is
the case here. This is consistent with the aims of ECAT and it ensures that victims of people trafficking are
not put in a better position than other asylum seekers when there is no substantive reason to do so and all
asylum seekers are seeking the same outcome, namely leave to remain on that basis.

88. Mr Tam also submitted that:

i) The Explanatory Memorandum does not support an argument that a residence permit should be issued
to a person who is irremovable in any event and/or simply on the basis that they are making a people
trafficking related application for asylum;


-----

ii) EOG does not assist given that Mostyn J was considering a different issue and did not in fact hold that a
full Article 14 compliant residence permit should be issued to potential victims of trafficking. Nor did the
claimant in EOG have statutory protection from removal, although she was not removable as a matter of
policy. And, in any event, **EOG was based on an incorrect interpretation of ECAT, as well as being per**
incuriam in that Mostyn J purported to fill a “lacuna” in existing policy [48], and therefore contrary to SC.

iii) Article 16 ECAT does not contemplate a binary distinction between being lawfully in the United
Kingdom and being removed and, in any event, Vietnam is not party to ECAT. Article 16 therefore has no
relevance.

89. On balance, I prefer Mr Buttler's interpretation of Article 14 ECAT, which is based on an ordinary
reading of the text of the provision and, in my view, consistent with its purpose. The reality of Mr Tam's
argument on interpretation is that Article 14(1) should be read as if it says that the issuing of the residence
_permit must be necessary, whereas the language of the provision clearly requires consideration of whether_
_the stay is necessary in which case the permit must be issued. Indeed, the requirement to consider_
whether “their stay is necessary” leaves room for it to be the case that the victim is staying in any event.
The provision then asks whether the stay is necessary for a particular reason or purpose, in which case a
residence permit, with attendant benefits and advantages, is required to be issued. The language does not
appear to regard the residence permit as solely for the purpose of facilitating a stay which would not
otherwise be possible, although this may be an important function of such a permit. Rather, the point of
the residence permit is at least in part to trigger additional advantages, as will be discussed below.

90. I do not consider that applying the language of Article 14 is an overly technical approach, or
inconsistent with the approach required by the Vienna Convention. Moreover, the approach suggested by
the language is consistent with the aims of ECAT including the aim of protecting and assisting the victims
of trafficking. Mr Tam's suggested interpretation of Article 14 is significantly less likely to further those aims
given that it has the consequence of reducing the likelihood that a residence permit will be issued, with the
beneficial consequences to which Mr Buttler refers.

91. Indeed, the effect of Mr Tam's argument is that ECAT contemplates that provided that a signatory
state has a policy of not removing victims of trafficking, or perhaps a law to this effect, they never need
issue residence permits pursuant to Article 14. In the context of the United Kingdom, asylum seekers who
relied on fear of re-trafficking would rarely, if ever, be eligible for MSL because such leave would not be
necessary to facilitate their stay given sections 77 and 78 of the 2002 Act. And this position would hold
good under Article 14 however powerful their case based on other personal circumstances, such as the
need for medical or other assistance for reasons related to their experiences of being trafficked. (I
appreciate that, in practice, in the United Kingdom they would have access to healthcare in any event, but
the point holds good for the purposes of interpreting Article 14, which is not country specific). Mr Tam's
argument would also hold good in a case where the victim's stay was “necessary for the purpose of their
_co-operation with the competent authorities in investigation or criminal proceedings” (i.e. under limb (b) of_
Article 14(1) as well). On his approach, the fact that such a person had made a claim for asylum would
disentitle them from a residence permit pursuant to Article 14(1)(b).

92. Mr Tam did not put forward specific arguments as to the meaning of _“is necessary owing to their_
_personal situation” if that phrase is applicable to the stay, or specifically submit that a stay which was_
necessary to pursue an asylum/protection claim based on the fear of re-trafficking on returning the country
from which the victim was trafficked cannot fall within this phrase. Nor did he place reliance, in this
connection, on the fact that one of the findings in the Decision letter is that there would not be significant
risk of the Claimant being re-trafficked or subjected to other trafficking related harm if she were to be
returned to Vietnam. I accept Mr Buttler's submission that the fact that a victim is pursuing an
asylum/protection claim based on the fear of re-trafficking may be an aspect of the victim's personal
situation for the relevant purposes given that this interpretation would be in accordance with the aims of
ECAT, including to protect people from trafficking or the risk of trafficking and to assist victims more
generally. Paragraph 184 of the Explanatory Memorandum also suggests that the personal situation
requirement has a broad application. Indeed, I note that the MSL Policy includes, as examples of the
personal situation of the victim the risk of re trafficking or other harm or ill treatment from their traffickers if


-----

they were to return. This seems to me to be consistent with the broad meaning which should be given to
_“personal situation” applying the approach stated in PK (Ghana), and with the proposition that the fact that_
a person is seeking to establish a right to asylum/protection on this basis is part of their “personal situation”
for these purposes.

93. I also agree with Mr Buttler that paragraph 183 of the Explanatory Memorandum tends to support the
view that the broad intention of Article 14(1)(a) is to require that a residence permit be issued to confirmed
victims of trafficking when it would be unreasonable to compel them to leave the relevant territory, and I
accept it is implicit in the fact that Parliament has accepted that a person should not be removed whilst
their asylum/protection claim is outstanding, that a stay for this purpose is generally necessary. That would
have been my view in any event. It follows from this that a stay in order to pursue a claim for asylum based
on the fear of being re-trafficked may be necessary owing to the victim's personal situation.

94. In addition to these points, reading Articles 10, 12 and 14 ECAT together it seems to me to be clear
that ECAT draws a distinction between those who merely may not be removed and those who are lawfully
here. This distinction is important because it means that Article 14(1) advisedly requires the issuing of a
residence permit where a victim qualifies under limbs (a) and/or (b), and it contemplates that a recognised
victim of trafficking who needs to stay for one of these specified purposes will have greater advantages
than would otherwise be the case. If their stay is necessary for the relevant purposes it therefore is not
sufficient merely to refrain from removing them, and nor is it permissible to withhold the advantages which
would otherwise accrue to them if they were lawfully here. If that is so, the fact that the focus of Article
14(1)(a) and (b) is on whether the stay is necessary, rather than whether the issuing of a permit is
necessary, is consistent with the scheme of the Convention as well as the words of Article 14 itself.

95. Thus, Article 10(2), which is concerned with the identification of victims, provides that:

_“Each Party shall adopt such legislative or other measures as may be necessary to identify victims as_
_appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure_
_that, if the competent authorities have reasonable grounds to believe that a person has been victim of_
_trafficking in human beings, that person shall not be removed from its territory until the identification_
_process as victim of an offence provided for in Article 18 of this Convention has been completed by the_
_competent authorities and shall likewise ensure that that person receives the assistance provided for in_
_Article 12, paragraphs 1 and 2.” (emphasis added)_

96. Article 12 provides, so far as material that:

_“Article 12 – Assistance to victims_

_1 Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their_
_physical, psychological and social recovery. Such assistance shall include at least:_

_a standard of living capable of ensuring their subsistence, through such measures as: appropriate and_
_secure accommodation, psychological and material assistance;_

_b access to emergency medical treatment;_

_c translation and interpretation services, when appropriate;_

_d counselling and information, in particular as regards their legal rights and the services available to them,_
_in a language that they can understand;_

_e assistance to enable their rights and interests to be presented and considered at appropriate stages of_
_criminal proceedings against offenders;_

_f access to education for children._

_2 Each Party shall take due account of the victim's safety and protection needs._

_3 In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident_
_within its territory who do not have adequate resources and need such help._


-----

_4 Each Party shall adopt the rules under which victims lawfully resident within its territory shall be_
_authorised to have access to the labour market, to vocational training and education.” (emphasis added)_

97. “Victim” is defined by Article 4(e) as follows:

_"Victim" shall mean any natural person who is subject to trafficking in human beings as defined in this_
_article.”_

98. As noted above, Article 14(1) requires the issuing of a residence permit to victims in two specified
situations. Articles 14(2)-(5) then contain further provisions relating to such residence permits.

99. It is thus apparent that ECAT maintains a distinction between being lawfully here and merely not being
liable to removal. The primary reason for this distinction is to determine whether the person should be
provided with the benefits and advantages specified in Article 12(1)-(4) or limited to the benefits referred to
in Articles 12(1) and (2). Lawful residence may be conferred by the issuing of a residence permit, as
required by Article 14, which is concerned with facilitating access to Article 12(1)-(4) benefits/advantages
where the person's stay is necessary for specified purposes, as well as facilitating the stay itself.

100. Mr Tam's analysis proceeds on the basis that the role of Article 14 ECAT is limited to facilitating a
stay and he argues that it has no role where the person is able to stay in any event. But that ignores the
fact that the Article also seeks to ensure that the defined subgroups of victims of trafficking who need to
stay in the relevant country have access to the additional benefits/advantages in Articles 12(3)-(4).

101.  I appreciate that Article 13 is less clear. This provides, so far as material, that

_“Article 13 – Recovery and reflection period_

_1 Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when_
_there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be_
_sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an_
_informed decision on cooperating with the competent authorities. During this period, it shall not be possible_
_to enforce any expulsion order against him or her. This provision is without prejudice to the activities_
_carried out by the competent authorities in all phases of the relevant national proceedings, and in particular_
_when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise_
_the persons concerned to stay in their territory._

_2 During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures_
_contained in Article 12, paragraphs 1 and 2.” (emphasis added)_

102. In **EOG, at [41], Mostyn J took the view that both of the sentences in Article 13(1) which I have**
highlighted refer to the same period of time – the recovery and reflection period – but it is not necessary for
me to decide this point. The important point is that the distinction between being protected from removal
and entitled to Article 12(1) and (2) benefits, on the one hand, and being issued with a residence permit
which has the effect that the person is lawfully here and entitled to additional benefits/advantages, on the
other, is maintained in Article 13.

103. I did not get a great deal of assistance from the other points relied on by Mr Buttler:

i) I am not sure that EOG does logically lead to the conclusion that the position under Article 14 ECAT is a
_fortiori. Mostyn J was considering the position under Article 10.2. Although he held that interim_
discretionary leave should be granted where a positive reasonable grounds decision has been made, he
did not appear to hold that full Article 12(1)-(4) benefits should be conferred at this stage. There is also a
tension between aspects of my analysis of the relevant provisions at paragraphs [92]-[100], above, and the
analysis of Mostyn J.

ii) Nor did I find the arguments based on Article 16 compelling. It seems to me that there is room for a
middle ground as between staying and being removed where, for example, a victim of trafficking claimed
asylum but not on a basis related to that fact, and they had no other trafficking related reason to remain. In
such a case, Mr Buttler accepted, they would not be able to establish a case under Article 14 ECAT even if
they were protected from removal by sections 77 and 78 of the 2002 Act and therefore remained here.


-----

104. Nor, however, did I accept Mr Tam's argument that Mr Buttler was arguing for an unwarranted
privilege or “windfall” for victims of trafficking as compared with other asylum seekers. Mr Buttler was clear
that his case was that Article 14(1)(a) is capable of applying to recognised victims of people trafficking
where their claim for asylum/protection is based on their status as victims of trafficking: in the present case,
where the claim is based on the fear of re-trafficking. It would not apply where the asylum/protection claim
had some other basis. To the extent that this puts victims of trafficking in a better position than asylum
seekers generally, that it is a function of the fact that they have the benefit of a protective regime which is
specific to them and based on the particular considerations which apply to the problem of people
trafficking.

**Does the MSL Policy accurately reflect Article 14(1)(a) ECAT?**

105. In my view Version 2 of the MSL Policy does not accurately reflect the requirements of Article 14
ECAT, essentially because it reflects Mr Tam's analysis of Article 14, with which I disagree. This is most
obvious in the passages which I have quoted at paragraphs [72]-[73], above, which state that the question
is whether “leave is necessary” for the relevant purpose rather than whether the victim's stay is necessary.
There is also no statement that the fact that a victim of people trafficking has made an asylum/protection
claim may be a ground for granting discretionary leave, or example to this effect. On the contrary, under
Version 2 the scheduling rule was to the opposite effect given that it meant that MSL would not be granted
where an asylum/protection claim had been made because the decision as to the grant of MSL would be
postponed in such a case. The fact of the asylum/protection claim was therefore a reason to defer an
application for MSL rather than to grant it.

106. Under Version 3, the focus on the question whether leave rather than the stay is necessary is
maintained, although the fact that the scheduling rule has been modified means that there is scope to grant
discretionary leave notwithstanding that there is an outstanding application for asylum/protection. It
remains the case that the examples of when the victim's personal situation may be a reason to grant MSL
do not include the fact that they have made a claim for asylum/protection, whether based on fear of retrafficking or otherwise.

107. The scheduling rule has been modified as follows in the section entitled “Actions to take following
**_a positive conclusive grounds decision”:_**

_“If the confirmed victim has an outstanding asylum claim and the deferral of a decision on whether to grant_
_discretionary leave would not itself result in the withdrawal of any NRM support which the victim receives_
_and still needs, then the asylum claim should normally be decided before any consideration is given to_
_whether the victim is eligible for DL under this policy.” (emphasis added)_

108. The examples of situations in which it may be appropriate to consider granting MSL are explained as
follows:

_“However, in some cases it may nonetheless be appropriate to consider a grant of DL under this policy in_
_advance of consideration of the asylum claim. Each case should be considered carefully on its own facts,_
_but examples of where this would be appropriate include:_

_• It is clear that the victim is assisting the police with enquiries and is therefore likely to qualify for_
_discretionary leave to remain under this policy._

_• It is clear that the victim is pursuing a claim for compensation and is therefore likely to qualify for_
_discretionary leave to remain under this policy._

_• It is clear that due to personal circumstances the victim is likely to qualify for discretionary leave to remain_
_under this policy, regardless of the outcome of the asylum of humanitarian protection claim. For example,_
_there is strong evidence that the victim has a medical need to help them recover from their experience of_
_being a victim of_ **_modern slavery and it is also clear that the assistance they require is unlikely to be_**
_available outside the UK (regardless of any issue about whether they would be safe in that country, which_
_would fall to be considered as part of their protection claim).” (emphasis added)_

109 The same passages appear in Version 4


-----

110. It is therefore apparent that Versions 3 and 4 do not take the stance taken by Mr Tam given that they
contemplate that there may be cases where a grant of MSL is appropriate notwithstanding that there is an
outstanding asylum/protection claim. However, I agree with Mr Buttler that the reasonable reader of
Versions 3 and 4 as a whole would conclude that the fact of an asylum/protection claim based on the fear
of being re-trafficked is relevant to the question whether to defer a decision on MSL but is not, of itself, a
potential reason to grant MSL. On the basis of this interpretation, then, the MSL Policy remains misleading
as to the effect of Article 14(1)(a) ECAT and will induce decisions by caseworkers which are inconsistent
with its requirements and, therefore, inconsistent with the Defendant's policy of compliance with Article
14(1)(a).

**Is the MSL Policy internally contradictory?**

111. This was a secondary argument which was not pleaded until the Claimant's skeleton argument and I
did not see what it added. It seems to me that this case turns on the arguments which I have addressed
above. The essence of the arguments about the MSL Policy was that it was internally contradictory
because, in effect, it announced an intention to make decisions in accordance with the requirements of
Article 14(1) ECAT but its exposition of aspects of these requirements was misleading and wrong. To this
extent it was internally contradictory. I can see, however, that this might be described as an irrational
policy.

**Was the decision in the Claimant's case contrary to the Defendant's policy of**
**compliance with Article 14(1)(a) ECAT?**

112. On the basis of the analysis set out above, I consider that it was. Essentially, this is because the
Decision letter of 17 August 2020 considers whether the grant of MSL is necessary to protect and assist
the Claimant's recovery and concludes that it is not. The decision-maker found that such treatment as she
requires is available in Vietnam and there were therefore no medical grounds for discretionary leave. The
decision-maker also considered the risk of re-trafficking or becoming a victim of **_modern slavery if the_**
Claimant were to return to Vietnam and concluded that the degree of risk was not such as to warrant MSL.
The decision maker did not consider whether the fact that the Claimant had made an asylum/protection
claim based on the fear of re-trafficking, and therefore needed to stay in this country to pursue that claim,
was a basis for granting MSL. The approach taken by the decision-maker was therefore broadly in
accordance with the aspects of Version 3 of the MSL Policy which I have highlighted above, although that
document had not yet been promulgated.

**Conclusion on Ground 1**

113. I therefore uphold Ground 1.

**Ground 3        .**

114. Mr Buttler confirmed that this Ground only arises if he is wrong on Ground 1. However, I will consider
it briefly for completeness.

115. Mr Buttler took me to [30]-[34] of the judgment of Mr Philip Mott QC in FM (supra) and submitted that
this is an _“anxious scrutiny” case. Accordingly, the Defendant would bear the burden of justifying the_
decision, and greater detail and thoroughness of reasoning would be required than in other cases,
although the degree of detail would depend on the circumstances. He also referred me to **R (MN) v**
**Secretary of State for the Home Department [2021] 1 WLR 1956[242]-[243]. Mr Tam did not dispute that**
this is an anxious scrutiny case.

116. As noted above, Mr Buttler's complaint about the Decision letter was ultimately limited to a complaint
that it did not address, whether sufficiently or at all, an argument by the Claimant that the grant of leave
pending the outcome of her asylum/protection claim would ameliorate her mental health and encourage
her to engage with therapy. Mr Tam's position was that this was because this argument was not put
forward on her behalf. I was therefore taken through the correspondence which led to the Decision, and
some of the evidence submitted on behalf of the Claimant with a view, primarily, to deciding whether the


-----

argument was raised with sufficient clarity and cogency that it required to be addressed by the Defendant.
Mr Tam's case was, in effect, that the Claimant had argued that she needed to remain in this country in
order to receive treatment and to avoid the risk of harm if she returned: this was the issue which the
Decision letter addressed.

117. Having considered the correspondence and the evidence submitted in support of the application for
MSL, which the Decision letter states was taken into account, I am satisfied that the broad argument was
raised by the Claimant. It was set out in some detail in the letter from Duncan Lewis written on 27 May
2020 which stated for example that:

_“We submit that our client should be granted discretionary leave to remain as a victim of trafficking/modern_
**_slavery immediately on the basis of her personal circumstances. It is submitted that any deferral of this_**
_decision, pending an outcome of her asylum claim, would be of significant detriment to her mental health.”_

118. The letter went refer to the views of Murray J in **JP and his references to expert evidence. It also**
summarised evidence submitted to the effect that the Claimant's insecure immigration status was having a
detrimental effect on her mental health and on her ability to engage with treatment. That evidence included
evidence from a case worker at City Hearts dated 13 May 2020 which stated in terms that:

_“A grant of leave would undoubtedly alleviate the stress and anxiety, and also provide that glimmer of hope_
_she is so desperate for in order to encourage her to toward overcoming her PTSD”_

119. There were also medico legal reports which emphasised the Claimant's poor mental health, and the
detrimental effect of her insecure immigration status. These included a report dated 18 May 2020 from a
consultant psychiatrist, Professor Abou-Saleh, to which I was taken at the Hearing.

120.  The 27 May 2020 letter from Duncan Lewis also included the following passage:

_“It is therefore submitted both that our client suffers from serious mental health conditions for which she_
_requires treatment in the UK, and that the lack of certainty surrounding her immigration status is preventing_
_her from accessing all required treatment, from benefitting from the treatment that she is accessing, and is_
_causing her continued suffering. She should therefore be granted discretionary leave to remain for a period_
_of 30 months due to her personal circumstances, while she awaits the outcome of her asylum case.”_

121. The letter of 22 July 2020 which sought a review of the original refusal of MSL was less detailed on
this issue but it clearly referred to the letter of 27 May 2020, listed the evidence which had been submitted
and complained that these representations and the evidence had not been considered. Moreover, as I
have noted, the Decision letter stated that the letter of 27 May 2020 had been taken into account as had
the various medico legal reports and the letter from City Hearts referred to above.

122. I am satisfied that the case that the grant of MSL would be beneficial to the Claimant's mental health
was made, albeit the thrust of her representations and evidence on this issue was to the effect that her
mental health was being undermined by her insecure immigration status pending the outcome of her
asylum/protection claim. I therefore accept that the issue ought to have been addressed and that the
Decision letter, which was essentially to the effect that she could access the relevant treatment in Vietnam
and was not at sufficient risk of re-trafficking or other ill treatment if she were to return there, did not do so.

123. But I would not have given relief on this Ground given that the evidence did not establish that MSL
pending the outcome of the Claimant's asylum/protection claim would have made a material difference to
the Claimant's mental health: her immigration status would still have been insecure until such time as her
asylum/protection claim was granted (if that was the outcome). The answer which would have been given
by the decision-maker, had the point been addressed, is fairly obvious and the point would not have made
any difference to the Decision.

124. I have also considered the point that if it was the case that the Claimant needed to access treatment
and needed to remain in the United Kingdom to pursue her asylum/protection claim, it would not be rational
to refuse MSL on the basis that the requisite care could be accessed in Vietnam. She was not able to
return to Vietnam given her asylum/protection claim. However, this does not take the case anywhere given


-----

that the Claimant was able to remain in the United Kingdom and to access healthcare in any event, given
her asylum/protection claim.

125. In relation to Ground 3 then, I would have granted permission but refused relief.

ANNEXE A: OUTLINE CHRONOLOGY

November 2016: Claimant encountered by UK police soon after arrival in the back of a lorry and
transferred into the care of Bedfordshire Social Services on the basis that she claimed to be a minor.

November 2016-March 2018: Claimant subjected to forced labour and sexual exploitation in brothels and
cannabis production.

20 March 2018: Claimant re-encountered by the authorities, returned to the care of social services and
referred to the NRM but leaves accommodation after 5 days and returns to prostitution and work in
cannabis production.

17 April 2018: positive reasonable grounds decision made in the Claimant's absence.

1 October 2018: Claimant pleads guilty, at Preston Crown Court, to conspiring to produce cannabis.

11 December 2018: Claimant sentenced to 28 months' imprisonment.

11 January 2019: Claimant served with Stage 1 deportation decision.

22 January 2019: in response to the Stage 1 letter, Greater Manchester Immigration Aid Unit write on the
Claimant's behalf confirming she wishes to claim asylum and (unaware of the reasonable grounds decision
in April 2018) urge an NRM referral.

18 March 2019: Ministry of Justice notify the NRM that the Claimant has been re-encountered and
imprisoned.

18 April 2019: Claimant undergoes a substantive asylum interview.

May 2019: Duncan Lewis comes on the record and urges an NRM referral. The Defendant maintains that
she has no record of the Claimant on the NRM system.

23 July 2019: Defendant informs Duncan Lewis that, contrary to earlier correspondence, a record of the
Claimant's first NRM referral and reasonable grounds decision has been located.

22 October 2019: Claimant detained under immigration powers.

31 October 2019: Defendant makes a positive conclusive grounds decision that the Claimant is a victim of
trafficking and postpones MSL decision pending the determination of her asylum/protection claim.

6 November 2019: Claimant issues proceedings challenging the legality of her detention (CO/4369/2019).

14 November 2019: in her Acknowledgement of Service, the Defendant concedes that the entire period of
her administrative detention was unlawful. Claimant released to a safe house, arranged pursuant to the
Defendant's Victim Care Contract with the Salvation Army.

7 May 2020: Defendant agrees, in light of **JP and BS, to promulgate an MSL decision no later than 7**
August 2020.

27 May 2020: Duncan Lewis submit representations to the Defendant in support of the grant of MSL to the
Claimant.

21 July 2020. Defendant refuses MSL.

22 July 2020: pre-action protocol letter challenging the legality of the refusal.

30 July 2020: Defendant agrees to reconsider the MSL decision.

17 August 2020: Defendant issues a revised decision but maintains refusal of MSL for essentially the same
reasons.


-----

24 August 2020: pre-action protocol letter challenging the legality of that decision.

29 September 2020: Claimant issues the current claim for judicial review.

21 October 2020: Defendant's Acknowledgement of Service and Summary Grounds of Defence.

23 November 2020: Mostyn J grants permission on Ground 1 and directs a rolled-up hearing in respect of
Grounds 2 and 3.

11 January 2021: Detailed Grounds of Defence.

23 April 2021: Defendant refuses the Claimant's asylum and human rights claims.

17 May 2021: Claimant lodges an appeal at the First Tier Tribunal.

**End of Document**


-----

