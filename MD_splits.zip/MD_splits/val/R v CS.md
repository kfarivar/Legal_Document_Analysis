# R v CS [2021] EWCA Crim 134

Court of Appeal, Criminal Division

Thirlwall, Holgate and Johnson LJJ

5 February 2021Judgment

Henry Blaxland QC and Shahida Begum appeared for the Applicants

Benjamin Douglas-Jones QC and Andrew Johnson appeared for the Respondent

Hearing date: 10 November 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

.............................

**Covid-19 Protocol: This judgment was handed down remotely by circulation to the parties'**
representatives by email, release to BAILII and publication on the Courts and Tribunals Judiciary website. The date
and time for hand-down is deemed to be

10:30am on Friday, 5 February 2021.

**Lady Justice Thirlwall:**

1. This is the judgment of the court to which we have all contributed.

2. These separate and otherwise unconnected applications for permission to rely on fresh evidence, and
permission to appeal against conviction and sentence, have been heard together because they raise
similar issues in relation to the prosecution of victims of trafficking. Those issues include the availability of
the statutory defence under section 45 Modern Slavery Act 2015 in respect of the alleged commission of
offences before the section came into force.

3. In each case the Applicant pleaded guilty after the coming into force of the 2015 Act to offences
allegedly committed before that date. Each Applicant submits:-i) that the defence under Section 45 is
available to a defendant from the date on which the section came into force, irrespective of when the
offence to which the defence relates occurred; alternatively

ii) that the prosecution should not have been commenced having regard to the systems that were in place
before the introduction of the statutory scheme to protect victims of trafficking; and

iii) the sentence imposed was manifestly excessive and did not sufficiently take account of the mitigating
impact of being a victim of trafficking.

4. In CS's case a separate issue arises as to the jurisdiction of the Court of Appeal (Criminal Division) to
entertain an application for permission to appeal against a conviction in the Magistrates' Court.

5. An application for anonymity has been made by each Applicant. All the applications have been referred
to the full court by the Registrar.


-----

**Jurisdiction to appeal to Court of Appeal (Criminal Division) against a conviction**
**imposed by the Magistrates' Court**

6. Section 1 Criminal Appeal Act 1968 provides:

“…a person convicted of an offence on indictment may appeal to the Court of Appeal against his
conviction.”

7. CS's convictions in the Magistrates' Court were not imposed on indictment.  CS was committed for
sentence to the Crown Court. She relies on section 5(1) Powers of Criminal Courts (Sentencing) Act 2000.
That provides:

“Where an offender is committed by a magistrates' court for sentence under section 3 or 4 above, the
Crown Court shall inquire into the circumstances of the case and may deal with the offender in any way in
which it could deal with him if he had just been convicted of the offence on indictment before the court.”

8. This meant that the Crown Court had the sentencing powers that would have been available if CS had
been convicted on indictment. It does not, however, mean that CS was convicted on indictment, or that she
is to be treated as having been convicted on indictment for the purpose of section 1 of the 1968 Act. It
follows that there is no jurisdiction to entertain CS's application for permission to appeal against the
convictions in the Magistrates' Court. CS's remedy is to appeal against conviction to the Crown Court, or to
appeal by way of case stated to the Divisional Court, or to seek judicial review of the convictions.

9. CS contends that, in the event that there is no jurisdiction to entertain an appeal against conviction, it
would be appropriate for the members of this Court to sit as a Divisional Court and, on an application for
judicial review, to quash the convictions imposed in the Magistrates' Court.

**CS's case: background facts**

10. On 28 June 2015 CS pleaded guilty in the Magistrates' Court to two offences of possession of a class
A drug (crack cocaine and heroin) with intent to supply. She also pleaded guilty to offences of driving with
no insurance and driving with no licence. The case was committed to the Crown Court for sentence. On 30
November 2015, in the Crown Court at Manchester, CS pleaded guilty to 6 further offences of supplying a
class A drug (crack cocaine and heroin).

11. On 15 January 2016 His Honour Judge Rudland sentenced CS to a total of 2 years' imprisonment, the
same term being imposed on each of the drugs counts to be served concurrently. Her driving licence was
endorsed with 6 penalty points for the offence of driving with no insurance. No separate penalty was
imposed for driving with no licence. Offences of possession of a bladed article and possession of offensive
weapons were ordered to lie on the file.

12. The facts giving rise to the convictions were as follows. In May/June 2015, the police conducted an
undercover operation into the supply of Class A drugs in the Salford area of Manchester. The police had
obtained telephone numbers for various drug supply lines, including the line known as “the black girl's line”.
Officers used the “black girl's line” to obtain drugs via the use of undercover officers known as Test
Purchase Officers (“TPO”).

13. The “black girl's line” was being run by CS. She would answer the telephone and set up meetings for
the supply of drugs (crack cocaine and heroin) to take place. She supplied drugs to TPOs on five
occasions in May and June 2015. On four occasions she drove to the meeting place.

14. On 28 June 2015, officers approached CS, who was parked in Eccles town centre. She had driven
there. The police identified themselves as police officers. CS appeared uneasy and distressed.  She was
searched. Two mobile phones were found in her possession. She only had a provisional licence and was
not therefore insured to drive. Following her arrest, during a strip search at the police station, CS informed
officers that she had drugs concealed in her underwear. Officers seized 51 wraps of crack cocaine and 21
wraps of heroin with an estimated street value of approximately £1,400.

15. CS pleaded guilty in the Magistrates' Court to the offences committed on 28 June. She was committed
to the Crown Court for sentence Prior to sentence she was charged with further offences for the incidents


-----

between 24 May and 25 June 2015. She pleaded guilty to the further offences at the first opportunity in the
Crown Court. Her case was that she had been under exceptional financial pressure at the time of the
offence and had 5 dependent children. She borrowed money from a friend. When she was unable to pay
the debt back on demand, the friend told her she would need to sell drugs to settle the debt. She was
provided with a car and the drugs, and made a return trip of 400 miles across the country on several
occasions to sell the drugs.

16. The sentencing Judge found that the offences fell between the Sentencing Guidelines for those who
perform a significant and a lesser role. The starting point for a lesser role is 3 years' imprisonment. The
starting point for a significant role is 4½ years (with a range of 3½ - 7 years). The Judge observed “[t]he
duress, as it were, if that be the right word, that you were experiencing was the terrible financial pressure
you had been put under and the needs of your children, all of which is enforced by the fact that you are not
a lady who has any previous convictions.” He imposed what he recognised was a lenient sentence of 2
years' imprisonment for each drugs offence, all to run concurrently with each other.

17. At the point at which CS would otherwise have been released, she was detained under immigration
powers pending deportation. After taking advice from new legal representatives she was referred to the
National Referral Mechanism (“NRM”). The Competent Authority assessed her case and concluded that
she was a victim of trafficking (or, more strictly, slavery, servitude or forced/compulsory labour) because:

“You borrowed money because you had little money to support yourself and your children. The children's
father was not providing for them. You were therefore in a position of vulnerability. You borrowed money
from a friend… and stated that you would pay it back when you had a job. However, two weeks later the
friend threatened you and told you that the people who gave you the money required that you repay the
money you borrowed by participation in supplying drugs… You were intimidated by [your friend] and her
colleagues… You didn't feel that you could leave the flat you were staying in, even though you were not
locked up, because it was known where you and your family live… You were too scared to tell the police.”

18. The application for permission to appeal against conviction is advanced on the basis that neither the
court nor the prosecution sufficiently considered the trafficking issues that were apparent, and the decision
to prosecute did not take account of the necessary considerations that arise in this context. CS was not
advised as to the protections available to her. In particular, she was not made aware of the defence
available under section 45 of the Modern Slavery Act 2015. Accordingly, it is said, CS has been deprived
of a “legal process to which she was entitled or to which she has a legitimate expectation” to her detriment.
She seeks to rely on fresh evidence, including the conclusive grounds decision. There is a dispute between
CS and her former representatives as to the instructions that she had given. We have not considered it
necessary to resolve that dispute. We proceed on the assumed basis of CS's account in that respect,
without making any finding that is critical of her former representatives.

_Application to set aside Court's direction that CS should give evidence_

19. A direction was made by a different constitution of this court at an earlier hearing, that CS should give
evidence. At the outset of this hearing, Mr Blaxland QC sought to argue that it was not necessary for CS to
give evidence. He pointed out that a finding had already been made that CS was a victim of trafficking. She
had a history of depression. The issues were whether CS had a credible defence under section 45 of the
**_Modern Slavery Act 2015 and whether it was in the public interest to prosecute. It was, he said, not clear_**
that anything would be achieved by CS giving evidence, and there was a question as to whether it was in
the public interest for her to be called. In response to the Court's question Mr Blaxland confirmed that there
was no medical evidence to suggest that CS was medically unfit to testify.

20. We rejected the suggestion that the Court's earlier direction should be set aside. Even if it were to be
accepted that CS is a victim of trafficking that does not, in itself, establish a defence under section 45 of the
2015 Act. The defence is only established where all the conditions in section 45(1) are satisfied. That
includes that a reasonable person in the same situation as the defendant, and having the defendant's
relevant characteristics, would have no realistic alternative to doing that act – see section 45(1)(d) of the
2015 Act. This Court's earlier direction envisaged that it would be necessary for CS to give evidence before


-----

the Court could reliably conclude that she had a credible defence under section 45. There is no reason to
depart from that view.

_CS's evidence_

21. We summarise the oral evidence given by CS as follows.

22. In 2015 CS was living with her partner and her 4 children. Her fifth child was born on 1 May 2015. Her
partner was abusive and controlling. He collected all the benefits to which she was entitled. CS was
desperate for money to provide for her children. She borrowed £3,000 from a friend, K. She was unable to
repay the debt. K put pressure on CS to repay, saying that it had not been K's money in the first place. K
came to CS's flat with a man. They drove CS to Manchester. She stayed in Manchester for about a week.
She went out in the car.  K gave CS a parcel. Somebody would come to the car window and CS would
pass the parcel to them. CS returned to London shortly before the birth of her baby. She was taken to
Manchester a second time, shortly after the birth. She took the baby with her. They stayed in Manchester
for a month but the baby was with CS for about a week. It was unclear how the baby returned to London.
CS went out in the car as before. She did not report the matter to the police because she was afraid of
what “they” might do to her.

23. When CS was arrested a saw and hammer were found in the car. CS's evidence to us was that she
had not known about the hammer. She had told the officers in interview that she had the hammer to put up
curtains. Her explanation for the difference was that the solicitor representative who had seen her at the
police station, who was not herself a solicitor, had told her that anything she said might be reported back to
K, and that she should therefore say “no comment.” It is apparent that she did not follow that advice.

24. After being shown her solicitor's brief to counsel, CS accepted that she had given instructions to her
solicitor to the effect that she had agreed to supply drugs because she was desperate for money, and did
not say that she had been threatened. She said she had been foolish. She agreed she could have not
supplied the drugs and that, instead, she could have gone to the police.

25. The brief to counsel indicated that CS had said that she was to be paid £200 for the drug supply on the
occasion she was stopped. She denied having said that, and said that she had done it because she owed
£3,000. She denied the suggestion in the instructions that she had agreed to be a courier, or that she had
said that the occasion on which she had been stopped by the police was the first occasion on which she
had supplied drugs.

26. In an earlier written statement CS had said that she had borrowed the money from K because she
needed it to pay for an immigration application for one of her children. In evidence to us she denied that
was the case, and said that she had needed the money to provide for her children. She did not explain
why such a large sum was necessary at that time.

27. CS said that it was not long after K had lent her the money that she asked for it back – it had been
about 5 days later. It was about a month later that K had made threats. She denied an account recorded in
immigration documentation that she had said it was about 2 weeks later. She also denied an account that
she had given in a previous statement that it was about 6 months later that the threats had been made.
She recognised the differences in these accounts and said it had now been a long time since the events in
question and it had been traumatic, making it difficult to remember the precise sequence of events.

28. The handwritten notes of a probation officer's interview of CS, for the purpose of writing a presentence report, record CS as having said “I wasn't forced or threatened”. CS said that that was not a
“word for word” record of what she had said, and that she had “never said that,” albeit she was not
accusing the probation officer of lying. CS said that she did tell the probation officer about the threats. In
the pre-sentence report itself the record of CS's account of the offence records that CS had said that she
had supplied the drugs in order to repay a debt – there was no mention of threats. In answer to the
question “[w]hy did the offence(s) occur” the author recorded:

“The defendant advised that she was unable to provide for her children and was coerced into her actions…

[Her partner's] behaviour was noted to be very controlling including financial control. It would seem that


-----

[CS's] partner although claiming funds for the children was not giving her the money to provide for them.

[CS] has since indicated that should such a situation arise again she would contact children's services and
speak to them, but when the offence occurred she was concerned that her children would be taken away
from her and resorted to ill advised methods of funding her living expenses.”

29. In re-examination on her evidence that she could have not supplied the drugs and could instead have
gone to the police she said “I think if I had gone to the police I would not be standing here.” She felt that
she had no option. K had verbally threatened her saying that K needed to pay the money back or else
something would happen to her. K never said what would happen.  In the event nothing has happened to
her.

**Luong Le's case: background facts**

30. On 14 October 2015, in the Crown Court at Wolverhampton, Mr Le pleaded guilty to the offence of
producing a controlled drug of class B (cannabis).

31. On 17 November 2015, Recorder Del Fabro imposed a sentence of 16 months' detention in a YOI.

32. Mr Le had been arrested on 22 April 2015. During the early hours of that day, police were called to a
suspected burglary. On arrival, Mr Le and a co-accused were seen running away from the scene. The
police gave chase and both were arrested shortly afterwards, trying to hide from the police behind a parked
van. Both smelt strongly of cannabis.

33. The prosecution case was that they had fled shop premises that were being used as a commercial
scale cannabis growing factory. 562 plants at various stages of growth were seized from seven rooms
within the premises, along with sophisticated cultivation equipment. The street value was estimated to be in
the hundreds of thousands of pounds. Items in the name of Mr Le, and a small amount of cash, were
recovered from the premises. He was found to be in possession of a mobile phone.

34. Initially, Mr Le gave a false name and date of birth. In interview, he accepted being involved in growing
the plants at the premises.

35. Mr Le initially pleaded not guilty in the Crown Court, but was re-arraigned on the day of trial and
pleaded guilty.

36. Mr Le's case was that he was an orphan who had come to the United Kingdom at the age of 17,
travelling through various other countries on route. When he arrived in the United Kingdom, a man told him
that he could find work for him. He was taken to the premises and told to look after the plants. He was paid
£4,000 and the money was transferred directly to his family in Vietnam. He was locked in the premises and
was not allowed to leave.

37. Mr Le had been referred to the NRM for assessment of whether he was a victim of trafficking. On 9
July 2015 the Competent Authority decided that there were reasonable grounds to suspect that Mr Le was
a victim of trafficking. However, on 3 September 2015 the Competent Authority made a conclusive grounds
decision that, on the balance of probabilities, Mr Le was not a victim of trafficking or modern slavery. This
was because his account was not considered to meet the required standard of proof: Mr Le had not given
any information as to how he had ended up in the house, and the police had said that there was insufficient
information to enable them to investigate.

38. The recorder observed that Mr Le “was a gardener in a sophisticated set-up, growing staggered crops
of cannabis for commercial sale, which may have provided drugs with a street value of many hundreds of
thousands of pounds.” He considered that Mr Le's motives (wishing to provide for his family) were
“admirable” but that his actions were not. The recorder considered that the Applicant had a lesser role in
the enterprise. The applicable Sentencing Council guideline provided a starting point of 1 year custody and
a category range of 26 weeks' - 3 years custody. The quantity of drugs fell towards the top of the guideline
bracket. The recorder adopted a starting point of 18 months custody (by which he meant the provisional
sentence before reduction for the plea of guilty). Allowing (slightly more than) a one tenth reduction to
reflect the guilty plea, a 16 month sentence was imposed.


-----

39. Mr Le sought judicial review of the decision that he was not a victim of trafficking. The Competent
Authority agreed to reconsider the case. On 23 February 2018 the Competent Authority decided that, on
the balance of probabilities, Mr Le was a victim of trafficking. That was because:

“It is considered that you have given a number of contradictory accounts as to the events that have
occurred.… However, it is considered likely, given the available country evidence, that you borrowed a sum
of money from loan sharks to facilitate your journey to the UK.

Equally, you have given a number of differing accounts following your release from police custody following
your arrival in the UK.

Given these inconsistencies, it is not accepted that these events occurred as you claim.

However, it is accepted that, on the balance of probabilities, you were recruited whilst in the UK to work in
a cannabis factory. It would appear consistent that you were threatened whilst in the cannabis factory and
that you were forced to do this work against your will. It is accepted that this was for the purposes of forced
criminality. Consequently, it is accepted that you are a victim of trafficking.”

40. Mr Le contends that his conviction is unsafe because the indictment should have been stayed as an
abuse of process. He says there is now evidence available that establishes that he was a victim of
trafficking at the time of his arrest and prosecution. The offence was committed as a direct consequence of
the trafficking. This was not properly investigated at the time. He was not advised as to the protections
available to him and in particular, was not made aware of the available defence under section 45 Modern
**_Slavery Act 2015. Accordingly, as in the case of CS, so too in the case of Mr Le, it is said that he has been_**
deprived of a “legal process to which he was entitled or to which he has a legitimate expectation” to his
detriment. He seeks to rely on fresh evidence, including the conclusive grounds decision. He did not
provide any witness statement in support of his appeal nor give any oral evidence at the hearing. Instead,
he relied upon the statement produced by his immigration solicitors.

**Protection from prosecution/conviction for victims of trafficking**

_[Protection from prosecution for victims of trafficking before the Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

41. The approach that should be taken to the protection from prosecution of victims of trafficking is
described in many decisions of this court, including in particular R v LM [2010] EWCA Crim 2327, R v N, R
_v Le_ _[2012] EWCA Crim 189, R v L [2013] EWCA Crim 991, R v VSJ [2017] EWCA Crim 36, R v EK [2018]_
EWCA Crim 296, R v O and N [2019] EWCA Crim 752, R v O _[2019] EWCA Crim 1389 and R v DS_ _[2020]_
_EWCA Crim 285._

42. Article 4 of the European Convention on Human Rights prohibits slavery and forced labour. The
Council of Europe Convention on Action Against Trafficking in Human Beings 2005 (“the Convention”) has,
as one of its purposes (see article 1(1)(b)) the protection of “the human rights of the victims of trafficking”
and “a comprehensive framework for the protection and assistance of [such] victims.” EU Directive
2011/36/EU on preventing and combating trafficking in human beings and protecting its victims (“the
Directive”) introduces common provisions for the protection of trafficking victims (see article 1).

43. Article 26 of the Convention states:

**“Non-punishment provision**

Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

44. Article 8 of the Directive states:

**“Non-prosecution or non-application of penalties to the victim**

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties


-----

on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2.”

45. Prior to the 2015 Act, these international obligations were not reflected in domestic legislation. Instead,
effect was given to them principally by means of CPS guidance as to the circumstances in which a
prosecution should be brought, the common law defence of duress, and the abuse of process jurisdiction –
see DS per Lord Burnett CJ at [6]-[7]:

“6. Prior to the enactment of the 2015 Act, there was no domestic statutory reflection of the United
Kingdom's obligations under the Convention and the Directive. As such, the UK's obligations in this respect
were adhered to by means of – (i) relevant CPS guidance, which indicated the capacity of, and the
circumstances in which, a prosecutor could decline to proceed against an individual suspected of being a
victim of trafficking; (ii) where available, the common law of duress, and (iii) the court's abuse of process
jurisdiction, whereby it could review the CPS' prosecutorial decision, and, in certain cases, refuse to
entertain proceedings. The 2015 Act changed this landscape by placing this system on a concrete
domestic footing.

7. The policy of the CPS (2015) in respect of those not within the scope of the 2015 Act required the
prosecutor to consider three broad questions where the defence of duress did not arise on the evidence.
First, was there credible evidence that the defendant fell within the definition of trafficking in Annex 11 to
the UN Convention against Transnational Organised Crime (the Palermo Protocol) and Directive 2011/36;
secondly, was there a nexus between the crime committed and the trafficking; and thirdly, was it in the
public interest to prosecute?”

46. In DS this Court held that in the light of the 2015 Act (where it applies) it is no longer necessary to give
effect to the Convention and Directive by means of the abuse of process jurisdiction – see per Lord Burnett
at [40]:

“…the result of the enactment of the 2015 Act and the section 45 statutory defence is that the responsibility
for deciding the facts relevant to the status of DS as a Victim of Trafficking is unquestionably that of the
jury. Formerly, there was a lacuna in that regard, which the courts sought to fill by expanding somewhat the
notion of abuse of process, which required the Judge to make relevant decisions of fact. That is no longer
necessary, and cases to which the 2015 Act applies should proceed on the basis that they will be stayed if,
but only if, an abuse of process as conventionally defined is found. By way of summary only, this involves
two categories of abuse, as is well known. The first is that a fair trial is not possible and the second is that it
would be wrong to try the defendant because of some misconduct by the state in bringing about the
prosecution.”

47. However, where the 2015 Act does not apply, it remains appropriate to give effect to the Convention
and Directive in the way explained in the earlier authorities. In R v GS _[2018] EWCA Crim 1824 the Court,_
at [76], included the following amongst its summary of the relevant principles:

“(iv)…factors obviously impacting on the discretion to prosecute go to the nexus between the crime
committed by the defendant and the trafficking. If there is no reasonable nexus between the offence and
the trafficking then, generally, there is no reason why (on trafficking grounds) the prosecution should not
proceed. If there is a nexus, in some cases the levels of compulsion will be such that it will not be in the
public interest for the prosecution to proceed. In other cases, it will be necessary to consider whether the
compulsion was continuing and what, if any, reasonable alternatives were available to the VOT. There will
be cases where a decision to prosecute will be justified but due allowance can be made for mitigating
factors at the sentencing stage.

The matter was most helpfully summarised by Lord Judge CJ, in LC, at [33], as follows:

“…the distinct question for decision, once it is found that the defendant is a victim of trafficking is the extent
to which the offences with which he is charged, or of which he has been found guilty are integral to or
consequent on the exploitation of which he was the victim. We cannot be prescriptive. In some cases the
facts will indeed show that he was under levels of compulsion which mean that, in reality, culpability was
extinguished If so when such cases are prosecuted an abuse of process submission is likely to


-----

succeed…… In other cases….culpability may be diminished but nevertheless be significant. For these
individuals prosecution may well be appropriate, with due allowance to be made in the sentencing decision
for their diminished culpability. In yet other cases, the fact that the defendant was a victim of trafficking will
provide no more than a colourable excuse for criminality which is unconnected to and does provide no
more than a colourable excuse for criminality which is unconnected to and does not arise from their
victimisation. In such cases an abuse of process submission would fail.”

(v) As always, the question for this Court goes to the safety of the conviction. However, in the present
context, that inquiry translates into a question of whether in the light of the law as it now is (this being a
rare change in law case) and the facts now known as to the Applicant (having regard to the admission of
fresh evidence) the trial court should have stayed the proceedings as an abuse of process had an
application been made. This question can be formulated indistinguishably in one of two ways which
emerge from the authorities: was this a case where either: (1) the dominant force of compulsion, in the
context of a very serious offence, was sufficient to reduce the Applicant's criminality or culpability to or
below a point where it was not in the Public Interest for her to be prosecuted? or (2) the Applicant would or
might well not have been prosecuted in the Public Interest? If yes, then the proper course would be to
quash the conviction. …”

_[The Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

[48. The Modern Slavery Act 2015 makes provision for the protection of victims of slavery, servitude and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
forced or compulsory labour, and human trafficking. It gives domestic statutory effect to provisions in the
Convention and the Directive, including (by section 45) to article 26 of the Convention and article 8 of the
Directive.

49. Sections 1 and 2 create offences of slavery, servitude and forced or compulsory labour and human
trafficking.

50. Section 45 provides a defence for slavery or trafficking victims who commit an offence. It states:

“45 Defence for slavery or trafficking victims who commit an offence

(1)  A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c)  the compulsion is attributable to slavery or to relevant exploitation, and

(d)  a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2)  A person may be compelled to do something by another person or by the person's circumstances.

(3)  Compulsion is attributable to slavery or to relevant exploitation only if—

(a)  it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4)   A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.


-----

(5)   For the purposes of this section— “relevant characteristics” means age, sex and any physical or
mental illness or disability; “relevant exploitation” is exploitation (within the meaning of section 3) that is
attributable to the exploited person being, or having been, a victim of human trafficking.

(6)   In this section references to an act include an omission.

(7)   Subsections (1) and (4) do not apply to an offence listed in Schedule 4.”

51. Schedule 4 to the Act lists the offences to which section 45(1)-(4) does not apply – see section 45(7).

52. Section 56 makes it clear that a person is to be regarded as a victim of slavery or trafficking if the
person is the victim of conduct which would have amounted to an offence of slavery or trafficking if it had
occurred after sections 1 and 2 had come into force.

53. Section 45, along with most of the Act, came into force on 31 July 2015 – see section 61, and
regulation 2 of the **_Modern Slavery Act (commencement No 1, Saving and Transitional Provisions)_**
Regulations 2015. Regulation 3 of the 2015 Regulations states:

“Saving and transitional provisions

3. The amendments and repeals made by the following provisions of the 2015 Act do not apply in relation
to offences committed wholly or partly before 31st July 2015—

(a) section 7(3);

(b) section 46;

(c) in Schedule 5—

(i)paragraph 1;

(ii)paragraph 5(2);

(iii)paragraph 5(4), insofar as it relates to section 46(2) of the Sexual Offences Act 2003(2);

(iv)paragraph 6(2), (3) and (4)(a);

(v)paragraph 8; and

(vi)paragraph 9.”

**Does section 45 apply to offences committed before 31 July 2015?**

54. The argument on behalf of the Applicants is that once section 45 came into force it had general
application: a defendant who could satisfy the conditions prescribed by section 45 was entitled to the
benefit of the provision, even if the events in question took place before 31 July 2015. This argument
involves interpreting section 45 as having retrospective effect. That is because at the time of the conduct
the statutory defence was not available. If the section does not have retrospective effect, CS's criminal
liability would turn on the application of common law principles identified by Lord Burnett CJ in DS at [6]
(see paragraph 45 above). The argument that is advanced by the Applicants, if correct, would mean that
the legal consequences of actions that occurred before 31 July 2015 were altered with effect from 31 July
2015. That approach involves interpreting the statutory provision as having retrospective effect – see
_Granada UK Rental and Retail Ltd v Pensions Regulator_ _[2018] UKUT 164 (TCC) at [198], approving the_
principle of retrospectivity given in (now) Bennion on Statutory Interpretation (Seventh Edition, March 2019)
at 5.12.

55. There is no doubt that Parliament has power to create a defence with retrospective effect. The
question is whether it did so when it enacted section 45. The presumption, unless the contrary intention
appears, is that Parliament does not intend a statutory provision to have retrospective effect – see
_Wainwright v Home Office [2002] QB 1334per Lord Woolf CJ at [27]._

56. The presumption is rooted in fairness – see L'Office Cherifien des Phosphates v Yamashita-Shinnihon
_Steamship Co Ltd [1994] 1 AC 486per Lord Mustill at 525. The potential for unfairness is at its most acute_


-----

where a retrospective penalty or obligation is imposed, rather than where (as here) the provision in
question creates a defence. It may be that a court will more readily find that the presumption is rebutted in
the latter case, but the presumption still operates: there is no authority to support an approach that limits
the application of the presumption only to certain types of statutory provision.

57. Mr Blaxland QC, on behalf of the Applicants, relies on five features of the legislation in support of his
contention that it can be inferred that Parliament intended section 45 to apply to offences committed before
31 July 2015.

58. First, the heading to the section does not indicate that it only has prospective effect. We are prepared
to accept this, even though the use of the present tense (“who commit an offence”) more naturally
accommodates the commission of an offence after the section comes into force (as opposed to “who have
committed an offence” or “who commit or have committed an offence”). At best, however, the point is
neutral and so insufficient to rebut the presumption. It is necessary to identify some factor which positively
indicates that Parliament intended section 45 to operate in respect of offences which predate the Act.
Otherwise, the presumption cannot be rebutted. The heading to the section does not suffice.

59. Second, reliance is placed on the interpretation provision, section 56. That provides that the definition
of a victim of slavery or human trafficking applies to conduct before the Act came into force. That does
involve a degree of express retrospection. It also affects the application of section 45, because it means
that if a person is a victim of trafficking before the Act comes into force, and then (after it comes into force)
commits an offence, he is not prevented from relying on the defence merely because he was trafficked
before July 2015. It does not, however, show that section 45 was intended to have retrospective effect in
the sense of providing a defence to an offence committed before the Act came into force. On the contrary,
the fact that specific provision was made in respect of the application of the definitions of slavery and
trafficking to pre-enactment events, but no provision was made for the defence to have pre-enactment
effect, undermines the Applicants' argument.

60. Third, the Applicants point to the fact that regulation 3 of the 2015 Regulations specifies the
amendments and repeals which are not to have effect in respect of offences committed before 31 July. The
argument is that because provision was made for those amendments and repeals not to have retrospective
effect, it can be inferred that section 45 (which was not the subject of any such provision) was intended to
have retrospective effect.

61. Assuming that the 2015 Regulations may be used as a legitimate aid to the interpretation of the
substantive legislation, they do not assist the Applicant's argument here. The purpose of regulation 3 is to
address what would otherwise have been a lacuna if amendments and repeals made by the 2015 Act took
effect from the date of enactment. That is because, in respect of pre-enactment events, the repealed and
pre-amended legislation would not apply (because the repeals and amendments would take effect from the
date of enactment) and the 2015 Act would not apply (precisely because it is not retrospective). There
would be a legislative gap. It was necessary to fill that gap by way of transitional provisions. The fact that
this provision was made therefore tends to support the presumption that Parliament did not intend the 2015
Act to have retrospective effect (save to the extent that it made explicit provision). Again, it undermines,
rather than supports, the Applicants' arguments.

62. Fourth, it is said that if Parliament had intended section 45 not to act retrospectively then it would have
said so. There are examples of Parliament doing precisely that. The partial defence to murder of loss of
control does not apply “in relation to offences committed wholly or partly before the commencement of the
provision in question” – see section 54 and paragraph 7(1) of schedule 2 to the Coroners and Justice Act
2009. The statutory modification to the common law on self-defence to benefit householders “does not
apply in respect of force used before the amendment comes into force” – see section 76(5A) Criminal
Justice and Immigration Act 2008 read with section 43(6) Crime and Courts Act 2013.  The assertion that
Parliament would make explicit provision if it had intended a defence not to operate retrospectively is
inconsistent with the presumption.  The logic of this argument is that the presumption against retrospective
effect should be reconsidered in the light of the approach taken to modern statutory drafting, although it


-----

was not put like that in argument.  We do not accept that the provisions above have the effect of removing
the presumption against retrospectivity.

63. Fifth, the Applicants say that if the defence is not retrospective then there will be difficulties where
there is uncertainty about the date of the offence, or where the indictment straddles 31 July 2015. But that
is not an aid to interpretation: the same could be said about any statutory provision that impacts on criminal
liability. Again, the effect of the argument is to deny the existence of the presumption.

64. More generally, the Applicants' argument is that (1) a defendant in criminal proceedings should be
entitled to rely on any statutory defence that is in force at the time that their criminal liability is being
determined, subject to any express or implied statutory restriction on the availability of the defence, (2)
there is nothing in the 2015 Act to limit the application of section 45 to post commencement events, and (3)
if Parliament had intended to prevent a defendant from relying on section 45 in respect of precommencement events then it could and would have said so. The argument is internally valid, but it
ignores the presumption against retrospectivity. The presumption means that the true question is whether
there is any positive indication that Parliament intended to give section 45 retrospective effect. The
Applicants' approach turns the true question on its head.

65. For the reasons we have given we do not consider that there is any positive indication that Parliament
intended to give section 45 retrospective effect. Accordingly, we do not consider that the Applicants have
rebutted the presumption that section 45 applies only to offences committed after it was enacted.

66. There are further reasons which we consider show that Parliament did not intend section 45 to operate
in the manner in which the Applicants suggest.

67. First, the defence is not universal. Some offences fall outside its ambit. They are listed in schedule 4.
They include some common law offences (like murder). They also include many statutory offences.
However, all of the statutory offences in schedule 4 were in force at the time of the 2015 Act: schedule 4
does not include any repealed statutory offences. So, for example, it includes rape contrary to section 1
Sexual Offences Act 2003. But it does not include rape contrary to section 1 Sexual Offences Act 1956. If
Parliament had intended the defence to have retrospective effect it would have had to deal with (for
example) historical sex offences. Otherwise, the effect would be that section 45 would be available as a
defence to a historical rape allegation, but not to a recent rape allegation. That would not be a coherent
approach to the legislative scheme.

68. Second, the Applicants' argument would apply not just to cases like the present where criminal
proceedings had started before 31 July 2015 but carried on afterwards. It would also apply whenever an
offence was committed before 31 July unless (they accept) there was also a conviction before that date.
The language of the statute does not support the drawing of these distinctions.

69. Third, the Applicants' argument has the effect of substituting retrospectively section 45 for the abuse of
process principles for (some) offences committed before 31 July 2015. Again, this would not promote a
coherent approach to the legislative scheme. The situation is analogous to section 16 of the Interpretation
Act 1978. A repeal of a statutory offence does not have retrospective effect (so the earlier legislation
continues to apply to offences already committed under that earlier legislation), unless the contrary
intention appears – see, for example, R v W London Stipendiary ex parte Simeon [1983] AC 234.

70. This Court has not previously determined the question that is raised on these applications. It has,
however, consistently proceeded on the understanding of the operation of section 45 which we consider to
be correct – see:

(1) VSJ at [4]: “as the 2015 Act was not drafted to provide retrospective protection, the regime developed
by the courts will…continue to apply to those not within the scope of the Act who face charges, but who
claim there is a nexus between the crime with which they are charged and their status as victims of
trafficking for the purposes of exploitation”;

(2) VSJ at [28]: “Parliament enacted section 45 without providing for retrospective protection”;


-----

(3) GS at [59]: “Section 45…provides an express (though not retrospective) defence to VOTs compelled to
commit an offence”;

(4) O and N _[2019] EWCA Crim 752 at [64]: “Since these offences preceded [the enactment of section 45],_
the jury would not have been able to consider the defence afforded by section 45”;

(5) O _[2019] EWCA Crim 1389 at [27]: 'Section 45…came into force on 31 July 2015. This new approach_
is not retrospective in effect.”

71. In R v Joseph _[2017] EWCA Crim 36; [2017] 1 WLR 3153the appellants argued that the common law_
defence of duress should be expanded (for offences committed before the 2015 Act came into force) so as
to reflect section 45. The submission was limited to victims of trafficking (see at [25]). It was only advanced
because section 45 is not retrospective. This Court rejected that submission and held that the common
law, as applied to events before the 2015 Act came into force, satisfied the requirements of the Convention
(see at [27]). If section 45 were to be given retrospective effect, then it would mean that _Joseph_ was
decided on a false basis. The result would be that section 45 overlies the common law in respect of events
that pre-date the 2015 Act. There is nothing to indicate that Parliament intended to bring about such a
muddled outcome.

72. Accordingly, we reject the Applicants' primary ground of appeal.

73. We heard some brief argument about the test to be applied in determining an appeal against
conviction on the basis of overlooked evidence.  Mr Douglas- Jones QC relied on the decision of this court
in R v Boal [1992] 1 QB 591. In that case the appellant who worked in a bookshop had pleaded guilty to
failing to comply with a premises fire certificate. He had been advised that he was undoubtedly the
manager of the shop so as to bring him within the scope of the offence. In fact he was not the manager of
the shop. His appeal against conviction was allowed.

74. The court added a “short paragraph of warning” at the end of its decision – see Simon Brown J at
599H

“This decision must not be taken as a licence to appeal by anyone who discovers that following conviction
(still less where there has been a plea of guilty) some possible line of defence has been overlooked. Only
most exceptionally will this court be prepared to intervene in such a situation. Only, in short, where it
believes the defence would quite probably have succeeded and concludes, therefore, that a clear injustice
has been done. That is this case. It will not happen often.”

75. The test has been followed on a number of occasions since then. Mr Blaxland  submits that it is
fundamentally wrong in principle and adds an unwarranted and impermissible gloss to the statute.

76. This issue only achieved prominence in the course of oral submissions. It was not clearly the focus of
any ground of appeal, and was not fully developed in either the written or oral argument. We permitted, and
received, short notes from the parties following the hearing (in the Respondent's case limited to a list of 5
authorities). It would be unsatisfactory for an issue of this nature to be determined on the basis of argument
that has developed in this way, and which may still be incomplete. Given our decision in respect of the
existence of the defence in this case it neither necessary nor desirable to determine this issue.

**Should the prosecutions have been stayed as an abuse of process?**

77. The Applicants' alternative argument is that their convictions are unsafe and that the prosecutions
should have been stayed as an abuse of process.

78. In the light of our decision that section 45 of the 2015 Act does not apply to the Applicants' cases, it
follows that the pre-2015 regime of protection (see paragraphs 41 – 47) does apply. It would have been
open to each of the Applicants to argue that they should not have been charged and/or that their
prosecution was an abuse of process. It is, in principle (subject to the applications to rely on fresh evidence
and to seek to appeal out of time) open to them now to appeal against their convictions on the grounds that
they are unsafe because the proceedings should have been stayed as an abuse of the court's process.


-----

79. We have considered the fresh evidence adduced by each Applicant de bene esse in order to assess
whether it provides arguable grounds for contending that their convictions are unsafe.

80. CS's case: In CS's case no consideration was given to the question of whether she was trafficked. The
Competent Authority subsequently determined that she was a victim of trafficking. There are many
inconsistencies in her evidence. Mr Blaxland rightly points out that this is a common feature in trafficking
cases, and is a consequence of the trafficking and the consequential psychological impact:
inconsistencies, in this context, are not necessarily an indicator that the core underlying account is
untruthful. Mr Douglas-Jones accepted that point in principle, but contended that the gross inconsistency
over the period of time that passed before threats were made (varying between 2 weeks and 6 months),
something that CS might have been expected to recall with some clarity, together with her account to the
probation officer, did indicate that her evidence was untruthful.

81. We do not consider it necessary to make a final finding in relation to this, or to depart from the
Competent Authority's finding that CS is a victim of trafficking (but nor do we endorse that finding). We
therefore proceed on the basis that she was a victim of trafficking. On that basis, we are also prepared to
accept that there was a clear nexus between the trafficking and her offending. She was not, however,
powerless to act. She was able to seek the assistance of the authorities when in need. Her offending
spanned 6 occasions over a period of a month.  She accepted that she could have decided not to supply
the drugs and instead gone to the police. We assume that her account that if she had done that she would
not have been “standing here now” means that she would have been subject to some form of reprisal.
However, she did not provide any detailed account of threats that had been made, or the background
circumstances.

82. We do not therefore consider that it is arguable that her culpability is extinguished by the trafficking
such that the prosecution was, arguably, an abuse of process. To the extent that CS contends otherwise
(by reference to threats) we do not consider that her evidence is capable of belief. The evidence is too
vague and inconsistent credibly to indicate that CS was prevented from seeking assistance from the police.

83. Mr Le's case: Consideration was given, before Mr Le was convicted, to the question of whether he was
a victim of trafficking. His case was referred to the NRM. The NRM concluded that he was not a victim of
trafficking. If the NRM conclusion is accepted at face value then there was no basis to apply the pre-2015
Act protection regime. There was no public interest ground against prosecution, and no basis for
contending that the prosecution amounted to an abuse of process. The fact that the Competent Authority
subsequently agreed to reconsider its decision, and that it then reached the opposite conclusion, does not,
in itself, show that its original decision was flawed. Far less does it show that there was any error in the
prosecution process. Even if it could be said that it should have been appreciated at the time of conviction
that Mr Le was a victim of trafficking, it does not follow that the conviction was unsafe. On his own
evidence, he made a free and informed choice to come to the United Kingdom. He made a free choice to
go to the property where he cultivated the cannabis. He secured significant financial rewards from the
enterprise. The events of the early hours of 22 April 2015 show that he was physically able to leave the
property. Accepting his case at its highest, he nonetheless bore substantial culpability for his offending. As
with CS's case, to the extent that he contends otherwise (and he has not even given evidence to support
his account) that is not capable of belief. This is far removed from the type of case where culpability is
extinguished as a result of trafficking, such that a prosecution is properly to be regarded as an abuse of
process.

**Application for leave to appeal against sentence: CS's case**

84. There were eight offences of supplying (or possessing with intent to supply) a class A drug. The Judge
considered that CS's role was between lesser and significant. The guideline starting point for the former is
a custodial term of 3 years. For the latter it is 4½ years with a range of 3½ to 7 years. The Judge's starting
point of 3 years was very significantly below that which would have been appropriate without significant
mitigation. He referred to “duress”. Although he had in mind CS's financial circumstances, the net effect is
that he was sentencing CS on the basis that she had felt compelled by the circumstances she was in to
resort to the supply of class A drugs. He could not have known what would subsequently be revealed by


-----

the conclusive grounds decision, but the sentence that he imposed was so reduced that it amply
accommodated the mitigation that would have been available to CS if the Competent Authority's later
decision had been available. We do not therefore consider that the sentence was arguably manifestly
excessive.

**Application for leave to appeal against sentence: Mr Le's case**

85. In Mr Le's case there was no reduction in sentence to reflect that he was a victim of trafficking or that
he was acting under a degree of duress falling short of the common law defence. This was a Category 2
case, the recorder considered (perhaps somewhat generously) that his role was a lesser one.  The
starting point therefore was 12 months' imprisonment with a range of 26 weeks' to 3 years' custody.
Taking account of the quantity of plants and the large scale production, of which the Applicant was aware,
the recorder was bound to move up very significantly from the starting point towards the upper end of the
range. There was little mitigation known at the time but the judge nonetheless reached a provisional
sentence of 18 months before the 10% reduction for the guilty plea and the sentence of 16 months.

86. Taking account of the finding of the Competent Authority that Mr Le was subject to a degree of force,
given the scale of the operation we do not consider that a sentence of 16 months could be said to be
arguably manifestly excessive. On the contrary it properly reflects the level of culpability in his case.

**Anonymity**

87. An interim order was made so that the Applicants' names were anonymised for this hearing.

88. We have considered the guidance of the Vice President of the Court of Appeal (Criminal Division) at

[9] to [15] of R v L and R v N _[[2017] EWCA Crim 2129. In particular the starting point is the importance of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
the principle of open justice, and anonymity orders can only be justified when they are strictly necessary.

89. We do not accept the submission advanced on behalf of the Applicants that there is no public interest
in the publication of their identities. The requirement for open justice includes the names of parties to court
proceedings being public. However, in the circumstances of this case, the incursion into the open justice
principle by a grant of anonymity is small. The proceedings in the Crown Court took place without any
order for anonymity or any reporting restriction with no adverse consequences but it has not been
suggested that the public understanding of this case would be appreciably enhanced by knowledge of the
Applicants' identities. There has been no submission on the part of the press, or anyone else, that their
identities should be revealed. None of that is, in itself, sufficient to warrant a grant of anonymity. However,
each Applicant has been found to be a victim of trafficking. In CS's case she has named those involved
and given evidence about their participation in criminal offending. We are prepared to accept that this gives
rise to a potential risk to her sufficient to justify a grant of anonymity. Accordingly, we shall direct that there
will be no reporting of CS's name or any detail of the proceedings which might tend to reveal her identity.

90. In Mr Le's case he has not given evidence. We have not been shown any evidence that the revelation
of his identity would give rise to any risk to him. Accordingly, we refuse the application for anonymity in his
case.

**Conclusion**

91. The defence created by section 45 Modern Slavery Act 2015 does not apply to offences committed
before 31 July 2015 when that section came into force. It is not arguable that the conviction of either CS or
Mr Le is unsafe, or that the sentence imposed in either case was manifestly excessive.

92. All the applications for leave to appeal are refused. It is not necessary to consider further in the case
of CS whether this court should reconstitute itself as a Divisional Court.

**End of Document**


-----

