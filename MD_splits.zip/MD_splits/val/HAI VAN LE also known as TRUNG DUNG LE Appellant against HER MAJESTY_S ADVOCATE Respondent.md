# HAI VAN LE also known as TRUNG DUNG LE Appellant against HER
 MAJESTY'S ADVOCATE Respondent 2019 Scot (D) 14/7

[2019] HCJAC 44

Appeal Court, High Court of Justiciary

Lord Brodie, Lord Turnbull

Appellant: Findlater; Faculty Appeals Unit

Respondent: Edwards QC, AD; Crown Agent

10 July 2019

**OPINION OF THE COURT delivered by LORD BRODIE**

[1]     The appellant's name is Trung Dung Le. He was born in 1981. He is a Vietnamese national. At a trial diet at
Aberdeen Sheriff Court on 21 January 2019, the appellant pled guilty to charges (3) and (4) on the indictment, these
being: (3) being concerned together with others in the supplying of cannabis between 19 June and 3 July 2018 in
[contravention of section 4(3)(b) of the Misuse of Drugs Act 1971; and (4) together with others, and over the same](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0KF-00000-00&context=1519360)
[period, producing cannabis in contravention of section 4(2)(a) of the Misuse of Drugs Act 1971.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0KF-00000-00&context=1519360)

[2]     The sheriff deferred sentence for the preparation of a Criminal Justice Social Work Report (CJSWR). On 25
February 2019, having heard a plea in mitigation and having considered the terms of the report the sheriff
sentenced the appellant to a period of 3 years imprisonment backdated to the date on which he was first remanded
in custody, that being 4 July 2018. The sheriff explains in her report to this court that she afforded the appellant a
discount of 12 months from what would otherwise have been the appropriate sentence. While this is not reflected in
the court minutes, at para [14] of her report the sheriff notes that she accepted what she has been advised by the
appellant's agent: that the appellant had been offering to plead guilty to the two charges in his true name since the
date of the first diet.

[3]     The sheriff records the written Crown narrative as follows:

“[6] I was advised that the locus, 24 Langstane Place in Aberdeen, is a privately owned granite tenement
building in the City Centre. It is on 3 levels - basement, ground and first floors.

[7]     During June 2018 Police Scotland received intelligence that a cannabis cultivation operation was
ongoing within the locus. On 26 June 2018, search and Misuse of Drugs Act warrants were obtained, which
were executed on 3 July 2018. At this time the Appellant and his co-accused Ha Quang Le were found within a
cupboard on the first floor of the locus. A significant growing operation was in progress.

[8]     The two were cautioned and arrested and conveyed to Kittybrewster Police Station, Aberdeen. A
systematic search of the locus was then conducted and six separate growing areas were found on the first floor
of the property. During the search numerous electrical items were found in each growing area. The items
consisted of fans, lighting units, air filters, climate control and temperature gauges, dehumidifiers, carbon
dioxide generators and mist makers. The windows in the property were covered with plastic sheeting internally


-----

and wooden boards externally. The hallway and various areas leading to and within the growing areas
contained a large volume of electrical boxes and cabling leading to various areas of the locus to power the
electrical equipment.

[9]     A total of 440 juvenile and 587 mature plants was found across the 6 growing areas. Samples
presumptively tested positive for Cannabis.

[10]     The potential combined 'street' value of the plants was given as being between £225,940 and
£831,870.

[11]     The appellant, a Vietnamese national, was later cautioned and interviewed with the assistance of a
Vietnamese interpreter. He claimed that he had been taken to the locus and had not left the building since he
had arrived. He stated it was already set up as was found by police. He was tasked only with watering the
plants for which he was due to be paid £500 per month, but had not yet received any money. He stated that
had no other involvement other than growing of the plants and persons unknown to him attend during the night,
provide him with food and harvested the mature plants. He advised that he was too frightened to attempt to flee
the address as he believed that the persons employing him would be watching outside.

[12]     I was advised that The Home Office had rejected the appellant's claims of human trafficking / slavery,
servitude and forced or compulsory labour. He was deemed to have entered the UK illegally and would be
deported to Vietnam in due course. I was advised that CCTV footage taken at Manchester Piccadilly railway
station on 1 July 2018 had been viewed by police officers and showed the Appellant purchasing a train ticket
and boarding a train to Aberdeen. Footage from various locations throughout Aberdeen on 1 July 2018 had
also been viewed by police officers and showed the appellant leaving Aberdeen railway station, making his way
along various streets, entering a betting shop and a fast food restaurant before approaching the locus where he
was seen speaking on his mobile phone before entering the locus.”

[4]     The sheriff records what was said in mitigation in paras [15] to [17] of her report:

“[15] In mitigation, I was referred to the Criminal Justice Social Work Report (CJSWR) and further advised by
his agent that the appellant is a Vietnamese National who maintained that he was trafficked into the UK in
2010. I was advised that it was accepted on his behalf that his position fell short of a defence of coercion (and
no exception had been taken to the Crown narration, including the sightings described at paragraph 12 above)
but that he had found it difficult to see any safe alternative to doing what he did, given that he was in the
country unlawfully with no legitimate means of income and had told his agent that he acted under the threat of
violence.

[16]     His solicitor further stated that he accepted, given his immigration status and lack of address in the
UK that there was no feasible alternative to a custodial sentence and asked that I take into account the stage at
which pleas were offered and the time spent in custody. I was also invited to accept that the appellant had
played a limited role in the operation, as a 'gardener'. He had been told that he would be paid £500 for his work
he had not received any such remuneration.

[17]     The CJSWR reported that the appellant was born and brought up in Vietnam, describing a good
upbringing and positive memories of childhood. He is married with a 15 year old daughter but has not seen his
family for 10 years. He told the social worker that between 2009 and 2010 he was forcibly removed from China,
where he was then working, with other Vietnamese Nationals and transported to France before being trafficked
to the UK. He said that he had been kept against his will and forced for around 10 years by the gang that had
smuggled him into the UK to look after cannabis plants at various locations, without financial gain and in fear
for his own safety and that of his family in Vietnam. He was reported to have expressed a level of regret for the
offences but to have said that he was not aware that the plants he was tending were illicit substances and to
have felt that he had little choice but to participate.”

[5]     What the sheriff summarises at para [17] of her report reflects the account given by the appellant to the
author of the CJSWR:


-----

“By way of background Mr Le reported that between 2009 and 2010 he had been working in China in order to
provide for his family in Vietnam. He informed that during one of his night shifts he was approached by a group
of Vietnamese people, unknown to him, and was told to follow them before they forced him to get in the back of
a lorry. He added that there were other Vietnamese people in the lorry and that they were all provided with
false identifications and instructed to use false names. Mr Le explained that he and the others were threatened
with violence should they had not followed given directions. Mr Le advised that after a long journey they arrived
in what he believed to be Russia. He informed that he was kept in an abandoned house for approximately five
days along with four other Vietnamese individuals. He stated that he and the others were then transported to
France where they stayed in 'a small house' for approximately four days before being trafficked to the United
Kingdom. Mr Le reported that in Britain, he was kept against his will in several locations and numerous houses
that had been converted into 'plant farms'. He stated that he was forced, over the course of approximately 10
years, to look after cannabis plants by 'the gang' that had smuggled him to the country. He denied gaining any
financial profit for work he was doing. Mr Le disclosed that he attempted to escape on two occasions however,
each time he got caught, 'beaten up' and told that his family in Vietnam would have be targeted and harmed
should he had not obeyed [sic]. Mr Le stated that he has only recently learnt that plants he was looking after
were in fact illicit substances.

**What is the level of responsibility taken by the individual for the offence?**

Mr Le reported that despite being forced to commit the offences described above he accepts his responsibility
and he does not dispute the facts outlined in the charge sheet.

**What is the level of planning?**

Mr Le maintained that he is a victim of human trafficking and that he was forced into cannabis cultivation. He
placed significant emphasis on his actions being influenced by feelings of intimidation and belief that 'the gang'
would cause him and his family significant harm if he had chosen to disobey. However, Mr Le accepted that he
became part of well organised cannabis supply chain and, therefore it is arguable that there would have been a
degree of pre-meditation involved in these offences.”

[6]     One ground of appeal has passed the sift and that is:

“The sheriff failed to attach sufficient weight to the personal circumstances of the appellant. In particular the
sheriff failed to take into account that the appellant had been trafficked for the purpose of committing the
offences to which he pled guilty. Neither the sheriff nor the Crown had called this aspect of the appellant's
mitigation into question. It is respectfully submitted that given the circumstances of the appellant, the sheriff
should have exercised her discretion to reduce what would have been the normally appropriate sentence.”

The ground of appeal also makes reference to the decision of the Appeal Court in _Quyen Van Phan_ v _HM_
_[Advocate, 2018 JC 195 at paras [44] and [45].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V7C-H0D2-D6MY-P29K-00000-00&context=1519360)_

[7]     In her report the sheriff responds to this ground of appeal as follows:

“[23] In relation to the first ground, I was presented with a written narration which was read out verbatim in court
and contained the information summarised at paragraph 12 above. It was presented as an agreed narration
and not challenged. In mitigation I was referred to the social work report, but only in general terms, and it was
also mentioned by the appellant's agent in court, as I have noted, that the appellant maintained that he was
trafficked. This position was not, however, argued or put forward as a significant strand of mitigation.
Specifically, whilst I was told what the appellant had said to his agent, I was not invited to accept that this was
the case. It was also placed in the context of 'falling short of a defence of coercion' as I have noted. Had it been
so argued and had the Crown narration been challenged in terms, I may have required to fix a proof in
mitigation, since the evidence provided in the agreed Crown narrative suggests that the appellant had at least a
degree of freedom to come and go without compulsion and is perhaps a little at odds with some of the
information provided by the appellant to the social worker.”


-----

[8]     The appellant's riposte in his case and argument is as follows:

“At no time during the plea in mitigation was there a challenge by the Crown, the sheriff nor the co-accused as
to what was said by the defence agent on behalf of the appellant. The appellant's agent submitted that the
appellant's position fell short of that of a defence of coercion (hence the pleas of guilty were tendered) and that
he had been trafficked. ...If what is being said on behalf of the appellant is challenged or in some way not
accepted by any other party (including the Sheriff) then it is incumbent on the other party or Sheriff to say so
[and only then might the issue of a proof in mitigation arise, (see HM Advocate v Murray 2008 HCJAC 1; Ross v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SWM-X3T0-TWYV-K0Y5-00000-00&context=1519360)
_[HM Advocate 2015 JC 271; Stewart v HM Advocate [2017] HCJAC 8; Sinclair v HM Advocate [2017] HCJAC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VF22-D6MY-P489-00000-00&context=1519360)_
_88_ _McCartney v HM Advocate 1998 SLT 160).”_

[9]     Mr Findlater appeared for the appellant. He drew attention to paras [18] and [19] of the sheriff's report
where she explains that in determining the appropriate sentence she had had regard to the guidance provided by
[the Appeal Court in Lin v HM Advocate 2008 JC 142. However, Mr Findlater submitted that what she had not done](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDH2-8T41-D02F-00000-00&context=1519360)
was to have regard to what had been said in Quyen Van Phan v HM Advocate: that the fact that an accused had
been trafficked may provide powerful mitigation even although the defence of coercion has not been made out. As
appeared from para [23] of her report, the sheriff had failed to give any weight to the appellant's history of having
been trafficked into the United Kingdom and through violence and intimidation having come to commit the offences
to which he had pled guilty. The sheriff had been pointed to that history by being referred to the CJSWR. She had
given no indication that she disputed what appeared there. It was not necessarily inconsistent with the terms of the
Crown narrative. In particular, the fact, as disclosed in the Crown narrative that the appellant apparently had a
degree of freedom of movement was not inconsistent with him being kept in a state of servitude: _Miller_ v _HM_
_[Advocate 2019 SCCR 78 at para [23]. Having not challenged what was said to her by the defence agent the sheriff](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V80-R1C2-8T41-D3N9-00000-00&context=1519360)_
was bound to accept its veracity and therefore should have reflected the mitigation provided by the appellant's
status as a victim of trafficking by reducing the length of the sentence imposed below the range indicated by the
guidance given in Lin v HM Advocate. This court should correct the sheriff's error by quashing the sentence of 3
years and replacing it with one which properly recognised the compulsion under which the appellant had been
acting.

[10]     We see there to be a number of difficulties in the way of our acceding to Mr Findlater's invitation.

[11]     The international trafficking of human beings for the purpose of their exploitation is well recognised as a
prevalent modern evil which can inflict great harm on its victims. The Scottish Parliament has attempted to supress
that evil and to reduce its consequent harm by the enactment of the Human Trafficking and Exploitation (Scotland)
Act 2015. It has done so in the context of a number of international instruments imposing relevant obligations on the
United Kingdom. These include the United Nations Protocol to Prevent, Suppress and Punish Trafficking in Persons
Especially Women and Children, supplementing the United Nations Convention against Transnational Organized
Crime, (the “Palermo Protocol”); the Council of Europe Convention on Action against Trafficking in Human Beings
of 16 May 2005 (the “Warsaw Convention” or the “Trafficking Convention”); and the Directive 2011/36/EU of 5 April
2011 of the European Parliament and of the Council of 5 April 2011 on preventing and combating trafficking in
human beings and protecting its victims (the “Directive”).

[12]     The Palermo Protocol, in article 3, the Trafficking Convention, in article 4, and the Directive, in article 2,
adopt very similar definitions of trafficking in human beings. This common concept is reflected in the terms of the
2015 Act. In the Directive, trafficking in human beings is described in this way:

“The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or
transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of
abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or
receiving of payments or benefits to achieve the consent of a person having control over another person, for
the purpose of exploitation.”

[13]     One of the ways in which a victim of trafficking may be exploited is through being compelled to engage in
criminal activity. A not uncommon example of such criminality, often associated with persons of East Asian origin, is


-----

what is often referred to as cannabis farming. It does not however follow that every cannabis farmer with an
irregular immigration history is a victim of human trafficking. At para [32] of its opinion, the court in _Van Phan_
records the submission on behalf of the Crown that the phenomenon of individuals who had voluntarily committed
criminal offences falsely claiming to have been compelled to do so, was not uncommon among Vietnamese
nationals who were involved in cannabis production. In support of that proposition the Crown had referred to the
Report of the Independent Anti-slavery Commissioner, _Combating_ **_Modern Slavery experienced by Vietnamese_**
_Nationals en route to, and within, the UK, paragraph 4.2.2._

[14]     The 2015 Act provides certain protections for those who are found to be involved in criminality and who
are judged either possibly or probably to be victims of human trafficking. Section 8 of the Act requires the Lord
Advocate to issue and publish instructions about the prosecution of an adult person who appears to be a victim,
which must include factors to be taken into account or steps to be taken by the prosecutor when deciding whether
to prosecute, where an adult is understood to have done an act which constitutes an offence because the adult has
been compelled to do so and the compulsion appears to be directly attributable to the adult being a victim of
trafficking. As is discussed in _Van Phan_ the Lord Advocate has issued and published such instructions. These
provide that there is a strong presumption against prosecution where there is credible and reliable information that:
the accused was a victim of trafficking; he or she was compelled to commit the offence; and the compulsion was
directly attributable to his being a victim. The Lord Advocate has appointed a national lead prosecutor for human
trafficking and exploitation. All cases require to be reported to her for a final decision. If information comes to light
which suggests that an accused is the victim of human trafficking, the prosecutor is required to investigate.

[15]     In addition, section 9 of the Act provides that where there are reasonable grounds to believe that an adult
is a victim of human trafficking, the Scottish Ministers must secure for the adult such support and guidance as they
consider necessary. Section 9 implements for Scotland certain obligations imposed on the United Kingdom by the
Trafficking Convention. It makes provision for the making of a “reasonable grounds decision” as to whether an adult
is a victim of human trafficking, to be followed, in the event of a positive reasonable grounds decision, by the
making of a “conclusive determination” of the same issue. These decisions are made by the “competent authority”
which, in terms of section 9(7) of the Act, is the competent authority of the United Kingdom for the purposes of the
Trafficking Convention. That is the Home Office acting under the National Referral Mechanism.

[16]     The principal issue in _Van Phan_ was whether the Scottish Parliament in enacting section 8 had
transposed article 8 of the Directive in a way which was compatible with the Directive. The court held that it was
compatible. However that was not the point relied on by Mr Findlater. Rather, he drew attention to what appeared in
paras [44] and [45] of the opinion of the court:

“[44] … It will be a matter for the minuter to decide whether to plead not guilty and to run a defence of coercion.
If the matter goes to trial and the jury reject coercion as a defence, the minuter can still maintain that he was
nevertheless trafficked and that that had a bearing on the degree of his culpability. The fact that the jury have
not been asked to rule on the fact of trafficking or its effect, other than in the context of coercion, has no
bearing on the sheriff's ability to assess that fact and its bearing. As with many potential mitigating factors, the
sheriff is entitled to form a view based upon the evidence heard. This may include the testimony of the minuter
himself. If he or she has not given evidence prior to a guilty verdict or he or she elects to plead guilty, he or she
can still make such submissions about his or her personal circumstances (including being a victim of trafficking)
as he or she wishes. If there is a material issue of disputed fact, he has the option of a proof in mitigation. In all
of these various situations, the sheriff has a discretion to reduce what would otherwise normally have been the
appropriate sentence. …

[45]     In a case such as the present, where there are established parameters in relation to sentences for
cannabis cultivation (Lin v _HM Advocate), a significant reduction in the level of custodial sentence may be_
appropriate. … What is clear is that the sheriff has a wide discretion in deciding what, if any, penalty should be
imposed where the person convicted has been a victim of trafficking and this has encouraged him or her to
commit the offence, albeit that the common law defence of coercion has not been made out.”


-----

We would respectfully suggest that nothing new is being said in these paragraphs. If coercion is made out, it
provides a complete defence to a criminal charge. At para [43] the hypothetical case of cannabis cultivation is
posited where the farmer is confined to a flat in which the cannabis is grown, and has reasonable grounds for
believing that, if he does not tend to the crop, he will be seriously injured on the arrival of those controlling the
operation. In such a case the defence of coercion may well be made out. However, even if coercion is not made
out, it has always been possible to advance by way of mitigation of sentence that a convicted person has acted as
he did by reason of intimidation or other means of compulsion. The court may be particularly sympathetic to such a
plea where it can be shown that the convicted person is in some way vulnerable and accordingly susceptible to
such pressure: see eg _Stafford_ v _HM Advocate_ 2005 SLT 836. A trafficked person may very well have such
vulnerabilities. However, the availability and effectiveness of such a plea in mitigation will always depend on the
facts and circumstances of the case and in particular whether it can be demonstrated that the pressure relied on
compelled the accused to commit the specific offence of which he has been convicted.

[17]     Here, the sheriff accepts that she did not factor in the appellant's account to the author of the CJSWR that,
as a victim of human trafficking, he had been forced to look after cannabis plants by “the gang”, as a distinct step in
determining the appropriate sentence. Rather she had followed the guidance provided by Lin, which she found to
be very much on all fours with the present case, other than the fact that the number and value of plants here were
significantly higher than in Lin.

[18]     In going first to Lin the sheriff cannot be criticised. It was intended as a guideline case in relation to what
was then the relatively recent phenomenon of commercial cannabis cultivation usually in urban environments and
very often employing the labour of foreign nationals whose immigration status was irregular. The court appreciated
that, as is usual with drugs operations, it is those with a lesser degree of responsibility who tend to appear before
the court. Nevertheless, the court determined that where cultivation is on a commercial and substantial scale a
sentence of imprisonment will, almost inevitably, be appropriate because: “The courts must seek to deter individuals
from lending their services to such activity - even where offenders are in circumstances where the pressure on them
to participate may be heavy.” Accordingly the appropriate starting point for “gardeners” involved in relatively large
scale operations will ordinarily be in the range of 4 to 5 years imprisonment.

[19]     We would make three observations about Lin and how the sheriff applied its guidance in the present case.
First, the court in _Lin_ took general deterrence to be a primary object in sentencing cases of this sort. Obviously,
general deterrence is weakened if the organisers of the commercial production and then supply of cannabis, can
plausibly represent to those they employ that by giving an entirely vague and generic account of having been
trafficked and then forced to participate in criminal activity they can escape or receive only light punishment.
Second, in fixing the ordinary range of 4 to 5 years imprisonment, the court in Lin intended that range to apply to
cases where there was “heavy” pressure on convicted persons to participate. Third, in selecting 4 years as the
headline sentence the sheriff in the present case can be said to have been lenient. We agree with the sheriff that
the circumstances of the present case are broadly on all fours with _Lin_ but somewhat more serious given the
number and value of the plants involved. In Lin the sheriff had chosen 5 years as the headline sentence, prior to
discounting it to take account of the guilty plea. The court described that as on the severe side but not excessive.

[20]     Mr Findlater nevertheless argued that the sheriff in the present case should have imposed a sentence
below the range indicated in _Lin_ having regard to what had been said by the appellant's agent and left
unchallenged.

[21]     We accept the proposition, generously vouched by authority in the note of argument on behalf of the
appellant, that when primary facts are put before the court by way of mitigation then, if they are not inconsistent with
the plea of guilty or any agreed narrative of events, and they are not manifestly absurd, unless he or she challenges
them and affords the convicted person the opportunity of a proof in mitigation, the sentencing judge will usually be
obliged to proceed on the basis that what has been put forward in mitigation is true and therefore have regard to it
in determining sentence. However, we do not accept that that proposition has much application to the
circumstances in the present case.


-----

[22]     Mr Findlater confirmed the accuracy of the sheriff's report in its account of how the plea in mitigation had
been presented to the sheriff. The Crown narrative was agreed. The appellant's account of having been trafficked,
as it appeared in the CJSWR, was referred to but it was not put forward as a significant strand in mitigation. The
defence agent specifically accepted that the appellant's position fell short of the defence of coercion. Now, as was
explained in Van Phan, that did not prevent a plea in mitigation of sentence being presented on the basis that, in
the context of being a victim of trafficking, the appellant had been compelled (by means falling short of coercion) to
be concerned in the supply of cannabis at a specified address in Aberdeen and elsewhere between 19 June and 3
July 2018 and to produce cannabis at the same address between the same dates. That does not appear to have
been done.

[23]     Mr Findlater suggested that it was enough for the defence agent to refer to the CJSWR where what had
been said by the appellant to the author of the report was set out. We disagree. The account given to the author of
the report does indeed include the assertion by the appellant that he was a victim of trafficking. However, as the
sheriff and the defence agent were aware, that was controversial. The Crown did not accept that proposition in that,
in light of the Lord Advocate's instructions issued in terms of section 8 of the 2015 Act, the decision had been taken
to prosecute the appellant. Moreover, the agreed narrative included the information that a reasonable grounds
decision, as provided for by section 9 of the 2015 Act had been made by the competent authority in respect of the
appellant on 2 August 2018, finding that there were not reasonable grounds to believe that he was victim of human
trafficking. Now, the appellant and his legal representative were not bound to accept the views of the Crown and the
competent authority, but if the sheriff was expected to ignore these views they had to lay before her a basis which
would allow her to do so. That might have been done through the medium of a proof in mitigation or it might have
been done through the medium of a sufficiently detailed, specific and therefore compelling plea. Neither course was
followed. Rather, the defence agent chose to rely on the account that the appellant had given to the author of the
CJSWR. That account was vague, lacking circumstantial detail and raised more questions than it answered.
According to the appellant he had been abducted while working in China and brought overland to France, by way of
Russia, before being taken to the United Kingdom. However, as appeared from other information in the CJSWR
(not provided by the appellant), the accuracy of which Mr Findlater accepted, in circumstances which were not
explained, the appellant was able to escape from his traffickers to the extent of having made an application for
asylum on 2 September 2010. Initially having been placed in detention, he was released on 7 September 2010 and
provided with accommodation but he absconded the following day. His asylum claim was refused for noncompliance on 15 September 2010 and he therefore became liable to removal from the United Kingdom, but he
appears to have avoided any contact with the authorities until his arrest on 3 July 2018. He claims in that period to
have kept against his will in several locations and forced to look after cannabis by “the gang” but that is more or less
all the detail he provided in relation to a period of just less than 8 years. He did not explain how he separated
himself from his traffickers in September 2010 or why, having done so, he absconded from the accommodation with
which he was provided (in Birmingham, according to information provided by the appellant during the hearing
before this court). He did not explain in what circumstances he then became involved with “the gang”. He did not
explain how his account of being kept against his will squared with the freedom of movement indicated by him
having been identified on CCTV footage purchasing a railway ticket in Manchester on 1 July 2018, travelling to
Aberdeen and then walking through Aberdeen before approaching the address referred to in the charges to which
he pled guilty, where he was seen speaking on a mobile phone before entering. Critically, the account recorded in
the CJSWR contained nothing specifically to support the proposition that he had been compelled to commit the
particular offences which were the subject of the instant charges, namely being concerned in the supplying of
cannabis and producing cannabis at a particular address in Aberdeen over a particular period in June and July
2018. Lest there be any doubt, we make no criticism whatsoever of the author of the CJSWR for the sketchy nature
of the appellant's history. It was no doubt sufficient for her purposes. It was not her responsibility to present a plea
in mitigation. That was the responsibility of the defence agent. If it was his intention to make something of the
appellant being a victim of human trafficking and in particular of the appellant having been compelled or at least
pressured to commit the offences to which he had pled guilty, then he should have obtained the instructions from
the appellant in order to allow him to do so. For whatever reason, he chose not to do that.

[24]     In conclusion, the short answer to the criticism that the sheriff failed to have regard to material, the content
of which was sufficient to sound materially in mitigation so as to bring the sentence below what would ordinarily be


-----

the appropriate range, is that there was no such material put before her. We do not consider that the sheriff's
approach to the information which was put before her has resulted in the imposition of a sentence which was
excessive in the circumstances; indeed the sentence imposed might be regarded as lenient. The appeal must be
refused.

**End of Document**


-----

