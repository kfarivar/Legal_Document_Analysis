# R (on the application of SW) v Secretary of State for the Home Department

 [2018] EWHC 2684 (Admin)

Queen's Bench Division (Administrative Court)

John Cavanagh QC (sitting as a Deputy judge of the High Court)

16 October 2018Judgment

**Ronan Toal and Raggi Kotak (instructed by Duncan Lewis) for the Claimant**

**Zane Malik (instructed by Government Legal Department) for the Defendant**

Hearing date: 2 October 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**By order dated 25 October 2017, the Claimant has been granted anonymity and no report of this**
**case shall directly or indirectly identify the Claimant.**

**John Cavanagh QC, sitting as a Deputy High Court Judge:**

**Introduction**

1. In this application for judicial review, the Claimant seeks a declaration that her detention under
Immigration Act powers during the period from 19 September 2017 until her release on 13 October 2017
was unlawful, and she seeks damages for false imprisonment.

2. The Claimant is a national of Namibia, and was born on 17 June 1978. She entered the United
Kingdom on 21 July 2017, and was given leave to enter as a visitor until 21 January 2018. The conditions
of entry required that the Claimant did not work whilst she was in the United Kingdom. On 19 September
2017, the Claimant was arrested in Portsmouth and admitted that she had been working as a carer, in
breach of the conditions of entry. She was taken into detention and was served with a Notice of Removal.

3. The Claimant's medical records show that, whilst she was examined by a nurse within 24 hours of being
taken into detention, she was not seen by a doctor during this period.  The records contain notes that were
made by a doctor, Dr Oozeerally, on 24 September 2017, but, as I will explain later in this judgment, there
is some dispute as to whether Dr Oozeerally met with the Claimant or simply made the notes after
reviewing the medical file.

4. On 27 September 2017, the day on which she was served with notice that she was to be removed on 3
October 2017, the Claimant claimed asylum, saying that she feared returning to Namibia.  In a written
Statement of Additional Grounds, made under section 120 of the Nationality, Immigration and Asylum Act
2002, she said that she had been sold into slavery/domestic work because of her ethnicity, and that she
feared that she would be killed on return or forced back into slavery. She also said that she wanted a
trafficking referral. A trafficking referral may be made by a First Responder (which includes the Defendant)
to the Competent Authority under the National Referral Mechanism ('NRM') to determine whether a person
has been a victim of trafficking. No trafficking referral was made to the Competent Authority by the


-----

Defendant at that stage. This was because, notwithstanding the assertion made by the Claimant, it was
not considered that she was a potential victim of trafficking. An immigration officer took the view that the
application was late and opportunistic and that it had the hallmarks of an abusive claim.

5. On 2 October 2017, an immigration officer completed an 'initial contact and asylum registration form',
following the asylum screening interview with the Claimant.  The form recorded the Claimant's answer
when she was asked to explain briefly all the reasons why she could not return to her home country.  The
answer was recorded as follows:

“There are some women who take me from my mother and then take me to their homes. They make me
work and take me to small school.  They were violent to me and aggressive. I can't remember when it
started. Someone broke my arm with a stick.”

6. On 10 October 2017, the Claimant was examined by a Home Office doctor, Dr Mahmood. Dr Mahmood
produced a Rule 35 report in which he stated that the Claimant had given him an account of a history of
domestic servitude in Namibia. The Claimant had informed him that she had been taken away from her
family as a small child and forced to work for another family, whose members routinely beat and verbally
abused her, and whose male members raped her and forced her to have sex with other men. The
Claimant informed the doctor that she had travelled to the UK to escape the treatment that she had
endured.  The Claimant has three children in Namibia.  Dr Mahmood noted that the Claimant had several
scars on her right arm.

7. Dr Mahmood's assessment stated that the Claimant's story was coherent and that she had been able to
answer any questions to fill in missing blanks. Dr Mahmood said that the Claimant had stated that her
detention reminded her of being forcefully held like she was in Namibia. He concluded that that, given the
extent of the Claimant's torture, she was not fit for detention and was certainly at risk of worsening should
her detention continue.

8. On 12 October 2017, the Defendant wrote to the Claimant to inform her that her claim of ill treatment
had been considered in line with the guidance set out in the Detention Services Order 9/2016 and the
'Adult at Risk Policy', and that she was regarded under the Policy as an Adult at Risk – Level 2.  The
Defendant informed the Claimant that, as a result, a decision had been taken to release her from detention,
and the Claimant was duly released into hostel accommodation on 13 October 2017.

9. On 29 November 2017, the Claimant was referred by the Salvation Army to the Competent Authority for
determination of her trafficking claim. On 20 December 2017, the Defendant, acting as Competent
Authority, decided that there were reasonable grounds to believe that the Claimant was a victim of
trafficking.  The Claimant has yet to be assessed for the next and final stage of the NRM process, the
'conclusive grounds' decision.  At that stage, the Competent Authority will reach a decision as to whether
there are conclusive grounds that the Claimant is a victim of trafficking.

10. Proceedings for judicial review were issued on 25 October 2017, just under two weeks after the
Claimant had been released from detention. On 27 November 2017, Mrs Justice Lang DBE granted
permission to apply for judicial review. The original Grounds included a challenge to the Defendant's
decision not to refer the Claimant to the Competent Authority, but this was rendered otiose by the referral
in December 2017.  The remaining issue in the proceedings is a challenge to the lawfulness of the
Claimant's detention. The Claimant was granted leave to file Amended Grounds, which are dated 29 June
2018.

11. The Claimant challenges the lawfulness of her detention on three separate grounds. These are:

i) There was no statutory power to detain her;

ii) The Claimant's detention was unlawful because rule 34 of the Detention Centre Rules was breached as
the Claimant was not examined by a doctor within the first 24 hours of her detention (and, indeed, the
Claimant contends that no such examination took place until she was seen by Dr Mahmood on 10 October
2017); and/or


-----

iii) The Defendant, in her capacity as First Responder, had acted unlawfully in failing to refer the Claimant
to the Competent Authority, on or about 27 September 2017, as soon as the Claimant claimed that she had
been trafficked.

12. I will first explain my decision to permit the full hearing of this claim to proceed by way of an application
for judicial review, even though, as the only substantial issue remaining is whether the Claimant should
recover damages for unlawful detention, the claim is of a type that would ordinarily have been dealt with in
the Queen's Bench Division or the County Court, not the Administrative Court. I will then deal in turn with
each of the three grounds relied upon by the Claimant.

13. The Claimant has been represented by Mr Ronan Toal and Ms Raggi Kotak, and the Defendant has
been represented by Mr Zane Malik. I am grateful to them all for their clear and helpful submissions.

**Venue**

14. This claim concerns the legality of the Claimant's detention. The Claimant had already been released
from detention before her claim commenced. At the point at which the proceedings began, the Claimant
also had an additional ground of challenge, relating to the decision not to refer her to the Competent
Authority, but this had fallen away by December 2017.

15. It follows that, since December 2017, this has essentially been a claim for damages. It is true that the
Claimant seeks a declaration as well as damages in respect of unlawful detention, but the claim for a
declaration does not add anything of substance to the claim.

16. There is no doubt that, in the ordinary course of events, claims such as this should be pursued in the
Queen's Bench Division or the County Court. This has been made clear on many occasions, for example
in Swaran v Secretary of State for the Home Department [2014] EWHC 1062 (Admin), per Dingemans J, at
paragraphs 30-33, R (DK) v Secretary of State for the Home Department [2014] EWHC 3257 (Admin), per
Haddon-Cave J, at paragraph 4, and R (SS) v Secretary of State for the Home Department [2015] EWCA
_Civ 652, at paragraph 11. It has been stressed that the Queen's Bench Division and the County Court are_
better suited than the Administrative Court to deal with contested issued of fact about historic events, and
that it would be wrong to clog up the Administrative Court with damages claims.

17. Nevertheless, I have taken the view that it was appropriate for this matter to proceed to a full hearing
by way of judicial review. As the relief sought includes a declaration and so is not limited solely to
damages, the Administrative Court has jurisdiction to deal with the matter (see CPR 54.3(2), which
provides that a claim for judicial review may include a claim for damages, but may not seek such a remedy
alone). The Defendant has not applied for a transfer to the Queen's Bench Division or County Court, and
does not object to the case being dealt with by way of judicial review. Indeed, directions were given, by
consent, for this to happen some months after the other issue fell away.  Though there is one contested
issue of fact, namely whether the Claimant was seen by Dr Oozeerally, and, if so, how thorough the
examination was, there has been no application for oral evidence or for cross-examination.  The main
issues that fall to be determined are issues of law.  The case has been listed for some time and the parties
attended the full hearing on 2 October 2018, ready to argue the case. In those circumstances, it would not
have been in accordance with the overriding objective for the matter to be transferred to another
jurisdiction at this stage, given the delays and additional expense that would inevitably have resulted.

**Ground 1: Did the Defendant have a statutory power to detain the Claimant?**

18. Mr Toal's argument, in broad summary, is that, at the point at which she was detained, the Claimant
had leave to enter the UK. Such leave can only be curtailed if the individual is given written notice of a
curtailment decision and, he says, the Notice of Removal that was handed to the Claimant as she was
being detained on 19 September 2017 did not contain such written notice of curtailment.  He submits that
the Defendant's statutory power to detain a person who is in breach of conditions applies only after notice
of curtailment has been given. The Defendant does not have power to do so merely because the
Defendant is aware that there are circumstances which mean that it is likely that leave will be curtailed and
the individual will be removed. Curtailment must already have taken place.


-----

19. Mr Malik, for the Defendant, accepts that a breach of conditions attached to leave to enter does not
automatically mean that leave is curtailed. Leave is only curtailed, following a breach, when a decision to
curtail is taken and the individual is then served with notice of curtailment. However, he submits that the
document headed 'Notice of Removal' that was served on the Claimant on 19 September 2017 contained
sufficient notice of curtailment and so that the Claimant's leave was curtailed before she was taken into
detention.  In the alternative, he submits that, in any event, the statutory framework permits the Defendant
to take a person into detention before leave is curtailed, if there are reasonable grounds for suspecting
removal directions may be given in the future as a result of the breach of conditions. Mr Malik described
this alternative argument as his 'primary argument'. In the further alternative, Mr Malik submits that, even if
there was no lawful power to detain the Claimant, it is highly likely that the outcome for the Claimant would
not have been substantially different if there had been no breach of the law, and so, applying section
31(2A) of the Senior Courts Act 1981, the Claimant is not entitled to any relief. He also submits that, in any
event, if there was a breach of public law, the Claimant is not entitled to any damages as she would have
been detained in any event.

20. Against that background, the issues that I have to decide in relation to the first Ground may be divided
into four parts:

i) Was the Claimant given written notice of the curtailment decision on 19 September 2017?;

ii) If not, was detention nonetheless lawful, because the Defendant has a statutory power to take into
detention persons whose leave has not yet been curtailed if there are reasonable grounds for suspecting
that leave will be curtailed and removal directions will be given?;

iii) If the Defendant acted in breach of the law in detaining the Claimant, should no relief be given,
pursuant to section 31(2A) of the Senior Courts Act 1981, because the result would not have been
substantially different, if the breach had not taken place?; and/or

iv) Should the Claimant receive only nominal damages because she would have been detained in any
event?

_The obligation to serve written notice of curtailment of leave to enter or remain_

21. Where a person is found to be working in breach of a restriction or prohibition on employment as set
out in the conditions of their leave to enter or remain in the UK, their leave may be curtailed with immediate
effect under paragraphs 323(i) and 322(3) of the Immigration Rules, such that they become liable to
administrative removal under section 10 of the Immigration and Asylum Act 1999 ('the 1999 Act).  The
relevant parts of section 10 are set out at paras 41-43, below.

22. Section 4(1) of the Immigration Act 1971 ('the 1971 Act') provides, in relevant part:

“(1) The power under this Act to give or refuse leave to enter the United Kingdom shall be exercised by
immigration officers, and the power to give leave to remain in the United Kingdom, or to vary any leave
under s3(3)(a) (whether as regards duration or conditions)… shall be exercised by the Secretary of State;
and…. those powers shall be exercised by notice in writing given to the person affected….”

23. Curtailment of leave to enter or remain is a variation as regards duration, and so the power to curtail is
exercised under s3(3)(a) of the 1971 Act.

24. It is common ground between the parties that, as a result of s4(1), curtailment of leave to remain takes
effect only once the person concerned has been given written notice of curtailment.  The fact that a person
has acted in breach of the conditions attached to leave to enter does not automatically mean that his or her
leave to enter will be curtailed.  The Defendant has a discretion to decide not to curtail leave,
notwithstanding the breach, and so curtailment will only take place once (a) the Defendant has taken a
decision that leave will be curtailed, and (b) that decision has been communicated in writing to the person
concerned.


-----

25. Further provision is made for the requirement that variation of a person's leave to enter or remain in
the UK is to be made by notice in writing by regulation 8ZA(1)(c) of the Immigration (Leave to Enter or
[Remain) Order 2000 (SI 2000/1161).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-24D0-TX08-H12B-00000-00&context=1519360)

26. It follows that the first question is whether the Notice of Removal that was served on the Claimant on
19 September 2017 contained notice in writing of the curtailment of her leave to enter and remain in the
UK.

27. It is worth noting in passing, however, that the position was different under the 1999 Act, prior to its
amendment on 19 October 2014 (by the _[Immigration Act 2014, section 1). The previous version of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C12B-00000-00&context=1519360)_
1999 Act, section 10, stated as follows, at sub-sections 10(1) and 10(8):

“(1) A person who is not a British citizen may be removed from the United Kingdom, in accordance with
direction given by an immigration officer, if –

(a) Having only a limited leave to enter or remain, he does not observe a condition attached to the leave or
remains beyond the time limited by the leave; ….”

“(8) When a person is notified that a decision has been made to remove him in accordance with this
section, the notification invalidates any leave to enter or remain in the United Kingdom previously given to
him.”

28. Accordingly, under the previous version of section 10 of the 1999 Act, where a person was in breach
of a condition for leave to enter or remain, there was no requirement that notice be served, in order for the
leave to be curtailed.  A removal notice would, of itself, curtail the leave, even if the person had not been
notified specifically that the leave was curtailed. The position is different in the version of s10 that was in
force at the relevant time.  Counsel were unable to help with why this should be so. Mr Malik explained
that the main reason for the amendments that were introduced into the 1999 Act by the _[Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
_[2014 was to remove the in-country right of appeal in certain circumstances, but he did not know why this](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
should have led to a change in the position so that written notice of curtailment is now necessary before
curtailment could take effect. In these circumstances, I do not think that I can derive any guidance for the
task of interpreting the current version of section 10 from the fact that the section has only relatively
recently been amended in a key respect.

_Was the Claimant given written notice of the curtailment decision on 19 September 2017?_

29. When the Claimant arrived in the UK on 21 July 2017, her passport was stamped, 'Leave to enter for
six months: employment and recourse to public funds prohibited.'  As I have said, it is not in dispute that
the Claimant worked as a carer in breach of this requirement of her leave to enter and remain.

30. At the time of the Claimant's arrest, on 19 September 2017, she was served, by hand, with a
document entitled 'NOTICE OF IMMIGRATION DECISION: NOTICE OF REMOVAL'.  The document was
addressed to the Claimant.  It stated, in relevant part:

“You are a person with no leave to enter or remain in the United Kingdom (UK). You have not given any
reasons as to why you should be granted leave to remain or why you should not require leave to remain.
Therefore, you are liable to removal.

**REASONS FOR DECISION**

The following reasons are given:

On 21/07/2017 you were granted leave to enter the United Kingdom as a visitor for six months [until]
21/01/2018 on condition that you do not access public funds and that employment is prohibited.

You are specifically considered a person who has failed to observe a condition to leave to enter as you
have admitted to an Immigration Officer that you have been working as a carer for the agency 'Together
We Care' and that you have left that agency to work for 'Star Agency'. You have admitted that the carer
uniform found in a wardrobe belongs to you and that you will be working for £8 per hour.

**LIABILITY FOR REMOVAL**


-----

Persons who require, but no longer have leave to enter or remain are liable for removal from the United
[Kingdom under s10 of the [1999] Act] (as amended by the Immigration Act 2014).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)

If you do not leave the United Kingdom as required you will be liable to enforced removal to Namibia.”

31. Mr Toal, for the Claimant, submits that this document did not amount to a written notice of curtailment
of the Claimant's leave to enter and remain. It did not tell her that her leave had been curtailed. Rather, it
was simply a Notice of Removal. Mr Malik, on the other hand, whilst acknowledging that the document
does not state, in words of one syllable, so to speak, that the Claimant's leave to enter and remain had
been curtailed, submits that it was nonetheless sufficiently clear on the face of the document that this is
what had been done, so that the Notice of Removal also operated as a notice of curtailment.

32. In my judgment, Mr Toal is right: the Notice of Removal did not amount to a written notice of
curtailment of leave. I set out my reasons for this conclusion in the following paragraphs.

33. First, it is important that notification of curtailment of leave to enter or remain is clear and
unambiguous. Many of the individuals who will be served with such a notice will have a weak grasp of
English. They will often be stressed, because they have just been apprehended by immigration officers.
Moreover, the curtailment of leave to enter and remain is a serious step, and may well have serious
consequences for the individual concerned. I think, therefore, that it is in keeping with the spirit and
purpose of the statutory requirement of notice, laid down in s4 of the 1971 Act, that the notice must make
clear that leave has been curtailed.

34. Second, the language used in the Notice of Removal of 19 September 2017 does not make sufficiently
clear that the Claimant's leave has been curtailed. It is clear that, to an informed reader, it would be
apparent from the text of the Notice that this is indeed what has happened.  Given that, up until 19
September 2017, the Claimant had leave to enter or remain in the UK, the sentence that states, 'You are a
person with no leave to enter or remain in the United Kingdom' carries with it the necessary implication
that the Claimant's leave must have been withdrawn. Similarly, the statement that persons who require but
no longer have leave to enter and remain are liable for removal, coupled with the fact that the Notice
makes clear that the Claimant is now liable for removal, indicates by implication that any leave to enter or
remain that the Claimant once had is now curtailed and withdrawn. However, I do not think that it is good
enough, for the purposes of the duty to notify set out in s4(1) of the 1971 Act, that the reader might be able
to work out by inference from the terms of the document with which s/he has been served that the leave to
enter and remain has been curtailed.  The decision to curtail is such an important step that it must be
communicated expressly, not left to be inferred by implication, especially when, as I have said, the reader
is likely to be stressed and may well not have a strong grasp of English.

35. Third, whilst the Notice makes clear that the Claimant is to be removed, and the Notice was
accompanied by another document which notified the Claimant that she was to be detained because her
removal from the UK was imminent, this is not the same as giving notice that the leave to enter and remain
had been curtailed. There is a difference between taking a decision to curtail leave, on the one hand, and
taking decisions to detain or to remove a person, on the other.  They are different decisions. There are, of
course, circumstances in which a person whose leave to enter and remain has been curtailed may
nonetheless not be removed.  The obvious example is if s/he makes a successful claim for asylum. Again,
it may be that a person's leave has been curtailed and s/he is awaiting removal and yet the person is not
detained. It follows that to notify a person that she is being detained, or is to be removed, is different from
notification that the person's leave to enter or remain has been curtailed.  The Notice of Removal in the
present case assumed that the Claimant's leave had been withdrawn, but it did not itself communicate to
her the decision to curtail the leave.

36. The Home Office has published Guidance for immigration officers in relation to administrative removal
from the UK for persons who have breached their conditions of entry (or who have obtained entry by
deception, or who have overstayed).  This Guidance is entitled, 'Liability to administrative removal (nonEEA): consideration and notification', and is dated 6 April 2017.  The Guidance contains a section
concerning curtailment or revocation of leave by service of a document entitled RED.0001. So far as it is
possible to tell I think that the Notice of Removal document that was served on the Claimant on 19


-----

September 2017 was in form RED.0001. Although the acronym 'RED.0001' does not appear on the face of
the document, the case notes (GCID Case Record Sheet) prepared by the immigration officer who was
responsible for the Claimant's case on 19 September 2017 say that the Claimant was served with a
RED.0001, and it is clear from the context that the officer was referring to the Notice of Removal document.

37. The Guidance states as follows about the notice that should be given in a form RED.0001:

“Bringing leave to an end via RED.0001

You must include clear evidence and reasoning for your decision and cite the appropriate legal basis for
curtailment”

38. The Guidance also provides sample wordings for curtailment decisions.  The sample wording consists
of three paragraphs, the first two of which were replicated in the 'REASONS FOR DECISION' section of
the Notice of Removal which was served on the Claimant on 19 September 2017.  However, the Guidance
also recommends that a third paragraph is included in form RED.0001, in the following terms:

“It is not considered that the circumstances in your case are such that the discretion should be exercised in
your favour. The Secretary of State therefore curtails your leave **[to enter or remain in]** the United
Kingdom under paragraph 323(i) with reference to 322(3) of the Immigration Rules so as to expire with
immediate effect.”

39. The Notice of Removal did not cite the appropriate legal basis for curtailment, and no equivalent to this
third paragraph was included in the Notice of Removal in the Claimant's case. In my view, it would not
matter if a Notice of Removal/form RED.0001 used a different form of words from that set out in the
Guidance, provided that it was made clear to the person concerned that his or her leave was curtailed.
However, the fact that the Guidance provides a sample form of words which contains an express statement
that leave has been curtailed reinforces my conclusion that the absence of any such express statement in
the Notice of Removal in the present case means that no valid curtailment had taken place at the point at
which the Claimant was taken into detention.

40. I recognise that it might be said, against this conclusion, that this means that, subject to the next
issues to be dealt with, the Claimant's detention may have been rendered unlawful by reason of a mere
technicality, ie the omission of a few words from the Notice of Removal. However, for the reasons that I
have given, I think that the failure to make clear that leave was curtailed was more than a mere
technicality.

41. Accordingly, in my judgment, at the time when the Claimant was taken into detention, her leave to
enter and remain was still in place and had yet to be curtailed.

_Was detention nonetheless lawful, because the Defendant has a statutory power to take into detention_
_persons who have leave to enter if there are reasonable grounds for suspecting that leave will be curtailed and_
_removal directions will be given?_

42. The statutory power to detain persons pending removal for breach of conditions of entry is to be found
in section 10 of the 1999 Act.

43. Section 10(1) provides as follows:

“(1) A person may be removed from the United Kingdom under the authority of the Secretary of State or an
immigration officer if the person requires leave to enter or remain in the United Kingdom but does not have
it.”

44. Section 10(7) provides:

“(7) For the purposes of removing a person from the United Kingdom under subsection (1) or (2), the
Secretary of State or an immigration officer may give such directions for the removal of the person as may
be given under paragraphs 8 to 10 of Schedule 2 to the 1971 Act”

45. Section 10(9) provides, in relevant part:


-----

“The following paragraphs of Schedule 2 to the 1971 Act apply in relation to directions under subsection (7)
(and the persons subject to those directions) as they apply in relation to directions under paragraphs 8 to
10 of Schedule 2 (and the persons subject to those directions)….

(b) paragraph 16(2) to (4) (detention of person where reasonable grounds for suspecting removal
directions may be given or pending removal in pursuance of directions)”

46. The relevant paragraph in Schedule 2 to the 1971 Act is paragraph 16(2), which provides:

“If there are reasonable grounds for suspecting that a person is someone in respect of whom directions
may be given under any of paragraphs 8-10A or 12-14, that person may be detained under the authority of
an immigration officer pending:

(a) a decision whether or not to give such directions;

(b) his removal in pursuance of such directions.”

47. Directions under paragraphs 8-10A and 12-14 of Schedule 2 to the 1971 Act are directions in relation
to illegal entrants and those who were refused leave to enter, and also directions in relation to persons who
entered the UK as a member of a crew of a ship or aircraft and who have remained beyond the time they
were allowed to stay in the UK.

48. Mr Toal submits that the power to detain for the purposes of removal, set out in section 10(9) of the
1999 Act, only applies if the person's leave has already been curtailed. He says that a person cannot be
detained on the basis that the Secretary of State knows that there are grounds for curtailment and intends
to curtail leave to enter or remain within a short period, prior to removing the person from the UK.

49. Both Mr Toal and Mr Malik were agreed that the key provision is section 10(9) of the 1999 Act.  The
answer to the question whether a person can be detained for breach of conditions before notice of
curtailment has been served may well lie in the answer to the question whether such detention comes
within the scope of the words 'detention of person where reasonable grounds for suspecting removal
directions may be given'.

50. In my view, section 10(9), on its true construction, does not require that a notice of curtailment has
already been given, before detention can take place.  In the present case, at the point of which detention
took place, it was already clear that the Claimant had worked as a carer in breach of her leave conditions.
She had admitted this, and had signed the immigration officer's notebook to accept the truth of the officer's
record of her admission.  A work uniform had been found in her wardrobe which she had admitted
belonged to her. The GCID Case Record Sheet completed by the immigration officer on 19 September
2017 makes clear that the officer had been satisfied that the Claimant was in breach of conditions and had
gone on to consider whether it was appropriate to administratively remove the Claimant from the UK.  The
officer took account of the Claimant's immigration history, the fact that she was single with no family in the
UK, and had no health issues, and considered that, in those circumstances there was no prejudice that
would render it inappropriate to serve a Notice of Removal. Against those facts, in my judgment, it was
plain that there were, at that stage, reasonable grounds for suspecting that removal directions would be
given.  The fact that notice of curtailment had not yet been given does not detract from this conclusion: it is
clear from the GCID Case Record Sheet that the immigration officer had, prior to detention, decided that
leave should be curtailed and that the Claimant should be made subject to removal directions.  The
reasonable grounds existed, regardless of whether or not the notice of curtailment had yet been served.

51. Mr Toal submits that the words 'reasonable grounds' refer to circumstances in which all the
requirements for removal directions are already in place. In other words, he submits that the 'reasonable
grounds' cannot exist until the curtailment decision has been notified in writing to the Claimant, since the
curtailment is a precondition for removal directions to be made, and written notice is, in turn, a precondition
for curtailment to be made. I disagree.  The wording in section 10(9) must be read as whole.  The
question is whether there are 'reasonable grounds for suspecting removal directions may be given'. In my
judgment, the language of section 10(9) does not impose a requirement that everything must have already
been done to enable removal directions to be given before detention can take place.  The phrase 'may be


-----

given' indicates that the question is whether there are reasonable grounds for suspecting that removal
directions may be given at some point in the future, not that all necessary formal steps have already been
taken.

52. Mr Toal submits that the requirement of 'reasonable grounds' is just a safeguard, to protect an
immigration officer if it turns out that there is a fact of which the immigration officer could not reasonably
have been aware which would mean that removal could not take place. He gave the example of a case in
which the person in question failed to mention that s/he had dual British nationality. However, I think that
'reasonable grounds' goes further than this: if there are reasonable grounds to think that removal will take
place in the future, then the requirement is satisfied.

53. In my view, where, as here, a person has admitted breach of conditions, and the immigration officer
has investigated whether there are any reasons why removal should not take place and has concluded that
there are none, the requirement that there are reasonable grounds for suspecting that removal directions
may be given has been satisfied.  Section 10(9) does not in terms impose a pre-condition that curtailment
has already taken place, and there is no basis for implying that there is such a precondition.

54. Moreover, I think that this interpretation is consistent with the statutory framework and the spirit and
intendment of the legislation. Section 10(9), and paragraph 16(2) of Schedule 2 to the 1971 Act, which
applies to 'breach of condition' cases by operation of section 10(9), make clear that detention can take
place before removal directions are actually given. It must follow that there is no statutory requirement that
all of the steps that must be followed before removal directions can be given have actually been followed
before detention can take place.

55. Mr Toal reminds me that, as detention is an infringement on liberty, any statutory provision which
permits administrative detention should be interpreted strictly and restrictively. Mr Malik accepted that this
is the right approach and I agree. If authority is needed for it, it can be found (by analogy) in R (B (Algeria))
_v Special Immigration Appeals Commission (Bail for Immigration Detainees intervening) [2018] UKSC 5;_

[2018] AC 418, at paragraph 29, and the cases cited therein. However, I do not think that this principle of
construction assists Mr Toal in the present case. In my view, even applying a strict and restrictive
construction to section 10(9) of the 1999 Act, there is no scope for construing it to mean that there is no
power to detain in a case such as the present unless and until notice of curtailment of leave has been
given. A strict and restrictive interpretation does not require that additional limitations are imposed that are
not to be found in the statutory language.

56. Mr Malik points out that absurd consequences will follow if the narrow interpretation of section 10(9) of
the 1999 Act and paragraph 16(2) of Schedule 2 to the 1971 Act, advanced by Mr Toal, were to be
adopted.  If it were right, then the Secretary of State would not be able to detain a person who has limited
leave to remain but has failed to comply with conditions, or who obtained leave by deception, unless leave
had already been curtailed. This would mean that the Defendant would not be able to detain a person who
is obviously an immigration offender. I think that there is force in this argument. It may well be that, in
some cases, it would not be practicable to prepare and serve a notice of curtailment at the point when the
offender first comes to the attention of the Defendant.  As Mr Malik points out in his skeleton argument, a
person who is found working illegally in the UK in breach of his immigration conditions will have little
incentive to stay in touch with the Defendant if not detained immediately.

57. Mr Toal says that this problem can be averted, because the person can be arrested immediately and
held pursuant to the powers of an immigration offender to arrest without warrant a person who the officer
has reasonable grounds to suspect has committed an immigration offence (including the offence of
breaching a condition of leave): see the 1971 Act, ss 24 and 28A. I do not think that this is an answer to
the problem, for two reasons. First, the immigration offence is only committed if the person 'knowingly'
breaches a condition, whereas, the Defendant may wish to make use of the powers of detention and
removal upon an individual even if the person has unwittingly breached the conditions of leave. Second,
and in any event, I do not think that it would be appropriate to use the power of arrest in relation to an
immigration offence for a collateral purpose, namely in order to detain the person administratively pending
their removal.


-----

58. For these reasons, I reject the first of the Claimant's Grounds. In my judgment, it was not unlawful to
detain the Claimant because, at the time of the Claimant's detention, she had not been served with written
notice of curtailment of her leave to enter and remain.

_[Should I decline to grant relief on this Ground because of section 31(2A) of the Senior Courts Act 1981?](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y172-00000-00&context=1519360)_

59. Given my conclusion on this Ground, this issue does not arise, and so I will deal with it very briefly.
Section 31(2A) of the Senior Courts Act 1981 provides that the Court must not grant relief on an application
for judicial review, and may not make an award of damages 'if it appears to the Court to be highly likely that
the outcome for the applicant would not have been substantially different if the conduct complained of had
not occurred.'

60. If I had reached a contrary conclusion, and had taken the view that the Claimant's detention was
unlawful because of the failure to serve written notice of curtailment, I would not have accepted the
submission that this is an appropriate case to decline to grant relief.  This is not like a case in which a
public authority, which has a statutory power to take a particular decision, has failed to take a relevant
consideration into account when reaching the decision, but where it is clear that the decision would have
been the same even if the consideration had been taken into account. Rather, this is a case in which it
was alleged that the Claimant was detained unlawfully, in circumstances in which there was no statutory
power to detain her. If I had accepted the Claimant's argument on this Ground, I would not have been
prepared to decline to grant relief on the basis that the Defendant could have detained her on 19
September 2017, if it had acted lawfully.

_If this Ground had succeeded, would it be appropriate to award only nominal damages?_

61. Once again, this does not arise, as the Claimant's first Ground has not succeeded, and so I will deal
with the point very briefly. Mr Malik submits that, even if there was a breach of public law, then, applying
the guidance in Lumba v Secretary of State for the Home Department [2012] UKSC 12; [2012] 1 AC 245,
at paragraph 95, the Claimant is not entitled to any damages as she would have been detained in any
event.

62. If this issue arose, I would not have accepted that only nominal damages should be awarded. In
_Lumba,_ the Supreme Court was dealing with a case in which the Defendant had a statutory power to
detain but had unlawfully fettered its discretion by applying a blanket policy which took no account of
individual circumstances.  At paragraph 95 of the judgment, Lord Dyson JSC said that only nominal
damages should be awarded, because even if a lawful policy had been applied, it was inevitable that the
Claimants in that case would still have been detained. In my view, the present case is different because, if
the Claimant's argument on Ground 1 had been accepted, there would have been no valid legal basis for
detention in the first place.  If the Claimant's argument were accepted, then detention prior to written notice
of curtailment would have been outside the statutory powers of the Defendant.  It is different from a case,
like Lumba in which there was a statutory power to detain but the discretion had been exercised in breach
of the law. If the Defendant had acted unlawfully by detaining someone when there was no power to do
so, it cannot be a good reason to decline to grant more than nominal damages to point out that, if the
Defendant had acted differently, she could have found a lawful way in which to detain the Claimant.

**Ground 2: Was the Defendant's detention unlawful because rule 34 of the Detention Centre Rules**
**was breached?**

_Failure to comply with Rule 34 renders subsequent detention unlawful_

[63. Rule 34(1) of the Detention Centre Rules (SI 2001/238) provides as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-S3R0-TX08-H0XH-00000-00&context=1519360)

“ Every detained person shall be given a physical and mental examination by the medical practitioner....
within 24 hours of his admission to the detention centre.”

64. Rule 35 provides, in relevant part, that:


-----

“(1) The medical practitioner should report to the manager on the case of any detained person whose
health is likely to be injuriously affected by continued detention or any conditions of detention.

(2) The medical practitioner shall report to the manager on the case of any detained person he suspects of
having suicidal intentions....

(3) The medical practitioner shall report to the manager on the case of any detained person who is
concerned may be the victim of torture.

(4) The manager shall send a copy of any report under paragraphs (1), (2) or (3) to the Secretary of State
without delay.”

65. It is clear that 'medical practitioner', for this purpose, means a doctor.  Rule 34 cannot be complied
with by subjecting the detainee to an examination by a nurse, even if the examination is thorough and
professional and the nurse is highly experienced: see _R (DK) v Secretary of State for the Home_
_Department [2014] EWHC 3257 (Admin), at paragraph 189, per Haddon-Cave J, and R (ZA) v Secretary of_
_State for the Home Department [2018] EWHC 183 (Admin), at paragraph 43, per Michael Kent QC._

66. In part, the purpose of Rule 34 is simply to ensure that the medical needs of detained persons are
identified promptly, and are then dealt with appropriately. However, the purpose of the Rule goes further
than that.  A Rule 34 medical examination may have an impact upon the decision whether to continue the
detention of the individual concerned. The consequence of a Rule 35 report may be that a detained person
is released forthwith, or that special arrangements are made for care or treatment of the person detained.
For that reason, a failure to comply with Rule 34, without good cause, renders the subsequent detention
unlawful.

67. This was made clear by Burnett J in (R (EO) _v Secretary of State for the Home Department [2013]_
_EWHC 1236 (Admin). At paragraph 51, Burnett J said that failure to carry out or arrange a Rule 34_
examination would be a public law failing which bore upon and was relevant to the decision to detain. At
paragraph 53, Burnett J said:

“In light of the Secretary of State's acceptance of the materiality of Rule 34, the conclusion dictated by
_Lumba_ is that if an immigration detainee is not medically examined within 24 hours of his arrival at a
detention centre, his detention thereafter will be unlawful. This is not to say that there is scope for a
multiplicity of actions against the Secretary of State on this narrow ground. There is no reason to suppose
that Rule 34 medical examinations are not usually conducted within 24 hours. Because the legality of
detention is concerned with compliance with the Secretary of State's policy (and not with a direct breach of
the Rule) a good reason for non-compliance would save the legality of the detention.  The Rule 34
examination is, in the context of a decision to detain, but a stepping stone to a Rule 35 report. If no Rule
35 report were raised when a medical examination did take place (albeit late) then it would follow that the
decision to detain would have been the same.”

68. This statement of principle was endorsed and adopted by Haddon-Cave J in _R (DK) v Secretary of_
_State for the Home Department [2014] EWHC 3257 (Admin), at para 187._

_The point at which the duty to carry out a Rule 34 examination arose in the present case, and the period_
_between 19 and 24 September 2017_

69. Rule 34 refers to a duty to conduct a medical examination within 24 hours of arrival at a detention
centre.  There was some disagreement at the hearing as regards when this 24 hour period started to run
from. The Claimant was arrested in Portsmouth at about 7.00 am on the morning of 19 September 2017.
The medical records for the Claimant show that she was examined by a nurse at Heathrow Immigration
Removal Centre in the early hours of the next morning, 20 September. She was then moved to Yarl's
Wood Immigration Removal Centre on 23 September, and there is a note on the file from Dr Oozeerally the
following morning 24 September.  I will deal in a moment with whether this was a note of an examination
or a review of the paper file.

70. Mr Malik submits that the 24 hours ran from the Claimant's admission to Yarl's Wood, as Yarl's Wood
th d t ti t f R l 34 I bl t t thi b i i I h l k d t


-----

the Detention Centre Rules 2001, and at the 1999 Act, under which the Detention Centre Rules were
made, to see if there is a definition of 'detention centre'. I cannot find one. However, Part VIII of the 1999
Act is headed 'Detention Centres and Detained Persons', and Part VIII begins with an interpretation
section, at section 147. Though section 147 does not contain a definition of the phrase 'detention centre'
itself, it contains a definition of two types of facility, 'short-term holding facility' and 'removal centre'.  A
short-term holding facility is a place where detained persons can be held for up to seven days, and a
removal centre is a place that is used solely to hold detained persons and which does so for periods longer
than seven days. I infer from this that the phrase 'detention centre' covers both short-term holding facilities
and removal centres and, therefore, that the reference to 'detention centre' in Rule 34 covers all types of
places that are used to hold detained persons, including both of the types referred to in s147.

71. It follows from this, in my view, that time starts to run for the Rule 34 obligation from the moment that a
person who has been taken into detention is removed to a location where detainees are kept. In the
present case, therefore, time started to run from the point at which the Claimant arrived at Heathrow
Immigration Removal Centre, not from when she arrived at Yarl's Wood, some days later. In any event, as
both Heathrow and Yarl's Wood are long-term detention centres (removal centres), I cannot think of any
reason why time should not start to run until 23 September 2017, when the Claimant arrived at a second
removal centre.

72. It follows in turn that, as the Defendant does not contend that the Claimant was examined by a doctor
until 24 September 2017, there was, even on the Defendant's case, a four-day delay and the Claimant's
detention during this four-day period was therefore unlawful.  The Defendant has not suggested that there
was a good reason for non-compliance.

73. The Claimant's case, of course, goes further. The Claimant contends that there was no valid Rule 34
examination until she was seen by Dr Mahmood on 10 October 2017, which led to the making of a Rule 35
Report and to her release on 13 October 2017. The Claimant therefore contends that her detention was
unlawful throughout the period from her first detention (or, more accurately, 24 hours after her first
detention) until her release from detention on 13 October.

_The factual dispute: preliminary observations_

74. The key factual question in relation to this part of the Claimant's claim is whether she underwent a
Rule 34 compliant examination by Dr Oozeerally on 24 September 2017. The Defendant says that she did.
Counsel for the Claimant contends that she did not. Either she did not undergo a physical and mental
examination at all on 24 September or, if she did, it was so cursory that it did not comply with Rule 34. The
Claimant submits that if there had been a proper Rule 34 examination on 24 September, it would inevitably
have come to light that the Claimant complained of torture and had scars on her arm that were consistent
with torture. The fact that the record made by Dr Oozeerally does not mention these matters shows, says
the Claimant, that whatever happened on 24 September, it cannot have amounted to a Rule 34
examination.

75. It is unfortunate, in this regard, that there is no evidence of what did or did not happen on 24
September, beyond the brief note in the Claimant's medical record. There is no witness statement from Dr
Oozeerally and, though the Claimant has filed two witness statements, she has not made any reference to
what did or did not happen on 24 September. This is, perhaps, a good illustration of why it is better for
these cases to be dealt with in the Queen's Bench Division or the County Court, where witness evidence is
habitually heard, rather than in the Administrative Court. Nevertheless, I must do my best to make findings
of fact on the basis of the limited information before me. In so doing, I bear in mind that the burden of proof
to justify the lawfulness of a person's detention rests with the Defendant: see Lumba, para 44.

_Findings of fact_

76. My findings of fact are based primarily on the contemporaneous medical records (the 'Patient Record')
compiled by medical staff employed by the Defendant, and upon inferences that I can draw from the
contents of these records.


-----

77. The Claimant was seen by a nurse, Mr Mubanguka, at Heathrow Removals Centre on 20 September
2017. As I have said, this does not count as a Rule 34 examination, because such an examination must
be conducted by a doctor. Nonetheless, the records suggest that the examination was thorough and that
the Claimant was asked a large number of (no doubt standard-form) questions, the answers to which are
recorded on the medical records. The notes show that the Claimant did not suggest that she had any
current health problems, and there is no suggestion that she made any reference to being tortured or illtreated. Indeed, she is recorded as having said that she had not received any physical injuries recently.

78. The Claimant was seen again, by another nurse, Ms Tazvivinga, on 23 September, upon her
admission to Yarl's Wood. It is clear that the Claimant was asked a large number of questions. The note
records, 'No Otijoherero interpreter when contacted Language Line, however, speaks fairly good English.'
Significantly, the note of this interview/examination records contains the following words, 'Victim of torture –
booked rule 35'.  The note also states, 'booked GP review next available 24th Sept.'  In addition, the note
says, 'Has not received any physical injuries recently – a few months ago alleged she was beaten by a
member of the family she was living with and fractured right arm, went to hospital, had a plaster put on that
came off after one month.'

79. The next entry on the medical notes is the entry made by Dr Oozeerally on 24 September. This note
is short. It states, in its entirety:

“History: NEW ARRIVAL

Speaks English.

Would like Otijherero interpreter

No medicine

No medical issues

Plan: adv if healthcare required to seek healthcare, which she understands”

80. Mr Toal submitted, somewhat tentatively, that I should conclude that Dr Oozeerally did not see the
Claimant at all on 24 September, but merely reviewed the file. I find that he did indeed meet the Claimant
face to face. I think that the reference to her speaking English and wanting an interpreter indicates that he
had a conversation with her. The last few lines of the note appear to be his record of her answers to his
questions and the words 'which she understands' are something that the doctor could only have said if he
had actually spoken to the Claimant. I have very limited information on which to base a conclusion as to
whether Dr Oozeerally examined the Claimant bodily, or just spoke to her. I conclude, however, that he
just spoke to her and did not undertake a full medical examination. If he had done so, he would surely have
noted the scars that Dr Mahmood noted a couple of weeks later.

81. Again, doing the best I can on the basis of the very limited evidence before me, I conclude that Dr
Oozeerally was not tasked with conducting a detailed medical examination of the Claimant. It appears
from Nurse Tazvivinga's notes that she arranged separately for two things to happen after she had seen
the Claimant: (1) a 'GP review' and (2) a 'rule 35', which I take to mean a more thorough examination at
which a doctor would decide whether or not to issue a Rule 35 report.  I find that this was arranged to be
the examination by Dr Mahmood which took place on 10 October.

82. I also find that, when he met the Claimant, Dr Oozeerally would have had available to him the notes
made by Nurse Tazvivinga when she met the Claimant the previous day.  The file does not state when the
notes were added on but I conclude on the balance of probabilities that he did see (or at least had the
opportunity to see) the Nurse's notes, because it looks like the notes were written on the computer whilst
she was interviewing the Claimant and because it would be extremely surprising if the notes were not
made available to a doctor who conducted a 'GP review' of the Claimant's medical condition.

83. I find that the Claimant did not mention her allegation of torture, or her physical injuries, to Dr
Oozeerally. If she had done so, no doubt he would have recorded the fact.


-----

84. Accordingly, I find that the purpose of Dr Oozeerally's meeting with the Claimant was just to find out if
there were any immediate medical problems which he could help the Claimant with. It was not an
examination that was conducted with a view to identifying if the Claimant had suffered torture or there were
any other reasons for raising a Rule 35 report. No doubt if Dr Oozeerally had examined the Claimant on 24
September, with a view to considering whether he should write a Rule 35 report, he would have asked the
Claimant about the reference in the records to having told Nurse Tazvivinga that she was a victim of torture
and had recently suffered a broken arm, but there is no record that he raised these matters. Adopting the
language of Burnett J in EO, the examination by Dr Oozeerally on 24 September was not intended to be a
'stepping stone' to a Rule 35 report.

85. The next time that the Claimant saw a doctor was on 10 October 2017, when she saw Dr Mahmood.
He wrote a Rule 35 report. I have summarised the contents of the rule 35 report at paragraphs 6 and 7,
above. As a result of that report, the Claimant was released from detention on 13 October.

86. Mr Malik suggested that it was not just the Rule 35 report that led to the Claimant's release, but I
disagree. The note made on the GCID Case Record Sheet by the lead officer says, having read the Rule
35 report, that 'the doctor clearly finds not fit for detention and further detention likely to be injurious. R35
335 response is approved, release is appropriate.' This shows that the reason for release was the Rule 35
report. It is true that there were also difficulties in obtaining a Otjiherero interpreter for the Claimant but I
have no doubt that, even if such difficulties had not existed, the Claimant would have been released on 13
October as a result of the Rule 35 report.

_Conclusion on Ground 2_

87. In my judgment, the Defendant acted unlawfully in failing to arrange for a Rule 34 examination of the
Claimant until she saw Dr Mahmood on 10 October 2017. It is true that she had been seen by a doctor on
24 September, but in my judgment this did not count as a Rule 34 examination. As EO makes clear, the
reason that a Rule 34 examination matters for the purposes of the lawfulness of immigration detention is
that the examination is a 'stepping stone' to a Rule 35 report. In other words, the Rule 34 examination is
an opportunity for the detainee to be seen by a doctor who can identify if there are any reasons why the
doctor should issue a Rule 35 report which might, in turn, lead to the detainee's immediate release. In the
present case, Dr Oozeerally did not examine the Claimant on 24 September with a view to considering
whether he should issue a Rule 35 report. The purpose of his meeting with the Claimant was much more
limited. Although, in the vast majority of cases, no doubt, a consultation between a detainee and a doctor
will be sufficient for Rule 34 purposes, this is one of the rare cases in which a meeting with a doctor was
not sufficient for Rule 34.

88. In oral argument, Mr Malik suggested that even if there was a breach of Rule 34, the Claimant should
not receive any damages, because she would not have complained of torture to Dr Oozeerally if she had
been pressed on the issue. I do not agree. The Claimant had mentioned torture and her broken arm when
she was seen by the nurse the day before. She mentioned her broken arm in her asylum screening
interview on 2 October. When she had a thorough examination by Dr Mahmood on 10 October, she gave
a full and frank description of her circumstances. In my judgment, if a proper Rule 34 examination had
been conducted by Dr Oozeerally on 24 September 2017, the same information would have come to light
as came to light on 10 October 2017, and the Claimant would have been released within a couple of days.

89. In light of the above, I find that the Claimant's Ground 2 succeeds, and that the failure to give the
Claimant a Rule 34 medical examination until 10 October 2017 means that the whole of her detention,
save for the first 24 hours of it, was unlawful.

**Ground 3: Was the Claimant's detention after 27 September 2017 unlawful because the Defendant**
**had failed to act on her request for a trafficking referral?**

90. This is not, strictly, a challenge to the decision not to refer the Claimant's trafficking allegation to the
Competent Authority on or about 27 September 2017 (the date on which she was notified of her removal to
Namibia on 3 October 2017), when she wrote the words, 'I would also like a trafficking referral' on her
Statement of Additional Grounds Such a challenge would now be academic as a referral was


-----

subsequently made to the Competent Authority in November 2017. Rather, it is a challenge to the
Claimant's continuing detention after the referral should, she says, have been made. This is on the basis
that, if a referral to the Competent Authority had been made, the Claimant would have been released.

91. I think it is clear that the Claimant would indeed have been released more or less immediately if her
case had been referred to the Competent Authority on or about 27 September 2017. The Defendant's own
guidance, 'The Victims of Modern Slavery - Competent Authority Guidance', supplied to Home Office staff
on 21 March 2016, states that a person whose case is referred to the Competent Authority should normally
be released from detention if there are reasonable grounds to believe the person to be a victim of
trafficking, unless there are any public order reasons why the person must remain in detention. It is plain,
in my view, that, if the Claimant's case had been referred to the Competent Authority on or about 27
September 2017, she would have passed the 'reasonable grounds' test, because this is what happened
when her case was eventually referred in December 2017. .  No-one has suggested that any such reasons
exist in the Claimant's case. The Competent Authority Guidance states that the expectation is that a
reasonable grounds decision will be taken within 5 working days of the referral by a First Responder.

92. In R (CP Vietnam) v Secretary of State for the Home Department [2018] EWHC 2122 (Admin), at para
100, Karon Monaghan QC, sitting as a Deputy High Court Judge, accepted, as a general proposition, that
unjustified delay in making a decision leading up to a 'reasonable grounds' decision will render detention
unlawful.

93. It follows that, though this Ground is a challenge to the Claimant's continued detention after 27
September 2017, it is in reality a challenge to the decision not to refer her to the Competent Authority on or
about that date. (The Claimant was also not referred after she had given information about her trafficking
allegation to Dr Mahmood and he had reported them in his Rule 35 report, but this Ground is essentially
about the alleged public law error in failing to make the referral on or about 27 September, not at a later
date.)

94. I have already found in the Claimant's favour on Ground 2 and so, to that extent, this Ground will not
affect the outcome of these proceedings. However, since I heard full argument on the point, I think it is
appropriate to set out my conclusions in this judgment.

95. It is clear from the papers before me that the reason why the Defendant, in her capacity as First
Responder, decided not to make a referral to the Competent Authority is that, having considered the
matter, the immigration officer who made the decision took the view that there was nothing in the
Claimant's complaint of trafficking.

96. Mr Toal's challenge in Ground 3 has two limbs to it. First, he submits that the Defendant as First
Responder has an obligation to make a referral to the Competent Authority in every case in which a person
makes a complaint of trafficking. Second, and alternatively, he submits that the threshold for a referral is
very low, and, even if the First Responder retains a discretion not to make a referral when a detainee
makes a complaint of trafficking, there were no valid grounds for declining to make a referral in the
Claimant's case, and the failure to do so was irrational.

_The National Referral Mechanism_

97. The UK's obligations to safeguard victims of trafficking are derived from the Council of Europe
Convention on Action against Trafficking in Human Beings and from Article 4 of the European Convention
on Human Rights: see, in relation to the latter, _Rantsev v Cyprus_ [2010] ECHR 3. In _Rantsev,_ the
European Court of Human Rights held that States have a positive duty to take active steps to identify a
victim of trafficking and to provide protection once identified.

98. The NRM has been adopted to comply with the UK's obligations under the Convention Against
Trafficking. It is a three-stage process.

99. The first stage is for a First Responder to identify a person as a potential victim of trafficking.  The
Defendant is a First Responder, as are a number of other statutory and voluntary sector agencies.  Where
a person is identified as a potential victim of trafficking, the First Responder refers the person to a


-----

Competent Authority to decide whether the person is or is not a victim of trafficking. The Competent
Authorities in the UK are UK Visas and Immigration (UKVI) and the **_Modern Slavery Human Trafficking_**
Unit (MSHTU).

100. The Court of Appeal has emphasised that the threshold for making a reference is very low. In
_[Secretary of State for the Home Department v H [2016] EWCA Civ 565, Burnett LJ said, at paragraph 36:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_

“This appeal is concerned with the procedural stage in the [Competent Authority] Guidance which leads to
a conclusion whether there are reasonable grounds to believe that the respondent was a victim of
trafficking. The procedural obligation under article 4 [ECHR] arises when there is a 'credible suspicion' that
a person has been trafficked.  Mr Westgate submits that 'credible suspicion' is not the same as
'reasonable grounds to believe'. To my mind, using the term 'credible suspicion', just as 'potential
trafficking' or 'arguable claim' in article 3 cases, the Strasbourg Court is drawing a distinction between mere
allegations and those with sufficient foundation to call for an investigation. The procedural obligation does
not arise simply on the making of an allegation. There is a very low threshold under the Guidance for a
case to be referred to the Competent Authority – in reality, any suspicion or any claim – but this is not
sufficient to trigger the procedural obligation under article 4”

101. It is true that Burnett LJ was principally concerned with the circumstances in which the Competent
Authority was required to find that there were reasonable grounds for the allegation of trafficking, rather
than with the responsibilities of the First Responder, but in my view this passage nevertheless gives
authoritative guidance about the nature of the First Responder's task.  The threshold for a referral is very
low. Burnett LJ's observations were approved and reiterated recently by Underhill LJ in _R (ota TDT) v_
_Secretary of State for the Home Department [2018] EWCA Civ 1395, at paragraphs 31(1) and 33(1)._

102. The Defendant has provided Guidance to its staff in their capacity as First Responders, entitled,
'Victims of Modern Slavery – frontline staff guidance.'  The Guidance states, in particular:

“It is the responsibility of frontline staff in the Home Office to identify if a person is the victim of **_modern_**
**_slavery._**

If they will not identify themselves as a victim, you must consider if there are any objective signs….

If you identify a potential victim of modern slavery, [First Responders] must refer them to the NRM to be
considered by a competent authority.

Frontline staff must identify indicators of **_modern slavery which merit further consideration by the_**
Competent Authority. However, the threshold for referring a case is low and there is no minimum
requirement for justifying a referral.

When removal directions are due to be carried out on an individual and they make a late claim to be a
victim of modern slavery, the Home Office must carefully consider the claim.

Where removal directions are set and imminent, you must follow existing procedures and refer the case to
the operational support and certification union (OSCU) who (1) act as Competent Authority and (20
respond to the claimant and their legal representative.”

103. Once a case has been referred to the Competent Authority, there are two further stages. First, the
Competent Authority decides whether there are reasonable grounds to believe that a person is a victim of
trafficking. If so, then the person is informed and is notified of their entitlement to a 45 day 'reflection and
recovery' period whilst a final decision is made on their case. At the final stage, the 'conclusive decision'
stage, the Competent Authority decides conclusively whether the person is a victim of trafficking. This
decision is taken by reference to the ordinary civil standard of proof.

_Did the Defendant, as First Responder, err in law in failing to refer the Claimant's case to the Competent_
_Authority on or about 27 September 2017?_

104. In my judgment, the answer is 'yes'.


-----

105. I do not think that it is necessary to decide Mr Toal's first argument, to the effect that it is never
permissible for a First Responder to refrain from making a referral in any case in which an individual makes
an allegation of trafficking. In the vast majority of cases, it is likely that this will trigger a duty to make a
referral, because the threshold is so low, but it is not necessary for the purposes of this judgment to
discount the possibility that an allegation of trafficking, made by a detained person, may be so frivolous or
so self-evidently untrue that there is no obligation to refer.

106. However, in my judgment, it is clear that the officer who took the decision not to refer on or about 27
September 2017 took account of irrelevant considerations in so doing. The reasons why the Claimant was
not considered to be a potential victim of trafficking are helpfully set out in paragraph 25 of the Detailed
Grounds of Defence. There are six of them. Five of them are reasons why it may not be credible for the
Claimant to claim that she was trafficked in the UK. These include that she was being paid for her work in
the UK, and has indicated that she wants to stay in the UK. These factors miss the point entirely: they are
irrelevant considerations, because the Claimant's contention is not that she has been the victim of
trafficking in the UK, but that she was a victim of trafficking in Namibia. A person can be the victim of
trafficking, for these purposes, if the trafficking took place entirely in their home country. There is no
requirement that they must have been moved across state borders for trafficking purposes: see the H case,
at paragraph 32. The fact that the Claimant was able to undertake paid work in the UK, and was willing to
do so, does not in any way detract from her allegation that she was trafficked when she was back in
Namibia. Indeed, if anything, her desire to remain in the UK despite having three children in Namibia tends
to support her allegation that she had suffered maltreatment in Namibia and does not wish to return there.

107. The fact that the decision-maker took into account these five factors, in my judgment, vitiates the
decision not to refer. It was taken by reference to irrelevant considerations.

108. The only remaining factor which the decision-maker took into account was that the Claimant had
waited two months after arriving in the UK before making the allegation of trafficking.  In my judgment, it
was irrational to rely upon this as a reason, let alone the sole reason, for declining to refer. The Guidance
for First Responders makes clear that trafficked persons will often be very reluctant to make the allegation
of trafficking. It is for this reason that First Responders are encouraged to be alive to the possibility of
making a referral because of indicators of trafficking, even if a person does not make a complaint at all.
The key consideration, in my judgment, is that the threshold for making a referral is 'very low'. The
passage from the judgment of Burnett LJ at paragraph 36 of the _H_ case makes clear that it is not the
function of the First Responder to evaluate the credibility of the claim. That is a task for the Competent
Authority at the 'reasonable grounds' stage. It should be left to the Competent Authority to decide because
the decision-makers at the Competent Authority have specialist training and expertise.

109. In the H case, Burnett LJ said that a referral should be made if there is 'any claim'. As I have already
indicated, I do not have to decide, in this case, whether this means that it is automatically an error of public
law for a First Responder to decline to make a referral in the face of an allegation of trafficking. However, it
is clear, in my view, that it will only be in a very rare case that it would be appropriate for a First Responder
to decline to make a referral where an allegation of trafficking is made. In the present case, the First
Responder took a range of wholly irrelevant considerations into account and reached a conclusion which
was, on the available facts, irrational.  There was no rational basis for the First Responder to decide not to
make a referral on or about 27 September 2017.

110. As I have also already said, an error of law in respect of the failure to make a referral on or about 27
September 2017 would render the Claimant's detention from that date onwards unlawful, if it was not also
rendered unlawful because of Ground 2.

111. Accordingly, Ground 3 also succeeds.

**Conclusion**

112. For these reasons, the Claimant's claims succeed on Grounds 2 and 3, but not on Ground 1. The
Claimant's detention from 20 September to 13 October 2017 was unlawful and she is entitled to damages
for the tort of false imprisonment.


-----

113. I have helpfully been provided by counsel with a draft order which, subject to one issue to which I am
about to refer, is agreed. The order provides that, unless the parties notify the Court within 28 days that
they have reached agreement as to the quantum of damages, the issue of quantum will be listed for an oral
hearing, with a time estimate of 1.5 hours.

114. The only outstanding issue relates to costs. The parties are content for me to deal with this issue on
the basis of written submissions. The Defendant accepts that he should be liable to pay the Claimant's
reasonable costs up to the date of judgment, to be assessed if not agreed.  The Claimant is legally-aided
and I will make an order for detailed assessment of the Claimant's publicly funded costs.  The dispute
concerns whether the Court should order that the Claimant pay 50% of those costs within 14 days of the
Claimant serving a bill of costs on the Defendant.

115. The Claimant has not served a schedule of costs upon the Defendant or the Court. Nevertheless, the
Claimant submits that such an order should be made because it is highly unlikely that the Defendant will
dispute over 50% of the final bill, and that experience has shown that bills have been settled with the
Defendant paying over 50% of the costs as drawn. The Claimant points out that there is likely to be a
substantial delay in the costs being paid.  The Defendant submits that it should not be required to pay any
percentage of the Claimant's costs in circumstances in which the amount of the costs that are sought by
the Claimant are as yet unknown.

116. I agree with the Defendant. Whereas it is relatively common nowadays for an unsuccessful party to
be ordered to pay a percentage of the successful party's costs by way of an interim payment, this is
normally in circumstances in which the total amount of costs that are to be claimed is known, either as a
result of costs budgeting or because a schedule of costs has been served by the successful party. I do not
think that it would be right, in the present case, for the Court to order the Defendant to pay 50% of an
unknown sum. Accordingly, I decline to make any order for the interim payment of a percentage of the
Claimant's costs.

**End of Document**


-----

