# R (on the application of Adesanya) v Secretary of State for the Home
 Department [2016] EWHC 1165 (Admin)

Queen's Bench Division, Administrative Court (London)

Judge Jarman QC (Sitting as a Deputy Judge of the High Court)

20 May 2016Judgment

**Miss Rowena Moffatt (instructed by Duncan Lewis Solicitors) for the Claimant**

**Miss Natasha Barnes (instructed by Government Legal Department) for the Defendant**

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

JUDGE JARMAN QC:

1. The claimant is a national of Nigeria who with the permission of His Honour Judge Bidder QC sitting as a judge of
the High Court seeks to challenge the defendant's decision to detain him, deport him and to certify his human rights
claim under section 94B of the Nationality Immigration and Asylum Act 2002 on the basis that although the appeals
process for that claim has not been exhausted, removal of the claimant to Nigeria pending the outcome of the
appeal would not be unlawful under section 6 of the Human Rights Act 1998.

2. The claimant was detained at Dover Immigration Removal Centre from 17 June 2015, after being released from
prison where he'd been remanded on an offence of assault, until November 2015 after permission was given to
bring this claim. At the heart of the claimant's challenge is a recognition by the defendant in a decision dated 17
September 2015 that there are reasonable grounds to believe that he has been a victim of trafficking.

3. On his behalf Miss Moffatt submits that this decision should have been made earlier in June 2015 and that
consequently he should have been released from prison and not detained in a removal centre at all. She submits
that it is only in exceptional circumstances that a person who is potentially a victim of modern slavery should be
detained and none exists here so that the detention is unlawful. Moreover there was no reasonable prospect of his
being deported within a reasonable time.

4. Miss Barnes on behalf of the defendant submits that detention was justified on public order grounds in view of the
claimant's criminal offending, immigration history and contact with the police. He was released only when
permission was given to bring this challenge and so then it appeared that he would not be deported within a
reasonable time.

5. Accordingly it is necessary to look at the claimant's history in some detail. He was born on the 28 September
1978. He was first encountered by authorities in the UK in 2007 when he was arrested on suspicion of being an
immigration offender. He handed officers a passport bearing a different name, and claimed to have entered the UK
three weeks beforehand on a student visa. He was subsequently released on reporting conditions but failed to
comply.

6. He formed a relationship with a Latvian national with whom he had a daughter born on 30 August 2009. In
October 2010, just after they had separated, she attended the local police station and accused him of rape and of
grabbing her by the throat. On further questioning she said that she was not willing to give any further details. The


-----

claimant was arrested and detained on two charges of assault and bailed on condition he did not approach his
former partner. He was acquitted of those charges in December 2010.

7. A few days later the former partner made further allegations to the police that the claimant had hit her three times
and ripped her jacket. She was observed to have injuries to her face and cuts to her middle finger where she said
the claimant bit her, and she was observed to be very unsteady on her feet. Three days later she made a further
allegation of rape against him. These allegations related to the time when his bail conditions prohibited him from
approaching her. The claimant voluntarily attended the police station in January 2011 and denied the allegations. In
March she alleged that he was contacting her. A police officer recorded that he admitted breaching some of his bail
conditions but that appeared to be because of emotional ties with his daughter, that he may have been “emotionally
blackmailed,” and that the other allegations appeared “extremely weak.” No further action was taken in respect of
those allegations or further allegations of harassment against the claimant made by his former partner later that
year.

8. The following year he formed another relationship with a partner who has two daughters. She and her daughters
are all British Citizens. The relationship was a volatile one and the police attended the home where they lived on a
number of occasions throughout 2013 and 2014. He was again arrested as an immigration offender in May 2013
and granted temporary admission pending full submissions regarding his family life but he says that his former
solicitors failed to pass on the request to him, and none were made.

9. In June 2013 his partner accused him of kicking her to the head and holding her by the throat. He was arrested
and said that it was she who attacked him with an iron. When this was put to her she said she had made up the
allegation and that his version was correct. The next month, patrolling police officers came across the couple with
another couple in the street who were all recorded as being very drunk. They saw the claimant being pushed in the
chest by his partner causing him to fall to the floor and she was arrested. However, the claimant made it clear he
would not assist the police and refused to give any further contact details.

10. The next day he called the police saying that his partner was very drunk. When officers attended she accused
him of squeezing her neck and the officers observed a mark there. He was arrested and interviewed. He said that
she had tried to hit him with a mirror and he pushed her away. A scuff mark was seen on his hand. In July the police
attended again and observed that he had a lump on his elbow and scratches to his neck. He broke down and said
that he was the victim of domestic violence. Later, in September she told the police she wanted to withdraw the
allegations and that she was back with the claimant. No further action was taken.

11. In November the police were again called when the partner accused the claimant of kicking her and strangling
her in a fight. No visible injuries were noted. He was arrested and interviewed but denied the allegation. He was
granted bail on reporting conditions. He failed to comply.

12. In January 2014 he pleaded guilty to criminal damage of his partner's leather jacket after a row. He maintained
that this happened after she had damaged his possessions. He was given a conditional discharge. The following
month, he got into an argument with another man. The police were called and when officers arrived the claimant
undressed. When the officers went to restrain him he bit one of them on his arm. He was arrested and again
released on reporting conditions and again failed to comply.

13. In April 2014 the claimant's partner again alleged that he had grabbed her by the throat on two occasions (she
later said this was a malicious account). She was later seen to punch the claimant to the chest, knocking him to the
ground. She was cautioned for being drunk and disorderly. Both the claimant and a lodger were interviewed
separately and both said it was the partner who had earlier assaulted the claimant.

14. In January 2015 he was arrested and charged with assault occasioning actual bodily harm arising out of the
incident the previous February, and he was remanded in custody at HMP Pentonville.

15. In April 2015, during a conversation with immigration officers, the claimant for the first time said that after the
death of each of his parents he was brought to the UK at the age of 15 or 16 by a Nigerian family to be used as a
domestic servant in the UK. He was kept locked in their home and beaten frequently over the course of the next


-----

eight years or so before he managed to escape and then lived with the help of people who befriended him. On 16
April, the officers faxed to HMP Pentonville a form for entry into the national referral mechanism for potential adult
victims of trafficking, with a request that the claimant should complete the form and sign the consent to the referral
part of the form, but on that day he was removed to HMP Thameside, so another form was faxed to there on 21
April.

16. In May the defendant sent an email chasing up the forms. In June the claimant was removed to Dover
Immigration Removal Centre and further referral forms were sent to him there. On 17 June he completed an
application for permission to remain in the UK on the basis of his family and private life, and requested that he be
released from detention. This was not received by the defendant until the end of June, at which time the claimant
returned the referral form. The first page containing his name and contact details were completed but the second
page, with the necessary signature in the consent section, was not.

17. By letter dated 3 July 2015, the defendant refused the applications. The reasons given for refusing to release
him included likelihood of absconding, lack of close family ties, lack of compliance with conditions, and the
deception as to his identity on arrest in 2007. It was said that no evidence had been provided that he cohabited with
his partner or of his day to day routine with his daughter or step daughters, and that whilst it was accepted that he
may have established a private life in the UK, interference with that was justified and proportionate to a social need
being fulfilled. It was also said that his application for temporary admission would be considered without delay.

18. On 6 July 2015, he pleaded guilty to the charge of assault. The judge expressed some reluctance about passing
a custodial sentence but referred to the fact that the claimant's counsel had invited him to do so because there was
no way of dealing with a community sentence in his situation. He was given a sentence of nine months'
imprisonment, the judge taking the view that as the case involved a police office in the execution of his duty the
custody threshold was passed, and 14 days concurrent for the breach of the conditional discharge. As he had been
detained in custody on this charge since January 2015 he had already served his sentence.

19. However he was not released from detention. On 13 July the defendant served upon him a decision to deport,
on the basis that as a result of his criminality, deportation was considered to be conducive to the public good
pursuant to section 3(5)(a) of the Immigration Act 1971. In that letter, reference was made to the claimant's
statement as the circumstances in which he was brought to the UK, and to the failure to complete the consent
section on the referral forms. As a result, it was said that that matter was considered concluded.

20. On 21 July the defendant wrote to him saying that while there is a presumption in favour of release, “because of
your criminality, the seriousness of the harm to the public should he re-offend and or high risk of absconding,” there
was reason to believe that detention was justified under the powers set out in Schedule 3 of the 1971 Act.

21. By letter dated 25 August 2015 the defendant served the claimant with a decision to refuse his human rights
claim and to maintain the decision to deport, essentially repeating that it was not accepted that he had a genuine
and subsisting relationship with his partner, her children, or his own child because of lack of evidence. For similar
reasons, the claim was certified under the 2002 Act as indicated above.

22. On 3 September he was served with notice of removal directions to Nigeria set for 29 September. He told the
immigration officers of having been brought to the UK as a domestic servant, so the defendant sent a further
referral form to him. By this time the form had been changed to include on the front in capital letters the requirement
to complete the consent section. This time the form was returned the next day with that section completed. That led
to the defendant's reasonable grounds decision dated 17 September. A couple of days beforehand he made an
asylum claim.

23. The decision letter, which was not served until October, stated that he had a period of 45 days to recover and
consider his options, as provided for under the terms of the Council of Europe Convention on Action Against
Trafficking in Human Beings (the Convention) which was ratified by the UK in December 2009. During that period
he would be entitled to safe accommodation and support. At the end of the period, it was said that the authorities
would make a conclusive grounds decision as to whether he was a victim of modern slavery.


-----

24. That decision has yet to be made. In the earlier part of this year, the claimant's solicitors asked the defendant to
await a psychiatric report on him before making the decision. That report was only received by the defendant a
couple of weeks ago and there is presently no indication of when the decision might be made.

25. By a pre-action letter dated 2 October, solicitors acting for the claimant after setting out the background, argued
that the decision to continue his detention following the reasonable ground decision was unlawful. They referred to
chapter 55.10 of the defendant's Enforcement Instructions and Guidance (the Guidance), which is intended to give
effect to her obligations under the Convention.

26. The letter continued that whilst it was accepted that the defendant intends to deport the claimant, it cannot be
said that deportation could be carried out within a reasonable period. Furthermore, whilst it was accepted that he
had a poor history of reporting to the authorities, he had given explanations and had periods of compliance, and as
he by then had an outstanding trafficking claim he had motivation to comply with any conditions of his release.

27. The defendant replied by letter dated 8 October, saying that the claimant's case had been carefully considered
in light of the representations, but that it was considered that the claimant should not be released for essentially the
same reasons as had been given in response to previous requests The letter included these passages:

“The Home Office has reviewed the decision to detain your client for immigration purposes. Following
careful consideration, the Home Office is maintaining your client's detention. This is justified on grounds of
public order, when taking into account his criminal history and blatant disregard of the United Kingdom's
criminal and immigration laws.

In reaching this decision your client's rights have been balanced against the wider rights and freedoms of
others and the general public interest. We have weight up the extent of your client's [potential victim of
trafficking] claim and failure to observe immigration regulations. It is considered that our actions are
proportional to a social need being fulfilled….”

28. The letter also indicated that detention would be reviewed on a regular basis and that the asylum claim which
he had made would be considered without delay.

29. Some 5 days later the October detention review was carried out. Neither that nor the review carried out in
November made reference to the victim of trafficking claim. However on the 24 November 2015 the defendant
signed a release order with restrictions including reporting conditions.

30. The issue of detention of persons who are victims of trafficking is dealt with in chapter 55.10 of the Guidance
which provides as follows so far as material.

“Certain persons are normally considered suitable for detention in only very exceptional circumstances,
whether in dedicated immigration accommodation or prisons…..

In criminal casework cases, the risk of further offending or harm to the public must be carefully weighed
against the reason why the individual may be unsuitable for detention. There may be cases where the risk
of harm to the public is such that it outweighs factors that would otherwise normally indicate that a person
was unsuitable for detention.

The following are normally considered suitable for detention in only very exceptional circumstances,
whether in dedicated immigration detention accommodation or prisons:

…persons identified by the competent authorities as victims of trafficking (as set out in Chapter 9, which
contains very specific criteria concerning detention of such persons).

If a decision is made to detain a person in any of the above categories, the caseworker must set out the
very exceptional circumstances for doing so on file.”

31. Chapter 9 deals with identifying victims of trafficking and the introduction provides as follows:

“This guidance should be followed during all operations where individuals who may be victims of trafficking
are encountered so that potential victims are handled in a consistent and sensitive manner


-----

During operations, enquiries into whether a person is a victim of trafficking should take precedence over
enquires into the individual's immigration status. Officers should be aware that victims of trafficking are
likely to be classified as vulnerable persons and detention will not normally be appropriate.

Officers should refer to Chapter 55 of the [the Guidance] when considering detention.”

32. Chapter 9.9 refers to the Convention and to assessment of claims by a potential victim of trafficking (referred to
in the Guidance as a PVoT) by the relevant authorities (referred to as Competent Authorities or CAs) and includes
the following passage:

“Competent Authorities will aim to complete an assessment of whether there are 'reasonable grounds to
believe' someone is a victim within 5 days of referral. A positive decision will trigger a 45 day 'recovery and
reflection' period during which time individuals will not be detained (unless their detention can be justified
on grounds of public order) and removal action will be suspended. Victims will have access to certain
rights, including accommodation and advice.

A process map highlighting the keys steps in the attached (NB for ease of reference, the process is broken
down onto three separate pages covering: Referral, RG Decision and the Conclusive Decision).”

33. The reference to RG refers to a reasonable grounds decision, and there is then a link set out on which to click
for the map.

34. Chapter 9.10 deals with making referrals to a Competent Authority and includes this passage:

“Where the CA accepts the reasonable ground the PVoT is allowed a 45 day Reflection period to recover
and consider their options and consider their options. The PVoT cannot be removed during this period or
detained on immigration grounds unless, in the particular circumstances, their detention can be justified on
grounds of public order. They can continue to be interviewed for asylum purposes and notified of their
decision in line with existing asylum deadlines.”

35. Despite the clear references in those two passages to detention of potential victims of trafficking being justified
on grounds of public order, Miss Moffatt submits that such references must be read in light of the defendant's
obligations under the Convention. She accepts the point made by Miss Barnes that the Convention has “no direct
effect unless and until incorporated by statute, but that it may be taken into account as an aid to interpretation in
cases of ambiguity” (per Lord Carnwath in _R (SG & Others) v Secretary of State for Work and Pensions [2015]_
_UKSC 16)._

36. Miss Moffatt submits that if a decision is based on part of the Guidance that misinterprets the Convention then
that amounts to an error of law (see R (Atamewan) v Secretary of State for the Home Department [2014] 1 WLR
1959at paragraph 69). Helen Mountfield QC, sitting as a judge of the High Court in R (Ham) v Secretary of State for
_the Home Department [2015] EWHC 1725 (Admin) at paragraph 53 approached the Convention in these terms:_

“Since the UK Government has announced that its policy is to give effect to its obligations under the
Trafficking Convention, that has consequences in domestic administrative law. Failure to apply the
provisions of the Convention may give rise to a successful claim for judicial review: not because the treaty
has any direct effect (because it does not), but because the Government has then failed to apply its own
published policy (see _R(Y) v SSHD [2012] EWHC 1075 (Admin)_ at [40]). Thus, the Competent Authority
should be taken to have intended to protect the victim's rights, combat trafficking and promote international
co-operation (the objectives identified in the Convention) and to promote a human rights based approach.”

37. It is important to note that the Convention does not deal with detention at all. It requires that victims are assisted
in their physical, psychological and social recovery. Article 12 so far as material provides as follows:

“1. Each Party shall adopt such legislative or other measure as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

a. standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;


-----

b. access to emergency medical treatment;

c. translation and interpretation services, when appropriate;

d. counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e. assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders.

f. access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.”

38. Article 13 provides:

“1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in the territory.

2. During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2.

3. The Parities are not bound to observe this period if grounds of public order prevent it or if it is found that
victim status is being claimed improperly.”

39. Two points to my mind are immediately obvious. The first is that Article 13 provides for a minimum period, which
is a short one, for the purposes of allowing a person reasonably believed to be a victim to recover and escape the
influence of traffickers and/or to decide on cooperating with authorities. The second is that there is a derogation
from that requirement if grounds of public order prevent observation of such a period.

40. Miss Moffatt submits that in respect of remaining in the territory, potential victims of trafficking have greater
protection afforded by Article 13 than those who are conclusively recognized as such. Moreover, the derogation is
closely circumscribed to where there are public order grounds which prevent observance, and this implies a
threshold of exceptionality at least equivalent to the test for detaining those who are conclusively recognized as
victims. There is some uncertainty in the Guidance as to the proper test to be applied in order to detain a person
reasonably believed to be victim of trafficking and that doubt must be resolved by having regard to such a threshold
of exceptionality.

41. Miss Moffatt points out that in the executive summary of a monitoring report of implementation of the
Convention into the UK by GRETA (Group of Experts on Action Against Trafficking in Human Beings) in 2012,
reference is made to the Government's policy as being “not to detain victims of trafficking except in exceptional
circumstances on public order or protection grounds,” and that: “Unless public protection issues prevent the UK
from doing so, following identification they will always be released into appropriate care.”

42. Miss Barnes submits that Chapter 55.10 clearly only applies to persons who have been conclusively recognised
as such victims, and that there is nothing to suggest that the test for detaining a person subject to a reasonable
ground decision is exceptionality. A person in the latter category is in a stronger position than a person in the former
category only in the sense that such a person may not be removed from the territory, but otherwise has fewer
rights. Miss Barnes also points out that in further guidance given by the defendant to its staff to help them decide
whether a person referred under the referral mechanism is a victim of trafficking, there is also clear reference to the
detention of persons reasonably believed to be such victims on grounds of public order.


-----

43. In my judgement the Guidance is tolerably clear. Chapter 55.10 refers to persons identified as victims of
trafficking. That is a different category to persons in respect of whom there are reasonable grounds to believe are
victims, and that distinction comes out clearly in the Convention and in the Guidance. It is true that the reference is
followed immediately by the words in brackets expressly incorporating Chapter 9. However Chapter 9 sets out the
three stage process leading to a conclusive decision that a person is a victim of trafficking. In my judgment, the
words in brackets are to be taken as indicating that the reference to persons identified as victims of trafficking
means persons who have gone through all three stages and has been conclusively decided to be such victims. It is
those persons to whom the exceptionality test for detention must be applied.

44. The fact that Chapter 9 also deals with persons in the second stage, those reasonably believed to be such
victims, does not detract from the clarity of Chapter 55.10. Chapter 9 is also clear in my judgment that those
persons can be detained on public order grounds. It would be rather surprising if, even though there were public
order grounds for detaining someone reasonably believed to be a victim of trafficking, such detention could not be
justified unless the circumstances were exceptional.

45. Accordingly, it is not permissible to have resort to the Convention in order to interpret the Guidance. Even if it
were, I would not have concluded that such a course would lead to a different interpretation. Grounds of public
order are expressly referred to in Article 13 as a derogation from the requirement to observe the period of reflection
and recovery. It is true that the word “prevent” suggests a high threshold of such grounds, but that is not a
justification for implying that the circumstances must be exceptional.

46. In my judgment therefore, in deciding to detain the claimant, the defendant applied the right test. The initial
decision to detain refers to the likelihood of absconding, the lack of evidence of close ties with family or friends, the
failure to comply with reporting conditions, and the use of deception upon arrest in 2007. After his conviction in July
2015, to these factors was added the serious risk of harm to the public (this risk was downgraded to medium in
October 2015). In my judgment the defendant was entitled to have regard to these factors.

47. It is true that in the monthly progress reports, public order grounds are not specifically mentioned, but a decision
that the claimant was a person reasonably believed to be a victim of trafficking was not made until 17 September.
Shortly afterwards in her letter of response dated 8 October to the claimant's pre-action letter, specific reference
was made to public order grounds, and essentially the same matters were set out as amounting to such grounds.

48. The next issue is whether in doing so, she was justified in concluding that there were public order grounds to
detain him. Miss Moffatt, in submitting that she was not, points to the fact that the judge in passing sentence in July
2015 was reluctant to pass a custodial sentence, did so at counsel's invitation so that the sentence passed had
already been served, and found the injury to the officer as being not very serious. In the decision dated 25 August
2015 to refuse the claimant's human rights claim and to maintain the decision to deport, reference is made to
permanent scarring to the officer, but it is accepted now that that appears to be an error.

49. The same letter after that reference continues: “Furthermore, you come to the attention of the police on several
other occasions for a variety of offences as detained in the police witness statement.” Miss Moffatt submits that that
is not a fair summary of the police records, which also show that many allegations were later retracted, and that the
claimant was possibly being emotionally blackmailed by his former partner, and that later he was the subject of
attacks by his subsequent partner.

50. Miss Barnes, whilst recognising the force of those points, nevertheless submits that there were occasions when
marks were seen on his partner, that victims of domestic abuse often retract allegations, that two of his partners
independently made allegations of abuse and that the defendant could not be expected to set out in detail
conclusions on each of the allegations made. What she was doing was making a general observation.

51. Miss Moffatt, accepts that the claimant has a poor history of compliance with reporting and other conditions, but
submits that this should be seen in the context that there are reasonable grounds to believe he is a victim of
trafficking. As suggested in the Guidance, distrust of authority is an indicator that a person is such a victim as was
identified as a factor in the claimant's referral.


-----

52. In my judgment, whilst there is some force in these criticisms of Miss Moffatt, these are tempered by the points
made by Miss Barnes. Moreover, such criticisms arise out of remarks made by the defendant in dealing with the
issue of deportation. In dealing with the question of detention, the emphasis was placed upon the matters set out
above. I am not persuaded that the conclusions which the defendant came to as to whether there were public order
grounds which justified continued detention were conclusions which were not open to her.

53. Miss Moffatt's next point is that the referral should have been earlier and that should have led to his release
earlier. The claimant says that initially he was told that he needed only to fill in the first page of the form, and there
is a note of the caseworker which gives some support for this. He did not initially return any part of it because he
says he was expecting immigration officers to come to him to deal with it. He says that when the form was again
sent in June he only received one page, whereas it is clear from the page numbers on the faxed documents that
there were two. That is irrelevant submits Miss Moffatt, because in June the claimant did return the first page of the
form completed with his name and contact details, and even though he had not signed the consent, it must have
been obvious that he was intending and trying to make the referral. As he was by then in Dover Immigration
Removal Centre, an officer could easily and should have simply asked him to sign the consent form. Miss Moffatt
refers to guidance which the defendant gives to her frontline staff to help them identify and help potential victims of
trafficking that they must ensure that the consent section of the referral form is signed.

54. Miss Barnes submits that it was reasonable for the defendant to consider that trafficking claim withdrawn, as the
form had not been returned in April despite a chasing email in May, and when it was returned in June the consent
section was not completed. On these occasions when the form was sent there was a specific request for the
claimant to sign the consent section. The failure to do so is in contrast to the application for temporary admission
application which was returned with the form, which was fully completed and made no reference to the trafficking
claim. He was informed in the deportation decision of 13 July that the matter was considered concluded because he
had not signed the consent section, and this was repeated in the detention review on 18 August and in the letter
dated 25 August.

55. In my judgment the defendant did take appropriate steps to ensure that the claimant had opportunities to sign
the consent section. Whilst the return of some details in June gave some indication that he was intending to make a
referral, put into context of the circumstances relied upon by Miss Barnes, it was not unreasonable for the
defendant not to make the referral without his signed consent and to treat the matter as concluded. Whilst an officer
could easily have gone to him to obtain the signature, in the circumstances of this case there was no obligation to
do so. The claimant was in secure accommodation, and his claim to being a victim related to events which he said
had occurred 15 years previously.

56. Moreover, in light of the conclusions set out above, I am not persuaded that even if the referral had been earlier,
that would have led to his release before November 2015. The defendant was entitled to detain him on public order
grounds and did so until this claim, which included a challenge to the decision to deport, was given permission to
proceed, at which time it no longer appeared that deportation would be achieved within a reasonable time. The
conclusive decision as to whether he is a victim of trafficking has yet to be made in the circumstances set out
above.

57. Miss Moffatt's final point on detention is that the realisation that deportation could not be achieved within a
reasonable time should have occurred much earlier and that detention after that time is unlawful under the principle
in _R (Hardial Singh) v Governor of Durham Prison_ [1984] 1 WLR 704. She submits that detention was no longer
reasonable following the point at which the positive reasonable grounds should have been made or alternatively
was made. The asylum claim he made on 15 September would give rise to appeal if not certified and the trafficking
claim may lead to a conclusive decision that the claimant is a victim of trafficking.

58. For reasons already set out I do not accept that the referral should have been made earlier. When it was and
when the reasonable ground decision was made, the defendant was nevertheless entitled, to continue to detain him
on public order grounds. It was only when permission was granted in the present claim that it was no longer tenable
to proceed on the basis that removal would be achieved within a reasonable time.


-----

59. I now turn to the challenge as to the decision to deport. The reasons given in the July decision letter refer to the
claimant's two convictions and then continues: “As a result of your criminality, your deportation is considered to be
conducive to the public good and as such you are liable to deportation by virtue of section 3(5)(a) of the Immigration
Act 1971.” That provides:

“A person who is not a British Citizen is liable to deportation from the United Kingdom if….the Secretary of
State deems his deportation to be conducive to the public good.”

60. It was also stated that in reaching the decision full account was taken of his immigration history as set out. This
included the details of his arrest in 2007 and his failure to report, his arrest in January 2011, the failure to comply
with the request in 2013 for full details of his family situation, his failure to report after October 2013, his arrest in
April 2014 and subsequent failure to report, his arrest in January 2015, and his claim in April 2015 to be a victim of
trafficking. The letter also referred to his human rights claim which remained outstanding.

61. Miss Moffatt accepts that the defendant retains a discretion to make a deportation order in circumstances where
paragraph 398 of the Immigration Rules do not apply. That applies where a foreign criminal is liable to deportation,
defined for the purposes of automatic deportation under section 32 of the UK Borders Act 2008 as a person
sentenced to at least 12 months imprisonment.

62. However paragraph 363 of the rules sets out circumstances where a person is liable to deportation and this
includes “where the Secretary of State deems the person's deportation to be conducive to the public good.” This
point is also made in paragraph 3.2 of her guidance on Deporting non-EEA foreign nationals (version 3.1, April
2015).

63. Miss Barnes accepts that once a decision to deport is made, the policy of the defendant is to consider
paragraphs 399-399A of the Rules which deal with Article 8 claims. The July letter did not purport to deal with such
a claim. In my judgment, the decision to deport on the information before the defendant in July was one she was
entitled to come to. I do not accept Miss Moffatt's submission that the defendant should only deport where there is
serious harm or persistent offending.

64. The defendant dealt with the claimant's human rights claims in the August letter. As indicated it was not
accepted that he had a genuine and subsisting relationship with his daughter, his partner, or her daughters because
of lack of evidence of his day to day activity with them.

65. The letter stated that information received from the police along with the claimant's two convictions referred to
above had been given full and anxious scrutiny and it had been concluded based on his character, conduct and
associations that his presence in the UK was not conducive to the public good. Some of the sentencing remarks of
the judge when passing the sentence of imprisonment were quoted in paragraph 16, including “you bit the officer
through his uniform on his arm, causing injury….since he knew nothing about you, there is always a risk of serious
diseases being transmitted… you assaulted an officer occasioning actual bodily harm when he was carrying out his
duty, and he was on duty, doing his duty on behalf of the public trying to control you.”

66. As indicated, later on in the letter at paragraph 21 there is a reference to permanent scarring, which does not
appear to be borne out by the evidence. The statement of the police refers to breaking of the skin and marking on
the skin but not to permanent injury. In my judgment that mistake does not vitiate the decision, reading the decision
as a whole and having regard to the passages of the sentencing remarks earlier on. Immediately following the
remarks quoted in relation to injury, but not itself quoted, were the words “Fortunately not very serious” and the
defendant must have had them in mind.

67. At paragraph 17 the letter refers to the claimant's arrest on a number of occasions for various offences. In my
judgment it is clear that the defendant did not proceed on the basis that these led to convictions. Whilst there is no
express mention of allegations being withdrawn or of the claimant being the subject of assault or emotional
blackmail, what was being considered was the claimant's character, conduct and associations. Immediately
following the references to arrest are the words “It is considered on the totality of all the evidence that deportation is
appropriate in your case.” In my judgment the defendant was clearly approaching the decision in the round.


-----

68. The immigration history is again set out, essentially as in had been in July. At paragraph 51 the defendant
considered whether there were very compelling circumstances why the claimant should not be deported. In doing
so, she said that he had entered illegally in 2007 and had not attempted to regularise the position. She clearly had
the claim he made in April 2015 in mind, because it is expressly referred to. At the date of this letter, no referral had
been made.

69. Now that it has, the removal directions have been suspended and a conclusive decision will have to be made on
whether the claimant is a victim of trafficking. Any further decision as to removal will have to take that into account.
However, I am not persuaded that the decisions in July or August to deport, were decisions which the defendant
was not entitled to make on the information then available.

70. Miss Moffatt accepted that the third ground of challenge, to the defendant's certification, stands or falls with the
submissions on the date and which the reasonable grounds decision should have been made. As I have not
accepted her submissions in that regard, the third ground also must fail.

71. It follows that the claim is dismissed. Counsel helpfully agreed to deal with any consequential matters which
remain in dispute by written submissions. A draft minute of order and/or such submissions should be filed within 14
days of handing down this judgment.

**End of Document**


-----

