# NN v Secretary of State for the Home Department; LP v Secretary of State for
 the Home Department [2019] EWHC 766 (Admin)

Queen's Bench Division, Administrative Court (Birmingham)

Julian Knowles J

28 March 2019Judgment

**Chris Buttler and Miranda Butler (instructed by Duncan Lewis) for the Claimants**

**Emily Wilsdon (instructed by GLD) for the Defendant**

Hearing date: 21 March 2019

**Judgment Approved by the court        for handing down        (subject to editorial**
**corrections)**

If this Judgment has been emailed to you it is to be treated as 'read-only'.You should send any suggested
amendments as a separate Word document.

**The Honourable Mr Justice Julian Knowles:**

1. On 20 March 2019 I heard two on notice oral applications by the Claimants, LP and NN, for interim
relief. The Secretary of State was represented at the hearing. At the conclusion of the hearing I gave my
decision granting interim relief and I made other directions about the future course of these proceedings.
An agreed order has been drawn up giving effect to my decision. I said I would give brief reasons in writing
for my decision, and this I now do.

2. The Claimants NN and LP are both victims of **_modern slavery/people trafficking and have been_**
recognised as such by the Defendant in Conclusive Grounds (CG) decisions dated 1 February 2019 and
30 January 2019 respectively. In summary:

a. LP is originally from Albania. She was trafficked to the UK and held captive from August 2016 until
March 2017 during which she was repeatedly raped. She became pregnant and now has a one-year old
daughter. She managed to escape in March 2017.

b. NN is originally from Vietnam. He was trafficked to the UK. He ended up working on a cannabis farm.
He tried to escape, and was badly beaten including by having some of his teeth knocked out. He was
arrested and prosecuted and imprisoned, and since his release he has been living in a Salvation Army safe
house. He has been diagnosed with PTSD and depression.

3. NN has claimed asylum and his application is pending. LP's claim for asylum was refused by the
Defendant and she is currently appealing to the First-tier Tribunal.

4. These claims for judicial review concern aspects of the Defendant's policy towards victims of modern
**_slavery/trafficking.  As victims of trafficking the Claimants are entitled to two things:_**

a. Support pursuant to Article 12 of the Council of Europe Convention on Action against Trafficking in
Human Beings (ECAT) and Article 11 of the Directive 2011/36/EU on Preventing and Combating
Trafficking in Human Beings and Protecting its Victims (the Directive) (which I will call 'the support duty').


-----

b. A determination whether they should be granted leave to remain pursuant to Article 14 of ECAT (ECAT
leave).

5. In simple terms, the support duty involves payment of £65 per week, accommodation at a safe house
and provision of a support worker.  Those not entitled to this receive basic accommodation and
subsistence payments of £37.75 per week pursuant to s 95(1) of the Immigration and Asylum Act 1999 and
the Asylum Support Regulations 2000. This is called NASS support (after the National Asylum Support
Service) and is restricted to meeting the cost of avoiding destitution: (R(JK)(Burundi) v Secretary of State
_for the Home Department)_ [2017] 1 WLR 4567, [59]. Hence, those receiving benefits pursuant to the
support duty are in a more advantageous position than those who are not.

6. The relevant aspects of the Defendant's policy at issue in these claims are as follows:

a. As well as support between RG and CG decision, the Defendant's policy provides for a package of
support until 45 days after the positive CG decision (the 45 day rule). The Claimants contend that the
support duty in Article 12 of ECAT and Article 11 of the Directives includes support after the CG decision.

b. An application for ECAT leave will be determined at the same time as a CG decision, unless the
individual has claimed asylum, in which case the ECAT leave decision will be deferred until the asylum
decision has been taken (the scheduling rule). It is argued in NN's case that this means that victims of
trafficking who claim asylum suffer delay, often in excess of one year, in determination of their right to
ECAT leave. This, it is said, results in significant financial disadvantage and risks delaying psychological
recovery.

7. LP and NN challenge these policies as being unlawful.

8. LP's grounds of challenge, in summary, are as follows:

a. The 45-day rule is incompatible with ECAT and the Directive and so unlawful because:

(i) The support duty subsists until the individual leaves the UK. This proposition is founded upon a
concession to that effect made by the Secretary of State in _R(PK (Ghana)) v Secretary of State for the_
_Home Department [2018] 1 WLR 3955, [46]._

(ii) The support duty is discharged by the provision of payments pursuant to the support duty and not just
NASS support, per Mostyn J in R(K and AM) v Secretary of State for the Home Department [2018] EWHC
_2951 (Admin), [25] et seq._

b. The withdrawal of the support duty at 45-days does not involve an assessment of LP's individual needs
but is a blanket rule and hence unlawful. This proposition is founded upon R(EM) v Secretary of State for
_the Home Department [2018] 1 WLR 4386, [66]._

9. NN also challenges the 45-day rule on the basis I have set out above at [8(a)(i) and (ii)].  In addition,
he challenges the scheduling rule:

a. As being inconsistent with Article 14 of ECAT which, he argues, requires that a renewable residence
permit _must_ be granted if the competent authority considers that the victim's stay is necessary owing to
their personal situation.  He also challenges it on the grounds it fails to take account of the victim's
particular needs.

b. As being discriminatory and so in breach of Article 14 of the European Convention on Human Rights.

10. In their applications for interim relief, the Claimants sought orders that the Defendant not reduce the
level of their financial and other support pursuant to the support duty pending the outcome of their claims.

11. In addition, shortly before the hearing, those representing the Claimants sought an order for interim
relief for all of those currently receiving support under the support duty (whether before the Court on
judicial review proceedings or not).

12. Ms Wilsdon attended the hearing on behalf of the Secretary of State and made some oral submissions
against the grant of interim relief. Despite the hearing having been ordered by His Honour Judge Cooke
itti j d f th Hi h C t 15 M h 2019 th S t f St t fil d id itt


-----

submissions. I make clear no blame attaches to Ms Wilsdon for that; she was only instructed very shortly
before the hearing and she did her best to assist.

**Discussion**

13. This is an application for (in effect) interim injunctive relief. The test I have to apply is therefore the
_American Cyanamid test, modified for the public law context._

14. Following submissions, I was satisfied that the Claimants have good arguable cases on the grounds of
challenge as presented. That was principally because:

a. Ms Wilsdon very fairly acknowledged that the concession in _PK, supra, to which I have referred,_
presented some obstacles for her in relation to the support duty challenge, but made clear that whether
that concession would be maintained was something which the Defendant wished to consider.

b. Furthermore, so far as the challenge to the scheduling rule is concerned, permission has been granted
on similar grounds by Andrew Baker J in _R(JP) v Secretary of State for the Home Department_
(CO/4606/2018) and R(BS) v Secretary of State for the Home Department (CO/4608/2018).

15. I turn to the balance of convenience and prejudice if interim relief is not granted.

16. So far as the individual Claimants are concerned, I was satisfied that they will suffer irremediable
prejudice if their current levels of support are not maintained pending the outcome of these claims.  For
example, LP's support worker has made a witness statement setting out the adverse effects it will have on
LP's ability to access her GP and other primary services if support is removed. She considers that it will
adversely impact upon her young daughter. LP is plainly in a very distressed and fragile state which the
support worker considers will deteriorate if her support is cut.  The evidence in NN's case also persuaded
me that he, too, would be at risk if his support is cut having regard in particular to his mental health issues.

17. Ms Wilsdon submitted that I should not grant interim relief. She said that it was possible to request an
extension of the 45-day period. The support duty is provided by the Salvation Army under contract to the
Home Office, and the Salvation Army subcontracts its role to other providers. Ms Wilsdon told me, and I
accept, that there is a contractual duty on the Salvation Army to make, and the Home office to consider,
such requests.  However, the problems with this submission struck me as follows:

a. There was no evidence in front of me. Obviously, I accepted so far as it went what Ms Wilsdon told me,
but her submissions were no substitute for proper evidence;

b. In particular, there was no evidence about the criteria that are applied in relation to requests for
extensions. Ms Wilsdon told me that a policy on extensions was currently being drafted, but was unable to
tell me more than that. It is therefore impossible to know what the outcome would be if LP and NN applied
for an extension.

18. I accepted that there will be financial consequences for the Defendant from the grant of interim relief.
However, when set against the potential harm to the Claimants, both of whom have been accepted by the
Defendant as having been trafficked and very badly mistreated, I was nonetheless satisfied that the
balance of prejudice came down in favour of the grant of relief.

19. For these reasons, I granted interim relief in the form recorded in the order which has the effect of
maintaining LP's and NN's current level of support until further order.

20. In relation to the grant of interim for all of these similarly situated, I accepted Ms Wilsdon's submission
that given the resource implications for making an order potentially affecting many hundreds (possibly into
the thousands) of persons, the Defendant should have the opportunity to file evidence. I therefore ordered
that the Defendant should file evidence within 14 days; the Claimants have seven days thereafter to reply;
and that there should be a rolled up permission and general interim relief hearing before the end of term
(15 April 2019). I ordered interim relief for all persons similarly situated to LP and NN until that date.

**End of Document**


-----

