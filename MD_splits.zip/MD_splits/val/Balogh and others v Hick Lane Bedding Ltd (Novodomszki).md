# Balogh and others v Hick Lane Bedding Ltd (Novodomszki)

**Date** 09/03/2021

**General damages (PSLA)** £50,000.00


**General Damages (PSLA)**
**Today's Value (incl SvC uplift*)**


£65,661.84


**Major injury** PTSD and mixed anxiety and depressive disorder

**Injury category** Psychiatric Damage Generally; Post Traumatic Stress Disorder

**Injury duration and prognosis**

Psychiatric Damage Generally

Post Traumatic Stress Disorder

**Facts**

The Claimant was a victim of modern slavery. His period of employment with the
Defendant was around three weeks. He was subjected to degrading work and working
conditions. The Claimant was diagnosed as suffering from a mixed anxiety and
depressive disorder, attributable to his experiences of modern slavery. The expert's
view was that the prognosis was good, especially if he underwent a brief course of
cognitive behavioural therapy. When he saw the second expert, which was nearly three
years later, he was continuing to suffer from mixed anxiety and depression, and at that
time he met the criteria for a diagnosis of mild post-traumatic stress disorder. His
condition had become chronic, but with treatment the expert expected an improvement
over a period of two years and suggested a phased return to work. Although the
Claimant's psychiatric injury was not as bad as those of his fellow Claimants, because
of the persistence of his symptoms and the relatively cautious prognosis he did not fall
into the 'less severe' bracket of either the PTSD or the general psychiatric damage
sections of the Judicial College Guidelines. The Claimant was in the 'moderate'
category. His period of modern slavery was around 21 days, meriting an award
somewhere between that of the other Claimants. Finally, the Claimant fell into the
middle Vento bracket. An appropriate global award was £50,000, to which the Court
added £5,000 for exemplary damages, making a grand total of general damages of
£55,000. Citation: [2021] EWHC 1140 (QB).

**Age at injury** 37 Year(s)

**Age at trial** 46

**Gender** Male

**Type of claim** Employers' Liability; Other; Criminal Injury; Psychiatric and Occupational Stress

**Total damages** £222,726.00

**Court** Queen's Bench Division

**Judge** Master Davison

**Contributor's firm** Lexis Nexis

**Notes**

The General Damages (PSLA) Today’s Value figure includes:

## • the Heil v Rankin uplift if the award was made on or before 23 March 2000
and is over £10,000 and

## • * the Simmons v Castle uplift. (If the award was made on or before 1 April
2013 or if the award was after 1 April 2013 and subject to a pre-1 April 2013
Conditional Fee Agreement, the Simmons v Castle uplift has been added by


-----

us except in mesothelioma cases. All other cases will have already had the
_Simmons v Castle uplift applied in the original damages award)._

For further details see our Flowchart: Quantum database general damages uplifts.


**End of Document**


-----

