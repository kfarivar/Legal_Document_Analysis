# R v AAB [2024] EWCA Crim 880

Court of Appeal, Criminal Division

Lord Justice Holroyde President Of The Court Of Appeal (Criminal Division), The Hon. Mrs Justice McGowan and
The Hon. Mrs Justice Steyn

26 July 2024Judgment

**Mr Daniel Bunting (instructed by Southwell & Partners) for the Applicant**

**Mr Daniel Pawson-Pounds (instructed by the CPS) for the Respondent**

Hearing date: 12 October 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 26 July 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives

(see eg https://www.bailii.org/ew/cases/EWCA/Civ/2022/1169.html).

.............................

**Mrs Justice McGowan:**

**Anonymity**

1. The Applicant seeks an anonymity order, the Respondent does not oppose the application. Anonymity
has already been granted provisionally to protect the position until the hearing. We make the order to
protect the interests of the proper administration of justice under s.11 of the Contempt of Court Act 1981.

2. The normal rule is open justice, but an anonymity order in the present case is strictly necessary,
pursuant to the principles identified in **_R v AAD and others_** **_[[2022] EWCA Crim 106 at [3] and [4] and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_**
summarised in Human Trafficking and Modern Slavery Law and Practice (2[nd] ed) (at 8.103-8.108).

3. We find the risk to the Applicant of being re-trafficked for criminal exploitation in the United Kingdom
("UK") is real. In passing sentence the Judge in the Crown Court said, “I cannot see…….. how you can
remain in this country and be anything other than subject to exploitation and put in a position where
sophisticated people are going to use you for their criminal ends”. Although that was some considerable
time ago, there is no reason to take a different view now.

4. Such an order is also consistent with (and so does not risk undermining) any anonymity orders made
previously in the immigration proceedings. Such orders are not determinative and there is no blanket rule
in favour of the making such orders in all trafficking cases but we find the risk in this case to be real.

**Introduction**


-----

5. We will refer to the Applicant as AAB. She was born in Vietnam on 5 January 1965. On 6 September
2007 (then aged 42) she pleaded guilty to an offence of Producing a Controlled Drug of Class C,
(cannabis) contrary to s 4(2)(a) of the Misue of Drugs Act 1971.

6. She was tried and acquitted by a jury of Being Concerned in a Money Laundering Arrangement,
[contrary to s328(1) of the Proceeds of Crime Act 2002 and Abstracting Electricity, contrary to s13 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y034-00000-00&context=1519360)
**Theft Act 1968.**

7. On 2 November 2007 she was sentenced by His Honour Judge Pugsley, (“the Judge”), in the Crown
Court sitting in Derby, to a term of 15 months imprisonment and she was recommended for deportation.

8. She applies for leave to appeal that conviction, for which she seeks an extension of time of 4659 days.
[She also applies for leave to adduce fresh evidence under s.23 of the Criminal Appeal Act 1968.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1KR-00000-00&context=1519360)

9. The fresh evidence is set out in a Gogana Affidavit dated 4 July 2020 from Ms Phillippa Southwell,
solicitor for AAB. We are grateful to her and to Mr Daniel Bunting who appears for AAB and Mr Daniel
Pawson-Pounds who acts for the Respondent. None of whom appeared in the original proceedings.

**Fresh Evidence**

10. The fresh evidence is described as follows:

i) The Reasonable Grounds decision (19 August 2015) and Conclusive Grounds decision (22 August
2016).

ii) The Sentencing Remarks dated 2 November 2007

iii) Court Documents

iv) Results of SAR from Derbyshire Police

v) Applicant's s.9 witness statement, dated 28 May 2020

vi) The psychiatric report of Dr Ghosh, dated 12 October 2019.

11. The Respondent accepts the admission of the fresh material, save the Applicant's witness statement
and the report of Dr Ghosh. We have considered all that material de bene esse.

12. This court gave directions on 11 July 2023, in preparation for the hearing. At that time the issue of the
Applicant's ability to give evidence was live. Following further consideration neither party requires the
Applicant to attend to give evidence and agree that her credibility can be determined on the papers.
Consequently the question of admissibility of any other fresh evidence relating to her ability to give
evidence or the need for an intermediary falls away.

13. The psychiatric assessment took place on 2 October 2019. The medical evidence in Dr Ghosh's report
can be summarised, without damage, to the following conclusions. The Applicant shows some of the
essential features of post-traumatic stress disorder, she shows evidence of “sub-average general
intellectual functioning” with limitations in her ability to communicate and “in self-direction”. Her specific
learning disability diminishes her ability to recount events in a “meaningful way”. She has had no formal
education and consequently is not capable of reading and writing.

**Facts of the Offending**

14. On 28 March 2007, police executed a search warrant at 10, St James Street, Buxton. They found 370
growing cannabis plants, there was also a substantial quantity of cropped cannabis. The electricity supply
had been tampered with to bypass the meter and was unsafe. During the search, AAB came to the
premises, tried to gain entry using a key and was arrested. She told police that she had no fixed address
and had only been in the UK for two days. Two mobile phones and a substantial amount of cash were
recovered from her.

15. In 2005 the Applicant had been cautioned for an offence of theft from a shop. On that occasion she
was served with an IS 151A form, warning her of her liability to removal, and released.


-----

**Crown Court and Subsequent Proceedings**

16. Given the length of time since the case was heard, the trial papers are no longer available. The
sentencing remarks have been retained as they were used in the immigration proceedings. Counsel has
made the usual requests under the McCook process and, unsurprisingly, counsel originally instructed have
no recollection of the detail of the case.

17. When AAB entered a plea of guilty to the offence of cultivating cannabis, she did that on a written
basis which was followed faithfully by the Judge in passing sentence. She said that she had come to the
UK looking for her daughter who had been abducted. She said she had travelled to Buxton looking for
work as a cleaner or child minder. She met a man, who promised to help her to find her daughter. She
went with him to the address in Buxton and stayed for a few days. At his request she tended the plants by
watering them and controlling the lighting. She recognised them as cannabis plants. The money found on
her at her arrest was the combination of personal savings and money borrowed from a friend.

18. It may be that the Judge saw the Applicant give evidence in the trial and formed a clear view of her. It
has not been possible to establish with certainty that she did give evidence on her own behalf but in any
event, the Judge made an assessment of her and the way in which she conducted herself. He said that he
could not form any view about the truth of her account of coming to the UK to look for her daughter but
described her life as an illegal immigrant as “pitiable”, she was vulnerable and being used as an “economic
slave” by “sophisticated gangsters” in the production of cannabis. He sentenced her to 15 months
imprisonment and recommended her for deportation. His decision to recommend deportation was based,
at least in part, on his belief that she would be further exploited in the UK.

19. A notice of intention to make a Deportation Order was served on her on 23 June 2008 and an order
was made on 4 July 2008. In reaction to that she claimed asylum on 10 July 2008, that was refused and
her appeal was dismissed on 15 October 2008. A Deportation Order was signed on 1 December 2008.

20. There were two further offences of theft by shoplifting in 2010, on the first occasion she was cautioned
again and on the other offence she was conditionally discharged.

21. On 23 February 2012 her application to be included in the Facilitated Returns Scheme to Vietnam was
approved, she refused to sign the papers and no further action seems to have been taken. As a result of a
complaint of rape made by the Applicant to the police on 13 August 2015, she was referred under the
National Referral Mechanism (“NRM”) and a Reasonable Grounds decision (“RG”) was made on 19 August
2015 accepting that she had been trafficked for the purpose of forced criminality.

22. Following further investigation a Conclusive Grounds decision (“CG”), was made on 22 August 2016.

23. Many issues about her credibility were raised in the CG, she had given various and sometimes
inconsistent accounts, however it was concluded, on the balance of probabilities, that the index offending
took place as a result of forced criminality. Her account of her travel from Vietnam, via China, to the UK
was not consistent. The author concluded that the issues around her credibility did not “outweigh the
particular circumstances of this incident”, (page 12 of 21). She was found to be a victim of **_modern_**
**_slavery._**

24. Although she was found to have been a victim of trafficking by the Competent Authority, it was decided
that she did not qualify for leave to remain in the UK as the circumstances supporting her status no longer
continued and she was therefore liable for removal.

25. She again claimed asylum, a Screening Interview took place on 4 January 2017, followed by a
Statement of Evidence Form (“SEF”) interview on 30 January 2017.

26. On 15 June 2020 she was granted leave to remain in the UK as a stateless person until 14 June 2025.
Her status after that date is uncertain.

**Legal Framework**

27. A plea of guilty does not deprive this court of jurisdiction to hear an appeal against conviction: R v Lee
**_(Bruce George) [1984] 1 W L R 578_**


-----

[28. The Modern Slavery Act 2015 created a defence under s.45:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

Admissibility of Fresh Evidence

[29. The test governing the admissibility of fresh evidence is set out in s.23 of the Criminal Appeal Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1KR-00000-00&context=1519360)
**1968. This court can accept fresh evidence if it is “necessary or expedient in the interests of justice”. The**
court must have regard to whether the evidence is “capable of belief”, whether it may “afford any ground for
allowing the appeal”, whether it would have been admissible in the proceedings at first instance and
whether there is good reason for its not having been adduced in those proceedings.

Change of Law

30. In **_R v S(G) [2018] EWCA Crim 1824 at [1] the court reviewed the position generally in light of a_**
change of law between the date of conviction and an appeal in cases of victims of trafficking.

_“Huge strides have been made, domestically and internationally, in recognising the evil of human_
_trafficking, in protecting victims of trafficking ("VOTs") and, where appropriate, shielding VOTs from_
_prosecution or penalties. However, as repeatedly made clear, where crimes have been committed by_
_VOTs, even arising from their own trafficking, there is no blanket immunity. Decisions are necessarily fact_
_sensitive, taking into account the public interest both in prosecuting alleged offenders and in protecting_
_VOTs. The present application gives rise to such considerations, made somewhat more complex by (put_
_neutrally for the moment) material developments in the law and practice since the time of the original trial_
_and the very lengthy Extension of Time ("EOT") sought.”_

The court also established principles to be applied in the approach to fresh evidence supporting the status
as a victim of trafficking at [66] to [69]

_“We have already outlined the fresh evidence which the Applicant seeks to adduce, …………..We have_
_also considered all the fresh evidence, de bene esse. We now express our conclusions._

_……..We have no real hesitation in granting the application to admit in evidence the FTT Decision, the CA_
_Minute and, for that matter, the Home Office Letter. Any analysis of this material and the weight to be_
_accorded to it are dealt with under Issue III._

_Applying s.23 of the 1968 Act, the receipt of this material is expedient in the interests of justice. Its essence_
_is the recognition, essentially undisputed by the Respondent, that the Applicant was a VOT. It would not be_
_in the interests of justice to proceed with the application (and any appeal) without having regard to the FTT_
_Decision and the CA Minute to this effect. The evidence is capable of belief; it may afford a ground for_
_allowing the appeal; it post-dates the trial and so could not have been adduced at trial._

_Before us, no question arises as to the admissibility of these materials as such. That is not the case as to_
_their admissibility at trial, where, to put it no higher, the admissibility of both the decisions in question and_
_the underlying reasoning must be regarded as unlikely on what may be broadly (if very loosely) described_
_as Hollington v Hewthorn [1943] KB 587 grounds._

_That said:_

_i) Had the FTT Decision and the CA Minute been available at the time of trial, we regard it as_
_overwhelmingly likely that, in the interests of justice and fairness, the Crown would have been required to_


-----

_make admissions as to their recognition of the Applicant as a VOT – so that, in practical terms, any_
_admissibility difficulties at trial would have been resolved._

_ii) Whatever the difficulties of admissibility at trial, we would not regard them as outweighing our_
_conclusion, on the basis of all the other relevant factors for the purposes of s.23, that the materials_
_comprising the First Part should be admissible before us. We proceed accordingly.”_

31. Further guidance on admissibility is provided in **_R v AAD_** **_[[2022] EWCA Crim 106. A conclusive](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_**
Grounds Decision may be admissible on appeal, even though it would not have been admissible in the
court below.

**Ground of Appeal**

32. Mr Bunting concedes that this is a “change of law” case. He accepts that he has to show a risk of
substantial injustice.

33. He submits that her conviction is unsafe on the following ground.

_In the circumstances as they are now known, the applicant was a victim of trafficking compelled into_
_committing the offence and, in light of the fresh evidence and the subsequent authorities, the prosecution_
_was not in the public interest and should not have been prosecuted to a conviction._

He submits that there is a clear nexus between her status as a victim of trafficking and her involvement in
the offending.

34. He relies on the Applicant's own account of her travel to the UK and her involvement in the offending.
He accepts that her account is properly the subject of some criticism but points out that she was a
Vietnamese National who did not have English as her first language, she has had no formal education, she
has a learning disability and shows some signs of PTSD.

35. He starts from the views expressed in the sentencing remarks. He submits that this court should be
reluctant to disagree with the view of the trial Judge who saw and heard her. His view that she was
compelled by sophisticated criminals who treated her as an “economic slave”. Additionally he relies upon
the CG decision to support the argument that she behaved as she did because she was “compelled” to do
so. He recognises the questions around her reliability, but he relies on her limited understanding and, even
if the court does not admit the medical evidence, it can still accept that her inconsistencies do not
necessarily undermine the force of the core proposition that she was a victim of trafficking and compelled
to act as she did.

36. He submits that the fact of her conviction and a sentence of over 12 months means that she remains
liable to deportation which would lead to a substantial injustice, MA (Pakistan) v SSHD [2019] EWCA Civ
**_1252. She only has leave to remain until June 2025._**

37. He argues that the necessary, very lengthy extension of time should be granted. In summary the
Applicant was not aware that she might have a defence until advised by solicitors acting for her in her
immigration and asylum matters.

38. Mr Pawson-Pounds argues that this court is not bound to accept the CG decision that the Applicant
was a victim of trafficking but should look behind the decision and consider the evidence in support with
care. Particularly, given that the Applicant herself is the source of that evidence and there are reasons to
doubt her credibility. In any event he argues, even if she was a victim of trafficking at the time of the
offending there was no sufficient nexus between her status and the commission of the offence.

39. He submits that as this is change of law case, basic principle requires that the Applicant can show a
substantial injustice. He argues there is no risk of substantial injustice.

40. He concedes that this is a finely balanced case. He maintains that it was in the public interest to
prosecute the Applicant. Further that the prosecution would be brought now, notwithstanding the
contemporary requirements on the CPS to review the position in such cases.


-----

41. He says that the Respondent has given very careful consideration to the new material and still invite
the court not to take the CG decision as determinative of the Applicant's status at the time of the offending.
He relies principally on the problems and weaknesses around the applicant's credibility. He points out that
her account about the time she spent in the UK before the offending varies and is internally inconsistent
and unreliable. She had keys to the premises and was in the process of letting herself in when she was
arrested. Even if the medical evidence establishes that she has learning difficulties and suffers from posttraumatic stress disorder, the inconsistencies sufficiently damage her account to the point that it should not
be relied upon.

42. Further, he argues that there is no sufficient basis for finding a substantial injustice, he points out that
the conviction itself would not be sufficient and as yet, it has not yet had any impact on her right to remain
in the UK.

43. The Respondent is neutral as to the application for the extension of time.

**Discussion**

[44. Parliament passed the Modern Slavery Act 2015 in recognition of the consequences in the UK of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
international problem of trafficking of individuals by criminals to be used in the furtherance of their criminal
activity. It created a statutory framework which set out a defence based on the compulsion to take part in
criminal activity in the specific circumstances of trafficking. It did not provide retrospective protection. It
does not provide blanket immunity to the victims of trafficking.

45. The principles to be followed by the courts in cases which predate the Act were set out in R v Joseph
**_& ors [2017] EWCA Crim 36. At [20] Lord Thomas CJ said,_**

_“The judgments in these cases established the legal regime in domestic law to give effect to the_
_international obligations we have set out:_

_i) The obligation under Article 26 of the Council of Europe Convention is given effect in England and Wales_
_through (1) the common law defences of duress and necessity or (2) guidance for prosecutors on the_
_exercise of the discretion to prosecute (which has been revised from time to time) or (3) the power of the_
_court to stay a prosecution for abuse of process (see R v M(L), B(M) and G(D), 2010 at paragraphs 7-12)_

_ii) In a case where (a) there was reason to believe the defendant who had committed an offence had been_
_trafficked for the purpose of exploitation, (b) there was no credible common law defence of duress or_
_necessity but (c) there was evidence the offence was committed as a result of compulsion arising from_
_trafficking, the prosecutor has to consider whether it is in the public interest to prosecute. (See: R v M(L),_
_B(M) and G(D), 2010 at paragraph 10.)_

_iii) The court's power to stay is a power to ensure that the State complied with its international obligations_
_and properly applied its mind to the possibility of not imposing penalties on victims. If proper consideration_
_had not been given, then a stay should be granted, but where proper consideration had been given, the_
_court should not substitute its own judgment for that of the prosecutor (see R v M(L), B(M) and G(D), 2010)_
_at paragraph 19)._

_iv) Where this court concludes that the trial court would have stayed the indictment had an application been_
_made, the proper course is to quash the conviction, (see R v M(L), B(M) and G(D), 2010) at paragraph 17)._

_v) The obligation under Article 26 does not require a blanket immunity from prosecution for victims of_
_trafficking. Various factors should be taken into account in deciding whether to prosecute; if there is no_
_reasonable nexus of connection between the offence and the trafficking, generally a prosecution should_
_proceed. If some nexus remained, then prosecution would depend on various factors including the gravity_
_of the offence, the degree of continuing compulsion and the alternatives reasonably available to the_
_defendant. Each case was fact specific. (See R v M(L), B(M) and G(D), 2010 at paragraph 13-14)._

_vi) The distinct question for decision in the case of a trafficked defendant is the extent to which the offences_
_with which he is charged (or of which he has been found guilty) are integral to or consequent on the_


-----

_exploitation of which the person was a victim (see R v L(C), N, N & T, 2013, at paragraph 33). The court_
_made clear such a decision is a fact sensitive one:_

_"We cannot be prescriptive. In some cases the facts will indeed show that he was under levels of_
_compulsion which mean that, in reality, culpability was extinguished. If so, when such cases are_
_prosecuted, an abuse of process submission is likely to succeed. That is the test we have applied in these_
_appeals. In other cases, more likely in the case of a defendant who is no longer a child, culpability may be_
_diminished but nevertheless be significant. For these individuals prosecution may well be appropriate, with_
_due allowance to be made in the sentencing decision for their diminished culpability. In yet other cases, the_
_fact that the defendant was a victim of trafficking will provide no more than a colourable excuse for_
_criminality which is unconnected to and does not arise from their victimisation. In such cases an abuse of_
_process submission would fail."_

_vii) The reason why the criminality or culpability of a trafficked person is diminished or extinguished does_
_not result merely from age but in circumstances where there has been no realistic alternative available to_
_the person but to comply with the dominant force of another individual or group of individuals (see R v L(C),_
_N, N & T, 2013 at paragraph 13)._

_viii) The decision of the competent authority as to whether a person had been trafficked for the purposes of_
_exploitation is not binding on the court but, unless there was evidence to contradict it or significant_
_evidence that had not been considered, it is likely that the criminal courts will abide by the decision (see R_
_v L(C), N, N & T, 2013 at paragraph 28).”_

46. As in **_R v S(G), we would have had no hesitation in admitting the CG decision, had it not been_**
conceded.

47. Applying the principles in R v Joseph to the specific facts of this case, we ask ourselves the following
questions,

i) Is there reason to believe that the Applicant had been trafficked for the purposes of exploitation?

ii) Is there reason to believe that the offence was committed as a result of compulsion arising from that
trafficking, integral to or consequent on the exploitation, in other words, is there sufficient nexus?

iii) Was there any realistic alternative open to the Applicant?

iv) If an application had been made to the Crown Court would the court have stayed the indictment?

v) Whilst we are not bound by the CG decision, is there material which contradicts it or was not
considered, and should we follow it?

48. We do find that the Applicant was trafficked for the purposes of exploitation in the criminal enterprise of
the cultivation of cannabis. We are not bound by the Judge's conclusions to that effect, nor by the CG
decision but we can find no reason to disagree and, in any event, would have reached the same
conclusion.

49. She was an illiterate woman from Vietnam. She has a learning disability and shows some symptoms of
PTSD. She was found to be caring for a cannabis crop and whilst she had a key to the premises and some
cash, there was no reason to think that she was anything other than at the lowest level being used in its
cultivation.

50. She did give a number of inconsistent accounts about the circumstances of how and why she had
come to the UK and how long she had been involved in the activity. It is trite to say that the victims of
trafficking often lie about how they come to be involved in such criminal activity. They are frightened of
those who exploited them and they do not trust the authorities. Her inconsistency is important but does not
necessarily disprove the elements of trafficking.

51. If, as we find, she was trafficked for the purposes of exploitation then did she have any alternative but
to comply? The recognition by the authorities of the risk of trafficking was much lower in 2007. The Modern
**_Slavery Act did not act as a prompt to the authorities to consider the question. The Judge who heard the_**


-----

case found that she had no option but to comply. Again his view does not bind this court but, in the
absence of any material to contradict it, we accept his conclusions as fair and realistic.

52. It follows that we should conclude that if an application had been made to the court, the Judge would
have accepted that the case should be stayed.

53. We admit the fresh evidence as agreed by the Respondent. Dealing with the areas of dispute, namely
the report of Dr Ghosh and the Applicant's own statement, we do find that the medical evidence is capable
of belief. The Respondent accepts that it could have been admissible in the trial on the counts on which
she was acquitted. In reality it would have been admissible if the applicant had been able to raise a
defence under s.45 of the Modern Slavery Act to assist in determining whether she had an alternative but
to comply. In considering whether it may afford her a ground of appeal, again, Mr Pawson-Pounds properly
and fairly concedes that it is material which is properly available to the court.

54. The contents of the Applicant's statement were available at the trial and, in any event, might well not
pass any of the other criteria in s.23. However her statement does not add anything of value to the issues
to be decided in this appeal. We do not admit it.

55. There is an arguable ground of appeal and there are acceptable reasons for the delay in all the
circumstances of this case. We grant the necessary extension of time. We grant leave. We emphasise the
importance of compliance with time requirements but this is an unusual case on its facts and there is merit
in the ground.

56. This is a finely balanced case. We conclude, however, that there is a sound basis for accepting that
the Appellant was compelled to commit the offence by virtue of her having been trafficked for the purposes
of being exploited in the commission of crime. We are satisfied that her conviction is therefore unsafe.

57. Accordingly we allow the appeal and quash the conviction.

**End of Document**


-----

