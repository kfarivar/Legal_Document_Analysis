ER (D) 13 (Mar)

# R (on the application of QSA and others) v Secretary of State for the Home
 Department and another [2018] EWHC 407 (Admin)

Queen's Bench Division, Administrative Court (London)

Holroyde LJ and Nicola Davies J

2 March 2018Judgment

**Karon Monaghan QC & Keina Yoshida (instructed by Birnberg Peirce Ltd) for the Claimants**

**Kate Gallafent QC & Christopher Knight (instructed by** **Government Legal Department) for the**
**Defendants**

Hearing dates: 17th, 18th January 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Holroyde:**

1. This is the judgment of the court, to which we have both contributed.

2. The first and third claimants each have the benefit of an order that their names be anonymised in these
proceedings. No such order was sought by the second claimant.

3. Each of the three claimants has been convicted, many years ago, of multiple offences of loitering or
soliciting in a street or public place for the purpose of prostitution, contrary to section 1 of the Street
Offences Act 1959. Those convictions, notwithstanding the passage of time, remain on their records; and
the claimants are required to disclose them, and to obtain verification of their disclosure, if they apply to
work or volunteer within particular occupations. They contend that the recording and retention of
information concerning their convictions, and the operation of the statutory provisions which require them
to disclose those convictions if seeking particular types of employment, are unlawful.

4. The proceedings are brought against the defendants as the authorities responsible for matters of policy
in relation to the criminal law, and for the recording of criminal offences and the operation of the Disclosure
and Barring Service (“DBS”).

5. We record at the outset our gratitude to counsel for their helpful written and oral submissions.

**The facts:**

6. The convictions which are primarily relevant for present purposes are those for offences contrary to
section 1 of the 1959 Act, to which I shall refer for convenience as “soliciting”. Insofar as any of the
claimants has any other criminal convictions, they are for offences which were not particularly serious, and
their only relevance is with regard to the operation of the multiple convictions rule (as to which, see below).

7.  The witness statements of the claimants paint a grim picture of the circumstances in which they
committed their soliciting offences, of their vulnerability when first required or persuaded by “boyfriends” to
prostitute themselves and of the violence and abuse to which they were subjected at the hands of the men


-----

ER (D) 13 (Mar)

who groomed, trafficked and prostituted them. The first claimant was put to prostitution when she was only
14 years old and subject to a care order, and she was first convicted of soliciting offences at the age of 16.
The second claimant was put to prostitution at the age of 15, and was just 17 when convicted for the first
time of a soliciting offence. The third claimant was a little older, but still only 18, when groomed into
prostitution, and was aged 21 when first convicted of a soliciting offence. The evidence of both the first and
the second claimant shows them to have entered into prostitution when they were, in law, too young to
consent to any sexual activity. Those who procured them to have sexual intercourse with others, when
they were below the age of majority, committed criminal offences contrary to section 23 of the Sexual
Offences Act 1956. Thus in those instances, the first and second claimants were themselves victims of
crime in relation to the activity which resulted in their own convictions of soliciting offences. Having read
their evidence, and the evidence of other witnesses who have similar forlorn histories to relate, I have no
difficulty in accepting that all three claimants have, even as adults, been victims in many other ways.

8. Ms Monaghan QC for the claimants emphasises that each complainant succeeded in removing herself
from prostitution many years ago. Again, I have no difficulty in accepting that it is greatly to their credit that
they did so, despite the many difficulties they have faced in making their exits. The 50 soliciting offences of
which the first claimant has been convicted were committed over a period of 8 years, the last conviction
being in 1998. In the second claimant's case, the 49 soliciting offences of which she has been convicted
were committed over a period of 3 years, the last conviction being in 1988. In the third claimant's case, the
9 soliciting offences of which she has been convicted were committed over a period of 4 years, the last
conviction being in 1992. In relation to each of them, the penalties imposed for the soliciting offences were
almost always fines, with conditional orders of discharge being made on a few occasions.

9. Although the offences were committed long ago, and the penalties imposed were comparatively minor,
the convictions of soliciting offences have continuing consequences for each of the claimants. They are
not statutorily barred from working with children or vulnerable adults, but the effect of the relevant statutory
provisions is that, throughout their lives, the claimants must disclose their convictions if they apply for
certain types of employment, or seek to assist as a volunteer in such types of employment, and must
obtain a certificate verifying any such disclosure. The claimants contend that it is unlawful to require them
to do so, and that the operation of the statutory provisions both exposes them to unfair embarrassment and
places them at an unfair handicap in obtaining employment of the kind which they, and many other women
in similar positions, are likely to seek. It also acts as a deterrent to their applying for such employment. As
will be seen, the adverse consequences of which the claimants complain arise because they have each
been convicted of more than one soliciting offence. They contend that it is unremarkable, having regard to
the nature of the soliciting offence and to the unhappy and difficult personal circumstances which often
apply to those women who enter prostitution, that they should be convicted more than once of soliciting.
They submit that in this respect also, the legislative provisions have an unfair effect and are unlawful.

10. It is accordingly necessary to consider aspects of the statutory provisions relating to the recording of
criminal offences and the extent to which a person applying for employment is required to disclose criminal
convictions.

**The legislative framework:**

11. Section 1 of the Street Offences Act 1959, as amended, provides as follows:

“1 Loitering or soliciting for purposes of prostitution.

(1) It shall be an offence for a person aged 18 or over (whether male or female) persistently to loiter or
solicit in a street or public place for the purpose of prostitution.

(2) A person guilty of an offence under this section shall be liable on summary conviction to a fine of an
amount not exceeding level 2 on the standard scale, or, for an offence committed after a previous
conviction, to a fine of an amount not exceeding level 3 on that scale.


-----

ER (D) 13 (Mar)

(2A) The court may deal with a person convicted of an offence under this section by making an order
requiring the offender to attend three meetings with the person for the time being specified in the order
(“the supervisor”) or with such other person as the supervisor may direct.

(2B) The purpose of an order under subsection (2A) is to assist the offender, through attendance at those
meetings, to—

(a) address the causes of the conduct constituting the offence, and

(b) find ways to cease engaging in such conduct in the future.

(2C) Where the court is dealing with an offender who is already subject to an order under subsection (2A),
the court may not make a further order under that subsection unless it first revokes the existing order.

(2D) If the court makes an order under subsection (2A) it may not impose any other penalty in respect of
the offence.

(3) . . . . . .

(4) For the purposes of this section

(a) conduct is persistent if it takes place on two or more occasions in any period of three months;

(b) any reference to a person loitering or soliciting for the purposes of prostitution is a reference to a person
loitering or soliciting for the purposes of offering services as a prostitute;

(c) “street” includes any bridge, road, lane, footway, subway, square, court, alley or passage, whether a
thoroughfare or not, which is for the time being open to the public; and the doorways and entrances of
premises abutting on a street (as hereinbefore defined), and any ground adjoining and open to a street,
shall be treated as forming part of the street.”

12. It should be noted that, at present, level 2 on the standard scale is a fine not exceeding £500, and
level 3 is a fine not exceeding £1,000; see section 37 of Criminal Justice Act 1982.

13. Thus in its present form, the offence of soliciting contrary to section 1 of the 1959 Act can be
committed by either a man or woman. The position was however different in this regard at the time when
the claimants were convicted of their offences. As originally enacted, the section – in material part –
provided as follows:

“1  Loitering or soliciting for purposes of prostitution.

(1) It shall be an offence for a common prostitute to loiter or solicit in a street or public place for the
purpose of prostitution.

(2) A person guilty of an offence under this section shall be liable, on summary conviction, to a fine not
exceeding ten pounds or, for an offence committed after a previous conviction, to a fine not exceeding
twenty-five pounds or, for an offence committed after more than one previous conviction, to a fine not
exceeding twenty-five pounds or imprisonment for a period not exceeding three months or both.”

Caselaw established that this was an offence which could only be committed by a woman: see, eg, R v De
_Munck_ _[[1918] 1 KB 635.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FFN0-TWXJ-217M-00000-00&context=1519360)_

14. It is not surprising that the offence as originally enacted could only be convicted by a woman, because
in 1959 there was already an offence which could only be committed by a man: section 32 of the Sexual
Offences Act 1956 provided 
“Solicitation

32. It is an offence for a man persistently to solicit or importune in a public place for immoral purposes.”

15. Although the offence of soliciting contrary to section 1 of the 1959 Act can now be committed by either
a man or a woman, it is an important part of the claimants' case that in practice the offence is
overwhelmingly likely to be committed by women As we explain in more detail below the claimants'


-----

ER (D) 13 (Mar)

evidence shows that in the decade after the offence ceased to be gender-specific, around 98% of all those
convicted or cautioned for an offence of soliciting contrary to section 1 of the 1959 Act were women.

16. Turning to the recording of criminal convictions, and the obligation to disclose criminal convictions in
certain circumstances, section 27 of the Police and Criminal Evidence Act 1984 (as amended) provides in
material part –

“(4) The Secretary of State may by regulations make provision for recording in national police records
convictions for such offences as are specified in the regulations.

(4A) In subsection (4) 'conviction' includes –

a. a caution within the meaning of Part 5 of the Police Act 1997; and

b. a reprimand or warning given under section 65 of the Crime and Disorder Act 1998.”

17. It is appropriate to begin by noting that in general, the offences which may be recorded in national
police records are those which are punishable by imprisonment. However, by virtue of the National Police
[Records (Recordable Offences) Regulations 1985, SI 1985/1941, convictions for offences under section 1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-D940-TX08-71FV-00000-00&context=1519360)
of the 1959 Act were made recordable even though they were punishable only with a fine, and not with
imprisonment. Those Regulations were revoked and replaced (and their ambit extended to include formal
police cautions and similar sanctions) by the National Police Records (Recordable Offences) Regulations
[2000, SI 2000/1139, paragraph 3 of which provides –](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-24D0-TX08-H0MX-00000-00&context=1519360)

“(1) There may be recorded in national police records
(a) convictions for; and

(b) cautions, reprimands and warnings given in respect of,

any offence punishable with imprisonment and any offence specified in the Schedule to these
Regulations.”

Paragraph 50 of the Schedule specifies offences of soliciting contrary to section 1 of the 1959 Act.
Convictions and cautions for soliciting offences are therefore recorded on the Police National Computer
(“PNC”) and so may come within the statutory provisions as to disclosure of convictions.

18. Those provisions are contained in the _[Rehabilitation of Offenders Act 1974. At common law, an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
employer could ask an applicant for employment whether he or she had been convicted of a criminal
offence. The applicant could choose not to answer such a question, but would no doubt be at risk of an
adverse inference being drawn from that failure to answer. If the applicant chose to answer the question,
he or she was under a duty to answer it honestly, and therefore to disclose any convictions. The 1974 Act
changed that position by introducing the concept that after a period of time, a criminal conviction becomes
“spent”, and the convicted person becomes “rehabilitated”.  When a rehabilitated person applies for
employment the Act (subject to exceptions) exempts him or her from any duty to disclose spent
conviction(s), and prohibits an employer from making a decision prejudicial to the applicant on the grounds
of non-disclosure of the spent conviction(s). The drafting of the Act, and of Regulations made under it,
gives effect to that broad scheme by a series of exemptions overlaid with exceptions and modifications. It
is therefore necessary to consider the detail of the provisions which are relevant to the issues in this case.

19. The Act contains separate, parallel provisions for England and Wales and for Scotland. Only the
former provisions are relevant in this case. So far as is material for present purposes, section 4 of the Act
provides as follows:

“4. - Effect of rehabilitation.

(1) Subject to sections 7 and 8 below, a person who has become a rehabilitated person for the purposes of
this Act in respect of a conviction shall be treated for all purposes in law as a person who has not
committed or been charged with or prosecuted for or convicted of or sentenced for the offence or offences


-----

ER (D) 13 (Mar)

which were the subject of that conviction; and, notwithstanding the provisions of any other enactment or
rule of law to the contrary, but subject as aforesaid—

(a) no evidence shall be admissible in any proceedings before a judicial authority exercising its jurisdiction
or functions in England and Wales to prove that any such person has committed or been charged with or
prosecuted for or convicted of or sentenced for any offence which was the subject of a spent conviction;
and

(b) a person shall not, in any such proceedings, be asked, and, if asked, shall not be required to answer,
any question relating to his past which cannot be answered without acknowledging or referring to a spent
conviction or spent convictions or any circumstances ancillary thereto.

(2) Subject to the provisions of any order made under subsection (4) below, where a question seeking
information with respect to a person's previous convictions, offences, conduct or circumstances is put to
him or to any other person otherwise than in proceedings before a judicial authority—

(a) the question shall be treated as not relating to spent convictions or to any circumstances ancillary to
spent convictions, and the answer thereto may be framed accordingly; and

(b) the person questioned shall not be subjected to any liability or otherwise prejudiced in law by reason of
any failure to acknowledge or disclose a spent conviction or any circumstances ancillary to a spent
conviction in his answer to the question.

(3) Subject to the provisions of any order made under subsection (4) below,

(a) any obligation imposed on any person by any rule of law or by the provisions of any agreement or
arrangement to disclose any matters to any other person shall not extend to requiring him to disclose a
spent conviction or any circumstances ancillary to a spent conviction (whether the conviction is his own or
another's); and

(b) a conviction which has become spent or any circumstances ancillary thereto, or any failure to disclose a
spent conviction or any such circumstances, shall not be a proper ground for dismissing or excluding a
person from any office, profession, occupation or employment, or for prejudicing him in any way in any
occupation or employment.

(4) The Secretary of State may by order—

(a) make such provision as seems to him appropriate for excluding or modifying the application of either or
both of paragraphs (a) and (b) of subsection (2) above in relation to questions put in such circumstances
as may be specified in the order;

(b) provide for such exceptions from the provisions of subsection (3) above as seem to him appropriate, in
such cases or classes of case, and in relation to convictions of such a description, as may be specified in
the order.”

20. By an amendment which came into effect in 2008, paragraph 3 of schedule 2 to the Act makes similar
provision where a person has not been convicted, but has been given a formal police caution for an
offence.

21. Section 5 of the 1974 Act prescribes rehabilitation periods for particular offences. Life imprisonment,
custodial terms of more than 4 years and certain other custodial sentences are excluded from rehabilitation
and thus never become spent. In relation to other sentences and orders, the relevant rehabilitation periods
are set out in a table. The rehabilitation periods vary according to whether the person convicted was an
adult or was aged under 18 at the date of the conviction. For an adult whose sentence is a fine, the end of
the rehabilitation period is “the end of the period of 12 months, beginning with the date of the conviction in
respect of which the sentence is imposed”. For an adult whose sentence is a “relevant order”, the end of
the rehabilitation period is “the day provided for, by, or under the order at the last day on which the order is
to have effect”. By section 5(8), orders which are a “relevant order” for this purpose include an order
discharging a person conditionally for an offence, and an order under section 1(2A) of the Street Offences


-----

ER (D) 13 (Mar)

Act 1959.  By section 5(4), there is no rehabilitation period for an order discharging a person absolutely
for an offence, and where such an order is made “references in this Act to any rehabilitation period are to
be read as if the period of time were nil”.

22. The effect of these provisions is that if a person is asked questions about his or her previous
conviction or cautions, the question is to be treated as not relating to spent convictions or cautions, and the
person concerned is exempted from any liability by reason of a failure to disclose a spent conviction or
caution. Similarly, neither a spent conviction or caution, nor a failure to disclose it, can be a proper ground
for excluding or dismissing a person from any occupation or employment, or for prejudicing him or her in
anyway in any occupation or employment. These protections are, however, subject to the provisions of
any order made by the Secretary of State for Justice pursuant to section 2(4).

23. Relevant to the present case is the _[Rehabilitation of Offenders Act 1974 (Exceptions) Order 1975,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
which came into effect on the same day as the 1974 Act itself. Article 3 of the Order provides that neither
section 4(2) of, nor paragraph 3(3) of schedule 2 to, the 1974 Act (relating to convictions and cautions
respectively) shall apply to questions asked in order to assess the suitability of a person for admission to
certain professions, or for certain offices or employments which are listed in schedule 1 to the Order (and
which include, by paragraph 12, any office or employment which is concerned with the provision of care
services to vulnerable adults, and by paragraph 14B, any employment at a children's home or residential
family centre). Nor shall they apply to –

“(aa) any question asked by or on behalf of any person, in the course of the duties of his work, in order to
assess the suitability of the person to work with children, where –

(i)the question relates to the person whose suitability is being assessed …

and where the person to whom the question relates is informed at the time the question is asked that, by
virtue of this Order, spent convictions are to be disclosed.”

Corresponding provision is made in article 4 of the Order disapplying section 4(3)(b), and paragraph 3(5) of
schedule 2, of the Act in relation to dismissal or exclusion of a person from such occupations or
employments.

24. Until 2013, articles 3 and 4 of the 1975 Order disapplied the relevant provisions of the 1974 Act in
relation to any spent conviction or caution. By amendments which came into effect in 2013, a category of
“protected” cautions and convictions was introduced. By articles 3(2) and 4(2), the provisions of articles 3
and 4 – subject to exceptions which are irrelevant for present purposes – do not apply in relation to a
protected conviction or caution. In material part, article 2A provides as follows:

“2A.

(1) For the purposes of this Order, a caution is a protected caution if it was given to a person for an offence
other than a listed offence and 
(a) where the person was under 18 years at the time the caution was given two years or more have passed
since the date on which the caution was given; or

(b) where the person was 18 years or over at the time the caution was given, six years or more have
passed since the date on which the caution was given.

(2) For the purposes of this Order, a person's conviction is a protected conviction if the conditions in
paragraph (3) are satisfied and –

(a) where the person was under 18 years at the time of the conviction, five years and six months or more
have passed since the date of the conviction; or

(b) where the person was 18 years or over at the time of the conviction, 11 years or more have passed
since the date of the conviction.

(3) The conditions referred to in paragraph (2) are that –


-----

ER (D) 13 (Mar)

(a) the offence of which the person was convicted was not a listed offence;

(b) no sentence mentioned in paragraph (4) was imposed in respect of the conviction; and

(c) the person has not been convicted of any other offence at any time.

(4) The sentences referred to in paragraph (3)(b) are –

(a) a custodial sentence, and

(b) a sentence of service detention,

within the meaning of section 5(8) of the Act, as to be substituted by section 139(1) and (4) of the Legal
Aid, Sentencing and Punishment of Offenders Act 2012.”

25. The effect of these provisions is that, in relation to a protected conviction or caution, the person
concerned again has the benefit of the exemptions provided by the 1974 Act. An offence of soliciting
contrary to section 1 of the 1959 Act is not a “listed offence”, and so a person convicted of a single such
offence would, after the passage of the relevant period of time, have the benefit of the 1974 Act. But
where the person concerned has been convicted at another time of any other offence or offences, the
effect of article 2A(3)(c) is that the soliciting conviction cannot be a protected conviction. This is what has
been referred to in the course of the case as the “multiple conviction rule”. It catches the claimants and,
they argue, catches many other women who have entered into prostitution in circumstances where their
vulnerability made it likely that they would be convicted of more than one offence of soliciting.

26. As Ms Gallafent QC points out on behalf of the defendants, the multiple conviction rule applies
whatever the nature of the convictions: it is not only a conviction of a further soliciting offence which would
prevent an earlier soliciting offence from being a protected conviction. That has potential consequences
for the claimants, each of whom has in the past been convicted of at least one offence which was not an
offence of soliciting. More generally, we note that it also means that a single conviction of soliciting, in
itself a protected conviction, would become liable to disclosure if years later the individual concerned was
convicted of an entirely different type of offence.

27. Part V of the Police Act 1997 introduced a statutory scheme for the disclosure of criminal records, and
in some cases of other information, where it is required for the purpose of assessing the suitability of an
applicant for certain categories of posts or positions (broadly, employment with children or vulnerable
adults, or employment which requires a high degree of trust). Certain categories of employer who work
with children and vulnerable persons may be registered as persons permitted to ask “exempted questions”
relating to the applicant's suitability. If an individual applies for a criminal record certificate, and a
registered person certifies that it is required for the purposes of an exempted question, the DBS must issue
an appropriate certificate, which may take one of two forms.

28. Sections 113A and 113B of the Police Act 1997 have the effect that a person who applies for such
employment, and who will have to answer a question about previous convictions or cautions, must apply to
the DBS for either a Criminal Record Certificate (“CRC”) or an Enhanced Criminal Record Certificate
(“ECRC”). The difference between the two is that the former provides details only of convictions or
cautions, whereas the latter may also provide information which the relevant chief officer of police
reasonably believes to be relevant. So far as material for present purposes, the sections provide (in
relation to England and Wales) as follows:

“113A Criminal record certificates

1) DBS must issue a criminal record certificate to any individual who 
a) makes an application,

aa) is aged 16 or over at the time of making the application, and

b) pays in the prescribed manner any prescribed fee.

2) The application must


-----

ER (D) 13 (Mar)

a) be countersigned by a registered person, and

b) be accompanied by a statement by the registered person that the certificate is required for the purposes
of an exempted question.

……

3) A criminal record certificate is a certificate which –

a) gives the prescribed details of every relevant matter relating to the applicant which is recorded in central
records, or

b) states that there is no such matter.

5) DBS may treat an application under this section as an application under section 113B if –

a) in its opinion the certificate is required for a purpose prescribed under subsection (2) of that section,

b) the registered person provides it with the statement required by that subsection, and

c) the applicant consents and pays to DBS the amount (if any) by which the fee payable in relation to an
application under that section exceeds the fee paid in relation to the application under this section.

6) In this section –

“central records” means such records of convictions and cautions held for the use of police forces generally
as may be prescribed;

“exempted question” means a question which

a) so far as it applies to convictions, is a question in relation to which section 4(2)(a) or (b) of the
Rehabilitation of Offenders Act 1974 (effect of rehabilitation) has been excluded by an order of the
Secretary of State under section 4(4) of that Act; and

b) so far as it applies to cautions, is a question to which paragraph 3(3) or (4) of Schedule 2 to that Act has
been excluded by an order of the Secretary of State under paragraph 4 of that schedule;

“relevant matter”, in this section as it has effect on England and Wales, means –

a) in relation to a person who has one conviction only –

i) a conviction of an offence within subsection (6D);

ii) a conviction in respect of which a custodial sentence or a sentence of service detention was imposed;
or

iii) a current conviction

b) in relation to any other person, any conviction;

c) a caution given in respect of an offence within

subsection (6D);

d). a current caution.”

……

113B Enhanced criminal record certificates

(1) DBS must issue an enhanced criminal record certificate to any individual who –

a) makes an application,

aa) is aged 16 or over at the time of making the application, and

b) pays in the prescribed manner any prescribed fee.


-----

ER (D) 13 (Mar)

2) The application must 
a) be countersigned by a registered person, and

b) be accompanied by a statement by the registered person that the certificate is required for the purposes
of an exempted question asked for a prescribed purpose.

……

3) An enhanced criminal record certificate is a certificate which 
a) gives the prescribed details of every relevant matter relating to the applicant which is recorded in central
records and any information provided in accordance with subsection (4), or

b) states that there is no such matter or information.

4) Before issuing an enhanced criminal record certificate DBS must

request any relevant chief officer to provide any information which

a) the chief officer reasonably believes to be relevant for the purpose described in the statement under
subsection (2), and

b) in the chief officer's opinion ought to be included in the certificate.

……

7) DBS may treat an application under this section as an application

under section 113A if in its opinion the certificate is not required for

purpose prescribed under subsection (2).

……

9) In this section –

_“central records”, “exempted question” and “relevant matter” have the same meaning as in section 113A:_

_“relevant chief officer” means any chief officer of a police force who is identified by DBS for the purposes of_
making a request under subsection (4).”

29. In relation to both these sections, it may be noted that in s113A(6), paragraph (b) of the definition of
“relevant matter” reflects the multiple conviction rule.

[30. In challenging these statutory schemes, Ms Monaghan relies on the provisions of the Human Rights](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[Act 1998. Section 3 of that Act requires that, so far as it is possible to do so, primary and secondary](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
legislation must be read and given effect in a way which is compatible with the rights listed in the European
Convention on Human Rights (“ECHR”) and set out in schedule 1 to the Act. By section 6, it is unlawful for
a public authority to act in a way which is incompatible with a Convention right. By section 7 –

“(1) A person who claims that a public authority has acted (or proposes to act) in a way which is made
unlawful by section 6(1) may –

a. bring proceedings against the authority under this Act in the appropriate court or tribunal, or

b. rely on the Convention right or rights concerned in any legal proceeding,

but only if he is (or would be) a victim of the unlawful act.”

In the circumstances of the present case, involving convictions recorded many years ago, it is relevant to
note section 22(4):

“(4) Paragraph (b) of subsection (1) of section 7 applies to proceedings brought by or at the instigation of a
public authority whenever the act in question took place; but otherwise that section does not apply to an act
taking place before the coming into force of that section.”


-----

ER (D) 13 (Mar)

31. It is convenient to set out here the terms of the Convention rights which have been the subject of
submissions:

Article 4(2) ECHR (prohibition of slavery and forced labour) provides that:

“No one shall be required to perform forced or compulsory labour.”

Article 7 ECHR (no punishment without law) provides that:

“1. No one shall be held guilty of any criminal offence on account of any act or omission which did not
constitute a criminal offence under national or international law at the time when it was committed. …”

Article 8 ECHR (right to respect or private and family life) provides that:

“1. Everyone has the right to respect for his private and family life, his home and his correspondence.

2. There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security,
public safety or the economic well-being of the country, for the prevention of disorder or crime, for the
protection of health or morals, or for the protection of the rights and freedoms of others.”

Article 14 ECHR (prohibition of discrimination) provides that:

“The enjoyment of the rights and freedoms set forth in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion,
national or social origin, association with a national minority, property, birth or other status.”

32. In addition to the caselaw cited by the parties, Ms Monaghan relies on a number of international
instruments and reports, to which we will refer as appropriate.

**The grounds of claim:**

33. We turn now to the grounds of the claim and the submissions of the parties. In doing so, we shall for
[convenience refer to the Street Offences Act 1959 as “SOA 1959”, the Rehabilitation of Offenders Act 1974](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y1N0-00000-00&context=1519360)
[as “ROA 1974”, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360) _[Police Act 1997 as “PA 1997” and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_ _[Rehabilitation of Offenders Act 1974](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
(Exceptions) Order 1975 as “the Exceptions Order”.

34. The claimants initially advanced seven grounds of their claim. William Davis J gave permission to
proceed on three of those grounds. In relation to the grounds on which he refused permission, the
claimants have abandoned one (ground 6) but have renewed their application for permission in respect of
the other three (grounds 2, 5 and 7). They have also applied for permission to amend grounds 1 to 4 in
order to encompass the relevant provisions of _[PA 1997 as well as those of the Exceptions Order. We](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
agree with Ms Gallafent that it is not entirely accurate in this context to speak (as the amended grounds do)
[of “the parallel provisions of the Police Act 1997”, but we think it appropriate that all the relevant statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
provisions should be considered. We therefore grant permission to amend.

**Ground 1:**

35. Ground 1 (as amended) contends that “the exception in the Exceptions Order 1975 and the parallel
provisions of _[PA 1997 requiring disclosure of the claimants' spent convictions violate Article 8 ECHR](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
because they are arbitrary and unlawful”. Permission to proceed on this ground was granted by William
Davis J.

36. As has been indicated above, the Exceptions Order was amended in 2013 by introducing the category
of protected convictions and cautions. The statutory provisions prior to that amendment were considered
by the Supreme Court in R (T) v Chief Constable of Greater Manchester Police; R (B) v Secretary of State
_for the Home Department [2015] AC 49(hereafter,_ _T), and were held to be incompatible with Article 8_
ECHR. Ms Monaghan relies on that decision and submits that the amendments introduced in 2013 have
not cured the incompatibility with Article 8.


-----

ER (D) 13 (Mar)

37. In T each of the two claimants had been issued, when very young, with a warning or caution for minor
offences. Years later, each had been required to disclose the warning or caution when applying for
[employment. The Court of Appeal made declarations to the effect that both the disclosure provisions of PA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
_[1997 and the provisions of the Exceptions Order were incompatible with Article 8. The defendants](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
appealed to the Supreme Court. In relation to _[PA 1997,the appeal failed: it was held that the statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
provisions were not in accordance with the law because they contained no safeguards against arbitrary
interferences with Article 8 rights. It was further held that, although it was necessary to check that persons
wishing to work with children or vulnerable adults did not present an unacceptable risk to them, the
disclosures required by Part V of PA 1997 were not based on any rational assessment of risk and so failed
the test of being necessary in a democratic society. In relation to the Exceptions Order, the appeal
succeeded on the ground that a declaration of incompatibility could not be granted in respect of
subordinate legislation, and that in all the circumstances of the case no other judicial remedy was
necessary. It was however held that, although the reason for the disclosure requirements was a legitimate
aim, there was no rational connection between minor dishonesty as a child and the question whether as an
adult that person might pose a risk to children. The requirement of disclosure therefore breached the
requirement of necessity and thus was not justified. The majority held that it was not necessary to consider
whether the Exceptions Order also failed the requirement of being in accordance with the law.

38. Lord Wilson, at paragraph 9, summarised the (unamended) provisions of the Exceptions Order in this
way:

“It is the circumstances in which the question is asked which dictate whether an exception from protection
under the 1974 Act arises; and when it arises, the duty to disclose in response to the question and the
entitlement of the questioner to act in reliance on the disclosure or on a failure to do so are both absolute,
being unrelated to the circumstances in which the spent conviction or the caution arose.”

As to the unamended provisions of Part V of PA 1997, he said this at paragraph 41:

“If the type of request was as specified, there had to be disclosure of everything in the kitchen sink. There
was no attempt to separate the spent convictions and the cautions which should, and should not, then be
disclosed by reference to any or all of the following: (a) the species of the offence; (b) the circumstances in
which the person committed it; (c) his age when he committed it; (d) in the case of a conviction, the
sentence imposed on him; (e) his perpetration or otherwise of further offences; (f) the time that elapsed
since he committed the offence; and (g) its relevance to the judgment to be made by the person making
the request.”

[39. Lord Reed, at paragraph 113, said in relation to the challenge to PA 1997:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)

“Put shortly, legislation which requires the indiscriminate disclosure by the state of personal data which it
has collected and stored does not contain adequate safeguards against arbitrary interferences with Article
8 rights.”

Lord Reed went on to indicate, at paragraph 114, that in order for the interference to be “in accordance
with the law” there must be safeguards which made it possible adequately to examine the proportionality of
the interference. He concluded, at paragraph 119, that the legislation failed to meet the requirements for
disclosure to constitute an interference “in accordance with the law”, because of

“the cumulative effect of the failure to draw any distinction on the basis of the nature of the offence, the
disposal in the case, the time which has elapsed since the offence took place or the relevance of the data
to the employment sought, and the absence of any mechanism for independent review of a decision to
disclose data under section 113A.”

40. In relation to the Exceptions Order, Lord Reed at paragraph 139 dismissed as immaterial the fact that
an ex-offender was not strictly required to disclose his criminal record, because he could avoid doing so by
not applying for jobs in the relevant sectors or by abandoning such an application when the inevitable
question was asked. At paragraph 140 he found it convenient to consider first whether the Exceptions
Order had a legitimate aim and was necessary in a democratic society He acknowledged at paragraph


-----

ER (D) 13 (Mar)

141, that in principle, measures designed to facilitate the vetting of applicants for positions such as those
involving the care of children and vulnerable adults would have a legitimate aim. He continued

“142  I cannot however see any rational connection between minor dishonesty as a child and the question
whether, as an adult, the person might pose a threat to the safety of children with whom he came into
contact. There is therefore no rational connection between the interference with article 8 rights which
results from the requirement that a person disclose warnings received for minor dishonesty as a child, and
the aim of ensuring the suitability of such a person, as an adult, for positions involving contact with
children, let alone his suitability, for the remainder of his life, for the entire range of activities covered by the
1975 Order.

143  It can only be concluded that the interference in issue in this case was not necessary in a democratic
society to attain the aim of protecting the safety of children.”

41. The amendments to _[PA 1997 and to the Exceptions Order which came into effect in 2013 were](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
intended to rectify the problem identified in the course of the proceedings in T. The issue of whether the
amendments had succeeded in that aim, and whether the amended scheme of _[PA 1997 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
Exceptions Order was compatible with Article 8, was considered by the Court of Appeal in _R (on the_
_application of P and others) v Secretary of State for the Home Department_ _[2017] EWCA Civ 321_
(hereafter, _“P”). Sir Brian Leveson PQBD, with whom Beatson and Thirlwall LJJ agreed, began his_
judgment by referring to “the interface of two important principles of social policy”: the rehabilitation of
offenders, and the need to protect the public against those who, by reason of their past behaviour, may
continue to present a risk. The particular features of the amended statutory provisions which were the
focus of the challenge in that case were the multiple conviction rule (with which, of course, the present
case is also concerned) and the serious offence rule (that is, the obligation of disclosure in relation to
certain specified offences). Sir Brian reflected on the ratio of the decision in T, as set out in the speech of
Lord Reed, and concluded at paragraph 44 that, without a mechanism for refinement, neither rule was “in
accordance with the law”:

“The multiple conviction rule is indiscriminate in that it applies without consideration of any of the features
identified by Lord Reed. If an individual has been convicted of more than one offence, the rule will apply
automatically irrespective of the nature of the offence, the disposal in the case, the time which has elapsed
since the offence took place or the relevance of the data to the employment sought. Therefore, in my view,
Lord Reed would conclude that it is not 'in accordance with the law', unless there is a mechanism for
independent review.”

42. Sir Brian then went on to consider whether, even if the revised system met the requirement of being in
accordance with the law, it would necessarily be compatible with Article 8 having regard to the requirement
that it must also be “necessary in a democratic society”. He noted counsel's submission that the amended
legislation did not fairly balance the rights of the individual and the interest of the community in public
protection, because of the indefinite nature of the requirement of disclosure and the complete absence of
relevance of the past offending to a particular job application which might be made many years later. He
reflected on ways in which the scheme might be amended to provide a filter beyond a bright line position.
At paragraph 66 he said:

“… it is not for the court to fashion a solution and, ultimately, it is a matter for the legislature to ascertain
whether as a matter of practice rather than legal theory, what system is appropriate. It must be
appreciated, however, that without some mechanism to ensure that disclosure is proportionate and linked
to the protection of the public (therefore being necessary in a democratic society), it is difficult to see how
challenges of the type raised in these cases can be avoided. It is not that the concept of the revised
scheme necessarily offends Article 8, but it may be that in its operation in individual cases, it does so. If
left to the courts as the scheme is presently devised, in my judgment, it will generate many challenges
which will require resolution on a case by case basis: such an approach cannot possibly be in the public
interest.”


-----

ER (D) 13 (Mar)

43. The Court of Appeal in P concluded that the revised scheme contained in the amended legislation was
not in accordance with the law and that, in the circumstances of the case before it, the operation of the
multiple conviction rule had been disproportionate and otherwise than as is necessary in a democratic
society.

44. There is a pending appeal to the Supreme Court in the case of _P. It is to be heard later this year,_
together with an appeal from Northern Ireland raising similar issues: re Gallagher's Application for Judicial
_review [2016] NICA 42. The Court of Appeal in Northern Ireland in that case considered the provisions_
applicable in Northern Ireland of the _[Police Act 1997,and the provisions (comparable to those in the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
Exceptions Order) of the Rehabilitation of Offenders (Exceptions) Order (NI) 1979, as amended by the
Rehabilitation of Offenders (Exceptions) (Amendment) Order (NI) 2014. It was common ground that the
scheme established by that legislation engaged Article 8. The court concluded that the amendments
introduced to the statutory scheme which had been considered in T had, so far as the multiple conviction
rule was concerned, merely replaced one blanket scheme with another. In relation to the 1997 Act, the
court concluded that the amended scheme was neither in accordance with the law nor necessary. In
relation to the 2014 Order, the court similarly found that it failed the necessity test, but accepted that the
conclusion as to “in accordance with the law” could not automatically be extended to both schemes
(because it was arguable that “the requirements of self-disclosure in the context of the 1979 Order as
amended are somewhat less stringent than the particularly sensitive element of the use and disclosure by
the State of personal data”) and found it unnecessary to make a decision as to necessity.

45. In the present proceedings, the defendants applied for a stay pending the Supreme Court's
determination of the appeals in _P and Gallagher. They argued, not that the Supreme Court's decision_
would determine every issue in this case, but that it would determine some and heavily influence others.
The application was refused by this court (differently constituted) in late July 2017.

The claimants' case

46. Ms Monaghan submits that the offence of soliciting contrary to section 1 of SOA 1959 is a minor
offence, as is demonstrated by the limited sentencing powers available to a magistrates' court dealing with
such an offence and by the sentences in fact imposed on the claimants for their offences. The offence of
soliciting is only recordable at all because specific provision is made to that effect in paragraph 3 of the
2000 Regulations (see paragraph 17 above). The offences of which the claimants have been convicted
were all committed many years ago, and it is only because of the multiple conviction rule that the claimants
do not have the benefit of the provisions relating to protected convictions. She submits that the past
convictions cannot properly be regarded as indicating any present risk to others. Even if they can be said
to show a pattern of offending, it is not a pattern which has any relevance to the present suitability of the
claimants for employment of the kind for which they would wish to apply. The disclosure requirements
operate as a deterrent to seeking employment, have prevented the claimants from obtaining employment,
and involve the revelation of very personal aspects of the claimants' private lives. In those circumstances,
Ms Monaghan argues that the statutory amendments of 2013 have not made any change which materially
alters the pre-2013 statutory provisions which the Supreme Court in T found to be incompatible with Article
8: the present scheme still fails to draw any distinction on the basis of the nature of the offences, the date
when they were committed, the penalty imposed or the relevance of the data to the employment sought;
and still does not include any system of independent review of a disclosure requirement. She therefore
invites the court either to make a declaration of incompatibility pursuant to section 4 of the Human Rights
Act 1998 or to grant a declaration.

The defendants' case

47. The defendants resisted the claimants' application for permission to amend, on the basis that it was
academic and unnecessary because (as they accept) this court is bound by the decision in _P that the_
[multiple conviction rule in PA 1997 is not in accordance with the law. As to whether that rule is necessary](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
and proportionate, Ms Gallafent submits that the present case can be distinguished from P, because here
the multiple convictions show a pattern of behaviour by each claimant, whereas no such pattern was


-----

ER (D) 13 (Mar)

shown in _P. This court is therefore not bound by_ _P on this issue, and she submits that the multiple_
conviction rule is necessary, because employers should have the information which they need to make a
proper assessment of risk.

48. The defendants accept that the Exceptions Order interferes with Article 8 rights. They argue however
[that, although the Exceptions Order and PA 1997 work together (including because information disclosed](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
[pursuant to PA 1997 must be required for the purpose of answering a question falling within the Exceptions](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
Order), they are not coterminous, and that accordingly caselaw relating to the one cannot simply be read
across to the other. Ms Gallafent submits that under the Exceptions Order, the state itself does not impose
an obligation upon the individual to disclose her criminal convictions. She therefore argues that the
involvement of the state, and the degree of intrusion by the state into the private life of an individual, are
minimal. She distinguishes the Exceptions Order from _[PA 1997 in this regard, and submits that the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
[approach which the Supreme Court took to PA 1997 in T should not be carried across to the Exceptions](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
Order. In particular, she argues that the jurisprudence of the European Court of Human Rights on which
Lord Reed relied in _T_ reflected a very particular approach which, she submits, does not apply to the
Exceptions Order. She submits that in relation to the Exceptions Order, the appropriate test of whether the
Order is “in accordance with the law” is by application of the well-established principles stated (with
reference to the phrase “prescribed by law” in Art 10) in _Sunday Times v UK (1979-80) 2 EHRR 245 at_
paragraph 49:

“In the Court's opinion, the following are two of the requirements that flow from the expression 'prescribed
by law'. First, the law must be adequately accessible: the citizen must be able to have an indication that is
adequate in the circumstances of the legal rules applicable to a given case. Secondly, a norm cannot be
regarded as a 'law' unless it is formulated with sufficient precision to enable the citizen to regulate his
conduct: he must be able – if need be with appropriate advice – to foresee, to a degree that is reasonable
in the circumstances, the consequences which a given action may entail.”

In Malone v UK (1985) 7 EHRR 14, similar principles were applied to the phrase “in accordance with the
law” in Article 8, which was said to imply that

“there must be a measure of legal protection in domestic law against arbitrary interferences by public
authorities with the rights safeguarded by paragraph 1.”

Applying those principles, Ms Gallafent submits, the Exceptions Order is in accordance with the law.

49. Ms Gallafent acknowledges that a similar argument was rejected by a Divisional Court in _R (R) v_
_National Police Chiefs' Council and Secretary of State for Justice_ _[2017] EWHC 2586 (Admin), but notes_
that the decision in that case is presently under appeal (though the appeal may be stayed pending the
determination of the appeal to the Supreme Court in P). She submits that the decision in R was made per
_incuriam (because the court assumed that the test of “in accordance with the law” was the same in relation_
to both the Exceptions Order and PA 1979) and in any event this court is not bound by it.

50. In _R the application of the Exceptions Order to “low level historical reprimands” was challenged as_
being a violation of Article 8 rights. In relation to such reprimands, but specifically without reference to
other cases, the court accepted the claimant's submissions (themselves relying on T and P) and concluded
that the Exceptions Order did violate Article 8, both because it was not “in accordance with the law” and
also because it was therefore “not necessary in a democratic society”. Ms Monaghan in her response
relied on this.

51. Ms Gallafent develops her submission by arguing that the Exceptions Order cannot be said to be
[arbitrary. ROA 1974 and the Exceptions Order together set out a coherent scheme which requires certain](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)
questions to be answered by an individual applying for particular categories of employment, and the
multiple conviction rule is justified because there is a clear public interest in an employer being able to
assess whether a prospective employee has shown a pattern of offending and a willingness to break the
law. In the Order, and in its amendments, Parliament has made careful choices which do differentiate on
the basis of the type of offence, the offender's age, the nature of the disposal, the time which has elapsed


-----

ER (D) 13 (Mar)

and whether the individual has committed any other offence, but which also take account of the need to
protect the public. Multiple convictions can show a pattern of offending (as indeed, she submits, it did in
the cases of these claimants), which is a legitimate reason for the multiple conviction rule. She accepts
that a pattern of offending was not shown in P, but argues that the facts of the present case are different
and that nothing in _P requires this court to find that the obligation of disclosure is not necessary in a_
democratic society.

52. Ms Gallafent relies on the detailed evidence contained in witness statements by two officials in the
[Ministry of Justice, Julia Gerrard and Alison Foulds, each of whom has held the post of policy lead on ROA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)
_[1974.  This evidence explains the history of the amendments to ROA 1974 and the introduction of filters in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
accordance with recommendations made in a 2010 report by Mrs Sunita Mason, _A Balanced Approach._
The report recommended, amongst other things, that those who had incurred a minor conviction or caution
should after a period of time be given a second chance, a recommendation which led to the multiple
conviction rule. The evidence shows that a significant proportion of those who have a criminal record have
only one conviction, which suggests that the terms of the amended legislation benefit a significant
proportion. The evidence is relied upon as explaining and justifying the “many nuanced decisions” which
are best taken by an employer who knows what is relevant to the employment for which an individual with
a criminal record applies. It is also relied on as supporting the submission that the 2013 amendments did
make significant changes and created a balanced filtering system. Ms Gallafent submits that the
Exceptions Order sets out a self-disclosure regime which is in accordance with the law and necessary in a
democratic society.

53. Ms Gallafent provided the court with a note on statistics in which a filter had been applied to the total
number of CRCs and ECRCs issued during a particular period, in order to show the effects of the 2013
amendments in respect of applicants with a single recorded conviction or caution. The statistics show that
the 2013 amendments would reduce the number of CRCs issued in such circumstances by about 26%,
and the number of ECRCs by about 32%. Ms Gallafent relies on this to support her submission that the
2013 amendments have made a real difference. It may be noted that the statistics also show, to our
surprise, that between 2012 and 2015 the total number of ECRCs issued annually was of the order of 3.7 –
3.8 million. The total number of CRCs, in contrast, was of the order of 235,000 – 280,000.

54. In the course of her submissions, Ms Gallafent also referred to guidance published by the government
in relation to _[ROA 1974 which gives the following advice about what employers should consider when](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
employing ex-offenders:

“Each employer is best placed to consider whether a person's convictions (either before they have become
spent or, in the case of activities listed in the Exceptions Order, when they are spent) make him or her
unsuitable for a particular job. But it is important that you should reach a balanced judgment, having
regard to such factors as

a. the person's age at the time of the offence;

b. how long ago the offence took place;

c. whether it was an isolated offence or part of a pattern of offending;

d. the nature of the offence;

e. its relevance to the post or position in question; and

f. what else is known about the person's conduct before or since the offence.

The DBS Code of Practice requires registered employers to have a fair and clear policy towards exoffenders and not to discriminate automatically on the basis of an unprotected conviction or caution.”

**Conclusion as to Ground 1:**

55. We accept that we are bound by P to conclude that the statutory scheme under sections 113A and
113B of PA 1997 is not in accordance with the law, because the multiple conviction rule operates in the


-----

ER (D) 13 (Mar)

indiscriminate, and hence arbitrary, manner summarised at paragraph 44 of P – a paragraph which carries
particular resonance when we look at the checklist of relevant factors in the Guidance which we have
quoted in paragraph 54 above, all of which are important but none of which plays any part in the blanket
operation of the scheme. Nor is it necessary in a democratic society that the desirable aim of safeguarding
children and vulnerable adults should be achieved by the use of the multiple disclosure rule under _[PA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
_[1997. We note that in P only one of the conjoined appeals – that of P - raised an issue as to the multiple](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
conviction rule. The Court of Appeal, at paragraph 77, held that in the circumstances of that case, the rule
was disproportionate and failed the test of necessity.

56. We would have reached the same conclusion even if not bound by P, in particular because the facts of
this case vividly illustrate the fact that the multiple conviction rule operates in circumstances in which any
link between the past offending, and the assessment of present risk in a particular employment, is either
non-existent or at best extremely tenuous.

57. As to the Exceptions Order, we have carefully considered Ms Gallafent's emphasis on the cautious
approach adopted by the Supreme Court in T, and by the Court of Appeal in Northern Ireland in Gallagher,
[to the differences between PA 1997 and the Exceptions Order (or its equivalent) in respect of the extent of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
State interference. In each of those cases, the court found it unnecessary to resolve the issue of whether
the multiple conviction rule under the Exceptions Order (or its equivalent) was in accordance with the law.
We note however that in P the court looked at the overall scheme under both the Act and the Order, as did
the court in R. In our view, it is right to adopt a similar approach in the circumstances of this case, and
there is nothing in T which binds us to take a different course.  We accept Ms Gallafent's submission that
the Act and the Order are not coterminous; but so far as the multiple conviction rule is concerned, they
[operate together, and we cannot see why a scheme which is unlawful so far as PA 1997 is concerned is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
saved, in relation to the Exceptions Order, by the fact that the individual concerned has a choice whether to
apply for a particular form of employment. An individual who wishes to apply for work in a relevant field
may be asked questions about her or his previous convictions, and is required to verify the answers by a
CRC or ECRC, only because of the combined effect of the Act and the Order. We conclude that in the
circumstances of the present case the multiple conviction rule under the Exceptions Order is neither in
accordance with the law nor necessary in a democratic society. Our reasons are as follows.

58. First, we are not persuaded by Ms Gallafent's submissions that a different approach should be taken to
the question of whether the provisions of the Exceptions Order are in accordance with the law. But even if
she is correct about that, it seems to us that the application of the approach for which she contends would
lead to the same result. In our judgment, the principle stated in Malone (see paragraph 48 above) works
against Ms Gallafent's submission rather than in her favour: the Exceptions Order does result in
interferences with the claimants' Article 8 rights which are arbitrary in the sense that they bear no, or very
little, relationship to the aim of safeguarding children and vulnerable adults.

59. Secondly, it seems to us that the approach for which Ms Gallafent contends would work against that
aim in two respects: first, by requiring disclosure by all those who have been convicted on two or more
occasions of soliciting, without reference to their personal circumstances or their present situation, it would
exclude some applicants whose ability to empathise with and assist those for whom they seek to care has
in fact been enhanced by their experience of having graduated from a school of very hard knocks; and
secondly, by making it harder for persons in the position of the claimants to obtain employment, it would be
capable of causing at least some to remain in prostitution when they wish to leave it.

60. Thirdly, whilst there is of course force in the point that it is the employer who is best placed to assess
the risk posed by a particular applicant for a particular position, that in our judgment does not provide a
complete justification for the present scheme. First, and most importantly, it provides no justification at all
for requiring disclosure in circumstances where no reasonable employer could possibly regard the previous
convictions collectively, or the previous conviction(s) for soliciting in particular, as having any relevance at
all to the assessment of present risk in the employment concerned. In this regard, we agree with Ms
Monaghan that it is not sufficient to say that convictions for two or more offences may show a pattern of
offending if that pattern cannot rationally have any relevance to the job application Secondly as Lord


-----

ER (D) 13 (Mar)

Wilson pointed out in a passage which we quote at paragraph 65 below, it is very likely that the result of
disclosure will be that another applicant will be preferred to the ex-offender, whether or not that is
objectively justified. It may be otherwise, and it may that an employer will choose not to ask a question
which requires disclosure; but the experience of the claimants has been that relevant questions are asked,
and the disclosure of previous convictions for soliciting is not followed by an offer of employment. We see
no reason to doubt that the experience of the claimants is likely to be typical of others in similar positions.
[We note that subsections 1(2A) and 1(2B) of SOA 1959 recognise the desirability of supporting those who](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y1N0-00000-00&context=1519360)
wish to leave prostitution, and we think it unfortunate that the multiple conviction rule works against that
aim.

61. Fourthly, we accept Ms Monaghan's broader submissions that the mere fact of disclosure of past
convictions for soliciting carries with it embarrassment and stigma which cannot be undone, whatever the
outcome of the job application. Even if the job application is successful, the person concerned will be
working in the knowledge that one or more persons in her employer's organisation is aware of highly
personal details about her which have been no impediment to her employment.

62. We accept that the claimants have all suffered a handicap in the labour market, and have suffered
embarrassment and humiliation, because of the operation of the multiple conviction rule. In our view, it
should be and is possible for Parliament to devise a scheme which more fairly balances the public interest
with the rights of an individual applicant for employment in relevant areas of work. It may be that only
broad lines can be drawn to act by way of filter before the employer is left to assess the risk. But that is not
a good reason for adopting the blanket approach which the present schemes adopt in widely-differing
circumstances. As was said in P, it is not for the court to devise a scheme.

63. We therefore conclude that the claim succeeds on this ground. Both under PA 1979 and under the
Exceptions Order, the application of the multiple conviction rule to the circumstances of this case results in
an interference with the claimants' Article 8 rights which is neither in accordance with the law nor
necessary in a democratic society. To that extent, the schemes are unlawful.

**Ground 2:**

64. Ground 2 (as amended) contends that “the exception in the Exceptions Order 1975 and the parallel
[provisions of PA 1997 requiring disclosure of the claimants' spent convictions under section 1 of SOA 1959](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
violate Article 8 ECHR because they are arbitrary and unlawful”. Permission to proceed on this ground
was refused by William Davis J.

The claimants' case

65. The claimants make the same submissions as they have in respect of Ground 1, but add that there is
no evidence that their convictions for soliciting can be an indicator of present risk if they are employed with
children or vulnerable adults. They submit further that it is no answer to say that the statutory provisions
properly enable an employer to make an assessment of risk, because the process of leaving that
assessment to an employer of itself results in harm to those who, like the claimants, were once (but are no
longer) engaged in prostitution. Ms Monaghan relies on an observation by Lord Wilson at paragraph 45 of
_T:_

“The Secretaries of State say, second, that the regime reflected a conclusion by Parliament that it was
preferable to make the prospective employer or other registered person the judge of the relevance of the
disclosure to his decision. Rely on him (they say) to sift the wheat from the chaff. But will he do so? In
these days of keen competition and defensive decision-making, will the candidate with the clean record not
be placed ahead of the other, however apparently irrelevant his offence and even if otherwise evenly
matched? More fundamentally, the regime reflects an exception to the eradication of the offence under the
1974 Act and it is the fact, or even the potentiality, of disclosure, whatever its ultimate consequences,
which causes the interference and for the person creates, as a minimum, embarrassment, uncertainty and
anxiety.”


-----

ER (D) 13 (Mar)

Ms Monaghan submits that those words apply with particular force in the present case, having regard to
the nature of the convictions in question and the stigma which attaches to the claimants' past engagement
in prostitution.

66. Ms Monaghan makes the further point that in the context of previous convictions for offences of
soliciting, disclosure or the potential for disclosure not only causes psychological harm to persons in a
position similar to that of the claimants but also impedes the ability of a woman to leave prostitution.

The defendants' case

67. Ms Gallafent submits that this ground is otiose, because if ground 1 succeeds, ground 2 is embraced
within it. In any event, she submits that permission was rightly refused on this ground, which seeks to
attack what she describes as a clear and logical bright line as to the disclosure of convictions of recordable
offences. Such a bright line rule is permissible in principle, and the line which Parliament has drawn in this
respect is obviously rational, even if it may produce hard cases at the margins. It is a proportionate
approach because even though a conviction of an offence of soliciting contrary to section 1 of SOA 1959 is
recordable, a single such conviction is not disclosable.

68. The defendants further submit that multiple convictions for soliciting offences are capable of being
relevant to the assessment of risk by an employer working with children or vulnerable adults. It must be
left to the employer to make that assessment, because the DBS cannot know all the details of the post or
position under consideration. Ms Gallafent accepts that sex workers may have been exploited, but submits
that it cannot be said that no risk ever arises. She does not suggest that multiple such convictions will
always be relevant in that regard, but submits that they may be (for example, because of a risk that a child
or vulnerable adult might be brought into contact with pimps) and that it should accordingly be left to an
employer to make the necessary assessment. She rejects the claimants' submissions that such an
approach is no more than negative stereotyping, and that convictions for this type of offence cannot give
rise to any risk in the context of later employment with children or vulnerable adults.

**Conclusion as to Ground 2:**

69. We agree with Ms Gallafent that this Ground is embraced within Ground 1 and that, as Ground 1 has
succeeded, this ground has become otiose. If Ground 1 had failed, we agree with the observation of
William Davis J when he refused permission on Ground 2: “there is nothing inherently unlawful in
disclosure provisions being engaged in relation to minor offending”.  We therefore conclude that this
ground was not arguable and that permission was rightly refused.

**Ground 3:**

70. Ground 3 (as amended) contends that “the exception in the Exceptions Order 1975 and the parallel
[provisions of PA 1997 requiring disclosure of the claimants' spent convictions under section 1 of SOA 1959](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)
violate Article 14, read with Article 8 ECHR, because they are gender discriminatory”. Permission to
proceed on this ground was granted by William Davis J.

71. Article 14 can only be considered in conjunction with one or more of the substantive Convention rights.
It is accepted that by reason of the disclosure provision, Article 8 ECHR is engaged.

72. In R (on the application of SG & others) v Secretary of State for Work and Pensions _[2015] UKSC 16_
Lord Reed identified the general approach to the application of Article 14 as follows:

“7. The general approach followed by the European Court of Human Rights in the application of article 14
was explained by the Grand Chamber in Carson v United Kingdom (2010) 51 EHRR 13, para 61:

'In order for an issue to arise under article 14 there must be a difference in the treatment of persons in
analogous, or relevantly similar, situations. Such a difference of treatment is discriminatory if it has no
objective and reasonable justification; in other words, if it does not pursue a legitimate aim or if there is not
a reasonable relationship of proportionality between the means employed and the aim sought to be
realised.'


-----

ER (D) 13 (Mar)

…

12. Article 14 is not confined to the differential treatment of similar cases: 'discrimination may also arise
where states without an objective and reasonable justification fail to treat differently persons whose
situations are significantly different' (Pretty v United Kingdom (2002) 35 EHRR 1, para 87). An example is
the case of _Thlimmenos v Greece (2001) 31 EHRR 411, where this type of discrimination was first_
recognised.

13. The European court has also accepted that a difference in treatment may be inferred from the effects of
a measure which is neutral on its face. In DH v Czech Republic (2008) 47 EHRR 59, the court stated at
para 175:

'The court has established in its case law that discrimination means treating differently, without an objective
and reasonable justification, persons in relevantly similar situations. … The court has also accepted that a
general policy or measure that has disproportionately prejudicial effects on a particular group may be
considered discriminatory notwithstanding that it is not specifically aimed at that group.'

In such a case, it will again be necessary to consider whether the difference in treatment has an objective
and reasonable justification, in the light of the aim of the measure and its proportionality as a means of
achieving that aim. For example, a rule requiring that employees should be capable of heavy lifting will
exclude a higher number of women than men, because of differences in the average bodily strength of the
sexes. Whether that difference in treatment has an objective and reasonable justification will depend on
whether the rule which results in the difference in treatment has a legitimate aim and is a proportionate
means of realising that aim…”

The claimants' case

73. The reality of the claimants' case is a challenge to the multiple conviction rule set out in paragraph
2A(3)(c) of the Exceptions Order. It is accepted that the rule applies to all offences and is not gender
specific. It is the claimants' case that the rule, although neutral on its face, when read in conjunction with
section 1 of SOA 1959, unlawfully discriminates against women. Thus, the challenge falls within the third
type of discrimination identified by Lord Reed in SG above.

74. The claimants contend that:

i) Offences pursuant to section 1 of SOA 1959 are overwhelmingly committed by women. At the time of
the claimants' convictions they could only be committed by women;

ii) The nature of prostitution is such that those who commit the offence are likely to have committed it on
multiple occasions, thus the multiple conviction rule impacts severely on those who have committed
offences pursuant to section 1 of the 1959 Act;

iii) Most of the occupations for which disclosure of spent convictions are required are those within the
caring and other professions where women are disproportionately employed;

iv) These measures impede a woman's ability to exit prostitution.

75. Reliance is placed upon the authority of Opuz v Turkey (2010) 50 EHRR 28 citing the authority of DH v
_Czech Republic (2008) 47 EHRR 3 where it was stated that:_

“…a general policy or measure that has disproportionately prejudicial effect on a particular group may be
discriminatory notwithstanding that it is not specifically aimed at that group…”

76. In Thlimmenos v Greece (2001) 31 EHRR 15 the Grand Chamber at [44] stated:

“44. The Court has so far considered that the right under Article 14 not to be discriminated against in the
enjoyment of the rights guaranteed under the Convention is violated when States treat differently persons
in analogous situations without providing an objective and reasonable justification. However, the Court
considers that this is not the only facet of the prohibition of discrimination in Article 14. The right not to be
discriminated against in the enjoyment of the rights guaranteed under the Convention is also violated when


-----

ER (D) 13 (Mar)

States without an objective and reasonable justification fail to treat differently persons whose situations are
significantly different.”

77. The Convention on the Elimination of All Forms of Discrimination against Women through its
committee has recognised the gendered nature of prostitution. In _Abdulaziz Cabales v Balkandalivuk_
(1985) 7 EHRR 471 gender is described as a “suspect” class. It is submitted that weighty reasons are
required to justify any discrimination.

78. Following a request pursuant to the _[Freedom of Information Act 2000 the claimants have produced](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4H0-TWPY-Y1K2-00000-00&context=1519360)_
statistics which demonstrate that a significantly higher number of women than men are convicted under
_[SOA 1959. Of those convicted, a significantly higher number of women have multiple convictions. Paul](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y1N0-00000-00&context=1519360)_
Ham, a solicitor instructed on behalf of the claimants, has produced a document entitled “Gender
breakdown of exempted professions”, which demonstrates that certain occupations, for example teaching
assistants, school support staff, adult social services are particularly female dominated. He states that the
research shows that approximately 70% of women are affected by the Exceptions Order as compared with
30% men.

79. It is the claimants' case that the offences pursuant to section 1 of SOA 1959 are intrinsically linked to
the claimants' gender and so should not be treated differently absent justification. There is said to be no
justification for the discrimination. There is no relationship between the convictions and the objective
sought, no proper balance has been struck. The women who have been convicted of these offences are
being stigmatised and will be required to disclose these convictions throughout their lives. The lack of
justification in respect of Article 8 is said to be even weightier in respect of Article 14 given the need to
justify the sexual discrimination.

The defendants' case

80. The defendants accept that:

i) Article 14 is engaged because disclosure of criminal records is within the ambit of Article 8;

ii) Article 14 extends to indirect discrimination, i.e. a gender neutral provision on its face which has a
disproportionate impact on one gender;

iii) The section 1 offence is disproportionately committed by women;

iv) The employments and offences listed in the Exceptions Order, to which the exceptions in principle
apply and are cross-referenced in sections 113A and 113B of the Police Act 1997, as a whole, are ones in
which women are disproportionately represented by approximately two-thirds to one-third.

81. The defendants accept that the challenge is to the multiple conviction rule, albeit the focus of Ground
Three is in respect of the section 1 offence. The defendants contend that the rule applies to all types of
offence irrespective of gender. Reliance is placed upon statistics from figures collated in 2016/17 and
provided by a Senior Executive Officer in the Public Protection Unit of the Home Office which identify the
number of applicants for CRCs or ECRCs with multiple convictions for the same offences by reference to
those offences. What are described as the “top ten offences” are set out: they include shoplifting, theft,
obtaining property by deception, burglary and theft, and criminal damage. A significantly higher number of
female offenders than male are convicted of the offence of shoplifting. The male/female statistics for the
offence of obtaining property by deception are approximately the same. The remaining eight offences are
recorded as showing significantly higher numbers of males with multiple convictions than females. The
offence of soliciting contrary to section 1 of SOA 1959 is fifty-ninth in the list of total applications for
certificates by those with multiple convictions.

82. Relying upon the statistics, the defendants submit that men have disproportionately heavier criminal
records and commit more multiple offences than women. In terms of the general application of the multiple
conviction rule, the gender discriminated against is men. As the multiple conviction rule applies to all
offences, men and women, the response of the defendants to the question “Is the rule adversely impacting
on women?” is that it is not In considering the issue of discrimination the Court cannot ignore the


-----

ER (D) 13 (Mar)

treatment of men as a result of the rule. It is the rule to which the Court's attention should be directed, not
the individual offence.

83. Reliance is also placed upon the fact that a person in a similar position to the claimants is a male
prostitute who, prior to 2003, would have been prosecuted pursuant to section 32 of the Sexual Offences
Act 1956. The male would receive no protection from disclosure. Since the amendment in 2003 a man
would be prosecuted pursuant to section 1 of SOA 1959. There would be no reason to suppose that
disclosure of his convictions would have any different effect upon a man rather than upon a woman. There
would be no difference in treatment of the relevant male comparator irrespective of whether there are more
female prostitutes than men.

84. In any event, the legislative regimes would be justified as a proportionate means of achieving a
legitimate aim. The regime as a whole heavily favours disclosure in respect of men rather than women at
every stage of the analysis save for this identified offence. The only exception to this may be said to be the
proportion of women in the totality of roles, employment and offices covered by the Exceptions Order.
There is no challenge to the inclusion of any of those employments or offices within these proceedings.
Moreover they are employments or offices which require interaction with vulnerable people or the highest
levels of personal integrity.

**Conclusion as to Ground 3:**

85. We accept that the provisions of Article 14 ECHR are engaged and that the argument falls within the
third category of discrimination identified by Lord Reed in _SG (above). The specific challenge is to the_
multiple conviction rule in the Exceptions Order, linked to sections 113A to 113B of the 1997 Act. A
disproportionately high percentage of women commit the offence of soliciting contrary to section 1 of SOA
1959, a disproportionately high proportion of women have multiple convictions for these offences and a
significantly higher proportion of women seek employment in the sectors where certification pursuant to the
provisions of the 1997 Act is required.

86. On its face the multiple conviction rule is gender neutral, it applies to all offences and genders.
Identifying a particular offence, namely section 1 of SOA 1959, illustrates a particularly limited example of
the application of the rule, as demonstrated by the statistics provided by the defendants set out in
paragraph 81 above. The application of this rule, where it pertains to the section 1 offence, does result in a
disproportionately high number of women being required to disclose spent convictions. However, this
offence cannot be viewed in isolation in terms of the general operation of the multiple conviction rule.

87. The undisputed statistical evidence shows that men, rather than women, are disproportionately more
likely to have a criminal record, to have been convicted of a recordable offence, to bring themselves within
the multiple conviction rule and to have committed particular types of offences including sexual offences.
As a result the criminal records disclosure regime, in fact, disproportionately affects more men than
women. Put shortly, the general operation of the rule does not adversely impact upon women.

88. There is a sound justification for the rule and the linked provisions of the 1997 Act. It is the protection
of those who are vulnerable, be they adults or children, together with the need in other related sectors for
individuals of the highest integrity. That aim is the same whether the individual with the multiple
convictions be male or female. So far as any issue of gender discrimination is concerned, the legislative
regimes are a proportionate means of achieving these legitimate aims. It follows that upon Ground Three
the claimants have not made out their case.

**Ground 4:**

89. Ground 4 (as amended) contends that “the exception in the Exceptions Order 1975 and the parallel
provisions of _[PA 1997 to the extent that it requires disclosure of the claimants' spent convictions under](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0YF-00000-00&context=1519360)_
section 1 of SOA 1959 violate Article 4 ECHR and Directive 2011/36/EU”. Permission to proceed on this
ground was granted by William Davis J.

The claimants' case


-----

ER (D) 13 (Mar)

90. The claimants' case upon this Ground has altered. It is now stated to be that the material provisions of
the 1997 Act and the Exceptions Order, to the extent that they require disclosure of the claimants' spent
convictions pursuant to section 1 of SOA 1959, violate Article 4 ECHR and Directive 2011/36/EU because
they penalise victims of trafficking and violate the right to anonymity for victims of trafficking.

91. Each of the claimants is alleged to have been internally trafficked by pimps. In penalising such
behaviour by convicting the claimants of offences related to that trafficking and then requiring disclosure of
the convictions in the circumstances set out in the Exceptions Order, the defendants are said to be
violating the positive obligations in Article 4 to protect trafficking victims. They are also continuously
violating the non-penalisation provisions in Article 4 read with the Council of Europe Convention on Action
against Trafficking in Human Beings and Directive 2011/36/EU. Accordingly the exception and its impact
upon the claimants are unlawful.

92. Article 4(2) ECHR, quoted in paragraph 31 above, encompasses trafficking: _Rantsev v Cyprus &_
_Russia (2010) 51 EHHR 1. It also imposes positive obligations to protect victims of trafficking: LE v Greece_

[2016] App. No. 71545/12 [64-5], _OOO v Commissioner of Police for the Metropolis_ _[2011] EWHC 1246_
_(QB). Article 26 of the Council of Europe Convention on Action against Trafficking in Human Beings_
provides that:

“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

Directive 2011/36/EU

93. The Directive “On preventing and combating trafficking in human beings and protecting its victims” is
directly effective. Article 2 defines trafficking consistently with other international instruments as follows:

“Offences concerning trafficking in human beings

1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or
transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of
abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or
receiving of payments or benefits to achieve the consent of a person having control over another person,
for the purpose of exploitation.

2. A position of vulnerability means a situation in which the person concerned has no real or acceptable
alternative but to submit to the abuse involved.

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of
sexual exploitation, forced labour or services, including begging, slavery or practices similar to slavery,
servitude, or the exploitation of criminal activities, or the removal of organs.

4. The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual,
shall be irrelevant where any of the means set forth in paragraph 1 has been used.

5. When the conduct referred to in paragraph 1 involves a child, it shall be a punishable offence of
trafficking in human beings even if none of the means set forth in paragraph 1 has been used.

6. For the purpose of this Directive, 'child' shall mean any person below 18 years of age.”

Article 8 provides:

“Non-prosecution or non-application of penalties to the victim

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties


-----

ER (D) 13 (Mar)

on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2.”

94. The United Nations Convention against Transnational Organised Crime (the Palermo Protocol)
contains the same definition of trafficking. At Article 6 it is stated:

“1. In appropriate cases and to the extent possible under its domestic law, each State Party shall protect
the privacy and identity of victims of trafficking in persons, including, inter alia, by making legal proceedings
relating to such trafficking confidential.”

95. It is the claimants' contention that Article 4 ECHR must be read consistently with the Council of Europe
Convention, the EU Directive and the United Nations Palermo Protocol with the result that a scheme which
requires or permits disclosure of offences pertaining to trafficking, without appropriate safeguards,
penalises the victims of trafficking and violates their right to anonymity.

96. As to anonymity, the retention and disclosure of such data is said to violate the right of anonymity
contained within the Council of Europe Convention above and the Palermo Protocol. They operate as
further “penalisation” and undermine the objectives of the non-penalisation provisions including
rehabilitation.

The defendants' case

97. The defendants accept that human trafficking falls within the scope of Article 4 ECHR and that in
certain circumstances Article 4 may impose positive obligations on states to penalise and prosecute
effectively any act aimed at maintaining a person in a situation of slavery, servitude or forced or
compulsory labour: see _Rantsev above. However, there is no domestic or Strasbourg authority for the_
proposition that Article 4 imposes a positive obligation on states to ensure that no criminal conviction from
prostitution offences is ever disclosed. None has been cited.

98. As to the claimants' reliance on Directive 2011/36/EU Article 8 (transposition date of 6 April 2013) and
the Convention on Action against Trafficking in Human Beings, Article 26, which although in force for the
United Kingdom, has not been incorporated into domestic law, it is the defendants' case that the United
Kingdom has implemented the provisions of Article 8 of the Directive and Article 26 of the Convention
through section 45 of the Modern Slavery Act 2015. This provision states:

“45. Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence,


-----

ER (D) 13 (Mar)

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.”

99. There is no authority for the proposition that disclosure of a criminal record is a penalty in the sense
that term is used by the Directive or the Convention. Article 7 ECHR states:

“1. No one shall be held guilty of any criminal offence on account of any act or omission which did not
constitute a criminal offence under national or international law at the time when it was committed. …”

100. Article 8 of the 2011 Directive contains the obligation upon Member States to ensure that competent
national authorities are entitled not to prosecute or impose penalties on victims of trafficking for their
involvement in criminal activity which they have been compelled to commit as a direct consequence of
being subjected to any of the acts referred to in Article 2 (see paragraph 93 above). Article 3 provides for
the inciting, aiding and abetting or attempting to commit any of the offences referred to in Article 2. Article
4 provides as follows:

“Penalties

1. Member States shall take the necessary measures to ensure that an offence referred to in Article 2 is
punishable by a maximum penalty of at least five years of imprisonment.

2. Member States shall take the necessary measures to ensure that an offence referred to in Article 2 is
punishable by a maximum penalty of at least 10 years of imprisonment where that offence:

(a) was committed against a victim who was particularly vulnerable, which, in the context of this Directive,
shall include at least child victims; EN L 101/6 Official Journal of the European Union 15.4.2011

(b) was committed within the framework of a criminal organisation within the meaning of Council
Framework Decision 2008/841/JHA of 24 October 2008 on the fight against organised crime;

(c) deliberately or by gross negligence endangered the life of the victim; or

(d) was committed by use of serious violence or has caused particularly serious harm to the victim.

3. Member States shall take the necessary measures to ensure that the fact that an offence referred to in
Article 2 was committed by public officials in the performance of their duties is regarded as an aggravating
circumstance.

4. Member States shall take the necessary measures to ensure that an offence referred to in Article 3 is
punishable by effective, proportionate and dissuasive penalties, which may entail surrender.”

101. These provisions are clear. The penalties, as defined, are those imposed following a conviction for a
criminal offence as identified by Article 2. The “penalties” identified in Article 4 are contrasted with
“sanctions” in respect of “legal persons” contained in Article 6. There is nothing in Article 4, nor within the
Directive or the Convention, which extends the meaning of penalty beyond punishment for a criminal
offence. The requirement of disclosure is an adverse consequence of criminal offending, it is not a penalty.

102. The arrangements now in place satisfy the requirements of Article 8 of the Directive, namely the
prosecutorial discretion given to the CPS not to prosecute victims of trafficking involved in criminal activities
which they have been compelled to commit as a direct consequence of being subjected to acts of
trafficking. The availability of any such prosecution being stayed as an abuse of process was recognised
in _R v L & Others_ _[2013] EWCA Crim 991. Section 45 of the_ **_Modern Slavery Act 2015 provides a_**
complete defence for slavery or trafficking victims who commit an offence attributable to slavery or relevant
exploitation.

103. The possible criminal liability of the trafficked victim was recognised by Lord Hughes in _Hounga v_
_Allen_ _[2014] UKSC 47 at [64]:_


-----

ER (D) 13 (Mar)

“64. Thus, the internationally recognised rule is clear, as is English criminal law. The trafficked victim,
assuming that is what she is, is not relieved of criminal liability for an offence which she has committed. If,
however, she was compelled to commit it as a direct consequence of being trafficked, careful consideration
ought to be given to whether it is in the public interest to prosecute her. In the present case, there is no
finding that Miss Hounga was compelled to commit the immigration offences which she committed; the
tribunal understandably found that she was well aware of what she was doing and voluntarily did it in the
hope of advantage. Young as she clearly was, she was no doubt under the influence of Mrs Allen and that
would constitute very real mitigation if punishment were in question. But what her trafficking, if that is what
it was, does not do is to take away the illegality of what she knowingly did.”

104. The fact of a conviction pursuant to section 1 of SOA 1959 does not of itself mean that the person
who committed the offence is a victim of trafficking.

Anonymity

105. Article 11 of the Council of Europe Convention on Action Against Trafficking in Human Beings
provides:

“Each party shall protect the private life and identity of victims. Personal data regarding them shall be
stored and used in conformity with the conditions provided for by the Convention for the Protection of
Individuals with regard to Automatic Processing of Personal Data (ETS No. 108).”

106. This Convention has not been incorporated into domestic law and is not binding. No right to
anonymity has been identified which would be offended by the disclosure of criminal records. The
fundamental problem with the claimants' submission is that any right to anonymity is in respect of being a
victim of trafficking, but a conviction for the section 1 offence does of itself not reveal such a fact.

**Conclusion as to Ground 4:**

107. There is nothing in the disclosure of an offence pursuant to section 1 of SOA 1959 which of itself
indicates that the offender is a victim of trafficking. There is no provision in domestic law or the cited
Directive or Convention which identifies the disclosure of such an offence as being a penalty. Article 7
ECHR read with Articles 2 to 4 of the Directive 2011/36/EU are clear; the penalty is the imposition of the
punishment following a criminal conviction, it is not the adverse consequence which can flow from a
criminal conviction.

108. As to the obligations set out in the identified Directive, Convention and Protocol there is nothing
which indicates that the United Kingdom is in breach of its international obligations with regard to the
victims of trafficking. On the contrary, section 45 of the **_Modern Slavery Act 2015 provides a complete_**
defence to a victim of trafficking in respect of any criminal offence. The availability of such a defence
would be taken into account by a prosecuting authority when deciding whether it is in the public interest to
prosecute any person.

109. The claimants have made bold assertions in respect of their case on “penalty” but there is no
authority which begins to provide a legal basis for their arguments.

110. The fundamental problem with the claimants' case upon a right to anonymity is that it relates solely to
an offender being a victim of trafficking. A conviction for an offence pursuant to section 1 of SOA 1959
does not reveal such a fact. Accordingly, this submission also fails.

**Ground 5:**

111. Ground 5 contends that “the recording and/or retention of data concerning convictions under section
1 of SOA 1959 violates Article 4 and/or Article 8 and/or Article 14 read with Article 8 ECHR and is
unlawful”. Permission to proceed on this ground was refused by William Davis J on the basis that it added
nothing to other grounds.

The claimants' case


-----

ER (D) 13 (Mar)

112. Ms Monaghan argues that this ground does add something to other grounds, because it concerns
recording and retention of data alone, irrespective of disclosure. First, she submits that the mere recording
and retention of data violates Article 4 (because of the absence of safeguards and the continuing
penalisation of the claimants), and Articles 8 and 14 (because it is discriminatory for the reasons argued in
relation to grounds 3 and 4). Secondly, she submits that the recording and retention of data about past
convictions is an interference with Article 8 rights which requires justification, but no justification exists. In
this respect she relies on paragraphs 16-18 of the speech of Lord Wilson in _T. Lord Wilson first quoted_
from the speech of Lord Hope in the earlier case of _R (L) v Commissioner of Police for the Metropolis_

[2010] 1 AC 410 at para 27:

“… information about an applicant's convictions which is collected and stored in central records can fall
within the scope of private life within the meaning of article 8.1, with the result that it will interfere with the
applicant's private life when it is released. It is, in one sense, public information because the convictions
took place in public. But the systematic storing of this information in central records means that it is
available for disclosure under Part V of the 1997 Act long after the event when everyone other than the
person concerned is likely to have forgotten about it. As it recedes into the past, it becomes part of the
person's private life which must be respected.”

Lord Wilson went on to accept a submission that the point at which a conviction receded into the past and
became part of a person's private life will usually be the point at which it becomes spent under _[ROA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
_[1974,which he regarded as “a neat and logical suggestion which this court should adopt”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_

113. Ms Monaghan argues that, just as there is no justification for the disclosure of information about past
convictions of offences of soliciting contrary to section 1 of SOA 1959 (her Ground 2 argument), so there is
no justification for recording and retaining that information. Ms Monaghan further submits that the
recording and retention of such information violates Article 14 (read with Article 8), for the reasons which
she has argued under Ground 3; and violates Article 4 and the Directive 2011/36/EU because it conflicts
with the positive obligations therein to protect victims of trafficking and with the provisions as to nonpenalisation and anonymity.

The defendants' case

114. The defendants submit that this ground is unarguable and that permission was rightly refused.
Although the recording and retention of criminal record data engages Article 8, it interferes with Article 8
rights to only a limited extent. Ms Gallafent refers to a number of decided cases for the proposition that the
need for a comprehensive database of criminal convictions is compatible with Article 8 and is both
necessary and proportionate to the legitimate aims of detecting and preventing crime and protecting the
rights of others. It is not necessary to cite each of them but, by way of example, R (C & J) v Commissioner
_of Police for the Metropolis_ _[2012] EWHC 1681 (Admin) at paragraph 61, was a case in which the court_
held that retention on the PNC record of information about an individual's arrest for (but not conviction of)
an alleged rape was not a disproportionate interference with the individual's Article 8 rights. At paragraph
61 Richards LJ (with whom Kenneth Parker J agreed) said –

“It seems to me that a PNC record that did not include the basic history of [the individual's] involvement
with the police would be an incomplete and potentially misleading record. Moreover, if a similar allegation
were made against [the individual] in the future, it would be profoundly unsatisfactory if it fell to be
considered without knowledge of the earlier allegation and the arrest and investigation to which it gave rise.
I am satisfied that retention of this kind of information in the PNC record is justified on any view. If it
engages Art 8 at all, the interference with [the individual's] right to respect for his private life is small and is
plainly proportionate.”

Ms Gallafent understandably places emphasis on the fact that the court was there concerned with a record
of an allegation, not of a conviction; and she refers to other decided cases which also refer to the need for
a criminal record to be complete because otherwise it may potentially be misleading (see, eg, _Chief_
_Constable of Humberside Police v Information Commissioner_ _[2009] EWCA Civ 1079 per Hughes LJ at_
paras 107-111)


-----

ER (D) 13 (Mar)

115. Ms Gallafent submits that the existence of the offence of soliciting contrary to section 1 of SOA 1959
does not breach any Convention rights (a point more fully considered under Ground 7 below), and that it is
therefore impossible to argue that the recording and retaining of data about convictions for such an offence
involves a breach of Convention rights merely because more women than men are convicted of the
offence. The retention of such data is necessary because section 1 prescribes a different maximum
penalty for a second subsequent conviction; it is justified under Article 8; and Article 4 is not engaged and
adds nothing.

**Conclusion as to Ground 5:**

116. We can state our conclusion on this ground briefly. We can accept Ms Monaghan's submission that
this ground does seek to add something to other grounds. The ground is, however, unarguable, for the
reasons given by Ms Gallafent. There is only a very limited interference with an individual's Article 8 rights
when the State records and retains information about criminal convictions, and that limited interference is
plainly justified in the public interest – especially where, as is the case under section 1 of SOA 1959, the
maximum penalty is increased when there is a conviction of a second or subsequent offence. In our
judgment, there is no merit in this ground and we refuse permission.

117. As has been indicated, ground 6 is no longer pursued.

**Ground 7:**

118. Ground 7 contends that “the criminalising of conduct falling within the scope of section 1 of SOA 1959
violates Article 8 read with Article 14 ECHR because it is gender discriminatory”. Permission to proceed on
this ground was refused by William Davis J on the basis that it added nothing to other grounds.

The claimants' case

119. Ms Monaghan again argues that this ground does add something to other grounds, because it
concerns the legality of section 1 of SOA 1959. She denies that this ground raises only a hypothetical
point, because none of the claimants is now engaged in prostitution; on the basis that if the section itself
violates Article 8, then there can be no lawful right to maintain, or to require disclosure of, criminal records.
She relies on her Ground 3 submissions as to the gender-discriminatory effect of section 1, and repeats
her argument that the criminalising of conduct falling within section 1 of SOA 1959 is discriminatory, and
violates Articles 8 and 14, because it is overwhelmingly committed by women and disadvantages them.

120. Ms Monaghan seeks to support her submissions by reference to a number of international
instruments, including the General Recommendations adopted by the UN Committee on the Elimination of
Discrimination Against Women. She relies in particular on paragraph 31 of General Recommendation No
35 (2017), which recommends the repeal of any legal provisions which criminalise women in prostitution.

The defendants' case

121. The defendants point out that this ground was not advanced in pre-action correspondence, and
submit that it raises an entirely abstract and hypothetical challenge which should not be entertained by this
court. The claimants were not convicted under section 1 of SOA 1959 in its present form, and section
22(4) of the Human Rights Act 1998 (set out at paragraph 30 above) prevents them from now trying to
apply the provisions of that Act retrospectively to convictions imposed long before it came into force.  This
ground therefore seeks a remedy which is not available to the claimants. Ms Gallafent relies on _R_
_(Rusbridger) v HM Attorney General [2003] UKHL 28 as authority that a declaration as to the legality of_
future conduct should only be granted in very exceptional circumstances.

122. Moreover, even if section 1 of SOA 1959 in its present form were to be declared incompatible with
Article 8, that in itself would not mean that there could be no justification for retaining data about offences
committed when the legislation was in a different form.

123. In any event, Ms Gallafent submits, it is for Parliament to determine what conduct should or should
not constitute a criminal offence. That important principle was referred to in R v Jones _[2006] UKHL 16:_


-----

ER (D) 13 (Mar)

Lord Mance at paragraph 102 referred to the creation and regulation of crimes being, in a modern
Parliamentary democracy, “a matter par excellence for Parliament to debate and legislate”; and at
paragraph 29 Lord Bingham referred to –

“… what has become an important democratic principle in this country: that it is for those representing the
people of the country in Parliament, not the executive and not the judges, to decide what conduct should
be treated as lying so far outside the bounds of what is acceptable in our society as to attract criminal
penalties. One would need very compelling reasons for departing from that principle”.

The offence of soliciting raises moral, ethical and practical issues, which should be considered by
Parliament and not by the courts. Although the claimants suggest that the offence of soliciting is only a
form of public nuisance, it must be remembered that prostitution can cause serious nuisance and
considerable distress to those living in areas where street prostitution is prevalent. Having justifiably made
such conduct an offence in 1959, Parliament has made amendments to section 1 of the Act on two
[occasions since the Human Rights Act 1998 came into effect but has retained the offence. Ms Gallafent](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
acknowledges that there is a respectable body of opinion in favour of decriminalising prostitution, but
submits that it is part of a policy debate which the courts should not seek to resolve. Although the
claimants point to a number of influential reports, they are not able to cite any authority in support of their
argument that prostitution offences breach Article 14 rights. Moreover, as has been considered above, the
proposition that a gender-neutral offence is in breach of Article 14 rights because it is predominantly
committed by women would have dramatic consequences for the many offences which are predominantly
committed by men – including, for example, the summary offences of kerb-crawling and persistent
soliciting of women. As Ms Gallafent succinctly puts it, it cannot be said that either the whole of the
criminal law, or the criminal law relating to many specific offences, are unlawfully discriminatory against
men. She submits that the international instruments relied on by the claimants provide at best only slight
authority in support of their claim: see R (A & B) v Secretary of State for Health _[2017] UKSC 41 (also a_
case in which the claimants relied on a CEDAW General Recommendation) per Lord Wilson at paras 3435.

**Conclusion as to Ground 7:**

124. As with Ground 5, we can deal with this ground shortly. Once again, we can accept that it does seek
to add something to other grounds. But what it adds is a very bold submission for which Ms Monaghan
has shown no arguable basis. The various international instruments and reports on which she relies carry
only limited weight, for the reasons explained earlier in this judgment, and the claimants' case based on
gender discrimination – on which the ground depends - has failed. Not all who commit offences of
soliciting have been coerced or trafficked.

125. In any event, the authorities cited by Ms Gallafent make it entirely clear that it is for Parliament to
determine the ambit of the criminal law. In our judgment, Ms Monaghan, in her brief submissions on this
ground, has been quite unable to put forward any compelling reasons why this court should depart from
that principle, let alone the “very compelling reasons” which _Jones indicates must be established._
Whatever the morality of selling sexual services, soliciting in public places is capable of giving rise to a
public nuisance and can have significant adverse consequences for local residents. Section 1 of SOA
1959 is concerned with conduct of a kind which raises many issues for debate, and in our judgment it is not
arguable that the debate should be resolved by the courts rather than by Parliament.

126. In any event, we see force in Ms Gallafent's submission that this ground is hypothetical, since none of
the claimants is now engaged in prostitution, and the lawfulness of the retention of data about their past
soliciting offences has been considered under the earlier grounds.

127. Permission is therefore refused.

**Overall conclusion:**


-----

ER (D) 13 (Mar)

128. In the result, the claim succeeds only on ground 1. As indicated at the hearing, we invite the parties
to agree an order reflecting our judgment. If agreement is not possible, we will receive written submissions
as to the appropriate form of order.

**End of Document**


-----

