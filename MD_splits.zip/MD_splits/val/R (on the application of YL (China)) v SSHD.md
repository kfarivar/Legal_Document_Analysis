# R (on the application of YL (China)) v SSHD [2018] EWHC 3541 (Admin)

QBD, ADMINISTRATIVE COURT

CO/2938/2018

Mr Mathew Gullick

Thursday, 29 November 2018

29/11/2018

J U D G M E N T

A P P E A R A N C E S

MISS R. KOTAK (instructed by Duncan Lewis Solicitors) appeared on behalf of the Claimant.

MR N. FETTO (instructed by the Government Legal Department) appeared on behalf of the Defendant.

____________THE DEPUTY JUDGE:

1 This is a claim for judicial review which has an unfortunate recent procedural history which I will recite before
giving judgment on the substantive issues which I have been asked to determine today.

2 The claimant is a national of China, who came to the United Kingdom in December 2014 as a visitor. She
overstayed her period of leave and was arrested in November 2015. She was released but failed to report as
required. She was again arrested in March 2018, when she was detained. She subsequently claimed asylum. Her
asylum claim was rejected by the defendant and is the subject of an appeal to the First-Tier Tribunal.

3 The claimant also claimed to have been a victim of trafficking for the purposes of sexual exploitation. On 10 April
2018 her then solicitors wrote to the defendant, stating that she had been forced into prostitution in China for a
number of years and that she had been beaten. A subsequent report under rule 35 of the Detention Centre Rules
showed that she had scars consistent with her account. The claimant was referred, under the National Referral
Mechanism, to the competent authority for determination of whether she was a potential victim of trafficking. That
claim was rejected on 20 April 2018, essentially on the grounds that the claimant's account was not credible and
that her accounts of her history, given at different times, had a number of discrepancies. This rejection was at the
second stage, “reasonable grounds” decision, after the first stage referral.

4 The claimant self-harmed in detention and there are multiple references to her being severely distressed. She
was released from detention following a successful bail application on 10 July 2018.

5 On 20 July 2018, three months after the rejection of her claim to have been a victim of trafficking, the claimant
filed a claim for judicial review in this court, requesting the quashing of the decision of 20 April 2018. The claim also
included a claim for a declaration and damages for her by then historic alleged unlawful detention in respect of the
period from 4 April 2018 to 10 July 2018.


-----

6 The claimant further sought a declaration that the defendant's policy “Victims of **_Modern Slavery: Competent_**
Authority Guidance” was unlawful. Three grounds are advanced in the extensive grounds of review submitted with
the claim form. Those grounds themselves run to no fewer than 112 paragraphs and 50 pages.

7 On Ground 1, the claimant contends that the negative decision on her trafficking claim at the “reasonable
grounds” stage is unsustainable in law because of a failure to follow policy, including alleged failure to put
inconsistencies to the claimant and because an incorrect standard of proof was supposed to have been applied.
Permission was granted on this ground by Mr Andrew Thomas QC, sitting as a Deputy High Court Judge, on
considering the papers on 15 October 2018.

8 On Ground 2, the claimant contends that “the requirement in the guidance that victims present as consistent is
unlawful”. Mr Thomas QC refused permission on that ground on the basis that the guidance was not as inflexible
as suggested and, in any event, it had to be read against the other guidance and policy, to which the claimant
herself referred.

9 On Ground 3, again permission was granted by Mr Thomas QC. The claimant argues that the failure to refer her
earlier and what she says is the unlawful failure to make a positive “reasonable grounds” decision, renders her
detention unlawful. Additionally, she relies on the rule 35 report and what is said to be a failure to act to release her
despite what is said to be her presentation as a seriously suicidal person with numerous self-harming injuries.

10 Mr Thomas QC's order contained standard form directions for the trial of this claim and any potential renewal of
the application for permission on Ground 2.

11 It was at this point that things began to go wrong. The application for permission on Ground 2 was renewed,
although it seems no fee was paid. The court sent an email to the parties regarding the listing of the substantive
hearing which resulted in that being fixed, on 29 October, to take place today, 29 November, together with the
renewed application for permission on Ground 2. Those involved in listing the claim appear not to have realised
that this listing resulted in the defendant's detailed grounds of defence becoming due after the final date for the
claimant's skeleton argument. So this listing date would have required either an adjournment or active cooperation
between the parties to adjust the deadlines in the order so as to file the necessary documents, evidence and
authorities prior to the hearing. That cooperation appears not to have taken place. There were proposals and
counter-proposals for the resolution or part-resolution of the proceedings and an application by the claimant to
vacate the hearing, save for the renewed permission application on Ground 2. That application, although dated 16
November, was not issued and sealed by the court until 22 November, four clear working days before the trial date.

12 The defendant's detailed grounds of defence were filed on 19 November and state in terms that the trafficking
decision has been withdrawn and so the claim, it is said, is academic save for the unlawful detention ground which
the defendant argues should be transferred to the Queen's Bench Division list or to the County Court. A proposed
consent order was provided but over the past ten days no form of consent acceptable to both parties was agreed.
There were further negotiations regarding a consent order to vacate the hearing over the last few days but no final
order was filed, and, as a result, this matter came before me, listed for trial this morning on Grounds 1 and 3, and
for permission on Ground 2. Neither party was ready for a trial of any of the remaining issues in this case including,
in particular, the unlawful detention claim.

13 This unfortunate set of procedural circumstances since permission was granted has led to a regrettable waste
of the court's time. In saying this, I do not seek to apportion blame between the parties: that is simply what has
happened.

14 Both parties were, however, agreed about what should happen today. Firstly, as the decision challenge has
now been withdrawn, then Ground 1 falls away. The defendant concedes that he will pay some part of the
claimant's costs as a result.

15 That leaves the question of permission on Ground 2. The parties are agreed that if I grant permission on
Ground 2 then both Grounds 2 and 3 should proceed to trial in this court. If, however, I refuse permission on


-----

Ground 2 then the unlawful detention claim, which is contained in Ground 3, would be all that remains in these
proceedings and they should be transferred to the County Court to proceed as a Part 7 claim.

16 After that procedural history, I turn to the question of permission on Ground 2. The claimant contends that the
defendant's policy, as I have already set out, is unlawful. When refusing permission to apply on the papers, Mr
Thomas QC said this about Ground 2:

“I do not grant permission on Ground 2. I do not accept the claimant's submission that the guidance is as inflexible
as is suggested and, in any event, it is to be read alongside the other guidance and policy to which the claimant
herself has referred.”

17 The defendant resists the grant of permission on Ground 2 on two bases. Firstly, that it is now academic as the
negative “reasonable grounds” decision has been withdrawn. There is, therefore, says the defendant, no live
decision capable of grounding a challenge to the defendant's policy. Secondly, the defendant invites me to adopt
the approach of Mr Thomas QC, which I have already set out, to the merits of the arguments being advanced.

18 I can say straightaway that I reject the defendant's argument that Ground 2 is academic for the reasons given
by Miss Kotak, namely that the question of whether the claimant was detained pursuant to a decision reached
under an unlawful policy when she would not have been detained absent the alleged unlawful features is an issue
potentially going to the lawfulness of detention on Ground 3, on which permission has been granted. In fairness to
him, Mr Fetto did not press the point.

19 Despite Miss Kotak's submissions, however, in my judgment, permission to apply for judicial review on Ground
2 should be refused. I should start by saying that I am in agreement with the view taken by Mr Thomas QC when
he refused permission on the papers. The claimant's arguments, as set out in the pleaded grounds of review, are
based on a fundamental misconception of the nature of the defendant's policy, as it is set out in the guidance. The
policy does not, as the heading to Ground 2 on p.16 of the grounds of review states “require trafficked persons to
present in a coherent and consistent way unless there is evidence of trauma”. Nor, as said at para.53 of the
grounds of review, is there under the policy a “requirement that victims present as consistent”. The policy, in
relevant parts, states at p.98:

“It is also reasonable to assume that a potential victim who has experienced an event will be able to recount the
central elements in a broadly consistent manner. A potential victim's inability to remain consistent throughout their
written and oral accounts of past and current events may lead the competent authority to disbelieve their claim …”.

20 I agree with what is said in the summary grounds of defence and by Mr Fetto that, properly read, the sentence
does not impose a requirement that a potential victim be consistent, which is what is said in the grounds of review.
Rather, it guides decision-makers that they may take into account, when assessing credibility, whether the central
elements of the factual account have been presented broadly consistently. I consider the contrary to be unarguable.
Further, the guidance at p.99 says this:

“When the Competent Authority assesses the credibility of a claim there may be mitigating reasons why a potential
victim of human trafficking/modern slavery is incoherent, inconsistent or delays giving details of material facts.
The Competent Authority must take these reasons into account when considering the credibility of a claim. Such
factors may include, but are not limited to, the following:

∙ Trauma (mental, psychological, or emotional)

∙ Inability to express themselves clearly

∙ Mistrust of authorities

∙ Feelings of shame

∙ Painful memories (including those of a sexual nature).”


-----

21 These potential mitigating reasons are not limited to trauma, as suggested in the claimant's grounds. They
include a variety of other potential reasons, including a person's inability to express themselves clearly. In my
judgment, it is clear, contrary to the claimant's contentions, that the policy does not impose the sort of requirement
discussed in the pleaded grounds, the contrary being unarguable.

22 In her oral submissions today, however, Miss Kotak went, in my judgment, considerably further than the
pleaded grounds of review. As I understood her, she complained about the use of credibility in the first place in this
type of decision at the “reasonable grounds” stage. In my judgment, any such contention, even if it had been
pleaded, which it has not, is not reasonably arguable.

23 I was referred to a number of authorities but I found of considerable assistance the judgment of Deputy Judge
Helen Mountfield QC in the case of R (on the application of Minh) v Secretary of State for the Home Department

_[2015] EWHC 1725 (Admin). Miss Kotak took me through this decision in detail. It was a decision which took into_
account the previous version of the policy now under challenge which, Miss Kotak informs me (and I accept), has
not materially changed for the purposes for which it is cited in this claim. In particular, it seems to me, from
considering the judgment of the learned Deputy Judge in that case, that the questions of credibility and consistency,
as set out in the guidance, are, and were found in her judgment, to be entirely relevant to the question of whether
there were reasonable grounds in this type of case. The learned Deputy Judge says in terms at para.80:

“Although credibility is relevant to the existence or otherwise of "reasonable grounds", a decision-maker does not
have to (and may be unable to) form a concluded view on credibility at the "reasonable grounds" stage of the
decision-making process under the National Referral Mechanism …”.

24 In my judgment, it is clearly lawful and consistent with the United Kingdom's obligations under the Council of
Europe Convention on action against trafficking in human beings that there is consideration of credibility at the
“reasonable grounds” stage, including consideration, as per the defendant's policy, of the issue of consistency.
Whilst I accept that, as Miss Kotak said, based on the material supplied by the Helen Bamber Foundation, there is a
basis for criticising the approach in the policy, in my judgment, on the material brought before the court the
evidence does not come close to establishing that the policy is unlawful in this regard. Ultimately at this stage, as
the policy says, the question is whether there are “reasonable grounds” to believe the claim, not whether the claim
is in fact established. In my judgment, it is clear and unarguable to the contrary that inconsistencies are relevant to
the assessment at this point but, as the policy says, the reasons for such inconsistencies must be carefully
considered.

25 Miss Kotak forcefully criticised the application of the policy in practice, in addition to its wording and scope.
Again, this goes beyond the pleaded grounds of review. Miss Kotak submitted that in practice what is being
required by the defendant, acting as the competent authority, is proof of trauma; the other potential reasons listed in
the policy, to which I have already referred, being ignored in practice. Miss Kotak said in practice it is impossible to
obtain such evidence during the period of five days in which the “reasonable grounds” decision must be taken.
However, as Mr Fetto submitted, there is no requirement in the policy that a claimant must provide such evidence.
It may come from other sources, including a rule 35 report which was undertaken and provided in this case and
which was considered by the decision-maker when the “reasonable grounds” decision was made.

26 The trouble, as I have said, is that none of this is pleaded in the grounds of review and there is no evidence,
save the decision in the particular case of this claimant, as to how the policy has been applied in practice so as to
enable a systemic challenge to be mounted, whether by a lead claimant or a representative body such as a charity.
I entirely accept Miss Kotak may have had difficulties in obtaining such evidence but I must consider the arguments
and evidence before me now. In addition, I remind myself that these points have simply not been pleaded as part
of Ground 2, in what were extremely extensive grounds of review, and no application to amend or alternative
grounds have been put forward. What might be the position on such other pleadings and other evidence is not a
matter for me today.

27 I also bear in mind the recent decision of Farbey J, to which I was referred by Miss Kotak. That is, in fact, a
decision handed down today, 29 November 2018, in the case of R (on the application of MN) v Secretary of State


-----

_for the Home Department (the Aire Centre intervening)_ _[2018] EWHC 3268 (Admin), in which the learned Judge_
considered a number of questions at trial in relation to the final stage of the decision-making process, namely the
final decision as to whether someone is a victim of trafficking. In that judgment the learned Judge said this:

“63. In my judgment, the appropriate standard for the assessment of a claim to have been trafficked will depend on
the legal issue to which it is relevant. If the issue is whether a person will suffer persecution under the Refugee
Convention or ill-treatment prohibited by article 3 ECHR, the lower standard will apply. If the issue is whether a
person has the specific rights available to victims of trafficking under ECAT, the standard has been rationally set by
the Secretary of State as the balance of probabilities. I am fortified in taking this issue-based approach by _RM_
_(Sierra Leone) v Secretary of State for the Home Department [2015] EWCA Civ 541 at [35] (cited in AS (Guinea) v_
_Secretary of State for the Home Department and another [2018] EWCA Civ 2234 at [55]). In that case, Underhill LJ_
applied an issue-based approach to the standard of proof to be applied in determining a person's nationality. He
held that the same question may require different standards, depending on whether it was relevant to an asylum
claim or some other claim.

64. In principle, it is possible that the Secretary of State may reject a trafficking claim on the balance of probabilities
but accept the same evidence in an asylum claim on the lower standard. I doubt that the different standard would
make a practical difference in every case. It would be unlikely to make a difference in the present case, where the
claimant has at every stage been disbelieved. …”.

28 In my judgment, insofar as Miss Kotak complained, on a matter again not pleaded in the grounds of review,
regarding the standard applied at the “reasonable grounds” stage in this particular context, Farbey J's judgment in
that case provides a clear answer to the point, which is that different standards may be applied at different stages of
the process for different purposes. In my judgment, quite apart from the fact that it is not pleaded in the grounds of
review, the arguments made regarding the standard being applied at this stage by Miss Kotak were not reasonably
arguable and had they been pleaded in the grounds of review I would have refused permission on this basis also.

29 Accordingly, for these reasons I refuse permission to apply for judicial review on Ground 2 in this claim. I will,
therefore, in accordance with the views of the parties, now transfer what remains of this claim, namely Ground 3, to
the County Court and I will hear counsel on any issues of costs that may arise.

THE DEPUTY JUDGE: Miss Kotak, you want your costs on Ground 1 or some part of the claim, do you not?

MISS KOTAK: Sorry, my Lord?

THE DEPUTY JUDGE: You want your costs on Ground 1 or some part of the claim, do you not?

MISS KOTAK: I want costs on Ground 1.

THE DEPUTY JUDGE: Yes. I am inviting you first because you have succeeded in having---
MISS KOTAK: Yes.

THE DEPUTY JUDGE: -- a decision revoked, so – and they have agreed to paid your costs. So you want your
costs, do you not?

MISS KOTAK: Yes.

THE DEPUTY JUDGE: On what basis would you like your costs? Costs of the issue on Ground 1 or a
percentage?

MISS KOTAK: The first one.

THE DEPUTY JUDGE: So the costs of – so the order will be that the defendant shall pay the claimant's costs of –
of and occasioned by Ground 1 of the grounds of review?


-----

MISS KOTAK: Yes.

THE DEPUTY JUDGE: To be assessed if not agreed.

MISS KOTAK: Yes.

THE DEPUTY JUDGE: Yes. And the costs in relation to Ground 3 are reserved to the trial in the County Court. It
should be the Central London County Court, I think, unless anyone wants to transfer it to some other County Court?

MISS KOTAK: No, that is fine.

THE DEPUTY JUDGE: And what about costs in relation to Ground 2?

MR FETTO: My Lord, we seek our costs in relation to Ground 2. We also seek our costs of today. We have
basically ended up where we invited the claimant to – a position that we invited the claimant to reach just after we
filed our detailed grounds. So the consent order attached to our detailed grounds was in terms that the – sorry, I
am looking at the claimant's consent order – was that there be a withdrawal of the decision, today would be
vacated, the challenge to the lawfulness of detention be transferred to the County Court and we pay the reasonable
costs of the negative “reasonable grounds” decision or, in effect, Ground 1.

THE DEPUTY JUDGE: Yes, Mr Fetto, but that – that was based on your – your solicitor's assessment that the
claim was entirely academic which was, I found, to be incorrect.

MR FETTO: Well, the underlying reasoning is different, my Lord, I accept, but the result is the same.

THE DEPUTY JUDGE: Well, the result is not the same because permission – permission on Ground 2 was
relevant to the lawfulness of detention, therefore it had to be heard, and had the consent order have been entered
into it would not have been heard. So I do not – I do not think there is any criticism of the claimant for not entering
into that consent order.

MR FETTO: Yes, my Lord, I have your clear indication. I would – I should make one more point, which is that the
claimant pursued Ground 2 but lost it so really---
THE DEPUTY JUDGE: Yes.

MR FETTO: -- my point on that is that it is costs following the event.

THE DEPUTY JUDGE: Well, costs following the event but of the acknowledgement of service, Mr Fetto, is it not,
because it is a permission decision?

MR FETTO: Yes, I follow that, my Lord. I follow that. So---
THE DEPUTY JUDGE: Do you want your costs of the acknowledgement of service in relation to Ground 2?

MR FETTO: Yes. My Lord, so far as the apportionment is concerned, or the nature of the order is concerned, Miss
Kotak has requested costs in relation to the issue of Ground 1. My proposal was going to be that we treated it as a
third, effectively, of the proceedings up till now.

THE DEPUTY JUDGE: Well, Mr Fetto, if that was your proposal, I was not going to accept – I would not accept it
because Ground 1, it seems to me, was the gravamen of this claim and she succeeded in the result. If you want to
pay a percentage it is going to be significantly higher than a third.

MR FETTO: Well---
THE DEPUTY JUDGE: You can – you can try – you can try me on a percentage but if Miss Kotak wants an issuesbased costs order then, even if you achieve a percentage, it is going to be significantly higher than a third.


-----

MR FETTO: Yes. Well, my Lord, it may be – it may be better if I turn my back on you briefly now and see whether--
THE DEPUTY JUDGE: Yes.

MR FETTO: -- I am to take it further. (After a pause): My Lord, I am not taking the point further.

THE DEPUTY JUDGE: In that case, Miss Kotak, can you say anything about the defendant's costs in relation to
Ground 2, on the acknowledgement of service?

MISS KOTAK: I accept that that should follow the event.

THE DEPUTY JUDGE: Yes. So that is the – so that is the defendant's costs – the claimant shall pay the
defendant's costs of the acknowledgement of service in relation to the issue on Ground 2. The claimant to get her
costs in relation to Ground 1 of the entire claim. The claim to be transferred to the County Court for trial on Ground
3 and the costs in relation to Ground 3 be reserved to the trial on Ground 3, or I suppose they should be costs in the
case in the County Court, the costs incurred in this court on Ground 3.

MR FETTO: Yes, I think I am content with that, my Lord.

THE DEPUTY JUDGE: Yes.

MISS KOTAK: Yes, thank you.

THE DEPUTY JUDGE: Yes. Is there anything else either of you want to raise with me?

MISS KOTAK: No, my Lord. Thank you.

THE DEPUTY JUDGE: No. Well, thank you both.

MISS KOTAK: Well, the detailed assessment of---
THE DEPUTY JUDGE: I am sorry, I thought you were not publicly funded but if you are, of course.

MISS KOTAK: We are publicly funded, yes.

THE DEPUTY JUDGE: Ah, I am so sorry. Of course you can have detailed assessment, yes.

MISS KOTAK: Thank you.

THE DEPUTY JUDGE: Would you agree the order and submit it in the usual way, please? Mr Fetto, would you
mind having carriage of the order and submitting it?

MR FETTO: Very well, my Lord.

THE DEPUTY JUDGE: Particularly as Miss Kotak is legally aided and you are not. I think if you have carriage of
the order and draft it and submit it to her and then submit it to me.

MISS KOTAK: I appreciate that.

THE DEPUTY JUDGE: Thank you both very much.

__________

CERTIFICATE

Opus 2 International Ltd. Hereby certifies that the above is an accurate and complete record of the judgment or part
thereof.


-----

Transcribed by Opus 2 International Ltd.

(Incorporating Beverley F. Nunnery & Co.)

Official Court Reporters and Audio Transcribers

5 New Street Square, London EC4A 3BF

Tel: 020 7831 5627   Fax: 020 7831 7737

**_admin@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

