# *R v MK; R v Gega (also known as Maione) [2018] EWCA Crim 667

Court of Appeal, Criminal Division

Lord Burnett CJ, Andrews and Martin Spencer JJ

28 March 2018Judgment

**Mr Amjad Malik QC (who did not appear in the Crown Court) and Mr Glenn Harris for the appellant**
**MK**

**Mr Andreas O'Shea for the appellant Persida Gega**

**Mr John McGuinness QC and Mr Ben Douglas-Jones QC for the Respondent**

Hearing date: 7 March 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**The Lord Burnett of Maldon:**

1. The common issue raised in both these otherwise unrelated appeals is whether the legal (or
persuasive) burden of proof rests on the defendant when a defence is raised under section 45 of the
**_Modern Slavery Act 2015 (“the 2015 Act”), or whether the defendant bears only an evidential burden with_**
the prosecution having to disprove to the criminal standard one or more of the elements of the defence.
The applications for leave to appeal have been referred to the full court by the Registrar.

**The Convictions**

2. On 19 June 2017 in the Central Criminal Court, MK, who used the alias D, was convicted of two
offences. First, conspiracy to supply a Class A drug (cocaine), contrary to section 1(1) of the Criminal Law
Act 1977; and secondly, of being in possession of an identity document with improper intention, contrary to
sections 4(1) and 4(2) of the Identity Documents Act 2010. On 26 June 2017 she was sentenced by HH
Judge Lucas QC to 8 years' imprisonment on the offence of conspiracy and 5 months' imprisonment on the
second count, to run concurrently. Her co-defendant, a man named AM, had pleaded guilty to the same
offences at a much earlier stage. He received a sentence of 6 years and 9 months imprisonment on the
count of conspiracy, with full credit for his early plea, and 5 months' imprisonment on the second count to
run concurrently. MK seeks leave to appeal against her conviction and her sentence.

3. On 9 June 2017 in the Crown Court at Wood Green, Persida Gega, who used the alias Anna Maione,
was convicted of a single count of possession of an identity document with improper intention. On the
same date, she was sentenced by Mr Recorder Rajah QC to 15 months' imprisonment. Her expedited
application for leave to appeal against that sentence was refused by this court on 19 July 2017. She seeks
leave to appeal against her conviction.

4. In each of these cases, the applicant is an Albanian national who claimed to have been a victim of
trafficking and who sought to rely on the statutory defence afforded to such victims under section 45 of the
2015 Act.


-----

**[The Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)**

5. Section 45 of the 2015 Act provides:

“Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if –

(a) The person is aged 18 or over when the person does the act which constitutes the offence;

(b) The person does that act because the person is compelled to do it;

(c) The compulsion is attributable to slavery or to relevant exploitation, and

(d) A reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if 
(a) It is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) It is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if

(a) The person is under the age of 18 when the person does the act which constitutes the offence;

(b) The person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation; and

(c) A reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5) For the purposes of this section –

“Relevant characteristics” means age, sex and any physical or mental illness or disability

“Relevant exploitation” is exploitation (within the meaning of section 3) that is attributable to the exploited
person being, or having been, a victim of human trafficking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.

(8) The Secretary of State may by regulations amend Schedule 4.”

6. Sections 1 to 3 of the 2015 Act set out what constitutes respectively slavery, servitude and forced or
compulsory labour, human trafficking, and the meaning of “exploitation”. Section 1 provides that:

“(1) A person commits an offence if –

(a) The person holds another person in slavery or servitude and the circumstances are such that the
person knows or ought to know that the other person is held in slavery or servitude, or

(b) The person requires another person to perform forced or compulsory labour and the circumstances are
such that the person knows or ought to know that the other person is being required to perform forced or
compulsory labour.

(2)   In subsection (1) the references to holding a person in slavery or servitude or requiring a person to
perform forced or compulsory labour are to be construed in accordance with Article 4 of the Human Rights
Convention.”


-----

7. By Section 2, human trafficking constitutes an offence if a person arranges or facilitates the travel of
another person with a view to that other person being exploited. Section 3 defines “exploitation” as
including circumstances where a person is the victim of behaviour which involves the commission of an
offence under section 1, (section 3(2)(a)); or where something is done to or in respect of the person which
involves the commission of an offence under Part 1 of the Sexual Offences Act 2003 (section 3(3)(a)(ii)); or
where the person is subjected to force, threats or deception designed to induce him or her to provide
services of any kind, to provide another person with benefits of any kind, or to enable another person to
acquire benefits of any kind (section 3(5)).

8. Schedule 4 sets out those offences that are excluded from the defence under section 45. The long list
of excluded offences includes murder, manslaughter, piracy, false imprisonment, kidnapping and
perverting the course of justice, the most serious offences of violence under the _[Offences Against the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)_
_[Person Act 1861 (including offences under sections 18 and 20), sexual offences, offences under the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)_
_[Domestic Violence, Crime and Victims Act 2004,cruelty to children, female genital mutilation, certain](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61F0-TWPY-Y0BK-00000-00&context=1519360)_
firearms offences, robbery, burglary, blackmail, hostage-taking, hijacking and other offences endangering
[the safety of aircraft, offences under the Explosive Substances Act 1883,and terrorism offences.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61D0-TWPY-Y1D2-00000-00&context=1519360)

9. Whilst Schedule 4 excludes many serious offences, including offences of violence, it does not exclude
other serious offences which may result in the imposition of long sentences of imprisonment on a convicted
defendant, such as the supply of, or conspiracy to supply, Class A drugs, or their importation.

**The ruling of the judges on this issue**

10. Following written and oral submissions, HH Judge Lucas QC gave a careful and detailed written ruling
in MK's case, a copy of which was provided to Recorder Rajah QC in Ms Gega's case. The Recorder
considered various arguments that had not been raised on behalf of MK but came to the same conclusion
as Judge Lucas QC.

11. The effect of the rulings may be summarised in this way:

(i) The defendant bears an evidential burden to raise the issue whether she was a victim of trafficking or
slavery;

(ii) Having successfully done so, it is for the prosecution to prove, beyond reasonable doubt, that she was
not;

(iii)  If the prosecution succeeds in that, the section 45 defence will not avail the defendant;

(iv)  However, if the prosecution fails in this respect, the legal or persuasive burden of proof in respect of
the other elements of the defence falls on the defendant. Therefore, if the defendant is over 18 years old,
she must prove on the balance of probabilities:

(a) That she was compelled to commit the offence;

(b) That the compulsion was as a direct consequence of her being or having been a victim of slavery or
relevant exploitation; and

(c) That a reasonable person in the same situation as her and having her relevant characteristics would
have no realistic alternative to doing the act which constitutes the offence.

**The legal submissions**

12. The applicants submit that the trial judge in each case misdirected the jury as to the burden and
standard of proof where a defendant raises a defence under section 45 of the 2015 Act. The Act itself is
silent on the question of who bears the burden of proof. They contend that:

i)  Section 45 of the 2015 Act does not fall within the third category of provisions identified by Lord Hope in
_R v DPP ex parte Kebilene [2000] 2 AC 326 at 379F-H as reversing the burden of proof. Properly_
construed, it does not relate to an exemption or proviso which the accused must establish if he wishes to


-----

avoid conviction but is not an essential element of the offence. It absolves the defendant of criminal
responsibility;

ii) There is no justification for a finding that Parliament intended that one element of the statutory defence
(i.e. whether the defendant was a victim of trafficking) was the subject of the usual legal burden, but that all
the other elements had a reverse burden;

iii) It would be very odd to interpret a provision aimed at furthering protection for trafficked individuals as
more onerous than the existing common law defence of duress, to which it bears a close resemblance.
That is so especially as in many cases of this nature both defences will be raised and depend on the same
alleged facts, with the consequent difficulties for juries in applying a different test in respect of each
defence;

iv) The judges' finding that the burden should rest on the defendant because she is best placed to identify
the circumstances of her personal situation betrays a fundamental misunderstanding of the situation in
which a victim of trafficking or slavery will find herself. It deprives victims of the protection that the section
was designed to provide.

v) The reversal of the burden of proof is contrary to the clear intention of Parliament as expressed in
Parliamentary debates.

The last of these points was not developed orally.

13. The respondent submits:

i) The judges below rightly held that it is for a defendant to raise the evidential burden that she has been
subjected to trafficking, slavery or servitude, and that once raised, it falls to the prosecution to disprove
such a claim to the criminal standard.

ii) If the prosecution cannot disprove that claim, then section 45 of the 2015 Act operates independently of
any statute creating an offence. It does not comprise any essential element of an offence, but operates as
an exception, exemption, excuse, proviso or qualification, providing a defence to defendants who are
otherwise guilty of non-exempted offences. It therefore falls within the third category of statutory provisions
identified by Lord Hope in Kebilene as placing a persuasive burden on the defendant.

iii) There is no analogy with duress, which is a much narrower defence and easier for the prosecution to
disprove. Under section 45, there is no need to establish a threat of violence or any need for a belief on the
part of the defendant that such threats would be carried out immediately or almost immediately if she did
not do what she was told. There is no absurdity in placing a more onerous burden on the defendant who
raises the defence under section 45, given that the statutory defence is far wider in scope and relates to a
multitude of criminal offences of varying degrees of seriousness. The defendant is far better placed than
the prosecution to establish the relevant elements.

iv) The reversal of the burden of proof would be consistent with the approach adopted in relation to the
statutory defence under Section 31 of the Immigration and Asylum Act 1999 (“the 1999 Act”) when raised
as a defence to one or more offences under the _Forgery and Counterfeiting Act 1981,which was_
considered in R v Makuwa _[2006] EWCA Crim 175, [2006] 2 Cr App R 11._

v) The scope of the rule in Pepper (Inspector of Taxes) v Hart [1992] UKHL 2, [1993] AC 593relating to the
circumstances in which the court can consider Parliamentary debates as an aid to construction of an
ambiguous statute has been significantly limited by subsequent decisions. Even if it were legitimate for the
court to consider the Parliamentary debates, they provide no assistance.

14. The approach of the prosecution adopted Crown Prosecution Service Guidelines which suggested the
two-stage approach to the burden and standard of proof. That approach was the same as is applied in
cases under the 1999 Act following Makuwa.

**The authorities on reverse burdens of proof**


-----

15. Ordinarily, the burden of proof is upon the prosecution to prove the guilt of a defendant in a criminal
trial. There may be exceptions. The general rule is reflected in the celebrated passage in the speech of
Viscount Sankey L.C. in Woolmington v DPP _[[1935] AC 462:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-20DC-00000-00&context=1519360)_

“Throughout the web of the English Criminal Law one golden thread is always to be seen, that it is the duty
of the prosecution to prove the prisoner's guilt subject to what I have already said as to the defence of
insanity and subject also to any statutory exception… No matter what the charge or where the trial, the
principle that the prosecution must prove the guilt of the prisoner is part of the common law of England and
no attempt to whittle it down can be entertained.”

16. A statute may place the legal burden of proof of a particular defence on the defendant without
necessarily infringing the presumption of innocence reflected in Article 6(2) of the European Convention on
Human Rights (“ECHR”), see Kebilene (above). If the defendant bears a legal burden, it is discharged by
proof on the balance of probabilities.

17. A statute may use express language to indicate that the legal burden of proof lies on the defendant. An
example is section 31(1) the 1999 Act:

“It is a defence for a refugee charged with an offence to which this section applies to show that, having
come to the United Kingdom directly from a country where his life or freedom was threatened (within the
meaning of the Refugee Convention), he

(a) Presented himself to the authorities in the United Kingdom without delay

(b) Showed good cause for his illegal entry or presence; and

(c) Made a claim for asylum as soon as was reasonably practicable after his arrival in the United
Kingdom.”

Section 31(7) provides that:

“If the Secretary of State has refused to grant a claim for asylum made by a person who claims that he has
a defence under subsection (1), that person is to be taken not to be a refugee unless he shows that he is.”

18. In Makuwa this court decided that in respect of the question of proof of refugee status, the burden on
the defendant was evidential only. But if the prosecution failed to disprove his refugee status, the legal
burden fell on the defendant to establish the remaining elements of the statutory defence on the balance of
probabilities. That two-stage approach was consistent with the two relevant subsections. If the defendant
had already been granted asylum, the issue of his status would not arise. If he had been refused asylum,
then section 31(7) imposed an evidential burden on the defendant. The defence under section 31(1) would
only arise if the prosecution failed to establish to the criminal standard that he was not a refugee. If he was
still awaiting a decision on a claim for asylum, and his status was contested, it would not be fair to put him
in a worse situation than if his claim had been refused, and therefore it would make sense for him to be
treated in the same way as a defendant to whom section 31(7) applied.

19. The case of _Makuwa illustrates that in cases where there is an express provision which appears to_
place the onus on the defendant, using language such as “the defendant must show”, the court may still be
faced with the task of discerning whether Parliament's intention was that the reverse burden should be
legal or evidential. If it appears that the intention was that it should be legal or persuasive, the court may
then have to decide whether that interpretation is compatible with Article 6(2) of the ECHR: see e.g. R v
_Lambert_ _[2001] UKHL 37, [2002] 2 AC 545. In that case the House of Lords expressed the view that_
express provisions of the _[Misuse of Drugs Act 1971 that appeared to place a legal burden on the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)_
defendant could be “read down” to make it an evidential burden, so as to make those provisions
compatible with Article 6(2).

20. Even if there is no express provision appearing to shift the burden of proof to the defendant, a statute
can, on its true construction, place a burden on the defendant by necessary implication: R v Hunt (Richard)

[1987] AC 352. In that case, Lord Griffiths referred to the difficulty in determining upon whom Parliament
intended to place the burden of proof when the statute had made no express provision. He endorsed


-----

observations made in the earlier case of Nimmo v Alexander Cowan & Sons Ltd [1968] AC 107to the effect
that if the linguistic construction of the statute did not clearly indicate upon whom the burden should lie, the
court should look to other considerations to determine the intention of Parliament. That would include the
mischief at which the Act was aimed and practical considerations affecting the burden of proof, in
particular, the ease or difficulty that the respective parties would encounter in discharging the burden. He
commented:

“I regard this last consideration as one of great importance, for surely Parliament can never lightly be taken
to have intended to impose an onerous duty on a defendant to prove his innocence in a criminal case, and
a court should be very slow to draw any such inference from the language of a statute.”

We note that although Lord Griffiths refers to the difficulty in discharging the burden in relation to both
parties, the difficulty has particular significance where it relates to a defendant because of the general
principle of the “golden thread” (see Woolmington above) and, now, Art 6(2) ECHR.

[21. Hunt was decided prior to the coming into force of the Human Rights Act 1998. In Kebilene, which was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
the first case to consider the impact of the Human Rights Act on reverse onus provisions, Lord Hope
referred to three kinds of statutory presumptions which transfer the legal burden to the accused. The first
two relate to elements of the offence itself. The third category comprises provisions which relate to an
exemption or proviso which the accused must establish if he wishes to avoid conviction, but which is not an
essential element of the offence.

22. Lord Hope referred to _R v Edwards [1975] QB 27in which a provision of this last kind was held to_
impose a burden of proof on the applicant to establish on the balance of probabilities that he had a licence
for the sale of intoxicating liquor. Lawton LJ observed at pages 39-40 of that case that this exception to the
fundamental rule that the prosecution must prove every element of the offence charged was limited to
offences arising under enactments which prohibit the doing of an act save in specified circumstances, or by
persons of specified classes or with special qualifications, or with the licence or permission of specified
authorities. Lord Hope also referred to what Lord Griffiths had said about this type of provision in Hunt at
375, namely, that he had little doubt that the occasions upon which a statute will be construed as imposing
a burden of proof upon a defendant which did not fall within Lawton LJ's formulation are likely to be
“exceedingly rare”.

**The construction of Section 45**

23. The defence under section 45 of the 2015 Act is unusual. Whereas most statutory defences apply
specifically to an offence created by the same statute, or (as in the case of section 31 of the 1999 Act) to a
series of offences created by a different statute, this defence applies to all criminal offences other than
those excepted by Schedule 4 to the 2015 Act.

24. The elements of the defence are also different, depending on whether the person concerned is over 18
or not. In the case of a child, it is still necessary that there should be a direct causal link between the
criminal act and the child being (or having been) a victim of slavery or human trafficking, but there is no
requirement of compulsion. Moreover, whereas in the case of an adult the defence requires that a
reasonable person in the same situation with the same relevant characteristics would have “no realistic
alternative” to doing the criminal act, in the case of a child it simply requires that a reasonable person in the
same situation and with the child's relevant characteristics would do what the child did.

25. At first sight, the defence under section 45 may appear to fall within the third category identified by
Lord Hope in Kebilene. The prosecution must prove all the elements of the underlying criminal offence. The
defence only arises if the prosecution has done so, and therefore at a time when the defendant would be
guilty of that offence unless the statutory defence is established. Yet it is not a provision of the type
described by Lawton LJ in R v Edwards, nor is it analogous to such a provision. Even if the prosecution
has proved the ingredients of the criminal offence to the criminal standard, section 45 states that a person
“is not guilty”, and so is innocent of the offence, if all the specified elements under section 45 are
established. That is the language of a defence, not an excuse or proviso. The status of a person as a
victim of trafficking or slavery does not automatically exempt him or her from criminal liability or permit the


-----

commission of acts that would otherwise be criminal. Those opening words of the section are a strong
indication that imposing a reverse legal or persuasive burden would be tantamount to requiring a defendant
to prove specific elements establishing his or her innocence.

26. Whilst it is correct to say that the defence is only available to a person who is or has been a victim of
slavery or human trafficking, the structure of section 45 only introduces that issue at a later stage of the
analysis: in the case of an adult defendant, after it has been established that the person is aged over 18
(section 45(1)(a)) and that they did the act which constituted the offence under compulsion (section
45(1)(b)). It is section 45(1)(c) which poses the question whether the act done under compulsion was a
direct consequence of the person being or having been a victim of slavery or human trafficking.

27. That subsection raises two issues, namely, (i) is or was the defendant a victim of slavery or human
trafficking? and (ii) if so, is there a direct causal link between the defendant's status as a victim and the act
done under compulsion?

28. In the light of the way in which the section is structured, it is difficult to understand the basis for the
CPS Guidelines (referred to in [15] above) and the prosecution's consequent stance in the Crown Court,
maintained before this Court, that as a preliminary step it would be for the prosecution to disprove beyond
reasonable doubt that the defendant was or had been the victim of slavery or human trafficking, and that
one could interpret section 45 in such a way as to create different burdens of proof in respect of the two
factual issues arising in section 45(1)(c).

29. Mr McGuinness QC sought to justify that stance by seeking to characterise the defence under section
45 as an “immunity” which is only available to persons falling within the two groups specified, victims of
slavery or victims of human trafficking, as indicated by the title to the section. He submits that the status of
the defendant should be established as a preliminary matter before considering the specific issues under
subsections 1(a), (b) and (c), in the same way as the 1999 Act requires a defendant's status as a refugee
to be established before consideration of the specific elements of the defence under section 31(1).

30. The submission relies heavily upon the title, “defence for slavery or trafficking victims who commit an
offence.” But the title is not part of the substantive provisions of the statute and simply describes the
subject-matter of section 45. As the Respondents' Notice itself contends in paragraph 63, the title is silent
as to how the status of the victim is established. We also consider that the submission depends on a
mischaracterisation of a defence, absolving the defendant from criminal liability, as an “immunity,” in order
more comfortably to shoehorn it into an exception of the sort discussed by Lord Hope in Kebilene (see [21]
above).

31. In our opinion, the central difficulty with the Respondent's submission is that there is nothing in the
language of the statute to support the contention that this one element of the defence should be singled out
for different treatment as regards the legal burden. The approach of the prosecution in truth requires a rewriting of section 45, whose structure is very different from that of section 31 of the 1999 Act. In particular,
there is no provision in the 2015 Act analogous to section 31(7) of that Act. It is not difficult to see why the
CPS Guidance was drafted to replicate the approach under the 1999 Act for ease of application, but the
structures of the relevant statutory provisions are different and there is no true analogy.

32. Mr McGuinness accepts that the international obligations of the United Kingdom under Article 4 ECHR
and Directive 2011/36/EU of the European Parliament and Council of Europe on preventing and combating
trafficking in human beings and protecting its victims (“the Directive”), which underlie the Modern Slavery
Act, justify the burden falling on the prosecution to disprove that a defendant is or was the victim of
trafficking or slavery. However, if the need to protect victims of trafficking and slavery requires the burden
of proof to remain with the prosecution in respect of that element of the statutory defence, the same
considerations would tend to support an interpretation which rests the legal burden of proof on the
prosecution for the remaining elements. There is no logical reason arising from the language of the statute
to isolate that single factor.

33. Mr O'Shea, on behalf of Ms Gega, refers to Lord Steyn's speech in Lambert (above) in which, at 571,
he adopted the observations of Dixon CJC in a Canadian case, R v Whyte (1988) 51 DLR (4th) 481 that:


-----

“if an accused is required to prove some fact on the balance of probabilities to avoid conviction, the
provision violates the presumption of innocence because it permits a conviction in spite of a reasonable
doubt in the mind of the trier of fact as to the guilt of the accused.”

34. Mr O'Shea submits that if the burden of proof under section 45 lies on the defendant, some victims of
slavery or human trafficking would be found criminally liable in circumstances where there was reasonable
doubt as to their guilt. In the context of a statute which aims to protect them from further victimisation, this
is not a consequence that Parliament could possibly have intended. Indeed, with the reversal of the
burden of proof, they could be found criminally liable even where the prosecution could not prove their guilt
on the balance of probabilities.

35. In support of that submission Mr O'Shea referred to the objectives of the Directive, especially those
reflected in Recital 14, which provides that:

“Victims of trafficking in human beings should… be protected from prosecution or punishment for criminal
activities such as the use of false documents, or offences under legislation on prostitution or immigration,
that they have been compelled to commit as a direct consequence of being subject to trafficking. The aim
of such protection is to safeguard the human rights of victims, to avoid further victimisation and to
encourage them to act as witnesses in criminal proceedings against the perpetrators. This safeguard
should not exclude prosecution or punishment for offences that a person has voluntarily committed or
participated in.”

36. There is force in the point that a reverse burden would undermine the protection that section 45 of the
2015 Act is designed to afford to vulnerable people who are likely to be traumatised by their experiences
and potentially still at the mercy of those who exploited them. The United Kingdom has enacted legislation
which in some respects affords greater protection than that envisaged by Recital 14. Nevertheless, if the
legal burden of proof is reversed, there is a danger of frustrating Parliament's objective that victims
(including children) of trafficking or slavery should be protected against the further stigma of a criminal
conviction for an offence committed in consequence of their initial victimisation.

37. Mr McGuinness submits that the defendant is best placed to identify the circumstances of his or her
personal situation in order to bring himself or herself within an exception relying on the elements of
compulsion (where required) and the direct link between the commission of the act and the defendant's
current or former status as a victim of slavery or trafficking.  He submits that it is far easier for a defendant
to give evidence about these matters, being within his or her knowledge. By contrast, the prosecution
would have real difficulty in disproving to the criminal standard the defendant's account.

38. We accept that in some cases that may be so, but are unpersuaded that it affects the overall question
of where the legal burden lies. In practical terms, the task that the prosecution faces if it bears the legal
burden is unlikely to be very different from the task it faces when disproving the common law defence of
duress. We accept that duress is narrower in scope than the defence provided by section 45, but it bears
some similarities. As we have observed, in Ms Kreka's case, she ran duress in parallel with a defence
under section 45 relying on the same evidence.

39. Moreover, the defence under section 45 is not established solely on the basis of evidence about what
the defendant did and why the defendant did it. There is an objective element, set out in section 45(1)(d)
(or section 45(4)(c) as applies to a child). The prosecution is likely to have less difficulty in establishing to
the criminal standard that an adult offender in the defendant's position had a realistic alternative to
committing the offence, than the defendant would have in establishing on the balance of probabilities that a
reasonable person in his or her position would have had no realistic alternative but to do what was done.
That final element of the defence is the safeguard against a defendant being absolved from liability for
what otherwise would be a serious criminal offence simply because the jury cannot be sure that his or her
account of being exploited and victimised is untruthful. It also serves to safeguard against the twin dangers
that (i) the defence under section 45 will be perceived as affording an easy means for an unscrupulous
defendant to avoid liability by making up a story about being trafficked or enslaved, and (ii) the apparent
ease with which defendants can set up a defence under the section will result in their controllers being
encouraged rather than discouraged to continue their exploitation and through them commit offences


-----

40. We have noted that the age of the defendant makes a difference to the elements of the defence.
There will be cases in which the age of a defendant is in issue. At the time of the alleged offence was he
or she under 18 or not? Mr Malik submits that whilst the evidential burden must lie on the defendant, once
age is put in issue, the prosecution should prove to the criminal standard that the defendant is an adult. If
they fail to do so, the defendant should be treated as a child for the purposes of section 45.

41. Mr McGuinness submits that the legal burden lies on a defendant to establish his or her age on the
balance of probabilities. Bearing in mind the practical difficulties that this could pose for a teenage
defendant separated from family (particularly one who has been trafficked from a country in which there
are no reliable means of documenting birth or dates of birth) the consequence of placing the legal burden
on the defendant to establish his or her age could be to impose on a child defendant the more onerous
elements of the section 45 defence that Parliament intended should only apply to adults.

42. Reversing the persuasive burden on the issue of age would also appear to undermine the approach to
child victims required by Article 13(2) of the Directive, which provides that:

“Member States shall ensure that, where the age of a person subject to trafficking in human beings is
uncertain and there are reasons to believe that the person is a child, that person is presumed to be a child
in order to receive immediate access to assistance, support and protection in accordance with Articles 14
and 15.”

Article 15 specifies certain types of measures to be taken by Member States to protect child victims of
trafficking in criminal investigations and proceedings, but they are likely to be of little avail if the child bears
the onus of proving his or her age, let alone each element of a defence in such proceedings.

43. Mr McGuinness submits that because it is incumbent on the prosecution to investigate any reasonable
line of defence, in practice the prosecution always takes upon itself the investigation of the age of a
defendant where that has been raised. Almost always the issue will be resolved satisfactorily before the
case comes to court. That may be so, but it provides no assistance on the question of construction of
section 45, and no justification for placing the burden of proof of age on the child in those cases, however
rare they may be, in which the issue cannot be resolved out of court.

44. In terms of which party is better able to establish the facts, the prosecution plainly has more resources
available than the defendant, particularly a young defendant, to investigate the age of the defendant in
cases where that is going to be in issue. In our judgment, Parliament cannot have intended that such a
defendant should not have the benefit of any reasonable doubt on the issue of age. If the legal burden of
proof in respect of age rests on the prosecution, as we consider it does, that is yet another indication that
Parliament did not intend to shift the burden of proof of the other elements of the defence under section 45.

**Conclusion**

45. In our judgment, section 45 of the 2015 Act does not bear the interpretation urged by the prosecution
upon, and accepted by, the judges below. It does not implicitly require the defendant to bear the legal or
persuasive burden of proof of any element of the defence. The burden on a defendant is evidential. It is for
the defendant to raise evidence of each of those elements and for the prosecution to disprove one or more
of them to the criminal standard in the usual way.

46. We have found it unnecessary to consider the Parliamentary debates in order to reach this conclusion,
and we doubt whether the rule in _Pepper v Hart would have permitted that course. However, having_
considered the material _de bene esse we do not consider that it sheds any further light on Parliament's_
intentions.

**The Individual Appeals**

_R v MK (or D)_

47. […]

48. […]


-----

49. […]

50. There was no suggestion by the prosecution that Mk's conviction was safe if we found the judge's
direction on the burden and standard of proof to be wrong. We therefore grant leave to appeal against
conviction, allow the appeal and quash the conviction. Having considered submissions in writing, we have
concluded that there should be a retrial in this case.

51. In these circumstances the application for leave to appeal against sentence falls away.

_R v Gega (or Maione)_

52. On 11 December 2016, police and immigration officers executed a warrant at an address in London
which was being used as a brothel. During their search, they found documentation in the name of 'Anna
Maione' addressed to a property in Enfield. They attended the Enfield address where they found a bedsit
being used by the applicant. When she arrived home, she was arrested. She was asked to produce
evidence of her identity and she produced to the immigration officers an Italian identity card in the name of
'Anna Maione'. This was subsequently examined and found to be false. When she was interviewed later
that evening, the applicant gave her name as Anna Maione and her nationality as Italian, in line with the
false identity card, but made no comment to all other questions.

53. Anna Maione was not the applicant's true identity, and she was not Italian. There were indications of
her true Albanian nationality in the bedsit. Her true name and nationality were later discovered. She was
indicted on one count of possession of a false identity document with improper intention. At her trial, she
accepted that she was in possession of the Italian identity card and that she knew it was false. She said
that she had been the victim of sex trafficking. Her account was that she had been trafficked from Albania
throughout Europe from the age of 16, ending up in England in 2006 without valid identification or a right to
remain. Her case was that she had been compelled to obtain false identification out of fear of the
consequences of being returned to Albania if she were to be found here illegally, and the fear that she
might be trafficked again or even killed. She said that the compulsion on her was a direct consequence of
her being a victim of slavery and her exploitation by her traffickers. She also asserted that a reasonable
person in the same situation as her, and having her characteristics, would have no realistic alternative to
doing what she did, namely obtain a false identity, falsely identify herself as an Italian national with the right
to remain, and work in the United Kingdom as an EU citizen.

54. The prosecution's case was that the applicant was not a victim of trafficking or slavery, that the whole
account was a concoction and that she was simply an illegal immigrant.

55. In evidence Ms Gega said that when she came to the UK in 2006, she worked for an agency which
sent her to different places to work, serving food and cleaning. Her fake Italian passport expired in 2007,
and in order to continue to be able to work, she obtained further fake identification with the assistance of a
man. However, in cross-examination she was unable to explain why her fake identity card carried a date of
14 December 2009. Between 2009 and 2011, she said that she worked as a prostitute just to survive, but
that stopped in 2011 after she met her boyfriend. Since then, she had worked in various jobs which he
found for her. She said that she then set up a brothel because she wanted to work for herself and worked
there until her arrest in December 2016. She said that she had been trying to make money in order to
bring her brother over to this country. She denied that she had become a madam and said that she still
feared Albania, and that apart from her boyfriend and a few friends, she stayed away from Albanians.

56. The jury convicted the applicant unanimously. In our view, despite the error in the direction to the jury
concerning the burden of proof in relation to section 45 of the 2015 Act, the evidence against Ms Gega was
overwhelming and the conviction is safe. It is fanciful to suppose in her case that the niceties of the legal
burden of proof could have made any difference. In those circumstances, we grant leave to appeal but we
dismiss the appeal.

57. Finally, we note that despite it being clear that this applicant's real name is Persida Gega, and that her
date of birth is 7 January 1982, she was indicted in her false name of Anna Maione (date of birth 22 March
1978). This was also the name in which this appeal was listed; it is now the name on the court record, and


-----

all the records refer to her by her alias alone. Thus, the Police National Computer printout giving her
antecedent history is simply in the name of “Anna Maione” and gives her false date of birth.

IMAGE NOT AVAILABLE

58. If, in the course of an investigation, it becomes apparent that the name and date of birth given by a prospective
defendant is false, the indictment and other records should refer to the defendant by his or her correct name and
date of birth if they are known. As is often done, the documentation can add “aka Anna Maione, DOB 22.03.78” or
similar.

59. Where, after a defendant has been charged and indicted, it becomes apparent that the charge and
indictment are in a false name and the defendant's true name is different, the prosecution should apply to
the court to amend the indictment and other court records to reflect the defendant's correct name, and that
is the name which thereafter should be used.

60. Despite the appeal of Ms Gega being brought in the name of Maione, we direct that the titles of these
cases should refer to both appellants by their true names and it is in those names that this judgment should
be published and reported, with their aliases in brackets, as in the heading of this judgment. We direct that
the record of Ms Gega's conviction in the court below should be amended to record her true name and
date of birth and that it should be made clear that “Anna Maione” is an alias.

**End of Document**


-----

