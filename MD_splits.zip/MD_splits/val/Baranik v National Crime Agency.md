# Baranik v National Crime Agency [2019] EWHC 3520 (Admin)

QBD, ADMINISTRATIVE COURT

CO/1430/2019

Jay J

Friday, 6 December 2019

06/12/2019

MR JUSTICE JAY:

1. This is the adjourned hearing of Mr Baranik's application for permission to appeal in this extradition case.
Strictly speaking, it is the adjourned “rolled up” hearing of that application. The background is fully explained in my
judgment given on 31 October of this year, [2019] EWHC 3127 (Admin).

2. The issues which remain to be determined all fall under the rubric of fresh evidence. The focus is on the report
of Dr McIntee, which was obtained after the extradition hearing at first instance before the district judge. The
questions, in a nutshell, are these: (1) should this report, with due diligence, have been obtained before so that it
was available to be adduced before the district judge? If not (2) Is this evidence both credible and decisive?

3. I derive these questions from the decision of the Divisional Court in Szombathely City Court & Ors v Fenyvesi &
_Anor [2009] EWHC 231 (Admin), which remains the leading authority on the topic of fresh evidence generally._

4. It is clear from my earlier judgment that the fresh evidence is of critical importance to the applicant. This is
because I have already upheld the district judge's decision on the basis of the material before him.

5. I adjourned the hearing on 31 October to enable Dr McIntee to give evidence and to be cross‑examined. In the

particular circumstances of this case, I considered that it was not possible to form a proper view of this expert's
credibility and reliability without taking that course. With my leave, she has given evidence by video link. This has
not been a perfect medium for my assessing her qualities as a witness. However, and in order to assuage any
concerns about it, I should state that evidence by video link is often given these days in civil cases.

6. As for the first question of whether the evidence of Dr McIntee was available with the application of due
diligence, the position before me on 31 October was that the applicant's solicitor, Ms Sarah Moulange, had provided
a short statement. She stated that on the day judgment was handed down by the district judge, for the first time the
applicant was apparently available to reveal to her the psychological stress under which he was operating. On that
occasion, his partner was not there and he had not felt able to be forthcoming about any mental health difficulties in
her presence. There were previous occasions on which his instructions were obtained, but I accepted on 31
October that there are obvious difficulties in obtaining evidence of this sensitivity over a video link.

7. Further evidence of this topic is now available in the form of a witness statement from Mr Noam Almaz, who is
the applicant's solicitor. The version I have is unsigned, but I assume that there is a signed copy available. If not,
Mr Almaz will have to undertake to lodge a signed version as soon as possible.

8. He explained that he, as he put it, happened to be in court on 10 August 2018 when he was informed that the
applicant was representing himself in a full extradition hearing He offered to assist the applicant He was only able


-----

to speak to Mr Baranik for a few minutes on that occasion, but the latter was able to explain the circumstances in
which he had been trafficked to the United Kingdom. There was insufficient time to go into the detail.

9. On hearing the background, the district judge agreed to adjourn the case. Mr Almaz recalls making applications
for bail on two occasions. On both of those occasions, the application or the confrontation with his client was over a
video link.

10. In my judgment, this issue cannot be considered as a wholly discrete question detached from the issue of the
applicant's mental health problems. The stronger the evidence that the applicant is depressed, anxious and

suffering from post‑traumatic stress disorder, the stronger the argument that he has or may have a good

explanation for not sharing his mental health difficulties with his legal team earlier. The converse naturally applies.

11. At this stage of my judgment, it is sufficient to say that I have absolutely no reason to doubt the evidence of Ms
Sarah Moulange and Mr Noam Almaz on this issue. The applicant has not given oral evidence before me, but that
is a neutral factor. Mr Joyes did not submit otherwise.

12. Dr McIntee's relatively brief report stated as follows. She provided it on 9 July 2019. She sets out the
background in short detail. Her conclusion was that the applicant has unresolved developmental trauma which has

now become severe post‑traumatic stress disorder. He is also experiencing impaired self‑reference, somatization,

severe depression, hopelessness and suicidal behaviour as well as very high chronic anxiety and extremely acute
anxiety.

13. Dr McIntee makes it clear that the applicant did complete tests in relation to his cognitive functioning, but it is
completely unclear from the report what other tests, if any, she carried out. For example, in relation to trauma
symptoms (this is paragraph 11), Dr McIntee states that Mr Baranik reported clinically significant somatization.
Then:

"High scores on this scale indicate a general preoccupation with bodily concerns either for psychological reasons or
as a result of pain."

14. It is implicit in that statement that some sort of test or questionnaire must have been administered, but virtually

no information is provided. The same observation may be made in relation to the diagnosis of post‑traumatic stress

disorder.

15. As I think I indicated during oral argument at the last hearing in October, it may be said in relation to this report
that Dr McIntee's reasoning proceeds along the lines that because the applicant has experienced traumatic events,

it must follow that he is now suffering from post‑traumatic stress disorder.

16. Dr McIntee does say that there are protective factors in place, namely his relatively new partner and their
young child, which are providing some degree of support in relation to his mental health. If those protective factors
were removed for any reason, in particular in the event of extradition, the risk of a deterioration or exacerbation in
his mental health difficulties would be obvious.

17. As I have said, my initial impression of Dr McIntee's report was that it was somewhat thin. She has given me
no insight into the extent, if any, of the psychological assessment she undertook. She has not explained how she
has proceeded from the general to the particular.

18. In the light of my concerns and given the importance of this case, it seemed to me obvious on 31 October that it
was necessary to receive evidence from Dr McIntee in order to see whether those initial or preliminary views which
I had formed would either be disabused or fortified. I was keeping an open mind as to how convincing Dr McIntee's
oral evidence might be.


-----

19. In her oral evidence, which lasted I think about 90 minutes, Dr McIntee explained to me that she is a clinical
and forensic psychologist as well as a psychotherapist of some considerable experience. She specialises in trauma
work and has done so for 30 years. Trauma and disassociation, as she put it, are major specialities of hers.

20. She undertook three appointments or examinations of the applicant. These were on 20 April, 21 April and 14
June 2019. There is a mistake in her report as to this last date. The first interview took two hours. The second
interview, with all of the questionnaires being administered by a technician, took four hours. The final interview took
90 minutes. It is not clear from her evidence in relation to the second interview whether Dr McIntee personally
undertook any further assessment of the applicant on that occasion, but in truth it does not matter.

21. Dr McIntee told me that the applicant, working through an interpreter, explained to her his history and the
events leading up to the current situation. The position was that the applicant had experienced a violent childhood.
In particular, he witnessed a significant trauma at work when he was about 14. A friend or a colleague died as a
result of some sort of accident, the details of which are not clear.

22. Aside from his experiences in a Polish prison, which it seems to me is unnecessary to dwell on, when he came
to the United Kingdom as a fugitive, as he did, he was effectively ensnared by traffickers who have been described
as Polish gypsies. His experiences in that regard were, in Dr McIntee's view, particularly traumatic.

23. Since then, however, the applicant has been able to turn his life round to some extent. He has formed a
relationship with a woman whom I will mention only by her first name, Rebecca, and he now has a child, Lily, who is
approximately 12 months old. He has been in gainful employment for some time.

24. Contrary to the impression which is I think reasonably derived from Dr McIntee's report, she did carry out a
number of thorough investigations by way of questionnaire. These questionnaires are, it is fair to say, extremely

well‑known to this court.

25. Aside from the application of the Wechsler Adult Intelligence Scale, which is, as its name suggests, intended to
address questions of cognitive ability or the lack of it, the following additional questionnaires were administered.

First, the Trauma Symptom Inventory, which is a well‑recognised questionnaire in the nature of a screening tool for

trauma. Secondly, the Beck Depression Inventory, which is, as its name suggests, limited to mood. Thirdly, the
Beck Hopelessness Scale, which is, of course, fairly similar. Fourthly, the Anxiety Scale, which is designed to

consider acute and chronic anxiety. Fifthly, the Impact of Event Scale ‑ Revised. Sixthly, the DAPS, a

questionnaire devised by someone called Briere, which is intended to map the results of the questionnaire onto the

corresponding criteria for post‑traumatic stress disorder under the Diagnostic and Statistical Manual, the DSM, the

relevant version of which is now DSM‑5.

26. It should be explained that although these questionnaires are completed by the patient or the putative patient
either alone or in the presence of a psychologist, there are tools within the questionnaires which are directed to the

issue of fabrication and exaggeration. It is well‑known in cases where there is an opportunity for personal gain that

patients will not always be telling the truth. Although these questionnaires cannot be described as precise forensic
devices, they do address to some considerable extent this question of exaggeration, which, from the CPS's
perspective, is extremely important in this case.

27. In Dr McIntee's opinion, there was reasonable consistency across the questionnaires both internally and when
compared with one other. Furthermore, the applicant did not exaggerate his symptoms, in her view, because there
was always the possibility within the questionnaires to state his degree of symptoms at a higher level.

28. Dr McIntee explained how her diagnosis of post‑traumatic stress disorder, in particular severe post‑traumatic

stress disorder, was arrived at. She had said in her report at paragraph 12 that there was a problematic level of
"PTS", which on one reading might suggest that the applicant did not fully qualify for the full diagnosis of

post‑traumatic stress disorder. However, it did become clear in her evidence that this problematic level related to


-----

only one questionnaire, namely the Trauma Symptom Inventory, which, after all, is just the screening tool. When it
came to other relevant questionnaires, in particular the DAPS and the IES, which in my experience are more
specific, the applicant scored more highly and moreover, there was consistency across all three measures.

29. Whereas in relation to the TSI there was a very raised level of trauma symptomatology, it did not quite reach
the level of clinical significance, the accumulation of all this evidence, in Dr McIntee's opinion, entitled her to

conclude that there was severe post‑traumatic stress disorder in this case under the criteria laid down in the DSM.

30. She has said that the applicant's PTSD has probably developed because of cumulative trauma, each previous
trauma rendering him more vulnerable. In her opinion, the applicant needed some skilled psychological intervention
at this stage and extradition to Poland would not merely create a considerable risk of suicide, but would render it
close to impossible for these sort of interventions to be undertaken.

31. Mr Joyes probed Dr McIntee in cross‑examination as to the basis of her conclusions and her methodologies.

She accepted that she was not present when the questionnaires were undertaken, but as I have said, very little
turns on that. She agreed that there was no other supporting evidence in the form of medical records and said,
however, that this should not undermine the reliability of her conclusions.

32. It was put to her that she made no reference to the possibility of fabrication, but she said that if one looks at
table 1 in her report, which deals with honesty and openness, that issue is very squarely addressed. Further points
were put to Dr McIntee on the NICE guidelines and also a brief document prepared by Professor Foa.

33. I think that the most important question asked by Mr Joyes concerned the issue of whether Dr McIntee was
moving too seamlessly from the general to the particular. In answer to his questioning on this issue, Dr McIntee

said that victims of trafficking would normally be expected to suffer from post‑traumatic stress symptoms, but she

was not saying that because one would expect him to have these symptoms it follows that he is suffering from
these symptoms. She carried out a more thorough examination of the applicant in the way in which I have
described.

34. I asked a number of questions of Dr McIntee, which have been noted. I was concerned to seek to identify what
she precisely meant by stating that the effect of the trauma or traumata over the course of the applicant's life was
cumulative. She did explain this in the way in which I have already summarised. I also asked her about the
availability of the sort of skilled help which she had indicated was necessary in the applicant's case. She said that
this would be rarely available in Her Majesty's Prison.

35. In my judgment, the key issues for me to consider in connection with Dr McIntee's evidence are (1) whether
she was sufficiently astute to the possibility of exaggeration or worse; (2) whether during the course of her evidence
she crossed the line into advocacy; and (3) whether in any event her various diagnoses, even if correct, present a
sufficiently serious picture of the applicant's mental health that it should be treated as decisive.

36. My overall impression of Dr McIntee, having considered her evidence very carefully, is that her oral evidence
was very much better than her report. I think that funding issues may have led her to take an excessively succinct
approach. She will need to bear this in mind in future because district judges in other cases will undoubtedly do so.
It is only very rarely that her oral evidence will be received and tested in this court.

37. Dr McIntee clearly has a special expertise in trauma and trauma‑related issues. She knows the literature and

was keen to display that knowledge in court yesterday. Her application of DSM‑5 in preference to ICD‑10 was, if

anything, unfavourable to the applicant because the former is known to be more stringent. That said, it is easier for
a clinician to map the findings of a number of the questionnaires onto the DSM.

38. In my view, Dr McIntee did occasionally cross the line into advocacy, but she was an impressive and measured
witness overall. I have concluded that I can accept the essential elements of her evidence. I also accept her
evidence that she considered the possibility of exaggeration or even fabrication and rejected it.


-----

39. The applicant is a man of limited intellectual and emotional resources. He has experienced trauma at various
stages in his life and there is clear evidence that he was the victim of modern slavery in the United Kingdom.

40. Although I certainly would not go so far as to say that PTSD would be the expectation in the light of the
applicant's experiences, I am satisfied, on the basis of Dr McIntee's evidence, that it has resulted. It is the
cumulative effect of these experiences which has been causative. It is unnecessary to be precise as to exactly

which traumatic events or series of events tipped the applicant from subclinical post‑traumatic stress disorder into

the full‑blown condition.

41. The applicant has not been treated for his PTSD, depression and anxiety. His trauma is, therefore, unresolved.
His psychological needs are complex and I agree with Dr McIntee that really skilled help is required. This may not
be available wherever the applicant finds himself. Dr McIntee pointed out, as I have said, that it is rarely available
in a UK prison. That assessment must, I am afraid, be right. It must also apply to Polish prisons, so the point has

the potential to be somewhat two‑edged.

42. The first issue is whether the application of due diligence has been demonstrated. As I indicated in oral
argument, I should be considering the fresh evidence de bene esse for that purpose because the extent, if any, of
the applicant's mental health problems is relevant to his failure to volunteer those problems before. In addition, the
court must be astute to the possibility that applicants may embroider their case once they have understood that they
lost at first instance, possibly contrary to their expectations of what would happen.

43. Bearing all these factors in mind, I have concluded that the first stage of Fenyvesi has been fulfilled. I accept
the evidence of the solicitors on this topic. Although the court is fully entitled to be sceptical about late evidence of
this sort, it has been thoroughly tested. I am satisfied that the applicant's coping strategy has been to diminish or
downplay his symptoms and that the reason for his not sharing them with his legal team lies in the very nature of his
mental health difficulties.

44. I asked Ms Townshend, who has continued to represent her client's interest with firmness, effectiveness and
calm poise, whether she could succeed on oppression and section 25 of the Extradition Act 2003 if she failed on
section 21 and Article 8. She submitted that she could not. In those circumstances, it seems to me that I should be
focusing on the Article 8 ground.

45. In this regard, I make the following points.

46. First, the test remains as set out by the Supreme Court in _HH v Deputy Prosecutor of the Italian Republic,_
_Genoa [2012] UKSC 25 (see Lady Hale in [8])._

47. Secondly, the fresh evidence now falls to be placed in that balance. Unless it is decisive because it tilts the
balance in the applicant's favour rather than against it, the effect of Fenyvesi is, I think, that having been considered
_de bene esse, it should not be admitted. In the particular circumstances of this case, in the event that the court_
should decide that the fresh evidence is not decisive, it makes little or no difference in practice whether (1) the
ultimate decision is that the court declines to admit the evidence or (2) the court does admit the evidence, but
concludes that the outcome is the same. My reading of Fenyvesi, in particular [22] and [35], is that item (1) is the
correct juridical analysis. The limited point I am making is that in pragmatic terms, it makes very little difference in a
case where exceptionally the evidence has been thoroughly considered and tested.

48. In my view, issues might arise in relation to [21] to [23] of Fenyvesi as to the correct analysis of what is
happening when potentially decisive fresh evidence is being considered de bene esse. For example, I would
respectfully question whether the Civil Procedure Rules have any application (see [23] of the Divisional Court's
judgment). The Criminal Procedure Rules are, I believe, applicable. However, given the course I have taken in this
particular case, I do not believe that these issues require resolution. I have explained how and why in practical
terms it makes little or no difference here.


-----

49. The final stage is for me to conduct the Article 8 balance, as constrained by HH, in the light of all the evidence
that is now available.

50. There remains a strong public interest in favour of extradition. The first conviction relating to conduct that took
place in November 2012 would have been charged as either section 18 or section 20 of the Offences Against the
Person Act 1861 in this jurisdiction. The second conviction is less serious and the offence in question took place in
May 2012. The total time left to be served is two years, eight months. I have already found that the applicant is a
fugitive. The fresh evidence does not bear on that question. The lapse of time in this case does not strongly weigh
in the applicant's favour.

51. On the other side of the balance, the applicant was the victim of modern slavery in the UK and a conclusive
finding to that effect has been made by the NCA. If that had left no lasting psychological consequences, it would
avail the applicant little because it is a past event, water under the bridge. However, it has left lasting psychological
consequences.

52. The applicant now has a partner and a one-year-old child, Lily. His partner has herself mental health

difficulties. She has anxiety and depression and there have been episodes of self‑harm. The evidence

demonstrates that she is heavily reliant on the applicant both emotionally and financially.

53. The district judge found that the applicant's partner could derive financial assistance from her father and
stepmother in the event of extradition. There is fresh evidence to the effect that her father has now "completely
stopped" assisting her financially. She lives in a remote village in Cumbria and would not be able to work if she
were alone. Her plan, in the event of extradition, would be to move to the West Midlands to be near her
grandfather, but he could not provide financial support. Though she would be entitled to welfare benefits, there is a
concern that she would either be living in poverty or close to it. This concern is particularly acute in relation to the
interests of the very young child. The applicant's partner, Rebecca, would, in my view, suffer severe emotional and
psychological hardship.

54. These considerations taken together mean that the consequences of extradition would be severe, but in my
judgment, they would not be exceptionally severe. These consequences do arise, as least in part, because the
applicant decided to come to the UK as a fugitive rather than serve the balance of his sentence. A harsh observer
would point out that had he not made that decision, in the events which happened, he would not have ended up in
**_modern slavery here._**

55. What tilts the balance decisively though in this case is Dr McIntee's evidence. Although I am satisfied that the
suicide risk could be managed, the impact of extradition on the applicant's mental health would be severe. The
protective factors that Dr McIntee mentions would disappear. The risk factors would predominate.

56. The notion that the applicant's complex mental health difficulties could effectively be addressed in a Polish
prison is implausible, as is the notion that they would be here, but it is unnecessary to reach a definitive conclusion
about this last matter. The reality is that extradition and subsequent imprisonment in Poland, however well these
events were managed, would have an important deleterious effect on the applicant's mental health. His
depression, anxiety and PTSD would, as Dr McIntee tells me, be significantly harmed.

57. It is when this consideration is added to all the others that the Article 8 balance, in my judgment, decisively tilts
against extradition. That would be disproportionate in all the circumstances of this case or, put another way, the
overall consequences of extradition would be exceptionally severe. Here, I am including the impact on the
applicant's partner and daughter.

58. In these circumstances, it is unnecessary for me to address the applicant's overlapping, albeit not altogether
congruent, case under section 25.

59. I grant permission, allow the appeal and order the applicant's discharge.

__________


-----

CERTIFICATE

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the Judgment or
part thereof.

Transcribed by Opus 2 International Limited

Official Court Reporters and Audio Transcribers

5 New Street Square, London, EC4A 3BF

Tel: 020 7831 5627   Fax: 020 7831 7737

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

