# ZL v Secretary of State for the Home Department  2020 Scot (D) 12/5

[2020] CSOH 44

Outer House, Court of Session

Lord Armstrong

14 May 2020

**Immigration – Victim of trafficking – Challenge to decision not to grant discretionary leave to remain**
Abstract

_Immigration – Victim of trafficking. Court of Session: Granting a judicial review petition in which a Chinese citizen,_
_whom the respondent had earlier determined was a victim of trafficking, sought reduction of a decision refusing to_
_grant him discretionary leave to remain in the UK as a victim of trafficking, contending that the respondent had erred_
_in her assessment of (i) the risk of his being re-trafficked on return to China, and (ii) of the risks associated with his_
_son's medical condition, in relation to the treatment available in China, and in her approach to the weight given to_
_that in her determination, the court held that in relation to the assessment of what was necessary to secure the_
_objective of affording the petitioner protection against the risk of being re-trafficked, there was a failure to follow_
_Home Office guidance which required due consideration of the totality of the available evidence, and against the_
_background of the obligation to actively promote the child's welfare as part of the overall assessment required of the_
_respondent, in that respect also it had been demonstrated that in assessing that aspect of the petitioner's personal_
_situation concerning the welfare of his young child, there was a failure properly to take into account the totality of_
_the available evidence._
Digest

The petitioner was a citizen of China who arrived in the United Kingdom in 2014. By a decision dated 28 November
2018 the respondent determined that he was a victim of trafficking and **_modern slavery. In this petition the_**
petitioner sought reduction of a decision letter of the respondent, dated 6 June 2019 ('the Decision'), refusing to
grant him discretionary leave to remain in the UK as a victim of trafficking. The issues in the case concerned the
way in which the respondent assessed the available evidence in that regard.

The petitioner challenged the Decision on the basis that the reasons stated for the refusal to grant discretionary
leave to remain were inadequate. In particular, (i) the respondent had erred in law in her assessment of the risk of
the petitioner being re-trafficked, or becoming a victim of modern slavery, on return to China, and (ii) she had erred
in law in her assessment of the risks associated with the petitioner's son's medical condition, in relation to the
treatment available in China, and in her approach to the weight given to that in her determination. Under reference
to art 14(1) of The Council of Europe Convention on Action against Trafficking in Human Beings 2005 ('the
Trafficking Convention'), and the decision in R (on the application of PK (Ghana)) v Secretary of State for the Home
_Department, a foreign national who was a victim of trafficking was to be granted discretionary leave to remain_
where the circumstances were such that the person's stay in the country was 'necessary owing to his personal
situation'. Whether such action was necessary was to be seen through the prism of the objectives of the Trafficking
Convention, which included the protection and assistance of victims of trafficking. Whether the petitioner's personal
situation was such as to make it necessary for him to stay in the UK could only be assessed by reference to that
objective. Return of the petitioner to China would render him vulnerable to the risk of being re-trafficked in two
ways: (i) by falling back into the hands of those who had originally trafficked him; and (ii) by being trafficked by


-----

others because of his vulnerability as someone who was already a victim of trafficking. In her assessment of the
petitioner's personal situation the respondent had considered the first of those categories but the Decision disclosed
no proper and adequate consideration of the second. The respondent had taken into account, and indeed had
quoted, parts of the US 2018 Trafficking in Persons Report: China ('the US Report'). It was reasonable to infer,
however, that in placing reliance on the parts of the US Report which she did, the respondent had been selective.
The passages quoted did not reflect the general content of the report. Although the parts of the US Report quoted in
the Decision indicated that steps were being taken in China to prevent trafficking, and to address the vulnerabilities
of internal migrants returning to China from exploitation abroad, other parts of it, not quoted in the Decision, were to
the effect that although the government of the People's Republic of China had taken some steps to address
trafficking, it 'does not fully meet the minimum standards for the elimination of trafficking and is not making
significant efforts to do so'. It was reasonable to infer that the absence of reference to, or quotation of, those
passages of the US Report critical of the situation in China was an indicator that no account had been taken of
them. In the circumstances of the petitioner's case, which included his forced labour following being trafficked to
London, in considering the risk of his being trafficked of new on return to China, by persons other than his former
traffickers, the respondent's reasons for her determination not to grant discretionary leave to remain were
inadequate. Her conclusion had resulted from a failure to have regard to the whole tenor of the US Report, and, in
particular, a failure to attach appropriate weight to those parts of it which were indicators of clear concerns in
relation to the relevant position in China. The contextual background to the issue regarding the petitioner's son's
[medical condition was s 55 of the Borders, Citizenship and Immigration Act 2009, which imposed on the respondent](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-71G2-00000-00&context=1519360)
a duty to make arrangements for ensuring that any function of hers in relation to immigration was discharged having
regard to the need to safeguard and promote the welfare of children who were in the UK. In the Home Office
guidance document 'Discretionary leave considerations for victims of **_modern slavery', under the heading_**
'Background to discretionary leave for potential victims of **_modern slavery', it was stated: 'Leave is necessary_**
owing to personal circumstances: When deciding whether a grant of leave is necessary under this criterion an
individualised human rights and children safeguarding legislation-based approach should be adopted.' A medical
report by Dr Andreas Brunklaus, consultant paediatric neurologist, dated 22 May 2019, in relation to RL, the
petitioner's son (who was born in November 2015), stated: '[R] has a condition which has not yet fully been
diagnosed. He began having seizures in August last year and these seizures quickly became severe and he was
having multiple seizures every day where he fell to the ground, hurting himself. The seizures are now controlled on
a combination of two medications but the likelihood of recurrence is high. His concentration and learning have been
effected by the seizures and he is seeing the neuropsychologist here and has an EEG booked in three weeks. [R]
will not be able to access the treatment he has here in the area of China he would be going to, which is likely to
significantly affect the outcome of his epilepsy and the rest of his life. He has been seen by many professionals in
the hospital who liaise with his nursery to ensure he gets the support he needs. We support the family's application
for asylum on the basis of their son [R's] epilepsy and the fact that he will not be able to access appropriate
treatment.' The Decision properly referred to the need to consider the duty imposed by s 55 of the 2009 Act, and to
the fact of RL's epilepsy. Reference was made to a World Health Organisation ('WHO') report, from which was
quoted five paragraphs describing the impact in China of a demonstration project conducted by the Global
Campaign Against Epilepsy: Out of the Shadows. The quotations included the passage: 'Thanks to this
demonstration project the government has supported the scale-up of the project to cover 7.5 million in 18 provinces,
who now have better access to epilepsy diagnosis and treatment. As of 2012, over 24,000 public health workers
have been trained in epilepsy management and nearly 200,000 people have been screened for epilepsy.' The
rationale of the Decision in that respect was based on the conclusion, derived from the passages quoted, that
'Therefore epilepsy treatment is available for your client's child'. Viewed in context however, in a country with a
population of 1.5 billion people, it was relevant to question the adequacy of the provision identified. On the basis of
the figures quoted it was clear that only a statistically small minority of the whole population had access to epilepsy
treatment. The appropriate approach was to consider the availability of appropriate healthcare in the foreign state
on the basis of a full analysis of the available information. The respondent had been partial in her approach to the
issue. No account had been taken of the inevitable and reasonable inference from the available evidence that, for
the vast majority of Chinese citizens, no access to appropriate epilepsy treatment was available. In determining if
leave was necessary owing to the petitioner's personal situation no proper and adequate consideration had been
given to the issue raised.


-----

The petition would be granted.

In determining whether, in the petitioner's case, the grant of discretionary leave was necessary owing to his
personal situation, it was incumbent on the respondent, affording the word 'necessary' its ordinary meaning, to
consider what was required in order to achieve the objective of the Trafficking Convention in relation to the
protection and assistance of victims of trafficking. That approach was consistent with the Home Office guidance on
the matter 'Discretionary Leave Considerations for Victims of **_Modern Slavery', September 2018, in which it was_**
stated that the circumstances in which discretionary leave might be appropriate were dependent on the totality of
evidence available in individual cases. On the basis of the passages from the US Report quoted in the Decision the
court was satisfied that the respondent had not attached due weight to the overall tenor of the report which, read
objectively, was critical of the position in China, described numerous failings, and provided an assessment of a
situation which was characterised as inadequate and of concern. Whether it was appropriate to describe the current
situation in China in that way was a separate matter, but in the context of the particular evidence which the
respondent had cited as relevant for the purposes of the Decision, in relation to the assessment of what was
necessary for the purposes of securing the objective of affording the petitioner protection against the risk of being
re-trafficked, there was force in the argument that there was a failure to follow the Home Office guidance which
required due consideration of the totality of the available evidence. In relation to the issues arising from the
petitioner's son's medical condition, the respondent conceded that in the context of the assessment required for the
purposes of the Decision the operation of s 55 of the 2009 Act, and in particular the need to safeguard and promote
the welfare of a child, was not excluded by circumstances in which the child himself was not a victim of trafficking,
but rather that those obligations required to be taken into account as part of an overall assessment of what was
necessary owing to the petitioner's personal situation. In response to criticism of the adequacy of the provision of
medical treatment for epilepsy, as reported in the passages from the WHO report 'Out of the Shadows: China
Demonstration Project' quoted in the Decision, it was accepted that the statistics to which reference was made were
those pertaining only to that particular project. Nevertheless, the respondent's position was that on that basis it
could be said that, in China, epilepsy treatment was available for the petitioner's child. The relevant question,
however, to which due weight ought to have been given, was not whether in China, on the available evidence,
treatment for epilepsy in general was available, but rather whether the particular treatment required by the
manifestation of the condition presented in the petitioner's son's case was available there. In that regard the
medical report by Dr Brunklaus, which was before the respondent, stated in clear terms that the treatment the
petitioner's son was receiving would not be available and that, as a consequence, the outcome of his epilepsy, and
the rest of his life, would be significantly affected. Against the background of the obligation to actively promote the
child's welfare as part of the overall assessment required of the respondent, in that respect also it had been
demonstrated that in assessing the petitioner's personal situation, in particular that aspect of it concerning the
welfare of his young child, there was a failure properly to take into account the totality of the available evidence. The
cumulative effect of the way in which the respondent addressed the issues raised, against the evidence available,
rendered the assessment which was required in determining the Decision materially deficient in the respects the
court had identified. The Decision would be reduced.

R (on the application of PK (Ghana)) v Secretary of State for the Home Dept [2018] EWCA Civ 98, [2018] 1 WLR
3955applied

**End of Document**


-----

