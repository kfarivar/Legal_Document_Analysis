# S.M. v Croatia (App. No. 60561/14) [2018] ECHR 60561/14

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE SICILIANOS (PRESIDENT), JUDGES PARDALOS, WOJTYCZEK, TURKOVIĆ, HARUTYUNYAN,
KOSKELO, ILIEVSKI; AND CAMPOS (SECTION REGISTRAR)

17 APRIL, 19 JUNE 2018

19 JULY 2018JUDGMENTPROCEDURE

1. The case originated in an application (no. 60561/14) against the Republic of Croatia lodged with the Court under
Article 34 of the Convention for the Protection of Human Rights and Fundamental Freedoms (“the Convention”) by
a Croatian national, Ms S.M. (“the applicant”), on 27 August 2014. The President of the Section acceded to the
applicant's request not to have her name disclosed (Rule 47 § 4 of the Rules of Court).

2. The applicant was represented by Ms S. Bezbradica Jelavić, a lawyer practising in Zagreb. The Croatian
Government (“the Government”) were represented by their Agent, Ms Š. Stažnik.

3. The applicant alleged, in particular, that the domestic authorities had failed to comply with their procedural
obligations under Article 4 of the Convention as regards her allegations of being forced into and exploited through
prostitution.

4. On 9 February 2015 the complaints concerning the lack of an effective procedural response by the domestic
authorities to her allegations of human trafficking, under Articles 3, 4 and 8 of the Convention were communicated
to the Government and the remainder of the application was declared inadmissible pursuant to Rule 54 § 3 of the
Rules of Court.
**THE FACTSI. THE CIRCUMSTANCES OF THE CASE**

5. The applicant was born in 1990 and lives in Z. Owing to problems in her family, between 2000 and 2004 she
lived with a foster family. Then she moved to a public home for children and young persons, where she stayed until
she completed her professional training as a waiter.

6. On 27 September 2012 the applicant lodged a criminal complaint with the Z. police against a certain T.M., a
former policeman, alleging that in the period between the summer of 2011 and September of the same year he had
physically and psychologically forced her into prostitution. He had given her a mobile telephone so that clients could
contact her and had driven her to meet clients in various places. He had also forced her to give sexual services in
the flat where they had lived together. During that whole period she had been under the control of T.M. When she
had refused to give sexual services to other men, he had physically punished her. After she had left him, he had
threatened her and her family and had attempted to contact her through a social-networking website.

7. The criminal record of T.M. showed that in 2005 he had been convicted of the criminal offences of pandering and
rape and sentenced to six years' and six months' imprisonment. He was released from prison on a conditional leave
in May 2009 and the conditional leave expired in June 2010.

8. The Z. County State Attorney's Office opened an investigation in respect of T.M. On 10 October 2012, following
an order by the Z. County Court, the police conducted a search and seizure of T.M.'s premises, where they found,
_inter alia, several pieces of automatic rifles, a number of mobile phones and condoms._


-----

9. On 16 October 2012 the applicant gave her evidence to the prosecuting authorities. She said that T.M. had first
contacted her at the beginning of 2011 through a social-networking website and that he had already known her
mother and introduced himself as a friend of her parents. She had met T.M. on various occasions in cafés and she
had asked him to help her in finding a job. T.M. had told her that he could find a job for her as a waitress or a shop
assistant.

One day at the beginning of July 2011 he had told her that he would take her to one of his friends who could help
her in finding a job. When they had arrived at the house of that man T.M. had told the applicant to go to a room with
him. The man had then told the applicant that he had expected sexual services from her. The applicant had said
that she had not wanted to do it. That man had also told her that he had answered an advertisement on the Internet
under the name Smokvica (“little fig”) and that T.M. had told him that T.M. and the applicant had been a husband
and wife who “[had done] such things together”. T.M., who had been eavesdropping outside the room, had stormed
into the room and started to shout at her and slap her and had then told her that she had been there with a
purpose, that she should not have behaved like that. The man had secretly given her 400 Croatian kunas (HRK);
when she had told T.M. about that, he had then taken that money from her.

At that time she had still lived with her friend K.Č. who had no knowledge of the events at issue. T.M. had again
contacted her and told her that they had needed to talk about what had happened. She had agreed to meet him but
they had not discussed what had happened. A few days later T.M. had given her a mobile telephone so that clients
seeking sexual services could contact her. T.M. had also told the applicant that she had had to give her physical
description to men who would contact her and charge HRK 400 for half an hour of sexual services or HRK 600 for
an hour, and that she had had to give half of that money to T.M.

The applicant also said that she had acquiesced to all that because she had been scared of T.M. and that he had
threatened to tell all to her parents.

Some ten days after that T.M. had rented a flat, where the applicant and T.M. had then lived together. She had
provided sexual services in that flat and on five to six occasions T.M. had driven her to clients. During the period in
question she had had about thirty clients. Since T.M. had lived in the same flat with her, he had controlled
everything she had been doing.

When she had refused to have sexual intercourse with him or when he had been dissatisfied with the manner in
which she had given sexual services to clients, T.M. had beaten her. He had beaten her every couple of days.

Questioned as to why she had not contacted the police earlier, the applicant answered that she had been afraid of
T.M. Once, when he had been out of the flat and had left the key, the applicant had called her friend M.I., who had
known that the applicant had been giving sexual services to men for money. The applicant had asked M.I. to help
her escape.

After that M.I.'s boyfriend, T., had arrived by taxi, helped the applicant to collect her things and taken her to M.I.'s
home. She had stayed with M.I. for about ten days.

The applicant also said that T.M. had told her that he had previously had a girlfriend, A., whom he had “treated in
the same way” and later on he had told her that after her, the applicant, he had had another girlfriend whom he had
“helped in it”. T.M. had told the applicant that he had filmed those girlfriends and punished them when they had
been “insolent”.

10. On 6 November 2012 M.I. gave her evidence to the prosecuting authorities. She said that she had never met
T.M. but that the applicant was her friend and she had known her for some two years. M.I.'s last contact with the
applicant, before the applicant had come to her flat, had been some eight or nine months previously. M.I. had
known already at the end of 2010, beginning of 2011 that the applicant had been giving sexual services for money
because the applicant had told her so.


-----

At the end of summer 2011 the applicant had suddenly come to her home with a bag containing her things. M.I. had
then learned that the applicant had agreed with M.I.'s mother to come to stay with them, but did not know any
details since she (M.I.) was not in very good relations with her mother.

The applicant had told her about T.M., from whom she had escaped because she had no longer wished to be
involved in prostitution “for him”. Before the applicant had come to her flat M.I. had not known where or for whom
the applicant “did that”. Only then had M.I. learned that the applicant “had being doing it for T.M.”. The applicant had
been very distressed and scared. She had told M.I. that T.M. had repeatedly beaten her; watched her through a key
lock when she had been giving sexual services to clients and afterwards also beaten her for “not being in a position
he had approved of”.

M.I. also said that in her understanding the applicant had voluntarily given sexual services because she had needed
money. The applicant had told her that she had had an agreement with T.M. to work for him and to share the
money, that she had had a mobile telephone for clients to call her and that there had been a small ad through which
she had been contacted for appointments by clients. The applicant had said that T.M. had given her that mobile
telephone and placed the advertisement.

M.I. also said that she could not remember if the applicant had told her that she had opposed T.M. It was true that
the applicant had said that she had not wished to “do it” but in M.I.'s understanding that had rather meant that the
applicant had been “doing it” because she had had no other means to earn money. The applicant had also told her
that T.M. had slapped her for very minor reasons which she (the applicant) had not expected. When she had
refused sexual relations with him T.M. would beat her and the applicant had not known what would make him
“explode again”. T.M. had also told the applicant that he had had another girlfriend who had worked for him and
whom he had also beaten. The applicant told M.I. that she had used the opportunity to run away from T.M. when he
had been out of the flat where they had lived.

M.I.'s boyfriend, T.R., had told her that he had spoken with the applicant but he had not given any details. M.I. had
broken up with him a week after that but still had his address.

M.I. also said that the applicant had stayed with her and her mother for several months and that T.M. had continued
to contact the applicant through a social-networking website and had threatened her as well as her mother. He had
also sent messages, saying that he had loved her and asking her to come back to him.

11. On 6 November 2012 the Z. County State Attorney's Office indicted T.M. in the Z. Criminal Court on charges of
forcing another to prostitution, as an aggravated offence of organising prostitution under Article 195 of the Criminal
Code.

12. On 21 December 2012 the applicant was officially given the status of victim of human trafficking by the Office for
Human and Minority Rights of the Government of Croatia (Vlada Republike Hrvatske, Ured za ljudska prava i prava
_nacionalnih manjina). On the same day the police contacted the Croatian Red Cross and its employees informed_
the applicant of her rights (accommodation, medical check-ups, psycho-social support, legal aid and material
support). The applicant told them that she was not interested in the right to safe accommodation since she lived
with her mother and sister. According to the Government the applicant contacted the Croatian Red Cross on twelve
occasions between 17 January 2013 and 24 April 2015. She received psycho-social support through individual
counselling and material support. The Croatian Red Cross also organised individual counselling for the applicant
with a psychologist in the Centre for Cognitive-Behavioural Therapy. Further to this the applicant was provided legal
aid by a non-governmental organisation, the R. Centre, within the legal-aid scheme supported by the State.

13. The summons served on the applicant contained detailed information on her rights as a victim, such as
psychological and practical support and of the possibility to contact the Department for Organising and Providing
Support for Witnesses and Victims within the Z. Municipal Criminal Court. Contact details of that Department were
also provided.

14. At hearings held on 13 January and 15 February 2013 T.M. gave his evidence. He denied that he had forced
the applicant into prostitution. He confirmed that he had contacted the applicant through a social-networking


-----

website because he had recognised her surname since he had known her parents. He had also known that the
applicant's mother had been a prostitute.

T.M. and the applicant had started to see each other and the applicant had told him that she had had no money and
needed a job and that she had some debts. The applicant had also told him that previously she had given sexual
services for money and had kept telephone numbers of her clients and asked him whether he could take her
sometimes to those clients, which he had done.

He confirmed that he had been in a relationship with the applicant during that time. However, he had not lived with
her in the flat she had rented but only sometimes spent a night there. He had had the keys of that flat and the
applicant had had them as well and she had been free to come and go as she liked. He had also been in the flat on
some of the occasions when the applicant had given sexual services there. He had known that the applicant had
charged HRK 400 for half an hour and HRK 600 for a full hour but these prices had been set by her and not him.
Initially he had lent her some money and from that sum she had bought a mobile telephone on which clients could
contact her. Later on she had returned the money she had borrowed from him. She had also given him some
money even though he had been reluctant to take it but she had insisted telling him that it had been for petrol.
However, it had mostly been he who had given money to the applicant because she had constantly complained that
she had had no money.

He admitted that he had slapped the applicant once when they quarrelled about her refusal to work in a bakery.

He also said that he had found her a job in a restaurant but that after he had told her about it she had disappeared.

15. Both the applicant and M.I. gave their evidence at a hearing held on 29 January 2013. A lawyer was provided to
the applicant by the R. Centre. Before giving her evidence the applicant told the trial court that she feared the
accused. The accused was then removed from the courtroom and the applicant gave evidence in his absence.

16. The minutes of that hearing indicate that the applicant repeated her statement given on 16 October 2012 (see
paragraph 9 above) and also said that T.M. had told her that he had been a former policeman and together with her
father in the war. Her father had confirmed that and had said that T.M. was “an okay person”. Her mother on the
other had told her that he was not a reliable person.

After the first time T.M. had driven her to give sexual services to another man, she had sat in the backseat of his
car. T.M. had been very angry and had been nagging her and at one moment he had stopped the car and slapped
her. She had exited the car, attempting to run away but he had caught up with her and taken her back to the car.

She had agreed to meet him the next day because he had told her that they would discuss what had happened but
they had not.

She had been afraid of him and for that reason had agreed to give sexual services to other men and also because
he had threatened her that he would “tell all” to her parents and that he would “cram her mother into prison”.

T.M. had found the flat to rent, but the applicant had signed the contract and paid the rent for the flat. She had not
had the keys to that flat.

Even though on three to four occasions he had allowed her to leave the flat alone to go to a nearby shop, she had
not dared to flee because T.M. had followed where she had been going from the balcony and she had been scared
of him. He had set some rules for her: she had been forbidden to talk with the clients; the clients had not been able
to touch her; and she had been allowed to give sexual services only in the manner ordered by T.M. When she had
refused to have sexual intercourse with him or when he had been dissatisfied with the manner in which she had
given sexual services to clients, T.M. had beaten her.

Questioned again as to why she had not contacted the police earlier, the applicant said that T.M. had told her that
he had “connection” at the police and that he would very soon learn if she reported “anything”.


-----

Questioned as to why she had not attempted to run away when T.M. had driven her to the clients the applicant said
that she had been sure that T.M. would have found her and that she had been allowed to stay with the clients for
exactly twenty-nine minutes.

When the applicant had called her friend M.I., who had known that the applicant had been giving sexual services to
men for money, the applicant had asked M.I. to help her escape. She had also spoken with M.I.'s mother. T.M. had
continued to contact her through a social-networking website, at first sending her love messages and then
threatening to tell all to her parents. Then T.M. had sent a letter to the authorities, accusing the applicant's mother
of neglecting the applicant's younger sister. Her mother had been asked to come to a police station on that account.
The applicant had then decided to contact the police.

The applicant also explained that she had been very much scared of T.M., that she had feared for her life because
he had threatened to “beat her to death”. T.M. had also threatened her with publishing naked photographs of her.
She had agreed to being photographed because she had been scared of him. T.M. had also told her that as a
former policeman he had known a lot of policemen and if she had reported him he would have fabricated stories
about her.

Later on she had learned from her mother that T.M. and her mother had lived together for a while and that a former
girlfriend of T.M. had reported him to the police for forcing her to give sexual services to other men.

17. M.I. repeated her statement given before the prosecuting authorities (see paragraph 10 above).

18. On 15 February 2013 the Z. Criminal Court acquitted T.M. on the grounds that although it had been established
that he had organised a prostitution ring in which he had recruited the applicant, it had not been established that he
had forced her into prostitution. However, he had only been indicted for the aggravated form of the offence at issue
and thus he could not be convicted for the basic form of organising prostitution. In finding this, the trial court in
particular noted that it could not give sufficient weight to the applicant's testimony because her statement had been
incoherent, she had been unsure and that she had paused and hesitated when speaking. At the same time, given
that there was no other conclusive evidence, it applied the _in dubio pro reo principle and acquitted T.M. The_
relevant part of the first-instance judgment reads:

“On the basis of the evidence given by the accused and the victim in these criminal proceedings the following
facts have been established: that the accused and the victim met through the social network Facebook when
the accused contacted the victim; ... that the accused gave a mobile telephone to the victim so that she could
be contacted by the clients with whom she discussed providing sexual services; that the victim indeed did
provide sexual services in the flat where she lived with the accused; that on five or six occasions the accused
drove the victim to the addresses of clients where she provided sexual services; that the victim charged for
providing sexual services the sum of HRK 400 for half an hour and the sum of HRK 600 for an hour ...”

19. The State Attorney's Office appealed against this decision, arguing that the first-instance court had erred in its
factual findings concerning the charges against T.M. when it did not accept the applicant's testimony.

20. On 21 January 2014 the Z. County Court dismissed the appeal of the State Attorney's Office and upheld the
first-instance judgment, endorsing its reasoning as well as the facts as established by the trial court. That decision
was served on the applicant on 28 February 2014.

21. On 31 March 2014 the applicant lodged a constitutional complaint with the Constitutional Court (Ustavni sud
_Republike Hrvatske), complaining about the manner in which the criminal-law mechanisms had been applied in her_
case. She relied on Articles 14, 23, 29 and 35 of the Constitution (see below paragraph 23) and Articles 3, 6, 8 and
14 of the Convention. In particular, she alleged that the national authorities had not properly investigated and
addressed the element of force. Also, owing to the failure of the authorities to reclassify the offence, T.M. had not
been convicted of any offence, to the applicant's detriment. She further stressed that she had not been provided
with any psychological help or assistance during the court hearing to help cope with the fear and pressure she had
felt from T.M. while testifying, which all resulted in her testimony being regarded as incoherent by the trial court. The
applicant also alleged a failure of the authorities to secure effective respect for her private life in particular through


-----

the domestic court's inadequate assessment of all the relevant circumstances in which she had been recruited to
T.M.'s prostitution ring.

22. On 10 June 2014 the Constitutional Court declared the applicant's constitutional complaint inadmissible on the
grounds that the applicant had not had the right to bring a constitutional complaint concerning the criminal
proceedings against T.M. since these proceedings had concerned a criminal charge against him. The decision of
the Constitutional Court was served on the applicant's representative on 1 July 2014.
_II. RELEVANT DOMESTIC LAWA. The Constitution_

23. The relevant provisions of the Constitution of the Republic of Croatia (Ustav Republike Hrvatske, Official
Gazette nos. 56/1990, 135/1997, 113/2000, 28/2001, 76/2010 and 5/2014) read as follows:

**Article 14**

“Everyone in the Republic of Croatia shall enjoy rights and freedoms regardless of their race, colour, sex,
language, religion, political or other belief, national or social origin, property, birth, education, social status or
other characteristics.

All shall be equal before the law.”

**Article 23**

“No one shall be subjected to any form of ill-treatment ...

Forced or compulsory labour is forbidden.”

**Article 29**

“Everyone has the right that an independent and impartial court established by law decides fairly and within a
reasonable time on his or her rights or obligations, or as regards suspicion or accusation of a criminal offence.

...”

**Article 35**

“Respect and legal protection of his or her private and family life, dignity, reputation and honour is guaranteed
to everyone.”

Article 134

“International agreements in force which have been concluded and ratified in accordance with the Constitution
and made public shall be part of the internal legal order of the Republic of Croatia and shall have precedence
over the [domestic] statutes. ...”

_B. Criminal Code_

24. The relevant part of the Criminal Code (Kazneni zakon, Official Gazette nos. 110/1997, 27/1998, 50/2000,
129/2000, 51/2001, 111/2003, 190/2003, 105/2004, 84/2005, 71/2006, 110/2007, 152/2008, 57/2011 and
143/2012) which was in force when the alleged offence was committed reads as follows:

**Trafficking in human beings and slavery**

**Article 175**

“(1) A person who violates the rules of international law in that he or she by the use of force or of a threat to
use force, by means of fraud, by abuse of power or of a position of vulnerability or in any other manner for the
purposes of slavery or a similar relationship, forced labour, sexual exploitation, prostitution or illegal humanorgan transplant recruits, buys, sells, hands over, transports, transfers, harbours, receives a person or entices


-----

or acts as an intermediary in the sale or transfer of a person for such purposes or keeps a person in slavery or
a similar relationship, shall be punished by imprisonment for one to ten years.

...

(5) The existence of the criminal offence under paragraph (1) ... does not depend on whether the person
concerned consented to force labour, servitude, sexual exploitation, slavery or a similar relationship, or illegal
transplant of human organs.”

**Pandering**

**Article 195**

“...

(2) A person who, for profit, organises or arranges for another person to provide sexual services shall be
punished by imprisonment for one to three years.

(3) A person who, for profit, forces or entices a person to providing of sexual services by the use of force or the
threat of the use of force or by means of deception shall be punished by imprisonment for one to five years.

...”

25. The relevant provisions of the Criminal Code in force in the Republic of Croatia (official Gazette nos. 125/2011
and 144/2012) read as follows:

**Slavery**

**Article 106**

“A person who violates the rules of international law in that he or she places another in slavery or a similar
relationship or keeps another in such a position, or buys, sells, transfers or acts as an intermediary in the sale
or transfer of a person or entices another to sell his or her freedom or the freedom of a person whom he or she
is caring for shall be punished by imprisonment for one to ten years

...”

**Trafficking in human beings**

**Article 106**

“(1) A person who by the use of force, of threat, of fraud, of deception, of abduction, of the abuse of power or

[abuse] of a difficult situation, or a dependency relationship, or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, or in any other manner
recruits, transports, transfers, harbours or receives a person or exchanges or transfers the control over a
person for the purpose of exploitation of his or her labour by means of forced labour, servitude, slavery or a
similar relationship, or for his or her exploitation for prostitution or other forms of sexual exploitation including
pornography, or for the purpose of entering an illegal or forced marriage, or for the removal of organs, or for his
or her participation in armed conflicts, or to commit an illegal act shall be punished by imprisonment for one to
ten years.

...

(7) The consent of a victim of trafficking in persons is irrelevant for the existence of the criminal offence in
question.”

**Prostitution**


-----

**Article 157**

“(1) A person who, for profit or other gain lures, recruits or entices another person to provide sexual services or
organises or arranges for another person to provide sexual services shall be punished by imprisonment for six
month to five years.

(2) A person who, for profit, by the use of force or threat, deception, fraud, abuse of power or abuse of a
difficult situation or a dependency relationship, forces or entices another person to provide sexual services, or
who uses sexual services of such a person for payment and knew of ought to have known of the abovementioned circumstances shall be punished by imprisonment for one to ten years.

...

(3) it is irrelevant for the existence of the criminal offence whether the person who was lured, recruited, enticed
or used for prostitution gave his or her consent or had already practiced it.”

_C. Code of Criminal Procedure_

26. The relevant part of the Code of Criminal Procedure (Zakon o kaznenom postupku, Official Gazette nos.
152/2008, 76/2009, 80/2011, 91/2012 and 143/2012) which was applied in the proceedings against T.M., reads as
follows:

**Article 2**

“(1) Criminal proceedings shall be instituted and conducted only at the request of a competent prosecutor. ...

(2) In respect of criminal offences subject to public prosecution, the competent prosecutor shall act as State
Attorney, and in respect of criminal offences that may be prosecuted privately, the competent prosecutor shall
be a private prosecutor.

(3) Unless otherwise provided for by law, the State Attorney shall undertake a criminal prosecution where there
is a reasonable suspicion that an identified person has committed a criminal offence subject to public
prosecution and where there are no legal impediments to the prosecution of that person.

...”

**Article 9**

“(1) The court and other State bodies participating in the criminal proceedings shall examine and establish with
equal care the facts against the accused and those in his or her favour ...”

**Article 16**

“(1) In criminal proceedings a victim and injured party have the rights provided for in this Code.

(2) The police, investigators, State attorney and court shall act with special care with the victim of the criminal
offence [concerned]. These authorities shall instruct the victim [of his or her rights] under paragraph 3 of this
Article and under Articles 43-46 of this Code and care for the victim's interests when adopting their decisions
concern the prosecution of the accused or when taking actions within the criminal proceedings in which the
victim had to participate personally.

(3) A victim suffering serious psycho-physical damage or serious consequences of a criminal offence has the
right to free professional aid of a counsellor in accordance with the law.

...”

**Article 38**


-----

“(1) The basic power and the main duty of a State attorney is prosecution of the perpetrators of criminal
offences liable to State prosecution.

...”

**1. Victim**

**Article 43**

“(1) A victim of a criminal offence has:

1. the right to effective psychological and other professional help and support of a body or organisation
providing support to the victims of criminal offences in accordance with the law;

2. the right to participate in the criminal proceedings as an injured party;

...

(3) When taking the first action in which the victim participates, the court [conducting the proceedings], a State
attorney, an investigator and the police shall inform the victim of:

1. his or her rights under subsections 1 and 2 of this Article and under Article 44 of this Code,

2. of his or her rights as an injured party.”

**Article 45**

“(1) A victim of a criminal offence against his or her sexual freedom and morals has, in addition to those under
Articles 43 and 44 of this Code, the following rights:

1. to free consultation with a counsellor before giving his or her evidence;

2. to be interviewed by an officer of his or her own gender when interviewed by the police;

3. not to answer a question concerning his or her strictly private life;

4. to ask to give his or her evidence by means of audio-visual equipment as provided under Article 292(4) of
this Code.

5. to confidentiality of personal data;

6. to request the exclusion of the public from a hearing.

(2) Before a victim gives his or her evidence for the first time, the court [conducting the proceedings], a State
attorney, an investigator and the police shall inform the victim of the criminal offence under paragraph 1 of this
Article of his or her rights under this Article.”

**2. Injured party**

**Article 47**

“In criminal proceedings an injured party has the right:

1. to use his or her language and to the services of a translator;

...

3. to have a representative;


-----

4. to point out facts and present evidence;

5. to be present at a hearing where evidence is presented;

6. to be present at hearings and to participate in the presentation of evidence and to give concluding remarks;

7. to consult the case file and [examine] objects [serving as evidence];

8. to lodge an appeal under the conditions set out in this Code;

...

9. to be informed of the outcome of the criminal proceedings.”

**Article 438**

“A [trial] panel may decide to temporarily remove the accused from the courtroom when a co-accused or a
witness refuses to give his or her evidence in the presence of the accused or if the circumstances show that a
co-accused or a witness is not [likely to] tell the truth in the presence of the accused.

...”

**Article 449**

“(1) A judgment may refer only to a person who was indicted and only to the criminal offence which is the
subject of the charges in the [initially lodged] indictment or the indictment amended or extended at a hearing.

(2) The court is not bound by the prosecutor's legal classification of the offence but the accused cannot be held
guilty of a more serious offence than the one he or she has been indicted for.

...”

_III. RELEVANT INTERNATIONAL LAWA. United Nations1. Convention for the Suppression of the Traffic in Persons_
_and the Exploitation of the Prostitution of Others_

27. The Convention for the Suppression of the Traffic in Persons and the Exploitation of the Prostitution of Others
was adopted on 2 December 1949 and entered into force on 25 July 1951. It was ratified by Croatia 12 October
1992. The relevant part reads as follows:

**Article 1**

“The Parties to the present Convention agree to punish any person who, to gratify the passions of another:

(1) Procures, entices or leads away, for purposes of prostitution, another person, even with the consent of that
person;

(2) Exploits the prostitution of another person, even with the consent of that person.”

_2. Convention on the Elimination of All Forms of Discrimination Against Women_

28. The Convention on the Elimination of All Forms of Discrimination against Women (“the CEDAW”) was adopted
in 1979 by the UN General Assembly and ratified by Croatia on 9 September 1992. The relevant part reads as
follows:

**Article 6**

“States Parties shall take all appropriate measures, including legislation, to suppress all forms of traffic in
women and exploitation of prostitution of women.”


-----

29. The United Nations Committee on the Elimination of Discrimination against Women, an expert body established
in 1982, composed of twenty-three experts on women's issues from around the world, issues its General
Recommendations and country reports.

In its General Recommendation no. 19 (11th session, 1992), the Committee recognised that poverty and
unemployment force many women and girls into prostitution, and acknowledged the link between the commercial
exploitation of women as sexual objects and gender-based violence.

General comment no. 14-15 stated:

“Poverty and unemployment increase opportunities for trafficking in women ... and force many women,
including young girls, into prostitution”.

30. In its Concluding Observations on Croatia of 28 July 2015 (CEDAW/C/HRV/CO/4-5), the Committee
recommended, in particular:

**Trafficking and exploitation of prostitution**

“20. While the Committee notes with appreciation the legislative and policy measures and programmes aimed
at protecting women and girls who are victims of trafficking, it is concerned:

(a) That perpetrators of trafficking are often charged with offences of pimping rather than the more serious
offence of human trafficking, resulting in a disturbingly low rate of conviction for human trafficking;

(b) That victims of exploitation of prostitution are sometimes prosecuted rather than provided with appropriate
support measures, while persons purchasing sex from victims of forced prostitution and/or victims of trafficking
are not consistently prosecuted and commensurately punished;

(c) That there are inadequate mechanisms for identifying victims of trafficking in situations of heightened risk;

(d) That there are inadequate systems for the collection of disaggregated data on victims of trafficking,
including by sex, age, ethnicity and nationality;

(e) That there are inadequate shelters, and training of personnel therein, for victims of trafficking;

(f) That there are inadequate measures to address the specific vulnerabilities and needs of non-national victims
of trafficking.

21. The Committee recommends that the State party:

(a) Ensure that perpetrators of trafficking receive sentences commensurate with the gravity of the offence;

(b) Consider measures to discourage the demand for prostitution and ensure that women and girls who are
victims of trafficking who have been subjected to forced prostitution are referred to adequate support measures
rather than being prosecuted by default and that individuals who have purchased sex from victims of trafficking
are prosecuted and adequately punished;

(c) Strengthen measures to identify and provide support to women at risk of trafficking;

(d) Establish procedures and systems for the collection of disaggregated data on women who are victims of
trafficking;

(e) Increase the human, technical and financial resources allocated to shelters for victims of trafficking to
increase both the number of such shelters, in particular in rural areas, and the quality of the care and of legal
and psychological counselling available at such shelters;

(f) Strengthen support measures for women, including non-nationals, who wish to leave prostitution;


-----

(g) Analyse the factors leading to the involvement of non-national women in prostitution in order to strengthen
measures to address their specific vulnerabilities to trafficking and exploitation of prostitution.”

_3. Palermo Protocol_

31. The Protocol to Prevent, Suppress and Punish Trafficking in Persons, especially Women and Children (“the
Palermo Protocol”), supplementing the United Nations Convention against Transnational Organised Crime 2000,
was signed by Croatia on 12 December 2000 and ratified on 24 January 2003.

The interpretative notes of the negotiation of the Palermo Protocol, however, state that the terms “exploitation of
prostitution” and “sexual exploitation” are intentionally not defined, which is therefore without prejudice to how the
States address prostitution in their domestic laws. Furthermore, the exploitation of the prostitution of others or other
forms of sexual exploitation can qualify as trafficking in human beings.

The Palermo Protocol defines forced labour as a form of exploitation.

Assistance and protection for victims of trafficking is dealt with in Article 6, which provides, in so far as relevant:

“2. Each State Party shall ensure that its domestic legal or administrative system contains measures that
provide to victims of trafficking in persons, in appropriate cases:

(a) Information on relevant court and administrative proceedings;

(b) Assistance to enable their views and concerns to be presented and considered at appropriate stages of
criminal proceedings against offenders, in a manner not prejudicial to the rights of the defence.

3. Each State Party shall consider implementing measures to provide for the physical, psychological and social
recovery of victims of trafficking in persons ...

...

5. Each State Party shall endeavour to provide for the physical safety of victims of trafficking in persons while
they are within its territory.

...”

**Article 3(a)**

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having
control over another person, for the purpose of exploitation. Exploitation shall include, at a minimum, the
exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or services, slavery
or practices similar to slavery, servitude or the removal of organs.”

_4. Declaration on the Elimination of Violence against Women_

32. The Declaration on the Elimination of Violence against Women was adopted at the United Nations General
Assembly plenary meeting on 20 December 1993. It recognises forced prostitution as a form of violence against
women.

In its Article 1, “violence against women” is defined as “any act of gender-based violence that results in, or is likely
to result in, physical, sexual or psychological harm or suffering to women, including threats of such acts, coercion or
arbitrary deprivation of liberty, whether occurring in public or in private life”.

Article 2b refers to “physical, sexual and psychological violence occurring within ... trafficking in women and forced
prostitution”.
_B. Council of EuropeCouncil of Europe Convention on Action against Trafficking in Human Beings_


-----

33. The Convention on Action against Trafficking in Human Beings was adopted on 16 May 2005 and entered into
force on 1 February 2008. It was ratified by Croatia on 5 September 2007.

The relevant part of the Convention reads as follows:

**Article 1 – Purposes of the Convention**

“1 The purposes of this Convention are:

a to prevent and combat trafficking in human beings, while guaranteeing gender equality;

b to protect the human rights of the victims of trafficking, design a comprehensive framework for the protection
and assistance of victims and witnesses, while guaranteeing gender equality, as well as to ensure effective
investigation and prosecution;

c to promote international cooperation on action against trafficking in human beings.

...”

**Article 2 – Scope**

“This Convention shall apply to all forms of trafficking in human beings, whether national or transnational,
whether or not connected with organised crime.”

**Article 4 – Definitions**

“For the purposes of this Convention:

a 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person, for the purpose of exploitation.

Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs;

b The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

...”

**Chapter III – Measures to protect and promote the rights of victims, guaranteeing gender equality**

**Article 10 – Identification of the victims**

“1 Each Party shall provide its competent authorities with persons who are trained and qualified in preventing
and combating trafficking in human beings, in identifying and helping victims, including children, and shall
ensure that the different authorities collaborate with each other as well as with relevant support organisations,
so that victims can be identified in a procedure duly taking into account the special situation of women and
child victims ...”

**Article 12 – Assistance to victims**

“1 Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:


-----

d counselling and information, in particular as regards their legal rights and the services available to them, in a
language that they can understand;

e assistance to enable their rights and interests to be presented and considered at

appropriate stages of criminal proceedings against offenders;

...”

The Explanatory Report of the Convention on Trafficking in Human Beings of the Council of Europe provides a
definition in paragraphs 83 and 84 of what is meant by “abuse of a position of vulnerability” as follows:

“83. By abuse of a position of vulnerability is meant abuse of any situation in which the person involved has no
real and acceptable alternative to submitting to the abuse. The vulnerability may be of any kind, whether
physical, psychological, emotional, family-related, social or economic. The situation might, for example, involve
insecurity or illegality of the victim's administrative status, economic dependence or fragile health. In short, the
situation can be any state of hardship in which a human being is impelled to accept being exploited. Persons
abusing such a situation flagrantly infringe human rights and violate human dignity and integrity, which no one
can validly renounce.”

“84. A wide range of means therefore has to be contemplated: ... violence by pimps to keep prostitutes under
their thumb, taking advantage of an adolescent's or adult's vulnerability, whether or not resulting from sexual
assault, or abusing the economic insecurity or poverty of an adult hoping to better their own and their family's
lot. However, these various cases reflect differences of degree rather than any difference in the nature of the
phenomenon, which in each case can be classed as trafficking and is based on use of such methods.”

_IV. REPORTS CONCERNING CROATIA_

34. In her observations the applicant relied, inter alia, on the following report.
_United States Department of State2017 Trafficking in Persons Report - Croatia, 27 June 2017_

35. The relevant part of that report reads as follows:

“Judges continued to issue light sentences for forced labor and sex trafficking, and often dismissed victim
testimony as unreliable due to a lack of understanding of trafficking.

...

**RECOMMENDATIONS FOR CROATIA**

Vigorously investigate and prosecute suspected traffickers; punish offenders with sentences commensurate
with the severity of the crime, particularly labor traffickers; train judges to ensure the judiciary understands the
severity of the crime when issuing sentences and sensitize judges about secondary trauma in sex trafficking
testimony; ...”

**THE LAWI. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION**

36. The applicant complained of inadequacy of domestic legal framework and the lack of an adequate procedural
response of the domestic authorities to her allegations that she had been pressured into or exploited through
prostitution by T.M. In particular, she alleged that the domestic authorities had failed to elucidate all the
circumstances of the case, had not secured her adequate participation in the proceedings and had not properly
qualified the offence. The applicant relied on Articles 3, 4 and 8 of the Convention. The Court, being master of the
characterisation to be given in law to the facts of the case, will examine these complaints under Article 4 of the
Convention alone which reads as follows:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.


-----

...”

_A. Admissibility1. Compliance with the six-month rule_

37. The Government argued that the application had not been lodged with the six-month time-limit which was to be
counted from the date when the appeal judgment was served on the applicant since her constitutional complaint
had been inadmissible. The Government maintained that in the case at issue there had been no reason for lodging
a constitutional complaint with the Constitutional Court since it had been a well-established practice of that court to
declare inadmissible constitutional complaints lodged by victims or injured parties in criminal proceedings against
third persons. Consequently, the final decision within the meaning of Article 35 § 1 of the Convention for the
purposes of calculating the six-month time-limit in the applicant's case had not been the Constitutional Court's
decision of 10 June 2014, but the County Court's judgment of 21 January 2014. As the applicant had been served
with the County Court's judgment on 28 February 2014, whereas she had lodged her application with the Court on 1
September 2014, she had missed the six-month time-limit.

38. The applicant argued that a constitutional complaint was a remedy to be exhausted. She added that even if the
six-month time-limit were to be counted from the date of receipt of the County Court's judgment (28 February 2014),
she had complied with the six-month time-limit as she had lodged her application with the Court on 27 August 2014.

39. The Court does not have to address the question of whether in the present case a constitutional complaint was
a remedy to be exhausted for the purpose of the application of the six-month rule. In particular, even if the time-limit
was to be counted from the date when the County Court's judgment was served on the applicant, as argued by the
Government, the Court notes that the applicant was served with that judgment on 28 February 2014 (see paragraph
20 above), whereas she had lodged her application with the Court on 27 August 2014, and not on 1 September
2014 as stated by the Government (see paragraph 1 above).

40. In view of the above, the Government's objection regarding the applicant's alleged non-compliance with the sixmonth rule must be dismissed.
_2. The applicant's victim status_

41. The Government also argued that the applicant had lost her victim status because the national authorities had
recognised her status as of a victim of human trafficking and provided her with assistance, support and aid in that
connection.

42. The applicant argued that the mere fact that she had been given the status of a victim of human trafficking and
had been provided with certain assistance could not affect her victim status. She contended that she had remained
defenceless in the face of the accused, who had been released, and that the State authorities had remained
passive. In particular, they had not elucidated all the circumstances of the case and properly qualified the offence.

43. The Court considers that the Government's arguments concern rather the issue whether the applicant was
provided with support and assistance as a victim of human trafficking. Such an issue falls to be considered on the
merits of the applicant's complaints under Article 4 of the Convention. The Court therefore rejects the Government's
objection.
_3. Conclusion as to the admissibility_

44. The Court notes that the application is not manifestly ill-founded within the meaning of Article 35 § 3 (a) of the
Convention. It further notes that it is not inadmissible on any other grounds. It must therefore be declared
admissible.
_B. Merits1. Submissions of the parties_

45. The applicant argued that in Croatia there were serious shortcomings in the legal framework concerning
regulation of trafficking in human begins and exploitation of prostitution. She pointed to a report of the European
Commission expressing concern about the number of convictions related to human trafficking in Croatia, which
appeared too low to have a deterrent effect. The report had also urged the Croatian Government to take proactive
measures to combat trafficking in human beings, including training for judges, prosecutors and other State officials
concerned. She also relied on the United States Department of States Trafficking in Persons Reports concerning


-----

Croatia of 20 June 2014 and 27 June 2017. She pointed out the discrepancy in the number of victims of human
trafficking in Croatia reported by international bodies (around 8,000, according to reports from the United States
State Department) and the number indicated by the Government (184 victims, see paragraph 49 below).

46. The shortcomings of the Croatian legal system were all clearly shown in the case at issue. The applicant
pointed to the lack of clear instructions of her rights as a victim and that the officials who had dealt with her case
had had no training on how to treat victims of sexually-related offences. The relevant authorities had not
investigated and properly assessed all aspects of the applicant's allegations about T.M., such as those that she had
been without means of subsistence and economically dependent on him; that T.M. had used various means of
coercion against the applicant such as the use of his position of power by for example making it clear that he had
been a former policeman and had had an arsenal of weapons; his threats about hurting her family and friends; his
false promises concerning finding a “proper job” for the applicant, which had all been made with the only purpose of
sexual exploitation of the applicant.

47. Even though in the criminal proceedings against T.M. the courts had established that he had exploited her for
prostitution, T.M. had not been convicted of any criminal offence. Moreover, the State Attorney had not reclassified
the criminal offence, committed by T.M. since he had been indicted and prosecuted only for a qualified form of the
crime of pandering which required the use of force, the element which the national courts found missing. Also, in
accordance with the well-established practice the trial court also had the power to reclassify the charges against
T.M. to a lesser criminal offence than the one he had been indicted for.

48. The Government contended that the Croatian legal system contained precise and clear provisions which
criminalised acts such as forcing another person into prostitution, enticing another person into prostitution or
enabling another person to engage in prostitution within an organised scheme. There were also precise procedural
provisions in Croatian law which ensured efficient prosecution of all criminal acts concerning prostitution.

49. The Government also pointed to various strategic documents aimed at prevention and combatting of trafficking
in human beings. Since the introduction of those documents in 2002 184 victims of human trafficking had been
identified. In 2002 the Government had established the National Committee for Suppression of Trafficking in Human
Beings, the Operative Team for Suppression of Trafficking Human Beings, as well as four regional “mobile teams”
focused on providing aid and protection to the victims of trafficking, available twenty-four hours a day and
composed of representatives of social-care centres, the Croatian Red Cross and non-governmental organisations
combatting trafficking in human beings. The members of such teams had to undergo specialised systematic training
organised by the Government's Office for Human Rights and the Rights of National Minorities.

50. As to the case at issue, the Government contended that T.M. had not been convicted because there had not
been sufficient evidence for his conviction. The only evidence against T.M. had been that of the applicant. The
Government analysed in detail the evidence given by the applicant before the trial court and asserted that the trial
court as well as the appellate court had provided comprehensive reasons as to why they had not accepted the
applicant's evidence as entirely reliable.
_2. The Court's assessment(a) Application of Article 4 of the Convention_

51. As to the applicability of Article 4 the Court refers to the principles and considerations set out in the cases of
_Rantsev and_ _Siliadin (see_ _Rantsev v. Cyprus and Russia, no. 25965/04, §§ 273-81, ECHR 2010 (extracts), and_

_Siliadin v. France, no. 73316/01, §§ 112-20, ECHR 2005‑VII)._

52. As to the present case the Court notes that the applicant alleged before the domestic authorities that she had
been psychologically and physically forced by T.M. to participate in a prostitution ring organised by him. In the
domestic proceedings the applicant also alleged that T.M. had fixed the amount of money to be paid by her (the
applicant's) clients; that she had given half of the money she had earned from providing sexual services to T.M.
(see paragraph 9 above). This led to the recognition of her status as a victim of human trafficking by the national
authorities (see paragraph 12 above).


-----

53. The national courts established as uncontested that T.M. had given the applicant a mobile telephone for the
purpose of clients' contacting her for sexual services; that T.M. had driven the applicant to the clients or that she
had provided sexual services in the flat she had occupied together with him (see paragraph 18 above).

54. There can be no doubt that trafficking and exploitation of prostitution threatens the human dignity and
fundamental freedoms of its victims and cannot be considered compatible with a democratic society and the values
expounded in the Convention. In view of its obligation to interpret the Convention in the light of present-day
conditions, the Court considers it unnecessary to identify whether the treatment of which the applicant complained
constituted “slavery”, “servitude” or “forced and compulsory labour”. Instead, the Court concludes that trafficking
itself as well as exploitation of prostitution, within the meaning of Article 3(a) of the Palermo Protocol, Article 4(a) of
the Anti-Trafficking Convention, Article 1 of the Convention for the Suppression of the Traffic in Persons and the
Exploitation of the Prostitution of Others and the CEDAW (see paragraphs 27, 28, 31 and 33 above), fall within the
scope of Article 4 of the Convention and will assess the present case under that provision. In this connection it is
irrelevant that the applicant is actually a national of the respondent State and that there has been no international
element since Article 2 of the Anti-Trafficking Convention encompasses “all forms of trafficking in human beings,
whether national or transnational” (see paragraph 33 above) and the Convention for the Suppression of the Traffic
in Persons and the Exploitation of the Prostitution of Others refers to exploitation of prostitution in general (see
paragraph 27 above).
_(b) General principles of Article 4_

55. The relevant general principles governing the application of Article 4 of the Convention in the specific context of
trafficking in human beings and forced labour are set out in the cases of _Rantsev (cited above, §§ 272-89) and_
_Chowdury and Others v. Greece (no. 21884/15, §§ 86-91, ECHR 2017). The Court reiterates that, together with_
Articles 2 and 3, Article 4 enshrines one of the basic values of the democratic societies making up the Council of
Europe (see _Siliadin, cited above, § 82). Unlike most of the substantive clauses of the Convention, Article 4 § 1_
makes no provision for exceptions and no derogation from it is permissible under Article 15 § 2 even in the event of
a public emergency threatening the life of the nation (see _C.N. v. the United Kingdom, no. 4239/08, § 65, 13_
November 2012).

56. The Court noted in Rantsev that trafficking in human beings was often described as a form of modern slavery,
and it therefore took the view that it was in itself an affront to human dignity and incompatible with democratic and
Convention values, and thus within the prohibition of Article 4, without needing to classify it as “slavery”, “servitude”
or “forced labour”. The identified elements of trafficking – the treatment of human beings as commodities, close
surveillance, the circumscription of movement, the use of violence and threats, poor living and working conditions,
and little or no payment – cut across these three categories (see Rantsev, cited above, §§ 279-82; see also J. and
_Others v. Austria, no. 58216/12, § 104, ECHR 2017 (extracts)._

57. In its _Siliadin judgment the Court confirmed that Article 4 entailed a specific positive obligation on member_
States to penalise and prosecute effectively any act aimed at maintaining a person in a situation of slavery,
servitude or forced or compulsory labour (cited above, §§ 89 and 112; see also _C.N. and V. v. France, no._
67724/09, § 105, 11 October 2012; _C.N. v. the United Kingdom, cited above, § 66; and_ _L.E. v. Greece, no._
71545/12, § 65, 21 January 2016).

58. It follows that States are under a positive obligation to put in place a legislative and administrative framework to
prohibit and punish trafficking, as well as to take measures to protect victims, in order to ensure a comprehensive
approach to the issue, as required by the Palermo Protocol and the Anti-Trafficking Convention (see Rantsev, cited
above, § 285, and L.E., cited above, § 66). States are also required to provide relevant training for law-enforcement
and immigration officials (Rantsev, cited above, § 287) and to conduct a comprehensive investigation (see J. and
_Others, cited above, § 104)._

59. The Court stresses in particular that like Articles 2 and 3, Article 4 also entails a procedural obligation to
investigate when there is a credible suspicion that an individual's rights under that Article have been violated (see
_C.N. v. the United Kingdom, cited above, § 69). The Court's case-law shows that the procedural requirements of_
Articles 2 and 3 of the Convention may go beyond the stage of the investigation, both in situations where the


-----

alleged ill-treatment was perpetrated by State officials and by private individuals (for State officials see, for example,
_Ali and Ayşe Duran v. Turkey (no 42942/02, 8 April 2008); and for private individuals see Beganović v. Croatia, no._
46423/06, § 77, 25 June 2009, and Baştürk v. Turkey, no. 49742/09, § 26, 28 April 2015). The Court has held that
where the investigation had led to the institution of proceedings in the national courts, the proceedings as a whole,
including the trial stage, are to be taken into account. While there is no absolute obligation for all prosecutions to
result in conviction or in a particular sentence, the national courts should not under any circumstances be prepared
to allow life-endangering offences and grave attacks on physical and mental integrity to go unpunished. The
important point for the Court to review, therefore, was whether and to what extent the courts, in reaching their
conclusion, might be deemed to have submitted the case to the careful scrutiny required by Articles 2 and 3 of the
Convention, so that the deterrent effect of the judicial system in place and the significance of the role it was required
to play in preventing violations of the right to life and the prohibition of ill-treatment are not undermined (see
_Beganović, cited above, § 77, relying on Ali and Ayşe Duran, also cited above, §§ 61 and 62)._

60. The same applies in the context of the procedural obligations under Article 4 of the Convention, as was
confirmed in the case of _Chowdury and Others_ where the Court held that the obligation to conduct an effective
investigation connected the prosecuting authorities with the judicial authorities. When these authorities established
that a person had been trafficked, they should take, within their respective competences, all necessary measures
following from the application of relevant criminal provisions (see _Chowdury and Others, cited above, §§ 68 and_
116). The obligation to investigate does not depend on a victim's complaint: once allegations of trafficking have
being brought to the authorities' attention, they must act of their own motion. To be effective the investigation must
be independent from those implicated in the events. The investigation must also be effective in the sense that it is
capable of leading to the identification and punishment of those responsible. This is not an obligation of result, but
of means. A requirement of promptness and reasonable expedition is implicit in this context. The victim must be
involved in the procedure to the extent necessary to safeguard his or her legitimate interests (see L.E., cited above,
§ 68).
_(c) Application of these principles to the present case_

61. The Court notes that the applicant's complaints have three aspects. The first is whether there was an
appropriate legal and regulatory framework for the protection of her rights under Article 4 of the Convention; the
second is whether she was provided with appropriate assistance and support to alleviate the fear and pressure she
had felt while testifying against T.M.; and the third whether in the application of that framework in her particular case
the national authorities complied with their procedural obligations.
_(i) Whether there was an appropriate legal and regulatory framework_

62. In international law, prostitution, sexual exploitation, and trafficking in human beings are closely related. In order
to honour their obligations under Article 4 of the Convention the States must set in place a legislative and
administrative framework that prohibits and punishes forced or compulsory labour, servitude and slavery (see
_Siliadin, cited above, §§ 89 and 112, and Rantsev, cited above, § 285). The member States should be also required_
to ensure that efficient criminal-law provisions are in place for cases concerning forced prostitution. In these cases
like in cases concerning acts such as rape and sexual abuse fundamental values, human dignity and essential
aspects of private life are at stake (see X and Y v. the Netherlands, 26 March 1985, § 27, Series A no 91 and M.C.

_v. Bulgaria, no. 39272/98, § 150, ECHR 2003‑XII)._

63. On the international, European and national level, a broad range of legislation exists which qualifies sexual
exploitation, even with the consent of exploited person, as a criminal offence (see paragraphs 27, 28, 31 and 32
above). It is also widely accepted that victims of exploitation of prostitution should be provided with appropriate
support measures rather than prosecuted (see paragraphs 31 and 33).

64. Thus in the present case, in order to determine whether there has been a violation of Article 4, the starting point
is the domestic legal framework and its application in an applicant's individual case (see Rantsev, cited above, §
284; and C.N. and V. v. France, cited above, § 105).

65. The Court notes that prostitution in Croatia is illegal. Both exploitation of prostitution including forced
prostitution, as the aggravated form of the former, and personal offering of sexual services are criminalised (see


-----

paragraphs 24 and 25 above). The criminal offences of trafficking in human beings, slavery, forced labour and the
criminal offence of pandering were prohibited under the Criminal Code at the time when the alleged acts were
committed and the criminal proceedings at issue conducted and continue to be criminalised today. The consent of a
victim is irrelevant for the existence of the criminal offence of trafficking in human beings and since 2013 the same
is as well expressly stated in Criminal Code for pandering. Furthermore, since 2013 purchase of sexual services
constitutes a criminal act. Prosecution in respect of all of the above offences was to be undertaken by the State
Attorney's Office.

66. The Croatian Code of Criminal Procedure also contains provisions on the rights of victims of criminal offences
and in particular the victims of offences against sexual freedom (see the relevant provisions of the Code of Criminal
Procedure, cited above in paragraph 26).

67. Further to this, the Croatian Government adopted various strategic documents aimed at prevention and
combatting of trafficking in human beings and established specialised teams designated with providing assistance
to the victims of trafficking in human beings (see paragraph 49 above).

68. The Court is therefore satisfied that at the time the alleged offence was committed and prosecuted there was an
adequate legal framework in Croatia for its examination within the context of trafficking in human beings, forced
prostitution and exploitation of prostitution. The Court also notes that in the meantime that framework has been
further improved (see paragraph 25 above).
_(ii) Support given to the applicant_

69. The Court notes that the Government submitted that a range of rights connected with the applicant's status as a
victim of human trafficking had been explained to the applicant, and she had been given various forms of support
and aid, including the rights to counselling, to free legal aid, and to give evidence at the trial without the presence of
the perpetrator (see paragraph 12 above). The applicant contested these submissions in general terms without
specifically pointing out which exact rights or forms of support had been denied to her (see paragraph 46 above).

70. The Court also notes that the applicant never objected to or brought any complaint as to the conduct of the
national authorities, including the court conducting the criminal proceedings against T.M., or any other authority, or
any complaint whatsoever concerning her rights as a victim of human trafficking, or concerning the assistance,
support and any form of counselling provided to her or the lack of it.

71. During the trial the applicant was informed of the possibility to contact the Department for Organising and
Providing Support for Witnesses and Victims within the Z. Municipal Criminal Court. Contact details of that
Department were also provided to the applicant (see paragraph 12 above). There is no evidence that the applicant
contacted the said Department.

72. In these circumstances the Court accepts that the applicant was indeed provided with the support and
assistance as submitted by the Government. That included in the first place recognition of her status as a victim of
human trafficking. As such she was provided counselling by the Croatian Red Cross and free legal assistance
through the State-funded and State-supported programme carried out by a non-governmental organisation.
Furthermore, immediately upon the applicant's request the accused was removed from the courtroom and the
applicant gave evidence in his absence.
_(iii) Whether the State authorities complied with their procedural obligations_

73. The Court will next examine whether or not the impugned regulations and practices, and in particular the
domestic authorities' compliance with the relevant procedural rules, as well as the manner in which the criminal-law
mechanisms were implemented in the instant case, were defective to the point of constituting a violation of the
respondent State's procedural obligations under Article 4 of the Convention (see C.N. v. the United Kingdom, cited
above, § 51).

74. The Court observes that the applicant alleged before the domestic authorities that she had been psychologically
and physically forced by T.M. into prostitution (see paragraphs 6, 9 and 16 above). This led to the recognition by
national authorities of her status as a victim of human trafficking (see paragraph 12 above). These circumstances


-----

entailed the State's obligation under the procedural aspect of Article 4 to properly investigate the applicant's
allegations (see Rantsev, cited above, § 252, ECHR 2010 and also paragraphs 58-60 above).

75. The important point for the Court to review is whether and to what extent the prosecuting authorities in taking
their actions and the courts in reaching their conclusion may be deemed to have submitted the case to the careful
scrutiny required by Article 4 of the Convention, so that the deterrent effect of the criminal-law system in place and
the significance of the role it is required to play in preventing violations of the rights protected under Article 4 of the

Convention are not undermined (see, _mutatis mutandis,_ _Okkalı v. Turkey, no. 52067/99, § 66, ECHR 2006‑XII_

(extracts)).

76. As regards the steps taken by the national authorities, the Court acknowledges that the police and the
prosecuting authorities acted promptly, in particular in carrying out searches of T.M.'s premises, interviewing the
applicant and indicting T.M.

77. On the other hand the Court cannot but note that the only witnesses interviewed during the investigation and
heard at the trial were the applicant herself and her friend M.I. Whereas it is true that M.I. did not entirely
corroborate the applicant's statement, the Court notes that there is indication that it was M.I.'s mother and not M.I.
to whom the applicant turned for help and with whom she spoke on the telephone on the day she fled the flat she
had been sharing with T.M. Immediately after having run from T.M., the applicant spent several months with M.I.
and her mother. However, the investigating authorities did not obtain a statement from M.I.'s mother. Likewise, they
did not interview M.I.'s boyfriend, T.R., who had taken the applicant from the flat at issue and driven her to M.I.'s
and her mother's flat.

78. These elements, together with those listed below show that the national authorities did not made a serious
attempt to investigate in depth all relevant circumstances and to gather all available evidence. They did not make
further attempts to identify the applicant's clients and interview them, and in particular the individual to whom T.M.
had taken the applicant to give sexual services for the first time. They also did not hear evidence from the
applicant's mother, the landlord and neighbours of the applicant and T.M., all of whom could have had some
relevant knowledge of the true relationship between the applicant and T.M., alleged beatings and locking her up in
the apartment.

79. The Court notes the applicant's allegations of being economically dependent on T.M. and of various forms of
coercion he had allegedly used against her such as stressing being a former policeman who had had “an arsenal of
weapons”, making threats of hurting her family and manipulating her with false promises that he would find her a
“proper job” (see paragraph 9 above) as well as M.I.'s statement that the applicant had been very distressed and
scared of T.M. who had continued to threaten the applicant through social media network when she had lived with
M.I. (see paragraph 10 above). There is no indication that the national authorities made a serious attempt to
investigate in depth these circumstances, which were all relevant for assessing whether T.M. had forced the
applicant into prostitution. It appears that no consideration was given to the fact that during the search of T.M.'s
premises the police had found several pieces of automatic rifles (see paragraph 8 above). The national courts did
not give adequate attention to these elements and concluded that the applicant had given sexual services
voluntarily. Furthermore, the Court notes that according to Croatian law, the United Nations Convention for the
Suppression of the Traffic in Persons and the Exploitation of the Prostitution of Others and the Council of Europe
Anti-trafficking Convention, the consent of the victim is irrelevant (see above, paragraphs 24-25, 27 and 33).

80. The Court further notes that the national courts dismissed the applicant's testimony as unreliable because they
deemed her statement as being incoherent, that she had been unsure and that she had paused and hesitated when
speaking (see paragraphs 18 and 35 above). The national authorities did not make any assessment of the possible
impact of psychological trauma on the applicant's ability to consistently and clearly relate the circumstances of her
exploitation. The Court, given the vulnerability of the victims of sexually-related offences, also accepts that the
encounter with T.M. in the courtroom could have had an adverse effect on the applicant, regardless of T.M. being
subsequently removed from the courtroom (see paragraph 15 above).
_(iv) Conclusion_


-----

81. In conclusion, the Court considers that the above elements demonstrate that, in the particular circumstances of
this case, the relevant State authorities did not fulfil their procedural obligations under Article 4 of the Convention.
There has accordingly been a violation of Article 4 of the Convention.
_II. APPLICATION OF ARTICLE 41 OF THE CONVENTION_

82. Article 41 of the Convention provides:

“If the Court finds that there has been a violation of the Convention or the Protocols thereto, and if the internal
law of the High Contracting Party concerned allows only partial reparation to be made, the Court shall, if
necessary, afford just satisfaction to the injured party.”

_A. Damage_

83. The applicant claimed 20,000 euros (EUR) in respect of non‑pecuniary damage.

84. The Government submitted that the applicant's claim for non‑pecuniary damage was unfounded, excessive and

unsubstantiated.

85. Having regard to all the circumstances of the present case, the Court accepts that the applicant has suffered
non-pecuniary damage which cannot be compensated for solely by the finding of a violation. Making its assessment
on an equitable basis the Court, given the purely procedural nature of the violation found, awards the applicant EUR
5,000 in respect of non-pecuniary damage (compare C.N. v. the United Kingdom, cited above, § 90).
_B. Costs and expenses_

86. The applicant also claimed EUR 4,376.15 for the costs and expenses incurred before the Court.

87. The Government argued that the applicant was represented by a lawyer provided for by a non-governmental
organisation and funded by the State. They also claimed that the applicant's request for costs and expenses was
unsubstantiated and excessive.

88. The Court notes that the applicant did not refute the Government's submission that her representative had
already been paid from the State funds. In these circumstances the Court rejects the applicant's claim for costs and
expenses.
_C. Default interest_

89. The Court considers it appropriate that the default interest rate should be based on the marginal lending rate of
the European Central Bank, to which should be added three percentage points.
**FOR THESE REASONS, THE COURT**

1. Declares, by a majority, the application admissible;

2. Holds, by six votes to one, that there has been a violation of Article 4 of the Convention in its procedural limb;

3. Holds, by six votes to one,

(a) that the respondent State is to pay the applicant, within three months from the date on which the judgment
becomes final in accordance with Article 44 § 2 of the Convention, EUR 5,000 (five thousand euros), plus any tax
that may be chargeable, in respect of non-pecuniary damage, to be converted into Croatian kunas (HRK) at the rate
applicable at the date of settlement;

(b) that from the expiry of the above-mentioned three months until settlement simple interest shall be payable on
the above amount at a rate equal to the marginal lending rate of the European Central Bank during the default
period plus three percentage points;

4. Dismisses, unanimously, the remainder of the applicant's claim for just satisfaction.
**DISSENTING OPINION OF JUDGE KOSKELO**


-----

1. I regret to have found myself unable to agree with the majority in the present case regarding both the
admissibility and the merits.
_A. Admissibility_

2. I have voted against declaring the application admissible. The opposite conclusion adopted by the majority is, in
my opinion, wrong in the light of the complaint as submitted to the Court. I consider that the majority have examined
the case on the basis of facts which the applicant has neither raised nor relied on in her complaint before the Court.
In so doing, the majority have gone beyond the scope of the case referred to the Court and exceeded the limits of
its jurisdiction.

3. I would recall at the outset that, as the Court's Grand Chamber has recently underlined, a complaint is
characterised, and limited, by the facts alleged in it. The Convention does not permit the Court to seize on facts that
have not been adduced by the applicant and to examine such facts for compatibility with the Convention. That the
scope of a case before the Court remains circumscribed by the facts as presented by the applicant is of
fundamental importance, because if the Court were to base its decision on facts not covered by the complaint, it
would rule beyond the scope of the case and exceed its jurisdiction by deciding matters which were not “referred to”
it, within the meaning of Article 32 of the Convention (see Radomilja and Others v. Croatia [GC], no. 37685/10, §§
108, 113, 121, 123 and 126, 20 March 2018).

4. In the present case, the applicant's complaint (of which, exceptionally, a translation has been made available)
was brought under Articles 3, 6 and 8 (but not Article 4). Its factual basis is that T.M., against whom the applicant
had raised an allegation of having forced her into prostitution, was not convicted before the domestic courts,
although the latter had established that the constituent elements of a lesser form of the alleged criminal offence,
namely pandering (which involves no use of force) had been proven. According to settled case-law, the Convention
guarantees no right to obtain the criminal conviction of any particular person (see _Javor and Others v. Hungary_
(dec.), no. 11440/02, 25 August 2005). This position is pertinent to the applicant's grievances under Articles 3 and
6, as well as to her complaint that the acquittal of T.M. had entailed a violation of her private life in terms of her
physical integrity.

5. Apart from the above specific grievances, the applicant has only introduced her complaints by stating that:

“the State must undertake adequate actions in order to punish those who act in an unlawful way. Thus, when
an individual lodges a criminal complaint, the State has a 'procedural' obligation to investigate the case, after
investigation to prosecute the perpetrators and, in the event of finding them guilty, to punish them in
accordance with the law”.

Such statements are nothing more than abstract references to the States' legal obligations under the procedural
limb of Article 3.

6. As the Court has held, it is not sufficient for an applicant to invoke Convention law in the abstract. A complaint
consists of two elements: factual allegations and legal arguments. The applicant is required not only to invoke a
legal norm but also to indicate the factual basis of the complaint and the nature of the alleged violation (see Allan v.
_the United Kingdom (dec.), no. 48539/99, 28 August 2001)._

7. Thus, the complaint submitted by the applicant must contain the factual parameters necessary for the Court to
define the issue which it is requested to examine. This is of fundamental importance, as the role of the Court cannot
be to act of its own motion, and also because it is necessary to ensure the adversarial nature of the proceedings
before the Court. The latter is required by Article 38 of the Convention, pursuant to which the Court must examine
the case “together with” the representatives of the parties, and by the Rules of Court (see Rule 54 § 2 (b) in
particular). The respondent Government must be in a position to know, on the basis of the complaint submitted by
the applicant, what are the issues that may come to be examined by the Court.

8. In the present case, the majority have proceeded to examine and adjudicate on issues to which the applicant
made no reference whatsoever in her application, or even in her subsequent observations to the Court. In
particular, the applicant did not raise any complaints regarding failures in the investigation, or indicate any


-----

deficiencies in the collection of evidence by the domestic authorities, nor has she pointed out any omissions in
respect of possible additional witnesses. Consequently, the respondent Government have not been afforded any
opportunity to comment on the elements which the majority have relied on as the basis for concluding that there has
been a violation in respect of the procedural obligations arising under Article 4.

9. While I do acknowledge that the applicant is in a vulnerable position, she has been assisted by a professional
lawyer throughout the domestic proceedings as well as before this Court. I can see no justification for the Court to
set aside basic principles of procedure. In my opinion, the Court has no jurisdiction to examine issues not
complained of by the applicant, and there is no reason why the present case should permit an exception from such
a fundamental norm.

10. A failure to respect the limits to the Court's jurisdiction set by the content of the complaint is serious because it
distorts the Court's role and undermines the adversarial nature of the proceedings that is essential for the authority
and legitimacy of an organ empowered to issue binding judgments. An equal treatment of applicants addressing the
Court is also neglected if the Court does not act consistently in this regard. Applicants are required to accept that
the Court will not go beyond an examination of the complaint they actually submitted, and this should apply to them
all.
_B. Merits_

11. As regards the merits of the case, I have two distinct grounds for my dissent. Firstly, I object to the manner in
which the majority use the present case as an occasion to expand the scope of application of Article 4. Secondly, I
object to the manner in which the majority, of their own motion, take on the role of a first-hand, or “first instance”,
examiner of the quality of the conduct of the domestic criminal proceedings.

12. I note at the outset that, at the domestic level, the applicant lodged a criminal complaint alleging that she had
been forced into prostitution. The final domestic decisions established, however, that the element of coercion was
not proven. In her application, the applicant referred to Article 3.

13. I would therefore recall that the Court has held that prostitution is incompatible with Article 3 of the Convention
when it is coerced (see V.T. v. France, no. 37194/02, § 25, 11 September 2007). At the same time, the Court has
acknowledged that there is no consensus among the member States of the Council of Europe regarding other
forms of prostitution and has therefore not taken any position as to whether prostitution as such is incompatible with
Article 3 (ibid., § 24).

14. In the present case, the majority have chosen to consider the case under Article 4 of the Convention. The
reason for this is neither obvious nor explained, but it may be linked with the fact that in a final domestic judgment
no coercion was established, together with an ambition to achieve a change in the case-law through a novel
interpretation of the latter provision.
_(i) The scope of Article 4_

15. In Rantsev v. Cyprus and Russia (cited in paragraph 51 of the present judgment), the Court held that human
trafficking, _within the meaning of Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti-Trafficking_
_Convention, fell within the scope of Article 4 of the Convention (see Rantsev, § 282). The words cited in italics are_
significant, because they link the scope of Article 4 with the definition of human trafficking as set out in the
provisions referred to (cited in paragraphs 31 and 33 of the present judgment) and limit that scope accordingly.

16. What is important to note is that the definition of human trafficking in the above instruments consists of three
cumulative elements, all of which must be present, namely the “action”, the “means” and the “purpose”[1]. The
“action” comprises “recruitment, transportation, transfer, harbouring or receipt of persons”. The “means” comprise
“the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or
of a position of vulnerability of or the giving or receiving of payments of benefits to achieve the consent of a person
having control over another person”. Finally, the purpose consists of “exploitation”. The latter is not defined but
“shall include, as a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation,
forced labour or services, slavery or practices similar to slavery, servitude or the removal or organs”.


-----

17. Three points are particularly essential. Firstly, in the above instruments relied on in _Rantsev, the notions of_
“exploitation of the prostitution of others” and “other forms of sexual exploitation” are relevant only as parts of the
“purpose” element of the definition of trafficking. Secondly, the terms “exploitation of the prostitution of others” and
“other forms of sexual exploitation” are not defined in those instruments. This is a deliberate choice in order for
these instruments to remain without prejudice to how States Parties deal with prostitution in their domestic law[2].
Thirdly, while it is correct that according to Article 4(b) of the Anti-Trafficking Convention, the consent of the victim is
irrelevant, this does not have the effect of diluting the “means” elements in the definition of trafficking. On the
contrary, the provision states that “the consent of the victim of 'trafficking in human beings' to the intended
exploitation of the prostitution of others or other forms of exploitation ... shall be irrelevant where any of the means
set forth ... have been used”. In other words, the victim's consent is no valid defence, and cannot have the effect of
exonerating the perpetrator, where it is established that the “means” element is present (cf. paragraph 79 of the
present judgment, where the majority appear to confuse the issues; in the present case the domestic courts did not
find that there was sufficient evidence to establish that the applicant had been forced into prostitution, such that the
issue of consent – in terms of consent not being capable of constituting a valid defence – could not even arise).

18. Whereas in _Rantsev the Court was careful to link its interpretation of the scope of Article 4 expressly and_
exclusively to the notion of human trafficking as defined in the Palermo Protocol and the Anti-Trafficking
Convention, the majority in the present case go far beyond that position by holding that both trafficking and the
exploitation of prostitution fall within the scope of Article 4 (see paragraph 54 of the present judgment). Notably, as
explained above, neither the Palermo Protocol nor the Anti-Trafficking Convention purport to ban the “exploitation of
prostitution” as a phenomenon distinct from its place as an element of the “purpose” component of human
trafficking, nor is it defined in those instruments. By considering now that the “exploitation of prostitution” – whatever
is meant by it – falls within the prohibition enshrined in Article 4, the majority introduce an enlargement of the scope
of that Article that is both significant and obscure. The latter aspect is particularly problematic in the light of the
requirement that such exploitation be qualified as a criminal offence (see paragraph 63 of the present judgment)
which, in the absence of any further definition, cannot but raise concerns under Article 7 of the Convention.

19. It is well known that there is no uniform understanding of what should qualify as “exploitation of prostitution” or
“sexual exploitation”. While some would consider that prostitution always involves exploitation, such a view is not
shared by others, nor do differences of opinion necessarily follow gender lines. Likewise, the policy approaches
adopted in the member States of the Council of Europe vary, as has been recognised in the Anti-Trafficking
Convention mentioned above and also in the Court's case-law (see V.T. v. France, cited above, § 24).

20. Interestingly, the majority refer to Article 1 of the older, 1951 UN Convention for the Suppression of Traffic in
Persons and the Exploitation of the Prostitution of Others, which indeed lays down a more generally formulated
obligation to “punish any person who, to gratify the passions of another... exploits the prostitution of another person”
(see paragraphs 27 and 54 of the present judgment). It is, however, important to note that quite a large number of
member States of the Council of Europe have not ratified this particular Convention (unless I am mistaken, 26 of the
47 member States are parties to it), whereas all of them have ratified the more recent and less comprehensively
formulated Anti-Trafficking Convention (to which reference was made in Rantsev).

21. What is also striking is that the new, significant development in the scope of Article 4 is introduced without any
real analysis, without proper discussion or explanation, and without clarity or openness. On the contrary, the
subsequent presentation of general principles blurs the issue by citations of case-law which refer to trafficking (see
paragraphs 58 and 60). It would also be problematic to suggest that the initial recognition of a person as a victim of
trafficking, for the purpose of qualifying for various measures of support, was in itself sufficient to engage the
application of Article 4 regardless of any further developments in the course of the case (see paragraph 52 of the
present judgment).

22. Furthermore, in the questions on which the Court invited the parties to submit observations, reference in respect
of issues under Article 4 was only made to Rantsev (§§ 283-89). Nothing suggested to the parties that they should
address a possible further extension of the scope of that Article. There has thus been no reason for the parties, or
any other interested circles, to anticipate that the scope of Article 4 would now be detached from the criteria that
define human trafficking (on which there is consensus among the member States) and extended to cover situations


-----

without the elements of coercion, deception or abuse that are required in the context of human trafficking. Notably,
the Contracting States most concerned by the issue, namely those where the current legislative policy for the
regulation of prostitution is different from that of the respondent State (the latter entailing that prostitution and the
purchase of sexual services are illegal, see paragraph 65 of the present judgment), will be taken by complete
surprise, and will not even have any possibility of requesting a referral of the case to the consideration of the
Court's Grand Chamber, this right being reserved to the parties to the case. Transparency and legal certainty do not
appear to have much bearing on the approach taken.

23. I would like to underline that the above criticism is not linked with the specific subject matter of the case or any
personal views in that regard. Rather, these are more general concerns about such a manner of judicial activity,
which I find highly problematic.
_(ii) The issue of compliance with procedural obligations_

24. It is well established that States have a positive obligation inherent in both Articles 3 and 4 of the Convention to

enact criminal‑law provisions effectively punishing serious acts prohibited under those provisions, even where they

are not committed by State agents but by private individuals, and to apply them in practice through effective

investigation and prosecution (see M.C. v. Bulgaria, no. 39272/98, § 153, ECHR 2003‑XII, and L.E. v. Greece, no.

71545/12, §§ 65 and 68, 21 January 2016). Concerning such serious acts, the State's positive obligation to
safeguard the individual's physical integrity may also extend to questions relating to the effectiveness of the criminal
investigation (see, for instance, _Y. v. Slovenia, no. 41107/10, 28 May 2015 ) and to the possibility of obtaining_
reparation and redress (see C.A.S. and C.S. v. Romania, no. 26692/05, 20 March 2012).

25. As regards the Convention requirements relating to the effectiveness of an investigation, the Court has held that
it should in principle be capable of leading to the establishment of the facts of the case and to the identification and
punishment of those responsible. This is not an obligation of result, but one of means. The authorities must have
taken the reasonable steps available to them to secure the evidence concerning the incident, such as witness
testimony and forensic evidence, and a requirement of promptness and reasonable expedition is implicit in this
context (see, for instance, _Y. v. Slovenia, cited above, § 96, with further references). The promptness of the_
authorities' reaction to the complaints is an important factor (see Labita v. Italy [GC], no. 26772/95, §§ 133 et seq.,

ECHR 2000‑IV). Consideration has been given in the Court's judgments to matters such as the opening of

investigations, delays in identifying witnesses or taking statements (see _Mătăsaru and_ _Saviţchi v. Moldova, no._
38281/08, §§ 88 and 93, 2 November 2010), the length of time taken for the initial investigation (see Indelicato v.
_Italy, no. 31143/96, § 37, 18 October 2001), and unjustified protraction of the criminal proceedings resulting in the_
expiry of the statute of limitations (see _Angelova and Iliev v. Bulgaria, no. 55523/00, §§ 101-03, 26 July 2007)._
Moreover, notwithstanding its subsidiary role in assessing evidence, the Court has held that where allegations are
made under Article 3 of the Convention the Court must apply a particularly thorough scrutiny, even if certain
domestic proceedings and investigations have already taken place (see Cobzaru v. Romania, no. 48254/99, § 65,
26 July 2007).

26. In the present case, the applicant brought a criminal complaint against T.M. alleging that the latter had forced
her into prostitution. An investigation was conducted and led to charges being brought against T.M. for having
forced another person into prostitution. The applicant chose not to participate in the proceedings as the injured
party and did not exercise the requisite procedural rights, although she did appear as a witness. The trial court
acquitted T.M. on the grounds of insufficiency of evidence. The prosecution lodged an appeal, but the acquittal was
upheld by the Court of Appeal.

27. Under such circumstances, the Court would need a solid basis for the conclusion that the respondent State has
failed in its duties of investigation and in the enforcement of the relevant criminal law provisions. In the present
case, I consider that for several reasons, the Court does not have a sufficient basis for such a finding.

28. Firstly, the applicant has not raised any specific complaints regarding the investigation. At the domestic level the
applicant, who was provided with free legal assistance (see paragraph 72 of the present judgment), refrained from
engaging in the criminal proceedings as the injured party, which would have included the right for her to point out


-----

facts and present evidence (see paragraph 26 of the present judgment). It does not appear that the applicant or her
legal representative raised any concerns, or attempted to address, any shortcomings in the identification of possible
witnesses.

29. Secondly, and more fundamentally, neither the applicant's complaint nor her observations before this Court
contain any allegations regarding a failure to identify or obtain evidence from witnesses other than those actually
heard in the domestic proceedings. (As discussed above, this aspect of the case should therefore not have been
admissible for examination by the Court in the first place.) Consequently, the Court has not received any party's
submissions that could provide a basis for its consideration of the question whether or not there were any
unjustified omissions in the investigation or in the taking of evidence from possible witnesses.

30. Thirdly, as a result of the above, the Court in the present case has delved into the case file, of its own motion
and without input from the parties, in order to identify persons who might have been, or ought to have been,
involved as witnesses in the domestic investigation. As no shortcomings in this regard have been alleged or
specified at the domestic level or before this Court, or otherwise addressed at either level, the majority are here
taking on the role of a first-hand examiner and first-instance arbiter of the quality of the domestic criminal
investigation.

31. Yet the Court has no direct, or under the circumstances even indirect, information about the reasons which may
lie behind, or explain, the steps that were taken, or not taken, or not pursued, in the course of a given investigation.
Among other things, a possible explanation may lie in the fact that the applicant did not lodge her criminal complaint
until a year after the events complained of, and the fact that both the identification of, and the receipt of testimony
from, the applicant's clients would presumably have encountered difficulties, as the purchase of sexual services in
itself is criminalised under the domestic law. The Court is, inevitably, on a very fragile and treacherous ground if it
ventures into the kind of exercise that the majority have undertaken in the present case – totally on its own, with no
input even from the parties. Normally, the Court should be conducting a review of how the issues referred to it in a
complaint have been dealt with, assessed and addressed at the domestic level, and it should be doing so on the
basis of the specific allegations raised and the submissions made by the parties before it. In the present case, the
majority are operating outside such a normal scenario and without the requisite adversarial basis.

32. Fourthly, the domestic case file is available only in the national language. In a case such as the present, most of
the judges composing the Chamber are not, for linguistic reasons, in a position to examine the case file on their
own, or to form any independent opinion of the elements in it. In the present kind of situation, where the Court is not
operating in a normal scenario, as referred to above, but has entered of its own motion, without the benefit of either
prior domestic assessments or party input, into a first-hand scrutiny of a domestic criminal investigation, the lack of
independent access to the elements that are being examined is quite problematic from the point of view of the
requirements inherent in the judicial role. All I can know about the domestic case file is what is included in the
judgment. To determine on that basis whether a failure to engage certain persons as witnesses represents noncompliance with the State's procedural obligations, or that there was “no serious attempt to investigate in depth all
relevant circumstances and to gather all available evidence” (see paragraphs 78 and 79) is too flimsy, at least by
my standards. If there was no serious attempt to investigate the case and if relevant witnesses were not heard, one
must wonder why the applicant, through her legal representative, did not raise any complaint based on such factual
allegations either domestically or before this Court.

33. Turning now to the assessment of the evidence before the domestic courts, in this respect I consider that the
majority enter into a very problematic fourth-instance mode. It is asserted that the applicant's testimony was
“dismissed” as unreliable without “any assessment of the possible impact of psychological trauma on her ability to
consistently and clearly relate the circumstances of her exploitation” (see paragraph 80 of the present judgment).
Such a statement implies that the majority perceive “her exploitation” as a fact, whereas the purpose of the trial was
to establish whether, as charged, T.M. had indeed forced the applicant into prostitution, and the conclusion reached
by the domestic courts on the evidence was that this had not been the case.

34. The majority further suggest that when assessing the evidence before them, the domestic courts failed to take
into account the applicant's situation and its possible impact on her demeanour when giving testimony. I have no


-----

idea how, and on what basis, the majority are able to make an assessment to conclude that the domestic court
made no assessment of those aspects of the applicant's testimony. Domestic criminal courts are frequently called
upon to take and assess evidence given by persons who are vulnerable and in distress. This Court has not heard
any of the domestic evidence, nor does it have any access to records of testimonies as given at the domestic trial,
nor can it be privy to the deliberations where an assessment of evidence has been conducted. Yet the majority
consider that they are in a position to determine that the domestic courts failed to take into account “the possible
impact of psychological trauma on her ability to consistently and clearly relate” the events. I have not seen any
tenable basis for such a finding.

35. Finally, the majority “accept” that the initial presence of T.M. in the courtroom could have had an adverse effect
on the applicant although he was not there when the applicant gave her evidence. Yet a defendant normally has a
right to be present at his own trial, and the domestic courts can hardly be criticised, without more, for this having
been permitted at the outset. The record shows that T.M. had been removed from the courtroom “immediately upon
the applicant's request” (see paragraph 72 of the present judgment). It is also established that prior to the trial, the
applicant had been officially given the status of victim of (alleged) human trafficking, and had received both psychosocial support, counselling and free legal aid (see paragraph 12 of the present judgment).

36. I would also note that while the majority cite extensively from the pre-trial statements (see paragraphs 9-10 of
the present judgment), the domestic courts (in line with Convention requirements) were called upon to adjudicate
the case on the evidence presented at the trial and not on the records from pre-trial interviews.

37. My conclusion, in the light of the above, is that I do not see a sufficiently solid basis for the Court to make the
kind of findings in which the majority consider that there has been a failure by the respondent State's authorities to
comply with the procedural obligations incumbent on them.

38. Lastly, on a point of law, I would reiterate that in my view, the statement made by the majority at the end of
paragraph 79 of the present judgment is based on a misconception of the norm according to which the victim's
consent is irrelevant. As mentioned in paragraph 17 above, that norm entails that where coercion or another form of
the “means” element of trafficking has been established, the victim's consent is incapable of operating as a valid
defence to the effect of exonerating the perpetrator. Where no coercion has been established, this issue does not
arise. Thus, in the context of the present case, the statement at the end of paragraph 79 is beside the point.
_C. Concluding remark_

39. I have set out the reasons for my dissent as regards the majority's approach to both the admissibility and the
merits of the present case. To sum up, in my opinion this is not how the Court is meant to operate, nor is it an
appropriate way for it to operate.

1

**End of Document**

1   See the Explanatory Report to the Council of Europe Convention on Action against Trafficking in Human Beings,
§§ 74-76.

2 S h 88 f h E l R f d b


-----

