# R v Henkoma [2023] EWCA Crim 808

Court of Appeal, Criminal Division

Lady Justice Carr, Mrs Justice May and the Recorder of Sheffield (His Honour Judge Jeremy Richardson KC)

14 July 2023Judgment

**Benjamin Douglas-Jones KC and James Robottom (instructed by Philippa Southwell of Southwell &**
**Partners Solicitors) for the Appellant**

**Andrew Johnson (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date : 7 July 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10am on Friday 14 July 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Lady Justice Carr :**

**Introduction**

1. On 9 October 2014, in the Crown Court at Woolwich before His Honour Judge Shorrock, the applicant
(then aged 16 years) changed his plea to guilty to the offence of possessing a firearm without a certificate,
contrary to s.1(1)(a) of the Firearms Act 1968 (Count 2). The applicant also pleaded guilty to the offence of
failing to surrender to custody, contrary to s.6 of the Bail Act 1976. We refer to these matters as “the
Woolwich offences”. The applicant was sentenced to a 4 month Detention and Training Order on Count 2,
and 7 days' detention in a Young Offender Institution for the offence of failing to surrender, such sentences
to run concurrently with each other.

2. On 14 July 2017, in the Crown Court at Isleworth before His Honour Judge Matthews, the applicant
(then aged 19 years) pleaded guilty to the offence of possessing a prohibited firearm, contrary to
s.5(1)(aba) of the _[Firearms Act 1968 (Count 1) and possessing ammunition without a firearm certificate,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CN10-TWPY-Y0VN-00000-00&context=1519360)_
contrary to s.1(1)(b) of the Firearms Act 1968 (Count 2). We refer to these matters as “the Isleworth
offences”. The applicant was sentenced to 5 years' detention in a Young Offender Institution on Count 1,
and 12 months' detention on Count 2, such sentences to run concurrently with each other.

3. The applicant was born in Nigeria on 13 May 1998 and is now 25 years old. He seeks leave to appeal
against these convictions, alongside applications to adduce fresh evidence and for very significant
extensions of time. He has an appeal as of right in respect of the Bail Act offence, subject to the need for
an extension of time.

4. The grounds of appeal advanced in each matter are the same. In summary, it is said that it is now
known that the applicant was a victim of trafficking (VOT) at the time of the offending. Had his status and
the nexus of the trafficking to the offending been known the Crown Prosecution Service (CPS) would or


-----

might well not have prosecuted him. The applicant's criminality or culpability was significantly diminished
and effectively extinguished. He had no realistic alternative but to comply with the dominant force of others.
Further, the Crown and/or police did not effect their operational duties under Article 4 of the European
Convention on Human Rights and Fundamental Freedoms (Article 4) to investigate the possible status of
the applicant as a VOT. The convictions are unsafe as a result.

5. The applications are resisted by the respondent. Whilst it is accepted that there is credible evidence that
the applicant was exploited by a criminal gang, and that there is nexus between the exploitation and the
offences in question, the prosecutions were nevertheless in the public interest, given the gravity of the
offending. There was no abuse of process and the convictions are not unsafe.

6. We record at this stage that shortly before this hearing we refused a very late application to intervene by
ECPAT UK, a specialist anti-trafficking charity.

**Facts: the Woolwich offences**

7. On 29 November 2013, police officers attended a hostel in Lewisham following a stabbing (in respect of
which the applicant was not implicated). A man named Wright lived there. The caretaker at the premises
found a black bag in a boiler cupboard in the laundry room. A police officer found a firearm with two barrels
inside the bag, the butt of the firearm being wrapped in a red bandana/scarf. It also contained machetes
and Samurai swords.

8. On 1 December 2013, police officers attended the applicant's address and he was arrested on
suspicion of being linked to the firearm. He was subsequently interviewed and gave a 'no comment'
interview. He was interviewed again the next day and shown CCTV footage from the hostel and asked
about a picture of himself holding a gun with the same red bandana. Again, he made no comment.

9. CCTV footage from 29 November 2013 depicted a man, said to be someone named Makanju, leaving
Wright's room at the hostel, carrying a black bag identical to that later found. He was with the applicant and
another man. All three left the premises with Makanju carrying the bag. The applicant later returned to the
premises and was depicted taking the black holdall into Wright's room. A short time later, the applicant,
carrying the black holdall, and another man left Wright's room and went to the laundry room. They were
recorded returning to Wright's room without the bag.

10. The applicant had previously shown his social worker a photograph of himself with a gun. On 14
November 2013, a woman attended Croydon police station and reported her daughter as missing. She
showed the police a photograph of the man with whom she believed her daughter to be. The man was
known to her as 'Sosa' and the photograph was of the applicant posing with a long-barrelled firearm with a
red and white bandana wrapped around the handle. The applicant's social worker confirmed that the
applicant was the person shown in both photographs. A Facebook account from a tablet device seized
from the applicant's home contained another photograph of the applicant holding a firearm.

11. Following his arrest, the applicant had been bailed to attend before the Crown Court at Woolwich on
18 August 2014, but failed to surrender to custody. He was arrested on 5 October 2014 and later pleaded
guilty to this offence.

12. The sentences imposed for the Woolwich offences were ordered to run concurrently to a sentence
imposed a short time earlier for a bladed article offence. That conviction is apparently the subject of a
separate application to the Criminal Cases Review Commission.

13. The applicant failed to comply with the terms of the Detention and Training Order, as a result of which
those terms were varied so as to impose supervision and curfew requirements.

**Facts: the Isleworth offences**

14. On 12 June 2017, police officers attended the applicant's home address as a result of an anonymous
call. The applicant's then partner and their two children, aged three and one, left the property, followed by
the applicant. An officer at the scene saw an object fall to the ground out of a window to the rear of the


-----

property. The officer found a bag on the floor which contained a black revolver with eight casings and one
live round of ammunition.

15. The applicant was arrested for possession of the firearm, and ammunition. He was subsequently
interviewed and gave a 'no comment' interview, save for a prepared statement in which he stated that he
did not know anything about the items found. They were not his and must have already been in the
gardens and his DNA would not be on the firearm.

16. A forensic examination of the firearm identified the applicant's fingerprint on the frame of the gun
behind the cylinder. It was an Alfa-Proj model 620 revolver, less than 60 cms in length. The ammunition
consisted of one unfired 4mm Flobert calibre cartridge. Testing of the firearm and ammunition revealed the
performance of the firearm to be low compared to other firearms firing bulleted cartridges, but similar in
kinetic energy to an airgun. The ammunition was undersized and not intended for that weapon. It would be
discharged at a low velocity that was not capable of skin penetration.

17. In mitigation, it was stated that the applicant was holding the gun on behalf of someone else and had
possession of it for only a matter of days before it was discovered by police. Both the applicant's parents
were deceased and he had been in the care of social services since he was six or seven years old.

**Events following conviction and fresh evidence**

18. Following deportation proceedings commenced in March 2018, on 10 March 2020, the applicant
received a positive Conclusive Grounds decision. The Single Competent Authority found him to be a VOT
for the purpose of forced criminality but determined that the period of trafficking was limited to between
2010 and 2014. Following submissions from the applicant's immigration solicitors, the applicant received
another Conclusive Grounds decision dated 6 August 2020 which determined that, on the balance of
probabilities, the applicant was a victim of **_modern slavery for the purpose of forced criminality not only_**
from 2010 to 2014, but also during the period 2014 to June 2017.

19. The applicant has provided a witness statement dated 30 March 2022, in which he gives fresh details
of the offending, the compulsion that he was under as a trafficked person and the lack of advice given to
him about modern slavery and exploitation.

20. He has also produced various expert reports, apparently prepared for the purpose of immigration
proceedings, including a psychological report and a report relating to the applicant's ability to integrate into
society in Nigeria; and also extensive records from Greenwich social services.

21. The matters referred to above in this section are the subject of the applications to adduce fresh
evidence, and we have considered them de bene esse.

22. Mr Douglas-Jones KC for the applicant draws on the following features in particular. The applicant
came to the United Kingdom in 2007. He was “tortured” by his stepmother, with some 50 scarring injuries
to prove it, and ran away from home. He was taken into care in 2008. Between March 2009 and June 2013
he was in a stable foster home. But he started going missing, with increasing signs of gang involvement.
There were breaches of Article 4 from as early as July 2012, when he was 14 years old and disclosing
association with gang members of a well-known gang. In 2013 he was talking of missing school because
he was under threat from older people. At a school meeting he said that he was “petrified” and it was noted
that he was on the verge of gang involvement. There were, in short, grounds for credible suspicion that he
was a VOT being recruited by gangs for the purpose of criminal exploitation. Yet no steps were taken to
refer him to the NRM, or to remove him from the local area.

23. The failings continued into and beyond 2013. The applicant was reporting that he was being
threatened for not selling drugs and being in debt bondage. He was recorded as being reduced to tears
because of threats to his mother. He moved schools and a new foster placement broke down. There was a
suggestion of a move to Folkestone, but that never took place. He went missing repeatedly during the
summer of 2013. In November 2013 he was said to be involved with a “drug den” in Margate.

24. Then came the Woolwich offending described above, and in due course the Isleworth offending,
itt d i i t f i ifi t th t B thi t th li t tt ti t t i t


-----

himself from gang activity and trying to hide from people looking for him. Despite the clear risks of harm, of
which the police and social services were aware, no referral to the NRM was made.

The applicant's trial lawyers' responses

25. The solicitors who had acted for the applicant in relation to the Woolwich offences state that the
applicant said nothing to them to indicate that he was a VOT. Likewise, the applicant's counsel in relation
to the Isleworth offences have no recollection of the applicant instructing them that his offending was borne
out of a trafficking situation. Both sets of counsel were experienced in dealing with vulnerable witnesses.
There was, they say, no outward sign or exhibition of vulnerability from the applicant. His solicitor (on the
Isleworth matters) states that he described his younger self as 'ruthless'. He was talkative, articulate and
open to talking about himself. There was nothing to indicate that he was a VOT.

**Submissions on appeal**

26. For the applicant Mr Douglas-Jones submits in summary:

i) The applicant's criminality was extinguished by virtue of his status as a VOT. The applicant was a
vulnerable child and then vulnerable adult when the offences were committed; he had been recruited and
perpetually threatened by gang members and exploited;

ii) In relation to the Isleworth matters, the police had told him to go to his then girlfriend's house. He had
been forced to hold the gun overnight. Given the applicant's vulnerabilities and age, the enduring nature of
the trafficking and the multiple failures of all branches of the state, prosecution was not in the public
interest. The dominant force of compulsion reduced his level of culpability to such an extent that his
prosecution was not in the public interest and an abuse of process;

iii) Further, the Crown and/or police did not effect their operational duties under Article 4, as discussed in
_VCL v United Kingdom_ [2021] 73 EHRR 9 at [148] to [162], and [197] to [199]. The applicant was not
adequately safeguarded, notwithstanding that he had reported being a victim of exploitation to his foster
parents. He had made disclosures of his exploitation by gang members to foster carers, teachers and
social services.

27. In summary, it is submitted that, had the applicant's VOT status and the nexus of the trafficking to the
offending been known, the Crown Prosecution Service (CPS) would or might well not have prosecuted him.
The Article 4 breaches are submitted to be self-standing reasons for finding the criminal proceedings to be
an abuse, or at the very least a factor highly relevant to the prosecutorial decisions. Those decisions
should be given particular scrutiny, given the human rights and international law obligations that are
engaged. But for the State's failings, the Woolwich and Isleworth offences would not have been committed.

28. Mr Johnson for the respondent submits that the applications should be refused.

29. Having reflected carefully on the evidence, and in particular on the contemporaneous social services
records that pre-date the CG Decision, the respondent does not consider that there is a basis to contend
that this court should depart from the conclusions of that decision. The records show that reports about the
applicant being exploited by gangs were made and recorded prior to his arrest for or conviction of criminal
offences.

30. In terms of nexus, as the applicant was a child at the relevant time, it is not necessary to show that the
applicant was compelled to commit the offences. On the basis of the CG Decision, the respondent accepts
that the relevant nexus was present.

31. The third question is whether it would nevertheless have been in the public interest to prosecute. It is
that question which the respondent respectfully suggests is central to the applications. The respondent
submits that the prosecutions were in the public interest, given in particular the gravity of the offending.

**Discussion**

[32. The applicant's convictions sit either side of the entry into force of the Modern Slavery Act 2015 (the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
A t) ( 31 J l 2015) I l ti t th W l i h ff d f d 45 f th A t ( 45)


-----

thus not available to him. In relation to the Isleworth offences, possession of a prohibited firearm is an
offence listed in schedule 4 to the Act; thus, by reason of s. 45(7), a s.45 defence again was not available.
The only offence to which a s.45 defence might have applied was count two, namely possession of
ammunition without a firearm certificate.

33. The relevant law is now well-established: see in particular R v S(G) [2018] EWCA Crim 1824; [2019] 1
[Cr App R 7 at [76]; R v AAD and others [2022] EWCA Crim 106; [2022] 1 Cr App R 19 at [142]; and AFU at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)

[81] to [90] where the principles engaged in both pre- and post-Act cases are summarised. It can be seen
that, in certain circumstances, the convictions of VOTs following either guilty pleas or trial may be unsafe
on grounds of abuse of process: see in particular AFU at [105] to [119].

34. The question is whether, on the present facts, abuse of process is made out such as to render the
applicant's convictions unsafe. In answering it, we proceed on the basis of what is common ground, namely
that there were multiple breaches of Article 4 affecting the applicant both before and after the relevant
offending occurred. In particular, there were multiple occasions when he should have been referred to the
NRM, and was not.

35. However, an appeal against conviction is not a vehicle for 'restoring' international law rights that are
said to have been infringed. Breaches of Article 4 do not, by themselves, render a prosecution unlawful.
The focus must be on the safety of the conviction. See R v LM and others [2010] EWCA Crim 2327 at [31]
[and [32]; R v AAJ [2021] EWCA Crim 1278 at [40]; and R v Thakoraka-Palmer [2023] EWCA Crim 491 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)

[41]. At the end of his oral submissions, Mr Douglas-Jones sought to rely on Article 4 breaches by
reference to the second limb of abuse identified in R v Horseferry Road Magistrates Court ex parte Bennett

[1994] 1 AC 42. However, we do not consider that such reliance adds anything for present purposes to the
existing line of authority as to when the prosecution of a VOT will be an abuse of process, as set out
above.

36. In this case the exercise involves reviewing the respondent's decision to oppose these applications on
the basis of its retrospective review of the evidence and assessment of the public interest in prosecution of
the applicant whom they now know and accept to be a VOT.

37. The context for that review is the important general principle that decisions to prosecute are ordinarily
for the prosecutor (see for example _R (Barons Pub Company Limited)_ _[2013] EWHC 898 (Admin) at_

[51(i)]). As was stated in AFU at [113] and [117], the decision to prosecute is ultimately for the prosecution,
and not the court. Where the prosecution has applied its mind to the relevant questions in accordance with
the applicable CPS guidance, it will not generally be an abuse of process to prosecute unless the decision
to do so is clearly flawed. The court does not intervene merely because it disagrees with the ultimate
decision to prosecute. It will review the decision by reference to rationality and procedural fairness.

38. Although on the present facts we are considering retrospective, hypothetical statements by the
respondent as to whether the prosecutions would have been pursued, those statements are still to be
accorded appropriate deference. We are satisfied that they have been made only after full, fair and careful
consideration by the respondent.

39. There are undoubtedly cases where, even where an applicant has been identified post-conviction as a
VOT and vulnerable, the decision to prosecute would have been the same – see for example R v A [2020]
EWCA Crim 1408 at [68].

40. The gravity of the offending is clearly a material factor. So much is clear from the Code for Crown
Prosecutors in place at the material time for the purpose of addressing the public interest stage of the
prosecutorial decision-making process. It required prosecutors to consider each of the following questions
(in what was a non-exhaustive list):

i) How serious is the offence committed?

ii) What is the level of culpability of the suspect?

iii) What are the circumstances of and the harm caused to the victim?


-----

iv) Was the suspect under the age of 18 at the time of the offence?

v) What is the impact on the community?

vi) Is prosecution a proportionate response?

vii) Do sources of information require protecting?

41. In relation to question iv) above (age), the Code stated that there may be circumstances which meant
that, notwithstanding the fact the suspect is under 18, a prosecution is in the public interest. These
included where the offence committed was serious.

42. The CPS Guidance in force at the time also stated that where a victim of human trafficking had been
compelled to commit the offence, but not to a degree where duress was made out, it would generally not
be in the public interest to prosecute “unless the offence [was] serious” or there were other aggravating
factors.

43. Mr Johnson accepted, rightly in our judgment, that the Article 4 breaches referred to above need to be
considered as relevant factual matrix and part of the prosecutorial decision-making process. The applicant
was a child in a very vulnerable situation interacting with gangs, and there were multiple occasions when
he should have been referred to the NRM, and was not. Mr Johnson was also right, however, to point out
that this was not a case of total inactivity on the part of the social services. Attempts were made to move
the applicant to safety from time to time, for example, and it is not clear that the applicant himself was
always prepared to do so.

44. Mr Johnson explained that the basis of the respondent's position that prosecution of the Isleworth
offences would have been pursued despite these failings is as follows.

45. This was offending of the utmost seriousness. The public interest is exemplified by the mandatory
minimum sentence of 5 years' imprisonment for possession of a prohibited firearm, and by the fact that
Parliament decided that the offence should not be amenable to a s. 45 defence. The applicant sought to
conceal or dispose of the firearm when police attended. The presence of two very young children in the
property with a firearm containing a live round was a highly aggravating feature, whatever the cause of the
applicant's presence in the property. To that there needed to be added the applicant's previous relevant
(Woolwich) offending. Whilst no actual harm was caused, the risk of harm was significant. Against this fell
to be balanced the applicant's age and status as a VOT, which impacted on his level of culpability, set in
the context of the Article 4 failings but also the attempts to seek to help him. The scales were tipped firmly
in favour of prosecution in the public interest. The offending was so serious in nature that only very rarely
would the public interest not favour prosecution.

46. In the respondent's assessment, prosecution would have been entirely proportionate in all the
circumstances.

47. Mr Johnson accepts that the position in respect of prosecution of the Woolwich firearm offence is
weaker. The applicant was much younger at the time. The offending did not involve a prohibited firearm,
and no children were involved. Nevertheless, the offending was still serious, as confirmed by the
photographs of the applicant holding the gun in question. There was thus positive evidence of his physical
contact with the firearm. There was also the presence of other weapons in the bag found to contain the
firearm.

48. There is no proper basis on which to second-guess the respondent's positive assertion that, even if all
the information had been before the CPS when making the decisions to charge the applicant, it would still
have been concluded that both prosecutions were in the public interest.

49. As indicated above, we are satisfied that the respondent has conscientiously revised the decision to
prosecute the applicant in light of the relevant material, and that its position that the prosecution would
have been pursued is not flawed, let alone clearly so. There was a balancing exercise to be carried out.
Even recognising the applicant's age at the time of the offending, and the circumstances underlying it,
there is nothing irrational in the view that it nevertheless remained in the public interest to prosecute. Nor


-----

would the court have stayed the prosecutions had any application to that effect been made. In short, there
was no abuse of process.

**The Bail Act offence**

50. There is one discrete matter that remains for us to address, namely the application to appeal the
applicant's conviction for failure to surrender, for which leave is not required but an extension of time is.
The instigation of that charge was a matter for the court, not the CPS.

51. The detail of the history, taken from the prosecution opening, is as follows. After a period on remand
following the plea and case management hearing in March 2014, the applicant was finally granted bail on
23 May 2014, with a condition of residence at a hostel in Wales. He complied with bail conditions by
returning to court for another hearing on 16 June 2014. It was only after that hearing that he went on the
run. He did not appear back at the hostel in Wales and was at that point in breach of bail conditions. A
warrant was issued in August, upon his failure to attend court that month.

52. He told the author of the relevant pre-sentence report that he had gone on the run whilst on bail
because he hated his placement home in Wales and was isolated. However, in his statement dated 30
March 2022, the applicant states that he was “told to go on the run by the elders, and he was told that this
was best option to sort out the case. I did not know I would be committing another offence by not attending
court. I did what I was told and had no choice and feared them. I was still in debt to them as the firearm
was seized.”

53. Given the chronology set out above, and the contents of the pre-sentence report, the reliability of
applicant's statement as to the circumstances surrounding his failure to surrender is at the very least
questionable. For example, he would have been warned when first granted bail that any breach would be a
separate offence for which he could be separately punished, and again on 16 June 2014. There is in fact
also a social services record dated 11 July 2014 with the following entry:

“[The applicant] was bailed to the LA and placed at the Meadows in Wales. He was not happy at the
placement as it was far from London and could not have contact with friends. He made threats of
breaching his bail so that he could be sent to jail as he wanted to be with other Gang Members…”

This would suggest that the applicant knew full well that breach of his bail conditions would result in
custody.

54. We do not, however, need to resolve these difficulties with the applicant's witness statement. That is
because we are satisfied that, whatever the correct position, the court, fully appraised of all the material
now available, would have proceeded with the prosecution relating to the applicant's failure to surrender.
That failure involved deliberate conduct on the part of the applicant but, more importantly, the charge of
failure to surrender was not to be pursued in isolation, but rather was to run alongside the proceedings for
firearms offending.

**Conclusions**

55. Standing back, despite the significant delay in making these applications, we consider that it is in the
interests of justice that we should grant the necessary extensions of time and leave as necessary. We
would admit fresh evidence but only to this extent:

i) The contemporaneous social services and probation records relating to the appellant;

ii) The CG decision;

iii) The appellant's (unchallenged) witness statement of March 2022 as background to the appeal (despite
our reservations as to its reliability at least in parts).

56. However, we would dismiss the appeals on the merits. For the reasons set out above, the convictions
on both firearms offences and the Bail Act offence are safe. Although the appellant was a VOT at the time
of the offending, and the relevant nexus existed, and although the appellant was not adequately


-----

safeguarded by the relevant authorities, there is no proper basis for going behind the prosecution's positive
assertion that it would have maintained both prosecutions as being in the public interest.

**End of Document**


-----

