# R (AM) v Secretary of State for the Home Department and another [2023]
 EWHC 3034 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Lane

1 December 2023Judgment

**Ms Shu Shin Luh and Ms Grace Capel (instructed by Leigh Day Solicitors) for the Claimant**

**Mr Jack Anderson (instructed by The Government Legal Department) for the First Defendant**

**Mr Hilton Harrop-Griffiths (instructed by LB Barnet) for the Second Defendant**

Hearing dates: 4 and 5 July 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 1 December 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives

(see eg https://www.bailii.org/ew/cases/EWCA/Civ/2022/1169.html).

.............................

MR JUSTICE LANE

**Mr Justice Lane :**

1. In this judgment, the following abbreviations are used:
2. With permission granted by Lang J, the claimant seeks judicial review of what is described as the
decision of the SSHD and/or Barnet to refuse to provide him with back-dated payments in respect of
financial support alleged to have been due to the claimant between 27 April 2018 and 16 December 2019,
as a CVOT and before he consented to remain in the NRM, after he reached the age of majority.

3. On 23 July 2022, the SSHD agreed to make back payments of trafficking support under the MSVCC
from 17th December 2019 to 25 January 2021. In essence, the SSHD disputes the substance of the
challenge on the basis that, between 27 April 2018 and 14 May 2019, the claimant was a child.
Accordingly, he did not fall within the MSVCC. Rather, his needs as a CVOT fell to be met by the second
defendant. So far as concerns a period of 14 May 2019 to 17 December 2019, although the claimant was
by then an adult, he had not consented to the MSVCC despite the fact that the SSHD had proactively
sought to elicit such consent.

4. The claimant also seeks to advance a broader challenge to what he says is the unlawful difference in
the way in which the SSHD's responsibilities under the MSA are discharged in relation to, respectively,
AVOTs and CVOTs. The SSHD contends the claimant does not have standing to bring this broader
challenge.


-----

5. In essence, Barnet argues that it was not at fault in failing to appreciate that the claimant was a CVOT
until it received a letter dated 1 March 2019 (shortly before the claimant reached the age of 18). Even if it
should have had such a reason, Barnet says there is nothing to show that its care for the claimant would
have been (or should have been) any different than what he actually received. In particular, Barnet
appreciated that the claimant was affected by trauma and would benefit from counselling, which it
endeavoured to arrange for him.

6. I am grateful to counsel and those instructing them for the quality of the submissions advanced on 4
and 5 July 2023.

7. I shall deal with the issues of timeliness and standing in due course. It is, however, necessary to
mention two procedural matters at this stage. I granted the claimant permission to rely upon a skeleton
argument that exceeded 25 pages. Given that the claimant's challenge against the first and second
defendants is in each case somewhat distinct, I considered that it was appropriate to do so.

8. Mr Harrop-Griffiths sought to adduce a supplemental bundle of evidence, concerning communications in
late December 2018 and 2019. This was said to be necessary in order to provide the complete factual
picture, in the light of witness evidence filed by the claimant in June 2023. The same applied to a witness
statement of Ms Kate Jeffrey, Barnet's Head of Service in the Corporate Parenting Service.

9. Ms Luh raised objections to the applications. By consent, I admitted the materials de bene esse. Given
the fact that the materials were adduced in response to recent evidence from the claimant and as I
consider it did not put the claimant or his team at any significant procedural disadvantage, I have decided
to accede to Mr Harrop-Griffiths's application and have therefore engaged substantively with this evidence.

**_BACKGROUND_**

10. The claimant was born in Eritrea on 14 May 2001. When he was aged about four, he moved with his
family to Ethiopia. He remained there until he was 15. The claimant says his uncle in Ethiopia was
exploiting him through forced labour and had him arrested and imprisoned when he tried to complain about
that. It seems the claimant at some point formed a decision to come to the United Kingdom. Whilst waiting
for an opportunity to embark for Europe, the claimant was subjected to forced labour by a gang in Libya.

11. Upon arriving in the United Kingdom on 17 April 2018, when he was 16 years old, the claimant claimed
asylum. He was initially accommodated by the London Borough of Camden, pending his transfer to
another local authority via the pan-London rota. That rota is a regional sub-set of the national transfer
scheme, which seeks to distribute responsibility for the care of unaccompanied asylum-seeking children
among local authorities.

12. In accordance with the pan-London rota, Camden completed a UUCR on 18 April 2018, requesting the
claimant's transfer to another local authority and facilitating the sharing of information with the receiving
authority. On the form, Camden answered “yes” to the question of whether the claimant may have been
trafficked. The form was provided to the SSHD the same day.

13. On 23 April 2018, the claimant had an asylum screening interview with the SSHD. The interviewing
officer identified indicators of child trafficking. The claimant was referred to the NRM that day. The claimant
was placed in the care of Barnet on 24 April 2018.

14. Where an UASC is transferred between local authorities pursuant to the pan-London rota, the
receiving authority is provided with an UUCR form. The receiving authority must complete parts D and E of
that form, in order to accept the transfer. The form is also used to request funding from the SSHD for
looking after the unaccompanied child.

15. Barnet says that it does not hold a copy of the form in question. Had Barnet obtained and considered
the form in accordance with the protocol, the claimant says that Barnet would have known early on about
the concerns expressed by Camden that the claimant may have been trafficked.


-----

16. On 27 April 2018, the SSHD made a positive “reasonable grounds” decision that the claimant was a
child victim of trafficking. The SSHD's letter said that the claimant was entitled to a “recovery and reflection
period” together with “safe accommodation and support” for his trafficking-related needs.

17. This letter was not sent to the claimant. The SSHD did, however, send a copy of the decision to the
London Borough of Croydon. That was the London Borough in which the claimant had had his asylum
screening interview. The London Borough of Croydon had, in fact, provided accommodation for the
claimant for one night, following that interview.

18. It appears that by 14 May 2018, the SSHD had become aware that Barnet was looking after the
claimant as his corporate parent. There is, however, no record of the SSHD providing Barnet with a copy of
the reasonable grounds decision or otherwise informing Barnet of the claimant's status in this regard.
Barnet did not ask the SSHD to provide the claimant's relevant immigration documentation.

19. Barnet's first care plan of 27 April 2018 recorded that he had suffered trauma in Libya. Subsequent
assessments in May, August and November 2018 recorded details given by the claimant regarding his
experiences in Ethiopia, Sudan and Libya. The claimant contends that these strongly indicated he was a
CVOT. Barnet, however, did not act on its duty as a First Responder in respect of trafficking issues, so as
to refer the claimant into the NRM. Although the claimant had, in fact, entered the NRM as a result of the
SSHD's actions, Barnet's case is that it was then unaware of the reasonable grounds decision. The
claimant argues that Barnet should have acted on the information that was before it, in order to make an
NRM referral. At the very least, this would have led to Barnet ascertaining the actual position, including the
claimant's entitlement to trafficking-related recovery support, which lies at the heart of this claim.

20. Not only did this not happen; Barnet's successive care plans in respect of the claimant did not refer at
all to his status as a child victim. The claimant says Barnet gave no consideration to the specific support
required by the claimant in order to assist in his recovery from trafficking. That alleged failure continued
into Barnet's pathway planning process for the claimant's leaving care.

21. Throughout his time as a looked after child, in addition to accommodation, the claimant was provided
with generic support that 16 and 17 year olds in care receive under Barnet's financial policy. This
comprised a weekly sum to meet his day-to-day basic living costs, travel, clothing, birthday and festival
allowances. On occasions, the claimant received additional money in order to attend college.

22. According to the claimant's witness statement, he nevertheless struggled to meet his basic day-to-day
needs. Sometimes he says he could not afford 3 meals a day or to purchase the clothes that he needed.
He accordingly had to borrow money from third parties, thus it is said placing him at risk of further
exploitation. Although Barnet's records stated that the claimant needed support to develop budgeting skills,
he did not receive this.

23. The claimant contends that although Barnet's care plans noted his trauma from past experiences, the
nature and extent of his mental ill health did not appear to have been explored. On occasions, police had to
be called, as a result of what is said to be the claimant's level of distress, or because he posed a risk of
harm to himself. Although various referrals were made to charities that provided counselling for asylum
seekers generally, the claimant notes that Barnet does not argue these charities specialised in therapy for
child victims of trafficking. The claimant contends that the real issue at this time was his struggle to access
counselling, due to lack of support. He was at times reluctant to engage because he “did not trust” Barnet
and felt uncomfortable and scared to discuss traumatic memories with a stranger.

24. On 7 December 2018, the SSHD sent the claimant's immigration solicitors a form, seeking his consent
to continue in the NRM once he turned 18. The claimant contends that the relevant guidance did not
require a child victim to give consent in order to remain in the NRM; and that, more fundamentally, the
SSHD cannot lawfully require such consent. In any event, the SSHD did not send the consent form directly
to Barnet. The SSHD made no contact with Barnet until some four months later.

25. On 1 March 2019, the claimant's immigration solicitors wrote to Barnet, enclosing an NRM
questionnaire in order to request information about “the support he is currently receiving as a looked after


-----

child suspected to be a victim of modern slavery”. The solicitor's letter referred to the claimant having had
a positive reasonable grounds decision made on 27 April 2018.

26. Although it is said that Barnet agreed do so, it did not, in the event, provide the requested information
to the claimant or discuss the matter with him.

27. The claimant says that Barnet was, at latest by March 2019, aware of his status as a child victim of
trafficking and his consequent entitlement to trafficking-related recovery needs support. Nevertheless,
Barnet did not conduct any assessment of those needs. Nor did it contact the SSHD in order to discuss the
available recovery support for the claimant. Barnet did not review the claimant's pathway plan to reflect and
address his specific needs, as required by the 2010 Regulations and the Care Leavers (England)
Regulations 2010. It is said that Barnet does not deny this failure.

28. Around 16 April 2019, Barnet apparently obtained the claimant's verbal consent to remain in the NRM.
Barnet did not, however, submit a signed consent form from the claimant until 12 December 2019. Nor did
Barnet inform the SSHD until 17 December 2019. The claimant contends that no explanation is given for
the delay. The SSHD relies on the absence of a signed consent to assert that the claimant was not entitled
to adult victim support from his eighteenth birthday until that point.

29. After the claimant became an adult, on 14 May 2019, Barnet still made no reference to his trafficking
victim status in the pathway plans. It did not assess his needs for trafficking-related recovery support.
Barnet did not give the claimant any advice, information or assistance regarding available NRM support
arrangements. This is said to be not disputed by Barnet.

30. Between 24 September 2019 and 13 October 2020, Barnet was in contact with the SSHD for updates
on the progress of decision making in respect of the claimant's asylum claim. However, Barnet never asked
the SSHD to provide the claimant with adult victim NRM support. For her part, the SSHD did not highlight
to Barnet the claimant's entitlements in this regard. The claimant says that there were ample opportunities
for the SSHD and Barnet to do so. One example given is that on 24 September 2019, the SSHD asked
Barnet to complete a personal circumstances form to inform her asylum decision-making. In January and
March 2020, the SSHD told Barnet that a conclusive grounds decision was pending.

31. On 27 August 2020, the SSHD made a conclusive grounds decision, accepting that the claimant was a
victim of trafficking in respect of forced labour in Ethiopia and Libya. Barnet was informed the following day.
The SSHD did not inform the claimant. This was despite the SSHD's arrangements providing that all
confirmed victims of trafficking have, as of right, 45 days of post-conclusive grounds continued recovery
needs support. The SSHD did not arrange a recovery needs assessment for the claimant. Such an
assessment is intended to ascertain whether the confirmed victim has ongoing recovery needs and, if so,
whether and what continued support is required to meet them.

32. On 12 January 2021, the SSHD recognised the claimant as a refugee. He was granted 5 years' leave
to remain in the United Kingdom, together with access to mainstream benefits.

33. According to his witness statement, the claimant was sleeping rough in a park and also playing football
there. In the course of doing the latter, he met someone who referred him to the charity known as Young
Roots. This organisation provides practical and emotional support to young asylum-seekers and refugees
aged 11 to 25. Young Roots helped the claimant to request support as a VOT, pursuant to the MSVCC. On
25 January 2021, the claimant finally started receiving a weekly sum of £39.60 for financial support, on top
of his mainstream benefits, to assist him to access activities, facilities and other support to meet his
trafficking-related recovery needs. He was also allocated an NRM support worker.

34. On 4 February 2021, Young Roots contacted the SSHD to request back-dated payments for the
claimant. On 25 February 2021, the SSHD refused to do so. However, on 16 February 2022, she
announced that some potential victims of trafficking might not have received correct financial support
payments between 1 April 2015 and 30 November 2019. She therefore said that there would be a
proactive review and that those identified as eligible would receive back-payments. The claimant was not
contacted in this regard.


-----

35. On 13 July 2022, the SSHD reversed her decision of 23 February 2021 and made the provision,
described earlier, in respect of backdated payments to the claimant. It is said, however, that this arose only
after the claimant's present solicitors had engaged in several months of pre-action correspondence.

36. The 13 July 2022 decision agreed to provide the claimant with back-dated payments for the period 17
December 2019 to 24 January 2021, calculated from the date when the claimant 's consent form was
received by the SSHD. As previously mentioned, the SSHD refused back-dated financial support for the
period 14 May 2019 (when the claimant became an adult) to 17 December 2019, in the absence of any
consent given by the claimant to access support. Back-dated financial support was also refused from when
the reasonable grounds decision was made on 27 April 2018, because the claimant was a child at that
point and the SSHD said that Barnet was responsible for the trafficking-related needs of child victims.

37. It is convenient here to set out Barnet's analysis of the factual background. Barnet notes that the
UUCR created by Camden said that there were indications the claimant may have been trafficked. The
only thing said about work, however, was that the claimant had been arrested in 2015 for stealing and
imprisoned for a year and a half. Barnet says that the transfer request was for “out of region”, rather than
within London, and that this might explain why Barnet never received the document or any part of it.

38. During the claimant's time in semi-independent accommodation in Luton, during April and May 2018,
following his placement there by Barnet, the claimant was referred to the Red Cross for therapeutic
support, as well as being provided with at least two hours of keywork support each day. A care plan of April
2018 recorded the claimant as saying that he had suffered “some trauma while in Libya” that he did not feel
that he needed counselling “right now”. He might, however, ask for emotional support in the future to deal
with his experiences if necessary. The record indicates that need was to be met by asking for counselling
support via the claimant's GP or to look for a counselling service that provided support specifically for
unaccompanied minors or those who may have suffered trauma.

39. In a placement plan of May 2018 listing the types of support to be provided to the claimant, it is said
that he was worried he would be arrested if he left his placement, which caused him anxiety. Staff
encouraged the claimant to go out. He said he could not sleep and agreed that counselling might be useful.

40. A Permanency Planning Panel form record of May 2018 stated that there was no information to
suggest that the claimant had been trafficked into the United Kingdom. A placement log of the same month
describes concerning behaviour on the part of the claimant following his age assessment interview. It
recorded that Barnet had originally felt the claimant might be at risk of trafficking but that based on
observations there did not appear to be evidence of this. The claimant was said to have very expensive
taste and that his weekly subsistence did not match this (a matter said to be a common theme in the
documentation).

41. A looked after child review of May 2018 recorded that the claimant had recently agreed to be
supported by the Refugee Council's counselling service, which would also help him with other matters. He
presented as being traumatised and there was a great deal of concern about his emotional wellbeing.
There was reference to him being referred to in-clinical psychologists.

42. A needs assessment of May 2018 did not refer to the claimant being forced to work, whether by his
uncle or in Libya or Sudan. It did, however, refer to trauma in Libya, in that he said he had been attacked
and held at ransom while his captors demanded money.

43. The claimant reported that he had not been trafficked into the United Kingdom and was not under
threat by anybody in the United Kingdom or abroad. The writer recommended that if there was any
information that the claimant was being exploited, then the necessary policies and procedures should be
followed to ensure that he was safe. The claimant had been advised to seek counselling but he had said
that he did not feel that he wished to take that up at that time.

44. The age assessment record of August 2018 describes the claimant having suffered trauma on his
journey into Europe and that he was attacked and was held for ransom in Libya. He was beaten and forced
to undertake household chores by his uncle. The claimant worked whist he was in Sudan, in order to pay
for his journey but was not given any wage


-----

45. A placement plan of September 2018 recorded that the claimant said he could not sleep as a result of
the stress he encountered thinking his journey to the United Kingdom and the friends he had lost. The
claimant agreed that counselling might be useful and a GP appointment should be made as soon as
possible.

46. A needs assessment of October 2018 records the claimant saying that he had been beaten by officials
in France, as well as referring to friends who had died during the journey. The writer stated that they had
made a referral to the Refugee Council's therapeutic counselling programme for unaccompanied asylum
seekers. This placement also had on-site support workers able to offer practical and emotional support. It
was stated that the writer considered it crucial that the claimant accessed medical support and counselling.

47. A looked after child review of October 2018 again described the claimant saying that he had witnessed
traumatic events on his journey to the United Kingdom. A referral to the GP about the claimant's mental
health was outstanding. This appears to be because there was a problem registering with the GP because
the claimant had lost his asylum registration card. In the meantime, he had been referred to the Refugee
Council for counselling support. He was due to see a psychotherapist that week.

48. A second age assessment of November 2018 recorded the claimant's harrowing journey and how he
was arrested and jailed for a crime his uncle had falsely accused him of. Instead of sending the claimant to
school, the uncle made him work in the uncle's recycling company. He had felt abused and unfairly treated
by his uncle. The claimant obtained a job in Sudan serving food to drivers. He did not receive payment but
his employer saved the money for the claimant's journey to Italy. Between Libya and Sudan there was a
vehicle accident which led to some people being killed. People were also shot and the claimant was
kidnapped. Eventually he was allowed to proceed from Libya on his journey to Europe.

49. The writer of the age assessment stated that they had considered whether the claimant had been
trafficked into the United Kingdom but had concluded that the claimant had decided on his own to come to
this country and had not been compelled to do so. The writer then referred to the claimant's experiences in
Sudan and Libya, concluding that the claimant “appears to have engaged in paid work and paid his way to
… Europe and was not enslaved or trafficked”.

50. A looked after child review of December 2018 noted that the claimant had been allocated a
psychotherapist by the Refugee Council, who was due to see him that week. A further document noted that
the claimant said he had not refused to go to counselling the day before but had not known where he
should go. This record noted, however, that the claimant had missed three appointments. The social
worker would try to get the claimant another appointment “and he needs to be taken”.

51. The pathway plan assessment of December 2018 referred to counselling sessions arranged by the
Refugee Council.

52. On 1 March 2019, Davjunnel Solicitors wrote to Barnet on behalf of the claimant. This stated that the
claimant had been the subject of a positive reasonable grounds decision made on 24 (in fact 27) April
2018, which showed the claimant was a possible victim of modern slavery in Libya. The letter asked, in
the light of this, for a report from Barnet detailing the claimant's well-being when he first came into the care
of the local authority and his current well-being in terms of the current support the claimant was receiving
as a looked after child suspected to be a victim of modern slavery. The letter asked if the claimant had
been referred for professional intervention by a general practitioner, psychologist or for counselling for
post-traumatic stress disorder and, if not, why not. The letter attached two documents. One was a consent
form in respect of a person who had been identified as a potential victim of modern slavery. The second
document was a letter from the SSHD to the claimant regarding him now being 18 years old and stating
that his consent was required under the NRM process.

53. A review of April 2019 explained that the claimant's care plan provided for him to stay in his current
placement until he was 18 and that after that it had been suggested that he should remain in semiindependent accommodation as the claimant needed a considerable amount of support in helping him to
develop his independence skills. The record referred to the claimant being on a “waiting list” for
counselling.


-----

54. A pathway plan of July 2019 noted that a referral had been made to Freedom From Torture for
counselling but this had not been accepted. Freedom From Torture said that they were unable to offer an
assessment due to limited capacity. Instead, they suggested a referral to the local Child and Adolescent
Mental Health Services, which is an NHS service.

55. A case note of December 2019 noted that Harringay CAMHS had assessed the claimant on 31
January 2019 and found he did not have any mental health issues.

56. A pathway plan of January 2020 noted that the claimant had been offered therapeutic support through
a counselling service called Terapia. The claimant had, however, declined this.

57. A case record of June 2020 recorded that Barnet continued to worry about the emotional well-being of
the claimant, noting that he had previously been offered therapeutic support but had not engaged. His
personal advisor was to encourage the claimant to speak with his GP.

58.  A pathway plan of August 2020 noted it was concerning that the claimant had not engaged fully with
the completion of the plan. It was understood that the claimant was struggling emotionally with the
uncertainty regarding his asylum claim. It noted that he had declined therapeutic support but Barnet was
encouraging discussions to continue about this.

59. A case note of November 2020 refers to a proposed referral to Thrive, an organisation that promotes
mental well-being in young people. The claimant was, however, adamant that he did not want any referrals
to any agency or health service until he “had his status (i.e. had leave to remain )”. The claimant was
working with the Human Torture Group, who was supporting him and the claimant said that they would
help him with “everything”.

60. A pathway plan of April 2021 recorded that the claimant did not participate in the exercise. He did not
want any contact with his personal advisor or “Onwards & Upwards”.

61. A pathway plan of November 2021 recorded that the claimant appeared to have high anxiety. It was
thought beneficial for him to access counselling sessions but the claimant continued to refuse these,
saying he had all the support he needed from his advocate at Action for Children, and from a case worker
from Young Roots.

62. The NRM conclusive grounds decision on 27 August 2020 was that the claimant had been subjected
to forced labour in Ethiopia and Libya. Barnet stated that all that it knew about the NRM referral was what
had been contained in the letter from Davjunnel Solicitors of 1 March 2019.

|AVOT|Adult Victim of Trafficking|
|---|---|
|Barnet|London Borough of Barnet (the Second Defendant)|
|CA 1989|Children Act 1989|
|CA 2004|Children Act 2004|
|Camden|London Borough of Camden|
|CAG|Victims of Modern Slavery Competent Authority Guidance 2014-2019 (issued under section 49 of the MSA)|
|CVOT|Child Victim of Trafficking|
|ECAT|Council of Europe Convention on Action Against Trafficking In Human Beings|
|ECHR|Convention for the Protection of Human Rights and Fundamental Freedoms|
|Explanatory Report|The Explanatory Report to ECAT|
|ICTG|Independent Child Trafficking Guardians (for which provision is made by section 48 of the MSA|
|MSA|Modern Slavery Act 2015|
|MSAG|Modern Slavery Act Guidance (made under section 49 of the MSA)|


-----

|MSVCC|Modern Slavery Victim Care Contract|
|---|---|
|NRM|National Referral Mechanism (the process for identifying VOTs)|
|PVOT|Potential Victim of Trafficking|
|RNA|Recovery Needs Assessment|
|Safeguarding Children|The Safeguarding Children who may have been trafficked practice guidance (2011)|
|SSHD|Secretary of State for the Home Department (the First Defendant)|
|UASC|Unaccompanied Asylum-Seeking Child|
|Unaccompanied and Trafficked Children Guidance|The care of unaccompanied migrant children and child victims of trafficking guidance (2017) (made under section 7 of the local authority Services Act 1970)|
|UUCR|Unique Unaccompanied Child Record|
|VOT|Victim of Modern Slavery|
|Working Together|Working Together to safeguard children (2006-2018) (issued under section 7 of the local authority Services Act 1970 and section 11(4) of the Children Act 2004)|
|2010 Regulations|Care Planning, Placement and Case Review (England) Regulations 2010 (amended 2014) (made under the Children Act 1998)|


**_LEGAL AND POLICY FRAMEWORKS_**

63. I turn to the legal and policy frameworks. These are extensive.

64. ECAT was signed by the United Kingdom on 23 March 2007 and ratified on 17 December 2008, with
effect from 1 April 2009.

65. Article 10 requires signatory States to adopt arrangements for victim identification. By article 12(1),
States are required to ensure such measures as may be necessary “to assist victims in their physical,
psychological and social recovery”. This includes at least:

“(a) standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

(b) access to emergency medical treatment;

…

(d) counselling and information, in particular as regards their legal rights and services available to them... ”.

66. Paragraph 152 of the Explanatory Report to the ECAT states that the obligation under article 12 (1)(a)
“is to provide victims with standards of living capable of ensuring their subsistence”. An example was given
of providing appropriate and secure accommodation, as well as psychological and material assistance, as
being particularly relevant to assisting victims of trafficking.

67. Paragraph 156 of the Explanatory Report reads as follows:
“156. Psychological assistance is needed to help the victim overcome the trauma they have been through
and get back to reintegration into society. The Convention provides for material assistance because many
victims, once out of the traffickers' hands, are totally without material resources. The material assistance
provided for in sub-paragraph (a) is intended to give them the means of subsistence. Material assistance is
distinguished from financial aid in that it may take the form of aid in kind (for example, food or clothing) and
is not necessarily in the form of money.”

68. Article 12(7) requires each party to “ensure that services are provided on a consensual and informed
basis…”. As to this, paragraph 171 of the Explanatory Report says that “it is indeed essential that victims
agree to the services provided to them ... ”.

69. Article 13(1) requires States to provide a “recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim” During that time the


-----

person is not to be expelled. Article 13(2) provides that those to whom article 13(1) applies shall be entitled
to the measures contained in article 12(1) and (2).

70. ECAT is an unincorporated treaty. It therefore does not have direct effect in United Kingdom law. The
SSHD, however, has a policy to give effect to articles 10 to 14 of ECAT. It is in this way that ECAT is
justiciable: EOG v SSHD [2022] 3 WLR 353.

71. Article 4 of the ECHR prohibits slavery, servitude and forced labour. This includes trafficking and
**_modern slavery._**

72. Section 49 of the MSA (as in force at the relevant times) provided as follows:
“(1) The Secretary of State must issue guidance to such public authorities and other persons as the
Secretary of State considers appropriate about
(a) the sorts of things which indicate that a person may be a victim of slavery or human trafficking;

(b) arrangements for providing assistance and support to persons who there are reasonable grounds to
believe may be victims of slavery or human trafficking;

(c) arrangements for determining whether there are reasonable grounds to believe that a person may be a
victim of slavery or human trafficking”.

73. Citing Wilson v The First County Trust [2004] 1 AC 816for the proposition that Ministerial statements in
Parliament can be used as background material to explain the Government's decision and its policy
objectives, the claimant refers to the Minister's statement in the House of Commons, during the passage of
the Bill for the MSA, that what became section 49 was “an important provision to ensure a consistent and
standardised approach to identifying potential victims and ensuring that they get the right support and
assistance to move on with their lives”.

74. At the Bill's Committee stage, the Minister also said this about the provision:
“The Guidance will set out the assistance and support on offer to victims through the government-funded
adult victim care contract, which is currently operated by the Salvation Army, and through local authority
safeguarding and child protection arrangements for children”.

75. Reference also needs to be made to section 48. This provides for the SSHD to make arrangements for
what are now known as ICTGs. Although section 48 is not substantively in force, ICTGs have been
introduced on a non-statutory, pilot basis. ICTGs must provide for the well-being of the child in question
and act in the child's best interest. They must also assist the child in obtaining support. ICTGs are now
available in two-thirds of local authority areas in England. At the relevant time when the claimant was a
child, ICTGs were not available in Barnet.

76. Before the publication of the MSAG, the SSHD had in 2014 published the CAG, which went through
several iterations. Version 6, published on 1 April 2019, defined First Responders as (inter alia) the Home
Office, local authorities, the Salvation Army and the Refugee Council. PVOTs are entitled to a minimum of
45 days supported recovery and reflection period. In England, requests for support must be made to the
Salvation Army. For children, requests for support must be made to the local authority children's services.
The CAG provided for the competent authority to refer child PVOTs to the relevant local authority's
children services, if they had not already been referred by the First Responder. Page 23 of the CAG noted,
without distinguishing between AVOTs and CVOTs, that potential victims are entitled to (inter alia)
counselling and information (particularly regarding their legal rights and the services available to them);
and to access to education for children.

77. The CAG did not provide detailed information about support for AVOTS, which was governed by the
Victim Care Contract, entered into between the SSHD and the Salvation Army. Clause 8.2 in Schedule 2
required the Salvation Army to provide accommodation to those not already accommodated, together with
financial support. The contract did not make express provision for trafficking payments to be reduced,
where persons were in receipt of mainstream benefits. In R(MD) v SSHD [2022] EWCA Civ 366, the Court


-----

of Appeal accepted that this was not because of a deliberate policy but as a result of error. The SSHD has
subsequently amended a policy to address that anomaly.

78. On 24 March 2020, the SSHD published the MSAG, pursuant to her duty under section 49. By that
time, the claimant was an adult. The MSAG has since been revised on a number of occasions. As of May
2023, version 3.2 is in place. At the hearing, attention focussed on Version 1.02 (published in April 2020)
and the following references are to that version.

79. Paragraph 1.8 states that MSAG is aimed, amongst other things, at staff within public authorities who
may encounter PVOTs and/or who are involved in supporting victims. Paragraph 3.2 provides that First
Responders, defined so as to include local authorities, need to know and understand signs which may
indicate that the person is a VOT in order to decide whether to refer a case to the NRM.

80. Paragraph 5.2 provides that consent is required to refer an adult into the NRM and that being
recognised as a PVOT may allow the individual to access support. Again, where a child victim is identified,
the First Responder should immediately contact the local authority children's services. Paragraph 5.5 notes
that support for children is provided through the local authority.

81. Chapter 8 concerns support for AVOTs. Paragraph 8.1 notes that support for adults who are PVOTs or
VOTS is provided through a mixture of mainstream and specialist support. This may be through a range of
organisations, which include local authorities.

82. Subsequent paragraphs in this chapter make provision for risk assessments and needs-based
assessments.

83. Annex F details the support available to adults who are VOTs or PVOTs. Amongst other matters,
provision is made for an “essential living rate” and for a “recovery rate”. The recovery rate can be used
flexibly, in accessing health, fitness or wellness classes, to help fund additional weekly transport and
communication costs or flexibly towards other recovery related costs.

84. The claimant draws attention to provisions in Annex F, concerning the accommodation of AVOTs. The
claimant highlights that paragraph 15.12 refers to such persons usually continuing to be supported through
asylum accommodation, unless they have specific needs over and above asylum accommodation
provision that require, for example, a safehouse accommodation. The claimant also draws attention to the
financial support provisions and the stated reasons for additional payments. The claimant's essential point
is that there is no difference, in this regard, between AVOTs and CVOTs. A child may require additional
financial support to deal with trafficking-induced problems, just as an adult may.

85. The SSHD draws attention to Annex G. This details the support available to children in England and
Wales. Paragraph 16.1 provides that support provided by local authorities to child victims is not dependent
on a child remaining in the NRM. “As such, children will continue to be supported in their existing situation
by local authorities under their statutory duty to safeguard and promote the welfare of looked after children
in their area”.

86. Paragraph 16.4 provides that where the CVOT's standard of living leads to concern that they are in
need of help, they should be referred to children's social care who, following an assessment, may decide
support is necessary.

87. Paragraph 16.5 provides that any unaccompanied child must be accommodated and will become
“looked after” 24 hours later, requiring the authority to provide them with care, accommodation and support
(including making arrangements for education and healthcare) in the same way as any other child who is in
the authority's care.

88. Paragraphs 16.6 and 16.7 summarise care planning, whilst paragraph 16.8 notes that local authorities
are responsible for making a health assessment of CVOTs who are looked after children, including in
relation to the child's physical, emotional and mental health.

89. Paragraph 16.10 states that for child victims, Child and Adolescent Mental Health Services will provide
child or adolescent- specific services. This operates in a similar way to adult mental health services but has


-----

access to a different group of professionals. Those services focus more on psychological and
pharmacological therapies. GPs and social workers will be able to facilitate access to counselling.

90. Paragraph 16.16 provides that all children should receive the same access to educational provision,
regardless of their immigration status. Paragraph 16.17 states that under section 22 of the CA 1989, all
local authorities in England are under a duty to promote the educational achievement of the children they
look after, wherever they are placed. The claimant queries, in this regard, the absence of any reference to
CVOTs who are not looked after children.

91. Section 17(1) of the CA 1989 imposes a general duty on local authorities to “safeguard and promote
the welfare of children within their area who are in need... by providing a range and level of services
appropriate to those children's needs”. Section 17(5) empowers local authorities to make arrangements
with others to provide services on their behalf. Section 17(6) empowers the local authority to provide
services, including accommodation or the giving of assistance in kind or cash.

92. Section 17(10) defines that a child shall be taken to be in need if, inter alia:
“(a) he is unlikely to achieve or maintain or to have the opportunity of achieving or maintaining, a
reasonable standard of heath or development without the provision for him of services by a local authority
under this Part; or

(b) his health or development is likely to be significantly impaired, or further impaired, without the provision
for him of such services”.

93. As was pointed out by the majority of the House of Lords in R(G) v Barnet LBC, [2002] AC 208, the
fact that section 17 is expressed as a general duty does not mean it is an empty one. On the contrary, it
carries an implied duty to assess: paragraphs 77, 110 and 117 of the judgments. An assessment, in turn,
requires a “diligent inquiry”: R(O v London Borough of Lambeth) [2016] EWHC 937 (Admin), paragraph 17.
The duty must be exercised having regard to relevant guidance and in accordance with public law
principles. In particular, a failure to assess or conduct a lawful assessment may be subject to judicial
review.

94. Section 20 of the CA 1989 imposes a specific duty to provide accommodation to children for whom,
inter alia, no person has parental responsibility or there is such a person but they are prevented from
providing the child with suitable accommodation. Where a child is provided with such accommodation for
more than 24 hours, they become a “looked after child”.

95. Section 22 imposes a specific duty on a local authority to “safeguard and promote” the welfare of a
looked after child.

96. Section 22B requires the local authority to maintain a child they are looking after in other respects
apart from the provision of accommodation. Section 22C sets out the ways in which a looked after child is
to be accommodated and maintained. For these purposes, the 2010 Regulations have been made.

97. Section 23C provides that, on becoming an adult, the “former relevant child” begins to be owed duties
under that section. These include the provision of material support such as accommodation and financial
support, to the extent that the former child's welfare requires this.

98. Section 11 of the CA 2004 imposes a duty on, inter alia, local authorities in England to ensure that
their functions are discharged having regard to the need to safeguard and promote the welfare of children.

99. Section 1 of the Children and Social Work Act 2017 provides that, in the case of, inter alia, looked after
children and of young people, local authorities in England must, in carrying out any of their functions in
relation to such children and young people, have regard to the best interests of such children/young people
and promote their physical and mental health and well-being.

100. Regulation 4(1) of the 2010 Regulations provides that where a child is not in the care of the authority
(by reason of a care order under section 31 of the CA 1989) and does not already have a care plan, the
authority must “assess his needs for services to achieve or maintain a reasonable standard of health or
development” and prepare such a plan.


-----

101. Regulation 5(1) provides that the care plan must include a record of certain information. Regulation
5(1)(f) requires there to be a record of the fact, if the child is:
“(f)(i) a victim, or there is reason to believe [CVOT] may be a victim or reason to believe [CVOT] may be a
victim, of trafficking in human beings within the meaning of the Council of Europe Convention on Action
against Trafficking in Human Beings…”.

102. Regulation 9 requires there to be a placement plan.

103. Regulation 32(1) provides that a local authority must review a child's case in accordance with Part 6
of the Regulations. By regulation 33(1), it must do so within 20 working days of the child becoming looked
after and, by regulation 33(2), the second review must be carried out not more than three months after the
first; and subsequent reviews at intervals of no more than six months. Regulation 33(3) sets out exceptions
to this timetabling, which are immaterial for our purposes.

104. Regulation 42 provides for an assessment of a child's needs to be completed not more than three
months after he turns 16 or becomes an “eligible child” after that age, with a view to preparing a “pathway
plan” for the child. The local authority must take into account, amongst other things, any needs the child
has as a result of having regulation 5(1)(f) status.

105. Regulation 43 requires the pathway plan to include, in particular, the child's care plan and the
information referred to in Schedule 8. In respect of paragraphs 2 to 10 of Schedule 8, the pathway plan
must amongst other things set out the manner in which the local authority proposes to meet the needs of
the child.

106. The claimant also alleges a breach of regulation 7 of the Care Leavers (England) Regulations 2010.
These provide for regular reviews of pathway plans. They have nothing discrete to say about trafficking,
although trafficking issues plainly fall within their ambit.

107.  In 2011, the Department for Education and the Home Office published the Safeguarding Children
guidance. This was non-statutory. Paragraph 4.5 provided that where a child had been referred to the local
authority because of trafficking concerns, children's social care should decide within 24 hours whether to
undertake an initial assessment to determine whether the child is child in need and, where appropriate,
following a strategic discussion, initiate a section 47 enquiry. The claimant notes that, although the
Safeguarding Children guidance described, at paragraph 6.12, the reflection and recovery period to which
CVOTs are entitled under the NRM, it did so only by reference to the SSHD's tasks during that period. It
did not refer to obligations to arrange specific recovery needs support to child victims during the period, or
who was responsible for doing so.

108. The Working Together guidance, first published in 2015 and revised in 2018, provided that special
provision could be put in place to support dialogue with children, who are victims of **_modern slavery_**
and/or trafficking (paragraph 14). It was also stated in chapter 1 that practitioners should, in particular, be
alert to the potential need for early help for a child who is at risk of **_modern slavery, trafficking or_**
exploitation. The claimant observes that no reference was made to the NRM or other arrangements to
discharge specific ECAT obligations to meet a child's recovery needs.

109. The claimant submits that the Safeguarding Children and Working Together sets of guidance are the
only forms of guidance to touch on the position of CVOTs who are not in local authority care. The claimant
says that what is said in the guidance is sparse and does not address the state-specific support obligations
or arrangements towards that cohort of children during the reflection and recovery period.

**_WITNESS EVIDENCE_**

110. In his first witness statement, the claimant says that he still thinks about his past experiences but
does not want to talk about them. He did not know that he had been referred into the NRM in April 2018,
nor that a positive reasonable grounds decision had been made in that regard on 27 April 2018. At
paragraph 10 of his first statement, the claimant says that it was only later that he found out he had been
identified as a victim of trafficking, when he was told this by his immigration solicitors:


-----

“They also told me that being a victim of trafficking might be a basis on which I could be allowed to stay in
the UK separately from my claim for asylum. They did not explain to me the rights to support I had as a
victim of trafficking. I only found out much later (around January 2021) from those supporting me at Young
Roots that being a victim of trafficking entitled me to certain financial support that would help me to access
specific services and activities that could help me deal with my past trafficking experiences. By then I was
an adult and had been in the UK for three years…”.

111. At paragraph 21 of this statement, the claimant said that Barnet's officials “would either tell me I had
to wait or that I had to ask someone else for help so eventually I just stopped asking”. At paragraph 22 he
said that, at the relevant times, he did not realise that as he had received a positive reasonable grounds
decision, he “was supposed to be receiving support specifically to help me deal with that experience. I got
nothing of that sort”.

112. After the claimant turned 18, he was moved to accommodation that he considered to be unsuitable.
He therefore started sleeping rough in Finsbury Park. It was here that he met an individual who introduced
him to Young Roots.

113. On the subject of the care plan and pathway plan arrangements, the claimant says that, although he
remembers discussing these with his social workers, “it felt like an artificial exercise … because social
services would discuss with me generally if I needed help but if I made specific requests for practical
assistance with certain things I was often told that I should ask the keyworker… or figure it out myself, I
was rarely able to get the support I needed…”.

114. The claimant remembers being asked whether he wanted to do any activities like going to a gym but
when he said yes, “social services told me that I was already getting money and that I could use this to join
a football club or gym myself”. They never gave him any practical help as to how to join. When he would try
to ask for things from social services, “the answer I would get would often be 'you didn't have that in your
country'. The way people from social services spoke to me was so degrading.” Young Roots were the first
people in the United Kingdom that the claimant felt he could trust.

115. In his second witness statement, filed after that of Ritah Jackson (see below), the claimant describes
what he considers to be negative interactions with the staff of Barnet, including one individual who,
according to the claimant, grabbed his arm and pushed him against a wall. Over time, the claimant felt less
and less able to trust Barnet and did not feel able to engage with them. He was reluctant to ask for help.
Initially, the claimant said he could not trust Barnet because he felt that they were just trying to dispute his
age and get him out of London so that he would not be their problem anymore. The claimant does not
recall Barnet asking him questions about trafficking: “When [Barnet] asked me questions to do with
anything about my immigration case, their questions focused on my age assessment…”. The claimant felt
that Barnet “were just trying to get me assessed as over 18 so they could move me out of their care. I was
16 and a half of the time”.

116. Dealing with the occasions on which he was recorded as refusing to attend counselling, the claimant
says that “the main reason is that I did not trust [Barnet] - trust had been broken between us”. In his first
statement, the claimant had said that he was unaware that social services had tried to refer him to multiple
different organisations for therapy. He was not told what this would involve and what needs it might
address. Accordingly, the claimant felt stressed at the prospect of having to go, did not feel that it would
help him and did not really understand how it could.

117. The claimant has filed two statements by Laura Durán. She is Head of Policy, Advocacy and
Research at ECPAT UK, which is a member of a global network of children's rights organisations. ECPAT
UK was established in 1994 to campaign against the sexual exploitation of children in tourism. It is the
United Kingdom's only children's rights organisation dedicated specifically to the protection of children from
child trafficking and modern slavery in all its forms. It regularly participates in stakeholder groups, which
advise the Home Office on policy and practice in these areas.

118. In her first statement, Ms Durán emphasises that even after being identified as victims of trafficking,
children often remain mistrustful of public authorities and adults. This mistrust is one of the main barriers to


-----

child victims engaging with support services. She therefore says it is important for professionals working
with child victims to actively work on building trust.

119. CVOTs also have other worries; in particular, their immigration status. It is therefore very common for
CVOTs who need leave to remain not to be able to engage at all with mental health support offered to
them until their asylum or immigration determination process has concluded and they feel that the limbo
and uncertainty of their situation have been resolved. Even then, however, CVOTs may require a period of
stabilisation before they feel ready to engage in mental health support.

120. Ms Durán states that her organisation has over many years expressed concerns to government
about the gaps and inadequacy of support for CVOTs. Most recently, they set out their concerns in a report
published in August 2020. They have publicly called for substantial reforms to the arrangements under the
NRM as it applies to child victims. They consider there is a lack of specific, targeted trafficking-related
support for children, which means that many CVOTs do not actually benefit from support available to them
during the “recovery and reflection” period.

121. ECPAT UK was actively involved with the government during the passage of the Bill for the MSA. In
particular, they campaigned for a specific duty to be included in the MSA, stating in terms that the
protection, assistance and support provided to trafficked, enslaved or exploited children “shall be at least
equivalent to the protection, assistance and support provided to adults”, save where other legislation
provided greater protection. Ms Durán says that “unfortunately, that provision was not ultimately reflected
in the legislation”. Instead, what is now section 49 of the MSA was put forward, alongside a commitment
from the SSHD that guidance would form the framework for ensuring a consistent standard of support for
all victims. When the statutory guidance was produced, some 5 years later, it did not, however, according
to Ms Durán, reflect that commitment. In particular, Working Together, while stating that CVOTs may
require support, does not identify what may be trafficking-related needs. Working Together does not
address the position of those CVOTs who are British or otherwise have leave to remain, and who are not in
the care of a local authority.

122. Ms Durán accepts that the Care Planning and Care Leavers (Amendment) Regulations recognised
there was a need for some focus and attention to be directed towards the specific needs of those children
in care who had experienced trafficking or who were separated from their family. As a result of the
amendments, a local authority is required to record in a care plan whether a child is or may be a VOT
and/or a UASC. Ms Durán regards these amendments as an improvement but says they do not impose
any specific obligation to provide trafficking-related recovery needs or support or explain what those needs
may be. Again, the amendments do not cover the position of those not in the care of a local authority.

123. Ms Durán says that there is often only limited recognition by a local authority of the additional risk
factors that CVOTs face due to their enhanced vulnerability, such as going missing and being re-trafficked.

124. In her view, the level of subsistence allowance to meet basic needs given by a local authority can
vary, depending upon the authority concerned, although it is usually based on the child's immigration status
and where they are in the process of transitioning to adulthood. The weekly allowance is not usually
determined on the basis of specific needs. CVOTs do not generally receive specific trafficking-related
support such as targeted counselling or other forms of youth support from their local authority.

125. Penny Clarke is policy manager in the Victims Support Policy Team of the Home Office. She states
that the fact that the Home Office is the government department with overall responsibility for **_modern_**
**_slavery policy does not mean it takes on responsibility in its own right for all aspects of the provision of_**
support victims of **_modern slavery, whether adults or children. The division of responsibility between_**
central and local government as regards CVOTs has been in place since the Home Office inherited full
responsibility for supporting AVOTs from the Ministry of Justice in 2014. At that point, provision of support
for CVOTs had already been separated from the adult provision and local authorities were provided with
support to potential CVOTs in their respective areas.

126. Ms Clarke says that local authority responsibility to support and promote the welfare of children in
their area extends to those who are exploited before coming to the United Kingdom or who are en route to


-----

it. Thus, for example, if a child is identified as a potential CVOT on arrival, it would be for the local authority
in which they were accommodated to assess them as a potential CVOT and provide appropriate
safeguarding/support. Similarly, if a child were identified as such after entering the United Kingdom and
being referred to the NRM, then that referral would also be flagged to the local authority where they were
living. It would be for that local authority to do a Child in Need assessment at that point.

127. MSAG, Annex G, which sets out the type of support available to CVOTs, makes it clear that local
authorities are responsible for providing the relevant care. Unlike for adults, provision of support for CVOTs
is not dependent on them remaining in the NRM or on them receiving a positive reasonable
ground/conclusive grounds decision. The local authority should assess and support/safeguard a child
independently of their status within the NRM and as soon as they are referred, the initial safeguarding
assessment having to take place within 24 hours. Because support for children provided by local
authorities is not directly linked to the NRM referral, if a local authority assesses the child has needs, it is
for the authority to decide how the child should be supported and for how long. If a child receives a
negative reasonable grounds decision but the local authority still feels the child has needs, they can
continue to support the child for as long as that is considered appropriate. Annex G does not provide the
same level of detail around the support of a child victim, as is given in the guidance for adult victims. Ms
Clarke says this is due to the fact that local authorities, along with their wider safeguarding partners, are
able to shape the provision around the structure of wider local processes/provision. As there is already a
framework in place for assessing and supporting the needs of children, in contrast to adults, she says it
makes sense that CVOTs sit within the framework as opposed to creating a separate framework for this
(and potentially other) types of victims.

128. Ritah Jackson is team manager with Barnet's Leaving Care Service. She describes the placement of
the claimant with Barnet. As far as Ms Jackson can see, the claimant received all of his statutory financial
allowances, including help with travel to college. Although there were isolated times when he did not
receive his subsistence in a timely manner, when staff became aware of this, they ensured that it was
immediately rectified. They also offered other solutions to ensure that the claimant was not disadvantaged
as a result.

129. When the claimant's claimed age was doubted following an age assessment on the 16 May 2018, the
claimant became very angry, trashed his bedroom and threatened a member of staff. The police had to be
called. On 24 September 2018, the claimant came home smelling of alcohol and appeared to be injured.
He refused to go to hospital for his injury. When next visited, the claimant complained he did not have
money for food and that the placement did not give him such funds. On checking his cupboards, the official
noted that the claimant had enough food.

130. Ms Jackson's statement makes reference to other incidents, such as the claimant complaining that
his room was too small and that a washing machine did not work. In July 2019, when moved to temporary
accommodation, the claimant said he was unhappy with it because it was a one bedroom studio and did
not meet his requirements. Other passages of the witness statement are in a similar vein. In particular, it is
noted that at paragraph 67 of the statement, Ms Jackson said that on 19 November 2020, the claimant was
recorded as not attending college due to lack of funds for travel. It was agreed that Ms Costi (a colleague
of Ms Jackson) would ask for continued travel money for him to attend college. She also suggested a
referral to THRIVE, a counselling service. The claimant, however, advised he did not want any referrals to
any agencies until he was “legal”; and that he was being supported by a human torture group, which was
all the help he needed. The claimant was asked to provide details of this so that Barnet could liaise with
this group in order to support him. In December 2020, Ms Costi was further advised by the claimant that he
did not want to be called by her until he was “legal” and that he “would call when he was ready”. When
emailed out of concern for him, he replied that he was quite disgusted with life and wanted to be left alone.
He did not respond to further inquiries about what support he required.

131. On 25 January 2021, the claimant's solicitors sent Barnet confirmation that the claimant had been
given refugee status. Ms Costi made contact with the claimant “who wanted housing immediately”. There
followed exchanges in which the claimant expressed dissatisfaction with the accommodation he was being
offered


-----

132. Ms Durán filed a second witness statement, concerning Barnet's assertion that it had performed its
operational duty in providing or arranging to provide or offering to provide such assistance as the claimant
needed, arising from him having been trafficked, and that it constantly tried to arrange for the claimant to
have counselling but to no avail because he did not want it. Ms Durán suggests that all this was dependent
on Barnet recognising that the claimant was a CVOT and considering what needs he might have as a
result. If Barnet did not and could not know that the claimant had been trafficked, it was not clear to Ms
Durán how Barnet could have considered his trafficking-specific needs for assistance and recovery. Local
authorities often do not recognise the need to identify and address matters arising from trafficking
experiences separately. Instead, they provide generic support to meet what they consider to be a child's
basic needs, with no differentiation between CVOTs and other unaccompanied asylum seekers. It is critical
to a child's recovery from trafficking that the support they receive is directed to their needs arriving
specifically from those experiences. The trauma suffered _en route by the claimant can only be properly_
recognised and addressed if it is considered in the context of his experience of exploitation.

133. Annex F to the MSAG refers to the provision of “further financial support, by directly funding
additional support services related to assisting individuals with their recovery from their **_modern slavery_**
experience”. Thus, the MSAG recognises that an AVOT's recovery needs require the availability of
additional funding to meet those needs by means of a “recovery rate”, in addition to a “essential living rate”.
This clearly reflects the need to make provision for the costs of meeting recovery needs over and above
provision for basic needs.

134. According to Ms Durán, it is unfortunate that there is no equivalent provision to this for CVOTs. This
is so, even though in practical terms, the support identified as related to recovery needs in the adult section
of the MSAG is materially similar to support that a CVOT may require. The absence of funding means
there is no designated source of support to ensure that similar support for recovery needs is actually
provided to CVOTs in all cases. The lack of any structured guidance on what support is required for
CVOTs means, by default, that what is provided to the child will come out of the general funds and
resources of the local authority. This involves reliance on the ability of the local authority to work out for
itself what specific steps may be appropriate to meet the recovery needs of a CVOT. According to Ms
Durán, this frequently results in those needs not being recognised or treated as a direct category of needs
for CVOTs. That in turn means that those needs are not frequently provided for. Where a CVOT is being
looked after by a local authority, it means that in the course of care planning, there is no focussed
consideration of what the trafficking-related needs of the child in care are; or how they should be met, as
distinct from the child's general needs for their physical, emotional and psychological development. For
CVOTs who are not in care, there is no guidance or structure at all to ensure their recovery needs are met.

135. Ms Durán addresses the evidence that the claimant refused to engage with counselling. She
acknowledges that, in her first statement, she said that children in particular find it difficult to disclose
experiences of abuse. Encouraging disclosure takes time as well as a trusted and secure relationship.
According to Ms Durán, this means that when identifying CVOTs, those supporting them cannot wait for
the child to say “the right thing” or rely on them to volunteer information. It is necessary carefully to explore
the CVOT's account of what happened over an extended period of time, ensuring that the CVOT feels
comfortable. In this regard, Ms Durán refers to the Unaccompanied and Trafficked Child guidance where,
at paragraph 68, it is said that the steps to build, quickly, a stable and trusting relationship with any looked
after child are important and that the child needs to be told that they are safe. A child should be asked what
help makes them feel safe.

136. As for her previous statement that the impact of a child's experience and of the age assessment
process undertaken in the United Kingdom may impact on their ability to trust local authority
representatives, Ms Durán says that a CVOT must be made to feel like those asking questions are on their
side and not a threat. The age assessment process often creates the opposite impression because it is
adversarial.

137. Regarding the contention that Barnet was unaware of the claimant's status as a CVOT until his
immigration solicitors wrote to his social workers on 1 March 2019, Ms Durán contends that since Barnet
started supporting the claimant in April 2018 inquiries should have been made to local authorities and to


-----

the Home Office, particularly if there was a suspicion that the child may have been trafficked. If Barnet had
correctly identified the trafficking indicators in the claimant's account of what happened to him, in line with
the requirements under the MSAG, Barnet would have had to refer him into the NRM. That would have
meant that Barnet would have found out a reasonable grounds decision had already been made. Because
Barnet failed to identify indicators relevant to the claimant CVOT status and to make inquiries, it did not
carry out an important part of care planning.

138. Ms Durán considers that Barnet's position that it met all of the claimants needs, is fundamentally at
odds with its position that it did not know that the claimant was trafficked. If it did not know this, Barnet
could not properly have assessed what his needs arising from trafficking were and how he could best be
supported to meet them.

139. Kate Jeffrey, Head of Service in Barnet's Corporate Parenting Service, has filed a statement in
response to the second witness statement of Ms Durán. Ms Jeffrey says that in 2018 Barnet made an
important change to the way in which it looked after unaccompanied children. Mindful of their special
vulnerabilities with regard to forming trusting relationships, such children are transferred, following an initial
assessment, to Barnet's “Onwards and Upwards Leaving Care Service”. This provides them with a social
worker throughout their transition towards adulthood. This meant that the claimant had the same social
worker from 7 January 2019 to 12 August 2019. It avoided too many changes in support during what can
be a difficult time. Mindful of the claimant's need to develop trust, two independent advocates were
appointed for the claimant. The purpose of this was to make sure his voice was heard and if necessary to
challenge Barnet. Case records show they supported the claimant in his relationship with Barnet and
helped him with his entitlements as a care leaver.

140. Although agreeing with the fact that trafficking victims may be taught not to trust people, Ms Jeffrey
does not believe that there was any evidence of this in the case of the claimant. So far as accommodation
was concerned, there was nothing to suggest that any of the placements where the claimant lived were
unable to meet his needs. When he complained he was not happy with accommodation, alternative
arrangements were made for him to go elsewhere.

141. So far as mental health needs, the claimant was repeatedly offered support via Terapia, which is a
bespoke psychotherapy service for care-experienced young people in Barnet. At no point was counselling
or accessing mental health support unavailable to the claimant.

142. Ms Jeffrey agrees with Ms Durán that there are currently no special obligations to address traffickingrelated recovery needs or clarity on how such needs might be specifically addressed. Barnet provided the
claimant with accommodation, education and healthcare as an unaccompanied child under section 17 of
the CA 1989. That in practice complied with article 12 of ECAT.

143. So far as identifying the claimant as a victim of trafficking, Barnet considered this issue when the
claimant was a child. It acknowledges that at no point did it refer in its records to the claimant as a potential
or actual victim of trafficking. However, Ms Jeffrey says that this did not fundamentally impact on care
planning in the provision of support and services provided to the claimant.

144. Lauren Starkey, an independent social worker, has provided a witness statement. She notes Barnet's
position that it considered it had met its duties towards the claimant, despite denying knowledge of his
trafficking experience and that Barnet questions what specific needs arising from those experiences the
claimant may have had which were not met. In Ms Starkey's experience, trafficking survivors commonly
have difficulty forming trusting relationships, due to the abuse of trust that takes place with their traffickers.
They are taught not to trust people in positions of authority. It is therefore necessary to ensure that support
is specifically targeted to young people's trafficking experience because of these difficulties. CVOTs
experience many of the same traumas as the overall population of unaccompanied asylum-seeking
children, but with the additional trauma of the control, subjugation and exploitation associated with
trafficking. Their support needs therefore need to extend beyond what is offered to the general population
of unaccompanied asylum-seeking children and must directly target the impact of those experiences.

**_THE GROUNDS OF CHALLENGE_**


-----

145. I turn to the grounds of challenge. They are as follows.

146. Ground 1 contends that the SSHD is in breach of articles 12 and/or 13 of ECAT and/or article 4 of the
ECHR by failing to make arrangements to ensure that there is consistent provision of support to child
victims of trafficking for their recovery needs. The SSHD is the executive arm of the State, with overall
responsibility for implementing the United Kingdom's obligations in this regard. It is the single competent
authority decision-maker on all victim identification decisions. Since 2009, the SSHD had responsibility for
designing and developing the arrangements of the NRM, issuing guidance in that regard which includes
the MSAG. The SSHD is under the duty imposed by section 49 of the MSA to issue guidance to public
authorities concerning arrangements for providing assistance and support to victims who have received
positive reasonable grounds decision, whether adult or child.

147. The claimant says that article 12(1) of ECAT is prescriptive as to the categories of support that the
State “shall” arrange and that the list comprises what the State “shall include at least” in its arrangements.
Although the claimant accepts that the SSHD can involve third parties, no matter what arrangements are
made, the responsibility remains with the SSHD “to take steps necessary to ensure that victims receive the
assistance they are entitled to, in particular by making sure that reception, protection and assistance
services are funded adequately and in time”: paragraph 149 of the ECAT Explanatory Report.

148. The SSHD must show how, in making arrangements, she has directed her mind specifically to what
existing support structures she can draw upon and whether these meet the aim of article 12(1) support on
their own. If not, then the State must make additional arrangements.

149. The claimant relies on K and AM v the Secretary of State for the Home Department [2018] EWHC
2951. In that case, the SSHD attempted to withdraw financial support to AVOTs who were in receipt of
asylum support to avoid their destitution. Mostyn J found that to be unlawful because the financial support
provided to an AVOT was to discharge the duty to meet their trafficking-related recovery needs, as distinct
from general support that a destitute asylum seeker receives to avoid destitution. Thus, the SSHD could
not withhold such support because other support was provided for another purpose.

150. The claimant notes that article 12 of ECAT does not specifically require recovery needs support to be
met through financial payments. However, as the Court of Appeal noted in R (MD) v Secretary of State for
the Home Department [2022] PTSR 1182, material assistance under article 12(1)(a), ECAT is “likely to
require at least a degree of financial support”: Underhill LJ at paragraph 19. That cannot be controversial,
as the SSHD has made express arrangements for such support for adult victims. The “recovery rate” is
intended to “assist victim in accessing health, fitness or wellness classes, to help fund additional weekly
transport and communications costs or flexibly towards other recovery related costs”. This is different from
the point about double-provisioning, as to which the Court of Appeal in EM v Secretary of State for the
Home Department [2018] EWCA 1070 held that the provision of psychological support for detained victims
was already met by medical care arrangements in the detention centre and did not require release of the
victim in order to access psychological recovery facilities.

151. The claimant maintains that Ground 1 is not about double provision. The problem lies in the fact that
the SSHD has denied she has any responsibility for ensuring arrangements to meet a CVOT's needs, as a
matter of principle. The SSHD had at least to consider whether the existing _[CA 1989 structures were](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
sufficient to discharge her ECAT obligations in respect of child victims. Support for trafficking-related
[recovery needs is not the same as general support under the CA 1989 for children in need and children in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
care. The claimant 's personal experience speaks to the detrimental impact of the SSHD'S failure.

152. Ground 2 alleges a breach of article 14 of the ECHR. This provides that the enjoyment of the rights
and freedoms in the Convention shall be secured without discrimination on any ground. That includes
disability and any other status. It is necessary in this regard for the claimant to show that he was subjected
to differential treatment; and that that treatment was on a relevant ground or status. He must also show
that the treatment is within the subject matter, ambit or scope of another ECHR right. Even so, the person
concerned will lose an article 14 challenge if the Government is able to justify the differential treatment by
showing that this was a proportionate method of pursuing a legitimate aim.


-----

153. Whether the discrimination in question is characterised as indirect or Thilmmenos discrimination (that
is to say, a failure to treat unlike cases differently), the claimant contends that the substance of this
challenge is to the justifiability of failing to make provision for recovery-related support needs for CVOTs in
the same manner as AVOTs, which creates particular difficulties for CVOTs.

154. The SSHD accepts that recovery needs support falls within the ambit of article 4 but not that it falls
within ECHR article 1, protocol 1. However, the claimant says that since support may be provided by way
of financial payments, it is an entitlement of a financial kind and thus a form of welfare benefit, akin to that
of social security.

155.  So far as difference in treatment is concerned, the claimant contends that AVOTs and CVOTs are in
an analogous position because both are entitled to support under ECAT. The SSHD has made clear
arrangements for AVOTs to access the minimum specific categories of support under article 12(1) of ECAT
under the MSAG, Annex F, and also under the MSVCC but has not done so for child victims.

[156. The SSHD has not shown evidence of ensuring that the framework under the CA 1989 on its own is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
sufficient to discharge the SSHD's obligations under articles 12/13 of ECAT. The claimant points to the
witness evidence which he says shows a systemic failure on the part of the SSHD to ensure the provision
of support to child victims to meet their trafficking-related needs.

157. The SSHD has to justify why she has treated child victims differently and detrimentally by failing to
make arrangements for a consistent and standardised approach to ensure they can access their entitled
support under article 12.

158. Ground 3 alleges a breach of articles 12/13 of ECAT and /or article 4 of the ECHR, on the part of
Barnet. Barnet contends it did not know and could not have known that the claimant was trafficked until 1
March 2019, when it was informed by the claimant's immigration solicitors that he had received a positive
reasonable grounds to decision. The claimant says that, even if that is right, taking Barnet's case at its
highest, Barnet took no steps to assess the claim of trafficking recovery related needs and provide him with
support, as required to discharge the articles 12 and 13 ECAT duties from 1 March 2019, when he was still
a child, until 14 May 2019, when he achieved his majority. The care plans were devoid of any such
reference, thereby directly breaching regulations 5(1)(f)(i), 42(ba) and 43 of the 2010 Regulations.

159. Barnet also failed to make arrangements to ensure the continuation of trafficking recovery needs
support in the claimant's transition to adulthood after 14 May 2019. The pathway plans made no reference
to his victim status.

160. Despite knowing about the claimant's trafficked victim status, Barnet took no steps to liaise with the
SSHD from 1 March 2019 onwards in order to ensure the claimant received the necessary recovery need
support as a victim of trafficking. This meant the claimant had no access to recovery needs support at all
until 25 January 2020, when Young Roots became involved.

161. The claimant says that it is no answer for Barnet to say that care and pathway plans were prepared
with a view to supporting the claimant's welfare, if Barnet never turned its mind properly to the question of
what support needs the claimant had, arising from his experience of trafficking. It is wrong to say, as
Barnet does, that trafficked children have the same needs as unaccompanied children generally. Plainly,
the Regulations recognise these needs as distinct. Although the needs of the two categories of children
overlap, they are not identical. This emerges from the witness evidence of Ms Durán and Ms Starkey. A
trafficked child may require different or additional support to access counselling (or a particular type of
counselling).

162. Although the information sent by Camden drew attention to the claimant being a potential victim of
trafficking, Barnet took no steps to obtain any information held by Camden or Croydon.

163. Furthermore, Barnet has duties under article 10 of ECAT and the NRM arrangements as a
designated First Responder. This means Barnet was obliged to refer a potential child victim to the NRM if
information indicated they may have been trafficked. Thus, Barnet should have referred the claimant to the


-----

NRM in order to be identified. This would at least have prompted information sharing with the SSHD and,
thus, disclose that the claimant was, in fact, in the NRM already, with all that entailed.

164. As well as denying unlawfulness on its part, Barnet submits in the alternative that the court must
refuse relief by reference to section 32(2A) of the Senior Courts Act 1981.

165. Ground 4 alleges a breach of Barnet's duties under the _[CA 1989. Barnet is unable to point to any](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
document that acknowledged the claimant's victim status or which attempt to comply with the requirements
under the 2010 Regulations, as well as regulation 7 of the Care Leavers Regulations. This was because it
had failed to identify the claimant as a child victim, even after Barnet had been explicitly told of that status
on 1 March 2019.

166. Ground 5 contends that Barnet is in breach of section 11 of the CA 2004 and section 1 of the
Children and Social Work Act 2017. As a matter of substance, the care plans and pathway plans failed to
acknowledge the claimant's victim status at all or give any consideration to what his trafficking-related
needs were.

**_DISCUSSION_**

**_Delay and standing_**

167. I must first address two preliminary matters. These concern delay and standing. Both the SSHD and
Barnet contend that the claimant is not in time to challenge acts or omissions between 27 April 2018 and
17 December 2019. This is because the challenge was not brought promptly and in any event within three
months. Furthermore, so far as the challenge concerns human rights, the claimant did not bring it within
one year of the date of the act complained of, as required by section 7(5)(a) of the Human Rights Act 1998.
Since the decision of Lang J granting permission was silent on the issue, the defendants submit that it is
open to me to consider timeliness: R v Lichfield District Council _[2001] EWCA Civ 304; R (Bokrosova) v_
London Borough of Lambeth [2016] PTSR 355.

168. Despite the oral and written submissions of Mr Anderson and Mr Harrop-Griffiths, I am satisfied that it
is appropriate to extend time under the CPR and section 7(5)(b) of the Human Rights Act 1998, so as to
enable the claimant to challenge the pre-July 2022 decisions. Whilst I agree with Mr Anderson that one
must be careful, at a substantive judicial review hearing, not to gloss-over the issue of timeliness, on the
basis that the parties will (as here) have come prepared to argue the substance of the matter in issue,
there are compelling reasons to extend time. Given the way in which matters have evolved, I find that it
was appropriate for those advising the claimant to concentrate on the issue of back-payments. In sharp
contrast with the position in Bokrosova, the claimant's solicitors have explained, in the witness statement of
Ms Carolin Ott, the thinking underlying the decision in October 2022 to bring the application for judicial
review (and by inference, why no such proceedings were initiated earlier). I agree with Ms Luh that the
back-payments issue does, indeed, carry us into the events of 2018. I do not agree with Mr Anderson that
so to find is in the nature of a non sequitur. The fact that the legal and policy position may have changed
since 2018 may make the challenge more complicated. It does not, however, mean that the challenge
should not be permitted, if relevant considerations would otherwise make it appropriate for time to be
extended. I also agree with Ms Luh that, in this regard, it is of significance that Lang J granted permission
in respect of what was properly categorised as a “systems” challenge.

169. Mr Harrop-Griffiths points out that his client was not alerted to the dispute between the claimant and
the SSHD until August 2022 and that letters were sent to the wrong address for Barnet. I note, however,
that paragraph 5 of Ms Ott's witness statement says that during the period October 2021-March 2022, the
claimant sought to engage with both the SSHD and Barnet, in order to obtain information on who was
responsible for the provision of back-payments in respect of NRM payments owed to the claimant; and in
respect of the arrangements in place more generally for the provision of such payments. Particular
attention is drawn to the letter of 29 October 2021 from the claimant's solicitors, which was followed up by
several chasing letters. Ms Ott states that the claimant was unable to secure a substantive response from
either public authority. In the light of the issues raised and the obvious difficulties regarding the position of


-----

the claimant, I consider this evidence to strengthen the case for an extension of time in respect of both sets
of challenge.

170. I am satisfied that granting the extension has not put Barnet at any disadvantage in terms of
advancing evidence of its dealings with the claimant and the other authorities to which reference has been
made. On the contrary, the state of Barnet's record keeping is such that Mr Harrop-Griffiths has been able
to refer to it extensively, as my earlier synopsis shows.

171. I turn to the issue of standing. It follows from what I have said on timeliness that I consider the
claimant has standing to bring a challenge based upon the alleged unlawful failure of the SSHD to make
what the claimant submits is proper provision for CVOTs who are in the care of a local authority; and that
the SSHD's arrangements in this regard unlawfully discriminate against CVOTs, as compared with AVOTs.

172. I do, however, agree with Mr Anderson that the claimant has no standing to bring a challenge in
respect of the position of CVOTs who are not looked after children. The claimant has been a CVOT under
the care of Barnet. His position is, however, materially different from that of a British citizen or person with
leave to remain in the United Kingdom who is or may be a CVOT but who is not under the care of a local
authority. The SSHD is quite right to point out that the claimant is simply not in a position to speak for that
cohort of CVOT. The policy considerations in respect of that cohort are likely to be significantly different.
Any challenge in respect of that cohort therefore needs to be brought by a member of it. The same is true
of CVOTs from abroad who are accompanied by their parents. Different considerations are, again, likely to
apply to this cohort, which the parties to the present proceedings are unable safely to predict, despite the
witness evidence advanced by the claimant.

**_The case against the SSHD_**

**_Ground 1_**

173. The primary weakness in the claimant's case under Ground 1 is that it proceeds from what I find to be
an incorrect interpretation of article 12 of ECAT. It is plain from the opening words of article 12.1 that
States are being given a broad discretion regarding the adoption of “such legislative or other measures as
may be necessary to assist victims”. It is up to the State concerned to determine what measures should be
adopted. Likewise, it is open to that State to decide, if a measure is to be adopted, how that should be
done in practice. That includes deciding what emanation of the State (eg. central or local) should be
chosen for the task.

174. Furthermore, it is plain that, even where the State decides that a measure needs to be undertaken by
one of its organs, that organ does not have to be the same, as regards all categories of victims.

175. It is with these important considerations in mind that one must construe the list set out at article 12.1
a-f of ECAT. Article 12.1(a) is heavily relied on by the claimant. It is, accordingly, important to note that
article 12.1(a) is all about _subsistence._ The bar is, therefore, set at a low level. It is in this light that the
following words in the sub-paragraph need to be construed.

176. I agree with Mr Anderson that the claimant's case under Ground 1 suffers because of his
impermissible attempt to infer from article 12 an obligation of “consistency”, as between different categories
of persons. As is evident from paragraph 67 of R (EM) v Secretary of State of the Home Department,

[2018] 1 WLR 4386, different (including better) provision may be made for some categories rather than
others, without this leading to a breach of the article 12 duty.

177. Although dealing with article 12.1(d), EM is important, in making it plain that article 12 as a whole
does not necessarily demand that “bespoke” assistance be given, where assistance is available on a
broader basis:
“66. As to that element of the duty that requires the provision of necessary medical treatment including
psychological assistance, counselling and information, the treatment provided must respond to the welfare
needs of the individual, objectively assessed in each case. The obligations arising under the Directive and
Guidance, read alongside the Convention, do not extend to a requirement that the assessment or
t t t t b id d b i li t i t ffi ki th t it b t t d t d t f


-----

individual's needs (the consequences of trafficking) as opposed to his or her overall psychological needs.
The support duty calls for the provision of support, not the accomplishment of physical, psychological or
social recovery. There is nothing in the Convention, Directive, or Guidance to warrant the extended
interpretation of the duty argued for by the Claimant. That interpretation would require significant additions
to the texts to prescribe specific obligations that would undoubtedly have been spelt out, had they been
intended” (Peter Jackson LJ).

178. Further support for the SSHD's stance is provided by the Explanatory Report to ECAT. Immediately
under the heading “Article 12- Assistance to victims”, one finds paragraph 146, the first sentence of which
reads: “Victims who break free of their traffickers' control generally find themselves in a position of great
insecurity and vulnerability”. The point being made is that at the time at which the victim breaks free, they
are likely to be without resources of their own, for the simple reason that their accommodation and food
were being provided by the traffickers. At this juncture, therefore, the victim is in need of a level of
subsistence which will remove the risk of them feeling compelled to return to their traffickers. Although, as
a general matter, article 12 also covers those who, like the claimant, broke free from their traffickers long
before arriving in the United Kingdom, this point nevertheless needs to be borne in mind in order to avoid
misconstruing the provision.

179. All this means that the SSHD is correct to emphasise that the article 12 obligations do not include a
specific duty of financial support. The point is underscored by paragraph 156 of the Explanatory Report,
which explains that the Convention “provides for material assistance because many victims, once out of
the traffickers' hands, are totally without material resources”. Furthermore, the same paragraph explains
that “material assistance is distinguished from financial aid in that it may take the form of aid in kind ...and
is not necessarily in the form of money.”

180. The passage in paragraph 19 of MD in which Underhill LJ said that “material assistance” is likely to
require at least a degree of financial support needs to be read in the light of the foregoing. His observation
was, in any case, obiter, made in the course of consideration of AVOTs (albeit those who had dependent
children).

181. For these reasons, the claimant's case under Ground 1, proceeding from a misconstruction of article
12 of ECAT (and, by extension, article 13) begins from a position of weakness. This informs the broader
challenge that the claimant makes to the SSHD's policy towards CVOTs who are looked after by a local
authority.

182. It is important to bear in mind that “systems” challenges involve the ultimate question of whether the
system in question is capable of being operated lawfully: R(A) v Secretary of State for the Home
Department _[2021] UKSC 37. A systems challenge must show more than the possibility of aberrant_
decisions and unfairness in individual cases. It must show unfairness that is inherent in the system itself. In
the course of her reply, Ms Luh submitted that what the Supreme Court said in this respect cannot apply
where an unqualified ECHR right, such as article 4, is in play. There is, however, no binding authority
(including anything in the judgments in R (A)) to support this submission, which is in any event,
problematic. The SSHD's decision-making functions in immigration frequently involve ECHR article 3 rights
and it would be a serious impediment on their discharge if they could be impugned in the way Ms Luh
suggests.

183. I do not consider that the claimant can derive any material support from the judgment of Mostyn J in
R(K). The general system of asylum support payments to adults, calculated at a level to avoid destitution,
is in no way analogous to the specific, individualised obligations owed to a looked after child such as the
claimant.

184. Central to the claimant's systems challenge is his argument that the duties of local authorities under
the _[CA 1989 are too broad and unfocused as to be capable of discharging the policy obligation of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
SSHD to give effect to ECAT as regards that category of person. In this respect, the claimant relies upon
R(G).


-----

185. Section 17 confers a duty to safeguard and promote the welfare of children within their area who are
in need, by providing a range and level of services appropriate to those children's needs. The claimant
relies, in particular, on the opinion of Lord Hope who, at paragraphs 82 and 83 of the judgments, held that
the duty in section 17 did not confer an absolute right to the provision of any particular services and that
section 17 was not intended to be enforceable as such by individuals.

186. As Mr Anderson submits, however, the overall thrust of the majority of their Lordships' opinions was
to the effect that section 17, whilst being a general duty, was in no sense an empty shell. As Lord Millett
pointed out at paragraph 110, the existence of a power to provide assistance to a class involves a duty to
consider whether a particular individual is eligible for such assistance. That in turn involves assessing the
needs of the child in order to decide whether and the extent to which the authority will meet those needs.
As Helen Mansfield QC, sitting as a judge of the High Court, observed at paragraph 17 of R(O) v the
London Borough of Lambeth [2016] EWHC 937 (Admin), there needs to be a “sufficiently diligent inquiry”
concerning whether a child is “in need”.

187. It is also relevant that section 20 of the CA 1989 imposes the duty on a local authority to provide
accommodation for any child in need who appears to them to require such accommodation. Furthermore,
section 22 provides that it is the duty of a local authority looking after any child to safeguard and promote
the child's welfare and to make such use of services available for children cared for by their own parents as
appears to the authority reasonable in the case of the child. Section 22A states that where a child is in the
care of a local authority, it is their duty to provide the child with accommodation. Section 22B says that it is
a local authority's duty to maintain the child that they are looking after in other respects apart from the
provision of accommodation. Section 23C contains continuing functions in respect of former relevant
children. Section 23C(4) requires assistance, in effect, to be continued under section 24B, to the extent
that the former child requires this.

188. I find that this statutory framework is an appropriate mechanism for giving effect to ECAT (in
particular, article 12) in the case of looked after children and those who have been such. The claimant has
been unable to show that any needs which a CVOT may have as a result of trafficking are not needs that a
[local authority does not have a legal obligation to address pursuant to the CA 1989 and related legislation.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)

189. Any doubt in that regard is dispelled by the MSAG. Annex G details the support available to CVOTs
from the local authority. 16.5 provides that any child who is unaccompanied, who is separated from both
parents and is not being cared for by an adult who by law has responsibility to do so must, by law, be
accommodated by the local authority and will become “looked after” 24 hours later by the local authority
where their needs have been identified. Paragraph 16.6 provides that local authorities must allocate a
social worker who will assess the child's needs and draw up a care plan which sets out how the authority
intends to respond to the full range of the child's needs. That specifically includes ensuring they have all
the necessary legal and other support they need, including access to health, education and appropriate
and safe accommodation. If there is reason to believe that the child is a victim of **_modern slavery,_**
including trafficking, this must be recorded in their care plan. The social worker has responsibility for linking
the child in with the right services including GP, school and mental health services if appropriate.

190. Importantly, the 2010 Regulations make detailed provision for a care plan. Regulation 5(1)(f) provides
that where the child is or there is reason to believe may be, a victim of trafficking or is an unaccompanied
asylum seeking child, the care plan must record that fact. This leads directly to regulation 42 (assessment
and needs). An assessment of the child's needs must specifically include any needs the child has, if the
child falls within regulation 5(1)(f), as a result of being trafficked and/or being an unaccompanied asylum
seeking child.

191. These statutory provisions are recognised at paragraph 16.8 of Annex G to the MSAG. For child
victims who were looked after by local authorities, the latter are responsible for making sure an
assessment of their physical, emotional and mental health needs is carried out. That includes the child's
physical, emotional and mental health. A written medical report must initially be produced. Thereafter the
child's state of health must be reviewed at least once every six months before a child's fifth birthday and at
least once every 12 months thereafter.


-----

192. Paragraph 16.9 explains that the statutory guidance for local authorities in England to support care of
child victims of modern slavery says that a looked after child's health plan should set out the objectives,
actions, timescales and responsibilities arising from the health assessment. This includes detail of how any
psychological issues will be addressed:

“For example, these may result from the child's experiences at the hands of traffickers overseas or in the
UK. Unaccompanied children may also require specialist mental health support to help them deal with the
impact of loss and trauma. This may require referral to specialist mental health assessment and treatment”.

193. Paragraph 16.10 provides that for child victims, the Child and Adolescent Mental Health Services will
provide child or adolescent specific services, in a similar way to adult mental health services, but with
access to a different group of professionals. These services focus more on psychological and
pharmacological therapies. GPs and social workers will be able to facilitate access to counselling.

194. The Unaccompanied and Trafficked Children Guidance provides, at paragraph 17, that all those
involved in the care of unaccompanied children and child victims of **_modern slavery should be able to_**
recognise and understand the particular issues likely to be faced by these children. This includes
recognising the indicators of trafficking, slavery, servitude and forced or compulsory labour. Further details
are given in the subsequent paragraphs of that section.

195. Paragraphs 28 to 34 explain the NRM process, both as to reasonable and conclusive grounds.

196. Paragraph 51 provides that for unaccompanied children it will be important that the health
assessment should ascertain any particular physical, psychological or emotional impact of experiences as
an unaccompanied child or child victims of **_modern slavery. Such experiences can be severe and_**
traumatic, although in many cases they may not be immediately apparent.

197. Paragraphs 83 to 86 provide for planning transition to adulthood. Paragraph 84 states that for
unaccompanied or trafficked children this will be likely to include issues relating to their immigration status
and to the advice and support they need to engage in a timely and effective way with the process for
resolving their status.

198. The claimant contends that the Unaccompanied and Trafficked Children Guidance is defective in not
amounting to a guarantee that the child concerned will receive the “baseline minimum” to which they are
said to be entitled under article 12 of ECAT.

199. I cannot accept that criticism. It is apparent that the primary and secondary legislative framework,
read with the guidance materials, constitutes the measures required by article 12.1.

200.  In so finding, I have had regard to the witness evidence adduced on the behalf of the claimant. I
have also, of course, had regard to the claimant's own experiences. Much of the evidence of Ms Durán is
directed to matters that have nothing to do with the facts of the claimant's case; namely, the position of
CVOTs who are living with their families or the position of CVOTs who are foreign nationals but
accompanied by their parents. For the reasons I have given, these matters are out of scope. An actual
challenge by an individual within this cohort is needed before one can make any meaningful findings. I
agree with the SSHD that Ms Durán's description of how her organisation was unsuccessful in lobbying
Parliament to introduce alternative legislation in this area shows that we are here concerned with the
formulation of law and policy. The proper way for civil society organisations to advance their concerns is
through dialogue with Parliament and Government. It is not for such organisations to ask this court to give
effect through judicial review to their views on what _should be done by way of lawmaking or policy_
formulation (as opposed to what must be done as a matter of public law). Ms Durán's second statement
likewise largely comprises her opinion about matters of policy.

201. Ms Starkey provides evidence of what constitutes good social work practice. I agree with Mr
Anderson that her general statements, such as that “I found local authorities are often unaware of any
specific obligations towards CVOTs”, are too unspecific to be given any material weight. By the same
token, her view that standards and training in local authorities could be improved does not begin to identify
a systemic illegality of the SSHD.


-----

202. Likewise, the claimant's history does not demonstrate any illegality on the part of the SSHD. (I deal
with the issue of consent to remain in the NRM below). The SSHD properly communicated the outcome of
the NRM referral to the LB Croydon. It is not the fault of the SSHD that Croydon did not pass this on to
Barnet. In any event, the fact that the claimant had been so referred could have been ascertained through
the UUCR form. Barnet is itself a local authority, and, as such, a First Responder. Accordingly, Barnet was
in a position to identify if there were concerns that the claimant might be a VOT. The SSHD was under no
obligation to provide support to the claimant, as a CVOT. That obligation lies with the relevant local
authority.

203. I turn to the issue of consent for the claimant to remain in the NRM, upon becoming an adult. The
claimant asserts that the SSHD had no right to require him to consent to remain in the NRM. This affects
the payments to which the claimant says that he is entitled, by way of backdating. The period in question is
from 14 May 2019, when the claimant became eighteen, to 17 December 2019.

204. The SSHD contends that the claimant did not advance in the grounds the argument set out in the
claimant's skeleton argument based on domestic law that the SSHD was wrong to require consent to entry
to the NRM.

205. Nevertheless, paragraph 34 of the grounds of claim refers in terms to the issue of consent, pointing
out that the SSHD cited no authority for the alleged requirement to provide consent. Under the heading of
Ground 1, paragraphs 86 and 87 specifically challenge the SSHD's case on consent.

206. The claimant says that there is nothing in the statutory guidance issued by the SSHD to say that a
person in the NRM must consent to continue in it after they become an adult. Thus, the claimant contends
that the SSHD is, in effect, operating a “secret” and thus unlawful policy. The claimant also points out that
there is nothing in ECAT to justify the SSHD's approach.

207. Not everything that the SSHD does in this (or any other) area has to be done in pursuance of
something that falls to be categorised as a policy. The SSHD is entitled to take the view that a person who
has entered the NRM as a child must consent to continue in it as an adult. Indeed, I consider that the
SSHD is obliged to take this view. If the SSHD did not, then serious issues would arise regarding consent
to such things as medical treatment being administered as a result of a reasonable grounds decision being
taken in respect of the person concerned. The fact that the issue of consent is not referred to in ECAT is
thus immaterial. So too is its absence from any domestic guidance.

208.  The claimant contends that the SSHD owes an operational duty under article 4 of the ECHR to
provide a victim with support for recovery. As held by the ECtHR in Rantsev v Cyprus and Russia (2010)
51 EHRR1, the operational duty falls to be exercised by the State of its own motion, without the need for
the victim to request support. Thus, the requirement of consent is said by the claimant to be incompatible
with article 4 of ECHR.

209. The claimant mentions in this context the May 2023 version of the MSAG. Paragraph 9.48 of this
version states that where “local authority support is no longer available for an adult whose modern slavery
experience was perpetrated when they were a child and they consent to continued support in the NRM as
an adult”, the local authority will put in motion the process for support to be given under the process that
applies to adults (my emphasis). The May 2023 MSAG is not, however, within the ambit of this judicial
review. Be that as it may, the appeal to article 4 ECHR in this context is misconceived. There is a
fundamental difference between the facts of Rantsev, where numerous requests for protection as a victim
of trafficking were ignored, with fatal results, and a person who is already within the NRM, having entered
as a child, being required to consent to remain there, upon becoming an adult.

210. That leaves the broader argument that the SSHD's approach to CVOTs in the care of the local
authority is contrary to article 4. Since, for present purposes, article 4 can have no wider reach than ECAT,
the fact that I have dismissed the challenge by reference to articles 12 and 13 of ECAT means that there is
no scope for the claimant to contend that Ground 1 should succeed by reference to article 4 of the ECHR.

211. The fact that the SSHD was entitled to require the claimant's consent to remain in the NRM is,
however not a complete answer to his claim in respect of back payments for the period 14 May 2019 to


-----

17 December 2019. The correspondence on this issue is far from pellucid. It is, however, sufficiently plain
from the materials that the SSHD treated the claimant as having consented to remain in the NRM unless
he positively opted out, on reaching his majority. At page 3317 of the bundle, there is an undated letter
from the Home Office to the claimant. This says that the claimant is “now 18 years old and as such your
consent is required under the NRM process”. The letter then says “If you no longer wish to be considered
under the NRM process and do not wish to give consent, please complete the declaration below.” The
declaration reads “I agree that I wish to withdraw from the NRM process meaning that I no longer wish the
**_modern slavery aspect of my case to be considered further.”_**

212. What I shall call the “opt out” letter appears to have been sent by the Home Office to the claimant's
then solicitors, under cover of a letter dated 7 December 2018. The year “2018” is at first sight strange, in
that the claimant did not become 18 until 14 May 2019 and yet the covering letter refers to the claimant
having reached the age of 18 and that his consent is required “to continue with the NRM referral and
pending conclusive grounds decision.” The reason appears to be that the letter gives what is now accepted
to be an incorrect date of birth for the appellant of 14 May 1999. The opt out letter appears to have been
enclosed. Oddly, the covering letter then says “If your client wishes to continue with the NRM referral,
please find attached a postal consent form and personal questionnaire”. A second enclosure appears to
have been included. This contains a declaration consenting to the Competent Authority considering
**_modern slavery. In the absence of consent, it is said that “the issue of_** **_modern slavery will not be_**
considered under the NRM”.

213. Neither party was able to shed any useful light on the oddity of the covering letter and the second
enclosure. In all the circumstances, I find that the position at the relevant time was as follows. Where a
child has entered the NRM process, the SSHD required that person to consent to continuing in the NRM,
once they have become 18. Consent would be treated as having been given unless the person opted out.
In the case of an adult, however, express consent was required in order for the person concerned to enter
the NRM process. This explains the existence of the second enclosure with the letter of 7 December 2018
but not why it was enclosed. I find that the second enclosure was included in error and that the covering
letter wrongly suggested the claimant's consent needed positively to be given.

214. There is no evidence that shows the claimant decided to opt out, either by making the declaration in
the opt out letter or in some other effective manner at any material time. On the contrary, at page 3359, a
Barnet case note of 16 April 2019 states that the claimant “has agreed to the NRM referral”. Even if this
may have been written on the assumption that the claimant was not yet in the NRM, it is plainly
incompatible with any suggestion that the claimant had done anything to opt out.

215.  At page 3408, there is a Home Office document signed by the claimant on 12 December 2019,
consenting to his details “being submitted to the Single Competent Authority who, where appropriate, might
contact other relevant agencies to assist in the identification and decision-making process.” This is not in
the same form as the second enclosure to the letter of 7 December 2018 and it is unclear how it came to
the claimant's attention. Be that as it may, the document at page 3408 cannot rationally be treated as
indicating that the claimant had opted out of the NRM and was now, in some way, seeking to re-engage.

216. In short, therefore, whilst the SSHD is entitled to address the issue of consent in respect of children in
the NRM, as they approach or reach majority, the SSHD chose to do so by means of a system of opting
out (at least, in the case of the claimant); and the evidence does not show that the claimant decided to opt
out and communicated this to the SSHD.

217. Ground 1 therefore succeeds, only to the extent that the claimant is entitled to back payments from
the SSHD in respect of the period from 14 May 2019 to 17 December 2019.

**_Ground 2_**

218. Ground 2 concerns the absence of recovery rate support provided to CVOTs. Paragraph 89 of the
claimant's skeleton argument refers to the policy, in the March 2023 MSAG, of providing recovery rate
financial support to AVOTs, making the point that the same has not been done for CVOTs. This policy,
however, post-dates the relevant impugned decision-making in the present case. In any event, whether a


-----

person would be “better off” on the basis of receiving individualised support as a looked after child or on
the basis of receiving a fixed payment, such as the recovery rate financial support, cannot be answered in
the abstract. Indeed, as a more general matter, there is no reason to consider that financial payments are
necessary or appropriate for all looked after children who are within the NRM. Everything will depend on
the particular circumstances of the case.

[219. The claimant contends that the SSHD has not shown evidence that the framework of the CA 1989 on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
its own is sufficient to discharge her obligations under articles 12/13 of ECAT. I have, however, found this
to be wrong, for the reasons given above. The local authority is responsible for ensuring that the child's
needs are met, holistically. Any failure in that regard can be challenged in the courts.

220. I agree with the SSHD that, for this purpose, children and adults are not in analogous situations. In
the present case, they occupy starkly disanalogous positions. A person such as the claimant is entitled to
be looked after by the local authority. I have already explained why the positions of those children who are
not looked after are outside the scope of this judicial review. There is nothing in ECAT that begins to
suggest that a State must produce a unitary system, applying equally to adults and children. Indeed, there
would have been obvious difficulties if ECAT had purported to do so; precisely because children and adults
are in fundamentally different positions.

221. In view of my findings, there is no scope for the claimant to rely upon Article 1, Protocol 1. He has not
suffered any discrimination in respect of his property.

222. Having regard to the witness evidence, the claimant contends that there is a “postcode lottery”
depending upon which local authority a CVOT finds themselves in. This is, however, common in many
areas of public life and is not necessarily indicative of any behaviour that might be proscribed by article 14.

223. Ground 2 accordingly fails.

**_The case against Barnet_**

**_Ground 3_**

[224. Barnet accepts that its duties under the CA 1989 and related legislation, together with the relevant](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
guidance, imposes upon it an operational duty with respect to articles 12 and 13 of ECAT. It is common
ground that Barnet did not specifically acknowledge that the claimant might be a VOT whilst the claimant
was under 18. On the facts, I find it is plain that Barnet ought to have done so.

225. The UUCR sent by Camden drew attention to the fact that the claimant was a potential CVOT. The
UUCR is the form that Barnet was required to complete under the National Transfer Scheme Protocol, not
only to confirm that the claimant had been taken into its care but also to secure funding from the SSHD for
the claimant, as an unaccompanied child. Barnet took no steps to obtain any information held by Camden
or Croydon regarding the claimant. I agree with the claimant that, in order to make the system work, there
was an operational duty on Barnet to do something in this regard. Barnet also made no inquiries with
SSHD as to information held by her on the claimant. I refer to what is said at paragraph 186 above. Subject
matter and context are relevant to the level of scrutiny that the court will employ in deciding whether the
_Tameside_ duty of inquiry has been discharged. Whilst taking full account of the pressures under which
Barnet, in common with other local authorities, must operate, I find that its inaction in the present case was
_Wednesbury unreasonable._

226. In any event, Barnet had duties deriving from article 10 of ECAT and the NRM arrangements to act
as a designated First Responder. It was, accordingly, obliged to refer a potential CVOT to the NRM, if
information was available that indicated the child may have been trafficked. It is clear from the records to
which I have made reference that Barnet was very alive to the question of whether the claimant had been
trafficked into the United Kingdom and, if so, whether he might still be at risk from traffickers.

227. Crucially, however, a person may be a VOT even though they have not been trafficked into the
United Kingdom. Trafficking may have occurred earlier, before the person concerned reached the United
Kingdom. The trafficking may have entirely ceased by this time.


-----

228. The evidence shows clearly that Barnet's social workers and other staff did not turn their minds to
whether the claimant may have been a victim, in this wider sense. Had they done so, then, at the very
least, Barnet's functions as a First Responder would have led them to conclude that what the claimant was
telling them about being held in Libya and compelled to work for his uncle were strongly indicative of
**_modern slavery. Accordingly, Barnet would have initiated the NRM process. That would undoubtedly have_**
led Barnet to discover that the SSHD had, in fact, already initiated that process.

229. What, though, would have ensued? Whether or not the descriptor of modern slavery was applied to
it, Barnet was aware of the account given by the claimant of his experiences in the various countries
through which he had travelled to the United Kingdom. Barnet was aware that those experiences,
cumulatively, had been traumatic for the claimant. Barnet was also aware of those aspects of the
claimant's account, such as seeing friends killed in a road accident and being beaten by officials in France,
which would not appear to fall within the ambit of modern slavery.

230. As a result of all this, the records show that Barnet was of the view that the claimant would benefit
from counselling and that he could well need other specialist services. The records show, however, that the
claimant was unwilling to engage with these. Indeed, that attitude continued whilst his immigration status
was unresolved. Despite the attempts of the claimant's witnesses to qualify certain of their earlier
pronouncements, it is clear that, as a general matter, potential or actual victims of **_modern slavery are,_**
indeed, unwilling to engage with specialist therapeutic services, for this very reason.

231. I reject any suggestion that, if Barnet had appreciated that the claimant was within the NRM and had
received a positive reasonable grounds decision, Barnet would (or would have been obliged to) have given
the claimant additional financial payments. As a looked after child, the claimant would not need such
payments in order to obtain any such specialist services. As for travelling to obtain any such services,
Barnet could have arranged travel for the claimant or made discrete financial provision for, say, a possible
taxi fare. The evidence shows that this was highly likely to have been how Barnet would have proceeded,
had the claimant chosen to engage in this regard. However, he did not.

232. This brings me to the issue of section 31(2A) of the Senior Courts Act 1981. This provides that the
court must refuse to grant relief on an application for judicial review if it appears to be highly likely that the
outcome for the applicant would not have been substantially different if the conduct complained of had not
occurred.

233. At first sight, there is much to be said for Barnet's case on section 31(2A). Even on the claimant's
evidence he accepts that he did not engage. He ascribes this to a lack of trust on his part, not least
because he appears to have felt aggrieved that Barnet undertook assessments of his age. Barnet was,
however, obliged to do so if it had cause to consider that the claimant was not telling the truth about his
age. It is also not for this court, in the context of a judicial review, to determine whether the apparent illfeeling towards Barnet on the part of the claimant was occasioned by, for example, any bad behaviour on
the part of employees of Barnet.

234. There is, however, one matter which is verifiable and which, I consider, means that section 31(2A) is
not available to Barnet to resist declaratory relief, as a consequence of Ground 3 being made out (which I
find it is). In his first witness statement, the claimant describes being told later that “being a victim of
trafficking might be a basis on which I could be allowed to stay in the UK separately from my claim for
asylum”. That is, of course, right. A person will not be removed from the United Kingdom, following receipt
of a reasonable grounds decision, in the absence of special circumstances (which do not apply here); and
a favourable conclusive grounds decision could itself lead to the claimant being given leave to remain in
the United Kingdom. If the claimant had discovered from Barnet, either shortly after his placement (by
reason of the matters to which I have referred) or, at the latest, when Barnet had its initial discussions with
the claimant and should have concluded that Barnet's function as First Responder required it to refer the
matter to the Single Competent Authority, then the claimant would have discovered that, quite apart from
his asylum claim, he enjoyed a measure of protection from removal. That, I find, is very likely to have had
the effect of changing the claimant's views regarding seeking specialist assistance, particularly since the


-----

claimant's appreciation of these important facts is likely to have occurred before his relationship with
Barnet's employees began to sour.

235. I acknowledge the somewhat speculative nature of what I have just said. The exercise demanded by
section 31(2A) is, however, such as to require the court to engage in such an exercise. I therefore do not
consider that Barnet has shown that it is “highly likely that the outcome for the applicant would not have
been substantially different if the conduct complained of had not occurred”.

236. Ground 3 accordingly succeeds to the above extent.

**_Ground 4_**

237. It follows from my conclusions on Ground 3 that Barnet cannot contend that, by the time it attempted
to comply with the requirements of regulations 5, 42 and 43 of the 2010 Regulations and regulation 7 of the
Care Leavers Regulations, it did not have reason to believe that the claimant may have been a VOT. The
claimant is entitled to a declaration to that effect.

238. Ground 4 accordingly succeeds.

**_Ground 5_**

239. Ground 5 alleges a breach of section 11 of the CA 2004 and section 1 of the Children and Social
Work Act 2017. Although Ground 5 does not anything of substance to Grounds 3 and 4, in the light of my
findings on them, it follows that ground 5 succeeds.

**End of Document**


-----

# R (AM) v Secretary of State for the Home Department and another

## [2023] EWHC 3034 (Admin), [2024] 4 WLR 5, [2023] All ER (D) 28 (Dec)

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 01/12/2023

# Catchwords & Digest

## IMMIGRATION - ASYLUM SEEKERS – ASYLUM

      The Administrative Court, determining a challenge in respect of the claimant’s claim for back payments of trafficking support under the Modern Slavery Victim Care Contract, held that the difference of treatment between child victims of trafficking and adult victims of trafficking in the relevant statutory provisions had not been unlawful, however the first defendant Secretary of State and second defendant local authority were liable to the claimant for the specific manner in which they dealt with the claimant who had entered the country as a child victim of human trafficking and was subsequently dealt with as an adult victim of human trafficking as he attained majority.

# Cases considered by this case


EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v
Secretary of State for the Home Department

_[[2022] EWCA Civ 307, [2023] QB 351, [2022] 3 WLR 353, [2022] INLR 213, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
_[ER (D) 70 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
Considered

MD and another v Secretary of State for the Home Department

_[[2022] EWCA Civ 336, [2022] PTSR 1182, [2022] All ER (D) 71 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-HXX3-CGX8-004D-00000-00&context=1519360)_
Considered

R (on the application of A) v Secretary of State for the Home Department

_[[2021] UKSC 37, [2022] 1 All ER 177, [2021] 1 WLR 3931, [2021] All ER (D) 115 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_
Considered

R (on the application of EM) v Secretary of State for the Home Department

_[[2018] EWCA Civ 1070, [2018] 1 WLR 4386, [2018] All ER (D) 113 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCR-C3C1-DYBP-N2GW-00000-00&context=1519360)_
Considered


17/03/2022

CACivD

16/03/2022

CACivD

30/07/2021

SC

15/05/2018

CACivD


R (on the application of O and the child's mother and litigation friend Ms PO) v 28/04/2016


-----

Lambeth London Borough Council

_[[2016] EWHC 937 (Admin), [2016] All ER (D) 16 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JP6-XVH1-DYBP-N25N-00000-00&context=1519360)_
Considered

Wilson v First County Trust Ltd

_[2003] UKHL 40, [2004] 1 AC 816, [2003] 4 All ER 97, [2003] 3 WLR 568, [2003] 2 All_
_[ER (Comm) 491, [2004] 2 LRC 618, (2003) Times, 11 July, [2003] GCCR 4931, [2003]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-82KK-00000-00&context=1519360)_
_[All ER (D) 187 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWJ1-DYBP-N232-00000-00&context=1519360)_
Considered

**End of Document**


AdminCt

10/07/2003

HL


-----

