# R v Joseph

_[[2017] EWCA Crim 36, [2017] 1 WLR 3153, [2017] 1 Cr App Rep 486, [2017] Crim LR 817, [2017] All ER (D) 100](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_

_[(Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 09/02/2017**

# Catchwords & Digest

**CRIMINAL LAW – TRAFFICKING PEOPLE FOR EXPLOITATION – OFFENCES COMMITTED BY VICTIMS OF**
**HUMAN TRAFFICKING – IN 2015, STATUTORY DEFENCE AVAILABLE TO INDIVIDUALS CLAIMING NEXUS**
**BETWEEN THEIR TRAFFICKING AND CRIME COMMITTED – FOR INDIVIDUALS NOT FALLING WITHIN**
**STATUTORY DEFENCE, JUDICIARY AND CROWN PROSECUTION SERVICE DEVELOPING LEGAL REGIME**
**TO GIVE EFFECT TO UNITED KINGDOM'S INTERNATIONAL OBLIGATIONS RELATING TO NON-**
**PUNISHMENT OF VICTIMS OF HUMAN TRAFFICKING – COURT OF APPEAL, CRIMINAL DIVISION,**
**HEARING CONJOINED APPEALS AND APPLICATIONS TO CLARIFY LEGAL PRINCIPLES FOR**
**[INDIVIDUALS NOT HAVING BENEFIT OF STATUTORY DEFENCE – MODERN SLAVERY ACT 2015, S 45,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)**
**_[SCH 4 – COUNCIL OF EUROPE CONVENTION OF ACTION AGAINST TRAFFICKING IN HUMAN BEINGS,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C3R0-00000-00&context=1519360)_**
**ART 26.**

The Court of Appeal, Criminal Division, gave guidance on the legal regime relating to those not within the scope of
the **_[Modern Slavery Act 2015 who faced charges, but who claimed there was a nexus between the crime with](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
which they were charged and their status as victims of trafficking for the purposes of exploitation.

# Cases referring to this case


R v AAB

_[[2024] EWCA Crim 880](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6CK0-H853-RSDK-X440-00000-00&context=1519360)_
Considered

Begum v Secretary of State for the Home Department

_[[2024] EWCA Civ 152, [2024] All ER (D) 131 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BD5-W5S3-RRP9-M257-00000-00&context=1519360)_


26/07/2024

CACrimD

23/02/2024

CACivD


-----

Considered
R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

R v BYA

_[[2022] EWCA Crim 1326](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66KY-GB03-CGX8-00J1-00000-00&context=1519360)_
Followed

R v AGM

_[[2022] EWCA Crim 920, [2022] All ER (D) 23 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65W9-2RG3-GXF6-827R-00000-00&context=1519360)_
Considered

A and another v Criminal Injuries Compensation Authority and another

_[[2021] UKSC 27, [2022] 1 All ER 577, [2021] 1 WLR 3746, [2021] All ER (D) 33 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64RX-C0V3-GXF6-80JN-00000-00&context=1519360)_
Considered

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Considered

R v O

_[[2019] EWCA Crim 1389, [2019] All ER (D) 56 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W67-WPX2-D6MY-P3GR-00000-00&context=1519360)_
Applied

R v JXP

_[[2019] EWCA Crim 1280, [2019] All ER (D) 44 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W56-P502-D6MY-P0NC-00000-00&context=1519360)_
Applied

R v GS

_[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2019] 1 Cr App Rep 84, [2018] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
_[(D) 90 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
Applied

# Cases considered by this case

R v L

_[[2013] EWCA Crim 991, [2014] 1 All ER 113, [2014] 3 LRC 1, [2013] 2 Cr App Rep](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_
[247, (2013) Times, 03 October, [2013] All ER (D) 216 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58RB-D6B1-DYBP-N1KF-00000-00&context=1519360)
Applied

R v LM

_[[2010] EWCA Crim 2327, [2011] 1 Cr App Rep 135, [2010] All ER (D) 202 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_
Applied

**End of Document**


20/01/2023

CACrimD

13/10/2022

CACrimD

05/07/2022

CACrimD

09/07/2021

SC

19/05/2021

CACrimD

31/07/2019

CACrimD

09/07/2019

CACrimD

31/07/2018

CACrimD

21/06/2013

CACrimD

21/10/2010

CACrimD


-----

