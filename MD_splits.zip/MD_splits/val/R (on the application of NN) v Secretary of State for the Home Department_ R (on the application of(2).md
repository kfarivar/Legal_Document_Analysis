Secretary of State for the Home Department

# R (on the application of NN) v Secretary of State for the Home Department; R
 (on the application of LP) v Secretary of State for the Home Department

_[[2019] EWHC 1003 (Admin), [2019] All ER (D) 104 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VJB-V2K2-8T41-D0R8-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 17/04/2019**

# Catchwords & Digest

**IMMIGRATION - TRAFFICKING – SUPPORT**

Immigration – Trafficking. The court had jurisdiction to grant general interim relief in respect of persons other than
the individual claimants who were not claimants before it. The Administrative Court further held that there was a
serious issue to be tried in the claimants' judicial review proceedings challenging the defendant Secretary of State's
policy of ending support 45 days after a conclusive determination that a person was a victim of **_modern_**
**_slavery/people trafficking and the balance of convenience came down in favour of granting the general relief_**
sought.

# Cases referring to this case


R (on the application of DA and others) v Secretary of State for the Home Department

_[[2020] EWHC 3080 (Admin), [2020] All ER (D) 101 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61C7-9213-GXFD-8401-00000-00&context=1519360)_
Followed

# Cases considered by this case

R (on the application of Majit) v Secretary Of State For The Home Department (2016)

_[[2016] EWHC 741 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JGN-9471-F0JY-C252-00000-00&context=1519360)_
Considered


13/11/2020

AdminCt

18/03/2016

AdminCt


-----

Secretary of State for the Home Department

HN (Afghanistan) v Secretary of State For The Home

_[[2015] EWCA Civ 1043](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5H59-T4C1-F0JY-C1B3-00000-00&context=1519360)_
Considered

Medical Justice (R on the application of) v Secretary Of State For The Home
Department

_[[2010] EWHC 1425 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
Applied

Smith v Inner London Education Authority

_[[1978] 1 All ER 411](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-612X-00000-00&context=1519360)_
Considered

American Cyanamid Co v Ethicon Ltd

[[1975] AC 396, [1975] 1 All ER 504, [1975] 2 WLR 316, [1975] RPC 513](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-604K-00000-00&context=1519360)
Applied

**End of Document**


21/08/2015

CACivD

21/05/2010

AdminCt

19/07/1977

CACivD

05/02/1975

HL


-----

