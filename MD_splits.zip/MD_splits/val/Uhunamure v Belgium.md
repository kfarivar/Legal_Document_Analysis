# Uhunamure v Belgium [2022] EWHC 2435 (Admin)

King's Bench Division, Administrative Court (London)

May J

30 September 2022Judgment

James Stansfeld (instructed by Sonn Macmillan Walker) for the Appellant

David Ball (instructed by the Crown Prosecution Service) for the Respondent

Hearing dates: 14/06/22

- - - - - - - - - - - - - - - - - - - - 
**Mrs Justice May DBE :**

**Introduction**

1. This is an appeal, brought with permission of the single judge, against an extradition order made by DJ
Branston (“the District Judge”) dated 17 March 2021.

2. The order was made pursuant to a European Arrest Warrant (“EAW”) issued on 25 September 2020
and certified by the NCA on 13 October 2020. The appellant is sought by the Examining Magistrate of the
Court of First Instance in West Flanders, Belgium to stand trial for six offences of human trafficking,
recruiting another person for prostitution using deception, coercion or threats, possession or retention of
the proceeds of crime, conversion, transfer or concealment of money derived from criminal activities and
hiding or disguising the movement or ownership of money derived from criminal activities.

3. The appellant was arrested on the EAW on 2 November 2020. The substantive hearing took place
before the District Judge on 5 February 2021 after which he reserved judgment, subsequently handing it
down and making the order on 17 March 2021.

4. As appears from the statement of Thomas Gillis dated 27 September 2021, after extradition was
ordered, but before the hearing of the application for permission to appeal, there was a trial in Belgium,
starting on 5 May 2021 and concluding on 26 May 2021. No objection is taken to the admission of this
evidence on appeal. The appellant was not present at trial, being represented there by his Belgian lawyer.
He was convicted and sentenced in his absence to 30 months imprisonment, 15 months of which were
suspended. The offences of which he was convicted in his absence were more circumscribed than those
for which he is sought on the EAW (a matter that was addressed in argument, see further below). He has
lodged an appeal against conviction and sentence. However in the meantime his lawyer in Belgium has
applied, successfully, for the appeal to be stayed pending these extradition proceedings. Accordingly it is
accepted that the appellant has not been finally convicted in Belgium and that he has a right to a fresh trial
there.

5. Permission to challenge extradition has been granted on two grounds:

(1)  The District Judge should have found that the warrant failed to include adequate particulars of the
[offences as required by section 2(4) of the Extradition Act 2003 (“EA 2003”);](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)


-----

(2) The District Judge was wrong to find that the offences were extradition offences, as required by section
10 of the EA 2003.

Permission was refused on two further grounds, of abuse of process and under Article 6 ECHR.

**The EAW and Further information**

6. In overview the conduct is described as follows: the appellant is said to be part of a criminal
organisation consisting of Nigerian citizens who exploit Nigerian women in enforced prostitution, putting
pressure on the persons involved to have the victims do what they what them to. The organisation
operates from Antwerp, sexual services are organised in Flanders. The appellant is said to be responsible
for a system by which money is sent outside accredited money transfer operations, referred to as 'Black
Western Union', for which he receives a commission. Others suspected of human trafficking, named as
Kabba, Danko, and Billo, used this system and sent money to each other and to third parties, in order to
facilitate the trafficking/prostitution operation and to launder the proceeds. Wiretaps and phone
interceptions show money transfers from Kabba to Danko, operated by the appellant through his money
transfer system, and Billo arranging to transfer money to Kabba, sometimes before Billo had placed money
with the appellant in order to do so. A system was created where advance payments were made where the
transferor did not have sufficient resources at the time of the transaction. At the time of the transaction the
appellant communicated with the persons wishing to transfer money regarding exchange rates and
commission. In the absence of the appellant money was handed over in a place called 'Dave store'.

7. Wiretaps and mobile phone investigations show that the appellant has interests in the UK and Spain
and is responsible for bringing money from Belgium to Nigeria. On 28 September 2019 the appellant said
to Billo that he would take 'something' with him to Nigeria and that everything needs to be collected, this
was about money. The appellant spoke to Billo about obtaining a residence permit and the possibility of
applying for asylum in Belgium. The appellant was aware that Billo had been transferred from Nigeria to
Belgium by Kabba. The appellant stated that when he would transfer a person he would look after the
residence permit himself. The evidence indicates that Billo organises people-trafficking and smuggling
between Dubai and Nigeria from Belgium. The appellant is responsible for advancing money that Billo
needs to finance the offences. Wiretaps and cell phone investigations have shown that the appellant
assumed that Billo would not be able to pay the money owed on time, before money was transferred out.
Before a victim of trafficking, named as Victoria Williams (“VW”), was flown out of Nigeria to Dubai, Billo
asked the appellant to check the internet for flight tickets for her. The appellant transferred money to a
person called Ivie Ozurumba, on behalf of Billo, to smuggle VW from Nigeria to Dubai and to exploit her in
forced prostitution in Dubai.

8. The involvement of the appellant in this activity is said to amount to six separate offences A to F,
contrary to Belgian law, details of which are set out at [25] below.

9. The respondent has provided further information dated 22 January 2021, 5 February 2021 and 14
September 2021.

**Issues before the District Judge and his findings**

10. The District Judge considered and rejected an argument that the warrant did not contain the
particulars required by section 2 EA 2003. He held that the EAW detailed “a criminal organisation
exploiting Nigerian women for the purposes of prostitution, trafficking them out of Nigeria and using
coercion to make them work as prostitutes”, in circumstances where the organisation profited from such
activities. The District Judge found that the appellant was an “integral part of the organisation, providing
the means by which monies to facilitate the enterprise is [sic] transferred and then transferring the profits of
the enterprise”, also providing advice. He held that there were sufficient particulars to show how the
appellant's conduct was said to constitute each of the offences for which he was sought: see paragraph 59
of the District Judge's judgment.

11. The District Judge took into account the contents of the further information dated 5 February 2021 in
which the Belgian prosecutor gave notice of an intention to proceed against the appellant in respect of four,
rather than six offences He concluded that this did not undermine the validity of the EAW provided that


-----

sufficient particulars had been given in respect of the six offences, which had been done: see paragraph 63
of his judgment.

12. The District Judge then moved to consider whether the offences were extradition offences under
section 10, applying (since the EAW is an accusation warrant) the requirements of section 64 EA 2003.
Focussing on the requirement of dual criminality under sub-section 64(3) the District Judge held that the
conduct had occurred in in Belgium “in the sense that the effects of the conduct were intentionally felt
there”, that the offending was centred on Antwerp and that Belgium was the main destination for the
trafficking of the Nigerian women. He found that there was “a wealth of information from which the court
can infer that [the appellant] was knowingly and willingly involved in the offences disclosed rather than
being some naïve or innocent party” and he set out the equivalent offences as follows:

(A)  Human trafficking for exploitation, contrary to section 2 of the **_[Modern Slavery Act 2015 (“MSA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
_[2015”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

(B) Holding a person in slavery, servitude or forced labour, contrary to section 1 MSA 2015.

(C) Facilitating a breach of immigration law by a non-EU citizen, contrary to section 25 of the Immigration
[Act 1091 (“IA 1971”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

(D) Possessing criminal property, contrary to section 329 of the Proceeds of Crime Act 2002 (“POCA
2002”)

(E) Concealing criminal property, contrary to section 327 POCA 2002.

(F) Disguising criminal property, contrary to section 327 POCA 2002.

See paragraph 84 of the District Judge's judgment.

13. The Judge was also satisfied that as regards the offence of participation in a criminal organisation the
conduct disclosed in the EAW and further information supported a finding that the appellant “was involved
in a conspiracy to traffic humans for exploitation and/or a conspiracy to hold persons in servitude and/or a
conspiracy to possess/conceal criminal property” and that such offence or offences would also be
extradition offences: see paragraph 85 of his judgment.

14. Lastly the District Judge considered and dismissed arguments under section 11(1)(aa) and section
12A EA 2003 regarding the absence of a prosecution decision. There is no appeal against his decision in
this respect.

**Issues on this appeal**

15. As indicated at [5] above, the issues arising for my decision are

(i) whether the District Judge was right to find that the EAW contained sufficient particulars as required by
section 2 EA 2003, and

(ii) whether the District Judge was right to find that the requirement of section 64(3) (dual criminality) were
met in respect of each of the six offences A to F set out in the EAW.

**The legal framework – sections 2 and 10 of the EA**

_Section 2 – particulars required_

16. So far as material, section 2 of the EA provides as follows:

**Part 1 warrant and certificate**

(1) This section applies if the designated authority receives a Part 1 warrant in respect of a person.

(2) A Part 1 warrant is an arrest warrant which is issued by a judicial authority of a category 1 territory and
which contains—

(a) the statement referred to in subsection (3) and the information referred to in subsection (4), or


-----

(b) the statement referred to in subsection (5) and the information referred to in subsection (6).

(3) The statement is one that— (a) the person in respect of whom the Part 1 warrant is issued is accused
in the category 1 territory of the commission of an offence specified in the warrant, and - 8 - (b) the Part 1
warrant is issued with a view to his arrest and extradition to the category 1 territory for the purpose of being
prosecuted for the offence.

(4) The information is—

(a) particulars of the person's identity;

(b) particulars of any other warrant issued in the category 1 territory for the person's arrest in respect of the
offence;

(c) particulars of the circumstances in which the person is alleged to have committed the offence, including
the conduct alleged to constitute the offence, the time and place at which he is alleged to have committed
the offence and any provision of the law of the category 1 territory under which the conduct is alleged to
constitute an offence;

(d) particulars of the sentence which may be imposed under the law of the category 1 territory in respect of
the offence if the person is convicted of it.

17. There has been considerable discussion in the cases as to what will suffice to meet the requirements
[of section 2 EA 2003, particularly section 2(4). In Von Der Pahlen v Austria [2006] EWHC 1672 (Admin) at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFV1-DYBP-P0P7-00000-00&context=1519360)

[21] Dyson LJ noted that section 2(4) requires the following: “(1) the conduct alleged to constitute the
offence; (2) the time, and (3) the place at which he is alleged to have committed the offence; and (4) any
provision of law under which the conduct is alleged to constitute an offence.”

18. The warrant in Van der Pahlen alleged three counts of fraud, which the requested person contended,
and the Divisional Court in that case accepted, were insufficiently particularised to meet the requirements
of section 2(4) EA 2003. Dyson LJ explained his reasons for so finding at [22] to [25]:

“22. How far does the warrant have to go? It would be unwise to attempt a prescriptive answer to this
question, and I do not do so. But I am in no doubt that the warrant in this case did not go far enough. In the
first charge, the warrant gave no details of the identity of the victims of the fraud, the number and size of
the advanced payments (except that in aggregate they exceeded €50,000), or the nature of the fraudulent
misrepresentation. Is it alleged that the appellant pretended to sell single family houses when he was in
fact offering something else? Or is it that he pretended to sell single family houses when he was not
offering anything for sale? A similar question arises in relation to the alleged intended arranging for building
contracts, delivery of materials and professional construction works.

23. In the second charge there are similar difficulties. What was the foreign property? How much money
was unjustifiably taken? In answering the charge of obscurity, Ms Ezekiel submits that the whole of this
charge must be read together, and that it contains only one allegation and not two, as suggested by Mr
Summers. It seems to me that this is by no means clear. But what is clear is that the allegation is put on
the basis that there was an obtaining of unjustified monies, dishonestly; or alternatively that the appellant
“had intended to take it”. How those two alternatives are to be understood without any amplification is
totally unclear. No amplification or explanation is provided in the text of the charge.

24. In the third charge, there are similar problems of lack of particularity. As regards the question of clarity,
Ms Ezekiel acknowledges that the language is obscure and suggests that one can make sense of the
charge as a whole by deleting most of the first two and a half lines on the grounds of redundancy. I am
unpersuaded that this is permissible in interpreting the warrant, having regard to the approach of relatively
strict compliance that needs to be adopted, as was explained by Lord Hope.

25. In my judgment, these three charges are too vague, and as regards charges (2) and (3) too obscure, to
satisfy the requirements of section 2(4)(c) of the 2003 Act. As I say, I bear in mind the need for strict
compliance as explained by Lord Hope, and also have regard to the principle of speciality, which is referred
to in Article 27.2 of the Framework Decision.


-----

19. In Ektor v National Public Prosecutor of Holland [2007] EWHC 3106 (Admin) at [7] Cranston J (with
whom Richards LJ agreed) explained the requirement of s.2(4) as follows:

“..the description must include when and where the offence is said to have happened and what
involvement the person names in the warrant had. As with any European instrument, these requirements
must be read in the light of its objectives. A balance must be struck between, in this case, the need on the
one hand for an adequate description to inform the person, and on the other the object of simplifying
extradition procedures. The person sought by the warrant needs to know what offence his is said to have
committed and to have an idea of the nature and extent of the allegations against him in relation to that
offence. The amount of detail may turn on the nature of the offence. Where dual criminality is involved,
the detail must also be sufficient to enable the transposition exercise to take place.”

20. The case of _Dhar v The Netherlands_ [2012] EWHC 697, concerned an accusation warrant alleging
involvement in a money laundering conspiracy involving the proceeds of drug trafficking. The Divisional
Court (Moore-Bick LJ and King J) found that the information failed to identify with sufficient clarity the
requested person's role, including “his knowledge of the suspected drug traffickers or his knowledge that
the funds had been or were to be paid to the drug traffickers (if knowledge on either basis, be the
allegation)” (per Moore-Bick LJ at [77].

_Section 10 – extradition offence_

21. Section 10(2) of the EA requires the judge to determine whether the offence specified in the warrant is
an extradition offence.

22. In relation to accusation warrants, the requirements for determining whether conduct alleged in the
warrant constitutes an extradition offence are to be found in section 64 of the EA. Section 64 provides for
three gateways through which an offence can qualify as an extradition offence, contained in sub-sections
(3), (4) and (5):

**64 Extradition offences: person not sentenced for offence**

…

(3) The conditions in this subsection are that—

(a) the conduct occurs in the category 1 territory;

(b) the conduct would constitute an offence under the law of the relevant part of the United Kingdom if it
occurred in that part of the United Kingdom;

(c) the conduct is punishable under the law of the category 1 territory with imprisonment or another form of
detention for a term of 12 months or a greater punishment.

(4) The conditions in this subsection are that—

(a) the conduct occurs outside the category 1 territory;

(b) in corresponding circumstances equivalent conduct would constitute an extra-territorial offence under
the law of the relevant part of the United Kingdom;

(c) the conduct is punishable under the law of the category 1 territory with imprisonment or another form of
detention for a term of 12 months or a greater punishment.

(5) The conditions in this subsection are that—

(a) the conduct occurs in the category 1 territory;

(b) no part of the conduct occurs in the United Kingdom;

(c) a certificate issued by an appropriate authority of the category 1 territory shows that the conduct falls
within the European framework list;


-----

(d) the certificate shows that the conduct is punishable under the law of the category 1 territory with
imprisonment or another form of detention for a term of 3 years or a greater punishment.

23. As the appellant was arrested prior to 31 December 2020 (after which, following Brexit, section 64(5)
ceased to apply) his case fell to be considered under each of the three gateways. However, in the light of
the District Judge's finding that the conduct occurred in Belgium (at paragraph 84 of his judgment), the
extraterritorial gateway under section 64(4) EA 2003 cannot apply. Mr Ball further accepted that, as the
District Judge found that the appellant operated “in general” from the UK (at paragraph 61 of his judgment),
section 64(5) EA 2003 is also inapplicable. In order to qualify as extradition offences, therefore, each of
offences A-F in the warrant needed to satisfy the requirements of dual criminality pursuant to section 64(3).
This was the approach which the District Judge correctly adopted.

24. I turn now to the individual grounds of appeal

**Ground 1 – whether the warrant is invalid for failing comply with section 2(4)(c)**

25. The warrant alleges six separate offences (A-F) under Belgian law, the material averments being as
follows:

“A. In Brugge and elsewhere in the Belgian kingdom and in Italy and Nigeria…In the period from
September 1st 2018 until the present day

Having infringed [articles and provisions cited] of the Belgian criminal code by having committed the
offence of human trafficking…with the aim to exploit prostitution or other forms of sexual exploitation…

…

Under the circumstance that the criminal activity constitutes participation in the principal or accessory
activity of an association, regardless of whether the offender has a leading position or not.

B. In Brugge and elsewhere in the Belgian kingdom and in Italy and Nigeria. In the period from September
1st 2018 until the present day

Having infringed [articles cited] of the Belgian criminal code by having recruited, impelled, enticed or
retained the services of an adult, even with his/her consent, in order to satisfy the desires of another
person, for the purposes of debauchery or prostitution…

Under the circumstance that the criminal activity constitutes participation in the principal or accessory
activity of an association, regardless of whether the offender has a leading position or not…

C. In Brugge and elsewhere in the Belgian kingdom and in Italy and Nigeria… In the period from
September 1st 2018 until the present day

Having infringed articles 66 of the Belgian criminal code and articles [cited] of the Law of 15 December
1980 on entry, stay, settlement and removal of foreign nationals and found guilty of human trafficking by
helping anyone…a citizen who is not a national of a Member State…to enter or transit the territory of that
State or to reside in it…for direct or indirect financial gain…

…

Under the circumstance that the criminal activity constitutes participation in the principal or accessory
activity of an association, regardless of whether the offender has a leading position or not…

D. Having infringed [articles cited] of the Belgian criminal code by having…possessed, kept or managed
the goods…although the offender was aware or must have been aware of the origin of these goods,
namely yet to be determined amounts of money derived from criminal activities

E. Having infringed [articles cited] of the Belgian criminal code by having converted or transferred the
goods…in order to conceal or disguise their illicit origin…namely yet to be determined amounts of money
derived from criminal activities


-----

F. Having infringed [articles cited] of the Belgian criminal code by having hidden or disguised the nature,
origin, location, positioning, movement or ownership of the goods…although the origin of these goods was
known or should have been known to the offender, namely yet to be determined amounts of money derived
from criminal activities.”

26. The framework list has been marked for offences of participating in a criminal organisation, trafficking
in human beings, laundering the proceeds of crime and facilitation of unauthorised entry and residence.

27. Particulars given in the warrant included the following:

_“The criminal investigation has shown that there are clear indications that the [appellant] is part of a_
_criminal organisation consisting of Nigerian citizens who systematically exploit Nigerian women in forced_
_prostitution and take advantage of the illegal status of the victims. The organisation is mainly operating_
_from Antwerp and from there sexual services are being organised throughout Flanders._

_There are strong indications that [the appellant] is responsible for the organisation of a system that is_
_known as 'Black Western Union'. Money is being sent outside the system of accredited money transmitters_
_and [the accused] gets a certain commission._

_..the persons being suspected of human trafficking [Kabba, Danko and Billo] use this system that was set_
_up by [the appellant] and send money to each other that was obtained by the offence of human trafficking_

_…The investigation has also shown that [the appellant] is responsible for bringing the money from Belgium_
_to Nigeria…_

_[The appellant] talks to [Billo] about obtaining a permanent residence permit…By saying this he shows he_
_is well aware of the difficult situation [Billo] is in. He is also aware of the fact that [Billo] was transferred by_

_[Kabba]._

_There are also serious elements in the investigation indicating that smuggling and trafficking of human_
_beings is made possible between Dubai and Nigeria and [Billo] seems to organise things from Belgium_

_There are indications that [the appellant] is responsible for advancing the money that [Billo] needs and_
_uses in order to finance the offences. The wiretapping and cell phone investigations have shown that [the_
_appellant] assumes that [Billo] cannot pay back the owed money._

_…_

_There are indications that [the appellant] transfers money to a certain [Ivie] on behalf of [Billo] in order to_
_smuggle 'Victoria Williams' from Nigeria to Dubai and to exploit this person in forced prostitution in Dubai”_

28. Further particulars dated 22 January 2021 were provided in response to a request from Westminster
Magistrates Court. The particulars run to 12 pages (in translation, close-typed).  So far as the appellant's
involvement is concerned the further information given in the particulars is helpfully summarised at
paragraph 24 of the Respondent's submissions as follows:

(i) The offences of human smuggling between Nigeria and Belgium were organised by Mariama Kabba:
_Chidinma Billo and Charity Neizena were smuggled to Belgium by Kabba where they had to repay the cost_
_of the journey. Kabba was forced to work as a prostitute under the control of Kabba and Margaret Danko._
_Kabba and Danko provided instructions to the prostitutes and the funds received from prostitution. The_
_requested person's involvement in this offending is proved by financial transactions involving money from_
_prostitution sent to Kabba and Danko._

(ii) _The smuggling of Victoria Williams was organised from Belgium by Chidinma Billo and by and Ivie_
_Ozurumba in Nigeria and Dubai. Williams was forced to work as a prostitute and received instructions from_
_Billo in Belgium by social media and phone. The requested person's involvement in this offending is proved_
_by his involvement in financial transactions through which Billo sent money to Ozurumba to pay for_
_Williams' journey from Nigeria to Dubai where she was forced to work as a prostitute._

(iii) Further detail is provided of the 'Black Western Union' system of money transfers. The money arising
_from the offences is laundered and invested in real property in Nigeria._


-----

(iv) On 6 February 2020 Kabba and Billo were arrested in Antwerp. Kabba's mobile phone was seized. It
_was analysed and WhatsApp messages between Kabba and the requested person showed messages_
_between them regarding money transfers referring to Danko, Constance Billo and others involved in_
_prostitution, between 23 November 2019 and 26 January 2020 (set out in full at pages 2-4 of the further_
_information). The conversations show the requested person's involvement in money transfers between_
_Kabba and Danko, using a shop referred to as 'Dave'. The requested person carried out transactions,_
_provided details of the exchange rate, and told Kabba that she should check her account, referring to_
_Kabba as 'aunt'._

(v) Further analysis of Kabba's phone revealed financial transactions involving the requested person. 135
_text messages provide an overview of transactions where funds were credited and debited by the_
_requested person between 3 and 29 January 2020._

(vi) In relation to the offences of money laundering and facilitating human trafficking, the requested person
_advanced money to Billo to finance these offences. The analysis of conversations between the requested_
_person and Billo show that Billo was late in repaying money advanced to her. The requested person's role_
_in organising and facilitating the smuggling of Victoria Williams is further explained._

(vii) _The further information sets out details of conversations between Billo and the requested person_
_between 26 September 2019 and 24 December 2019 in which they discussed arranging work permits for a_
_person called Rosa and repayment of €1705 that Uhunamure advanced to Billo where the requested_
_person was seeking repayment._

(viii) _The analysis of Billo's phone further evidences the involvement of the requested person in the_
_offending alleged. Specifically, the requested person was in regular contact with Billo by Facebook_
_messenger regarding money transfers the requested person conduct at the request of Billo, discussions_
_regarding exchange rates, the transfer of funds and debts owed by Billo to the requested person. Further_
_analysis of the phone showed WhatsApp conversations between the requested person and Billo regarding_
_sending money to Nigeria in January and February 2019 including a request by Billo on 1 February 2019 to_
_the requested person to transfer 200000 to the Nigerian account of Ivie Ozurumba to buy a plane ticket_
_(being the ticket used by Victoria Williams to travel from Nigeria to Dubai to work as a prostitute there)._

(ix) _On 2 February 2019 Billo asked for the requested person's help 'for the girl that is to be smuggled'_
_(Williams) namely internet research to find and book a plane ticket. Billo sent the requested person a_
_WhatsApp audio message regarding booking this ticket on 2 February 2019. Billo asked the requested_
_person to transfer money to Ozurumba to allow the purchase of a plane ticket to bring Victoria Williams to_
_Dubai from Nigeria. The requested person confirmed that this transaction was done on 4 February 2019._
_On 5 March 2019 the requested person sent instructions to Ivia Ozurumba on where to collect the money._

(x) _On 10 November 2019 Billo asked the requested person to transfer €50 to Kabba's Nigerian bank_
_account which the requested person did. He made a further payment of 10,000 Nigerian Naira in Kabba's_
_Nigerian bank account at the direction of Billo on 3 January 2020. The further information records further_
_messages sent between the requested person and Billo in January 2020 regarding money transfers_
_conducted by the requested person at Billo's request, including sending €150 to Danko's husband on 31_
_January 2020._

(xi) _The police intervention of 6 February 2020, arresting Kabba and Billo stopped the organisation's_
_communication and human trafficking business._

(xii) _The investigations set out in the further information show the requested person's involvement in_
_money laundering. The requested person's mobile phone activity was investigated showing his connection_
_to 10 persons involved in human trafficking or people smuggling or the victims of those offences. On 8_
_February 2020 Ibrahim El Abu called the requested person for 9 seconds. His phone number was part of a_
_text message that the requested person sent Billo on 13 January 2020 also referring to a sum of €630. El_
_Abu's phone activity was also analysed showing contact with others involved in the alleged offending._

(xiii) _On 30 December 2019 Sarah Eghharevba spoke to Billo. They discussed the requested person's_
_involvement in facilitating sending and receiving money Egharevba discussed collecting money from a girl_


-----

_referred to as 'Joy' to send on to the requested person. They discuss transaction fees and that the_
_requested person 'can enjoy his money thanks to the girls, that the requested person collected money from_
_the girls and started a business and that he collected money in Belgium. The requested person asked Billo_
_to drop off this money in Dave's shop when she is in town._

(xiv) _Finally, analysis of the requested person's social media accounts shows that he is following Billo,_
_Magret Danko and others including Loveth Emmanuel who was an escort controlled by Kabba._

29. The District Judge found that the warrant satisfied the requirements of section 2 EA 2003. His
reasoning is to be found at paragraphs 55-64 of his judgment, with conclusions as follows:

“55. The conduct alleged is that of a criminal organisation of Nigerian citizens (including Mr Uhunamure,
who was born in Nigeria), systematically exploiting Nigerian women in forced prostitution. It is clear that the
organisation as a whole uses moral and financial coercion on the women involved in order to have them do
what they want. It is clear that the enterprise is concerned with earning money from prostitution…The
women are controlled by KABBA and DANKO.

56. Mr Uhunamure's role is shown to be the transfer of monies either facilitating the enterprise or earned
from it, through a system called “Black Western Union”. Mr Uhunamure receives commission. Mr
Uhunamure is alleged to be in direct contact with those directly involved with the human trafficking of
women for prostitution (KABBA, DANKO and BILLO). There is a wealth of material showing direct contact
between Mr Uhunamure and these individuals. Some of his direct contacts are shown by mobile phone
and social media evidence. Ten of Mr Uhunamure's Belgian contacts on his phone can be linked to human
trafficking or people smuggling offences. Mr Uhunamure is also connected to others connected to human
trafficking, such as EL ABU, EGHAREVBA and EMMANUEL. He advances money to BILLO in order to
finance the offences. Money from performed escort services is sent to KABBA and DANKO. Some of Mr
Uhunamure's conduct includes the direct transportation of money from Belgium to Nigeria, Monies arising
from the offences is being laundered. Some is invested in real estate in Nigeria.

…

59…In summary, the EAW details a criminal organisation exploiting Nigerian women for the purposes of
prostitution, trafficking them out of Nigeria and using coercion to make them work as prostitutes. The
criminal organisation thereby profits from these activities. Mr Uhunamure is an integral part of the
organisation, providing the means by which monies to facilitate the enterprise is transferred and then
transferring the profits of the enterprise. Mr Uhunamure also provides advice to those more directly
involved with the exploitation. As with any conspiracy, different participants have different roles within the
enterprise.”

The District Judge went on to deal with each of the specific offences A to F finding, in relation to each of A
to C that the appellant was “a participant in that offence”, and, in relation to the money laundering offences
D to F that the appellant was directly involved in receiving, possessing, handling and transferring proceeds
of illegal prostitution and trafficking.

_[Arguments on section 2 EA 2003](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1GP-00000-00&context=1519360)_

30. Mr Stansfeld's main objection concerned the absence of any and/or any sufficient particularisation of
knowledge by the appellant of the underlying offending. He argued that when a person is sought, as the
appellant is here, on matters which require them to have certain knowledge, then on the authority of Dhar it
is necessary for the warrant to include information which identifies why it is said that the person had the
requisite knowledge. Since it is not alleged that the appellant, who on the District Judge's findings
operated mainly from the UK, was himself responsible for trafficking Nigerian women into Belgium/Dubai,
coercing them into prostitution or collecting their earnings from them, then his involvement as an alleged
conspirator to those offences, or as a person assisting or encouraging their commission, could only arise if
he is shown to have made/received payments through his money transfer system knowing and intending
that the underlying offences be carried out by others.


-----

31. Dealing specifically with offences A and B, Mr Stansfeld pointed out that, as indicated by the further
evidence concerning the trial which has now taken place in Belgium, the prosecution based its case at trial
against the appellant solely on activities of trafficking and coercion in relation to one victim, VW, who was
taken from Nigeria to Dubai. According to the particulars, Billo arranged for VW to be transferred to Dubai
in the company of another woman, Ivie. Mr Stansfeld points out that although the further information
details a telephone call between the appellant and Billo concerning a flight from Nigeria to Dubai, there is
nothing to indicate how it is said that the appellant did so as a conspirator to the trafficking of VW, knowing
and intending that VW would be taken to Dubai and there coerced into working as a prostitute.

32. As to Offence C, Mr Stansfeld indicated that according to the further information provided about the
trial in Belgium, the appellant was not himself proceeded against for this offence at trial, suggesting that the
respondent does not consider that it has a case implicating the appellant in smuggling persons into
Belgium in breach of immigration control. In any event, he submitted, the particulars do not allege any link
between money receipts/transfers made by the appellant with the activity of bringing any persons (Billo and
Neizena being the only persons named) into Europe illegally.

33. Mr Stansfeld criticised Offences D to E for a lack of particulars of knowledge, also on the basis that it
was impossible to differentiate the activity underlying each separate money laundering offence.

34. Mr Ball responded by noting that the Belgian offences A to C simply allege participation as a principal
or accessory, with no specific requirement for knowledge; all that the Judicial Authority has to provide is
adequate particulars to allow the appellant to see and understand the allegation that he has been
implicated in trafficking conduct.

35. However, to the extent that it was necessary for the purposes of section 2(4)(c) to particularise
knowledge of the predicate offending - which Mr Ball resisted, saying that this was a matter for s.10 dual
criminality only – then he submitted that there was ample evidence from which to infer that the appellant
had such knowledge. He relied on six separate matters arising from the warrant and further information as
follows:

(1) The entire purpose of the “Black Western Union” set up by the appellant was to have an “off-books”
system unknown to the authorities, operating outside any routine supervisory or regulatory control.

(2) The particulars disclose extensive conversations between the appellant and key figures central to the
trafficking/prostitution enterprise, in particular Kabba and Danko.

(3) The respondent has alleged that the appellant was not only involved in the laundering of profits but
also that he facilitated human trafficking and smuggling.

(4) There were not just extensive conversations with key figures in the trafficking ring, the appellant also
had 10 contacts stored on his phone of people known to be linked to other trafficking activity. One of those
contacts, El Abu Ibrahim, was a particularly significant figure in trafficking circles, as indicated by the nature
of 14 contacts found on his phone.

(5) The information given includes a conversation between Billo and another woman, Sarah Egharevba,
referring to the appellant as a wealthy man “thanks to the girls”, that he collected money from the girls and
started a business and also that he collected money in Belgium. Messages between the appellant and Billo
refer to his asking her to drop money off at “Dave's shop” when she is in town.

(6) Finally, Mr Ball pointed to information indicating that the appellant used coded language when
speaking about money, referring to transfers of “it” and “the thing” when speaking to Billo. Mr Ball
suggested that the appellant spoke guardedly because he knew that Billo was involved in trafficking and
making money from prostitution, and that he was facilitating this through his illegitimate transfer system.

36. As to the point made concerning the appellant's trial and conviction solely in relation to offences
concerning the trafficking by Billo of VW to Dubai, Mr Ball responded that the warrant sought the
appellant's return for the more general offence of facilitating trafficking and prostitution by a number of
defendants in Belgium, even though the trial in Belgium eventually proceeded on the narrower basis of his


-----

involvement in the specific offence concerning the trafficking of VW. The fact that proceedings in Belgium
were limited in that way could not render the warrant deficient under section 2 EA 2003.

_Analysis and decision_

37. The authorities to which I have been referred establish the following:

(1) Warrants are not to be read as indictments or civil pleadings. The need for simplicity in extradition has
to be balanced against the requirement for a requested person to understand what offences they are being
sought for and what conduct on their part is said to amount to those offences: von der Pahlen, Ektor.

(2) The fact that the particulars would sufficiently enable the requested person to identify any possible bars
to extradition cannot of itself demonstrate satisfactory compliance with the requirement under section
2(4)(c); on the other hand if the particulars lack sufficient details to enable any bars to be identified, or to
enable specialty arguments to be made on return, then the warrant would be defective without more: King
_v Public Prosecutors of Villefranch sur Saone, France [2015] EWHC 3670 (Admin) ._

(3) The extent to which particulars are required will vary from case to case, depending upon what
offence(s) are alleged: Ektor.

(4) Where knowledge of particular facts or matters forms part of the offence for which the requested
person's return is sought, then the information provided should contain sufficient detail of the basis upon
which it is alleged that the requested person had such knowledge: Dhar.

38. It is not a complete answer to a complaint about particularity to say that the particulars are sufficient to
enable a requested person to identify any bars, as Mr Ball accepted, but it is also relevant to note that the
appellant has not pointed to any prejudice which he might experience here or in Belgium by reason of any
deficiency said by Mr Stansfeld to exist in the particulars which have been given.

39. Since much of Mr Stansfeld's argument focused on a requirement to establish knowledge, by
reference to the authority of Dhar, it is necessary to examine that case in more detail. The appeal in Dhar
was heard and considered by a Divisional Court (Moore-Bick LJ and King J) and concerned a EAW issued
by a court in The Netherlands relating to a single offence of involvement in a money laundering conspiracy.
At [73] King J referred to the description of the offence under the relevant provisions of the Dutch Criminal
Code given in the warrant:

“..under Dutch law a person is considered guilty of the offence of “money laundering” if he, amongst other
things, (a) hides or conceals the real nature of an object, while knowing that this object directly or indirectly
originates from an offence or (b) acquires possesses transfers or turns over or uses an object, _while_
_knowing that this object directly or indirectly originates from an offence.” (my emphasis)_

40. At [76] to [77] King J sets out the submissions made on behalf of the requested person in that case as
to the ambiguity and lack of clarity in the particulars given concerning the conduct said to amount to the
offence. The essence of his conclusion that the warrant in Dhar was deficient is to be found at [81]

“The Appellant is entitled in my judgment to sufficient particulars to enable him to understand how the case
is being put against him on critical allegations without that understanding being obscured by the fog of
vagueness or ambiguity. The respondent has chosen in the EAW to make what in my judgment, looking at
the particulars as a whole, is a critical allegation in the conduct alleged to amount to the offence of money
laundering, namely the appellant “received funds within the United Kingdom that were paid to suspected
drug traffickers in the Netherlands by Singh”. The appellant's understanding of that allegation must be
wholly disabled in my judgment by the ambiguity to which Mr Farrell referred and which is discussed
above, and the lack of clarity of what it is the appellant is supposed to have done in this regard. Whether
the funds were received by the appellant before or after they were paid to the suspected drug traffickers,
how he is said to have received them and from whom, and the role if any which the appellant is supposed
to have played in facilitating that payment, must be of considerable importance to any understanding of the
role the appellant is supposed to have played in the alleged conspiracy” (emphasis in original)

King J went on to observe at [83]:


-----

“It may be that in a different case here conspiracy is alleged, it may not matter that one particular piece of
conduct relied upon in support of the allegation that the Requested Person played a certain role in that
conspiracy, is obscure and ambiguous, when the overall clarity of the allegation made against the appellant
as to the nature and extent of his role is made good by particulars of other pieces of conduct relied on. But
this is not the case here…”

41. In his judgment Moore-Bick LJ added these further observations, at [116]-[117]:

“116. [referring to the description of conduct given in the warrant] This information certainly leaves no
doubt about the suspicions of the Dutch authorities, but it does not make it at all clear what the appellant is
said to have done by way of handling the proceeds of crime or engaging in money laundering. The
allegation that he received loans from Singh is consistent with involvement with Hawalla banking, but does
not indicate involvement in handling the proceeds of crime. The allegation that the appellant received
funds in the United Kingdom that were paid to suspected drugs traffickers in The Netherlands by Singh is
ambiguous: it could mean that he received funds that Singh had paid to suspected drugs traffickers
(which, if true, would render them proceeds of crime) or, as I think more likely, that he received funds in
this country that were then transferred to Singh in The Netherlands, who in turn paid them to suspected
drugs traffickers. If the latter is intended, it does not follow that the funds the appellant received were
themselves the proceeds of crime or, if they were, that he knew it.

117. Although I accept that the warrant need not contain highly detailed information of the kind that one
might expect to find in a civil pleading, it must contain enough information to enable the requested person
to understand with a reasonable degree of certainty the substance of the allegations against him, namely,
what he is said to have done, when and where, and also, in a case where knowledge of particular matters
is an essential ingredient of the offence, sufficient information to enable him to understand why it is said
that he had the necessary knowledge. In the present case I do not think that the warrant satisfies these
requirements because the information given in it fails to make it reasonably clear what the appellant is said
to have done by way of handling property that was, and that he knew was, the proceeds of crime.”

42. It is apparent from a detailed consideration of the reasoning in Dhar that the court was there
concerned about a lack of clarity surrounding the receipt/payment of monies by the appellant in that case.
There is not at all the same lack of clarity here. As the District Judge rightly observed, it is plain from the
warrant and further information what activities are said to have generated monies sent to the appellant and
for the facilitation of which he provided funds through his money transfer system.

43. I agree with Mr Ball's primary contention that, at least for the purposes of satisfying section 2(4)(c) EA
2003, it is unnecessary for the warrant and further information to have provided details of knowledge in
relation to the allegation of participation in, or being an accessory to, an enterprise involving trafficking
(Offence A), forced prostitution (Offence B) or illegal immigration into a Member state (Offence C). That
said, I note the reference in Offence A to transporting persons “with the aim to exploit..”, which suggests an
element of knowledge. To the extent that it may be necessary to provide particulars of the appellant's
knowledge of the underlying offending then in my view these sufficiently arise from the matters relied on by
Mr Ball and set out at [35] above.

44. The position is different so far as the money laundering offences D to F are concerned, since the
description of the offence in each case includes some reference to knowledge on the part of the appellant:

“…the offender was aware or must have been aware of the origin of these goods…” (Offence D)

“..in order to conceal or disguise their illicit origin…” (Offence E)

“…although the origin of these goods was known or should have been known to the offender..” (Offence F)

45. In relation to these offences there is a requirement for the particulars to disclose the basis for the
allegation of knowledge/awareness, as indicated in Dhar. However in my view the matters to which Mr Ball
referred, at [35] above, taken together sufficiently provide the necessary particularity.

46. It follows that in my view the District Judge rightly decided that the warrant and particulars provide
sufficient detail of the offending This is not a case where as in Dhar there is any ambiguity or lack of


-----

clarity in what the appellant is said to have done. The case against him is clear: his involvement is said to
have been as the provider of funds, through his under-the-counter money transfer service, for the
movement of young women from Nigeria into Belgium/Dubai and thereafter for the receipt and laundering
of the proceeds of their forced prostitution. Women trafficked to Belgium were there illegally, thus a breach
of immigration control (Offence C) was an integral part of the trafficking conspiracy. The individuals
primarily responsible for organising the trafficking and prostitution used the appellant's money transfer
service both to obtain and pay funds required to traffic the woman from Nigeria and also to “bank” and
distribute the proceeds derived from putting those women to work as prostitutes.

47. As all the cases emphasise, there is no requirement to set out in the warrant the evidence by which
the particularised conduct is to be established against the requested person at trial. As it happens, in this
case a great deal of the evidence was canvassed in the first Further Information, moreover it is apparent
from the further evidence that the respondent restricted its case against the appellant at trial on Offences A
and B to the trafficking/forced prostitution of VW. In doing so, the respondent presumably took a view on
the (in)sufficiency of the evidence against the appellant regarding his involvement in a wider enterprise, but
that is immaterial for the purposes of considering whether the requirements of section 2(4)(c) are satisfied
in respect of the warrant as drafted.

**Ground 2 – does the warrant satisfy the requirement under s.10 of dual criminality?**

48. Although the respondent had initially sought to argue that the requirement under section 10 EA 2003
for the offences to qualify as extradition offences could be met through the application of section 64(4) as
well as section 64(3) EA 2003, by the time of the hearing Mr Ball accepted that the circumstances of this
case required the respondent to satisfy the requirements of section 64(3). Section 63(3) EA 2003 requires
the respondent to show that conduct occurring in Belgium would constitute an offence if it occurred in the
UK – the requirement of dual criminality.

49. For convenience, I shall summarise the arguments and express my conclusions in relation to each of
the offences separately.

_Offence A_

50. The District Judge found that the equivalent offence in this jurisdiction was human trafficking for
exploitation under s.2 MSA 2015. That section provides as follows:

**“2 Human trafficking**

(1)  A person commits an offence if the person arranges or facilitates the travel of another person (“V”)
with a view to V being exploited.

(2) It is irrelevant whether V consents to the travel (wither V is an adult or a child)

(3) A person may in particular arrange or facilitate V's travel by recruiting V, transporting or transferring V,
harbouring or receiving V, or transferring or exchanging control over V.

(4) A person arranges or facilitates V's travel with a view to V being exploited only if
(a)  The person intends to exploit V (in any part of the world) during or after the travel, or

(b)  The person knows or ought to know that another person is likely to exploit V (in any part of the world)
during or after the travel.

(5) “Travel” means
(a)  arriving in, or entering, any country,

(b)  departing from any country,

(c)  travelling within any country.

(6) A person who is a UK national commits an offence under this section regardless of
( ) h th i f ilit ti t k l


-----

(b) where the travel takes place.

(7) A person who is not a UK national commits an offence under this section if
(a)  any part of the arranging or facilitating takes place in the United Kingdom, or

(b)  the travel consists of arrival in or entry into, departure from, or travel within, the United Kingdom.”

51. When considering dual criminality is it necessary to transpose the requirements of the section by
applying it as if in the relevant requesting state, in this case by reading Belgium in place of the UK: see
section 64(3)(b) EA 2003.

52. Mr Stansfeld argued that section 2(7) MSA could not apply here, in circumstances where the judicial
authority has only actually proceeded against the appellant in relation to the trafficking by Billo of VW from
Nigeria to Dubai. He submitted that there was nothing in the EAW making a case that the appellant
arranged or facilitated VW's transfer to Dubai, further nothing to indicate where Billo was at the time of
telephoning to him about the flight or about making arrangements to transfer money to pay for the tickets.
Since VW did not enter Belgium then sub-section (7)(b) was of no application. As to subsection (7)(a),
there was no evidence of any part of the arranging or facilitation taking place in Belgium. Thus dual
criminality, applying the (transposed) requirements of section 2(7) could not be made out. Even if it were
to be accepted that the appellant was part of a wider conspiracy operating through Belgium then in that
case the appellant's knowledge of the underlying offending had to be shown. In the absence of any
indication in the Belgian offence as to the degree of knowledge required, then knowledge had to be
established as an inevitable or necessary inference from the alleged facts, Mr Stansfeld referred me in this
respect to the case of Cleveland v. United States [2019] 1 WLR 4392.

53. I understood Mr Ball to confirm in argument at the hearing that the respondent seeks the return of the
appellant in relation to Offences A and B only insofar as they concern the trafficking of VW into Dubai. Mr
Ball pointed to the District Judge's conclusion that Billo “who resides in Belgium” played a key role in
organising the offences involving VW. He submitted that Billo's location in Belgium, together with the
appellant's facilitation of her criminal activity there, sufficiently satisfies the requirements of section 2(7)(a)
MSA 2015, when considering those requirements as transposed from the UK to Belgium.

54. Regarding knowledge, Mr Ball relied on the matters summarised at 34-36 above.

55. Referring to Cleveland, Mr Ball argued that the higher test of inevitable inference was not required, but
even if it was then it was satisfied on the facts as set out in the warrant and further information, in particular
the matters referred to above.

_Conclusion – Offence A_

56. The case of Cleveland concerned an application for extradition by a court in the United States on a
charge of murder and associated offences in relation to a shooting, where the requested person's
involvement was said to have been as an accessory. The issue of dual criminality raised the mental
element required for accessory liability to murder in this jurisdiction and the extent to which the warrant had
addressed that requirement. It was argued on behalf of the requested person that the higher requirement
of the facts “impelling” an inference of knowledge, discussed by the Divisional Court in Assange v. Swedish
_Prosecution Authority_ [2011] EWHC 2849, applied. Holgate J, with whose judgment Leggatt LJ agreed,
first reviewed the decision of the House of Lords in Norris v Government of the United States of America

_[2008] UKHL 16, pointing out that separate legal issues arose in relation to different offences on the US_
indictment. In relation to count 1 of that indictment, which alleged a strict liability offence, the House of
Lords held that the US offence lacked a legal ingredient essential to establishing criminal liability under
English law and that, in consequence, the dual criminality requirement could not be satisfied. But in
relation to the other counts on the indictment, the correct approach to dual criminality involved examining
the overall conduct alleged as a whole, to see whether it fell within the scope of an English offence.

57. Turning next to Assange, Holgate J emphasised that when read in context, the higher test referred to
by the court at paragraph 57 in Assange was not authority for a general proposition that when considering
d l i i lit th t l l t i d d E li h l ld l b i f d h th f t


-----

“impelled” such an inference, or where it was the only reasonable inference that could be drawn. Assange
concerned an allegation of rape where the Swedish offence did not specify the element of absence of
reasonable belief in consent, as required under English law. Holgate J explained the distinction as follows,
at [59]:

“The rationale for the Divisional Court's insistence upon the “inevitability” test is clear and delimits the
circumstances in which it is proper for that test to be applied by the court. Where the offence in a foreign
state does not include an element (eg mens rea) essential to establishing criminal liability under English
law, that element may be inferred provided that it is an inevitable corollary of, or necessarily implied from,
the conduct which will have to be established in that foreign jurisdiction. Plainly where an essential
ingredient under English law is absent from the alleged foreign offence, dual criminality can only be
satisfied by insisting on that test, rather than by being satisfied that the inference is one which _could or_
_might be drawn; otherwise a person could be convicted in a foreign court for something that would not be a_
criminal offence in this jurisdiction.”

Holgate J went on to distinguish the situation where the argument is not that the foreign offence lacks an
ingredient necessary to criminality in this jurisdiction, but simply that the particulars of conduct provided do
not address an ingredient of an equivalent English offence. Applying this distinction to a consideration of
the mental element of an offence he said this, at [62]-[63]:

“62…The offence alleged may require proof of a simple intent to commit that crime and the equivalent
English offence may not require the proof of any additional specific intent. In this country proof of intention
depends in most cases upon the drawing of inferences by the jury (or by the magistrates' court)… In this
situation there is no “gap” in the mental element of the foreign offence which needs to be filled. The mere
fact that intention would need to be inferred from conduct in order to establish guilt in any future trial in the
foreign court, does not justify the imposition of an “inevitable inference” test in order to satisfy dual
criminality at the extradition stage. Instead, where this issue is raised, the court need only consider
whether the inference of intention is one which is capable of being drawn from the matters alleged, leaving
the question of whether that inference will be established to the trial process.

63. But in some instances, extradition may be resisted because the English equivalent offence requires
proof of a specific intent (eg dishonesty or knowledge of or belief in a state of affairs), whereas the foreign
offence for which extradition is sought only requires proof of a simply intent and not also that specific intent.
In that situation it is necessary for the court to apply the test in para 57 of Assange's case to decide
whether that gap in the ingredients of the foreign offence can be filled by drawing an inference from other
matters set out in the warrant or extradition request. Here, dual criminality depends upon the court being
satisfied that, if the matters constituting the alleged foreign offence were to be proved, the inevitable or only
reasonable inference would be that the additional intent required by English law would also be
established.”

58. I am satisfied that there is sufficient to demonstrate that the conduct in respect of the trafficking of VW
to Dubai comes within section 2(7) MSA 2015. As Mr Ball pointed out, the District Judge found that Billo
resided in Belgium; it follows that her acts in arranging for VW to be taken from Nigeria to Dubai to be
exploited as a prostitute there were undertaken in Belgium, which acts would be indictable under section 2
MSA 2015 if committed in the UK. The case against the appellant is that he facilitated the transfer of VW
by investigating the plane ticket and by transferring the money used to obtain that ticket, in essence by
assisting Billo in trafficking VW; her part in the criminal activity (which he facilitated) took place in Belgium,
and that is sufficient for the purposes of the (transposed) offence under section 2 MSA 2015.

59. Section 2(4) MSA contains the mental element required to be proved for the offence, namely an
intention to exploit the trafficked victim, or knowledge that another person is likely to exploit the trafficked
victim. Mr Stansfeld argued that since the warrant in this case is silent as to the mental element required
for Offence A, then the stricter test discussed in _Assange must be applied. But I disagree that the_
description of the offence in the warrant is silent on the question of the mental element, since it alleges that
the trafficking has been committed _“with the aim to exploit prostitution or other form of sexual_
_exploitation…” (my emphasis). It follows that, at least so far as Offence A is concerned, there is no lack of_


-----

an ingredient essential to criminality in this jurisdiction. The ordinary test set out in Norris applies, namely
whether the overall conduct alleged would amount to an offence under English law. In my view, taking into
account the matters going to knowledge identified by Mr Ball, there is sufficient to establish that the
appellant's conduct, if committed in the UK, would amount to an offence under section 2 MSA. Properly
viewed, Mr Stansfeld's criticisms in relation to Offence A go to the level of evidential support for the
appellant's knowledge of VWs travel to Dubai and the purpose for which she was going there, rather than
to the issue of whether the request has identified an offence known to English law.

_Offence B_

60. I remind myself, once again, of Mr Ball's concession made at the hearing that Offences A and B relate
only to the trafficking of VW from Nigeria to Dubai. As Mr Ball put it during submissions, Offence B
involves recruiting VW into prostitution using coercion. The District Judge found that the conduct under
Offence B would constitute an offence under s.1 MSA, however Mr Ball also suggested that it could
amount to an offence under section 2 MSA.

61. Mr Stansfeld pointed out that the warrant and further information give very few particulars of the
conduct complained of, but argued that any coercion of VW must have occurred either in Nigeria or (more
probably) Dubai; in any event her coercion could not have taken place in Belgium since VW was not
trafficked to Belgium but to Dubai. This being so then section 1 MSA cannot apply since that section deals
exclusively with conduct inside the UK. Transposing this to Belgium, then for dual criminality to be
established under section 1 MSA the coercion of VW would have had to have taken place in Belgium,
which it plainly did not. Mr Stansfeld went on to argue that section 2 MSA 2015 could not serve for the
purposes of establishing dual criminality since acts of coercion do not fall within that section. The Belgian
offence as described under Offence B is one of coercion, of forcing a person (here VW) into prostitution,
not one of trafficking a person somewhere for that purpose. Accordingly, Mr Stansfeld argued, the alleged
conduct (to the extent that the warrant and further information went so far as to allege any coercive
conduct in relation to VW) could not amount to an offence under section 2(7), whether as principal or as
accessory.

62. No doubt because he appreciated the force of Mr Stansfeld's points summarised above, and in an
effort to deal with them, Mr Ball embarked on an elaborate discussion of an offence of conspiracy to
commit an offence under section 1 MSA outside the jurisdiction, applying the provisions of section 1A
[Criminal Law Act 1977 (“CLA 1977”). That section provides as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)

**“1A –conspiracy to commit offences outside England and Wales**

(1)  Where each of the following conditions is satisfied in the case of an agreement, this Part of this Act
has effect in relation to the agreement as it has effect in relation to an agreement falling within section 1(1)
above.

(2) The first condition is that the pursuit of the agreed course of conduct would at some stage involve—

(a) an act by one or more of the parties, or

(b) the happening of some other event,

intended to take place in a country or territory outside England and Wales.

(3) The second condition is that that act or other event constitutes an offence under the law in force in that
country or territory.

(4) The third condition is that the agreement would fall within section 1(1) above as an agreement relating
to the commission of an offence but for the fact that the offence would not be an offence triable in England
and Wales if committed in accordance with the parties' intentions.

(5) The fourth condition is that—

(a) a party to the agreement, or a party's agent, did anything in England and Wales in relation to the
agreement before its formation, or


-----

(b)a party to the agreement became a party in England and Wales (by joining it either in person or through
an agent), or

(c)a party to the agreement, or a party's agent, did or omitted anything in England and Wales in pursuance
of the agreement.

(6) In the application of this Part of this Act to an agreement in the case of which each of the above
conditions is satisfied, a reference to an offence is to be read as a reference to what would be the offence
in question but for the fact that it is not an offence triable in England and Wales.

(7) Conduct punishable under the law in force in any country or territory is an offence under that law for
the purposes of this section, however it is described in that law.

(8) Subject to subsection (9) below, the second condition is to be taken to be satisfied unless, not later
than rules of court may provide, the defence serve on the prosecution a notice—

(a) stating that, on the facts as alleged with respect to the agreed course of conduct, the condition is not in
their opinion satisfied,

(b) showing their grounds for that opinion, and

(c) requiring the prosecution to show that it is satisfied.

(9) The court may permit the defence to require the prosecution to show that the second condition is
satisfied without the prior service of a notice under subsection (8) above.

(10) In the Crown Court the question whether the second condition is satisfied shall be decided by the
judge alone, and shall be treated as a question of law for the purposes of—

(a) section 9(3) of the Criminal Justice Act 1987 (preparatory hearing in fraud cases), and

(b) section 31(3) of the Criminal Procedure and Investigations Act 1996 (preparatory hearing in other
cases).

(11) Any act done by means of a message (however communicated) is to be treated for the purposes of
the fourth condition as done in England and Wales if the message is sent or received in England and
Wales.

(12) In any proceedings in respect of an offence triable by virtue of this section, it is immaterial to guilt
whether or not the accused was a British citizen at the time of any act or other event proof of which is
required for conviction of the offence.

(13) References in any enactment, instrument or document (except those in this Part of this Act) to an
offence of conspiracy to commit an offence include an offence triable in England and Wales as such a
conspiracy by virtue of this section (without prejudice to subsection (6) above).”

63. Mr Ball submitted that when considering Billo's actions in relation to VW as if they had taken place in
the UK, then each of the four conditions set out in subsections (2) to (5) are met such that the requirement
of dual criminality is satisfied. The first condition was met since the coercion of VW into prostitution was to
take place in Dubai, outside Belgium (transposing the UK to Belgium for these purposes). As to the
second condition, Mr Ball submitted that the phrase “under the law in force in that country” in subsection
(3) is to be read (when transposed) as referring to Belgian law. The third and fourth conditions were met
by reason of the fact that Billo, as a party to the conspiracy, was acting in Belgium and that the conduct
would be an offence under section 1 MSA if it had occurred here.

64. Mr Stansfeld accepted that the first of the conditions set out in section 1A CLA 1977 was met. But he
submitted that the second condition, in subsection (3), was not. He argued that the phrase “under the law
in that country” in subsection (3) referred to the law in Dubai/Nigeria, since the act(s) of coercion of VW
must of necessity have occurred in one or other of those places. It was for the respondent to prove what
the law is in those countries and it had not done so. Further, Mr Stansfeld argued that the fourth condition
was not met, since Billo (based in Belgium) had done no acts of coercion there. For these reasons section
1A CLA 1977 ld t il th d t b ti 1 MSA i t t t it i l ff


-----

65. Mr Stansfeld also relied on a missing mental element in the description of the Belgian offence. He
argued that whether seen as an offence of conspiracy to commit an offence under section 1 MSA, or as an
offence of assisting the commission of an offence under that section, the equivalent offence in this
jurisdiction requires proof of knowledge of an intention to commit the underlying offence. The Belgian
offence as described under Offence B in the warrant is silent as to any mental element, thus the Assange
test of “inevitable inference” applies. Mr Stansfeld pointed out that so far from there being sufficient
information to give rise to the inevitable inference that the appellant knew and intended that VW was to be
coerced into prostitution in Dubai, the paucity of information directed to the circumstances of VW's
trafficking and his knowledge of it did not even reach the lower standard of an inference of knowledge of
coercion being capable of being drawn.

_Conclusions – Offence B_

66. I have concluded that requirement of dual criminality is not satisfied as regards Offence B. The main
objection is that the conduct element of the offence as it is now restricted – namely the coercion of VW into
prostitution in Dubai – has not been shown to constitute an offence in this jurisdiction. Section 2 MSA
2015, which covers extraterritorial conduct, does not apply since that section deals with recruitment and
travel for the purposes of exploitation; it is not apt to cover acts of coercion forcing a person into
prostitution. Such conduct is covered by section 1 MSA, but only where it occurs within the UK or, when
transposed for consideration in this case, in Belgium. Conduct occurring in Dubai does not qualify.

67. Mr Ball's ingenious argument on conspiracy, applying section 1A CLA 1977, cannot avail him either,
since I agree with Mr Stansfeld that the phrase “under the law in that country..” is a reference to the law of
the country where the intended conduct/event has occurred or is to occur. Transposition cannot call for the
phrase to refer to the law of Belgium, as Mr Ball suggested, or the ordinary application of the second
condition would refer to the law of England and Wales, which would make no sense; the phrase is clearly
intended to refer back to the first condition, dealing with an event taking place “in a country or territory
outside England and Wales”.  The transposition exercise leaves the operation of this and the (related)
second condition unaffected. In the present case the conduct of coercion of VW into prostitution must
necessarily have occurred in Dubai/Nigeria, so that satisfaction of the second condition set out in section
1A CLA would require the respondent to show that the conduct was unlawful in one or other of those
countries.  Since the respondent has produced nothing directed at this point, the conditions under section
1A CLA 1977 cannot be met. I also agree with Mr Stansfeld that the fourth condition is not met in
circumstances where, although Billo was resident in Belgium, there is nothing to suggest that she did
anything in that country to force VW into prostitution in Nigeria/Dubai.

68. Having decided that the conduct requirement for dual criminality is not met it is unnecessary to reach a
final view on the arguments concerning any mental element and the correct test to be applied. I incline to
the view that the arguments fall within the distinction discussed by Holgate J in _Cleveland at [62]-[63] to_
which I refer above. Properly understood, the issue is not whether the Belgian offence lacks a specific
mental element necessary to the English offence, but that the particulars given in respect of VW have
failed to establish the necessary mental element required.

_Offence C_

69. Mr Stansfeld's primary objection concerning Offence C is that the appellant has not in fact been
prosecuted or tried for this offence. As indicated in the second further information and in the additional
evidence, a trial has taken place in the appellant's absence in which he was not proceeded against for an
immigration offence as described under Offence C. In those circumstances, Mr Stansfeld suggested, the
respondent should have withdrawn its case for extradition on this offence, yet it has not. Mr Stansfeld
accepted that he was not entitled to pursue an abuse argument, leave to appeal having been refused on
this ground, nevertheless he emphasised that the decision not the try the appellant in Belgium supported
his case that the particulars disclose no identifiable extradition offence.

70. The District Judge concluded that Offence C equated to an offence contrary to section 25 of the IA
1971. Mr Stansfeld criticised the particulars for insufficiently linking the appellant to conduct by others in


-----

breaching immigration law. But even if the conduct requirement is made out, he argued, then there was
insufficient to establish the necessary mental element, of knowledge of the underlying offending. In
relation to knowledge, Mr Stansfeld reiterated that the Belgian offence is silent as to any mental element,
whilst the offence under section 25 IA 1971 requires the prosecution to demonstrate that a defendant
“knows or has reasonable cause for believing that the act facilitates the commission of a breach of
immigration law” and that (s)he “knows or has reasonable cause for believing that the individual is not a
citizen of the European Union”. The Belgian offence being silent on the question of knowledge, then the
stricter “inevitable inference” test is to be applied.

71. Mr Ball accepted that the Belgian court had not proceeded against the appellant on the immigration
offence set out in Offence C. Nevertheless, he argued, that did not preclude the respondent from seeking
the appellant's return if the requirements under s.2 and s.10 EA are satisfied. Whilst the respondent
obviously could not rely on the movement of VW into Dubai for a breach of EU immigration law, he argued
that the particulars sufficiently set out a case that the appellant assisted Kabba in bringing Neizena and
Billo into Belgium. Billo started as a victim, though she progressed to becoming a perpetrator. The case
made in the warrant and particulars establishes that the appellant assisted Kabba in bringing Billo to
Belgium and that he knew she was there illegally. Thus the appellant knowingly facilitated breaches of
immigration law at least in relation to Billo.

_Conclusion – Offence C_

72. In view of the respondent's decision as to the actual offences for which the appellant was to be
prosecuted, and has been tried, any decision as regards Offence C is probably academic. Nevertheless, I
am satisfied that the dual criminality requirement is met as regards this offence.

73. Section 25(1) IA 1971 provides as follows:

“(1) A person commits an offence if he
(a) does an act which facilitates the commission of a breach or attempted breach of immigration lay by an
individual who is not a citizen of the European Union,

(b) knows or has reasonable cause for believing that the act facilitates the commission of a breach or
attempted breach of immigration law by the individual, and

(c) knows or has reasonable cause for believing that the individual is not a citizen of the European Union”

74. I agree with Mr Ball that there is sufficient on the face of the warrant and further information for an
immigration offence under section 25 IA 1971 to be made out in relation to Billo's transfer. Taken together,
the particulars allege that the appellant assisted Kabba, by the provision of money transfers, to bring
Nigerian women into Belgium. One such was Billo, in respect of whom it is said the appellant knew she
was transferred to Belgium by Kabba and that she was in Belgium illegally.  There is reference to a
telephone call between the appellant and Billo in which reference is made to her illegal status.

75. I agree with Mr Stansfeld that the description of the Belgian offence is silent as to any necessary
mental element, whilst the English offence requires proof of specific knowledge/belief (see above). On this
basis, and applying the principles discussed in Cleveland, the stricter test would apply. But even applying
the stricter test I am satisfied that the inevitable inference from the facts (if proved) would be that the
appellant knew or had reasonable cause for believing that Billo was being brought into Belgium illegally
and that she was not an EU citizen.

_Offences D-F_

76. The District Judge found that Offences D-F equated to offences under sections 329 (acquisition use
and possession of criminal property) and 327 (concealing, disguising or converting criminal property)
POCA 2002.

77. Mr Stansfeld's arguments in respect of the money-laundering offences were essentially the same as
those he deployed in challenging particularity under s.2 EA 2003. He noted that the District Judge had


-----

failed to ascribe distinct conduct to each of the separate offences. Whilst he accepted that, subject to the
question of mens rea, the conduct alleged could give rise to an offence of possessing criminal property
contrary to section 329 POCA, he contended that the particulars could not give rise to separate offences of
“concealing” or “disguising” criminal property. As to the necessary mental element, Mr Stansfeld accepted
that the lesser test applied, since the descriptions of the Belgian offences include equivalent elements of
knowledge/suspicion, but he argued that the particulars were not capable of establishing the appellant's
knowledge/suspicion that the monies which he received/transferred were derived from
trafficking/prostitution.

78. Mr Ball relied on the matters summarised at 34-36 above as establishing the necessary knowledge.
As to the separate offences of concealing and disguising he pointed to particulars given of transferring
money to Nigeria and of using it to buy property in Nigeria. These details were sufficient to establish the
separate offences, he argued.

79. Following the hearing I invited and received further written submissions on the question of whether it is
necessary under English law to show knowledge of the particular criminal conduct from which the funds
derived. I am grateful to both counsel for their succinct submissions on this issue.

_Offences D-F - conclusion_

80. Like the District Judge I am satisfied that each of Offences D to E are extradition offences. Taken
together the particulars establish the appellant's involvement in receiving and distributing funds received
from the illegal activities of persons involved in trafficking women from Nigeria into Belgium and Dubai for
the purposes of prostitution. If proved, the particulars are capable of showing that the appellant knew of
the origin of the funds which he received from Kabba, Danko and others. There is sufficient to establish
separate offences of possessing, concealing and disguising such funds, under sections 329 and 327 of
POCA 2002. The dual criminality requirements are properly made out.

**Conclusion**

81. For these reasons the appeal is allowed to this extent only: the extradition order will be discharged in
relation to Offence B, but will remain in place in respect of Offences A, C, D, E and F.

**End of Document**


-----

