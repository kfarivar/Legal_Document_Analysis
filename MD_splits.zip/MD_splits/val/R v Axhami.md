# R v Axhami [2022] EWCA Crim 1687

Court of Appeal, Criminal Division

Dingemans LJ, Sweeney J, HHJ Picton

14 December 2022Judgment

MISS V FOWLER appeared on behalf of the Appellant

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

LORD JUSTICE DINGEMANS:

1. This is an appeal against sentence. The appellant is a 19‑year‑old man having been born on 12

February 2003. He is an Albanian national and was of previous good character.

2. On 9 August 2022 he appeared before the Crown Court at Aylesbury and was sentenced to two years
eight months' imprisonment for the production of a class B drug. The appeal raises the issue of whether
the judge gave sufficient discount for the appellant's youth and immaturity, and issues about how he was
categorised for the purposes of the sentencing guidelines.

3. It is necessary to record that the appellant should have been sentenced to detention in a young offender
institution and not to imprisonment and we alter the record for those purposes.

4. On 24 February 2022, so just after his 19th birthday, the appellant was arrested in a warehouse unit
which had been vacated by a previous tenant in 2019, which had been converted (without the knowledge

of the owner) to grow cannabis plants. There were approximately 900 well‑established cannabis plants

and the electricity supply had been bypassed. There were hydroponics and quite a sophisticated system
for maintaining the plants. The appellant was found in the kitchen and had keys to the warehouse and was
able to come and go. About two hours after his arrest his brother arrived. He had a car and had cash
upon him. The position in relation to the brother's prosecution is not known.

5. At police interview the appellant made a prepared statement suggesting that he had been present only
for one week but knew that he was growing cannabis.


-----

6. The appellant was charged with the production of a class B drug on 26 February 2022, so four days
after his arrest. He pleaded guilty at the Magistrates' Court and was committed for sentence. On 9 August
2022 he then appeared and was sentenced as already indicated.

7. During the prosecution opening of facts the judge asked whether it was still being contended on behalf
of the appellant that he had only been in the premises for one week in the light of the fact that the plants

were well‑established and in the light of the fact that the appellant had the keys. Defence counsel took

instructions and clarified that the appellant was not contending that he had a role limited to that of a
gardener and that there was a factor of significant role. It was also contended that there were factors of
lesser role present.

8. When sentencing the judge identified that this was a Category 2 case based on the yield and that the
appellant had a significant role. That gave a starting point of four years with a range of two years six
months to five years. The judge identified that there were aggravating factors being the expected profit,
the unlawful access to electricity and the expensive and specialised equipment. The judge said that there
were mitigating factors being a lack of previous convictions and the fact that the appellant was 19 years
old. The judge said that there was no evidence that the appellant lacked maturity and that there was no

evidence that the appellant had been exploited. The judge said it was a well‑organised enterprise and the

appellant had the significant role already identified.

9. The judge then said that he had taken account of aggravating and mitigating factors and came up with a

sentence of the four year starting point which was then discounted by one‑third for guilty plea, giving a

sentence of 32 months (which is two years eight months).

10. Miss Fowler, to whom we are grateful for her written and oral submissions this morning, pursues three
grounds of appeal. The first is in relation to personal mitigation. It is said that the appellant made
admissions in interview and pleaded guilty, that he was of previous good character and that some weight
should have been given to the fact that he said he had been brought into this country illegally and that he
owed a debt. The second ground of appeal was that insufficient reduction was made on account of his
age. The third ground of appeal was that in fact properly analysed he was on the borderline of a significant
and lesser role and somewhere between the two and therefore the starting point taken by the judge was
too high.

11. So far as the first ground of appeal is concerned, we agree that there was mitigation in the appellant's

previous good character and that his age was relevant. It is well‑established that the age of 18 is not a cliff

edge and that the youth and maturity of an offender will be factors that inform any sentencing decision,
even after an 18th birthday. It is common ground in all the authorities that a reduction for age and maturity
does not cease simply on the cliff edge, as it was described, of the 18th birthday.

12. The judge did not express the effect of this, but the judge had identified, and was right to identify,
aggravating factors. These were the expected profit, unlawful access to electricity and expensive and
specialised equipment. The judge must therefore have taken a starting point of four years and gone up to
reflect those aggravating factors before reducing that increased sentence to take account of the mitigating
factors, in particular of age and previous good character. That means that the judge then ended up with
the sentence which he had, before he then gave the full and appropriate discount for the plea of guilty and
the fact that admissions were made in interview. In those circumstances we do not consider that grounds
1 and 2 take the matter any further or forward. It is right, as Miss Fowler pointed out in her submissions,
that that was not made clear in the sentencing remarks, but it was certainly implicit from the judge's
sentencing.

13. That leaves the question of whether the judge was entitled to find that the appellant had a significant
role and Miss Fowler points out that there was exploitation and lack of maturity in this case. In this case
the judge expressly addressed the issue of maturity and said that there was no evidence of a lack of
maturity and he also considered the issue of exploitation. The judge was entitled to find that there were no
indications of exploitation. This appellant had the keys to the property, it was his brother who turned up


-----

two hours later who had cash and a car, and we note, and Miss Fowler has confirmed it today, that there
has been no reference to the Single Competent Authority. A reference can be made to the Single
Competent Authority regardless of whether the circumstances would amount to a defence under the
**_Modern Slavery Act (and it was common ground in this case that the circumstances were not such that_**
there would have been a defence under the Modern Slavery Act).

14. In all these circumstances we are unable to say that the sentence was either wrong in principle or
manifestly excessive. We will therefore dismiss the appeal.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

