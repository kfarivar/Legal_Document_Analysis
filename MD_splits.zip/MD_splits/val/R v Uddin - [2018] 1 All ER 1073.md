# R v Uddin [2018] 1 All ER 1073

[2017] EWCA Crim 1072

COURT OF APPEAL, CRIMINAL DIVISION

HALLETT VP, GREEN J AND JUDGE TAYLOR

29 JUNE, 26 JULY 2017

**Criminal law — Domestic violence — Causing or allowing death of child or vulnerable adult — Meaning of**
**'vulnerable adult' — Domestic Violence, Crime and Victims Act 2004, s 5(1), (6).**

The appellant had stood trial with six members of his family, two of whom had been charged with murder and all of
[whom had been charged with an offence contrary to s 5[a] of the Domestic Violence, Crime and Victims Act 2004.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y0NW-00000-00&context=1519360)
He was convicted of causing or allowing the death of a vulnerable adult, his sister, and conspiracy to pervert the
course of justice. The deceased had lived with the appellant and the other family members. At the time of her death,
she had been 19 years old. Police inquiries of the deceased had revealed a lengthy history of isolation and
sustained physical and emotional abuse. The appellant appealed against his conviction on the single ground that
the judge had been wrong to find that there was evidence from which the jury could have concluded that the
deceased had been a 'vulnerable adult' within the meaning of s 5(6) of the 2004 Act and had therefore been wrong
to reject a submission of no case to answer on the s 5 offence. Section 5(6) defined a 'vulnerable adult' as 'a person
aged 16 or over whose ability to protect himself from violence, abuse or neglect is significantly impaired through
physical or mental disability or illness, through old age or otherwise'. There was no suggestion that the deceased
had been suffering from physical or mental disability or illness; and she had been only 19 years old. The court
therefore considered the meaning of the phrase 'or otherwise' in s 5(6).

**Held – The words 'or otherwise' in s 5(6) of the 2004 Act had created an additional third category or categories of**
potentially vulnerable adults who were not suffering from an illness, disability or old age, which could be simply
defined as 'a cause (other than physical or mental disability or illness or old age) which had the effect on the victim
of significantly impairing his ability to protect himself from violence, abuse or neglect'. Further, the natural meaning
of 'otherwise' did not necessitate that the cause be intrinsic; it could be an external cause, through which the
victim's ability to protect him or herself was impaired. In principle, there was no limit to the facts and circumstances
that might lead to the victim finding him or herself in a state of impaired ability to obtain protection. In the first
category, any illness, physical or mental disability, provided there was evidence that it caused significant
impairment, would suffice. The concept of old age in the second category was also not limited. Similarly, the jury
had to determine whether a victim fell into the third category. The inquiry the court had to perform was fact and
context sensitive. The causes of vulnerability might be physical, psychological and or they might arise from the
victim's circumstances. The third category was not limited to

1

cases of 'utter dependency'. A victim of sexual or domestic abuse or modern slavery, for instance, might find him
or herself in a vulnerable position, having suffered long-term physical and mental abuse leaving them scared,

a Section 5, so far as material, is set out at [16], below.

**[*1074]**


-----

cowed and with a significantly impaired ability to protect themselves. Not every victim of abuse and domestic
violence would qualify as a vulnerable adult, however; there was a further safeguard built into the definition, namely
that the effect upon him or her had to impair significantly their ability to protect themselves. Applying those
conclusions to the facts of the present case, the judge had been right not to withdraw the case from the jury. There
had been ample evidence for the jury to consider whether the deceased had fallen into the third category.
Accordingly, the appeal would be dismissed (see [34]–[42], [46]–[50], below); _R v Khan_ _[[2009] 4 All ER 544](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G1HW-00000-00&context=1519360)_
considered.
**Notes**

For causing or allowing the death of a child or vulnerable adult, see 25 Halsbury's Laws (5th edn) (2016) para 123.

[For the Domestic Violence, Crime and Victims Act 2004, s 5(1), (6), see 12(5) Halsbury's Statutes (4th edn) (2017](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y0NW-00000-00&context=1519360)
reissue) 5, 6.
**Cases referred to**

_[Pepper (Inspector of Taxes) v Hart [1993] 1 All ER 42, [1993] AC 593, [1992] 3 WLR 1032, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60C0-00000-00&context=1519360)_

_[Quazi v Quazi [1979] 3 All ER 897, [1980] AC 744, [1979] 3 WLR 833, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6123-00000-00&context=1519360)_

_[R v Khan [2009] EWCA Crim 2, [2009] 4 All ER 544, [2009] 1 WLR 2036, [2009] 1 Cr App R 370.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G1HW-00000-00&context=1519360)_
**Appeal**

On 17 December 2015, following trial before judge and jury at St Albans Crown Court, Tohel Uddin was convicted
[of causing or allowing the death of a vulnerable adult contrary to s 5 of the Domestic Violence, Crime and Victims](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y0NW-00000-00&context=1519360)
Act 2004 and conspiracy to pervert the course of justice. He appealed against conviction on the ground that the
deceased had not been a 'vulnerable adult' within the meaning of s 5(6) of the 2004 Act. The facts are set out in the
judgment of the court.

_David Etherington QC (instructed by Faradays Solicitors) for the appellant._

_Stuart Trimmer QC (instructed by the CPS Appeals Unit) for the Crown._

_Judgment was reserved._

26 July 2017. The following judgment of the court was delivered.

**HALLETT VP.**
**Introduction**

**[1] This appeal raises a short but important point of construction. It focuses upon the interpretation of the phrase 'or**
otherwise' in the definition of 'vulnerable adult' in s 5(6) of the Domestic Violence, Crimes and Victims Act 2004 ('the
Act').

**[2] In December 2015, the appellant stood trial at St Albans Crown Court with six members of his family, two of**
whom were charged with murder and all of whom were charged with an offence contrary to s 5 of the Act. On 17
December 2015, the appellant was convicted of causing or allowing the
**[*1075]**

death of a vulnerable adult and conspiracy to pervert the course of justice. The trial judge Spencer J sentenced him
to a total of 61/2 years' imprisonment.

**[3] His co-accused Laila Begum was acquitted of causing or allowing the death of a vulnerable adult and conspiracy**
to pervert the course of justice on the direction of the judge. Salma Begum was convicted of murder and conspiracy
to pervert the course of justice. Suhail Uddin was acquitted of murder and convicted of causing or allowing the
death of a vulnerable adult and conspiracy to pervert the course of justice. Jhuhal, Jewel and Rehena Uddin were
convicted of causing or allowing the death of a vulnerable adult and conspiracy to pervert the course of justice.


-----

**FactsProsecution case**

**[4] The deceased Shahena Uddin was one of eight children. She and her sisters Rehena, and Sabina were treated**
badly by their mother and removed from her care. In 2010, Suhail Uddin (their oldest brother) and Salma Belgum
(his wife) were awarded custody of the three girls. There were three other brothers, the appellant Tohel Uddin,
Jhuhal Uddin and Jewel Uddin. Laila Begum is the sister of Salma Begum and Rina Begum. She is married to
Jhuhal Uddin.

**[5] By the time of her death on 11 October 2014, Shahena was 19 years of age. She lived with members of the**
family at 96 Leavesden Road, Watford. The family owned another property a short distance away at 39 Middle Ope.
During the night of 10–11 October 2014 Shahena was beaten to death. Before calling the emergency services, the
family (i) disposed of her clothes soiled with blood and faeces and her blanket (ii) moved a bed so that it covered a
blood and vomit stained rug (iii) removed the youngest daughter Sabina from the house to prevent the police
speaking to her (iv) agreed a false account that Sabina had spent the night at Middle Ope and (v) put Shahena's
body in the bathroom.

**[6] Jhuhal Uddin then telephoned 999 and reported that Shahena was not breathing and that she had been sick**
and fainted. Paramedics and a doctor attended; Shahena was pronounced dead at the scene.

**[7] She had 55 separate areas of injury, including two black eyes, bruising to her head, face and ears both on the**
left and right, a cut to the head and her lip, with bruising inside her mouth, and injuries to the back of her head, right
shoulder, legs and back. She had specific targeted injuries to both breasts, hip, stomach, arms and hands, including
defensive injuries. Some injuries appeared to have been caused by objects such as a 'glow stick' and mop handle.
The 'fresh' injuries had been caused by moderate force and within 24 hours of her death. There were older injuries
to her arms, legs, face and head.

**[8] Dr Chapman estimated that death had occurred between 6 and 6.30 am and was caused by choking on inhaled**
vomit when unconscious. Shahena had been rendered unconscious no earlier than 5.30 am and probably from
repeated blows to her head.

**[9] The family members were interviewed as significant witnesses on 11 October. Amongst other things, all failed to**
mention that Sabina lived at Leavesden Road or that she had been present. They were all arrested between 11
October and 14 October. Only Rehena Uddin answered questions in interview.

**[10] Police inquiries of Sabina and school friends of the deceased revealed a lengthy history of isolation and**
sustained physical and emotional abuse of
**[*1076]**

Shahena. Suhail and Salma believed in discipline of an extreme kind that included beatings on a regular basis and
degrading punishments. The other members of the family, including the appellant, were either active or complicit in
the beatings and punishments. The brutal regime left Shahena battered and bruised and terrified of what would
happen to her if she complained.

**[11] The regime included physical beatings with objects, being made to eat paper, her own faeces and vomit, force**
feeding, deprivation of sleep and water, being made to stand for hours staring into a lavatory bowl, not being
allowed to use the lavatory or shower when she needed to, having to use the lavatory or shower under surveillance,
forced to sleep on the floor when she wet the bed and being made to lick the lavatory bowl or seat.

**[12] She was not allowed a mobile telephone and had no access to social media. She could not socialise with**
anyone outside the home, speak to anyone about her family in a way that might reveal what was happening to her.
When witnesses raised concerns with the school authorities, the deceased was directed to spend break times only
with her sister. When the family learned Shahena had allowed herself to be taken to the school matron for an ear
infection, she was punished. Witnesses were so concerned about her being in an emotionally and physically
abusive situation, they obtained contact details for a helpline on domestic abuse and for a local charity to give to the
deceased. She did not contact either for fear of repercussions at home.


-----

**[13] Sabina suffered similar treatment but was not beaten to the same extent. She confirmed that the sisters**
discussed running away and Shahena considered killing herself. The main perpetrator of the violence was Salma
Begum and to a lesser extent her eldest brother Suhail Uddin.
_Defence case_

**[14] In summary, this was a complex and dysfunctional family. Shahena challenged her sister-in-law's strict regime**
and it was this that brought her into conflict with the family and brought about episodes of punishment beatings. She
was not feeble-minded, nor suffering from any illness or disability, mental or physical. She was 'feisty and
argumentative', 'controlling' and prepared to stand up for herself at school; she was not a vulnerable adult within the
meaning of the section.
**Appeal**

**[15] There is one ground of appeal that the judge was wrong to find that there was evidence from which the jury**
could conclude that Shahena was a vulnerable adult within the meaning of s 5(6) of the Act and therefore wrong to
reject a submission of no case to answer on the s 5 offence.

**[16] Section 5, where relevant, provides:**

'(1) A person (“D”) is guilty of an offence if—

(a) a child or vulnerable adult (“V”) dies as a result of the unlawful act of a person who—

(i) was a member of the same household as V, and

(ii) had frequent contact with him,

(b) D was such a person at the time of that act,

(c) at that time there was a significant risk of serious physical harm being caused to V by the unlawful act of
such a person, and

(d) either D was the person whose act caused V's death or—

(i) D was, or ought to have been, aware of the risk mentioned in paragraph (c),

**[*1077]**

(ii) D failed to take such steps as he could reasonably have been expected to take to protect V from the risk,
and

(iii) the act occurred in circumstances of the kind that D foresaw or ought to have foreseen …

(6) In this section—

“act” includes a course of conduct and also includes omission;

“child” means a person under the age of 16;

[“serious” harm means harm that amounts to grievous bodily harm for the purposes of the Offences against the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)
_[Person Act 1861 (c 100);](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)_

“vulnerable adult” means a person aged 16 or over whose ability to protect himself from violence, abuse or
neglect is significantly impaired through physical or mental disability or illness, through old age or otherwise.

(7) A person guilty of an offence under this section is liable on conviction on indictment to imprisonment for a
term not exceeding 14 years or to a fine, or to both.'

_The appellant's submissions_


-----

**[17] The focus of the appellant's argument was on the definition of vulnerable adult: 'a person aged 16 or over**
whose ability to protect himself from violence, abuse or neglect is significantly impaired through physical or mental
disability or illness, through old age or otherwise'. There is no suggestion that Shahena was suffering from physical
or mental disability or illness; she was only 19. The only way, therefore, in which she could be described as a
vulnerable adult for these purposes would be if the words or otherwise are given a broad meaning.

**[18] Section 5 is a penal section creating an offence with a maximum penalty of 14 years' imprisonment and should**
be narrowly construed. The section radically extended the ambit of the criminal law and 'circumspection' is therefore
required when construing the section. The ambit of the offence should not be extended further 'than obviously
intended by Parliament'.

**[19] Parliament imposed a duty on a limited pool of individuals not to allow the death of a limited pool of vulnerable**
adults. The key to the extension to the law was that there was something intrinsic in the very condition of the victim
that rendered his or her ability to obtain protection significantly impaired. In the case of a child it is age (under 16);
in the case of an adult it is disability or illness or old age. Parliament deliberately specified the 'trigger' conditions,
not as examples of what might cause significant impairment but as the first stage of a two-stage test. First, the court
should ask the question: was the victim suffering from a disability or illness, old age or similar condition? Second, if
the answer is yes, did that condition significantly impair their ability to protect themselves?

**[20] If the respondent's interpretation that or otherwise covers any set of circumstances or condition that leads to a**
significant impairment of the ability to protect oneself is correct, a jury would be able to conclude that impairment
could be caused by conditions such as sleep, being taken unawares, and being attacked by a stronger individual.
This would be far too broad an extension of the law and cannot have been intended by Parliament. It would also
mean that the words through physical or mental disability or illness, through old age or otherwise are superfluous.
Parliament could have simply stated an adult is vulnerable
**[*1078]**

where the ability to protect oneself is significantly impaired. The words or otherwise must qualify to an extent, or be
subject to, the words that have gone before.

**[21] Because the words** _or otherwise_ are apparently wide, they are subject to the ejusdem generis principle of
construction, namely that wide words associated in the text with more limited words are taken to be restricted, by
implication, to matters of the same limited character. The rule may be overridden if it would defeat the intentions of
[Parliament (the rule is 'a useful servant but a bad master'—per Lord Scarman in Quazi v Quazi [1979] 3 All ER 897](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6123-00000-00&context=1519360)
_[at 917, [1980] AC 744 at 824). It may be defeated by express exclusion. Neither applies here.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6123-00000-00&context=1519360)_

**[22] At its most extreme, Mr Etherington's argument, based on the ejusdem generis principle, was to the effect that**
the prosecution has two hurdles to surmount in proving a victim is a vulnerable adult: (i) that the adult's ability to
protect him or herself from violence, abuse or neglect is significantly impaired by reason of a physical or mental
disability or an illness and (ii) the physical or mental disability or illness is caused by old age or a like condition to
old age. The words or otherwise are restricted by implication to the words old age. Only conditions that are 'like' old
_age can fall within the additional category._

**[23] At the very least, he insisted there is one hurdle: the prosecution must prove either that the adult's ability to**
protect him or herself from violence, abuse or neglect was significantly impaired through physical or mental
disability or illness or it was significantly impaired through old age (presumably physical and/or mental infirmity) or
otherwise (within that genus).

**[24] Accordingly, Mr Etherington claims the judge erred when he directed the jury:**

'As a matter of interpretation of the Act of Parliament, in law this means that you must be sure that Shahena
was reduced to that state of vulnerability as a result of emotional and/or psychological damage she had
suffered through the way she was treated in the household.'


-----

This kind of vulnerability, caused by emotional or psychological damage, is not enough, absent evidence of illness
or disability or something similar.

**[25] We were taken to the one decision counsel could find that addresses the issue of the meaning of the words or**
_[otherwise: In R v Khan [2009] EWCA Crim 2, [2009] 4 All ER 544, [2009] 1 WLR 2036(at [25]–[27]) Lord Judge CJ](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G1HW-00000-00&context=1519360)_
observed:

'[25] Children under the age of 16 expressly fall within the protective provisions of the Act. Adults, or near
adults who are over the age of 16, are vulnerable if their ability to protect themselves from “violence, abuse or
neglect” is significantly impaired. There was some discussion whether the words “or otherwise” found in s 5(6)
extended to an individual like this unfortunate deceased, lonely and friendless in this, to her, utterly strange
country, and consequently, totally dependent on her husband and his family.

[26] The Act is not embarking on the impossible task of dissipating misery and unhappiness. Its objective is to
protect those whose ability to protect themselves is impaired. In agreement with the judge, however, we do not
rule out the possibility that an adult who is utterly dependent on others, even if physically young and apparently
fit, may fall within the protective ambit of the Act. The case here proceeded on the basis that the

**[*1079]**

protective provisions of the Act did not arise for consideration before the major attack on the deceased some
three weeks before her death. The issue whether she was indeed vulnerable after that attack was rightly left to
the jury, but if the facts had been different, we should not have ruled out the possibility that the jury might have
inferred that she was already a vulnerable adult for the purposes of the Act before she sustained the violent
injuries inflicted on her in the first violent attack three weeks before her death. However, in this particular case
the prosecution would, on the evidence, have faced difficulty in establishing that the deceased was exposed to
a significant risk of serious physical harm before that attack, and in demonstrating that any one of these
appellants fell within the ambit of awareness and foresight prescribed by s 5(1)(d). The case was exclusively
concerned with direct physical violence sustained by the deceased. In another case, the question whether the
victim could protect himself or herself from “abuse or neglect” might well arise in relation to an individual in
Sabia's situation.

[27] We should add that in any event the state of vulnerability envisaged by the Act does not need to be longstanding. It may be short, or temporary. A fit adult may become vulnerable as a result of accident, or injury, or
illness. The anticipation of a full recovery may not diminish the individual's temporary vulnerability.'

**[26] Thus, the court did not 'rule out' the possibility that an adult 'who is utterly dependent on others, even if**
physically young and apparently fit, may fall within the protective ambit of the Act'. Mr Etherington first questioned
whether this was too broad an interpretation of the section and adopted the observations of the highly respected
academic Professor Ormerod in his commentary on _Khan_ at [2009] Crim LR 349 at 350. Professor Ormerod
suggested that the broader possible interpretation in _Khan_ has the potential to create problems making 'such a
broad offence undesirably wide'. He commented that the court's interpretation of 'otherwise' gives it a meaning
'unconstrained by all the words preceding it'. 'Where the statute is introducing such a radical concept as a positive
duty to act, with a criminal sanction for failing to do so, a narrower approach to interpretation may have been
expected.' 'If liability as to V's status is strict and the definition of vulnerability is as ambiguous as it seems to be, the
offence is remarkably wide.'

**[27] Second and importantly, Mr Etherington invited us to note that the court in Khan did not resolve the issue. It**
'did not rule out' a possibility. Third, and in any event, he understood Lord Judge's words to mean that to qualify as
a vulnerable adult, a young adult physically fit would have to be 'utterly dependent' on others. Only if someone is
'utterly dependent' might they be described as suffering from a condition similar to old age. Shahena had a
psychological dependency on her family but it remains the defence case that she did not fall into the category of
'utter dependency'.


-----

**[28] Finally, Mr Etherington invited us to consider the debate in Parliament on the Domestic Violence, Crimes and**
Victims Bill and the record of proceedings in Hansard. If the words _or otherwise_ are ambiguous, as he suggests
they are, the words of the sponsoring Minister, the then Attorney General, Baroness Scotland QC, were not. The
court is entitled to inspect Hansard, therefore, to assist in the interpretation of the phrase in its context: see Pepper
_[(Inspector of Taxes) v Hart [1993] 1 All ER 42, [1993] AC 593.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60C0-00000-00&context=1519360)_
**[*1080]**

**[29] During the debate, the potential for ambiguity in the phrase** _or otherwise_ was recognised and the Attorney
General's response (Hansard (HL Debates) 21 January 2004 vol 657, cols 311–372GC) was this:

'The term “or otherwise” should be construed in the light of the preceding words: that is, “physical or mental
disability or illness, through old age”. They are connected with those things. We think it is crucial that there
should be a linkage in relation to that definition. But the crucial part of the definition is that the person's “ability
to protect himself from violence, abuse or neglect is significantly impaired”. It will, of course, be a matter for the
court to determine in each case whether that person's physical or mental disability through illness or age was
significantly impaired. Of course it will be a matter of evidence whether it is medical, physical or otherwise …

In essence, although we absolutely understand that this was not something that the Law Commission chose to
deal with, we consider that we would neglect our duty when looking at victims generally—the Bill also concerns
victims—if we failed to take a step that we could and should properly take to protect an identifiable vulnerable
group who are subject to similar concerns that we now have in relation to children.'

**[30] The Minister was pressed by Lord Donaldson on the potential for ambiguity and suggested Parliamentary**
counsel revisit the definition. Baroness Scotland replied:

'Obviously the comments I have made will be recorded in Hansard. One of the things of which we are very
conscious is, just as with domestic violence, definitions change rapidly. There may be a new species, which
could include “or otherwise”, about which we do not know. That is why we have included the measure.'

Thereafter, no changes were made to the definition.

**[31] Mr Etherington asked us to note the Minister's words: 'The term “or otherwise” should be construed in the light**
_of the preceding words: that is, “physical or mental disability or illness, through old age”. They are connected with_
those things. We think it is _crucial that there should be a linkage_ in relation to that definition' (emphasis added),
followed by her observation that her comments would be recorded in Hansard. The cumulative effect of her
responses, he suggested, was an underlining of the important link between illness, disability, old age and the words
_or otherwise._
**Conclusion**

**[32] The Act imposes a new and positive duty on members of the same household to protect from serious physical**
harm children or vulnerable adults, whose ability to protect themselves is significantly impaired. There may be many
causes of significant impairment, but in the definition of vulnerable adult, the Act expressly identifies only two
categories: disability or illness (category one) and old age (category two). The categories are clearly distinct; hence
the repetition of the word _through. Accordingly, we can reject summarily the most extreme of Mr Etherington's_
submissions. Parliament did not intend to protect the sick and disabled only if they fell into the category of old age.

**[33] The word** _through_ in relation to category one and _through_ in relation to category two denotes a causal link
between the conditions described in each category and the significant impairment of the ability to protect oneself
**[*1081]**

against violence, abuse or neglect. The causal link is maintained in relation to or otherwise, the lack of an explicit
_through_ being for obvious grammatical reasons. One would not say 'through otherwise'. However, there is no
reasonable construction which would allow for these words to have no causal link with significant impairment of the
ability to protect oneself. The focus of the section is therefore clearly on significant impairment.


-----

**[34] In our view, the choice of the words or otherwise to follow the identified categories is significant. The word or**
creates an alternative scenario. The word otherwise is defined in the Oxford English Dictionary as 'in circumstances
different from those present or considered'. The words _or otherwise_ therefore distinguish the circumstances in
question from the categories that precede them. The words have a specific purpose, leaving open the possibility of
other sets of circumstances or conditions that could feature as the background to the central operative requirement
that the individual's ability to protect him or herself from violence, abuse or neglect is significantly impaired. They
provide for an additional third category or categories of potentially vulnerable adults who are not suffering from an
illness, disability or old age. The linkage between the categories specified and the alternative category is that the
adult's ability to protect himself must be impaired.

**[35] We reject the submission that the words** _or otherwise_ should be construed ejusdem generis so that _or_
_otherwise becomes a reason similar to those listed. Section 5(6) does not justify such an interpretation. It does not_
for instance say 'some other similar reason' or 'some like reason' or 'some equivalent reason' or 'a reason of a
similar type'. If Parliament had wished to link 'other reason' to the identified categories, then it could easily have
chosen any of these drafting techniques. It did not do so.

**[36] The first and second categories therefore provide examples of conditions that can be causes of significant**
impairment. The words _or otherwise_ on their natural meaning are clearly intended to bring within the protection
offered by the section causes other than the causes identified but which have the same impact. For us to limit the
range of causes in the way suggested would curtail the very purpose of the statute, which is not only, as Lord Judge
said in Khan, to protect those whose ability to protect themselves is impaired, but to prevent them from death as a
result.

**[37] Consequently, what is envisaged is a third category, other than and different from the first and second**
categories. By reason of the causal link, common to all, the third category encompassed by or otherwise can be
simply defined as:

'A cause (other than physical or mental disability or illness or old age) which has the effect on the victim of
significantly impairing his ability to protect himself from violence, abuse or neglect.'

**[38] Furthermore, whilst the first and second categories are conditions intrinsic to the victim** _through_ which the
ability to protect him or herself is impaired, the cause of such conditions (other than old age) can be either intrinsic
or external, for example the mental or physical trauma suffered in an accident. The natural meaning of otherwise
does not necessitate that the cause be intrinsic. It can be an external cause, through which the victim's ability to
protect him or herself is impaired.

**[39] In principle, there is no limit to the facts and circumstances that might lead to the victim finding him or herself in**
a state of impaired ability to obtain protection. None of the categories is closely defined. In the first category, any
**[*1082]**

illness, physical or mental disability, provided there is evidence that it caused significant impairment, will suffice.
The concept of illness and physical and mental disability is a broad one. The illness or disability does not have to be
a 'recognised medical condition' (as for example in the Homicide Act 1967). The jury decides if the victim was
suffering from an illness or disability and if so, its impact on the adult's ability to protect him or herself. The concept
of old age in the second category is also not limited. The jury is left to determine what constitutes old age and
whether it caused a significant impairment.

**[40] Similarly, the jury must determine whether a victim falls into the third category. The inquiry the court must**
perform is fact and context sensitive. The causes of vulnerability may be physical, psychological and or they may
arise from the victim's circumstances as in Khan. However, in our view, the third category is not limited to cases of
'utter dependency' as postulated in Khan. A victim of sexual or domestic abuse or modern slavery, for instance,
might find him or herself in a vulnerable position, having suffered long-term physical and mental abuse leaving them
scared, cowed and with a significantly impaired ability to protect themselves.


-----

**[41] In reaching our conclusions, we are acutely conscious that this is a penal section creating a serious criminal**
offence, but, in our judgment, the words _or otherwise_ are not ambiguous. Furthermore, we note that the section
provides several safeguards for a defendant. The positive duty is not as broad as Mr Etherington suggested it would
be if we accepted the respondent's interpretation. The duty only arises if:

(i)   the victim is vulnerable, ie their ability to protect him or herself from violence, abuse or neglect is
significantly impaired;

(ii)   the victim dies as a result of an unlawful act;

(iii)   both the perpetrator and the defendant were members of the same household and had frequent
contact with the victim;

(iv)   at the time, there was a significant risk of serious physical harm;

(v)   the defendant was, or ought to have been, aware of the significant risk of serious physical harm to
the victim;

(vi)   the defendant failed to take such steps as he could reasonably have been expected to take to
protect the victim from the risk; and

(vii)   the unlawful act occurred in circumstances of the kind that the defendant foresaw or ought to have
foreseen.

**[42] Thus, the section provides a series of criteria, each one of which must be met before a prosecution can be**
brought under this section. The criteria are stringent and limit the pool of potential defendants, as Lord Judge CJ
observed in Khan. Only once those criteria are met by the defendant, does the section turn to the definition of the
vulnerable adult. Not every victim of abuse and domestic violence will qualify as a vulnerable adult. There is a
further safeguard built into the definition, namely that the effect upon him or her must be to impair significantly their
ability to protect themselves.

**[43] It follows that we do not accept the submission that we should have recourse to comments made in Parliament**
on a Pepper v Hart basis. However, had we resorted to Hansard we observe that the passage cited to us from the
discussion of the provision and its underlying policy does not support the appellant's submissions. On the contrary,
Baroness Scotland emphasised the broad policy objective behind the section was as a measure applicable to all
vulnerable adults. She said at one stage:
**[*1083]**

'We know of at least one case where a vulnerable adult has died in domestic circumstances. The details of that
case are very disturbing indeed. It would perhaps not be right for me to go into them here. Suffice it to say that
one of the close family members must have been responsible for that person's death, but the prosecution was
unable to prove which one it was. The family members all chose to remain silent.'

**[44] Later she referred to there being a strong policy case 'to protect the most vulnerable in our society'. She said**
that Parliament had not gone down the route of creating a complex legal definition of a 'vulnerable' adult but would
leave it '… as a matter of common sense and properly and safely … to the courts'. She added:

'One of the things of which we are very conscious is, just as with domestic violence, definitions change rapidly.
There may be a new species, which could include “or otherwise”, about which we do not know. That is why we
have included the measure …'

**[45] Examination of the debate, therefore, supports the proposition that Parliament intended to provide for a new**
species of circumstances that later emerged.

**[46] We now apply our conclusions to the facts of this case. The judge referred to the 'emotional and/or**
psychological damage' that Shahena had suffered 'through the way she was treated in the household' as the
identified set of circumstances leading to her vulnerability.


-----

**[47] Shahena was subject to long-term bullying and beatings. She was punished in bizarre and degrading ways for**
fabricated and the most innocuous of alleged misbehaviour. She had her liberty curtailed. She had her ability to
communicate with others restricted. She was subject to powerful cultural and family pressure. Notes she had written
in the past suggest the family's controlling and cruel behaviour left her feeling it was her fault that she was beaten
and punished. When she did confide in a friend and that intelligence got back to the family she was punished,
thereby deterring her again from reporting her ordeal to third parties and preventing her taking steps to protect
herself. She was in a very real and tangible way vulnerable to the violence inflicted upon her and the control exerted
over her by her family.

**[48] This may not have been a case of 'utter dependency', as described in Khan, but the effect on the victim was**
similar. The judge was right not to withdraw the case from the jury. Had we been persuaded that the test for the
third category was one of 'utter dependency', we would still have upheld the judge's refusal to uphold the
submission of no case to answer. There was ample evidence for the jury to consider whether Shahena fell into the
third category.

**[49] In our view, this is exactly the kind of circumstances Parliament intended to cover in creating the new duty.**
There is nothing undesirable as a matter of law or social policy in holding to account someone in the position of this
appellant. He was a member of the same household and had frequent contact with his younger sister. He must
have known how she was being treated; he knew or ought to have known of the significant risk of serious physical
harm to her and she was killed in an unlawful act in circumstances of the kind he foresaw or should have foreseen.
Far from taking steps to protect her, at the very least he condoned the treatment of her and at the worst he was
actively involved in it and or encouraged it.
**[*1084]**

**[50] We hope we have done justice in this judgment to the eloquence of Mr Etherington's arguments but, for those**
reasons, we reject this appeal.

Appeal dismissed.

Wendy Herring Barrister.

**End of Document**


-----

