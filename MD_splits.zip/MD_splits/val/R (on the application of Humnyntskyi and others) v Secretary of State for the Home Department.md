1912 (Admin)

# R (on the application of Humnyntskyi and others) v Secretary of State for the
 Home Department [2020] EWHC 1912 (Admin)

Queen's Bench Division, Administrative Court (London)

Johnson J

21 July 2020Judgment

Laura Dubinsky and Eleanor Mitchell (instructed by Deighton Pierce Glynn solicitors) for the First Claimant

Laura Dubinsky and Agata Patyna (instructed by Wilson Solicitors LLP) for the Second Claimant

Laura Dubinsky and Marisa Cohen (instructed by Wilson Solicitors LLP) for the Third Claimant

Eric Metcalfe (instructed by the Government Legal Department) for the Defendant

Hearing dates: 8-10 July 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Johnson:**

1. These three separate claims for judicial review concern, in their area of intersection, the legality of the
Secretary of State's policy approach to the exercise of her power under paragraph 9 of Schedule 10 of the
Immigration Act 2016 to provide accommodation to those who are granted immigration bail. In each of
these cases the Secretary of State did not provide bail accommodation:

(1) Mr Humnyntskyi (see paragraphs 61 - 78 below) was detained for a period of 16 months pending his
deportation from the United Kingdom. The delay in his deportation was in large measure because he gave
a false name and nationality. Conditional orders for bail, subject to a residence condition, were not effective
because Mr Humnyntskyi did not have suitable accommodation and the Secretary of State did not provide
accommodation. Mr Humnyntskyi has now been deported to Ukraine. He seeks a declaration that he was
unlawfully detained (but not damages). My findings in his case are at paragraphs 144 - 188 below.

(2) A (see paragraphs 79 - 101 below) was detained for a period of 11 months. A grant of bail, initially
subject to a residence condition, was not effective because A did not have suitable accommodation and
the Secretary of State did not provide accommodation. A was then released on bail without any residence
condition. He was homeless for a period of 15 months (and street homeless for 10 months). In these
proceedings an order was made for interim relief requiring the Secretary of State to provide
accommodation. Such accommodation was provided, but A was not moved to the accommodation until 8
days after the final date for compliance with the order. He seeks a finding that the Secretary of State has
breached his rights under Article 3 of the European Convention on Human Rights (“ECHR”) (the prohibition
on inhuman or degrading treatment). My findings in A's case are at paragraphs 189 - 221 below.

(3) WP (see paragraphs 102 - 143 below) was detained for a period of 4 months. Requests for
accommodation did not receive a favourable response. WP withdrew a bail application because of the lack


-----

1912 (Admin)

of accommodation and her concerns about being homeless. In these proceedings, an order was made for
interim relief requiring the Secretary of State to provide accommodation. Such accommodation was
provided. WP seeks damages for unlawful detention. My findings in WP's case are at paragraphs 222 - 247
below.

2. Each of the Claimants contends that the refusal to provide accommodation was unlawful and had
deleterious consequences (loss of liberty in the cases of Mr Humnyntskyi and WP; street homelessness in
A's case). They also each say that the system for providing Schedule 10 accommodation is inherently
unfair and that it is unlawful both by reason of unfairness and because the Secretary of State has fettered
her discretion as to the circumstances in which she will provide accommodation. My findings on these
“common claims” are at paragraphs 248 - 297 below.

3. The Secretary of State accepts that individual decisions made in A's case and WP's case were unlawful
(accepting “flagrant” errors in A's case). She expresses regret, but says that these were “aberrant errors”
by individual caseworkers, that her policy is fair and lawful and she has not fettered her discretion. She
argues that (beyond the concessions as to illegality and the consequences that flow from that) the claims
should be dismissed because they are now academic: Mr Humnyntskyi has now been removed from the
United Kingdom, A and WP have each been provided with accommodation.

**The statutory framework**

_Detention_

4. The Secretary of State has power to detain a person pending their deportation from the United Kingdom
– paragraph 2 of schedule 3 to the Immigration Act 1971. She also has a power to detain a person pending
a decision as to whether to give directions for their administrative removal from the United Kingdom (and
pending removal pursuant to such a decision) – section 62(1) Nationality, Immigration and Asylum Act
2002.

_[Provision of accommodation – section 4(1)(c) Immigration and Asylum Act 1999](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1G5-00000-00&context=1519360)_

[5. Prior to the Immigration Act 2016 a person who might otherwise be detained pending deportation could,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
instead, be granted temporary admission to the United Kingdom, or temporary release from immigration
detention, or release on restrictions, or immigration bail. A grant of immigration bail could be made subject
to bail conditions, including a condition of residence at a specified address. The Secretary of State had
power to provide accommodation for persons who were granted temporary admission, or temporary
release from immigration detention, or bail - section 4(1)(c) Immigration and Asylum Act 1999. A person
seeking bail was entitled to apply to the Home Office for the provision of accommodation which could be
utilised in the event of a grant of bail. This was done by completion of a form that was submitted in
advance of a bail application. The form elicited information that informed the Secretary of State's decision
as to whether to provide accommodation. Applications for accommodation were, generally, granted if the
person did not have alternative accommodation (or the funds to accommodate themselves).

6. The power to provide accommodation under section 4(1)(c) of the 1999 Act was, in part, repealed by
the _[Immigration Act 2016 with effect from 15 January 2018. There continues to be a power to provide](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
accommodation under section 4(1)(c) of the 1999 Act, but only in respect of a person who has made a
claim for asylum which has been rejected.

_[Bail under Immigration Act 2016](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_

7. Schedule 10 of the 2016 Act (which is given effect by section 61 of that Act) came into force on 15
January 2018. It makes fresh provision in respect of immigration bail. Paragraph 1 confers a power on the
Secretary of State and the First-tier Tribunal (“the Tribunal”) to grant bail to any person detained under
(amongst other provisions) the powers set out at paragraph 4 above. It also confers a power to grant bail to
any person who is liable to detention under those powers (irrespective of whether it would be lawful to


-----

1912 (Admin)

exercise the power of detention – see Kaitey v Secretary of State for the Home Department [2020] EWHC
_1861 (Admin)_ _per Elisabeth Laing J at [80])._

8. Paragraph 2(1) requires that any grant of bail must be made subject to conditions. The conditions that
may be imposed include “a condition about the person's residence” (paragraph 2(1)(c)). The Secretary of
State or the Tribunal must have regard to certain prescribed matters in determining whether to grant
immigration bail and the conditions to be attached to a grant of immigration bail (paragraph 3(1)). Those
matters include factors such as the likelihood of a person committing an offence while on immigration bail
(paragraph 3(2)(c)) but also “such further matters as the Secretary of State or the First-tier Tribunal thinks
relevant” (paragraph 3(2)(f)).

9. A person who grants immigration bail may amend, remove or add conditions to the grant of bail
(paragraph 6(2)). Where the Tribunal grants bail then it may direct that the power to amend, remove or add
conditions is to be exercised by the Secretary of State (paragraph 6(3)). If the Tribunal makes such a
direction then the Tribunal may not itself amend, remove or add conditions to the grant of bail (paragraph
6(4)).

_Provision of accommodation under Schedule 10 of the Immigration Act 2016_

10. Paragraph 9 of Schedule 10 states:

“Powers of Secretary of State to enable person to meet bail conditions

(1) Sub-paragraph (2) applies where—

(a) a person is on immigration bail subject to a condition requiring the person to reside at an address
specified in the condition, and

(b) the person would not be able to support himself or herself at the address unless the power in subparagraph (2) were exercised.

(2) The Secretary of State may provide, or arrange for the provision of, facilities for the accommodation of
that person at that address.

(3) But the power in sub-paragraph (2) applies only to the extent that the Secretary of State thinks that
there are exceptional circumstances which justify the exercise of the power.

(4) The Secretary of State may make a payment to a person on immigration bail in respect of travelling
expenses which the person has incurred or will incur for the purpose of complying with a bail condition.

(5) But the power in sub-paragraph (4) applies only to the extent that the Secretary of State thinks that
there are exceptional circumstances which justify the making of the payment.”

11. The Secretary of State's power to provide accommodation under paragraph 9 of Schedule 10 is
restricted. It may only be exercised where:

(1) The person is on immigration bail;

(2) The person is subject to a bail condition requiring them to reside at a specified address;

(3) The person would not be able to support himself or herself at the address without the provision of
accommodation by the Secretary of State;

(4) The Secretary of State thinks that there are exceptional circumstances;

(5) The Secretary of State thinks that those exceptional circumstances justify the exercise of the power to
grant accommodation.

12. Unless each of these 5 conditions are satisfied, the Secretary of State has no power to provide
accommodation under Schedule 10. These are stringent conditions. Self-evidently they only fall to be
applied exceptionally. It is unsurprising that the power is limited in this way. Otherwise there is a risk that


-----

1912 (Admin)

any person who is in the United Kingdom unlawfully could demand the provision of accommodation at
public expense.

13. The Secretary of State has a considerable measure of control over conditions (1), (2), (4) and (5). As
to conditions (1) and (2), the Secretary of State may herself grant bail and may herself impose (or,
subsequently, add or vary) conditions of bail where she has granted bail, or where bail has been granted
by the Tribunal and then the management of bail has been transferred to the Secretary of State.

14. As to condition (4), it is for the Secretary of State, not the Court, to determine whether circumstances
are exceptional. The Court's role is limited to a review of that assessment on public law grounds – see R v
_Secretary of State for the Home Department ex parte Onibiyo [1996] QB 768per Sir Thomas Bingham MR_
at 784-785. Mr Metcalfe accepted that the Secretary of State must act lawfully (which includes acting fairly
and rationally) when deciding whether to provide Schedule 10 accommodation – see _R v Secretary of_
_State for the Home Department ex parte Doody_ [1993] 1 AC 531per Lord Mustill at 560D, _R_
_(Sathanantham) v Secretary of State for the Home Department_ _[2016] EWHC 1781 (Admin) [2016] 4 WLR_
128per Edis J at [69]. Thus, in considering whether to grant Schedule 10 accommodation the Secretary of
State must act compatibly with Convention rights (within the meaning of section 1(1) Human Rights Act
1998) unless she is compelled to do otherwise by Schedule 10 (or some other primary legislation) – see
section 6 Human Rights Act 1998. Moreover, the statutory power to provide accommodation must, so far
as possible, be given effect in a way that is consistent with Convention rights – see section 3(1) of the 1998
Act.

15. Mr Metcalfe accepts that this means that there are circumstances where the Secretary of State is
compelled to treat the circumstances as exceptional and to grant accommodation under Schedule 10 (and
to grant or support the imposition of a bail residence condition). This will include cases where:

(1) A person has been released on immigration bail, with the Secretary of State having responsibility for
the management of that bail, or where the Tribunal has granted bail with a residence condition, and

(2) The person is, by reason of lack of accommodation, at real and immediate risk of suffering inhuman
and degrading treatment within the meaning of Article 3 ECHR, and

(3) The person is not able themselves to avoid that risk from materialising (for example, by securing
accommodation from another source, or returning to their country of nationality).

16. A's case is, as I find below (see paragraphs 199 - 212), an example.

17. A further consequence of the requirement to operate Schedule 10 in a way that is lawful arises from
the fact that a grant of immigration bail (with attached conditions) may be made even where detention
would be unlawful. If a grant of bail is conditional on the provision of accommodation by the Secretary of
State, then the Secretary of State will not be entitled to maintain detention if that would be unlawful (for
example where the person has been detained for an unreasonable period of time). In such circumstances,
the Secretary of State would either have to provide Schedule 10 accommodation, or else amend the bail
condition.

**Secretary of State's Schedule 10 policy**

18. Paragraph 9 of Schedule 10, read with paragraph 2, risks tying a Gordian knot. That is because a
person may not be granted Schedule 10 accommodation unless they have been released on bail subject to
a residence condition that specifies an address (paragraph 9(1)). If the person is reliant on the Secretary of
State to provide the accommodation then an address cannot be specified until the accommodation is
provided. But the Secretary of State cannot provide the accommodation until the person has been released
on bail. There is therefore a risk of circularity.

19. The circularity is avoided, and the knot untied, in one of two ways. First, the Tribunal (or the Secretary
of State) might make an “in principle” decision to grant bail subject to a residence condition. That grant of
bail will then only take effect if and when the Secretary of States provides accommodation. Second, the
Secretary of State might make an “in principle” decision to provide accommodation That accommodation


-----

1912 (Admin)

will then only be provided if and when bail is granted. This pragmatic approach to the legislative regime is
helpfully confirmed in a letter from the Home Office dated 26 March 2018 (in the context of the
correspondence described at paragraphs 41 - 46 below): “A 'specified address' can be either an address
that is already specified or one that is to be specified.”

_The unpublished guidance_

20. On 15 January 2018 (the date the 2016 Act came into force), the Secretary of State promulgated
internal policy guidance on the provision of Schedule 10 accommodation. It is addressed to the Secretary
of State's caseworkers. It is primarily focussed on “foreign national offenders” (“FNOs”). The scope of the
term FNO is not defined in the guidance. It certainly encompasses those (like Mr Humnyntskyi and A) who
are being deported from the United Kingdom following the commission of a criminal offence. How far
beyond that it goes (for example, whether it covers offenders who are not subject to deportation action but
who are being considered for administrative removal, or whether it encompasses those who have
committed a criminal offence but who are not subject to any form of removal action) is not specified in the
policy. It is not clear whether WP is properly considered a FNO. When WP's solicitors asked, they were
given inconsistent responses by the Secretary of State (ie both “yes” and “no”). It appears from the
contemporaneous documents that WP was treated as a FNO and I proceed on that basis. It follows that it
is not necessary, for the purpose of these three cases, to consider the lawfulness of the Secretary of
State's policy so far as it applies to those who are not FNOs. This judgment is therefore limited to the
application of the policy to FNOs.

21. The guidance warns that it “must not be disclosed outside of the Home Office.” It states that Schedule
10 accommodation “will not be appropriate” for asylum seekers, failed asylum seekers, those who have
[dependent children and those accommodated under the Care Act 2014. That is, no doubt, because in each](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)
of those cases other sources of accommodation are available. The policy guidance explains what might
constitute “exceptional circumstances” justifying the provision of accommodation:

“Harm Cases

Exceptional circumstances include assessment of risk of harm associated with FNOs. These are defined
as:

FNOs who are assessed by Her Majesty's Prison and Probation Service as being a high or very high risk of
causing harm to the public and granted bail

FNOs at high risk of harmful reoffending against an individual – for example, offences of domestic burglary,
robbery, sexual assaults and violence

If the FNO has nowhere suitable accommodation in accordance with their probation licence and/or multiagency public protection arrangements (MAPPA) for a limited period, or otherwise at the discretion of the
Home Secretary in the interest of public protection

**Special Immigration Appeals Commission (SIAC) Cases**

Exceptional circumstances include where bail conditions, including a residence condition, are imposed by
the Special Immigration Appeals Commission (SIAC).

**Article 3 cases**

Article 3 of the European Convention on Human Rights (ECHR) is the prohibition on torture or inhuman or
degrading treatment or punishment.

You must assess whether it is appropriate to consider providing Schedule 10 accommodation support to
FNO's that do not fit within the categories above in the following circumstances:

they do not have adequate accommodation or the means of obtaining it (whether from a public body under
different legislative powers or through their own efforts)

the provision of accommodation is necessary in order to avoid a breach of their human rights


-----

1912 (Admin)

…

The first step in determining whether accommodation or support may need to be provided for human rights
reasons is to note that in ordinary circumstances a decision that would result in a person sleeping rough or
being without shelter or funds, will usually be considered inhuman or degrading treatment contrary to
Article 3 of the ECHR.

You must assess whether the consequences of a decision to deny a person accommodation would result
in a person suffering such treatment. To make that assessment you must consider if the person can obtain
accommodation and support from charitable or community sources or through their families or friends.

In situations in which you conclude that there is no support from any of these sources you must arrange
accommodation for the FNO in order to avoid a breach of Article 3 of the ECHR.

However, you must only provide accommodation for these reasons if it is clear that the FNO cannot
reasonably be expected to leave the UK.

The expectation is that this will cover a FNO with serious physical or mental health problems who would
not otherwise fall to be supported under other arrangements.”

22. The first category therefore comprises FNOs who pose a high risk to the public (“high risk FNOs”). The
third category is “Article 3 cases”. The natural reading of the policy is that these are two distinct and
independent categories. Each is capable of amounting to an exceptional circumstance for the purpose of
Schedule 10. Thus, Schedule 10 accommodation could be provided to a high risk FNO even if the denial of
accommodation would be compatible with Article 3. Conversely, accommodation could be provided in an
Article 3 case even if the individual is not a high risk FNO.

23. The policy explains the decision making process that is required. Nothing is said about how a FNO
might apply for accommodation, or might make representations in support of Schedule 10 accommodation.
The policy contemplates an internal process that does not necessarily encompass input from the FNO.
Caseworkers are not empowered to grant accommodation. Rather, they must first make a threshold
decision as to whether it would be appropriate to impose a bail condition of residence (without which the
question of Schedule 10 accommodation does not arise). The following guidance is given:

“It will not usually be necessary to impose a residence condition. A residence condition should only be
imposed where residence at a particular address is necessary to enable a high level of contact or mitigate
against a serious risk of non-compliance. This is more likely where the person poses a high risk of harm to
the public on the basis of criminality or in cases concerning national security.

If you conclude that a residence condition would not be appropriate, then it is not necessary to go on to
consider whether the individual would be eligible for Schedule 10 accommodation. However, the Tribunal
may still require an address in the event that the FNO makes an application for bail. You should therefore
seek to establish whether or not the FNO would have a private release address at which he or she could
be accommodated if bailed.”

24. A flow chart is provided to illustrate this process. This sets out, in schematic form, the following
structured questions for the purpose of considering whether Schedule 10 accommodation should be
provided:

(1) Can the FNO provide own address? If not:

(2) Do you intend to impose residence condition? If not then “release to no fixed abode”. If you do intend
to impose a residence condition then:

(3) Does the FNO meet threshold for Schedule 10 support?

25. Ms Dubinsky argues that there is an inherent structural defect in this process. That is because
someone who is in need of accommodation to avoid a breach of Article 3, but who is not a high risk FNO,
will not have their accommodation needs considered. The question of whether to impose a residence
condition encompasses onl q estions of risk posed b the FNO (“A residence condition sho ld onl be


-----

1912 (Admin)

imposed where residence at a particular address is necessary to… mitigate against a serious risk of noncompliance”). It does not therefore encompass consideration of whether accommodation is required to
avoid a breach of Article 3. If a residence condition is not considered appropriate, then there is no
consideration at all of the need for Schedule 10 accommodation – the person is released to “no fixed
abode”. Questions two and three should therefore be the other way around if Article 3 rights are to be
protected. That they have been deliberately inverted, is, says Ms Dubinsky, supported by the Secretary of
State's own evidence (see paragraphs 47 - 52 below).

26. I am quite satisfied that the Secretary of State intended that the policy should protect Article 3 rights,
and did not intend the structure of the decision making to leave such rights out of consideration. The
inclusion in the policy of the “Article 3 cases” section, and the structure of that part of the policy (which
suggests that this is a freestanding category that is capable of amounting to “exceptional circumstances”
justifying the provision of accommodation) strongly suggests that it was intended to avoid a breach of
Article 3 in respect of any FNO (who would otherwise come within the scope of Schedule 10), not just high
risk FNOs. Moreover, it would be irrational to a high degree to implement a system with the intention of
respecting the Article 3 rights of high risk FNOs, but not those of FNOs who pose no risk to the public. Mr
Metcalfe confirms that was not the intention.

27. There are further indications that the policy intent was to ensure proper consideration of the Article 3
rights of all FNOs who come within the scope of Schedule 10, and not just high risk FNOs:

(1) Each iteration of the published policy (see paragraphs 29, 32 and 39 below) suggests that Article 3
cases are within their scope (and that consideration of Article 3 rights is not limited to high risk FNOs).

(2) Correspondence from shortly after the implementation of the policy suggests that Article 3 cases were
intended to be within its scope (see paragraph 42 below).

(3) The Secretary of State has accepted that the decision in A's case amounts to a breach of her policy. A
was not a high risk FNO. That acceptance therefore only makes sense if the protective ambit of Article 3
cases was not intended to be restricted to high risk FNOs.

28. Accordingly, I do not find that there was a policy intent to limit the protection of Article 3 rights to high
risk FNOs, and to exclude someone such as A from its scope. I do, however, accept the logic of Ms
Dubinsky's argument that strict and literal adherence to the flowchart in the unpublished policy risks having
this effect. It will therefore be necessary to address whether, in practice, the Secretary of State's staff
confine themselves to the tramlines of the flowchart, or whether they take a more purposive approach so
as to achieve what I am prepared to accept is the true policy intent.

_The published Schedule 10 guidance_

29. The Secretary of State has also published (on the internet) guidance on the policy that is taken to the
provision of accommodation under Schedule 10. It is addressed to all those acting on behalf of the
Secretary of State on immigration bail matters. It refers to the statutory test for the provision of Schedule 10
accommodation, and the threshold condition of “exceptional circumstances.” The versions of the guidance
which applied from the date Schedule 10 came into force until 5 April 2019 said:

“The exceptional circumstances are:

SIAC cases [an explanation is then given of SIAC cases]

Harm cases [an explanation is then given, in effect those who are assessed as being at a high or very high
risk of causing serious harm to the public]

European Convention on Human Rights: article 3 cases

It may be appropriate to consider using the power to provide accommodation under paragraph 9 to
accommodate individuals who do not fit within the categories above, but only usually where the following
circumstances apply:


-----

1912 (Admin)

they do not have adequate accommodation or the means of obtaining it…

the provision of accommodation is necessary in order to avoid a breach of their human rights

The consideration of whether the provision of accommodation is necessary to avoid a breach of the
person's human rights will usually require an assessment of whether they are likely to suffer inhuman or
degrading treatment contrary to Article 3 of the European Convention on Human Rights (ECHR) if they are
not provided with accommodation and other assistance to meet their daily living needs while they are in the
UK. However, decision makers should only provide accommodation for these reasons if it is clear that the
person cannot reasonably be expected to leave the United Kingdom.

The expectation is that this will cover people with serious physical or mental health problems who would
not otherwise fall to be supported under other arrangements.

Decision makers should also note that it will not be appropriate to use this power to accommodate the
following categories of migrant:

…

- other migrants who have dependent children: if the family cannot obtain adequate accommodation it will
usually be available through the duties local authorities have to safeguard and promote the welfare of
children under Section 17 of the Children Act 1989, or the equivalent in the devolved administrations

- migrants accommodated under the provisions of the _[Care Act 2014,or the equivalent in the devolved](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)_
administrations – generally, they will have been accommodated because they have a serious disability,
exceptionally, however, accommodation may be arranged temporarily under the power in paragraph 9
whilst the case is referred to a local authority and pending a decision by that local authority as to whether
[the duty to provide accommodation under the Care Act 2014 (or equivalent) applies”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)

30. Ms Dubinsky suggests that the words “The exceptional circumstantial circumstances are…” (rather
than wording such as “Circumstances which might be considered as exceptional include…”) suggest that
this is a closed, exhaustive list, such that caseworkers are prohibited from considering whether other
circumstances, not on the list, might be thought exceptional.

31. As with the unpublished policy, nothing in these versions of the published guidance indicates how a
FNO might apply for accommodation or make representations in support of the provision of
accommodation. It is an internal process without any necessary input from the person affected. There is a
page of the policy entitled “Informing detainees of their immigration bail rights.” It provides helpful
information about the steps to be taken to ensure that detainees are aware of their right to apply for bail. It
says nothing about Schedule 10 accommodation.

32. Version 4 of the published guidance was promulgated on 5 April 2019. It contains the same 3
categories – SIAC cases, Harm cases and Article 3 cases. However, instead of the introductory words
“The exceptional circumstances are:”, the categories are introduced by the following paragraph:

“Exceptional circumstances

The power may be exercised only if the Secretary of State thinks that there are exceptional circumstances
to justify doing so. The types of cases where exceptional circumstances will normally justify providing
accommodation under paragraph 9 of Schedule 10 are SIAC cases, Harm cases and European
Convention on Human Rights: Article 3 cases.”

33. Mr Metcalfe argues that the word “normally” cures any vice occasioned by the word “are” in the
previous policy. It shows that the categories not exhaustive and that there is scope to consider other
circumstances as being exceptional.

34. Ms Dubinsky contests that interpretation. She argues that the word “normally” in this context narrows
the circumstances in which any of the closed list of three categories will amount to exceptional
circumstances, rather than indicating that other categories are available for consideration. Whereas,
pre io sl the three categories ere each deemed to constit te e ceptional circ mstances (“are”) no


-----

1912 (Admin)

there is merely a recognition that they will ordinarily (“normally”) amount to exceptional circumstances, but
with the corollary that they will not always amount to exceptional circumstances. What, in context, the word
does not do, is permit caseworkers to treat anything outside the closed list of three categories as
exceptional.

35. I do not think it profitable to seek to resolve this debate by reference only to the language of the
paragraph. More helpful is the evidence as to the application of the policy in practice. As to that evidence, I
have the facts of the three cases that are before me (although see the point about selection bias in
paragraph 185 below). I have witness statements from the Secretary of State's officials as to how the policy
is intended to operate. I have evidence from Bail for Immigration Detainees (“BID”), a charity that provides
legal advice, information and representation to people who are in immigration detention and which has
considerable experience in this area. I summarise this evidence below. Given the nature of this challenge I
am confident that if there were good examples of caseworkers not treating the policy as setting out a
closed list of exceptional circumstances then I would, one way or another, have been told about them.
There is no evidence before me of any caseworker ever considering whether something outside the three
specified cases is capable of amounting to an exceptional circumstance.

36. This version of the guidance does have a new paragraph that was not in the earlier iterations (under a
section “Requests for accommodation”) which states:

“Individuals who are SIAC cases or foreign national offenders are not required to make a separate request
for accommodation under paragraph 9 of Schedule 10. They should set out their needs in the bail
application form, B1 or BAIL 401 as appropriate, and these will be assessed as part of the bail
consideration process. All other individuals who are not asylum seekers or failed asylum seekers will need
to set out the reasons why they consider that accommodation should be provided under paragraph 9 of
Schedule 10 on form BAIL 409, in addition to their application for bail. This applies to those in immigration
detention and those on immigration bail in the community. The form is included in the immigration bail pack
given to detainees on induction to detention and is also available on GOV.UK for all who need to use it.
The completed BAIL 409 must be sent to the address shown on the form.”

37. So, this says that forms B1 and Bail 401 can be used to set out why a FNO needs Schedule 10 bail
accommodation. In fact, these forms do not enable a FNO to do that. Neither form says anything about
Schedule 10 accommodation. Form B1 is the appropriate form to apply for bail from the Tribunal. It has
been in use since before the 2016 Act came into force, and it has not been substantially amended as a
result of Schedule 10 of the 2016 Act. Form Bail 401 is the appropriate form to apply for bail from the
Secretary of State. Neither form asks questions that would readily elicit the information necessary to
determine whether an individual is eligible for Schedule 10 accommodation. The closest it gets is question
13 of Bail 401 which asks “Do you have an address to reside at if the Secretary of State grants you bail”
which is answered by completing a “yes” or “no” tick box. There is no supplementary question in the event
that the individual does not have an address.

38. Mr Metcalfe points out that section 4 of the form asks the question “what are the reasons why you
think the Secretary of State should grant you bail.” The guidance for completing the form requires bail
applicants to “set out all the reasons why you think the Secretary of State should [grant] you bail”. They are
told to “give as much detail as possible” and that they are permitted to use “additional sheets of paper.” He
argues that there is nothing to stop applicants from using this part of the form to request Schedule 10
accommodation. Strictly, he is right. However, it is quite unrealistic to expect applicants to do that. The
questions do not naturally elicit that information and there is nothing (beyond version 4 of the guidance to
caseworkers, which is not proactively provided to FNOs) in the published guidance to suggest that
Schedule 10 accommodation should be sought in this way. There is a mismatch between the information
that is required for a Schedule 10 decision (eg as to whether the person would be rendered street
homeless as a consequence of release) and the information that is sought by the question (ie why the
person should be released).


-----

1912 (Admin)

39. Version 4 of the guidance contained a new paragraph relating to the provision of information to
detainees. It says:

“Detainees must also be given BAIL 403 during their induction to detention. This contains information on:

…

    - how to apply for immigration bail accommodation (using form BAIL 409)”

40. Again, this is incorrect. Form BAIL 403 contains no information about how to apply for immigration bail
accommodation.

_Correspondence about the operation of the policy_

41. Very shortly after the introduction of the _[Immigration Act 2016,BID became concerned about the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
approach being taken to Schedule 10 accommodation. By an email dated 25 January 2018 (so 10 days
after the Act came into force) its Assistant Director, Pierre Makhlouf, wrote to the Home Office:

“We have received bail summaries that state that our clients are not entitled to exceptional circumstances
accommodation as they have not shown that such circumstances exist. Yet:

There is no process for applying to the Home Office for such accommodation and support.

The new Home Office bail policy makes some sweeping statements about persons who will be excluded
from support and seems to attempt to restrict entitlement to certain categories.

The policy seems to accept the Limbuela interpretation that a person would face an Article 3 violation if left
homeless and destitute, but it does not introduce any procedure for such **individuals who may need to**
apply for bail.” [Emphasis in original].

42. On 6 March 2018 the following response was provided by the Home Office:

“There is no separate process for applying for “exceptional circumstances” accommodation. Exceptional
circumstances only ever become a consideration if:

bail is granted subject to a condition requiring a person to reside at a specified address; and

the person would not be able to support themselves at the specified address if the Secretary of State does
not exercise the power to provide support.

…

In cases in which the Secretary of State is proactively considering granting bail, she will assess whether a
relevant residence condition is necessary and will make a decision as to the exercise of the paragraph 9
power on the basis of the facts that she has available.

In cases in which the individual is making an application for bail, either to the Secretary of State or to the
Tribunal, it is for the individual to make clear that a relevant residence condition is sought, and that the test
in paragraph 9 (including the “exceptional circumstances” test) would be made out if it were granted.

…In cases in which the Tribunal decides to impose a residence condition that satisfies the requirements of
the test in paragraph 9, it will be for the Secretary of State to decide subsequently if there are exceptional
circumstances.”

43. So, this suggests that an applicant may raise the question of Schedule 10 accommodation by making
an application for bail and, within that application, identifying the circumstances that are said to be
exceptional. There is nothing in versions 1-3 of the published guidance to alert individuals to this intended
process (as to version 4, see paragraph 36 above). Nor, as I explain above, is there anything in the bail
forms that would naturally elicit information that is relevant to a Schedule 10 application.


-----

1912 (Admin)

44. Not deterred by the absence of any bespoke form for a Schedule 10 application, BID (in reliance on
the letter of 6 March 2018) wrote to the Home Office to make a Schedule 10 application, and explained
why the circumstances should be considered exceptional. The following response was received:

“We are in receipt of your letter… in which you have requested for your client to be sourced with
accommodation provided by the Home Office under Schedule 10, Residence Condition. Unfortunately, the
Home Office cannot accept any “applications” for Schedule 10 from representatives. There is no process
for a Representative to apply for Schedule 10 as it is the Home Office's decision to decide whether a
Residence Condition under Schedule 10 is suitable or not.”

45. The logic of the final sentence of this extract is difficult to fathom. BID raised this in a letter of 10 April
2018. It received a holding response 4 months later on 6 August 2018:

“Your letters have highlighted some issues with access to accommodation from immigration detention,
which we are working to resolve. This is taking longer than anticipated but we want to make sure we get it
right.”

46. On 24 September 2018 BID chased for a substantive response. None came.

_The operation of the policy_

47. Mr Cockell, an Acting Assistant Director of the Home Office, has filed a witness statement in Mr
Humnyntskyi's claim. He explains the application of the Schedule 10 policy in that case. He accurately
refers to the three recognised categories of exceptional circumstances, and then says:

“The Claimant was assessed as being medium risk and therefore did not qualify. Harm indicators are set
out in the guidance.”

48. He then accurately sets out the Article 3 category and says:

“Only those foreign national offenders who have been assessed as high harm of risk to the public, qualify
for Schedule 10 accommodation.

…based on the offender manager's assessment, a referral to Schedule 10 was not made from the SSHD's
criminal casework unit. The First Defendant properly applied their own policy in respect of the Claimant.
Such accommodation is only available to foreign national offenders at a high or very high risk of causing
serious harm to the public or reoffending. The Claimant presents only a medium risk of harm.”

49. This suggests that Mr Cockell was interpreting the policy in the way suggested at paragraph 25 above,
only to consider Schedule 10 accommodation for high risk FNOs, and excluding other FNOs from
consideration even where accommodation would be required to avoid a breach of Article 3. This is also
consistent with the response to the pre-action letter of claim in which a Home Office Director said that Mr
Humnyntskyi was not eligible for Schedule 10 accommodation because he was not a high risk (see
paragraph 72 below). Mr Metcalfe says that this is infelicitous language and that it is not intended to limit
consideration of Article 3 to high risk cases.

50. Ms Dolby is a grade 7 civil servant who has responsibility for enforcement policy, which includes the
policy on Schedule 10 accommodation. In her statement she confirms that there was no application
process for Schedule 10 accommodation. She explains the rationale thus:

“because the majority of persons to whom the exceptional circumstances apply are national security cases
or foreign national offenders convicted of criminal offences, it was not considered appropriate [to introduce
an applications process] - the decision to provide support if necessary based on the assessment of
whether the FNO is eligible, is made by the Secretary of State.”

51. Ms Dolby explains the process that is applied as follows:

“The preliminary assessment of an FNO's eligibility under Schedule 10 is carried out in the first instance by
the FNO's caseowner in the Criminal Casework Directorate… If the CCD caseowner has satisfied
themselves that no other form of support is available on release and that the FNO is a high harm case


-----

1912 (Admin)

they will consider the provision of Schedule 10 as a last resort, but only where they are satisfied that the
initial essential criteria (eg high or very high harm, destitution) have been met.

As part of this assessment, the CCD caseworker will ask the FNO's offender manager at HM Prison and
Probation Service (“HMPPS”) to complete a release proforma in relation to the FNO…. This contains up-todate risk/harm information… As explained previously, the FNO must present a high or very high risk of
causing serious harm to the public… as well as meet the other criteria set out in the Secretary of State's
policy.”

52. This again might suggest that “high harm” is a pre-condition to the provision of Schedule 10
accommodation, consistent with the approach taken by Mr Cockell. Again, Mr Metcalfe says that this is due
to infelicitous language and is because the focus of this paragraph was the provision of Schedule 10
accommodation under the “high harm” (as opposed to the Article 3) gateway. Again, I am prepared to
accept that this is the case. It is, however, striking that two separate witnesses who have particular
knowledge of this policy area, and who were providing statements to deal with complaints made about the
policy, should express themselves in this way. It reinforces the need to scrutinise how in fact the policy is
being operated. The policy itself is potentially misleading (in that it suggests a decision making process that
is not intended). The officials responsible for the policy express themselves in a misleading way (in that
they suggest that only high risk FNOs are considered for Schedule 10 accommodation). There is an open
question as to whether those operating the Schedule 10 policy have, nonetheless, correctly understood
how it is intended to operate.

53. Ms Dolby completes her explanation of the process as follows:

“If, having received the completed proforma from the HMPPS, the explicit criteria appear to be met, the
CCD caseowner will refer the FNO's proforma on to the Criminal Casework Accommodation Team
(“CCAT”) for further consideration. … If the CCAT refuses to grant accommodation, the CCD caseworker
will likewise be notified of the explanation… If accommodation is refused, the CCD will complete a bail203
form to confirm the refusal decision.”

54. This reinforces the point that the FNO is largely excluded from the process of deciding whether
Schedule 10 accommodation should be provided. The possibility that there might be input from the FNO is
not addressed. If the caseowner decides not to refer the case to CCAT then the FNO will not necessarily
(or even ordinarily) be informed. It is only if the matter is referred to CCAT, and CCAT makes a refusal
decision, that the individual will receive notification by way of a “Bail 203” form. Moreover, because the
decision is made by CCAT, not the caseowner, there is no scope for direct communication between the
FNO and the decision maker. Everything goes through the filter of the caseowner. But there is no explicit
obligation on the caseowner to pass to CCAT any information provided or representations made by the
FNO.

55. Ms Dolby explains that it “was considered to be overly burdensome” to make provision for an
application process for “the small number… who would be eligible for Schedule 10 bail support under
Article 3 ECHR”. However, “[f]ollowing further consideration” (the Claimants say this resulted from litigation
rather than being initiated by the Secretary of State) the Home Office decided, from 5 April 2019, to
introduce an application process for “non-FNOs” (but not for FNOs themselves) who could seek
accommodation by completing form BAIL 409. That is a bespoke form for those seeking immigration bail
accommodation to prevent a breach of Article 3. It asks questions that are apt to elicit relevant information,
such as “will you become destitute or street homeless if granted immigration bail” (and many more
besides). Mr Metcalfe said that there is nothing to prevent FNOs from using this form. Again, strictly, that is
so. There is, however, this warning on the Home Office website (on the page containing form 409): “Do not
use this form… if the Home Office is considering you for deportation because you are a foreign national
offender.” If the reader disobeys that instruction and opens the form, then the instructions on the form itself
say “Do not use the form if you are being considered for deportation because you are a Foreign National
Offender (FNO). If you are an FNO please contact the caseworker allocated to you in the Criminal


-----

1912 (Admin)

Casework Unit.” Mr Metcalfe argues that this shows that FNOs are positively directed to contact the
caseworker allocated to them if they wish to make an application for Schedule 10 accommodation.

56. I have been provided with extensive evidence on behalf of the Claimants as to the operation of the
system in practice. This comprises evidence from BID based on its experience, evidence based on
[information secured in response to requests made under the Freedom of Information Act 2000,and other](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4H0-TWPY-Y1K2-00000-00&context=1519360)
anecdotal evidence. I am certain that the evidence has been provided in good faith with the intention of
putting a true picture before the court. It is helpful, and I have taken it into account. However, by the nature
of this type of evidence it can only ever amount to part of the picture, and there is a possibility that it gives
(unintentionally) a distorted view.

57. The Claimants' evidence suggests that Schedule 10 accommodation has been provided sparingly.
[Information provided under the Freedom of Information Act 2000 shows that in the 8 month period between](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4H0-TWPY-Y1K2-00000-00&context=1519360)
15 January and 17 September 2018 51 people were granted Schedule 10 accommodation. By contrast, in
2017 there had been 2,824 grants of accommodation (BID is careful to explain not necessarily all to
different people, so this might overstate the position) under the 1999 Act.

58. Out of 15 randomly selected detainees where BID made requests for accommodation, conditional
grants of bail were made in 7 cases. In all those cases accommodation was refused (so the conditional
grants of bail lapsed, as they did in the cases of Mr Humnyntskyi and A, albeit in A's case resulting in a
grant of bail without a residence condition). In only 2 cases were written responses provided for the refusal.
In a separate review of 22 cases in February 2020 where there was (or may have been) an internal
process for determining whether to grant Schedule 10 accommodation, none of the FNOs had been
informed of the process or asked to make representations or otherwise provide input. That was consistent
with BID's more general experience that FNOs are not asked to provide representations in support of the
provision of Schedule 10 accommodation.

59. BID says that in its experience there are, in principle, two main routes to an eligibility decision on
Schedule 10 accommodation for FNOs. The first is where the Secretary of State, of her own motion,
formulates a release plan (this is what is contemplated in the unpublished guidance). The second is where
an individual or solicitor requests Schedule 10 accommodation.

60. Karris Hamilton of Gatwick Detention Welfare Group (“GDWG”), a Detainee Advocacy Coordinator,
says that GDWG has encountered repeated problems of detainees not being aware that Schedule 10
accommodation exists or how they might be eligible for it, or how they might apply for it. This has resulted
in individuals remaining longer in detention. Where grants of bail are made conditional on the provision of
Schedule 10 accommodation, the Secretary of State does not make a decision on Schedule 10
accommodation before the grant of bail lapses. Others are granted bail without a residence condition and
become street homeless, either immediately or after a period of “sofa surfing”. She is not aware of any
case where the Secretary of State has communicated to a person in detention that they have been
considered for and refused Schedule 10 accommodation (whereas this does happen in respect of the
provision of support under section 4 of the 1999 Act). It is not clear to GDWG how Schedule 10
accommodation can be obtained, again in contrast to the position under section 4 of the 1999 Act.

**The facts of the three cases**

_Mr Humnyntskyi's case_

61. Mr Humnyntskyi is a national of Ukraine. He says that he came to the United Kingdom in 2004.
Between December 2007 and January 2018 he committed 35 offences, predominantly theft and drug
offences. They included taking a mobile phone and cannabis into a prison, resulting in a sentence of 21
months' imprisonment. On 8 January 2018, he was convicted of possession of a Class A drug. He was
sentenced to 12 weeks' imprisonment. He was due to be released on 18 February 2018. He would then
ordinarily have been under licence conditions until the end of his sentence. Following the end of his
sentence he was subject to post-sentence supervision pursuant to section 256AA Criminal Justice Act


-----

1912 (Admin)

2003. The supervision requirements imposed under that provision included an obligation (when not in legal
custody) to reside permanently at an address approved by his supervisor.

62. Mr Humnyntskyi was not released on 18 February 2018. Instead, he was detained by the Secretary of
State pending his deportation. He claimed to be a national of Estonia and he used a false name and date
of birth. On 21 March 2018, the Estonian Embassy denied that Mr Humnyntskyi was an Estonian national.
By 23 August 2018, the Ukrainian authorities identified Mr Humnyntskyi from his fingerprints and confirmed
that he was a Ukrainian national. He continued to protest that he was Estonian.

63. On 12 September 2018 a request for accommodation under Schedule 10 was made in these terms:

“…were our client to be released, he would become both destitute and homeless. This we contend would
be a breach of his rights as protected under Article 3 of ECHR, by virtue of placing him in a position both
degrading and inhuman.

We therefore maintain that [Mr Humnyntskyi's] circumstances are exceptional and justify being provided
with an address sourced by the Home Office, as envisaged under Schedule 10 of the Immigration Act
2016…”

64. On 19 October 2018 the request was repeated in similar terms. There was no response to these
requests. An application for bail was made on 17 October 2018 in which it was said that Schedule 10
accommodation was sought. In response, the Secretary of State said that there was no record of any
application for Schedule 10 accommodation. It was said that Mr Humnyntskyi had not provided a release
address and that, for that reason alone, bail should be refused.

65. On 24 October 2018 Mr Humnyntskyi was granted conditional bail by the Tribunal:

“Conditional bail granted on the basis that the applicant is able to provide a suitable residential address
approved by the HO, and the probation service, if necessary, within 14 days. Alternatively, if the HO
provide accommodation within 14 days, then that will be acceptable. If no suitable accommodation has
been provided on either basis within 14 days, this grant of conditional bail lapses, and no further judicial
decision is required to confirm that it has come to an end.

Depending upon the circumstances, if bail lapses after 14 days, there may be grounds to submit a further
bail application on the grounds of material change in circumstances. The applicant has been in detention
for a lengthy period of time and his continued detention is approaching the outer limits of reasonableness,
under the circumstances.”

66. A note in the Defendant's records written on 25 October 2018 (but before the author of the note was
made aware of the outcome of the bail hearing) states:

“Thank you for the attached request from BID in relation to Schedule 10 accommodation, however we are
unable to accept requests for Schedule 10 support from representatives. If you think that Mr Humnyntskyi
meets the criteria for Schedule 10 support then you have to complete the release pro forma and send that
over to our team to action. If you don't think that he is eligible then you can complete a Bail.203 and send
to the representatives.”

67. A subsequent note records the basis for the grant of conditional bail and adds:

“Based on the above, it is considered that at present there is no obligation for the Home Office to provide
accommodation.”

68. On 29 October 2018 Mr Humnyntskyi offered an address for bail and asked, in the alternative, for the
provision of Schedule 10 accommodation. There was no response. An internal note dated 14 November
2018 states:

“With regards to Schedule 10 accommodation Mr. H is not eligible for this as he has been assessed by
probation as MEDIUM risk of HARM to the public.”


-----

1912 (Admin)

69. On 16 November 2018 Mr Humnyntskyi's representatives again sought Schedule 10 accommodation
and reapplied for bail. On 23 November 2018 the Tribunal again granted Mr Humnyntskyi conditional bail:

“Bail is granted in Principle. The Respondent shall seek suitable accommodation, in discussion with the
Probation Service, but the Applicant is not to be released until Probation has approved the address; if not
provided by 7th December 2018 the decision lapses. Such accommodation to be compatible with any
conditions of the supervising Probation Officer and any other Court/Police orders or notices.”

70. Again, the Secretary of State did not respond to the request for a Schedule 10 address. A chronology
prepared for the Secretary of State (for the purpose of a subsequent bail hearing) records:

“5 December 2018 contacted CCAT Schedule 10 team, to ascertain whether he is eligible for Schedule 10
accommodation, as probation have assessed his risk of harm as MEDIUM. Application for Schedule 10
accommodation are only for HIGH harm cases. Forwarded the letter from BID in relation to this.”

71. An entry on 28 December 2018 records:

“…the criteria for consideration of Schedule 10 support is that the applicant must meet both of the following
criteria:

¿ Subject to a residency condition

¿ High or very high harm

It is noted that the applicant claims he is subject to a residency condition, however a CID note… clearly
states this applicant is not, and is also of “medium” risk of harm, and will not therefore be eligible under
Schedule 10.”

72. On 7 January 2019, in a response to a pre-action protocol letter of claim sent from the Defendant's
“General Group Managed Migration Directorate”, the same point was made:

“your client was assessed by his offender manager… as Medium Risk of Harm… In view of his medium
risk of harm, your client is not eligible under the published guidance for Schedule 10 support.

…

Therefore, a referral to CCAT Schedule 10 accommodation was not made to them by criminal casework,
as he does not meet the requirements of the published guidance.”

73. On 23 January 2019 these proceedings were issued, challenging the legality of Mr Humnyntskyi's
continued detention. The proceedings were brought in the false name that Mr Humnyntskyi had been
using, and made clear that he maintained that he was Estonian. The Claim Form was supported by a
statement of truth.

74. As it happens, on the day that these proceedings were issued, Mr Humnyntskyi was interviewed by a
Ukrainian official. Mr Humnyntskyi admitted his true name and nationality. The Ukrainian Embassy issued
a travel document for Mr Humnyntskyi the next day, 24 January 2019.

75. Mr Humnyntskyi's solicitors then sought urgently to address the consequences of Mr Humnyntskyi
having misled the court (and them) as to his true identity. An application for interim relief was withdrawn. It
was accepted that, at this point, Mr Humnyntskyi's detention was lawful because it now appeared that he
could imminently be removed to Ukraine. The Secretary of State consented to Mr Humnyntskyi having
permission to amend the Claim Form. It was duly amended to give Mr Humnyntskyi's correct name.

76. On 8 March 2019 Mr Humnyntskyi signed a disclaimer form agreeing to voluntary departure. On 18
March 2019 the Tribunal recorded that Mr Humnyntskyi had withdrawn his appeal. The deportation order
was signed on 27 March 2019. On 10 May 2019, the Ukrainian Embassy issued a further travel document
for Mr Humnyntskyi's removal.

77. Mr Humnyntskyi sought bail on 15 May 2019. The Secretary of State's bail summary said:


-----

1912 (Admin)

“The applicant has been assessed by the offender manager as MEDIUM risk of harm to the public.
Therefore does not meet the criteria for Schedule 10 accommodation, only those applicants who have
been assessed by probation as HIGH harm offenders can apply for Schedule 10 accommodation. The
applicant does not qualify for this.”

78. Mr Humnyntskyi was removed from the UK on 29 June 2019.

_A's case_

79. A is a national of South Africa. He was granted a visa to visit the United Kingdom in 2005. He
unlawfully failed to leave when his visa expired. Instead, he implemented a plan to “disappear”: he first
travelled to Ireland, where he stayed for 3 months, before then returning to the United Kingdom by ferry
(without having to show his South African passport). He undertook cash in hand employment and paid rent
in cash. He had no bank account. He avoided detection for almost 12 years.

80. On 2 May 2017 A was sentenced to 16 months' imprisonment following his guilty plea to offences of
making 1,454 indecent images of a child, possessing 1,071 prohibited images of a child and possessing an
extreme pornographic image.

81. On 13 July 2017, the Secretary of State served A with a decision to deport him from the UK. A
completed a “disclaimer” indicating that he was aware that he was entitled to lodge representations against
deportation but that he wished to leave the UK without doing so. On 31 July 2017 a deportation order was
made.

82. A would have been released on licence from his sentence on 28 December 2017. Licence conditions
under the _[Criminal Justice Act 2003 were set for the period until sentence expiry on 1 September 2018.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
These included that A must:

“Reside permanently at an address approved by the supervising officer and obtain the prior permission of
the supervising officer for any stay of one or more nights at a different address…”

83. A was not released. Instead, he was detained pending his deportation. A's South African passport had
expired, so it was necessary for a travel document to be secured before he could be deported. There is
evidence that applications for travel documents for South Africa, and returns to South Africa, were not
taking place in late 2017 and early 2018.

84. On 26 April 2018 A was interviewed by the South African High Commission in order to obtain a travel
document. On 30 April 2018 A applied to the Secretary of State for bail. He pointed out that he had been
detained for 4 months, that he was cooperating with the redocumentation process, that he had done
everything possible to facilitate his removal but that returns to South Africa were not apparently taking
place. His representative wrote:

“The Applicant has no-one to support him financially or with accommodation if he is released. He requests
that he be provided with accommodation under paragraph 9 of Schedule 10 to the Immigration Act 2016 on
the basis that his rights will otherwise be breached under Article 3 ECHR. He would end up street
homeless if released without such support.

Please note that our client is still subject to licence conditions and he would be in breach of his licence if he
were released to no fixed abode. …”

85. The application for bail was refused because of: (a) the likelihood that A would fail to comply with a bail
condition, (b) the offences he had committed, (c) the likelihood that he would commit an offence while on
immigration bail, (d) the assessed fact that detention was necessary for the protection of another person,
(e) the fact that travel document applications for South Africa had resumed and the Secretary of State was
waiting for a decision on A's application from the South African High Commission. For those reasons the
Secretary of State considered that A's continued detention was both necessary and proportionate.

86. By 13 September 2018 A was no longer subject to licence conditions. A travel document had still not
been obtained A had not made any further application for bail The Secretary of State nevertheless gave


-----

1912 (Admin)

consideration to a “release accommodation plan”, including whether accommodation should be provided
under Schedule 10. This was done without seeking any input from A. The Secretary of State addressed the
risk of harm to society, the propensity for reoffending and the consequential impact of reoffending, the
likelihood of absconding and the repercussions from absconding. These assessments were not provided to
A. Accordingly, he was not able to make any representations about them. There was no assessment of the
consequences for A if he were released without accommodation being provided. There was therefore no
assessment of whether accommodation should be provided (as required by the Secretary of State's policy)
in order to avoid A being subject to inhuman or degrading treatment within the meaning of Article 3 ECHR.
On 16 October a decision was made by “the accommodation team” not to provide accommodation under
Schedule 10. The following reasons were given:

“- Not exceptional due to medium harm & reoffending

- Despite my request for tagging this does not meet criteria

- It does not appear that any other form of support would be suitable either at the present time.”

87. The Home Office's internal notes record:

“On checking this case would not appear to meet the criteria for s10 as not exceptional due to medium
harm and reoffending and despite request for tagging does not meet criteria".

88. These reasons did not engage with the reasons why A had originally sought accommodation, namely
to avoid him being rendered homeless. Nor did they engage with the policy guidance that accommodation
ought to be provided in Article 3 cases. A was not provided with reasons for the decision, so he was unable
to address its flaws. He was simply told that the request for accommodation had been refused.

89. The accommodation team recommended that the possibility of private accommodation should be
explored, but if this was not feasible then it could be explained to A that he could apply for bail even if he
did not have a release address. By this time A had been detained under immigration powers for almost 10
months. A travel document had not been provided, and he could not return to South Africa without one. A's
reaction is described in the Home Office's documentation thus:

“…A stated the Home Office are driving him to suicide, that he has no options left as the South African
officials have refused to accept him back and he was stuck here indefinitely. Mr A stated he felt that there
is no light at the end of the tunnel and he was at the end of his tether. He claimed to have feelings of self
harm. He also questioned how the Home Office could be so inhumane. As a result of this, he was placed
on an ACDT.”

90. On 1 November 2018 A applied for Tribunal bail. He pointed out that his removal to South Africa
appeared “to be on hold indefinitely” and contended that he should be granted “bail in principle” on the
basis that the Home Office should then provide accommodation. The Home Office response was that
Schedule 10 accommodation had been refused because A “does not pose a high or very high risk of harm
or a high risk of harmful offending against an individual.”

91. On 8 November 2018 the Tribunal granted bail. The Secretary of State was given until 22 November
2018 to arrange suitable accommodation, but thereafter A was to be released on 22 November 2018
whether or not accommodation had been provided.

92. The Secretary of State again considered the question of provision of accommodation, but this was
again refused because “there is no evidence that [A] meets any of the exceptional circumstances required
for support.” There was no reference to the obligation to provide accommodation in Article 3 cases.

93. Accordingly, A was released on 22 November 2018. He stayed with a succession of friends between
then and 23 March 2019. At that point he became street homeless, and slept in a tent in Reading. A was
reliant on a Church drop-in service for food and basic hygiene needs. I set out the circumstances in greater
detail when addressing A's Article 3 claim (see paragraphs 204 - 205 below).


-----

1912 (Admin)

94. On 26 July 2019 A's representatives made a request for Schedule 10 accommodation. It was
explained that A was destitute with no cash or any other assets, and that he was street homeless (and had
been for 4 months). Concerns were raised about A's anxiety. It was contended that his destitution was in
breach of his rights under Article 3 ECHR.

95. By 22 August 2019 there had been no substantive response. A's solicitors sought an update.

96. On 9 September 2019 the Secretary of State refused to provide accommodation. It was said that
“Schedule 10 is not an application process, it is a referral process by the case owner” and that,
accordingly, A's case had been dealt with by reference to section 4 of the 1999 Act. Accommodation was
refused because A was not a failed asylum seeker, and he was not therefore eligible for accommodation
under section 4 of the 1999 Act. That is correct, although it misses the point that the application had
(correctly) been made by reference to Schedule 10 of the 2016 Act. It was said that the Secretary of State
required 6 months of bank statements in order to prove that A was destitute (missing the point that A did
not have a bank account). A was incorrectly told that he had a right of appeal to the Tribunal.

97. After further chasing correspondence, the Secretary of State responded on 7 November 2019. She
pointed out that A had not appealed against the decision to refuse support under section 4 of the 1999 Act:
“you should have taken the opportunity to appeal this decision and have an Independent Adjudicator
consider your submissions.” It was said that A did “not fit the criteria for support under Schedule 10”, but
without explaining why he did not do so.

98. After further correspondence, on 10 December 2019 A's representatives sent to the Secretary of State
a letter before action challenging the failure to provide A with accommodation. The Secretary of State did
not provide a substantive response.

99. On 15 January 2020 A issued these proceedings, challenging the failure to grant accommodation, the
failure to operate a fair and rational system to determine eligibility for Schedule 10 support, and the
apparent policy of limiting accommodation under Schedule 10 to “high harm” cases.

100. On 22 January 2020 the Secretary of State made a decision granting Schedule 10 accommodation to
A, on the basis that he “met the criteria for support”. No explanation was given for the change in stance.
However, accommodation was not, at that stage, made available.

101. On 28 January 2020, following a hearing at which the Secretary of State was represented, Mr
Timothy Brennan QC (sitting as a deputy Judge of the High Court) granted interim relief to A, requiring the
Secretary of State to vary A's bail conditions and provide Schedule 10 accommodation to A by no later
than 30 January 2020. A was not accommodated by 30 January. He remained street homeless. A was
belatedly provided with accommodation on 7 February 2020.

_WP's case_

102. WP is a national of Poland. She was homeless in the UK and living on the streets from August 2019.
There is evidence that she was raped and/or sexually assaulted. She was, for a period, detained under the
_[Mental Health Act 1983. In late November she was arrested on suspicion of offences including assault on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0F8-00000-00&context=1519360)_
an emergency worker.

103. She was seen by a Home Office official on 26 November 2019. She said she was “[u]nsure of her
offence - pushed a security guard in McDonalds when trying to use the toilet.”

104. On 18 December 2019 she was convicted of assault of an emergency worker, using
threatening/abusive words/behaviour likely to cause harassment/alarm, and destroying or damaging
property. She was sentenced to 14 days' imprisonment. She would have been released because of the
time that she had spent on remand pending sentence. However, she was detained by the Secretary of
State pursuant to section 62(1) Nationality Immigration and Asylum Act 2002, pending a decision whether
to give directions for administrative removal. She was served a notice setting out the reasons for detention
as follows:


-----

1912 (Admin)

“It has been decided that you should remain in detention because…

- There is insufficient reliable information to decide on whether to grant you immigration bail.

…

This decision has been reached on the basis of the following factors…

- You do not have enough close ties (eg family or friends) to make it likely that you will stay in one place.

- You have not produced satisfactory evidence of your identity, nationality or lawful basis to be in the UK.”

105. On 20 December 2019 the Secretary of State notified WP that she was liable to administrative
removal in accordance with section 10 of the 1999 Act as an EEA national who has ceased to have a right
to reside under regulations 23(6)(a) and 32(2) of the Immigration (European Economic Area) Regulations
2016.

106. On 31 December 2019, WP lodged a notice of appeal against her removal on the basis that it would
breach Article 3 ECHR.

107. On 3 January 2020, the Secretary of State's Senior Enforcement Officer decided that consideration
must be given to WP's release because “removal cannot be said to be imminent”.

108. Over the following days it was clear that WP was not going to cooperate in her removal. She refused
even to provide her biodata. It was, however, made abundantly clear that she would be street homeless if
she were released – so much so that she preferred to be kept in detention than released to the streets. An
entry on 6 January 2020 records:

“I explained that the caseowner would now be reviewing her case and making a decision on whether she
will be detained or not. She got very irate and said it was her human right not to be put on the street, she is
homeless and has nowhere to go and insisted she should be kept in prison until the conclusion of her
appeal.

…Having calmed her down a couple of times and managed to get from her that she has nowhere to go and
she believes it is the UK Govts responsibility to either find her some accommodation or allow her to stay in
prison (she was very clear that she only want to stay in prison and not a detention centre) I eventually gave
up, as she was becoming more angry and agitated.

It is possible that I may still be able to get the bio-data completed on another day, but today she was far too
hostile and just wouldn't listen (I had when I last saw her showed her how to book an appointment for the
link, where she can get help on accessing emergency accommodation etc).

She appears to be suffering from the previous substance abuse and her moods swing quickly and she also
struggles to either listen or understand simple things.

I think if she is released, it is likely she will re-offend.”

109. On 10 January 2020 an entry was made in the notes as follows:

“14 day detention review authorised and on doc.gen.

Subject has lodged an appeal, appeal bundle is required at Lunar House by 25/1/2020.

Subject has stated she is homeless and has refused to complete a bio data, does not want to leave the
prison until she has secured accommodation.”

110. On 14 January 2020 WP was transferred from prison to Yarl's Wood Immigration Removal Centre.
Her medical notes record that she was displaying:

“very odd behaviour whilst screening, constantly talking to herself (…) sudden body movements and
twitching (…) is very hyper… previous mental health issues…”.


-----

1912 (Admin)

111. On 17 January 2020, a nurse at Yarl's Wood made a note that WP had a history of mental illness and
“in my professional opinion she is not fit to be detained and will need hospital admission and treatment.”

112. On 20 January 2020, there is a record: “I have spoken to our mental health lead at Yarls Wood IRC
who states that in his opinion she is not fit for release if she has no address.”

113. The Secretary of State's notes dated 20 January 2020 record:

“Healthcare further advised that it is highly likely that she will be sectioned under the Mental Act and
transferred to a mental institute within days or weeks.

Although CCD have informed us that they intend to grant bail because she has lodged an appeal, she
cannot be released from detention at this stage for safeguarding reasons.”

114. An entry the following day indicated that the Criminal Casework Non-Criteria team “would not be
minded to exercise our power to detain beyond the end of this week”. On 22 January 2020 WP was
assessed by a forensic psychiatrist who was satisfied that WP was fit for detention and did not require
hospitalisation. The note records:

“Currently no sign of acute mental illness noted and is happy for her to be detained here in Yarlswood and
will not need hospitalization.

…

Was homeless and maybe taken advantage of by strangers when released to no fix abode.”

115. This final sentence (“taken advantage of by strangers”) must be read in the context of the recognised
possibility that WP had been raped and/or sexually assaulted whilst living on the streets.

116. A note of 23 January 2020 stated “the Home Office will be looking to release her today or tomorrow”,
but that WP's detention could be maintained if she signed a voluntary removal disclaimer (because then
removal could take place very quickly). It further stated: “If she refuses she should be signposted to
charities dealing with homeless people and details of any local authorities that might be able to assist her
(as an EEA national) to get accommodation. I would strongly suggest that this be done in writing”.

117. A note on 24 January records that WP might be willing to return to Poland because she knew she
would be homeless if she remained in the UK. Three days later WP signed a disclaimer that she was
willing to return to Poland voluntarily. WP says that she signed the form to avoid homelessness.

118. On 10 February 2020 WP indicated that she wished to proceed with her appeal against removal. She
withdrew her voluntary return disclaimer the following day. Her solicitor wrote:

“We put the Home Office on notice that if our client is released to homelessness, that decision will be
swiftly subject to a judicial review application. Our client is an incredibly vulnerable woman whom has
mental health issues which were recently treated as an hospital inpatient. She has been physically and
sexually assaulted whilst previously homeless and destitute in the UK.

Therefore, we apply for Schedule 10 accommodation to be urgently provided to our client. It is not
appropriate to keep her in detention whilst she has in-country appeal ongoing, there are alternatives to
detention and due to her vulnerabilities; however it would be a breach of her human rights under Article 3
ECHR if she is released by the Home Office from detention to the streets.”

119. On 11 February 2020 the Secretary of State responded that the “question of release does not arise”.
There was no response to the request for Schedule 10 accommodation. It was said that the result of WP's
appeal would be expected within two weeks of the hearing date and “there is nothing stopping the Home
Office from setting removal directions”.

120. On 13 February 2020, at a Case Management Review Hearing, WP's appeal hearing was adjourned
to 17 April 2020.


-----

1912 (Admin)

121. On 14 February 2020 WP's solicitors repeated their request for Schedule 10 accommodation. A
further letter was sent on 20 February 2020 making the same request, and also seeking a referral to the
National Referral Mechanism (“NRM”) on the basis that WP was a potential victim of trafficking. A referral
to the NRM was made the following day.

122. On 22 February 2020 WP was assessed by a medical practitioner, Dr Asif Khan, who prepared a
report under Rule 35(3) of the Detention Centre Rules 2001:

“Patient claims to be a victim of torture and I believe that based on her accounts she may be a victim of
torture. Her scars are consistent with her history of events. Although she is currently stable in detention, I
do believe that she may deteriorate with prolonged detention. She is receiving mental health support from
both the counselling service and the consultant psychiatrist.”

123. The Secretary of State received the report on the same day, but “due to staff shortages” the report
was not forwarded to the Rule 35 Referrals Team until 25 February 2020.

124. On 25 February 2020 WP's solicitors were informed that the Secretary of State was minded to
release WP but that it was necessary to establish that “the criteria relating to the grant of [Schedule] 10
accommodation has been met”. Further it was “deemed that it would be reasonable to await the [NRM
decision] before determining whether and how the subject ought to be addressed.” WP's solicitors were
asked to outline why WP met the criteria relating to the grant of accommodation and supply any
documentary evidence in support of her vulnerability.

125. On 2 March 2020 WP's solicitor complained that (a) the Single Competent Authority had failed to
make a decision following the referral of WP to the NRM, (2) the Secretary of State had failed to respond to
the rule 35 report, (3) there had been a “total lack of engagement with our correspondence and enquiries”
and (4) WP continued to be detained.

126. On 4 March 2020 the Secretary of State, acting as the Single Competent Authority, decided that
there were no reasonable grounds to conclude that WP was a victim of trafficking/modern slavery. On the
same day the Secretary of State's Senior Enforcement Officer recommended WP's release from detention
noting that removal was not imminent, that WP was at level 2 of the Adults at risk in detention policy, and
ongoing detention was not appropriate because there were “vulnerabilities and alternative measures which
could be utilised, such as weekly reporting conditions.”

127. On 5 March 2020 WP was informed that she would be released from detention “upon
accommodation being secured”. Detailed reasons were given for reaching this conclusion. The following
day WP's solicitors requested that the Secretary of State grant WP Schedule 10 accommodation as soon
as possible, stating that this was necessary to avoid a breach of WP's human rights under Article 3 ECHR.

128. On 10 March 2020 WP's representatives submitted a bail application on WP's behalf to the Tribunal.
On the same day an internal note recorded that whilst WP would not be released that day it was “highly
likely” that this would happen in the “near future”.

129. On 11 March 2020 a release plan pro forma was submitted to the CCAT. It was deemed invalid by
the CCAT. This was explained thus to WP:

“They subsequently informed us that on the information your representatives had thus far supplied it was
unlikely that you would be assessed as High Harm and due to lack of medical evidence that would show
how you meet the Vulnerability assessment. The application was therefore deemed invalid.”

130. An internal note stated: “… Legal reps have requested Schedule 10 accommodation. A referral is to
be made but it is not considered she meets the exceptional circumstances qualifying criteria”.

131. On 11 March 2020 Ms Price wrote to WP's solicitors:

“… As to the ongoing detention, since the coming into force of our new immigration bail policy, it has not
been possible for detainees and their representatives to seek release from detention in general
correspondence. They are required to complete a Bail 401 application. That is why she was supplied with a


-----

1912 (Admin)

bail pack on 15 January 2020 and explained to her by an Engagement Officer at the Detention centre. Any
request for a Schedule 10 accommodation should be included in the bail application. We apologise if our
correspondence did not reiterate that point. In any event it has always been open to the subject and those
representing her to seek bail from the First-tier Tribunal.

… there is no immigration bail application pending before us and this will remain the position unless and
until a completed Bail 401 application is put before us…”

132. On 12 March 2020 WP's solicitors completed a Bail 401 form. The form does not include any place
for addressing a request for Schedule 10 accommodation (see paragraph 37 above), but WP's solicitors
nonetheless set out such a request in the section dealing with 'Reasons for Applying for Bail'.

133. On 16 March 2020, CCAT made a decision to refuse Schedule 10 accommodation to WP stating
“based on the evidence you have supplied the subject would not get Schedule 10 support”. It was not clear
what information had been supplied to CCAT or why Schedule 10 support had been refused. On 17 March
2020, CCAT emailed Ms Price stating “we have not received a valid referral form to make a Schedule 10
decision. When you have all the details please re-apply and make a new referral for Schedule 10”.

134. WP's bail application was due to be heard by the Tribunal on 19 March 2020. On 18 March 2020, the
Secretary of State provided a bail summary in advance of the hearing, which stated:

“We have been informed from the information at hand, that it is unlikely that [the] applicant would be
assessed as High Harm and there is no medical evidence before us at present that shows how she would
meet the Vulnerability assessment. However, if supporting evidence is provided as advised, the Home
Office can assess this information if bail in principle has been agreed.…”

135. On 18 March 2020, Ms Price emailed WP's solicitor asking for documentary evidence as to how WP
met the criteria for Schedule 10 accommodation. The email stated: “you are not able to make this
application directly to the accommodation team on behalf of your client, it is either something we
recommend via a referral we make to this team… or it could also take the form as a request through a bail
application and this being granted in principle…” WP was asked to provide the documents within the next 5
working days, otherwise the Secretary of State would be “minded to release her to no fixed abode”.

136. WP instructed her solicitor to withdraw her bail application because she was “terrified of potentially
being released to street homelessness.”

137. On 23 March 2020 WP's solicitors sent to the Secretary of State a letter before action.

138. On 26 March 2020, a caseworker agreed to raise a further Schedule 10 referral to the
accommodation team. That was then done 5 days later.

139. On 1 April 2020 WP's solicitors requested a timescale for the Schedule 10 accommodation decision
and put the Secretary of State on further notice of their intention to issue judicial review proceedings.

140. By email dated 2 April 2020 the Secretary of State confirmed that WP's entitlement to Schedule 10
support had been agreed. The Secretary of State stated that it was not possible to give a timescale as to
when accommodation would be made available to WP (due to Covid-19).

141. By a further pre-action letter dated 2 April 2020 WP's solicitors sought a specific time-scale and
warned of their intention to issue proceedings if WP were not released with appropriate accommodation
and support.

142. On 6 April 2020 the Secretary of State responded stating that she could not provide a precise
timescale for a response but would review the position in “about the next seven days”.

143. WP issued these proceedings on 8 April 2020. On 16 April 2020 Cavanagh J granted interim relief,
requiring that accommodation be provided by 23 April 2020. WP was released from detention to Schedule
10 accommodation on 22 April 2020.

**The individual claims**


-----

1912 (Admin)

**(1) Humnyntskyi v SSHD**

_Argument_

144. Ms Dubinsky argued that the way in which Mr Humnyntskyi's requests for accommodation were dealt
with was unlawful and that rendered his detention unlawful. They were illustrative of the systemic
complaints made about the policy: requests for accommodation were not treated fairly, and the Secretary
of State refused to contemplate the provision of Schedule 10 accommodation to a FNO who was not high
risk.

145. Mr Metcalfe contended that once Mr Humnyntskyi admitted his true nationality he was swiftly
deported, thereby bringing his detention to an end. The delay in deportation, and hence his detention, was
entirely due to Mr Humnyntskyi's lies as to his identity and nationality. He therefore brought his detention
upon himself. The Secretary of State was entitled to refuse Schedule 10 accommodation. Mr
Humnyntskyi's claim was an abuse of the court's process.

_Is Mr Humnyntskyi's claim an abuse of the court's process?_

146. Mr Humnyntskyi's case, as originally formulated, was brought in a false name, and contained the
dishonest assertion that he was Estonian. Estonia (correctly as it turned out) refused to accept that he was
an Estonian national. This was a significant cause of the length of time that Mr Humnyntskyi spent in
detention. The reason he was granted bail was because of the amount of time he had spent in detention
and the lack of any imminent prospect of his removal. If Mr Humnyntskyi had told the truth about his
Ukrainian nationality then his removal could have been effected much more quickly. It is highly unlikely
that, in those circumstances, he would have been granted bail. Any grant of bail would have been revoked
once the true facts became known.

147. Accordingly, as Mr Metcalfe puts it, “[o]n the true facts of his case [Mr Humnyntskyi] was never
entitled to immigration bail, still less accommodation under Schedule 10… [T]he only reason [Mr
Humnyntskyi's] eligibility for Schedule 10 accommodation was even at issue was because he had
fraudulently obtained two grants of conditional bail. [His] claim stands on the rotten branch of his
dishonesty.”

148. There is jurisdiction to strike out a statement of case on the grounds that it amounts to an abuse of
the court's process – see CPR 3.4(2)(b). The purpose of proceedings brought under the CPR is to deal
with cases justly and at proportionate cost (see CPR 1.1(1)). CPR 3.4(2)(b) is part of a procedural code
designed to enable courts to deal with cases justly. It is an abuse of the court's process to seek to use the
court's processes for an improper purpose. Where a party conducts proceedings in a way that is designed
to prevent a fair trial then that may amount to an abuse of process. In Arrow Nominees Inc v Blackledge

[2000] EWCA Civ 200 a petitioner in proceedings brought under the _[Companies Act 1985 had, in the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJX0-TWPY-Y0R5-00000-00&context=1519360)_
course of standard discovery, produced fraudulent documents which rendered it impossible to determine
the case fairly. The Court of Appeal struck out the petition - see per Chadwick LJ at [55]:

“a fair trial is a trial which is conducted without an undue expenditure of time and money; and with a proper
regard to the demands of other litigants upon the finite resources of the court. The court does not do justice
to the other parties to the proceedings in question if it allows its process to be abused so that the real point
in issue becomes subordinated to an investigation into the effect which the admittedly fraudulent conduct of
one party in connection with the process of litigation has had on the fairness of the trial itself. That, as it
seems to me, is what happened in the present case. The trial was “hijacked” by the need to investigate
what documents were false and what documents had been destroyed. The need to do that arose from the
facts (i) that the petitioners had sought to rely on documents which Nigel Tobias had forged with the object
of frustrating a fair trial and (ii) that, as the judge found, Nigel Tobias was unwilling to make a frank
disclosure of the extent of his fraudulent conduct, but persisted in his attempts to deceive. The result was
that the petitioners' case occupied far more of the court's time than was necessary for the purpose of
deciding the real points in issue on the petition. That was unfair to the Blackledge respondents; and it was
unfair to other litigants who needed to have their disputes tried by the court ”


-----

1912 (Admin)

149. In the present case, Mr Humnyntskyi's dealings with the Secretary of State, and the Tribunal, were
fundamentally dishonest. If he had given an honest account then he would not have been detained for
such a long period of time. Mr Metcalfe is right that, in large measure, he brought his detention upon
himself.

150. That does not mean that his conduct of these proceedings is abusive. Although he issued the claim in
a false name, as soon as his solicitors became aware of the true position they acted with speed and
energy to amend the claim. The Secretary of State did not oppose the amendment. Nor was there any
application to strike out the claim. The Secretary of State opposed the grant of permission, contending the
proceedings were an abuse of process. Sir Wyn Williams considered the Secretary of State's objection but
granted permission for Mr Humnyntskyi to claim judicial review.

151. Ms Dubinsky argues that the purpose of Mr Humnyntskyi bringing these proceedings is to seek the
vindication of his legal rights and to secure a ruling from the court that (notwithstanding his admitted
dishonesty) he was unlawfully detained and unlawfully refused Schedule 10 accommodation. He does not
seek any award of damages (and any claim for substantive damages would be met by an argument that
the true cause of Mr Humnyntskyi's losses was his own dishonesty such that any award of damages
should be nominal only). It has not been suggested that Mr Humnyntskyi has any other purpose in bringing
these proceedings. Nor is there any reason to consider that the proceedings cannot be fairly determined.
Mr Humnyntskyi has admitted his dishonesty and there is no significant dispute about the underlying facts.
What remains to be determined is the legal consequences of those facts. Mr Humnyntskyi is an
unsympathetic litigant. But he is far from unique in that respect and it emphatically does not exclude him
from a right of access to the court (see R (Kambadzi) v Secretary of State for the Home Department _[2011]_
_UKSC 23 [2011] 1 WLR 1299per Baroness Hale at [61])._

152. I was not shown any authority remotely comparable to the current circumstances where a claim was
treated as abusive. By contrast, the conduct of the claimant in R (B(Algeria) v Special Immigration Appeals
_Commission [2018] UKSC 5 [2018] AC 418(whose claim proceeded to the Supreme Court whilst he was_
refusing to reveal his true identity – see _per_ Lord Lloyd-Jones JSC at [6]-[8]) and the Claimants in _R_
_(Lumba) v Secretary of State for the Home Department [2011] UKSC 12 [2012] 1 AC 245was, arguably, at_
least as egregious as that of Mr Humnyntskyi - see the first instance decision of Davis J, _[[2008] EWHC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TNY-RCD0-Y96Y-H1P1-00000-00&context=1519360)_
_[3166 (Admin) at [53] – [88] - but that was not a reason for depriving them of a remedy. Davis J said (at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TNY-RCD0-Y96Y-H1P1-00000-00&context=1519360)_

[50]):

“In one sense none of the claimants appeals very much to a sense of the merits: and some of them very
decidedly do not. One might have thought that some kind of reciprocity, in the form at least of seeking to
behave in a responsible and law abiding way, should be expected from someone in whose case a country
has been prepared to grant leave to enter or remain. Not so…

… But… [t]hose unlawfully detained (if they are unlawfully detained) should have the appropriate remedy,
even if “undeserving”, no less than those unlawfully detained however “deserving”. The law cannot
discriminate in such a context: and a broad, and in some respects subjective, appeal to “the merits” should
not be permitted to subvert legal certainty and the proper application of firmly established principles.”

153. The Supreme Court in Lumba expressly rejected a submission advanced by the Secretary of State
that claims for unlawful detention should leave out of account periods of time where the detainee was
pursuing hopeless challenges to removal – see per Lord Dyson JSC at [111] - [121].

154. For all these reasons, Mr Humnyntskyi's claim is not an abuse of the court's process.

_Is Mr Humnyntskyi's claim academic?_

155. Mr Humnyntskyi has now been returned to Ukraine. There is no evidence that he will seek to return to
the United Kingdom. There is therefore no question of him continuing to be detained by the Secretary of
State or of him seeking Schedule 10 accommodation.


-----

1912 (Admin)

156. There is, however, a live issue between the parties as to whether the Secretary of State unlawfully
detained Mr Humnyntskyi. That gives rise to a claim for declaratory relief (but not a claim for damages). To
that extent, Mr Humnyntskyi's claim is not academic.

157. Further, there is a live issue as to whether the Secretary of State's decision to deny Mr Humnyntskyi
accommodation was unlawful. If that issue had stood alone then it would not have been proportionate to
entertain substantive judicial review proceedings – it does not have any continuing effect on Mr
Humnyntskyi, there is no real prospect that Mr Humnyntskyi will, in future, need to rely on Schedule 10 of
the 2016 Act, and the issue arises against the contrived background that Mr Humnyntskyi was presenting
as an Estonian national. It is, however, necessary to resolve this issue in order to determine Mr
Humnyntskyi's claim that he was unlawfully detained.

158. Moreover, Mr Humnyntskyi seeks to advance a challenge to the Secretary of State's policy more
generally. That is academic so far as Mr Humnyntskyi is concerned because it will not be applied to him
and he will secure no benefit from a determination as to the policy's legality. However, this is a live issue in
the other two cases. For the reasons given below (see paragraphs 190 - 198 and 224) I have rejected the
Secretary of State's argument that those cases should not be heard on the grounds that they are
academic. It is also likely to be a live issue in other cases. It has been fully argued before me. I recognise
the need to exercise caution in drawing inferences about the operation of policy from its application in an
individual case. So long as that necessary caution is applied, the facts of Mr Humnyntskyi's case throw
some light on the practical workings of the policy over many months, by different caseworkers, in response
to determined and skilful attempts to utilise the policy by experienced solicitors. For these reasons, and the
reasons I have given more fully in respect of A's case, I consider it appropriate to rule on the issues that
have been raised.

_Was Mr Humnyntskyi unlawfully denied Schedule 10 accommodation?_

159. Mr Humnyntskyi was subject to a post-release supervision requirement to live in accommodation that
had been approved by the probation service. He was under a statutory obligation to comply with that
requirement – see section 256AA(2) Criminal Justice Act 2003. Breach of the requirement, without
reasonable excuse, would render Mr Humnyntskyi liable to a term of imprisonment for up to 14 days (or a
fine, or a community sanction) – section 256AC(4) of the 2003 Act. Moreover, I was told that, not
surprisingly, the Tribunal will not grant bail to a person who is subject to such a requirement unless an
approved address has been provided.

160. In those circumstances, there was no real prospect of Mr Humnyntskyi securing bail unless either the
requirement was removed, or the Secretary of State provided Schedule 10 accommodation. Further, the
grant of condition bail by the Tribunal indicates that it took the view that the period of detention was
reaching the outer limit of what was reasonable. It is for the Secretary of State to decide whether
circumstances are “exceptional” so as to permit the grant of accommodation, subject only to the court's
reviewing jurisdiction. I do not make any finding as to whether these were exceptional circumstances: that
would risk usurping the Secretary of State's decision-making function. I do, however, consider that the
Secretary of State would have been entitled to consider that they were exceptional circumstances. Mr
Metcalfe did not suggest otherwise.

161. The issue was squarely put before the Secretary of State by the grant of conditional bail on 23
November 2018, which directed the Secretary of State to “seek suitable accommodation… compatible with
any conditions of the supervising Probation Officer and any other Court/Police orders or notices.”

162. Following that direction (at the latest) the Secretary of State ought to have considered whether the
circumstances justified the provision of accommodation. There is no evidence that the Secretary of State
considered whether Mr Humnyntskyi's situation was exceptional so as to merit the grant of
accommodation. All of the evidence suggests that a decision was made that Mr Humnyntskyi did not
qualify for accommodation because he was not a high risk FNO. In other words, the FNO risk gateway was
treated as being a necessary rather than a sufficient condition for the grant of Schedule 10


-----

1912 (Admin)

accommodation. No consideration was given as to whether there might be some other exceptional feature
to justify the provision of accommodation.

163. Moreover, Mr Humnyntskyi requested Schedule 10 accommodation by his letters in September and
October 2018. He did so by pointing to the risk that he would become destitute and suffer inhuman and
degrading treatment. That is a factor which is specifically identified in the Secretary of State's policy as
being capable of amounting to exceptional circumstances so as to justify, in principle, the provision of
accommodation. On the facts, I do not consider that there was a real and immediate risk of Mr
Humnyntskyi suffering such treatment. It is unlikely that he would have immediately become street
homeless: he had previously suggested an address where he could stay (although it had not been
approved and so would be in breach of the post-sentence supervision condition). The failure to consider
his application by reference to Article 3 was not, therefore, a breach of section 6 of the Human Rights Act
1998. Ms Dubinsky does not suggest otherwise. Mr Humnyntskyi was, however, entitled to have his
request considered and that simply did not happen.

164. Mr Metcalfe argues that there was some evidence that Mr Humnyntskyi had accommodation
available to him, and that in any event the Secretary of State was entitled to conclude that he did not come
within any category that she would have been bound to treat as exceptional. There is force in that
submission, but only if the Secretary of State had adopted a fair process and addressed her mind to all
relevant matters. That did not happen.

165. It follows that the decision not to provide Mr Humnyntskyi with accommodation was unlawful because
there was a failure to have regard to material considerations, namely to consider whether Mr
Humnyntskyi's circumstances were exceptional by reason of his post-sentence residence condition and/or
a risk of inhuman and degrading treatment and/or the observations made and directions given by the
Tribunal when granting bail. Put another way, the Secretary of State unlawfully fettered her own discretion
to provide accommodation in exceptional circumstances by treating the fact that Mr Humnyntskyi was not a
high risk FNO as determinative of his entitlement to accommodation.

166. Ms Dubinsky further argues that the failure to provide accommodation was in breach of a duty owed
“to use reasonable endeavours to provide a bail address if the person concerned would otherwise be likely
to remain in detention” (see R (Razai) v Secretary of State for the Home Department [2010] EWHC 3151
_(Admin)_ _per Nicol at [26], recording a concession made by counsel in respect of section 4(1)(c) of the 1999_
Act). In _R (Sathanantham) v Secretary of State for the Home Department_ _[2016] EWHC 1781 (Admin)_

[2016] 4 WLR 128that concession was withdrawn, but Edis J found that section 4(1)(c):

“is a power coupled with a duty… to deal fairly and rationally with an application… is not, in practice, a
materially different duty from a duty to make reasonable efforts to provide accommodation [where the
person concerned would otherwise be likely to remain in detention.]”

167. Schedule 10 of the 2016 Act is more restrictive than section 4(1)(c) of the 1999 Act, in part because
of the need to show “exceptional circumstances”. That difference is not a reason for departing from the
observations in _Razai_ and _Sathanantham_ that it imposes a duty to deal fairly and rationally with an
application for accommodation. In the context of Schedule 10, it is, at the least, a duty to consider fairly and
rationally whether there are exceptional circumstances so as to justify the provision of accommodation.
That did not here happen.

168. Although there was no consideration of Mr Humnyntskyi's requests for accommodation, it is clear that
a caseworker did consider whether to refer the matter to the team responsible for making decisions on
accommodation (see the letter of 7 January 2019 at paragraph 72 above). However, that consideration
took place without Mr Humnyntskyi's knowledge. He was kept ignorant of the decision not to refer the case
to the relevant team. He was given no opportunity to make representations. The requests he had made
were not taken into account. He was not informed that he was ineligible for Schedule 10 accommodation.
He was not given a right of appeal, or a right to ask for the decision to be reviewed. It is not necessary, for
these purposes, to identify the minimum ingredients of a fair process in this context. On any view, the
process that took place was unfair


-----

1912 (Admin)

_Was Mr Humnyntskyi unlawfully detained?_

169. For the reasons given above, the decision communicated on 8 January 2019 not to provide Mr
Humnyntskyi with Schedule 10 accommodation was unlawful because it was unfair and because the
Secretary of State failed to have regard to relevant factors. That is so whether or not the Secretary of State
could have made a lawful decision to refuse accommodation.

170. A public law error which bears on and is relevant to a decision to detain renders that decision
unlawful – see _R (Lumba) v Secretary of State for the Home Department [2011] UKSC 12 [2012] 1 AC_
245per Lord Dyson at [68]. That is so whether or not the error caused the detention. The detention is
unlawful even if detention could (or even would) have been lawfully imposed but for the public law error –
see per Baroness Hale in Lumba at [207]:

“the breach of public law duty must be material to the decision to detain and not to some other aspect of
the detention and it must be capable of affecting the result - which is not the same as saying that the result
would have been different had there been no breach.”

171. It is therefore not relevant to the question of the legality of the detention (as opposed to quantum of
damages) that detention could have been justified on some basis other than that which was relied on at the
time – see per Lord Kerr at [242] and [247]:

“…Detention cannot be justified on some putative basis, unrelated to the actual reasons for it, on which the
detention might retrospectively be said to be warranted. Simply because some ground of lawfully detaining
may exist but has not been resorted to by the detaining authority, the detention cannot be said, on that
account, to be lawful.

…if the policy which is applied is unlawful, the exercise of discretion is unlawful. The individual has not had
applied to his case the proper exercise of discretion to which he is entitled. The application of an unlawful
policy will therefore ipso facto render the decision to detain unlawful.”

172. Here, there can be no doubt that the decision to refuse Mr Humnyntskyi Schedule 10 accommodation
bore upon and was relevant to the decision to detain him. He had the benefit of a grant of bail, subject only
to the provision of accommodation. The provision of Schedule 10 accommodation was capable of affecting
the question of whether he would be detained (indeed, on the facts, it did affect that question – the more
exacting test of causation is satisfied). Accordingly, Mr Humnyntskyi's detention was unlawful.

173. This does not necessarily mean that it was unlawful from the moment of the decision to refuse
accommodation. There is a dispute between the parties as to how Lumba illegality plays out in a case such
as this where there is an interim stage between the public law illegality (here the refusal to provide
accommodation) and the decision to detain. That interim stage is, in this case, the process of taking the
practical steps necessary to secure accommodation and make it available to Mr Humnyntskyi. Mr Metcalfe
agrees that the fact of the interim stage does not prevent the detention authority from being vitiated of legal
justification (see _R (Diop) v Secretary of State for the Home Department_ _[[2018] EWHC 1934 (Admin),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWK-Y1V1-F0JY-C19R-00000-00&context=1519360)_ _R_
_(DN (Rwanda)) v Secretary of State for the Home Department_ _[2020] UKSC 7 [2020] 2 WLR 611). Mr_
Metcalfe says that the detention only becomes unlawful from the point in time where the accommodation
would have been provided. This point is acutely illustrated by the facts of A's case where there was a 3
week time period between the eventual decision to provide accommodation and it being made available to
A. In A's case (where illegality is admitted) Mr Metcalfe submits that the detention only became unlawful 3
weeks after the earlier unlawful decision to refuse accommodation. So too here, he submits that Mr
Humnyntskyi's detention only became unlawful at a point, some weeks after the unlawful refusal to provide
accommodation, when accommodation would have become available if the Secretary of State had acted
lawfully.

174. Ms Dubinsky says that this is inconsistent with the clear finding of the Supreme Court in Lumba that
there is no causation test. She argues that the detention becomes unlawful as soon as there is a public law
error which bears on the decision to detain. Here, that is at the time of the unlawful decision to refuse
accommodation The effect is illustrated by an example addressed by Ms Dubinsky in argument Take two


-----

1912 (Admin)

individuals in materially identical situations, X and Y. They are each lawfully detained on 1 January. In X's
case, the Secretary of State lawfully decides, on 2 January, to secure Schedule 10 accommodation,
recognises that this will take 2 days to secure, and lawfully detains X until 4 January before releasing her
on bail to the accommodation. In Y's case, the Secretary of State unlawfully refuses to provide Schedule
10 accommodation with the result that Y remains in detention. Ms Dubinsky agrees that in X's case the
detention is lawful from 2 January, but argues that in Y's case the detention is unlawful from 2 January
onwards (as opposed to from 4 January onwards – the date she would have been released), with the result
that Y would be entitled to release on a writ of habeas corpus (albeit she says that the Court would be
entitled to stay such a writ for a short period whilst accommodation was provided). She argues that to hold
otherwise is wrongly to impose a causation test, contrary to the outcome in Lumba.

175. On this point I do not accept the full extent of either party's submission. So far as Mr Metcalfe's
argument is concerned there is no principled basis for determining the moment at which detention
becomes unlawful by reference to the point in time when the Secretary of State would in fact have provided
accommodation. That really would be to apply a causation test. It would also fail to cater for any unlawful
delay in the provision of the accommodation by the Secretary of State.

176. The key to the issue is the basis for illegality as explained in _Lumba. It is that the public law error_
vitiates the later detention decision of its legality. Causation is no part of the test, but there are two different
components in play – the public law error and the decision to detain. It is only at the point that the latter is
vitiated that the detention becomes unlawful. The detention decision is only vitiated at the point at which it
is capable of being impacted by the public law error – until that point the public law error does not bear on
the detention decision. In Lumba the public law error was the adoption of a secret detention policy. It was
only at the point that that policy was applied to a particular detainee that that detainee's detention became
unlawful. In the example of X and Y the decision as to whether to provide accommodation was not capable
of bearing on the decision to detain until 4 January, because there was no question or possibility of release
until that date. Conversely, from that point it was capable of bearing on the decision to detain and the
detention decision is therefore vitiated, even if a lawful decision to detain would have been made but for
the public law error. That is shown by changing the facts of the hypothetical comparator, X, so as to
assume that a lawful decision would have been made, on 4 January, to withhold bail notwithstanding the
availability of Schedule 10 accommodation. X's detention would be lawful throughout. In Y's case, by
contrast, no separate decision is made on bail because Schedule 10 accommodation has not been
provided. Y's detention is unlawful because the public law error in the Schedule 10 decision making was
capable of bearing on detention from 4 January, even though (as the facts played out) it would not in fact
have made a difference. The question is not when the Secretary of State would have provided Schedule 10
accommodation. The question is when is the earliest date by which Schedule 10 accommodation could or
(if earlier) should have been provided (because it is from that date that a public law error in the
accommodation decision is capable of bearing on the detention decision).

177. I do not think that the date when accommodation should have been provided in Mr Humnyntskyi's
case is reliably determined by the 3 weeks that it took the Secretary of State to provide accommodation in
A's case. Rather, it is determined by reference to what would have been a reasonable time in all the
circumstances. That will include any restrictions on the accommodation that is suitable which might impact
on supply (for example, where the offender is high risk and the accommodation needs to be approved by
the National Probation Service, or where the accommodation needs to be in a particular location where
there is a supply shortage). It also includes the degree of urgency (for example, where the detainee is at
real and immediate risk of suffering a deterioration in their mental health as a result of incarceration, or, in
the case of someone who is already on bail, where they are street homeless and/or at real and immediate
risk of facing inhuman or degrading treatment). It may also include general market and supply
considerations (for example, if it were shown that restrictions imposed as a result of the Covid-19
emergency had an impact on the availability of accommodation).

178. In Mr Humnyntskyi's case any accommodation needed to be approved by the Probation Service.
However, he was not a high risk FNO and there is no suggestion that there was any particular restriction


-----

1912 (Admin)

on the location of accommodation. He was not at real or immediate risk of suffering a deterioration of his
mental health or of being street homeless so as to give rise to an exceptional degree of urgency, but he
was deprived of his liberty. The relevant time period pre-dates Covid-19 lockdown.

179. In all these circumstances I consider that a period of 1 week is reasonable. That seems to me to be
consistent with the time periods that have been adopted in the authorities:

(1) In R (Qarani) v Secretary of State for the Home Department _[2017] EWHC 507 (Admin) Philip Mott QC,_
sitting as a deputy High Court Judge, considered that a week was sufficient to organise accommodation
(longer than the 48 hours that might otherwise have been appropriate, because the offender was a sex
offender who was subject to residence notification requirements and MAPPA involvement) and that 3
weeks was too long (see at [74]).

(2) In R (AC (Algeria)) v Secretary of State for the Home Department _[2020] EWCA Civ 36 the Court of_
Appeal considered that two weeks “would have been ample” for a serious sex offender who could only be
released to secure conditions, in the context of a history which showed that the Secretary of State had
known for many months that secure conditions would be required.

(3) In R (Merca) v Secretary of State for the Home Department _[[2020] EWHC Admin 1479 Fordham J held](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:603D-HCM3-CGXG-0364-00000-00&context=1519360)_
that a period longer than 2 weeks (which was 7 days from the date of his judgment) would be unjustified,
even taking into account that the Covid-19 pandemic had given rise to “special difficulties” (see at [12]
[13]).

(4) Orders for interim relief typically require the provision of accommodation within 7 days or less – see the
order of Timothy Brennan QC (sitting as a deputy High Court Judge) in A's case (2 days), and the order of
Cavanagh J in WP's case (7 days). Sometimes, where there is pressing urgency and no reason to consider
that compliance is impracticable, such an order might take effect within a matter of hours.

_Does the Home Secretary owe an obligation to liaise with Secretary of State for Justice in relation to_
_residence requirements?_

180. The agreed list of issues raises the question:

“What (if any) are the SSHD's legal obligations where an FNO detained under the Immigration Acts cannot
be released on bail owing to the combination of (i) a residence requirement imposed under s256AA of the
Criminal Justice Act 2003 and (ii) the non-provision of Schedule 10 accommodation?”

181. Ms Dubinsky submits that in these circumstances there is an obligation on the part of the Home
Secretary to liaise with the Secretary of State for Justice with a view to amending or withdrawing the
condition imposed under the 2003 Act.

182. There was nothing to prevent Mr Humnyntskyi (or, more realistically, his representatives) from
directly asking that his post-sentence residence requirement be amended or withdrawn. I was shown no
convincing basis in law for the imposition of a duty on the Home Secretary to intervene on Mr
Humnyntskyi's behalf in this respect. Ms Dubinsky relied on the decision in _R (Bowen and Stanton) v_
_Secretary of State for Justice [2018] 1 WLR 2170. It is not, however, necessary to reach a final_
determination on this point which is not directly relevant to any of the relief that is sought.

_Article 5 ECHR_

183. I have found that Mr Humnyntskyi was unlawfully detained. Ms Dubinksy advanced, by reference to
Article 5 ECHR, a number of further reasons why it was said that Mr Humnyntskyi was unlawfully detained.
It is not necessary to address these.

_Did the errors in Mr Humnyntskyi's case arise from systemic failings?_

184. The central claim of all three Claimants is that the Secretary of State's policy is systemically unfair
and irrational. That claim is addressed below (see paragraphs 248 - 286). It is relevant to that claim to
assess the errors made in the individual cases and the extent to which these are (as the Secretary of State


-----

1912 (Admin)

contends) aberrations by individual caseworkers, or whether they are symptomatic of underlying systemic
or structural deficiencies in the policy.

185. It is possible that the errors in Mr Humnyntskyi's case were due to mistakes made by individual
caseworkers in spite of a perfectly fair and lawful policy. Caution should be applied not too readily to find
that errors reflect underlying systemic failings. However well designed and fair the system, it is inevitable
that errors will be made from time to time. Errors are not necessarily (or even ordinarily) indicative of
system failure. There is a considerable risk of selection bias if too much emphasis is placed on the
particular facts of the cases that happen to be before the Court. Almost by definition they are cases where
problems have arisen. On the other hand, they are also cases where the detainees were represented by
experienced and persistent legal representatives who were doggedly pursuing their clients' interests. In
that respect there ought to have been less opportunity for error than in cases where detainees were
unrepresented.

186. Beyond asserting that the errors were “aberrant” and were not due to any policy flaw, the Secretary of
State has not explained how the errors came to be made. There is no evidence from the caseworkers
concerned, and no evidence from their managers. There is no evidence that anyone has spoken to the
individuals concerned to seek to understand how the errors came to be made. There is no evidence of any
remedial steps being taken (for example, further training, reminding caseworkers of the criteria and
processes to be applied) so as to minimise the risk of further “aberrant” decision making.

187. In the absence of such evidence, the following features of Mr Humnyntskyi's case are consistent with
the errors being due to systemic or structural deficiencies in the policy:

(1) There were multiple errors by different caseworkers over a protracted period of time. It was not a single
error by a single caseworker.

(2) Two separate requests for accommodation went missing (see paragraph 64 above) and were not
addressed. Two further requests went unanswered (see paragraphs 68 and 70 above). This is consistent
with the policy not having a secure mechanism by which representations can be made in a way that
ensures they are considered.

(3) The errors are not isolated and different and random. They are repeated and consistent and form an
internal pattern. They are of the type that might be expected if they are due to a failing in the system.

(4) Thus, the failure to consider whether there were exceptional circumstances (eg by reason of the postsentence residence condition) is consistent with the three explicit categories in the published policy (SIAC,
high harm FNO and Article 3) being treated as a closed list (as the natural wording of the policy suggests,
at least for versions 1-3), such that the discretion to consider other cases as exceptional was unlawfully
fettered.

(5) The decision that lack of a high risk of harm is determinative of an application for accommodation is
consistent with the possible vice of the unpublished guidance identified by Ms Dubinsky (see paragraph 25
above).

(6) There are repeated references in the records to risk of harm being a determinative factor (see
paragraphs 68, 70 - 72 and 77 above).

_Is Mr Humnyntskyi entitled to substantial (as opposed to nominal) damages?_

188. This was initially an issue for determination. In the event, on the eve of the hearing Mr Humnyntskyi
withdrew his claim for damages. It is not therefore necessary to determine whether any award of damages
should be nominal (see _Lumba per_ Lord Dyson JSC at [95]) or whether a claim for damages should
otherwise be refused having regard to the claimant's wrongdoing (see _Patel v Mizra [2016] UKSC 42_

[2017] AC 467).

**(2) A v SSHD**


-----

1912 (Admin)

_Argument_

189. It is common ground that A met the criteria for a grant of Schedule 10 accommodation as an “Article
3” case and that the failure to grant such accommodation was unlawful. Ms Dubinsky contends that there
was, accordingly, a breach of A's right under Article 3 ECHR and that he is entitled to damages. Mr
Metcalfe contends that the conditions A endured did not meet the high minimum threshold required to
amount to inhuman or degrading treatment within the meaning of Article 3 and, for that reason, no award of
damages should be made.

_Is A's claim academic?_

190. The Secretary of State accepts that her decisions of 9 September 2019 and 7 November 2019 were
unlawful. A has now been provided with accommodation. The Secretary of State contends that his claim is
therefore academic. She contends that insofar as A seeks to maintain that he has suffered a breach of his
Convention rights, the appropriate course is to transfer the proceedings to the County Court “rather than to
maintain an academic application for relief in the Administrative Court.”

191. I agree that there is no issue as to the legality of the decision of 9 September 2019 – the Secretary of
State accepts that the decision was unlawful as being contrary to the Secretary of State's own policy. If the
claim were limited to a challenge to that decision, on that basis, seeking only declaratory relief, then I agree
that the claim would be academic. There are, however, broader elements to A's claim.

192. First, he contends that the refusal to provide him with accommodation was a breach of the prohibition
on degrading treatment pursuant to Article 3 ECHR. He contends that the decision was therefore unlawful
for this (separate) reason as being a breach of section 6 of the Human Rights Act 1998. He seeks a
declaration to that effect (which is not conceded by the Secretary of State). He also seeks damages under
section 8 of the Human Rights Act 1998 (again, not conceded by the Secretary of State). He has a right to
bring these claims – see section 7(1)(a) Human Rights Act 1998. At the time the claims were brought there
was an outstanding issue as to whether a mandatory order should be made under section 29(1) Senior
Courts Act 1981 requiring the Secretary of State to provide accommodation under Schedule 10 of the 2016
Act. The application for that order was appropriately made by this application for judicial review. It was
[plainly appropriate to bring the claim under the Human Rights Act 1998 within the same proceedings.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

193. At the point at which permission to claim judicial review was granted, the Secretary of State had
conceded that the decision was unlawful. It would have been open to the Court, at that point, to consider
transferring the proceedings to the County Court - see CPR 54.20 and CPR 30. The issue is whether
permission having been given for the claim to proceed to a substantive judicial review hearing, that power
should nevertheless now be exercised. In deciding whether to exercise that power it is necessary to give
effect to the overriding objective – see CPR 1.2(a). The case has now been fully argued. I cannot discern
any benefit in declining to rule on the issue and instead transferring the proceedings to proceed as a
private law action, for it to be re-argued and a determination made as to whether the Secretary of State
acted incompatibly with Article 3 ECHR. Such an approach would not save expense – it would give rise to
considerable extra and duplicated expense (cf CPR 1.1(2)(b)). Nor would it ensure that the case is dealt
with expeditiously – it would result in further delay before the case is resolved. I therefore decline to
transfer the proceedings out of the Administrative Court for the resolution of these issues.

194. Second, A remains in the United Kingdom and subject to deportation to South Africa. There remains
a statutory power to detain him pending his deportation. If the Secretary of State were to exercise that
power then it would be open to A to re-apply for bail. He considers that the processes adopted by the
Secretary of State, as demonstrated by the history of this case, are neither fair nor rational. He wishes to
secure the Court's ruling on this point, which is disputed by the Secretary of State, so as to protect his own
future interests. This point is not academic. It is in dispute between the parties and is not resolved or
avoided by the grant of accommodation.


-----

1912 (Admin)

195. Even where a claim is academic it may be subject to adjudication, although the discretion to decide
such a claim should be exercised with caution – R v Secretary of State for the Home Department ex parte
_Salem [1999] 1 AC 450per Lord Slynn at 457A:_

“The discretion to hear disputes, even in the area of public law, must be exercised with caution and
appeals which are academic between the parties should not be heard unless there is good reason in the
public interest for doing so as for example (but only by way of example) where a discrete point of statutory
construction which does not involve detailed consideration of the facts, and where large number of similar
cases exist or are anticipated so that the issue will most likely need to be resolved in the near future.”

196. The discretion should only be exercised where there are exceptional circumstances – _R (Zoolife_
_International Ltd) v Secretary of State for Environment, Food and Rural Affairs [2007] EWHC 2995 (Admin)_
_per Silber J at [36]:_

“…academic issues cannot and should not be determined by courts unless there are exceptional
circumstances such as where two conditions are satisfied in the type of application now before the court.
The first condition is in the words of Lord Slynn in Salem… that “a large number of similar cases exist or
anticipated" or at least other similar cases exist or are anticipated and the second condition is that the
decision in the academic case will not be fact−sensitive. If the courts entertained academic disputes in the
type of application now before the court but which did not satisfy each of these two conditions, the
consequence would be a regrettable waste of valuable court time and the incurring by one or more parties
of unnecessary costs.”

197. In Razai the Secretary of State argued that the claims were academic because the Secretary of State
had agreed to provide accommodation to the claimants and the relevant policy had been amended. Nicol J
rejected the submission that he should decline to consider the claims – see at [68]:

“For the reasons given by the Claimants I have concluded that I should not decline to consider the
applications on the grounds that they have become academic. The resolution of their individual
applications may well be material as and when it comes to the question of the appropriate remedy.
However, their cases do illustrate generic issues which, the Claimants say, demonstrate the unlawfulness
of the SSHD's policy and these can, at least to some extent, still be appropriately addressed. If this
occasion is not taken to consider them, there is a risk of further delay and potential injustice before another
case can reach a final hearing. I note that R (Salih) v Secretary of State for the Home Department _[2003]_
_EWHC 2273 (Admin) is another example of a case where the Court considered the lawfulness of the_
SSHD's general policy even though the individual claimants had already achieved the accommodation and
support which they had wanted when the proceedings commenced – see Salih at [2].”

198. Likewise, even if A's claim were (as regards the common challenge to the policy) properly to be
considered to be academic, because he now has accommodation, I nevertheless consider that it would be
appropriate to determine it, for the reasons given by Nicol J in Razai and also for the following reasons:

(1) He has been given permission to pursue the claim (and nothing has changed since the grant of
permission);

(2) The claim has been fully argued;

(3) The evidence of BID and GDWG (and the fact that there are two other cases before the Court)
suggests that these are recurring issues. If they are not addressed in this case it is likely that other similar
claims will be brought (I was told other claims already had been brought) and the issues would soon need
to be addressed in another case.

(4) The common challenge to the policy is, by its nature, not fact sensitive.

(5) The Secretary of State has accepted that the decision making in A's case was unlawful. She asserts
that this was an aberrant and isolated error. But there is no evidence that anything has been done to
address the error.


-----

1912 (Admin)

_Was the Secretary of State's decision to refuse to provide accommodation compatible with the prohibition_
_on inhuman or degrading treatment pursuant to Article 3 ECHR?_

199. The Secretary of State must, when deciding whether to provide Schedule 10 accommodation, act in a
way that is compatible with rights under the European Convention on Human Rights, unless compelled to
do otherwise by primary legislation – see section 6 Human Rights Act 1998.

200. The Secretary of State's published policies recognise that the provision of accommodation under
Schedule 10 may, in certain cases, be necessary to avoid a breach of a person's human rights if they are
otherwise likely to suffer inhuman or degrading treatment contrary to Article 3 ECHR (and where the
person cannot reasonably be expected to leave the UK, and the other conditions for Schedule 10
accommodation are met).

201. Mr Metcalfe expressly accepted that where a person is at real and immediate risk of suffering
inhuman and degrading treatment for want of accommodation, and the other conditions for the grant of
Schedule 10 accommodation are met, it will be unlawful not to provide such accommodation.

202. He stresses, correctly, that a minimum threshold of severity must be met before treatment will be
considered to be inhuman and/or degrading – see Kudla v Poland (2002) 35 EHRR 11 GC at [96]:

“ill-treatment must attain a minimum level of severity if it is to fall within the scope of Article 3. The
assessment of this minimum is, in the nature of things, relative; it depends on all the circumstances of the
case, such as the nature and context of the treatment, the manner and method of its execution, its
duration, its physical or mental effects and, in some instances, the sex, age and state of health of the
victim.”

203. Mr Metcalfe recognised that A had endured “very substantial hardship” during the period when he
was street homeless, but argued that it nonetheless fell short of the high minimum threshold set by Article
3. A was a 50 year old man with no particular health problems. He pointed out that by January 2020 A was
able to stay overnight in local churches. He was, for a period, provided with one hot meal a day. Before
that, he had been able to live in a tent. He also had occasional access to showering facilities and the use of
a bicycle.

204. Notwithstanding these observations, I am satisfied that the conditions endured by A amply met the
Article 3 threshold. I see no reason not to take his witness statements at face value. There is nothing to
undermine his account, it is internally consistent, and it is not all self-serving – he has fairly made the
points about hot meals and access to a bicycle that Mr Metcalfe has relied on. His underlying offending
does not involve dishonesty. He has not sought to resist removal and there has been no challenge to his
credibility. On A's account, which I accept, he was street homeless for a period of 10 months. He had no
way of knowing how or when his predicament would come to an end. He was unable to earn a living or to
rent accommodation. He was unable to return to his country of nationality. He had no real family support.
At one point he was sleeping in a ditch. It was often very cold at night. There were times when he thought
he was going to die. He was given a tent by the church, but it was ransacked on a number of occasions,
with all of his belongings stolen. On one occasion he found someone inside his tent “smoking crack”. He
felt very insecure and felt that he had to sleep with one eye open.

205. He was unable to wash his clothes. They would become so dirty that he would have to throw them
away. He describes living in the tent as “extremely unpleasant.” At one point he was ill and was unable to
leave his tent for 2 days. All he had to eat was a cold Pot Noodle. He has suffered persistent infections
which he attributes to “being cold and wet all of the time… I have not been completely dry in months.” He
had no food at all for, on average, 3 days a week, and would miss some meals on the other 4 days. He
was totally reliant on food handouts. He lost weight. He was required to move on by the Council. He felt
ashamed and would try to conceal himself. He describes feeling “like an urban fox or something, hiding
away from the rest of society.”

206. In R (Limbuela) v Secretary of State for the Home Department _[2005] UKHL 66 [2006] 1 AC 396the_
House of Lords held that decisions to withdraw financial support from three destitute asylum seekers


-----

1912 (Admin)

amounted to a breach of Article 3 ECHR. Lord Bingham (at [7]) had “no doubt” that the minimum threshold
may be crossed if an applicant:

“with no means and no alternative sources of support, unable to support himself, is, by the deliberate
action of the state, denied shelter, food or the most basic necessities of life. It is not necessary that
treatment, to engage article 3, should merit the description used, in an immigration context, by
Shakespeare and others in Sir Thomas More when they referred to 'your mountainish inhumanity'.”

207. As to the test to be applied, Lord Bingham said (at [9]):

“It is not in my opinion possible to formulate any simple test applicable in all cases. But if there were
persuasive evidence that a late applicant was obliged to sleep in the street, save perhaps for a short and
foreseeably finite period, or was seriously hungry, or unable to satisfy the most basic requirements of
hygiene, the threshold would, in the ordinary way, be crossed.”

208. A's experience comfortably meets this test. It also resonates with the observations of Lord Scott at

[71]:

“Most of us will have slept out of doors on occasion; sometimes for fun and occasionally out of necessity.
But these occasions lack the features of sleeping rough that these respondents had to endure under the
statutory regime imposed on them. Not only did they have to face up to the physical discomfort of sleeping
rough, with a gradual but inexorable deterioration in their cleanliness, their appearance and their health,
but they had also to face up to the prospect of that state of affairs continuing indefinitely. People can put up
with a good deal of discomfort and privation if they know its duration is reasonably short-lived and finite.
Asylum seekers caught by section 55(1) do not have that comfort. Growing despair and a loss of selfrespect are the likely consequences of the privation to which destitute asylum seekers, with no money of
their own, no ability to seek state support and barred from providing for themselves by their own labour are
exposed.”

209. Mr Metcalfe seeks to distinguish _Limbuela on the grounds that was a case where the effect of the_
policy was positively to withdraw support (a “malign” policy), whereas here the Secretary of State has
simply decided not to give the claimants the benefit of accommodation under Schedule 10 of the 2016 Act
(a “benevolent” policy). Although intention can be relevant to the Article 3 threshold, I do not here see any
material distinction between _Limbuela_ and A's case. In any event, the net effect on A is pretty much the
same.

210. Mr Metcalfe relies on the decision in R (AR) v London Borough of Hammersmith and Fulham [2018]
_EWHC 3453 (Admin) in which Upper Tribunal Judge Markus QC, sitting as a deputy Judge of the High_
Court, found that the claimant's circumstances in the UK, if his accommodation were withdrawn, would not
get close to the threshold required by article 3 ECHR. The case was, however, very different. The claimant
in that case would be able to access charitable support during the winter and was unlikely to be rendered
street homeless. He was unlikely to be reduced to a position where he would be seriously hungry or unable
to satisfy basic hygiene requirements. He was able to find some paid work. “[M]ore importantly, any impact
on [his] Convention rights [could] be avoided by his returning to Lithuania.” A positively wants to return to
South Africa, but is unable to do so.

211. For all these reasons, I consider that the conditions that A endured were inhuman and degrading
within the meaning of Article 3 ECHR. At the time of the Secretary of State's decision there was a real and
immediate risk that A would endure such conditions if he were not provided with accommodation.

212. Accordingly, I find that the Secretary of State's failure to grant Schedule 10 accommodation was
unlawful pursuant to section 6(1) Human Rights Act 1998, because it was incompatible with the prohibition
of inhuman and degrading treatment.

_Is A entitled to damages?_

213. I have found a breach of section 6(1) Human Rights Act 1998. It follows that “the Court may grant
such relief or remedy or make such order within its powers as it considers just and appropriate” section


-----

1912 (Admin)

8(1) Human Rights Act 1998. There is power to award damages – see section 8(2) Human Rights Act 1998
and section 31(4) Senior Courts Act 1981. However, no award of damages should be made unless, taking
account of all the circumstances, the award is necessary to afford just satisfaction to A – section 8(3)
Human Rights Act 1998.

214. The approach to be taken to the exercise of the power to award damages for breach of Article 3
ECHR was extensively reviewed (albeit in a different context) by Green J in DSD v Commissioner of Police
_of the Metropolis [2014] EWHC 2493 (QB) [2015] 1 WLR 1833. At [18] Green J said:_

“In relation to any claim for an award of compensation the starting point for the analysis is to answer the
question whether a non-financial remedy is necessary “just satisfaction”? In the present case I have
already made declarations in favour of each Claimant to the effect that their Convention rights have been
violated… The importance of declaratory relief in an appropriate case is not to be underestimated. It
provides a formal, reasoned, vindication of a person's legal rights and an acknowledgment in a public
forum that they have been wronged. It is an integral part of the democratic process whereby a public body
can be called to account. Case law suggests that there are (at least) two components to the question
whether a financial award should supplement a declaration. First, it is necessary to consider whether there
is a causal link between the breach and the harm which should appropriately be reflected in an award of
compensation in addition to a declaration? Secondly, and regardless of the answer to the first question, it is
necessary to consider whether the violation is of a type which should be reflected in a pecuniary award?”

215. Here, Mr Metcalfe submitted that the breach of Article 3 was merely “procedural” – a failure to take
steps to avert a real and immediate risk of inhuman and degrading treatment but in circumstances where
no actual inhuman and degrading conditions eventuated. On that premise he argues that no award of
damages would be necessary. I have, however, rejected that premise and found that A did suffer inhuman
and degrading conditions. Mr Metcalfe accepted that such a violation was “of a type which should be
reflected in a pecuniary award”, and that he would not resist a finding that damages were necessary. The
parties agree the question of quantum should be determined separately.

_Did the errors in A's case arise from systemic failings?_

216. The reason that the Secretary of State unlawfully failed to provide accommodation to A is of
relevance to A's broader claim that the Secretary of State's approach to her statutory power is unfair and
irrational. If the illegality was due to an error on the part of a single caseworker that was not likely to be
repeated then that would afford no support for A's broader claim. Conversely, if it were symptomatic of an
underlying structural flaw then that might be relevant to that claim.

217. As in Mr Humnyntskyi's case, the Secretary of State has offered no explanation for the errors and has
not suggested that any steps have been taken to prevent their recurrence. No evidence has been provided
from any of the caseworkers who were directly involved in A's case. In the absence of such evidence or
explanation it is necessary to make findings on the basis of the contemporaneous material. I consider that
the material supports the following conclusions:

(1) This was not a single error at a single point in time – there were multiple errors made at discrete points
over a period of months;

(2) It appears that the errors were not made by a single caseworker. The redaction of the records makes it
impossible to be certain, but it appears that the errors were made by different officials in different teams.

(3) The errors were similar to those made in Mr Humnyntskyi's case, even though they apparently involved
different officials.

(4) As in Mr Humnyntskyi's case the errors are repeated, consistent and form a pattern.

(5) As in Mr Humnyntskyi's case, there was no response to accommodation requests (see paragraph 94
above), no involvement in the decision making process (see paragraph 88 above), no notification to A of
the reasons for the decision (see paragraph 88 above), treating a “high harm” test as determinative, or
otherwise simply asserting that the test was not met without giving reasons (see paragraphs 87 90 92 and


-----

1912 (Admin)

98 above), and not apparently considering the need to provide Schedule 10 accommodation when
conditional bail is granted to a person who will otherwise be homeless on release.

(6) The references to section 4 of the 1999 Act (see paragraphs 96 - 97 above) are striking. It must have
been obvious that section 4 of the 1999 Act did not apply (there is no suggestion that A had ever applied
for asylum, or that anyone mistakenly thought that he had applied for asylum). They could be aberrant
errors. However, they are also consistent with officials struggling to make the Schedule 10 process work in
a fair manner, and reaching for section 4 (which had an application form, a process, and a right of appeal)
as a make-do substitute.

_Compliance with order for interim relief_

218. No complaint was made by A about the apparently late compliance with the order for interim relief.
That order required (following a with notice application and representations from both parties) that the
Secretary of State should provide accommodation by 30 January 2020. In fact, A was not moved to the
accommodation until 8 February 2020. In the interim he was homeless and enduring the conditions I have
described. The Secretary of State made an application, on 30 January (so the day for compliance), for an
extension of time. That application was not determined before the time for compliance had expired (ie the
same day) and, in fact, the application was never brought before the court.

219. There is an important distinction between procedural directions in a case, requiring steps to be taken
by a particular date, and a mandatory injunction. The former may be subject to an application to extend
time under CPR 3.1(2)(a). Where the application is made before the date for compliance has passed it will
be determined in accordance with the overriding objective and it will not be necessary to meet the test for
relief from sanctions under CPR 3.9. That is so even if the application is not determined until after the date
for compliance.

220. Mr Metcalfe readily accepted that an order for a mandatory injunction is quite different. Such an order
is exceptional and is indicative of the Court having found both that there is a serious issue to be tried as to
whether the defendant has acted unlawfully (or a strong prima facie case that the defendant has acted
unlawfully) and that the balance of convenience lies in favour of granting such an order. In this case it was
made to bring an end to treatment which I have found to be inhuman and degrading. There is a strong
expectation that public bodies will comply with such orders. A last minute application to extend time, which
is not then brought before the court, risks thwarting the order. Stringent sanctions are available in the event
of deliberate flouting of mandatory orders by public bodies – see _M v Home Office_ [1994] 1 AC 377and
_MSA v London Borough of Croydon [2009] EWHC 2474 (Admin)._

221. In the present case A does not, as I have said, ask the Court to take any further action. He will, in any
event, fall to be compensated for the consequences of the delay in providing him with accommodation. I
am satisfied that it is not necessary for further action to be taken. Mr Metcalfe readily recognised on behalf
of the Secretary of State the importance of complying with this type of order. As it happens, particular
problems arose which meant that although accommodation was sourced by 30 January 2020. A could not
be transported to the accommodation until 7 February 2020.

**(3) WP (Poland) v SSHD**

_Argument_

222. Ms Dubinsky argues that what happened to WP was profoundly unfair. She was a highly vulnerable
destitute woman who would be at risk of appalling consequences if she were released into street
homelessness. She clearly qualified for accommodation as an Article 3 case. She was in no position to
make an application for Schedule 10 accommodation, and was not given the information necessary to do
so. There was no proactive consideration of her case. When solicitors acting for her demanded that
consideration was given to the provision of Schedule 10 accommodation the caseworker did not provide
the information that CCAT claimed to need to treat the claim as “valid”. WP was unlawfully detained
because (1) her detention was contrary to EU law, (2) there was a breach of common law principles that


-----

1912 (Admin)

regulate administrative detention, (3) there was a breach of the Secretary of State's “adults at risk” policy,
and (4) the decision making in respect of Schedule 10 accommodation was unlawful.

223. Mr Metcalfe agrees that the decision of 11 March 2020 to refuse Schedule 10 accommodation was
unlawful. He contends that this was “no more than isolated error”. He agrees that, as a result, WP's
detention became unlawful, but only from 2 April 2020 when accommodation would have been provided
(see paragraphs 173 - 179 above for the same argument in Mr Humnyntskyi's case). He says that this
claim should be transferred to the County Court for assessment, and subject to that, the proceedings are
academic.

_Is WP's claim academic? If so, does it meet the criteria for continuing an academic claim_

224. I have found that A's claim is not academic. WP is in materially the same position. The primary
difference is the relief that is claimed for the unlawful Schedule 10 decision. In A's case, damages are
claimed for breach of Article 3 ECHR. In WP's case, damages are claimed in false imprisonment. That
difference is not material to the question of whether the claim is academic.

_Application to adduce psychiatric evidence_

225. There is an outstanding application on the part of WP to adduce psychiatric evidence. The
background is that WP unilaterally produced a psychiatric report in support of her claim. That was done
without seeking the Court's permission to adduce the report in evidence pursuant to CPR 35.4. The
Secretary of State responded by seeking permission to adduce expert psychiatric evidence in response.
That was granted, following a hearing before Swift J, on 15 June 2020. WP did not seek directions for the
experts to meet and provide a joint report, or to adduce any further expert evidence. Then, on the eve of
the hearing, WP produced a new psychiatric report which sought to respond to the Secretary of State's
report and purported to identify areas of agreement and disagreement between the experts. She applies
for permission to adduce the report. I refuse permission. The Court is under a duty to restrict expert
evidence – see CPR 35.1. It was entirely foreseeable that the Secretary of State's expert witness would not
agree with everything said by the expert witness instructed on behalf of WP. If WP had wanted the
opportunity to adduce further evidence then she ought to have sought permission from Swift J. I am not
willing to accept as a fait accompli the report that has now been produced. It would not be fair to the
Secretary of State. It would not restrict expert evidence to that which is reasonably required to resolve the
proceedings, as I am required to do by CPR 35.4. It would give rise to a myriad of satellite issues which
have, at best, only tangential relevance to the issues in the case. In the event, the psychiatric evidence
was barely addressed by counsel in the course of their oral submissions. I agreed to consider it de bene
esse. Having done so, I decline to permit it to be adduced in evidence.

_Is WP entitled to pursue a claim that her detention was in breach of EU law?_

226. The Secretary of State contends that WP should not be permitted to pursue a claim that her detention
was in breach of EU law because neither section 7 of her claim form, nor her prayer for relief, seeks a
declaration that the Secretary of State is in breach of her EU law obligations or that she has breached any
of WP's rights under EU law.

227. I disagree with the suggestion that WP should not be permitted to pursue this issue. Section 7 of the
claim form seeks a declaration that WP has been unlawfully detained. The Claim Form was supported by
the grounds of claim which were filed with the Claim Form. The fifth ground of challenge was that the
Claimant's detention was unlawful (supporting the declaration sought in the Claim Form). The first
particular of that ground of challenge was based on EU law (and, in particular, Article 27 of the Citizens'
Directive) and was that WP's detention was in breach of Article 27(2) as being “unnecessary and otherwise
disproportionate”. Permission to claim judicial review was granted by Eady J on 13 May 2020.

_Was WP lawfully detained?_


-----

1912 (Admin)

228. The various routes by which it is said that WP was unlawfully detained are intertwined, and all to
some extent rely on the same underlying complaint. That is (so it is said) it was unnecessary and
unreasonable to detain WP when she did not pose a significant risk of absconding or re-offending, was
likely to suffer a deterioration of her mental health in detention, and when she could and should have been
safely and appropriately accommodated in Schedule 10 accommodation rather than administrative
detention.

229. I prefer to address this underlying complaint (with the caveat that it is then subject to testing against
the legal constraints that are imposed) before then turning to the different legal frameworks.

230. In a typical FNO case the Secretary of States considers the deportation of the FNO whilst they are
still serving their sentence of imprisonment. There is often a period of months during which the Secretary of
State is able to secure relevant information and formulate a plan of action. That might involve removal
under a facilitated return scheme. Or it might involve detention followed by deportation. Or it might involve
release on immigration bail (with or without Schedule 10 accommodation, and with or without removal
action thereafter).

231. In WP's case the Secretary of State did not have this luxury of time in which to formulate an
appropriate plan. WP was released from criminal justice imprisonment on the day of sentence (because of
the time she had served on remand awaiting sentence). Although the Secretary of State had some
information about her (and she had been visited by an immigration official before she was sentenced) this
was limited. WP's circumstances were complex. It was not immediately clear whether or when she could
be removed from the UK, whether she should be in hospital, or whether she could safely be detained.
What ought to have been clear, fairly rapidly, is that she should not be put back on the streets. If she was
not going to be detained, and if she was not going to be moved to hospital, she would need to be provided
with some form of accommodation. Release to street homelessness was clearly not a viable, or lawful,
option in WP's case. Her vulnerability and previous experience of street homelessness was such that it
ought to have been clear that that would not have been compatible with her Convention rights.

232. I do not accept the Secretary of State's assessment that WP posed a high risk of harm to the public.
True it is that she had assaulted an emergency worker. However, the circumstances of that offence (so far
as they are identified in the papers) do not justify a conclusion that she posed a sufficiently significant
broader risk of harm to justify detention for more than a short period of time. There was certainly a risk that
it would be difficult to keep track of WP if she were released without an address to go to, but, as I have
said, that ought not to have been an option.

233. What all this means is that a period of time was required to establish whether WP could be removed,
the timeframe within which removal could take place, whether WP was fit to be detained (or whether she
should be in hospital) and whether accommodation should be provided for her under Schedule 10. The
assessment of the period of time for which it was reasonable to implement detention needs to be
conducted in the light of the events that were taking place.

234. The decision as to whether to seek to remove WP was taken quickly – within 2 days of her detention.
In the absence of any challenge to removal it was likely that removal could take place within a short period
of time. There was no evidence that detention would cause her mental health to deteriorate within a short
period of time. There would have been a risk of absconding if WP were released, even if she were
released to Schedule 10 accommodation. That risk was, in principle, sufficient to justify a short period of
detention to secure removal.

235. However, once WP intimated that she would appeal against the decision (as she did on 31 December
2019 – see paragraph 106 above) that changed. At that point there was no real prospect of removal within
days or a few weeks (notwithstanding the possibility that WP would change her mind, as she did – but
twice, not once). The risk of absconding and offending was not sufficient to justify detention for a period of
months. Accordingly, at that point, arrangements ought to have been made for WP's release, including
consideration of Schedule 10 accommodation. Some of the entries in the notes suggest that this was
appreciated by the caseworkers I do not think it was unreasonable that the decision to consider release


-----

1912 (Admin)

was not made for 3 days. However, from that point, it ought to have been possible to facilitate release
within a further week, so by 10 January 2020.

236. Against that background I address briefly the different legal bases by which it is said that detention
was unlawful (although I am not convinced that there is a great deal of practical difference between the
different legal routes – to a considerable extent they give legal effect to the same underlying principles –
but see the observations of Michael Fordham QC (then sitting as a deputy High Court Judge) in _R_
_(Lauzikas) v Secretary of State for the Home Department [2018] EWHC 1045 Admin [2018] 1 WLR 5299 at_

[34]).

237. EU law: WP is a national of Poland. Her detention and removal interfered with her free movement
rights under Article 21 of the Treaty on the Functioning of the European Union. Such interference is
permissible on grounds of public policy, public security or public health – see Article 27(1) of Directive
2004/38/EC (“the Citizens Directive”). However, by Article 27(2):

“2. Measures taken on grounds of public policy or public security shall comply with the principle of
proportionality and shall be based exclusively on the personal conduct of the individual concerned.
Previous criminal convictions shall not in themselves constitute grounds for taking such measures.

The personal conduct of the individual concerned must represent a genuine, present and sufficiently
serious threat affecting one of the fundamental interests of society. Justifications that are isolated from the
particulars of the case or that rely on considerations of general prevention shall not be accepted.”

238. This provision applied to the detention of WP – see _Lauzikas_ at [23] and [25]. The principle of
proportionality was explained by the Supreme Court in _R (Lumsdon and others) v Legal Services Board_

_[2016] UKSC 41 [2016] AC 697. It requires an assessment of whether the objectives that are being_
pursued are incapable of being achieved by less restrictive means.

239. Ms Dubinsky argues that here it was possible to employ less restrictive means: WP could have been
granted Schedule 10 accommodation rather than kept in detention. I agree that that is so for the period
from 10 January. However, for the period between 18 December 2019 and 10 January 2020 I consider that
WP's detention was necessary and complied with the principle of proportionality having regard to all of the
circumstances, including the risk of absconding and offending. Removal was being pursued and may have
been achievable within a short period of time, the conditions for a grant of Schedule 10 accommodation
were not met, and it would take time for Schedule 10 accommodation to become available.

240. Common law: A person may not be subject to immigration detention pending removal if there is no
real prospect of removal within a reasonable period of time, having regard to the amount of time that the
detainee has already spent in detention (see Lord Dyson JSC in Lumba at [24] and [103]). The assessment
of what amounts to a reasonable period is for the Judge, taking account of all relevant circumstances. For
the reasons I have given I consider that detention up until 10 January 2020 was reasonable, but not
thereafter.

241. Adults at risk policy: The Secretary of State has a policy to address adults at risk in immigration
detention. A person is treated as being at risk if they are particularly vulnerable to harm, and therefore at
risk in detention. This includes those suffering from certain mental health conditions. The policy
distinguishes between different levels. Level 2 comprises those in respect of whom there is professional
evidence or official documentary evidence which indicates that the individual is (or may be) an adult at risk.
Level 3 comprises those in respect of whom there is professional evidence stating that the individual is at
risk and that a period of detention would be likely to cause harm.

242. Here, the Secretary of State accepts that WP was at level 2. I agree that she was at least at level 2,
and was at that level from mid January 2020 (see paragraphs 110 - 111 above).

243. Under level 2 the policy guidance is that detention should only be considered if:


-----

1912 (Admin)

“• the date of removal is fixed, or can be fixed quickly, and is within a reasonable timescale and the
individual has failed to comply with reasonable voluntary return opportunities, or if the individual is being
detained at the border pending removal having been refused entry to the UK

     - they present a level of public protection concerns that would justify detention, for example, if they meet
[the criteria of foreign criminal as defined in the Immigration Act 2014 or there is a relevant national security](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
or other public protection concern

     - there are negative indicators of non-compliance which suggest that the individual is highly likely not to be
removable unless detained”

244. None of these conditions was satisfied. Accordingly, detention could not be justified under the
Secretary of State's Adults at Risk policy. The claim is advanced for the period from 25 February (the date
of receipt of the rule 35 report – see paragraph 123 above). I have already found that detention was
unlawful by that point in any event, but from that date it was also unlawful as being a departure, without
good reason, from the Secretary of State's Adults at Risk in immigration detention policy.

245. I therefore do not consider it necessary to decide whether in fact (as is contended on WP's behalf)
she was at level 3 (rather than just level 2) having regard to the concern of Dr Khan (“I do believe that she
may deteriorate with prolonged detention...” - see paragraph 122 above).

246. Schedule 10: There is no evidence of early proactive consideration being given to the provision of
Schedule 10 accommodation, even though it should have been clear from an early stage that WP might
need to be released and that she would be at risk of inhuman and degrading treatment as a lone
vulnerable destitute woman on the streets. Even when there was a compelling basis for the provision of
Schedule 10 accommodation, applications prepared by caseworkers were “deemed invalid” with
observations that WP did not pose a high risk. Rather, officials contemplated with apparent equanimity the
prospect of releasing WP to “no fixed abode”. I consider that it was unlawful not to have given
consideration to the provision of Schedule 10 accommodation by 3 January. If that had been done it was
capable of affecting the detention decision by 10 January. For this separate reason, detention from 10
January was unlawful.

_Did the errors in WP's case arise from systemic failings?_

247. The errors that were made in WP's case resonate with those made in Mr Humnyntskyi's case and A's
case. They also resonate with the type of error that is likely as a result of the suggested deficiencies in the
Secretary of State's policy. Thus:

(1) There is no evidence of any proactive consideration of whether WP (who may or may not have been
considered to be a FNO) should be afforded Schedule 10 accommodation (see paragraphs 102 - 116
above).

(2) There was no timeous response to WP's solicitor's request for Schedule 10 accommodation (see
paragraphs 118 - 119 and 127 above).

(3) The requests for Schedule 10 accommodation were flatly rejected as “invalid” with reference to the fact
that WP was not a high risk (see paragraphs 127, 129 - 130 and 133 - 134 above).

(4) WP's solicitor was belatedly (and wrongly) told that a request for Schedule 10 correspondence could
not be made in correspondence (see paragraph 131 above).

(5) WP's solicitor was not able to make representations directly to the decision maker (see paragraph
135).

(6) The Secretary of State was ready to release her to “no fixed abode” (see paragraph 135 above). This
is consistent with the decision making process prescribed in the unpublished guidance, including the
wording of “release to no fixed abode” (see paragraph 24(2) above). Yet, on the facts, this would have
likely been a breach of WP's rights under Article 3 ECHR.


-----

1912 (Admin)

**The Common Claims**

**Common Claim 1: Fairness**

_Argument_

248. It is common ground that the Secretary of State must operate a fair system for granting Schedule 10
accommodation. This is an aspect of the rule of law – see _R (Osborn) v Parole Board_ _[2013] UKSC 61_

[2014] AC 1115per Lord Reed JSC at [71].

249. Ms Dubinsky complains that the Secretary of State's policy is inherently unfair, and therefore
unlawful, because:

(1) There is no mechanism for affording FNOs a fair opportunity to make representations before a decision
on Schedule 10 accommodation is made.

(2) There is no mechanism for informing FNOs that the SSHD is minded to refuse Schedule 10
accommodation and of the reasons why, so as to enable them to make representations in response.

250. Mr Metcalfe responds that there is no blanket requirement of public law that an affected person must
be permitted to make representations in advance of a decision, or that notification of a provisional decision
is required. He says that if Schedule 10 accommodation is refused there is nothing to prevent an individual
from seeking a further decision, and making further representations at that stage, so as (as Mr Metcalfe put
it) to “try, try again”.

_Is it open to the Claimants to advance complaints of procedural fairness?_

251. Mr Metcalfe objects that the pleaded grounds do not sufficiently identify a complaint of procedural
unfairness. I disagree. Such a complaint is writ large throughout the grounds (and, before that, the preaction correspondence) of all three cases. The relief sought in section 7 of each of the claim forms includes
a declaration that the Secretary of State is unlawfully failing to operate a fair or rational system for the
determination of eligibility for Schedule 10 accommodation. Paragraph 3(3) of the grounds in Mr
Humnyntskyi's case states:

“The central questions in this claim are:

(3) Is the Defendant operating a fair and rational system to determine eligibility for Schedule 10
accommodation?

(4) Is the Defendant under a duty to elicit representations or applications and to give a decision and written
reasons where he refused Schedule 10 accommodation?”

252. Ground 4 of the challenge is entitled “Representations, written decisions, reasons and fairness.” It
sets out the complaints that are made about the fairness of the system. The claims of A and WP are to
similar effect. The objection appears to be that the Claimants generally refer to “fairness” without the
adjective “procedural” (although in some places “procedural fairness” is in fact used). There is no
substance to the complaint. The scope of the challenge was and is clear. It is notable that the Secretary of
State's Skeleton Argument in response to the challenge is replete with references to “procedural fairness”.

_The requirements of fairness in this context_

253. A public law decision that is taken following an unfair procedure is, for that reason, unlawful. The
requirements of a fair procedure depend on the context in which the decision is made – see R (L) v West
_London Mental Health NHS Trust [2014] EWCA Civ 47 [2014] 1 WLR 3103per Beatson LJ at [67]._

254. In _R (Howard League for Penal Reform) v Lord Chancellor_ _[2017] EWCA Civ 224 [2017] 4 WLR_
92Beatson LJ set out a non-exhaustive list of factors that are relevant to the content of the fairness
requirement:


-----

1912 (Admin)

“The factors include the nature of the function under consideration, the statutory or other framework in
which the decision-maker operates, the circumstances in which he or she is entitled to act and the range of
decisions open to him or her, the interest of the person affected, the effect of the decision on that person's
rights or interests, that is, the seriousness of the consequences for that person. The nature of the function
may involve fact-finding, assessments of matters such as character and present mental state, predictions
as to future mental state and risk, or policy-making. The decision-maker may have a broad discretion as to
what to do, or may be required to take into account certain matters, or to give them particular or even
dispositive weight. The decision may affect the individual's rights and interests, and its effect can vary from
a minor inconvenience to a significant detriment.”

255. There is no suggestion that the system for bail applications is, in and of itself, unfair. There is a right
of access to an independent Tribunal, a right of access to the material that will be taken into account by the
Tribunal (SIAC cases aside), a right to make representations, and a right to notification of a reasoned
decision. The Secretary of State only has power to grant Schedule 10 accommodation if there is a grant of
bail that is subject to a residence condition. Even then, the Secretary of State only has power to grant
Schedule 10 accommodation if she thinks that there are exceptional circumstances. The principal category
that is considered by the Secretary of State to amount to exceptional circumstances is that of a high risk
FNO. The question of whether a FNO poses a high risk of harm is a matter for expert assessment. It is
informed by documentary evidence that is likely to be generated in the course of the criminal justice
process. That includes material such as Offender Assessment System (“OASys”) reports, prepared by the
Probation Service. In many cases it may be unlikely that the individual FNO could make meaningful
representations that would be capable of impacting on the assessment. To secure accommodation on this
basis, the FNO would need to show that they posed a high risk to the public – something which would be
contrary to their interests on the antecedent question of bail. I infer that it is considerations such as these
that caused the Secretary of State to consider that a representations process would be “overly
burdensome” (see paragraph 55 above).

256. I am prepared to accept that these are relevant components of the context which inform the
requirements of fairness (without making a finding that they would – even if they stood alone - justify the
Secretary of State's conclusion that a representations process was unnecessary). They do not, however,
stand alone. There are other important contextual factors.

257. Although a high risk to the public is one factor that might justify the provision of Schedule 10
accommodation, it is not the only one. Any factor considered by the Secretary of State to be exceptional
will qualify. Some factors may be unknown to the Secretary of State unless they are drawn out by some
form of representations process. The Secretary of State accepts, in principle, that “Article 3 cases”
normally qualify as exceptional circumstances. But the Secretary of State may not be in a position to know,
or even suspect, that a person will face Article 3 conditions without Schedule 10 accommodation, unless
she seeks information that is relevant to that issue.

258. The matters at stake when a Schedule 10 decision is made may include whether the individual is at
liberty or in detention (for a period that may extend for months or even, in extreme cases, years) or
whether (as in A's case) they are rendered street homeless enduring inhuman and degrading conditions
(again, as in A's case, for a protracted period of time). There is no right of appeal to an independent
appellate body against an adverse decision.

259. Some of those in immigration detention who seek Schedule 10 accommodation may be sophisticated
English speaking offenders who have the wherewithal to navigate a complex and bureaucratic system. A
greater number may be able to secure the benefit of representation from those who are skilled at making
requests for Schedule 10 accommodation. The evidence, however, is that a sizeable number are
vulnerable, ignorant of the legal landscape with no ready access to legal advice (the evidence suggests
that 30-40% are unrepresented, and whilst there are legal advice surgeries in Immigration Removal
Centres there is no duty advice scheme in the prison estate), limited access to the internet or telephones
and with no or limited English.


-----

1912 (Admin)

260. It is for the Court to assess what fairness requires in the particular case-specific context and whether
the procedure adopted meets those requirements – see Osborn per Lord Reed JSC at [65]. That is so both
where (as in _Osborn) an individual decision is challenged, and where a challenge is advanced on the_
grounds that administrative arrangements are themselves systemically or inherently unfair – see _R_
_(Detention Action) v First-tier Tribunal (Immigration and Asylum Chamber)_ _[2015] EWCA Civ 840 [2015] 1_
WLR 4341.

261. Ms Dubinsky argues that a high standard of procedural fairness is required where, as here, the
decision may have a significant impact on the fundamental rights of highly vulnerable individuals. In
principle, I accept the submission, which is supported by authority. It is, however, necessary to identify the
practical features that are required of a fair system in this particular context, rather than formulating an
arbitrary set of requirements that would afford a “high” level of protection and then assessing whether the
Secretary of State's policy contains all elements of that arbitrary set.

262. Ms Dubinsky contends that the safeguards required include an opportunity to make representations
in advance of the decision, and notification of a provisional decision with a right to make further
submissions at that point.

263. The right to be heard has been long recognised as a fundamental aspect of natural justice. More
recently it has been put this way (see R (Talpada) v Secretary of State for the Home Department [2018]
_EWCA Civ 841_ _per Singh LJ at [57]):_

“the fundamental requirement of the second limb of procedural fairness is to give an opportunity to a
person whose legally protected interests may be affected by a public authority's decision to make
representations to that authority before (or at least usually before) the decision is taken.”

264. The parenthetic qualification recognises that there are some contexts where it may be possible for
representations to be invited only after the decision is taken (for example, in order to inform a review of a
decision which was made in conditions of urgency and without time to secure representations). So, Ms
Dubinksy's first suggested requirement is not a universal rule of fair decision making.

265. As to the second suggested requirement, there are many contexts in which notification of a
provisional decision is required. The concept of “Maxwellisation” in public inquiries involves notification of
draft inquiry findings with an invitation to make representations before promulgation of the inquiry report,
even though there may have been extensive opportunities to make representations at earlier stages (see
rule 13(3) Inquiry Rules 2006). Ms Dubinsky argues that this “minded to” process has been adopted in a
wide range of different contexts. It is not, however, necessary to look beyond the context of the provision of
accommodation for those in immigration detention. In _Razai_ Nicol J said at [85] (in the context of
accommodation provided under section 4 of the 1999 Act):

“In my judgment, a decision, even a provisional decision, that a detainee is not suitable for an immediate
offer of Initial Accommodation is of such significance that fairness does require the SSHD to tell the
applicant that is what she has in mind and why. That is because of the stark difference between the time
that it takes to offer Initial Accommodation as a bail address (only a few days) and the delays that can
occur if Initial Accommodation is not offered (on the evidence, delays of weeks or months). Fairness also
requires the SSHD to take in account any presentations that are made in response.”

266. As this passage makes clear, the reason why a provisional decision was required in that context was
because of the particular way in which the system operated. Again, there is nothing approaching a
universal rule that advance notification of provisional decisions is required, even where the decisions may
impact on fundamental rights (see _Hoffmann La-Roche & Co AG v Secretary of State for Trade and_
_Industry [1975] AC 295HL per Lord Diplock at 369)._

267. Moreover, depending on the detailed workings of a policy there may be little substantive distinction
between a “minded to” process (where a provisional decision is notified with a right to make
representations before a final decision is made) and a “re-application” process (where a first decision is
notified with a right to make representations and seek a further decision)


-----

1912 (Admin)

268. Accordingly, neither of Ms Dubinsky's rules are of universal application. She accepts as much. If they
are required, it can only be because of particular features of decision making in this context. Ms Dubinsky
points to an extensive body of authority to support her contention that there are features of this context
(principally the vulnerability of some FNOs, and the matters that are at stake) that require the very highest
standards of fairness. The authorities she relied on included R (Howard League for Penal Reform) v The
_Lord Chancellor_ _[2017] EWCA Civ 244 [2017] 4 WLR 92per Beatson LJ at [37] - [39], R (Q) v Secretary of_
_State for the Home Department_ _[2003] EWCA Civ 364 [2004] QB 36per Lord Phillips MR at [72] – [73], [83]_
– [84], [90] - [91] and [99], and H and L v A City Council [2011] EWCA Civ 403 _per Munby LJ at [49] – [51]._
Some of the authorities are close to the present context. Others less so. Each is fact specific. Moreover,
the determination of whether a system is fair requires a holistic assessment of all of the measures that are
in place to achieve fairness. There is often an inter-relationship between them. Ms Dubinsky accepted, for
example, that where (as is often the case with court proceedings) there is an oral hearing, there is no
requirement to provide a provisional decision. Even in the context of court proceedings cases are
sometimes determined without a hearing (see eg CPR 54.18), without any suggestion that the court should
issue a provisional decision for comment before it is made final.

269. For these reasons, some caution is necessary before determining that any particular safeguard is
necessary, irrespective of the other safeguards that may be in place. If there has been a very high level of
procedural fairness throughout the process then it may well be that it is unnecessary to provide a
provisional decision with an opportunity to comment. Otherwise (if, for example, the decision maker has
taken account of material that the individual has not had an opportunity to address), an opportunity to
comment on a provisional decision might cure a fairness gap. It is not, however, a panacea. By the stage
of a provisional decision there is the possibility that a decision maker's views may have hardened – it is
more valuable to provide input at an earlier stage when representations might have more influence. A
“minded to” process can make decision making more cumbersome, carrying a greater administrative
burden (as the lengthy delays associated with some Maxwellisation processes demonstrate).

270. Ultimately, I do not think it is necessary to make a finding on whether either or both of the
requirements suggested by Ms Dubinsky are required in precisely the form she suggests. It is sufficient to
set out what I consider is an irreducible minimum of practical outcomes that a fair Schedule 10 policy must
achieve, and without which a Schedule 10 policy would be unfair. They are that:

(1) The FNO is able to make representations as to why Schedule 10 accommodation should be provided
(see paragraph 263 above).

(2) The FNO is able to access information setting out the criteria that will be applied when deciding
whether to provide Schedule 10 accommodation, so as to know the target for representations (see Lumba
_per_ Lord Dyson JSC at [20]-[38], and, particularly, at [35]: “There is a… right to know what the currently
existing policy is, so that the individual can make relevant representations in relation to it.”). For the same
reason, the FNO must be able to access information setting out the mechanism by which representations
should be made. This does not necessarily mean that the Secretary of State must separately notify each
individual FNO of the criteria – a more general form of publication may be sufficient – see Salih v Secretary
_of State for the Home Department [2003] EWHC 2273 (Admin)_ _per Stanley Burnton J at [61]._

(3) The representations made by the FNO are (so far as they are potentially relevant) taken into account
by the decision maker (otherwise the right to make representations is pointless).

(4) The decision is to be considered in accordance with the Secretary of State's policy (see _Lumba per_
Lord Dyson JSC at [35]: “The individual has a basic public law right to have his or her case considered
under whatever policy the executive sees fit to adopt…”).

(5) The FNO is notified of the decision. Mr Metcalfe agreed that it was necessary to notify the FNO of the
decision when it was reached by CCAT on the merits. But he contended that there was no such obligation
where the caseworker made the preliminary decision not to refer the case to CCAT. I see no ground for the
distinction: the net effect is the same for the FNO – Schedule 10 accommodation is not provided. In both
cases procedural fairness requires that the decision is communicated to the FNO so that the FNO knows


-----

1912 (Admin)

where they stand and can decide whether to make further representations to the Secretary of State, or to
make a bail application, or to challenge the Secretary of State's decision.

271. I do not make a finding as to whether these outcomes are sufficient to ensure fairness, but they are
an irreducible minimum without which a decision making process in this context would be unfair.

_How is systemic unfairness established?_

272. The fact that individual decisions made under a policy are unfair does not necessarily mean that the
policy itself is unfair. The Claimants are not satisfied with rulings that the decisions in their individual cases
were unfair. Their far more ambitious aim is to demonstrate that the system itself is unfair.

273. There was a dispute between the parties as to the correct legal test to be applied when assessing
whether a policy is systemically unfair. A considerable volume of authority was relied on by both counsel.
The arguments mirror those that were advanced before the Court of Appeal in R (BF (Eritrea)) v Secretary
_of State for the Home Department_ _[2019] EWCA Civ 872 [2020] 4 WLR 38. Underhill LJ derived a test to_
be applied at [63]:

“I do not think it is necessary or useful to analyse the various cases referred to. In my view the correct
approach in the circumstances of the present case is, straightforwardly, that the policy/guidance … will be
unlawful, if but only if, the way that they are framed creates a real risk of a more than minimal number of

[unlawful decisions]. I should emphasise, however, that the policy should not be held to be unlawful only
because there are liable, as in any system which necessarily depends on the exercise of subjective
judgment, to be particular “aberrant” decisions—that is, individual mistakes or misjudgments made in the
pursuit of a proper policy. The issue is whether the terms of the policy themselves create a risk which could
be avoided if they were better formulated.”

274. The same test was applied in _R (W) v Secretary of State for the Home Department [2020] EWHC_
_1299 (Admin)_ _per_ Bean LJ and Chamberlain J at [58]. Applied to the present case the test could be
formulated thus: does the Secretary of State's policy create a real risk of unfairness in a significant number
(that is in more than a minimal number) of cases.

275. In applying the test, Mr Metcalfe argued that it was necessary to consider the “full run” of cases. I
agree that it may not be sufficient to consider decision making in isolated cases, without reference to the
policy. Errors in such decision making might be “aberrant”. I also agree that a finding of systemic
unfairness should not be made unless there is a sufficient evidential basis for concluding that the
unfairness is inherent in the system – see _R (Woolcock) v Secretary of State for the Home Department_

_[2018] EWHC 17 (Admin) [2018] 4 WLR 49per Hickinbottom LJ at [68]. I do not, however, agree that it is_
necessary to consider the application of the policy against every possible factual permutation. Once it is
demonstrated that there are legally significant categories of case where there is (as a result of the terms of
the policy) a real risk of a more than minimal number of procedurally unfair decisions, the policy will be
shown to be systemically unfair. In some cases it may be possible to demonstrate that the test is met by
reference to the wording of the policy: for example, whether the written policy patently creates an unfair
process and it is accepted that the written policy is applied in practice. The cases show that systemic
illegality can sometimes be demonstrated without reference to the facts of a large number of different
cases – see _Razai_ and _Q_ and _R (Help Refugees) v Secretary of State for the Home Department [2018]_
_EWCA Civ 2098 [2018] 4 WLR 168._

276. The approach I have taken to the issue is first to consider the terms of the policy itself, and to identify
the potential risks that it creates (see paragraphs 18 - 46 above). I have then considered the Secretary of
State's evidence to see if that shows that those risks do not materialise in practice (see paragraphs 47 - 56
above). I have then considered the generic evidence filed by the Claimants as to the workings of the policy
(see paragraphs 57 - 60 above). Against that context I have identified the problems in each of the three
cases and the extent to which these are likely to be aberrant decisions or whether they are more likely to
be symptomatic of the identified systemic risks materialising. That approach provides a sufficient and safe
evidential platform for reaching an assessment of whether the policy is systemically unfair.


-----

1912 (Admin)

277. In assessing whether the evidence demonstrates systemic unfairness, Mr Metcalfe relies on a
number of authorities to support his submission that the test is “high” – see eg Detention Action per Lord
Dyson MR at [27]: “the threshold of showing unfairness is a high one.” This does not, however, impose any
additional requirement that must be satisfied before a finding of systemic unfairness can be made. Rather,
it is an accurate description of the exacting test I have identified.

_Is the Schedule 10 policy systemically unfair?_

278. I have set out above what I consider to be irreducible minimum requirements, without which a
Schedule 10 policy would not be fair. I assess the Secretary of State's policy against those requirements,
applying the test set out at paragraph 274 above.

279. (1) Ability to make representations: There are circumstances in which representations can be made.
In each of the three cases that are before the Court it was possible for the experienced solicitors to make
representations as to why their clients should be provided with Schedule 10 accommodation. There is,
however, some force in the suggestion made on behalf of the Claimants that this was possible in spite of,
rather than because of, the system that was in place. In any event there are categories of case where there
is no ability to make representations.

280. One such category arises where the decision is made as a result of an internal referral process
without notification to the individual concerned (so where the caseworker decides not to refer the matter to
CCAT). In such a case the person will not know that the decision is being made, and will therefore not be
able to make representations. Nothing in the unpublished or published guidance documents suggests that
representations will be invited or entertained in these circumstances. There is no evidence that
representations are, in practice, invited or entertained in these circumstances. Such evidence as there is,
suggests that they are not. This is demonstrated by the facts of these cases. Decisions were made without
the knowledge of the Claimants or their representatives. They could not have known that the decisions
were being made, and they did not have any ability to make representations.

281. A second category comprises FNOs who are not in detention. Such a person may find themselves
destitute, street homeless, and facing inhuman and degrading conditions. In some cases the only way to
avoid such conditions will be by way of provision of Schedule 10 accommodation. In those cases the
Secretary of State is under an obligation to provide such accommodation (and, if necessary, to attach a
residence condition to the FNO's bail). Yet the policy does not provide any mechanism by which such
FNOs might seek Schedule 10 accommodation. Forms B1 and Bail 401 are not apt because they are
forms for those who are in detention who wish to seek bail. Form 409 is not apt because that is for “nonFNOs” (Mr Metcalfe said that this was intended only to exclude FNOs that are in detention, but that is not
what the form says). Form B2 is not apt because that is for those who have been granted bail from the
Tribunal (without a direction under paragraph 6(3) of Schedule 10). Nothing in the policy or the evidence
filed by the Secretary of State suggests that such cases are considered proactively. A's case tends to
indicate that they are just not considered at all.

282. (2) Notification of criteria and process: FNOs are not proactively informed of the process. Version 4 of
the policy guidance does identify a process by which an application for Schedule 10 accommodation might
be made by a FNO. That guidance is addressed to caseworkers rather than FNOs and is not provided to
FNOs. It is published on the internet and is therefore available to anybody who speaks English with an
internet connection. That does not encompass all FNOs. Version 5 of the policy states that detained FNOs
are provided with an information sheet that explains how to apply for Schedule 10 accommodation (see
paragraphs 39 - 40). But the information sheet that is provided does not have this information. Of course,
that is likely to be a simple error that is easily corrected. It has, however, not been corrected. The result is
that a significant number of FNOs will not have any way of knowing how they should make an application
for Schedule 10 accommodation. The cases before the Court illustrate the difficulties that arise as a result,
and the consequential unfairness. The only processes by which FNOs in detention can seek Schedule 10
accommodation are by (a) using a form designed for another purpose and/or which carries an explicit
prohibition of use by a FNO, or (b) making a speculative ad hoc request which may never be considered.


-----

1912 (Admin)

283. (3) Representations taken into account by decision maker: When representations are made, they are
made to the caseworker rather than the person responsible for making a decision on whether to provide
Schedule 10 accommodation. There is nothing in the policy that requires the representations to be passed
to the decision maker. There is no evidence that this is routinely done. The cases before the Court tend to
indicate that representations are not necessarily provided to the decision maker.

284. (4) Decision considered in accordance with the published policy: I have accepted the Secretary of
State's submission that the policy is intended to recognise that Article 3 cases are a discrete category that
should be considered in the case of all FNOs, not just high risk FNOs. However, on the evidence, this is
not how applications are treated. The decision making process that is mandated by the unpublished
guidance has the result – if it is strictly followed - that no consideration is given to the provision of Schedule
10 accommodation in the case of a FNO who does not pose a high risk to the public. That is because in
such a case it is not considered that a bail residence condition is necessary, and if a bail residence
condition is not considered then it necessarily follows that Schedule 10 accommodation will not be
considered. There is no evidence that caseworkers have been instructed to depart from the guidance on
the decision making process, or that they do depart from that guidance. The evidence of the cases before
the court indicates that in each of those 3 cases Schedule 10 accommodation was refused because the
claimant was not considered to be a high risk. I do not accept that these were aberrant errors. The
decisions made are consistent with the letter of the unpublished guidance and were repeatedly made by
different caseworkers over a period of many months. The result is that the decisions are not made in
accordance with the published policy.

285. (5) Notification of the decision: Nothing in the policy requires FNOs to be informed of a decision to
refuse Schedule 10 accommodation made by a caseworker. There is no evidence that such refusal
decisions are routinely provided in practice. Mr Metcalfe accepted that where a decision is made by a
caseworker that a case is not eligible for Schedule 10 accommodation (with the result that the request is
not passed to CCAT) the FNO will not be informed of the decision (unless it was in response to an
application for Schedule 10 accommodation). The Claimants' cases are illustrations of this in practice.

286. It follows that the Secretary of State's policy for the provision of Schedule 10 accommodation does
not come close to satisfying the irreducible minimum criteria which are necessary (and may not even be
sufficient) to secure fairness. Procedural unfairness is inherent in the policy. The policy creates a real risk
of unfairness in more than a minimal number of cases. The exacting test for demonstrating systemic
unfairness is therefore satisfied. Further, I consider that it is satisfied by some margin. I have considerable
doubts that the irreducible minimum criteria I have specified would be sufficient to secure fairness. There is
force in Ms Dubinsky's submissions that much more is required in this particular context. The Secretary of
State's policy is deficient in respect of each and every component of that irreducible minimum. The result is
that not only is there a real risk of unfairness, that is the likely result in significant categories of case, A's
case being a paradigm example.

**Common Claim 2: Fettering discretion**

_Argument_

287. The statutory power to provide Schedule 10 accommodation only arises where the Secretary of State
thinks that there are exceptional circumstances. The parties agree that it would be unlawful (as a fetter of
discretion) to produce an exhaustive list of circumstances that are capable of being thought exceptional,
and to refuse to contemplate the possibility that any other circumstances are exceptional – see _R v_
_Secretary of State for the Home Department ex parte Venables [1998] AC 407per Lord Browne-Wilkinson_
at 496H:

“When Parliament confers a discretionary power exercisable from time to time over a period, such power
must be exercised on each occasion in the light of the circumstances at that time. In consequence, the
person on whom the power is conferred cannot fetter the future exercise of his discretion by committing
himself now as to the way in which he will exercise his power in the future. He cannot exercise the power


-----

1912 (Admin)

nunc pro tunc. By the same token, the person on whom the power has been conferred cannot fetter the
way he will use that power by ruling out of consideration on the future exercise of that power factors which
may then be relevant to such exercise.”

288. It is simply not possible prospectively to predict the situation of every possible FNO and to produce
an exhaustive list of what is, and what is not, exceptional. Nor would it be lawful. Because that is not
possible, or lawful, the Secretary of State must leave open the possibility that there are other
circumstances, not specified in the policy, that she may assess as exceptional so as to merit the grant of
Schedule 10 accommodation.

289. Mr Metcalfe argues that the Secretary of State has not fettered her discretion. Whatever was said in
early versions of the policy, versions 4 and 5 of the policy (by specifying what would “normally” amount to
exceptional circumstances) leave the categories open. Ms Dubinsky argues that the Secretary of State is
only willing to consider three categories of case as being exceptional (high risk, SIAC and Article 3), and in
practice the only category that the Secretary of State is prepared to consider in cases involving FNOs is
that of high harm.

_Has the Secretary of State unlawfully fettered her discretion?_

290. Versions 1, 2 and 3 of the policy give the impression, on a natural reading of their wording (the use of
the single word “are” rather than “include”), that the Secretary of State only considers that the three
specified categories of case are capable of amounting to exceptional circumstances. Those policies are no
longer in force. I accept that any challenge to their content is academic and should not be entertained.
They do, however, provide the context in which version 4 was introduced. That was not a fresh policy. It
was a fresh iteration of a policy with which officials had, by then, become familiar. That creates the risk that
nuanced changes in the guidelines as to process may not be noted by busy officials unless they are
proactively drawn to their attention.

291. There is a dispute between counsel (see paragraph 35 above) as to whether the use of the word
“normally” in version 4 corrects any earlier fettering of discretion. Each of their interpretations is tenable,
both on the natural wording of the paragraph and the context in which it was introduced. If it was intended
clearly to signal that the categories of exceptional circumstances were not closed and that caseworkers
should consider whether other cases amount to exceptional circumstances, it singularly fails to achieve its
intended effect. That effect could easily have been achieved with straightforward language.

292. Mr Metcalfe argues that the reference to the provision of Schedule 10 accommodation for the period
[whilst a local authority makes an assessment under the Care Act 2014 shows that the categories are not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)
closed (see paragraph 29 above). I disagree. This is a subset of the Article 3 category. It is dealt with in
[that section. Cases under the Care Act 2014 form an exception to the Article 3 category because, in those](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)
cases, accommodation will be provided by the local authority. There is, though, a risk of a gap in coverage.
The policy recognises that Schedule 10 accommodation may be used as a stop gap. It is, properly
construed, an exception to an exception within the Article 3 category. It is not an indication of the exercise
of a residual discretion to consider any other circumstances, not specifically identified in the policy, as
being exceptional.

293. The drafting of the policy therefore creates the (I am prepared to accept, unintended) risk that
caseworkers will regard the categories of exceptional circumstances as closed.

294. There is a greater problem which masks the effect of this issue and makes it impossible to assess
what the practical consequence of the change between version 3 and version 4 would otherwise have
been. That greater problem is the decision making process itself. That process creates the risk that only
high risk FNOs are considered for Schedule 10 accommodation. If this risk materialises then the Article 3
category (which is expressly included in the published policy) is excluded from consideration (in cases of
FNOs who are not high risk) because of the way the decision-making process works. It likewise follows that
any category which is not expressly included in the policy would not be considered. That is why the effect
of the drafting change is masked.


-----

1912 (Admin)

295. I am prepared to accept that this was not the intention underpinning the drafting of the unpublished
guidance. Indeed, I think it is very unlikely that this was the intention (see paragraphs 26 - 28 above). In
principle, I would have been receptive to evidence that showed that the policy is not operated in that way.
There has been no such evidence. On the contrary, the consistent evidence in the three cases before the
Court (uncontradicted by any evidence filed by the Secretary of State) is that this is precisely how the
policy has been operated.

296. I am therefore satisfied that the Secretary of State has, unintentionally but nonetheless unlawfully,
fettered her discretion as to the circumstances that might be treated as exceptional so as to merit a grant of
Schedule 10 accommodation.

297. Ms Dubinksy constructed an elaborate framework for categorising types of systemic flaw: those that
are due to a policy itself, those that are due to widespread general practice, those that are due to
widespread error, and those that are due to aberrant error. I do not think it is necessary to choose from
these options (save that aberrant error can be rejected). They are just different points on a continuum. In
this case the problem has its origin in the policy. It could have been operated in a different way, but it is not
surprising that officials have followed the clear flowchart decision making process that has been
prescribed. The result is that the operation of the policy results (at least in a more than a minimum number
of cases) in the Secretary of State fettering her discretion. It is therefore unlawful.

**Outcome**

298. Mr Humnyntskyi has established that he was unlawfully detained, and is entitled to a declaration to
that effect.

299. A has established that the Secretary of State breached his Convention rights and thereby acted in
breach of section 6 of the Human Rights Act 1998. That is because the Secretary of State unlawfully
breached the prohibition on inhuman and degrading treatment, by refusing Schedule 10 accommodation in
circumstances where A was at a real and immediate risk of suffering such treatment. He is entitled to a
declaration to that effect and an award of damages by way of just satisfaction.

300. WP has established that she was unlawfully detained from 10 January 2020 until 22 April 2020. She
is entitled to an award of damages.

301. I will set directions for the assessment of damages in the cases of A and WP.

302. The Claimants have established that the Secretary of State's policy for granting Schedule 10
accommodation is unlawful because:

(1) It is systemically unfair. It creates a real risk that unfair decisions will be made in a significant number
of cases. Those risks materialised in the cases before the Court.

(2) In its operation it fetters the Secretary of State's discretion to consider whether the situation of an
individual applicant amounts to exceptional circumstances. That unlawful fetter was applied in the cases
before the Court.

303. They are entitled to declarations to that effect.

**End of Document**


-----

