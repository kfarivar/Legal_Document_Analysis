(D) 12/5

# ZL Petitioner against THE SECRETARY OF STATE FOR THE HOME
 DEPARTMENT Respondent 2020 Scot (D) 12/5

[2020] CSOH 44

Court of Session (Outer House)

OPINION OF LORD ARMSTRONG

Petitioner: Caskie; Drummond Miller LLP

Respondent: Tariq; Office of the Advocate General

14 May 2020

**OPINION OF LORD ARMSTRONG**
**Introduction**

[1]     The petitioner is a citizen of China who arrived in the UK in 2014. By a decision, dated 28 November 2018,
the respondent has determined that he is a victim of trafficking and modern slavery.

[2]     By this petition, the petitioner seeks reduction of a decision letter by the respondent, dated 6 June 2019
(“the Decision”), not to grant him discretionary leave to remain in the UK as a victim of trafficking. The issues in the
case concern the manner in which the respondent assessed the available evidence in that regard. Before me,
counsel for both parties adopted their respective notes of argument, the terms of which, together with the oral
submissions advanced in the course of the hearing, are reflected in what follows.
**Submissions(i)** _the submissions for the petitioner_

[3]     The Decision was challenged on the basis that the reasons stated for the refusal to grant discretionary
leave to remain were inadequate. In particular, (i) the respondent had erred in law in her assessment of the risk of
the petitioner being re-trafficked, or becoming a victim of **_modern slavery, on return to China, and (ii) the_**
respondent had erred in law in her assessment of the risks associated with the medical condition of the petitioner's
son, in relation to the treatment available in China, and in her approach to the weight given to that in her
determination.
(a) the risk of re-trafficking

[4]     Under reference to Article 14(1) of The Council of Europe Convention on Action Against Trafficking in
Human Beings 2005 (“the Trafficking Convention”), and the decision in _The Queen on the Application of PK_
_(Ghana) v Secretary of State for the Home Department [2018] 1 WLR 3955, a foreign national who is a victim of_
trafficking is to be granted discretionary leave to remain where the circumstances are such that the person's stay in
the country is “necessary owing to his personal situation”. Whether such action is necessary is to be seen through
the prism of the objectives of the Trafficking Convention (PK (Ghana) at paragraph 44), which include the protection
and assistance of victims of trafficking. In the case of the petitioner, whether his personal situation was such as to
make it necessary for him to stay in the UK could only be assessed by reference to that objective (paragraph 50).


-----

(D) 12/5

[5]     It was submitted that return of the petitioner to China would render him vulnerable to the risk of being retrafficked in two ways; (i) by falling back into the hands of those who had originally trafficked him, and (ii) by being
trafficked by others as a consequence of his vulnerability as someone who was already a victim of trafficking.

[6]     In her assessment of his personal situation, the respondent had considered the first of these categories, but
the Decision disclosed no proper and adequate consideration of the second.

[7]     In that regard, under reference to the second and third pages of the Decision, the respondent had taken
into account, and indeed had quoted, parts of The US 2018 Trafficking in Persons Report: China (“the US Report”).
It was reasonable to infer, however, that in placing reliance on the parts of the US Report which she did, the
respondent had been selective. The passages quoted did not reflect the general content of the US Report which
was extensive and detailed. Although the parts of the US Report quoted in the Decision indicated that steps were
being taken in China to prevent trafficking, and to address the vulnerabilities of internal migrants returning to China
from exploitation abroad, other parts of it, not quoted in the Decision, were to the effect that although the
government of the People's Republic of China had taken some steps to address trafficking, it “does not fully meet
the minimum standards for the elimination of trafficking and is not making significant efforts to do so”; “Unlike (in the
year prior to 2018) the government did not report identifying any trafficking victims or referring them to protective
services”; “The efficacy of the government's previously reported victim assistance … remained unclear”; and
“China's internal migrant population, estimated to exceed 180 million people, is vulnerable to trafficking, with
Chinese men, women and children subjected to forced labour in coal mines and factories, some of which operate
illegally to take advantage of lax government enforcement”. The report stated numerous recommendations as to
how the position in China should be improved.

[8]     Although there was no requirement on the respondent to quote the whole document, having regard to the
structure of the Decision, it was reasonable to infer that the absence of reference to, or quotation of, those
passages of the US Report critical of the situation in China was an indicator that no account had been taken of
them.

[9]     In the circumstances of the petitioner's case, which included his forced labour, following being trafficked to
London, in considering the risk of the petitioner being trafficked of new on return to China, by persons other than his
former traffickers, the respondent's reasons for her determination not to grant discretionary leave to remain were
inadequate. The respondent's conclusion had resulted from a failure to have regard to the whole tenor of the US
Report, described in the Decision as “objective evidence”, and, in particular, a failure to attach appropriate weight to
those parts of it which were indicators of clear concerns in relation to the relevant position in China.
(b) the medical condition of the petitioner's son

[[10]     The contextual background to this issue was section 55 of the Borders, Citizenship and Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)
2009, which imposed on the respondent a duty to make arrangements for ensuring that any function of the
respondent in relation to immigration was discharged having regard to the need to safeguard and promote the
welfare of children who were in the United Kingdom (subsections (1)(a) and (2)(a)). Those provisions were
consistent with the rationale of the decision in _Beoku-Betts (FC) (Appellant)_ v _Secretary of State for the Home_
_Department [2009] 1 AC 115, in which, at paragraph 43 it was stated:_

“once it is recognised that 'there is only one family life', and that, assuming the appellant's proposed removal
would be disproportionate looking at the family unit as a whole, then each affected family member is to be
regarded as a victim … ”

[11]     The respondent's policy, relevant to the issue, was consistent with that approach. In the Home Office
guidance document; “Discretionary leave considerations for victims of **_modern slavery”, under the heading_**
“Background to discretionary leave for potential victims of modern slavery”, at page 7 of 19, it was stated:

“Leave is necessary owing to personal circumstances:


-----

(D) 12/5

When deciding whether a grant of leave is necessary under this criterion an individualised human rights and
children safeguarding legislation-based approach should be adopted”

[12]     A medical report by Dr Andreas Brunklaus, consultant paediatric neurologist, dated 22 May 2019, in
relation to RL (D.O.B. 11/03/15), the petitioner's son, was in the following terms:

“(R) has a condition which has not yet fully been diagnosed. He began having seizures in August last year and
these seizures quickly became severe and he was having multiple seizures everyday where he fell to the
ground hurting himself. The seizures are now controlled on a combination of two medications but the likelihood
of recurrence is high. His concentration and learning have been effected by the seizures and he is seeing the
neuropsychologist here and has an EEG booked in three weeks.

(R) will not be able to access the treatment he has here in the area of China he would be going to which is
likely to significantly affect the outcome of his epilepsy and the rest of his life. He has been seen by many
professionals in the hospital who liaise with his nursery to ensure he gets the support he needs. We support
the family's application for asylum on the basis of their son (R's) epilepsy and the fact that he will not be able to
access appropriate treatment.”

[13]     The Decision, at page 3, properly referred to the need to consider the duty imposed by section 55 of the
2009 Act, and to the fact of (R's) epilepsy. On page 4, reference was made to a World Health Organisation report
from which was quoted five paragraphs describing the impact in China of a demonstration project conducted by the
Global Campaign Against Epilepsy: Out of the Shadows. The quotations included the passage:

“Thanks to this demonstration project the government has supported the scale-up of the project to cover 7.5
million in 18 provinces, who now have better access to epilepsy diagnosis and treatment. As of 2012, over
24,000 public health workers have been trained in epilepsy management and nearly 200,000 people have
been screened for epilepsy.”

[14]     The rationale of the Decision in that respect was based on the conclusion, derived from the passages
quoted, that “Therefore epilepsy treatment is available for your client's child” (page 4). Viewed in context however,
in a country of a population of some 1.5 billion people (UN estimate in 2019: 1,434,726,940), it was relevant to
question the adequacy of the provision identified. On the basis of the figures quoted, it was clear that only a
statistically small minority of the whole population had access to epilepsy treatment.

[15]     The rationale of the test considered in _GS (India) and others_ v _Secretary of State for the Home_
_Department [2015] EWCA Civ 40, in relation to health cases in which Article 3 ECHR was engaged, was not_
appropriate in this context. The appropriate approach was to consider the availability of appropriate healthcare in
the foreign state on the basis of a full analysis of the available information. In that regard, the respondent had been
partial in her approach to the issue. No account had been taken of the inevitable and reasonable inference from the
available evidence that, for the vast majority of Chinese citizens, no access to appropriate epilepsy treatment was
available. In this respect, in determining if leave was necessary owing to the petitioner's personal situation, against
the need to safeguard and promote the welfare of children in the UK, no proper and adequate consideration had
been given to the issue raised.
_(ii)_ _the submissions for the respondent(a) the background to the Decision_

[16]     The relevant approach was that set out in PK (Ghana), supra, at paragraph 50:

“50. Article 14(1)(a) of the Convention requires the identification of the individual's relevant personal
circumstances and then an assessment by the competent authority of whether, as a result of these
circumstances and in pursuance of the objectives of the Convention, it is necessary to allow that person to
remain in the United Kingdom. Leaving aside the Convention purposes of facilitating the investigation of
criminal proceedings and/or a civil claim by the victim (neither of which apply in the appellant's case), the only
relevant objective of the Convention is the protection and assistance of victims of trafficking. As I have
described, this is one of the primary objectives of the Convention, as expressed in the Preamble and Article 1.


-----

(D) 12/5

Whether the Appellant's personal circumstances were such as to make it necessary for him to stay in the
United Kingdom could only be assessed by reference to that objective.”

[17]     There was no automatic right to remain by virtue of being a trafficking victim. The rights which arose from
the Trafficking Convention were separate and distinct from the right to asylum.

[18]     Article 4 of the Trafficking Convention defined the terms “child” and “victim” in the following terms:

“d 'Child' shall mean any person under 18 years of age;

e 'Victim' shall mean any natural person who is subject to trafficking in human beings as defined in this article.”

[19]     “Victim” as a defined term, therefore, excluded a child from consideration of the relevant test of Article
14(1)(a), that is: whether “the competent authority considers that (the victim's) stay is necessary owing to their
personal situation”.

[20]     Although for the purposes of the Trafficking Convention, the concept of necessity was referable to the
victim, it was accepted that it remained incumbent on the respondent to take the duties arising from section 55 of
the 2009 Act into account.
(b) the risk of re-trafficking

[21]     The Decision took into account the facts that (i) the petitioner had been released by his traffickers in 2015;
(ii) that full payment of his debt had been made; (iii) that he had no contact with his trafficker since his release; and
(iv) that, under reference to the US Report, country guidance indicated that China was taking steps to provide
assistance to citizens should they require support and protection.

[22]     The respondent had made reference in the Decision to the relevant parts of the US Report. The
respondent had paid due regard to the petitioner's personal circumstances. The petitioner had not demonstrated
that he was in fact at risk of being re-trafficked in China. In circumstances where the test was one of necessity, it
was not enough to demonstrate only that he might, or could be, subject to such a risk.

[23]     The petitioner's challenge to the Decision was predicated on matters general in China, rather than on
factors personal to him. That was an insufficient basis for challenge where the referable test was whether leave was
necessary in the context of his personal circumstances. In that context, at best, under reference to the UK
Government paper, “The Trade in Human Beings: Human Trafficking in the UK”, 2009, it was noted that “With
regards to the level of re-trafficking, it is difficult to ascertain scale”, and that an independent study suggested that,
of a sample group of 118 people, approximately 1 in 5 indicated that they had been re-trafficked (paragraph 26).
(c) the medical condition of the petitioner's son

[24]     The medical condition of the petitioner's son had been taken into account by the respondent. The Decision
included reference to the medical report bearing on his medical condition, and concluded that since epilepsy
treatment was available in China, it was in his best interests to be returned to China together with his parents.

[25]     It was accepted that the respondent's policy did not exclude the operation of section 55 of the 2009 Act
where the child himself was not a victim. In the petitioner's case, the referable duty had been taken fully into
account.

[26]     The decision in Beoku-Betts (supra) in relation to the need to have regard to the family unit as a whole,
per paragraph 43, was to be distinguished from the circumstances of the petitioner's case. In contrast to the
position in Beoku-Betts, in the petitioner's case there was clear language to be considered. The term “victim” was
defined by Article 4 of the Trafficking Convention, and did not include the child.

[27]     It was, nevertheless, accepted that the petitioner's personal circumstances included his family situation,
but the test was in relation to what was necessary in respect of the petitioner's personal circumstances as a victim
of trafficking. In that context, the obligation to promote the best interest of the child in terms of section 55 of the


-----

(D) 12/5

2009 Act was to be considered as part of what was, in effect, an assessment of proportionality. The question was
whether the petitioner had established that adequate treatment was not available in China.

[28]     In that context, the fact that it was stated in the medical report that the treatment which the petitioner's
child was currently receiving in the UK was not available in China did not mean that there was no epilepsy
treatment available there. The statistical references quoted in the Decision from the World Health Organisation
report: “Out of the Shadows: China Demonstration Project”, to which criticism had been directed, where in respect
only of the project there described.

[29]     The interests of the petitioner's child were not determinative, but, rather, were part of a proportionate
evaluation. The respondent had considered what was in the best interests of the child in the context of what was
necessary in light of the petitioner's personal circumstances. Where it was determined that it was not necessary for
leave to be granted, resulting in the petitioner being returned to China, it was legitimate to conclude that the family
unit staying together, with the child residing with his parents in China, would best serve the interests of the child.

[30]     Against the whole background, the Decision was one which was reasonably open to the respondent on
the basis of the evidence before her.
**Discussion**

[31]     In determining whether, in the case of the petitioner, the grant of discretionary leave was necessary owing
to his personal situation, it was incumbent on the respondent, affording the word “necessary” its ordinary meaning,
to consider what was required in order to achieve the objective of the Trafficking Convention in relation to the
protection and assistance of victims of trafficking (PK (Ghana), supra, at paragraph 50). That approach is consistent
with the Home Office guidance on the matter “Discretionary Leave Considerations for Victims of Modern Slavery”,
September 2018, in terms of which, at page 7 of 19, it is stated that the circumstances in which discretionary leave
may be appropriate are dependent on the totality of evidence available in individual cases.

[32]     On the basis of the passages from the US Report, quoted in the Decision, I am satisfied that it is
reasonably to be concluded that the respondent has not attached due weight to the overall tenor of the report
which, read objectively, is critical of the position in China, describes numerous failings, and provides an assessment
of a situation which is characterised as inadequate and of concern.

[33]     Whether it is appropriate to describe the current situation in China in that way is a separate matter, but in
the context of the particular evidence which the respondent has cited as relevant for the purposes of the Decision,
in relation to the assessment of what was necessary for the purposes of securing the objective of affording the
petitioner protection against the risk of being re-trafficked, I consider that there is force in the argument that, in the
determination of this matter, there was a failure to follow the Home Office guidance which required due
consideration of the totality of the available evidence.

[34]     In relation to the issues arising from the medical condition of the petitioner's son, it was conceded for the
respondent, that in the context of the assessment required for the purposes of the Decision, the operation of section
55 of the 2009 Act, and in particular the need to safeguard and promote the welfare of a child, was not excluded by
circumstances in which the child himself was not a victim of trafficking, but rather that these obligations required to
be taken into account as part of an overall assessment of what was necessary owing to the petitioner's personal
situation.

[35]     In response to criticism made of the adequacy of the relevant provision of medical treatment for epilepsy,
as reported in the passages from the World Health Organisation report: “Out of the Shadows: China Demonstration
Project” quoted in the Decision, it was accepted that the statistics to which reference was made were those
pertaining only to that particular project. The respondent's position, however, was that, nevertheless, on that basis it
could be said that, in China, epilepsy treatment was available for the petitioner's child.

[36]     The relevant question, however, to which due weight ought to have been given, was not whether in China,
on the available evidence, treatment for epilepsy, in general, is available, but, rather, whether the particular


-----

(D) 12/5

treatment required by the manifestation of the condition presented in the case of the petitioner's son is available
there. In that regard, the medical report by Dr Brunklaus, which was before the respondent, states in clear terms
that the treatment being received by the petitioner's son would not be available and that, as a consequence, the
outcome of his epilepsy, and the rest of his life, would be significantly affected. Against the background of the
obligation to actively promote the child's welfare as part of the overall assessment required of the respondent, I am
satisfied, in this respect also, that it has been demonstrated that in assessing the petitioner's personal situation, in
particular that aspect of it concerning the welfare of his young child, there was a failure properly to take into account
the totality of the available evidence.

[37]     Having carefully considered the whole circumstances of the case, and, in particular, on a fair and
reasonable reading of the content of the documents on which reliance was placed, I am persuaded that the
cumulative effect of the manner in which the respondent addressed the issues now raised, against the evidence
available, rendered the assessment which was required in determining the Decision materially deficient in the
respects which I have identified.
**Decision**

[38]     In the result, therefore, for these reasons, I shall sustain the petitioner's plea-in-law, repel the respondent's
second, third and fourth pleas-in-law, and reduce the Decision. I reserve, meantime, all questions of expenses.

**End of Document**


-----

