# Independent Workers' Union of Great Britain (IWGB) v RooFoods Ltd (t/a
 Deliveroo) [2018] IRLR 84

TUR1/985(2016)

Central Arbitration Committee, (CAC)

14112017

**_[100   Contracts of employment](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N0TJ-00000-00&context=1519360)_**

**_[101   Meaning of 'employee'](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N13C-00000-00&context=1519360)_**

**_[1100   Trade union recognition](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N162-00000-00&context=1519360)_**

**_[1102   Meaning of 'worker'](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0KK-00000-00&context=1519360)_**
**The facts:**

RooFoods Ltd (t/a Deliveroo) entered into agreements with restaurants and other partners under which it agreed to
deliver food and drink to customers, who could order from Deliveroo's website or smartphone app. To arrange
delivery, Deliveroo entered into what it described as 'supplier agreements' with individuals, who were mostly riders
of bicycles, scooters and motorcycles ('riders'). Riders were made aware of deliveries available for collection
through an app. They could log in or out of the app whenever they chose during set hours. GPS was used to
identify their proximity to a restaurant from which an order had been made and the closest rider was offered the job
and had three minutes to decide whether to accept it.

The IWGB union applied to the Central Arbitration Committee ('CAC') to be recognised for collective bargaining by
Deliveroo for a bargaining unit comprising of riders in Camden, London. Deliveroo did not accept that anyone within
[the proposed bargaining unit was a 'worker' within the meaning of s 296 of the Trade Union and Labour Relations](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y0B0-00000-00&context=1519360)
(Consolidation) Act 1992 ('TULR(C)A'). A few weeks before the commencement of the hearing, Deliveroo
introduced new contracts for its riders. A covering letter specifically drew attention to a substitution clause, stating
'You will see that this agreement means you still have the ability to appoint another person to work on your behalf
with Deliveroo at any time. A substitute working for you can log in using your phone or rider app details. But we
request that you never “swap orders” with another app user as this can prevent the customer from receiving
accurate GPS data to track where their order is.' In practice, substitution by riders was rare. The covering letter also
informed riders that they could work for other companies including competitors.

The parties agreed that the relationship between the riders and Deliveroo had contractual force, that it was not a
contract of employment and that limb (b) of s 296(1) was the only potentially applicable subsection. Section 296(1)
provided that 'In this Act “worker” means an individual who works, or normally works or seeks to work … (b) under
any other contract whereby he undertakes to do or perform personally any work or services for another party to the
contract who is not a professional client of his …' That definition was subtly different to that contained in the


-----

_[Employment Rights Act 1996, s 230(3). The central issue was whether the riders undertook to do or perform](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0P0-00000-00&context=1519360)_
personally any work or services for Deliveroo.

The CAC (Judge Stacey, Chair, Roger Roberts and Michael Leahy OBE) refused the union's application by a
decision dated 14 November 2017.
**The CAC held:**

_[101, 1102](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N13C-00000-00&context=1519360)_

The Deliveroo riders were not 'workers' under s 296 TULR(C)A.

The central and insuperable difficulty for the union was that the substitution right was genuine, in the sense that
Deliveroo had decided in the new contract that riders had a right to substitute themselves both before and after they
had accepted a particular job; and there was evidence of it being operated in practice. Deliveroo was comfortable
with it. One rider explained that he engaged in subcontracting for a 15–20% cut. In light of that substitution right, it
could not have been said that the riders undertook to do personally any work or services for another party. It was
fatal to the union's claim. If a rider accepted a particular delivery, their undertaking was to either do it themselves in
accordance with the contractual standard, or get someone else to do it. They could even abandon the job part way
having only to telephone rider support to let them know. A rider would not be penalised by Deliveroo for not
personally doing the delivery her or himself, provided the substitute complied with the contractual terms that applied
to the rider.

Many riders did as much work as possible insofar as they could, given any other commitments, and placed
themselves as close as possible to restaurants so they would be offered work by the Deliveroo algorithm and relied
on it as their main source of income. But that was not the applicable test under s 296. The delivery had to be
undertaken by a person, however it did not have to be the rider that personally performed it and riders were free to
substitute at will. That necessitated a high level of trust in the substitute by the rider – both because the substitute
had to have either the rider's phone, or Deliveroo passwords to download the rider's app onto her or his phone, and
because of the contractual commitments borne by the rider on behalf of her substitute (particularly in light of
Deliveroo's right to end the contract for any reason on one week's notice), which limited the attractiveness of subcontracting, coupled with the lack of incentive for doing so. But that did not make the substitution provisions a sham.
The factual situation in the present case was very different from, for example, that of Uber private hire drivers, or
Excel or City Sprint.

By allowing an almost unfettered right of substitution, Deliveroo lost visibility, and therefore assurance over who
was delivering services in its name, thereby creating a reputational risk, and potentially a regulatory risk (related to
public safety and food hygiene), but that was a matter for them. The riders were not workers within the statutory
[definition of either s 296 TULR(C)A or s 230(3)(b) Employment Rights Act 1996.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0P0-00000-00&context=1519360)
**Cases referred to:**

_Autoclenz v Belcher_ _[[2011] UKSC 41, [2011] IRLR 820, [2011] 4 All ER 745, [2011] ICR 1157SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53V7-X6Y1-DYPB-W305-00000-00&context=1519360)_

_Kalwak v Consistent Group Ltd_ _[UKEAT/0535/06, [2007] IRLR 560 EAT](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P217-00000-00&context=1519360)_

_Pimlico Plumbers Ltd v Smith_ _[[2017] EWCA Civ 51, [2017] IRLR 323, [2017] ICR 657CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N93-VH01-DYPB-W374-00000-00&context=1519360)_

_Protectacoat Firthglow Ltd v Szilagyi_ _[[2009] EWCA Civ 98, [2009] IRLR 365, [2009] ICR 835CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W44S-00000-00&context=1519360)_
**Appearances:**

_[Trade Union and Labour Relations (Consolidation) Act 1992: s 296](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0XF-00000-00&context=1519360)_

For the meaning of 'worker' see Harvey AI [82]

For the union:

JOHN HENDY QC and KATHARINE NEWTON instructed by Leigh Day


-----

For Deliveroo:

CHRIS JEANS QC and AMY ROGERS, instructed by Lewis Silkin
1
**Introduction**

The IWGB (the union) submitted an application to the CAC dated 28 November 2016 that it should be recognised
for collective bargaining by RooFoods Ltd t/a Deliveroo (Deliveroo) for a bargaining unit comprising 'Drivers in the
Camden Zone' adding 'By drivers we refer to both drivers of motorbikes and riders of bicycles'. The location of the
bargaining unit was given as 'Camden, London'. The application was received by the CAC on 29 November 2016
and the CAC gave both parties notice of receipt of the application that same
**[*85]**

day. The company submitted a response to the CAC dated 6 December 2016 which was copied to the union.
2

In accordance with _[s 263 of the Trade Union and Labour Relations (Consolidation) Act 1992 (the Act), the CAC](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYD0-TWPY-Y19J-00000-00&context=1519360)_
Chairman established a Panel to deal with the case. The Panel consisted of Her Honour Judge Stacey, the Panel
Chair, and, as Members, Mr Roger Roberts and Mr Keith Sonnet. Mr Sonnet was unable to attend the hearing in
this matter and was replaced by Mr Michael Leahy OBE. The case manager appointed to support the Panel was
Nigel Cookson.
3
**Issues**

The Panel is required by para 15 of Sch A1 to the Act (the Schedule) to decide whether the union's application to
the CAC is valid within the terms of paras 5 to 9; is made in accordance with paras 11 or 12; is admissible within the
terms of paras 33 to 42; and therefore should be accepted.
4
**Summary of the union's application**

In its application to the CAC the union stated that it had made a formal request for recognition to Deliveroo on 7
November 2016 and Deliveroo responded on 21 November 2016 rejecting the request on the grounds that its
drivers were not workers and the Schedule did not apply; the union did not represent the views of the drivers
nationally and the proposed bargaining unit was inappropriate and not compatible with effective management.
Copies of the relevant letters were attached to the application.
5

When asked whether the union had made a previous application under the Schedule for statutory recognition for
workers in the proposed bargaining unit or a similar unit the union answered 'No'. The union stated that, following
receipt of the request for recognition, Deliveroo had not proposed that Acas should be requested to assist the
parties.
6

According to the union Deliveroo employed a total of 4,500 workers with 100 of these in the proposed bargaining
unit, of whom 32 were union members. When called upon to provide evidence that the majority of the workers in the
proposed bargaining unit were likely to support recognition for collective bargaining, the union stated that more than
50% of the workers in the bargaining unit had signed a petition stating that they wanted union recognition for the
proposed bargaining unit. Supporters' names were confidential however the union was prepared for the CAC to
verify the evidence.
7

The union detailed its reasons for selecting the proposed bargaining unit. It explained that Deliveroo was a business
that delivered food from restaurants to customers: its tagline was 'your favourite restaurants, delivered fast to your
door.' Drivers collected the food from restaurants on their motorbikes or bicycles and then transported it to
customers. Deliveroo managed its business by dividing it into different geographical zones. All drivers in London


-----

were assigned to a specific zone. Drivers' work revolved around this zone assignment. For example, when drivers
were waiting for a job to be sent to them they were told to go to the centre of the zone. Drivers were only sent to
collect food from restaurants within the allocated zone and rarely would they deliver food outside the zone such as
when a customer was based just outside the zone. Different zones had different pay structures. For example, in
Camden drivers were paid a piece rate of £3.75 per delivery. However, in Battersea most drivers were paid a
combination piece rate/hourly rate of £7 per hour + £1 per delivery. Deliveroo managed each zone separately with
managers assigned to specific zones. Given that Deliveroo of its own accord organised its business by dividing it
into geographical zones with different pay structures for different zones, it was the union's submission that a
bargaining unit based on a zone was compatible with how Deliveroo managed its business and workforce and was
therefore compatible with effective management.
8

The union said that the bargaining unit had not been agreed with Deliveroo and that, as far as it was aware, there
was no existing recognition agreement in force covering any of the workers in the proposed bargaining unit.
9

The union confirmed that it held a current certificate of independence a copy of which was attached to its
application. The union stated that it had copied its application and supporting documents to Deliveroo on 28
November 2016.
10
**Summary of Deliveroo's response to the application**

In a detailed response to the union's application Deliveroo stated that it had received a written request for
recognition from the union on 7 November 2016 and that it declined the request by way of letter dated 21 November
2016, a copy of which it enclosed.
11

Deliveroo confirmed that it had received a copy of the application form from the union on 28 November 2017. At no
stage had it agreed the proposed bargaining unit. It did not accept that anyone within the proposed bargaining unit
was a 'worker' within the meaning of s 296 of the Act and in any event such a bargaining unit would be wholly
incompatible with effective management and would, if adopted, tend towards the creation of small fragmented
bargaining units.
12

Asked for the number of workers[1] it employed Deliveroo stated once again that it did not accept that anyone that it
engaged to perform deliveries to customers, whether by motorbike or bicycle, was a worker within the meaning of s
296 of the Act. However, Deliveroo stated that at present some 10,808 individuals were engaged as suppliers.
13

Deliveroo stated that it did not agree with the number of riders in the bargaining unit as particularised by the union
as it did not accept that the individuals it engaged were 'workers'. Nor did Deliveroo accept the concept of a
'Camden Zone' and asked that the union be called upon to clarify the basis on which it asserted that existence of
such a zone or the number of riders within it. Deliveroo added that the concept of a zone such as CKT was
somewhat vague and nebulous. 216 riders were registered in CKT but being registered to work in a particular area
did not tie suppliers to work in that area. For example, in the past 24 weeks 535 suppliers had performed duties in
the CKT area.
14

Deliveroo confirmed that there was no existing agreement for recognition in force covering workers in the proposed
bargaining unit.
15

Deliveroo stated that it had not proposed that Acas be requested to assist following receipt of the application.
16


-----

In answer to the question whether it agreed with the number of workers in the bargaining unit as defined in the
union's application Deliveroo repeated its comments as to the concept of the 'Camden Zone' stating that it had no
basis for either agreeing or disagreeing with the union's estimate having received no supporting evidence that
would enable Deliveroo to assess whether the individuals were engaged in CKT or not.
17

When asked to give its reasons if it took the view that the majority of workers in the bargaining unit would not be
likely to support recognition of the union Deliveroo stated that on its own figures the union only had 32 members
within CKT and that while it was difficult to arrive at a meaningful figure for the number of individuals in the
proposed bargaining unit, notwithstanding Deliveroo's view that they were not 'workers',
**[*86]**

if the 535 individuals that had performed deliveries in CKT in the last 24 weeks were taken as a reference point,
then 32 was substantially less than 10% of this number.
18
**Further correspondence and case management directions**

Both parties provided extensive further information and detailed submissions focussed on the two issues in dispute:
whether the riders were workers within the statutory definition and the level of support for union recognition within
the proposed bargaining unit. The parties were unable to agree case management directions and a telephone case
management conference with the Panel Chair took place on 10 March 2017 and suitable directions were agreed
and issued along with a notice of hearing.
19

During the course of the case management conference it was agreed that the hearing would encompass both the
question of whether the CAC had jurisdiction to consider the application and whether the provisions of para 36 of
the Schedule were satisfied. In order to assist the Panel's determination of the second issue – whether 10% of the
proposed bargaining unit were members of the union and whether a majority of the workers (if indeed they were
workers[2]) in the proposed bargaining unit would be likely to favour recognition of the union – it was agreed that the
case manager would conduct a check of membership and support in the proposed bargaining unit in advance of the
hearing in order that the parties could include submissions on his findings when lodging their submissions on the
'worker' issue.
20
**The membership and support check**

To assist in the application of the admissibility criteria specified in the Schedule, namely, whether 10% of the
workers[3] in the proposed bargaining unit are members of the union (para 36(1)(a)) and whether a majority of the
workers in the proposed bargaining unit are likely to favour recognition of the union as entitled to conduct collective
bargaining on behalf of the bargaining unit (para 36(1)(b)), the Panel proposed independent checks of the level of
union membership in the proposed bargaining unit which is commonly understood to comprise 'Riders of pushbikes
(cycles) and motorbikes (scooters) with an 'Ops code of CKT' and the number of riders in the unit who had signed a
petition supporting recognition of the union.
21

It was agreed with the parties that Deliveroo would supply to the case manager a list of the full names, dates of birth
and job titles of riders within the proposed bargaining unit, and that the union would supply to the case manager a
list of the full names and dates of birth of the paid up union members within that unit and a copy of the petition. The
information from both the union and Deliveroo was received by the CAC on 8 May 2017. It was explicitly agreed
with both parties that, to preserve confidentiality, the respective lists and the petition would not be copied to the
other party and that agreement was confirmed in a letter from the case manager to both parties dated 3 April 2017
in line with the agreement reached during the case management telephone conference on 10 March 2017.
22

Deliveroo provided a list bearing the details of 214 individuals in the proposed bargaining unit explaining in its
i l tt th t th li t t d th ith CKT d f 3 M 2017 hi h th l t d th


-----

code date was recorded before the system was changed. The list of members supplied by the union contained 54
names. According to the case manager's report the number of Union members in the proposed bargaining unit was
41, a membership level of 19.16%.
23

The union also provided the results of a petition conducted both online and on paper which it stated supported its
application. The paper version of the petition ran to 50 pages, each carrying the proposition:

'I am a Deliveroo driver working in the Camden zone. I support union recognition of the IWGB by Deliveroo for
the Camden Zone bargaining unit.'

The print out of the on-line petition gave a timestamp, first name, last name and that the 'signatory' had checked a
box to confirm that 'I am a Deliveroo driver/rider who works in the CKT zone (Camden Kentish Town zone) in
London. I want the Independent Workers' Union of Great Britain (IWGB …' (The rest of the proposition was not
visible.)
24

Deliveroo also provided, outside the agreement referred to above, a survey that it said was completed by 63
riders/drivers and which ran to some 132 pages. Deliveroo further provided, again outside the agreement referred
to above, eight emails from riders/drivers in the proposed bargaining unit that were addressed to the union in which
they notified the union of their wish to cancel their membership. Deliveroo explained that annexed to its covering
letter were four lists: the first represented those riders that had completed Deliveroo's survey and said that although
they had signed the union's petition they had subsequently changed their minds and were no longer supportive of
the union. The second list comprised a list of 14 names of riders who said they were unhappy and planned to
cancel their membership. The third list was the list of riders who had forwarded to Deliveroo emails that they had
sent to the union cancelling their membership. The final list represented those surveyed who said that they had not
signed the union's petition. No checks were conducted using these four lists as the information fell outside the
scope of the original agreement referred to above.
25

The case manager's report showed that the paper petition was signed by 46 riders in the proposed bargaining unit,
a figure which represents 21.5% of the bargaining unit. Of those 46 signatories 26 were members of the union
(12.15% of the proposed bargaining unit) and 20 were non-members (9.35% of the proposed bargaining unit). The
report also showed that the online petition was signed by 24 riders in the proposed bargaining unit, a figure which
represents 11.21% of the bargaining unit. Of those 24 signatories 18 were members of the union (8.41% of the
proposed bargaining unit) and six were non-members (2.80% of the proposed bargaining unit). The report noted
that 10 union members and three non-members had signed both forms of the petition
26

A report of the result of the membership and support check was circulated to the Panel and the parties on 15 May
2017 and the parties were informed that submissions on the findings in the case manager's report should be
included with the parties' submissions on the 'worker' issue due to be lodged ahead of the hearing commencing 23
May 2017.
27
**The hearing**

The hearing was held in London over four days on the 23, 24 and 25 May and 26 June 2017. It is regretted that an
earlier hearing could not be convened, but the parties' desire to be represented by their counsel of choice was
respected. The names of those attending the hearing on behalf of the parties are annexed to this decision.
28

The parties had produced an agreed bundle of documents and witness statements had been exchanged in
accordance with the case management directions. We wish to record our thanks to the parties for their work in
preparing the bundles for the Panel as well as our

**[*87]**


-----

gratitude to both Mr Hendy QC and Ms Newton, Mr Jeans QC and Ms Rogers for their helpful oral and written
submissions and advocacy.
29

For Deliveroo the following gave live evidence at the hearing: David Scott, (UK and Ireland Operations Director);
Farrukh Riaz, Asim Munir, Rashid Mamun and Hannah Taylor, (Deliveroo riders); and, Charlotte Clancy, (User
Research Team member). William Holmes was not available for cross-examination and nor were the anonymous
riders whose statements were appended to Mr Scott's witness statement.
30

For the union both Mags Dewhurst (Union member and Chair of the Couriers and Logistics Branch, February 2015–
May 2017) and Billy Shannon (Deliveroo Rider and IWGB member) gave evidence. In accordance with normal CAC
procedures, none of the witnesses gave evidence under oath.
31
**The evidence**

The Panel is grateful to the parties for their assistance in formulating some agreed facts from the evidence. Where
the evidence was in dispute, or the facts to be inferred from the agreed and decided facts was in dispute, the Panel
has made its findings and reached its conclusions on the balance of probabilities from the evidence before it and
noting that the union, as the bringer of the claim, bears the burden of proof of establishing worker status and the
requisite level of support for Union recognition.
32

The witness statement of Mr David Scott (Deliveroo's Operations Director for UK & Ireland) had a number of
anonymous statements with names and signatures redacted and addresses withheld. The Panel accepted the
union's objections to their being considered. Although CAC hearings do not follow strict rules of evidence and
evidence is not given under oath, the statements were of such limited probative value when there was no
opportunity for the union to test the evidence that they were excluded from the Panel's considerations.
33

There was considerable evidence before the Panel, not all of which was relevant to the determination of the issues
before us. Where we have not recorded facts from the evidence before us, it is because it was not sufficiently
pertinent or relevant to the issues. Inevitably in a case such as this the parties wished to explain various matters to
us that fall outside the scope of the hearing and we intend no disrespect to either side by nor rehearsing them in
what is already a lengthy decision. For example, it is not part of our role to say whether Deliveroo's approach to the
payment of riders is generous or not, or whether Deliveroo is seeking to subvert the national minimum wage
legislation. Nor do we make findings about whether Deliveroo deliberately tried to sabotage a union meeting on 8
November 2016 by offering surge pricing at the precise time of the gathering to lure would be attendees away.
Insofar as the relationship between the union and Deliveroo is relevant for ascertaining likely majority support for
the union, it is not necessary to make specific findings concerning that meeting.
34
**The facts**

Deliveroo was founded in 2013 in London and now has operations in approximately 150 cities worldwide. Its
business involves the delivery of food and drink items from restaurants and others (whom they refer to as partners)
to customers' homes or to other premises such as offices.
35

Deliveroo enters into commercial agreements with the restaurants and other partners by which it agrees to deliver
food and drink items supplied by them to customers. It enters into what it describes as 'supplier agreements' to
arrange the delivery of the food and drink items with individuals, who are mostly riders of bicycles, scooters and
motorcycles, although outside London in the UK some are car riders. We shall refer to them as Riders. They are
accurately described as the face of Deliveroo as they will usually be the only human interaction the customers have
with Deliveroo.
36


-----

The union is an independent trade union and recruits members and organises in the delivery and courier sectors,
amongst other areas.
37
_The proposed bargaining unit_

The proposed bargaining unit comprises 'riders of pushbikes (cycles) and motorbikes (scooters) registered in CKT'.
These were Riders who are referred to by Deliveroo as having an 'Ops Code' of 'CKT' which stands for 'Camden &
Kentish Town' and referred to a 'food delivery zone' with those initials.
38

Deliveroo registered all Riders, including 'fee per delivery' (FPD) riders with an 'Ops Code', such as CKT. It was
those registered with an Ops Code of CKT who are the subject of this application. There is a dispute between the
parties as to whether those without the CKT code make deliveries within CKT and the extent to which those with the
CKT code deliver outside the code, but that issue is not relevant for the purposes of this decision – although it may
well become so should the appropriateness of the proposed bargaining unit require determination.
39
_Recruitment_

The Deliveroo website enables would-be Riders to apply to join what Deliveroo calls the Roo community, referring
to them as Roomen and Roowomen – there is a considerable emphasis on the sense of community and team spirit
shared by the Riders as part of the innovative and fast-growing company image that Deliveroo presents.
40

Deliveroo emphasises the personal nature of the service provided to its customers, advertising on its website: 'We
have a fantastic team of drivers who take pride in getting your food to you as quickly as roo-ly possible. We call
them the Roowomen and Roomen.' More recently the non-gender specific abbreviation of 'Roos' was introduced –
such as emails addressed to all Riders: 'Hi Roos' and 'Hey Roos.'
41

In its Rider recruitment literature, it emphasises the importance of its Riders to the company and seeks to engender
a sense of belonging to the 'Roo Community.' Deliveroo sends out monthly 'Roosletters' to all Riders, with various
offers and promotions with other companies and arranges get togethers for Riders to meet each other from time to
time.
42

They have described the Riders as 'The very life blood of our company. Without them Deliveroo wouldn't exist – a
fact at the very heart of how we operate as a business' and they stress the consultative nature of the relationship
with the Riders in their recruitment literature.
43

Deliveroo refers to their recruitment procedure as the onboarding process. Individuals wanting to become Riders
apply to work for Deliveroo online by filling in an application form[4]. After filling in the online application form, riders
are telephoned by a representative of Deliveroo for what is, for all intents and purposes, a telephone interview.
Although Deliveroo states it tries to avoid using the term 'telephone interview' the purpose of telephoning the
applicants is a sift, to ask questions of them in order to gather information to determine whether certain minimum
requirements are met before inviting the applicant for a trial session. In other words, it is a telephone interview.
44

If the applicant Rider passes the sift, s/he must then attend a trial session during which they and their
**[*88]**

bicycle are assessed by Deliveroo trainers. Their bike riding competency is also assessed, and feedback on the
trainees is provided to Deliveroo.
45


-----

If the trial goes well, the applicant Rider receives confirmation – 'Congratulations on passing your trial shift' was the
wording on the email Mr Shannon received notifying him that he had been successful, although Deliveroo now calls
it a 'trial session,' not 'trial shift.'
46

The next phase of the process involves attending at Deliveroo premises to complete an online training course. It
involves watching a number of detailed videos containing instructions on how to carry out the role. These videos
have learning points at the end, and online multiple choice tests which the riders must take and score 100% (there
is no limit to the number of times these tests can be re-taken) to demonstrate the Rider's understanding of the
topics covered. The IWGB understood that the recruitment process is run by Deliveroo's 'Driver Hiring Team',
whereas Deliveroo referred to them as the Rider Supply team. They were colloquially called the Rider or driver
hiring team, whatever their official nomenclature.
47

There is considerable emphasis on the need to present well as the face of Deliveroo as a customer service with a
front line role, as well as detailed advice on such matters as how to wash your hands and other aspects of food
hygiene and health and safety stressing the important responsibility of food handling for customers when working
for Deliveroo.
48

Criminal record bureau checks are undertaken and paid for by Deliveroo before any Rider is accepted.
49

Once accepted as a Rider, the individual is required to sign a Supplier Agreement and pay £150 for an 'equipment
pack' containing a thermal box and bags to transport the food and drink, a branded hi-vis jacket and various other
items. When Riders stop working for Deliveroo they are refunded the £150 if they return the equipment in good
order.
50

Since the start of 2017, in spite of a high demand to become a Rider, Deliveroo has taken on very few new Riders
in CKT in order to avoid an over-supply of Riders as a way of regulating the market to ensure there is sufficient
work available for its Riders.
51
_Written contractual terms with Riders_

Billy Shannon is a Rider and member of the union and his FPD contract (pp 212–8, 'the Earlier Contract') with
Deliveroo is typical of the contracts entered into between riders registered in CKT and Deliveroo that were offered
by Deliveroo up until a few weeks before the commencement of the hearing in this case. New contracts were
introduced just before the first hearing ('the New Contract' see p 3/731). Some of the Earlier Contracts are still in
force, but Deliveroo is encouraging Riders on the Earlier Contract to change to the New Contract and newly
recruited Riders are required to sign the New Contract. The parties agreed that the Panel should consider the
question of worker status by reference to the New Contract and not the Earlier Contract.
52

The terms of both the Earlier and New Contracts, and indeed all the contracts with Riders that have been issued at
any time by Deliveroo, are set by Deliveroo and there is no scope for individual negotiation. Riders are required to
sign the contract if they wish to become a Deliveroo Rider.
53

'Services' is defined in the New Contract as 'the collection by you of hot/cold food and/or drinks ('Order Items') from
such restaurants or other partners ('Partners') as are notified to you through the Deliveroo rider app ('App'), and the
delivery of such Order Items by bicycle, car, motorbike or scooter to Deliveroo's customers at such locations as are
notified to you through the App.' (cl 2.2).
54


-----

Deliveroo issued the New Contracts to existing Riders on 11 May 2017 with a covering letter which specifically drew
attention to the substitution clause: 'You will see that this agreement means you still have the ability to appoint
another person to work on your behalf with Deliveroo at any time. A substitute working for you can log in using your
phone or rider app details. But we request that you never “swap orders” with another app user as this can prevent
the customer from receiving accurate GPS data to track where their order is.'
55

The covering letter also informed Riders that they could work for other companies including competitors: 'That is
fine with us: as an independent contractor you are free to work with whoever you choose and wear whatever kit you
want to. There continues to be no requirement to wear Deliveroo branded kit while you work with us.' (3/729–730).
56

The New Contract states that the Rider is:

'not obliged to do any work for Deliveroo, nor is Deliveroo obliged to make available any work to you.
Throughout the term of this Agreement you are free to work for any other party including competitors of
Deliveroo.

…

2.4 It is entirely up to you whether, when and where you log in to perform deliveries, save that it must be in an
area in which Deliveroo operates and at a time when that area is open for deliveries.

…

2.51 while logged into the App, you can decide whether to accept or reject any order offered to you and if you
do not wish to receive offers of work at any time, you can use the “unavailable” status.

…

2.6 when you choose to provide Services you should:

2.6.1 when you have accepted an order, go to the Partner to collect the order items. You should then deliver
the Order Items to the customer. In both instances, you should complete the Services within a reasonable time
period, using any route you determine to be safe and efficient.

6.2.2 be professional in your dealings with Deliveroo staff, other riders, restaurant personnel and members of
the public while providing the Services, and provide the Services with due care, skill and ability.

**3. equipment**

3.1 you will provide the equipment necessary to provide the Services including your own phone; and bicycle,
car, motorbike or scooter. You will comply with all applicable legal requirements in relation to the usage of such
vehicle, will ensure that it is at all times in a good state of repair and roadworthy while providing the Services,
and (if you ride a bicycle, motorbike or scooter) you confirm that you will use appropriate road safety equipment
including a helmet and clothing which meets delivery to safety standards. You will notify Deliveroo of any
driving or other conviction which may impact your ability to provide the Services.

3.2 you will not, at any time when providing Services, drive the car or ride the bicycle, motorbike or scooter
while under the influence of drugs or alcohol.

3.3 you will use food transportation equipment which meets Deliveroo's safety standards.

3.4 Deliveroo's safety standards, as updated from time to time, will be communicated to you. Equipment which
meets Deliveroo's safety standards can be obtained from Deliveroo.'

**[*89]**
57


-----

FPD riders are paid on a fee per delivery basis. Clause 4 sets out that payment is for each completed delivery
which is defined as 'the collection of Order Items from a Partner and delivery to a customer'. Deliveroo prepares a
draft invoice on a fortnightly basis in respect of the services in the previous fortnight provided by the Rider or their
substitute. Riders may create and submit their own invoices should they prefer. Riders are entitled to keep any tips
or gratuities paid directly to them. The New Contract states that 'as a self-employed supplier you are responsible for
accounting for and paying any tax and national insurance due in respect of sums or penalty payable to you under or
in connection with this Agreement. You will inform Deliveroo of your tax reference number on request'.
58

The Rider provides various warranties as strict conditions of the New Contract such as a right to residency and
work in the UK, not having any unspent convictions and that s/he will comply with all legal obligations and allow
customers to track the progress of deliveries by using GPS technology.
59

Riders are responsible for obtaining third party liability insurance for themselves and the New Contract states that
'any substitute appointed by you need not have their own insurance as long as they are covered under your
insurance.'

Clause 8 sets out the provisions concerning the right to appoint a substitute as follows:

'8.1 Deliveroo recognises that there may be circumstances in which you may wish to engage others to provide
the Services. Deliveroo is not prescriptive about this and you therefore have the right, without the need to
obtain Deliveroo's prior approval, to arrange for another courier to provide the Services (in whole or in part) on
your behalf. This can include provision of the Services by others who are employed or engaged directly by you;
however, it may not include an individual who has previously had their Supplier Agreement terminated by
Deliveroo for a serious or material breach of contract or who (while acting as a substitute, whether for you or a
third party) has engaged in conduct which would have provided grounds for termination had they been a direct
party to a Supplier Agreement. If your substitute uses a different vehicle type to you, you must notify Deliveroo
in advance.

8.2 it is your responsibility to ensure your substitute(s) have the requisite skills and training, and to procure that
they provide the warranties at clause 5 above to you for your benefit and for Deliveroo's benefit. In such event
you acknowledge that this will be a private arrangement between you and that individual and you will continue
to bear full responsibility for ensuring that all obligations under this Agreement are met. All acts and omissions
of the substitute shall be treated as though those acts and/or omissions were your own. You shall be wholly
responsible for the payment to or remuneration of any substitute at such rate and under such terms as you may
agree with that substitute, subject only to the obligations set out in this Agreement, and the normal invoicing
arrangements as set out in this Agreement between you and Deliveroo will continue to apply.'

60

The Rider may terminate the New Contract at any time for any reason on giving Deliveroo immediate notice in
writing and Deliveroo is required to give a Rider one week's written notice of termination for any reason, and with
immediate effect 'in the event of any serious or material breach of any obligation owed by you (including for the
voidance of doubt where such breach is the responsibility of any substitute engaged by you).' (cl 10).
61

There are fairly standard clauses concerning confidentiality and data protection including: 'You, and any substitute,
will maintain password protection on the smartphone that you use in the provision of the Services and keep your
App login details and password confidential at all times.'
62

Clause 12 addresses **_modern slavery and human trafficking laws: 'In performing your obligations under the_**
Agreement, you shall comply with all applicable anti-slavery and human trafficking laws, statutes, regulations and
codes in place at the time including but not limited to the **_[Modern Slavery Act 2015 and any anti-slavery policy](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
adopted by Deliveroo communicated to you (and will ensure that any substitute engaged by you does the same) '


-----

There is no explanation, nor any training on how the Rider is expected to know of what all applicable anti-slavery
etc laws etc consists of, nor her or his obligations, Deliveroo has not adopted any anti-slavery policy, but confirmed
at the final hearing that the transparency in supply chains reporting requirements of s 54 of the Modern Slavery Act
apply to the company, given its global annual turnover, but no statement has yet been made pursuant to that
provision.
63

Clause 13.2 provides that: 'this Agreement contains the whole agreement between you and Deliveroo. You confirm
that you are not entering into the Agreement in reliance upon any oral or written representations made to you by or
on behalf of Deliveroo.' Clause 13.3 provides that the agreement is personal to the Rider and may not be assigned
to a third party without Deliveroo's express written agreement which goes on to state '(for the avoidance of doubt,
this includes any substitute engaged by you in the provisions of the Services)'.
64

Deliveroo does not provide a pension or other benefits such as life assurance and permanent health insurance to
riders. Previous restrictions on wearing competitor clothing and an obligation to wear at least one piece of Deliveroo
branded equipment have been removed from the New Contract.
65

After Riders were sent the New Contract to consider agreeing and signing, it was followed up by a further email the
next day, 12 May 2017, which addressed the issue of 'swapping orders'. The communication set out what it
described as clarification of swapping orders and what works and what does not. It provided as follows: 'It's very
important that customers can track their orders accurately. So, if you ask someone else to complete a delivery
assignment to your phone, it is important that they have your phone with them while completing that delivery. This
will ensure that the customer always receives accurate GPS data to track where their order is.' (P3/735).
66
**How the parties conduct themselves in practice**

Once a Rider has signed whichever contract was in force at the time – in Billy Shannon's case the Earlier Contract,
or the New Contract, they can download the Deliveroo application (the App). It can be downloaded to any number
of devices but used by only one, at any one time: it is not possible to sign in simultaneously on multiple devices.
The App is the sole means by which Riders are made aware of deliveries available for collection from partners for
delivery to customers.
67

Within FPD zones such as CKT, there is no expectation or requirement that riders will indicate in advance when
they intend to work. Such riders are not subject to any form of schedule. Instead they operate exclusively on a 'free
log-in' basis, meaning they can log in and log out of the Deliveroo App whenever they choose during 'opening
hours' (those hours being when restaurants are open and customers are making orders – a
**[*90]**

rider could not, for example, log in at 3am in an area where all restaurants are closed), subject to the requirement
that they perform at least once every three months.
68

Riders with a CKT Ops Code are paid on a 'fee per delivery' ('FPD') basis, also sometimes known as 'drop fee'. This
means that they are paid a fee for each delivery they complete. Riders in CKT are normally paid £3.75 per delivery,
however, the fee offered to riders for each delivery varies to some degree depending on demand: 'surge pricing',
(higher fees) may be offered when demand is particularly high and there is a need to incentivise riders to go out on
the road.
69

When a FPD Rider is logged into the App, a screenshot appears with a checklist of things to remember before they
start. Since the requirement to wear Deliveroo branded equipment has been removed, the screenshot no longer
refers to Deliveroo branded equipment (p 473A) The App defaults to marking the Rider as 'Unavailable' for


-----

deliveries, but by swiping right on their screen they can make themselves 'available', if the zone they are in is open
at that time.
70

They can swipe left to make themselves 'unavailable' at any time, unless they have already accepted an order
which has not yet been delivered. If Riders do not want to perform any more deliveries, they can click 'this is my last
order' and no more deliveries will be assigned to them
71

When Riders mark themselves as available, the Deliveroo algorithm may start to offer them work if an order has
been requested in the vicinity. It uses GPS to identify the Rider's proximity to a restaurant from which an order has
been made and the Rider closest to it is offered the job and has three minutes to decide whether to accept it. If the
Rider rejects, or does not accept the job by ignoring the request within three minutes, the job is offered to another
Rider. Riders wanting jobs can therefore maximise their chances of being offered a delivery by being in the vicinity
of popular restaurants – physically placing themselves and their cycle nearby. It explains why Riders congregate at
take away and restaurant hot spots at anticipated busy times.
72

When a Rider accepts an order, they will be told the details of the restaurant or partner where the food or drink is to
be collected from via the App. They go to the relevant partner to collect it and at that point only do they find out what
the order consists of and where it is to be delivered to and then take it to the customer's location. The Deliveroo
App will suggest a route for them, but they are not obliged to follow it. Before accepting the job the Rider will not
know how much food is to be delivered or the delivery address. Once they have delivered the items, they slide a
button on their phone (or whatever other device they have used and downloaded the App onto) to say they have
completed the order. They will only be considered available to accept another order after they have confirmed
delivery of the previous order.
73

Occasionally there will be a stacked order where Deliveroo require the Rider to take two orders from the same
restaurant to different locations. When both have been completed by the Rider confirming by swiping the App, s/he
will then be considered available for further orders, unless the Rider chooses not to be.
74

Riders are typically provided with 'rider intelligence data' from time to time, including order volumes and expected
peak periods, for their zone and sometimes for neighbouring zones in which they are, at times, also permitted to
work. This helps them to decide if and when to perform deliveries, either at all, or in any particular area. A high
demand period is more likely to be one in which a higher price is offered, so information about order volumes and
expected peak periods gives them a signal about price.
75

Restaurants and other 'Partners' receive information about the orders placed through Deliveroo. This information
includes the order number, the full name of the Rider who will collect the order from the restaurant/Partner and that
Rider's telephone number.
76
_Substitution in practice_

There is no policing by Deliveroo of a Rider's use of a substitute should s/he choose to use one. Deliveroo simply
relies on the contractual terms with the Rider. In practice substitution is rare as there is no need for a Rider to
engage a substitute. If the Rider does not want to accept a job or be available for work, s/he need not log on to the
App, or if they are logged on, they do not need to make themselves available, and if they are logged on and mark
themselves as available they are not under any obligation to accept any jobs offered. There are no adverse
consequences for them.
77


-----

We have set out above the termination provisions that enable Deliveroo to terminate the Rider's contract for any
reason at all with one week's notice. Deliveroo does not terminate FPD contracts for not accepting a certain
percentage of orders or for Riders not making themselves sufficiently available, although the position is different for
hourly paid Riders. FPD Riders are vulnerable to having their contracts terminated on one week's notice if their, or
their substitute's delivery times over a sustained period are deemed too slow.
78

A few, if that, Riders use substitutes. In a survey of Riders with CKT Ops codes in April/May 2017 conducted by
Deliveroo 14 of the 65 Riders who answered the question had either themselves used a substitute or knew of other
Riders who did. A Rider might, for example, allow a friend (who is not a Rider) to use their App while they are on
holiday, and since Deliveroo is not currently taking on new Riders in CKT, the friend would not otherwise be able to
do so. All that is required is for either the substitute to download the App onto her or his own phone or the Rider
lend their device to their substitute. Either way, the substitute would need to be privy to the Rider's Deliveroo
password. The confidentiality clause in the New Agreement provides for the substitute to be told the password, but
the Rider is responsible for the substitute maintaining confidence. The Rider is paid for any deliveries made by the
substitute, and Deliveroo will not be aware of the identity of the substitute, or the fact that one has been used on
any particular occasion. How and if the substitute is remunerated by the Rider is between the Rider and the
substitute.
79

Most Riders do not use a substitute – if they do not want to do Deliveroo deliveries they do not log onto the App and
do not wish to sub-contract the opportunity or be responsible for anyone else. We have set out above the provisions
in the New Contract that make the Rider entirely responsible for the substitute, including insuring them and the
Rider has to trust the substitute with her or his Deliveroo passwords. The vast majority of Riders see no point in
engaging a substitute.
80

A few Riders do however and one Rider who gave evidence on behalf of Deliveroo, Asim Munir, explained that he
regularly engages a substitute by giving a friend his App to download and password details. When repeatedly
pressed to explain why he did so, he eventually explained that he took 15–20% of the fee he received from
Deliveroo, passing on the balance to his friend: he was exercising the substitution provisions for his own potential
profit. Deliveroo does not object to this practice.
**[*91]**
81

We heard of one example – provided by Deliveroo – of a Rider accepting a delivery and then changing his mind
and substituting the job after acceptance and before going to the restaurant for collection. It will be very rare indeed
that this will happen in practice – what would be the point? The explanation for the example we were told about
involved a group of Riders sitting in a Cafeì Nero close to popular restaurants, all logged into the App and marking
themselves as available, sitting around drinking coffee and waiting for jobs to be offered. When one of them was
offered and had accepted the job, just a few seconds later, he apparently changed his mind decided he wanted to
stay longer in the cafeì chatting to his wife who was also there. He passed the job on to one of the others sitting
with him, by handing that other his device with the App. Mr Hendy cross-examined Deliveroo's witnesses
extensively about this event and questioned the plausibility of the account. It does sound a little surprising, but even
if the whole situation was crafted to provide an example of a mid-job substitution, it effectively demonstrates the
capacity of a Rider to do such a thing, should they want to.
82

If a Rider is unable or does not want to complete a job after accepting it and does not want, or is not able to pass it
on to a substitute, they have to telephone Rider Support who will arrange for another Rider to take over the job.
That Rider will not be paid if s/he or their substitute does not complete the job and it is Rider Support who reallocate the delivery. Deliveroo was planning to change the system to enable a Rider to cancel after accepting via
the App and facilitate the process.
83


-----

Some Riders are also signed up with other food delivery organisations such as Uber Eats, and Deliveroo does not
object to this – as they said in their email accompanying the New Contract: 'We know that the vast majority of riders
work with other companies as well as Deliveroo, including our competitors. That is fine with us: as an independent
contractor you are free to work with whoever you choose' (p 3/730). The union does not believe that it is a vast
majority, but accept a goodly proportion may.
84

Some Riders can and do have several apps open at once, including the Deliveroo App, and take jobs as and when
they are offered, from whichever company offers first at the moment they are available. It makes sense at it
maximises the chance of work. In theory it would therefore be possible to accept jobs from different companies at
the same time. In practice however, it is tricky, and risky, for Riders to undertake simultaneous deliveries for
different food delivery companies because the Rider does not know enough information about the order in advance
to know both if doubling up will work logistically (can both orders fit in the box?) and geographically (where are the
different deliveries going?) until after they have accepted to do the delivery. Since delivery times are monitored, and
persistent slow deliveries are a cause of termination, there is a disincentive in doubling up orders for different
companies, when the second delivery could end up being very slow.
85

If a Rider does not undertake at least one delivery for three months, they are taken off the books as a Rider by
Deliveroo and can no longer use the App.
86

The Panel has considered the position as at May 2017 under the New Contract and the position in practice. The
contractual terms under the Earlier Contract, and in practice, were markedly different and involved much more
control and direction by Deliveroo – strict uniform requirements, a different attitude to substitutes and in other,
significant respects. But both the written contractual terms, and how the parties conducted themselves changed and
the parties wanted us to consider the position as at May 2017 and ongoing, what happened previously is of historic
interest only, and little assistance in understanding the current situation.
87
**The parties' submissions**

Both parties submitted extremely comprehensive and helpful written and oral submissions and skeleton arguments.
Rather than attempt a summary we have sought to weave an analysis of their principal points throughout this
decision.
88
**The 'worker' questionThe statute**

A worker is defined in s 296 of the Act as follows:

'(1) In this Act, “worker” means an individual who works, or normally works or seeks to work –

(a) under a contract of employment, or

(b) under any other contract whereby he undertakes to do or perform personally any work or services for
another party to the contract who is not a professional client of his, or

(c) …

(2) In this Act “employer”, in relation to a worker, means a person for whom one or more workers work, or have
worked or normally work or seek to work.'

89

The s 296 definition is subtly different to the definition of a worker under _[Employment Rights Act 1996 s 230(3)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0P0-00000-00&context=1519360)_
which provides that:


-----

'In this Act “worker”… means an individual who has entered into or works under (or, where the employment has
ceased, worked under) –

(a) a contract of employment, or

(b) any other contract, whether express or implied and (if it is express) whether oral or in writing, whereby the
individual undertakes to do or perform personally any work or services for another party to the contract whose
status is not by virtue of the contract that of a client or customer of any profession or business undertaking
carried on by the individual;'

90

The parties were unable to assist with an explanation as to why the definitions were different and why the
legislators had chosen not to follow the TULR(C)A definition when drafting the 1996 Employment Rights Act (ERA).
Both parties initially submitted that the linguistic differences between the two statutes were inconsequential and the
body of case law which has interpreted the 'worker' definition in the ERA are equally applicable to the TULR(C)A
definition. By the end of the hearing they were less confident: between them they had not been able to find any
authority exploring the interplay between the two definitions or analysis of the extent to which it was a distinction
without difference and no case law had been found specific to s 296.
91

It would be odd for there to be a misalignment given the companion nature of the two statutes but one starts with
the principle that words are chosen with care and for good reason. The principles set out in the extensive body of
case law are of general application to the approach to be adopted by the courts and tribunals or panels such as
ours, but it is also to be borne in mind that it is the statute that is to be construed, not the case law.
92

Both parties agreed that the relationship between the Riders and Deliveroo, whatever it was, had contractual force
and was a legally binding agreement. It was also common ground that it was not a contract of employment and limb
(b) of s 296(1) was the only potentially applicable subsection. Deliveroo did not suggest that Deliveroo was a
professional client of the Riders. The central issue between the parties was whether, under the contract, the Riders
undertake to do or perform
**[*92]**

personally any work or services for Deliveroo as another party to the contract. That broke down into two sub issues
– (1) whether there was an obligation to perform work, and (2) personal service. The terms of the contract were not
agreed – Deliveroo contending that there was no legal obligation to work, and no personal service obligation and
the union arguing the contrary.
93
**The terms of the agreementThe law**

It was common ground between the parties that whether a person undertakes personally to perform work or
services depends 'entirely on the contract between them' (Pimlico Plumbers Ltd v Smith _[2017] EWCA Civ 51,_

_[[2017] IRLR 323, para 73) and that 'the essential question in each case is what were the terms of the agreement'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N93-VH01-DYPB-W374-00000-00&context=1519360)_
(Autoclenz v Belcher _[[2011] UKSC 41, [2011] IRLR 820, para 20).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53V7-X6Y1-DYPB-W305-00000-00&context=1519360)_
94

The Supreme Court judgment in Autoclenz v Belcher sets out the proper approach to the construction of contracts
such as here, which relate to work or services as opposed to commercial contracts between parties of equal
bargaining power. The task is to find the true agreement or the actual legal obligations of the parties – not to be
confused with the true intentions or expectations of the parties, but what was agreed. It is for this reason that the
question of whether Deliveroo's true purpose in constructing the contracts as they did was to avoid their Riders
gaining worker status is not relevant, the proper question is what was actually achieved.
95


-----

It is important to spot the difference between form and substance – the oft quoted dicta of Elias LJ in _Kalwak v_
_Consistent Group Ltd_ _[[2007] IRLR 560: 'The concern to which tribunals must be alive is that armies of lawyers will](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4WK-00000-00&context=1519360)_
simply place substitution clauses, or clauses denying any obligations to accept or provide work in employment
contracts, as a matter of form, even where such terms do not being to reflect the real relationship.'
96

It follows that all the relevant evidence has to be examined as set out by Smith LJ [Protectacoat Firthglow Ltd v
_Szilagyi_ _[[2009] EWCA Civ 98, [2009] IRLR 365], as approved and endorsed in Autoclenz [2011] IRLR 820 at 824]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W44S-00000-00&context=1519360)_

'To carry out [the exercise of discovering the actual legal obligations of the parties] the tribunal will have to
examine all the relevant evidence. That will, of course, include the written term itself, read in the context of the
whole agreement. It will also include evidence of how the parties conducted themselves in practice and what
their expectations of each other were. Evidence of how the parties conducted themselves in practice may be so
persuasive that the tribunal can draw an inference that that practice reflects the true obligations of the parties.
But the mere fact that the parties conducted themselves in a particular way does not of itself mean that the
conduct accurately reflects the legal rights and obligations. For example, there could well be a legal right to
provide a substitute worker and the fact that that right was never exercised in practice does not mean that it
was not a genuine right.'

97
**Discussion and conclusions**

The relevant written terms in the New Contract have been set out above, as have the Panel's findings about the
way in which the parties currently conduct themselves in practice.
98

An issue that puzzled the Panel considerably was this: Deliveroo stressed the total flexibility of its Riders' ability to
log in to the App as and when they wished, and ability to pass on offers of a delivery, even when logged on; and
even to abandon the delivery midway by just ringing the service delivery support desk (perhaps by now this can be
done simply via the App without even a phone call). In such circumstances, why would the question of substitution
ever arise? Why would a Rider bother to engage a substitute? And why would Deliveroo spend so much time,
money and energy selecting and training Riders, when the Riders could then sub-contract the right to use the App
willy-nilly? We termed it the substitution conundrum in our deliberations – what would be the point of using a
substitute if you were a Rider and why would you let a Rider do it if you were Deliveroo? Mr Hendy submitted that
the reason why it was perplexing was because there was, in reality, no substitution right and because of the setup
of the App system, substitution provisions would be both unnecessary and undesirable. Deliveroo would also be
unable to have any control over who was delivering the food and whether they were following the high customer
service standards learnt by the Riders in the training videos and on-boarding process. It also made a mockery of
the extensive training given to Riders – why would Deliveroo invest in training its Riders when anyone other than
what Mr Jeans described as 'a very bad egg' would be able to act as a substitute without any objection from
Deliveroo. Why pay for a CRB check for a Rider?
99

Mr Jeans' bland response was that if Deliveroo was willing to invest in training for its Riders, knowing that they
could sub-contract whenever they wanted, then that was up to them. If they were willing to risk their Riders subcontracting to unsuitable types who had not washed their hands in accordance with the training video resulting in
the customers being unhappy with the person on the doorstep, then that was their choice. The Panel's role is not to
judge the good sense or otherwise of the business model. Even if they did it in order to defeat this claim and in
order to prevent the Riders from being classified as workers, then that too was permissible: all that mattered was
the terms of the agreement, analysed in the holistic and realistic way set out in Autoclenz. He of course made no
concession that either proposition was accurate. Deliveroo's purpose in deciding the terms of the agreement (and
there was no question that the Riders had any direct say in the matter) was immaterial – all that mattered was what
the terms actually were.

_[101, 1102](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N13C-00000-00&context=1519360)_


-----

100

The central and insuperable difficulty for the union is that we find that the substitution right to be genuine, in the
sense that Deliveroo have decided in the New Contract that Riders have a right to substitute themselves both
before and after they have accepted a particular job; and we have also heard evidence, that we accepted, of it
being operated in practice. Deliveroo was comfortable with it. We did not find the Deliveroo witnesses to be liars.
One answer to the substitution conundrum was given by Mr Munir when he eventually explained that he was
engaged in sub-contracting for a 15–20% cut.

_[101, 1102](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N13C-00000-00&context=1519360)_
101

In light of our central finding on substitution, it cannot be said that the Riders undertake to do personally any work or
services for another party. It is fatal to the union's claim. If a Rider accepts a particular delivery, their undertaking is
to either do it themselves in accordance with the contractual standard, or get someone else to do it. They can even
abandon the job part way having only to telephone Rider Support to let them know. A Rider will not be penalised by
Deliveroo for not personally doing the delivery her or himself, provided the substitute complies with the contractual
terms that apply to the Rider.

_[101, 1102](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N13C-00000-00&context=1519360)_
102

Some Riders do few and intermittent jobs for Deliveroo
**[*93]**

but many Riders do as much work as possible insofar as they can given any other commitments, and to place
themselves as close as possible to restaurants so they will be offered work by the Deliveroo algorithm and rely on it
as their main source of income. But that is not the applicable test under s 296 of the Act. The delivery has to be
undertaken by a person, however it does not have to be the Rider that personally performs it and Riders are free to
substitute at will. We also appreciate the high level of trust required in the substitute by the Rider – both because
the substitute has to have either the Rider's phone, or Deliveroo passwords to download the Rider's App onto her or
his phone, and because of the contractual commitments borne by the Rider on behalf of her substitute (particularly
in light of Deliveroo's right to end the contract for any reason on one week's notice), which limits the attractiveness
of sub-contracting, coupled with the lack of incentive for doing so. But that does not make the substitution
provisions a sham. The factual situation in this case is very different from, for example, that of Uber private hire
drivers, or Excel or City Sprint.

_[101, 1102](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N13C-00000-00&context=1519360)_
103

It is therefore unnecessary to dissect the other features of the contractual relationship between Deliveroo and its
Riders: they are insufficient to compensate in the union's favour in light of the substitution finding. Nor do the facts
of this case require a more detailed analysis of whether the subtly different wording of s 296 to the worker definition
[in Employment Rights Act 1996 amount to a distinction without a difference. The Panel was concerned about public](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0CH-00000-00&context=1519360)
safety and food hygiene and the way the New Agreement seeks to place all risk and responsibility on the shoulders
of the Riders. The Panel noted the union's extensive submissions on the Food Safety and Hygiene (England)
Regulations 2013, _[SI 2013/2996, the relevant EU provisions and the Health and Safety at Work Act 1974 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5B09-SG41-F16W-C4BD-00000-00&context=1519360)_
associated regulations. Deliveroo did not accept that its hands off approach to overseeing Riders' substitutes
placed Deliveroo at risk of prosecution. But the absence of control and supervision of substitutes and the nondelegable health, safety and food hygiene obligations on Deliveroo, does not mean that the substitution provisions
are not genuine. By allowing an almost unfettered right of substitution, Deliveroo loses visibility, and therefore
assurance over who is delivering services in its name, thereby creating a reputational risk, and potentially a
regulatory risk, but that is a matter for them. The Riders are not workers within the statutory definition of either s 296
[TULR(C)A or s 230(3)(b) Employment Rights Act 1996.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0P0-00000-00&context=1519360)


-----

104

Mr Hendy made a secondary submission pursuant to art 11 ECHR and s 3 Human Rights Act 1996. However on
the specific facts of this case and the unfettered and genuine right of substitution that operates both in the written
contract and in practice, the argument does not succeed. In a less clear cut case the position might have been
different.
105
**Paragraph 36 of the Schedule**

Since we have found that the Riders are not workers, we cannot accept the union's claim for recognition and for
rights to negotiate on pay, hours and holidays with Deliveroo. However in case we are wrong about worker status,
we will briefly consider the remaining admissibility test in issue.
106
**Paragraph 36(1)(a)**

In accordance with para 36(1)(a) of the Schedule the Panel must determine whether members of the union
constitute at least 10% of the workers in the union's proposed bargaining unit. The check of Union membership in
the proposed bargaining unit as conducted by the case manager on 15 May 2017 showed that Union membership
stood at 19.16%. The employer's position was that it challenged whether the density of union membership was as
high as the figure stated in the case manager's report as its own recent survey data showed a number of riders
having indicated that they had recently cancelled, or intended to cancel, their membership. According to the
employer, if these riders were removed from the calculation then membership would drop from the reported 19.16%
to 11% (based on there being only 24 riders in the 213 strong bargaining unit in membership).
107

On either parties' figures – whether the true figure is the 19.16% as established by the case manager or the lower
figure of 11% – both figures are in excess of the 10% threshold necessary to satisfy this test.
108
**Paragraph 36(1)(b)**

The test in para 36(1)(b) is whether a majority of the riders constituting the proposed bargaining unit would be likely
to favour recognition of the union as entitled to conduct collective bargaining on behalf of the bargaining unit.
109

To support its position the union relied on its level of membership, which, as stated above, stood at 19.16% and its
petition which came in both a paper format as well as an on-line version. In his report the case manager established
that 46 riders had signed the paper version and 24 riders 'signed' the web based version. Having adjusted the
figures to take into account those riders that signed both forms a total of 34 members and 23 members signed one
or the other form of the petition in support of union recognition. This equates to a combined total of 26.76%. The
percentage of non-members support as expressed by both forms of the petition was 10.80%.
110
**Summary of the union's submissions on para 36(1)(b)**

Mr Hendy, for the union, reminded us that the test at this stage was whether or not the union could demonstrate
that the majority of workers in the relevant bargaining unit would be likely to favour recognition of the union and that
the CAC was not being asked to assess the level of support currently enjoyed by the union, still less was it asked to
assess the level of support currently proved by the union. On the contrary, the CAC had to answer the hypothetical
question after weighing all the evidence and counter evidence on the balance of probabilities whether, if the matter
were to proceed to a statutory ballot, a majority would be likely to favour recognition.
111

Mr Hendy submitted that it was clear that Deliveroo had embarked on a campaign of misinformation in an attempt to
frustrate the union's application and he pointed to the witness statement of Mags Dewhurst who set out these
attempts in detail, but the position can be summarised thus:
112


-----

Deliveroo had been contacting CKT riders about the union's application before the CAC and wrongly telling them
that if the application for recognition were to succeed, they would lose their ability to work flexibly. Deliveroo was
well aware that the concept of 'flexibility' was prized highly by many Riders and had sought to exploit this by
misinforming the Riders in relation to this key issue
113

It had also misled Riders as to the tax position by informing them that if Riders were found to be workers, then
Deliveroo would need to deduct tax and National Insurance via PAYE. This was not true.
114

During the union's recruitment drive in CKT in November 2016, Deliveroo had instructed CKT riders to work in
Islington rather than CKT. The Riders received text messages and phone calls from managers telling them to work
in Islington, where there would be
**[*94]**

a fee surge which entailed paying the riders in ISL an extra £1 per delivery. This had the purpose and effect of
reducing the number of riders in the Jamestown road area, the very location of the union's recruitment drive.
115

Deliveroo arranged meetings for Riders in CKT to take place at exactly the same time as the union's meeting on 22
February 2017. Deliveroo offered the Riders Amazon vouchers to try and divert as many riders away from the
meeting as possible. Riders were also told they would get vouchers if they signed a petition against the union.
Riders were sent repeated reminders to attend this meeting.
116

The evidence submitted to the CAC by Deliveroo should be treated with caution. The questionnaires relied on were
of no probative value. It was clear from the answers that many of those who filled in the forms did not even
understand the questions. A number of answers were contradictory for example, some said they had never been a
member of the union at the same time as saying they were leaving the union because they were not happy.
117

As regards the confidential untested witness statements, provided by Deliveroo under the cloak of anonymity, these
should be given very little, if any, weight. It was clear that in many cases the content of the statements was based
on a fundamental misunderstanding of the union's position in circumstances where it had not been given formal
access to the workers.
118

The CAC was entitled to infer that Deliveroo had concluded that the union was likely to win a majority unless
underhand tactics were employed by it in order to reduce support for union recognition. The extent of these
underhand tactics were therefore a factor fortifying the union's claim that it would achieve majority support in a
ballot held under statutory conditions, in the run-up to which the riders could be given the true facts. This was
because if the matter were to proceed to a statutory ballot, Deliveroo would be subject to the specific duties under
para 26 of the Schedule, namely; a general duty of co-operation, giving the union access to the riders in the
bargaining unit so as to afford the union a reasonable opportunity to canvass their support and a duty not to inhibit
attendance at union meetings which included refraining from bribing or bullying riders to stay away from a union
access meeting. Deliveroo would also be under a duty to refrain from penalising or threatening to penalise a rider
for having attended or having indicated his intention to attend a union access meeting.
119

The union contended that if Deliveroo complied with its duties, and the union had access to the Riders so that it
could accurately explain its position and the implications of it, then a majority of the riders in CKT would be likely to
favour recognition. In particular it would provide the union with the opportunity to redress the misinformation
regarding flexibility, tax, and the proposed definition of worker.
120


-----

In conclusion, the members of the union constituted at least 10% of the riders constituting the relevant bargaining
unit, and a majority of the riders would be likely to favour recognition of the union as entitled to conduct collective
bargaining on behalf of the bargaining unit.
121
**Summary of the employer's submissions on para 36(1)(b)**

In his submissions Mr Jeans made a number of points that went to the question as to whether or not a majority of
the Riders in the proposed bargaining unit would be likely to support recognition of the union. First, he stated that
the union has underestimated the number of Riders in the CKT zone and the true figure was more than double that
set out in the union's application. According to Deliveroo, even if the CAC were to assume that all challenges and
uncertainties in relation to the petition were resolved in the union's favour, then as few as 57 of 213 riders may have
signed the petition in support of recognition which equated to only 26% of the bargaining unit. However, if the Panel
were to take into account the data put forward by Deliveroo then membership may be as low as 24 of 213 riders –
ie only 11% of the bargaining unit (excluding those riders who had cancelled or were shortly to cancel their
membership); and support for recognition may be as low as only 42 of 213 riders – ie only 19% of the bargaining
unit (excluding those who no longer supported the union's petition). Simply put, the union's position was stark. The
application came nowhere near the admissibility threshold whereby a 'majority' must be 'likely' to favour recognition.
122

Nor was there anything in the broader context which would permit the Panel to infer that majority support was likely
by the time of any ballot. The union had been canvassing for support in CKT since at least August 2016, when it
was instrumental in organising opposition to the move, in CKT and certain other 'zones', from hourly fees to FPD –
that was to say, the union had at least nine months now to generate support. Indeed, it can be seen from the
confidential statements that the union promised to pay riders who joined the union in 2016, at around the time of
such opposition.
123

The evidence was that the union had been vigorous in seeking support, for example Mamun paras 14–15, in which
Mr Mamun explained that union representatives asked him repeatedly to sign the petition, and to become a
member of the union, and had even called his son 'to try to get him to convince me to join'. The evidence of Messrs
Munir, Riaz and Mamun demonstrated a consistent pattern – Riders joined the union, or signed its petition, during
or following the 2016 protests, but had since decided that the flexibility that came with self-employment, and with
the 'fee per delivery' model in CKT, suited them well, or that the union did not really understand their business and
way of working, and had withdrawn support. That pattern was likely to be replicated more widely. There was
certainly nothing to suggest any uptake in support. As to the evidence, Mr Jeans took the Panel to the statements of
Messrs Munir and Riaz. The Panel did not consider that the five further confidential statements exhibited by Mr
Scott were of sufficient weight to be reliable and they have therefore been disregarded.
124

Deliveroo's own survey data was consistent with that pattern. The survey was described at Mr Scott in his
statement. As appeared from the responses provided to the CAC:

(i)   seven riders had told the union that they wished to cancel their membership;

(ii)   a further 11 riders had indicated that they intended to do so; and

(iii)   no fewer than 16 riders had indicated that they signed the union's petition but had since changed
their minds and no longer support recognition.

125

Looking at the picture in the round, therefore, there was no sensible or realistic prospect of majority support for
recognition. The reality was that only a very small proportion of Riders presently supported the application and
support was falling, within CKT, rather than rising.
126


-----

Deliveroo was concerned, moreover, that some Riders who had signed the petition had done so without
understanding what 'worker status' (as a precondition to recognition) would entail. The feedback that
**[*95]**

Mr Scott had received from Riders suggested that the union had painted a misleading picture about the implications
of 'worker status'. The union was, of course, fully entitled to make clear the potential benefits to Riders if they were
found to be 'workers'. It was wrong to suggest to Riders, however, that there would be no change to the existing
operating model if they were 'workers' rather than self-employed. To the contrary, as a matter of operational reality,
it would be impossible (for example) to maintain complete flexibility as to whether, and when, Riders accepted
orders, and whether, and how, they used substitutes, if Deliveroo were required to engage riders as 'workers'.
Similarly, it would be impossible to permit Riders to carry out deliveries for other companies at the same time as
being marked 'available' for deliveries for Deliveroo. Significant changes would be necessary to the present 'FPD'
model and to the present contractual terms.
127

Ms Dewhurst's concerns that Deliveroo had deliberately impeded the union's efforts to garner support were
unfounded, as Mr Scott and Ms Clancy made clear. Deliveroo believed that its Riders were self-employed. It
certainly had not sought to prevent Riders meeting with the union. To the contrary, it had been at pains to
emphasise that it was a matter for each individual whether to join the union, sign petitions or similar. Deliveroo
regularly implemented fee surges and provided suggestions to Riders as to which areas were busy, and it regularly
offered Amazon vouchers or other benefits when asking Riders to give up time for meetings. It was not therefore
very striking that such events coincided with one or two events organised by the union. There was no basis
whatsoever for any suggestion that Deliveroo had prevented union access to Riders in advance of this application.
128

But even if Ms Dewhurst's evidence were to be taken at face value, and even if the Panel were to assume for the
purposes of argument that Deliveroo had implemented a fee surge in Islington in November 2016 and had held a
meeting in February 2017 at the same time as a planned Union activity, the fact remained that the union had had at
least some nine months to persuade Riders to become members and/or to support recognition. After such a lengthy
and vigorous campaign, it was unrealistic to suggest that two single events, in November 2016 and on a single day
in February 2017, could explain the massive shortfall in support.
129

The union did not meet the admissibility criterion in para 36(1)(b) as it could not show that 'a majority of the workers
constituting the relevant bargaining unit would be likely to favour recognition'.
130
**Discussion and conclusions on para 36**

The union has established that it has 10% of the proposed bargaining unit in membership, and approximately one
third of the workers in the bargaining unit have demonstrated their support by means of signing either an online or
paper petition or by being paid up members of the union. We accept that opinions can change over time, and a few
individuals (such as Deliveroo's witnesses at our hearing) either signed the petition and then changed their mind, or
signed the petition whilst not agreeing with what they were ostensibly giving their name too. There will always be a
degree of ebb and flow as issues are debated, as facts and arguments are discussed – it is a sign of healthy
debate.
131

The union has been able to demonstrate considerable and consistent levels of support over the unfortunately long
period of this case, notwithstanding Deliveroo's opposition to the union's claim, and notwithstanding the difficulties
of organising and contacting other Riders and the individual nature of the work – being a one person cycle delivery
rider is, by definition, a solitary activity. There are clearly concerns about the precarious nature of the work and the
wider debate around the gig economy. From all the information before us, if the Riders had been workers within the
meaning of s 296 of the Act, we would have found that a majority of the Riders in the proposed bargaining unit
would support the union's bid for collective bargaining on pay, hours and holiday. From the industrial relations


-----

expertise of the Panel for which we were appointed to the CAC, we infer that the support and membership levels
demonstrate an appetite and interest in collective bargaining beyond those who have made themselves visible.
Many individuals supportive of a union choose not to show their hand when an Employer is known to oppose
recognition. Some prefer not to join a union until after recognition rights have been obtained, and some prefer never
to join, but are content with the achievements of the union on behalf of the collective group.
132

It is also readily understandable that workers who do not support a union where an employer opposes recognition,
will be comfortable and energetic in making their views known and participating vigorously in employer organised
surveys and petitions. Highly visible minorities on either side may not speak for the whole group, but it is harder for
those in support of recognition to speak out than those opposed. In a case such as this where worker status is in
[issue it is especially so, since the scope of protection afforded to workers in the Employment Rights Act 1996 from](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0CH-00000-00&context=1519360)
retaliatory action and being subjected to a detriment for involvement in a recognition campaign is unclear. We also
bear in mind that here a Rider's contract may be terminated for any reason on one week's written notice.
133

In considering all the evidence and circumstances of this case, we conclude that the declared support of
recognition, and sustained significant membership levels, point to an underlying likely majority support within the
proposed bargaining unit and the union has thus met both threshold tests in para 36.
134
**Decision**

Accordingly, the decision of the Panel is that the union's application is not accepted since the Riders are not
workers within the meaning of s 296 TULR(C)A, but in all other respects the acceptance tests have been met by the
union.

12

**Appendix**

Names of those who attended the hearing over the 23, 24 and 25 May and 26 June 2017:

For the union:
John Hendy QC – Counsel

Katharine Newton – Counsel

Annie Powell – Solicitor, Leigh Day

Jason Moyer-Lee – General Secretary, IWGB

Billy Shannon – Witness

Mags Dewhurst – Witness

**[*96]**

For Deliveroo:
Chris Jeans QC – Counsel

Amy Rogers – Counsel

Colin Leckey – Solicitor, Lewis Silkin

David Hopper – Solicitor, Lewis Silkin

Catherine Hayes – Solicitor, Lewis Silkin

Carla Davidson – Solicitor, Lewis Silkin

Jessica Cox – Trainee Solicitor, Lewis Silkin

1 The terminology is that used on the standard form a respondent to an application is required to complete.

2 The term has been used to reflect the statutory wording of the Act and the Schedule, and in this context does not represent
fi di i l i f h P l h i


-----

Jack Baldwin – Trainee Solicitor, Lewis Silkin

Sam Harper – General Counsel, Deliveroo

Tarun Tawakley – Solicitor, Deliveroo

David Scott – Operations Director, UK & Ireland, Deliveroo (witness)

Charlotte Clancy – User Research Lead, Deliveroo (witness)

Khee Lim – Operations Strategy Associate, Deliveroo

Asim Munir – Supplier of delivery services to Deliveroo (Witness)

Farrukh Riaz – Supplier of delivery services to Deliveroo (Witness)

Mamunur Rashid Mamun – Supplier of delivery services to Deliveroo (Witness)

**End of Document**


-----

