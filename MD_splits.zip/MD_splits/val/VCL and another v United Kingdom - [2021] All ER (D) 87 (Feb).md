# VCL and another v United Kingdom [2021] All ER (D) 87 (Feb)

European Court of Human Rights

European

Judges Grozev (President), Eicke, Motoc, Harutyunyan, Vilanova and Schukking

12 January 2021

**Human rights – Right not to be required to perform forced or compulsory labour – Breach**
Abstract

_The applicant Vietnamese nationals had both been recognised as victims of trafficking by the designated competent_
_authority in the UK, for criminal offences connected to their work as gardeners in cannabis factories. They_
_successfully lodged complaints in the European Court of Human Rights, alleging that their rights not to be required_
_to perform forced or compulsory labour had been violated, in breach of art 4(1) of the European Convention of_
_Human Rights. They further alleged that their rights to a fair trial had been breached, in breach of art 6(1) of that_
_Convention. In allowing their complaints, the European Court of Human Rights held, among other things, that the_
_state could not be said to have fulfilled its duty under art 4 of the Convention to take operational measures to_
_protect the applicants, either initially, as potential victims of trafficking, and subsequently, as persons recognised by_
_the competent authority to be a victim of trafficking._
Digest

The judgment is available at: App. Nos. 77587/12 and 74603/12

**Background**

On 1 April 2009, to coincide with the coming into force of the Council of Europe Convention on Action Against

Trafficking in Human Beings 2005 (the Anti‑Trafficking Convention), the UK government created the National

Referral Mechanism (the NRM) to provide the framework for identifying and referring potential victims of modern
**_slavery and ensuring they received the appropriate support. To be referred to the NRM, potential victims of_**
trafficking should first be referred to one of the UK's two competent authorities, namely the United Kingdom Human
Trafficking Centre (within the National Crime Agency), and the Home Office, which were responsible for making
conclusive decisions on whether a person had been trafficked for the purpose of exploitation. The competent
authorities first made a 'reasonable grounds' decision. The threshold for that decision was 'I suspect but cannot
prove', and a positive decision triggered a 45-day recovery and reflection period. Following that period, the same
competent authority should make a 'conclusive grounds' decision for which the threshold was a 'balance of
probabilities', namely, that 'it is more likely than not' that the person had been trafficked.

Prior to the coming into force of the relevant provisions of the Slavery Act 2015 (SLA 2015), there had been no
statutory provision in the UK which transposed into domestic law the state's obligations under international
conventions towards those victims of human trafficking who had committed crimes where there was a nexus
between the crime and the trafficking. Consequently, in cases where the defence of duress was not likely to be
applicable, it was left to the judiciary and to the Crown/CPS to develop a legal regime in which the state's
international obligations were given effect.


-----

The present applications concerned the prosecution of the (then) minor applicants (VCL and AN, respectively).
They were both Vietnamese nationals and had both been recognised as victims of trafficking by the designated
competent authority, for criminal offences connected to their work as gardeners in cannabis factories.

In the case of VCL, in 2009, following his plea of guilty to the production of a Class B drug, he was sentenced to 20
months' detention in a young offenders' institution. He sought permission to appeal out of time against conviction
and sentencing. He argued that he should have been advised to vacate his plea and an application to stay the
proceedings should have been made because he was a credible victim of trafficking and, as such, should not have
been prosecuted. He also complained that there was no appropriate adult present when he decided not to change
his plea, and that the CPS had failed to confirm why it was in the public interest to prosecute. In the case of AN, in
2009, following his plea of guilty to being concerned in the production of a Class B drug, he was sentenced to an 18
month detention and training order. In his perfected grounds of appeal against conviction he argued, among other
things, that his conviction was unsafe because as a minor and victim of trafficking and forced labour contrary to art
4 of the Anti-Trafficking Convention, he had been entitled to protection rather than prosecution. In particular, he
argued that the CPS should have carried out a much greater investigation into whether he had been trafficked into
the UK and exploited in a cannabis factory.

Permission was granted in both cases and the appeal were joined. The Court of Appeal, Criminal Division, identified
the principal issue in the appeals to be whether the process of the court was abused by the decision of the
prosecuting authority to prosecute. However, having fully considered the facts of the applicants' cases, in a
judgment handed down in February 2012, the court dismissed their appeal against conviction. The Court allowed
VCL's appeal against sentencing as it found that, given his age and guilty plea, a 12-month custodial sentence
would have been sufficient. In view of AN's young age, his guilty plea and the extremely short period he was
working in the cannabis factory, the court indicated that it should have reduced his sentence to a four-month
detention and training order. Both applicants unsuccessfully applied for leave to appeal to the Supreme Court.

In November 2012, VCL and AN, respectively, lodged complaints before the European Court of Human Rights (the
Court). They both complained that the UK was in breach of art 4 of the European Convention on Human Rights (the
Human Rights Convention) which provided that: '1. No one shall be held in slavery or servitude. 2. No one shall be
required to perform forced or compulsory labour.' Their principal complaint was that by prosecuting them for
criminal offences connected to their work in the cannabis factories the UK had failed in its duty to protect them as
victims of trafficking. Having regard to the similar subject matter of the applications, the Court decided that it was
appropriate to examine them jointly in a single judgment. The applicants further complained that as a result of the
state's breach of its positive obligation under art 4 they had been denied a fair trial within the meaning of art 6 of the
Human Rights Convention.

In 2013, VCL sought a review of his conviction based on new evidence and new legal arguments. In 2016, the
Criminal Cases Review Commission (the CCRC) decided to refer VCL's case back to the Court of Appeal. His
appeal was heard together with five other appeals in which convicted defendants argued that they should not have
been prosecuted as there was a nexus between their crimes and their status as victims of trafficking. In VCL's case,
in its judgment of February 2017, the Court of Appeal was satisfied that his criminality or culpability had not been
extinguished or significantly reduced to such a level that he should not have been prosecuted in the public interest.
VCL failed in his application to the Court of Appeal for a certificate that points of law of general public importance
were involved in that judgment which ought to be considered by the Supreme Court.

**Issues and decisions**

(1) Whether the applicants could claim to be 'victims' of the alleged violation.

The applicants submitted that that they had been recognised as credible victims of trafficking by the competent
authority. Further, that finding did not deprive them of their victim status because the state's positive obligation went
beyond a duty to recognise them as victims of trafficking.

In both cases, a positive obligation to take operational measures to protect the applicants as potential victims of
trafficking had arisen shortly after they were discovered Further in view of the fact that the potential scope of that


-----

obligation extended beyond their identification as victims of trafficking, neither applicant had been deprived of his
'victim status' within the meaning of art 34 of the Human Rights Convention by the decision of the competent
authority. Accordingly, it fell to be determined whether, in all the circumstances of each applicant's case, the state
had fulfilled its duty under art 4 of the Human Rights Convention to take operational measures to protect him (see

[121], [122] of the Convention).

It was well-established that both national and transnational trafficking in human beings, irrespective of whether or
not it was connected with organised crime, fell within the scope of art 4 of the Convention. Further, the member
states' positive obligations under art 4 of the Convention should be construed in light of the Anti-Trafficking
Convention and be seen as requiring not only prevention but also victim protection and investigation. The general
framework of positive obligations under art 4 included: (1) the duty to put in place a legislative and administrative
framework to prohibit and punish trafficking; (2) the duty, in certain circumstances, to take operational measures to
protect victims, or potential victims, of trafficking; and (3) a procedural obligation to investigate situations of potential
trafficking. In general, the first two aspects of the positive obligations could be denoted as substantive, whereas the
third aspect designated the states' (positive) procedural obligation (see [148], [150], [156] of the judgment).

To date, the Court had not had the opportunity to consider a case concerning the prosecution of a victim, or
potential victim, of trafficking. Consequently, the present case was the first occasion on which the Court had been
called upon to consider if and when such a prosecution could raise an issue under art 4 of the Convention (see

[157] of the judgment).

It was clear that no general prohibition on the prosecution of victims of trafficking could be construed from the AntiTrafficking Convention or any other international instrument. Nevertheless, the prosecution of victims, or potential
victims, of trafficking could, in certain circumstances, be at odds with the state's duty to take operational measures
to protect them where they were aware, or ought to be aware, of circumstances giving rise to a credible suspicion
that an individual had been trafficked. The duty to take operational measures under art 4 of the Human Rights
Convention had two principal aims: to protect the victim of trafficking from further harm; and to facilitate his or her
recovery. It was axiomatic that the prosecution of victims of trafficking would be injurious to their physical,
psychological and social recovery and could potentially leave them vulnerable to being re-trafficked in future. Not
only would they have to go through the ordeal of a criminal prosecution, but a criminal conviction could create an
obstacle to their subsequent integration into society. Further, incarceration could impede their access to the support
and services that were envisaged by the Anti-Trafficking Convention (see [157]-[159] of the judgment).

In order for the prosecution of a victim or potential victim of trafficking to demonstrate respect for the freedoms
guaranteed by art 4, his or her early identification was of paramount importance. It followed that, as soon as the
authorities were aware, or ought to be aware, of circumstances giving rise to a credible suspicion that an individual
suspected of having committed a criminal offence might have been trafficked or exploited, he or she should be
assessed promptly by individuals trained and qualified to deal with victims of trafficking. Once a trafficking
assessment had been made by a qualified person, any subsequent prosecutorial decision would have to take that
assessment into account. While the prosecutor might not be bound by the findings made in the course of such a
trafficking assessment, the prosecutor would need to have clear reasons which were consistent with the definition
of trafficking contained in the Palermo Protocol and the Anti-Trafficking Convention for disagreeing with it (see

[160], [162] of the judgment).

In the case of VCL, despite having been discovered in circumstances which themselves had given rise to a credible
suspicion that he had been a victim of trafficking, his case had not been referred to the NRM. Instead, he had been
charged with a criminal offence to which he had pleaded guilty on the advice of his legal representative. Even
though he had subsequently been recognised by the competent authority as a victim of trafficking, the CPS, without
providing adequate reasons for its decision, had disagreed with that assessment and the Court of Appeal, relying
on the same inadequate reasons, had twice found that the decision to prosecute him had been justified.
Accordingly, the state could not be said to have fulfilled its duty under art 4 of the Human Rights Convention to take
operational measures to protect VCL, either initially, as a potential victim of trafficking, and subsequently, as a
person recognised by the competent authority to be the victim of trafficking. It followed that there had been a
violation of art 4 of the Human Rights Convention (see [172]-[174] of the judgment).


-----

In the case of AN, from the point when he had been discovered, certain aspects of his account should have raised
concerns that he might have been a victim of trafficking. Those concerns should only have intensified when it had
become apparent that he was a minor. From that point on, the state had had a positive obligation to take
operational measures to protect him. Instead, the criminal proceedings were allowed to proceed, with AN entering a
guilty plea on the advice of his legal representative. Even though he had subsequently been recognised as a victim
of trafficking, the CPS had disagreed with that assessment without providing clear reasons for its decision which
went to the core of the elements necessary to establish 'trafficking', and the Court of Appeal, relying on the same
reasons, had found that the decision to prosecute was not an abuse of process. Accordingly, the state could not be
said to have fulfilled its duty under art 4 of the Human Rights Convention to take operational measures to protect
AN, either initially, as a potential victim of trafficking, and subsequently, as a person recognised by the competent
authority to be a victim of trafficking. It followed that there had been a violation of art 4 of the Human Rights
Convention (see [181]-[183] of the judgment).

_Siliadin v France (Application 73316/01) 20 BHRC 654 [2005] ECHR 73316/01 43 EHRR 287 considered;_ _R v O_

_[[2008] EWCA Crim 2835 (2008) Times, 2 October [2008] All ER (D) 07 (Sep) considered; Rantsev v Cyprus and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_
_[Russia (Application 25965/04) 28 BHRC 313 [2010] ECHR 25965/04 51 EHRR 1 considered; R v LM](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_ _[2010] EWCA_
_Crim 2327 [2011] Crim LR 425 [2011] 1 Cr App Rep 135_ _[[2010] All ER (D) 202 (Oct) considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_ _R v L_ _[2013]_
_EWCA Crim 991_ _[[2014] 1 All ER 113 [2014] Crim LR 150](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_ _[[2013] All ER (D) 216 (Jun) [2013] 2 Cr App Rep 247](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58RB-D6B1-DYBP-N1KF-00000-00&context=1519360)_
considered; National Union of Rail, Maritime and Transport Workers v United Kingdom (Application No 31045/10)
60 EHRR 199 37 BHRC 145 [2014] ECHR 31045/10 _[[2014] All ER (D) 101 (Jun) considered; S.M. v Croatia (App.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CDN-3C11-DYBP-N1YR-00000-00&context=1519360)_
_No. 60561/14)_ _[[2020] ECHR 60561/14 49 BHRC 1 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60B2-3B93-CGXG-045Y-00000-00&context=1519360)_

(2) Whether there had been a violation of art 6(1) of the Human Rights Convention.

The failure to investigate whether the applicants had been the victims of trafficking before they had been charged
and convicted of drugs-related offences raised an issue under art 6 of the Human rights convention. It had already
been found that the authorities' failure to conduct a timely assessment of whether the applicants had in fact been
trafficked amounted to a breach of their positive obligations under art 4 of the Human Rights Convention. In the
context of art 6 of that Convention, the lack of such an assessment prevented them from securing evidence which
might have constituted a fundamental aspect of their defence. Further, the applicants could not be considered to
have waived their rights under art 6(1) (see [200] of the judgment).

As the Court had found on numerous occasions, compliance with the requirements of a fair trial had be examined in
each case having regard to the development of the proceedings as a whole and not on the basis of an isolated
consideration of one particular aspect or one particular incident, although it could not be ruled out that a specific
factor could be so decisive as to enable the fairness of the trial to be assessed at an earlier stage in the
proceedings (see [205] of the judgment).

In the present case, even though the applicants had pleaded guilty to the offences charged, the CPS had
nevertheless reviewed its decision to prosecute them after the competent authority had recognised them as victims
of trafficking. In addition, they were both subsequently been granted permission to appeal out of time and the first
applicant's case had been referred back to the Court of Appeal by the CCRC for a further appeal. However, the
appeal proceedings did not cure the defects in the proceedings which had led to the applicants' charging and
eventual conviction. Consequently, in respect of both applicants, the proceedings as a whole could not be
considered 'fair'. It followed that there had been a violation of art 6(1) of the Human Rights Convention (see [208]
[210] of the judgment).

The applicants would be awarded the sum of €25,000 in respect of non-pecuniary damage, plus any tax that might
be chargeable (see [219] of the judgment).

_Salduz v Turkey (Application no 36391/02) 26 BHRC 223_ _[[2008] ECHR 36391/02 considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2SV-00000-00&context=1519360)_ _Dvorski v Croatia_
_(App no 25703/11) 40 BHRC 659 considered;_ _Beuze v Belgium (Application No 71409/10) 47 BHRC 147 [2019]_
Crim LR 233 69 EHRR 1 considered.


-----

**End of Document**


-----

