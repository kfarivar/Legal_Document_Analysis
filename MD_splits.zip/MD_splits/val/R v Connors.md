# R v Connors [2019] EWCA Crim 2029

Court of Appeal, Criminal Division

Thirlwall LJ, Yip J, and HHJ Sloan

31 October 2019Judgment

**Mr G Jones QC for the Appellant**

**The Crown was not represented**

- - - - - - - - - - - - - - - - - - - - 
If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**Approved Judgment**

**LADY JUSTICE THIRLWALL DBE:**

1. There are reporting restrictions. An order was made in the Crown Court pursuant to section 46 of the
Youth Justice and Criminal Evidence Act 1999 in respect of both victims of the offences to which we will
turn in a moment. Those orders remain in force for the lifetime of the two victims of the offences with which
we are concerned and of the other victim.

2. On 24th May 2016, after a trial, Patrick Joseph Connors, who is now 62, was convicted and sentenced
as follows:Counts 1-6: offences of assault occasioning actual bodily harm, contrary to section 47 of the
Offences against the Person Act 1861, 18 months' imprisonment on each count to run concurrently. .Count
7, conspiracy to kidnap, contrary to section 1(1) of the Criminal Law Act 1977, seven years' imprisonment,
concurrentCount 8, another offence of assault occasioning actual bodily harm, two years' imprisonment
also to run concurrently. The victim of all those offences was Michael Hughes.

3. The next group of offences which follow were all against K. The applicant was convicted and sentenced
as follows:Counts 10, 11, and 13 of three offences of kidnap and sentenced to four years' imprisonment
concurrent; Count 12, another assault occasioning actual bodily harm, two years' imprisonment concurrent;
Count 14, another offence of kidnapping, six years' imprisonment concurrent; count 15, requiring another to
perform forced or compulsory labour, contrary to section 71(1)(b) of the Coroners and Justice Act 2009,
seven years consecutive, making a total sentence of 14 years' imprisonment.

4. We deal briefly with the point that a victim surcharge order was imposed in error in the sum of £120. we
quash the surcharge.

5. The applicant was ordered to pay £7,500 compensation to each of the victims.


-----

6. There were three co-accused: Patrick Dean Connors, who was the applicant's son, was convicted on
counts 10 and 15, sentenced to a total of six and a half years' imprisonment; William Connors, his brother,
was convicted on count 15 and was sentenced to four years' imprisonment; and Lee Christopher Carbis,
his brother in law, was convicted of kidnapping and sentenced to 30 months' imprisonment.

7. This is a renewed application for permission to appeal combined with an application for an extension of
time in which to lodge the application for permission to appeal. We have been assisted this morning by Mr
Jones QC who did not appear below.

8. The extension of time sought is one of 958 days. We shall turn to that having considered the merits of
the appeal generally.

9. The facts are set out in detail in the Court of Appeal summary:

"Between 1990 and 2015 the applicant committed a number of offences against the two victims, Michael
Hughes and K. The applicant was the head of a family business that carried out general building work and
tarmacking work on driveways. He would target vulnerable customers and charge them grossly inflated
prices. He was also involved in purchasing and renovating property. Patrick Dean Connors was his son,
Lee Carbis his son in law, and William Connors his nephew.

For a number of years Michael Hughes and K worked for the applicant under very poor conditions. If they
failed to carry out works as directed they would be beaten or threatened. They performed heavy manual
labour over long hours often through the day and then into the evening at the applicant's own properties.
For many years they were paid with alcohol and tobacco or very small amounts of money. The men were
kept in sub-standard living conditions that often did not have running water or heating facilities. They
would be forced to work when ill or injured and were old that no one would miss them if they were killed.
Whey they attempted to escape they were hunted down and forced to return.

When made subject to a Trading Standards Investigation the applicant passed the manual side of the
business over to the other three defendants but remained in overall control. By them Hughes had been
under the applicant's control for over 20 years.

Offences against Michael Hughes (Counts 1-8 and 15)

Michael Hughes was born in 1970. When he was 18 he moved from Scotland to Cardiff where he stayed
in a shelter. Initially Hughes found work with a man named Johnny Wall. He was then 'passed on' to
Michael and Daniel Doran who in turn gave him to the applicant. Hughes worked at the applicant's home,
Fieldview bungalow. He was provided a wooden shed to sleep in and had to wash outside using a cold tap
and bucket. He would be sent to carry out tarmacking work and would be beaten if it was not completed to
the applicant's satisfaction. The beatings carried out by the applicant became a feature over the years
Hughes spent under his control. Counts 1 - were specimen counts of assault occasioning actual bodily
harm committed by the applicant against Hughes between 1990 and 2012.

In 1992 Hughes was arrested for a driving offence. He was then transported to Scotland where he spent a
few days in custody due to unpaid fines. Upon his release he was collected by the applicant and taken
back to Wales. Hughes continued to live in the shed until he was permitted to move into a garage.
Hughes eventually built himself an eight-foot by six-foot work shad to live in. Hughes began a relationship
with a woman named Rachel Harvey who became pregnant. The applicant told Harvey's mother that
Hughes was a drug and alcohol user and that Harvey should have an abortion, something she later did.

Counts 7 and 8 (Conspiracy to kidnap and assault occasioning actual bodily harm)

In the middle of one night Hughes ran away and hiked back to Scotland. A few months later he went to
claim benefits in Aberdeen where he encountered the applicant and Patrick Dean Connors, along with
another male. He was forced into their car and driven back to Wales. Hughes was then taken to the
garage at Fieldview bungalow and beaten by the applicant. He was made to resume working the same
long hours and was assaulted if work was not of the desired standard. It was around this time that Hughes
became aware of K and saw how the applicant also treated him.


-----

After years of living in those conditions, and as a result of the control successfully asserted over him,
Hughes was permitted some independence. He was allowed to have a relationship with a woman named
Sandra Boalch. He was permitted to live with Boalch and allowed to go on holiday with her. At around the
same time the applicant began to take a smaller role in the family business. The applicant passed Hughes
onto the other defendants to undertake work for them as instructed, albeit subject to the applicant's
permission. Count 15, requiring another person to perform forced or compulsory labour, represented the
period between 6 April 2010 and 31 January 2013 where Hughes was forced to work.

Offences against K (Counts 10-14)

K was born in 1974 and suffered from retinitis pigmentosa, a degenerative eye condition that leads to
tunnel vision and blindness. In 1995/1996 K was homeless in Cardiff when introduced to the applicant who
offered him food and work. The proffered accommodation was a concrete shed next to the applicant's
home at Fieldview bungalow. K was immediately put to work, usually tarmacking, paving or slabbing, often
from dawn until 23.00. The price for the work was agreed verbally between the applicant and the customer
with the price being variously inflated depending on the customer's vulnerability. He worked with Hughes
after Hughes returned from Aberdeen. They were also expected to undertake work on the applicant's
property. When they failed in their tasks they were assaulted.

Approximately two years later the applicant moved to a farm in Peterstone. The house was derelict and K
was put to work renovating it. Both he and Hughes lived at the farm while it had no running water. After
the farmhouse was demolished both men moved into a caravan with no heating, no gas, no running water
and no toilet. At around the same time the applicant told K and Hughes that they were going to go on
'holiday'. In reality they were taken to carry out work on mobile homes in a caravan park in Carmarthen
under the applicant's direction. While there K was made to sleep on a concrete floor in a 6 foot by 6 foot
shed. While using machinery K crushed his hand but was made to continue working without a splint.

Count 10 (Kidnapping)

K attempted to escape numerous times. The first time K travelled to Llanrymney, located a few miles
away, where he hid at a friend's flat. A few days later K travelled to Cardiff by bus with the intention of
claiming benefits. On route back he was seen by the applicant and Patrick Dean Connors who chased him
down and took him back.

Counts 11 and 12 (Kidnapping and assault occasioning actual bodily harm

The second time K attempted to escape he went to Bristol to a fellow worker known as 'Bristol Mike's'
home. The applicant, with another relative, went and collected K. On the way back K was threatened as
to what punishment he might receive for running away. The following day K was taken to see a male
named Michael Siddorick, who had a reputation for violence. K was told that if he ever attempted to flee
again Siddorick would be set loose on him. later that night the applicant assaulted K, knowing that K would
be unable to see in the dark due to his eye condition.

Count 13 (Kidnapping)

The third time K left in the early hours of the morning and travelled to Pontypridd. He intended to look for
work but was found by the applicant, Patrick Dean Connors and another relative. K was forced into their
car and threatened with violence. K was told that no one would miss him when he was gone.

Count 14 (Kidnapping)

In 2000 K, with the assistance of others, successfully managed to escape and left the area for
approximately 6 months. In 2001 he returned to see some friends but was discovered by the applicant and
Carbis in Trowbridge. They forced him into a car but he fled the vehicle as it was moving and jumped in
front of a passing bus, forcing it to stop and allow him on. K described what happened to the bus driver
and the matter was reported to police although no investigation followed.

In 2013 K contacted Gwent Police to report the offending after having seen media coverage of a Gwent
Police modern day slavery operation.


-----

Hughes was spoken to by police in December 2013 where he made disclosures about the offending
committed against him.

The applicant was interviewed by police on a number of occasions. He denied committing any offences
against K or Hughes."

10. There were before the court statements from Mr Hughes and from K.

11. The sentencing judge had a been the trial judge and was in a good position to assess the overall
criminality in this case.

12. The submissions were made in detail in writing and then developed a little before us this morning. The
[principal point is this: had the Coroners and Justice Act 2009 (the Act) been in force during the period of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95G0-Y97X-70VH-00000-00&context=1519360)
this offending, a single count under section 71(1) would probably have been preferred and would have
reflected all the criminality. And, so the argument runs, the maximum sentence would have been one of 14
years' imprisonment. If further follows, Mr Jones submits, that a sentence of 14 years' imprisonment for all
of these offences in this case is plainly manifestly excessive.

13. We disagree. First, the Act was not in force for the period of most of the offending; second, even if it
had been, a single count under section 71(1) would come nowhere near properly reflecting the criminality
here both in terms of the conduct, the length of time over which it was pursued which was the best part of
two decades and the number of victims. That approach had the Prosecution taken it would have
significantly understated the extent of the criminality and would have hampered the ability of the judge
properly to sentence for all of the offences and the overall harm and culpability. As a minimum, one would
have expected on the facts here, had they occurred post the coming into force of the Act, separate counts
in respect of each victim with a maximum sentence available to the court of 14 years in respect of each. In
the event, the judge imposed a number of concurrent sentences and then a seven-year consecutive
sentence in relation to the Modern Slavery Act count.

14. The aim of the new provisions was not to reduce the consequences of this sort of conduct but to
ensure that it was easier to prosecute it with appropriate punishment to follow conviction, the submissions
in support of this application go to precisely the opposite effect. In our judgment they are misconceived
and unarguable. It is incumbent on the prosecutors to choose the offences of the type which best reflect
the whole of the criminality. That was the approach taken here and would have been the approach under
the Act.

15. We were referred to a decision in **Attorney General's Reference (nos 2-4 of 2013) R v William**
**Connors and others [2013] EWCA Crim 324. The hearing took place in 2012. A sentence of six and a**
half years was not considered to be unduly lenient. Some of the facts are very similar to the facts in this
case but there is a fundamental difference. The conduct for which sentence was there passed took place
over a period of a year. Previous conduct was part of the background but there were no charges in respect
of it. This case is quite different as we have already described.

16. The judge was entitled and indeed bound in our judgment to sentence for all of the conduct reflecting
the culpability of the applicant and the harm he had done over such a long period of time. The sentencing
remarks are measured, thoughtful and impressive. He plainly considered every aspect of the exploitation
that had taken place in this case and had had the opportunity to assess during the trial. We see no basis
upon which it could properly be argued that the sentences were wrong in principle or manifestly excessive.

17. We turn to the question of the prolonged extension of time that is required. After the single judge had
noted that there was no real explanation for the delay other than that the solicitors had been instructed
relatively recently, a witness statement was produced by Mr Panesar who currently acts for the applicant.
It goes no further than to confirm that the current firm was not instructed until 2019. That does not explain
delay of three years between sentence and the filing of the appeal. Had there been some merit in the
grounds of appeal, we would have considered extending time but, in the event, there was no merit in any of
the grounds.

18. The applications are dismissed.


-----

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

