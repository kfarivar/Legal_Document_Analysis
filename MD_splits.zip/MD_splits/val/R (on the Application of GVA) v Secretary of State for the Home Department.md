# R (on the Application of GVA) v Secretary of State for the Home Department

 [2023] EWHC 2838 (Admin)

King's Bench Division (Administrative Court)

Lang J

24 October 2023Judgment

MR S GALLIVER-ANDREW (instructed by Duncan Lewis Solicitors) appeared on behalf of the Claimant.

MR J FLETCHER (instructed by Government Legal Department) appeared on behalf of the Defendant.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

(Transcript prepared without access to documents)

MRS JUSTICE LANG:

1 This is the claimant's application for interim relief, namely a mandatory order for release from
immigration detention. Alternatively, he seeks a grant of immigration bail.

2 On 26 September 2023 the claimant filed a claim for judicial review in which he challenged the
defendant's decision, dated 12 September 2023, that there were no reasonable grounds to conclude that
he was a victim of modern slavery. The claimant also challenged the lawfulness of his detention.

3 On 3 October 2023, Eyre J ordered that the application for interim relief should be listed for hearing. He
observed that there appeared to be considerable force in the submissions made by the defendant, so the
case for interim relief was not such that relief could be granted on the papers, and the claimant was entitled
to an oral hearing in any event.

4 The interim relief application filed with the claim form sought an order for the claimant's release and
disclosure of documents. However, in the claimant's skeleton argument, not filed until 19 October 2023, he
also seeks provision of accommodation re-referral into the National Referral Mechanism (“NRM”) for a
reasonable grounds decision, and a needs and risk assessment under the **_Modern Slavery Victim Care_**
Contract in advance of release from detention.

5 The principles governing the grant of interim relief in judicial review proceedings are those contained in
_American Cyanamid Company v Ethicon Ltd [1975] AC 396, modified as appropriate to public law cases._
First, the claimant must demonstrate that there is a serious question to be tried. In judicial review claims
this involves considering whether there is a real prospect of the claim succeeding at the substantive


-----

hearing. See _R (Medical Justice) v Secretary of State for the Home Department_ _[[2010] EWHC 1425](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
_[(Admin), per Cranston J at [6] and the Administrative Court Judicial Review Guide 2023 [16.6.1]. This is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
generally thought to be a higher threshold than the “arguable” test applied when deciding whether to grant
permission for judicial review.

6 Secondly, the court should consider whether the balance of convenience lies in favour of granting or
refusing the interlocutory relief that is sought. At para.16.6.1 of the Judicial Review Guide it states:

“This involves balancing the harm to the claimant that would be caused if interim relief is not granted and
the claim later succeeds against the harm that would be caused to the defendant, any third party and the
public interest if interim relief is granted and the claim subsequently fails.”

7 At the beginning of the hearing both counsel agreed with my suggestion that it would be an efficient use
of the court's time to treat this as an oral permission hearing because the merits of the claim have to be
considered as part of the application for interim relief. Both counsel confirmed that they were content to
proceed to deal with permission today and would not be prejudiced by doing so.

Facts

8 The claimant is an Albanian national, born on 5 February 1991. He entered the UK illegally on an
unknown date in 2012 or 2013. On 2 March 2022 he was arrested on suspicion of possession of Class A
drugs with intent to supply. On 10 March 2022 he was remanded in custody. In his interview, he stated
that in October 2021 he made an application for leave to remain as the unmarried partner of a British
national with whom he has a child (date of birth 16 June 2020). As far as I am aware no application for
leave to remain has never been processed. He and his child's mother live separately. Counsel conceded at
this hearing that he did not have a genuine subsisting relationship with the child. The GCID note dated 10
March 2022 raises doubts that he has a genuine relationship with the mother of his child, suggesting it
appears to be a relationship of convenience.

9 On 22 April 2022, the claimant was convicted, at the Crown Court at Northampton, of one count of
possession with intent to supply Class A drugs, and sentenced to a custodial sentence of two years 10
months. HHJ Mayo's sentencing remarks were as follows.

“... I am assuming that you have no difficulty following the English language having been here for a long
time and having worked hard. I have to sentence you for your dealing in Class A drugs. It was stopped by
you driving a car uninsured; drugs were found in it. There were probably 200 grams altogether of cocaine;
two wraps found in one part of the car, 60 wraps in another, together with 156 grams of cocaine, and
further cocaine, a machete, scales and cash found at your ex-girlfriend's address. You gave 'no comment'
replies but you now plead on the basis that you had been persuaded to top up your income in the UK by
selling drugs around the Rushden area.

I therefore put your role as significant but only just, because you were not just a slave going round
supplying drugs for others. You had both deals with you and also a supply from which deals could be
made up, together with scales. So there was a level of sophistication in your actions. That provides for
category 3, which is street trading, a starting point after a trial of four and a half years with a category range
of 3 years and 6 months. In my judgment, the starting point here for you before giving you credit for your
guilty plea, because of your good character, and because of positive things I have heard about you, would
be one of 46 months imprisonment.

I give you one-quarter credit for your pleas of guilty. That takes it down by 11 and a half months, but I will
round that up to 12. So, the sentence is 36 months or three years. You will serve up to half of that in
custody. For the remainder you will nominally be on licence but because you are now a foreign criminal,
as defined in the Immigration Act, you will be deported at the end of your sentence....”

10 The records show that the sentence of three years was altered to 2 years 10 months, i.e. 34 months,
not 36 months. His sentence expiry date is 3 January 2025 and his conditional release date was 4 August
2023.


-----

11 On 2 October 2022 the claimant made a claim for asylum. On 4 October 2022 he was seen in prison
and advised about NRM referral. On 6 October 2022 he was interviewed and completed an NRM form.

12 On 8 October 2022 the defendant notified the claimant of her decision to deport him to Albania as he
fell within the definition of a foreign criminal in s.32(1) of the UK Borders Act 2007, and none of the
exceptions to deportation applied in his case. He was informed that there was no right of appeal under
s.82 of the National Immigration & Asylum Act 2002 (“NIAA”). He was served with a one-stop notice (s.120
NIAA 2002) requiring him to inform the defendant of any reason he might have for remaining in the UK.

13 GCID notes indicate he was seen in prison on 10 October 2022 and stated that he did not wish to be
deported and wanted to claim asylum. On 12 October 2022 he had an asylum screening interview. On 12
October 2022 he made representations as to why he should not be deported.

14 On 12 October 2022 a negative reasonable grounds decision was issued by the Immigration
Enforcement Competent Authority (“IECA”). It was accepted that Part A, Action, was met as he had been
recruited, and Part B was met because he was threatened with being shot if he said anything. He was
found to have been broadly consistent and there were no significant credibility concerns. However, it was
not accepted that part C, Purpose, was met.

15 The decision stated:

“Purpose – part C.

“In applying part 'C' consideration must be given to whether you were
recruited/transported/transferred/harboured/received for the purpose of exploitation ...

You said you started working in February 2022 with other people. You were arrested by police in March
2022. The police found a large quantity of drugs at your location which were valued around £20,000.

You have provided no information regarding the terms of your employment in the UK, nor have you
provided any evidence to suggest that you were forced to carry out any type of work or provide any service
against your will, or if you were under any menace of penalty, and there is no evidence that there was an
intention to subject you to any form of exploitation.

It is therefore considered that you were not subjected to forced labour/forced criminality/domestic
servitude/sexual exploitation/organ harvesting/other, nor was there an intention to subject you to this. ...
As you do not meet the three constituent elements of trafficking above, it is also considered that you do not
meet the two constituent parts of the definition of slavery, servitude and forced or compulsory labour.”

16 On 9 November 2022 his Offender Assessment System (“OASys”) report set out the background facts
to the offence. It noted that he had significant employment and financial problems as he had no right to
work or claim benefits and so was reliant on illegal working. He was a drug user. His risk of reoffending
was considered to be low.

17 On 17 November 2022 the claimant attended an asylum interview. The date of 8 January 2023 is
recorded as his asylum claim application date in immigration history records. The claimant's reasons for
not being deported, which he gave to the defendant, were treated as an asylum claim.

18 On 1 December 2022 the Offender Management Unit reviewed the claimant's prison categorisation.
His behaviour in prison was found to be generally good, but a move to open conditions for the remainder of
his custodial sentence was refused because of the deportation proceedings.

19 On 24 July 2023, Form IS91 Detention Authority was issued on the basis of the notice of decision to
make a deportation order. On 30 July 2023 family separation was authorised. It was found that there were
no compelling compassionate factors in line with the duty under s.55 Borders Act 2009. Given the serious
nature of his offending and likely absconding risk, any impact on Article 8 ECHR rights was likely to be
proportionate.

20 On 31 July 2023 an initial detention review took place. Detention was considered in line with the
criteria in “Detention: general instructions” and Hardial Singh principles, the Adults at Risk policy and the


-----

presumption to release. On the issue of removability, it was noted that he held a valid passport and had
made an asylum claim which would likely take 3 to 6 months to determine. There were no claimed medical
issues. He was assessed as a medium risk of absconding based on his criminal and immigration history.
He was fully aware of the intention to deport. There was no legal basis to remain and therefore he was
likely to abscond. The low risk of harm and reoffending was consistent with the OASys report. His son was
taken into account under compassionate circumstances. The authorising officer agreed with the
recommendation of detention, but stated that if the asylum process was prolonged and removal was not
possible within a reasonable timeframe, release on condition should be considered.

21 On 4 August 2023 the claimant was detained at Yarls Wood IRC. His medical reports noted he was fit
and well. On 5 August 2023 a seven-day detention review took place. On 6 August 2023 the claimant
wrote to the defendant requesting an interview and explaining that he wished to remain in the UK as a legal
resident to support his son and watch him grow up. He confirmed that he wished to continue with his
asylum claim.

22 On 10 August 2023 the claimant's current solicitors, who are immigration specialists, were instructed by
the claimant. On 11 August 2023 he had an induction interview. On 21 August 2023 written submissions
were received from the claimant's solicitors requesting referral into the NRM. The solicitors also sent a
subject access request for the claimant's file and a preliminary letter from Ms Elizabeth Flint, a trafficking
expert, who stated she found indicators of exploitation in his case and signed that he met three parts of the
Trafficking Convention. She was not able to produce evidence, however, until the end of October 2023.

23 On 23 August 2023 a decision letter under s.72 of the NIAA 2002 was issued (it was not served until 27
September). The letter stated:

“On 8 January 2023 you stated you have a fear of returning to Albania. This has been treated as an
asylum claim. Section 72(2) of the Nationality Immigration and Asylum Act 2002 states that,

'A person shall be presumed to have been convicted of a final judgment of a particularly serious crime and
to constitute a danger to the community of the United Kingdom if –

(a) he is convicted in the United Kingdom of an offence; and

(b) sentenced to a period of imprisonment of at least two years.'

You have been convicted in the United Kingdom of an offence and sentenced to a period of imprisonment
of at least 2 years...

Article 33(2) of the 1951 United Nations Convention on the Status of Refugees states that a refugee cannot
claim the benefit of Article 33(1) where there are reasonable grounds for regarding him as a danger to the
security of the country in which he is or who having been convicted by a final judgment of a particularly
serious crime constitutes a danger to the community of the protecting state.

Section 72 of the Nationality Immigration and Asylum Act 2002 applies for the purpose of the construction
and application of Article 33(2) of the Refugee Convention (Exclusion from Protection).  The consequence
of s.72 to a person is that their claim for asylum will be refused. Their refusal is on the basis they do not
qualify for a grant of asylum under paragraph 334 of the Immigration Rules. The presumption that they
pose a danger to the community of the United Kingdom means that they cannot satisfy sub-para.334(iv).
Article 33(2) of the Refugee Convention applies to them and as a result the Refugee Convention does not
prevent removal from the United Kingdom.

You may seek to rebut the presumption under s.72 that you have been convicted of a particularly serious
crime and that you constitute a danger to the community. If you wish to rebut the presumption, you must
do so in writing within 20 working days of the date of service given at the end of this letter. After that time,
a decision about whether s.72 applies will be taken on the basis of all available information...”

24 On 25 August 2023, the claimant attended the surgery at the detention centre for a rule 35
assessment.  The notes state that he wished to discuss his mental health. He was missing his family. He


-----

had not seen them for a long time. His mood was low. He was not sleeping well. He was prescribed
antidepressants and he was to be reviewed in four weeks. He denied any thoughts of self-harm or suicide.

25 On 26 August 2023. a rule 35 report was submitted to the defendant stating that the claimant may be a
victim of torture. The doctor set out the claimant's account of modern day slavery. No physical injuries
were recorded (the claimant contends that an injury to his knee sustained when he was allegedly trafficked
in 2021 was not observed by the doctor). The report went on to state:

“Mental scars. Patient has been feeling low and anxious. Seen in the IRC. He has been started on
antidepressants today and referred to our mental health team. Denies any thoughts of self-harm or
suicidal thoughts... I believe this patient could be a victim of torture. His story is consistent with his mental
scars. He is currently stable in detention with regards to his physical and mental health. However, he may
deteriorate.

26 The defendant responded on 29 August 2023 stating:

“Your claim of torture has been considered in line with the guidance set out in the Detention Services Order
09/2016, as well as the Adult at Risk policy.

...

In relation to your claim of torture, your account as set out in the report does not meet the above definition
as there is no evidence that you were subjected to severe pain or suffering and the account does not
convey a situation in which you were powerless to resist as a result of control. As a result, you would not
meet the Adults at Risk in Immigration Detention policy on this basis.

Consideration has also been given to other known vulnerabilities in your case which fall under the policy.
The additional medical evidence engages Level 2 of the same policy based on the mental health concerns
raised which are being managed within the centre.

**Balancing risk-factors against immigration control factors**

Detention should be used as a last resort and for the shortest possible timescale in order to facilitate
removal or deportation from the UK.

...

It is noted that you raised a modern slavery claim for which you received a negative Reasonable Grounds
decision on 12 October 2022. It is further noted that you raised an asylum claim for which a substantive
asylum interview has already taken place. You have been served with a s.72 notice for which you have
three weeks to respond and a decision can be expected on your asylum claim within approximately six to
eight weeks thereafter. Should your claim be refused, a decision will be made on whether your deportation
remains appropriate, and if the decision is made to deport you, a deportation order will be signed against
you. In that instance, your removal can take place on your valid passport within approximately 12 to 16
weeks.

You have been assessed as being a medium risk of absconding, a high risk of harm and a medium risk of
reoffending. This is due to the nature of your offence and the effect of this on the wider community. You
received a 2 year 10 month term of imprisonment for possession with intent to supply cocaine, suggesting
that you are a current protection concern, given that you present a significant risk to others in the
community. As such, although assessed at Level 2 of the AAR policy following your Rule 35(3)
assessment, detention can be maintained in line with the appropriate guidance and policy based on your
public protection risk and the significant custodial sentence that you have received.

It is noted that you claim to have a partner living in the UK. However, it is considered that your claimed
partner would not be able to ensure that you would remain in one place or report to immigration if released.
As such, there is reason to believe that if removal directions are set, you would be highly unlikely to
surrender for departure.


-----

The medical practitioner has stated within the Rule 35(3) report that you have been feeling low and anxious
since your arrival at the IRC. You are presently stable in detention with regards to your physical and
mental health. However, you may deteriorate. It is noted that you have begun taking antidepressants and
have been referred to the mental health team and as such it is considered that appropriate measures are
currently in place to support you.

As your removal can take place within a reasonable timeframe on conclusion of your asylum claim and on
service of a deportation order, it is considered that appropriate close monitoring and support could
commence during this period to safeguard your vulnerabilities within detention whilst awaiting a decision on
your deportation.

Whilst it is acknowledged that there is a presumption of liberty, when considering the factors it is concluded
that ongoing detention is appropriate to progress your case towards deportation in light of the public
protection concern amid your criminal conviction for possession with intent to supply a controlled drug of
Class A – Cocaine. Whilst it is acknowledged that there is a presumption of liberty, it is considered that the
current immigration factors outweigh the vulnerabilities in your circumstances meaning that the risks
associated with your release are enough to justify your ongoing detention. As a result of this, a decision
has been made to maintain your detention at this time.”

27 On 29 August 2023 an ad hoc detention review was undertaken. The rule 35 report and response was
considered and the current time estimate for decision to be made on his asylum claim. It was concluded
that detention was necessary and proportionate to effect removal.

28 On 30 August 2023 the claimant's solicitors sent a pre-action letter identifying grounds of challenge and
requesting that the defendant disclose information in documents, make a referral to the NRM and release
him from detention.

29 On 31 August 2023 the claimant was discharged from the mental health team on a “watch and wait”
basis. He remained on antidepressants and he was advised that he could self-refer back to the mental
health team if more support was needed.

30 On 1 September 2023 a 28-day detention review took place. It was considered in line with the criteria
in Detention: General Instructions, “Hardial Singh” principles, Adults at Risk Policy and Presumption to
Release. He had been assessed at Level 2 of the Adults at Risk Policy following a Rule 35 report where
the defendant decided to maintain detention. He was assessed as a high risk of absconding based on
criminal and immigration history. He was fully aware of the intention to deport. No legal basis to remain,
and therefore likely to abscond. It was considered that deportation would not be achieved without the use
of continued detention. Low risk of harm and re-offending consistent with the OASys report. It was noted
that he had no legitimate means of support in the UK and so his risks may increase upon release. A
response to the s.72 letter was expected before the next review and a decision could be taken then.
Removal was currently expected to take place within 6 months, depending on the progress and outcome of
his asylum claim.

31 On 1 September 2023 the defendant sent a monthly progress report to the claimant setting out the
history and reminding him of the facilitated return scheme which is a voluntary scheme providing him with
assistance and a financial incentive to return and settle in Albania. His detention was reviewed and the
defendant had concluded that he should remain in detention because he was likely to abscond if granted
immigration bail based on his previous offending and immigration history.

32 On 11 September 2023 the defendant agreed to reconsider the earlier negative Reasonable Grounds
decision under the NRM. On 12 September 2023 the defendant made a fresh negative Reasonable
Grounds decision. This is the decision identified in s.3 of the claim form as the subject of this challenge,
and so I will consider it in more detail at a later stage in my judgment.

33 On 12 September 2023 the defendant responded to the claimant's pre-action letter. On 20 September
2023 the claimant sent a further pre-action letter. The defendant sought a seven- day extension of time to
respond.


-----

34 On 26 September, the claimant issued and served his claim for judicial review, seeking urgent
consideration, interim relief and disclosure. On 26 September 2023, Johnson J ordered the defendant to
provide a written response to the application for interim relief, and either disclose the documents sought or
explain why disclosure was not appropriate.

35 On 27 September 2023 the s.72 letter, dated 23 August was served on the claimant. On 29 September
2023 a detention and case progression review took place. Continued detention was recommended
because of his conviction and pending deportation and a high risk of absconding. The outstanding barriers
to his removal were identified as any response he may make to the s.72 letter, his asylum claim and a
stage 2 decision and deportation order. The authorising officer said:

“I have spent time weighing up his current circumstances against presumption to release, including the
high risk of absconding and the likely timescale to removal. In light of his past evasion of immigration
control, I am not satisfied that the [claimant] would abide with any release restrictions imposed or remain in
contact with the Home Office. By means of passport or (letter) he can be documented for removal. I am
satisfied that his outstanding applications could be resolved quickly and potentially with no further right of
appeal. I consider 'there is a realistic prospect of removal within a reasonable timescale'.”

36 On 29 September 2023 the defendant sent a monthly progress report to the claimant stating that his
detention had been reviewed and was to continue because he was likely to abscond if granted immigration
bail.

37 On 29 September 2023 the defendant served her response to the interim relief application as ordered
by the court and disclosed the documents sought by the claimant.

38 On 6 October 2023 the claimant's solicitors notified the defendant that the presumption in the s.72
notice would be disputed, once the disclosed documents had been considered.

39 On 16 October 2023 the claimant applied for a reconsideration of the negative Reasonable Grounds
decision made on 12 September 2023. On 18 October 2023 the claimant applied for asylum support and
accommodation pursuant to s.95 of the Immigration and Asylum Act 1999.

**Grounds for judicial review**

**_Ground 1 – modern slavery_**

40 Under ground 1, the claimant submits that the defendant's negative Reasonable Grounds decision
dated 12 October 2023 is defective and that the defendant has failed to discharge her positive obligation to
identify and protect the claimant as a potential victim of modern slavery.

[41 The Modern Slavery Act 2015 and the defendant's statutory guidance were introduced to give effect to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
the UK's obligations under the Council of Europe Convention on Action against Trafficking in Human
Beings (ECAT). The NRM is the UK's framework for identifying and supporting victims of modern slavery.
The statutory guidance states in its introduction that **_modern slavery is a serious crime that violates_**
human rights. Chapter 2 explains that it encompasses human trafficking and slavery, servitude and forced
or compulsory labour.

42 Following a referral to the NRM a “Reasonable Grounds decision” will be made. It is described in the
glossary of the statutory guidance as a decision taken by the competent authorities as to whether the
decision-maker agrees there are reasonable grounds to believe, based on all available general and
specific evidence, but falling short of conclusive proof, that a person is a victim of modern slavery (human
trafficking or slavery, servitude or forced or compulsory labour.). Three parts or components must be
present for a positive finding in an adult trafficking case. The first part is “Action”. That is recruitment,
transportation, transfer, harbouring or receipt, which includes an element of movement, whether national or
cross-border, which is achieved by the second part, “Means”. That is a threat or use of force, coercion,
abduction, fraud, deception, abuse of power or vulnerability, which is for the Purpose of the third part,
which is exploitation, such as sexual exploitation, forced labour or domestic servitude, slavery, financial
exploitation.


-----

43 Where a positive Reasonable Grounds decision is made, a person will be eligible for support, including
accommodation and financial support.

44 The next stage is a conclusive grounds decision which the glossary describes as “a decision taken by a
competent authority as to whether on the balance of probabilities there are sufficient grounds to decide that
the individual being considered is a victim of modern slavery.”

45 Article 4 of the European Convention on Human Rights provides:

“1. No-one should be held in slavery or servitude;

“2. No-one shall be required to perform forced or compulsory labour.”

46 Article 4 is an unqualified right and the United Kingdom has positive obligations to protect and support
victims.

47 In a decision dated 12 September 2023 the decision-maker appointed by the IECA concluded:

“We have assessed your case and have decided there are not currently reasonable grounds to conclude
you are a victim of modern slavery.”

48 Due to the inconsistencies in the claimant's accounts of events given on different occasions his
credibility was damaged, his claim to have been trafficked could not be believed and was rejected.

49 The decision referred to the following matters:

“Our reasons for this decision are as follows: Competent authority guidance on credibility is contained in
the attached Decision Annex. For the reasons outlined below your account of events is not accepted.

“Firstly, you state within your NRM referral (RF) dated 06.20.22 and your full asylum interview (AIR) dated
17.11.22 that in 2021 when Covid started you were looking for a job as a painter and decorator. A friend of
yours provided you with a contact number of someone who could offer you a job. You phoned the number
and spoke to a man called Alex who offered you a job in Northampton. The first time you met him in prison
he told you that before you can start work as a painter/decorator you would have to sell and deliver drugs
for him. He showed you that he had a gun and told you that if you refused, then he would kill you. You
were scared and felt you had no choice, so you started to deliver drugs for Alex in February of 2022. You
did this for around six weeks until you were arrested by police on 04.03.22. It is important to note,
however, that there is an inconsistency with the timeframes relating to how long you have worked for Alex.
As mentioned above, you state in your RF and your AIR that you sold drugs for about six weeks starting in
February 2022, yet within the rule 35 report (R35) submitted on 24.08.23 and the expert witness letter
(EWL) dated 18.08.2023 you claim that you first made contact with Alex in 2021 and when you started
selling drugs for him you did this for around three months. You also claim that you received no payment
for any of the work you carried out for Alex within your referral form (RF). However, in the expert witness
letter submitted it states that you received a one-off payment of £500.

Furthermore, the information provided within the NRM referral is inconsistent with information provided
within the Judge's Sentencing Remarks (JSR) made at Northampton Crown Court on 22.04.2022. Within
this document the judge states that after being stopped by the police, driving an uninsured car which had
drugs in it, you plead guilty on the basis that you were persuaded by Alex to sell drugs for him to help top
up your own income, therefore meaning that you did this for economic necessity. The judge also stated:

'Your role was significant but only just because you were not just a slave going round supplying drugs for
others. You had both deals with you and also supply from which deals could be made up, together with
scales. So there was a level of sophistication in your actions. That provides for Category 3 which is street
trading.'

This statement contrasts with what you claim within your RF that you were forced at gun point to become
involved with the drug dealing. The information provided in the JSR ultimately casts doubt on the
information provided within the RF, the EWL and also the R35 as the Judge concluded that you played a


-----

significant part in the operation and you were not just a slave who was following orders or being threatened
at gun point to do so.

Lastly, you state within your asylum screening (SCR) dated 12.10.2022 that you have never been
subjected to any type of exploitation (2.5). This is inconsistent with the information provided with your
referral form.  Particular consideration has been given to the Judge's Sentencing Remarks (JSR) which
has significantly damaged the credibility of your account. It is considered the judge's findings are reliable,
held to the highest standard of proof and are therefore not disputed by the IECA. It is considered that you
have provided inconsistencies which call into question your credibility to the point where your account
cannot be believed.

Consideration has been given as to whether there are any mitigating circumstances in relation to your
account.

Consideration has been given to the Rule 35 report (R35) dated 25.08.2023 when considering your mental
health and how this may impact upon the decision. It is important to note that we have taken into
consideration the views of the expert within this report. Their findings conclude that you have been feeling
low and anxious. You also state within your detention induction record (DET) that you are suffering from
stress. However, the author has provided a response in relation to the consistency of physical and/or
mental symptoms with the applicant's given account as a possible victim of torture or abuse. Yet, they
have not provided a response in relation to the consistency of physical and/or mental symptoms with the
applicant's given account as a potential victim of **_modern slavery. Therefore, this is not considered_**
specific evidence for the purpose of NRM decision-making. Due to the inconsistencies in your account,
your credibility has been damaged to the extent that your claim to have been trafficked cannot be believed
and is rejected.”

50 The decision-maker then proceeded to consider the three-part analysis: Action, Means and Purpose
(Parts A, B and C) and under each head concluded that the claimant's account was rejected in its entirety,
and therefore it was not accepted that each or any part was met.

51 In his pleaded case, the claimant complains that the defendant prioritised the decision as it was
completed only one day after the defendant sent the letter undertaking to reconsider it. He submits that
rushed decision-making adversely affected the quality of the decision.

52 In my view, this allegation is unarguable. Paragraph 7.6 of the guidance indicates that a decision
should be made swiftly, i.e. within five working days of referral. The claimant expressly applied for a swift
decision. The claimant's solicitor's draft order required the defendant to reconsider the NRM decision
within five working days. Importantly, it does not follow that, because the decision was made swiftly, the
decision maker did not give the task due consideration and anxious scrutiny.

53 The claimant submits that the decision is defective because the decision-maker did not obtain material
records, e.g. detention centre induction records, GCID records and medical records in advance of the
decision being made. In my view, there is no substance to this allegation. Page one of the decision lists
the records that the decision-maker says she considered. These were the Judge's Sentencing Remarks,
NRM referral form, asylum screening, full asylum interview, detention induction record, expert witness
letter, Rule 35 report and Home Office records. Home Office records would normally include GCID and
Atlas records. Relevant medical information was in the \rule 35 report. These documents were clearly
sufficient and, contrary to the claimant's oral submission, the expert witness letter was expressly
considered by the decision-maker.

54 The claimant submits that the inconsistencies could be a result of the claimant's trauma having
impaired his recollection. However, there is no evidence to support that in this particular case. The
claimant suggests the decision-maker failed to consider the statutory guidance on this issue. He did not
specify which part of the guidance in his written submissions. Annex D gives guidance on working with
vulnerable people including mental health and psychological indicators. At the hearing, the claimant
particularly relied on the following paragraphs in Annex D: 13.10 - reluctant to self-identify; 13.18 - barriers
to disclosure, including impact of trauma; and 13.19 to 13.24 - difficulty recalling facts.


-----

55 In my view, the decision-maker who has received training and who has prior experience would be likely
to be aware of the entirety of the statutory guidance, including Annex D. Generally, I accept the
defendant's submission that it is clear from the wording and structure of the decision that the statutory
guidance was taken into account in relation to the decision as a whole.

56 The claimant contends that the inconsistencies in his account should not affect his credibility, but
Annex E of the guidance at paras.14.3 to 14.7 makes clear that when considering a reasonable grounds
decision, decision-makers can take into account credibility.  At paras.14.8 and 14.9 the guidance indicates
that in assessing credibility it is generally unnecessary to focus on minor or peripheral facts that are not
material to the claim and that the competent authority should assess the material facts asking whether they
are coherent and consistent, how well the evidence fits together, or whether there are contradictions, and
whether claims are consistent with any documentary evidence.

57 In this case the length of time the claimant was working for Alex and whether he was paid for his work
were material factors in assessing the credibility of the claimant's claim to be a potential victim of modern
**_slavery because they went to the heart of the claimant's claim where there was no other witness evidence_**
or contemporaneous documentary evidence to support the claimant's case.

58 The claimant criticises the decision-maker's assessment of the evidence. He submits that the finding of
inconsistencies with timeframes does not acknowledge that the material date straddled the New Year in
2021/22, and that the claimant was consistent about recruitment taking place in 2021. The one-off
payment for his expenses was consistent with his account of receiving a one-off payment of £500 referred
to in the account he gave to the trafficking expert, Ms Flint. In my view, the claimant's disagreement with
the decision-maker's assessment of details of the evidence does not disclose any arguable public law
error, nor raise a serious question to be tried.

59 The claimant contends that the Sentencing Remarks support his claim that he was forced to work at
gunpoint. I agree with the defendant's submission that this is not the case. The Sentencing Remarks
indicate that the claimant was operating with a degree of autonomy as the decision to deal drugs was
entered into for financial reasons to supplement the claimant's income. Furthermore, the presence of
drugs both on his person and at the ex-girlfriend's premises, together with drug paraphernalia showed a
level of sophistication that meant he was not just “a slave going around delivering drugs” but was rather
someone who was able to put drug deals together. Therefore, the Remarks do undermine the claimant's
claim that he was forced to work.

60 The claimant complains that too much emphasis was placed in the decision on the fact that the
claimant was street dealing and the decision does not reflect that street dealing is always a category 3
offence; the starting point is not based on quantity; the claimant only just fell into the “significant role”
category; and his sentence was at the bottom of the category range. I consider that this reading of the
decision is unarguable. Wherever the Sentencing Guidelines place the claimant, the Judge's remarks
indicated that he was satisfied that the claimant's action showed autonomy and sophistication. The
decision-maker was entitled to place weight on the Judge's remarks as reliable and supported by evidence.

61 The claimant points out that when the claimant was sentenced there was no basis of plea, no statutory
defence relied on under s.45 of the **_Modern Slavery Act 2015 and no NRM referral from the CPS._**
However, the claimant was legally represented at his trial by different solicitors, and he pleaded guilty on
legal advice. It can safely be assumed that his defence solicitor and counsel would have been aware of
[the Modern Slavery Act 2015,and he would not have been advised to plead guilty if they thought that he](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
had a good defence.

62 In his oral submissions the claimant relied upon the findings in the previous decision. Although that
decision was in some respects more favourable to the claimant, essentially the overall conclusion was the
same as in this one, namely, that there was no evidence that he was exploited or subjected to forced
labour. In any event the decision of 12 September 2023 was a fresh decision by a different decisionmaker, as requested.


-----

63 In my judgment, the claimant has not succeeded in identifying an arguable error of law in the decision.
I do not agree with the submission made orally that the decision-maker applied too high a test. In my view,
the decision-maker followed the guidance, set out the circumstances fully, assessed the evidence and
made a reasonable decision on the evidence before her. It follows that this ground of challenge is
unarguable and there is no real prospect of ground 1 succeeding at a substantive hearing.

**_Ground 2 – detention_**

64 The claimant submits that his detention has at all times been unlawful.

65 The claimant is subject to automatic deportation pursuant to s.32(5) of the UK Borders Act 2007
because he was sentenced to a period of imprisonment of 34 months. On 8 October 2022 the defendant
gave notice of a decision to deport the claimant.

66 Once the custodial element of the claimant's prison sentence was completed, his immigration detention
was authorised pursuant to paragraph 2(2) of Schedule 3 to the Immigration Act 1971 pending his
deportation.

67 In order to be lawful, immigration detention must accord with the limitations implied by the common law
and by Article 5 ECHR. At common law the power to detain is subject to the limitations set out in _R_
_(Hardial Singh) v Governor of Durham Prison [1983] EWHC 1 (QB), [1984] 1 WLR 704. In_ _R (I) v_
_Secretary of State for the Home Department_ _[2002] EWCA Civ 888, Dyson LJ described the Hardial Singh_
principles in the following terms, which the Supreme Court approved in R (Lumba) v Secretary of State for
_the Home Department_ _[2011] UKSC 12, [2011] 2 WLR 671._

“46. There is no dispute as to the principles that fall to be applied in the present case. They were stated by
Woolf J in _Re Hardial Singh [1984] 1 WLR 704, 706D in the passage quoted by Simon Brown LJ at_
paragraph 9 above. This statement was approved by Lord Browne-Wilkinson in Tan Te Lam v Tai A Chau
Detention Centre [1997] AC 97, 111A-D in the passage quoted by Simon Brown LJ at paragraph 12 above.
In my judgment, Mr Robb correctly submitted that the following four principles emerge:

i) The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose;

ii) The deportee may only be detained for a period that is reasonable in all the circumstances;

iii) If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not be
able to effect deportation within that reasonable period, he should not seek to exercise the power of
detention;

iv) The Secretary of State should act with the reasonable diligence and expedition to effect removal.

47. Principles (ii) and (iii) are conceptually distinct. Principle (ii) is that the Secretary of State may not
lawfully detain a person 'pending removal' for longer than a reasonable period. Once a reasonable period
has expired, the detained person must be released. But there may be circumstances where, although a
reasonable period has not yet expired, it becomes clear that the Secretary of State will not be able to
deport the detained person within a reasonable period. In that event, principle (iii) applies. Thus, once it
becomes apparent that the Secretary of State will not be able to effect the deportation within a reasonable
period, the detention becomes unlawful even if the reasonable period has not yet expired.

48. It is not possible or desirable to produce an exhaustive list of all the circumstances that are or may be
relevant to the question of how long it is reasonable for the Secretary of State to detain a person pending
deportation pursuant to paragraph 2(3) of schedule 3 to the Immigration Act 1971. But in my view they
include at least: the length of the period of detention; the nature of the obstacles which stand in the path of
the Secretary of State preventing a deportation; the diligence, speed and effectiveness of the steps taken
by the Secretary of State to surmount such obstacles; the conditions in which the detained person is being
kept; the effect of detention on him and his family; the risk that if he is released from detention he will
abscond; and the danger that, if released, he will commit criminal offences.”


-----

68 Lord Justice Dyson emphasised at [121] in _Lumba that when considering whether detention is_
appropriate, the risk of absconding will be of paramount importance.

69 The importance of the risk of absconding was also underlying in Fardous v Secretary of State for the
_Home Department [2015] EWCA 931 Civ where the Lord Chief Justice held:_

“44. It is self-evident that the risk of absconding is of critical and paramount importance in the assessment
of the lawfulness of the detention. That is because if a person absconds it will defeat the primary purpose
for which Parliament conferred the power to detain and for which the detention order was made in the
particular case. This has been made clear in a number of cases: see for example paragraph 54 of the
judgment of Keene LJ in R (A) v Secretary of State for the Home Department _[2007] EWCA Civ 804 and_
the judgment of Lord Dyson in Lumba at paragraph 121.

45. Although the risk of absconding will therefore always be of paramount importance, a very careful
assessment of that risk must be made in each case, as the magnitude of that risk will vary according to the
circumstances. It may be very great, for example, where the person has, as in this case, a clear track
record of dishonesty and a knowledge of how to 'work' the controls imposed to regulate immigration in the
European Union. Another example where the risk may be high is where the person refuses voluntary
repatriation that is immediately available to him. It is important to emphasise that the risk of absconding is
distinct from the risk of committing further offences and not dependent on that further risk. The risk of reoffending requires its own distinct assessment.

46. However, as is accepted on behalf of the Secretary of State, the risk of absconding cannot justify
detention of any length, as that would sanction indefinite detention. It is therefore not a factor that invariably
'trumps' other factors, particularly the length of detention. It is nonetheless a factor that can, depending on
the circumstances, be a factor of the highest or paramount importance that may justify a very long period of
detention.

70 Whilst according deference to the defendant's expertise and knowledge, the court has held that it is the
judge of reasonableness when applying the Hardial Singh principles and the usual Wednesbury principles
do not apply. See R (A) v Secretary of State for the Home Department _[2007] EWCA Civ 804._

71 The law appears to have changed somewhat upon the coming into force of s.12 of the Illegal Migration
Act 2023 on 28 September 2023, which amends the statutory detention provisions. The changes are not
retrospective. In a deportation case where detention is authorised under para.2 of Schedule 3 to the
Immigration Act 1971 it provides:

“(2) In paragraph 2 of Schedule 3 to the Immigration Act 1971 (detention or control pending deportation)—

(a) after sub-paragraph (3) insert—”

“(3A) A person liable to be detained under sub-paragraph (1), (2) or (3) may be detained for such period
as, in the opinion of the Secretary of State, is reasonably necessary to enable the deportation order to be
made, or the removal to be carried out.

(3B) Sub-paragraphs (1) to (3) apply regardless of whether there is anything that for the time being
prevents the deportation order from being made or the removal from being carried out.

(3C) [is not relevant here]

(3D) Sub-paragraph (3E) applies if, while a person is detained under sub-paragraph (1), (2) or (3), the
Secretary of State no longer considers that the deportation order will be made or the removal will be
carried out within a reasonable period of time.

(3E) The person may be detained under that sub-paragraph for such further period as, in the opinion of the
Secretary of State, is reasonably necessary to enable such arrangements to be made for the person's
release as the Secretary of State considers to be appropriate.”

72 Similar amendments are made to s.62 of the NIAA (detention) by the Secretary of State and s.36 of the
[UK Borders Act 2007 (detention relating to deportation). The explanatory notes to the Illegal Migration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)


-----

_[2023 state, at para.101, that s.12 replaces in part the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_ _Hardial Singh principles with a codified statutory_
version of the second and third principles. The notes also state, at para.102, that s.12 overturns the
common law principle established in  R(A) and later authorities, that it is for the court to decide for itself
whether there is a reasonable or sufficient prospect of removal within a reasonable time.

73 I have only received limited submissions on the meaning of the recent amendments and I anticipate
that these provisions will be explored in much greater detail in cases in the future. For the purposes of this
case it is not necessary for me to do so.

74 The claimant's submission that detention is neither reasonable nor proportionate because he is a
potential victim of **_modern slavery is, in my view, unarguable given the negative Reasonable Grounds_**
decision made on 12 September, and my conclusions on ground 1 of this claim for judicial review.

75 The claimant alleges that the decision to maintain detention is based on errors and omissions of facts.
There are no objective factors to suggest non-compliance with bail. He points to his good behaviour in
prison noted by the prison offender manager; his release on licence; his close ties with his young son and
a friend he seeks to live with on release. He has only been convicted of a single offence and has been in
the UK for over a decade.

76 The claimant contends the defendant has failed to identify or take into account the factors in favour of
release. First, that he has been assessed at Level 2 in the Adults at Risk policy. Second, the barriers to
removal, which are the asylum decision, a stage two deportation decision, and consideration of the best
interests of his son pursuant to s.55 of the Borders Act 2009. Family separation will have to be authorised.

77 The claimant submits that the defendant has failed to act with reasonable diligence and expedition.
The asylum claim has been outstanding since 10 October 2022. The detention centre induction did not
comply with rule 34 of the Detention Centre rules. The claimant's vulnerability was not identified by the
claimant until the Rule 35 assessment.

78 After giving careful consideration to the claimant's submissions, I accept the defendant's submission
that it is unarguable that there has been an infringement of the Hardial Singh principles in this case. First,
at all material times the defendant has intended to deport the claimant as authorised by statute and that is
the reason he has been detained. Second, the claimant has been and continues to be detained for a
period that is reasonable and proportionate in all the circumstances. The defendant has identified a high
risk of absconding because of his immigration history. He entered the UK illegally more than 10 years ago.
He has never regularised his immigration status. This demonstrates a lack of respect for immigration law
and procedure, with an increased likelihood that he will not adhere to bail conditions. The claimant is now
fully aware that the defendant intends to deport him and has refused to return to Albania under the
voluntary scheme. If released, there is a real risk he will abscond to avoid being deported. The claimant
relies on favourable findings as to the claimant's behaviour whilst he was in prison, but the prison
authorities were not assessing risk from the same perspective as the immigration authorities.

79 The claimant has limited close family ties to keep him in the UK. In his induction interview on 11
August 2023 the claimant stated he had no family in the UK. He has a young son, but he does not live with
the boy's mother. The claimant has now conceded that he does not have close family ties with his son.
The family separation was authorised on 30 July 2023. It found that there were no compelling
compassionate factors in line with the duty under s.55 of the Borders Act 2009, and given the serious
nature of his offending and likely absconding risk, any impact on Article 8 rights were likely to be
proportionate.

80 The claimant has been convicted of a serious offence of supply of Class A drugs. This is a single
offence and he was assessed at a low risk of reoffending by OASys. However, a release does carry with it
a risk of committing further offences. As highlighted by the OASys report, the claimant has no right to work
or claim benefits in the UK, meaning he would be likely to resort to work illegally to earn a living. In my
view, this was a legitimate concern for the defendant, despite the OASys assessment.

81 Contrary to the claimant's submission, the detention reviews have considered the Rule 35 report and
the claimant's status and vulnerability as an Adult at Risk Level 2 However there is no medical evidence


-----

to suggest that detention is injuring the claimant, such that he should be released. There was no
suggestion that he was vulnerable when he had a Healthcare appointment, when he was first detained on
4 August 2023, at which time it was noted that he was fit and well. On 11 August 2023 in his induction
interview he stated he was stressed, and on 21 August 2023 he stated he was having difficulty sleeping.
The Rule 35 report noted that he was feeling low and anxious and had been described antidepressant
medication, and referred to the mental health team. The claimant denied any thoughts of self-harm or
suicide.

82 The Rule 35 report concluded that the claimant was “stable in detention in regard to his physical and
mental health, however, he may deteriorate”. However, on 31 August 2023 the claimant was discharged
from the care of the mental health in-reach team which does suggest that any mental health problems were
being successfully managed whilst in detention.

83 The detention reviews have considered the presumption in favour of release and the issue of
removability. In the initial review on 31 July 2023 it was noted that the claimant had a pending asylum
claim. It was expected that detention would be for a short period of time, but if the asylum process was
prolonged and release was not possible within a reasonable time, the decision should be reconsidered. By
the time of the detention review on 1 September 2023, a notice under s.72 NIAA 2002 had been issued,
giving rise to a presumption that the claimant had been convicted of a serious crime and posed a danger to
the community. Unless the claimant could rebut this presumption, his asylum claim was liable to be
refused. That would accelerate removal. The authorising officer stated:

“[His] asylum claim is a barrier to removal; a response to his Section 72 letter is expected before the next
review and a decision will then be made. A Stage 2 decision will be made, and confirmation of any appeals
rights obtained; any appeal can be heard through the DIA process. …Removal is currently expected to
take place within 6 months depending on the progress and outcome of his asylum claim and any potential
appeal.”

84 At the detention review on 29 September 2023 the authorising officer stated:

“[He] has outstanding barriers of his asylum claim, Stage 2 and deportation order. He has a passport but in
any case, would be removeable on a UK Letter. His asylum screening interview and substantive interview
have been completed, and once the asylum claim is determined it is likely to be with no further right of
appeal.

I have spent time weighing up his current circumstances against presumption to release, including the high
risk of absconding and the likely timescale to removal. In light of his past evasion of immigration control I
am not satisfied that [he] would abide with any release restrictions imposed or remain in contact with the
Home Office. By means of passport or UKL, he can be documented for removal, and I am satisfied his
other outstanding applications could be resolved quickly and potentially with no further right of appeal. I
consider there is a realistic prospect of removal within a reasonable timescale.”

85 These assessments show that at all material times there was a timetable for removal within a
reasonable time.

86 The third principle, which requires that the power to detain should not be exercised in circumstances
where it is apparent on the basis of the material before the defendant at the time that the defendant will not
be able to effect removal within a reasonable time, is not arguably engaged on the facts of this case. It has
never been apparent to the defendant that the claimant could not be removed within a reasonable
timescale, as can be seen from the detention reviews.

87 The current position is that the claimant is an Albanian national with a valid passport. He can be
removed with his passport or on a UK letter. Albania is a designated safe country for removal. The
claimant has 20 working days (until 25 October 2023) to file a response to the s.72 notice. It is likely that a
decision on the asylum claim will be made within three weeks thereafter. If the asylum claim succeeds he
is likely to be released. If the claim is refused, his claim may be certified without a right of appeal. In that
case, the remaining stages of the deportation procedures would be completed and removal could take


-----

place at best within nine weeks, but perhaps more realistically between 12 to 16 weeks. That is on the
assumption that there is no judicial review challenge made to the decision on the asylum claim.

88 If he is granted a right of appeal, it can be processed via the Detained Immigration appeals process
within 6 to 8 months. If that position arose, it would require a re-assessment as to whether detention
pending appeal was reasonable, but that is not the position before me presently.

89 As to the fourth principle, I do not consider that the detention has been rendered unlawful by a failure
on the part of the defendant to act with reasonable diligence and expedition in this case. The delays
identified by the claimant are not of sufficient gravity to engage this principle. The claimant's detention has
been regularly reviewed and the reports and the action points listed in the reports demonstrate the
defendant's awareness of the need to make decisions promptly once barriers have been overcome as
does the internal email dated 27 September 2023.

90 In respect of the period from 28 September 2023 onwards after the coming into force of s.12 of the
Illegal Migration Act 2023, I consider that the detention of a claimant has been lawful pursuant to the
provisions of sub-para.(3)(a) of paragraph 2 of Schedule 3 to the Immigration Act 1971 for the reasons set
out above.

91 In my judgment, the claimant has not succeeded in demonstrating that the claimant's detention is
arguably unlawful. I do not consider there is any real prospect of ground 2 succeeding at a substantive
hearing. Therefore permission to apply for judicial review is refused.

92 It follows that, as the claimant has not been able to demonstrate an arguable claim and permission has
been refused, the court cannot grant interim relief. Therefore, it is not appropriate to proceed to the second
stage of considering the balance of convenience in the grant of interim relief.

93 The claimant applies, in the alternative, for a grant of immigration bail because it does not depend upon
the existence of an arguable claim. In my view, the appropriate forum for an application for immigration
bail is the First-tier Tribunal, not a claim for judicial review in the High Court. The Administrative Court will
not generally allow a claim to proceed where, as in this case, there is a suitable alternative remedy
provided for by statute. It remains open to the claimant to make an application for bail to the First-tier
Tribunal at any time, in particular should his circumstances change.

94 Therefore the application for interim relief is refused, the application for immigration bail is refused, and
the application for permission to apply for judicial review is refused.

________________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.


-----

**End of Document**


-----

