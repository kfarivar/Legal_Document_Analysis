# S.M. v Croatia (App. No. 60561/14) [2020] ECHR 60561/14

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE SPANO (PRESIDENT), JUDGES KJØLBRO, NUßBERGER, TURKOVIĆ, O'LEARY, DE GAETANO,
LAFFRANQUE, GRIŢCO, KŪRIS, LUBARDA, RANZONI, RAVARANI, VILANOVA, SERGHIDES, ELÓSEGUI,
BÅRDSEN, PAVLI; AND LIDDELL (REGISTRAR)

15 MAY 2019, 8 JANUARY, 25–26 MARCH 2020

25 JUNE 2020JUDGMENTPROCEDURE

1. The case originated in an application (no. 60561/14) against the Republic of Croatia lodged with the Court under
Article 34 of the Convention for the Protection of Human Rights and Fundamental Freedoms (“the Convention”) by
a Croatian national, Ms S.M. (“the applicant”), on 27 August 2014. The President of the Grand Chamber upheld the
decision not to have the applicant's name disclosed (Rule 47 § 4 of the Rules of Court).

2. The applicant, who had been granted legal aid, was represented by Ms S. Bezbradica Jelavić a lawyer practising
in Zagreb. The Croatian Government (“the Government”) were represented by their Agent, Ms Š. Stažnik.

3. The applicant alleged, in particular, that the domestic authorities had failed to apply effectively the relevant
criminal-law mechanisms concerning her allegations of human trafficking and/or exploitation of prostitution, contrary
to Articles 3, 4 and 8 of the Convention.

4. The application was allocated to the First Section of the Court (Rule 52 § 1 of the Rules of Court). On 19 July
2018 a Chamber of that Section composed of Linos-Alexandre Sicilianos, Kristina Pardalos, Krzysztof Wojtyczek,
Ksenija Turković, Armen Harutyunyan, Pauliine Koskelo and Jovan Ilievski, judges, and also of Abel Campos,
Section Registrar, gave judgment. The Chamber by a majority declared the application admissible and held that
there had been a violation of Article 4 of the Convention in its procedural limb. The dissenting opinion of Judge
Koskelo was annexed to the judgment.

5. On 19 October 2018 the Government requested the referral of the case to the Grand Chamber in accordance
with Article 43 of the Convention. On 3 December 2018 the panel of the Grand Chamber granted that request.

6. The composition of the Grand Chamber was determined according to the provisions of Article 26 §§ 4 and 5 of
the Convention and Rule 24 of the Rules of Court. During the second deliberations, Angelika Nußberger, Vincent A.
De Gaetano and Julia Laffranque, whose term of office expired in the course of the proceedings, continued to deal
with the case (Article 23 § 3 of the Convention and Rule 24 § 4). Robert Spano succeeded Angelika Nußberger as
President of the Grand Chamber (Rules 10 and 11).

7. The applicant and the Government each filed further written observations (Rule 59 § 1) on the merits of the case.
In addition, third-party comments were received from the Council of Europe Group of Experts on Action against
Trafficking in Human Beings (GRETA); Clinique doctorale de droit international des droits de l'homme (Faculté de
_droit d'Aix-en-Provence); the Research Centre_ _L'altro diritto onlus (University of Florence); and the group of_
researchers Bénédicte Bourgeois (University of Michigan), Marie-Xavière Catto (University Paris I PanthéonSorbonne) and Michel Erpelding (Max Planck Institute Luxembourg for Procedural Law).

8. A hearing took place in public in the Human Rights Building, Strasbourg, on 15 May 2019 (Rule 59 § 3).

There appeared before the Court:


-----

(a) for the Government

Ms Š. Stažnik, Representative of the Republic of Croatia before the European Court of Human Rights, Agent,

MS N. Katić, Office of the Representative of the Republic of Croatia before the European Court of Human
Rights,

Mr K. Nikolić, Office of the Representative of the Republic of Croatia before the European Court of Human
Rights Advisers;

(b) for the applicant

MS S. Bezbradica Jelavić, Lawyer, Counsel.

The Court heard addresses by Ms Bezbradica Jelavić and Ms Stažnik, and also replies by Ms Bezbradica Jelavić,
Ms Katić and Ms Stažnik to questions from judges.
**THE FACTS**

9. The applicant was born in 1990 and lives in Z.

10. Owing to problems in her family, between 2000 and 2004 she lived with a foster family. Then she moved to a
public home for children and young persons, where she stayed until she completed her professional training in
catering service. Afterwards she moved to live with her father in S. and occasionally visited her mother in Z.
_I. The applicant's criminal complaint and the ensuing investigationA. The applicant's criminal complaint against T.M._

11. On 27 September 2012 the applicant came to a police station in Z. and on the record made a criminal complaint
against a certain T.M. She alleged that during the summer of 2011 T.M. had physically and psychologically forced
her into prostitution.

12. The applicant submitted that sometime before the summer of 2011 T.M. had contacted her via Facebook and
presented himself as a friend of her parents. Following this initial contact, for about a month or two she had
continued exchanging messages with T.M. over everyday things. Then sometime in June or July 2011 she had met
T.M. and went for a drink with him. On that occasion T.M. had explained that he wanted to help her with finding a
job because he knew her parents. For that purpose T.M. left his phone number. Already on that occasion the
applicant felt that T.M. was a person who insisted on having things his own way and who could not be contradicted.

13. The applicant further stated that following this meeting she had continued exchanging messages with T.M. via
Facebook. As she had had no reason to question T.M.'s intentions, about two weeks after the first meeting she had
contacted T.M. and they had decided to meet again. This time when they met T.M. had said that he would take her
to a man to whom she should provide sexual services for money. T.M. had explained that she should charge 400
Croatian kunas (HRK; approximately 50 euros (EUR)) for her services and that she should give him half of that
money. She had told T.M. that she did not want to do this. T.M. had then said that she would only have to do this
until he found her a proper job. As she had earlier realised that T.M. was not a person to whom one could say “no”,
out of fear she had agreed to go with him to see the man.

14. T.M. had then taken her in his car to a place in the proximity of Zap. (a city near Z.) where the man had been
waiting for her in a house. The applicant had explained to the man what was happening and the man had not
insisted on having intercourse with her but said that he would give her HRK 400. T.M. had listened to this
conversation behind the door and, after the man had left the room, T.M. had slapped the applicant saying that she
should never talk to clients and that she should listen to him and do only what he told her.

15. The applicant further explained that after this incident, T.M. would pick her up every day in front of the place
where she lived in Z. and he would take her in his car to provide sexual services to men who had answered an
advertisement on a social network. After a while, he had given her a mobile telephone so that clients could contact
her and had continued to drive her to meet clients in various places. Soon afterwards T.M. had rented a flat in Z.
(the applicant provided the address) where she continued rendering sexual services to men. This arrangement had


-----

allowed T.M. to have her constantly under control as he had always been in the flat and had also said that he would
install cameras so that he could know what was happening. The applicant had been afraid of T.M. as he had said
that he had done the same thing with some other girls, whom he would physically punish if they did not listen to
him. T.M. had also physically punished her when she opposed him over something. When she had refused to
provide sexual services to other men, he had beaten her.

16. The applicant also stated that at the beginning of September 2011, when she knew that T.M. would be absent
from the flat for a longer time, she had left the flat and gone to the house of her friend M.I. She explained to M.I.
what had happened to her. After he had realised that she had left him, T.M. had at first started contacting her via
Facebook asking her to come back and saying how he loved her and that she would never again have to provide
sexual services. As the applicant had not answered these messages, T.M. had started threatening that he would
find her and that she and her parents would “pay” for everything. The applicant had continued ignoring these
messages so after a while T.M. had stopped sending them. A year later, and two weeks before the applicant lodged
her criminal complaint, T.M. had again contacted her via Facebook mentioning her mother. All this had made the
applicant feel frightened for her own safety and the safety of her parents and sister.

17. The applicant finally explained that on average she had had one client per day because when T.M. had not
been around she would turn off the phone and deactivate the advertisement so that clients could not contact her. In
total she had some thirty clients and she had earned approximately HRK 13,000 (approximately EUR 1,700). Half of
this amount she had given to T.M.
_B. Preliminary police investigation_

18. On the same day when the applicant made her criminal complaint, the police informed the Z. Municipal State
Attorney's Office (hereinafter “the State Attorney's Office”) that the complaint had been lodged and that they were
conducting a preliminary investigation.

19. On 10 October 2012, following an order by the Z. County Court (hereinafter “the County Court”), the police
conducted a search of T.M.'s premises and his car. In the car, the police found and seized condoms. During the
search of T.M.'s premises, the police seized two automatic rifles and the accompanying ammunition, a hand
grenade and a number of mobile phones.

20. The police also established that T.M. was registered in the police records as a perpetrator of the criminal
offences of procuring prostitution, and rape. His criminal record, obtained by the State Attorney's Office, indicated
that in 2005 T.M. had been convicted of the offence of procuring prostitution using coercion, under Article 195 §§ 2
and 3 of the Criminal Code (see paragraph 96 below) and rape under Article 188 § 1 of the Criminal Code, and that
he had been sentenced to six and a half years' imprisonment.

21. On 10 October 2012 T.M. was arrested and questioned by the police. It was established that T.M. had trained
as a policeman. He denied the allegations made by the applicant and stated that everything was an attempt by the
applicant and her mother to take revenge on him for the difficult relationship he had had with the applicant's mother.

22. On 11 October 2012 the police sent the applicant's criminal complaint and all the collected evidence to the State
Attorney's Office. The police classified the applicant's complaint under Article 195 § 3 of the Criminal Code
(procuring prostitution using coercion). T.M. was also brought before an investigating judge of the County Court
who ordered his pre-trial detention. He remained in detention until the end of the criminal proceedings against him
in the Municipal Court.
_C. Investigation conducted by the State Attorney's Office1. Questioning of T.M._

23. On 11 October 2012 T.M. was questioned in the State Attorney's Office. He reiterated the arguments made
during the police questioning. He also explained that the applicant had contacted him because she had asked him
to protect her from another person for whom she was engaged in prostitution. T.M. denied that he had ever
proposed to her that she engage in prostitution for him. He also stressed that the applicant had rented a flat in Z.
and that he had lent her money for that, which she had later returned. T.M. further explained that at the applicant's
request he used to drive her around. However, she had not told him where she was going but he had suspected
that she might be engaged in prostitution T M stated that he had not lived with the applicant in the same flat He


-----

would only sometimes stay overnight when she would invite him as they had had a relationship. T.M. admitted that
once he might have hit the applicant but that was because she had provoked him. He denied that he had given her
a mobile phone as she had had her own phone.
_2. Questioning of the applicant_

24. On 16 October 2012, in the context of the investigation against T.M., the applicant was questioned in the State
Attorney's Office. The applicant was informed of all her rights as a victim of an offence under Articles 43 § 1, 45 and
52 § 4 of the Code of Criminal Procedure (see paragraph 98 below). She stated that she had understood the
instructions and made no specific request in that regard.

25. During the questioning, the applicant repeated her statement concerning the first contact she had had with T.M.
(see paragraphs 12-13 above). She also explained that sometime in spring 2011 T.M. had started suggesting that
he could find a job for her in a shopping mall. As she had been without employment, she had started
communicating with him more intensively. In this context, she had met T.M. on various occasions in cafés and he
had continued saying that he could find a job for her. She had had no reason to question his intentions.

26. The applicant also provided further details concerning the incident when T.M. had taken her to provide sexual
services to a man in a house near Zap. She stated that it had happened at the beginning of July 2011 and that T.M.
had taken her there by deceiving her into thinking that he would take her to a friend who could find her a job. The
applicant repeated her statement as regards the events in the house and how the man had not insisted on sexual
intercourse but had still paid her HRK 400. She also reiterated that T.M. had stormed into the room where she was
with the man and started to shout at her, following which he had slapped her. Moreover, on their way to Z., T.M.
had threatened to throw her out of the car on the highway because she had started asking what was happening.

27. The applicant further explained that the next day T.M. had again contacted her and told her that they needed to
talk about what had happened. She had agreed to meet him but they had not discussed what had happened as he
had avoided the topic. A few days later T.M. had given her a mobile telephone. He had explained that clients
seeking sexual services would contact her on that number. T.M. had also told the applicant that she had to give her
physical description to men who would contact her and charge HRK 400 for half an hour of sexual services or HRK
600 (approximately EUR 80) for an hour, and that she had to give half of that money to T.M. The applicant had
acquiesced to all that because she had been scared that T.M. would attack her again and that he would tell her
parents everything that was happening.

28. The applicant also submitted that the men who would contact her had explained that they had seen the
advertisement on the Internet. Some ten days after the incident in Zap., T.M. had rented a flat (the applicant
provided the address), where the applicant and T.M. had then lived together. She had provided sexual services in
that flat and sometimes T.M. had driven her to clients. Since T.M. had lived in the same flat with her, he had
controlled everything she did. When she had refused to have sexual intercourse with other men or with him or when
she had talked to the clients, T.M. had beaten her. He had beaten her every couple of days. She repeated the
statement concerning the amount of money she had earned and stressed that she had given half of it to T.M.

29. Asked as to why she had not contacted the police earlier, the applicant answered that she had been afraid of
T.M. and that he had had her under his control. However, once, when T.M. had been out of the flat and had left the
key, she had called her friend M.I. and asked her for help. M.I. had known that she had been giving sexual services
to men for money against her will and that she had been in trouble. After this discussion, M.I.'s boyfriend, T., had
arrived by taxi, helped the applicant to collect her things and taken her to M.I.'s home, where she had then stayed
for several days.

30. The applicant further said that after she had left, T.M. had at first started contacting her via Facebook asking her
to come back to him and telling her that he loved her. As the applicant had not answered these messages, T.M. had
started threatening that he would tell everything she had done to her parents. She had truly been afraid that he
might do that so she had decided to lodge a criminal complaint to put an end to everything that had happened.

31. The applicant also said that T.M. had told her that he had previously had a girlfriend, A., whom he had treated in
the same way as the applicant She had also learned from Facebook that T M had later had another girlfriend who


-----

had been engaged in prostitution. T.M. had told the applicant that he had filmed those girlfriends and punished
them when they had been insolent. He had also threatened to do the same thing to the applicant. T.M. had told her
all that in order to break her will to stand up to him.
_3. Questioning of M.I._

32. On 6 November 2012 the State Attorney's Office questioned M.I. She said that the applicant was her friend and
she had known her for some two years. M.I.'s last contact with the applicant (before the applicant had come to her
flat) had been some eight or nine months previously.

33. M.I. explained that at the end of summer 2011 the applicant had suddenly come to her home with a bag
containing her things. M.I. had then learned that the applicant had agreed with M.I.'s mother that she would come to
stay with them, but she (M.I.) did not know any details since she was not on very good terms with her mother. Also,
M.I.'s boyfriend (whose full name and address she gave) had told her that he had spoken to the applicant.
However, soon afterwards M.I. had broken up with her boyfriend so they had not discussed any details concerning
his contact with the applicant.

34. M.I. further stated that the applicant had told her about T.M., from whom she had escaped because she had no
longer wished to be involved in prostitution for him. Before the applicant had come to her flat, M.I. had known that
the applicant was engaged in prostitution but she had not known where or for whom the applicant was doing this.
Only then had M.I. learned that the applicant had being doing it for T.M. According to M.I., the applicant had been
very distressed and scared. She had told M.I. that T.M. had repeatedly beaten her, had watched her through a key
hole when she had been giving sexual services to clients and afterwards had also beaten her for not being in a
position he had approved of.

35. M.I. also said that she understood that the applicant had voluntarily given sexual services because she had
needed money. The applicant had told her that she had had an agreement with T.M. to work for him and to share
the money, that she had had a mobile telephone for clients to call her and that there had been a small ad through
which she had been contacted for appointments by clients. The applicant had said that T.M. had given her that
mobile telephone and placed the advertisement.

36. M.I. further stated that she could not remember if the applicant had told her that she had resisted T.M. It was
true that the applicant had said that she had not wished to “do it” but in M.I.'s understanding that had rather meant
that the applicant had been “doing it” because she had had no other means to earn money. The applicant had also
told her that T.M. had slapped her for very minor reasons which she (the applicant) had not expected. The applicant
had also said to M.I. that when she had refused sexual relations with him T.M. would beat her and the applicant had
not known what would make him explode again. According to M.I.'s knowledge, T.M. had also told the applicant that
he had had another girlfriend whom he had treated in the same way as the applicant. The applicant told M.I. that
she had used the opportunity to run away from T.M. when he had been out of the flat where they had lived.

37. M.I. also said that the applicant had stayed with her and her mother for more than half a year and that T.M. had
continued to contact the applicant through Facebook. M.I. had seen the messages that he had sent and they were
threatening to the applicant and the applicant's mother. He had also sent messages saying that he loved her and
asking her to come back to him.
_D. The indictment against T.M._

38. On 6 November 2012 the State Attorney's Office indicted T.M. in the Z. Municipal Criminal Court (hereinafter
“the Municipal Court”) on charges of procuring prostitution using coercion, as an aggravated offence of procuring
prostitution, proscribed by Article 195 § 3 of the Criminal Code (see paragraph 96 below).

39. The indictment alleged that T.M., in order to obtain pecuniary gain, had deceived the applicant into believing
that he would find her a job. However, after that he had taken her to provide sexual services to a man in Zap. As the
applicant had refused to do that, T.M. had hit her and then, on their way back to Z., had threatened to throw her out
of the car. Soon afterwards T.M. had provided the applicant with a mobile phone to answer the clients' calls. He had
also instructed her how to charge for sexual services and to give half of the money to him. According to the
indictment the applicant had consented to this out of fear T M had then taken the applicant to the addresses of


-----

clients where she had provided sexual services for money and after a while he had rented a flat in Z. where the
applicant had continued providing sexual services to a number of men. T.M. had kept the applicant under
surveillance and had also told her that he had beaten other girls who did not do what he had requested. When the
applicant resisted him saying that she did not want to provide sexual services anymore, T.M. would hit her. She had
therefore, out of fear of him, continued providing sexual services to men for money until September 2011, when she
had run away from the flat.

40. The indictment relied on the applicant's statement and considered that it was corroborated by M.I.'s evidence.
The indictment also considered that T.M.'s defence, although denying the commission of the offence, essentially
made the applicant's statement even stronger.

41. On 22 November 2012 a three-judge panel of the Municipal Court confirmed the indictment and sent the case
for trial.
_II. Criminal proceedings against T.M.A. First hearing_

42. The first hearing before the Municipal Court scheduled for 12 December 2012 was adjourned because T.M.
claimed to be on hunger strike and could not therefore participate in the proceedings. The judge conducting the
proceedings commissioned an expert report to establish whether T.M. could participate in the trial.

43. The expert report established that T.M. had worked as a policeman for a number of years and that he had been
a member of the special police forces during the war in Croatia in the 1990s. He had retired from the police in 2001.
He suffered from a post-traumatic stress disorder (PTSD) related to his participation in the war and he had also
developed a personality disorder. He had received psychiatric treatment over a number of years. According to the
report, T.M.'s capacity to understand the nature of the impugned acts had been diminished but not to a significant
degree. The report therefore recommended that, in the event of conviction, an order for mandatory psychiatric
treatment be made. The report also considered that T.M. could participate in and follow the proceedings.
_B. Second hearing (T.M.'s defence pleading)_

44. At a hearing on 14 January 2013 T.M. pleaded not guilty. He denied that he had forced the applicant into
prostitution. He confirmed that he had contacted the applicant through Facebook because he had recognised her
surname since he had known her mother. After several exchanges of messages via Facebook, T.M. and the
applicant had started to see each other and the applicant had told him that she had had no money and needed a
job and that she had some debts. She had also said that she was in fear of a certain B., whom T.M. had known
from prison and it had therefore been clear to him “what the applicant was doing”. Moreover, she had said that she
had kept contact details of her clients which she had obtained from B. The applicant had also asked T.M. to lend
her money to rent a flat, which he had done and she had later returned the amount she had borrowed in two
instalments. The applicant had also said that she would try to find a job.

45. T.M. further stated that a few weeks after he had met the applicant, they had engaged in a relationship. The
applicant had asked him to take her to certain addresses by car and on five or six occasions he had done so. He
had known that she was going there to give sexual services for money. However, he had not known how much she
had been earning from the provision of her services. T.M. confirmed that he had once hit the applicant because
they had had a disagreement over “work” and she had provoked him. He specified that this concerned the fact that
the applicant had said that she had found a job in a bakery but that she did not want to work. T.M. had not liked her
attitude so there had been an argument and, as he had not been able to control himself, he had hit her. Later on, he
had found a job for the applicant in a restaurant in Zap. but then she had disappeared. This had happened in
August 2011 and the only thing he had found in the flat she had rented had been a message from the owner of the
flat addressed to the applicant.

46. When questioned by the judge conducting the proceedings, T.M. explained that he had not lived with the
applicant in the flat she had rented but only sometimes spent the night there. He had had the keys of the flat.
Sometimes the applicant would go alone to see her clients or to see a doctor or her friends, and she would later
inform T.M. that she had some money. T.M. could not explain why he had agreed to the applicant providing sexual
services to other men when he had been in a relationship with her. He stressed that she had wanted to be
i d d t d t h h h d t t d t i t f i th t H l l i d th t h h d


-----

only used one mobile phone and that those found by the police during the search had been his old phones which
he had no longer used.

47. When questioned by the prosecutor, T.M. denied that he had given any mobile phone to the applicant.
According to him, she had had her own two mobile phones. T.M. also stated that on two or three occasions the
applicant had given him some money for fuel because he had driven her around. However, she had constantly
complained that she had no money so he used to give her money as well. T.M.'s impression was not that the
applicant had been afraid of him as she had not been the kind of person to be afraid of anybody.

48. Following T.M.'s questioning, the prosecutor asked that the applicant and M.I. be heard as witnesses. The
defence agreed and made no other proposal for the taking of evidence. The trial court accepted the parties'
proposal and scheduled the next hearing for 29 January 2013.
_C. Third hearing (the applicant's and M.I.'s oral evidence)_

49. The summons for the hearing served on the applicant contained detailed information on her rights as a victim,
such as psychological and practical support and the possibility to contact the Department for Organising and
Providing Support for Witnesses and Victims within the Municipal Court. The contact details of that Department
were also provided.

50. At a hearing on 29 January 2013 the Municipal Court heard evidence from the applicant and M.I. The applicant
was accompanied by a lawyer provided to her by the non-governmental organisation the Rosa Centre.

51. Before giving her evidence the applicant told the trial court that she was afraid of T.M. He was then removed
from the courtroom and the applicant gave evidence in his absence.
_1. The applicant's oral evidence_

52. During questioning, the applicant repeated her statement given during the investigation (see paragraphs 25-31
above) and said that she wanted to clarify certain aspects of that statement. In this connection, she explained that
before the incident in Zap. she had met T.M. three or four times for a coffee and they had exchanged messages on
Facebook. He had promised to do his best to find her a job as a waitress or in a shop. The applicant further clarified
that when T.M. had taken her to see the man in Zap., he had said that they would have a coffee with him. In the
house, the man had seen T.M. slapping her. With regard to the events that happened on their way back to Z., the
applicant explained that she had wanted to run away from T.M. but that he had managed to catch her and had
forced her to stay in the car. The next day when they had met they had not talked about these events but about her
attempts to find a job. The applicant also explained that she had agreed to move into the flat which T.M. had found
without him using any force on her. She had done that in order to protect her roommate with whom she had lived at
the time. T.M. had commented on how good-looking she was and the applicant had tried to avoid getting her in any
of these things and to end up like she (the applicant) did.

53. When questioned by the judge conducting the proceedings, the applicant explained that when T.M. had rented
the flat for her she could guess what she was expected to do there, namely to provide sexual services. She had
been afraid of him and for that reason had agreed to give sexual services to other men. He had also threatened that
he would tell everything to her parents and that he would put her mother in prison. The applicant also repeated her
statement from the investigation about the number of clients she had had and the money she had earned, half of
which she had given to T.M.

54. The applicant further stated that T.M. had been present in the flat when she had provided sexual services to
other men. Sometimes he had watched her through the keyhole and he would slap her if she refused to be with a
client or to have the intercourse in the way T.M. had wanted. She had also been forced to have sex with T.M. She
had not sought medical help or contacted the police because she could not get out of the flat.

55. When further questioned by the judge conducting the proceedings, the applicant said that she had not known
T.M.'s background when they had first got in touch. At that time, he had known that she had no job and he had
promised to try to find her one. As to the incident in Zap., the applicant repeated her statement from the
investigation. She explained that she had voluntarily given the money she had received from the man to T.M.


-----

56. The applicant also explained that she had accepted the mobile phones which T.M. had procured for the
contacts with clients because she had been afraid of him. Later on, while no longer living in the flat which T.M. had
rented, the applicant had learned from T.M. that her mother had previously reported him (the applicant did not
specify for what) and that he had been in prison. The applicant also stated that it was she alone who had answered
the clients' calls. Clients would sometimes come to the flat or T.M. would drive her to meet them. In the flat, she had
lived with T.M. although she had been required to pay rent, and she had done so. She had not had keys to the flat.
She had had one mobile phone which T.M. had provided and she had her own mobile phone but did not have
money on the pre-paid SIM card. She had stayed in the flat for about a month and a half. She had not tried to run
away because she had been afraid of T.M. She had also not tried to contact the police because T.M. had said that
he had contacts in the police and that he would very quickly learn if she had reported him.

57. As regards her escape from the flat, the applicant explained that once she had taken advantage of the fact that
T.M. had been absent for a while and that the key had been left in the front door. She had then called her friend
M.I., with whom she had been in contact over the Internet some fifteen days before when she had told M.I. that she
was in trouble and that she would need her help. On the occasion when she had called M.I., the applicant had
spoken to M.I. and her mother. She had not explained any details but had simply said that she was staying with a
man in a flat and was engaged in prostitution and that she wanted to escape. The agreement was that M.I.'s now
former boyfriend T. would come by taxi to pick her up. The applicant explained that she had had some earlier
contacts with T. via Facebook but she had not told him anything about her situation. When T. had taken her to M.I.'s
place, the applicant had found M.I. and her mother there. She had stayed with them for about ten days and she had
told M.I. what she had been through. Meanwhile, she had also had contact with the owner of the flat where she had
stayed with T.M. concerning the rent and how she could get some of her belongings that she had left there.

58. Further to the judge's questions, the applicant explained that she had not tried to escape from T.M. when he
took her to see clients away from the flat because she had been sure that he would find her and he had strictly
controlled the time she spent with clients. The applicant also stated that T.M. had told her that he had done the
same thing to another girl. When confronted with T.M.'s defence, the applicant denied that T.M. had ever lent her
money to pay her rent. She said that she did not know any person by the name of B. and denied that she had had
any contact details of clients. She also stated that T.M. had never told her that he had found her a job in the
restaurant in Zap. Later on, when she had already left him, he had sent her some messages via Facebook
mentioning that he had found her a job in a shop.

59. The applicant also stated that at first when she had run away from T.M. she had not wanted to report him to the
police. However, after she had left, T.M. had continued contacting her via Facebook, had reported to the authorities
that her mother had neglected and abused her younger daughter, and had threatened that as soon as she found a
job or continued with her education he would destroy everything for her. She had therefore decided to report him to
the police. The applicant also explained that after she had left T.M. she had been afraid to go out in public and felt
fear every time she saw a car similar to T.M.'s.

60. When questioned by the prosecutor, the applicant stated that she had been very afraid of T.M. She had never
known how he would react and she had been in fear for her life because he used to threaten that he would beat her
to death. Also, when she had refused to have sex with him, he would beat her. He had also beaten her when she
said that she did not want to provide sexual services anymore. Moreover, he had deceived her by saying that she
would have to provide sexual services only for a few days and that he would find her a proper job. As to the sharing
of money, the applicant explained that she would first hand over all the money she had collected from a client to
T.M. and he would then give part of it to her. T.M. had also set some rules concerning the way she was allowed to
provide sexual services. When she did not obey this or if she gave sexual services in a manner that he did not like,
he would then beat her. He had also taken photos of her naked and published them with the ad. She had not
objected to him taking the photos because she had been scared. Then, he had threatened to show the photos to
her parents.

61. When questioned by her lawyer, the applicant stated that T.M. had at first presented himself to her as a former
policeman and said that he had been in the war with her father. Later on he had said that he knew people in every
police station and that he would “frame” her if she tried to report him.


-----

62. When questioned by the defence lawyer, the applicant stated that following her first contact with T.M. she had
not tried to get in touch with her mother to check whether she had known him. At that time, her mother had not lived
in Croatia and they had not been on good terms. However, she had then exchanged some messages with her
mother, who had simply said that T.M. was not a reliable person. The applicant had also asked her father about
T.M. and he had said that T.M. was “an okay person”. The applicant had concluded from the messages which she
had exchanged with T.M. that he was not a bad person and she had no reason to call into question his statement
that he had been a policeman. Later on, after she had left T.M., the applicant had spoken to her mother about him.
Her mother had told her that she had lived with T.M. after she had split from the applicant's father. When the
applicant asked her mother why T.M. was angry with her and why she had reported him (it was not specified in the
record for what), her mother had said that it had not been her but another girl who had reported him and that this
girl had provided sexual services in the same manner as the applicant did. According to the applicant, that was the
same girl about whom T.M. had also spoken to her.

63. When further questioned by the defence lawyer, the applicant explained that when she had gone to pick up her
belongings from the flat where she had lived with T.M., the owner of the flat and M.I. had been there with her. She
had been contacted by the owner as she had not paid the last rent. The flat had been rented in her name. During
her stay in the flat with T.M. the owner used to come and T.M. would present them as a couple to the owner. The
applicant also stated that T.M. had slept every night in the flat. She did not deny that there had been moments
when she would leave the flat to go to a shop without T.M. It had happened three or four times during the period of
a month and a half. However, she had not dared to run away because of her fear of T.M., who had always watched
her from the window.

64. After the applicant's questioning, T.M. was brought back to the courtroom and her statement was read out to
him. He had no questions and made a general objection as to the credibility of her statement.
_2. M.I.'s oral evidence_

65. The trial court then proceeded to the questioning of M.I. She repeated her statement given during the
investigation (see paragraphs 32-37 above).

66. When questioned by the judge conducting the proceedings, and after being presented with the applicant's
statement, M.I. denied that the applicant had called her when she had left T.M. She insisted that the applicant must
have arranged everything with her (M.I.'s) mother. M.I. further stated that she had known from before that the
applicant was engaged in prostitution because the applicant had told her so. The applicant had explained to M.I.
that she needed money and that she was living without parents. M.I. considered that the applicant had initially
engaged in prostitution voluntarily. M.I.'s opinion was that the applicant had also voluntarily engaged in the
prostitution ring with T.M. because she had needed money. However, the applicant had not known who she was
dealing with given that – as M.I. had learned from the applicant – T.M. had forced and beaten her. M.I. could not
remember whether the applicant had told her that she had resisted T.M. when he had asked her to provide sexual
services to men. The applicant had told M.I. that she did not want to do these things anymore but M.I. had
understood that as a general complaint about the fact that she had to earn money in this way.

67. When further questioned by the judge conducting the proceedings, M.I. stated that the applicant had stayed for
several months with her. When she had come to M.I.'s place, the applicant had not had any visible injuries but had
been very scared and upset. She had been in fear of T.M. and had said that she could not believe what had
happened to her and that she had not expected that. M.I. also explained that she had seen the Facebook
messages which T.M. had sent to the applicant on the applicant's laptop. They had been long messages in which
T.M. had sometimes said how he loved the applicant and sometimes had made threats mentioning the applicant
and her mother. M.I. denied that she had gone with the applicant to pick up her belongings in the flat where she had
lived with T.M. According to M.I., it had been her boyfriend T. who had gone with the applicant to the flat.

68. When questioned by the defence lawyer, M.I. stated that the applicant had never mentioned to her a person by
the name of B. She also said that at about the time when the applicant had come to her place she was about to
break up with her boyfriend T. As far as M.I. knew, at the relevant time T. had only once exchanged a message with
the applicant via Facebook.


-----

69. Following M.I.'s questioning, the applicant stated that she had no objections to M.I.'s evidence. The applicant
considered that, although there had been some discrepancies in their statements, this was the result of the peculiar
course of events.

70. After hearing the applicant and M.I., the prosecutor proposed that the materials from the file be allowed as
evidence. The defence asked that a certain K.Z. be heard as a witness concerning the threats of revenge that the
applicant's mother had allegedly made towards T.M. The defence also asked that T.M.'s brother be heard as a
witness.

71. The prosecution opposed these proposals and the trial court considered that it was not necessary to take the
evidence proposed by the defence. The next hearing was scheduled for 15 February 2013.
_D. Closing hearing (T.M.'s closing statement)_

72. At the hearing on 15 February 2013 the applicant was represented by the lawyer provided by the Rosa Centre.
T.M. asked the trial court to allow him to make a further statement, which the trial court agreed to.

73. In his statement, T.M. stated that he knew the applicant's mother because she had also been a prostitute but
had lost touch with her when he had started serving his prison sentence. After he had made contact with the
applicant via Facebook, the applicant had told him that she had talked to her mother about him. He had wanted to
help the applicant to find a job and she had also told him that she was engaged in prostitution because that had
been the easiest way to earn money. He had fallen in love with the applicant and wanted to have a relationship with
her. He had agreed that she could continue with the prostitution because he was not a jealous person. However, he
had told her that she should get a proper job.

74. T.M. further stated that it was the applicant who had rented the flat and organised everything. He knew that she
had charged HRK 400 for half an hour and HRK 600 for an hour but it had been her, not him, who had set that
price. He had not constantly stayed in the flat. He also denied that the incident in Zap., as stated in the indictment,
had ever happened.

75. When questioned by the judge conducting the proceedings, T.M. admitted that sometimes he had been in the
flat when the applicant had provided sexual services to men and that he had received half of the money which she
had charged for her services. He had not wanted to take the money but the applicant had insisted saying that it was
for the fuel that he had used when driving her to meet clients away from the flat. T.M. also denied that he had
strictly controlled the time the applicant had spent with her clients. However, he admitted that he had given her
money to buy a mobile phone but that was because she had asked for it. According to T.M., the applicant could
have left the flat whenever she wished. However, he had been surprised to see that one day she had simply left. He
assumed that the reason for that was the fact that he had put pressure on her to find a proper job and had even
made certain contacts to arrange job interviews for her. T.M. admitted that he had hit the applicant once but the
reason had again been related to his insistence that she find a proper job. T.M. also stated that he had not known
how many clients the applicant had had in total. He had not always been with her and had not constantly controlled
her. He denied any deception or force towards the applicant related to her provision of sexual services.

76. When asked by the applicant's lawyer why the applicant needed him at all when she had arranged everything
on her own, T.M. refused to answer that question saying that he had already explained everything concerning their
relationship.

77. After hearing T.M.'s further statement, the parties made no further proposals for the taking of evidence. The
judge conducting the proceedings admitted the documents provided by the prosecution as evidence, heard the
parties' and the applicant's lawyer's closing statements and concluded the proceedings.
_E. The judgment_

78. Following the hearing of 15 February 2013 the Municipal Court acquitted T.M. on the grounds that although it
had been established that he had organised a prostitution ring into which he had recruited the applicant, it had not
been established that he had forced or pressured her into prostitution, which was a constituent element of the


-----

offence he was charged with under Article 195 § 3 of the Criminal Code. In finding this, the court in particular noted
the following:

“On the basis of the evidence given by the accused and the victim in these criminal proceedings the following
facts have been established: that the accused and the victim met through the social network Facebook when
the accused contacted the victim; that the accused had known the victim's mother and father from before; that
after the initial contact, the contacts continued in that the accused and the victim met in cafés in Z.; that at the
time the victim lived in a rented flat with a friend K.; that she voluntarily, and at the invitation of the accused,
moved to [another] flat in Z.; that she lived in that flat together with the accused for about month or month and a
half. There is also no doubt that the accused gave a mobile telephone to the victim so that she could be
contacted by the clients with whom she discussed providing sexual services; that the victim indeed did provide
sexual services in the flat where she lived with the accused; that on five or six occasions the accused drove the
victim to the addresses of clients where she provided sexual services; that the victim charged for providing
sexual services the sum of HRK 400 for half an hour and the sum of HRK 600 for an hour. Moreover, there is
no doubt that on one occasion the victim left the flat where she lived with the accused and went to her friend
M.I.

However, it remains to be established whether the accused forced the victim to provide sexual services – which
she undoubtedly provided – by the use of force or threat of the use of force or by deception, in order to obtain
pecuniary gain.”

79. In reaching the above conclusion, the Municipal Court noted that the decisive evidence on which the indictment
was based was the applicant's witness statement. However, the Municipal Court considered that it could not give
sufficient weight to the applicant's testimony because her statement had been incoherent, in places illogical and
contrary to the evidence given by the witness M.I. and also by T.M. in his defence. Moreover, she had been unsure
and had paused and hesitated when speaking. On the other hand, the Municipal Court considered that it could rely
on the evidence given by M.I. and that it could generally accept T.M.'s defence, despite the fact that he had
changed his statement during the proceedings. The court also considered that T.M.'s denial of the use of any
coercion against the applicant was confirmed by the evidence given by M.I. as regards her knowledge of the
applicant's previous life and the circumstances in which she had engaged in prostitution for T.M.

80. On 26 March 2013 the State Attorney's Office lodged an appeal against the first-instance judgment with the
County Court. It argued that the first-instance court had erred in its factual findings concerning the charges against
T.M. in not accepting the applicant's testimony. The State Attorney's Office considered that her statement had been
coherent, credible, logical and convincing, given that in all relevant parts she had provided a consistent account of
the manner in which T.M. had forced her into prostitution. It also considered that T.M.'s statement could not be
taken as credible and stressed that M.I. did not have direct knowledge of the relevant facts of the case.

81. On 21 January 2014 the County Court dismissed the appeal of the State Attorney's Office and upheld the firstinstance judgment, endorsing the reasoning as well as the facts as established by the Municipal Court.

82. The County Court's judgment was served on the applicant's lawyer on 28 February 2014.
_III. Proceedings before the Constitutional Court_

83. On 31 March 2014 the applicant lodged a constitutional complaint with the Constitutional Court, complaining
about the manner in which the criminal-law mechanisms had been applied in her case. She alleged, in particular,
that the domestic authorities had not properly elucidated all the circumstances of the case relating to her
participation in the prostitution ring organised by T.M. and had allowed that the offence committed by him to remain
unpunished.

84. On 10 June 2014 the Constitutional Court declared the applicant's constitutional complaint inadmissible on the
grounds that the applicant had not had the right to bring a constitutional complaint concerning the criminal
proceedings against T.M. since these proceedings had concerned a criminal charge against him.
_IV. Victim support and assistance provided to the applicant_


-----

85. On 21 December 2012, following an identification process carried out by the Ministry of the Interior, the
applicant was officially given the status of victim of human trafficking by the Office for Human and Minority Rights of
the Government of Croatia (Vlada Republike Hrvatske, Ured za ljudska prava i prava nacionalnih manjina;
hereinafter “the Human Rights Office”; see paragraph 105 below).

86. On the same day the Ministry of the Interior contacted the Croatian Red Cross and its employees informed the
applicant of her rights (safe accommodation, medical check-ups, psycho-social support, legal aid and material
support).

87. The applicant did not wish to exercise the right to safe accommodation since she lived with her mother and
sister. However, in the period between 17 January 2013 and 24 April 2015 the applicant contacted the Red Cross
on several occasions. She received psycho-social support through individual counselling and material support. On
two occasions the Red Cross also organised a dental examination for the applicant, as well as individual
counselling with a psychologist.

88. Further to this the applicant was provided with legal aid by the non-governmental organisation the Rosa Centre
(see paragraph 50 above), whose activities in the field of human trafficking were in part supported by the State.
_V. Other relevant factsA. Complaint concerning the criminal proceedings against T.M._

89. On 13 March 2013 the non-governmental organisation the Rosa Centre complained to the Human Rights Office
that the State Attorney's Office had not pursued the applicant's case diligently by collecting and presenting evidence
capable of elucidating all the circumstances of the case. In this connection, the Rosa Centre stressed that there had
been some inconsistencies in the statements of the applicant and the witness M.I., which required further
clarification. It also submitted that the applicant had later explained that certain inconsistencies in her statement had
been the result of her wish to protect other persons, namely her roommate, her friend M.I. and her mother.

90. The Rosa Centre further argued that the trial court, which had not been bound by the prosecution's legal
classification of the facts, had not reclassified the charges to the basic form of procuring prostitution under Article
195 § 2 and convicted T.M. of that offence. The Rosa Centre also suggested that after the hearing, in an informal
context, the judge conducting the proceedings had said to its lawyer that probably eighty percent of his colleagues
would have convicted T.M. but that he had not considered that T.M. should be convicted as charged by the State
Attorney's Office. On that occasion, the judge had also stated that the State Attorney's Office should have amended
the indictment.

91. The Human Rights Office forwarded this letter to the State Attorney General's Office and asked for the relevant
explanations.

92. In its report of 14 May 2013 the competent State Attorney's Office explained that it had considered the
applicant's statement to be credible and convincing, and that it provided sufficient grounds for T.M.'s conviction
under Article 195 § 3 of the Criminal Code. However, the Municipal Court had not agreed with this assessment and
had acquitted T.M. The State Attorney's Office still believed that the classification of procuring prostitution using
coercion was appropriate and it had therefore lodged an appeal against the first-instance judgment (see paragraph
80 above). In these circumstances, it did not consider that it should have amended the indictment. In any event, it
stressed that if the Municipal Court considered that T.M. should have been convicted of the basic form of the
offence of procuring prostitution under Article 195 § 2 of the Criminal Code, it could have amended the legal
classification of the charges itself.

93. On the basis of this report, on 21 August 2013 the State Attorney General's Office informed the Human Rights
Office of its findings endorsing the assessment of the case by the competent State Attorney's Office.
_B. T.M.'s action concerning the applicant's mother_

94. The case file of the Municipal Court which the Government provided to the Court contains a document
indicating that on 4 September 2012 the Office of the Deputy Prime Minister of Croatia forwarded to the Ministry of
Social Policy and Youth and the Ministry of the Interior a complaint made by T.M. about the alleged mistreatment of


-----

her children by the applicant's mother. The Office of the Deputy Prime Minister asked the relevant ministries to
examine the matter and to report back on their findings. A copy of the Office's request was also sent to T.M.
**RELEVANT LEGAL FRAMEWORK AND PRACTICEI. Relevant domestic lawA. Constitution**

95. The relevant provisions of the Constitution of the Republic of Croatia (Ustav Republike Hrvatske, Official
Gazette no. 56/1990, with further amendments) read as follows:

**Article 23**

“No one shall be subjected to any form of ill-treatment …

Forced or compulsory labour is forbidden.”

**Article 35**

“Everyone shall have the right to respect and legal protection of his or her private and family life, dignity,
reputation and honour.”

**Article 134**

“International agreements in force which have been concluded and ratified in accordance with the Constitution
and made public shall be part of the internal legal order of the Republic of Croatia and shall have precedence
over the [domestic] statutes. …”

_B. Criminal Code_

96. The relevant part of the Criminal Code (Kazneni zakon, Official Gazette no. 110/1997, with further
amendments), as in force at the relevant time, read as follows:

**Trafficking in human beings and slavery**

**Article 175**

“(1) Whoever violates the rules of international law in that he or she by the use of force or of a threat to use
force, by means of fraud, by abduction, by abuse of authority or of a position of helplessness or in any other
manner recruits, buys, sells, hands over, transports, transfers, incites or acts as intermediary in the purchase or
delivery [of a person], or harbours a person for the purposes of slavery or a similar relationship, forced labour,
sexual exploitation, prostitution or illegal human-organ transplant, or who keeps a person in slavery or a similar
condition, shall be punished by imprisonment for one to ten years.

…

(5) The existence of the criminal offence under paragraph (1) … does not depend on whether the person
concerned consented to force labour, servitude, sexual exploitation, slavery or a similar relationship, or illegal
transplant of human organs.”

**Procuring prostitution (Podvođenje)**

**Article 195**

“…

(2) Whoever, for profit, organises or arranges for another person to provide sexual services shall be punished
by imprisonment from six months to three years.

(3) Whoever, for profit, forces or entices a person to provide sexual services by the use of force or the threat of
the use of force or by means of deception shall be punished by imprisonment from one to five years.


-----

(7) It is irrelevant for the existence of the criminal offence under this Article whether the person who was
engaged in prostitution had already practised it.”

97. The relevant provisions of the Criminal Code (Official Gazette nos. 125/2011 and 144/2012) currently in force
read as follows:

**Slavery**

**Article 105**

“(1) Whoever violates the rules of international law in that he or she places another in slavery or a similar
relationship or keeps another in such a position, or buys, sells, transfers or acts as an intermediary in the sale
or transfer of a person or entices another to sell his or her freedom or the freedom of a person whom he or she
is caring for shall be punished by imprisonment for one to ten years.

…”

**Trafficking in human beings**

**Article 106**

“(1) Whoever by the use of force, of threat, of fraud, of deception, of abduction, of the abuse of authority or

[abuse] of a difficult situation, or a dependency relationship, or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, or in any other manner
recruits, transports, transfers, harbours or receives a person or exchanges or transfers the control over a
person for the purpose of exploitation of his or her labour by means of forced labour, servitude, slavery or a
similar relationship, or for his or her exploitation for prostitution or other forms of sexual exploitation including
pornography, or for the purpose of entering an illegal or forced marriage, for the removal of organs, for his or
her participation in armed conflicts, or in order to commit an illegal act shall be punished by imprisonment for
one to ten years.

…

(7) The consent of the victim of trafficking in persons is irrelevant for the existence of the criminal offence in
question.”

**Prostitution**

**Article 157**

“(1) Whoever, for profit or other gain lures, recruits or entices another person to provide sexual services or
organises or arranges for another person to provide sexual services shall be punished by imprisonment for six
month to five years.

(2) Whoever, for profit, by the use of force or threat, deception, fraud, abuse of power or abuse of a difficult
situation or a dependency relationship, forces or entices another person to provide sexual services, or uses
sexual services of such a person for payment and knew or ought to have known of the above-mentioned
circumstances, shall be punished by imprisonment for one to ten years.

…

(3) It is irrelevant for the existence of the criminal offence whether the person who was lured, recruited, enticed
or used for prostitution gave his or her consent or had already engaged in prostitution.”

_C. Code of Criminal Procedure_


-----

98. The relevant provisions of the Code of Criminal Procedure (Zakon o kaznenom postupku, Official Gazette no.
152/2008, with further amendments), as applicable at the relevant time when a particular procedural action was
taken, read as follows:

**Article 2**

“(1) Criminal proceedings shall be instituted and conducted only at the request of a competent prosecutor. …

(2) In respect of criminal offences subject to public prosecution, the competent prosecutor shall be the State
Attorney …

(3) Unless otherwise provided for by law, the State Attorney shall undertake a criminal prosecution where there
is a reasonable suspicion that an identified person has committed a criminal offence subject to public
prosecution and where there are no legal impediments to the prosecution of that person.”

**Article 16**

“(1) In criminal proceedings the victim and injured party shall have the rights provided for in this Code.

(2) The police, investigators, State attorney and court shall act with special care with the victim of the criminal
offence [concerned]. These authorities shall instruct the victim [of his or her rights] under paragraph 3 of this
Article and under Articles 43-46 of this Code and care for the victim's interests when adopting their decisions
concerning the prosecution of the accused or when taking actions within the criminal proceedings in which the
victim has to participate personally.

(3) A victim suffering serious psycho-physical damage or serious consequences of a criminal offence has the
right to the free professional aid of a counsellor in accordance with the law.”

**Article 38**

“(1) The basic power and the main duty of a State attorney shall be the prosecution of the perpetrators of
criminal offences liable to State prosecution.”

**Victim**

**Article 43**

“(1) The victim of a criminal offence shall have:

1. the right to effective psychological and other professional help and to the support of a body or organisation
providing support to the victims of criminal offences in accordance with the law;

2. the right to participate in the criminal proceedings as an injured party;

3. other rights provided for by law.

(2) In accordance with special legislation, the victim of an offence punishable by five or more years'
imprisonment shall have the right:

1. to a legal aid counsellor before being heard in the criminal proceedings and when making a compensation
claim, if he or she suffers serious psycho-physical damage or other serious consequences of the offence;

2. to compensation for pecuniary and non-pecuniary damage from the State fund as provided for in a special
law …

(3) When taking the first action in which the victim participates, the court [conducting the proceedings], a State
Attorney, an investigator and the police shall inform the victim of:


-----

1. his or her rights under subsections 1 and 2 of this Article …

2. of his or her rights [in the proceedings] as an injured party.”

**Article 45**

“(1) The victim of a criminal offence against his or her sexual freedom and morals shall have, in addition to
those under Articles 43 and 44 of this Code, the following rights:

1. to free consultation with a counsellor before giving his or her evidence;

2. to be interviewed by an officer of his or her own gender when interviewed by the police;

3. not to answer a question concerning his or her strictly private life;

4. to ask to give his or her evidence by means of audio-visual equipment as provided for under Article 292(4) of
this Code.

5. to confidentiality of personal data;

6. to request the exclusion of the public from a hearing.

(2) Before the victim gives his or her evidence for the first time, the court [conducting the proceedings], a State
attorney, an investigator and the police shall inform the victim of the criminal offence under paragraph 1 of this
Article of his or her rights under this Article.”

**Article 52**

“(1) The victim shall have the right to point to the relevant facts and to propose evidence necessary for the
establishment of the criminal offence, identification of the perpetrator and establishment of the victim's civil
claim.

(2) At the hearing the victim shall have the right to propose evidence, question the accused, witnesses and
experts and make objections and give explanations concerning their evidence, as well as to give other
statements and requests.

(3) The victim shall have the right to inspect files and examine objects used as evidence …

(4) The State Attorney and the court shall inform the victim of the rights set out in [this Article].”

**Main hearing**

**Article 419**

“(1) The parties shall have the right to propose the questioning of witnesses and experts and the taking and
examination of other evidence. The trial panel can take and examine evidence which the parties have not
proposed, or in respect of which they have withdrawn their proposal, if it considers it to be important for the
establishment of circumstances relating to the exclusion of unlawfulness or guilt or it concerns [the issues of
sanctioning].

(2) … The President of the trial panel shall inform the parties and the injured party that [the court] shall not take
and examine evidence of which the parties were aware before the start of the hearing but for which they have
failed, without justified reason, to make a timely request for examination.”

**Article 441**


-----

“(1) If during the hearing the prosecutor finds that the evidence taken and examined in the proceedings
suggests that the factual circumstances set out in the indictment have changed, he or she can [orally or in
writing] amend the indictment until the end of the proceedings for the taking and examination of evidence.

(2) In order to prepare the amendments to the indictment or to prepare the defence [as appropriate] the parties
may seek adjournment of the trial.”

**Article 449**

“(1) A judgment may refer only to a person who has been indicted and only to the criminal offence which is the
subject of the charges in the [initially lodged] indictment or the indictment amended or extended at a hearing.

(2) The court is not bound by the prosecutor's legal classification of the offence but the accused cannot be held
guilty of a more serious offence than the one he or she has been indicted for.”

_D. Minor offences legislation_

99. The Minor Offences against Public Order and Peace Act (Zakon o prekršajima protiv javnog reda i mira, Official
Gazette no. 5/1990 with further amendments) proscribes acts facilitating prostitution (section 7) and prostitution
itself (section 12). Both offences are punishable by a fine or thirty days' imprisonment.
_E. Compensation for damage_

100. A claim for the compensation in respect of damage resulting from an infringement of rights of personality can
be made under the Civil Obligations Act (Zakon o obveznim odnosima, Official Gazette nos. 35/2005, with further
amendments). Rights of personality within the meaning of that Act are, amongst other, the right to physical and
mental health, reputation, honour, dignity, privacy of personal and family life, liberty (section 19).

101. On 1 July 2013 the Act on Compensation for Damage to Victims of Criminal Offences came into force (Zakon
_o novčanoj naknadi žrtvama kaznenih djela, Official Gazette, no. 80/2008, with further amendments). It provides for_
the possibility for the victims of violent offences and offences against sexual integrity to obtain compensation from
the State of some forms of damage under certain conditions.
_F. Policy documents and activities concerning human trafficking_

102. In May 2002 the Government of Croatia established the National Board for the Suppression of Human
Trafficking as a multidisciplinary inter-departmental body composed of representatives of the relevant authorities
and non-governmental organisations working in the field of human trafficking. The Board is in charge of preparing
programmes, plans and policy guidelines in this field. Within the Board, there is also an Operative Team for the
Suppression of Human Trafficking which ensures the effective functioning and performance of the Board's tasks.

103. Since 2002 the Government have also adopted several National Plans for the Suppression of Human
Trafficking. They are aimed at establishing guidelines and defining policies in particular in relation to the
improvement of the normative framework of human trafficking; ensuring a proactive approach to the identification of
victims of human trafficking; achieving effective coordination between the prosecuting authorities, other State
bodies and civil society; processing of data on cases of human trafficking; raising awareness of and working on the
prevention of human trafficking; and ensuring sufficient financial means for these activities. Under the National Plan,
the Human Rights Office coordinates the activities in the field of human trafficking.

104. In addition, the activities and coordination of the work of the national authorities in the suppression of human
trafficking is based on three specialised protocols: the Protocol on the identification, assistance and protection of
victims of human trafficking (2008); the Protocol on procedures during the voluntary return of victims of human
trafficking (2009); and the Protocol on the integration/reintegration of the victims of human trafficking (2011).

105. The Protocol on the identification, assistance and protection of victims of human trafficking regulates the
procedure for recognition of the status of victim of human trafficking. The identification is carried out by specialised
bodies of the Ministry of the Interior in cooperation with the Red Cross and representatives of civil society. The
decision on identification can be taken by the Ministry of the Interior or the Operative team of the National Board for


-----

the Suppression of Human Trafficking. The Human Rights Office formally certifies the decision on identification. The
purpose of the procedure is to ensure various rights of assistance and protection to the victim.

106. The domestic authorities also cooperate actively with civil society and in particular with the “Petra” network of
non-governmental organisations dealing with the issues of human trafficking and sexual exploitation of women and
children, which is financed by the Human Rights Office. The Rosa Centre is a member of the “Petra” network.
_II. INTERNATIONAL LAW AND PRACTICEA. United Nations instruments1. The 1949 Convention for the_
_Suppression of the Traffic in Persons and the Exploitation of the Prostitution of Others (“the 1949 Convention”)_

107. The 1949 Convention consolidated several treaties adopted between 1904 and 1933. It came into force on 25
July 1951 and was ratified by Croatia on 12 October 1992. In addition to Croatia, it has been ratified by twenty-five
other Council of Europe member States.

108. The relevant parts of the 1949 Convention read as follows:

**Preamble**

“Whereas prostitution and the accompanying evil of the traffic in persons for the purpose of prostitution are
incompatible with the dignity and worth of the human person and endanger the welfare of the individual, the
family and the community,

…”

**Article 1**

“The Parties to the present Convention agree to punish any person who, to gratify the passions of another:

(1) Procures, entices or leads away, for purposes of prostitution, another person, even with the consent of that
person;

(2) Exploits the prostitution of another person, even with the consent of that person.”

**Article 2**

“The Parties to the present Convention further agree to punish any person who:

(1) Keeps or manages, or knowingly finances or takes part in the financing of a brothel;

(2) Knowingly lets or rents a building or other place or any part thereof for the purpose of the prostitution of
others.”

_2. Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children (“the Palermo_
_Protocol”)_

109. The United Nations Convention against Transnational Organized Crime (“UNCTOC”) forms part of the central
legal framework concerning trafficking in persons under international law. It represents the “parent instrument” to a
specialised protocol on the matter, namely the Palermo Protocol.

110. UNCTOC was signed on 12-15 December 2000 and entered into force on 29 September 2003. 189 States are
parties to this Convention. The Palermo Protocol was signed on 15 November 2000 and entered into force on 25
December 2003. 173 States are parties to this Protocol. Both instruments were ratified by Croatia on 24 January
2003.

111. The purpose of UNCTOC is to promote cooperation with a view to preventing and combating transnational
organised crime more efficiently (Article 1). The scope of this Convention is subject to three prerequisites: firstly, the
offence in question must have a transnational aspect, secondly, it must involve an “organized criminal group” and
thirdly, the offence must constitute a “serious crime” (Article 3). However, Article 34 § 2 of UNCTOC provides the
following:


-----

“The offences established in accordance with articles 5, 6, 8 and 23 of this Convention shall be established in
the domestic law of each State Party independently of the translational nature or the involvement of an
organized criminal group as described in article 3, paragraph 1, of this Convention, except to the extent that
article 5 of this Convention would require the involvement of an organized criminal group.”

112. For its part, the Palermo Protocol aims to: (1) prevent and combat trafficking in persons, paying particular
attention to women and children; (2) protect and assist the victims of such trafficking, with full respect for their
human rights; (3) promote cooperation among States Parties in order to meet those objectives (Article 2). The
provisions of UNCTOC apply, mutatis mutandis, to the Palermo Protocol unless provided otherwise (Article 1 § 2).
_(a) Definition of trafficking in human beings_

113. Trafficking in human beings has been defined for the first time under international law in the Palermo Protocol
as follows (Article 3 (a)):

'Trafficking' in persons shall mean the recruitment, transportation, transfer, harbouring or receipt of persons, by
means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse
of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the
consent of a person having control over another person, for the purpose of exploitation. Exploitation shall
include, at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced
labour or services, slavery or practices similar to slavery, servitude or the removal of organs …”

114. The crime of trafficking in persons has three constituent elements: (1) an action (what is done: the recruitment,
transportation, transfer, harbouring or receipt of persons); (2) the means (how it is done: by means of the threat or
use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having control
over another person); (3) an exploitative purpose (why it is done: this includes at a minimum, the exploitation of the
prostitution of others or other forms of sexual exploitation, forced labour or services, slavery or practices similar to
slavery, servitude or the removal of organs). A combination of the three constituent elements is necessary in order
for the crime of trafficking to be established as regards adult victims (UNODC, Combating Trafficking in Persons: A
_Handbook for Parliamentarians, March 2009, No. 16-2009, pp. 13-14)._

115. Article 3 (b) clarifies that if one of the means set forth in Article 3 (a) is used, it is irrelevant whether the person
expressed his/her consent or not. In its Issue Paper _The Role of 'Consent' in the Trafficking in Persons Protocol_
(2014), the United Nations Office on Drugs and Crime (“UNODC”) found that the requirement to show “means”
affirms that, at least within the Protocol, exploitative conditions alone are insufficient to establish trafficking of adults.

116. The terms “exploitation of the prostitution of others” and “sexual exploitation” have been intentionally left
undefined in the Palermo Protocol to allow States, irrespective of their domestic policies on prostitution, to ratify the
Protocol. This was highlighted in the Interpretative notes for the official records (travaux préparatoires) of the
negotiation of the Palermo Protocol in the following manner (paragraph 64, p. 12):

“[T]he Protocol addresses the exploitation of the prostitution of others and other forms of sexual exploitation
only in the context of trafficking in persons and … the terms 'exploitation of prostitution of others' or 'other forms
of sexual exploitation' are not defined in the Protocol, which is therefore without prejudice to how States Parties
address prostitution in their respective domestic laws.”

117. However, in the Model Law against Trafficking in Persons (pp. 13-15 and 19), UNODC defined “exploitation of
prostitution of others” as the unlawful obtaining of financial or other material benefit from the prostitution of another
person. It also defined “sexual exploitation” as the obtaining of financial or other benefits through the involvement of
another person in prostitution, sexual servitude or other kinds of sexual services, including pornographic acts or the
production of pornographic materials. It should also be noted that as regards “forced labour or services”, the
UNODC explained that “initial recruitment can be voluntary and the coercive mechanisms to keep a person in an
exploitative situation may come into play later.”


-----

118. Furthermore, in a document entitled “Joint UN Commentary on the EU Directive – A Human Rights-Based
Approach” (2011), issued by the relevant United Nations bodies (the Office of the High Commissioner for Human
Rights (OHCHR); the UN Refugee Agency (UNHCR); UNICEF; UNODC; UN Women; and the International Labour
Organisation), the following was noted (p. 104):

“Exploitation of prostitution of others and sexual exploitation are not defined in international law. The terms
have been intentionally left undefined in the Protocol in order to allow all States, independent of their domestic
policies on prostitution, to ratify the Protocol. While the Protocol draws a distinction between exploitation for
forced labour or services and sexual exploitation, this should not lead to the conclusion that coercive sexual
exploitation does not amount to forced labour or services, particularly in the context of trafficking. Coercive
sexual exploitation and forced prostitution fall within the scope of the definition of forced labour …”

_(b) Scope of the Palermo Protocol_

119. According to Article 4, the scope of the Palermo Protocol is as follows:

“This Protocol shall apply, except as otherwise stated herein, to the prevention, investigation and prosecution
of the offences established in accordance with article 5 of this Protocol, where those offences are transnational
in nature and involve an organized criminal group, as well as to the protection of victims of such offences.”

120. According to the Model Law against Trafficking in Persons prepared by UNODC (p. 8), although Article 4 limits
its applicability to offences that are transnational in nature and involve an organised criminal group, these
requirements are not part of the definition of the offence and therefore national laws should establish trafficking in
persons as a criminal offence, independently of the transnational nature or the involvement of an organised criminal
group. In this connection, reference is made to Article 34 § 2 of UNCTOC (see paragraph 111 above).
_(c) Relevant State obligations_

121. Article 5 of the Palermo Protocol provides as follows:

“1. Each State Party shall adopt such legislative and other measures as may be necessary to establish as
criminal offences the conduct set forth in article 3 of this Protocol, when committed intentionally.

2. Each State Party shall also adopt such legislative and other measures as may be necessary to establish as
criminal offences:

(a) Subject to the basic concepts of its legal system, attempting to commit an offence established in
accordance with paragraph 1 of this article;

(b) Participating as an accomplice in an offence established in accordance with paragraph 1 of this article; and

(c) Organizing or directing other persons to commit an offence established in accordance with paragraph 1 of
this article.”

122. Article 6 provides for various measures of assistance to and protection of victims of trafficking in persons. In so
far as relevant for the present case, it reads as follows:

“…

2. Each State Party shall ensure that its domestic legal or administrative system contains measures that
provide to victims of trafficking in persons, in appropriate cases:

(a) Information on relevant court and administrative proceedings;

(b) Assistance to enable their views and concerns to be presented and considered at appropriate stages of
criminal proceedings against offenders, in a manner not prejudicial to the rights of the defence.

3. Each State Party shall consider implementing measures to provide for the physical, psychological and social
recovery of victims of trafficking in persons including in appropriate cases in cooperation with non


-----

governmental organizations, other relevant organizations and other elements of civil society, and, in particular,
the provision of:

(a) Appropriate housing;

(b) Counselling and information, in particular as regards their legal rights, in a language that the victims of
trafficking in persons can understand;

(c) Medical, psychological and material assistance; and

(d) Employment, educational and training opportunities.

…

5. Each State Party shall endeavour to provide for the physical safety of victims of trafficking in persons while
they are within its territory.

6. Each State Party shall ensure that its domestic legal system contains measures that offer victims of
trafficking in persons the possibility of obtaining compensation for damage suffered.”

_3. Convention on the Elimination of All Forms of Discrimination against Women (“CEDAW”)_

123. CEDAW was adopted in 1979 by the UN General Assembly and ratified by Croatia on 9 September 1992.
Article 6 reads:

“States Parties shall take all appropriate measures, including legislation, to suppress all forms of traffic in
women and exploitation of prostitution of women.”

124. The CEDAW Committee, in its General recommendation No. 19 on violence against women (1992), held as
follows:

“13. States parties are required by article 6 to take measures to suppress all forms of traffic in women and
exploitation of the prostitution of women.

14. Poverty and unemployment increase opportunities for trafficking in women. In addition to established forms
of trafficking there are new forms of sexual exploitation … [which are] incompatible with the equal enjoyment of
rights by women and with respect for their rights and dignity. They put women at special risk of violence and
abuse.

15. Poverty and unemployment force many women, including young girls, into prostitution. Prostitutes are
especially vulnerable to violence because their status, which may be unlawful, tends to marginalize them. They
need the equal protection of laws against rape and other forms of violence.”

125. In its General recommendation No. 35, which complements and updates its General recommendation No. 19,
the CEDAW Committee held, inter alia, as follows:

“10. The Committee considers that gender-based violence against women is one of the fundamental social,
political and economic means by which the subordinate position of women with respect to men and their
stereotyped roles are perpetuated …

12. In general recommendation No. 28 and general recommendation No. 33, the Committee confirmed that
discrimination against women was inextricably linked to other factors that affected their lives. The Committee,
in its jurisprudence, has highlighted the fact that such factors include women's … being in prostitution, as well
as trafficking in women.

…


-----

32. The Committee recommends that States parties implement the following measures with regard to
prosecution and punishment for gender-based violence against women:

(a) Ensure effective access for victims to courts and tribunals and that the authorities adequately respond to all
cases of gender-based violence against women, including by applying criminal law and, as appropriate, ex
officio prosecution to bring alleged perpetrators to trial in a fair, impartial, timely and expeditious manner and
imposing adequate penalties …”

126. The CEDAW Committee, in its background paper concerning Article 6 summarising the travaux préparatoires
and the jurisprudence of the Committee (CEDAW/2003/II/WP.2), concluded as follows:

“The Committee consistently addressed the issue of prostitution and trafficking in women and girls when
considering the initial and periodic reports of the States parties. In general, the approach taken by the
Committee focused on the need to adopt a comprehensive strategy against the exploitation of prostitution and
trafficking which would include: adoption or review of legislation to de-criminalize prostitutes and impose severe
sanctions to pimps, procurers and traffickers; implementation of measures aimed at improving the economic
situation of women and girls so as to eliminate their vulnerability to prostitution and trafficking; provision of
social support and health-care services to prostitutes; implementation of rehabilitation and reintegration
measures for women and girls who had been victims of trafficking; and training of border police and law
enforcement officials in order that they might recognize and provide support for victims of trafficking. In its
approach, the Committee laid particular emphasis on the need to respect the human rights of prostitutes and
victims of trafficking.”

127. On 28 July 2015 the CEDAW Committee published its concluding observations on the combined fourth and
fifth periodic reports of Croatia (CEDAW/C/HRV/CO/4-5). As regards trafficking and exploitation of prostitution, it
noted as follows:

“20. While the Committee notes with appreciation the legislative and policy measures and programmes aimed
at protecting women and girls who are victims of trafficking, it is concerned:

(a) That perpetrators of trafficking are often charged with offences of pimping rather than the more serious
offence of human trafficking, resulting in a disturbingly low rate of conviction for human trafficking;

(b) That victims of exploitation of prostitution are sometimes prosecuted rather than provided with appropriate
support measures, while persons purchasing sex from victims of forced prostitution and/or victims of trafficking
are not consistently prosecuted and commensurately punished;

(c) That there are inadequate mechanisms for identifying victims of trafficking in situations of heightened risk;

(d) That there are inadequate systems for the collection of disaggregated data on victims of trafficking,
including by sex, age, ethnicity and nationality;

(e) That there are inadequate shelter and training of personnel therein, for victims of trafficking;

(f) That there are inadequate measures to address the specific vulnerabilities and needs of non-national victims
of trafficking.”

128. It therefore recommended, inter alia, that Croatia:

“(a) Ensure that perpetrators of trafficking receive sentences commensurate with the gravity of the offence;

…

(c) Strengthen measures to identify and provide support to women at risk of trafficking …”


-----

129. In 1993 the UN General Assembly adopted, by consensus, the Declaration on the Elimination of Violence
against Women (A/RES/48/104) to complement CEDAW. Article 2(b) of this Declaration underlines that violence
against women shall be understood to encompass, but not be limited to the following:

“Physical, sexual and psychological violence occurring within the general community, including rape, sexual
abuse, sexual harassment and intimidation at work, in educational institutions and elsewhere, trafficking in
women and forced prostitution.”

_4. International Covenant on Civil and Political Rights (“the ICCPR”)_

130. The ICCPR was adopted in 1966 by the UN General Assembly and ratified by Croatia in 1992. Article 8 of the
ICCPR reads, in so far as relevant, as follows:

“1. No one shall be held in slavery; slavery and the slave-trade in all their forms shall be prohibited.

2. No one shall be held in servitude.

3. (a) No one shall be required to perform forced or compulsory labour.”

131. In its General Comment no. 28 on Equality of rights between men and women (CCPR/C/21/Rev.1/Add.10), the
Human Rights Committee (“the HRC”) held that States parties should inform the Committee of measures taken to
eliminate trafficking of women and children, within the country or across borders, and forced prostitution.

132. On 30 April 2015 the HRC published its concluding observations on the third periodic report of Croatia
(CCPR/C/HRV/CO/3). As regards trafficking, it held as follows:

“The Committee takes note of reports indicating retrogression with regard to measures taken to combat
trafficking in persons. The Committee is also concerned that trafficking in persons persists in the State party.
The Committee is further concerned about the small number of prosecutions and the leniency of the sentences
imposed on traffickers (art. 8).

The State party should vigorously pursue its public policy to combat trafficking. It should continue its efforts to
raise awareness of and combat trafficking in persons, including at the regional level and in cooperation with
neighbouring countries. The State party should train its police officers, border control personnel, judges,
lawyers and other relevant personnel in order to raise awareness of the matter and of the rights of victims. It
should ensure that all individuals responsible for trafficking in persons are prosecuted and punished
commensurately with the crimes committed, and that victims of trafficking are compensated and rehabilitated.
Furthermore, the State party should step up its efforts to identify victims of trafficking and ensure the systematic
collection of data on trafficking, which should be disaggregated by age, sex and ethnic origin and should also
be focused on trafficking flows from, to and through its territory.”

_5. Recommended Principles and Guidelines on Human Rights and Human Trafficking_

133. In 2002 the High Commissioner for Human Rights issued Recommended Principles and Guidelines on Human
Rights and Human Trafficking (E/2002/68/Add.1), which adopted a rights-based approach to human trafficking.

134. As regards the primacy of human rights, the Recommended Principles underline that States have a
responsibility under international law to act with due diligence to prevent trafficking, to investigate and prosecute
traffickers and to assist and protect trafficked persons (Principle 2).

135. As to protection and assistance, Principle 9 requires that legal and other assistance be provided to trafficked
persons for the duration of any criminal, civil or other actions against suspected traffickers.

136. In so far as criminalisation and punishment are concerned, Principle 13 provides that States must “effectively
investigate, prosecute and adjudicate trafficking, including its component acts and related conduct”.
_6. Special Rapporteur on trafficking in persons, especially women and children_


-----

137. In her annual report to the Human Rights Council, in 2006, the Special Rapporteur Sigma Huda focused on
demand for commercial sexual exploitation and trafficking. In particular, she noted as follows:

“41. The Protocol [Palermo] does not necessarily require States to abolish all possible forms of prostitution. It
does, however, require States to act in good faith towards the abolition of all forms of child prostitution and all
forms of adult prostitution in which people are recruited, transported, harboured, or received by means of the
threat or use of force, or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or
of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of one
person having control over another, for the purpose of exploiting that person's prostitution.

42. For the most part, prostitution as actually practiced in the world usually does satisfy the elements of
trafficking. It is rare that one finds a case in which the paths to prostitution and/or a person's experience within
prostitution do not involve, at the very least, an abuse of power and/or an abuse of vulnerability. Power and
vulnerability in this context must be understood to include power disparities based on gender, race, ethnicity
and poverty. Put simply, the road to prostitution and life within “the life” is rarely one marked by empowerment
or adequate options.

43. Thus, State parties with legalized prostitution industries have a heavy responsibility to ensure that the
conditions which actually pertain to the practice of prostitution within their borders are free from the illicit means
delineated in subparagraph (a) of the Protocol definition, so as to ensure that their legalized prostitution
regimes are not simply perpetuating widespread and systematic trafficking. As current conditions throughout
the world attest, States parties that maintain legalized prostitution are far from satisfying this obligation.”

138. In her annual report to the Human Rights Council, in 2012, the Special Rapporteur Joy Ngozi Ezeilo focused
on integration of a human rights-based approach in the prosecution of cases of human trafficking. In particular, she
noted as follows:

“31. Timely and efficient identification of victims is central to the criminalization of trafficking, as it affects the
ability of law enforcement officials to prosecute traffickers effectively and is fundamental in terms of being able
to provide trafficked persons with the necessary support services. The Special Rapporteur observes, however,
that the issue of identification raises a number of complex pragmatic questions, in particular concerning how,
where and by whom identification should be performed.

…

34. Police are often at the forefront when identifying victims, and thus play a critical role in this process. While
they may be experienced in law enforcement in general, they may not have specific expertise in trafficking in
persons; for this reason, the Special Rapporteur highlights the importance of ensuring that they are given
appropriate training to identify victims of trafficking accurately and with sensitivity.

…

57. Proactive investigations that seek to collect evidence to obviate or support victim testimony are another
way for States to realize their due diligence obligation to prosecute trafficking without unduly burdening victims.
The Special Rapporteur notes that alternative or corroborative evidence may be difficult to collect in trafficking
cases because of limited resources and a lack of trained officials, particularly in States most affected by
trafficking. The situation may also be compounded by the hidden nature of the crime and the lack of concrete
records or indicators of criminal activity. It is important to acknowledge that substituting victim testimony with
alternative evidence may not allow for full and effective prosecution. Nevertheless, the added value of such
evidence merits attention, not least because the discovery of additional or corroborative evidence may alleviate
some of the pressure put on victims during the prosecution process.”

_B. International Labour Organisation (“the ILO”)_


-----

139. The ILO has adopted two conventions on forced labour, namely the 1930 Forced Labour Convention
(“Convention No. 29”) and the 1957 Abolition of Forced Labour Convention (“Convention No. 105”), which were
ratified by Croatia on 8 October 1991 and 5 March 1997 respectively.

140. In 2014 two new instruments were adopted by the ILO with a view to providing a comprehensive strategy
against all forms of forced labour, including trafficking in persons, namely the Protocol to Convention No. 29 and
Recommendation 203 on Supplementary Measures for the Effective Suppression of Forced Labour.
_1. Forced or compulsory labour according to Convention No. 29_

141. Convention No. 29 requires ratifying States to suppress all forms of forced or compulsory labour. Article 2(1)
reads as follows:

“For the purposes of this Convention the term forced or compulsory labour shall mean all work or service which
is exacted from any person under the menace of any penalty and for which the said person has not offered
himself voluntarily.”

142. The definition consists of three elements: (1) work or service – this refers to all types of work, service and
employment, occurring in any activity, industry or sector, including in the informal economy. Forced labour can
occur in both the public and private sectors; (2) menace of a penalty – this refers to a wide range of penalties used
to compel someone to perform work or service, including penal sanctions and various forms of direct or indirect
coercion such as physical violence, psychological threats or the non-payment of wages. The “penalty” may also
consist of a loss of rights or privileges; and (3) involuntariness – the term “offered voluntarily” refer to the free and
informed consent of a worker to enter into an employment relationship and his or her freedom to leave the
employment at any time. For example, an employer or recruiter could interfere with this freedom by making false
promises to induce a worker to take a job that he or she would not otherwise have accepted (ILO, Standards on
_Forced Labour: the New Protocol and Recommendation at a glance (2016), p. 5)._

143. The ILO's Special Action Programme to Combat Forced Labour has devised eleven indicators of forced
labour. They are: (1) abuse of vulnerability, (2) deception, (3) restriction of movement, (4) isolation, (5) physical and
sexual violence, (6) intimidation and threats, (7) retention of identity documents, (8) withholding of wages, (9) debt
bondage, (10) abusive working and living conditions, and (11) excessive overtime. It has been suggested that the
presence of a single indicator in a given situation may in some cases imply the existence of forced labour but that in
others it may be several indicators, which, taken together, point to a forced labour practice.

144. However, the ILO has stressed that “forced labour” encompasses activities which are more serious than the
mere failure to respect labour laws and working conditions. For example, the failure to pay a worker the statutory
minimum wage does not in itself constitute forced labour (ILO, Human Trafficking and Forced Labour Exploitation:
_Guidance for Legislation and Law Enforcement (2005), pp. 19-21)._

145. The Committee of Experts which monitors the implementation of the ILO Conventions has considered the
following concerning the link between human trafficking and trafficking-related conduct and forced or compulsory
labour (ILO, _Report of the ILO Committee of Experts on the Application of Conventions and Recommendations,_
Report III (Part IB), p. 41):

“77. A crucial element of the definition of trafficking is its purpose, namely, exploitation, which is specifically
defined to include forced labour or services, slavery or similar practices, servitude and various forms of sexual
exploitation. The notion of exploitation of labour inherent in this definition allows for a link to be established
between the Palermo Protocol and Convention No. 29 and makes clear that trafficking in persons for the
purpose of exploitation is encompassed by the definition of forced or compulsory labour provided under Article
2, paragraph 1, of the Convention.

78. While a certain distinction has been drawn in the above definition between trafficking for forced labour or
services and trafficking for sexual exploitation, this should not lead to a conclusion that coercive sexual
exploitation does not amount to forced labour or services, particularly in the context of human trafficking. The
inclusion of 'exploitation for the prostitution of others' may create difficulties in this since, since there is no duty


-----

to criminalize prostitution, either under the Palermo Protocol, or under Convention No. 29, and consequently
prostitution and related matters falling outside the scope of trafficking in persons should be dealt with by
individual countries in accordance with their national laws and policies. Nonetheless, it seems clear that
coercive sexual exploitation and forced prostitution do come within the scope of the definition of forced or
compulsory labour in Article 2, paragraph 1, of the Convention.”

146. In this connection, it is also worth mentioning that the European Commission, together with the ILO, developed
the _Operational Indicators of Trafficking in Human Beings, which provide for three different indicators (strong,_
medium and weak) applied to each of the elements of the trafficking definition (act, means and purpose).

147. In its Direct request to Croatia on the application of Convention No. 29, adopted in 2018, the Committee of
Experts held, inter alia, as follows:

“The Committee … requests the Government to take the necessary measures to ensure that investigations and
prosecutions are carried out against perpetrators of trafficking in persons.

…

The Committee … requests the Government to strengthen its efforts with regard to the identification of victims
of trafficking for purposes of both sexual and labour exploitation, and to take the necessary measures to ensure
that appropriate protection and assistance is provided to such victims. The Committee also requests the
Government to provide information on the measures taken and the results achieved in this regard.”

_2. Protocol to Convention No. 29_

148. The Protocol to Convention No. 29 aims to address various gaps in the implementation of that Convention by
reaffirming that measures of prevention, protection and remedies are necessary to achieve the effective and
sustained suppression of forced or compulsory labour. Croatia has not yet ratified this Protocol.

149. In particular, the preamble to the Protocol recognises the following:

“[T]he context and forms of forced or compulsory labour have changed and trafficking in persons for the
purposes of forced or compulsory labour, which may involve sexual exploitation, is the subject of growing
international concern and requires urgent action for its effective elimination …”

150. Article 1 reads, in so far as relevant, as follows:

“1. In giving effect to its obligations under the Convention to suppress forced or compulsory labour, each
Member shall take effective measures to prevent and eliminate its use, to provide to victims protection and
access to appropriate and effective remedies, such as compensation, and to sanction the perpetrators of
forced or compulsory labour.

…

3. The definition of forced or compulsory labour contained in the Convention is reaffirmed, and therefore the
measures referred to in this Protocol shall include specific action against trafficking in persons for the purposes
of forced or compulsory labour.”

151. Article 3 reads:

“Each Member shall take effective measures for the identification, release, protection, recovery and
rehabilitation of all victims of forced or compulsory labour, as well as the provisions of other forms of assistance
and support.”

_C. Council of Europe1. Convention on Action against Trafficking in Human Beings (“the Anti‑Trafficking_

_Convention”)_


-----

152. The Anti-Trafficking Convention entered into force on 1 February 2008. It was ratified by Croatia on 5
September 2007.

153. The Anti-Trafficking Convention is a comprehensive treaty which aims to prevent and combat trafficking in
human beings, while guaranteeing gender equality; to protect the human rights of the victims of trafficking, design a
comprehensive framework for the protection and assistance of victims and witnesses, while guaranteeing gender
equality, as well as to ensure effective investigation and prosecution; and to promote international cooperation on
action against trafficking in human beings (Article 1).

154. Article 39 of the Anti-trafficking Convention underlines that it does not affect the rights and obligations deriving
from the Palermo Protocol, that it was intended to enhance the protections afforded by the Protocol and to develop
the standards contained therein.
_(a) Definition of trafficking in human beings_

155. The definition of trafficking in human beings under Article 4 (a) is identical to Article 3 (a) of the Palermo
Protocol and consists of the same three components (see paragraph 113 above).

156. In the Explanatory report to the Anti-Trafficking Convention it is underlined that trafficking in human beings is a
combination of these constituents and not the constituents taken in isolation. Thus, as in the Palermo Protocol, for
there to be trafficking in adult human beings, ingredients from each of the three categories must be present
together.

157. As regards terminology, the Explanatory report clarifies that “recruitment” includes recruitment by using new
information technologies like the Internet (see further, the Council of Europe publication “Trafficking in human
beings: Internet recruitment Misuse of the Internet for the recruitment of victims of trafficking in human beings” EGTHB-INT (2007) 1), and that “transport” does not need to be across a border to be a constituent of trafficking in
human beings.

158. It also highlights the fact that fraud and deception are frequently used by the traffickers, as when victims are
led to believe that an attractive job awaits them rather than the intended exploitation. The term “abuse of
vulnerability” means “abuse of any situation in which the person involved has no real and acceptable alternative to
submitting to the abuse”. It this connection it is further held as follows:

“The vulnerability may be of any kind, whether physical, psychological, emotional, family-related, social and
economic. The situation might, for example, involve insecurity or illegality of the victim's administrative status,
economic dependence or fragile health. In short, the situation can be any hardship in which a human being is
impelled to accept being exploited.”

159. The terms “exploitation of the prostitution of others” and “other forms of sexual exploitation” are not defined in
the Anti-Trafficking Convention. The Explanatory report underlines that this is so as not to prejudice how State
parties deal with prostitution in domestic law.

160. Article 4 (b) reads as follows:

“The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used.”

161. According to the Explanatory report the approach adopted in Article 4 (b) is in line with the approach to
consent in the Court's case-law.

162. The scope of the Anti-Trafficking Convention is clearly meant to include “all forms of trafficking in human
beings, whether national or transnational, whether or not connected with organized crime” (Article 2).
_(b) Identification of and assistance to victims_

163. Chapter III concerns measures to protect and promote the rights of victims. In particular, Article 10(1) on
identification of the victims reads as follows:


-----

“Each Party shall provide its competent authorities with persons who are trained and qualified in preventing and
combating trafficking in human beings, in identifying and helping victims, including children, and shall ensure
that the different authorities collaborate with each other as well as with relevant support organisations, so that
victims can be identified in a procedure duly taking into account the special situation of women and child
victims and, in appropriate cases, issued with residence permits under the conditions provided for in Article 14
of the present Convention.”

164. The Explanatory report to the Anti-Trafficking Convention clarifies that the competent authorities involved in
the identification process need not be specialists in human trafficking matters but that they must have the necessary
training and qualifications to be able to identify victims.

165. Further, Articles 11-16 of the Anti-Trafficking Convention provide for further measures of assistance and
protection of victims: protection of their private life; psychological, social and legal assistance to victims; recognition
of a recovery and reflection period for the victim to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the authorities; granting of residence permits in some instances; providing for
the possibility of compensation and legal redress; and measures to facilitate the repatriation and return of victims.
_(c) Provisions related to substantive criminal law, investigation, prosecution and procedural law_

166. Chapters IV and V of the Anti-Trafficking Convention contain a series of obligations on States with a view to
enabling the effective investigation and prosecution of traffickers, including the attribution of proportionate and
dissuasive sanctions.

167. Article 18 is identical to Article 5 of the Palermo Protocol and provides that States shall adopt such legislative
and other measures as may be necessary to establish as criminal offences the conduct contained in Article 4 of this
Convention, when committed intentionally. Article 23 provides for the necessity of introducing effective,
proportionate and dissuasive sanctions and measures.

168. Article 27(1), concerning prosecution, reads as follows:

**“Each Party shall ensure that investigations into or prosecution of offences established in accordance with this**
Convention shall not be dependent upon the report or accusation made by a victim, at least when the offence
was committed in whole or in part on its territory.”

169. Other relevant procedural issues are regulated in Articles 28 and 30, and concern the protection of victims,
witnesses and collaborators with the judicial authorities and the protection of victims during court proceedings.
_(d) Monitoring_

170. Chapter VII of the Anti-Trafficking Convention provides for the establishment of a monitoring mechanism that
will supervise its implementation by the member States. It consists of two pillars: (1) the Group of Experts on Action
against Trafficking in Human Beings (“GRETA”) – a group of independent experts, and (2) the Committee of the
Parties – a political body composed of the representatives of all States parties to the Convention.

171. Following the first evaluation round of the Convention, GRETA devoted a part, in its 4th General Report
(2015), to stock-taking. It noted, inter alia, as regards investigation, prosecutions and sanctions on human trafficking
cases, as follows:

“One of the purposes of the Convention is to ensure the effective investigation and prosecution of trafficking
offences. GRETA's evaluation of 35 parties to the Convention reveals that there is an important gap between
the number of identified victims of trafficking and the number of convictions. GRETA's reports refer to a variety
of reasons for this gap: over-reliance of victims' statements, issues around credibility of witnesses who may
change their statements over time, or difficulties in relation to the sufficiency of evidence …

Investigators, prosecutors and judges who are not specialized and trained to deal with trafficking cases may be
prejudiced vis-à-vis victims of trafficking and insensitive to the problems experienced by them.


-----

GRETA has urged 17 countries to address gaps in the investigation and the presentation of trafficking in
human being cases in court with a view to improving the conviction rate and securing sentences proportionate
to the seriousness of the crime. In this context, GRETA has stressed the need to improve the training and
specialization of judges, prosecutors, police investigators and lawyers regarding trafficking in human beings
and the rights of victims of trafficking, stressing the severe impact of exploitation on victims and the importance
of ensuring that victims are prepared psychologically before they give statements.”

172. Croatia has been subject to two rounds of evaluations by GRETA. In its second evaluation report published on
4 February 2016 GRETA considered that since the adoption of its first report on Croatia in 2011, progress had been
made in a number of areas but that there remained some issues which gave rise to concern. It therefore urged the
Croatian authorities, inter alia, as follows:

“[T]ake additional steps to ensure that all victims of trafficking are identified as such and can benefit from the
assistance and protection measures contained in the Convention, in particular by:

  - taking steps so that law enforcement officials, social workers, NGOs and other relevant actors adopt a more
proactive approach and increase their outreach work to identify victims of human trafficking for the purpose of
sexual exploitation;

   - to take additional legislative and practical measures to ensure that:

   - trafficking in human beings cases are investigated proactively, prosecuted successfully and lead to effective,
proportionate and dissuasive sanctions;

   - the offence of trafficking in human beings is excluded from the plea bargaining procedure.”

_2. Relevant material of the Committee of Ministers and the Parliamentary Assembly_

173. In Recommendation 1325 (1997) on traffic in women and forced prostitution in Council of Europe member
States, the Parliamentary Assembly, defined traffic in women and forced prostitution as follows:

“2. … [A]ny legal or illegal transporting of women and/or trade in them, with or without their initial consent, for
economic gain, with the purpose of subsequent forced prostitution, forced marriage, or other forms of forced
sexual exploitation. The use of force may be physical, sexual and/or psychological, and includes intimidation,
rape, abuse of authority or a situation of dependence.”

174. Considering trafficking in women and forced prostitution to be a form of inhuman and degrading treatment and
a flagrant violation of human rights, it recommended that the Committee of Ministers elaborate a convention on
traffic in women and forced prostitution.

175. The Committee of Ministers in its Recommendation No. R (2000) 11 on action against trafficking in human
beings for the purpose of sexual exploitation, noted that trafficking in human beings for the purpose of sexual
exploitation, which mainly concerned women and young persons, might result in slavery for the victim and
recommended, _inter alia, that member States review their legislation and practice in line with the measures_
described in the appendix to the recommendation.

176. In Recommendation Rec (2002) 5 on the protection of women against violence, the Committee of Ministers
reminded States, inter alia, of their obligation to exercise due diligence to prevent, investigate and punish acts of
violence, whether those acts were perpetrated by the State or private persons, and provide protection to victims. In
its appendix, it is underlined that the term “violence against women” encompasses, amongst other things, instances
of trafficking in women for the purposes of sexual exploitation.

177. The Parliamentary Assembly in its Recommendation 1545 (2002) on a campaign against trafficking in women
noted that “in European societies trafficking is a very complex subject which is closely linked to prostitution and
hidden forms of exploitation, such as domestic slavery, catalogue marriages and sex tourism”. It therefore called on
all European countries to develop common policies and actions covering all aspects of this problem, such as
introducing effective punishment of traffickers


-----

178. In its Recommendation 1815 (2007) entitled “Prostitution – which stance to take?”, the Parliamentary
Assembly underlined that all necessary measures must be taken to combat forced prostitution and trafficking in
human beings. It further noted as follows:

“Regarding adult voluntary prostitution, the Assembly encourages the Committee of Ministers to recommend
that Council of Europe member states formulate an explicit policy on prostitution. In particular, they must avoid
double standards and policies which criminalise and penalise prostitutes.”

179. On 11 June 2008, in its reply to the Parliamentary Assembly Recommendation 1815 (2007), the Committee of
Ministers noted as follows:

“[T]he approaches adopted in the 47 member states of the Council of Europe vary widely in this field. For this
reason, a common policy on prostitution can only be formulated with great difficulty at this stage …”

180. Finally, in its Resolution 1983 (2014) on prostitution, trafficking and **_modern slavery, the Parliamentary_**
Assembly expressed, inter alia, the following views:

“3. Although they are distinct phenomena, trafficking in human beings and prostitution are closely linked. It is
estimated that 84% of trafficking victims in Europe are forced into prostitution; similarly, victims of trafficking
represent a large share of sex workers … [C]onsidering the significant overlap between the two phenomena,
the Assembly believes that legislation and policies on prostitution are indispensable anti-trafficking tools.

…

5. Legislation and policies with regard to prostitution vary across Europe, ranging from legalisation to
criminalisation of prostitution-related activities. …

6. Forced prostitution and sexual exploitation should be considered as violations of human dignity and, as
women are disproportionately represented among victims, as an obstacle to gender equality.

…

8. The Assembly acknowledges that different legal approaches and cultural sensitivities make it difficult to
propose a single model of prostitution regulations that would fit all member States. It believes, however, that
human rights should be the main criteria in designing and implementing policies on prostitution and trafficking.

9. Irrespective of the model chosen, legislators and law-enforcement officials should be aware of their
responsibility to ensure that sex workers, where prostitution is legalised or tolerated, may carry out their activity
in dignified conditions, free from coercion and exploitation, and that the protection needs of those who are
victims of trafficking can be adequately identified and addressed.

11. Furthermore, in all cases, the authorities should refrain from considering prostitution regulations as a
substitute for comprehensive action aimed specifically at human trafficking, based on a sound legal and policy
framework and implemented effectively …

12. In the light of these considerations, the Assembly calls on Council of Europe member … States … to:

…

12.1.3. criminalise pimping, if they have not already done so;”

_D. Other international instruments1. International humanitarian law_

181. Article 27 of the Geneva Convention (IV) relative to the Protection of Civilian Persons in Time of War, 12
August 1949, reads, inter alia, as follows:

“Women shall be especially protected against any attack on their honour, in particular against rape, enforced
prostitution or any form of indecent assault ”


-----

182. In its commentary, “enforced prostitution” is defined as “the forcing of a woman into immorality by violence or
threats”.

183. Likewise, Article 75(2)(b) of Protocol Additional (I) to the Geneva Conventions relating to the Protection of
Victims of International Armed Conflicts and Article 4(2)(e) of Protocol Additional (II) to the Geneva Conventions

relating to the Protection of Victims of Non‑International Armed Conflicts (8 June 1977), prohibit enforced

prostitution at any time and in any place whatsoever.

184. Article 7(1)(g) of the Rome Statute of the International Criminal Court of 17 July 1998 included “enforced
prostitution” as a crime against humanity. The Rome Statute Elements of Crimes define this concept in the following
manner:

“1. The perpetrator caused one or more persons to engage in one or more acts of a sexual nature by force, or
by threat of force or coercion, such as that caused by fear of violence, duress, detention, psychological
oppression or abuse of power, against such person or persons or another person, or by taking advantage of a
coercive environment or such person's or persons' incapacity to give genuine consent.

2. The perpetrator or another person obtained or expected to obtain pecuniary or other advantage in exchange
for or in connection with the acts of a sexual nature.

3. The conduct was committed as part of a widespread or systematic attack directed against a civilian
population.

4. The perpetrator knew that the conduct was part of or intended the conduct to be part of a widespread or
systematic attack directed against a civilian population.”

_2. The Organisation for Security and Co-operation in Europe (“the OSCE”)_

185. On 3 December 2003 the OSCE's Ministerial Council adopted Decision No. 2/03 on Combatting Trafficking in
Human Beings in which it endorsed the OSCE Action Plan to Combat Trafficking in Human Beings and decided to
establish an OSCE mechanism to provide assistance to participating States to combat trafficking in human beings.
As a result, a Special Representative and Co-ordinator for Combating Trafficking in Human Beings was established.

186. The Action Plan, which is based on the Palermo Protocol definition of trafficking in persons, intends to provide
participating States with a comprehensive toolkit to help them implement their commitments to combating trafficking
in human beings. In this respect, it requires at the national level, for example, the following:

“2.7 Encouraging investigators and prosecutors to carry out investigations and prosecutions without relying
solely and exclusively on witness testimony. Exploring alternative investigative strategies to preclude the need
for victims to be required to testify in court.”

187. In 2013 an Addendum to the OSCE Action Plan was adopted by the Ministerial Council Decision No. 7/13. The
Addendum aimed to address the current and emerging trends and patterns in trafficking in human beings, as well
as the most pressing challenges relating to the prosecution of the crime, its prevention, and the protection of
trafficked persons. In this connection, it held, in particular, that recommended action at the national level included:

“1.2 Enhancing the criminal justice responses to human trafficking, including the prosecution of traffickers and
their accomplices, while ensuring that victims are treated in a manner that respects their human rights and
fundamental freedoms and that they are provided with access to justice, to legal assistance and to effective
remedies and other services as applicable.

…

1.1. … [R]elevant State authorities identify individuals as trafficked persons, who have suffered human rights
abuses, as soon as there are reasonable grounds to believe that they have been trafficked, and, in accordance
with national law, ensure that victims of trafficking in human beings are provided with assistance even before
the in estigation is initiated ”


-----

_E. Relevant regional instruments1. Inter-American system_

188. Article 6 of the American Convention on Human Rights (“the ACHR”) guarantees “Freedom from Slavery” and
reads, insofar as relevant, as follows:

“1. No one shall be subject to slavery or to involuntary servitude, which are prohibited in all their forms, as are
the slave trade and traffic in women.

2. No one shall be required to perform forced or compulsory labor …”

189. Another key instrument is the Inter-American Convention on the Prevention, Punishment and Eradication of
Violence against Women (“Convention of Belem Do Para”). Article 2 of this Convention states that:

“Violence against women shall be understood to include physical, sexual and psychological violence:

…

b. that occurs in the community and is perpetrated by any person, including, among others, rape, sexual abuse,
torture, trafficking in persons, forced prostitution, kidnapping and sexual harassment in the workplace, as well
as in educational institutions, health facilities or any other place …”

190. On 20 October 2016 the Inter-American Court of Human Rights (“the Inter-American Court”) adopted a
judgment on Article 6 of the ACHR in the case of _Trabjadores de la hacienda Brasil verde v. Brasil, which_
concerned a group of workers allegedly subjected to trafficking in human beings, forced labour, debt bondage and
slavery in a privately-owned cattle ranch. The Inter-American Court expanded on the content and scope of the
concepts of slavery, servitude, slave trade and traffic in women, as well as forced labour. It recalled, in particular,
that the ACHR used the expression “slave trade and traffic in women”. However, it stressed that, considering the
evolution of international law, the most favourable interpretation and the pro persona principle, that expression was
to be understood as “trafficking in persons”, which would also bring its current definition into line with the Palermo
Protocol.

191. On 26 September 2018, in the case of López Soto y otros v. Venezuela, the Inter-American Court found, inter
_alia, a violation of Article 6 of the ACHR in relation to the deprivation of liberty of a woman by a private individual_
who had subjected her to various acts of physical and psychological violence, notably, of a sexual nature. For the
Inter-American Court, this conduct amounted to sexual slavery.
_2. African system_

192. Article 5 of the African Charter on Human and Peoples' Rights reads:

“Every individual shall have the right to the respect of the dignity inherent in a human being and to the
recognition of his legal status. All forms of exploitation and degradation of man, particularly slavery, slave trade,
torture, cruel, inhuman or degrading punishment and treatment shall be prohibited.”

193. In its General Comment No. 4 on the African Charter on Human and Peoples' Rights: The Right to Redress for
Victims of Torture and Other Cruel, Inhuman or Degrading Punishment or Treatment, the African Commission on
Human and Peoples' Rights held, inter alia, that:

“57. Acts of sexual and gender based violence, or the failure by States to prevent and respond to such acts,
may amount to torture and other ill-treatment in violation of Article 5 of the African Charter…

58. These include physical and psychological acts committed against victims without their consent or under
coercive circumstances, such as … trafficking for sexual exploitation, enforced prostitution, sexual slavery,
sexual exploitation … These acts may occur in public or private and include force or coercion caused by fear of
violence, duress, detention, psychological oppression or abuse of power.”


-----

194. Article 4 of the Protocol to the African Charter on Human and Peoples' Rights on the Rights of Women in
Africa requires States to prevent and condemn trafficking in women, prosecute the perpetrators of such trafficking
and protect those women most at risk.
_III. EUROPEAN UNION LAWA. Primary law_

195. Article 83(1) of the Treaty on the Functioning of the European Union (“the TFEU”) reads, inter alia, as follows:

“1. The European Parliament and the Council may, by means of directives adopted in accordance with the
ordinary legislative procedure, establish minimum rules concerning the definition of criminal offences and
sanctions in the areas of particularly serious crime with a cross-border dimension resulting from the nature or
impact of such offences or from a special need to combat them of a common basis.

These areas of crime are the following: … trafficking in human beings and sexual exploitation of women and
children …”

196. In addition, Article 79(1) of the TFEU requires the Union to develop a common immigration policy aimed at the
prevention of, and enhanced measures to combat illegal immigration and trafficking in human beings.

197. Article 5 of the Charter of Fundamental Rights of the European Union is worded as follows:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. Trafficking in human beings is prohibited.”

198. According to the Explanations relating to the Charter, the right in paragraphs 1 and 2 of Article 5 corresponds
to paragraphs 1 and 2 of Article 4 of the Convention and that therefore it has the same meaning and scope as set
out therein. As regards paragraph 3 of Article 5 it states as follows:

“Paragraph 3 stems directly from human dignity and takes account of recent developments in organized crime,
such as the organisation of lucrative illegal immigration or sexual exploitation networks. The Annex to the
Europol Convention contains the following definition which refers to trafficking for the purpose of sexual
exploitation: 'traffic in human beings: means subjection of a person to the real and illegal sway of other persons
by using violence or menaces or by abuse of authority or intrigue with a view to the exploitation of prostitution,
forms of sexual exploitation and assault of minors or trade in abandoned children'. … On 19 July 2002, the
Council adopted a framework decision on combating trafficking in human beings (OJ L 203, 1.8.2002, p. 1)
whose Article 1 defines in detail the offences concerning trafficking in human beings for the purposes of labour
exploitation or sexual exploitation, which the Member States must make punishable by virtue of that framework
decision.”

_B. Secondary legislation1. Directive 2011/36/EU of the European Parliament and of the Council of 5 April 2011 on_

_preventing and combating trafficking in human beings and protecting its victims (“the Anti‑trafficking Directive”)_

199. The Anti‑Trafficking Directive aims to prevent trafficking, to effectively prosecute criminals and to protect the

victims. In this regard, the recitals to the Anti-Trafficking Directive underline the following:

“(1) Trafficking in human beings is a serious crime, often committed within the framework of organised crime, a
gross violation of fundamental rights and explicitly prohibited by the Charter of Fundamental Rights of the
European Union. Preventing and combating trafficking in human beings is a priority for the Union and the
Member States.

…

(18) It is necessary for victims of trafficking in human beings to be able to exercise their rights effectively.
Therefore assistance and support should be available to them before, during and for an appropriate time after


-----

criminal proceedings. Member States should provide for resources to support victim assistance, support and
protection.”

200. As regards the definition of trafficking in human beings, Article 2 of the Directive, in so far as relevant, reads as
follows:

“1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or transfer
of control over those persons, by means of the threat or use of force or other forms of coercion, of abduction, of
fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of
payments or benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation.

2. A position of vulnerability means a situation in which the person concerned has no real or acceptable
alternative but to submit to the abuse involved.

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, including begging, slavery or practices similar to slavery, servitude, or
the exploitation of criminal activities, or the removal of organs.

4. The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual, shall be
irrelevant where any of the means set forth in paragraph 1 has been used.”

201. Article 4 of the Anti-Trafficking Directive stipulates, in so far as relevant, that the relevant offence under Article
2 is punishable by a maximum penalty of at least five years, or in some instances ten years, of imprisonment.

202. As regards the investigation and prosecution of the crime of trafficking in human beings, Article 9 of the AntiTrafficking Directive reads:

“1. Member States shall ensure that investigation into or prosecution of offences referred to in Articles 2 and 3
is not dependent on reporting or accusation by a victim and that criminal proceedings may continue even if the
victim has withdrawn his or her statement.”

203. In addition, Articles 11 and 12 provides for various measures of assistance and support to be provided to
victims of trafficking in human beings and their protection in criminal investigations and proceedings.

204. Article 18 of the Anti-Trafficking Directive requires that Member States promote regular training for officials
likely to come into contact with victims or potential victims of trafficking in human beings so that they can identify
and deal with such victims and potential victims.

205. In accordance with the requirements of the Anti-Trafficking Directive (Articles 20, 23(1)-(2)), the European
Commission, following the adoption of the Directive, has provided the European Parliament and the Council with a
number of reports.

206. In its first report on the progress made in the fight against trafficking in human beings dated 19 May 2016, the
Commission noted, inter alia, the following:

“Increasing the number of investigations and prosecutions is one of the key priorities of the EU legal and policy
framework addressing trafficking in human beings. However, it is also one of the key challenges reported by
the Member States. In fact, trafficking in human beings is a crime often difficult and costly to detect and
investigate. The investigations in this field require a substantial body of evidence in order to reach a conviction.
In particular, practitioners note that excessive burden is placed on victims and their testimonies both before and
during criminal proceedings for evidence gathering, while, according to the Anti-trafficking Directive,


-----

investigative tools and approaches should ensure that victims, either acting as witness or not, are not burdened
excessively during procedures that can cause secondary trauma to them …

Based on the previous Eurostat data and the latest data transmitted by the Member States for the Report, the
level of prosecutions and convictions remains worryingly low, especially when compared to the number of
victims identified. This trend has been also confirmed by the GRETA reports, concluding that there is an
important gap between the number of identified victims of trafficking and the number of convictions, and
referring to several factors such as over-reliance on victims' statements, issues around the credibility of
witnesses who may change their statements over time, difficulties in relation to the sufficiency of evidence, or
non-specialised and prejudiced investigators, prosecutors and judges …

One of the main factors reported by Member States [contributing to the low level of prosecution] is related to
the high evidentiary threshold applied by national courts, which leads to qualify cases of trafficking in human
beings as crimes of lesser degree – such as procuring or pandering instead of trafficking for the purpose of
sexual exploitation, or breach of labour laws or fraud instead of trafficking for the purpose of labour exploitation
– resulting in minor convictions.”

207. In its second report on the progress made in the fight against trafficking in human beings dated 3 December
2018, the Commission noted, inter alia, the following:

“Trafficking in human beings for the purpose of sexual exploitation continues to be the most reported form. In
2015-2016, there were 9 759 registered victims of sexual exploitation. i.e. over half (56%) of the registered
victims who had a recorded form of exploitation, predominantly women and girls (95% of registered victims of
sexual exploitation).

…

Internal trafficking, within the territory of a Member State, is reported to be on the increase.

Member States report that traffickers are constantly changing the ways they work, using less physical force but
more psychological and emotional violence.

…

In view of the ever-adjusting methods used by traffickers, Member States should ensure specialised training for
professionals likely to come in contact with victims, which is adapted to the role of new information
technologies, and initiatives to prevent trafficking in human beings.

…

Nevertheless, trafficking in human beings remains a crime characterised by impunity for the perpetrators and
those who exploit the victims. The findings of this report do not indicate that trafficking has decreased. Further,
the analysis of the data reveals a tendency to identify victims of prioritised forms of exploitation, with certain
categories of victims placed at the forefront of action, while others receive less attention. Information from the
Member States reveals persisting complexities and a lack of progress in key areas. The Member States must
therefore make it a priority to take all the necessary measures.”

_2. Directive 2012/29/EU of the European Parliament and of the Council of 25 October 2012 establishing minimum_
_standards on the rights, support and protection of victims of crime, and replacing Council Framework Decision_
_2001/220/JHA (“The Victims' Rights Directive”)_

208. The Victims' Rights Directive establishes minimum standards on the rights, support and protection of victims of
crime. According to recital 57 of that Directive, there should be a strong presumption that victims of human
trafficking within the meaning of the Anti-trafficking Directive will benefit from special protection measures.
_C. Other European Union material_


-----

209. The relevant parts of the European Parliament's Resolution of 26 February 2014 on sexual exploitation and
prostitution and its impact on gender equality (2013/2103(INI)) read as follows:

“B. whereas prostitution and forced prostitution are forms of slavery incompatible with human dignity and
fundamental human rights;

C. whereas trafficking of persons, particularly women and children, for sexual as well as other forms of
exploitation is one of the most egregious violations of human rights; whereas trafficking in human beings is
growing globally, led by the increase in organised crime and its profitability;

…

1. Recognises that prostitution, forced prostitution and sexual exploitation are highly gendered issues and
violations of human dignity, contrary to human rights principles, among which gender equality, and therefore
contrary to the principles of the Charter of Fundamental Rights of the European Union, including the goal and
the principle of gender equality;

…

10. Recognises that prostitution and forced prostitution can have an impact on violence against women in
general, as research on sex buyers shows that men who buy sex have a degrading image of women …

11. Stresses that prostituted persons are particularly vulnerable socially, economically, physically,
psychologically, emotionally and in family terms, and are more at risk of violence and harm than persons
engaged in any other activity …

…

34. Believes that looking upon prostitution as legal 'sex work', decriminalising the sex industry in general and
making procuring legal is not a solution to keeping vulnerable women and under-age females safe from
violence and exploitation, but has the opposite effect and puts them in danger of a higher level of violence,
while at the same time encouraging prostitution markets – and thus the number of women and under-age
females suffering abuse – to grow …”

_IV. COMPARATIVE LAW_

210. According to the information available to the Court concerning the legislation of thirty-nine Council of Europe
member States (Albania, Armenia, Austria, Azerbaijan, Bosnia and Herzegovina, the Czech Republic, Denmark,
Estonia, Finland, France, Georgia, Germany, Hungary, Iceland, Ireland, Latvia, Liechtenstein, Lithuania,
Luxembourg, Malta, Moldova, Montenegro, the Netherlands, North Macedonia, Norway, Poland, Portugal,
Romania, the Russian Federation, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey,
Ukraine, and the United Kingdom) across Europe there is a universal recognition that human trafficking involving
sexual exploitation is a serious crime. In all thirty-nine member States human trafficking is criminalised. Similarly, all
member States criminalise compelling another person to provide sexual services (forced prostitution).

211. The majority of member States surveyed criminalise the involvement in the provision by another person of
sexual services even where there is no coercion on the person providing the services. The exceptions are
Germany, the Netherlands, Slovenia, Spain and Switzerland.

212. The member States have different approaches to identifying the existence of coercion; the constitutive
elements of compulsion in national legislation are not uniform. The threat of physical violence is the most commonly
identified indicator of coercion. Some other indicators are, for instance, blackmail, deceit, fraud, false promises,
taking advantage of the victim's vulnerability, restriction of movement, abduction, and abusing a position of power.
**THE LAWI. THE GOVERNMENT'S PRELIMINARY OBJECTIONS**

213. The Government raised preliminary objections concerning in part the scope of the case before the Court, and
in part the admissibility of the applicant's complaint.


-----

_A. Scope of the case1. The parties' submissions(a) The Government_

214. The Government pointed out that in her application to the Court, in so far as it was declared admissible, the
applicant, who was legally represented, relied on Articles 3 and 8 but not on Article 4 of the Convention. Although
the Government accepted that the Court could reclassify a complaint under a different Article than the one relied on
by an applicant, they did not consider that such a possibility existed in the present case. Moreover, the Government
considered that the applicant's complaint concerned only the outcome of the criminal proceedings. It did not involve
any other procedural aspect as the applicant's arguments in that respect were very general and abstract.
_(b) The applicant_

215. The applicant stressed that she had been identified as a victim of human trafficking by the Human Rights
Office (see paragraph 85 above) and that she had pointed to that fact in her application form. She also argued that
she had complained before the Court of a failure of the domestic authorities to comply with their procedural
obligation and to investigate the case properly. In the applicant's view, her complaints undoubtedly raised an issue
under Article 4 of the Convention and gave an opportunity to the Court to assess whether the domestic authorities
had complied with their procedural obligation under that provision.
_2. The Court's assessment_

216. At the outset, the Court reiterates that the “case” referred to the Grand Chamber necessarily embraces all
aspects of the application previously examined by the Chamber in its judgment. The “case” referred to the Grand
Chamber is the application as it has been declared admissible as well as the complaints that have not been
declared inadmissible (see _Navalnyy v. Russia [GC], nos. 29580/12 and 4 others, § 58, 15 November 2018, and_
_Ilias and Ahmed v. Hungary [GC], no. 47287/15, § 177, 21 November 2019)._

217. Furthermore, for the purpose of Article 32 of the Convention the scope of a case “referred to” the Court in the
exercise of the right of individual application is determined by the applicant's complaint. A complaint consists of two
elements: factual allegations and legal arguments (see Radomilja and Others v. Croatia [GC], nos. 37685/10 and
22768/12, § 126, 20 March 2018).

218. By virtue of the jura novit curia principle the Court is not bound by the legal grounds adduced by the applicant
under the Convention and the Protocols thereto and has the power to decide on the characterisation to be given in
law to the facts of a complaint by examining it under Articles or provisions of the Convention that are different from
those relied upon by the applicant (see, for instance, ibid.; Navalnyy, cited above, § 65; and, most recently, Molla
_Sali v. Greece [GC], no.[.] 20452/14, § 85, 19 December 2018)._

219. The Court cannot, however, base its decision on facts that are not covered by the complaint, it being
understood that, even if the Court has jurisdiction to review circumstances complained of in the light of the entirety
of the Convention or to “view the facts in a different manner”, it is nevertheless limited by the facts presented by the
applicants in the light of national law. However, this does not prevent an applicant from clarifying or elaborating
upon his or her initial submissions during the Convention proceedings. The Court has to take account not only of
the original application but also of the additional documents intended to complete the latter by eliminating any initial
omissions or obscurities. Likewise, the Court may clarify those facts _ex officio (see_ _Radomilja and Others, cited_
above, §§ 121-122 and 126).

220. In the case at hand in her initial application to the Court the applicant pointed to the fact that she had been
identified as a victim of human trafficking (see paragraph 215 above) and that T.M. had been prosecuted for forced
exploitation of prostitution against her. The applicant also briefly explained the course of the domestic proceedings,
which had eventually led to T.M.'s acquittal due to the fact that the domestic courts had not found that he had
forced her into prostitution. In the light of these facts – albeit not set out in a completely coherent manner – the
applicant raised an issue of the State's procedural obligation complaining, in particular, of impunity for the acts of
abuse to which T.M. had allegedly subjected her. She stressed that it was the State's responsibility to investigate
criminal acts and subsequently to conduct proceedings against the relevant individuals and, if they were found
guilty, to punish them in accordance with the law. In her view, this meant that the State must put in place an
effective criminal justice system. The applicant further argued that if the domestic courts had considered that T.M.
h d t f d h i t tit ti th h ld h i t d hi t l t f th i f tit ti d th


-----

relevant domestic law. The applicant also complained of a lack of appropriate assistance provided to her as a victim
during the proceedings. Lastly, the applicant argued that procuring prostitution, as a form of gender-based violence,
should not go unpunished. The applicant relied on Articles 3, 6, 8 and 14 of the Convention and Article 1 of Protocol
No. 12.

221. On 9 February 2015 the Government were given notice of the applicant's complaints, in so far as relevant and
admissible, under Articles 3, 4 and 8 of the Convention.

222. In her further submissions before the Chamber, the applicant stressed the authorities' procedural obligation
under the Convention. She also argued that her allegations of forced prostitution before the domestic authorities
had been justified. Also, in reply to the Government's submission, she elaborated on the domestic legal framework
and argued that it was inadequate to address the problem of human trafficking. Moreover, in her view, the relevant
domestic authorities had failed to recognise her case as human trafficking and had erroneously subsumed her
allegations under a provision relating to forced prostitution. In particular, she argued that T.M. should have been
prosecuted and convicted for human trafficking under Article 175 of the Criminal Code. In any event, in her view,
even if he had been erroneously prosecuted for procuring prostitution using coercion under Article 195 § 3 of the
Criminal Code (and not human trafficking), after the domestic courts had not found the element of coercion to be
established they should have convicted him at least under Article 195 § 2 of the Criminal Code (procuring of
prostitution). The fact that T.M. had eventually been acquitted showed, in the applicant's view, the lack of an
effective application of the criminal-law mechanisms in her case. The applicant also insisted that she had not been
provided with adequate assistance or with the possibility of effective participation in the proceedings as a victim of
human trafficking.

223. On the basis of the above submissions, the Chamber declared the communicated complaints (Articles 3, 4 and
8) admissible but examined the case under Article 4 of the Convention only (see § 36 and Operative point 1 of the
Chamber judgment; see also paragraphs 244-249 below).

224. Having regard to the above circumstances, the Court is of the view that there is no reason for it to decline
jurisdiction in respect of the complaints declared admissible by the Chamber. The applicant expressly relied, and
elaborated, on Articles 3 and 8 of the Convention. Her complaints (see paragraphs 220 and 222 above)
undoubtedly raised an issue which the Court, by virtue of the jura novit curia principle and in view of its case-law
(see paragraph 218 above; see also, for instance, V.T. v. France, no. 37194/02, § 35, 11 September 2007; Rantsev
_v. Cyprus and Russia, no. 25965/04, §§ 272-282, ECHR 2010 (extracts); and L.E. v. Greece, no. 71545/12, § 58,_
21 January 2016), could seek to determine whether it fell to be characterised under Article 4 of the Convention. This
is, of course, without prejudice to the discussion on the actual applicability and scope of protection guaranteed
under that provision.

225. Further, the Court is not persuaded by the Government's argument that the applicant's complaint concerned
only the outcome of the proceedings. Having regard to the case taken as a whole, the Court finds that the factual
elements of the applicant's initial complaint and their elaboration in the applicant's further submissions (see
paragraphs 220 and 222 above) are sufficiently broad to cover different aspects of the domestic authorities'
procedural obligation to apply the relevant criminal-law mechanisms effectively.

226. Indeed, according to the Court's case-law, impunity may derive from different causes. In particular, in so far as
relevant for the present case, it may result from the failures of the relevant prosecuting authorities and criminal
courts effectively to elucidate and address all the (often subtle) elements of conduct contrary to the Convention
(see, for instance, Chowdury and Others v. Greece, no. 21884/15, §§ 117-127, 30 March 2017).

227. Moreover, reference may be made to the Court's case-law which shows that it is prepared to take into account
any particular investigative omissions it considers relevant in the context of its overall assessment of an applicant's
procedural complaint of ineffective application of criminal-law mechanisms (see, for instance, _C.N. v. the United_
_Kingdom, no. 4239/08, §§ 47-52 and 80, 13 November 2012, where the Court found fault with the domestic_
authorities' failure to question one of the central witnesses in the case although the applicant had not raised that
issue in her arguments before the Court; see also M. and Others v. Italy and Bulgaria, no. 40020/03, §§ 86 and 104,


-----

31 July 2012, where the Court identified certain witnesses who needed to be questioned in order for the domestic
authorities to meet their procedural obligation under the Convention).

228. Having regard to the above, and in so far as the applicant's submissions relate to a deficiency in the
application of the relevant criminal-law mechanisms, which eventually allegedly led to impunity, the Court is of the
view that such claims are sufficiently broad to allow it to examine whether, on the whole and on the basis of the
particular aspects of the case it considers relevant, there has been a breach of the domestic authorities' procedural
obligation under the Convention.

229. In sum, the Court rejects the Government's objection concerning the scope of the case. It finds that the
“scope” of the case before it, in terms of its legal characterisation, raises legal issues under Articles 3, 4 and 8 of
the Convention. As to the factual scope of the case, the Court notes that the applicant's complaint raises issues of
alleged impunity for human trafficking, forced or alternatively non-forced prostitution relating to a deficient
application of the relevant criminal-law mechanisms. It is thus essentially of a procedural nature. This finding, as
already stressed above, is without prejudice to the further assessment and conclusion as to the actual applicability
and scope of protection guaranteed under the Convention for the acts complained of by the applicant.
_B. Preliminary objections on admissibility1. The parties' submissions(a) The Government_

230. The Government argued that the application was inadmissible under Article 35 of the Convention. They
contended that Article 4 was inapplicable in the present case and that, in any event, the applicant's complaint
should be declared inadmissible as it concerned an issue of outcome, where the Court's power of review was
limited.

231. As regards the applicability of Article 4, the Government did not contest that this provision applies to various
forms of human trafficking. However, they considered that the Court should adopt a clear position on the issue of
human trafficking by defining the meaning of that concept and the material scope of Article 4 in that regard. In any
event, in their view, there was no human trafficking in the present case as the element of “means” of human
trafficking, as conceived in the international definition of that phenomenon, was missing. In particular, the
Government considered that the applicant had not been subjected to any threat, or to the use of force, or other
forms of coercion.

232. In this respect, the Government relied on the findings of fact by the domestic courts, which, in the
Government's view, were relevant for determining the applicability of Article 4. Moreover, the Government argued
that some other elements of human trafficking were missing. In particular, the Government pointed out that T.M.
had not confiscated the applicant's papers, that he had not deprived her of her liberty, that she had had her mobile
phone and the possibility to contact others, that she had not been without any income as she had shared her
earnings with T.M., and that she had voluntarily decided to engage in prostitution in order to earn money. The
Government also argued that the fact that the applicant had been recognised as a victim of human trafficking by the
relevant domestic services could in no way be interpreted as implying that she had been subjected to human
trafficking within the meaning of the criminal law.

233. The Government also considered that a situation where an individual benefited from the prostitution of another
without any use of force or coercion could not fall within the scope of Article 4 as that would extend the scope of
Article 4 beyond the international definition of human trafficking. Such a position would bring uncertainty as regards
the scope of Article 4 and would also run counter to the spirit of that provision and the Court's earlier case-law on
the matter (referring to _V.T. v. France, cited above). Moreover, it would mean that all forms of prostitution were_
prohibited conduct under Article 4. Such a position could raise an issue as regards the practice of those States that
had not criminalised prostitution and could lower the rights of the victims, who also enjoyed protection under Articles
3 and 8 of the Convention. In sum, in the Government's view, no issue could arise under Article 4 with regard to the
fact that T.M. had not been convicted of the offence of procuring prostitution.
_(b) The applicant_

234. The applicant stressed that the allegations she had made before the prosecuting authorities (the police and the
State Attorney's Office) and later before the criminal court undoubtedly showed that she had been a victim of
h t ffi ki d th t h h d i d i d A ti l 4 f th C ti I thi ti th


-----

applicant also pointed out that she had been recognised as a victim of human trafficking at the domestic level; this
finding had not had, and should not have had, only an administrative character but was also of importance in the
sphere of criminal law.

235. In this connection, the applicant also found it relevant that in their submissions before the Chamber the
Government had argued that the recognition of her status as a victim of human trafficking at the domestic level,
coupled with the measures of assistance and support, amounted to a loss of her victim status under Article 34 of
the Convention (see § 41 of the Chamber judgment). Thus, the applicant found unconvincing the Government's
submissions before the Grand Chamber in which they had essentially changed their mind as to the importance of
the recognition of her status as a victim of human trafficking.

236. In the applicant's view, the procedural response of the prosecuting authorities, including the criminal courts, to
her allegations had been inadequate and contrary to the requirements of Articles 3, 4 and 8 of the Convention. In
particular, due to their lack of sensitivity concerning the matter, the domestic authorities had failed properly to
recognise her allegations as involving human trafficking and had thus failed properly to discharge their procedural
obligation under Article 4 of the Convention.
_2. The Court's assessment_

237. The Grand Chamber is not precluded from examining, where appropriate, questions concerning the
admissibility of an application under Article 35 § 4 of the Convention, as that provision enables the Court to dismiss
applications it considers inadmissible “at any stage of the proceedings”. Therefore, even at the merits stage and
subject to Rule 55 of the Rules of Court, the Court may reconsider a decision to declare an application admissible
where it concludes that it should have been declared inadmissible for one of the reasons given in the first three
paragraphs of Article 35 of the Convention (see, for instance, _Muršić v. Croatia [GC], no. 7334/13, § 69, 20 October_
2016).

238. The Court notes in the present case that the Government essentially raised two preliminary objections
concerning the admissibility of the applicant's complaints. The first concerns the applicability of the guarantees
under Article 4, which the Court finds more appropriate to address following an assessment of the scope of
protection under that provision and on the basis of a careful assessment of the particular circumstances of the case
at hand. The Court therefore joins this objection to the merits.

239. The second limb of the Government's objection could be interpreted as an invitation to the Court to declare the
applicant's complaints inadmissible as manifestly ill-founded given that, in the Government's view, they simply
concern dissatisfaction with the outcome of the proceedings (see paragraph 230 above). However, the Court
considers that the applicant's complaints raise complex issues relating to the interpretation of, in particular, Article 4
of the Convention and cannot be considered manifestly ill-founded. Accordingly, the Court finds this second limb of
the Government's objection unfounded. It should therefore be dismissed (compare _Zubac v. Croatia [GC], no._
40160/12, §§ 52-55, 5 April 2018).
_II. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION_

240. The applicant alleged that the domestic authorities had failed effectively to apply the relevant criminal-law
mechanisms concerning her allegations of human trafficking, forced or alternatively non-forced prostitution, contrary
to their obligations under Articles 3, 4 and 8 of the Convention.

241. Having regard to its current case-law and the nature of the applicant's complaint, the Court is of the view that
the issues raised in the present case should be addressed from the perspective of Article 4 of the Convention. It is
true that similar issues may arise under Article 3 (see V.T. v. France, cited above, § 26, and M. and Others v. Italy
_and Bulgaria, cited above, § 106) and potentially also under Article 8 of the Convention (see_ _V.C. v. Italy, no._
54227/14, §§ 84-85, 1 February 2018). However, the Court notes that in its case-law it has tended to apply Article 4
to issues related to human trafficking (see _Rantsev, cited above, §§ 252 and 336;_ _C.N. and V. v. France, no._
67724/09, § 55, 11 October 2012; C.N. v. the United Kingdom, cited above, § 84; and J. and Others v. Austria, no.
58216/12, § 123, 17 January 2017).


-----

242. The Court considers that this approach allows it to put the possible issues of ill-treatment (under Article 3) and
abuse of the applicant's physical and psychological integrity (under Article 8) into their general context, namely that
of trafficking in human beings and sexual exploitation. Indeed, allegations of ill-treatment and abuse are inherently
linked to trafficking and exploitation, whenever that is the alleged purpose for which the ill-treatment or abuse was
inflicted (see, in general, Rantsev, cited above, § 252, and C.N. and V. v. France, cited above, § 55). It follows that
the applicant's allegations (see paragraph 240 above) fall to be examined under Article 4 of the Convention.

243. Accordingly, being the master of the characterisation to be given in law to the facts of a case (see, for
instance, Molla Sali, cited above, § 85), the Court will examine the present case under Article 4 of the Convention,
which, in so far as relevant, reads as follows:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

…”

_A. The Chamber judgment_

244. The Chamber noted that the applicant had alleged before the domestic authorities that she had been
psychologically and physically forced by T.M. to participate in a prostitution ring organised by him. This had led to
the recognition of her status as a victim of human trafficking by the national authorities. In addition, the national
courts had established as uncontested that T.M. had given the applicant a mobile telephone for the purpose of
clients' contacting her for sexual services and that T.M. had driven the applicant to the clients or that she had
provided sexual services in the flat she had occupied together with him.

245. In these circumstances, the Chamber considered it unnecessary to identify whether the treatment of which the
applicant complained constituted slavery, servitude or forced or compulsory labour. Instead, it concluded that
trafficking itself as well as exploitation of prostitution, within the meaning of Article 3(a) of the Palermo Protocol,
Article 4(a) of the Anti-Trafficking Convention, Article 1 of the 1949 Convention and the CEDAW, fell within the
scope of Article 4 of the Convention.

246. The Chamber thus decided to assess the present case under Article 4 of the Convention. In this connection, it
also noted that it was irrelevant that the applicant was actually a national of the respondent State and that there had

been no international element since Article 2 of the Anti‑Trafficking Convention encompassed “all forms of

trafficking in human beings, whether national or transnational” and the 1949 Convention referred to exploitation of
prostitution in general.

247. Relying, in particular, on the general principles developed by the Court in Rantsev (cited above, §§ 272-289),
the Chamber considered that the applicant's complaints had three aspects and assessed them separately. The first
aspect was whether there was an appropriate legal and regulatory framework at the domestic level; the second was
whether the applicant had been provided with appropriate assistance and support to alleviate the fear and pressure
she had felt while testifying against T.M.; and the third was whether in the application of that framework in the
applicant's particular case the national authorities had complied with their procedural obligations.

248. As to the first aspect of the complaint, the Chamber was satisfied that at the time the alleged offence had been
committed and prosecuted there was an adequate legal framework at the domestic level concerning trafficking in
human beings, forced prostitution and exploitation of prostitution. With regard to the second aspect of the complaint,
the Chamber considered that the applicant had been provided with adequate support and assistance.

249. As regards the third aspect of the complaint, the Chamber held that there had been no indication that the
national authorities had made a serious attempt to investigate in depth all the circumstances relevant for assessing
whether T.M. had forced the applicant into prostitution. Also, the Chamber considered that the domestic courts'
assessment of the applicant's statement had not taken into account the possible impact of psychological trauma on
the applicant's ability to consistently and clearly relate the circumstances of her exploitation. In these


-----

circumstances, the Chamber considered that the relevant State authorities had not fulfilled their procedural
obligation and thus found a violation of Article 4 of the Convention.
_B. The parties' submissions1. The applicant_

250. The applicant contended that the prosecuting authorities had erroneously characterised her allegations, which
undoubtedly suggested that she had been a victim of trafficking, as an issue of forced prostitution. Relying on
different monitoring reports in respect of Croatia, the applicant argued that there was a general issue in relation to
the conduct of the domestic authorities who tended to classify charges of human trafficking as an offence of
procuring prostitution, which left many instances of trafficking unpunished.

251. The applicant further argued that when submitting her complaint to the domestic authorities, she had provided
all relevant details of the case and identified witnesses who could have provided further information concerning her
allegations. According to the applicant, when she had submitted her complaint, the prosecuting authorities had
advised her that she had done everything she could and that they were taking over the investigation. Ultimately,
however, out of five possible witnesses concerning the events, the prosecuting authorities had only questioned one.

252. In this connection, the applicant also stressed that at the time of the events she had not trusted the system and
had decided to report the events to the police due to T.M.'s threats relating to her family. Moreover, at the time
when the criminal proceedings took place she had been seriously afraid of T.M., who had threatened her after she
had run away from him. In such circumstances, she had decided to tell her story to the relevant court only after she
had been provided with legal assistance by the Rosa Centre. However, according to the applicant, that legal
assistance had not been part of the State legal aid but an assistance provided by a non-governmental organisation
at the request of the applicant's mother.

253. In these circumstances, it could not be said that she had been passive during the proceedings as she had
given her statements three times, provided detailed information about the events and identified all possible
witnesses. Thus, in her view, as a victim of human trafficking she could not have been expected to do more. In
particular, it would be unreasonable to expect that she should take the position of the State Attorney's Office, which
was ex officio obliged to conduct the relevant criminal proceedings effectively.

254. The applicant also contended that the State Attorney's Office and the criminal court had failed to ensure, each
within their scope of competence and if needed in cooperation with each other, that the relevant measures were
taken so that the offence against her did not remain unpunished. In her view, they should have reclassified the
charges against T.M. so as to ensure that he was punished at least for the basic form of procuring prostitution.
However, the State Attorney's Office and the criminal court had remained passive, shifting the responsibility from
one to another. Moreover, the domestic courts had demonstrated a lack of sensitivity towards the emotional trauma
suffered by the victims of human trafficking and its impact on their capacity to relate all details of the case. This
ultimately resulted in a situation in which she, as a victim of human trafficking, had been left unprotected by the
authorities from T.M.'s actions. It also opened the door to the possibility of her future abuse by T.M. given that he
was, as was clear from M.I.'s evidence, obsessed with her (the applicant).

255. In sum, relying also on her submissions during the Chamber proceedings, the applicant considered that the
domestic criminal-law mechanisms as applied in the case at hand were defective to the point of constituting a
violation of the State's positive obligations under Article 4 of the Convention.
_2. The Government_

256. The Government argued that there was no deficiency in the domestic legal framework concerning the issue of
human trafficking or other related conduct. In this connection, the Government stressed that the domestic
authorities were making continuous efforts to strengthen the administrative and operational practices aimed at
enhancing the fight against trafficking in human beings. Thus, so far a total of 117 judges and prosecutors had
finished training on the issues of human trafficking and specialised courses on the matter were also part of the
training given to the police. In particular, as regards those involved in the present case, the prosecutor who first
questioned T.M. (see paragraph 23 above) had attended two one-day training sessions on human trafficking in
February 2005 and November 2009. The trial judge had attended two one-day training sessions on the matter in
S t b 2003 d F b 2005 hil f th j d itti i th l t h d d t d d


-----

training course in November 2013. Moreover, the Government argued that in recent years the number of identified
victims of human trafficking was increasing and so was the number of convictions for human trafficking.

257. The Government also submitted, relying on the Chamber's findings (see paragraph 248 above), that the
applicant had been provided with all the relevant services of protection, support and assistance, which was all in
compliance with the relevant GRETA recommendations. Moreover, the Government pointed out that the applicant
had not made any complaint in this regard before the domestic authorities.

258. As regards the authorities' compliance with their procedural obligation, the Government considered that the
domestic authorities had diligently investigated the case on the basis of the applicant's allegations by collecting all
the relevant evidence in this regard. In this connection, the Government pointed out that the applicant had been
legally represented throughout the proceedings and that she had never proposed any evidence to be taken by the
authorities or made any complaint in that regard.

259. Moreover, in the Government's view, the domestic courts had adopted their decision on the basis of the

established facts and their findings could not be considered arbitrary. In particular, even assuming that non‑coerced

exploitation of prostitution fell under Article 4, the domestic courts could not be criticised for not reclassifying the
State Attorney's indictment from forced exploitation of prostitution to that form as that would entail an unjustified
interference with the nature and cause of the accusations against the accused.
_3. The third-party interveners(a) The Council of Europe Group of Experts on Action against Trafficking in Human_
_Beings (“GRETA”)_

260. GRETA stressed that one of the core objectives of the Anti‑Trafficking Convention was to ensure the effective

investigation and prosecution of trafficking offences. However, GRETA's country monitoring revealed that there was
a significant disparity between the number of identified victims of trafficking, on the one hand, and the number of
prosecutions and convictions, on the other hand. The identified reasons for this were numerous and included, in
particular, overreliance on victims' statements, issues related to the credibility of witnesses who might change their
statements over time, or difficulties in relation to the sufficiency of evidence. In this connection, GRETA pointed out
that victims were sometimes afraid or reluctant to make depositions because of threats of revenge from the
perpetrators or lack of trust in the effectiveness of the criminal justice system.

261. At the same time, in some trafficking cases, as research from the field showed, the only evidence available to
the court was the victim's testimony and the defendant's denial. In such cases, the courts were called upon to
decide whether the victim's testimony sufficed to convict a defendant, even when his or her allegations were denied
by the defendant and it was a word-against-word situation. GRETA stressed that a failure of the prosecution to
support the victim's statement with other evidence, such as testimonial evidence of customers served by victims,
neighbours who might be able to provide facts about the victim's situation, NGO members who could testify about
the psychological state of victims, expert opinions or financial investigations, might lead to the exoneration of the
defendant.

262. One of the important reasons for such an outcome was a lack of training and specialisation of investigators,
prosecutors, judges and lawyers on the matters of human trafficking, which could lead them to be prejudiced vis-à_vis victims of trafficking and insensitive to the problems experienced by them. Thus, GRETA had repeatedly_
stressed the need to improve the training and specialisation of those involved in cases concerning human
trafficking.

263. The same was true for Croatia. In the country monitoring of Croatia, GRETA noted that prosecutions for the
offence of trafficking in human beings had been rare, that victims had not been properly informed of and assisted in
the use of their rights, and that victims had been reluctant to cooperate with the criminal justice authorities.
Moreover, GRETA's findings suggested that judges were reportedly not sufficiently aware of the particular
vulnerability of victims of human trafficking. GRETA had also been provided with examples of cases where other
offences, in particular procuring prostitution, had been prosecuted instead of human trafficking, and perpetrators
had been given lighter sentences in such cases, as well as instances where victims of sexual exploitation acting as


-----

witnesses had not been treated with the required sensitivity. GRETA had thus, in particular, repeatedly insisted on
increased training for judges and public prosecutors on the legislation concerning trafficking in human beings.

264. GRETA also stressed that one of the measures to fight trafficking in human beings included the necessity to
ensure protection of victims and witnesses of human trafficking, as provided for in the Anti-Trafficking Convention.
GRETA had thus made recommendations to the Croatian authorities concerning this matter as well.

265. Lastly, GRETA elaborated, in particular, on the issue of “abuse of vulnerability” as one of the “means” of
human trafficking. GRETA stressed that establishing the existence of victim vulnerability was important for many
aspects of a trafficking case, as vulnerability could be a critical indicator when identifying victims, and accurate
assessment of vulnerability could help to ensure that victim witnesses were appropriately supported and protected.
In criminal prosecutions, both the existence of vulnerability and the abuse of that vulnerability should be established
by credible evidence. In this context, GRETA also referred to a UNODC study according to which the mere
existence of vulnerability might suffice to satisfy the means element and thereby help support a conviction. Thus,
GRETA had insisted in the country evaluation procedures that the “abuse of vulnerability” be properly addressed. In
sum, GRETA stressed that evidence of an abuse of a position of vulnerability might be less tangible than for other
means used to commit a human trafficking offence, such as the use of force. It was therefore important to involve
specialists, such as psychologists, social workers or NGO representatives working with victims of trafficking, at the
investigative phase to ensure that evidence was effectively and appropriately collected and presented at the trial.
(b) Clinique doctorale de droit international des droits de l'homme (Faculté de droit d'Aix-en-Provence)

266. The third party intervener pointed out that forced prostitution could be considered as a form of forced labour
and that force or coercion in this context could be of different kinds, such as psychological, physical or financial. In
such instances, when there was force or coercion, any consent of the victim was excluded. In the intervener's view,
when related to human trafficking and to the practices associated with slavery, prostitution should be characterised
as slavery (sexual slavery) within the meaning of Article 4 of the Convention. This conclusion followed from the
Court's case-law which made reference to the issue of modern day slavery and it also followed from other
international jurisdictions such as the Inter-American Court, the Special Tribunal for Sierra Leone and the
International Criminal Court. Indeed, in the intervener's view, such an approach was consistent with the
international definition and approach to slavery.

267. Furthermore, the third-party intervener argued that when prostitution was exploited by others for economic
gain it amounted to trafficking. However, “exploitation” in this context had to be associated with a de facto exertion
of coercion. Thus, even if a person voluntarily engaged in prostitution, his or her abuse by a third party would be
indicative of some form of coercion into prostitution.

268. The third-party intervener also argued that persons engaged in prostitution belonged to a vulnerable group and
that this applied in particular to women, as was recognised in various international instruments. Such vulnerability
was in some cases further exacerbated by economic constraints or the race of the victim. Thus, an intersectional
approach was needed to address the issue of vulnerability. For instance, at the national level in France, it was
recognised that abuse of vulnerability referred to a totality of situations of distress that could lead a person to accept
his or her exploitation. In the intervener's view, this vulnerability needed to be taken into account in the context of
the duty to investigate and in the context of the taking and assessment of the victim's evidence. In particular, in
connection with the latter aspect, the third-party intervener stressed that it was a well-known fact that the victim's
evidence could be incoherent and contradictory as a result of the treatment to which the victim had been subjected
and that this was insufficient to conclude that the victim had provided false evidence. Thus, emphasis should be
placed on the essential aspects of the victim's evidence and it was important to obtain further evidence concerning
the impugned situation.
_(c) Research Centre L'altro diritto onlus (University of Florence)_

269. The third-party intervener argued that it was a common understanding in international law that the Palermo
Protocol, when read in conjunction with its parent Convention against Transnational Organized Crime, required
criminalisation not only of trans-border but also of internal trafficking. Indeed, the most recent UNODC _Global_
_reports on trafficking in persons pointed out that victims who had been detected within their own borders_


-----

represented the largest part of the victims detected worldwide. Moreover, the Anti-Trafficking Convention explicitly
included within the definition of human trafficking instances of internal trafficking. The European Union AntiTrafficking Directive also covered internal and cross-border trafficking.

270. In this connection, the third-party intervener stressed that, as it followed from the UNODC material,
“movement” was not a necessary requirement of the definition of human trafficking. That definition also included
instances, such as receipt and harbouring, which did not involve movement. Thus, the third party intervener
considered that it was important that the Court recognise both internal and cross-border trafficking as the
constituent elements of the phenomenon of trafficking in human beings.

271. The third-party intervener further submitted that the issue of “exploitation of prostitution” could not be taken out
of the context of human trafficking as done by the Chamber in the present case. In this connection, the intervener
stressed that the issues of prostitution and exploitation of prostitution raised some very sensitive questions on which
opinions differed, in particular between those who saw prostitution as being a degrading and exploitive practice in
itself and others who saw it as a form of work. In this context, the domestic practices also differed and in the V.T. v.
_France case (cited above) the Court had not wished to take a stance on this particular matter. In these_
circumstances, in the intervener's view, when relying on the 1949 Convention, which had a very ambivalent
approach towards prostitution and exploitation of prostitution, the Chamber judgment had essentially raised an
issue of the Court's neutrality in this debate.
_(d) Group of researchers Bénédicte Bourgeois (University of Michigan), Marie-Xavière Catto (University Paris I_
_Panthéon-Sorbonne) and Michel Erpelding (Max Planck Institute Luxembourg for Procedural Law)_

272. The third-party interveners firstly stressed that, due to different historical and legal reasons, under general
international law the notions of slavery, forced labour and servitude were imperfectly compartmentalised concepts.
However, under international human rights law these phenomena were addressed within single provisions and their
general and unconditional prohibition was clearly proclaimed. As regards the Court's approach to these
phenomena, the third-party interveners considered its case-law as representing a “gradation model” where slavery
was not considered to be a distinct phenomenon from forced labour but the most severe form of it, while servitude
constituted an intermediate form of abuse. For the interveners, the Court had a wide judicial discretion in
interpreting the definitions used in early instruments concerning slavery, servitude and forced or compulsory labour
when taken in the context of individual human rights protection.

273. The third-party interveners further submitted that the three legal concepts mentioned in Article 4 of the
Convention (slavery, servitude and forced or compulsory labour) pertained to different forms of human exploitation,

as followed from the Court's case-law in _Siliadin v. France (no. 73316/01, ECHR 2005‑VII). However, they noted_

that in the Rantsev case (cited above), the Court had brought an additional concept within the ambit of Article 4:
that of human trafficking. For the interveners, there was no doubt that the concept of human trafficking was
inherently linked to that of human exploitation. Indeed, the blameworthiness of human trafficking stemmed from its
purpose, namely severe exploitation of human beings. Thus, there was no doubt that such conduct fell within the
scope of Article 4 of the Convention. However, the third-party interveners asserted that the Court's reasoning in
_Rantsev was incoherent as it confused the concepts of human trafficking and slavery. Moreover, noting the Rantsev_
approach, the third-party interveners argued that there were many uncertainties in the scope of these concepts
relating, in particular, to the threshold of severity attached to particular conduct.

274. The third-party interveners also pointed out that the international definition of human trafficking did not define
the element of sexual exploitation. In particular, during the preparatory work on the Palermo Protocol several
national delegations had wanted to distinguish victims of prostitution from those who had chosen to engage in
prostitution. It was finally decided to leave the concept undefined. Eventually, however, UNODC had attempted to
define the concept of “exploitation of prostitution of others” but linked it to an issue of unlawfulness in domestic law
(see paragraph 117 above). For the third-party interveners, this created a problem of circular reasoning and the risk
that States through their national laws might preclude characterising a particular situation as exploitation. In the
intervener's view, from the perspective of international human rights law this was unacceptable and thus the Court
needed to have recourse to its autonomous concept doctrine in order to define “exploitation”.


-----

275. Lastly, the third-party interveners stressed that the concept of forced prostitution was a similar, but in practice
distinct, matter from rape or sexual slavery. The concept of forced prostitution implied a financial gain for its
perpetrator. In the third-party interveners' view, the Court might consider drawing inferences from the definition of
forced prostitution in international criminal law in order to define this concept in international human rights law.
_C. The Court's assessment1. Introductory remarks_

276. The Court has not so far had many opportunities to consider the extent to which treatment associated with
human trafficking and/or exploitation of prostitution falls within the scope of the Convention. At the same time,
attention to trafficking in human beings and exploitation of prostitution as global phenomena has increased
significantly in recent years. As the overview of international material shows, different international legal instruments
and supervision mechanisms have dealt with these issues and elaborated on the central tenets of their effective
prevention and suppression.

277. Regard being had to the parties' submissions and the third parties' comments, the present case allows the
Court to clarify certain aspects of its case-law on human trafficking for the purpose of exploitation of prostitution. It
also requires the Court to address the statement in paragraph 54 of the Chamber judgment according to which
“trafficking itself _as well as exploitation of prostitution … fall within the scope of Article 4 of the Convention”_
(emphasis added).

278. The Court will now address the question of the material scope of Article 4 of the Convention. In this
connection, it will first give an overview of the relevant standards relating to the three concepts enunciated under
Article 4 (slavery, servitude and forced or compulsory labour). Secondly, it will address the issue of trafficking in
human beings under Article 4 of the Convention. Thirdly, it will turn to the question of “exploitation of prostitution”
under that provision. The Court will then address the States' positive obligations under Article 4 of the Convention.
_2. Scope of Article 4 of the Convention(a) The three concepts enunciated under Article 4 of the Convention_

279. Article 4 refers to three concepts: slavery, servitude and forced or compulsory labour. However, as the Court
already observed in its case-law, the Convention does not define any of them (see Van der Mussele v. Belgium, 23
November 1983, § 32, Series A no. 70, and Siliadin, cited above, §§ 121-125). Thus, in determining the material
scope of Article 4 of the Convention, the Court has sought guidance in various instruments of international law
dealing with these concepts.

280. In its early case-law, as regards the concept of “slavery”, the Court referred to the 1927 Convention to
Suppress the Slave Trade and Slavery, which defined slavery as “the status or condition of a person over whom
any or all of the powers attaching to the right of ownership are exercised”. As to the concept of “servitude”, the
Court had regard to the European Commission of Human Rights' earlier case-law and the 1956 Convention to
Suppress the Slave Trade and Slavery, according to which that concept related to a “particularly serious form of
denial of freedom” and included “in addition to the obligation to perform certain services for others … the obligation
for the 'serf' to live on another person's property and the impossibility of altering his condition”. In sum, having
regard to these elements, the Court held that the concept of “servitude” had to be understood as “an obligation to
provide one's services that is imposed by the use of coercion” (see _Siliadin, cited above, §§ 122-125). It also_
observed that servitude corresponded to “aggravated” forced or compulsory labour (see _C.N. and V. v. France,_
cited above, §§ 89-91).

281. As regards the definition of “forced or compulsory labour”, in Van der Mussele (cited above, § 32) the Court
noted that no clear guidance on this point was to be found in the various Council of Europe documents relating to
the preparatory work of the Convention. However, the Court considered it evident that the text of Article 4 was to a
large extent based on ILO Convention No. 29. Thus, in view of the fact that this legal instrument was binding on
nearly all the member States of the Council of Europe, the Court considered that the ILO's definition of “forced or
compulsory labour” should be taken as a starting-point for the interpretation of Article 4 of the Convention (see also
_Siliadin, cited above, §§ 115-116, and Stummer v. Austria [GC], no. 37452/02, § 117, ECHR 2011, where the Court_
more recently confirmed this approach). According to this definition, “forced or compulsory labour” means all work
or service which is exacted from any person under the menace of any penalty and for which the said person has not
offered him or herself voluntarily (see paragraphs 140-143 above).


-----

282. On the basis of the ILO definition, as regards the concept of “labour” under Article 4 § 2 of the Convention, the
Court stressed that it should be understood in a broader sense as “all work or service”. As to the “forced or
compulsory” nature of such labour, the Court noted that the adjective “forced” brought to mind the idea of physical
or mental constraint and the second adjective (“compulsory”) referred to a situation where work was “exacted …
under the menace of any penalty” and also performed against the will of the person concerned, that is work for
which he “has not offered himself voluntarily”. The Court also clarified that the concept of “penalty” had to be
understood in a broader sense as “any” or “a” penalty. Moreover, the Court stressed that in the event of the
existence of a risk comparable to “the menace of [a] penalty” relative weight was to be attached to the argument
regarding “prior consent” to an activity (see Van der Mussele, cited above, §§ 34-37; Siliadin, cited above, §§ 115117; Stummer, cited above, § 117; and Chowdury and Others, cited above, §§ 90-91).

283. In its subsequent case-law, the Court further clarified some of the elements of the definition of “forced or
compulsory labour” set out in Van der Mussele. In particular, in the above-cited Siliadin case (§§ 114-120), in which
it was called upon to elaborate on the extent to which treatment essentially associated with trafficking fell within the
scope of Article 4, the Court referred to the Van der Mussele concept of “forced or compulsory labour” and further
held that the concept of “a penalty” extended to any equivalent situation in terms of the perceived seriousness of
the threat. With regard to the question of “consent” to the impugned work, the Court referred to the absence of a
choice.

284. Moreover, in C.N. and V. v. France (cited above, § 77), relying on an ILO report, the Court elaborated on the
concept of “a penalty” explaining that this concept “may go as far as physical violence or restraint, but it can also
take subtler forms, of a psychological nature, such as threats to denounce victims to the police or immigration
authorities when their employment status is illegal”.

285. In the recent case of Chowdury and Others v. Greece (cited above, § 96), the Court elaborated on the concept
of “consent” stressing that “where an employer abuses his power or takes advantage of the vulnerability of his
workers in order to exploit them, they do not offer themselves for work voluntarily”. Thus, the Court further stressed
that “[t]he prior consent of the victim is not sufficient to exclude the characterisation of work as forced labour” and
that “[t]he question whether an individual offers himself for work voluntarily is a factual question which must be
examined in the light of all the relevant circumstances of a case”.
_(b) Trafficking in human beings under Article 4 of the Convention_

286. The most important development in the Court's case-law on the issue of human trafficking for the purpose of
sexual exploitation occurred with the adoption of its judgment in the case of Rantsev v. Cyprus and Russia (cited
above). The case concerned the alleged trafficking and death of a young Russian woman, who had been recruited
to work as a “cabaret artiste” in Cyprus (which different organisations denounced as a cover-up for prostitution) and
who then died in suspicious circumstances following a conflict with the man for whom she had worked. In so far as
relevant for the present case, the Rantsev case raised issues under Article 4 of the Convention.

287. In this connection, in particular, the Court noted that there was no mention of trafficking in that provision.
However, having outlined the various international instruments in the field of human trafficking, the Court referred to
the following interpretative principles of the Convention:

“273. The Court has never considered the provisions of the Convention as the sole framework of reference for
the interpretation of the rights and freedoms enshrined therein (Demir and Baykara v. Turkey [GC], no.
34503/97, § 67, 12 November 2008). It has long stated that one of the main principles of the application of the
Convention provisions is that it does not apply them in a vacuum (see Loizidou v. Turkey, 18 December 1996,
Reports of Judgments and Decisions 1996-VI; and _Öcalan v. Turkey [GC], no. 46221/99, § 163, ECHR_

2005‑IV). As an international treaty, the Convention must be interpreted in the light of the rules of interpretation

set out in the Vienna Convention of 23 May 1969 on the Law of Treaties.

274. Under that Convention, the Court is required to ascertain the ordinary meaning to be given to the words in
their context and in the light of the object and purpose of the provision from which they are drawn (see Golder
_v. the United Kingdom, 21 February 1975, § 29, Series A no. 18; Loizidou, cited above, § 43; and Article 31 § 1_


-----

of the Vienna Convention). The Court must have regard to the fact that the context of the provision is a treaty
for the effective protection of individual human rights and that the Convention must be read as a whole, and
interpreted in such a way as to promote internal consistency and harmony between its various provisions (Stec
_and Others v. the United Kingdom (dec.) [GC], nos. 65731/01 and 65900/01, § 48, ECHR 2005-X). Account_
must also be taken of any relevant rules and principles of international law applicable in relations between the
Contracting Parties and the Convention should so far as possible be interpreted in harmony with other rules of
international law of which it forms part (see Al-Adsani v. the United Kingdom [GC], no. 35763/97, § 55, ECHR

2001‑XI; Demir and Baykara, cited above, § 67; Saadi v. the United Kingdom [GC], no. 13229/03, § 62, ECHR

2008‑…; and Article 31 para. 3 (c) of the Vienna Convention).

275. Finally, the Court emphasises that the object and purpose of the Convention, as an instrument for the
protection of individual human beings, requires that its provisions be interpreted and applied so as to make its
safeguards practical and effective (see, inter alia, Soering v. the United Kingdom, 7 July 1989, § 87, Series A
no. 161; and Artico v. Italy, 13 May 1980, § 33, Series A no. 37).”

288. The Court further noted that the absence of an express reference to trafficking in the Convention was
unsurprising given that the Convention was inspired by the Universal Declaration of Human Rights, which only
referred to “slavery and the slave trade in all their forms”. However, the Court stressed that in assessing the scope
of Article 4 of the Convention, sight should not be lost of the Convention's special features or of the fact that it was a
living instrument which should be interpreted in the light of present-day conditions. Moreover, the increasingly high
standards required in the area of the protection of human rights and fundamental liberties correspondingly and
inevitably required greater firmness in assessing breaches of the fundamental values of democratic societies
(Rantsev, cited above, § 277).

289. The Court further stressed that “[i]n light of the proliferation of both trafficking itself and of measures taken to
combat it, the Court considers it appropriate in the present case to examine the extent to which trafficking itself may
be considered to run counter to the spirit and purpose of Article 4 of the Convention such as to fall within the scope
of the guarantees offered by that Article without the need to assess which of the three types of proscribed conduct
are engaged by the particular treatment in the case in question” (ibid., § 279). Finally, the Court concluded the
following:

“282. There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its
victims and cannot be considered compatible with a democratic society and the values expounded in the
Convention. In view of its obligation to interpret the Convention in light of present-day conditions, the Court
considers it unnecessary to identify whether the treatment about which the applicant complains constitutes
“slavery”, “servitude” or “forced [or] compulsory labour”. Instead, the Court concludes that trafficking itself,
within the meaning of Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti-Trafficking Convention,
falls within the scope of Article 4 of the Convention. …”

290. In this connection, it follows from _Rantsev that impugned conduct may give rise to an issue of human_
trafficking under Article 4 of the Convention only if all the constituent elements (action, means, purpose) of the
international definition of human trafficking are present (see paragraphs 113-114 and 155-156 above). In other
words, in keeping with the principle of harmonious interpretation of the Convention and other instruments of
international law (see Demir and Baykara v. Turkey [GC], no. 34503/97, § 67, ECHR 2008), and in view of the fact
that the Convention itself does not define the concept of human trafficking, it is not possible to characterise conduct
or a situation as an issue of human trafficking unless it fulfils the criteria established for that phenomenon in
international law.

291. The Court further notes that in its subsequent cases, while regularly referring to the _Rantsev principles on_
human trafficking, it sought to provide an explanation on how the phenomenon of human trafficking falls within the
scope of Article 4 of the Convention. Thus, for instance, in J. and Others v. Austria (cited above, § 104) the Court
explained that the identified elements of trafficking – the treatment of human beings as commodities, close
surveillance, the circumscription of movement, the use of violence and threats, poor living and working conditions,
and little or no payment cut across the three categories set out in Article 4 Similarly in Chowdury and Others


-----

(cited above, § 93), the Court stressed that “exploitation through work is one of the forms of exploitation covered by
the definition of human trafficking, and this highlights the intrinsic relationship between forced or compulsory labour
and human trafficking”.

292. Having regard to these observations, the concept of human trafficking can properly be incorporated, in the
Court's view, within the scope of Article 4. Indeed, given the Convention's special features as a human rights treaty
and the fact that it is a living instrument which should be interpreted in the light of present-day conditions (see, inter
_alia, Khamtokhu and Aksenchik v. Russia [GC], nos. 60367/08 and 961/11, § 73, 24 January 2017) there are good_
reasons to accept the assertion in Rantsev that the global phenomenon of trafficking in human beings runs counter
to the spirit and purpose of Article 4 and thus falls within the scope of the guarantees offered by that provision.

293. This conclusion also finds support in the comparison of the essential elements of the concepts enunciated in
Article 4, as construed in the Court's case-law (see paragraphs 279-285 above) and the constituent elements of the
phenomenon of human trafficking (see paragraphs 113-117 and 155-162 above). Moreover, such an approach to
the phenomenon of human trafficking is convincingly set out in the ILO materials (see paragraphs 144-145 above),
which have traditionally played a key role in informing the scope of guarantees under Article 4 of the Convention
(see paragraph 281 above). It should also be noted that it follows from the comparative law material available to the
Court that there is universal recognition of human trafficking as a serious crime that involves, _inter alia, sexual_
exploitation. Indeed, all thirty-nine Council of Europe member States for which the comparative information is
available criminalise human trafficking (see paragraph 210 above).

294. However, it should be noted that there is an apparent difference between the Palermo Protocol and the AntiTrafficking Convention as regards the scope of their application, the latter being applicable to all forms of trafficking
in human beings, whether national or transnational, whether or not connected with organised crime, whereas the
former relates to transnational trafficking involving an organised criminal group (see paragraphs 119 and 162
above). It is therefore necessary for the Court to clarify its position on this particular point.

295. In the Court's view, there are several reasons why the approach under the Anti-Trafficking Convention should
be followed. First, this is dictated by the fact that excluding a group of victims of conduct characterised as human
trafficking under the Anti-Trafficking Convention from the scope of protection under the Convention would run
counter to the object and purpose of the Convention as an instrument for the protection of individual human beings,
which requires that its provisions be interpreted and applied so as to make its safeguards practical and effective
(see, for instance, Güzelyurtlu and Others v. Cyprus and Turkey [GC], no. 36925/07, § 234, 29 January 2019). In
this connection it should be noted, as follows from the international material and as pointed out by one of the thirdparty interveners (see paragraph 269 above), that internal trafficking is currently the most common form of
trafficking. Secondly, the Court has already held that the member States' positive obligations under Article 4 of the

Convention must be construed in the light of the Council of Europe's Anti‑Trafficking Convention (see _Chowdury_

_and Others, cited above, § 104). Thirdly, the limited definitional scope of the Palermo Protocol is relative as, when_
read in conjunction with its parent instrument (UNCTOC), the Protocol in fact proscribes trafficking irrespective of a
transnational element or the involvement of an organised criminal group (see paragraphs 111 and 120 above).

296. Thus, the Court finds that from the perspective of Article 4 of the Convention the concept of human trafficking
covers trafficking in human beings, whether national or transnational, whether or not connected with organised
crime, in so far as the constituent elements of the international definition of trafficking in human beings, under the
Anti-Trafficking Convention and the Palermo Protocol, are present.

297. Such conduct or such a situation of human trafficking then falls within the scope of Article 4 of the Convention.
This, however, does not exclude the possibility that, in the particular circumstances of a case, a particular form of
conduct related to human trafficking may also raise an issue under another provision of the Convention (see, for
instance, M. and Others v. Italy and Bulgaria, cited above, §§ 106-107; see also paragraph 241 above).
_(c) “Exploitation of prostitution” under Article 4 of the Convention_

298. It is important to note at the outset that, as also stressed by the third party intervener L'altro diritto onlus (see
paragraph 271 above), the current discussion on the “exploitation of prostitution” opens up some very sensitive


-----

issues relating to the approach to prostitution in general. In particular, there are different, often conflicting, views as
to whether prostitution as such can ever be consensual or is always a coercive form of exploitation. In this context,
it should be noted that prostitution is approached differently in different legal systems depending on the relevant
society's understanding of it (see paragraph 180 above).

299. In V.T. v. France (cited above, §§ 24-27 and 35), as the only case so far addressing this particular issue, the
Court noted the substantial differences in legal systems concerning the approach to prostitution. In the
circumstances of that case, the Court did not consider it relevant to enter into the debate whether prostitution in
itself was contrary to, in particular, Article 3 of the Convention. However, it stressed that prostitution was
incompatible with the dignity of a person if it was coerced. It held that it was where a person was coerced to engage
in, or continue with, prostitution that an issue arose under Article 3. Similarly, as regards Article 4 of the Convention,
the Court found that in the absence of coercion of the applicant to continue with prostitution, she could not be
considered to have been compelled to perform “forced or compulsory labour” within the meaning of that provision.

300. Relying on the above analysis of its case-law under Article 4 of the Convention (see paragraphs 281-285
above), the Court finds that the notion of “forced or compulsory labour” under Article 4 of the Convention aims to
protect against instances of serious exploitation, such as forced prostitution, irrespective of whether, in the
particular circumstances of a case, they are related to the specific human trafficking context. Moreover, any such
conduct may have elements qualifying it as “servitude” or “slavery” under Article 4, or may raise an issue under
another provision of the Convention (see paragraphs 241 and 280 above).

301. In this context, it is important to stress that “force” may encompass the subtle forms of coercive conduct
identified in the Court's case-law on Article 4 (see paragraphs 281-285 above), as well as by the ILO and in other
international materials (see, in particular, paragraphs 141-144 above).

302. The Court would also underline that the question whether a particular situation involves all the constituent
elements of “human trafficking” (action, means, purpose) and/or gives rise to a separate issue of forced prostitution
is a factual question which must be examined in the light of all the relevant circumstances of a case.
_(d) Conclusion on the material scope of Article 4_

303. In conclusion, having regard to the above considerations, the Court finds the following:

(i) Human trafficking falls within the scope of Article 4 of the Convention. This, however, does not exclude the
possibility that, in the particular circumstances of a case, a particular form of conduct related to human
trafficking may raise an issue under another provision of the Convention (see paragraph 297 above);

(ii) It is not possible to characterise conduct or a situation as an issue of human trafficking under Article 4 of the
Convention unless the constituent elements of the international definition of trafficking (action, means,
purpose), under the Anti-Trafficking Convention and the Palermo Protocol, are present. In this connection, from
the perspective of Article 4 of the Convention, the concept of human trafficking relates to both national and
transnational trafficking in human beings, irrespective of whether or not connected with organised crime (see
paragraph 296 above);

(iii) The notion of “forced or compulsory labour” under Article 4 of the Convention aims to protect against
instances of serious exploitation, such as forced prostitution, irrespective of whether, in the particular
circumstances of a case, they are related to the specific human trafficking context. Any such conduct may have
elements qualifying it as “slavery” or “servitude” under Article 4, or may raise an issue under another provision
of the Convention (see paragraphs 300-301 above);

(iv) The question whether a particular situation involved all the constituent elements of “human trafficking”
and/or gives rise to a separate issue of forced prostitution is a factual question which must be examined in the
light of all the relevant circumstances of a case (see paragraph 302 above).

_3. States' positive obligations under Article 4 of the Convention(a) The scope of the States' positive obligations_
_concerning human trafficking and forced prostitution_


-----

304. At the outset, the Court notes that the cases relating to human trafficking under Article 4 typically involve an
issue of the States' positive obligations under the Convention. Indeed, the applicants in these cases are normally
victims of trafficking or trafficking-related conduct by another private party, whose actions cannot attract the direct
responsibility of the State (see J. and Others v. Austria, cited above, §§ 108-109).

305. The nature and scope of the positive obligations under Article 4 are comprehensively set out in the Rantsev
case. The general principles summarised in _Rantsev represent the central tenets of the existing case-law and to_
date represent the relevant Convention framework within which cases of, or related to, human trafficking are
examined. These principles read as follows:

“283. The Court reiterates that, together with Articles 2 and 3, Article 4 enshrines one of the basic values of the
democratic societies making up the Council of Europe (Siliadin, cited above, § 82). Unlike most of the
substantive clauses of the Convention, Article 4 [§ 1] makes no provision for exceptions and no derogation
from it is permissible under Article 15 § 2 even in the event of a public emergency threatening the life of the
nation.

284. In assessing whether there has been a violation of Article 4, the relevant legal or regulatory framework in
place must be taken into account (see, mutatis mutandis, Nachova and Others v. Bulgaria [GC], nos. 43577/98

and 43579/98, § 93, ECHR 2005‑VII). The Court considers that the spectrum of safeguards set out in national

legislation must be adequate to ensure the practical and effective protection of the rights of victims or potential
victims of trafficking. Accordingly, in addition to criminal law measures to punish traffickers, Article 4 requires
member States to put in place adequate measures regulating businesses often used as a cover for human
trafficking. Furthermore, a State's immigration rules must address relevant concerns relating to
encouragement, facilitation or tolerance of trafficking (see, _mutatis mutandis,_ _Guerra and Others v. Italy, 19_

February 1998, §§ 58 to 60, Reports of Judgments and Decisions 1998‑I; Z and Others v. the United Kingdom

[GC], no. 29392/95, §§ 73 to 74, ECHR 2001‑V; and Nachova and Others, cited above, §§ 96 to 97 and 99
102).

285. In its Siliadin judgment, the Court confirmed that Article 4 entailed a specific positive obligation on member
States to penalise and prosecute effectively any act aimed at maintaining a person in a situation of slavery,
servitude or forced or compulsory labour (cited above, §§ 89 and 112). In order to comply with this obligation,
member States are required to put in place a legislative and administrative framework to prohibit and punish
trafficking. The Court observes that the Palermo Protocol and the Anti-Trafficking Convention refer to the need
for a comprehensive approach to combat trafficking which includes measures to prevent trafficking and to
protect victims, in addition to measures to punish traffickers (see paragraphs 149 and 163 above). It is clear
from the provisions of these two instruments that the Contracting States, including almost all of the member
States of the Council of Europe, have formed the view that only a combination of measures addressing all
three aspects can be effective in the fight against trafficking (see also the submissions of Interights and the
AIRE Centre at paragraphs 267 and 271 above). Accordingly, the duty to penalise and prosecute trafficking is
only one aspect of member States' general undertaking to combat trafficking. The extent of the positive
obligations arising under Article 4 must be considered within this broader context.

286. As with Articles 2 and 3 of the Convention, Article 4 may, in certain circumstances, require a State to take
operational measures to protect victims, or potential victims, of trafficking (see, _mutatis mutandis, Osman [v._

the United Kingdom, 28 October 1998, § 115, Reports of Judgments and Decisions 1998‑VIII]; and Mahmut

Kaya v. Turkey, no. 22535/93, § 115, ECHR 2000‑III). In order for a positive obligation to take operational

measures to arise in the circumstances of a particular case, it must be demonstrated that the State authorities
were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion that an identified
individual had been, or was at real and immediate risk of being, trafficked or exploited within the meaning of
Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti-Trafficking Convention. In the case of an answer
in the affirmative, there will be a violation of Article 4 of the Convention where the authorities fail to take


-----

appropriate measures within the scope of their powers to remove the individual from that situation or risk (see,
_mutatis mutandis, Osman, cited above, §§116 to 117; and Mahmut Kaya, cited above, §§ 115 to 116)._

287. Bearing in mind the difficulties involved in policing modern societies and the operational choices which
must be made in terms of priorities and resources, the obligation to take operational measures must, however,
be interpreted in a way which does not impose an impossible or disproportionate burden on the authorities
(see, mutatis mutandis, Osman, cited above, § 116). It is relevant to the consideration of the proportionality of
any positive obligation arising in the present case that the Palermo Protocol, signed by both Cyprus and the
Russian Federation in 2000, requires States to endeavour to provide for the physical safety of victims of
trafficking while in their territories and to establish comprehensive policies and programmes to prevent and
combat trafficking (see paragraphs 153 to 154 above). States are also required to provide relevant training for
law enforcement and immigration officials (see paragraph 155 above).

288. Like Articles 2 and 3, Article 4 also entails a procedural obligation to investigate situations of potential
trafficking. The requirement to investigate does not depend on a complaint from the victim or next-of-kin: once
the matter has come to the attention of the authorities they must act of their own motion (see, _mutatis_

_mutandis,_ _Paul and Audrey Edwards v. the United Kingdom, no. 46477/99, § 69, ECHR 2002‑II). For an_

investigation to be effective, it must be independent from those implicated in the events. It must also be
capable of leading to the identification and punishment of individuals responsible, an obligation not of result but
of means. A requirement of promptness and reasonable expedition is implicit in all cases but where the
possibility of removing the individual from the harmful situation is available, the investigation must be
undertaken as a matter of urgency. The victim or the next-of-kin must be involved in the procedure to the extent
necessary to safeguard their legitimate interests (see, _mutatis mutandis,_ _Paul and Audrey Edwards, cited_
above, §§ 70 to 73).”

306. It follows from the above that the general framework of positive obligations under Article 4 includes: (1) the
duty to put in place a legislative and administrative framework to prohibit and punish trafficking; (2) the duty, in
certain circumstances, to take operational measures to protect victims, or potential victims, of trafficking; and (3) a
procedural obligation to investigate situations of potential trafficking. In general, the first two aspects of the positive
obligations can be denoted as substantive, whereas the third aspect designates the States' (positive) procedural
obligation.

307. This latter obligation, which is in issue in the present case, will be elaborated in detail further below. Moreover,
given the conceptual proximity of human trafficking and forced prostitution under Article 4, the Court considers that
the relevant principles relating to human trafficking are accordingly applicable in cases concerning forced
prostitution (see, _mutatis mutandis,_ _C.N. v. the United Kingdom, cited above, §§ 65-69, concerning domestic_
servitude).
_(b) States' procedural obligations concerning human trafficking and forced prostitution_

308. The procedural obligation under Article 4 of the Convention, as an element of the broader concept of positive
obligations, essentially relates to the domestic authorities' duty to apply in practice the relevant criminal-law
mechanisms put in place to prohibit and punish conduct contrary to that provision (see, for instance, Rantsev, cited
above, § 288, and Chowdury and Others, cited above, § 116). As will be elaborated further below, this entails the
requirements of an effective investigation concerning allegations of treatment contrary to Article 4 of the
Convention.

309. The content of this procedural obligation concerning instances of human trafficking was set out in general in
the _Rantsev case (cited above, § 288). It draws largely on the Court's well-established case-law concerning the_
domestic authorities' procedural obligation, as developed under Articles 2 and 3 of the Convention (see paragraph
305 above). Indeed, ever since the _Siliadin case (cited above, § 89), the converging principles of the procedural_
obligation under Articles 2 and 3 of the Convention (see Mocanu and Others v. Romania [GC], nos. 10865/09 and 2
others, § 314, ECHR 2014 (extracts)) have traditionally informed the requirements of the procedural obligation
under Article 4 (see Rantsev, cited above, § 288; M. and Others v. Italy and Bulgaria, cited above, §§ 157-158; L.E.


-----

_v. Greece, cited above, § 68; J. and Others v. Austria, cited above, § 123; and Chowdury and Others, cited above,_
§ 116).

310. In the Court's view, given that Article 4, together with Articles 2 and 3, enshrines one of the basic values of the
democratic societies making up the Council of Europe (see Siliadin, cited above, § 82, and Rantsev, cited above, §
283; see also _Stummer, cited above, § 116), there are no grounds for revisiting this well-established approach_
concerning the procedural obligation under Article 4 of the Convention. Moreover, as already explained above,
these principles are accordingly applicable to instances of forced prostitution (see paragraph 307 above).

311. Accordingly, given that, as already noted, the procedural obligation under the converging principles of Articles
2 and 3 informs the specific content of the procedural obligation under Article 4 of the Convention, and in view of
the fact that Rantsev referred only to the most general aspects of this obligation (see paragraph 305 above), the

Court finds it important to set out, in so far as relevant and appropriate, some further principles of its case‑law in this

regard.

312. It should be noted at the outset that whereas the general scope of the State's positive obligations might differ
between cases where the treatment contrary to the Convention has been inflicted through the involvement of State
agents and cases where violence is inflicted by private individuals, the procedural requirements are similar (see
_Denis Vasilyev v. Russia, no. 32704/04, § 100, 17 December 2009, and, more recently, Milena Felicia Dumitrescu_
_v. Romania, no. 28440/07, § 52, 24 March 2015, and Hovhannisyan v. Armenia, no. 18419/13, § 55, 19 July 2018)._

313. These procedural requirements primarily concern the authorities' duty to institute and conduct an effective
investigation. As explained in the Court's case-law, that means instituting and conducting an investigation capable
of leading to the establishment of the facts and of identifying and – if appropriate – punishing those responsible (see
_Jeronovičs v. Latvia [GC], no. 44898/10, § 103, 5 July 2016, and Tsalikidis and Others v. Greece, no. 73974/14, §_
86, 16 November 2017; see also Rantsev, cited above, § 288).

314. In this connection it is important to stress that, in accordance with their procedural obligation, the authorities
must act of their own motion once the matter has come to their attention. In particular, they cannot leave it to the
initiative of the victim to take responsibility for the conduct of any investigatory procedures (see, for instance, Bouyid
_v. Belgium_ [GC], no. 23380/09, § 119, ECHR 2015, and _Abdurakhmanova and Abdulgamidova v. Russia, no._
41437/10, § 76, 22 September 2015; see also _Rantsev, cited above, § 288;_ _C.N. v. the United Kingdom, cited_
above, § 69; L.E. v. Greece, cited above, § 68; and J. and Others v. Austria, cited above, § 107).

315. The procedural obligation is a requirement of means and not of results (see Mustafa Tunç and Fecire Tunç v.
_Turkey_ [GC], no. 24014/05, § 173, 14 April 2015, and _Dimitar Shopov v. Bulgaria, no. 17253/07, § 48, 16 April_
2013; see also Rantsev, cited above, § 288; C.N. v. the United Kingdom, cited above, § 69; L.E. v. Greece, cited
above, § 68; and J. and Others v. Austria, cited above, § 107). There is no absolute right to obtain the prosecution
or conviction of any particular person where there were no culpable failures in seeking to hold perpetrators of
criminal offences accountable (see _A, B and C v. Latvia, no. 30808/11, § 149, 31 March 2016, with further_
references). Thus, the fact that an investigation ends without concrete, or with only limited, results is not indicative
of any failings as such (see, for instance, Brecknell v. the United Kingdom, no. 32457/04, § 66, 27 November 2007).
Moreover, the procedural obligation must not be interpreted in such a way as to impose an impossible or
disproportionate burden on the authorities (see J. and Others v. Austria, cited above, § 107).

316. Nevertheless, the authorities must take whatever reasonable steps they can to collect evidence and elucidate
the circumstances of the case. In particular, the investigation's conclusions must be based on thorough, objective
and impartial analysis of all relevant elements. Failing to follow an obvious line of inquiry undermines to a decisive
extent the investigation's ability to establish the circumstances of the case and the identity of those responsible (see
_Hentschel and Stark v. Germany, no. 47274/15, § 94, 9 November 2017, with further reference; see also J. and_
_Others v. Austria, cited above, § 107)._

317. As to the level of scrutiny to be applied by the Court in this regard, it is important to stress that, although the
Court has recognised that it must be cautious in taking on the role of a first-instance tribunal of fact where this is not


-----

rendered unavoidable by the circumstances of a particular case, it has to apply a “particularly thorough scrutiny”
even if certain domestic proceedings and investigations have already taken place (see Bouyid, cited above, § 85,

with further references; see also Aktaş v. Turkey, no. 24351/94, § 271, ECHR 2003‑V (extracts), and Y. v. Slovenia,

no. 41107/10, § 96, ECHR 2015 (extracts)).

318. In the context of Articles 2 and 3, the Court has held that any deficiency in the investigation which undermines
its capability of establishing the circumstances of the case or the person responsible is liable to fall foul of the
required measure of effectiveness (see, in the context of Article 2, _Nachova and Others v. Bulgaria [GC], nos._

43577/98 and 43579/98, § 113, ECHR 2005‑VII, and Armani da Silva, v. the United Kingdom [GC], no. 5878/08, §

233 _in fine, 30 March 2016; see also, in the context of Article 3,_ _Denis Vasilyev, cited above, § 100, and_ _Milena_
_Felicia Dumitrescu, cited above, § 52). However, in this regard, it is not possible to reduce the variety of situations_
which might occur to a bare check-list of acts of investigation or other simplified criteria (see _Mustafa Tunç and_
_Fecire Tunç, cited above, § 176)._

319. In other words, compliance with the procedural obligation must be assessed on the basis of several essential
parameters (see _Bouyid, cited above, §§ 118-123; see also_ _Rantsev, cited above, § 288, and_ _Chowdury and_
_Others, cited above, §§ 89 and 116), including those mentioned above (see paragraphs 313-316 above). These_
elements are inter-related and each of them, taken separately, does not amount to an end in itself. They are criteria
which, taken jointly, enable the degree of effectiveness of the investigation to be assessed (see Mustafa Tunç and
_Fecire Tunç, cited above, § 225, and Nicolae Virgiliu Tănase v. Romania [GC], no. 41720/13, § 171, 25 June 2019;_
see also Sarbyanova-Pashaliyska and Pashaliyska v. Bulgaria, no. 3524/14, § 37, 12 January 2017).

320. The above approach under Articles 2 and 3 in essence corresponds to the Court's approach in Siliadin (cited

above, § 130), where it stressed that the possible defects in the relevant proceedings and the decision‑making

process must amount to significant flaws in order to raise an issue under Article 4 (see also, for instance, M.G.C. v.
_Romania, no. 61495/11, §§ 60-61, 15 March 2016, concerning sexual abuse under Articles 3 and 8 of the_
Convention). In other words, the Court is not concerned with allegations of errors or isolated omissions but only

significant shortcomings in the proceedings and the relevant decision‑making process (see, for the relevant

analysis, _Söderman v. Sweden [GC], no. 5786/08, §§ 90-91, ECHR 2013), namely those that are capable of_
undermining the investigation's capability of establishing the circumstances of the case or the person responsible.
_4. Application of the above principles to the present case(a) Whether the circumstances of the present case gave_
_rise to an issue under Article 4 of the Convention_

321. At the outset, the Court notes that the Government contested that the circumstances of the present case gave
rise to an issue under Article 4 of the Convention (see paragraphs 230 and 238 above).

322. In this connection, and having regard to the parties' arguments relating to the recognition of the applicant's
status as a potential victim of human trafficking (see paragraphs 232 and 235 above), the Court first finds it
necessary to clarify that administrative recognition of the status of a potential victim of human trafficking cannot be
taken as recognition that the elements of the offence of human trafficking have been made out. Such special
treatment of a potential victim of human trafficking does not necessarily presuppose an official confirmation that the
offence has been established, and may be independent of the authorities' duty to investigate. Indeed, (potential)
victims need support even before the offence of human trafficking is formally established; otherwise, this would run
counter to the whole purpose of victim protection in trafficking cases. The question whether the elements of the
crime are present has to be answered in subsequent criminal proceedings (see J. and Others v. Austria, cited
above, § 115). In this connection, the Court would also stress the necessity of protection of the rights of the
suspects or accused, in particular the right to the presumption of innocence and other fair trial guarantees under
Article 6 of the Convention (see, for instance, _Schatschaschwili v. Germany_ [GC], no. 9154/10, §§ 101 and 103104, ECHR 2015).

323. Accordingly, having regard to the above considerations, the Court cannot attach decisive importance to the
fact that the applicant obtained administrative recognition of the status of a victim of human trafficking from the
Human Rights Office (see paragraph 85 above).


-----

324. The Court further notes, as regards the applicability of the protection under Article 4 in relation to human
trafficking or forced prostitution, that when an applicant's complaint is essentially of a procedural nature as in the
present case, it must examine whether, in the circumstances of a particular case, the applicant made an arguable
claim or whether there was prima facie evidence (commencement de preuve) of her having been subjected to such
prohibited treatment (see, to that effect, C.N. v. the United Kingdom, cited above, § 72, and J and Others v. Austria,
cited above, § 112-113; see also _Rantsev, cited above, § 288, where reference is made to the situations of_
“potential trafficking”). This corresponds in essence to the Court's approach in other cases concerning, in particular,
Article 3 of the Convention (see, for instance, Hassan v. the United Kingdom [GC], no. 29750/09, § 62, ECHR 2014;
_Bouyid, cited above, § 124; and Beganović v. Croatia, no. 46423/06, § 68, 25 June 2009)._

325. In this connection, a conclusion as to whether the domestic authorities' procedural obligation arose has to be
based on the circumstances prevailing at the time when the relevant allegations were made or when the prima facie
evidence of treatment contrary to Article 4 was brought to the authorities' attention and not on a subsequent
conclusion reached upon the completion of the investigation or the relevant proceedings (see _C.N. v. the United_
_Kingdom, cited above, § 72; compare also_ _Mustafa Tunç and Fecire Tunç, cited above, §§ 132-134, concerning_
Article 2, and Alpar v. Turkey, no. 22643/07, § 42, 26 January 2016, concerning Article 3). This is particularly true
when there are allegations that such conclusions and the relevant domestic proceedings were marred by significant
procedural flaws. Indeed, relying on such domestic findings and conclusions would entail a risk of creating a circular
reasoning resulting in a case concerning an arguable claim or prima facie evidence of treatment contrary to Article 4
remaining outside the Court's scrutiny under the Convention.

326. In the present case, the applicant complained before the domestic authorities that she had been forced into
prostitution by T.M. She explained how initially he had contacted her via Facebook and that on that occasion T.M.
had presented himself as a friend of her parents and promised to help her finding a job. She also explained that she
had had no reason to question T.M.'s intentions and continued exchanging messages with him, which eventually
led to a first situation where he had insisted on her providing sexual services to others. On that occasion, according
to the applicant's allegations, T.M. had assured her that she would be doing that only until he found her a proper
job. However, according to the applicant, T.M. had afterwards started exerting pressure on her by the use of force,
threats and close monitoring. He had also made the necessary arrangements for the provision of her sexual
services by securing accommodation, transportation and other facilities, such as by providing her with a mobile
phone and advertising her services. The applicant also stated that T.M. had taken half the money she had charged
for the provision of sexual services (see paragraphs 12-17 above).

327. The preliminary police investigation concerning the applicant's allegations led to a search of T.M.'s premises
and his car, during which the police found condoms, two automatic rifles and the accompanying ammunition, a
hand grenade and a number of mobile phones (see paragraph 19 above). In addition, it was established during the
preliminary investigation that T.M. had been trained as a policeman and that he had been convicted of procuring
prostitution using force, and of rape (see paragraphs 20-21 above). During T.M.'s first questioning, he denied
forcing the applicant into prostitution but admitted that he had on one occasion used force against her and also
stated that he had lent her money for the flat she had rented (see paragraph 23 above). On the basis of the
applicant's complaint and the results of the preliminary investigation, a further investigation was conducted by the
State Attorney's Office (see paragraphs 24-37 above).

328. In the Court's view, the above circumstances clearly indicate that the applicant made an arguable claim and
that furthermore there was prima facie evidence that she had been the victim of treatment contrary to Article 4 of
the Convention, as defined by the Court (see paragraph 303 above).

329. Thus, for instance, the applicant's personal situation undoubtedly suggested that she belonged to a vulnerable
group (see paragraphs 10 and 158 above), while T.M.'s position and background suggested that he was capable of
assuming a dominant position over her and abusing her vulnerability for the purpose of exploitation of prostitution
(see paragraphs 20-21 above). Further, the means used by T.M. when he had allegedly first contacted the applicant
and recruited her is also indicative of one of the means often used by traffickers to recruit their victims. This was
also true of the alleged promise of employment, accompanied by the applicant's belief that she had no reason for
concern (see paragraphs 157-158 above).


-----

330. Moreover, the applicant's allegations that T.M. made the necessary arrangements for her to provide sexual
services by securing accommodation and other facilities suggested the elements of harbouring as one of the
constituent “actions” of trafficking (see paragraphs 113-114 above). It should further be noted that T.M. admitted
using force against the applicant, which required a careful and subtle assessment in the context of the “means”
element of human trafficking for the purpose of exploitation of prostitution. The same is true for T.M.'s statement
that he lent money to the applicant, which raised an issue of possible debt bondage as another “means” of
trafficking.

331. It should also be noted that the above allegations and circumstances, which suggested, in particular, that T.M.
unlawfully earned money from the provision of sexual services by the applicant in an environment where arguably
he assumed a dominant position over her and had recourse to force, threats and other forms of coercion, in any
event gave rise to an arguable claim and the existence of prima facie evidence of forced prostitution, which is, in
itself, a prohibited form of conduct under Article 4 of the Convention (see paragraph 300 above).

332. In sum, the Court finds that the applicant made an arguable claim and that there was prima facie evidence that
she had been subjected to treatment contrary to Article 4 of the Convention – human trafficking and/or forced
prostitution –, which in turn triggered the domestic authorities' procedural obligation under that provision (compare
_C.N. v. the United Kingdom, cited above, § 72). The Court therefore rejects the Government's preliminary objection_
concerning the applicability of Article 4 of the Convention which it has joined to the merits (see paragraph 238
above).
_(b) Compliance with the procedural obligation under Article 4 of the Convention_

333. The Court reiterates that the applicant's complaint is of a procedural nature (see paragraph 229 above). Thus,
having regard to the scope of the respondent State's positive obligations (see paragraph 306 above), in this case
the Court will deal with the applicant's complaint of a deficient response by the domestic authorities to her
allegations of human trafficking and/or forced prostitution.

334. In making this assessment the Court will examine whether there were significant flaws or shortcomings in the
relevant domestic proceedings and decision-making processes (see paragraph 320 above). In particular, the Court
will assess whether the applicant's allegations under Article 4 were properly investigated and subjected to careful
scrutiny in accordance with the applicable standards of its case-law (see paragraphs 317-320 above).

335. However, it should be noted that the applicant did not clearly articulate her complaints as regards the relevant
procedural deficiencies and omissions, a circumstance which gave rise to the question regarding the scope of the
case before the Court. Thus, having regard to its findings concerning the scope of the case (see paragraphs 227229 above), although the Court can take into account the particular procedural omissions it considers relevant in the
context of its overall assessment of the applicant's complaint, in the present case it must exercise caution when
assessing the domestic authorities' compliance with their procedural obligation under Article 4 of the Convention. In
any event, in accordance with the general principles set out above, the Court will focus only on significant
shortcomings in the domestic authorities' procedural response to the applicant's allegations of human trafficking
and/or forced prostitution, namely those that were capable of undermining the investigation's capability of
establishing the relevant circumstances of the case (see paragraph 320 above).

336. In the present case, although the prosecuting authorities – namely, the police and the relevant State Attorney's
Office – reacted promptly to the applicant's allegations against T.M., in their investigation they failed to follow some
obvious lines of inquiry capable of elucidating the circumstances of the case and establishing the true nature of the
relationship between the applicant and T.M. As already stressed, such a requirement follows from the domestic
authorities' procedural obligation and does not depend on an initiative of the applicant to take responsibility for the
conduct of any investigatory procedures (see paragraph 314 above; see also Mihhailov v. Estonia, no. 64418/10, §
126, 30 August 2016). Indeed, as the prosecuting authorities are better placed than a victim to conduct the
investigation, any action or lack of action on the part of the victim cannot justify a lack of action on the part of the
prosecuting authorities (see, _mutatis mutandis,_ _Asllani v. the former Yugoslav Republic of Macedonia, no._
24058/13, § 62 in fine, 10 December 2015).


-----

337. In this connection, for instance, it should be noted that there is no indication that the prosecuting authorities
made any effort to inquire into the circumstances of the applicant's and T.M.'s contacts via Facebook, although, as
noted above, such contacts represent one of the recognised ways used by traffickers to recruit their victims. Indeed,
the prosecuting authorities never sought to inspect the applicant's or T.M.'s Facebook accounts and thus to
ascertain the nature of the applicant's and T.M.'s first contact and their further exchanges. Moreover, the available
evidence suggested that T.M. used Facebook to threaten the applicant after she had left him (see paragraphs 37
and 67 above), but there is no indication that the authorities followed this lead to determine the real nature of their
relationship and whether those threats suggested the use of a means of coercion by T.M.

338. Further, neither during the investigation nor after the relevant information surfaced during the trial did the
prosecuting authorities give any consideration to obtaining evidence from the applicant's parents, in particular the
applicant's mother. Nevertheless, the applicant's mother appears to have had earlier contacts and difficulties with
T.M., which T.M., according to the available evidence, used as one of the means of pressure and threats towards
the applicant (see paragraphs 62, 67 and 73 above).

339. The prosecuting authorities also never sought to identify and interview the owner of the flat where the applicant
lived with T.M. in order to determine the circumstances in which the flat had been rented and thus to clarify who in
reality was in charge of the whole rental process, which could have been relevant for establishing the potential
action of “harbouring”, as an element of human trafficking. Moreover, although later in the course of the criminal
proceedings the applicant stated that the owner of the flat used to come and visit the flat (see paragraph 63 above),
the State Attorney's Office did not seek to have the owner questioned in order to establish her impression of the
atmosphere in the flat and the relationship between the applicant and T.M. during the critical period.

340. It is also worth noting that the prosecuting authorities did not identify and interview any of the neighbours. They
too could also potentially have been able to provide information on the circumstances of the applicant's and T.M.'s
stay in the flat, relating, in particular, to the question whether and how often the applicant was seen leaving the flat,
whether she went outside alone without T.M., and whether and how often T.M. left the flat. All these elements could
have clarified the applicant's allegations as regards the circumstances in which she was under T.M.'s control during
their stay in the flat, it being understood that the mere fact that the applicant on occasions left the flat could not
conclusively mean that she was not coerced by T.M. (compare Siliadin, cited above, § 127).

341. Against the background of the above shortcomings, it should be noted that, in addition to the search of T.M.'s
flat and car and the questioning of the applicant and T.M., the only action taken by the prosecuting authorities was
the questioning of the applicant's friend M.I. (see paragraphs 32-37 above). However, the evidence she gave during
the investigation and the criminal proceedings contradicted in places some of the information provided by the
applicant. Moreover, M.I.'s statement suggested that the key persons having information on the applicant's alleged
escape from T.M. were her (M.I.'s) mother and boyfriend (see paragraphs 33 and 66 above).

342. However, the prosecuting authorities never sought to question M.I.'s mother and boyfriend, who could have
provided details on the applicant's alleged escape from T.M. and whose evidence could have served to ascertain
the consistency of M.I.'s statement and reliability of her oral evidence. The same is true of the applicant's and M.I.'s
contradicting statements as regards the circumstances in which the applicant collected her belongings from the flat
where she had lived with T.M., which could have been clarified by questioning the owner of the flat. However, as
already noted, the prosecuting authorities never sought to question the owner of the flat.

343. All these elements, in the Court's view, suggest that the prosecuting authorities did not effectively investigate
all relevant circumstances of the case and follow some of the obvious lines of inquiry in order to gather the available
evidence, in accordance with their procedural obligation under Article 4. Instead, they relied heavily on the
applicant's statement and thus, in essence, created a situation in the subsequent court proceedings where her
allegations simply had to be pitted against the denial of T.M., without much further evidence being presented.

344. In this connection, the Court notes the position of GRETA and other international bodies on the requirements
of effective investigation and prosecution of human trafficking offences. In particular, having regard to the
prosecuting authorities' decisive reliance on the applicant's statement (see paragraphs 40, 80 and 92 above) and
th i f il t f ll f th b i li f i i th C t t th t it h l d b i d i th


-----

work of GRETA and other expert bodies that there may be different reasons why victims of human trafficking and
different forms of sexual abuse may be reluctant to cooperate with the authorities and to disclose all the details of
the case. Moreover, the possible impact of psychological trauma must be taken into account. There is thus a risk of
overreliance on the victim's testimony alone, which leads to the necessity to clarify and – if appropriate – support
the victim's statement by other evidence (see paragraphs 138, 171, 206 and 260 above).

345. The Court is of the view that the above multiple shortcomings in the conduct of the case by the prosecuting
authorities fundamentally undermined the domestic authorities' – including the relevant courts' – ability to determine
the true nature of the applicant's and T.M.'s relationship and whether the applicant had been exploited by him as

she alleged (compare Makaratzis v. Greece [GC], no. 50385/99, § 77, ECHR 2004‑XI).

346. This is therefore sufficient for the Court to conclude that there were significant flaws in the domestic authorities'
procedural response to the arguable claim and prima facie evidence that the applicant had been subjected to
treatment contrary to Article 4 of the Convention. Accordingly, the Court finds that the manner in which the criminallaw mechanisms were implemented in the instant case was defective to the point of constituting a violation of the
respondent State's procedural obligation under Article 4 of the Convention.

347. There has therefore been a violation of Article 4 of the Convention in its procedural limb.
_III. APPLICATION OF ARTICLE 41 OF THE CONVENTION_

348. Article 41 of the Convention provides:

“If the Court finds that there has been a violation of the Convention or the Protocols thereto, and if the internal
law of the High Contracting Party concerned allows only partial reparation to be made, the Court shall, if
necessary, afford just satisfaction to the injured party.”

_A. Damage_

349. Before the Chamber the applicant claimed 20,000 euros (EUR) in respect of non-pecuniary damage. The
Government contested this claim as unfounded, excessive and unsubstantiated.

350. The Chamber decided, on an equitable basis, to award the applicant EUR 5,000 in respect of non-pecuniary
damage.

351. In the proceedings before the Grand Chamber the parties did not alter their submissions under this head. The
Court upholds the Chamber judgment in respect of the claim for damage and awards the applicant the same
amount as the Chamber: EUR 5,000 in respect of non-pecuniary damage.
_B. Costs and expenses_

352. In the Chamber proceedings the applicant claimed EUR 4,376.15 for the costs and expenses related to her
case before the Court. The Government argued that the applicant had been represented by a lawyer provided by
the Rosa Centre, whose relevant activities were largely funded by the State. They also claimed that the applicant's
request for costs and expenses was unsubstantiated and excessive.

353. The Chamber dismissed the applicant's claim for costs and expenses on the grounds that she had not refuted
the Government's submission that her representative had already been paid from the State funds.

354. Before the Grand Chamber the applicant claimed 62,353.85 Croatian kunas for the costs and expenses of the
proceedings before the Chamber and the Grand Chamber. The Government contested this claim.

355. The Court notes that the applicant failed to provide any proof of payment or of an obligation to pay the costs
and expenses claimed, whether in respect of the Chamber or the Grand Chamber proceedings. In the absence of
such documents, the Court finds no basis on which to accept that the costs and expenses claimed by the applicant
were actually incurred by her (compare _Merabishvili v. Georgia_ [GC], no. 72508/13, §§ 371-372, 28 November
2017). The Court also notes that the applicant was granted legal aid for the proceedings before the Grand
Chamber. It therefore dismisses the applicant's claim for costs and expenses.


-----

_C. Default interest_

356. The Court considers it appropriate that the default interest rate should be based on the marginal lending rate of
the European Central Bank, to which should be added three percentage points.
**FOR THESE REASONS, THE COURT, UNANIMOUSLY,**

1. _Joins to the merits the Government's preliminary objection concerning the applicability of Article 4 of the_
Convention and dismisses it;

2. Dismisses the Government's other preliminary objection;

3. Holds that there has been a violation of Article 4 of the Convention in its procedural limb;

4. Holds that the respondent State is to pay the applicant, within three months, EUR 5,000 (five thousand euros),
plus any tax that may be chargeable, in respect of non-pecuniary damage, to be converted into Croatian kunas at
the rate applicable at the date of settlement; and that from the expiry of the above-mentioned three months until
settlement simple interest shall be payable on the above amount at a rate equal to the marginal lending rate of the
European Central Bank during the default period plus three percentage points;

5. Dismisses the remainder of the applicant's claim for just satisfaction.
**CONCURRING OPINION OF JUDGE TURKOVIĆ**

Whilst I agree with the Court's conclusion I would like, however, to make several remarks relating to the procedural
obligations under the Convention.

Firstly, the criteria for an investigation to be considered effective are the same under Articles 2, 3 and 4 of the
Convention (see paragraphs 310 and 319 of the judgment), and under all three Articles the Court applies the same
level of scrutiny, which is a particularly thorough one (see paragraph 317 of the judgment). In fact, the criteria for an
effective investigation (independence, thoroughness, promptness, public oversight and the victim's involvement,
see paragraph 305 of the judgment) should be the same across all the Articles of the Convention (for example, in
the context of Article 5, in situations such as the arrest of a person of whom all traces are subsequently lost, or
arbitrary deprivation of liberty[1]; and also in the context of serious violations of the rights guaranteed by Articles 8, 9,
10 and 11 of the Convention, such as sexual abuse[2], insults and threats[3], the illegal search of an apartment[4],
attacks on members of certain religious groups[5], attacks on journalists[6] or protesters[7], violence motivated by
discrimination under Article 14 of the Convention[8], and the violation of property rights under Article 1 of Protocol No.
1 to the Convention[9]).

Secondly, once there is an arguable complaint about the effectiveness of an investigation the Court is obliged to
look at each of these criteria separately (even if some are not specifically addressed by the applicant in the
application, the questions put at the communication stage should be broad enough to cover all the criteria), and
only if all of them are fulfilled can the investigation be considered effective. As the Court has put it, none of the
criteria amounts to an end in itself (see paragraph 319 of the judgment). However, only significant flaws in the
fulfilment of any of these criteria, that is, flaws that are capable of undermining the investigation's capability of
establishing the circumstances of the case or the person responsible, merit finding that the investigation was not
effective (see paragraph 320 of the judgment). At the same time, the fact that one criterion has been fulfilled cannot
offset a serious flaw or flaws in fulfilling the other criteria.

Thirdly, the Court has specified that the State has a duty under Article 4 to carry out an effective official
investigation where an individual makes an “arguable complaint” of having been subjected to treatment contrary to
Article 4, or, in the absence of an express complaint, where there is prima facie evidence that he or she been
subjected to such treatment. The Court has further emphasised that this corresponds in essence to the Court's
approach in other cases concerning, in particular, Article 3 of the Convention (see paragraph 324 of the judgment),
meaning that under both Articles the triggering standard for the obligation of the State to institute some form of
effective investigation is the same. Consequently, the prima facie evidence to which the Court refers in this
judgment (see paragraphs 324, 325, 331 and 332) corresponds to the notion of “sufficiently clear indications” to


-----

which the Court commonly refers under Article 3 in this regard (see, for example, Hassan v. the United Kingdom

[GC], no. 29750/09, § 62, ECHR 2014; _M.S. v. Croatia (no. 2), no. 75450/12, § 76, 19 February 2015;_ _Members_
_(97) of the Gldani Congregation of Jehovah's Witnesses, cited above, § 97; and_ _Bati and Others v. Turkey, nos._

33097/96 and 57834/00, § 133, ECHR 2004‑IV (extracts)).

Fourthly, in the present case the applicant made an arguable complaint at the domestic level and there were at the
same time sufficiently clear indications (prima facie evidence) that she had been subjected to human trafficking and
forced prostitution. This is reflected in the language used in paragraphs 331 and 332 of the judgment. However, that
does not mean that both elements – an arguable complaint and sufficiently clear indications – must coincide in
order for a duty to carry out an effective investigation to arise for a State. Either element suffices in this regard (see
paragraph 324 of the judgment). This follows clearly from the obligation of the authorities to act of their own motion
once the matter has come to their attention (see paragraph 314 of the judgment).

Fifthly, as the authorities have to act of their own motion, the Court has emphasised that they cannot leave it to the
initiative of the victim to take responsibility for the conduct of any investigatory procedures (ibid.). In this connection
it is important to keep in mind that the Court considers that the provisions often found in contemporary domestic
criminal-procedure laws, relating to the various rights of victims, are not to be understood as imposing an obligation
for victims to use those rights in the context of exhaustion of domestic remedies (see _Tadić v. Croatia, no._
10633/15, § 43, 23 November 2017).

Sixthly, it is important to note that when an investigation leads to the initiation of proceedings before the domestic
courts, the proceedings as a whole, including the trial phase, must meet the above criteria for an effective

investigation (see _Öneryýldýz v. Turkey_ [GC], no. 48939/99, §§ 95‑96, ECHR 2004‑XII; _Ali and_ _Ayşe Duran v._

_Turkey, no. 42942/02, § 61, 8 April 2008; and Chowdury and Others v. Greece, 21884/15, §§ 123 and §§ 127-28,_
30 March 2017). The domestic courts must not allow the perpetrator to go unpunished. Compliance with a State's
procedural obligation under the Convention requires the domestic legal system to demonstrate its capacity and
willingness to apply the criminal law against those who have unlawfully taken the life of another, violated his or her
physical integrity (see _Aðdaş v. Turkey, no. 34592, § 102, 27 July 2004, and_ _McKerr v. the United Kingdom, no._

28883/95, § 134, ECHR 2001‑III) or grossly violated another guaranteed right of a person, for instance by exposing

the person to forced labour (see Chowdury and Others, cited above). Criminal proceedings before an independent
and impartial tribunal in which the principle of deliberation is respected usually provide sufficient possibilities for
establishing the facts and criminal responsibility (see Aðdaþ, cited above, § 102, and McKerr, cited above, § 134).

Furthermore, although the domestic courts have considerable discretion in choosing the appropriate sanction for
serious human rights violations, the Court retains a certain measure of supervision and has the possibility to
intervene in cases where there is a clear disproportion between the offence committed and the sanction imposed
(see Armani Da Silva v. the United Kingdom, no. 5878/08, § 285, 30 March 2016; see also Kasap and Others v.
_Turkey, no. 8656/10, §§ 60-62, 14 January 2014; Darraj v. France, no. 34588/07, § 49, 4 November 2010; Kopylov_
_v. Russia, no. 3933/04, § 141, 29 July 2010; and_ _Chowdury and Others,_ cited above, §§ 124-27). The Court's
review is not limited to the severity of the sentence imposed by the domestic courts, but also includes the manner in
which the sentence is executed (see Enukidze and Girgvliani v. Georgia, no. 25091/07, §§ 269 and 275, 26 April
2011; Ali and Ayşe Duran, cited above, § 69; A. v. Croatia, no. 55164/08, §§ 75-80, 14 October 2010; and Branko
_Tomašić and Others v. Croatia, no. 46598/06, §§ 55-61 and § 65, 15 January 2009). Finally, States have a duty to_
enforce, without undue delay, final judgments against perpetrators (see Kitanovska Stanojkovic and Others v. the
_former Yugoslav Republic of Macedonia, no. 2319/14, § 32, 13 October 2016)._

It is regrettable that in the present case the Court, having found multiple shortcomings in the conduct of the case by
the prosecuting authorities, stopped its review there and concluded that this was sufficient in order to find that the
manner in which the criminal-law mechanisms were implemented in the instant case was defective to the point of
constituting a violation of the respondent State's procedural obligation under Article 4 of the Convention (see
paragraphs 345-46 of the judgment). In view of the alleged violations (see paragraphs 254 and 255 of the judgment
and §§ 46 and 47 of the Chamber judgment), this case presented an opportunity to elaborate further on the


-----

procedural obligations arising not only in the context of an effective investigation but in the context of an effective
trial as well.

Lastly, the Court notes that in the work of GRETA and other expert bodies it has already been recognised that there
may be different reasons why victims of human trafficking and of different forms of sexual abuse may be reluctant to
cooperate with the authorities and to disclose all the details of the case, and it recognises the need for the domestic
authorities, including the courts, to take the possible impact of the victim's psychological trauma into account (see
paragraph 344 of the judgment). In this way the Court has indicated that flaws in the protection and treatment of
victims and their testimonies, and in particular disregard for their possible psychological trauma and overreliance on
the victim's testimony, are elements to be taken into consideration in reviewing the State's procedural obligations in
criminal proceedings. The Court is increasingly recognising victims' rights in criminal proceedings as human rights,
and as it has demonstrated in this case, it is ready to acknowledge the need to protect them not only under Article
8, as part of the effective respect of private life and personal integrity (see Y. v. Slovenia, no. 41107/10, §§ 100-01
and §§ 103-04, ECHR 2015 (extracts)), but also as part of a procedural obligation for the State (see paragraph 344
of the judgment), provided that a fair balance has been struck between the competing interests of the defence and
the rights of the victims (see Y. v. Slovenia, cited above, § 103).

1

**JOINT CONCURRING OPINION OF JUDGES O'LEARY AND RAVARANI**

We have, with some hesitation, voted in favour of finding a violation of the procedural limb of Article 4 of the
Convention in the present case.

The reason for supporting a limited procedural violation lies in certain shortcomings in the domestic investigation
relating to the applicant's complaint of forced prostitution (see §§ 341-355 of the Grand Chamber judgment).

Furthermore, at the heart of the applicant's domestic complaint and the one she principally brought before this
Court lay the failure of the trial court, after having held that the constituent element of coercion could not be
established in order to convict T.M. of forced prostitution under the Croatian Criminal Code, to reclassify the charge
to the more basic form of procuring prostitution. This was an offence, she argued, with which he could have been
convicted given the available evidence. Since such a reclassification complaint, brought by an alleged victim, has
difficulty finding a proper home in the Convention and its case-law, a finding of no violation would have further
compounded the impunity of which the accused may have benefitted and the applicant essentially complained.
_1. Problematic scope of the case_

Our first difficulty lies with the scope of the case. As demonstrated ably by judge Koskelo in her dissenting opinion
at Chamber level there is a clear risk that the Grand Chamber has examined the case and sought to develop

1 See Kurt v Turkey, 25 May 1998, § 124, Reports of Judgments and Decisions 1998-III; Orhan v Turkey, no 25656/94,
§ 369, 18 June 2002; _Varnava and Others v Turkey [GC], nos 16064/90 and 8 others, § 208, ECHR 2009; and_ _Al_
_Nashiri v Poland, no 28761/11, § 529, 24 July 2014._

2 See B.V and Others v Croatia (dec.), no 38435/13, § 154, 15 December 2015.

3 See R.B v Hungary, no 64602/12, § 80, 12 April 2016.

4 See Bagiyeva v Ukraine, no 41085/05, §§ 47 and 64, 28 April 2016.

5 See Members of the Gldani Congregation of Jehovah's Witnesses and Others v Georgia, no 71156/01, § 114, 3 May
2007, and Karaahmed v Bulgaria, no 30587/13, § 110, 24 February 2015.

6 See Ozgur Gundem v Turkey, no 23144/93, § 45, ECHR 2000-III.

7 See Promo Lex and Others v the Republic of Moldova, no 42757/09, § 23, 24 February 2015.

8 See Nachova and Others v Bulgaria [GC], nos 43577/98 and 43579/98, § 161, ECHR 2005-VII.

9 S _Bl_ _b_ _L_ _i_ 70930/01 § 67 14 O b 2008


-----

general principles with reference to facts which the applicant neither raised domestically nor relied on in her
application (see §§ 2 – 10 of the dissent at Chamber level).

Applications are lodged with this Court by applicants who often act without means and without the benefit of legal
representation; although this was not the applicant's case. It is generally accepted that an applicant can clarify or
elaborate upon his or her initial submission during the course of the Convention procedure (see § 219 of the Grand
Chamber judgment and the authorities cited therein). It is also accepted that the Court has to treat such applications
with a degree of flexibility in order for the rights guaranteed by the Convention to be practical and effective. It would
be too strict, in our view, to conclude, as the dissenting Judge did at Chamber level, that the applicant raised no
issues regarding the investigation of her forced prostitution complaint or in relation to the collection of evidence. If
the trial court failed to establish the constituent element of coercion, the applicant in challenging the acquittal was
perhaps implicitly, but nevertheless logically, impugning the investigation which led to that result. Her main
complaint was nevertheless the failure by the trial and appeal courts to convict the defendant of the lesser charge.

The principle of ne ultra petitum means, quite literally, that a court should not go “beyond the request” or “beyond
the scope of the dispute”. There is a limit to the flexibility which can be afforded one party without the procedural
rights and principles which form the backbone of the Court's own Article 6 case-law being traduced. The Grand
Chamber recognises that “the applicant did not clearly articulate her complaints as regards the relevant procedural
deficiencies and omissions, a circumstance which gave rise to the question regarding the scope of the case before
the Court” (see §§ 220 and 335). One may accept that the “bones” of a complaint about procedural deficiencies
regarding her complaint of forced prostitution can be made out in the original application, in which she relied on
Articles 3, 6, 8 and 14 and Article 1 of Protocol no. 12 of the Convention. To those bare bones the applicant
subsequently added some meat in her written submissions at Chamber level.

According to well-established case-law, the Court has jurisdiction to review the circumstances complained of in the
light of the entirety of the Convention and it can view the facts presented in a different manner, requalifying under a
Convention article not initially relied on. It is nevertheless limited by the facts presented by the applicants in the light
of national law. The system of protection established by the Convention does not enable the Court to seize on facts
that have not been adduced by the applicant and to examine those facts for compatibility with the Convention (see
_Radomilja and others v. Croatia [GC], nos. 37685/10 and 22768/12, §§ 110-125, 20 March 2018; and_ _Foti and_
_others v. Italy, nos. 7604/76, 7719/76, 7781/77 and 7913/77, § 44, 10 December 1982)._

However, what an applicant cannot be allowed to do when a case is communicated under a different Convention
article than the one originally relied on, in no doubt a well-meaning application of the _jura novit curia principle, is_
seek to expand the case to cover facts and legal arguments which go beyond the scope of the case referred to the
Court pursuant to Article 32 of the Convention. Nor can they be allowed to seek to further expand that scope
following referral of the case to the Grand Chamber pursuant to Article 43 of the Convention. This is what has
happened in the instant case.

At domestic level, six weeks after T.M. was indicted for coerced prostitution, the applicant was identified as a
potential victim of human trafficking, an administrative status taken by a multi-disciplinary domestic body. The
purpose of that status was to ensure that a possibly vulnerable person receive the necessary assistance as the
domestic proceedings advanced. As the Grand Chamber recognises, this does not mean that the three constituent
elements of the offence of human trafficking had been made out and is independent of any duty to investigate (see
§ 322 of the Grand Chamber judgment). Having initially complained of the failure to investigate forced prostitution
properly, or convict T.M. of the lesser offence of procuring prostitution if commission of the former offence proved
impossible to establish, in her written submissions before the Chamber the applicant complained further, and for the
first time, of the failure by the authorities to charge and convict T.M. of the more serious offence of human trafficking
under Article 175 of the Criminal Code. This expansion of the scope of her complaint continued in her submissions
before the Grand Chamber, where what was criticised was the prosecuting authorities' erroneous characterisation
of her allegations, “which undoubtedly suggested that she had been a victim of trafficking, as an issue of forced
prostitution” (see § 250 of the Grand Chamber judgment).


-----

Like the dissenting judge at Chamber level, we do not consider that the principle of jura novit curia can be allowed
to operate as an invitation to applicants to alter, as a case proceeds, the factual and legal arguments on which their
complaints rest. However flexibly a human rights court finds it has to operate to ensure the voices of the
dispossessed and vulnerable are heard, it cannot ignore the fundamental principles of judicial procedure and must
continue to operate as a court.

It should be added that at the communication stage, by virtue of the following question – “Has there been a violation
of the State's obligations under Article 4 of the Convention _with regard to the applicant's allegations of human_
_trafficking […]?” – the Chamber expanded the case to cover human trafficking, despite the absence of any such_
allegations by the applicant, either before the domestic investigating authorities or in her application before the
Court. From then on the focus of the applicant was no longer about the failure to convict T.M. of the charge of
forced prostitution or the lesser charge of procurement but rather on the failure to bring what she now argued was
the correct charge, namely for the criminal offence of human trafficking. Given this alteration – whether mistaken or
deliberate – of the scope of the case first by the Chamber and then by the applicant in response, the Grand
Chamber should have proceeded with greater care in its legal characterisation, concentrating on the clear set of
factual allegations which had been put forward by the applicant, which related (solely) to forced prostitution. It was
after all these factual allegations which had been the subject of the investigation, prosecution and trial.
_2. Absence of clarity in the general principles on Article 4_

The second difficulty with the case lies in the consequences for the Court's legal analysis which seem to flow from
the inflation of the scope of the case.

As concurring judges, we do not dispute that when the applicant brought her complaint to the attention of the
Croatian police, she presented an arguable claim of some treatment which could have been found to be contrary to
Articles 3, 8 and even 4 of the Convention.

Instead of concentrating on clarifying the trigger for that positive procedural obligation and what the latter entails for
domestic authorities in a case like this, the Grand Chamber judgment expends considerable space and energy
exploring the concept of human trafficking. Over one hundred paragraphs of the judgment are devoted to
international and EU law and practice mainly on human trafficking. Human trafficking, as the Court already clarified
in previous cases, is dependent on the presence of three constituent and cumulative elements: action, means and
purpose (see the elaboration of the principles in _Rantsev v. Cyprus and Russia, no. 25965/04, §§ 277 - 289, 7_
January 2010). As the Grand Chamber judgment in the present case indicates, § 290:

“it is not possible to characterise conduct or a situation as an issue of human trafficking unless it fulfils the
criteria established for that phenomenon in international law”.

Having emphasised the importance of those three constituent elements, outlined existing case-law on human
trafficking, while explaining that the latter can occur at national and transnational level, the judgment avoids
providing a clear answer regarding whether the domestic investigating authorities should have been investigating
human trafficking, forced prostitution or sexual exploitation generally. The solution to the conceptual vagueness
thus developed is to refer vaguely to “treatment contrary to Article 4” (see §§ 308, 325, 328, 332 and 346) and to
state that irrespective of whether the Court is (or more importantly the domestic authorities were) in the presence of
human trafficking or forced prostitution, the core procedural obligation, namely the duty to investigate effectively, is
the same.

The purpose of bringing a case to the Grand Chamber is to bring clarity where it is lacking and to resolve
jurisprudential conflict or contradiction. By allowing the scope of the applicant's case to be unnecessarily inflated
and insisting on making this case about human trafficking the Grand Chamber has not brought clarity to its Article 4
case-law. The line between forced prostitution and human trafficking is blurred in and by this judgment. This is not
helpful and was certainly not necessary, since the Court was only ever going to decide whether there had been a
procedural as distinct from a substantive violation of Article 4 in the applicant's case.
_3. Transposition of positive procedural obligations from one Convention article to another_


-----

Our third difficulty lies in the _blanket transposition from Articles 2 and 3 to Article 4 (and in some cases perhaps_
even Article 8) of the positive procedural obligations developed with reference to the former provisions (see §§ 309311 of the Grand Chamber judgment).

The nature and scope of positive obligations under Articles 2, 3 and 4 were set out in detail in §§ 283 – 288 of
_Rantsev, cited above. They encompass, in essence, duties to prevent, protect and punish. However, the first two_
positive obligations arise where the State authorities were aware or should have been aware of circumstances
giving rise to a credible suspicion that an identified individual had been or was at real and immediate risk. In
contrast, the procedural obligation to investigate appears to depend on something less. In Rantsev it was triggered
“once the matter has come to the attention of the authorities” (ibid, § 288). In the present case the applicant had to
make out an arguable claim and/or there had to exist prima facie evidence of “treatment contrary to Article 4” (see
§§ 324-325, 331-332 and 346 of the Grand Chamber judgment).

There is a risk that the technique of blanket transposition fails to take into account the specificity of the type of
investigation which the authorities would have to initiate when confronted with an “arguable claim” or prima facie
evidence under Article 2 as distinct from Articles 3 and 4, as well as the nature of the facts which would constitute
such a claim under these different Convention articles. In relation to the first provision, a case like _Mustafa Tunç_
_and Fecire Tunç v. Turkey provides a good example of what would generally confront the authorities in an article 2_
case ([GC], no. 24014/05, 14 April 2015, § 133):

“where it is not clearly established from the outset that the death has resulted from an accident or another
unintentional act, and where the hypothesis of an unlawful killing is at least arguable on the facts, the
Convention requires that an investigation which satisfies the minimum threshold of effectiveness be conducted
in order to shed light on the circumstances of the death”.

In an article 2 case, to put matters bluntly, there is generally physical evidence of a death, or concrete elements
pointing to the risk thereof. Similarly, in Article 3 cases, the authorities are confronted with allegations of illtreatment, more often than not including physical manifestations on the body of the alleged victim of the treatment
of which they complain. Questions may arise regarding whether the threshold of severity is reached, or the absence
of physical evidence may be excused when the complainant has been under the authority and control of the State
which alone was in a position to know or establish the facts complained of (see, for a recent example, Ibrahimov
_and Mammadov v. Azerbaijan, nos. 63571/16 and 5 others, § 89, 13 February 2020)._

However, in Article 4 cases, as we see from the facts of the applicant's case, the available evidence with which
investigating authorities may be confronted can be of quite a different nature. The present case involved a first
connection via Facebook, social drinks, the search for employment, an alleged attempt to coerce into prostitution,
continued social contact, a physical relationship carried on over months which may or may not have been
consensual or which may have ceased to be consensual with time, allegations of threats and domestic violence, the
renting and payment of a flat by the complainant who had been able to leave the flat on certain occasions and who
retained use of her identity documents, mobile phone and part of the money earned from the alleged forced
prostitution. It also involved, crucially, evidence of a friend of the complainant, with whom she had lived, confirming
the threats to which she had been subject but also testifying that her involvement in prostitution had been voluntary.

In the present case, it is unclear what the Court expected the police to do when confronted by the applicant's
complaint of forced prostitution. Should they, when confronted by a relatively young woman, who may have
engaged in prostitution, and who appears to have been in some sort of relationship with an older, aggressive and
allegedly violent man, have sought first to establish whether commission of a higher level offence like human
trafficking had to be discounted, before proceeding to investigate the offence complained of, namely forced
prostitution? What will an arguable claim that treatment contrary to Article 4 has taken place look like in practice and
of what, in the absence of a complaint, will prima facie evidence consist? What concretely will either require of the
police and subsequently the prosecution service? The reality of the applicant's case was that the facts she
presented did not appear to match the constituent elements of human trafficking, nor did some of the central pieces
of evidence subsequently gathered. That does not mean that her complaint of forced prostitution was carefully and
sufficiently investigated and prosecuted. The finding of a violation is the result of identified deficiencies. However, it


-----

does mean that the domestic decision not to prosecute the more serious charge of human trafficking which the
applicant subsequently criticised appears to have been far from arbitrary.

A further reason why clarity on the trigger for the procedural obligation to investigate is so important is that once
triggered it becomes an own motion obligation for the domestic authorities. The authorities cannot, according to the
Court's case-law, leave it to the initiative of the alleged victim to take responsibility for the conduct of any
investigatory procedures (see § 314 of the Grand Chamber judgment). It is not incumbent on an applicant to
indicate deficiencies in the collection of evidence by the domestic authorities or omissions regarding possible
additional witnesses. In addition, when a complaint in relation to the procedural obligation to investigate comes
before the Strasbourg court, the investigation, prosecution and judicial stages of a case all become open to
examination; an examination which benefits from hindsight. As stated in § 227 of the Grand Chamber judgment:

“[…] the Court's case-law […] shows that it is prepared to take into account _any particular investigative_
_omissions it considers relevant in the context of its overall assessment of an applicant's procedural complaint_
of ineffective application of criminal law mechanisms”.

In the present case, although the applicant's complaint focussed on deficiencies at the judicial stage, the Court
focuses instead on the investigation stage, from where it implies any subsequent prosecutorial and judicial
deficiencies arise. As indicated by the dissenting judge at Chamber level, the Court must avoid, not least because it
is ill-equipped, to act as a first-hand examiner and first-instance arbiter of the quality of a domestic criminal
investigation. However, the transposition of Articles 2 and 3 standards to Article 4 and beyond to Article 8 carries
with it just such an inherent risk. The judgment indicates that the flaws in the relevant domestic proceedings must
amount to significant flaws in order to raise an issue under Article 4, emphasising that the Court is not concerned
with allegations of errors or isolated omissions. However, it remains to be seen what will qualify as a “significant”
flaw and the risk of the Court too easily assuming the role of a first-instance tribunal (of fact) is clear. The nature
and scope of the own motion investigation obligation which an arguable claim under Article 4 or prima facie
evidence of treatment contrary to that article can trigger, sits uneasily with, on the one hand, the substantial
deference which the Court says it must pay to national courts in the choice of appropriate measures (Beganović v.
_Croatia, no. 46423/06, § 78, 25 June 2009, and Pulfer v. Albania, no. 31959/13, § 81, 20 November 2018) and, on_
the other, the rule precluding the Court from seizing on facts which have not been adduced by the applicant and
examining those facts for compatibility with the Convention (see Foti and others, cited above, § 44).

While a procedural violation of Article 4 in this case may have been warranted, given the deficiencies uncovered in
the investigation into the applicant's complaint of forced prostitution, we are not convinced that the Grand Chamber
has engaged sufficiently with the implications for police and prosecution authorities of the procedural duties outlined
(see further, for similar concerns expressed in an Article 3 case by a domestic court, Commissioner of Police of the
_Metropolis (Appellant) v DSD and another (Respondents)_ _[2018] UKSC 11, Lord Mance at § 142)._
_Conclusions_

In a 2017 report on human trafficking, the European Commission referred to the fact that there were 15, 846
“registered victims” (both identified and presumed) of trafficking in the EU in 2013-2014, that trafficking for the
purpose of sexual exploitation is still the most widespread form (67 % of registered victims) and that over three
quarters of the registered victims were women (76 %) (Report on the progress made in the fight against trafficking
_in human beings, COM (2016) 267 final). That report highlighted the fact that the level of prosecutions and_
convictions for human trafficking remains worryingly low, especially when compared to the number of victims
identified, that although investigations in this field require a substantial body of evidence to secure a conviction, the
information gathered for the report indicated that Member States are not using enough effective investigative tools
and that an excessive burden is placed on victims both before and during criminal proceedings.

The picture painted in the Commission report, in the 9[th] General report published in April 2020 by GRETA, and that
provided by third party interveners in the instant case, may support a further Grand Chamber judgment like
_Rantsev, highlighting the scourge of human trafficking, developing the Court's case-law and finding, where_
appropriate, a violation of Article 4 as a result of a failure by a respondent State to prevent, protect against and
punish such crimes.


-----

However, while certain deficiencies in the domestic procedure involving the applicant mean it is not possible to vote
against the finding of a violation of Article 4, we do not agree with the manner in which the Court decided to
approach this case. We also consider that little has been gained in terms of the clarity of the Court's case-law on
Article 4 and share some of the concerns expressed by our Chamber colleague regarding the case as presented by
the applicant and her legal representatives both domestically and after communication at Strasbourg level.

The Grand Chamber is charged with addressing serious questions affecting the interpretation or application of the
Convention or the Protocols thereto and serious issues of general importance. For it to execute its functions
effectively, the right case must be chosen as the right vehicle for those questions and issues to be resolved. While
we support the finding of a procedural violation, the present case could and should have been disposed of on
narrower grounds at Chamber level. It could never successfully serve as the wider jurisprudential vehicle for which
it seems to have been intended.
**CONCURRING OPINION OF JUDGE PASTOR VILANOVA**

_(Translation)_

1. In this case the Grand Chamber found a violation of Article 4 of the Convention in its procedural limb. I subscribe
fully to that conclusion.

2. However, I have some reservations regarding the Grand Chamber's response to the crucial issue concerning the
exploitation of prostitution by another person. Whereas the Grand Chamber first asks the question whether
“exploitation of prostitution … falls within the scope of Article 4 of the Convention” (see paragraph 277 of the
judgment), it ultimately finds that the protection of Article 4 covers “instances of serious exploitation, such as forced
_prostitution” (see paragraph 300), and goes on to state (paragraph 301) that the “force” in question “may_
_encompass the subtle forms of coercive conduct identified in the Court's case-law on Article 4 (see paragraphs 281-_
_285 above), as well as by the ILO and in other international materials (see, in particular, paragraphs 141-144_
_above)”. Hence, the Grand Chamber refers us to a certain degree of gravity, to its own case-law and to international_
law. As regards the first requirement, it is of limited usefulness in this context, especially since the Grand Chamber
does not delve into the substance of the case. It is therefore a statement of principle. As to the second requirement,
none of the cases cited deals specifically with prostitution. These case-law references do not therefore appear to be
very relevant. Lastly, the references to the ILO do not relate expressly to prostitution, although it is to be noted that
this organisation links the issue of forced labour to the fact that the victim does not offer his or her services
“voluntarily”.

3. The Grand Chamber's response appears to me to be too ambiguous. This is evidenced, in particular, by the
case-law cited in paragraphs 281 to 285 of the judgment. To date, in order to characterise forced labour, the Court
has indeed required the presence of a threat, but also the absence of genuine consent. However, the latter element
appears to be ultimately excluded, or at least assigned minimal importance, in the present case since the Grand
Chamber concentrates on the notion of force.

4. Nevertheless, the time has come to address the question whether exploitation of prostitution, as such, remains
compatible with the European Convention on Human Rights. As a general rule, I do not believe so. Human dignity
cannot be paid for. The principle that the human body is not property also remains incompatible with its
commodification (res extra commercium) and unsuited to the context of a contract of employment, which
remunerates the persons concerned for their (physical or intellectual) efforts and not for making their own bodies
available to others on the instructions of their employer.

5. Academic research shows that persons who have chosen fully and freely to engage in prostitution are in a
minority. Those who do not, or no longer, wish to do so or who, in spite of themselves, have no other option, must
be protected by the Convention and by the High Contracting Parties.

6. The harmful physical consequences and the psychological impact of prostitution are such that no one should be
subjected to them without their free and informed consent. In that regard a survey was carried out in 2013 by the
French National Federation of Reception and Social Integration Associations (FNARS) and the Health Monitoring
Institute (IVS) on the health of persons working in prostitution who were interviewed in social and medical facilities


-----

Of all the individuals surveyed, over half (56%) reported their state of health as fair, poor or very poor, while 35%
said that they had a chronic illness (such as HIV) or psychological problems. The majority of those interviewed
reported episodes of insomnia, anxiety or depression in the past year. The survey added that “[t]he most frequently
_reported kinds of violence were insults and psychological violence: 64% of respondents had been subjected to such_
_violence at least once in the past twelve months”. The survey added that “[o]ver a third of the respondents had been_
_forced to have sexual relations at some point in their lives”. The section dealing with respondents' social conditions_
stated as follows: “The persons interviewed for the survey combined a number of features of social vulnerability, as
_evidenced by their social isolation (42% did not have a close relative or friend to call on in the event of difficulties, in_
_particular the women) or their housing conditions (39% lived in precarious accommodation such as hotels, shelters,_
_with friends or family, on the street, or in a squat)”._

7. To my mind, exploitation of prostitution, in the broad sense in which it is used in paragraph 117 of the judgment,
that is to say, the fact of unlawfully obtaining financial or other material benefit from the prostitution of another
person, should be presumed to be contrary to Article 4 of the Convention. The sole exception should be prostitution
entered into with free, informed and express consent, which cannot be characterised as forced labour. All other
forms of prostitution without consent therefore come within the scope of application of Article 4.

8. As I see it, consent to prostitution can be considered to be free and informed if – and only if – it is expressed and
obtained in an indisputable manner. No form of implicit consent can be accepted nor can it justify the exploitation of
one person by another. Silence or lack of resistance must never be regarded as implicit consent. Otherwise, the
way would be wide open to all manner of abuse, to say nothing of all the evidential difficulties that the victims
themselves would face. Giving in is not the same as consenting (Nicole-Claude Mathieu)! Article 3 (b) of the
Palermo Protocol and Rule 70 of the International Criminal Court's Rules of Procedure and Evidence reflect this
approach.

Article 3 (b) of the Palermo Protocol provides:

“The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph (a) of
this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used”.

Rule 70 of the International Criminal Court's Rules of Procedure and Evidence reads as follows:

“In cases of sexual violence, the Court shall be guided by and, where appropriate, apply the following
principles:

…

(b) Consent cannot be inferred by reason of any words or conduct of a victim where the victim is incapable of
giving genuine consent;

(c) Consent cannot be inferred by reason of the silence of, or lack of resistance by, a victim to the alleged
sexual violence;

(d) Credibility, character or predisposition to sexual availability of a victim or witness cannot be inferred by
reason of the sexual nature of the prior or subsequent conduct of a victim or witness.”

9. Hence, consent cannot be free and informed unless the person engaged in prostitution is capable of giving
consent and that consent is not vitiated by, for instance, violence, error or deception. Furthermore, it must be
possible for consent to be withdrawn at any time. A person cannot consent to something which he or she knows
little or nothing about. Individuals engaged in prostitution may realise subsequently that this activity does not
correspond in any way to how they previously imagined it, particularly where they are carrying it out in exhausting
conditions, earning less than they had hoped, or in view of the devastating impact on their physical and mental
health. The possibility for them to change their minds must be genuine and not merely theoretical. If prostitution is
the result of a true choice then it must be possible to leave it behind at any time and without any lasting effects.
Likewise, there can be no consent where there is a lack of options. Prostitution is frequently an activity of last resort.


-----

Where someone is in a situation of economic hardship, prostitution is not a genuine solution. If, and only if, all these
conditions are met can we speak of a truly free choice, made voluntarily and with full awareness.

10. The vast majority of the Council of Europe member States criminalise involvement in the provision by another
person of sexual services even where there is no coercion on the person providing the services (see paragraph 211
of the judgment). This is not necessarily a moral issue, as no one emerges unscathed from the experience of
prostitution (see point 6 above). However, the Grand Chamber appears to disregard this consensus. It is true that
some States regulate the exploitation of prostitution (Germany, the Netherlands, Slovenia, Spain and Switzerland,
for example). However, detailed legal regulation of an activity does not suffice to make it compatible with the
Convention. The fact that it is regulated does not in any way mean that the person's consent is entirely free,
informed and express, and above all verified. I note in that connection the legislation initiated by several European
countries which have opted to define sexual violence on the basis of lack of consent rather than just on the basis of
violence or threats (Sweden, Iceland, the United Kingdom and Ireland, for example). Consequently, the absence of
violence does not necessarily denote consent.

11. Lastly, Article 4 also imposes positive obligations on the High Contracting Parties. In that regard they should, at
the very least, establish a legal framework that is sufficient to make the prohibition of slavery and forced labour
effective; investigate thoroughly where there are credible suspicions that the rights of persons enjoying protection
have been breached; and, finally, take operational steps to protect potential or actual victims. With regard to this
last aspect, this would entail, firstly, strengthening the guarantees and safeguards surrounding legal prostitution, in
other words, ascertaining whether the consent given is genuine. Secondly, the list of States' positive obligations
under Article 4 should be expanded by the introduction of preventive measures such as identifying and supporting
persons in a precarious or vulnerable situation (the vast majority of them women) who are in danger of falling into
the trap of forced prostitution, and affording assistance and protection to those who wish to escape the spiral of
prostitution.

12. In his 1862 work Les Misérables, Victor Hugo observed as follows: _“We say that slavery has vanished from_
_European civilisation, but it is not true. Slavery still exists, but now it applies only to women and its name is_
_prostitution”. The Convention is a living instrument. It is up to the Court to show the way._
**CONCURRING OPINION OF JUDGE SERGHIDES**

1 The applicant is a woman, young and unemployed at the material time, who allegedly was physically and
psychologically forced into prostitution by a certain T.M., a former policeman. Her complaint before the Court was
that the domestic authorities had failed effectively to apply the relevant criminal-law mechanism concerning those
allegations.

2. The Court, being the master of the characterisation to be given in law to the facts of a case, rightly decided in its
judgment (see paragraph 243 of the judgment) to examine the present case under Article 4 § 2 of the Convention,
which prohibits forced labour.

3. I agree with the conclusion of the judgment that there has been a violation of Article 4 of the Convention in its
procedural limb (see paragraph 347 of the judgment), but I arrive at that conclusion by using a simpler and direct
methodological approach which I will explain below. I will then provide a more detailed explanation of my concern
as to the effect the judgment may potentially have on the scope of Article 4 § 2 of the Convention, by outlining the
relationship between the two dimensions of logic (intension and _extension) in the term “forced and compulsory_
labour” under the said provision. This will provide a further insight into my preference for the direct methodological
approach, which I believe to be more compatible with the principle of effectiveness[1].
_I. The direct methodological approach_

4. The judgment undertakes at length the difficult task of providing definitions of “human trafficking” and
“exploitation of prostitution”, a task which it sees as essential in order to determine whether the treatment
complained of by the applicant falls within the scope of Article 4 § 2 of the Convention. With due respect, I consider
such an undertaking unnecessary. These concepts, which in any event are not specifically mentioned in Article 4 §
2, are only instances or sub-categories of “forced or compulsory labour” and they do not cover the full breadth of the
l tt A it f th l f th C t ( h 281 85 f th j d t) “f d


-----

compulsory labour”, in general, means any work or service which is extracted from a person without his or her will
by way of force (that is, using a physical or mental constraint or both) or compulsion (that is, using a menace of any
penalty or a serious threat, or both).

5. I consider the approach taken in the judgment problematic for two key reasons: firstly, it disproportionately
devotes the major part of its legal analysis to determining whether the treatment complained of falls within the
definition of “human trafficking” and/or “exploitation of prostitution”, thus distracting from the more general issue of
“forced or compulsory labour” which is at the heart of the case; and, secondly, such examination has the effect of
unduly narrowing the scope of Article 4 § 2. I will briefly explain this in more detail, in order to clarify why I favour the
direct methodological approach.

6. Firstly, as already mentioned, the major proportion of the legal analysis of the judgment is devoted to providing a
definition of “human trafficking” and “exploitation of prostitution”. This may be relevant in determining whether the
treatment complained of falls within the scope of Article 4 § 2, yet this should be undertaken by considering the full
breadth of the concept of “forced or compulsory labour”, rather than limiting the scope of this provision to only these
two sub-categories of forced or compulsory labour. The excessive focus on defining “human trafficking” and
“exploitation of prostitution” diverts attention from the central and more general issue, as explained above.

7. Secondly, the approach taken in the judgment has the effect of limiting the scope of Article 4 § 2 by equating
“forced or compulsory labour” with “human trafficking” and “exploitation of prostitution”. The methodology adopted in
the judgment could lead to a situation where an authorisation, a kind of “visa”, has to be requested bearing the
words “human trafficking” and/or “exploitation of prostitution” in order for a complaint to be allowed to fall within
Article 4 § 2.

8. Consequently, such methodology is: (a) erroneous, as the scope of “forced or compulsory labour” is wider and is
not confined to these two sub-categories, something which the judgment seem to overlook; (b) highly restrictive;
and (c) contrary to the object and purpose of Article 4 § 2, namely the practical and effective protection of the right
not to be subjected to “forced or compulsory labour”, and thus in contravention of the principle of effectiveness.
Again, the approach taken in the judgment is unnecessary and not in the spirit of Article 4 § 2.

9. For the reasons stated above, I favour the direct methodological approach which avoids the above-mentioned
problems. To my mind, the question to be asked is whether the applicant's complaint (that is, her factual
allegations) can be considered to amount to “forced or compulsory labour” within the meaning of Article 4 § 2 of the
Convention. This concept is a generic and autonomous one, susceptible to evolutive interpretation, allowing the
living instrument to be developed. The generic nature of the concept is reinforced by the provisions of the next
paragraph of the Article, namely paragraph 3 (a)-(d), which expressly excludes from the concept of “forced or
compulsory labour” four categories or kinds of work or service.

10. “Human trafficking” and “exploitation of prostitution” by their very nature fall within the concept of “forced or
compulsory labour”, as such behaviour is a very serious means of coercing an individual to perform labour against
his or her will. “Forced or compulsory labour” may occur in many different contexts and is not limited to “human
trafficking” and/or “exploitation of prostitution. The very nature of the appalling exploitation of human beings
involved in “human trafficking” and/or “exploitation of prostitution” is such that it must automatically fall within the
scope of Article 4 § 2.

11. In view of the above, the direct methodological approach obviates the need to attempt, as the judgment does, to
define the concepts of “human trafficking” and/or “exploitation of prostitution”, which are very difficult concepts to
define, and instead shifts the focus back to the actual and more general issue which the Court has to decide, as
stated above.

12. To further explain the scope of Article 4 § 2 of the Convention, I will consider the meaning of “forced or
compulsory labour” in the light of its twofold dimension in logic. This will illuminate how the direct methodological
approach I favour is more compatible with the intension and extension of the term, and how the approach taken in
the judgment would have the effect of unduly narrowing its scope.


-----

_II. “ForceD or compulsory labour” in the light of its twofold dimension in logic – intension and extension – and OF_
_the principle of effectiveness_

13. As stated above, in my humble opinion the lengthy examination of whether the applicant's complaint (that is, her
factual allegations) can be considered as “human trafficking” and/or “exploitation of prostitution” within the meaning
of Article 4 § 2 of the Convention was, with due respect, unnecessary. In my view, like any other Convention term or
concept, the scope of “forced or compulsory labour” in Article 4 § 2 of the Convention can be better understood if it
is examined in the context of its twofold dimension in logic, thus in its intension and extension[2], as well as in the
light of the relationship between these dimensions[3].

14. In logic, the _intension (otherwise: connotation, comprehension, definition or depth), consists of the essential_
qualities, properties or characteristics of a term, and _extension (otherwise: denotation, classification or breadth)_
consists of the matters or instances to which the term refers. An easy distinction between the two can be illustrated
through the example of the term “ship”. The intension of this term would be a “vehicle for conveyance on water”,
whereas its extension would embrace cargo ships, passenger ships, battleships, and sailing ships[4].

15. These two dimensions are important in interpreting a term in the Convention because they assist in offering a
holistic idea of its meaning: in depth and in breadth. A deeper understanding of Convention terms is required for
effective protection of human rights. This holistic approach to interpreting a Convention provision is an aspect or
property of the principle of effectiveness as a norm of international law and a method of interpretation. H.E.
Cunningham aptly observes that “[e]xtension and intension as applied to terms may, in a sense, apply to relations”[5].
Hence, in my view, the same applies to human rights, which are based on and concern human relations in society.
Although the _intension of a term is also described as a definition of the term, it should be pointed out that the_
concepts of relations and human rights may be very difficult to define or may sometimes even be undefinable[6].

16. Having said that, it can easily be explained why the Court prefers not to define rights, or terms concerning
Convention rights. Unless it is very general, any definition of the rights would leave no room for the Convention to
be developed as a living instrument, a doctrine followed by the Court. Yet, closer enquiry into the two dimensions
may assist in this evolution in order to appropriately establish the meaning of the right in relation to a specific set of
circumstances, while ensuring conformity with the underlying protection the Article seeks to guarantee.

17. I submit that the determination of the right not to be subjected to “forced or compulsory labour” must follow this
twofold meaning which the term has in logic. The intension of the term “forced or compulsory labour” is any labour
which can be characterised as forced or compulsory and therefore taking place against the will of the individual.
“Human trafficking” and “exploitation of prostitution” undoubtedly fall within the _extension_ of the term, but its
_extension is not limited to just these two examples. These are only some instances falling within the extension or_
breadth of the term “forced or compulsory labour” and, as stated above, they do not cover the full breadth of the
latter.

18. Thus, in my humble view, if the applicant's complaint had to be classified as “human trafficking” or “exploitation
of prostitution”, in order for it to be considered “forced or compulsory labour” under Article 4 § 2, as is done by the
judgment, this would unduly narrow the application of that provision. Not seeing the whole extension of “forced or
compulsory labour”, by fixating on two of its sub-categories, can be likened to not seeing the wood for the trees.

19. Furthermore, this or any similar attempt to delimit the extension of “forced or compulsory labour” will not only
erroneously result in the extension being stagnant and diminished, but will also increase the intension of the term
“forced or compulsory labour” to such a degree as to equate it to these two instances of extension. This will have
the end result of removing the distinction between intension and extension since both will be identified with “human
trafficking” and “forced prostitution”. As will be explained below, such a result runs counter to the relationship
required by logic between the extension and intension of a term as well as to the principle of effectiveness which
supports this relationship for the benefit of the effective protection of a right.

20. In logic, there is an inverse relationship between _extension_ and intension; as the _intension diminishes, the_
_extension increases, and, conversely, as the_ _extension diminishes, the_ _intension increases[7]. In brief, to use the_
words of Horace William Brindley Joseph “the extension and intension of words vary inversely”[8] The less specific


-----

the definition, the more instances and objects are likely to fit within the scope of that definition. A good example
given by A. Wolf[9] of the inverse relationship between intension and extension is the following. If we qualify the
intension of the word “triangle” by adding the adjective “equilateral”, the intension of “triangle” increases and its
extension decreases. Conversely, if we omit from the term “equilateral triangle” the adjective “equilateral”, the
intension of the term decreases and its extension increases.

21. In the present case, the meaning of “forced or compulsory labour” allows a broad array of situations and
contexts to be classified as such; this requires a broad extension and a narrow intension. However, if instead one
were to identify “forced or compulsory labour” as “human trafficking” and “exploitation of prostitution”, then this
would severely restrict the _extension,_ and consequently the term would not cover other instances of “forced or
compulsory labour”. Such an interpretation would be a contra legem since the generic term contained in Article 4 §
2 would be unjustifiably qualified. Instead, the direct methodological approach outlined above allows Article 4 § 2 to
protect individuals from exploitation of labour occurring against their will.

22. In my view, the consideration of these two dimensions of “forced or compulsory labour” is apt to illustrate that
the direct methodological approach which I discussed above is preferable, maintaining a narrow intension and thus
not erroneously limiting the extension of the complaints that can be brought forward under Article 4 § 2. Unlike the
approach taken in the judgment, the proposed direct methodological approach is compatible with the principle of
effectiveness, which after all is based upon logic and fairness. This principle, both in its capacity as a norm of
international law and as a method of interpretation, serves to make a term in the Convention wider, within, of
course, the limits of the text and the object of the relevant Convention provision. This can be achieved either by
decreasing its _intension or increasing its_ _extension. By doing either, the result will be the same, namely the_
widening of the overall meaning of the term.
_III. Conclusion_

23. In the light of the above considerations, I decided to follow the direct methodological approach to dealing with
the applicant's complaint under Article 4 § 2 of the Convention. I did this in combination with the approach I
borrowed from the science of logic, consisting in determining “forced or compulsory labour” in the light of its
_intension_ and _extension and maintaining the requisite inverse relationship between these dimensions, in_
accordance with the principle of effectiveness.

24. By way of conclusion, apart from the different methodological approach which I have followed, I am in
agreement with the judgment that the respondent State was in breach of its procedural obligation under Article 4 of
the Convention, and for that reason I voted in favour of all five of the operative provisions. To my mind, however,
this breach was the result of failure to apply the criminal-law mechanism allowing for the investigation, prohibition
and punishment of “forced or compulsory labour” in such a way as to facilitate protection using the entire breadth of
this term, instead of limiting protection to the framework of “human trafficking” or “forced prostitution” as the
judgment did.

2

1 On this principle, see, inter alia, Case “relating to certain aspects of the laws on the use of languages in education in
Belgium” (merits), 23 July 1968, pp. 24, 26, Series A no. 6; Mamatkulov and Askarov v. Turkey [GC], nos. 46827/99
and 46951/99, § 123, ECHR 2005-I; Rietiker, Daniel, “The principle of 'effectiveness' in the recent jurisprudence of the
European Court of Human Rights: its different dimensions and its consistency with public international law – no need
for the concept of treaty sui generis”, Nordic Journal of International Law, 79 (2010), pp. 245 et seq; Georgios A.
Serghides, “The Principle of Effectiveness in the European Convention on Human Rights, in Particular its Relationship
to the Other Convention Principles”, in (2017), 30, Hague Yearbook of International Law, 1 et seq.; Georgios A.
Serghides, “The Principle of Effectiveness as Used in Interpreting, Applying and Implementing the European
Convention on Human Rights (its Nature, Mechanism and Significance), in Iulia Motoc, Paulo Pinto de Albuquerque
and Krzysztof Wojtyczek, New Developments in Constitutional Law – Essays in Honour of András Sajó, The Hague,
2018 389 S l i d ll i f l k d b D i l Ri ik


-----

**End of Document**

“Effectiveness and Evolution in Treaty Interpretation”, Oxford Bibliographies (last modified 25 September 2019):
https://www.oxfordbibliographies.com/view/document/obo-9780199796953/obo-9780199796953-0188.xml

2 See, on the meaning of extension and intension in logic: H.E. Cunningham, Textbook of Logic, New York, 1924, at
pp. 26-27; A. Wolf, _Textbook of Logic, London, 1938, 1st Indian edition, reprinted 1976, at p. 323; Horace William_
Brindley Joseph, _An Introduction to Logic, 2nd edition (revised), Oxford, 1916, at pp. 136, 142-43, 155; W. Stanley_
Jevons, The Principles of Science: A Treatise on Logic and Scientific Method, 2nd edition, New York, 1887, at pp. 2526; Evangelos P. Papanoutsos, Logic (in Greek), 2nd edition, Athens, 1974, at pp. 52-53.

3 I also employed these two dimensions of logic in § 46 of my concurring opinion joined by Judge Dedov in Obote v.
_Russia (no. 58954/09, 19 November 2019)._

4 Adam Augustyn (ed.), _Encyclopaedia Britannica, online under “Intension and extension” (March 2020)_
<https://www.britannica.com/topic/intension>

5 See Cunningham, op. cit., at p. 37.

6 As said by Cunningham on this: “Extension leads to a type of definition which is called concrete, i.e. definition by
example. The intension or connotation of a relation is more difficult to state. Relations do not yield readily to abstract
definition, and by many are treated as indefinables” (ibid., at p. 37).

7 See A. Wolf, op. cit., at p. 324; Evangelos P. Papanoutsos, op. cit., at pp. 52-53.

8 See H.W.B. Joseph, op. cit., at p. 137. At p. 146 (ibid.) Joseph also argues that “… you cannot widen or narrow the
extension of a term without restricting or enlarging its intension, and vice versa”.

9 A W lf i 324


-----

