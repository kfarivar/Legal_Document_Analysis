# R v Majdouline [2020] EWCA Crim 1120

CA, CRIMINAL DIVISION

2020/00257/A1

Popplewell LJ, O'Farrell J, Nicklin J

18 August 2020

18/08/2020

Tuesday 18[th] August 2020

LORD JUSTICE POPPLEWELL:

Introduction

1. Following a trial at the Central Criminal Court before The Common Serjant, His Honour Judge Marks QC, and a
jury, the applicant was convicted of murder, and of having an offensive weapon.

2. On 18[th] December 2019 he was sentenced for the murder to custody for life with a minimum term of 21 years
(less 331 days spent on remand). On a count of having an offensive weapon, he was sentenced to 18 months'
detention in a young offender institution to run concurrently.

3. He renews his application for leave to appeal against sentence after refusal by the single judge. Mr Scobie QC,
who represented him at the trial, has appeared before us on his behalf pro bono.

The Facts

5. Just before 5.45pm on 8[th] January 2019, the applicant and four other males were driving a stolen Mercedes
vehicle around Leyton, a location associated with a gang called the Mali Boys with whom the applicant was
connected. Those in the vehicle were armed with knives and were wearing hoods and gloves. When 14 year old
JM, who was associated with the rival Beaumont Crew gang, was spotted riding a moped he became a target.
CCTV footage showed the Mercedes make a U-turn before mowing down JM. As Jayden lay defenceless on the
ground, four of the five occupants of the Mercedes exited the vehicle. Three were armed with knives and had their
hoods pulled up. The applicant was one of these three. Jayden was stabbed nine times, including four times to the
chest. Four of the stab wounds were to a depth of between 8 and 12 centimetres. A number of the blows involved
severe force. Jayden suffered catastrophic blood loss and died at the scene. The nature and ferocity of the attack
left the judge in no doubt that the intention was to kill the victim, a conclusion he was well placed to reach having
presided over the trial. The applicant and the others got back into the Mercedes which was driven away at speed
and abandoned nearby. The applicant went to a churchyard with the intention of burning his clothing to cover his
tracks. The fire only caught in part, and his DNA was found on two items recovered from there, as well as on a pair
of gloves and the handle of a knife found in nearby drains.

Antecedents


-----

6. The applicant was aged 18 years and 5 months at the date of the offence. He had seven convictions for 15
offences, including three separate offences of carrying a knife in a public place when he was aged 16 and 17, and
two separate offences in relation to supplying Class A drugs when he was aged 17.

Reports

7. The judge had before him two pre-sentence reports prepared in relation to those previous offences and, in
addition, an up-to-date letter from the head of Islington Child Social Services. They revealed that the applicant had
had a traumatic upbringing involving extensive and extreme physical and emotional abuse; and that since he had
run away from his last foster placement in March 2017 he had been groomed and exploited by older adults into
participating in drug dealing. In 2018 the National Crime Agency made a determination that he was the victim of
**_modern slavery. The reports and the letter made clear that he had a number of good qualities._**

The Sentencing Remarks

8. In sentencing, the judge said that he did not underestimate the impact of the huge personal difficulties
experienced by the applicant from an early age. The judge identified the starting point for the minimum term as 25
years because the applicant had taken a knife to the scene and it had been used in the murder. He identified as
aggravating features that this was gang and drug related violence, involving a group attack, with an element of
planning in that the group were plainly out looking for serious trouble; and the applicant's previous convictions for
possession of bladed articles. He said that those factors merited a "slight" increase in the 25 year starting point.
He did not expressly refer to the further aggravating features identified by the prosecution: that the victim was a 14
year old child; that the offence was committed in a residential street witnessed by members of the public; and that
steps were taken to destroy evidence and hamper the police investigation.

9. The judge identified as mitigating factors: first, the applicant's young age (just under 18½ at the time of the
offence); and secondly (to use the judge's words), the applicant's "terribly difficult personal background". Taking the
aggravating and mitigating features into account, he reached a minimum term of 21 years, less time spent on
remand.

The Grounds of Appeal

10. Mr Scobie's submission is that the minimum term of 21 years was manifestly excessive in view of the
applicant's age at the time of the offence and the exceptional mitigation relating to his childhood and background,
which Mr Scobie described as "unique". He submitted that the appropriate minimum term would be below the 20
year level.

11. We should fill in a little detail of that background. The letter from Social Services described the applicant as "a
young man, who since his birth has been exposed to significant childhood trauma and experienced chronic neglect
and violence within his family life and in the community".  The letter goes on to state: "throughout his life, [the
applicant] has not been provided with any safe adults within his family to help him navigate an extremely difficult
upbringing".

12. The applicant's father was murdered in January 2015, when the applicant was 14 years old.

As a teenager, he was removed from his mother's care by Social Services because his mother's partner sought to
radicalise him. The applicant did not become radicalised but due to his exposure to dangerous ideologies, he had
to be removed from the care of his mother. The applicant was physically abused (described by Social Services as
extreme violence) and emotionally abused by his mother's partner, who exposed him to extremist ideologies.

13. The applicant was then placed in numerous foster care placements. He was separated from his siblings and
was thereafter placed into the care of his paternal aunt, who also physically and emotionally abused him.

14. The applicant spent increasing amounts of time in the Leyton area and became involved in county lines drug
dealing for older males in that area. He was found by police in a crack house in Basingstoke, from where he was
dealing Class A drugs He was referred by Islington Social Services to the National Referral Mechanism as a


-----

possible victim of **_modern slavery. On 31[st] August 2018, the National Crime Agency confirmed that he was a_**
victim of modern slavery. Their reasoning was reflected in the Agreed Facts which were read to the jury at the trial
in the following terms:

"The basis of the [NCA] decision was that [the applicant] had gone missing for over a month and a half and had
been seen in Hampshire with a known drug dealer, in an area where he had no connections. He had been
removed from the care of his mother due to abuse against him and his siblings by his step-father and taken into the
care of his aunt where he was again physically and emotionally abused. He had also suffered a bereavement due
to the death of his father in January 2015. He was placed in a number of foster placements, which he went missing
from. The NCA (and other agencies) were concerned that [the applicant] was being groomed by more
sophisticated adult offenders. It was not clear whether [the applicant] was benefitting proportionally from the drug
dealing."

15. The letter from Social Services emphasises that the applicant has been kind, respectful and thoughtful in his
interactions with Social Services and has been loving and protective towards his siblings, whilst fully acknowledging
the seriousness of the offence and the fact that a young boy has lost his life

15. In one of the pre-sentence reports, the author says:

"[The applicant] tells me that on a number of occasions, he was badly beaten by the adults. He also tells me that
the fumes from the drugs he was exposed to resulted in [him] being physically sick regularly whilst residing in
Basingstoke. Whilst the aforementioned are indicative of child trafficking and exploitation, [the applicant] did not
deny wrongdoing throughout interview"

The author also records that the applicant was admitted to custody at Oakhill Secure Training Centre with stab
wounds on his hands and having lost a significant amount of weight.

16. We would agree that these are truly exceptionally grim circumstances by way of background.

Authorities

17. Mr Scobie reminded us of a number of recent authorities in relation to the age and immaturity of young adult
offenders. Reliance was placed on R v Clarke [2018] 1 Cr App R (S) 52, in which Lord Burnett CJ made clear that
turning 18 is not a "cliff edge" and that the youth and immaturity of the offender is still an important consideration for
the purpose of sentencing. He said at [5]:

"Reaching the age of 18 has many legal consequences, but it does not present a cliff edge for the purposes of
sentencing. So much has long been clear. The discussion in R v Peters _[2005] EWCA Crim 605; [2005] 2 Cr App_
R(S) 101 (page 627) is an example of its application: see [10]-[12]. Full maturity and all the attributes of adulthood
are not magically conferred on young people on their 18[th] birthdays. Experience of life reflected in scientific
research (e.g. The Age of Adolescence: thelancet.com/child-adolescent; 17 January 2018) is that young people
continue to mature, albeit at different rates, for some time beyond their 18[th] birthdays. The youth and maturity of an
offender will be factors that inform any sentencing decision, even if the offender has passed his or her 18[th] birthday"

18. The Definitive Guideline on Sentencing Children and Young People, which is applicable to those aged under
18, provides at paragraph 1.5:

"It is important to bear in mind any factors that may diminish the culpability of a child or young person. Children and
young people are not fully developed and they have not attained full maturity. As such, this can impact on their
decision making and risk taking behaviour. It is important to consider the extent to which the child or young person
has been acting impulsively and whether their conduct has been affected by inexperience, emotional volatility or
negative influences. They may not fully appreciate the effect their actions can have on other people and may not
be capable of fully understanding the distress and pain they cause to the victims of their crimes. Children and
young people are also likely to be susceptible to peer pressure and other external influences and changes taking
place during adolescence can lead to experimentation, resulting in criminal behaviour. When considering a child or


-----

young person's age their emotional and developmental age is of at least equal importance to their chronological
age (if not greater)."

19. That guideline also identifies as one statutory mitigating factor at paragraph 4.7:

"Unstable upbringing including but not limited to: time spent looked after; lack of familial presence or support;
disrupted experiences in accommodation or education; exposure to drug/alcohol abuse, familial criminal behaviour
or domestic abuse; victim of neglect or abuse, or exposure to neglect or abuse of others; experiences of trauma or
loss."

20. It has been made clear in cases such as R v Balogun _[[2018] EWCA Crim 2933 and R v Daniels [2019] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TKW-WC12-8T41-D3RT-00000-00&context=1519360)_
_[Crim 296; [2019] 4 WLR 52, that although that guideline is not directly applicable to those aged 18 and above, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V0H-S8B2-8T41-D1XH-00000-00&context=1519360)_
considerations identified within it can and should have weight when sentencing young adults who are not yet fully
mature.

21. In Annex A to the Sentencing Council General Guideline, which is applicable to all adult offenders, there is the
following passage as an expanded explanation of age and/or lack of maturity as a mitigating factor in sentencing
offenders:

"In particular young adults (typically aged 18-25) are still developing neurologically and consequently may be less
able to:

∙ evaluate the consequences of their actions

∙ limit impulsivity

∙ limit risk taking

Young adults are likely to be susceptible to peer pressure and are more likely to take risks or behave impulsively
when in company with their peers.

Immaturity can also result from atypical brain development. Environment plays a role in neurological development
and factors such as adverse childhood experiences including deprivation and/or abuse may affect development."

Disposal

22. We have no doubt that the very experienced judge had these principles in mind, and it is clear from his
sentencing remarks that he reduced the sentence considerably on account of the applicant's young age and very
traumatic upbringing and background which led him into being exploited into the gang culture which formed the
background to this offence. This was a brutal murder, gang and drug related, in which a 14 year old boy was
stabbed to death in the street by the applicant as part of a group, having first been knocked off his moped when the
Mercedes was deliberately driven straight at him. The judge identified aggravating factors which justified what he
described as a "slight" increase from the statutory starting point for the minimum term of 25 years. The aggravating
factors would have justified increasing the minimum term to at least 26 years or more. The judge then expressly
took account of the applicant's young age and his "terribly difficult personal background" in reducing the minimum
sentence to 21 years.  Having presided over the trial he was ideally placed to assess the applicant's culpability and
maturity in the light of all the information before him.  He gave a discount of at least five years for the applicant's
age and background. In our view it is not arguable that such a reduction was manifestly insufficient.

23. Accordingly the renewed application is refused.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS


-----

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

