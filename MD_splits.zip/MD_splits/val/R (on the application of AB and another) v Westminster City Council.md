# R (on the application of AB and another) v Westminster City Council [2024]
 EWHC 266 (Admin)

King's Bench Division, Administrative Court (London)

Dan Squires KC (sitting as a deputy judge of the High Court)

9 February 2024Judgment

**Karen Reid (instructed by IHB Law Ltd (t/a Lawstop) for the Claimant**

**Andrew Lane** (instructed by **the Director of Law, Bi-borough Shared Legal Service for City of**
**Westminster) for the Defendant**

Hearing dates: 17 January 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely by circulation to the parties' representatives by email and release to The
National Archives. The date and time for hand-down are deemed to be 9 February 2024 at 2:00 pm.

**Dan Squires KC sitting as a Deputy High Court Judge:**

Introduction

1. The Claimants, AB and CD, are a couple. They each suffer from a number of serious physical and
mental disabilities. The Defendant, Westminster City Council, was satisfied they were homeless within the
[meaning of the Housing Act 1996 (“HA 1996”) and is currently providing them accommodation to discharge](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)
its duties under the Act. This judicial review concerns the adequacy of the accommodation provided. It also
concerns the Defendant's policy applicable to the sourcing of accommodation that permits animals, and in
particular whether the policy operates in a way that discriminates indirectly against those who are disabled
and have a need to be accommodated with an animal for a reason related to their disability.

2. The basis on which the judicial review is brought, and my determination of it, is set out below. I am
grateful to counsel for their helpful submissions orally and in writing.

Material legislation

_[Housing Act 1996](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)_

[3. The legal regime governing homelessness is set out in the HA 1996.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)

[4. HA 1996 s 184(1) provides that if a local authority “has reason to believe that a [person who applies to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBX0-TWPY-Y1GM-00000-00&context=1519360)
them for housing assistance] maybe homeless or threatened with homelessness, they shall make such
enquiries as are necessary to satisfy themselves (a) whether he is eligible for assistance and (b) if so,
whether any duty, and if so what duty, is owed to him under the under [the Act]”. Section 184(3) requires
the local authority to notify the person of the outcome of their enquiries.


-----

5. _[HA 1996 s 188(1) provides that, pending the enquiries required by s 184(1), “if the local housing](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y1GR-00000-00&context=1519360)_
authority have reason to believe that an applicant may be homeless, eligible for assistance and have a
priority need, they must secure that accommodation is available for the applicant's occupation.”

6. As set out below, on 18 August 2023 the Defendant completed its enquiries pursuant to s 184 and
concluded that the Claimants were eligible for assistance and were owed what is sometimes described as
[the “full” or “main housing duty” pursuant to HA 1996 s 193. Section 193 provides where material:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)

(1) This section applies where—

(a) the local housing authority—

(i) are satisfied that an applicant is homeless and eligible for assistance, and

(ii) are not satisfied that the applicant became homeless intentionally,

(b) the authority are also satisfied that the applicant has a priority need…

(2) Unless the authority refer the application to another local housing authority …, they shall secure that
accommodation is available for occupation by the applicant.

7. It was common ground between the parties that the obligation pursuant to _[HA 1996 s 193(2), once](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
triggered, is not simply a duty to take reasonable steps to secure accommodation or to secure
accommodation within a reasonable time. The duty to secure accommodation is “immediate, nondeferrable and unqualified”: R (Elkundi) v Birmingham City Council _[2022] EWCA Civ 601, [2022] Q.B. 604_
paragraph 81.

[8. Pursuant to HA 1996 s 206(1), a local authority can discharge its duties under ss 188(1) and 193(2) “(a)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0W8-00000-00&context=1519360)
by securing that suitable accommodation provided by [the local authority] is available” to the person to
whom the duty is owed; “(b) by securing that he obtains suitable accommodation from some other person”;
or “(c) by giving him such advice and assistance as will secure that suitable accommodation is available
from some other person.” The suitability of accommodation is thus critical to the statutory regime. A local
authority will not discharge its duties under sections 188(1) or 193(2) unless the accommodation it
“secures” is “suitable” for the individual to whom the housing duty is owed.

9. _[HA 1996 s 202(1) accords a “right to request [a] review”. It applies to a number of relevant local](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0F9-00000-00&context=1519360)_
authority homelessness decisions. That includes at s 202(1)(f) a right to request a review of “any decision
of a local housing authority as to the suitability of accommodation offered to [a person] in discharge of their
[duty under [s 193(2)]”. A detailed procedure for the conduct of such a review is set out in HA 1996 s 203](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y0X7-00000-00&context=1519360)
and the Homelessness (Review Procedure etc) Regulations 2018. Further, if a person is dissatisfied with
the outcome of an internal review conducted pursuant to s 202, they have a right to appeal to the County
[Court on any point of law pursuant to HA 1996 s 204(1). The right to appeal is unqualified and permission](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y06M-00000-00&context=1519360)
is not required to bring an appeal.

_[Equality Act 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_

10. The Claimants also rely on provisions in the _[Equality Act 2010 (“EA 2010”). The relevant provisions](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
are as follows.

11. Pursuant to _[EA 2010 s 29(6) “A person must not, in the exercise of a public function that is not the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)_
provision of a service to the public or a section of the public, do anything that constitutes discrimination…”
It was common ground that the Defendant's discharge of its relevant homelessness obligations pursuant to
_[HA 1996 fall within](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)_ _[EA 2010 s 29(6). It would thus be unlawful for the Defendant, in discharging those](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-73Y4-00000-00&context=1519360)_
obligations, to discriminate against the Claimants in relation to a protected characteristic. The relevant
protected characteristic here is “disability,” and, for the reasons set out below, it is not disputed that the
[Claimants are both “disabled persons” as defined by EA 2010 s 6.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-743W-00000-00&context=1519360)

[12. The form of discrimination relied on by the Claimants is indirect discrimination. It is defined in EA 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
_[s 19 as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_


-----

(1) A person (A) discriminates against another (B) if A applies to B a provision, criterion or practice which is
discriminatory in relation to a relevant protected characteristic of B's.

(2) For the purposes of subsection (1), a provision, criterion or practice is discriminatory in relation to a
relevant protected characteristic of B's if—

(a) A applies, or would apply, it to persons with whom B does not share the characteristic,

(b) it puts, or would put, persons with whom B shares the characteristic at a particular disadvantage when
compared with persons with whom B does not share it,

(c) it puts, or would put, B at that disadvantage, and

(d) A cannot show it to be a proportionate means of achieving a legitimate aim.

13. The Claimants also rely on the public sector equality duty contained in EA 2010 s 149(1). It provides:

(1) A public authority must, in the exercise of its functions, have due regard to the need to—

(a) eliminate discrimination, harassment, victimisation and any other conduct that is prohibited by or under
this Act;

(b) advance equality of opportunity between persons who share a relevant protected characteristic and
persons who do not share it;

(c) foster good relations between persons who share a relevant protected characteristic and persons who
do not share it.

Factual background

14. The First Claimant is in his mid-40s and the Second Claimant in her mid-50s. They have been a
couple for the past decade. They each suffer from a series of serious mental and physical health
conditions, and have led, at times, difficult and chaotic lives. The First Claimant suffers from personality
disorder, drug dependence, single episode depressive disorder and Post Traumatic Stress Disorder. He
also has respiratory difficulties and mobility problems. The Second Claimant suffers from Schizophrenia,
personality disorder, recurrent depressive disorder, Post Traumatic Stress Disorder, and opioid
dependence. She also suffers from bronchospasm, cirrhosis of the liver, severe frailty, asthma, urinary
incontinence, and chronic back pain. She uses a wheelchair. The Claimants have a dog who acts as a
“support animal”, meaning it provides emotional support which helps maintain their mental health.

15. Until 2022, the Claimants were living in a town in the Midlands. For reasons set out below I will not
identify the name of the town and will refer to it as “Town X”. In October 2022 the Claimants fled Town X
after they were the victims of what is, somewhat euphemistically, called “cuckooing”, a practice by which a
criminal gang takes over the home of a vulnerable person and exploits the person and the property to
engage in criminal activity. The alleged exploitation and criminal activity in the present case are serious,
and the police are investigating the matter. In addition the First Claimant has been referred to the National
Referral Mechanism as a victim of modern slavery.

16. In the Claimants' case, those who had exploited them are regarded by the police as being particularly
dangerous, such that the Claimants are not only regarded as being unsafe in Town X, but also, as set out
below, were regarded by the police as being unsafe anywhere in London after one of those allegedly
responsible for their exploitation was seen in the city. The police in Town X have also expressed concerns
about the Claimants being identified in these proceedings or their current whereabouts being revealed. I
therefore granted the Claimants anonymity and have sought to remove information that might identify them
or their current whereabouts from this judgment.

17. After being briefly accommodated by the police near Town X, the Claimants left the area and
eventually arrived in London on 2 January 2023 where they initially slept rough for a number of nights.
They were then provided hostel accommodation located in the Defendant borough.


-----

18. On 20 April 2023 the Claimants made a homelessness application to the Defendant. They sought
accommodation form the Defendant for themselves and their dog. As that proved difficult to find, the
Claimants were initially housed separately. The First Claimant was housed, from 24 April 2023, with the
couple's dog in a hostel, Passage House, run by a charity with connections to the Defendant. From the
same date the Second Claimant was housed by the Defendant in temporary accommodation in Ealing. The
accommodation was not wheelchair accessible, and the Second Claimant had to use a walker inside the
property and had difficulties using the shower. This was brought to the Defendant's attention by the
Claimants' representatives, and it was recognised by the Defendant that the accommodation was not
[“suitable” within the meaning of HA 1996 s 206. It was, however, accepted by the Claimants in the short](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0W8-00000-00&context=1519360)
term while accommodation was found in which the couple could live together with their dog.

19. Following correspondence with the Claimants' representatives, including a pre-action letter, the
Defendant stated that it required medical evidence of the Claimants' need to be housed with their dog if
accommodation was to be sought which accepted animals. This was provided on 7 August 2023 in the
form of a report from a psychiatrist. On 17 August 2023 the Defendant stated that, having reviewed the
medical evidence, it agreed to seek to accommodate the Claimants with their dog. On 18 August 2023 the
Defendant wrote to the Claimant indicating that their homelessness application had been considered, and
[that the Defendant accepted that the full housing duty under HA 1996 s 193 was owed to them.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)

20. On 20 August 2023 the First Claimant left Passage House. There is some dispute about why he did
so, but it is not material to this claim. It is not disputed that the First Claimant then became street
homeless. The Defendant was informed of this on 21 August 2023. On 22 August 2023 the Defendant
sourced alternative hostel accommodation for the First Claimant, but he did not feel safe there and left on
23 August 2023.

21. On 25 August 2023 the Claimants issued judicial review proceedings. Their grounds of challenge are
set out further below, but essentially they contended that the Defendant had accepted the full housing duty
pursuant to s 193 was owed, and in breach of the duty the Defendant had not made suitable
accommodation available to them. The Claimants also sought and obtained interim relief on 25 August
2023 requiring the Defendant to secure accommodation for the First Claimant and the Claimants' dog as a
matter of urgency. The Defendant did not immediately comply with the order, and later that night the
Claimants obtained an out-of-hours injunction requiring the Defendant to make accommodation available
for the First Claimant in a London-based Travelodge. On 26 August 2023 the Defendant accommodated
the First Claimant in a Travelodge in central London with the Claimants' dog.

22. On 5 September 2023 the Defendant submitted Summary Grounds of Defence. At the time the First
Claimant was accommodated in the London Travelodge while the Second Claimant remained in Ealing.
The Defendant accepted that the accommodation was not suitable, not least because the Claimants
required joint accommodation as well as because of the mobility difficulties for the Second Claimant in the
[Ealing property. The Defendant thus accepted it was in breach of its HA 1996 s 193(2) duty and accepted](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
that permission should be granted to the Claimants to challenge the breach of duty. The Defendant stated
that the only issue in dispute in relation to that part of the case was the question of relief, and in particular
whether a mandatory order was appropriate. The Defendant invited the Court to refuse permission on the
[Claimants' other two grounds which involved alleged breaches of the EA 2010 and are set out below.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)

23. On 27 September 2023 the Claimant's representatives were advised by the police from Town X that
one of the individuals being investigated for the exploitation of the Claimants had been seen in London. On
29 September 2023 the police put in writing their concerns about the Claimants' safety if they remained in
London. This was passed on to the Defendant and it was asked to find accommodation for the Claimants
outside London. On 6 October 2023 the Defendant agreed to the request and on 17 October 2023 the
Claimants were moved together to a Travelodge in Town Y, a town outside London, which accommodated
dogs and was, as I understand it, wheelchair accessible. They have remained there since.

24. On 6 December 2023 David Lock KC, sitting as a Deputy High Court Judge, granted the Claimants
[permission to pursue Ground 1 (which concerned the Defendant's failure to comply with the HA 1996 s 193](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
duty) and Ground 3 (which concerned an alleged breach of the public sector equality duty in EA 2010 s


-----

[149). He refused permission on Ground 2 (which concerned an alleged breach of EA 2010 s 19 and 29 in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
relation to the Defendant's policy / practice on securing accommodation which allowed animals). The
Claimants sought to renew their application to pursue Ground 2.

25. On 20 December 2023 the Defendant submitted Detailed Grounds of Resistance, along with a witness
statement of Gregory Roberts, the Defendant's Head of Temporary Accommodation, dated 18 December
2023. In its Detailed Grounds, the Defendant stated that matters had moved on since its Summary
Grounds. It asserted that since the Claimants were now accommodated together in wheelchair-accessible
[accommodation with their support dog, the Defendant no longer accepted that it was in breach of its HA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
_[1996 s 193(2) duty. It stated that “[t]he primary position of the Defendant at this stage is that the Claimants](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
are presently being suitably accommodated pursuant to the full housing duty… It is not said that their
current accommodation is necessarily suitable as a long-term option but rather that it is [suitable] in respect
of the short to medium term.” Mr Roberts confirmed in his witness statement that the Defendant believed
the Claimants were “currently suitably accommodated” while “a long-term resolution” is sought. That
remained the Defendant's position at the hearing before me.

26. On 17 January 2023 I heard the Claimants' judicial review. I considered both Grounds 1 and 3 of the
claim for which permission had been granted, and, on a “rolled-up” basis, the Claimants' application for
permission to be granted on Ground 2. At the hearing I also considered an application by the Claimants to
adjourn and an application by the Claimants, dated 5 January 2024, to admit a psychiatric report of Dr
Galappathie, a Consultant Forensic Psychiatrist, who had produced a report on the First Claimant on 11
November 2023. I set out my decision on those applications, as well as my conclusion on the grounds of
challenge, below.

Grounds of challenge

[Ground 1 : Breach of HA 1996 duty to provide suitable accommodation](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)

Introduction

27. Ground 1 of the Claimants' claim is that the Defendant has been under a duty to provide them with
suitable accommodation since 20 April 2023 (initially under _[HA 1996 s 188(1), and then from 18 August](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y1GR-00000-00&context=1519360)_
2023, when the full homelessness duty was accepted, under s 193(2)). The Defendant accepts that, until
17 October 2023, the duty was breached. I will hear from the parties on whether any declaratory or other
relief in relation to the historic position should flow from the concession, and any costs consequences. The
key issues before me, however, are whether the Defendant is now, and has been since 17 October 2023,
in breach of s 193(2), and if so what relief is appropriate.

The parties' positions and the issues in dispute

28. Since 17 October 2023, the Claimants have been accommodated together in wheelchair accessible
accommodation, along with their support dog, in a Travelodge in Town Y. The Defendant's position is that
[they have, since that date, been provided with “suitable” accommodation and that the Defendant's HA 1996](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
_[s 193(2) duty has thus been discharged. The Defendant relied on the observations of Baroness Hale in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
_Birmingham City Council v Ali and others [2009] UKHL 36; [2009] 1 W.L.R. 1506 at paragraph 47 that_
“[t]here are degrees of suitability. What is suitable for occupation in the short term may not be suitable for
occupation in the medium term, and what is suitable for occupation in the medium term may not be suitable
for occupation in the longer term.” It is the Defendant's case that the current accommodation may not be
suitable on a long-term basis, but it is suitable for the Claimants in the “short to medium term”. The
Defendant further contends that if the Claimants consider the current accommodation is not suitable, that is
not a matter that should be challenged in judicial review proceedings, but should be raised by way of a
request for a statutory review pursuant to _[HA 1996 s 202(1)(f), and, if that is unsuccessful, through an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0F9-00000-00&context=1519360)_
appeal to the County Court pursuant to s 204(1).

29. Before me Ms Reid noted that the suggestion that the Town Y Travelodge was suitable was made for
the first time in the Defendant's Detailed Grounds of Defence and witness evidence served on 20
December 2023 She submitted that the accommodation had never before been offered in purported


-----

discharge of the Defendant's duty under _[HA 1996 s 193(2), and that without some formal notice to that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
effect the Claimants have no right to seek a statutory review or appeal under ss 202 and 204. She pointed
to the general practice of the Defendant, when it considered it had provided suitable accommodation, of
giving a formal notice indicating that it believed it had discharged its statutory duties and informing those
affected of their rights to seek a review. She noted that has not been done in relation to the Town Y
[Travelodge. She also referred me to HA 1996 s 208(2) which provides that if a local authority discharges](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y078-00000-00&context=1519360)
its housing functions by providing accommodation outside their district, they should give notice to the
housing authority where the accommodation is situated. She noted that, too, has not been complied with.
Ms Reid submitted that, on that basis, the position was the same as when the Defendant filed its Summary
Grounds, and I should simply go on to consider the question of remedy for breach of duty.

30. It is regrettable that the Defendant did not indicate earlier than 20 December 2023 that it considered
the Town Y Travelodge was “suitable” accommodation, and that that was not done by way of a formal
notice given to the Claimants. It meant that the Claimants believed, at least until 20 December 2023, that
the Defendant continued to accept they were not in suitable accommodation, and that the issue in dispute
[in these proceedings was solely what remedy was appropriate for the failure to discharge the HA 1996 s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
_[193(2) duty, rather than the prior issue of breach. For the Defendant, Mr Lane frankly accepted that notice](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
should have been given on or shortly after 17 October 2023, and the Claimants told of their right to seek a
review. He also accepted that notice under s 208 should have been given to the relevant housing authority
for Town Y.

31. The difficulty is that, while Ms Reid's criticisms of the Defendant's conduct may be well-founded, I do
not consider they assist on the issues before me.

32. Ms Reid did not suggest the Defendant's contention that the Town Y Travelodge was suitable was
made in bad faith, or that the Defendant did not genuinely believe the accommodation was suitable. As I
indicated, it was set out in the Defendant's Detailed Grounds of Resistance and confirmed in a witness
statement of the Defendant's Head of Temporary Accommodation, that the Defendant considered the
Claimants were now suitably accommodated. That maybe an erroneous belief, but I have no reason to
[believe it is not genuinely held. I cannot, therefore, simply assume that the Defendant is in breach of its HA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
_[1996 s 193 duty and proceed to consider the question of remedy. While it may be desirable for a housing](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
authority that considers it has provided suitable accommodation, and so discharged its housing duty, to
give clear notice to that effect, that is not a condition precedent to the authority asserting that the
accommodation is suitable. I also do not accept the Claimants' submission that without formal notice they
cannot seek a statutory review or appeal the Defendant's conclusion on suitability. There is no requirement
in the statute or elsewhere for some particular form of notice before an individual has a right of review or
[appeal a suitability decision under HA 1996 ss 202 and 204. There thus was, and is, nothing to prevent the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0F9-00000-00&context=1519360)
Claimants, having been told on 20 December 2023 that the Defendant considered their current
accommodation suitable, from commencing the applicable statutory process to challenge the conclusion.

33. The first issue I need to determine pursuant to Ground 1, therefore, is whether the Defendant is, and
[has been since 17 October 2023, in breach of its duty under HA 1996 s 193(2). That turns on the suitability](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
of the Town Y Travelodge. If I do not find the Town Y Travelodge is unsuitable, or more accurately if I do
not find the Defendant is irrational in concluding it is suitable, that is the end of the matter pursuant to
Ground 1. It is only if it is unsuitable, that I would then need to determine what relief was appropriate, and
in particular whether to make a mandatory order applying the principles set out by the Supreme Court in R
_(Imam) v Croydon LBC [2023] UKSC 25; [2023] 3 WLR 1178._

Analysis

34. Turning to suitability, there are three reasons why I am not prepared to hold that the Defendant was
irrational in concluding the Town Y Travelodge is suitable.

(i) The Claimants' pleaded case


-----

35. First, if the Claimants wish the court to determine that the Town Y Travelodge is unsuitable, I consider
that needed to be specifically pleaded, and I do not consider that issue is currently properly before the
court.

36. The courts have in recent years expressed concern about a lack of procedural rigour in judicial review
cases (see e.g. R (Dolan) v Secretary of State for Health and Social Care _[2020] EWCA Civ 1605, [2021] 1_
WLR 2326at paragraphs 116-120 and _R (Spahiu) v Secretary of State for the Home Department_ _[2018]_
_EWCA Civ 2604, [2019] 1 WLR 1297at paragraphs 2, 62-63). The concern arises, in particular, where, as_
sometimes occurs, circumstances change during the course of a judicial review claim and claimants seek
to shift their case to a different target without amending their pleadings. Judicial review is a remedy in
which “unnecessary formality is to be avoided” (Spahiu paragraph 2). There will, however, be
circumstances in which procedural rigour will be important “not for its own sake” but “in order for justice to
be done” and so that “everyone should know where they stand, so that, for example, the defendant can
properly prepare evidence in a timely fashion” (Dolan paragraph 117). That arises, in particular, where
events have moved on after a judicial review was issued, such that the case becomes fundamentally
different to that originally pleaded. I consider that applies here.

37. I have sympathy for the position in which the Claimants' representatives found themselves on 20
December 2023. The Defendant gave no indication that it considered the Town Y Travelodge to be suitable
accommodation for over two months from 17 October 2023 to 20 December 2023, let alone giving the kind
of formal notice that one expects for such a decision. Once it became clear on 20 December 2023 that the
Defendant did consider the accommodation suitable, however, in my view some form of amendment to the
Claimants' pleadings was required. This is not a situation, as sometimes occurs, where there have been
some minor developments due to the passage of time, and which could be dealt with by way of updating
evidence, but where the core issue in dispute remains the same. A case about accommodation A (which
both parties accept is unsuitable) is quite different to a case about accommodation B (which the local
authority considers is suitable, but the claimant does not). It requires amended pleadings.

38. When the Claimants issued proceedings, the case turned on whether the steps being taken by the
Defendant to find alternative accommodation were sufficient to render it inappropriate to make a mandatory
order. The case now turns on the particular suitability of the Town Y Travelodge. In those circumstances it
was necessary, in my view, for the Claimants to plead precisely why they considered the Travelodge to be
unsuitable, and why it was irrational for the Defendant to reach a different view. The difficulty of proceeding
without such pleadings is that the Defendant and the Court do not know what aspect of the accommodation
is regarded as unsuitable and on what basis, and the Defendant is not in a position to “properly prepare
evidence in a timely fashion” in response. The result, without amended pleadings and evidence, is that
there was virtually no evidence before me from which I could properly assess the suitability of the Town Y
Travelodge. It is not clear what exactly is the nature of the accommodation, its size and layout, its suitability
for a wheelchair user or for people living with a dog. There is almost no information about the facilities in
terms of the Claimants' ability to prepare or heat food, whether the Claimants have a shared bathroom,
laundry facilities etc, and how that affects the Claimants. The Defendant cannot fairly respond to, and the
court cannot properly determine, an allegation that it was irrational to conclude accommodation is suitable
without the Claimants indicating on what basis it is said to be unsuitable and providing evidence to that
effect.

39. There is a further reason why I consider that amended pleadings were required in the present case. As
set out further below, there is a question as to whether, once suitability of accommodation is in dispute,
judicial review is the correct mechanism to resolve it. That is likely to lead to a challenge to the suitability of
accommodation being refused permission if it was raised at the outset. It would be wrong, in my view, to
avoid such a permission decision by continuing with a claim that was brought when suitability was not
disputed, and using the same claim to challenge the suitability of different accommodation. I am not
suggesting the Claimants have acted in any way improperly or have sought to take a procedural advantage
in proceeding as they have. They were plainly entitled to issue proceedings in August 2023 as they did.
Nevertheless, in my view the case fundamentally changed once it was asserted that the Claimants'
accommodation was suitable, and it was necessary for an application to be made to amend pleadings. As


-----

well as ensuring the issues in the case were clear and both parties had a fair opportunity to produce
relevant evidence, it would have enabled the court to decide, as it would at the permission stage, whether
to allow the amendment and permit a suitability challenge to proceed by way of judicial review, or whether
an alternative remedy was more appropriate.

40.  In circumstances in which the Claimants' pleadings have not challenged the Defendant's assessment
of the suitability of the Town Y Travelodge, I therefore do not consider the issue is properly before me and I
am not prepared to find the Defendant's conclusion on suitability to be irrational.

(ii) Alternative remedy

41. I also consider that it is not appropriate to determine a challenge to the suitability of the Town Y
Travelodge in these judicial review proceedings for a second reason. That is because there is an
alternative, and more appropriate, remedy open to the Claimants.

42. The Claimants were told on 20 December 2023 that the Defendant considered the Town Y Travelodge
was suitable in the short to medium term and that it had therefore discharged its statutory duties to them. It
was open to them to seek an internal review of that decision, and, if that was unsuccessful, to appeal to the
[County Court pursuant to HA 1996 ss 202 and 204. As well as being the remedy Parliament has directed,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0F9-00000-00&context=1519360)
that is significantly more likely to lead to the matter being resolved, or at least for any dispute to crystalise
properly. The internal review follows a detailed prescribed process set out in the 2018 Regulations. If the
review concluded that the accommodation was unsuitable that would be the end of the matter. If the review
concluded it was suitable, reasoning would need to be provided (see _[HA 1996 s 203(4)), and that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y0X7-00000-00&context=1519360)_
reasoning could then form the basis for an appeal to the County Court which would be much better placed
than this court to determine if the Defendant's assessment of suitability was irrational or otherwise unlawful.

43. I do not suggest there is some jurisdictional bar on the High Court in judicial review proceedings
[determining suitability of accommodation pursuant to the HA 1996. Judicial review remedies are, however,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)
discretionary. Where there is an alternative remedy for a dispute which is more suitable, and in particular
one prescribed by Parliament, it will generally be inappropriate to proceed to determine the matter by way
of judicial review. I consider that applies in the present case and I do not consider it appropriate, even if
such a challenge had been properly pleaded, to determine, in these judicial review proceedings, whether
the Defendant's assessment of suitability of the Town Y Travelodge was irrational.

(iii) Evidence on suitability

44. Third, I do not consider that the Claimants have, in any event, established, on the evidence currently
before me, that it was unlawful for the Defendant to conclude that the Town Y Travelodge was suitable.

45. It was common ground that the issue was not whether I considered the Town Y Travelodge suitable,
but whether the Defendant was entitled to consider it suitable. It was also common ground that, to
succeed, the Claimants would need to establish the Defendant's decision was irrational. The difficulty for
the Claimants in establishing irrationality arises in large part because of the way the way the case has
developed and the failure to amend the claim to challenge suitability that I described above. As a
consequence, there was little or no evidence before me on suitability, and certainly not enough to allow me
to determine that the Defendant's assessment of suitability was not one open to a rational local authority.

46. The Claimants themselves provided no evidence about the conditions in the Town Y Travelodge,
whether they assert it is unsuitable and if so why. Their witness statements were prepared when the
judicial review proceedings were issued and the Claimants were in different accommodation. The only
evidence before the court that touched on the suitability of the Town Y Travelodge was the psychiatric
report from Dr Galappathie of 11 November 2023 on the First Claimant. As set out above, the Claimants
had applied on 5 January 2024 to admit that report and I considered it de bene esse. Insofar as the report
sought to deal with suitability, there was a good argument it was inadmissible given my conclusions above
that that was not a matter the court should be determining. The Defendant did not, however, object strongly
to the admission of the report, and it did contain material which was of relevance to other issues in the


-----

case. I am therefore content to admit it. I do not, however, consider it establishes the Defendant's
assessment of suitability was irrational.

47. It is true that Dr Galappathie's report expressed some concerns about the First Claimant being housed
in the Town Y Travelodge, but they do not come close to establishing that a view that the Travelodge was
suitable in the short to medium term was not one open to a rational local authority. First, Dr Galappathie's
11 November 2023 report was based only on speaking to the First Claimant. It is therefore of limited value
in determining the suitability of the accommodation for the Second Claimant, and does not deal, for
example, with any difficulties she might have in the accommodation as a wheelchair user or given her other
disabilities. Secondly, it was based on an interview conducted on 8 November 2023, approximately 3
weeks after the Claimants arrived at the Travelodge. At that point any assessment of the actual impact on
them of being in the accommodation (as opposed to potential impacts) would be difficult to undertake, and
Dr Galappathie did not purport to undertake such an assessment.

48. As I indicated, the Claimants were able to be accommodated together in the Town Y Travelodge with
their support dog and in wheelchair accessible accommodation. So at least the principal concerns about
the suitability of the previous accommodation were dealt with. It is again right to record that Dr Galappathie
did express concerns about the Claimants being in “shared accommodation … such that they have to use
a shared kitchen and shared bathroom” and he considered that would likely have a “long term impact upon

[the First Claimant's] mental health” given his previous experience of cuckooing as well as childhood
traumas. That, however, deals with long term impact rather than short and medium term suitability. It is
also not clear, because there is no evidence on the set up at the Travelodge, whether the Claimants, in
fact, have a “shared kitchen and shared bathroom” or whether Dr Galappathie was giving his opinion on
the general suitability of such arrangements. Dr Galappathie also expressed concerns about the First
Claimant being in accommodation that needed to be frequently rebooked as he needed “stable
accommodation which is permanent to give him the sense of security … in order to engage in the
treatment he requires.” Dr Galappathie made other similar comments about the benefits of the First
Claimant being placed in “self-contained accommodation that is stable long term” and where he can obtain
treatment for his substance misuse. Again, that goes to long term suitability, and does not suggest it is
irrational to consider the accommodation suitable in the short to medium term. Indeed, Dr Galappathie
recognised that the First Claimant's mental health was, at least in the short term, relatively stable and he
did not suggest the accommodation was undermining that stability.

49. It may be with evidence directly from the Claimants, further information about the nature of the
accommodation and the effect it is having on the Claimants, or further and up to date medical evidence,
that the picture will change. It may be that the Defendant could be persuaded by such evidence in an
internal review that the accommodation is unsuitable. As matters stand, however, I do not consider that the
evidence establishes that the Defendant's view on the current suitability of the Town Y Travelodge to be
irrational.

50. During the course of the hearing, as it became clear that the Claimants would have difficulty
establishing irrationality on the evidence before the court, Ms Reid sought an adjournment so that she
could obtain further witness statements from the Claimants. I declined to adjourn for two reasons. Firstly, I
considered it likely an adjournment would serve no purpose. I had reached a preliminary view that it would
not be appropriate for the court to determine the suitability of the accommodation in judicial review
proceedings given the statutory remedies open to the Claimants, and that it should not be determined
without amendment of the Claimants' pleadings. Ms Reid made clear that the purpose of the adjournment
was solely to obtain evidence from the Claimants and not to seek to amend their case. An adjournment
was therefore not likely to assist the Claimants to succeed on Ground 1 in any event. Secondly, I refused
an adjournment as I did not consider it an appropriate exercise of the court's case management discretion.
The Claimants have known since 20 December 2023 that the question of the suitability of accommodation
was in issue. As Mr Lane noted, the order granting permission had made specific provision for the
Claimants to serve evidence in reply. The Claimants had not sought to do so. I considered it was too late in
the day to apply for an adjournment, and not fair and proportionate to the parties, or an appropriate use of
court time, to adjourn the case on the day of the hearing.


-----

Conclusion on Ground 1

51. For the reasons set out above, I therefore allow the Claimants' judicial review to the extent that it
[asserts, as conceded, a breach of the HA 1996 ss 188(1) and 193(2) up until 17 October 2023. I do not,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y1GR-00000-00&context=1519360)
however, find that the Defendant has been in breach of _[HA 1996 s 193(2) from 17 October 2023, or is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)_
currently in breach. I do not therefore need to consider the question of whether, if there was a breach
established, a mandatory order would be appropriate.

Ground 2: Unlawful policy on support animals

Introduction

52. Pursuant to Ground 2, the Claimants seek to challenge the Defendant's policy in respect of
accommodating households with animals. They contend that it is discriminatory pursuant to _[EA 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_
_[sections 19 and 29. Permission to pursue this ground was refused on the papers. I considered a renewed](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_
application to grant permission, and I heard submission on whether, if I granted permission, I should allow
the judicial review.

The parties' positions and the issues in dispute

53. It was not disputed that the Claimants have significant mental and physical health impairments and are
[thus disabled persons pursuant to the EA 2010. It is also not disputed that their dog operates as a “support](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
animal” who alleviates mental distress and provides emotional support and comfort for them in ways that
support their mental health. The Claimants seek to challenge the Defendant's policy on accommodating
households with support animals. The ground was framed as being a challenge to the “unreasonable”
nature of the policy. It is difficult to see, in particular in light of the guidance given by the Supreme Court on
challenges to policies or practice statements of public bodies, how a challenge that simply asserts a policy
is “unreasonable” could succeed (see R (A) v Secretary of State for the Home Department _[2021] UKSC 37_
and R (BF (Eritrea)) v Secretary of State for the Home Department [2021] UKSC 38). It became clear,
however, that the Claimants' case was that the Defendant's policy or practice was unlawful because it
[breached EA 2010 s 19 read with s 29 rather than because it was “unreasonable” in some general sense.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
That is a legitimate challenge following A and BF(Eritrea).

54. The Claimants identify two aspects of what they say is the Defendant's policy or practice they seek to
challenge. First, they seek to challenge the Defendant's policy that applicants “must provide medical
evidence to demonstrate a need to be housed with an animal”. Second, the Claimants seek to challenge
the Defendant's policy “not to maintain a housing stock which allows households with pets.”

Pleading a discrimination claim

55. I say more about the two aspects of the Defendant's policy. First, though, I return to the question of
procedural rigour.

56. It is not uncommon for challenges for breach of the _[EA 2010 to be brought in judicial review](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_
proceedings rather than before the County Court. That is so, in particular, in relation to policies or practices
of public bodies it is said are indirectly discriminatory because they disadvantage those with a protected
characteristic. There is nothing wrong in pursuing such claims in judicial review proceedings which is
generally an appropriate remedy for challenges to a public authority's policies. It is, however, important
that, where a discrimination claim is brought, the pleadings make clear (from both sides) how exactly it is
[being said that the conditions for establishing indirect discrimination in EA 2010 s 19 are met. EA 2010 s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
_[19 sets out a series of discrete requirements for establishing indirect discrimination. The claimant must first](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_
identify the “provision, criterion or practice” (“PCP”) pursuant to s 19(1) they seek to impugn. They must
then show that the defendant “applies or would apply [the PCP] to persons whom [the claimant] does not
share a protected characteristic” (s 19(2)(a)). The claimant must show that the PCP “puts, or would put,
persons with whom [they] share the characteristic at a particular disadvantage when compared with
persons with whom [the claimant] does not share it” (s 19(2)(b)), and that the PCP puts or would put the
claimant “at that disadvantage” (s 19(2)(c)). If that is established, the burden then shifts to the defendant to


-----

show the PCP is a “proportionate means of achieving a legitimate end” (s 19(2)(d)). If they cannot do so
they are guilty of indirect discrimination.

57. There is an obvious benefit in the parties going through each of the four elements set out in s 19(2),
and indicating the basis on which they contend each element is or is not established, and the evidence
being relied on in that regard. The court will then be in a position to identify what PCP is at issue, the basis
on which it is said to apply generally, exactly why it is being said that it does or does not disadvantage the
claimants and those who share their protected characteristics, and why it is or is not justified. While both
parties' counsel were very helpful before me in seeking to elucidate their respective cases, it was not
always clear exactly which elements of s 19 were in dispute and on what basis, and what evidence was
being relied on in relation to the various requirements for indirect discrimination. The impact that had on the
claim is explained below.

Analysis

(i) Requirement for evidence of medical need

58. Turning to the first way in which the Claimants put their case, they contend the Defendant imposed a
requirement that those seeking temporary accommodation with an animal “must provide medical evidence
to demonstrate a need to be housed with an animal”, and that that is indirectly discriminatory against those
[with disabilities. As to the first stage of the EA 2010 s 19 analysis, the Claimants have clearly identified a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
[PCP within the meaning of EA 2010 s 19, and the Defendant accepts it operates the impugned policy or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
practice. The policy or practice was applied generally to those who are disabled and those who are not.
Section 19(2)(a) is therefore satisfied.

[59. The second stage, pursuant to EA 2010 s 19, is that it is for the Claimants to establish that the PCP](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
places those with disabilities at a particular disadvantage compared to others, as required by s 19(2)(b). It
is not, however, immediately clear that is established, or what disadvantage the Claimants were relying
upon.

60. Ms Reid referred me to evidence from Dr Galappathie that “a number of mental health patients rely on
support animals” and that it is “not common for them to have medical evidence” to support the need for an
animal. That maybe right, but it does not mean those who are disabled are placed at a particular
disadvantage by the Defendant's PCP. It was not disputed that it is more difficult for the Defendant to
source accommodation for someone who wants to be accommodated with an animal as opposed to
someone who does not. That is not surprising given that many of the private providers from whom the
Defendant sources accommodation do not accept animals. The Defendant explained why, in those
circumstances, it requires evidence of medical need. In an email of 26 June 2023 to the Claimants'
representatives, the Defendant wrote: “there is a very scarce supply of properties [that accept animals]”
and “accordingly these properties will only be provided where a medical need is evidenced.”

61. It may be that a requirement to evidence medical need will require steps to be taken which will not
always be easy to satisfy. But there is no basis for assuming, certainly without evidence, that the
requirement disproportionately disadvantages those with disabilities. If there is a limited pool of
accommodation which accepts animals, there needs to be a mechanism by which it is distributed. A
practice which requires medical evidence, rather than disadvantaging those with disabilities overall, may, in
fact, ensure that those with the greatest disability-related need to be housed with the animal are prioritised.
Without such a policy, and if the Defendant accepted it was sufficient for people simply to assert that they
needed to be housed with an animal for such accommodation to be sought, the limited accommodation
which accepts animals might well be allocated to those who have a lesser need for it. It may not be
straightforward to obtain evidence of medical need, but I do not accept, without evidence to that effect, that
the policy, as a general matter, disproportionately disadvantages those with disabilities. It may do so, or it
[may, as I indicated, advantage them. Without evidence it is the former, the Claimants have not satisfied EA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
_[2010 s 19(1)(b).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_

62. I am also not satisfied that the Claimants have shown that they were, themselves, disadvantaged by
[the Defendant's policy as required by EA 2010 s 19(1)(c). The First Claimant was housed at Passage](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)


-----

House with the couple's support dog from 24 April 2023 to 20 August 2023. The Claimants provided
medical evidence of their need to be housed with an animal on 7 August 2023, and it was accepted by the
Defendant on 17 August 2023. The First Claimant was again housed with the couple's dog at the central
London Travelodge from 26 August 2023 to 17 October 2023, and from 17 October 2023 both Claimants
have been accommodated with their dog in the Town Y Travelodge. The First Claimant was thus
accommodated with the couple's dog for all but 20-25 August 2023. The period 20-25 August 2023 cannot,
however, be regarded as establishing disadvantage occasioned by the PCP, as that was after the medical
evidence was provided. As to any delay in accommodating the Claimants together with their support
animal, it is also difficult to see how that can be attributed to the Defendant's medical evidence policy. The
delays may be explained by the shortage of accommodation which accepts dogs, but that is a separate
PCP the Claimants seek to challenge which I deal with below. It is difficult to see how any delay can be
said to have been due to the requirement to obtain evidence of medical need. The Claimants were told of
the requirement to evidence medical need on 26 June 2023, the Defendant accepted such evidence had
been provided on 17 August 2023, but the Claimants were not accommodated with their dog until 17
October 2023 when they moved out of London. It was clearly not the requirement to obtain evidence of
medical need that caused the two months delay, and there is no reason to think the Claimants would have
been accommodated earlier with their dog if the Defendant had not requested such evidence. They have
[not therefore shown they were disadvantaged by the PCP as required by EA 2010 s 19(2)(c).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)

[63. If the Claimants were able to establish the requisite disadvantage pursuant to EA 2010 s 19(1)(b) and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
_[(c), the burden would then shift to the Defendant to establish justification. If the Claimants had reached that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_
[stage, I would have found the Defendant's policy to be justified within the meaning of EA 2010 s 19(2)(d).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
Even if the Claimants had shown the policy of seeking evidence of medical need does disadvantage those
with disabilities, for example because it meant it took somewhat longer for them to be provided with
accommodation that accepts animals, in circumstances in which such properties are in short supply it
seems clearly justifiable to give priority to those who can evidence a medical need. That is likely to better
target the limited properties accepting animals to those most in need of them, which is a legitimate aim for
the Defendant to pursue, and I consider that requiring evidence of medical need for a support animal is a
proportionate way of pursuing that aim.

64. For completeness the Claimants had an additional argument in reliance upon the Homelessness Code
of Conduct for Local Authorities. The Code states at paragraph 17.67:

Housing authorities will need to be sensitive to the importance of pets to some applicants, particularly
elderly people and rough sleepers who may rely on pets for companionship. Although it will not always be
possible to make provision for pets, the Secretary of State recommends that housing authorities give
careful consideration to this aspect when making provision for applicants who wish to retain their pet.

The Claimants submitted that requiring evidence of medical need to be housed with an animal is
inconsistent with the Code as it does not show the required “careful consideration”. I do not consider that to
be a good argument. I do not consider the requirement for evidence of medical need is inconsistent with
giving “careful consideration” of why pets are “important” to some applicants. Indeed, it might be thought to
be a way of according such consideration by prioritising the most in need.

(ii) Failure to secure access to housing stock which allows pets

65. The second way in which the Claimants put their case is that, they claim, the Defendant had a policy
or practice of failing to secure housing stock which allows animals, and that disproportionately
[disadvantages those with disabilities. Again, in analysing the claim, it is helpful to break down EA 2010 s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
_[19 into its constituent parts.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_

[66. As to identifying the relevant PCP for the purpose of EA 2010 s 19, the Defendant's evidence is that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
“none of [its] regular providers of temporary accommodation will accept dogs in their properties”. The
Defendant denies, however, that it has a policy or practice of not maintaining stock which allows animals
as the Claimants claim. It says that the fact that its regular providers do not accept animals simply reflects
the preferences of private sector suppliers, and does not arise because of any policy or practice of the


-----

Defendant. Therefore, the Defendant asserts, _[EA 2010 s 19 is not engaged at all. I do not accept that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)_
argument.

67. It is important to identify exactly what is the relevant PCP. Here it is the series of practices by which
the Defendant identifies suitable temporary accommodation to meet its statutory homelessness duties.
That includes having a number of “regular providers” of accommodation from the private sector. It also
includes making ad hoc arrangements, for example in hotels or hostels, when that is necessary. As Mr
Roberts explains in his statement, “a number of senior officers hold corporate credit cards which are used
where bespoke ad hoc arrangements are needed”. It is on that “ad hoc” basis that the First Claimant was
accommodated with the couple's dog in the Travelodge in London from 26 August 2023, and both
Claimants were accommodated in the Town Y Travelodge from 17 October 2023. I see no reason why the
Defendant's procurement arrangements with the private sector, taken with the possibility of obtaining
[property on an ad hoc basis when needed, is not a “practice” within EA 2010 s 19. If, for example, a local](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
authority's procurement practices meant all of the temporary accommodation it sourced was nonwheelchair accessible, and so the Defendant routinely failed to discharge its housing duties to provide
suitable accommodation for wheelchair users, I cannot see why that would not be a PCP capable of falling
[within EA 2010 s 19. It may be that the difficulties sourcing wheelchair-accessible accommodation would](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
be relevant to justification, but I do not think that the authority could assert there was no relevant PCP and
no possible indirect discrimination. Similarly here, the Defendant's private sector procurement practices,
which lead to it having no regular providers of housing stock that accepts dogs, coupled with the possibility
of ad hoc procurement or assistance, is a PCP within the meaning of s 19. It is a PCP which applies
[generally so as to satisfy EA 2010 s 19(2)(a).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)

68. The next step is for the Claimants to establish that the PCP puts those who are disabled at a
“particular disadvantage when compared with persons [who are not disabled]” pursuant to s 19(1)(b). That
requires not simply establishing the Claimants themselves were disadvantaged by the PCP, but that the
PCP does, or would, disadvantage those with disabilities generally. Here, again, it is important to identify
what exactly is being said to be the disadvantage, and what evidence is being relied upon to establish it.
The Claimants' pleaded case is that the impact of being accommodated without an animal will be more
detrimental to those individuals who have a disability which means they require an animal to help with their
mental health. I can accept that proposition as a general matter, and it was not disputed by the Defendant
that if it had a PCP of refusing to allow people to be housed with animals that will disadvantage those with
disabilities as they are likely to have a greater need to be accommodated with an animal than those without
disabilities. That is not, however, the PCP. The PCP is the Defendant's private sector procurement
practices (which it is accepted leads to it having no regular providers of housing stock that accepts dogs),
coupled with the possibility of “ad hoc” procurement where that is required. The difficulty is that I have no
evidence of how that practice operates generally or how it impacts, or is likely to impact, on those with
disabilities. I therefore have no basis for concluding that, as a general matter, the PCP places those with
disabilities at a particular disadvantage compared to those without.

69. Claimants pursuing indirect discrimination claims do not necessarily require statistical evidence to
establish group disadvantage (see _R (Burnip) v Birmingham City Council [2012] EWCA Civ 629, [2013]_
PTSR 117 paragraph 13). In some cases it will be obvious a PCP will disadvantage those with disabilities
or other relevant protected characteristic, or it may be possible to infer such general disadvantage from the
experience of an individual claimant. I do not consider that to be the case here, however. The PCP of
having regular providers of temporary accommodation who do not accept animals, coupled with ad hoc
provision, may disadvantage those with disabilities. Or it may not. In the present case the Defendant found
the Claimants accommodation with their dog through ad hoc provision. The First Claimant was
accommodated with the couple's dog in Passage House from 24 April 2023 to 20 August 2023 and then in
the London Travelodge between 26 August 2023 and 17 October 2023, and the couple were
accommodated together with their dog from 17 October 2023 in the Town Y Travelodge. The Claimants
had various criticisms about the way the accommodation was arranged and the fact the couple were not
accommodated together with the dog sooner (though it was not immediately clear why they were not
accommodated together in the London Travelodge with their dog). That, however, does not enable me to
i f i [d b EA 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360) _19(2(b) th t th_ PCP ll di d t th ith di biliti


-----

70. It may be that a practice of having no regular suppliers of temporary accommodation which allow dogs,
but having ad hoc practices of sourcing animal-friendly accommodation that will be used when evidence of
medical needs is produced, leads to accommodation that permits animals being found relatively quickly for
those with disabilities. If ad hoc accommodation can be found relatively easily, it may be a better way to
ensure accommodation that allows animals can be quickly found than trying to find regular suppliers that
maintain housing stock that allows pets. Or it may not. The difficulty is that without the Claimants identifying
exactly how the PCP disadvantages those with disabilities generally, and providing evidence which
[establishes such disadvantage, they are unable to satisfy EA 2010 s 19(2)(b).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)

[71. Given my conclusion on EA 2010 s 19(2)(b), it is not necessary to consider s 19(2)(c) or whether the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
PCP is justified pursuant to s 19(2)(d). Had the latter stage been reached the clear identification and
establishment of the disadvantage relied on would again be important. An assessment of whether a
defendant can show that a PCP is a “proportionate means of achieving a legitimate aim” requires the
undertaking of a balancing exercise. It requires a defendant to establish that the disadvantage occasioned
by its PCP to the particular claimant, and to those who share the relevant protected characteristic
generally, can be justified. That requires having some sense of the scale of any disadvantage. If, in a case
such as the present, a defendant's PCP is likely to lead to short delays in obtaining accommodation in a
small number of cases, it may be relatively easy to justify not obtaining access to standing accommodation
that allows pets. That could be expensive and difficult to administer. On the other hand, if the disadvantage
arises in a significant number of cases and is much more severe, proportionality will be more difficult to
[establish. In circumstances where EA 2010 s 19(2)(b) is not established, that is not an exercise I need to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJM0-Y97X-72M1-00000-00&context=1519360)
undertake, and is not one which can properly be undertaken where, as here, if there is disadvantage
caused by the PCP, I do not have any sense of its scale.

Conclusion on Ground 2

72. Having heard full argument on Ground 2, it seemed to me that there is sufficient merit in the case to
grant the Claimants permission to pursue it. I do not, however, consider that the ground succeeds in
relation to either of the PCPs identified by the Claimants, and I dismiss it on its merits.

Ground 3 Public Sector Equality Duty

Introduction

73. Ground 3 of the Claimants' claim is that the Defendant has breached the public sector equality duty
(“PSED”) contained in EA 2010 s 149. The Claimants contend that what is required in this context is set out
in the Court of Appeal's judgment in _Hackney LBC v Haque [2017] EWCA Civ 4; [2017] HLR 14 at_
paragraph 43, and it was the Claimants' case that the Defendant failed to follow the approach in Haque.

74. Haque was an appeal from a decision of the County Court, which followed an internal review by a local
authority, on the suitability of accommodation provided to a disabled person to discharge the authority's
[duty pursuant to HA 1996 s 193(2). The Court of Appeal considered the role of the PSED in that context. At](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)
paragraph 43, the Court of Appeal made clear the PSED applied, and it required the local authority to
recognise an individual's disabilities and give “due regard” to those disabilities when determining the
suitability of accommodation. The Court of Appeal held, however, that the PSED did not require
accommodation to be provided which was “more than suitable” (paragraph 44), and it was not necessary to
expressly refer to the PSED in order to establish compliance with the duty (paragraph 47).

75. The parties did not cite other PSED authorities before me, but the applicable principles are wellestablished. In particular, it is well-established that the PSED imposes a duty of process rather than result,
and that provided “the court is satisfied that there has been a rigorous consideration of the duty, so that
there is a proper appreciation of the potential impact of the decision on equality objectives and the
desirability of promoting them, then it is for the decision-maker to decide how much weight should be given
to the various factors informing the decision” (see _R (Bridges) v Chief Constable of South Wales Police_

_[2020] EWCA Civ 1058, [2020] 1 WLR 5037at paragraph 176(6)). The way the PSED operates, therefore,_
is that it makes the potential impact of a decision on equality objectives, and the desirability of promoting
those objectives mandatory relevant considerations for the decision maker The decision maker has no


-----

discretion as to whether to consider those matters. In determining a PSED challenge, it is, therefore, for the
court to decide whether there were any potential equality issues which required consideration and whether
due regard was had to them. If due regard was had to equality issues, it is then a matter for the decisionmaker, subject to a review on a rationality basis, to decide how much weight to give to equality
considerations, to determine how to balance them against other factors, and, ultimately, to decide what
substantive decision to take.

The parties' positions and the issues in dispute

76. The Claimants' case was that in making decisions about the suitability of the accommodation offered
to them, the Defendant did not have due regard to the Claimants' disabilities. As originally pleaded the
focus was only on the Second Claimant, and the Claimants' case was that in relation to the Second
Claimant's accommodation, then in Ealing, “there is no recognition [by the Defendant] that the Second
Claimant has a physical disability, no focus on what the extent to which her disabilities impact on the
suitability of the property and the disadvantage she may suffer in the current accommodation that a person
without those disabilities would not, and to consider the suitability of the property through that lens.” By the
time the Claimants submitted their skeleton argument, they had moved to the Town Y Travelodge. The
Claimants sought to expand their claim to include both the First and Second Claimant and contended that
“[t]he Defendant has not focused on the extent to which the Claimants' disabilities impact on the suitability
of the property and the disadvantage they may suffer in the current accommodation that a person without
those disabilities would not and to consider the suitability of the property through that lens.”

Analysis

77. I do not allow this ground of claim for two reasons.

78. Firstly, this is a challenge to the manner in which the Defendant assessed suitability, and suitability
was either not disputed (pre-17 October 2023) or is not a matter I consider is appropriate to determine in
these judicial review proceedings (post-17 October 2023). As to the latter, a PSED challenge cannot
succeed in those circumstances any more than any other challenge to the way the Defendant determined
suitability.

79. At the time proceedings were issued, and up until 17 October 2023, the Defendant accepts that the
Claimants were not suitably accommodated. That was in large measure because the Second Defendant's
disabilities, and her need for wheelchair accessible accommodation, meant the accommodation in Ealing
was not suitable. It is impossible to see how there will be a breach of the PSED in assessing the suitability
of accommodation where it is accepted the accommodation is not suitable because of the individual's
disability. As to the position after 17 October 2023, and insofar as the Claimants are seeking to challenge
suitability, the matters I considered pursuant to Ground 1 apply. As I indicated, I do not consider that the
issue of suitability of Town Y Travelodge is properly before the court, and the Claimants have an
alternative and more suitable remedy to challenge the Defendant's assessment of suitability. As _Haque_
[makes clear, the PSED can be raised in an internal review under HA 1996 s 202, and can be considered](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0F9-00000-00&context=1519360)
by the County Court under s 204. That is the appropriate mechanism for the Claimants to raise concerns
that their current accommodation is not suitable or that the Defendant has failed properly to take account of
their disabilities in determining suitability.

80. Secondly, I do not accept that the Claimants' disabilities were not adequately considered in the
decision-making process either prior to or after 17 October 2023.

81. The Defendant completed a housing needs assessment for the Second Claimant on 20 April 2023. It
recorded that:

[The Second Claimant] stated that she has mobility issues. She uses a wheelchair. [She] has been
diagnosed with depression. [She] states that her husband has serious physical health conditions and
mental issues. He uses a walking aid.

The assessment noted that a report was provided of the medication the Second Claimant was taking and
concluded that “there is a reason to believe the [Second Claimant has] priority need because of her health


-----

conditions”. Subsequently the Claimants' representatives, as well as charities that helped the Claimants,
were assiduous in providing medical evidence to the Defendant about the Claimants, and, at least prior to
the 17 October 2023, explaining why their disabilities meant their accommodation was not suitable. A
report on the Second Claimant by Dr Galappathie was sent to the Defendant on 7 August 2023. GP reports
on each of the Claimants was provided to the Defendant on 9 August 2023. Those reports led to the
Defendant accepting that the Claimants had established a medical need to be housed with their dog due to
their mental health conditions. It also led, along with submissions made on the Claimants' behalf, to the
Defendant accepting that the accommodation being provided to the Claimants prior to 17 October 2023
was not suitable.

82. The Claimants complain about the failure to house them together with their dog until 17 October 2023,
and they suggest they were only housed with their dog after that date as a result of the threat to them in
London, and not because of any proactive steps taken by the Defendant. Whether or not those criticisms
are valid, they concern outcome not process. The Defendant recognised that the Claimants'
accommodation prior to 17 October 2023 was not suitable given their disabilities and that they needed to
be housed together. The Claimants' disabilities were factored into the Defendant's decision-making when it
assessed suitability as required by _Haque._ That discharges the EA 2010 s 149 duty. The fact the
Defendant did not then find the Claimants suitable accommodation until 17 October 2023 may be a
[substantive breach of HA 1996 s 193(2), but is not a breach of the PSED.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBY0-TWPY-Y14D-00000-00&context=1519360)

83. In relation to the post 17 October 2023 position, as set out above, there is little evidence before me as
to why it is said that the Town Y Travelodge is unsuitable in the short to medium term and what exactly it is
said the Defendant should have, but did not properly, consider, in assessing suitability by reference to the
Claimants' disabilities. The various issues which made the previous accommodation unsuitable (lack of
wheelchair access, the Claimants not being accommodated together and the Second Claimant not living
with the support dog) had been resolved. If further issues related to the Claimants' disabilities have not
been considered, that is a matter which may arise if the Claimants seek an internal review and pursue a
challenge in the County Court, but I do not consider the Claimants have established a breach of the PSED
in relation to the Defendant's current decision-making.

84. Finally, I note that when he granted permission in relation to the PSED, David Lock KC made
observations about the Defendant's policies and practices on sourcing accommodation that accepts
animals. The Claimants referred to that in passing in their skeleton of 4 January 2024. That was not,
however, how the case was pleaded. As set out above, Ground 3 was framed as a challenge, based on
_Haque, to the Defendant's specific assessment of the suitability of accommodation provided to these_
Claimants, not as a challenge to the Defendant's general policies or practices on accommodating animals
in temporary housing. As a consequence, in its Defence and evidence the Defendant did not deal with an
allegation that it had not had due regard to equality considerations in relation to its general policies or
practices, and I do not consider it fair to the Defendant to treat the Ground as if it had been formulated in
that way.

Conclusion

85. There is no doubt that the Claimants are vulnerable individuals and have significant housing needs,
and I pay tribute to the hard work of the Claimants' counsel, solicitors and charity workers who have helped
them thus far. It is accepted on all sides that the current accommodation at the Town Y Travelodge is not
necessarily a long-term solution, and it may be that if the Claimants seek an internal review or pursue an
appeal to the County Court it will be accepted that it is not suitable in the short to medium term. For the
reasons set out above, however, I consider that judicial review is not the appropriate remedy to deal with
those matters, and I do not consider the Claimants have established grounds on which the Defendant has
acted unlawfully. I therefore do not allow the Claimants' judicial review. That is save in relation to the
conceded position regarding the Ground 1 challenge to the suitability of the Claimants' accommodation
prior to 17 October 2023, on which I will hear submissions on relief.

**End of Document**


-----

