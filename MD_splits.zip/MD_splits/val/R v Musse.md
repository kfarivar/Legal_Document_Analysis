# R v Musse [2024] EWCA Crim 1012

Court of Appeal, Criminal Division

Singh LJ, Cutts J and Judge Timothy Spencer KC

25 July 2024Judgment

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making are that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**Mr M Moore-Taylor appeared on behalf of the Appellant**

**____________________**

**J U D G M E N T**

**(Approved)**

**____________________**

Thursday 25[th] July 2024

**LORD JUSTICE SINGH:**

1. This is an appeal against sentence brought with the leave of the single judge.

2. On 29 January 2024, the appellant pleaded guilty at Leeds Magistrates' Court in respect of an immigration
offence. He was committed for sentence to the Crown Court, pursuant to section 14 of the Sentencing Act 2020.

3. On 16 April 2024, in the Crown Court at Leeds, the appellant was sentenced by Mr Recorder Simon Jackson KC
to 20 months' imprisonment. An appropriate statutory surcharge was imposed.

4. For present purposes the facts can be summarised as follows. The appellant is an Eritrean national. On 30
September 2023, he was travelling in a rigid hull inflatable boat in the English Channel. The vessel was intercepted
within UK territorial waters by a Border Force vessel. The appellant was conveyed to the Immigration Reception
Centre in Dover before being taken to an immigration triage centre. He was then housed in a hotel in Bradford. He
was arrested at that hotel on 20 November 2023, following confirmation that he had made no application for a visa
or entry clearance, nor had such clearance been granted to him.

5. During interview, the appellant made full admissions. He accepted that he knew that he had not been permitted
to enter the UK without valid clearance and explained that he had not been forced to travel and had undertaken the


-----

journey of his own free will. He told officers that he did not perceive himself to be in any danger in the UK. He
explained further that he had travelled to Belgium in 2014 via Libya, France and Italy. He had made an application
for asylum in Belgium before receiving two custodial sentences there, which led to his asylum application being
revoked upon his release and therefore his being required to leave Belgium. He then travelled through France
before embarking on the boat journey to the UK.

6. Before this court Mr Moore-Taylor, who appears on his behalf, has told us that the appellant was rendered street
homeless in Belgium but was unable to return to his home country of Eritrea. He had left in 2014 owing to what Mr
Moore-Taylor submits were a well founded fear of persecution, in particular associated with compulsory
conscription in Eritrea.

7. The maximum penalty for an offence of this type is four years' imprisonment. The offence arises under an
[amendment made to the Immigration Act 1971 and is now to be found in section 24(D1) and (F1). Also, because](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
this was an attempt, there was a contravention of section 1(1) of the Criminal Attempts Act 1981. The offence was
therefore attempting to arrive in the UK without a valid entry clearance.

8. There is no offence specific definitive guideline for this type of offence, but guidance has been given by this court
in _R v Ginar_ _[2023] EWCA Crim 1121; [2024] 1 WLR 1264, in which the judgment of the court was given by_
Holroyde LJ, the Vice President of the Court of Appeal Criminal Division: see [17] to [27].  At [21] the court said:

"… the predominant purpose of sentencing in cases of this nature will generally be the protection of the
public. Deterrence can … carry only limited weight as a distinct aim in the sentencing of those who have
travelled as passengers in a crossing such as that upon which the applicant embarked. The circumstances
of those who commit offences of that kind, as opposed to those who organise them, will usually be such
that they are unlikely to be deterred by the prospect of a custodial sentence if caught. …

22. … the following considerations are relevant as to culpability and harm. There is legitimate public
concern about breaches or attempted breaches of border control, and this type of offence, which is
prevalent, will usually result in significant profit to organised criminals engaged in people smuggling. A key
feature of culpability inherent in the offence, save in very exceptional circumstances, is that the offender
will know that he is trying to arrive in the UK in an unlawful manner: if it were otherwise, he would take the
cheaper and safer alternative route which would be available to him. The harm inherent in this type of
offence is not simply the undermining of border control but also, and importantly, the risk of death or
serious injury to the offender himself and to others involved in the attempted arrival, the risk and cost to
those who intercept or rescue them, and the potential for disruption of legitimate travel in a busy shipping
lane.

23. Those considerations lead to the conclusion that the seriousness of this type of offence is such that
the custody threshold will generally be crossed and that an appropriate sentence, taking into account the
inherent features which we have mentioned but before considering any additional culpability or harm
features, any aggravating and mitigating factors and any credit for a guilty plea, will be of the order of 12
months' imprisonment.

24. Culpability will be increased if the offender plays some part in the provision or operation of the means
by which he seeks to arrive in the United Kingdom, for example by piloting a vessel rather than being a
mere passenger; or if he involves others in the offence, particularly children; or if he is seeking to enter in
order to engage in criminal activity (for example by joining a group engaged in **_modern slavery or_**
trafficking). Culpability will be reduced if the offender genuinely intends to apply for asylum on grounds
which are arguable."

9. Finally, for present purposes, at [25] the court stated:

"25.  Consideration of aggravating and mitigating factors must of course be a case-specific matter, but the
following may commonly arise and will call for either an upwards or downwards adjustment of the
provisional sentence. The offence will be aggravated by relevant previous convictions, by a high level of
planning going beyond that which is inherent in the attempt to arrive in the United Kingdom from another


-----

country, and by a history of unsuccessful applications for leave to enter or remain or for asylum. Even if
the previous attempts did not involve any criminal offence, the history of previous failure makes it more
serious that the offender has now resorted to an attempt to arrive without valid entry clearance."

The court again stressed that the weight to be given to that factor will of course depend on the circumstances of
each case.

10. Finally, we should observe that at [26] and [27] the court noted that the offence will be mitigated by an absence
of recent or relevant convictions, and that there may often be powerful features of personal mitigation, to which
appropriate weight should be given on a fact-specific basis.

11. In the present case the appellant was born on 1 February 1992. He was aged 32 at the date of sentence. He
had four previous convictions for five offences, spanning the period from 28 Jue 2017 to 15 September 2021.
These offences were all committed and dealt with in Belgium. They included production of drugs with intent to
supply, attempted manslaughter, trafficking of a prohibited weapon and two offences of the illegal transportation of
drugs.

12. We note that the sentencing court did not have a pre-sentence report. Nevertheless, we confirm, pursuant to
section 33 of the Sentencing Act 2020 that in our judgment it was unnecessary and is now unnecessary.

13. In his sentencing remarks, after referring to the facts and the decision of this court in Ginar, the Recorder said
that he was satisfied to the required standard that the appellant posed a serious risk to the public safety in the UK.
He summarised the appellant's antecedents in Belgium. He was satisfied that that pattern of aggressive and
sustained offending was such that the appellant presented a serious risk of committing serious criminal offences,
both of drug dealing and violence. Against that background, the Recorder took the view that a custodial sentence
was inevitable and appropriate.

14. The Recorder observed that, although deterrence is rarely a relevant issue, as this court had said in Ginar, an
additional factor in the Recorder's view was the deterrent effect for criminally motivated migrants such as the
appellant, who he was satisfied would be likely to continue a criminal lifestyle within the UK.

15. On behalf of the appellant, Mr Moore-Taylor submits, we think with some force, that there was no evidence
before the sentencing court to substantiate that view.

16. Returning to the sentencing remarks, the Recorder concluded that the starting point for this offence would be
30 months' imprisonment. Giving full credit for the early guilty plea, that reduced the sentence to 20 months'
imprisonment, to which we have already referred.

17. In the written Grounds of Appeal, Mr Moore-Taylor submitted that the Recorder imposed a sentence which was
manifestly excessive, particularly for two reasons: first, that he erred in attaching too much weight to the appellant's
antecedent record in Belgium; and secondly, that he erred in attaching too little weight to the appellant's mitigation.

18. We have been assisted by helpful written and oral submissions by Mr Moore-Taylor on the appellant's behalf.
In his skeleton argument, Mr Moore-Taylor submits that the sentence was manifestly excessive for three essential
reasons, each of which can be taken either individually or cumulatively. He submits: first, that the increase in
culpability envisaged by this court in _Ginar at [23] does not apply to the facts of this case; secondly, that the_
appellant's antecedent record in Belgium did not warrant an uplift to the 12 month starting point envisaged by this
court in Ginar by as much as 18 months. He observes that that is a 250 per cent increase. Thirdly, he submits that
too little weight was afforded to the appellant's mitigation.

19. Mr Moore-Taylor realistically concedes that the offence does – and had to – cross the custody threshold. He
further realistically concedes that the sentence would inevitably have been one of immediate custody.
Nevertheless, in his oral submissions before us he emphasises two points in particular. First, he submits that in so
far as the Recorder appears to have taken into account that the appellant knew that he was entering the UK
illegally, that would have been an error of approach, because this court had already explained in Ginar at [22] that


-----

that aspect of such cases is an inherent feature in the commission of the underlying offence in the first place.
Secondly – and this has received prominence in Mr Moore-Taylor's submissions before us – he submits that at the
end of the day the Recorder erred by simply giving too much weight to the previous convictions which the appellant
had committed in Belgium. That resulted, accordingly, in a sentence which was manifestly excessive.

20. We see force in Mr Moore-Taylor's essential submissions. In our judgment, while an increase from the 12
months recommended in _Ginar was warranted in this case – in particular having regard to the appellant's poor_
criminal record, an increase of the order of 250 per cent was not justified. In our judgment, the appropriate
sentence after trial would have been one of 18 months' imprisonment. In view of the early guilty plea, the appellant
is entitled to full credit of one third. That results in a sentence of 12 months' imprisonment.

21. For the reasons we have given, we quash the sentence of 20 months' imprisonment and substitute one of 12
months' imprisonment. To that extent this appeal is allowed.

____________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground Floor, 46 Chancery Lane, London WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

