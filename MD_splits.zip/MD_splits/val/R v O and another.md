# R v O and another [2019] EWCA Crim 752

Court of Appeal, Criminal Division

Macur LJ, Russell J and Judge Leonard QC (sitting as a judge of the Court of Appeal Criminal Division)

9 May 2019Judgment

**Mr Daniel Bunting (instructed by Philippa Southwell of Birds Solicitors) for the Appellants**

**Mr James Marsland (instructed by The Crown Prosecution Service) for the Crown**

Hearing dates: 28 March 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Macur LJ:**

1. These two cases seek a retrospective review of the respective decisions to prosecute two individuals
who claim to have been the victims of trafficking. In N, the applicant raised the issue at the outset but then
pleaded guilty on 15 February 2015 to cultivation of cannabis, was sentenced and has served his custodial
term. The Registrar has referred his case to the full court. N seeks an extension of time to do so, and
permission to rely on fresh evidence relating to his status as a Victim of Trafficking (VOT). The Respondent
raises no objection to us considering the merits of the case or having regard to the fresh evidence 'de
benne esse'.  In O, the appellant did not raise the issue until serving a custodial sentence of 5 years,
having been convicted by a jury of two offences of controlling prostitution for gain on 31 July 2014. The
single judge has granted an extension of time and leave to her to appeal sentence. The single judge has
referred O's application for an extension and permission to appeal against conviction, which must rely on
fresh evidence relating to her status as a Victim of Trafficking (VOT). Likewise, the Respondent raises no
objection to us considering the merits of the case or having regard to the fresh evidence 'de benne esse'.
N and O await determination of their asylum claims to remain in the UK.

2. The facts of the cases are distinct, but the principles of law to be applied to the respective facts are
identical. Section 45 of the Modern Slavery Act 2015 does not apply. Giving the judgment of the Court in
[R v EK [2018] EWCA Crim 2961 in a similar case to these, Gross LJ referred to the legal framework as](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-V2S2-8T41-D4NJ-00000-00&context=1519360)
“now well-travelled territory” and referred to the summary of the relevant law he provided in R v S(G) [2018]
Crim 1824 at paragraphs 75 and 76; the principles derived from the decisions and guidance of the Court in
R v M(L) and others [2010] EWCA Crim 2327;R v N(A) and others [2012] EWCA Crim 189; R v L(C) and
others [2013] EWCA Crim 991 and R v Joseph (Verna) [2-17] EWCA Crim 36 and others [2017] EWCA .
We do not repeat them here but adopt them, as both Mr Bunting, who appears for the applicants, N and O,
and Mr Marsland, who appears for the respondent in both cases, invite us so to do. Therefore, we have
asked ourselves whether, (i) there is credible evidence that the applicant falls within the definition of
trafficking in the Palermo protocol and the Directive; (ii) there is a nexus between the crime committed and
the trafficking; and (iii) was it in the public interest to prosecute either N or O.

R V N


-----

3. The indictment arose out of N's role as a 'gardener' of cannabis. He pleaded guilty to a single count of
producing a controlled drug of class B. He was sentenced on 19 February 2015 to 16 months
imprisonment.

4.  On 6th November 2014, police officers searched an address in Derby and found a sophisticated
system for the production of cannabis. 464 plants were found in the loft and a number of bedrooms. N was
the sole occupant of the premises. He was arrested.

5. In interview, N claimed to have been born in Vietnam. He had lived in Cambodia from a young age. He
was involved in a fishing accident. He was rescued and taken to France. He had lived in France for a time.
He could not say where. He was kept in a basement. The man who kept him there had his face covered.
He was told to go to England to help someone. He had arrived in the United Kingdom four months before
he was arrested. He travelled lying down in a vehicle. His eyes were covered. He was taken to a house
with only one bed. His journey to the premises involved being taken to a tube station by taxi with his face
covered. He was let out and told to follow someone on the tube. He did so and was collected from a
second tube station by taxi. His face was re-covered. He was taken to the premises from which he had
been arrested. The plants were already there. He did not know what they were. He was told he was
responsible for watering them and keeping them alive. He worked in order to pay off a debt which arose
from his transportation to the UK. If he had left the house or not worked then “they would kill me”

6. The police did not refer N to the National Referral Mechanism ('NRM').

7. N has waived privilege. In an unsigned and undated proof of evidence given to his former solicitors, N
repeated the account he gave in interview. He said he was given instructions on feeding and watering the
plants. He was provided with two mobile phones and told that he could access the internet. He said:

'I didn't have anywhere to go so I stayed where I was. I didn't have any money. I couldn't speak the
_language. I thought I owed a debt to the people who took me from the house in France. I thought I would_
_stay and do the work until I paid off my debt and then I could leave. I didn't know how much my debt was, I_
_was just hoping that after a while they would let me go. I was very grateful for them giving me food and a_
_place to stay'._

8. On 21st November 2014, during a preliminary hearing, the issue of trafficking was raised. The
attendance notes of prosecution counsel states:

_'Defence are claiming that because he claims to be trafficked, we should not proceed in the public interest_
_and just deport him as per our guidance. …_

_POLICE ACTION: can the immigration service confirm his status; whether it is believed he was trafficked;_
_and what will happen to him in terms of deportation._

_…What are the police's views on whether this is a trafficked person who was in effect a slave and should_
_not be prosecuted?_

9. In response to the inquiries of prosecution counsel, a memorandum of 15th December 2014 from an
unnamed police officer states:

'I've completed and submitted paperwork in relation to an Interpol check which has come back stating he is
_not known to the French authorities and that they have no record of him and that his fingerprints are not on_
_their database._

_In my opinion, the defendant was trafficked and was brought over here to carry out the task of 'gardener',_
_however I take issue with the credibility of his account (stating he was locked in and that nobody came to_
_the house whilst he was there) and therefore am of the opinion than he knows more than he is telling us._
_He stated in interview that he is scared of the persons that brought him over here and what they might do_
_to him if he did not water the plants etc, which I am inclined to believe, however he did have two mobile_
_phones in his possession and in my opinion did have the opportunity to leave the address.'_


-----

10. On 5th February 2015 N appeared at court, but the hearing had to be adjourned in the absence of an
interpreter. His advocate recorded that he had spoken to prosecution counsel 'about the trafficking issue. It
_would appear that the investigation is underway. The court was told of the position.'._

11. On 19th February 2015 N appeared at court again. His advocate recorded that 'the 'defendant
_instructed me that he wished to plead guilty'._

12. N signed an endorsement:

'l [N] having been fully advised by my legal representatives wish to plead guilty to the offence of producing
_cannabis. I am aware that I could have a trial and raised the defence of duress. I am aware that I may face_
_a custodial sentence"._

13. The advocate for N in the court below has made a statement at the request of the Registrar. He states:

i) 'My direct recollection of the case is limited';

ii) _'I was aware that the issue of trafficking had been raised by the Crown and that enquiries had been_
_undertaken by the Crown';_

iii) 'My recollection is that the Crown, having been given the opportunity to examine further the question of
_trafficking, made it clear that they were satisfied that the defendant had not been trafficked and would not_
_be further reviewing the case in light of the defendant being trafficked';_

iv) 'Although my note is silent on the point, I must have advised [N] of the Crown's position, as it was of
_direct relevance to the progress of the case and any decisions he wished to make';_

v) 'I having seen my note I am certain I advised him of the evidence against him and, despite the position
_of the Crown, that on the basis of his account it was open to continue to pursue the matter to trial';_

vi) 'I advised [N] that the defence of duress was still open to him on his account, even if the Crown were
_not accepting that he had been trafficked. I would have taken [N's] instructions on how he wished to_
_proceed with the case'; and_

vii) 'I accept the endorsement does not explicitly refer to “trafficking”, but in this case both trafficking, and
_duress were founded on the same account. In drafting the endorsement I must have been sufficiently_
_concerned to ensure that before [N] pleaded guilty he understood and was aware of the implications of the_
_plea, i.e. that he was not seeing to rely on his account of his entry to the UK and the allegations for_
_anything other than mitigation.'_

14. In sentencing N, the Judge referred to a 'note attached to the door – that you were clearly told that you
_should not give any description or names of the individuals who brought you to the address and who must_
_have come regularly to collect cannabis material'._

15. She accepted that N had 'acted under instruction' and had been 'involved under pressure', but that he
had been involved in a 'very sophisticated and commercial grow'. She noted the pressure including N being
_'in some difficulty because you do not speak English, you did not have accommodation and that was_
_provided as part of the employment that you were required to undertake in the United Kingdom'._

16. A decision to deport N was made on 10th March 2015. On 30th April 2015, he was informed that he
had failed to respond to the notification of the decision to deport and a deportation order was made. On
13th May 2015, he made a claim for asylum. On 2nd June 2015 an asylum screening interview was
conducted. On 20th August 2015, the claim was refused and certified as being clearly unfounded.

17. On 7th January 2016, N asserted that he was a victim of trafficking. On 3rd March 2016, he was
referred to the National Referral Mechanism.

18. On 19th May 2016, the Home Office acting as the Competent Authority concluded that there were
reasonable grounds to believe that N had been a victim of human trafficking ('the reasonable grounds
decision'). On 6th October 2016, the Competent Authority concluded that N had been a victim of trafficking
('the conclusive grounds decision').


-----

FRESH EVIDENCE

19. N seeks permission to rely on the fresh evidence in his own witness statements; the decisions of the
Competent Authority; in the Home Office's file in relation to his proposed deportation and subsequent claim
for asylum; and the files of his former solicitors, and CPS in the proceedings below.

20. N provides an account of his decision to enter a plea of guilty:

_'I initially pled not guilty but was then advised by my solicitor to plead guilty, it was when I had a_
_consultation with my solicitor who then told me it would be difficult to argue my case and I would likely be_
_convicted. They told me I would receive a greater sentence if convicted after a trial. He told me he would_
_ask for a lighter sentence for me if I entered a guilty plea'._

21. He does not say that he received any advice regarding the issue of trafficking, nor any discussion of
potential referral to the NRM during the criminal proceedings.

22. The Home Office file shows that on 2nd June 2015, N had an Asylum Interview. His claim for asylum
was refused.

23. The Competent Authority's conclusive grounds decision:

(1) Cites several international reports on the prevalence of human trafficking in Cambodia and Vietnam;

(2) Records a number of issues giving rise to concern as to the Applicant's credibility, but concludes that
they 'relate more to the details of his asylum claim rather than the incidents that surround the trafficking
_elements of his claim', and that the credibility issues do not 'detract' from the 'core elements of the_
_trafficking claim';_

(3) Finds a 'general level of consistency' in the Applicant's account of his trafficking, considering the
accounts recorded in his interview with police upon his arrest, in the judge's sentencing remarks, to a
probation officer as recorded in an Pre - Sentence report, and in the submissions made to the Competent
Authority;

(4) Concludes that on the balance of probabilities, the Applicant was 'transported to the United Kingdom
_from France', was 'transported by means of threat or use of force or other form of coercion and of a_
_position of vulnerability', and was 'made to work in the cultivation of cannabis'; and_

(5) Concludes that 'in the absence of any evidence which undermines [N's] _account, it is accepted_
_conclusively that he was trafficked to and within the UK'._

**GROUNDS OF APPEAL**

24. Mr Bunting relies on the written advice and grounds of appeal. If only the case had carried on the
correct course, it was extremely unlikely that N would have been prosecuted. The Competent Authority
rightly accept that N was a victim of trafficking. Whilst the Home Secretary had previously made an
adverse finding of credibility against N, the NRM were aware of and acknowledging the same,
subsequently carried out “a careful analysis” of his account and articulated the reasons why it should be
accepted with reference to all the documentary evidence.

25. The role of trafficked victims as 'gardeners' is well known. The offending commenced immediately after
the applicant was brought to the United Kingdom and N maintained that the offending was forced to pay off
monies owed to the traffickers and therefore shows the relevant nexus of offending to trafficked status.

26. N had been compelled to act as he had; albeit that the circumstances fell short of duress. There was
supporting evidence of this, as referred to by the Judge in her sentencing remarks. His possession of
mobile telephones and access to Wi-Fi did not contradict this. He was not free to come and go as he
pleased. He spoke no English, had no social or family network in the UK and feared violence.

27.  It had not been in the public interest to prosecute N. Whilst the offence to which he pleaded guilty was
a serious one, in the circumstances described above, it was not so serious as to require a prosecution
regardless of his status as a VOT. Had the information available now have been considered and the


-----

prosecution continued, there would have been an argument to stay the proceedings. The conviction is
unsafe.

**RESPONDENT'S SUBMISSIONS**

28. The Respondent's Notice filed strenuously opposed the merits of the substantive application for
permission to appeal. Whilst accepting that N should ideally have been referred to the NRM, it was said he
should not be permitted to now seek to rely on his alleged status of a victim of trafficking. N had pleaded
guilty. The analysis of the Competent Authority was flawed. The international reports of Vietnamese VOT's
employment as 'gardeners' was of little weight in circumstances where N does not assert that he was
trafficked from Cambodia or Vietnam, but rather reached France having been rescued by a French vessel,
following an accident on a boat.

29. If the Court accepts that N was trafficked in the circumstances he asserts, and the Competent
Authority accepted, a nexus between the trafficking and the offending will have been established, albeit not
such as to effectively extinguish N's culpability. N's culpability remains significant. The evidence of
compulsion is limited. The premises were unlocked. N had access to electronic devices. The evidence
does not demonstrate that 'no realistic alternative was available but to comply with the dominant force of
_another'. The decision to prosecute N was in accordance with CPS policy and the Applicant's conviction is_
safe.

30. However, Mr Marsland's oral submissions departed markedly from the Respondent's Notice. He
accepted that the Conclusive Grounds Consideration Minute was a reasoned decision; N's version of
events was consistent from the outset and there was no contrary indication. He does not “press the point”
of the guilty plea. Mr Marsland conceded that “if the Prosecution had been in possession of all the material
now to hand, … the decision would be made that [N] was the victim of trafficking”

31. On the other hand, he resisted the application and asserted that the crux of the matter was the lack of
nexus of the offending to the trafficking and the degree of compulsion under which N acted.  N had a
realistic alternative to the offending. He was in unlocked premises and was not constantly supervised. He
had means of communication with the outside world. He had a positive experience of French arresting
authorities. He had not been trafficked from his home country and would be returned to France; his
traffickers were said to have been Vietnamese and therefore posed no threat.

32. Subject to this Court's determination on nexus, he did not assert that this was a case in which public
interest demanded prosecution.

Decision:

33. We have no hesitation in finding that N was a VOT and are particularly struck by the candid
assessment of the police officer in December 2014. (See paragraph 9 above.) We have no doubt that this
would have to have been disclosed in any contested hearing. It coincides with the final assessment of the
NRM in October 2016. There is no basis upon which to question the NRM finding. N has been consistent in
his accounts of restriction of his autonomy, and there is objective corroboration for the material aspects of
his account in this respect. We think Mr Marsland makes a realistic concession on this point.

34. We also find there to have been nexus and compulsion associated with the trafficking. Mr Marsland's
arguments require us to ignore the undoubted fact of N's isolation by virtue of his inability to communicate
in English and his geographical ignorance. We accept the force of the rhetorical question put by Mr
Bunting: 'Communicate with whom? The French authorities?' N's account indicated he was in fear of
immediate reprisals from his traffickers.

35. In all the circumstances we agree that public interest did not require prosecution. The conviction is
unsafe. We extend time, find that it would be unjust not to allow the applicant to rely on the fresh evidence,
grant permission to appeal, and allow the appeal. The conviction will be quashed. The findings that we
make regarding his status as a VOT and his extant asylum appeal justify his anonymity. We order
accordingly.

R V O


-----

36. The indictment arose out of O 's dealings with two women to whom we will refer as P and A. Count 1
alleged that she had trafficked P within the United Kingdom for sexual exploitation. She was acquitted by
the jury of that count. Counts 2 and 3 alleged that she had controlled each woman for gain as a prostitute.
She was convicted of these two counts.

37. A had arrived at London City Airport on 21 July 2012. She was travelling under a false name. She
had papers purporting to show that she was 16 years old and was travelling with a man who claimed to be
her father. Having heard the evidence, the trial judge concluded for the purposes of sentencing that,
although her precise age was not known, she was beyond doubt under 18.

38. P arrived at Heathrow on 2 December 2012 claiming to be 27 years old. In evidence, she gave her
date of birth as 30 May 1997 so that she would have been 16 on arrival. The clear implication from the
jury's verdict on count 1 was that they were not sure that she was under 18. The judge in sentencing said
that he did not believe that she was 27 but was not convinced that she was not an adult.

39. Each woman told a similar story. A said that she had been approached by O's mother in Nigeria. That
woman suggested that she travel to the UK where she would be looked after by O and placed in education.
She was taken to O's house. She started working as a prostitute that day. Thereafter for 18 months she
worked as a prostitute at two different addresses often for seven days a week. She gave half her earnings
to O or to a man she believed to be O's husband. Some of her money was sent back to her mother in
Nigeria.

40. P also said that she had been approached in Nigeria by O's mother, for whom she had worked, with a
similar story namely that she would be looked after by O and placed in education. She took an oath not to
speak to the police or cause any trouble. She travelled to the UK with false documents. O met her with
another woman, who was a co-accused who had absconded before trial and was tried in her absence.
They took her to a house. There she was told that she owed £42,000 to the traffickers and needed to work
as a prostitute to pay it off. She was a virgin.

41. Thereafter for the next 12 months she worked regularly as a prostitute at different addresses giving the
money she earned to O or to O's husband. P was allowed small sums for herself. She serviced up to 8 or
10 men a day.  She became pregnant on two occasions. On each, O booked appointments for her to
have those pregnancies terminated at hospital.

42. The judge in passing sentence summarised the way in which the women had been treated by O and
her co-accused. They were put to work in a most brutal way. They were in the main confined to the
Woolwich area with very little freedom of movement. They were coerced to participate in unsafe sexual
activity and coerced into seeing many customers. They lived in fear of exposure and being sent back to
Nigeria and were too afraid to go to the police.

43. Although O did not give evidence at trial, a positive case was put to the women. It was suggested that
O had had nothing to do with arranging for them to come to the UK nor with meeting them at the airport.
She had met P by chance in the street and because she was homeless O had allowed her to stay with her.
A later moved in as well. They were already working as prostitutes. All three women continued as
prostitutes sharing the rent but O had no part in the work of P or A and received none of their money. It
was suggested that they were free agents.

44. Matters came to light after P had approached a man in Woolwich in about December 2013 saying that
she was hungry. He gave her some money. She asked for his telephone number which he gave her.
Thereafter there was an exchange of messages during which she disclosed some details of her plight. He
went to the police station to report his concerns. That night, the police raided address where P and A were
living and O's house and she was arrested.

45. She was interviewed on several occasions. She declined to answer questions but submitted two
prepared statements. In them she detailed what she said were her dealings with the two women and the
difficulties she said she had had with P's boyfriend. She said nothing about her own arrival in the UK nor
how she had become involved in prostitution.


-----

46. The nature of her grounds of appeal was such that O was required to waive privilege in respect of her
instructions at trial. Counsel for the defence at trial has set out the instructions she gave in writing and in
conference. She said that in 2007 a man called Idris had arranged for her to come from Nigeria to London
to work in child care. She paid him £45,000 and took an oath that she would repay him. She said that
after about a year, she saw an advertisement in Loot seeking 'working girls. She decided to work as a
prostitute which she did thereafter at a number of different brothels.

47. O unsuccessfully applied for a residence card as the spouse of an EEA national on three occasions in
November 2012, May 2013 and December 2013. Prior to trial, on 20 January 2014 she was served with
illegal entry papers. She was convicted and sentenced in July 2014 and on 12 August applied for a
Facilitated Returns Scheme which was denied because of the length of her sentence. In January 2015, she
was served with a notice of decision to deport. She signed a disclaimer stating she wished to leave the UK
without making representations. In April 2015 O made an asylum claim.

48. On 19 October 2015, O was referred to the National Referral Mechanism by the Poppy Project. On 1
November 2016 her application for asylum was rejected.

49. On 28 October 2015, the Home Office acting as the Competent Authority concluded that there were
reasonable grounds to believe that the Applicant had been a victim of human trafficking ('the reasonable
grounds decision'). On 17th December 2015, the Competent Authority concluded that the Applicant had
been a victim of trafficking ('the conclusive grounds decision').

FRESH EVIDENCE

50. O seeks permission to rely on the fresh evidence in her own witness statements; the NRM referral
form; and the decisions of the Competent Authority.

51. In interview with the Poppy Project in HMP Holloway, she confirmed her account that Idris had
arranged her trip to London for £45,000 and described not merely an oath to repay the money but an
elaborate and blood-curdling juju ceremony with threats of death if she broke the oath. She gave a
detailed account of how she became involved in prostitution. Before she left Nigeria, she was given the
name of Victor as the person who would meet her in England. He was not there at the airport to meet her.
She said that she had met a man named by Jackson by chance shortly afterwards. She had nowhere to
live so went to live with him in Woolwich and then Plaistow.

52. After about six months, Victor contacted her. He and another woman introduced her to prostitution.
She gave half her money to him to pay off her debt. He was violent to her on occasions. She later formed
a relationship with and married a Slovakian national who was one of her clients. They never lived together,
and she continued to work as a prostitute. After she had paid off half her debt, she rented the flat where P
and A met her. In 2013, she learned that Victor had been deported so she could thereafter keep her
money. In a subsequent statement she said she had paid over £12,000 to another prostitute's boyfriend in
order to enrol on a nursing course.

53. She described meeting the two women but again denied that she had controlled either of them for
gain.

54. As part of her application for asylum, O made a detailed witness statement dated 19 May 2016 which
followed and expanded on her statement to the Poppy Project. It included the sentence ''I remember
providing a witness statement that discussed everything that had happened to me, including being a victim
of trafficking.” As Counsel for the Appellant below pointed out in his note, that was untrue. She also said
that she had sent money to Victor in Nigeria on two occasions after his deportation. She found out in April
2015 that he had attacked her mother in Nigeria and threatened her son.

55. The Competent Authority's conclusive grounds decision lacks the detailed analysis seen in N's case
above and makes no reference to the facts of the criminal proceedings as may be derived from the Court
transcripts of summing up and sentencing remarks. It refers to the information provided on the NRM
referral form completed on O's behalf by the Poppy Foundation, which comprised details of assertions of
expressions of fear and anxiety, signs of psychological trauma, injuries, fact of typical trafficking offence,


-----

perception, threats against family, intimidation and signs of ritual abuse and witchcraft; cites an
international report on the prevalence of human trafficking in Nigeria and finds, “In the absence of any
evidence which undermines [O's] account” that she was trafficked to and within the UK.

**GROUNDS OF APPEAL**

56. Mr Bunting relies on the written advice and grounds of appeal. The NRM had confirmed that the
applicant was a victim of trafficking. There appears to be a nexus between the offending and trafficking;
there is inevitably a “grey line” between a VOT who had removed themselves from trafficking and become
a perpetrator. O's case was “intertwined with the question of compulsion”. Whilst he accepts there were
indicators that she had an element of free will, and she was not incarcerated, it was not enough to say that
throughout the indictment period she was not acting under compulsion. She had little choice because of
her personal circumstances, and she feared the juju oath. Threats had been made against her family
abroad and the phenomenon of 'debt bondage' is well known.

57. If the full circumstances had been known, the prosecution would not have been
commenced/continued, The conviction is unsafe. However, if he failed in that argument, the facts would
have significantly mitigated the serious offences for which she had been convicted and a reduced sentence
would have been imposed.

58. He recognises that this case is not as clear cut as that of N and the more serious the offence, the
greater the degree of compulsion required to breach any apparent 'nexus'. He prays in aid the fact that
Victor was still able to exert influence, even when abroad. O was 'unsophisticated', in fear of reprisals and
black magic. If trafficking had been raised by O, even if the CPS had proceeded, the jury would have been
able to consider the nexus and therefore the conviction was unsafe.

59. If this Court refuses permission to appeal against conviction, it should nevertheless consider O's own
position as a VOT to reduce her culpability and to substantially mitigate the sentence that would otherwise
be appropriate.

**RESPONDENT'S SUBMISSIONS**

60. Mr Marsland relies on the Respondent's Notice filed. The Respondent's Notice  “acknowledges” the
decision of the competent authority and that a VOT may make staged disclosures in which
inconsistencies between accounts can arise, but notes in particular the similarity of O's account to that of
one of the complainants in the trial and that the evidence at trial, which the jury must have accepted to
significant degree, contradicts O's present account of her circumstances. O's account is inconsistent to the
instructions she gave to her legal team and in her applications for a residence card.

61. If the Court accepts that O was trafficked, there is no nexus between the trafficking and the offending
of which she has been convicted. O continues to maintain, as she did at trial, that P and A were working
independently as prostitutes. There is no evidence that she was compelled 'by the dominant force of
another' to control the prostitution of P and A for gain.

62.  Even if the Court were to find a nexus, the decision to prosecute O was in accordance with public
policy and the conviction is safe. That is, the offences were serious and aggravated by features of O's
knowledge of the trafficking of P and A, O's coercion of P and A to enter into prostitution, debt bondage,
threats, P's abortions and the age of A.

Decision:

63. Whilst we have some misgivings regarding O's status as a VOT, for the reasons indicated in the
Respondent's Notice, we give her the benefit of the doubt on this issue. However, this status does not
establish nexus or compulsion at the relevant time. If O was a VOT on arrival in the UK, we have no doubt
that she was complicit in trafficking P and A thereafter, and not by reason of coercion. Even on her own
eventual account, there was a significant time interval between her own arrival, and significant
geographical distance of her alleged 'operator', at the relevant time of these offences. She had


-----

demonstrated free will in the operation of her 'business' as sex worker, an ability to accumulate money and,
she said, produce a simple accounting system for the earnings of other prostitutes.

64. In any event, we agree that public interest did require prosecution. The trial Judge would rightly have
dismissed any abuse of process argument suggesting otherwise and, since these offences preceded its
enactment, the jury would not have been able to consider the defence afforded by section 45 of the
**_Modern Slavery Act 2015. The conviction is safe. We refuse permission to appeal conviction._**

65. We consider the trial Judge's assessment of the culpability withstands the finding that O was a VOT.
That is, these were aggravated offences. There was no nexus between her status as VOT and offending
as charged. There was no flaw in the sentencing exercise conducted by the Judge. The sentence was not
manifestly excessive. We dismiss the appeal against sentence.

66. O's application for asylum is outstanding. Since, albeit with some hesitation, we confirm her status as a
VOT, this will justify an order for her continued anonymity in any report of this case, at least until after her
asylum claim is determined. We order accordingly.

**End of Document**


-----

