# R v Nguyen [2023] EWCA Crim 1376

Court of Appeal, Criminal Division

Macur LJ, Choudhury and Constable JJ

9 June 2023Judgment

DR F GERRY KC appeared on behalf of the Applicant.

**J U D G M E N T**

(APPROVED)

1. MR JUSTICE CHOUDHURY: This is a renewed application for leave to appeal against conviction following
refusal by the single judge. On 10 November 2017, in the Crown Court at Woolwich before Mr Recorder Bryan, the
applicant (then aged 27) pleaded guilty to two counts, production of a Class B drug and possession with intent to
supply Class B drug, the drug in question being cannabis. On 6 April 2018, before the same court, the applicant
was sentenced to 18 months' imprisonment concurrent on each count. The applicant also seeks an order for
anonymity, an extension of time of 1621 days and leave to adduce evidence relating to his status as a victim of
trafficking.

2. The background to this matter is as follows. On 14 September 2017, police executed a search warrant issued
[under the Misuse of Drugs Act 1971 at an address in SE12 London. Having forced entry to the house, they found](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)
that three of the rooms were filled with cannabis plants at various stages of cultivation. There were large
hydroponic systems in each of the rooms, and a CCTV system, which appeared to be controlled from inside the
property. In total there were 294 cannabis plants in the property, with a potential yield of 12 kilograms and four
bags of approximately 4 kilograms of skunk cannabis ready packaged for onward supply. The applicant and

another person, Huy Manh Nguyen (the co‑accused), were sleeping in a room located off the hallway. They were

both arrested. They were both in possession of mobile phones. The police were able to interrogate one of the
phones in the applicant's possession and it showed significant use of calls and messages sent and received. On
further investigation the police discovered that the property had been rented from the landlord using a false Chinese
passport and residence permit in the name “Huy Chen”.

3. The applicant was interviewed with the assistance of an interpreter. He gave a full account stating that he had
paid to come to the United Kingdom with the promise of work 2 years earlier. However, 2 months before his arrest,
he had been taken to this property and forced to look after the plants. He said that he was unable to leave the
property as he did not have a key, and he was scared of the person that he thought owned the property, a man
called "Dat", because that man had previously attacked him, injuring his eye. The applicant was given the phones
by this person so that he could contact him, and he had also been able to speak to his family. In light of the
applicant's account, the day after his arrest the police made a referral through the National Referral Mechanism to
the Single Competent Authority. On 16 September 2017 the applicant appeared at Bromley Magistrates' Court, on
which occasion he was represented by counsel, Mr Walker. An attendance note of the same date, produced for
these proceedings in accordance with the McCook procedure, indicates that the applicant had "instructed that he
had been threatened and physically attacked by individuals who forced him to work in the property". The
attendance goes on to state that on the basis of those instructions the applicant was raising the defence of duress.
The applicant indicated a not guilty plea


-----

4. On 21 September 2017, the Single Competent Authority concluded that there were reasonable grounds to
believe that the applicant was a victim of modern slavery. Upon review the Crown decided that the prosecution of
the applicant remained in the public interest. On 13 October 2017, the applicant appeared at Woolwich Crown
Court for a plea and trial preparation hearing. On that occasion he was represented by Mr Dacre of counsel. Mr
Dacre's attendance note records that the applicant gave instructions consistent with his police interview, namely
that he had been forced, under threat of violence, to work at the cannabis factory. The applicant indicated that he
wished to plead not guilty.

5. Mr Dacre notes that the issues for trial were summarised on the online PTPH form as follows:

i. "Forced to undertake work ‑ defence under section 45 of the Modern Slavery Act and duress. No intention to

supply."

6. Whilst Mr Dacre's note does not record the advice given in respect of these defences, he confirms that it was his
usual practice to provide such advice and that he would not have identified the defence he did, had he not advised
the applicant about its availability during his conference. Mr Dacre's note also records a conversation with
prosecution counsel. He said that inquiries were going to be made by the Crown as to whether the applicant's
claims in interview about being trafficked could be substantiated. On that basis Mr Dacre applied for the
arraignment to be adjourned, to allow for those inquiries to be made. The judge on that occasion agreed and the
arraignment was adjourned to a further hearing on 10 November 2017. The judge also agreed that credit available
at the PTPH stage should be preserved until that later hearing.

7. Mr Dacre was not available for the hearing on 10 November. The applicant was therefore represented by
another colleague, Mr Renteurs. Mr Renteurs did not make a note of the conference with the applicant, but a note
was made by the applicant's solicitor, Mr Snodgrass, of a firm then known as "Murry Partnership Solicitors". That
note refers to advice having been given in relation to the defence of duress, although it makes no express mention
of the defence available under section 45 of the **_Modern Slavery Act 2015. Mr Renteurs considers it to be_**
extremely unlikely that he would not have discussed the section 45 defence as well as the defence of duress. He
notes that he is fortified in his view by the fact that the issues identified at the previous hearing expressly referred to
that defence. He also notes that the very reason for adjourning the PTPH on the previous occasion was in order for
the Crown to review its position, in light of the positive reasonable ground's decision issued by the Home Office in
respect of the human trafficking claims made by the applicant. In those circumstances, Mr Renteurs considers it
extremely unlikely that he would not have discussed and advised the applicant in relation to the section 45 defence.
He also points out that, in his experience, duress and the section 45 defence tend to be discussed "in very much
the same breath as there is in practice considerable overlap between applicability of those defences given the
requirement for compulsion and of no realistic alternative." Mr Snodgrass's attendance note further records that,
having had the defence explained to him, the applicant said that he wished to plead guilty as he "desperately wants
to get shorter sentence as possible as he wants to see his family. He understands he could fight the case via
duress but does not want to risk longer sentence." Following that conference at court, the applicant was arraigned
and entered guilty pleas to both of the counts that he faced on the indictment. Sentencing was adjourned.

8. In a letter sent to the applicant following the hearing Mr Snodgrass stated that a long conference had taken
place at court and that:

i. **"You explained that you had been forced to stay at the address and tend to the plants as payment to**
**people smugglers. They have made veiled threats to you and your family. Mr Renteurs went on to explain**
**the defence of duress. You stated however that you did not want to pursue the matter to trial and that you**
**wanted to plead guilty. You explained that you basically just wanted to get the shortest sentence as**
**possible so that you can see your family."**

9. The applicant received a negative Conclusive Grounds Decision on 27 February 2018. That decision noted that
there was a "vast array of inconsistencies" in the applicant's account, and that it was not accepted that he was a
victim of modern slavery.


-----

10. The applicant's co‑accused had given a "no comment" interview and pleaded not guilty. He claimed to be a

victim of trafficking and modern slavery but was convicted of both offences by a jury in March 2018.

11. Both the applicant and co‑accused were sentenced on 6 April 2018. The applicant was represented at the

sentencing hearing by Ms Stephenson of counsel. She does not recall any information being provided to her that
caused her any concern that the defences have not been properly considered. Upon meeting the applicant on 6
April, he did not raise any desire to vacate his guilty pleas. Ms Stephenson took instructions on his personal
circumstances and matters to be raised in mitigation. Her attendance note records that she "advised whilst I could
not put forward defences of duress and trafficking in mitigation, I could argue that the conditions in which he was
working placed him in a lesser role." In so doing, Ms Stephenson confirms that she was not seeking to advise the
applicant on the availability of those defences given that he had already pleaded guilty. Ms Stephenson went on to
advise the applicant that she would tell the court about the difficult circumstances that he was living and working in
but did not intend to make submissions amounting to advancing the defence of duress or a defence under section
45 because that would be inconsistent with his earlier guilty pleas. Ms Stephenson records that no issue was
raised by the applicant and there was no indication from him that he did not understand what he was being told or
that he wanted to vacate his pleas. In other words, there was no indication that the applicant had changed his
mind. As far as Ms Stephenson was concerned, her instructions were that the applicant had accepted his guilt, that
he wished to maximise credit for his guilty pleas and did not wish to rely on any defence but put forward mitigation
which amounted to a defence.

12. We have considered the transcript of the sentencing hearing before Mr Recorder Bryan on that occasion. The
contents of that are consistent with Ms Stephenson's account. The judge expressly stated, and Ms Stephenson
confirmed, the plea of guilty excluded duress and trafficking. However, Ms Stephenson did rely upon the
circumstances, quite properly, as amounting to a form of exploitation which lessened his role in the offence.

13. On 15 June 2018, having served the custodial period of his sentence of imprisonment, the applicant was
detained under immigration powers. On 2 July 2018, the applicant claimed asylum. His claim was refused. He

then appealed to the First‑tier Tribunal. The final outcome of the immigration proceedings and his current

immigration status remain unclear on the papers.

14. Following judicial review proceedings, the Single Competent Authority reconsidered the applicant's status as a
victim of trafficking and modern slavery. On 7 February 2022 the applicant received a positive conclusive grounds
decision. The Single Competent Authority noted that the applicant said in his recorded interview that he had not
sold or been involved in cultivating cannabis. He had also noted that he had however pleaded guilty to two counts
of production of cannabis and possession with intent to supply. The decision goes on to deal with this
inconsistency as follows:

i. **"It is noted that you addressed this inconsistency in your witness statement, in which you stated that**
**your criminal solicitors advised you to plead guilty to decrease your sentence. You added that you did not**
**realise that you could raise trafficking and** **_modern slavery as a defence. It is considered that you have_**
**offered inadequate explanation as to the reason for your delay in disclosure as such for this**
**inconsistency".**

15. The Single Competent Authority further concluded that the cumulative medical evidence adduced in support of
the applicant's case mitigates the inconsistencies in his account and that: "looking at the evidence in the round, it is
considered your account has met the required threshold namely, 'on the balance of probabilities' it is more likely
than not to have occurred."

16. This positive conclusive grounds decision is relied upon as fresh evidence in support of the applicant's appeal.
The applicant also seeks to rely upon a number of witness statements prepared for the purposes of immigration
proceedings. In the first of those statements, he claims he was advised to plead guilty to decrease the sentence
and that the solicitors never spoke to him about trafficking or modern slavery and so he did not realise he could
raise it as a defence in his case.


-----

17. In a statement prepared for the purposes of this application, he states:

i. "I cannot recall what advice I was given regarding entering a guilty plea, it has been a significant period of time
that has passed, and I also suffer from mental health problems and I am still on medication which includes

Fluoxetine and Quetipine. I am also on medication for my eye post‑acid attack which includes Doxycycline and

Maxidex. I have been on this medication for two years."

18. This fresh evidence and the fresh expert evidence referred to below has been considered by this Court de bene
_esse for the purposes of this application without making any final decision as to its admissibility under section 23 of_
the Criminal Appeal Act 1968.

**_Grounds of Appeal_**

19. The applicant is represented before us by Dr Gerry KC. She relies upon three grounds of appeal. These are
that the convictions are unsafe because the applicant's guilty plea was entered despite a positive reasonable
ground decision of trafficked status. Had his true status been known, either the Crown's evidential test for
prosecution would not have been met or he would have been acquitted at trial. Secondly, the positive conclusive
grounds assessment renders it reasonable to conclude that the applicant was compelled to commit the crimes to
which he pleaded guilty and, had this been known, he would not have been prosecuted and/or his guilty plea would
not have been entered. Thirdly, his criminality is so significantly diminished, this Court should quash his conviction
following the decision in R v AAD & Ors [2022] 1 Cr App R(S), that to maintain the conviction would be an abuse of
process.

20. Dr Gerry seeks to rely on fresh expert evidence including two independent trafficking expert reports and
medical evidence that he was a victim of human trafficking at the time, that his offending was a direct consequence
of his trafficked status and that he has suffered significantly as a result of his experiences. As we have said, we
have considered those reports.

21. Dr Gerry submits that the applicant does not recall being advised in 2017 that he could really raise duress or
human trafficking as defences. She submits that this is understandable given the level of trauma he suffered and
the risk that he and his family were under at the time. These matters should, she submits, have led to the obtaining
of expert evidence of the type that has now been obtained. She further submits that had he been advised to pursue
the conclusive grounds assessment he could have had his evidence heard. As such his guilty plea was premature
and apparently put forward without full and clear advice on available challenges and where relevant expert
evidence was not obtained.

22. Dr Gerry acknowledges that some consideration was given to the issues of duress and modern slavery but
maintains, in her written submissions, that there remains an issue as to the extent and effect of such advice. It is
suggested in her written submissions that the advice did not appear to have been complete. Although she does
rein back from that somewhat in her oral submissions, she acknowledges that there were plainly differences as to
the advice and it is not possible to challenge the McCook responses.

23. Similar grounds to those summarised were relied upon before the single judge, who concluded as follows:

i. "I have considered the papers in your case and your grounds of appeal.

ii. The applicant pleaded guilty to cultivation of cannabis. He was represented by solicitors and counsel. To have
an arguable appeal against conviction he must bring himself within one of the three categories of case identified at

[155] to [157] of AAD and others. The grounds of appeal assert that his plea was equivocal. In strict terms that is
not correct. The applicant's real submission is that he was not properly advised about a defence which probably
would have succeeded and/or that there was a legal obstacle to him being tried in that the prosecution would have
been stayed as an abuse of process had the full position been known.

iii. The applicant made a statement in 2019 in which he said that his solicitors advised him to plead guilty to
decrease his sentence. He also said that his solicitors never spoke to him about trafficking or modern slavery so


-----

he did not realise that he could raise it as a defence. In a statement made in 2022 the applicant said that he did not
recall at any stage being advised on a Section 45 defence or an [National Referral Mechanism] referral. If there
were any prospect of those propositions being established, it would be necessary to consider whether it is arguable
that a defence based on trafficking probably would have succeeded. In fact, the contemporaneous documentary
evidence supported by the recollection of solicitors and counsel contradicts what the applicant has said.

iv. Even at the magistrates' court there was discussion about the possibility of a defence based on duress or on
trafficked status. This appears from the solicitors' attendance note. At the PTPH the applicant was not arraigned
because the prosecution wished to consider their position in relation to the applicant's status. There had already
been a reasonable grounds decision from the Single Competent Authority in the applicant's favour. Counsel noted
on the PTPH form that the issues in the case were defence under S.45 of the **_Modern Slavery Act and duress._**
Counsel's clear recollection is that there was discussion with the applicant in relation to those issues. The
contemporaneous material is clear and unequivocal.

v. The adjourned case management hearing took place about 6 weeks later. There is some disparity between the
recollection of the solicitor who attended and instructed counsel. The solicitor's attendance note refers to advice in
relation to the defence of duress. Counsel considers that this must be taken as shorthand for duress plus trafficking
given the overlap between the two and given the reason why arraignment had been postponed. In any event, there
is agreement that the impetus for the plea came from the applicant. He did not wish to run any available defence.
Rather, he wished to plead guilty in order to reduce his sentence. The judge at the PTPH had indicated that
whatever credit was available at that point would be preserved until the adjourned hearing so there was a real
benefit to be obtained from a plea at the adjourned hearing.

vi. By the time of sentence the issue of plea was no longer immediately relevant. However, counsel who appeared
for the applicant explained to him that, whilst the defences of trafficking and duress no longer were in issue, she
could use the matters relevant to the potential defences in mitigation. This is recorded in a contemporaneous
attendance note. There was an exchange with the sentencing judge which confirms the accuracy of the note.

vii. Given all those matters, the proposition that the applicant was not advised about his defence is untenable. It
also is not sensibly arguable that the applicant was advised to plead guilty to reduce his sentence. All of the
contemporaneous material supports the proposition that it was his decision to take that course in order to obtain the
benefit of a plea of guilty.

viii. This is not a case in which the position was not appreciated by the prosecution. They considered the issue of
whether the applicant was trafficked and how this might affect the proceedings. It is not arguable that there was or

is any obstacle to the applicant being tried. It is to be noted that he had a co‑accused who pleaded not guilty and

who was convicted. The co‑accused's personal position was similar to that of the applicant.

ix. In those circumstances, the proposed appeal is not arguable. It falls at the first hurdle with the applicant's plea
of guilty."

24. We agree entirely with the analysis of the single judge. Our reading of the contemporaneous notes of the
various conferences with the applicant leading up to his guilty pleas and of the exchanges thereafter at the
sentencing hearing as set out above is entirely consistent with that of the single judge.

25. Dr Gerry's suggestion, in her written submissions, that the advice given to the applicant by his legal advisors
was somehow incomplete is wholly untenable. The applicant was given clear advice as to the availability of the
defences but decided, of his own volition, to enter guilty pleas in order to minimise his sentence and the time away
from his family.

26. It is notable that the positive conclusive grounds decision, which has provided much of the impetus for this
application, is based in part on an acceptance of the applicant's assertions in statements that he had not been
advised about the defences or that he had not realised he could raise such defences. For reasons already set out,
those assertions appear to us to be unsustainable.


-----

27. Dr Gerry's further submission is that even if there is a decision to plead guilty, by which we understand her to
mean a plea which cannot be set aside for any of the available grounds summarised at paragraphs 155 to 157 of
AAD & Ors, the United Kingdom's international obligations in respect of the protection of victims of trafficking means

that the review process of the Appeal Court is engaged but the non‑punishment principle applies and that the

applicant should not have a criminal record or suffer the consequences of such a criminal record. She submits that
it is either: (a) not necessary in circumstances where a victim of trafficking is involved for the vitiation of plea to fall
within one of the broad categories identified in AAD & Ors; or (b) that there is a further category that protection
remains necessary notwithstanding the advice and plea because "justice must be seen to be done". Furthermore, it
is suggested that protection for victims of trafficking is an exception to the general principle of finality. In oral
submissions this morning Dr Gerry elaborated on that and suggested that, given the applicant is worthy of
protection by reason of his trafficked status, a different approach ought to be taken by the court to the guilty pleas in
question.

28. In our judgment, none of these points is remotely arguable. Dr Gerry did not specify originally the international
obligations upon which she relies. She has taken the opportunity to identify those obligations before the Court this
morning. However, the Court of Appeal's decision in AAD & Ors was plainly reached with those obligations in the
context of trafficking in mind. Thus, in relation to the question of whether the definition of "compulsion" in section 45
of the 2015 Act is too narrow, the Court there held:

"153. Given the clear terms of section 45 which aptly reflect the United Kingdom's international obligations in this
context (as summarised above), there is no sustainable foundation for the submission that this legislative provision
should be reformulated in the manner suggested, substituting the 'compulsion' element of the defence with that of
'causation'. That would involve the wholesale rewriting of a statutory defence without any, or any material,
justification. At least since the Council of Europe Convention came into force domestically on 1 April 2009, the
United Kingdom has subscribed to and implemented a binding international approach, now reflected in section 45,
which provides a defence to certain crimes for trafficked individuals if the prosecution is unable to make the court
sure the 'compulsion' defence does not apply."

29. The Court went on in the very next section of its judgment (at paragraphs 155 to 157) to consider whether a
victim of trafficking could seek to argue that a conviction following a guilty plea is unsafe. There can therefore be no
credible suggestion that in so doing the Court of Appeal did not have in mind those international obligations which it
had just considered. Thus, the circumstances in which a guilty plea may be set aside by a victim of trafficking are
those contained in the three broad categories set out at paragraphs 155 to 157 of the decision in AAD & Ors. The
Court of Appeal did not see fit on that occasion to add any further category that would, if Dr Gerry were correct,
enable victims of trafficking to set aside their plea irrespective of the circumstances. We see no arguable
justification for such an expansion which would be an affront to the principle of finality. Accordingly, leave to appeal
is refused. In the circumstances, any extension of time would be futile and is also refused.

30. We deal finally with anonymity as is said to be required for the protection of the applicant's safety. We bear in
mind the importance of the principle of open justice. Although there is an extant positive conclusive grounds
decision, there are reservations, as we have set out above, as to some of the evidence on which that decision is
based. We have no information before us as to whether anonymity has been granted or continued in other
proceedings. The principle of open justice requires that the identity of those who commit crimes be published
unless it is strictly necessary and proportionate not to do so. The applicant was here properly convicted of serious
offences having pleaded guilty. In the circumstances, we are satisfied that anonymity is not strictly necessary, and
the principle of open justice prevails. This case should therefore be listed under the applicant's name and previous
reporting restrictions, if there are any, should be revoked.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400


-----

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

