# Assange v Government of the United States of America and another [2024]
 EWHC 700 (Admin)

King's Bench Division, Administrative Court (London)

President Of The King'S Bench Division and Mr Justice Johnson

26 March 2024Judgment

Edward Fitzgerald KC, Mark Summers KC and Florence Iveson (instructed by Birnberg Peirce) for the Applicant

Clair Dobbin KC and Joel Smith (instructed by Crown Prosecution Service) for the First Respondent

Ben Watson KC (instructed by the Government Legal Department) for the Second Respondent

Hearing dates: 20 and 21 February 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down by release to The National Archives on 26 March 2024 at 10.30am.

**Dame Victoria Sharp P.:**

1. This is the judgment of the court.

_Introduction_

2. The applicant is Julian Assange. The Government of the United States of America (who we will refer to
as the respondent), seeks his extradition to the United States on the ground that he unlawfully solicited an
intelligence analyst in the United States army, Chelsea Manning, and others, to disclose to him vast
amounts of United States intelligence, and that he then unlawfully published the names of human
intelligence sources, placing at grave and imminent risk the lives of many innocent individuals. The
respondent's request is based on an indictment (the second superseding indictment) issued by a federal
grand jury in 2020, charging the applicant with 18 offences.

3. Leave to appeal having been refused on the papers by Swift J in June 2023, the applicant renews his
application for leave to appeal: first under section 103 of the Extradition Act 2003 (the 2003 Act) against
the decision of Senior District Judge Goldspring to send his case to the Secretary of State (but in
substance the appeal is against an earlier decision of District Judge Baraitser (the judge)); and secondly,
under section 108 of the 2003 Act against the extradition order made by the Secretary of State.

4. The hearing before us attracted an exceptional level of national and international interest. It was held in
public, and arrangements were made to provide links to the hundreds of those within the jurisdiction who
had asked for them, so they could view and listen to the hearings as they took place. The applicant, who is
currently in custody in HMP Belmarsh, asked us for permission to attend the hearing. We granted
permission, but we were told by his representatives that unfortunately he has a persistent cough which
would have made attendance at the hearing difficult, whether in person or by video link, which was the
other option made available to him.


-----

5. We were provided with an enormous amount of material prior to the hearing (in excess of 8,000 pages)
and some further material after the hearing had ended. The documents provided after the hearing included,
at our request, the written closing submissions of the respondent and applicant before the judge which
enabled us to see how the case had been put to her.

6. We are grateful to the legal teams for the work that went into the preparation of the renewed application
and to counsel for the submissions made during the course of the hearing.

7. In his reasons for refusing leave, Swift J had commented adversely on the prolixity and unfocussed
nature of the applicant's perfected grounds of appeal. He therefore directed that in the event of a renewal,
the applicant's grounds of renewal should not exceed 20 pages. The applicant was subsequently granted
permission to file a 10-page Renewal Skeleton. The application however remains extremely wide ranging
and raises a large number of discrete issues, hence the length of this judgment. The Renewal Skeleton as
served has focussed on three issues only which the applicant wishes to further develop. These arise under
the first two grounds identified at para 9 below. It includes some new grounds of appeal on which we heard
oral argument from both sides, without objection by the respondent. Shortly after the hearing, the applicant
applied to amend his grounds of appeal, as we had invited him to do during the course of the hearing. We
grant that application and address the issues raised in the order in which they were advanced in oral
argument.

8. In bare outline, the issues raised before us are as follows.

9. First, the applicant submits pursuant to section 103 of the 2003 Act that the decision to send the case to
the Secretary of State was wrong (and arguably wrong for the purposes of this leave application) for the
following reasons:

i) The UK-US Extradition treaty (the Treaty) prohibits extradition for a political offence (and the offences
with which the applicant is charged fall within that category).

ii) The extradition request was made for the purpose of prosecuting the applicant on account of his political
opinions (contrary to section 81(a) of the 2003 Act).

iii) Extradition is incompatible with article 7 of the European Convention on Human Rights (the
Convention) (which provides there should be no punishment without law).

iv) Extradition is incompatible with article 10 of the Convention (freedom of expression).

v) If extradited, the applicant might be prejudiced at his trial by reason of his nationality (contrary to section
81(b) of the 2003 Act).

vi) Extradition is incompatible with article 6 of the Convention (right to a fair trial).

vii) Extradition is incompatible with articles 2 and 3 of the Convention (right to life, and prohibition of
inhuman and degrading treatment).

10. Secondly, the applicant submits that the Secretary of State's decision to extradite him was wrong (and
arguably wrong for the purposes of this application) because (continuing the numbering sequentially):

viii) Extradition is barred by the Treaty; and

ix) Extradition is barred by inadequate specialty/death penalty protection.

11. For the reasons set out below, we have concluded that:

i) The applicant has established an arguable case that the decision to send the case to the Secretary of
State was wrong because:

a) if extradited, the applicant might be prejudiced at his trial by reason of his nationality (contrary to section
81(b) of the 2003 Act), and

b) as a consequence of a), but only as a consequence of a), extradition is incompatible with article 10 of
the Convention.


-----

ii) The applicant has established an arguable case that the Secretary of State's decision was wrong
because extradition is barred by inadequate specialty/death penalty protection.

iii) The applicant has not established an arguable case in respect of the remaining grounds of appeal.

12. Accordingly, subject to the question of whether the concerns we identify in this judgment can be
addressed by way of assurances from the respondents, we will grant the applicant leave to appeal under
both section 103 of the 2003 Act (in respect of grounds iv) and v)) and section 108 of the 2003 Act (in
respect of ground ix).

13. For the reasons explained below, before making a final decision on the application for leave to appeal,
we will give the respondent an opportunity to give assurances. If assurances are not given then we will
grant leave to appeal without a further hearing. If assurances are given then we will give the parties an
opportunity to make further submissions before we make a final decision on the application for leave to
appeal.

_Extradition generally_

14. Extradition is as form of international cooperation in criminal matters, based on comity intended to
promote justice. It takes place when a person (the Requested Person) who is accused or convicted of a
criminal offence is returned to the state seeking the Requested Person's extradition (the Issuing or
Requesting State) to be tried, sentenced or to serve a term of imprisonment. Extradition proceedings are
not concerned with establishing innocence or guilt. That is a matter for trial in the Requesting State.

15. The underlying rationale of extradition needs to be understood; it was accurately encapsulated by the
House of Lords Select Committee on Extradition Law (2[nd] Report of Session 2014-5, published in March
2015) which was appointed to consider and report on the law and practice relating to extradition, in
particular, the 2003 Act. In short, because of its cooperative and bilateral nature, it is inherent in extradition
proceedings that each country accepts to a certain degree the criminal justice systems of other countries.
Each country has different views of different crimes and how they should be punished. However, this
acceptance is not absolute. For example, extradition from the United Kingdom must be compliant with the
Convention. Extradition is also a two-way process; to refuse extradition to a country may lead to that
country not honouring an extradition request from the United Kingdom. Maintaining good extradition
relationships and the honouring of international obligations in this regard ensures that countries do not
become safe havens from justice.

16. Since 1870, extradition from the United Kingdom has been regulated by primary legislation passed by
Parliament.

[The Extradition Act 2003](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)

17. The legislation which now mandates the circumstances in which extradition must or must not be
ordered is the 2003 Act [1]. The 2003 Act has been subject to significant legislative amendment and
parliamentary scrutiny by Select Committees of both Houses since its enactment [2].

18. If a bar to extradition prescribed by the 2003 Act applies, such as that extradition would be contrary to
[Convention rights under the Human Rights Act 1998,then extradition must be refused. If none of the bars](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
set out in the 2003 Act apply, then extradition must be ordered. Neither the court, nor the Secretary of
State, has any discretion. The court does not have a general discretion to decide whether the applicant
should or should not be extradited.

19. The approach to be taken by an appeal court is also closely regulated by the 2003 Act. The appeal
court has no power to decide for itself whether extradition should be ordered. Instead, it is required to
review the decisions of the judge and the Secretary of State and decide if those decisions have been
shown to be wrong. In deciding whether to grant leave to appeal, we have to decide if there is a real
prospect that the appeal court would conclude that the judge's decision, or the Secretary of State's
decision, was wrong.


-----

[20. The United States is a category 2 territory for the purposes of part 2 of the 2003 Act: Extradition Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)
_[2003 (Designation of Part 2 Territories) Order 2003. Part 2 of the 2003 Act makes provision for the making](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)_
of extradition requests by category 2 territories (section 69). Once such a request is made, the Secretary of
State must decide whether to certify the request under section 70, which states:

“Extradition request and certificate

(1) The Secretary of State must (subject to subsection (2)) issue a certificate under this section if he
receives a valid request for the extradition of a person to a category 2 territory.

(2) The Secretary of State may refuse to issue a certificate under this section if—

(a) he has power under section 126 to order that proceedings on the request be deferred,

(b) the person whose extradition is requested has been recorded by the Secretary of State as a refugee
within the meaning of the Refugee Convention, or

(c) the person whose extradition is requested has been granted leave to enter or remain in the United
Kingdom on the ground that it would be a breach of Article 2 or 3 of the Human Rights Convention to
remove him to the territory to which extradition is requested.

(3) A request for a person's extradition is valid if—

(a) it contains the statement referred to in subsection (4)…, and

(b) it is made in the approved way.

(4) The statement is one that
(a) the person is accused in the category 2 territory of the commission of an offence specified in the
request, and

(b) the request is made with a view to his arrest and extradition to the category 2 territory for the purpose
of being prosecuted for the offence.

…

(7) A request for extradition to any other category 2 territory is made in the approved way if it is made—

(a) by an authority of the territory which the Secretary of State believes has the function of making
requests for extradition in that territory, or

(b) by a person recognised by the Secretary of State as a diplomatic or consular representative of the
territory.

(8) A certificate under this section must

(a) certify that the request is made in the approved way, and

(b) identify the order by which the territory in question is designated as a category 2 territory.

(9) If a certificate is issued under this section the Secretary of State must send the request and the
certificate to the appropriate judge.

(10) Subsection (11) applies at all times after the Secretary of State issues a certificate under this section.

(11) The Secretary of State is not to consider whether the extradition would be compatible with the
[Convention rights within the meaning of the Human Rights Act 1998.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

21. The 2003 Act makes provision for the issuing of an arrest warrant for the requested person (sections
71 and 72). Once the requested person is arrested, he must be brought before the appropriate judge as
soon as practicable (section 72(3)).

22. The judge must then decide whether the documents sent by the Secretary of State include those
required by section 78(2). If so, the judge must proceed under section 79: section 78(7).


-----

23. Section 79 states:

“79 Bars to extradition

(1) If the judge is required to proceed under this section he must decide whether the person's extradition to
the category 2 territory is barred by reason of
…

(b) extraneous considerations;

(c) the passage of time;

…

…

(2) Sections 80 to 83E apply for the interpretation of subsection (1).

(3) If the judge decides any of the questions in subsection (1) in the affirmative he must order the person's
discharge.

(4) If the judge decides those questions in the negative and the person is accused of the commission of
the extradition offence but is not alleged to be unlawfully at large after conviction of it, the judge must
proceed under section 84.

…”

24. Sections 81, 82 and 87 make provision in respect of extraneous considerations, the passage of time,
and human rights respectively. The effect of these provisions is that unless the judge is _required by the_
2003 Act to order the requested person's discharge, the judge must send the case to the Secretary of State
for a decision as to whether the person is to be extradited.

25. Section 81 states:

“Extraneous considerations

A person's extradition to a category 2 territory is barred by reason of extraneous considerations if (and only
if) it appears that—

(a) the request for his extradition (though purporting to be made on account of the extradition offence) is in
fact made for the purpose of prosecuting or punishing him on account of his… political opinions, or

(b) if extradited he might be prejudiced at his trial… by reason of his race, religion, nationality, gender,
sexual orientation or political opinions.”

26. Section 87 states:

“Human rights

(1) If the judge is required to proceed under this section (by virtue of section 84…) he must decide whether
[the person's extradition would be compatible with the Convention rights within the meaning of the Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[Rights Act 1998 (c. 42).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_

(2) If the judge decides the question in subsection (1) in the negative he must order the person's
discharge.

(3) If the judge decides that question in the affirmative he must send the case to the Secretary of State for
his decision whether the person is to be extradited.”

27. Section 103 gives a right of appeal against a decision to send a case to the Secretary of State.

28. On appeal, the role of the appellate court is prescribed by section 104. Section 104(3) permits an
appeal to be allowed only if the district judge ought to have decided a question before her differently with
_the result that the applicant would have had to be discharged. Section 104 provides as follows:_


-----

“104 Court's powers on appeal under section 103

(1) On an appeal under section 103 the High Court may
(a) allow the appeal;

(b) direct the judge to decide again a question (or questions) which he decided at the extradition hearing;

(c) dismiss the appeal.

(2) The court may allow the appeal only if the conditions in subsection (3) or the conditions in subsection
(4) are satisfied.

(3) The conditions are that
(a) the judge ought to have decided a question before him at the extradition hearing differently;

(b) if he had decided the question in the way he ought to have done, he would have been required to order
the person's discharge.

(4) The conditions are that
(a) an issue is raised that was not raised at the extradition hearing or evidence is available that was not
available at the extradition hearing;

(b) the issue or evidence would have resulted in the judge deciding a question before him at the
extradition hearing differently;

(c) if he had decided the question in that way, he would have been required to order the person's
discharge.

(5) If the court allows the appeal it must
(a) order the person's discharge;

(b) quash the order for his extradition.

…”

29. The role of the appellate court as prescribed by section 104(3) was explained in Love v United States
_of America_ _[2018] EWHC 172 (Admin); [2018] 1 WLR 2889per Lord Burnett CJ at paras 25 to 26:_

“25. The statutory appeal power in section 104(3) permits an appeal to be allowed only if the district judge
ought to have decided a question before him differently and if, had he decided it as he ought to have done,
he would have had to discharge the applicant. The words “ought to have decided a question differently”
(our italics) give a clear indication of the degree of error which has to be shown. The appeal must focus on
error: what the judge ought to have decided differently, so as to mean that the appeal should be allowed.
Extradition appeals are not re-hearings of evidence or mere repeats of submissions as to how factors
should be weighed; courts normally have to respect the findings of fact made by the district judge,
especially if he has heard oral evidence. The true focus is not on establishing a judicial review type of error,
as a key to opening up a decision so that the appellate court can undertake the whole evaluation afresh.
This can lead to a misplaced focus on omissions from judgments or on points not expressly dealt with in
order to invite the court to start afresh, an approach which risks detracting from the proper appellate
function. …

26. The true approach is more simply expressed by requiring the appellate court to decide whether the
decision of the district judge was wrong. …The appellate court is entitled to stand back and say that a
question ought to have been decided differently because the overall evaluation was wrong: crucial factors
should have been weighed so significantly differently as to make the decision wrong, such that the appeal
in consequence should be allowed.”

30. The focus is thus on the first instance judge's judgment, rather than the appellate court's own
evaluation of the statutory test (but for the approach where a Convention right is in issue, see para 121
below)


-----

31. Section 93 states:

“Secretary of State's consideration of case

(1) This section applies if the appropriate judge sends a case to the Secretary of State under this Part for
his decision whether a person is to be extradited.

(2) The Secretary of State must decide whether he is prohibited from ordering the person's extradition
under any of these sections—

(a) section 94 (death penalty);

(b) section 95 (speciality);

…

(3) If the Secretary of State decides any of the questions in subsection (2) in the affirmative he must order
the person's discharge.

(4) If the Secretary of State decides those questions in the negative he must order the person to be
extradited to the territory to which his extradition is requested…”

32. Section 108 gives a right of appeal against an extradition order made by the Secretary of State.

33. On appeal, the role of the appellate court is prescribed by section 109:

“Court's powers on appeal under section 108

(1) On an appeal under section 108 the High Court may—

(a) allow the appeal;

(b) dismiss the appeal.

(2) The court may allow the appeal only if the conditions in subsection (3) or the conditions in subsection
(4) are satisfied.

(3) The conditions are that—

(a) the Secretary of State ought to have decided a question before him differently;

(b) if he had decided the question in the way he ought to have done, he would not have ordered the
person's extradition.

(4) The conditions are that—

(a) an issue is raised that was not raised when the case was being considered by the Secretary of State or
information is available that was not available at that time;

(b) the issue or information would have resulted in the Secretary of State deciding a question before him
differently;

(c) if he had decided the question in that way, he would not have ordered the person's extradition.

(5) If the court allows the appeal it must—

(a) order the person's discharge;

(b) quash the order for his extradition.”

The Swedish European Arrest Warrant

34. In order to understand some of the background, it is necessary to refer briefly to an earlier request for
the applicant's extradition, made by the Swedish judicial authorities. On 2 December 2010, a European
Arrest Warrant was issued by a Swedish judicial authority, alleging the commission by the applicant of
offences of unlawful coercion, rape and molestation. On 7 December 2010, the applicant was arrested


-----

pursuant to the warrant. On 24 February 2011, an order was made for the applicant's extradition to
Sweden. He was released on bail.

35. On 30 May 2012, the Supreme Court dismissed the applicant's appeal against the extradition order:
_Assange v The Swedish Prosecution Authority [2012] UKSC 22; [2012] 2 AC 471. On 19 June 2012, the_
applicant entered the Embassy of Ecuador in London. He failed to surrender to the court as required by the
terms of his bail. A warrant for his arrest was issued. He remained in the Ecuadorian Embassy for the next
seven years.

36. On 12 August 2015, three of the allegations in Sweden (but not the allegation of rape) became time
barred. On 19 May 2017, the Swedish prosecutor announced that she was discontinuing the prosecution of
the applicant.

The United States extradition request

37. On 21 December 2017, a federal magistrate judge in the Commonwealth of Virginia issued a criminal
complaint against the applicant, charging him with conspiracy to commit an offence of computer intrusion.
On the same day, the applicant was granted diplomatic status by the Ecuadorian government. On 6 March
2018, a federal grand jury returned an indictment against the applicant for that offence.

38. On 23 May 2019, a federal grand jury returned a superseding indictment containing 18 counts alleging
further offences related to the obtaining, receiving and disclosure of “National Defense Information.” On the
same day, a warrant was issued by the United States District Court for the Eastern District of Virginia for
the arrest of the applicant. On 6 June 2019, the respondent submitted via diplomatic channels a request for
the applicant's extradition based on the charges in the superseding indictment.

39. On 24 June 2020, a federal grand jury in Alexandria, Virginia returned the second superseding
indictment charging the applicant with 18 offences.

40. Title 18 of the United States Code concerns “Crimes and Criminal Procedure”. The charges against
the applicant are (with the exception of count 2) brought under 18 USC paragraph 793. Paragraph 793
concerns “gathering, transmitting or losing defense information.” The relevant parts of paragraph 793 state:

“(b) Whoever, for the purpose [of obtaining information respecting the national defense with intent or
reason to believe that the information is to be used to the injury of the United States, or to the advantage of
any foreign nation], copies, takes, makes, or obtains, or attempts to copy, take, make, or obtain, any…
document… connected with the national defense; or

(c) Whoever, for the purpose aforesaid, receives or obtains or agrees or attempts to receive or obtain from
any person, or from any source whatever, any document… of anything connected with the national
defense, knowing or having reason to believe, at the time he receives or obtains, or agrees or attempts to
receive or obtain it, that it has been or will be obtained, taken, made, or disposed of by any person contrary
to the provisions of this chapter; or

(d) Whoever, lawfully having possession of, access to, control over, or being entrusted with any
document… relating to the national defense, or information relating to the national defense which
information the possessor has reason to believe could be used to the injury of the United States or to the
advantage of any foreign nation, willfully communicates, delivers, transmits or causes to be communicated,
delivered, or transmitted or attempts to communicate, deliver, transmit or cause to be communicated,
delivered or transmitted the same to any person not entitled to receive it, or willfully retains the same and
fails to deliver it on demand to the officer or employee of the United States entitled to receive it; or

(e) Whoever having unauthorized possession of, access to, or control over any document… relating to the
national defense, or information relating to the national defense which information the possessor has
reason to believe could be used to the injury of the United States or to the advantage of any foreign nation,
willfully communicates, delivers, transmits or causes to be communicated, delivered, or transmitted, or
attempts to communicate, deliver, transmit or cause to be communicated, delivered, or transmitted the
same to any person not entitled to receive it, or willfully retains the same and fails to deliver it to the officer
l f th U it d St t titl d t i it


-----

…

Shall be fined under this title or imprisoned not more than ten years, or both.

(g) If two or more persons conspire to violate any of the foregoing provisions of this section, and one or
more of such persons do any act to effect the object of the conspiracy, each of the parties to such
conspiracy shall be subject to the punishment provided for the offense which is the object of such
conspiracy.”

41. The offences charged on the second superseding indictment, with the allegations made in each case,
are:

42. The maximum penalty for each offence is 10 years' imprisonment, save that the maximum penalty in
respect of count 2 is 5 years' imprisonment. The offences can be conveniently grouped into three
categories. In the first category are counts 1, 3-14 and 18. These concern the applicant's alleged complicity
in Ms Manning's unlawful conduct in _obtaining_ the material. In the second category is count 2, which
concerns conspiring with hackers to commit computer intrusions to benefit WikiLeaks. In the third category
are counts 15, 16 and 17. These publication counts i.e. counts alleging that the applicant distributed and
published the material on the internet, are expressly limited to documents which contained the names of
_human sources who have risked their safety by providing information to the United States and its allies._

43. Gordon D Kromberg is an Assistant US Attorney in the Eastern District of Virginia. His responsibilities
include the prosecution of persons charged with offences relating to computer intrusion and the
mishandling of national security information. He has provided five declarations (sworn statements) in
support of the extradition request. The applicant did not challenge his bona fides before us, or before the
judge.

44. Mr Kromberg explains that he operates according to published “Principles of Federal Prosecution”
which are akin to the Code for Crown Prosecutors. The Principles of Federal Prosecution require that
prosecutorial decisions are made rationally and objectively on the merits of each case, and that federal
prosecutors may not take account of a person's “political association activities or beliefs”. He says that the
second superseding indictment reflects those principles and does not reflect any political bias or
motivation. The charges are “based on the evidence and the rule of law, not [the applicant's] political
opinions.”

45. Mr Kromberg says that each of the charges that relates to the publishing of information are explicitly
_limited to the distribution of “documents classified up to the SECRET level containing the names of_
individuals in Afghanistan, Iraq, and elsewhere around the world, who risked their safety and freedom by
providing information to the United States and our allies to the public.” This is clear from the wording of
charges 15, 16 and 17. A deliberate decision was made not to charge the applicant in respect of any other
publications made by the applicant. So, the charges _do not cover the publication of material which the_
applicant says exposes the respondent's involvement in war crimes and other misconduct.

**Offence** **Allegation**

1 Conspiracy to Obtain, Receive, and Disclose Between 2009 and 2015 the applicant conspired to obtain documents
National Defense Information, contrary to Title relating to national defence and to communicate, to those who were
18, USC section 793(g) not entitled to receive them, the names of those who had risked their

safety and freedom by providing information to the US and its allies.

2 Conspiracy to Commit Computer Intrusion Between 2009 and 2015 the applicant conspired to access a computer
contrary to Title 18 USC section 371 without authorisation in order to obtain classified information, believing

that the information would be used to the injury of the US or to the
advantage of a foreign nation; intentionally accessed a protected
computer without authorisation in order to obtain information;
knowingly caused the transmission of information causing damage
and specified loss to the computer; and intentionally accessed a
protected computer causing the same specified loss.

3 Unauthorised Obtaining of National Defense Between November 2009 and May 2010 the applicant knowingly and

|Col1|Offence|Allegation|
|---|---|---|
|1|Conspiracy to Obtain, Receive, and Disclose National Defense Information, contrary to Title 18, USC section 793(g)|Between 2009 and 2015 the applicant conspired to obtain documents relating to national defence and to communicate, to those who were not entitled to receive them, the names of those who had risked their safety and freedom by providing information to the US and its allies.|
|2|Conspiracy to Commit Computer Intrusion contrary to Title 18 USC section 371|Between 2009 and 2015 the applicant conspired to access a computer without authorisation in order to obtain classified information, believing that the information would be used to the injury of the US or to the advantage of a foreign nation; intentionally accessed a protected computer without authorisation in order to obtain information; knowingly caused the transmission of information causing damage and specified loss to the computer; and intentionally accessed a protected computer causing the same specified loss.|


-----

|Col1|Information contrary to Title 18, USC section 793(b)|unlawfully obtained, aided, abetted, counselled, induced, procured and wilfully caused Ms Manning to receive and obtain secret diplomatic cables, having reason to believe that the information would be used to damage the interests of the US or used to the advantage of a foreign nation.|
|---|---|---|
|4|Unauthorised Obtaining of National Defense Information contrary to Title 18, USC section 793(b)|Between November 2009 and May 2010 the applicant knowingly and unlawfully obtained, aided, abetted, counselled, induced, procured and wilfully caused Ms Manning to receive and obtain secret Iraq rules of engagement files, having reason to believe that the information would be used to damage the interests of the US or used to the advantage of a foreign nation.|
|5|Attempted Unauthorised Obtaining of National Defense Information contrary to Title 18, USC section 793(c)|Between November 2009 and May 2010, the applicant knowingly and unlawfully attempted to receive and obtain secret information relating to national defence, knowing and having reason to believe that they had been unlawfully obtained.|
|6|Unauthorised Obtaining of National Defense Information contrary to Title 18, USC section 793(c)|Between November 2009 and May 2010, the applicant knowingly and unlawfully received and obtained detainee assessment briefs, which were documents connected with the national defence and classified as secret, knowing and having reason to believe that they had been unlawfully obtained.|
|7|Unauthorised Obtaining of National Defense Information contrary to Title 18, USC section 793(c)|Between November 2009 and May 2010, the applicant knowingly and unlawfully received and obtained diplomatic cables, which were documents connected with the national defence and classified as secret, knowing and having reason to believe that they had been unlawfully obtained.|
|8|Unauthorised Obtaining of National Defense Information contrary to Title 18, USC section 793(c)|Between November 2009 and May 2010, the applicant knowingly and unlawfully received and obtained Iraq rules of engagement, which were documents connected with the national defence and classified as secret, knowing and having reason to believe that they had been unlawfully obtained.|
|9|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(d)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to transmit to him secret detainee assessment briefs to which she had lawful access.|
|1 0|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(d)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to transmit to him secret diplomatic cables to which she had lawful access.|
|1 1|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(d)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to transmit to him secret Iraq rules of engagement files to which she had lawful access.|
|1 2|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(e)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to transmit to him secret detainee assessment briefs to which she had unauthorised access.|
|1 3|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(e)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to transmit to him secret diplomatic cables to which she had unauthorised access.|
|1 4|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(e)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to transmit to him secret Iraq rules of engagement files to which she had unauthorised access.|


1
5


Unauthorised Disclosure of National Defense
Information contrary to Title 18, USC section
793(e)


Between July 2010 and April 2019, the applicant, having unauthorised
possession of, access to and control over documents relating to
national defence (significant activity reports from the Afghanistan war),
and containing the names of individuals who risked their safety by
providing information to the US and its allies, communicated these
documents to persons not authorised to receive them, by distributing


-----

|Col1|Col2|and then publishing them and causing them to be published on the internet.|
|---|---|---|
|1 6|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(e)|Between July 2010 and April 2019, the applicant, having unauthorised possession of, access to and control over documents relating to national defence (significant activity reports from the Iraq war), and containing the names of individuals who risked their safety by providing information to the US and its allies, communicated these documents to persons not authorised to receive them, by distributing and then publishing them and causing them to be published on the internet.|
|1 7|Unauthorised Disclosure of National Defense Information contrary to Title 18, USC section 793(e)|Between July 2010 and April 2019, the applicant, having unauthorised possession of, access to and control over documents relating to national defence (diplomatic cables), and containing the names of individuals who risked their safety by providing information to the US and its allies, communicated these documents to persons not authorised to receive them, by distributing and then publishing them and causing them to be published on the internet.|
|1 8|Unauthorised Obtaining of National Defense Information contrary to Title 18, USC section 793(e)|Between November 2009 and May 2010, the applicant aided, abetted, counseled, induced, procured and wilfully caused Ms Manning to obtain detainee assessment briefs, having reason to believe the information would be used to damage the interests of the US or used to the advantage of a foreign nation.|


The Extradition Proceedings

46. On 29 July 2020, the Secretary of State issued a certificate under section 70(8) of the 2003 Act
certifying that the request for extradition was valid. The applicant was then arrested on this request.

47. The hearing of the extradition request occupied 4 days in February, from 24 to 27 February, and a
further three weeks from 7 September 2020 to 1 October 2020. Oral evidence was given on all issues. On
4 January 2021, the judge handed down her judgment. It was 132 pages long. There was an additional
appendix of 79 pages, containing the judge's summary of the extensive witness evidence she had heard.
The judge concluded that the extradition of the applicant would be oppressive, particularly having regard to
the possibility that he might be subject to “special administrative measures” by the respondent. She
therefore discharged him. Apart from the question of oppression, the judge rejected each of the applicant's
other objections to extradition.

48. The respondent then appealed under section 105 of the 2003 Act [4]. Whether the applicant would
himself appeal (under section 103 of the 2003 Act) depended on the outcome of the respondent's appeal:
[see Government of the United States of America v Assange [2021] EWHC 2528 (Admin), Holroyde LJ and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63RB-3D73-CGX8-04P9-00000-00&context=1519360)
Farbey J, at para 31.

49. After the hearing before the judge and before the section 105 appeal by the respondent took place, the
respondent provided assurances [5] as to how the applicant would be treated. These included an assurance
that he would not be subject to special administrative measures and that if he were convicted, the
respondent would consent to an application that he serves his sentence in Australia. The Divisional Court
(Lord Burnett CJ and Holroyde LJ) allowed the respondent's appeal in the light of those assurances: see
_Government of the United States of America v Assange [2021] EWHC 3313 (Admin); [2022] 4 WLR 11._

50. The Divisional Court remitted the case to the Westminster Magistrates' Court with a direction to send
the case to the Secretary of State. In accordance with the court's direction, the Senior Magistrate sent the
applicant's case to the Secretary of State for a decision as to whether he should be extradited. On 17 June
2022, the Secretary of State ordered the applicant's extradition to the United States.

51. On 30 June 2022, the applicant filed a notice of appeal under both section 103 and section 108 of the
2003 Act, followed by perfected grounds and an application to submit further evidence. The Secretary of
State and the respondent filed respondent's notices on 28 and 31 October 2022, opposing the applications


-----

for leave and permission to adduce further evidence; and on 1 December 2022, the applicant served a
reply. Permission to adduce further evidence, and leave to appeal, were refused on the papers by Swift J
on 6 June 2023.

52. It is against this background that the applicant now renews his application for leave to appeal.

The alleged conduct

53. In 2006, the applicant founded WikiLeaks. It is described as “…a multi-jurisdictional organization to
protect internal dissidents, whistle-blowers, journalists and bloggers who face legal or other threats related
to publishing.” The respondent alleges that WikiLeaks solicited material by publishing a list of information it
wished to obtain; and that this included military and intelligence documents, photos showing the abuse of
detainees that had been “withheld by the Obama administration” and “Guantanamo Bay operating and
interrogation Standard Operating Procedures”.

54. In 2009, Chelsea Manning (then known as Bradley Manning) was an intelligence analyst in the United
States Army. She was deployed to Iraq. She held a “Top Secret” security clearance. She had signed a
classified information non-disclosure agreement. It is alleged that Ms Manning responded to the WikiLeaks
solicitation by using a United States classified information-network search engine. The search terms she
used indicated that she was looking for material relating to the interrogation and/or abuse of Iraqi detainees
by United States forces, and Guantanamo Bay detainee operations, interrogations, and standard operating
procedures. For example, she ran the search terms “retention+of+interrogation+videos” and
“detainee+abuse” through a classified search engine. She also searched for Guantanamo Bay detainee
operations, interrogations, and standard operating procedures. She uploaded files to a Secure File
Transfer Protocol (SFTP) connection to a cloud drop box operated by WikiLeaks and into a specific
directory which had been created for her by the applicant. She used the SFTP connection to upload
250,000 diplomatic cables to the cloud drop box.

55. On 22 March 2010, Ms Manning downloaded the Iraq rules of engagement files, and between 28
March and 9 April 2010 she downloaded the diplomatic cables, all of which were consistent with materials
WikiLeaks sought.

56. Between November 2009 and May 2010, Ms Manning was in direct contact with the applicant using a
chatlog. They discussed measures to prevent the discovery of Ms Manning as the applicant's source, such
as clearing logs, the use of a “cryptophone”, and a code phrase to use if something went wrong.

57. On 8 March 2010, it is alleged that the applicant agreed to assist Ms Manning to crack a password
hash stored on a Department of Defense computer. He indicated that he was “good” at “hash-cracking”
and that he had tools that could be used to crack password hashes. Ms Manning provided the applicant
with an alphanumeric string which was identical to an encrypted password hash stored on the registry file
of a secure computer that was used by Ms Manning. The applicant later told her that he had no luck yet
and asked for more “hints.” It is alleged that had they succeeded in cracking the encrypted password hash,
Ms Manning might have been able to log on to computers connected to a classified network under a
username that did not belong to her, making it more difficult for investigators to identify her as the source of
the disclosures. It is specifically alleged that the applicant entered into this agreement to assist Ms
Manning's ongoing efforts to steal classified material.

58. In March 2010, the applicant encouraged Ms Manning to obtain detainee assessment briefs. He told
her that they wanted “to mine entirely” the Open Source Center of the Central Intelligence Agency (CIA).
When Ms Manning indicated that she did not have any more material to provide, the applicant replied,
“curious eyes never run dry in my experience”.

59. It is alleged that between January and May 2010, Ms Manning downloaded more than 700,000
documents. Many of the documents were classified as “secret”. That is the security classification that
applies where it is said that unauthorised disclosure could reasonably be expected to cause serious
damage to United States national security. Ms Manning provided the documents that she had downloaded
to the applicant and WikiLeaks.


-----

60. During 2010 and 2011 WikiLeaks published the materials which had been obtained from Ms Manning.
These included files relating to Iraq rules of engagement, diplomatic cables, and Afghan and Iraq
significant activity reports.

61. The respondent says that this caused damage in that:

i) Disclosure of the Iraq rules of engagement files allowed enemy forces in Iraq to anticipate actions or
responses by US armed forces and to carry out more effective attacks.

ii) Disclosure of the diplomatic cables included the names of covert human sources whose safety was
thereby put at risk.

iii) Disclosure of Afghanistan and Iraq significant activity reports included the names of local Afghans and
Iraqis who had provided information to the United States and coalition forces, thereby putting their safety at
risk.

iv) Hundreds of people were identified by United States forces as being “at risk”: some were relocated;
some “disappeared” (although the respondent cannot prove that their disappearance was the result of
being outed by WikiLeaks) and some have been arrested or investigated by the countries in which they
live.

v) Correspondence found in 2011 at the compound of Osama Bin Laden in Pakistan indicated that he had
obtained the Afghanistan significant activity reports and diplomatic cables from the WikiLeaks website.

vi) On 30 July 2010, the New York Times published an article which stated that a member of the Taliban
claimed to be studying the report with a view to punishing those who were “really spies working for the US”.

62. As explained above, although the respondent says that many of the publications made by WikiLeaks
have caused damage, the second superseding indictment is limited to the publication of material that
included the names of human sources.

63. The extradition request states that the applicant knew of the dangers. He was warned of the risks in
advance of publication. He is recorded as having acknowledged that people might be harmed, that it was
regrettable that sources might face some threat, but that he was not obliged to protect them. On 27
November 2010, shortly before he published the diplomatic cables, he was informed by the United States
State Department's legal adviser that their publication would “place at risk the lives of countless innocent
individuals - from journalists to human rights activists and bloggers to soldiers to individuals providing
information to further peace and security”.

The applicant's case as to the underlying conduct

64. For the purposes of this leave to appeal application, the applicant does not dispute the respondent's
case that he conspired with Ms Manning to secure a large volume of protected intelligence documentation
which he then published. His contention is that this was done in the course of an entirely legitimate
journalistic endeavour, it exposed serious wrongdoing by the respondent, it was justified in the public
interest, nobody has come to any harm as a result, and it is conduct that is protected by article 10 of the
Convention and the First Amendment to the United States Constitution.

65. The applicant has provided extensive evidence in support of this case. All of it was before the judge
(except where stated otherwise). This includes evidence, not contested by the respondent, that his
disclosures exposed criminality on the part of the respondent “on a massive and unprecedented scale.”
The criminality includes evidence of illegal rendition, torture, black site CIA prisons across Europe, extrajudicial assassinations in Afghanistan and Pakistan, subversion of prosecutions of United States personnel,
drone strikes in Yemen (which had been denied by the respondent) and the United Kingdom training death
squads in Bangladesh. One video showed the killing of 11 unarmed civilians by a United States helicopter
in Baghdad whilst the pilots “exchanged banter.”

66. The applicant says that these disclosures resulted in the investigation and prosecution of state
criminality and contributed to the saving of countless lives. The disclosures brought down despotic and
autocratic regimes In El Masri v Macedonia (2013) 57 EHRR 25 the Grand Chamber of the European


-----

Court of Human Rights ordered Macedonia to compensate a German citizen who had been handed to the
United States authorities for extraordinary rendition to Afghanistan. At para 77 the court said:

“The applicant submitted several diplomatic cables in which the US diplomatic missions in the respondent
State, Germany and Spain had reported to the US Secretary of State about the applicant's case and/or the
alleged CIA flights and the investigations in Germany and Spain. These cables were released by
WikiLeaks (described by the BBC on 7 December 2010 as “a whistle-blowing website”) in 2010.”

67. At para 205 the court described the conduct of a “special CIA rendition team” at Skopje Airport:

“the applicant, handcuffed and blindfolded, was taken from the hotel and driven to Skopje Airport. Placed in
a room, he was beaten severely by several disguised men dressed in black. He was stripped and
sodomised with an object. He was placed in a nappy and dressed in a dark blue short-sleeved tracksuit.
Shackled and hooded, and subjected to total sensory deprivation, the applicant was forcibly marched to a
CIA aircraft (a Boeing 737 with the Tail No.N313P), which was surrounded by Macedonian security agents
who formed a cordon around the plane. When on the plane, he was thrown to the floor, chained down and
forcibly tranquillised. While in that position, the applicant was flown to Kabul (Afghanistan) via Baghdad.”

68. The applicant says that the United States response to the disclosures “is a textbook example of
political persecution.” He alleges that the respondent plotted to interfere with judges who investigated the
matters that were exposed by the applicant and it sought to silence the International Criminal Court. He
also alleged that there is evidence (referred to at paras 70 to 75 below) that the respondent planned to
kidnap and rendition the applicant from the streets of London, or else murder him in London.

69. The applicant says of the proposed prosecution of him that: “(a) It is unprecedented in law. (b) It cuts
clean across established principles of free speech. (c) To deal with that, the applicant anticipates a trial at
which he, as a foreigner, can be denied reliance on the First Amendment. (d) Indeed, a trial outwith the
protections of the US Constitution altogether, and (e) Is accompanied by exposure to a grossly
disproportionate sentence.” As to the extradition request, “(f) It violates the prohibition on extradition for
political offences expressly provided for in the relevant treaty and under international law. (g) It deliberately
misstates the core facts.”

The alleged plot to poison/kidnap/murder/rendition the applicant

70. The applicant's Spanish lawyers have filed a criminal complaint in Spain against the owner of UC
Global, which was responsible for providing security at the Ecuador Embassy in London. Two anonymous
witnesses who were employed by UC Global provided statements before a public notary. Witness 1 said
that as well as providing monthly security reports to the government of Ecuador, UC Global also secretly
provided copies of the reports to the United States authorities. The owner of UC Global made regular trips
to the United States to speak with the CIA. His wealth increased considerably. The information provided to
the United States included details of meetings between the applicant and his lawyers.

71. Witness 2 alleges the following (assuming that when the witness says “American friends” this is a
reference to the CIA). Guy Goodwin Gill (a lawyer who had visited the applicant) was required to leave his
iPad with security when he entered the embassy. The contents of his iPad were illicitly copied. Witness 2
was asked to steal the nappy of a baby who was visiting the applicant because the CIA wished to establish
the child's paternity. Suggestions were made by the CIA of extreme measures to end the applicant's stay in
the embassy, including leaving the door open to enable his kidnap or poisoning him. Illicit recording
equipment was placed in the embassy at the behest of the CIA. He was asked to place stickers on the
external windows of the embassy, which enabled the CIA (using directional microphones outside the
embassy) to extract the applicant's conversations (despite a white noise machine the applicant used as a
counter-surveillance measure). Security personnel were asked to obtain the applicant's fingerprints from an
imprint on a glass. Security personnel stole documents from the applicant. Security personnel were
instructed to target the applicant's lawyers, and to photograph their documentation. He installed an FTP
server which stored the embassy's daily security reports and which could be (and was) accessed remotely
from the United States by the CIA. UC Global made monthly payments of €20,000 to the person
responsible for security at the embassy to ensure that there were no negative reports about its work.


-----

72. On 26 September 2021, a report was published by Yahoo News entitled “Kidnapping, assassination
and a London shoot-out: Inside the CIA's secret war plans against WikiLeaks” under the byline of Zach
Dorfman, Sean D Naylor and Michael Isikoff. The Yahoo News article and the consequential statements of
Mr Dratel and witness 2 (see below) post-date the judge's decision. The applicant seeks to rely on them as
fresh evidence.

73. The 26 September Yahoo report alleges the following amongst other matters. The disclosure by
WikiLeaks of exceptionally sensitive intelligence, relating to CIA hacking tools and known as “Vault 7”,
caused the CIA director, Mike Pompeo, and other senior officials inside the CIA, to become “completely
detached from reality because they were so embarrassed… They were seeing blood.” In 2017, Mr Pompeo
publicly described WikiLeaks as a “non-state hostile intelligence service.” The designation as a non-state
hostile intelligence service enabled the CIA to take far more aggressive actions. Some senior officials
inside the CIA and the Trump administration discussed killing the applicant, requesting options on how to
assassinate him. Discussions over kidnapping or killing the applicant occurred “at the highest levels”. Eight
former United States officials told Yahoo News of the CIA's proposals to abduct the applicant. White House
lawyers objected to these proposals. The Justice Department was concerned that the CIA's plans would
derail criminal proceedings against the applicant, and expedited the drafting of charges so that they were in
place if the applicant was brought to the United States.

74. Joshua Dratel, a United States Attorney, has provided a statement for the applicant in which he draws
a comparison between the use of the term “non-state hostile intelligence service” and that of “enemy
combatant” to justify detention at Guantanamo Bay. He said the term was used “to place [the applicant]
outside any cognizable legal framework that might protect them from the US actions based on purported
“national security” imperatives”. It could be viewed as being intended to provide legal authority and cover
for the kidnapping and/or killing of the applicant. Mr Dratel considered that these discussions would have
included personnel from the Department of Justice, including the Attorney General, National Security
Division lawyers and the prosecution team.

75. On 17 August 2022, witness 2 provided a signed witness statement. He confirmed that the content of
his 2019 statement was correct. He confirmed that UC Global was in a position to provide essential
information for “options on how to assassinate [the applicant]”.

The grounds of appeal under section 103 of the 2003 Act

Ground i): Extradition is contrary to the Treaty

76. This ground of appeal arises out of the difference between the terms of the Treaty and the 2003 Act.
We refer in more detail to the Treaty below. In summary however, article 4.1 of the Treaty says that
“Extradition shall not be granted if the offense for which extradition is requested is a political offense”.
There is no such wording in the 2003 Act. The applicant says his extradition is requested for a political
offence; extradition for a political offence is contrary to the United Kingdom's obligations under the Treaty;
those obligations should be read into the 2003 Act.

77. The judge did not consider that the Treaty was relevant to her assessment of the issues. This was
because it was an unincorporated international treaty that did not give rise to any individual rights, and
which could not therefore provide a basis for her to refuse to refer the case to the Secretary of State.

78. Edward Fitzgerald KC, who appeared for the applicant before us and below, submits the judge erred in
law in reaching that conclusion. He says that there is nothing to indicate that Parliament intended to
exclude from the scope of the 2003 Act the well-recognised principle that extradition for political offences is
objectionable. He submits that section 81(a) of the 2003 Act must be interpreted as covering extradition for
political offences.

79. Alternatively, whilst he accepts that the 2003 Act “may be” the governing instrument, he submits that it
does not follow that it is exhaustive of the judge's powers. There are, he submits, two other routes to the
same conclusion.


-----

80. First, he submits that the only basis for the applicant's detention is the extradition request which is
barred by article 4 of the Treaty. It follows that the applicant's detention is arbitrary in contravention of
article 5 of the Convention (which is incorporated into the 2003 Act by reason of section 87(1)). Secondly,
he submits it is an abuse of the court's process for the respondent to request the applicant's extradition
where that is prohibited by the terms of the Treaty. In support of this submission he says that Parliament
was aware that the operation of the Act would be subject to the court's abuse of process jurisdiction when
enacting the 2003 Act: R (Kashamu) v Governor of Brixton Prison _[[2001] EWHC 980 (Admin); [2002] QB](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6CBD-93R3-RRNC-B1M3-00000-00&context=1519360)_
887.

81. We think the straightforward answer to the applicant's case on this ground is that identified by the
judge. In short, the Treaty is not incorporated into domestic law, and does not reflect customary
international law. It follows that, standing alone, it does not create personal rights for individual citizens
directly enforceable by the courts. We do not consider the contrary to be arguable.

82. In order to put flesh on these bones, we need to say something about the Treaty and the various
authorities on this issue.

83. On 31 March 2003, the United Kingdom and United States agreed an extradition treaty. It was ratified
on 26 April 2007, and it came into force on the same day. Article 1 imposes a mutual obligation “to
extradite to each other, pursuant to the provisions of this Treaty, persons sought by the authorities in the
Requesting State for trial or punishment for extradition offences.”

84. Article 4 of the Treaty states:

“Political and Military Offenses

1. Extradition shall not be granted if the offense for which extradition is requested is a political offense.

…

3. …extradition shall not be granted if the competent authority of the Requested State determines that the
request was politically motivated...”

85. The applicant says that this provision reflects well-established practice and points out that the United
Kingdom has ratified extradition treaties with 158 other countries, of which 156 have an equivalent “political
offence” provision.

86. The United Kingdom operates under a Parliamentary democracy. Under the royal prerogative, the
Executive may conclude international treaties; but it is well established that such treaties operate only on
the international plane unless incorporated by Parliament (or its delegate) into domestic law. The Executive
has no power to alter domestic law by entering into an international treaty. And it is well established that
the royal prerogative (under which treaties are concluded) “does not extend to altering the law or conferring
rights on individuals or depriving individuals of rights which they enjoy in domestic law without the
intervention of Parliament”: Maclaine Watson & Co Ltd v International Tin Council [1990] 2 AC 418per Lord
Templeman at 476F-477A and Lord Oliver at 449F-500C, R v Secretary of State for the Home Department
_ex parte Brind [1991] 1 AC 696, R v Lyons [2003] 1 AC 976per Lord Hoffmann at para 27. See also R (SC)_
_v Secretary of State for Work and Pensions_ _[2021] UKSC 26; [2022] AC 223at paras 79 to 84 and_
_Heathrow Airport Ltd and others v Her Majesty's Treasury_ _[2021] EWCA Civ 783; [2021] STC 1203 where_
Green LJ set out the circumstances in which an international law measure “becomes embedded or
assumes a foothold into domestic law” so as to become justiciable by the courts.

87. In R (Miller) v Secretary of State for Exiting the European Union _[2017] UKSC 5; [2018] AC 61(Lord_
Neuberger, Baroness Hale, Lord Mance, Lord Kerr, Lord Clarke, Lord Wilson, Lord Sumption and Lord
Hodge) the court said, at para 55:

“Subject to any restrictions imposed by primary legislation, the general rule is that the power to make or
unmake treaties is exercisable without legislative authority and that the exercise of that power is not
reviewable by the courts... Lord Coleridge CJ said that the Queen acts throughout the making of the treaty
and in relation to each and every of its stipulations in her sovereign character, and by her own inherent


-----

authority: _Rustomjee v The Queen (1876) 2 QBD 69, 74. This principle rests on the so-called dualist_
theory, which is based on the proposition that international law and domestic law operate in independent
spheres. The prerogative power to make treaties depends on two related propositions. The first is that
treaties between sovereign states have effect in international law and are not governed by the domestic
law of any state. As Lord Kingsdown expressed it in _Secretary of State in Council of India v Kamachee_
_Boye Sahaba (1859) 13 Moo PC 22, 75, treaties are governed by other laws than those which municipal_
courts administer. The second proposition is that, _although they are binding on the United Kingdom in_
_international law, treaties are not part of UK law and give rise to no legal rights or obligations in domestic_
_law.” (emphasis added)_

88. The position is no different in the extradition context. In _R (Ian Norris) v Secretary of State for the_
_Home Department_ _[2006] EWHC 280 (Admin);_ _[[2006] 3 All ER 1011 it was argued that an extradition](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4KPF-VSN0-TWP1-60NY-00000-00&context=1519360)_
request should have been refused because the requesting state had not established a prima facie case, as
required by the (then) UK-US extradition treaty. That argument was rejected. Sir Igor Judge, P. said at para
44:

“Mr Jones was unable to show any previous authority in the United Kingdom which suggested that the
1972 Treaty, standing alone, created personal rights enforceable by its individual citizens. The treaty
specified the circumstances in which the governments of the United Kingdom and US agreed that
extradition would, or would not, take place and they bound themselves to a series of pre-conditions which
would govern the extradition process. Thereafter, the rights of citizens of the United Kingdom were
governed by domestic legislative arrangements which ensured that the extradition process should be
subject to judicial oversight, in an appropriate case, extending as far as the House of Lords in its capacity
as the final appellate court. The treaty reflected the relationship agreed between the United Kingdom and
the US for the purposes of extradition, rather than the municipal rights of United Kingdom citizens,
enforceable against their own government. In brief, therefore their rights were provided and guaranteed,
not by treaty, but by domestic legislation.”

89. Mr Fitzgerald seeks to distinguish Norris from this case. He submits that it was not surprising that in
_Norris the court declined to apply an unincorporated treaty in a way that gave rise to a conflict with the_
express terms of domestic legislation. As is clear from the passage cited above however, the decision in
_Norris was not made on that basis. It rested on the principle, well-established in this jurisdiction as we have_
said, that treaties standing alone do not create personal rights enforceable by individual citizens.

90. There is no arguable merit either in the submission that by virtue of the Treaty, the “political offence”
bar is to be read into the 2003 Act (an argument Clair Dobbin KC for the respondent accurately
characterised as an attempt to get the Treaty in by the back door, when it could not enter through the
front).

91. The “political offence” bar certainly did appear in earlier legislation. Section 3(1) of the 1870 Act
prohibited extradition “if the offence in respect of which his surrender is demanded is one of a political
character”. The _[Extradition Act 1989,the immediate predecessor legislation to the 2003 Act, by section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHH0-TWPY-Y0CD-00000-00&context=1519360)_
6(1)(a), prohibited extradition in similar terms i.e. “if it appears to an appropriate authority… that the offence
of which that person is accused or convicted is an offence of a political character.” It is also to be noted that
by section 6(1)(c), the 1989 Act also prohibited extradition if the “request for his return (though purporting
to be made on account of an extradition crime) is in fact made for the purpose of prosecuting or punishing
him on account of his… political opinions.”

92. Turning however to the 2003 Act, the starting point is that the language of section 81(a) is clear. It
precludes extradition where extradition is for the purpose of prosecuting the requested person on account
of their political opinions. It says nothing, however, about preventing extradition for a political offence.
Although there may be a degree of overlap, the two are separate concepts. Parliament has legislated to
cover the former, not the latter. There is, further, nothing in the 2003 Act or its Explanatory Notes to
suggest that Parliament intended Part 2 of the 2003 Act precisely to replicate the terms of the Treaty. As it
is, the 2003 Act re-enacted section 6(1)(c) of the 1989 Act but not section 6(1)(a). If Parliament had


-----

intended to incorporate the political offence exception this could have been simply achieved by the reenactment of section 6(1)(a) of the 1989 Act. Parliament did not do so [6].

93. The parties made reference to things said during the Parliamentary debates on the Extradition Bill,
however the conditions for admitting material from Hansard are not satisfied. The legislative wording is not
ambiguous or obscure and does not lead to absurdity: Pepper v Hart [1992] UKHL 3; [1993] AC 593. We
considered them de bene esse. It seemed to us in any event, that the statements the parties relied on do
not show any clear contrary Parliamentary intent.

94. It follows from the above that subject to the abuse of process argument (see paras 97 to 103 below), in
the context of the issues we are considering, the 2003 Act provides an exhaustive code of the
circumstances in which a case should be sent to the Secretary of State so that where a statutory bar is not
established, the case must be sent to the Secretary of State: section 87(3).

95. We turn next to the argument based on article 5 of the Convention. Detention is arbitrary and
incompatible with article 5 of the Convention if it is not in accordance with a procedure prescribed by law.
Here, the applicant's detention is justified under the 2003 Act. The Secretary of State (correctly) certified
that the extradition request was valid within the meaning of section 70(3). She sent the request and the
certificate to the appropriate judge under section 70(9). The judge issued a warrant for the applicant's
arrest under section 71(2). That warrant was then exercised.

96. It is not arguable that the applicant's detention is arbitrary: he was arrested in accordance with the
statutory framework prescribed by Parliament. If the extradition request was not in accordance with the
Treaty, that does not render his detention arbitrary. For the reasons already given, the Treaty does not
affect the rights of the parties, and non-compliance with the Treaty does not render detention arbitrary.
Non-compliance with an unincorporated treaty is also irrelevant when considering Convention rights: see R
_(SC) v Secretary of State for Work and Pensions_ _[2021] UKSC 26; [2022] AC 223per Lord Reed at paras_
2(7)(i) and 74 to 79.

97. We turn finally to the issue of abuse of process. Criminal proceedings are an abuse of the court's
process if the defendant cannot receive a fair trial, or if it is unfair for the defendant to be tried. The abuse
jurisdiction applies to extradition proceedings. Here, there is no suggestion that the applicant could not
have a fair hearing of his objections to extradition. The issue is whether the (asserted) breach of the Treaty
renders the extradition proceedings unfair.

98. The applicant relies on R v Uxbridge Magistrates' Court ex parte Adimi [2001] QB 667. In that case,
the applicants had committed offences in order to get to the United Kingdom to claim asylum. Article 31 of
the Refugee Convention prohibits the imposition of penalties on illegal entrants who come directly from a
place of persecution and present themselves without delay to the authorities and show good cause for their
illegal entry. The applicants sought judicial review of the decisions to prosecute them. At first instance,
Simon Brown LJ (with whom Neuberger J agreed) held that the United Kingdom's accession to the
Refugee Convention created a legitimate expectation in the minds of asylum seekers that they would be
accorded the benefit of article 31. This reasoning appears to be tantamount to affording domestic legal
force to an unincorporated treaty.

99. The decision in Adimi however must be read subject to the subsequent decision of the Court of Appeal
in R (European Roma Rights) v Prague Immigration Officer _[2003] EWCA Civ 666; [2004] QB 811. In this_
latter case, Simon Brown LJ (who was part of the constitution of the Court of Appeal) said that his
comments in Adimi “are to be regarded as at best superficial” and that his conclusion “with regard to the
legitimate expectations of asylum seekers to the benefits of article 31, is suspect.” We respectfully agree.
_Adimi is not binding on us. We decline to follow it._

100. The applicant also relies on the decision of the House of Lords in R v Asfaw [2008] UKHL 31; [2008]
1 AC 1061. The facts were similar to Adimi. At the relevant time, unlike the position in Adimi, article 31 had
been incorporated into domestic law by section 31 of the Immigration and Asylum Act 1999. The House of
Lords held that the proceedings on one of the counts (which had the effect of circumventing section 31 for
no legitimate purpose) was an abuse of the court's process. This decision does not assist the applicant.


-----

The critical point was that article 31 of the Refugee Convention had been incorporated into domestic law by
primary legislation. By contrast, article 4 of the Treaty has not been incorporated into domestic law.

101. The applicant further relies on a series of cases which have held that prosecutions of victims of
human trafficking, contrary to international measures, have been an abuse of the court's process. Ms
[Dobbin says that these cases can be distinguished, because the Modern Slavery Act 2015 has the effect](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
of incorporating international measures on human trafficking into domestic law. That therefore provides the
necessary “foothold” to trigger an abuse of process jurisdiction. The difficulty with that argument is that the
abuse of process jurisdiction in human trafficking cases was developed before the enactment of the 2015
Act (and in order to fill a lacuna that existed before that point): R v M(L) [2010] EWCA Crim 2327; [2011] 1
Cr App R 12, R v N _[2012] EWCA Crim 189; [2013] QB 379, R v L(C) [2013] EWCA Crim 991; [2013] 2 Cr_
[App R 23, R v AFU [2023] EWCA Crim 23; [2023] 1 Cr App R 16.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)

102. Nevertheless, we do not consider that the modern slavery authorities assist the applicant. Section
10(1)(a)(i) of the Prosecution of Offences Act 1985 requires the Director of Public Prosecutions to issue a
Code for Crown Prosecutors giving guidance on the general principles to be applied when determining
whether proceedings for an offence should be instituted. The Code requires crown prosecutors to exercise
a discretionary judgement when deciding whether to bring criminal proceedings. One aspect of the Code
which must be satisfied before a prosecution can be brought, is that the proceedings are in the public
interest. Additional legal guidance provided to Crown Prosecutors requires that consideration be given to
the question of whether the offender was a victim of trafficking. To that extent, the international measures
on trafficking were given indirect domestic legal effect because decision makers were required to take
account of guidance that reflected those measures. This falls within one of the recognised categories in
which, contrary to the general rule, a treaty may have domestic legal effect: R v Secretary of State for the
_Home Department ex part Launder [1997] 1 WLR 839 at 867B-D._

103. The modern slavery cases, correctly understood, and in accordance with the authoritative principles
that govern the effect of unincorporated treaties, do not therefore provide an example of direct effect being
given to an unincorporated treaty. More specifically, in the context of this case, they do not provide an
arguable basis for giving effect to the Treaty through the prism of the abuse of process jurisdiction.

Ground ii): Whether the extradition request was made for the purpose of prosecuting the applicant on account of his
political opinions

104. As set out above, section 81(a) provides that a person's extradition is barred if the request is made
for the purpose of prosecuting him on account of his political opinions.

105. The applicant contends that this is the case here, i.e. that he is being prosecuted because of his
exposure of the respondent's alleged involvement in gross crimes of “universal jurisdiction” [7], and that this
amounts to a protected political act for the purposes of the 2003 Act: Voitenko v Minister for Immigration
_and Multicultural Affairs [1999] FCA 428 per Hill J at para 32-23, Grava v Immigration and Naturalization_
_Service (2000) 205 f.3d 1177 (USCA 9[th] Cir March 7) at p2, Klinko v Canada (Minister of Citizenship and_
_Immigration) [2000] 3 FCR 327 at paras 24 to 31. For the same reasons, he contends that his extradition is_
incompatible with article 18 (read with articles 5 and/or 10) of the Convention.

106. The applicant submits that the judge failed to address this issue. Further, the applicant says that the
judge's rejection of the applicant's case on bad faith was “not the result of a proper consideration of the
issues or evidence”. He submits that “it is perfectly obvious” that the respondent was motivated to bring the
prosecution in order to maintain its impunity for the crimes that the applicant had revealed, and to deter
further disclosures.

107. The applicant relies, as he did before the judge, on evidence which he says shows amongst other
things: United States political interference with any judge in any country who sought to investigate or
prosecute matters that the applicant helped to expose; United States plans to kidnap and poison the
applicant; a decision in 2017 to initiate a criminal prosecution, even though a decision had been made in
2013 not to prosecute; and public attacks on those who expose the respondent's crimes as enemies of the


-----

people and evidence that prosecutors resigned in protest against the preferment of the superseding
indictment in May 2019.

108. The judge said that the burden was on the applicant to establish, to the civil standard of proof, that
the extradition request was barred by section 81 of the 2003 Act. She found that the applicant was
opposed to war crimes and human rights abuses, and she accepted that these amounted to “political
opinions” within the meaning of section 81(a). She considered the applicant's evidential case for
suggesting that the request for extradition was made for the purpose of prosecuting or punishing him for
his political opinions but concluded that he had failed to establish that case on the balance of probabilities.
The federal prosecutors who decided to bring the charges did so in good faith and the applicant had not
established that he was the target of a politically motivated prosecution. She rejected the applicant's case
that a decision was made not to prosecute him in 2013 and that federal prosecutors were put under
pressure to bring charges.

109. Our conclusion in summary on this ground is that the judge properly addressed the question that she
was required to answer under section 81(a), namely whether the request for extradition was made for the
purpose of prosecuting the applicant on account of his political opinions; and she concluded on the facts
that it was not. She was entitled to reach that conclusion on the evidence before her, and on the
unchallenged sworn evidence of the prosecutor (which refutes the applicant's case). The contrary is not
arguable.

110. The issue before the judge was whether the extradition request was made for the purpose of
prosecuting or punishing the applicant on account of his political opinions. This required an enquiry into the
purpose of making the extradition request.

111. The judge considered the various strands of evidence on which the applicant relied with great care.
We take one example. Four pages of her decision were devoted to an examination of the material the
applicant relied on in support of the contention that a decision not to prosecute him was made in 2013. And
six reasons were given by the judge for her conclusion that this contention was not made out. First, the
applicant's case relied on a newspaper article, but on close analysis that article did not say that a decision
had been made not to prosecute the applicant. It said that the case had not been formally closed.
Secondly, the applicant relied on witnesses who were merely expressing an opinion based on material that
was already before the judge and this did not take the matter further. Thirdly, decisions by federal courts in
2015 and 2016 showed that an investigation into the allegations against the applicant was ongoing.
Fourthly, in 2016 the applicant had asked for the investigation to be brought to an end. This was
inconsistent with his case that a decision had been made not to prosecute him in 2013. Fifthly, accounts
that the investigation had remained in the same state since 2013 were “pure conjecture”. And sixthly a
grand jury remain empanelled long after 2013.

112. Mark Summers KC, who argued this aspect of the case on behalf of the applicant, does not now take
issue with the judge's finding that there was no decision not to prosecute the applicant in 2013. That, he
submits, does not matter, and does not change the logic of the applicant's case.

113. This submission rather overlooks how the applicant's case was put before the judge. The written
closing submissions on behalf of the applicant, said:

“Decision not to prosecute Julian Assange in 2013

We now know that a decision was made under the Obama administration not to prosecute Julian Assange
in 2013 on the very same evidence that was relied on to indict him in 2018.

…

… there was no prosecution under the Obama administration because it was still thought wrong to
prosecute the media for either receiving or publishing state secrets from a government official….

Yet the principled and consistent stand taken under the Obama administration was reversed under the
present Trump administration from early 2017 onwards. The reason for that lies primarily in the nature of


-----

Julian Assange's disclosures to the world and the nature of his political opinions, which inevitably attracted
the hostility of the Trump administration and the CIA.”

114. Mr Summers says now that the important point is that having not initiated a prosecution before, a
decision to prosecute was made following an announcement made by the International Criminal Court in
late 2016 that it was taking forward an investigation into matters revealed by WikiLeaks; and that at about
that time, senior political figures were denouncing the applicant and planning to kill or rendition him. The
prosecution was part of the rendition plan so as to ensure that once he had been returned to the United
States he would face criminal charges. The chronology demonstrates that the prosecution is politically
motivated.

115. None of this provides a basis for impugning the judge's reasoning. The applicant's case before us
amounts simply to a reassertion of his case on this issue, and a disagreement with the judge's conclusion.
It does not engage with the judge's reasoning. Far less does it identify any flaw in her factual conclusions.

116. The primary complaint the applicant now makes is that the judge failed to address an argument that
he had exposed criminal activity by the respondent, and that that exposure amounted to a protected
political act. The first thing to say about this argument is that the judge accepted, as we have already said,
that the applicant's motives were political. The point of substance, however, is that the applicant's
argument conflates his motive for his conduct with the respondent's purpose in seeking his extradition. The
two are distinct.

117. We are content (like the judge) to assume that the applicant acted out of political conviction, and that
his activities exposed state involvement in serious crimes. It does not follow however that the request for
his extradition is made on account of his political views. The authorities Mr Summers relied on do not
establish the contrary.

118. The judge was entitled to conclude on the evidence before her and for the reasons she gave that the
request for extradition was made for the purpose of prosecuting the applicant on account of the extradition
offences, and not on account of his political opinions. That reflected the sworn evidence given by Mr
Kromberg, the federal prosecutor in the case (see para 43 above). He has given a detailed account of the
steps that resulted in the decision to prosecute the applicant and to seek his extradition. Mr Summers
made it clear, in terms, that the applicant does not accuse Mr Kromberg of dishonesty. That, in itself, is
fatal to this aspect of the applicant's case.

Ground iii) Extradition incompatible with article 7 of the Convention (no punishment without law)

119. As we have explained above, the 2003 Act provides a “step by step” process for deciding whether an
extradition case should be sent by a judge to the Secretary of State.

120. The last step, if there are no other statutory bars to extradition, is to decide pursuant to section 87(1)
[of the 2003 Act, whether extradition is compatible with Convention rights within the meaning of the Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[Rights Act 1998. If it is not, the judge must order the person's discharge. If it is, the judge must send the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
case to the Secretary of State, for the Secretary of State's decision as to whether the person should be
extradited.

121. On appeal, a court must decide whether the judge was wrong to decide that extradition is compatible
with Convention rights: see paras 28 to 30 above. As human rights are in issue under section 87(1), it is for
the appeal court to reach its own decision as to whether extradition would be compatible with Convention
rights (or arguably so on a leave application): see Norris v Government of United States of America [2010]
_UKSC 9; [2010] AC 487, per Lord Phillips at para 68. This is the approach we have applied to each of the_
section 87(1) challenges.

122. The applicant challenged his extradition on the basis that it was incompatible with article 7 of the
Convention, which requires that an individual is able to know (if need be after taking appropriate legal
advice), whether particular conduct will render him liable under the criminal law, and what penalty might be
imposed. Article 7 states:

“N i h t ith t l


-----

1. No one shall be held guilty of any criminal offence on account of any act or omission which did not
constitute a criminal offence under national or international law at the time when it was committed. Nor
shall a heavier penalty be imposed than the one that was applicable at the time the criminal offence was
committed.

2. This Article shall not prejudice the trial and punishment of any person for any act or omission which, at
the time when it was committed, was criminal according to the general principles of law recognised by
civilised nations.”

123. When considering the Convention challenges to extradition under section 87(1), including the article
7 challenge, the judge proceeded on the basis that it was for the applicant to show that there was a real
risk of a flagrant denial of those Convention rights, applying the principles articulated in R (Ullah) v Special
_Adjudicator [2004] UKHL 26; [2004] 2 AC 323by Lord Steyn at para 40, Lord Carswell at para 67 and_
(agreeing generally with Lord Steyn) Lord Bingham at para 25 and Baroness Hale at para 53 [8]. See further,
paras 125 and 135 below. In Ullah, the House of Lords took the flagrant denial test from the decision of the
ECtHR in Soering v United Kingdom (1989) 11 EHRR 439. That was a case in which the applicant resisted
extradition to the United States to stand trial in Virginia on the grounds that it would infringe his right to a
fair trial under article 6 of the Convention. The application was dismissed, but at para 113 the court said:
“The Court does not exclude that an issue might exceptionally be raised under Article 6 by an extradition
decision in circumstances where the fugitive has suffered or risks suffering a flagrant denial of a fair trial in
the requesting country.”

124. The applicant says that a prosecution was unforeseeable because it is unprecedented and contrary
to the First Amendment of the United States Constitution (which, on his case, effectively provides
journalists with an immunity from prosecution in respect of conduct that would otherwise be criminal but
which is engaged in for journalistic reasons). Publishing leaked United States national security information
was both legal and commonplace. Criminalising such conduct retrospectively breaches the protection
required by article 7 of the Convention. The judge should have decided for herself whether the extradition
of the applicant was compatible with article 7, rather than leaving this issue to a United States court to
determine through the prism of the Fifth Amendment [9]. Further, it is at least arguable that the correct test is
not as stringent as having to show a real risk of a flagrant denial of the protection required by article 7 of
the Convention: Arranz v Spanish Judicial Authority _[2013] EWHC 1662 (Admin)_ _per Sir John Thomas P.,_
at para 38.

125. We turn first to the “correct test” issue. In our view, it is not arguable that the judge was wrong to
apply the test of flagrancy (that is, whether there is a real risk of a flagrant denial of the protection of
Convention rights in this extradition context). The law is clear on this point. See _Ullah_ at para 45 where
Lord Steyn said “[Article 7] is among the first tier of core obligations under the [Convention]. It is absolute
and non derogable… Bearing in mind the principles laid down by the ECtHR in respect of extradition…
involving a real risk of a flagrant violation of fair trial rights, the same must be the case in respect of this
obligation”. Further, in Arranz, at para 38, Sir John Thomas P. expressly recognised that Lord Steyn had
laid down the test to be applied and that the Divisional Court was bound by that test. There is therefore no
reason to conclude that an appeal based on the test to be applied would have a real prospect of success.

126. We turn next to the substance of the applicant's case on article 7. The judge's reasoning was as
follows:

“252. I am satisfied that the flagrant denial threshold has not been reached in this case. This is primarily
because Mr. Assange's Article 7 rights are protected in America by the US Constitution and, in particular,
by the Fifth Amendment.

253. The Fifth Amendment, inter alia, prohibits a person from being deprived of their liberty without due
process of law (“due process clause”). It states:

“No person shall be held to answer for a capital, or otherwise infamous crime, unless on a presentment or
indictment of a grand jury, except in cases arising in the land or naval forces, or in the Militia, when in
actual service in time of War or public danger; nor shall any person be subject for the same offence to be


-----

twice put in jeopardy of life or limb; nor shall be compelled in any criminal case to be a witness against
himself, nor be deprived of life, liberty, or property, without due process of law; nor shall private property be
taken for public use, without just compensation”.

254. Pursuant to this constitutional protection, two related but distinct doctrines have been developed by
US courts; (i) the doctrines of “vagueness”, which is directed at lack of sufficient clarity and precision in a
statute; and (ii) the doctrine of “overbreadth” which invalidate statutes which “infringe on expression to a
degree greater than justified by the legitimate governmental need” (see United States v. Morison, 844 F.2d
1057). The vagueness doctrine is premised on the principle that due process of law requires the
government to provide potential defendants with fair warning that their conduct may be proscribed, and that
vague statutes may encourage arbitrary and discriminatory enforcement (see US v Rosen). As the court in
_Morison (above) stated, “[i]t is sufficient... to satisfy requirements of 'reasonable certainty' that while the_
prohibitions of a statute may not satisfy those intent on finding fault at any cost, they are set out in terms
that the ordinary person exercising ordinary common sense can sufficiently understand and comply with,
without sacrifice to the public interest.” The due process clause and the development of the “void for
vagueness” and “overbreadth” doctrines appear to provide the same protections to a defendant in the US
as Article 7 of the ECHR provides here.

255. The defence does not criticise the US legal system or its processes. This court expects that a US
court will consider challenges, to the vagueness or overbreadth of these provisions, fairly and diligently. I
am told that challenges of this nature can be made either at the pre-trial stage or during the substantive
trial and the defence has a statutory right of appeal against any ruling made by the lower court and a
further discretionary right of appeal to the Supreme Court.

256. An example of US courts applying these doctrines in relation to 18 U.S.C. §793 can be seen in the
Court of Appeals decision in _United States v Morison, 844 F.2d 1057. The defendant was a naval_
intelligence officer who transmitted classified satellite photographs of Soviet naval preparations to a British
periodical. He was charged, inter alia, with offences contrary to 18 U.S.C. §793(d) and (e). The court
rejected both vagueness and First Amendment challenges to the provisions. The court set out the
principles underpinning the vagueness doctrine:

“it has been repeatedly stated that a statute which “either forbids or requires the doing of an act in terms so
vague that men of common intelligence must necessarily guess at its meaning and differ as to its
application, violates the first essential of due process of law.” It noted also that “[i]t is sufficient, though, to
satisfy requirements of “reasonable certainty,” that while “the prohibitions [of a statute] may not satisfy
those intent on finding fault at any cost, they are set out in terms that the ordinary person exercising
ordinary common sense can sufficiently understand and comply with, without sacrifice to the public interest
. . . [and they] will not be struck down as vague, even though marginal cases could be put where doubts
might arise.” Arnett v Kennedy,416 U.S. 134, 159, 40 L. Ed. 2d 15, 94 S. Ct. 1633 (1974)2”.

257. It went on to explain:

“..in any event, it is settled beyond controversy that if one is not of the rare “entrapped” innocents but one
to whom the statute clearly applies, irrespective of any claims of vagueness, he has no standing to
challenge successfully the statute under which he is charged for vagueness. _Parker v. Levy, supra,417_
U.S. at 756. Finally, the statute must be read in its entirety and all vagueness may be corrected by judicial
construction which narrows the sweep of the statute within the range of reasonable certainty.”

258. In relation to the claim of overbreadth, the court acknowledged that the doctrine is an exception to the
“traditional” rules of practice not recognised outside the context of the First Amendment; however, it was a
“strong medicine” to be applied.

259. The court ultimately rejected Mr. Morrison's claims under both doctrines. It found the statute itself to
be both constitutionally overbroad and vague, however considered that this was remedied by the trial judge
limiting the scope of the term “information relating to the national defence” in its directions to the jury. The
court concluded:


-----

“The notice requirement insures that speakers will not be stifled by the fear they might commit a violation of
which they could not have known. The district court's limiting instructions properly confine prosecution
under the statute to disclosures of classified information potentially damaging to the military security of the
United States. In this way the requirements of the vagueness and overbreadth doctrines restrain the
possibility that the broad language of this statute would ever be used as a means of punishing mere
criticism of incompetence and corruption in the government. Without undertaking the detailed examination
of the government's interest in secrecy that would be required for a traditional balancing analysis, the
strictures of these limiting instructions confine prosecution to cases of serious consequence to our national
security.”

260. The case demonstrates the approach a US court would take if these arguments were advanced by
Mr. Assange. It shows that courts have long been alive to the issues of vagueness and overbreadth in
relation to 18 U.S.C. §793 and have already interpreted it as subject to limitations which have confined its
ambit.

261. It is difficult to see how Mr. Assange will be exposed to a real risk of suffering a violation of his Article
7 right in the US. A US court will make a principled determination of any vagueness and overbreadth in
relation to the provisions of 18 U.S.C. §793 and the CFAA. It will take account of the ambit of the
provisions themselves and any refinements to their interpretation from judicial rulings (for example which
occurred in Morrison, above). If, on the basis of its analysis, it finds the language of the statute so broad or
vague that it does not meet the standards of accessibility and foreseeability, it will find the provisions
unconstitutional and therefore unenforceable. If need be any lower court rulings will be reviewed by the
senior courts.

262. For this reason, there is no need for an extradition court to embark on the detailed discussion on
accessibility and foreseeability invited by the defence. A US court is well equipped to interpret its own
legislation and reach a conclusion that is compatible with Mr. Assange's constitutional rights. Through this
process, I am satisfied that his Article 7 rights will be fully protected.

…

266. The defence has not discharged its burden to establish a real risk of a 'flagrant denial' of Mr.
Assange's Article 7 rights if he is extradited to face trial in America. “

127. The applicant's arguments fail to do justice to this careful analysis. It is not arguable that the judge
was wrong to conclude that the United States courts are “alive to the issues of vagueness and overbreadth
in relation to 18 U.S.C. §793”. Nor is it arguable that the judge was wrong to conclude that the applicant
would not be exposed to a real risk of suffering a violation of his article 7 rights in the United States. She
did, in terms, decide this issue for herself. In order to determine the issue, the judge was right to take
account of the protection that the applicant would have under the Fifth Amendment which affords broadly
similar protection to article 7 of the Convention. In the light of that protection, it is not arguable that
extradition would give rise to a real risk of a flagrant denial of the rights protected by article 7 of the
Convention.

128. This ground of appeal has no arguable merit.

Ground iv) Extradition incompatible with article 10 of the Convention (freedom of expression)

129. Free speech is a fundamental right recognised by the common law and by international and domestic
human rights instruments. It is given strong but qualified protection in this jurisdiction by the common law,
article 10 of the Convention and sections 6 and 12 of the Human Rights Act 1998. In the United States it is
protected by the First Amendment to the United States Constitution.

130. Article 10 states:

“Freedom of expression

1. Everyone has the right to freedom of expression. This right shall include freedom to hold opinions and to
receive and impart information and ideas without interference by public authority and regardless of


-----

frontiers. This Article shall not prevent States from requiring the licensing of broadcasting, television or
cinema enterprises.

2. The exercise of these freedoms, since it carries with it duties and responsibilities, may be subject to
such formalities, conditions, restrictions or penalties as are prescribed by law and are necessary in a
democratic society, in the interests of national security, territorial integrity or public safety, for the
prevention of disorder or crime, for the protection of health or morals, for the protection of the reputation or
rights of others, for preventing the disclosure of information received in confidence, or for maintaining the
authority and impartiality of the judiciary.”

131. Article 10 of the Convention was central to two separate objections to extradition that were raised by
the applicant. First, the applicant contended that the extradition offences did not satisfy the “dual
criminality” rule. Secondly, as a matter of practice, the conduct engaged in by the applicant was normal
journalistic practice, and there were numerous examples of the obtaining and publication of “state secrets”
which had not resulted in any prosecution. The applicant contended that a prosecution for such conduct in
this jurisdiction would be incompatible with article 10 of the Convention, and that his extradition would
result in a flagrant denial of his article 10 rights, contrary to section 87(1).

132. The judge addressed separately the arguments that were advanced in respect of dual criminality and
article 10 of the Convention. She rejected the applicant's dual criminality challenge. She found that the dual
criminality rule was satisfied, and that a prosecution of the applicant in the United Kingdom would not
offend article 10 of the Convention. There is no appeal against the judge's decision on this issue.

133. When the judge came to address the contention that extradition was incompatible with article 10, she
recorded that the applicant had submitted that “a US court is bound to conclude that the First Amendment
will prevent this prosecution, and this is a sure indicator that Article 10 is engaged” [10]. The applicant's
argument to this effect, made in his written closing submissions, was expressly premised on the
assumption that “contrary to [Mr Kromberg's] stated position… the First Amendment will be considered at
all [at trial]”.

134. The judge then referred back to, and relied on, her conclusion that a prosecution of the applicant in
the United Kingdom would not offend article 10. She said:

“272. First, in relation to any suggestion that the First Amendment will not apply to Mr. Assange, I repeat
my observations above. I have not been referred to any authority which supports the proposition that a
foreign national, who is on US soil and facing trial before a US court, would be denied the protections
provided by the US Constitution. This was not the decision of the U.S. Supreme Court in USAID v Alliance
_for Open Society (2020) 140 SC 2082)._

273. Secondly, in relation to the defence submission that Mr. Assange's conduct was lawful, I have already
determined not only that Mr. Assange's conduct would be capable of constituting criminal offences in
England and Wales but also that his prosecution in this jurisdiction would not be prevented by the
operation of Article 10. This clearly demonstrates that prosecution of Mr. Assange for the same conduct in
the US would not involve any nullification of his Article 10 rights.

274. Thirdly, the First Amendment to the US Constitution protects freedom of speech, providing a similar
protection to that given by Article 10. It states:

“Congress shall make no law respecting an establishment of religion, or prohibiting the free exercise
thereof; or abridging the freedom of speech, or of the press; or the right of the people peaceably to
assemble, and to petition the Government for a redress of grievances”.

275. As noted above, the defence does not criticise the US legal system, and I accept that the challenges
raised by the defence on free speech will properly be considered. As I have noted, the defence can raise
these issues at the pre-trial stage or during the substantive trial and there is a statutory right of appeal
against rulings made by the lower court, and a further discretionary right of appeal to the Supreme Court.
This court trusts that upon extradition, a US court will properly consider Mr. Assange's right to free speech
and determine any constitutional challenges to their equivalent legislation.


-----

276. Fourthly, in relation to the defence submission that US statutes do not contain equivalent safeguards
for whistle-blowers, the US identifies the whistle-blowing avenues which would have been available to Ms.
Manning in 2010. The defence complain that this evidence was not introduced formally or put to defence
witnesses, however, these avenues are contained in statutory provisions available to all, and the defence
have had ample opportunity in their closing submissions to comment on this material. In any event, the
cache of documents disclosed in this case is rightly described as “vast” and contained the names of
informants. I accept that it is unrealistic to argue that authorisation might have been given to their
disclosure or that a court might sanction their disclosure upon judicial review.

277. The defence has failed to discharge its burden of establishing that extradition would constitute a
flagrant denial of Mr. Assange's rights so that they would be completely denied or nullified.”

135. The judge clearly applied the correct test of “flagrant denial” to a qualified Convention right: see Ullah
at para 24 per Lord Bingham:

“While the Strasbourg jurisprudence does not preclude reliance on articles other than article 3 as a ground
for resisting extradition or expulsion, it makes it quite clear that successful reliance demands presentation
of a very strong case… Where reliance is placed on article 6 it must be shown that a person has suffered
or risks suffering a flagrant denial of a fair trial in the receiving state… Successful reliance on article 5
would have to meet no less exacting a test. The lack of success of applicants relying on articles 2, 5 and 6
before the Strasbourg court highlights the difficulty of meeting the stringent test which that court imposes.
This difficulty will not be less where reliance is placed on articles such as 8 or 9, which provide for the
striking of a balance between the right of the individual and the wider interests of the community even in a
case where a serious interference is shown. This is not a balance which the Strasbourg court ought
ordinarily to strike in the first instance, nor is it a balance which that court is well placed to assess in the
absence of representations by the receiving state whose laws, institutions or practices are the subject of
criticism. On the other hand, the removing state will always have what will usually be strong grounds for
justifying its own conduct: … the great desirability of honouring extradition treaties made with other states.
The correct approach in cases involving qualified rights such as those under articles 8 and 9 is in my
opinion that indicated by the Immigration Appeal Tribunal (Mr C M G Ockelton, deputy president, Mr Allen
and Mr Moulden) in Devaseelan v Secretary of State for the Home Department [2002] IAT 702, [2003] Imm
AR 1, paragraph 111:

“The reason why flagrant denial or gross violation is to be taken into account is that it is only in such a case

- where the right will be completely denied or nullified in the destination country - that it can be said that
removal will breach the treaty obligations of the signatory state however those obligations might be
interpreted or whatever might be said by or on behalf of the destination state.”

136. The judge therefore rejected the applicant's case under article 10, broadly for two reasons. First, she
said that the First Amendment to the United States Constitution protecting freedom of speech provides a
similar protection to that given by article 10 of the Convention; and she did not accept that the applicant
had shown that he would be denied the protections provided by the First Amendment. Secondly, she
considered that the prosecution of the applicant in England and Wales would be compatible with article 10
of the Convention.

137. As to the First Amendment, there is a separate question as to whether the applicant will be denied its
protection on account of his nationality. We address that question under ground v) below. For these
purposes it is sufficient to assume that the applicant will be granted the same First Amendment rights as a
United States citizen. On that assumption, the applicant's own case was that the First Amendment would
operate to prevent a prosecution. Even if the applicant has overstated the protection of the First
Amendment for forensic purposes, the fact that his freedom of speech will be fully taken into account in any
prosecution means that he has not demonstrated that his extradition would involve a flagrant denial of his
rights under article 10.

138. As to whether article 10 would prevent a prosecution in the United Kingdom for equivalent conduct,
the judge referred back to her findings on dual criminality which are not now challenged. In respect of that
issue the judge (naturally enough) addressed the arguments that were advanced before her The


-----

applicant's case was that a prosecution of Ms Manning would be contrary to article 10, and that the position
of the applicant (as publisher rather than leaker) was _a fortiori. The judge rejected this argument. She_
considered that binding domestic authority in the House of Lords showed that a prosecution would be
compatible with article 10 of the Convention: R v Shayler [2002] UKHL 11; [2003] 1 AC 247[11].

139. Before us, the applicant repeats his submission that Ms Manning was a whistleblower, whose
disclosures to the applicant would have been justified under article 10 and fastens in particular on the
decision of the Grand Chamber of the ECtHR in _Halet v Luxembourg_ _[(2023) 55 BHRC 348 (a decision](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69X8-WCJ3-RRHH-4390-00000-00&context=1519360)_
which post-dates the decision of the judge in this case). It follows, he submits, _a fortiori, that any_
prosecution of him would amount to a flagrant denial of his article 10 rights. Further, as it is put in the
perfected grounds of appeal for this hearing: “publishing leaked national security information was (and is)
commonplace because it is conduct protected by entrenched principles of free speech, principles which are
as familiar to the First Amendment as they are to Article 10 ECHR”. It follows that the prosecution of a
journalist for obtaining or publishing classified information is fundamentally inconsistent with (and a flagrant
denial of) press freedoms. The judge failed to recognise that the applicant's alleged conduct in encouraging
Ms Manning to leak classified information is “the stuff of every-day investigative journalism; are in fact mild
examples of it, and are plainly within Article 10”.

140. No-one can doubt the importance of the protection provided for whistle-blowers and journalists by
article 10 of the Convention. It is, however, a qualified not an absolute right. It is necessary to balance the
public interest in publication against the legitimate aims pursued by legislation that is intended to protect
national security. That is a fact sensitive exercise in the circumstances of any individual case. The
importance of this exercise is emphasised in the Strasbourg case law, including the authorities on which
the applicant particularly relies. The Strasbourg authorities do not support the proposition advanced by the
applicant that whistle-blowers or journalists have an immunity from prosecution in respect of criminal
conduct in the course of journalistic activities.

141. In Gîrleanu v Romania (2019) 68 EHRR 19, the court said (at para 84):

“…the protection afforded by art 10 of the Convention to journalists is subject to the proviso that they act in
_good faith in order to provide accurate and reliable information in accordance with the tenets of responsible_
_journalism. The concept of responsible journalism, as a professional activity which enjoys the protection of_
art 10 of the Convention, is not confined to the contents of information which is collected and/or
disseminated by journalistic means. That concept also embraces the lawfulness of the conduct of a
journalist, and the fact that a journalist has breached the law is a relevant, albeit not decisive, consideration
when determining whether he or she has acted responsibly.” [emphasis added].

142. In Stoll v Switzerland (2008) 47 EHRR 59 the court said, at para 102:

“The Court further reiterates that all persons, including journalists, who exercise their freedom of
expression undertake “duties and responsibilities”, the scope of which depends on their situation and the
technical means they use (see, for example, Handyside v United Kingdom (1979-80) 1 EHRR 37 at [49]).
Thus, notwithstanding the vital role played by the press in a democratic society, _journalists cannot, in_
_principle, be released from their duty to obey the ordinary criminal law on the basis that Article 10 affords_
_them protection. Paragraph 2 of Article 10 does not, moreover, guarantee a wholly unrestricted freedom of_
expression even with respect to press coverage of matters of serious public concern (see, for example,
_Bladet Tromsø and Stensaas v Norway (2000) 29 EHRR 125 at [65], and_ _Monnat v Switzerland, no_
73604/01 at [66].” [emphasis added].

143. In Doryforiki Tileorasi Anonymi Etairia v Greece (application 72562/10, 22 February 2018) the court
said (at para 61):

“…journalists who exercise their freedom of expression undertake “duties and responsibilities”… Article 10
_does not guarantee a wholly unrestricted freedom of expression, even with respect to media coverage of_
_matters of serious public concern. In particular, and notwithstanding the vital role played by the media in a_
democratic society, journalists cannot, in principle, be released from their duty to obey the ordinary criminal
_law on the basis that, as journalists, Article 10 affords them a cast-iron defence… In other words, a_


-----

_journalist cannot claim exclusive immunity from criminal liability for the sole reason that, unlike other_
_individuals exercising the right to freedom of expression, the offence in question was committed during the_
_performance of his or her journalistic functions…” [emphasis added]._

144. Depending on the circumstances, the prosecution of journalists for criminal conduct can be
compatible with article 10 of the Convention. We were not referred to examples in this jurisdiction; but they
do include prosecutions for unlawful telephone interception (Phillips v News Group Newspapers Ltd [2012]
_UKSC 28; [2013] 1 AC 1at paras 19 to 21), committal proceedings for breaching court orders (Attorney_
_General v Punch Limited [2002] UKHL 50; [2003] 1 AC 1046) and prosecutions for paying public servants_
for confidential information: _R v France [2016] EWCA Crim 1588; [2016] 4 WLR 175;_ _R v Chapman,_
_Gaffney and Panton_ _[2015] EWCA Crim 539._

145. As to whistle-blowers, in _Halet_ the Grand Chamber of the ECtHR found that the conviction and
€1,000 fine of an employee for the disclosure of information concerning the tax practices of multinational
companies (that the employee had discovered in the course of his employment) amounted to a
disproportionate interference with his rights under article 10 of the Convention. It referred to previous
Strasbourg authority, including the decision of the Grand Chamber in Guja v Moldova (2011) 53 EHRR 16
which was, itself, a whistle-blower case. At para 112 the court said:

“Protection of freedom of expression in the workplace thus constitutes a consistent and well-established
approach in the case-law of the Court, which has gradually identified a requirement of special protection
that, subject to certain conditions, ought to be available to civil servants or employees who, in breach of the
rules applicable to them, disclose confidential information obtained in their workplace. Thus, a body of
case-law has been developed which protects “whistle-blowers”, although the Court has not specifically
used this terminology.”

146. The court said at para 114, that the following factors should be taken into account in deciding
whether, and to what extent, a whistle-blower could rely on article 10 of the Convention: whether or not
alternative channels for the disclosure were available; the public interest in the disclosed information; the
authenticity of the disclosed information; the detriment to the employer; whether the whistle-blower acted in
good faith; and the severity of the sanction.

147. The court gave extensive guidance as to the approach to be taken to each of these factors. In
respect of the public interest in the disclosed information, at paras 133 to 135, it identified certain types of
information that were matters of public interest, including improper conduct by a high-ranking politician,
matters implicating high-ranking officials and affecting the democratic foundations of the State, information
which concerned acts involving “abuse of office”, “improper conduct” and “illegal conduct or wrongdoing”,
and information reporting on “questionable” and “debatable” conduct or practices on the part of the armed
forces. At para 136 it said:

“The Court emphasises that in cases concerning situations in which employees claim the special protection
to which whistle-blowers may be entitled after disclosing information to which they gained access in the
workplace, notwithstanding the fact that they were under an obligation to observe secrecy or a duty of
confidentiality, the public interest capable of serving as a justification for that disclosure cannot be
assessed independently of the duty of confidentiality or of secrecy which has been breached. It also
reiterates that, under Article 10 § 2 of the Convention, prevention of the disclosure of information received
in confidence is one of the grounds expressly provided for permitting a restriction on the exercise of
freedom of expression. In this connection, it is appropriate to note that many secrets are protected by law
for the specific purpose of safeguarding the interests explicitly listed in that Article. This is the case with
regard to national security, territorial integrity or public safety, the prevention of disorder or crime, the
protection of health or morals, maintaining the authority and impartiality of the judiciary or the protection of
the reputation or rights of others. The existence and content of such obligations usually reflect the scope
and importance of the right or interest protected by the statutory duty of secrecy. It follows that the
assessment of the public interest in the disclosure of information covered by a duty of secrecy must
necessarily have regard to the interests that this duty is intended to protect. This is particularly so where


-----

the disclosure involves information concerning not only the employer's activities but also those of third
parties.”

148. It is not necessary to decide whether a prosecution of Ms Manning in the United Kingdom, in
equivalent circumstances, would be a breach of her article 10 rights. The issue we have to decide is
whether it is arguable that the extradition of the applicant would give rise to a real risk of a flagrant denial of
his article 10 rights. We do not consider that it does.

149. First, the only counts that directly concern freedom of expression are counts 15 to 17 (we refer to the
article 10 considerations in respect of the other counts below). And in respect of these counts, the article
10 balance does not clearly fall in the applicant's favour. There is no strong public interest in the publication
or revelation of the names; and strong countervailing interests in protecting them. The authorities show that
the need to protect confidential human sources may be a weighty factor in the article 10 balance: see
_Shayler per Lord Bingham at para 33._

150. The starting point, as Mr Kromberg has explained, is that each of the publication charges (counts 15
to 17) is explicitly limited to documents that contain the names of human intelligence sources. This is clear
from their wording. Indeed, a deliberate decision was made _not_ to charge the applicant in respect of the
publication of any other material by him. The applicant's publication of material which he alleges exposed
the respondent's involvement in serious criminality may well raise strong public interest factors justifying a
high level of protection. But the respondent does not seek to prosecute the applicant in respect of those
matters.

151. The applicant says that he went to great lengths to protect the names of sources, and that he only
published them after they had already been published by others that he was working with, in breach of a
clear understanding that names would be redacted. Those who published the identities of human sources
could only do so because he had provided them with the names. This did not provide the applicant with a
public interest justification for publishing them too.

152. Mr Summers stressed too that no harm has been caused as a result of the disclosure of source
names. We do not accept that is an accurate reflection of the evidence. The evidence is that significant
harm has been caused (including arrests, detention and forced removals). There is also evidence that the
disclosures risked physical harm or death to some of the human sources (see para 61 above). At para 130,
the judge summarised the evidence of harm as follows:

“well over one hundred people were placed at risk from the disclosures and approximately fifty people
sought and received assistance from the US. For some, the US assessed that it was necessary and
advisable for them to flee their home countries and that they, their spouses and their families were assisted
in moving to the US or to safe third countries. Some of the harm suffered was quantifiable, by reference to
their loss of employment or their assets being frozen by the regimes from which they fled, and other harm
was less easy to quantify. It is alleged that Mr. Assange was well-aware of the danger to these informants;
examples of his comments from 2010 are included above. In addition, it is alleged that his disclosures
harmed national defence by deterring informants willing to trust the government to keep their details safe in
the future.”

153. Moreover, quite apart from the weight to be given to the direct (physical) harm that publication may
cause, as the court in Halet explained at paras 145 to 148, harms such as loss of confidence in the State
intelligence services, or damage to business interests or professional reputation can properly be taken into
account in the article 10 balance. This is undoubtedly a factor in this case.

154. Further, whilst a countervailing factor in support of the public interest in publication in any particular
case may be conduct which can properly be characterised as responsible journalism (and this is a factor
that is heavily emphasised in this application, as it was below), there were strong reasons, as the judge
found, to conclude that the applicant's activities did not accord with the “tenets of responsible journalism”.

155. In this context, we refer, as did the judge, to the views expressed by the press itself, including by the
Guardian, the New York Times, El Pais, Der Spiegel and Le Monde. She said at para 132:


-----

“in stark contrast to Mr. Assange's final, indiscriminate disclosure of all of the data, newspapers who had
worked with him from both sides of the Atlantic condemned his decision. These traditional news media
outlets contrasted their own careful editorial decisions not to publish these names, with what they describe
as a “data dump” carried out by Mr Assange. The Guardian published the following report on 2 September
2011…:

“WikiLeaks has published its full archive of 251,000 secret US diplomatic cables without redactions,
potentially exposing thousands of individuals named in the documents to detention, harm or putting their
lives in danger. The move has been strongly condemned by the five previous media partners, the
Guardian, the New York Times, El Pais, Der Spiegel and Le Monde who have worked with WikiLeaks
publishing carefully selected and redacted documents. …. We deplore the decision of WikiLeaks to publish
the unredacted State Department cables which may put sources at risk, the organisations said in a joint
statement… We cannot defend the needless publication of the complete data. Indeed, we are united in
condemning it.”

156. The New York Times magazine had said:

“From the beginning, we agreed that in our articles and in any documents we published from the secret
archive, we would excise material that could put lives at risk. Guided by reporters with extensive
experience in the field, we redacted the names of ordinary citizens, local officials, activists, academics and
others who had spoken to American soldiers or diplomats. We edited out any details that might reveal
ongoing intelligence-gathering operations, military tactics or locations of material that could be used to
fashion terrorist weapons…

[The applicant] was angry that we declined to link our online coverage of the War Logs to the WikiLeaks
Web site, a decision we made because we feared — rightly, as it turned out — that its trove would contain
the names of low-level informants and make them Taliban targets….

As for the risks posed by these releases, they are real. WikiLeaks's first data dump, the publication of the
Afghanistan War Logs, included the names of scores of Afghans that The Times and other news
organizations had carefully purged from our own coverage. Several news organizations, including ours,
reported this dangerous lapse, and months later a Taliban spokesman claimed that Afghan insurgents had
been perusing the WikiLeaks site and making a list. I anticipate, with dread, the day we learn that someone
identified in those documents has been killed.”

157. The applicant now criticises the judge for failing to refer to the overwhelming public interest in
exposing the wrongdoing that was revealed by the material published by him. This submission simply
ignores the confined nature of the prosecution case: see para 150 above. We would add that the applicant
has not identified any public interest in disclosing the names of the covert human sources.

158. As for the remaining counts (counts 1 to 14 and 18) the allegations are of what may be described as
ordinary criminal offences viz, in ordinary language, conspiracy to obtain national security information and
hacking; such conduct is contrary to the criminal law and does not directly concern free expression rights.
As the respondent submits, on the prosecution case, the applicant's role in obtaining classified material
went far beyond the mere setting up of a drop box or other means of depositing classified materials. As the
indictment makes clear, the prosecution allegation is that WikiLeaks and the applicant sought to encourage
theft and hacking by recruiting and working with individuals with access to classified information, or the
ability to conduct malicious computer attacks. Thus, in general terms, the applicant encouraged sources to
circumvent legal safeguards on information; provide that information to WikiLeaks for public dissemination;
and continued the illegal procurement and provision of protected information to WikiLeaks for distribution to
the public. With regard to Ms Manning, she responded to the applicant's solicitation of classified materials.
Further, throughout the time that Ms Manning was providing information to WikiLeaks, she was in direct
contact with the applicant who encouraged her to steal classified documents and provide them to
WikiLeaks. In furtherance of this, the applicant agreed to assist Ms Manning in cracking an encrypted
password hash stored on United States Department of Defense computers. Following direction and
encouragement from the applicant, Ms Manning continued to steal documents from the United States. This
is all ordinary criminal conduct [12] And as we have explained above article 10 does not provide journalists


-----

with an immunity from the ordinary criminal law, even in respect of conduct which is or may be engaged in
for journalistic purposes. The prosecution of such conduct does not therefore arguably involve a flagrant
denial of article 10 of the Convention.

159. We would not necessarily accept the respondent's contention that the decision in _Shayler_ is an
answer, in itself, to this ground of appeal. Lord Bingham made it clear at para 37, that the case did not
concern journalistic publications.

160. However, we agree with the judge that extradition of the applicant would not involve a flagrant denial
of his article 10 rights. In summary, that is because:

i) The First Amendment gives strong protection to freedom of expression, which broadly reflects the
protection afforded by article 10 of the Convention. On the assumption that the applicant is permitted to
rely on the First Amendment, it is not arguable that extradition will give rise to a real risk of a flagrant denial
of his article 10 rights.

ii) Counts 1 to 14 and 18 concern conduct which is contrary to the criminal law and which does not directly
concern free expression rights. The prosecution of such conduct does not involve a flagrant denial of article
10 of the Convention.

iii) Counts 15, 16 and 17 concern the publication of the names of human intelligence sources. There is a
strong public interest in protecting the identities of human intelligence sources, and no countervailing public
interest justification for publication has been identified.

iv) There were strong reasons, as the judge found, to conclude that the applicant's activities did not accord
with the “tenets of responsible journalism”.

161. The applicant seeks to rely, by way of fresh evidence, on a statement of Alan Rusbridger dated 26
August 2022. Mr Rusbridger is the former editor of The Guardian. He draws attention to a statement made
by the Committee to Protect Journalists (of which Mr Rusbridger is a board member), a New York-based
organisation which considers the boundaries of free speech in a digital age. In its statement it warned of
the harmful precedent the prosecution of the applicant could set and the damaging impact this could have
on journalism more generally.

162. The principles regulating the admission of fresh evidence under section 104(4) of the 2003 Act were
discussed by Sir Anthony May, P. in Hungary v Fenyvesi _[[2009] EWHC 231 (Admin); [2009] 4 All ER 324.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WW4-W0S0-Y96Y-G155-00000-00&context=1519360)_
It must be shown that the fresh evidence is evidence which was “not available at the extradition hearing”,
meaning that it was evidence which either did not exist at the time of the hearing, or was not at the disposal
of the party wishing to adduce it and which he could not with reasonable diligence have obtained. In
addition, it must be shown that the evidence would have been decisive in that it would have resulted in the
judge ordering the applicant's discharge under section 87(2).

163. With the greatest of respect to Mr Rusbridger, we do not consider that his statement amounts to fresh
evidence, as it is evidence that the applicant could have adduced before the judge. Nor do we consider she
would have reached a different decision if the evidence had been produced before her. It is essentially the
same as a great deal of evidence that the applicant relied on below.

Ground v) Whether the applicant might be prejudiced at his trial by reason of his nationality

164. As set out above, section 81(b) provides that a person's extradition is barred if it appears that he
might be prejudiced at his trial by reason of his nationality.

165. The applicant relies, in this context, on the statement by Mr Kromberg that the United States
prosecution may argue at trial that “foreign nationals are not entitled to protections under the First
Amendment”. Further, in April 2017, Mike Pompeo (then the director of the CIA, and at the time of the
extradition request, the United States Secretary of State) asserted that the applicant “has no First
Amendment freedoms” because “he is not a US citizen”. It follows, says the applicant, that he might be
prejudiced at his trial by reason of his nationality, meaning that extradition is barred under section 81(b).


-----

166. The respondent submits, first, that any prejudicial statements made by politicians could, if necessary,
be dealt with during the trial to ensure fairness; and secondly, the fact that arguments might be advanced
by the prosecution as to the applicant's status as a foreign national, does not demonstrate that he will be
prejudiced at his trial or that he would be punished on account of his nationality.

167. The judge regarded both the comments of Mr Pompeo, and what may be raised by the prosecution,
as immaterial. In respect of the latter she said (in the context of an issue concerning the Fifth Amendment):

“the prosecution may or may not make this argument before the court. If they do, it appears to relate to the
application of the First Amendment rather than to the general application of the US Constitution; the
argument may be limited to the application of the First Amendment only so far as it applies to national
defence information; and in any event, it will be for a court to determine on its merits. None of this raises a
real risk that a court would find that Mr. Assange will not be protected by the US Constitution in general or
by the due process clause of the Fifth Amendment in particular.”

168. The judge said it would be for the (United States) court to determine the application of the law to the
applicant, and to do so on objective criteria. The applicant had relied on a decision of the United States
Supreme Court in _Agency for International Development v Alliance for Open Society International (2020)_
140 SC 2082. In that case, Justice Kavanaugh, giving the opinion of the court, said “it is long settled as a
matter of American constitutional law that foreign citizens outside United States territory do not possess
rights under the US Constitution.”

169. The judge pointed out that _Open Society concerned the foreign affiliates of the plaintiff, who were_
operating abroad. By contrast, the applicant, at the time he asserts any rights under the United States
Constitution, “will be on US soil facing a criminal trial before a US court”. The judge said she had not been
shown any authority to support the notion that a person in the applicant's position would not have the
protections of the United States Constitution. She said she regarded such a notion as surprising, because
it would enable a United States court to remove due process rights at trial, solely on the grounds of the
defendant's nationality.

170. Before us, the applicant repeats the arguments he advanced before the judge. The respondent
submits that Mr Kromberg was referring to possible arguments of law that may be relied on at a trial in the
United States to define the outer limits of the applicant's right to rely on the First Amendment in any
prosecution. The respondent also submits that the judge was entitled to find, as a matter of fact, that this
was not evidence that the applicant would be deprived of all constitutional rights in the United States. It
says: “[t]here is an obvious difference, in this regard, between a legal process that will judge the availability
of certain rights to defendants and those rights being removed for oppressive or prejudicial reasons”.

171. On this issue, we consider that the applicant has identified a properly arguable ground of appeal.

172. The applicant wishes to argue, at any trial in the United States, that his actions were protected by the
First Amendment. He contends that if he is given First Amendment rights, the prosecution will be stopped.
The First Amendment is therefore of central importance to his defence to the extradition charge. Further, if
he is convicted, he may wish to invoke the First Amendment on the question of sentence. If he is not
permitted to rely on the First Amendment because of his status as a foreign national, he will thereby be
prejudiced (potentially very greatly prejudiced) by reason of his nationality.

173. Nothing in the United States Constitution, including the First Amendment, says that the rights
prescribed by the United States Constitution (as far as they might apply to a criminal trial) are available
only to United States citizens and may not be invoked by non-citizens.

174. The question of whether the United States Constitution may be invoked by the applicant is a question
of foreign law. It is therefore an issue of fact, on which expert evidence would usually be required. There is
no expert evidence on this issue. Instead, the applicant relies on the assertion of Mr Pompeo that he would
not benefit from the protection of the United States Constitution, and the account of Mr Kromberg as to the
evidence that might be advanced at trial.


-----

175. Mr Pompeo's assertion in 2017 does not constitute expert evidence on a question of foreign law and
it is not otherwise relevant to this issue. The judge was right to regard it as immaterial.

176. As to Mr Kromberg, in the context of addressing the applicant's ability to challenge the indictment
before independent federal judges and a jury, Mr Kromberg identified a number of arguments that might be
advanced by the applicant. These included that his conduct was protected by the free speech provisions of
the First Amendment, or that the underlying offences with which he was charged were unconstitutionally
vague, contrary to the Fifth Amendment. He explained the different ways in which such arguments might
be advanced. He then said:

“To be clear, the United States has arguments against these potential challenges to the superseding
indictment, and does not believe that they would have any merit; otherwise, it would not have proceeded
with the charges. Without binding the United States to any position here, however, we could advance a
number of arguments in response to those challenges. …Concerning any First Amendment challenge, the
_United States could argue that foreign nationals are not entitled to protections under the First Amendment,_
_at least as it concerns national defense information, and even were they so entitled, that Assange's_
conduct is unprotected because of his complicity in illegal acts and in publishing the names of innocent
sources to their grave and imminent risk of harm… Concerning any void-for-vagueness claim, the United
States could point out that courts are not to expect statutes to provide “[p]erfect clarity and precise
guidance.” _Williams, 553 U.S. at 304; see also_ _United States v Saunders, 828 F.3d 198, 207 (4th Cir._
2016) (“[A] statute need not spell out every possible factual scenario with 'celestial precision' to avoid being
struck down on vagueness grounds.”). …Regardless of the arguments the United States will ultimately
assert, however, what is important here is that Assange will have an opportunity to challenge the alleged
facts before an independent jury, and challenge the law supporting the charges in the superseding
indictment before independent United States courts. Those courts are most familiar with the nuances of
United States law, and are best suited to address any legal or constitutional challenges that Assange may
have to his prosecution.” [Emphasis added].

177. The judge took this evidence into account, and reached a factual conclusion that the applicant would
not be prejudiced by reason of his nationality. Although this was a factual finding made by the judge, it is “a
question of fact of a peculiar kind” (i.e. as to foreign law) with which an appellate court might more readily
interfere: Parkasho v Singh [1968] P 233per Cairns J at 250.

178. Mr Kromberg is a United States Attorney and federal prosecutor with responsibility for this particular
prosecution. He made a formal sworn declaration on behalf of the respondent and in support of the
extradition request. He put himself forward as able to provide authoritative assistance as to the application
of the First Amendment. It can fairly be assumed that he would not have said that the prosecution “could
argue that foreign nationals are not entitled to protections under the First Amendment” unless that was a
tenable argument that the prosecution was entitled to deploy with a real prospect of success. If such an
argument were to succeed it would (at least arguably) cause the applicant prejudice on the grounds of his
non-US citizenship (and hence, on the grounds of his nationality).

179. It is possible that Mr Kromberg was referring to the principle that is highlighted in _Open Society_
concerning the absence of extra-territorial protection for foreign nationals. That does not necessarily
answer the section 81(b) issue. Although the applicant will be in the United States at the time of his trial,
the events under consideration occurred when he was not in the United States. It is possible that this will
affect the application of the First Amendment to him in a way that differs from its application to a United
States citizen in otherwise identical circumstances.

180. It follows that it is arguable that the applicant might be treated differently at trial on the grounds of his
nationality. Subject to the question of whether this could be addressed by means of an assurance from the
respondent, we would grant leave to appeal on ground v).

Ground vi) Extradition incompatible with article 6 of the Convention (right to a fair trial)

181. The applicant challenged his extradition on the basis that it was incompatible with article 6 of the
Convention, which provides for a right to a fair trial. Article 6 states:


-----

“Right to a fair trial

1. In the determination of… any criminal charge against him, everyone is entitled to a fair and public
hearing within a reasonable time by an independent and impartial tribunal established by law…

2. Everyone charged with a criminal offence shall be presumed innocent until proved guilty according to
law.

…”

182. The applicant's case is that his trial will be unfair having regard to the following factors. First, coercive
plea bargaining (“fuelled by swingeing potential sentences and overloaded indictments”); secondly, a jury
selected from a pool located in an area with a high concentration of defence and intelligence employees
(because the courthouse is just 15 miles away from CIA headquarters); thirdly, a denial of the presumption
of innocence (because of prejudicial denouncements of the applicant made by senior public figures,
including the President), and fourthly, tainted evidence (because of reliance on evidence obtained from Ms
Manning who was subjected to inhuman treatment). The sentencing process would also be flagrantly unfair
for the following reasons. He would or could be sentenced for conduct he has not been charged with (and,
potentially, conduct in respect of which he has been acquitted) following a judicial fact-finding exercise on
the balance of probabilities, based on evidence he will not see and which may have been unlawfully
obtained.

183. The applicant submits that the judge wrongly focused on the fact that there are procedural rules
which require courts to be satisfied that plea agreements are entered into voluntarily. The evidence is that
when faced with a swingeing sentence after trial, defendants willingly and voluntarily enter into plea
agreements “because Hobson's Choice is not a real one”. The plea rate is over 97 percent which is said to
be higher than any other country in the world. The judge's finding in relation to the treatment of Ms
Manning is undermined by the findings of the UN Special Rapporteur who said, in November 2019 that the
detention of Ms Manning “does not constitute a circumscribed sanction for a specific offence, but an openended, progressively severe measure of coercion fulfilling all the constitutive elements of torture or other
cruel, inhuman or degrading treatment or punishment”.

184. Joel Smith for the respondent, submits that the judge was not arguably wrong to reject each of the
complaints made by the applicant as to the fairness of criminal proceedings in the United States. As to the
complaint about the exercising of sentencing powers, he submits that in the absence of a valid specialty
argument the complaint does not approach the flagrancy threshold necessary under article 6 of the
Convention. In _Welsh and another v Secretary of State_ _[2006] EWHC 156 (Admin); [2007] 1 WLR 1281,_
Ouseley J explained that the sentencing procedures about which the applicant complains have been in
place since before 1776, when the United States became independent, and they have never been found to
operate as a bar. Moreover, article 6(2) of the Convention (the presumption of innocence) does not apply
to the sentencing stage of a case. It follows there can be no valid article 6 objection to the burden or
standard of proof applied by the courts of the United States on sentence.

185. The judge said that the issue was whether the applicant had shown that there is a real risk that he will
suffer a flagrant denial of a fair trial in the United States: Soering. She referred to the Sixth Amendment to
the United States Constitution which guarantees fair trial rights, but did not suggest that this was a
sufficient answer to the issues that the applicant had raised.

186. The judge rejected the applicant's arguments in respect of public denouncements of him and the
likely composition of the jury pool. She pointed to evidence as to the procedural guarantees in place to
ensure the impartiality of the jury. These went beyond the procedures that are in place in England and
Wales: jurors can be questioned carefully as to what they know about the case and whether they are able
fairly to discharge their juror oaths; the applicant would have a right to 10 peremptory challenges to jurors
without having to show any cause. As to the system of plea-bargaining, the judge pointed to the conclusion
of the European Court of Human Rights in Babar Ahmad v United Kingdom (2010) 51 EHRR SE6 at para
168:


-----

“…it would appear that plea bargaining is more common in the United States than in the United Kingdom or
other Contracting States. However, it is a common feature of European criminal justice systems for a
defendant to receive a reduction in his or her sentence for a guilty plea in advance of trial or for providing
substantial co-operation to the police or prosecution (for examples of plea bargains in the Court's own case
law see Slavcho Kostov v Bulgaria (28674/03) November 27, 2008 at [17]; Ruciński v Poland (33198/04)
February 20, 2007 at [12]; Albo v Italy (2006) 43 EHRR 27 at [22], February 17, 2005; Erdem v Germany
(2002) 35 EHRR 15). Often, early guilty pleas will require the prosecution and the defence to agree the
basis of that plea. For that reason, the fact that the prosecution or trial judge indicates the sentence which
the defendant would receive after pleading guilty at an early stage and the sentence the defendant would
receive if convicted at trial cannot of itself amount to oppressive conduct. Therefore, there is nothing
unlawful or improper in that process which would raise an issue under art.6 of the Convention.”

187. The judge considered that there was no credible evidence to suggest the indictment had been
deliberately overloaded to put pressure on the applicant to plead guilty as part of a plea bargain:

“229. …Dr Eric Lewis gave an account of the US plea bargaining system, concluding “the combination of
the power of individual prosecutors to reduce or inflate charges and the cudgel of severe sentences
available at trial mean that defendants who choose not to waive their right to trial face much higher
sentences than those who accept guilty plea arrangements”.

…

232. Mr Kromberg confirmed the role of the court in overseeing this process. He stated that the US
Constitution requires that a guilty plea is a voluntary expression a defendant's choice. Pursuant to Rule
11(b)(2) of the Federal Rules of Criminal Procedure (FRCP), a trial court is required to ensure that a guilty
plea is made voluntarily and rule 11(b)(3) of the FRCP prohibits a US federal court from entering a
judgment upon a guilty plea without determining that there is a factual basis for it. I am not aware of any
attempt by prosecutors to enter into discussions with Mr Assange about sentence at this early stage and
there is no evidence that a plea agreement has been offered to him.

233. In relation to the submission that the indictment is overloaded, the defence rely on the evidence of
Eric Lewis who stated:

“But the evidence to date demonstrates that the DOJ has every intention of punishing Mr Assange as
harshly as possible and that it has the power to do so. The DOJ initiated a single five-year maximum
charge against Mr Assange over seven years after the alleged offense (an indictment which remained
under seal until April 2019), and thereafter it added 17 counts of violations of the Espionage Act for the
same underlying conduct as the original single charge. Indeed, just in the last month, the DOJ filed a
second superseding indictment which added new conspiracy allegations. Presumably such information to
buttress the non-Espionage Act counts was included to have additional “relevant conduct” (see below) that
could be used to enhance sentencing on counts on which Mr Assange may be convicted, even if he is
acquitted on others”.

234. However, there is no credible evidence to support this opinion. For reasons already given, I have
found no reason to find that federal prosecutors have improper motives for bringing these charges or to
find that they have acted contrary to their obligations and responsibilities of impartiality and fairness.”

188. The judge considered that there was no evidential foundation for the defence submission that the
evidence secured from Ms Manning was obtained as a result of inhuman treatment or torture.

189. As to the sentencing practice of United States courts, the judge referred to the decision of Ouseley J
in Welsh at paras 112 to 113:

“112. It certainly seems alien to English criminal procedure that the sentence for one offence can be
enhanced by reference to matters so serious as those engaged here without a trial, and that is a matter
which had concerned the Supreme Court, in the context of mandatory increases above the standard
statutory range.


-----

113…It is possible to disagree with its merits or effects, but the approach is a legitimate one to what
constitutes punishment for the offence of which someone has been convicted. In a domestic US case, in
which the same procedure is adopted, they are clearly seeking to punish the defendant for the crime of
which he has been convicted. The fact that they can take a broader approach to what is relevant to
sentencing than the UK Courts might do, and adopt a different procedure for determining facts does not
mean that there is a breach of specialty. They are still punishing the defendant, and certainly on their
legitimate perception, for the offence for which the defendant has been tried, the extradition offence in an
extradition case.”

190. The judge observed that if the applicant was right in his contention that this sentencing practice
rendered a trial unfair, it would follow that all extradition requests by the United States were doomed to
failure. She said: “[t]his cannot be the case.”

191. We, like the judge, consider the article 6 objections raised by the applicant have no arguable merit,
from which it follows that it is not arguable that his extradition would give rise to a flagrant denial of his fair
trial rights.

192. The starting point here is that extradition involves a recognition that different jurisdictions legitimately
take different approaches to criminal procedure. The fact that other jurisdictions differ from this jurisdiction
in their procedural approach to criminal trials does not in itself mean that their (different) procedures are
unfair or a flagrant breach of article 6 of the Convention. In England and Wales, for example, an indication
of the sentence that might be imposed following a guilty plea may only be given where stringent
safeguards are applied: see _R v Goodyear_ _[2005] EWCA Crim 888; [2005] 1 WLR 2532. The system of_
plea bargaining in the United States is different, but not unfair in the context of extradition: see the passage
from _Barbar Ahmad_ set out above. We were not referred to any authority to the contrary, let alone any
where generic complaints of this nature – either here or in Strasbourg – have been upheld.

193. We take the objections under this head one by one. We turn first to the submission that the
indictment was deliberately overloaded to put pressure on the applicant to plead guilty as part of a plea
bargain. This assertion is not sustainable on the evidence. Mr Kromberg explained the rationale for the
charges (including the expansion of the indictment) in his declarations in support of the extradition request.
As we have said, the applicant does not accuse Mr Kromberg of bad faith.

194. Next, jury selection, and the potential impact of public statements about the applicant. This objection
is not sustainable on the evidence either. The evidence is that the system in place in the United States for
jury selection, and in particular to ensure that jurors are fair and impartial is at least as rigorous and fair as
that in England and Wales. The fact that many CIA or government employees live in the general area of
the court, or that the applicant has been the subject of public verbal attacks by politicians, does not mean
that it will be impossible to find twelve jurors who do not work for (or have any connection with) the CIA and
who will be able to fulfil their jury oath; that is, to faithfully try the defendant and return true verdicts
according to the evidence. As the judge also pointed out at para 227 of her decision, the potential jury pool
in this connection is huge. There are 1,100,000 people living in Fairfax County alone; and the jury could be
drawn from any of six counties in the relevant area (the Alexandria Division of the Eastern District of
Virginia). As to public statements, the judge was right to rely on the fact that all prospective jurors will be
questioned carefully as to what they had seen, read or heard about the case, as part of the jury selection
process. Nor is it arguable that there would be a flagrant denial of the applicant's fair trial rights because
the evidence of Ms Manning was “tainted” in the manner alleged. As the judge correctly identified, there
was no evidential basis for this allegation, which therefore amounted to mere assertion. The applicant has
not identified what evidence from Ms Manning would be advanced, let alone how it was obtained by
torture; nor has he said why he would not be able to challenge its admissibility on that basis, in a United
States court.

195. Next, sentencing. The applicant has not identified any authority to support the proposition that, in
general, extradition is incompatible with article 6 of the Convention because of the (different) approach to
sentencing in the United States. Upholding a generic submission to that effect would have the
consequence, as the judge pointed out, that no extradition to the United States could take place. Yet there


-----

have been many extraditions to the United States including in cases where such extraditions have been
challenged in the courts. See for example, _Barbar Ahmad, Harkins and others v USA_ _[2011] EWHC 920_
_(Admin), McKinnon v Government of the United States of America_ _[2008] UKHL 59; [2008] 1 WLR 1739,_
_Shaw v Government of the United States of America_ _[[2014] EWHC 4654 (Admin), and paragraph 441 of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F9R-BJ61-F0JY-C2S7-00000-00&context=1519360)_
the House of Lords Select Committee on Extradition Law.

196. One issue in respect of the sentencing process gained greater prominence before us than it had
before the judge. It concerns the possibility that the applicant might be sentenced for conduct which has
been deliberately excluded from the scope of the second superseding indictment. The potential for a
sentence “enhancement” is illustrated by _United States of America v Garcia_ (2000) 208 F 3d 1258, a
decision of the United States Court of Appeals, Eleventh Circuit. In that case, the defendant had been
extradited to the United States on charges of possession of cannabis, conspiracy to supply cannabis, and
use of a firearm. He pleaded guilty to the charges. In sentencing him, the court took account of other
cannabis supply beyond that to which he had pleaded guilty. The court also took into account that on the
court's finding, the defendant had murdered a distributor of cannabis who had not paid him a debt. The
sentence was upheld on appeal. Senior Judge Watson said: “The short answer is that defendant was not
punished for crimes other than those for which he was extradited because under our law, the consideration
of other conduct in the sentencing process is legally and conceptually a part of the punishment for the
indicted crimes and within the limits set for those crimes”.

197. The first thing to note is that this aspect of the applicant's case barely featured in the arguments
made to the judge below. And where the applicant adopted what appeared to be a wide-ranging approach
to the case, it is not surprising that the point may have been lost. The applicant's reference to “unjust
sentencing procedure” was contained in one short paragraph in its closing submissions (of 252 pages). But
that paragraph did not identify any particular feature of this case which might give rise to an article 6 issue.
Nor did the closing submissions identify any particular conduct which would or could result in an increase
(or “enhancement”) to the applicant's sentence. In those circumstances, it is not surprising that the judge
said that the defence had not identified any particular conduct outside the conduct in the request which
“would result in a court “upwardly enhancing” Mr. Assange's sentence.”

198. This issue however received more attention before us. And the applicant has referred to evidence
that may be material in this context (not referred to in his closing submissions to the judge, but which the
judge accurately summarised in the annex to her decision). In his witness statement, Dr Lewis said:

“'...Other Wikileaks' publications could form part of this 'relevant conduct' including publication of the
Detainee Policies in 2012, revelations of US espionage against European leaders including Chancellor
Merkel and President Sarkozy, the 2015 revelations of espionage against the European Commission, the
European Central Bank and French industry, and the 2017 publication of US spying during the French
presidential election campaign. The publication of the DNC emails during the 2016 US presidential election
may also be considered. If the US government believes that publishing leaked documents is a crime, as is
evident from its indictment of Mr Assange, then it seems reasonably likely that it will seek to enhance his
sentence with evidence of similar conduct...'.”

199. First, in substance this is a complaint that the applicant might be “dealt with” in the United States for
offences other than those in respect of which he has been extradited. We agree with the respondent that
this amounts to a specialty complaint which falls to be addressed under section 95 of the 2003 Act. The
applicant does not now pursue a specialty complaint, no doubt recognising that the authorities show that
such a complaint is without merit.

200. Secondly, there is no challenge to the prosecutor's bona fides. As we have explained, Mr Kromberg
has emphasised that the second superseding indictment has been specifically limited to exclude from the
indictment, any national security material published by the applicant _save for_ that which contained the
names of covert human sources. It would be inconsistent with that approach for the United States court to
take account of such material when it comes to sentence. Whilst there is a theoretical possibility that a
United States court might impose an enhanced sentence, there is no evidence that it would do so in the


-----

particular circumstances of this case, where the indictment has been deliberately constrained in the way
that we have explained.

201. Thirdly, the core of the objection here might be said to be the unfairness that would arise were the
applicant to be sentenced for conduct which the prosecution have specifically and deliberately excluded
from the extradition request (in recognition no doubt of the objections that might otherwise be made under
article 10 if the prosecution encompassed all the intelligence material published by the applicant). When
considering the application of article 6 of the Convention however, we can proceed on the basis that the
applicant will not be sentenced in a way that gives rise to a risk of a flagrant denial of his article 10 rights. If
the assurance we have referred to at para 180 above is given, then the applicant's First Amendment rights
will be taken into account throughout the proceedings, including sentence. If the assurance is not given,
and the matter falls to be considered by the full court, it remains the case (whatever view the full court
takes of the point that we consider to be arguable) that the full court will only allow the applicant's
extradition to proceed if there is no risk of a flagrant denial of his free expression rights, whether in the
prosecution itself or in any sentencing process.

202. Fourthly, it would be necessary at a substantive appeal hearing for the applicant to show that there is
a real risk of a flagrant denial of his fair trial rights if he is extradited. The fact that, on sentence, there may
be the possibility of an argument as to the matters that fall to be taken into account, having regard to First
Amendment rights and the circumstances leading to the extradition, does not begin to meet the flagrancy
threshold.

203. We therefore refuse leave to appeal on this ground.

Ground vii) Extradition incompatible with articles 2 and 3 of the Convention (right to life; prohibition of inhuman or
degrading treatment or punishment)

204. The applicant's case is that fresh evidence (the September 2021 Yahoo News article, and the
consequential evidence from Mr Dratel and witness 2: see para 72 above) shows that his extradition would
be incompatible with the right to life under article 2 of the Convention and/or the prohibition of inhuman or
degrading treatment or punishment under article 3 of the Convention.

205. The applicant did not rely on articles 2 and 3 of the Convention as a ground for objecting to
extradition on this issue at the hearing below. He did rely on the allegations regarding United States
interference in the Ecuadorian Embassy in support of his contention that the prosecution of the applicant is
politically motivated. The judge considered the evidence put before her by the parties. She decided it was
not appropriate to make findings of fact as to these allegations for a number of reasons: the matter was
being investigated in Spain; the material before her amounted to partial information; there was a need for
caution, and she did not have access to the underlying evidence. Critically, she found that _if the United_
States was involved in surveillance of the embassy, there was no reason to assume that this surveillance
was related to these proceedings.

206. The applicant now relies on the September 2021 Yahoo News article, and the evidence from Mr
Dratel and witness 2 as fresh evidence to support an argument that his extradition would be incompatible
with articles 2 and 3 of the Convention. He argues that “[t]he Strasbourg Court might foreseeably take a
different view of what may properly be inferred for the future in a state where, from evidence from former
United States government officials, the sitting United States President can be party to / responsible for
plans for the applicant's extra-judicial murder”. He seeks to adduce the fresh evidence and renew his
application for leave to appeal so that he has exhausted his domestic remedies in respect of articles 2 and
3 of the Convention.

207. The respondent submits that the September 2021 article from Yahoo News is simply another
recitation of opinion by journalists on matters that were considered by the judge. The article merely repeats
the assertion that the CIA were considering rendition of the applicant from the embassy, an assertion that
the applicant had already relied on before the judge. The judge was satisfied that such matters did not
provide a basis for refusing extradition. Further, the affidavit of Mr Dratel, and the second statement of
witness 2, are inadmissible and irrelevant because they merely provide commentary on the Yahoo article.


-----

208. This ground of appeal is contingent on an application to adduce evidence that was not before the
judge. We have summarised at para 162 above the principles regulating the admission of fresh evidence
under section 104(4) of the 2003 Act, as explained in Fenyvesi. In this context, it must be shown that if this
material had been before the judge, she would have decided that the extradition of the applicant would be
incompatible with article 2 or 3 of the Convention.

209. The fresh evidence is similar to the evidence that was before the judge, including from witness 2, and
expands upon that evidence in certain respects (on the basis that it alleges the CIA planned to kidnap
and/or assassinate and/or rendition the applicant, not merely to poison him). Plainly, these are allegations
of the utmost seriousness. We are satisfied however that the _Fenyvesi_ test is not met. The relevant
question here is would the judge have discharged the applicant on article 2 and/or 3 grounds if the fresh
evidence had been before her. In our view, it is not arguable that she would have done so.

210. The judge did not reject the evidence that the applicant had adduced to similar effect as untrue and
the original allegations were (by some margin) serious enough to bar extradition, if the alleged misconduct
was in any way connected to the extradition proceedings. The judge's critical finding however is that there
was nothing to show that the conduct in relation to the Embassy was _connected_ to the _extradition_
proceedings. The new evidence does not change that. On the face of the allegations (on the evidence
before the judge and the fresh evidence) the contemplation of extreme measures against the applicant
(whether poisoning for example or rendition) were a response to the fear that the applicant might flee to
Russia. The short answer to this, is that the rationale for such conduct is removed if the applicant is
extradited. Extradition would result in him being lawfully in the custody of the United States authorities, and
the reasons (if they can be called that) for rendition or kidnap or assassination then fall away.

211. It follows that we decline to admit the fresh evidence. Since this proposed new ground is based solely
on that evidence, we refuse leave to appeal on this ground.

The grounds of appeal under section 108 of the 2003 Act

Ground viii) Decision of Secretary of State: UK-US Extradition treaty

212. As set out above, section 70 of the 2003 Act makes provision for the Secretary of State to certify an
extradition request as being valid.

213. Mr Fitzgerald submits that the extradition request is incompatible with the Treaty because it seeks the
extradition of the applicant for a “political offense”, contrary to article 4 of the Treaty. He says that the
Secretary of State was therefore required by the Treaty to decline the request. The Secretary of State's
answer when deciding the request for extradition was that the 2003 Act does not make provision for the
Secretary of State to decline to order extradition in these circumstances. Mr Fitzgerald submits it would be
surprising and contrary to the rule of law if the Treaty could be overridden in this way. The 2003 Act does
not expressly say that the Treaty may not be taken into account. The Secretary of State has previously
recognised that there is a residual jurisdiction: following the decision in _McKinnon v Government of the_
_United States of America_ _[2008] UKHL 59; [2008] 1 WLR 1739, the extradition of Mr McKinnon was_
refused by the Secretary of State on human rights grounds, even though the 2003 Act did not permit the
Secretary of State to take human rights grounds into account. So too here, it is open to the Secretary of
State to refuse extradition on the ground that extradition is incompatible with the Treaty.

214. Ben Watson KC, for the Secretary of State, adopted the submissions advanced by the respondent on
ground i). He says that the Treaty operates on the international plane and is not justiciable in the courts.
The 2003 Act provides a complete code for determining whether the applicant should be extradited. The
Secretary of State is required to comply with the terms of the 2003 Act, and those terms do not give her
any power to take account of the Treaty. Even if the Secretary of State considers that an extradition
request is clearly in breach of the Treaty, and even if an extradition request by the United Kingdom in
equivalent circumstances would clearly be refused by the United States, the Secretary of State is still
required by the 2003 Act to declare that the extradition request is “valid” and to order extradition.


-----

215. The difficulty for the applicant in relation to this aspect of the case is that the Treaty is not
incorporated into the laws of the United Kingdom and is not enforceable by the court: see paras 86 to 89
above. And the duty of the court is to enforce the law prescribed by Parliament in the 2003 Act. The
statutory scheme does not permit the Secretary of State to refuse an extradition request on the grounds
that it is incompatible with the Treaty. Subject to exceptions that do not here apply, section 70 requires the
Secretary of State to certify an extradition request as “valid” if it is made in the approved way and contains
the required statement. This request was made in the approved way. It contains the required statement.
The contrary is not suggested. The Secretary of State was therefore required, by primary legislation, to
certify the request as “valid”. She had no residual discretion. She had no power to refuse the request even
if she considered that it did not comply with the Treaty.

216. The Secretary of State's decision, once the case was sent to her under section 87(3), was regulated
by section 93. Nothing in section 93 permitted the Secretary of State to take account of the terms of the
Treaty. Nothing in section 93 permitted the Secretary of State to refuse extradition on the grounds that it is
incompatible with the Treaty. The Secretary of State was obliged to consider (and to consider only)
whether she was prohibited from ordering the applicant's extradition under sections 94, 95, 96 and 96A. In
the event that she was not prohibited from ordering the applicant's extradition under any of those
provisions then she was required to order his extradition (subject to the exceptions in section 93(4), which
do not apply here).

217. The jurisdiction that was exercised in _McKinnon stemmed from the_ _[Human Rights Act 1998. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
Secretary of State is a public authority, and (subject to contrary primary legislation) is required to act in
accordance with Convention rights when making an extradition decision: section 6(1) of the 1998 Act. So
there was primary legislation (albeit not the 2003 Act) that gave rise to a residual obligation to refuse
extradition. That jurisdiction no longer exists, because section 70(11) of the 2003 Act (inserted by the
_[Crime and Courts Act 2013) now provides that “[t]he Secretary of State is not to consider whether the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:58B7-YS11-DYCN-C4CF-00000-00&context=1519360)_
extradition would be compatible with [Convention rights]”. Mr Fitzgerald has not identified any legislative
provision that would permit the Secretary of State to take the Treaty provisions into account.

218. We therefore refuse leave to appeal on ground viii).

Ground ix) Extradition barred because insufficient specialty/death penalty protection

219. Section 93(2) of the 2003 Act (see para 31 above) required the Secretary of State to decide if she
was prohibited from ordering the applicant's extradition under section 94 (death penalty) or section 95
(speciality). If she was so prohibited, the Secretary of State was required to order the applicant's discharge.
If not (and subject to exceptions that do not apply) she was required to order the applicant's extradition to
the United States.

220. Section 94 states:

“Death penalty

(1) The Secretary of State must not order a person's extradition to a category 2 territory if he could be, will
be or has been sentenced to death for the offence concerned in the category 2 territory.

(2) Subsection (1) does not apply if the Secretary of State receives a written assurance which he
considers adequate that a sentence of death
(a) will not be imposed, or

(b) will not be carried out (if imposed).”

221. Section 95 states:

“Speciality

(1) The Secretary of State must not order a person's extradition to a category 2 territory if there are no
speciality arrangements with the category 2 territory.


-----

(3) There are speciality arrangements with a category 2 territory if (and only if) under the law of that
territory or arrangements made between it and the United Kingdom a person who is extradited to the
territory from the United Kingdom may be dealt with in the territory for an offence committed before his
extradition only if—

(a) the offence is one falling within subsection (4), or

(b) he is first given an opportunity to leave the territory.

(4) The offences are—

(a) the offence in respect of which the person is extradited;

(b) an extradition offence disclosed by the same facts as that offence, other than one in respect of which a
sentence of death could be imposed;

(c) an extradition offence in respect of which the Secretary of State consents to the person being dealt
with;

(d) an offence in respect of which the person waives the right that he would have (but for this paragraph)
not to be dealt with for the offence.

…”

222. Article 7 of the Treaty says:

“Capital Punishment

When the offense for which extradition is sought is punishable by death under the laws in the Requesting
State and is not punishable by death under the laws in the Requested State, the executive authority in the
Requested State may refuse extradition unless the Requesting State provides an assurance that the death
penalty will not be imposed or, if imposed, will not be carried out.”

223. The applicant accepts that none of the offences for which extradition is sought carry the death
penalty. He contends, however, that the facts which are alleged against him could lead to a charge of
aiding and abetting treason under 18 USC paragraph 2381 or espionage under 18 USC paragraph 794,
both of which are capital offences. He points to evidence that United States Government officials, including
a former United States President (who is also a potential candidate for the forthcoming Presidential
elections) have called for him to be subject to the death penalty:

i) On 2 December 2010, Mr Donald Trump (before his election as President in 2017) was interviewed and
asked in the context of a discussion about WikiLeaks, whether he had anything to do with the leaking of the
documents. He responded “No, but I think it was disgraceful… I think there should be like a death penalty
or something.” It was suggested that this may have been a discussion about taxes. We have viewed the
video. It is sufficiently clear (at least for the purposes of this leave application) that it was a discussion
about the WikiLeaks leaking of documents.

ii) An article in The Telegraph on 30 November 2010 reported that Sarah Palin, a former Vice-Presidential
candidate, considered that the applicant “should be hunted down just like al-Qaeda and Taliban leaders”.

iii) An article in The Guardian on 1 December 2010 reported that Mick Huckabee, the Republican
candidate for the 2010 Presidential election “wants the person responsible for the WikiLeaks cables to face
capital punishment for treason”.

iv) An article in The Telegraph on 10 January 2011 reported “[l]eading US political figures have called for
the death penalty to be imposed on the person who leaked sensitive documents to whistle-blower website
WikiLeaks”.

224. The Secretary of State says that the applicant's argument is speculative and points out that he did not
argue before the judge that extradition was incompatible with article 3 of the Convention because of the
potential for the imposition of the death penalty. He is not currently charged with any offence that carries
the death penalty. Although some public figures have suggested that he should be charged with a capital


-----

offence, that does not afford a proper basis to suggest that he is at risk of the death penalty. Further, the
death penalty would be contrary to the spirit of the assurance that has already been provided: that the
respondent would, if requested, agree to the applicant serving his sentence in Australia [13].

225. We consider that this ground of appeal is arguable.

226. The Secretary of State is right that the applicant did not contend before the judge that extradition was
barred because of a risk of the imposition of the death penalty, contrary to articles 2 and 3 of the
Convention. Article 2 protects the right to life, but is subject to an exception for “the execution of a sentence
of a court following his conviction of a crime for which this penalty is provided by law.” Article 1 of the
Thirteenth Protocol does prohibit the death penalty. Arguably, it has the effect of abrogating the death
penalty exception in article 2(1): Oclan v Turkey (2005) 41 EHRR 45 at para 164. Article 1 of the Thirteenth
Protocol is, anyway, itself a Convention right within the meaning of the _[Human Rights Act 1998 (section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
1(1)(c)) which may therefore be directly invoked as an objection to extradition under section 87 of the 2003
Act. Either way, we agree with Mr Watson that the applicant could have raised this as an issue before the
judge.

227. We do not, however, agree with Mr Watson's submission that the fact that the applicant did not do so
precludes a challenge to the Secretary of State's decision. The Secretary of State had an explicit statutory
obligation not to order the applicant's extradition if he could be sentenced to death for the offence
concerned, or if he could be charged with an extradition offence disclosed by the same facts in respect of
which a sentence of death could be imposed: sections 93(2)(a), 93(2)(b), 94(1), 95(3)(a), 96(5)(b). The
applicant has (subject to leave) a right to appeal against the Secretary of State's decision: section 108(1),
(3). The court may allow the appeal if the Secretary of State was obliged not to order the applicant's
extradition: section 109(1), (3). None of that is conditional on the applicant having raised the point before
the judge.

228. Article 7 of the Treaty envisages that extradition may take place for capital offences, but only where
an assurance is in place that the death penalty will not be imposed (or, if imposed, will not be carried out).
No such assurance is in place in this case, but breach of the Treaty does not provide a ground for refusing
extradition (for the reasons explained under grounds i) and viii)); and once extradition has taken place it is
by no means clear that the applicant would be able to rely on the Treaty to prevent the addition of a capital
charge.

229. The critical issue is whether, arguably, the death penalty “could be” imposed, such that extradition is
contrary to section 94(1) and/or 95(3)(a) and (4)(b). The fact that political leaders have called for the death
penalty does not, in itself, mean that the death penalty could be imposed, or that extradition would arguably
be incompatible with sections 94 and 95.

230. Paragraph 2 of the existing assurance states:

“Pursuant to the terms of the Council of Europe Convention on the Transfer of Sentenced Persons (COE
Convention), to which both the United States and Australia are parties, if Mr Assange is convicted in the
United States, he will be eligible, following conviction, sentencing and the conclusion of any appeals, to
apply for a prisoner transfer to Australia to serve his U.S. sentence. Should Mr. Assange submit such a
transfer application, the United States hereby agrees to consent to the transfer. Transfer will then follow, at
such time as Australia provides its consent to transfer under the COE Convention.”

231. We agree with Mr Watson that the imposition of the death penalty would be contrary to the “spirit” of
this assurance. It is, however, conceivable that the assurance might be interpreted narrowly by the
respondent, so as not to preclude the imposition of the death penalty. Section 95(4)(b) applies to the
imposition of the penalty rather than the carrying out of the death penalty, so protection is required if the
penalty could be imposed even if it could not be carried out. Nothing in the existing assurance explicitly
prevents the imposition of the death penalty.

232. In the course of argument, and in answer to direct questions from the court, Mr Watson accepted
that:


-----

i) The facts alleged against the applicant could sustain a charge of aiding or abetting treason, or
espionage.

ii) If the applicant is extradited, there is nothing to prevent a charge of aiding or abetting treason, or a
charge of espionage, from being added to the indictment.

iii) The death penalty is available on conviction for aiding or abetting treason, or espionage.

iv) There are no arrangements in place to prevent the imposition of the death penalty.

v) The existing assurance does not explicitly prevent the imposition of the death penalty.

233. It is not necessary, for the purposes of this leave decision, to identify the precise relationship between
sections 94(1) and sections 95(3)(a) and (4)(b), the precise scope of their protection, or the threshold risk
that must exist before they are engaged. It is sufficient to record that Mr Summers described them as a
“double lock” against the death penalty. That seems to us to be a fair description. It is (at least) arguable
that they require the Secretary of State to refuse to extradite in any case where the death penalty “could
be” imposed (whether for the extradition offence or for an offence disclosed by the same facts as the
extradition offence). It is (at least) arguable that that test is met here, for these cumulative reasons: the
potential, on the facts, for capital charges to be laid; the calls for the imposition of the death penalty by
leading politicians and other public figures; the fact that the Treaty does not preclude extradition for death
penalty charges, and the fact that the existing assurance does not explicitly cover the death penalty.

234. The Secretary of State's decision letter says that the Secretary of State has concluded “[a]fter careful
consideration of the matters raised… that she is not prohibited from ordering [the applicant's extradition]
under [section 93(2), read with sections 94 and/or 95 of the Act].” The reasoning was that the “offences
concerned… do not carry the death penalty” and because “there are specialty arrangements with the
United States of America” since “the 'Rule of Specialty' is set out in Article 18 of the extradition treaty
between the United Kingdom and the United States.” That reasoning does not engage with the applicant's
concern about the potential for the addition of capital charges. It is not sufficient to defeat the application
for leave to appeal.

235. Accordingly, subject to the provision of appropriate assurances, we would grant leave to appeal on
this ground.

_Assurances_

236. For the reasons given above, grounds iv), v) and ix) are each arguable grounds of appeal.

237. The concerns that arise under these grounds may be capable of being addressed by assurances
(that the applicant is permitted to rely on the First Amendment, that the applicant is not prejudiced at trial
(including sentence) by reason of his nationality, that he is afforded the same First Amendment protections
as a United States citizen, and that the death penalty is not imposed). In _Government of the USA v_
_Assange Lord Burnett CJ and Holroyde LJ said, at para 42:_

“a court hearing an extradition case, whether at first instance or on appeal, has the power to receive and
consider assurances whenever they are offered by a requesting state… If, however, a court were to refuse
to entertain an offer of assurances solely on the ground that the assurances had been offered at a late
stage, the result might be a windfall to an alleged or convicted criminal, which would defeat the public
interest in extradition. Moreover… a refusal to accept the assurances in this case, on the ground that they
had been offered too late, would be likely to lead only to delay and duplication of proceedings: if the appeal
were dismissed on that basis, it would be open to the USA to make a fresh request for extradition and to
put forward from the outset the assurances now offered in this appeal, subject, of course, to properly
available abuse arguments.”

_Outcome_

238. We grant the applicant's application to amend the grounds of appeal. We refuse the applicant's
application to adduce fresh evidence.


-----

239. Unless satisfactory assurances are provided by the respondents, we will grant leave to appeal on
grounds iv) (extradition incompatible with the right to freedom of expression under article 10 of the
Convention), v) (extradition barred by section 81(b) of the 2003 Act because the applicant might be
prejudiced on grounds of nationality) and ix) (extradition barred by sections 93 to 95 of the 2003 Act
because of inadequate specialty/death penalty protection).

240. We adjourn the renewed application for leave to appeal on grounds iv), v) and ix). The adjournment is
for a period of 55 days until 20 May 2024, subject to the following directions:

i) The respondents have permission to file any assurances with the court by 16 April 2024.

ii) In the event that no assurances are filed by then, leave to appeal will be granted on grounds iv), v) and
ix).

iii) In the event that assurances are filed by 16 April 2024, the parties have permission to file further written
submissions on the issue of leave to appeal, in the light of the assurances, such submissions to be filed by
the applicant by 30 April 2024, and by the respondent and the Secretary of State by 14 May 2024.

iv) In the event that assurances are filed by 16 April 2024, we will consider the question of leave to appeal
at a hearing on 20 May 2024.

241. We refuse the renewed application for leave to appeal on grounds i) and viii) (extradition incompatible
with the Treaty), ii) (extradition barred by section 81(a) because it is for the purpose of a prosecution for
political opinion), iii) (extradition incompatible with article 7 of the Convention), vi) (extradition incompatible
with the right to a fair trial under article 6 of the Convention) and vii) (extradition incompatible with articles 2
and 3 of the Convention).

**End of Document**


-----

