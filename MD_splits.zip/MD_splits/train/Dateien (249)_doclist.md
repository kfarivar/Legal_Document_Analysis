**User Name: =**

**Date and Time: = 2024-10-16**

**Job Number: = 236111572**

# Documents (249)

**Client/Matter: -None-**

**Search Terms: "modern slavery"**

**Search Type: NaturalAnd**

**Content Type** **Narrowed by**

cases-uk -None
1. Taiwo v Olaigbe and another ; Onu v Akwiwu and another - (2016) 43 BHRC 54

2. Taiwo v Olaigbe and another; Onu v Akwiwu and another - [2017] 1 All ER 985

3. ZV (Lithuania) v Secretary of State for the Home Department

4. AL-MALKI and another (respondents) v. REYES and another (appellants) - [2015] IRLR
289

5. Al-Malki and another v Reyes and another - [2018] 1 All ER 629

6. Al-Malki and others v Reyes and another - [2016] 2 All ER 136

7. Al-Malki v Reyes and another - [2018] 1 LRC 613

8. A Local Authority v C (by his litigation friend) and others (Institute of Registered Case
Managers and others intervening) - 183 BMLR 66

9. AS (Safety of Kabul) (CG)

10. Basfar v Wong


-----

11. Director of Public Prosecutions v Edosa and Enoghaghase

12. Elphysic Ltd and other companies v Revenue and Customs Commissioners

13. Elphysic Ltd and others v Revenue and Customs Commissioners - [2024] SFTD 873

14. EOG (anonymity order made) v Secretary of State for the Home Department - [2020]
All ER (D) 37 (Dec)

15. HD (Trafficked women)

16. Highlights: November 2016

17. HOUNGA (appellant) v. ALLEN and another (respondents) - [2014] IRLR 811

18. Hounga v Allen and another - [2014] 4 All ER 595

19. Hounga v Allen and another - (2014) 39 BHRC 412

20. *Hounga v Allen and another - [2014] All ER (D) 289 (Jul)

21. JR199 and others' Application for Judicial Review

22. *Medical Justice and others v Secretary of State for the Home Department (Equality
and Human Rights Commission intervening)

23. MILLER v HM ADVOCATE - 2019 JC 61

24. MR Petitioner for JUDICIAL REVIEW

25. MS (Trafficking - Tribunal's Powers - Art. 4 ECHR)

26. M v R

27. MYRNA REBUJIO PASIAN Petitioner against THE SECRETARY OF STATE FOR THE HOME
DEPARTMENT Respondent


-----

28. Ngoc Son Do v Czech Republic

29. NN v Secretary of State for the Home Department; LP v Secretary of State for the
Home Department

30. NV (Vietnam) v Distirct Court in Plezen-Mesto, Czech Republic and another

31. Pasian v Secretary of State for the Home Department - 2022 Scot (D) 29/2

32. R (AB (By His Litigation Friend CD)) v Uxbridge Youth Court and Another - [2023]
Costs LR 1731

33. Rantsev v Cyprus and another (App. No. 25965/04) - [2010] ECHR 25965/04

34. Rantsev v Cyprus and Russia - (2010) 28 BHRC 313

35. Re A (Wardship: 17-Year Old: Section 20 Accommodation) - [2019] 1 FLR 105

36. *Reyes and another v Al-Malki and another (Secretary of State for Foreign and
Commonwealth Affairs and others intervening) - [2015] All ER (D) 56 (Feb)

37. R (on the application of AAA (Syria) and others) v Secretary of State for the Home
Department (United Nations High Commissioner for Refugees intervening) and other
cases

38. R (on the application of AB (by his litigation friend CD)) v Uxbridge Youth Court

39. R (on the application of Adesanya) v Secretary of State for the Home Department

40. R (on the application of BT) v Secretary of State for the Home Department

41. R (on the application of CP (Vietnam)) v Secretary of State for the Home Department 
[2018] All ER (D) 07 (Sep)

42. R (on the application of EM) v Secretary of State for the Home Department

43. R (on the application of FH) v Secretary of State for the Home Department


-----

44. *R (on the application of Galdikas and others) v Secretary of State for the Home
Department - [2016] All ER (D) 181 (Apr)

45. R (on the application of HS) v Secretary of State for the Home Department

46. R (on the application of IJ (Kosovo)) v Secretary of State for the Home Department

47. R (on the application of Medical Justice and others) v Secretary of State for the Home
Department (Equality and Human Rights Commission intervening) - [2018] 1 All ER 400

48. R (on the Application of Medical Justice) v Secretary of State for the Home
Department

49. R (on the application of NN) v Secretary of State for the Home Department; R (on the
application of LP) v Secretary of State for the Home Department - [2019] All ER (D) 104
(May)

50. R (on the application of YL (China)) v SSHD

51. Rotherham Metropolitan Borough Council v G (A child) and others

52. R v A

53. R v AAC

54. R v Ahmet and another

55. R v Axhami

56. R v Capitao

57. R v DKN

58. R v D & Ors (2015)

59. R v Falder

60. *R v Ginar - [2023] All ER (D) 23 (Oct)


-----

61. R v Gurney

62. R v Iyamu - [2018] All ER (D) 74 (Sep)

63. R v Jones

64. R v Joseph

65. *R v Joseph and others (Anti-Slavery International intervening) - [2017] All ER (D) 100
(Feb)

66. R v Kovalkov

67. *R v MK; R v Gega (also known as Maione) - [2018] All ER (D) 10 (Apr)

68. R v N - [2019] All ER (D) 24 (Jul)

69. R v O and another

70. R v Omorie Tevon-Te Nixon

71. R v Stephens

72. R v Tancos

73. R v TN

74. R v Tran

75. R v Uddin - [2018] 1 All ER 1073

76. R v Wabuela

77. Sajid v R


-----

78. *Taiwo v Olaigbe and another; Onu v Akwiwu and another

79. *Taiwo v Olaigbe and another; Onu v Akwiwu and another - [2016] All ER (D) 134 (Jun)

80. TC09126: ELPHYSIC LTD; PHYARREIDON LTD; ROSSCANA LTD; ZRAYTUMBIAX LTD

81. Windy Anjasmoro v The Home Office (2017)

82. Balogh and others v Hick Lane Bedding Ltd (Balogh)

83. Esslemont v The Information Commissioner

84. H v Director of Public Prosecutions

85. JR295's Application for Judicial Review

86. JR v Advocate General for Scotland - 2024 Scot (D) 18/6

87. NN v Secretary of State for the Home Department; LP v Secretary of State for the
Home Department

88. R (AM) v Secretary of State for the Home Department and another

89. R (on the application of Adesanya) v Secretary of State for the Home Department 
[2016] All ER (D) 14 (Jun)

90. R (on the application of BVN) v Secretary of State for the Home Department

91. R (on the application of DA and others) v Secretary of State for the Home Department

92. R (on the application of DS) v Secretary of State for the Home Department - [2019] All
ER (D) 109 (Nov)

93. R (on the application of EL) v Secretary of State for the Home Department - [2018] All
ER (D) 10 (May)

94. R (on the application of Galdikas and others) v Secretary of State for the Home
Department


-----

95. *R (on the application of K and another) v Secretary of State for the Home
Department - [2018] All ER (D) 50 (Nov)

96. R (on the application of LH) v Secretary of State for the Home Department - [2020] All
ER (D) 113 (Jan)

97. R (on the application of LM) v Secretary of State For the Home Department

98. R (on the application of NN) v Secretary of State for the Home Department; R (on the
application of LP) v Secretary of State for the Home Department

99. R (on the application of Saadawi) v Secretary of State for the Home Department 
[2017] All ER (D) 03 (Dec)

100. R (on the application of TVN) v Secretary of State for the Home Department

101. R v A

102. R v AGM

103. R v AH

104. R v Bajrakatari

105. R v Bajrakatari

106. R v Bakayoko

107. R v Balmont (Nathan)

108. R v BNN

109. R v BRP

110. R v BWM


-----

111. R v Cahill

112. R v Cubi

113. R v DS

114. R v F - [2007] EWCA Crim 2567

115. R v Feng - [2008] All ER (D) 83 (Feb)

116. R v Ginar

117. R v GS - [2018] All ER (D) 90 (Aug)

118. R v Henkoma - [2023] All ER (D) 76 (Jul)

119. R v Iyamu (Josephine)

120. R v Kaminskas

121. R v Love

122. R v Maciejczyk (Damian)

123. R v Mccann

124. R v Michael Joyce

125. R v MK (also known as D); R v Gega (also known as Maione)

126. R v Mohamed

127. R v Mohammed

128. R v Moussa


-----

129. R v N

130. R v Ninh

131. R v O and another - [2019] All ER (D) 119 (May)

132. R v S

133. R v Saffa

134. R v T

135. *R v Uddin - [2017] All ER (D) 68 (Aug)

136. R v Watson-Best

137. R v Xhaferi

138. R v Y

139. Sheikh v The Law Society of England and Wales and others

140. *A and another v Criminal Injuries Compensation Authority and another - [2021] All
ER (D) 33 (Jul)

141. Ahmed v Arearose Ltd

142. Ajao (appellant) v Commerzbank AG and others (respondents) - [2024] IRLR 756

143. Ajayi (claimant) v Abu and another (defendants) - [2018] IRLR 1028

144. Ajayi v Abu and another

145. A Local Authority v AB and others

146. A Local Authority v C (by his litigation friend) and others (Institute of Registered
Case Managers and others intervening) - [2022] 3 All ER 812


-----

147. Anti-Trafficking and Labour Exploitation Unit and another v Secretary of State for
Justice

148. Bell v Metropolitan Police Commissioner

149. Case Number: V 0008/94_1

150. Chief Constable of Kent Police and another company v Taylor

151. DSD and another v Metropolitan Police Commissioner - [2018] 3 All ER 369

152. FB and another v Secretary of State for the Home Department (Public Law Project
intervening)

153. GFH Capital Ltd (a company incorporated in the Dubai International Financial Centre
of the Emirate of Dubai) v Haigh and others

154. *Gudanaviciene and others v Director of Legal Aid Casework and another - [2014] All
ER (D) 123 (Jun)

155. HAI VAN LE also known as TRUNG DUNG LE Appellant against HER MAJESTY'S
ADVOCATE Respondent

156. Highlights: October 2022

157. Independent Workers Union of Great Britain (claimant) v Central Arbitration
Committee (defendant) and Roofoods Ltd (t/a Deliveroo) (interested party) - [2018] IRLR
911

158. Independent Workers Union of Great Britain v Central Arbitration Committee

159. J. and others v Austria (App. No. 58216/12) - [2017] ECHR 58216/12

160. Jasuitis and imaitis v Lithuania (App. Nos. 28186/19 and 29092/19) - [2023] ECHR
28186/19

161. JOHN MILLER against HER MAJESTY'S ADVOCATE - 2019 S.C.C.R. 78


-----

162. JOHN MILLER Appellant against HER MAJESTY'S ADVOCATE Respondent

163. JR Petitioner against ADVOCATE GENERAL FOR SCOTLAND Respondent

164. Kajeepaan and others v Been, Director of Immigration and another - [2021] 3 LRC
270

165. KAM (Nuba - return) Sudan CG

166. KK v Leeds City Council and another

167. KK v Leeds City Council and DK (By Her Litigation Friend the Official Solicitor) 
[2021] COPLR 96

168. Komives and another v Hick Lane Bedding Ltd (in administration) and another

169. Krachunova v Bulgaria - (2023) 56 BHRC 781

170. Krachunova v Bulgaria (App. No. 18269/18) - [2023] ECHR 18269/18

171. LY, petitioner - 2019 Scot (D) 16/2

172. Minister for Justice and Equality v Harrison

173. Nguyen, petitioner - 2022 Scot (D) 19/9

174. Nosworthy v Instinctif Partners Ltd

175. *Polish Judicial Authorities v Celinski and others; Slovakian Judicial Authority v
Cambal; R (on the application of Inglot) v Secretary of State for the Home Department
and another - [2015] All ER (D) 37 (May)

176. Polish Judicial Authority v Celinski and other cases - [2016] 3 All ER 71

177. Re JR96 and another

178. *Reyes and another v Al-Malki and another - [2017] All ER (D) 85 (Oct)


-----

179. Reyes (appellant/cross-respondent) v Al-Malki and another (respondents/crossappellants) - [2018] IRLR 267

180. R (on the application of AAA and others) v Secretary of State for the Home
Department (United Nations High Commissioner for Refugees intervening) and other
cases - [2023] All ER (D) 02 (Jul)

181. R (on the application of AAA (Syria) and others) v Secretary of State for the Home
Department (United Nations High Commissioner for Refugees intervening) and other
appeals - [2023] 4 All ER 253

182. R (on the application of AB and another) v Westminster City Council

183. R (on the application of ARM) v London Borough Of Brent

184. R (on the application of AS) v Liverpool City Council

185. *R (on the application of BG) v Secretary of State for the Home Department

186. R (on the application of Bowen) v Kent County Council

187. R (on the application of B) v Secretary of State for the Home Department

188. R (on the application of Ellis) v Secretary of State for the Home Department
(discretionary leave policy; supplementary reasons)

189. R (on the application of FX) v Secretary Of State For The Home Department (2016)

190. R (on the application of Gudanaviciene and others) v Director of Legal Aid Casework
and another (British Red Cross Society intervening) — [2015] 3 All ER 827

191. R (on the application of Humnyntskyi and others) v Secretary of State for the Home
Department

192. R (on the application of L) v Director of Public Prosecutions

193. R (on the application of Mc) v London Borough Camden (2015)


-----

194. R (on the Application of MXK and others) v Secretary of State for the Home
Department

195. R (on the application of Naeem) v Secretary of State for Education

196. R (on the application of Naeem) v Secretary of State for Education (Morris,
interested party) - [2022] 3 All ER 648

197. R (on the application of Qin and others) v Metropolitan Police Commissioner and
another

198. R (on the application of the Joint Council for the Welfare of Immigrants) v Secretary
of State for the Home Department (Residential Landlords Association and others
intervening) - [2020] 4 All ER 1027

199. *R (on the application of TN (Vietnam) and another) v Secretary of State for the
Home Department and another

200. R (on the application of TN (Vietnam)) v Secretary of State for the Home Department
and another; R (on the application of US (Pakistan)) v Secretary of State for the Home
Department and another - [2017] 4 All ER 399

201. R (on the application of Y) v Secretary of State for the Home Department

202. Rubak v Circuit Court in Warsaw, Poland

203. R v A - [2022] All ER (D) 84 (Jul)

204. R v Alexandru Lupu

205. R v Aliaj

206. R v AM

207. R v Bariana

208. R v BLS

209. R v Brezezinski


-----

210. R v BXR - [2022] All ER (D) 52 (Nov)

211. R v Cawley

212. R v Connors

213. R v Cuthbertson

214. R v Egeresi (Laszlo)

215. *R v Ginar - [2023] All ER (D) 23 (Oct)

216. R v Ginar; Note - [2024] 2 All ER 767

217. R v GS

218. R v Henry-Smith

219. R v Iyamu

220. R v Kavanagh and another

221. R v Kovalkov

222. R v L (OK) (2017)

223. R v Musse

224. R v Parczewska

225. R v Rafiq (Mohammed) and Another (2016)

226. R v Stewart and Another

227. R v Tang - (2008) 25 BHRC 35


-----

228. R v Tang - [2009] 2 LRC 592

229. R v Thakoraka-Palmer

230. *R v Uddin - [2017] All ER (D) 68 (Aug)

231. R v Umo and another

232. R v White

233. SB (vulnerable adult: credibility) Ghana

234. Secretary of State for Justice v A local authority and others (Institute of Registered
Case Managers and another intervening)

235. Secretary of State for Justice v C and Others - [2022] COPLR 227

236. *Secretary of State for the Home Department v R (on the application of Joint Council
for the Welfare of Immigrants) (Residential Landlords Association and others intervening)

237. Sheikh v The Law Society of England and Wales and others

238. SH v Waltham Forest London Borough Council

239. SM v Croatia - (2020) 49 BHRC 1

240. S.M. v Croatia (App. No. 60561/14) - [2018] ECHR 60561/14

241. S.M. v Croatia (App. No. 60561/14) - [2020] ECHR 60561/14

242. TD and AD (Trafficked women)

243. THUONG KHAM NGUYEN (AP) Petitioner

244. TT (Vietnam) v Secretary of State for the Home Department


-----

245. Uhunamure v Belgian Judicial Authority

246. Uhunamure v Belgium

247. VCL and another v United Kingdom - [2021] All ER (D) 87 (Feb)

248. Visha v Criminal Court Of Monza (Italy)

249. Z (In Accordance With Anonymity Order)v Commerzbank AG and others


-----

# Failed Documents (1)

1. Bibliography


-----

