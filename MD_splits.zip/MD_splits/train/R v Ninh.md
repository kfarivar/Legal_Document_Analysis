# R v Ninh [2023] EWCA Crim 667

Court of Appeal, Criminal Division

Warby LJ, Hilliard J, HHJ Flewitt KC

23 May 2023Judgment

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

JUDGE FLEWITT:

**Introduction**

1 This is a renewed application for leave to appeal against sentence following a refusal by the single
judge.

2 On 14 November 2022, in the Crown Court at Leeds, the applicant was convicted of an offence of
producing a controlled drug of class B, namely cannabis, and sentenced to a term of 42 months'
imprisonment.

**Facts**

3 On 9 May 2022, following a report of an unrelated incident, police made their way to 87 Bayswater
Grove in Leeds. When they arrived, there were lights on in the property and there were windows open on
the upper floors. They knocked on the front door several times and shouted that they were the police. The
door was locked, and when they looked through the letter box they could see that there were people inside
the house. In addition, they could hear movement and they could smell cannabis.

4 The police forced entry and detained the applicant in the bathroom. When they searched the house they
discovered 83 cannabis plants growing in the basement and they found associated equipment, including
electrical cables, curtains and heat lamps. They discovered a further 106 cannabis plants growing in the

first‑floor bedroom and they found lights, timers, transistors and fans. There was a bedroom on the second

floor which did not contain any cannabis plants but which had been set up as a potential grow space with
the installation of plastic sheeting and vents.

5 The applicant was arrested and taken to the police station. When he was interviewed he said that he
travelled to Leeds on the train. He lived at the address and received food and clothing as payment for
watering the plants. He replied "no comment" to all the other questions asked of him.

6 In his defence statement the applicant asserted that he was trafficked into the United Kingdom, and he
relied on the defence contained in section 45 of the Modern Slavery Act 2015. That defence was clearly
rejected by the jury.


-----

**Sentence**

7 The applicant was born on 14 November 1973, and so now is 49 years of age. He has no other criminal

convictions. The applicant was sentenced without the benefit of a pre‑sentence report. We do not

consider it is necessary to obtain such a report to determine this application.

8 The judge applied the guideline in relation to the cultivation of cannabis. He concluded that the case fell
into harm Category 2 because the applicant was involved in an operation capable of producing significant
quantities for commercial use. He considered whether, in fact, the case fell into harm Category 1 which
would apply to an operation capable of producing industrial quantities for commercial use. He concluded
that it did "not quite" do so.

9 In relation to culpability, it was submitted on behalf of the applicant that he should be treated as having
played a lesser role. The judge rejected that submission, and concluded on the basis of the evidence that
he heard during the trial that the applicant had played a significant role. For a defendant playing a
significant role in the commission of a Category 2 offence, there is a starting point of four years' custody

and a category range of two‑and‑a‑half to five years' custody. The judge reduced that starting point by six

months to reflect the limited mitigation available to the applicant, namely his lack of previous convictions
and the fact that his time in custody would be more difficult as English was not his first language. In that
way, the judge arrived at his final sentence of 42 months' imprisonment.

**Ground of Appeal**

10 The applicant argues that the judge was wrong to treat him as having played a significant role in the
commission of this offence. He maintains that he should have been treated as having played a lesser role
or, alternatively, that the judge should have concluded that his case fell somewhere between significant
and lesser role.

11 In refusing leave to appeal, the single judge made the following observation:

"Ultimately, the assessment of your role was a matter for the learned judge who heard the evidence at trial.
It is not arguable that his conclusion was wrong nor that the sentence was manifestly excessive."

**Discussion**

12 It seems from the material available to us that before the trial started there had been a discussion
about the categorisation of the role played by the applicant. During that discussion prosecution counsel
indicated that the prosecution were prepared to accept that the applicant played a lesser role. At that
stage the judge indicated that he, too, may be prepared to proceed on that basis. However, the judge also
made clear that if the applicant were convicted after a trial he would determine his role on the basis of the
evidence called during the trial. That is exactly what happened.

13 In his sentencing remarks, the judge indicated that as a result of what he had heard during the trial his
view had changed. He concluded that the applicant was trusted by others in both London and Birmingham
to look after cannabis with a potential value of more than £100,000. He noted that the applicant was given
a key to the property and could come and go as he pleased. He also observed that the applicant had
access to three mobile telephones to keep in touch with others involved in the enterprise. In addition, he
concluded that the applicant had the expectation of significant financial or other advantage and that he had
some awareness and understanding of the scale of the operation.

14 It was open to the judge to make those findings, and at the same time to reject the suggestion that the
applicant had played a lesser role. The judge was not bound to accept the role previously suggested by
prosecution counsel. He was entitled to reach his own view about the evidence presented at trial.

15 For those reasons it is not arguable that the sentence imposed was either wrong in principle or
manifestly excessive. Accordingly, the application is refused.

__________


-----

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge_**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge

**End of Document**


-----

