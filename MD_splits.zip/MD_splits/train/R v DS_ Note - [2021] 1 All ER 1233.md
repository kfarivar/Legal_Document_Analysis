# R v DS; Note [2021] 1 All ER 1233

[2020] EWCA Crim 285

COURT OF APPEAL, CRIMINAL DIVISION

LORD BURNETT CJ, EDIS AND JOHNSON JJ

26, 28 FEBRUARY 2020

**Criminal law — Trafficking people for exploitation — Offences committed by victims of human trafficking —**
**Whether court having jurisdiction to stay proceedings as abuse of process — Modern Slavery Act 2015, s**
**45.**

The prosecution appealed from the ruling of Judge Griffith-Jones QC that proceedings against the respondent, DS,
should be stayed as an abuse of process. The court, LORD BURNETT CJ, EDIS J and JOHNSON J, considered
its jurisdiction to stay proceedings as an abuse of process in the context of the prosecution of victims of human
[trafficking following the enactment of s 45 of the Modern Slavery Act 2015, which provided a statutory defence for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
slavery or trafficking victims who committed an offence. The court gave leave to appeal, allowed the appeal and
directed the proceedings to continue in the Crown Court, stating, inter alia, as follows:

**'The legal context**

**[4] The case concerns the approach of domestic law to the international obligations of the United Kingdom in**
relation to the treatment of victims of trafficking and modern slavery. Although this is well-travelled territory in
a series of decisions of this court, it is worth briefly summarising the relevant material.

**[5] Article 4 of the European Convention on Human Rights (“ECHR”) is the starting point. This prohibits slavery**
and forced labour. Domestic case law on when it is appropriate to prosecute a credible victim of human
trafficking has evolved from: (i) the Council of Europe Convention on Action Against Trafficking in Human
[Beings 2005 (CETS No 197) (“the Convention”), in particular art 26; and (ii) European Parliament and Council](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)
_[Directive 2011/36/EU on preventing and combating trafficking in human beings and protecting its victims (“the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
Directive”), in particular art 8. The two most relevant provisions, in relation to the non-prosecution of trafficked
individuals for offences committed whilst they were subject to trafficking, read as follows:

**Article 26 of the Convention – Non-punishment provision**

“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.”

**Article 8 of the Directive – Non-prosecution or non-application of penalties to the victim**

“Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent

**[*1234]**


-----

national authorities are entitled not to prosecute or impose penalties on victims of trafficking in human beings
for their involvement in criminal activities which they have been compelled to commit as a direct consequence
of being subjected to any of the acts referred to in Article 2.”

**[6] Prior to the enactment of the 2015 Act, there was no domestic statutory reflection of the United Kingdom's**
obligations under the Convention and the Directive. As such, the UK's obligations in this respect were adhered
to by means of – (i) relevant CPS guidance, which indicated the capacity of, and the circumstances in which, a
prosecutor could decline to proceed against an individual suspected of being a victim of trafficking; (ii) where
available, the common law of duress, and (iii) the court's abuse of process jurisdiction, whereby it could review
the CPS' prosecutorial decision, and, in certain cases, refuse to entertain proceedings. The 2015 Act changed
this landscape by placing this system on a concrete domestic footing.

**[7] The policy of the CPS (2015) in respect of those not within the scope of the 2015 Act required the**
prosecutor to consider three broad questions where the defence of duress did not arise on the evidence. First,
was there credible evidence that the defendant fell within the definition of trafficking in Annex 11 to the UN
Convention against Transnational Organised Crime (“the Palermo Protocol”) and European Parliament and
_[Council Directive 2011/36/EU; secondly, was there a nexus between the crime committed and the trafficking;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
and thirdly, was it in the public interest to prosecute?

**[8] Since the enactment of s 45 of the 2015 Act, which provides a statutory defence for some victims of**
trafficking to some offences, that CPS Guidance has changed as we shall describe below. It is necessary to
consider the effect of the 2015 Act and the new Guidance, and the extent to which the role of the court in its
application has changed because of them.

**[9] It is, we think, unnecessary to distil the authorities in relation to this issue as they stood in relation to cases**
which arose before the enactment of the 2015 Act. They have been most recently summarised by this court in
_R v JXP_ _[[2019] EWCA Crim 1280, [2019] All ER (D) 44 (Aug) (at [36]) by Nicola Davies LJ giving the judgment](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W56-P502-D6MY-P0NC-00000-00&context=1519360)_
of the court and we respectfully adopt that analysis. This is the first time this court has had to consider the
position in relation to cases to which the 2015 Act applies, and the issues we have to decide are not directly
covered by authority.

…

**Decisions**

**[39] We begin by making three fundamental observations.**

(i) The jurisdiction to stay proceedings as an abuse of the process of the court is an important, but limited,
power of a criminal court. It should not be widened in scope to meet particular needs unless there is a very
clear reason for doing so.

(ii) The Convention and the Directive are not directly applicable in domestic law. It is for Parliament and the
executive to decide how to give effect to the international obligations of the United Kingdom, and where it does
so by legislation the function of the court is to apply that legislation. The Directive required Member States of
the European Union to put in place arrangements that reflect its requirements. We

**[*1235]**

have not identified any clear gap between the provisions of the 2015 Act and those obligations, and in our
judgment the CPS Guidance means that the CPS is “entitled” not to prosecute for the purposes of art 8 of the
Directive. That being so, our primary focus is on the domestic law as found in the common law of duress and
the statutory defence in s 45 of the 2015 Act.

(iii) The state's positive obligation under art 4 ECHR has been considered in _Rantsev v Cyprus_ (App no
[25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1 (para 285): “member States are required to put in place a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)
legislative and administrative framework to prohibit and punish trafficking. The court observes that the Palermo


-----

Protocol and the Anti-Trafficking Convention refer to the need for a comprehensive approach to combat
trafficking which includes measures to prevent trafficking and to protect victims, in addition to measures to
punish traffickers.” There is a recognition of the operational choices in terms of priorities and resources that
must be made in this context at para 286. The state's positive obligation to protect victims of trafficking is not
expressed in terms of non-prosecution, see para 287: it “requires states to endeavour to provide for the
physical safety of victims of trafficking while in their territories and to establish comprehensive policies and
programmes to prevent and combat trafficking …” We do not think that there is any basis for deriving a positive
obligation not to prosecute victims of “forced or compulsory labour” in art 4 of the ECHR. This, the court found,
is the lowest level of gravity of oppression against which protection is required, below “slavery” and “servitude”.
That is the level of oppression for which DS contends in this case. If any such obligation did exist, it would be
heavily qualified and there is no basis for concluding that the qualifications found in the common law of duress,
and in s 45 of the 2015 Act, and the CPS Guidance are inadequate so that there is a violation of any such
positive obligation under art 4 ECHR which might exist.

**[40] In our judgment, the result of the enactment of the 2015 Act and the s 45 statutory defence is that the**
responsibility for deciding the facts relevant to the status of DS as a Victim of Trafficking is unquestionably that
of the jury. Formerly, there was a lacuna in that regard, which the courts sought to fill by expanding somewhat
the notion of abuse of process, which required the Judge to make relevant decisions of fact. That is no longer
necessary, and cases to which the 2015 Act applies should proceed on the basis that they will be stayed if, but
only if, an abuse of process as conventionally defined is found. By way of summary only, this involves two
categories of abuse, as is well known. The first is that a fair trial is not possible and the second is that it would
be wrong to try the defendant because of some misconduct by the state in bringing about the prosecution.
Neither of these species of abuse affected this case, and it should not therefore have been stayed.

…

**Conclusion**

**[47] The appeal was allowed because there was no room in the light of s 45 of the 2015 Act for the abuse of**
process jurisdiction to immunise the respondent from prosecution.'

**[*1236]**

The full text of this judgment, in which _Ben Douglas-Jones QC and_ _Dan Bunting (instructed by the Crown_
_Prosecution Service) appeared for the Crown and Henry Blaxland QC and Lee Sergent (instructed by GT Stewart_
_Solicitors) appeared for the respondents, can be found on the LexisLibrary online service ([2020] EWCA Crim 285)._

**_Wendy Herring Barrister._**

**End of Document**


-----

