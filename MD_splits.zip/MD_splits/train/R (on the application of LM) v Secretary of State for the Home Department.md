# R (on the application of LM) v Secretary of State for the Home Department

 [2021] EWHC 3034 (Admin)

Queen's Bench Division, Administrative Court (London)

Whipple J

15 November 2021Judgment

Miranda Butler (instructed by Duncan Lewis) for the Claimant

Michael Wall (instructed by Government Legal Department) for the Defendant

Hearing date: 03/11/2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

**Mrs Justice Whipple DBE :**

1. The Claimant challenges the Defendant's negative Conclusive Grounds decision (“CG Decision”) dated
11 November 2020 in which the Defendant concluded that the Claimant was not a victim of trafficking.

2. The Claimant advances three grounds:

i) That the Defendant has failed to apply anxious scrutiny to the CG Decision;

ii) That the Defendant has misdirected herself as to the correct approach to credibility; and

iii) That the Defendant has misdirected herself as to the correct approach to expert evidence.

3. Permission was granted by the Single Judge referring to ground i) only, but without specifically limiting
the grant. So argument proceeded on the basis that all grounds were before the Court, although the focus
was on grounds i) and iii).

4. The Claimant invited the Court to permit reliance on two witness statements filed with the application.  I
will deal with this at the end of this judgment.

**Background**

5. The Claimant is a national of Albania born on 25 September 1994.

6. Many of the facts which underpin the Claimant's case are in dispute. Thus, the following is intended
merely as a neutral summary of the background facts so far as they relate to the Claimant's entry to the
UK, in order to provide context for the arguments which follow.

7. The Claimant attempted to enter the UK for the first time on 29 June 2017. She was stopped by the UK
Border Force on a minibus in Calais in possession of false Romanian identity documents She was


-----

refused leave to enter and issued with a one year ban on re-entry. On her own admission, she gave a
false account when interviewed by immigration officials on that occasion.

8. She attempted to enter the UK for a second time on 20 July 2017. She was stopped by the UK Border
Force in the UK Control Zone in Lille, in possession of a false Greek identity document. She was in the
company of her sister's boyfriend Sean Cronin who she stated was her boyfriend, which was not true. She
was removed from the UK Control Zone and refused entry. On her own admission, she gave a false
account when interviewed by immigration officials on that occasion.

9. She managed to enter the UK in July 2017. She started working illegally at Poundstretcher in Brighton,
assuming a false identity and using false documents to do so.  Her wages were paid into Mr Cronin's bank
account.

10. In the early hours of 25 April 2018, a member of the public called police to report that they had seen a
female in a distressed state standing on a traffic island in Brighton. This was the Claimant. Her hands
were bound with duct tape. She was wearing torn fishnet stockings and was covered in bruises and
scratches. Sussex Police attended. The Claimant was interviewed. She provided a detailed account of
horrific experiences at the hands of traffickers since her arrival in the UK in July 2017. She told of kidnap,
forced prostitution and physical abuse at the hands of a man called Loli, who she said she had escaped
from that night. She told the police about a group of women being held against their will at a brothel in the
UK. A police investigation was launched.

11. On 3 May 2018, the Claimant was interviewed under caution in the presence of a solicitor. She
admitted that every aspect of her story given in that earlier interview from how she had arrived in the UK to
what had happened to her since was a lie. But she maintained that she had been a victim of trafficking
outside the UK and gave a different account of what had led to her being picked up on 25 April 2018,
namely that she had taped up her own wrists before running out onto the traffic island. She did not answer
some questions put to her. She was remanded in custody.

12. On 25 April 2018, the Sussex Police referred her to the National Referral Mechanism (“NRM”). A
negative reasonable grounds decision was made on 17 May 2018.

13. On 1 June 2018, the Claimant pleaded guilty to perverting the course of justice (by the lies told to the
police) and dishonestly making false representations (by her illegal work at Poundstretcher). On 6 July
2018 she was sentenced to 19 months' imprisonment. The judge had the benefit of a Pre-Sentence Report
from Emily Andrews, probation officer, dated 20 June 2018, in which it is noted that the Claimant said she
had lied to the police because she wanted to stay in the UK. She advanced further lies to Ms Andrews,
telling her that she had been Miss Albania and was representing her country in Malaysia; this, as Ms
Andrews notes, was not true. The author noted a “well established and possibly habitual pattern of lying to
those in authority”. The sentencing judge, HHJ Kemp sitting at Lewes Crown Court, noted that she had
told a pack of lies and that her lies had caused Sussex Police to spend £60,000 investigating her false
allegations and wasted a great deal of police time.

14. She was released from prison on 12 February 2019.

15. On 15 October 2019, the NRM agreed to reconsider the reasonable grounds decision. A positive
reasonable grounds decision was made on 28 October 2019, on the basis that the NRM suspected but
could not at that stage prove that the Claimant was a victim of **_modern slavery. That led to a detailed_**
investigation of her claim.

16. During that investigation, the Claimant provided a third, and different account, of what happened on
the night of 24/25 April 2018, namely that she was assaulted by her boyfriend who beat her and bound her
wrists together, and then told her to leave but not to say his name.

17. The Defendant produced the CG Decision on 11 November 2020. In the CG Decision, the Defendant
rejected the Claimant's claim to be a victim of modern slavery.

**Expert evidence**


-----

18. As part of the investigation into her claim that she was a victim of modern slavery, the Claimant relied
on a report from Dr Lisa Wootton, consultant forensic psychiatrist, dated 1 April 2019. Dr Wootton's view,
based on a single 2 hour assessment of the Claimant, was that the Claimant was suffering from
PTSD/complex PTSD and a moderate/severe depressive disorder. Dr Wootton said that the Claimant's
account and other sources of information were consistent with the expected symptoms of her disorders.
Further, in Dr Wootton's professional opinion, the symptoms, presentation and other evidence were
consistent with a person with the history disclosed by the Claimant who was not feigning or exaggerating
her symptoms.

19. As to causation of her symptoms, Dr Wootton's view was that the events which caused the Claimant's
mental health problems were various, and listed at paragraph 13 of the report. Those events included
trafficking and sexual exploitation, as well as childhood experiences of domestic abuse and violence,
sexual abuse by a relative in childhood, other family trauma, violence at the hands of her boyfriend more
recently and her experience of being interviewed by Sussex police and being in fear about what would
happen, and being in prison. Dr Wootton did not think it was possible to separate out each event and
comment on it individually as the effects were complex and cumulative. Dr Wootton concluded that it was
the trafficking in Albania, Turkey and en route to the UK which were the traumatic events which had
precipitated her PTSD, but that she was already predisposed by virtue of experiences as a child and her
condition was being perpetuated by stresses she had continued to experience.

20.  The Claimant also relied on a letter dated 14 February 2019 from Dr Dunmore, Clinical Psychologist,
who saw her at HMP Peterborough just before she was released. Dr Dunmore noted that the Claimant
was difficult to assess; and that there had been inconsistencies in her accounts.

21. The Claimant also relied on a Trafficking Identification Report dated 10 October 2019 from Mirjam
Thullesen, psychologist. She concluded that the Claimant's account contained a significant number of
trafficking indicators, based on the Claimant's account and all the other evidence Ms Thullesen had seen
as well as her experience. Her presentation was consistent with that of other victims of trafficking for
sexual exploitation. The diagnosis was consistent with her experiences and likely to be compounded by
the disbelief of her account by British authorities and by uncertainty as to her immigration and legal status.

**CG Decision**

22. The CG Decision summarises the various accounts put forward by the Claimant: to the immigration
officials at Calais and Lille, to the police, and in her statement dated 7 March 2019 which is her most recent
account, relied on by Ms Butler who represented the Claimant at this judicial review as representing a
truthful account and explaining the previous untruths.

23. The crux of the Claimant's case on trafficking, as set out in the CG Decision and indeed in that witness
statement dated 7 March 2019, which is reflected in the CG Decision, is that the Claimant says she had
been working in Albania as a journalist and TV presenter, but a man called Shpeitim Zeneli had persuaded
her to go to Kosovo, and then take part on a beauty pageant in Malaysia, but in March 2016 Zeneli took
her to Turkey where she was taken to various places by various men before she was threatened and
forced into being a sex worker; she was raped and beaten every night and when she did not comply she
was taken to a room where cold water was poured on her while she stood naked and was beaten; she
went back to Albania, but there a man called Kuti took her to a house where she was further exploited for 9
months; she was taken to Tirana and then onto Belgium by Kuti; she was taken to France and tried to get
to the UK but was stopped in Calais, when she told a false story to immigration officials; then she went to a
detention centre in Lille and some Albanian men picked her up from that detention centre and took her to
Belgium where she stayed for two months; when she tried again to get to the UK carrying a Greek ID card
she told a false story; she was then picked up by Kuti who beat her up; she then worked on the streets for
some months before travelling to the UK alone by bus. As things now stand, on the Claimant's case that
marks the end of her period of being trafficked.

24. The CG Decision records that she had originally said that she remained trafficked on her arrival in the
UK, that she spent time in other houses in the UK, under the control of Albanian men, and she was beaten


-----

and tortured, and that she was tied up and taken to a house, but managed to escape and was found on 25
April 2018 by a member of the public who called the police. She has since accepted she had been living
with her sister since being in the UK and was not trafficked while in the UK.  She has put forward three
different versions of the events of 25 April 2018: the first is above, that she was tied up but managed to
escape; then she told police that she had tied her own hands; more recently (when her boyfriend's DNA
was found on the tape) she said that he had tied her hands but told her that she should not mention his
name.

25. Extensive reference is made in the CG Decision to the Claimant's witness statement of 7 March 2019.
It is in this witness statement that the Claimant suggests reasons for at least some of her past lies. She
suggested she had lied because she remained in fear of her traffickers and her former boyfriend.

26. Reference is made in the CG Decision to the expert evidence (of Dr Wootton, Dr Thullesen, and Dr
Dunmore).

27. The CG Decision concludes that the Claimant's credibility was damaged by her various differing
accounts, and by the fact that she had lied to immigration officials and to the police. The CG Decision
summarised the evidence in the Claimants' favour, namely external evidence on Albania which notes that
trafficking does occur, as well as other documents which supported the Claimants' case (as to her
education, employment and attendance at a beauty pageant in Malaysia as she claimed), as well as the
expert evidence and the Trafficking Identification Report. The CG Decision then summarised the evidence
which went against the Claimant's case, which was the two documents evidencing what the Claimant had
said to the Border Force on two occasions, police interview, judge's sentencing remarks, other police
documents and the NHS letter which indicated a non-specific diagnosis of PTSD and possible trauma.

28. The CG Decision concluded:

“Looking at the available evidence in the round of your case, it is considered that while there is some
information that supports your account, looking at all the pieces of information cumulatively, the credibility
issues outweigh the evidence in support of your account. As such, it is not considered that you have met
the required evidentiary standard. Due to the inconsistencies in your account, your credibility has been
damaged to the extent that your claim to have been trafficked cannot be believed in applying the standard
of proof 'on the balance of probabilities' and is consequently rejected.”

The CG Decision summary recorded that it was not accepted that she was a victim of modern slavery.

**Law and Guidance**

29. There is no dispute between the parties as to the law, guidance or legal principles which apply in this
case. Those matters can be summarised shortly.

30. The Defendant publishes guidance pursuant to s 49 of the Modern Slavery Act 2015 on the approach
officials should take to Conclusive Grounds Decisions under the National Referral Mechanism. The current
guidance is dated June 2021. It deals with the assessment of credibility, inviting the decision-maker to
assess all information critically and objectively, noting that victims of modern slavery have been through
trauma and that their account might be inconsistent or lack detail (§14.5, 14.6). Guidance is also given
about the way in which expert views are to be approached, noting that the decision-maker should take into
account any expert reports submitted (§14.26) and that weight is for the decision-maker to assess, but
expert evidence is not determinative, and there is no requirement to accept an assessment of an expert
that a person is or is not a victim: “any expert assessment must be considered in the round with all other
_evidence” (§14.30). Specifically, a decision should not rely on an expert report without the decision-maker_
making other independent enquiries into the potential victim's circumstances and credibility (§14.33).

31. The approach has been examined in a number of cases. The Defendant must demonstrate a “high
standard of reasoning” in the CG Decision (see R (M) v SSHD [2015] EWHC 2467 at §55, and see MN v
_SSHD_ [2021] 1WLR 1956at §§ 242-3). The Defendant must apply anxious scrutiny and show by her
reasoning that every factor which tells in favour of the applicant has been properly taken into account: see
_R (YH) v SSHD [2010] EWCA Civ 116 at §24._


-----

32. Expert evidence must be taken into account and may support an applicant's credibility. In _MN, the_
Court summarised the principles and the process to be adopted at §121: it is for the decision-maker to
reach a decision on the totality of the evidence “viewed holistically”, and the weight to be accorded to a
doctor's opinion on the truthfulness of an applicant's account will depend on the circumstances of the
particular case, it will never be determinative; other possible causes of reported symptoms must be
considered.

33. The fact that a person has lied to the authorities is not determinative of whether they are a victim of
trafficking, see MA (Somalia) v SSHD [2010] UKSC 49 at §48. The significance of lies will vary from case
to case, but where a person lies on a matter of central importance, the decision-maker may conclude that
is a matter of great significance: see _MA_ at §33. Where the decision turns on credibility, the competent
authority must carefully analyse the relevant factors and explain the reasoning about credibility in the
decision (R (M) v SSHD at §55).

34. On judicial review, the Court must consider the decision with particular care: _MN v SSHD_ [2021] 1
WLR 1956at §244.

**Grounds of Challenge**

35. I take the grounds out of order. By ground 2, the Claimant alleges that the decision-maker misdirected
herself as to the correct approach to credibility. The Claimant's submissions consist of a rehearsal of the
Claimant's arguments as to why her latest account should be accepted. They do not demonstrate any
error of law in the way the decision-maker approached credibility. The CG Decision refers in terms to the
Guidance on credibility; it goes through the various accounts, and makes the unsurprising comment in
relation to the (now admitted) false accounts that they damaged the Claimant's credibility.

36. The Claimant argued that the CG Decision was structured in such a way that the conflicting accounts
were considered first, and a conclusion on credibility apparently reached, before looking at whether the
expert evidence provided mitigation. The Defendant answered that on a fair reading that was not the
approach the decision-maker took. Rather, the conclusion on credibility was reached with the Guidance
firmly in mind, and on the basis of a holistic assessment of all the material before the decision-maker. I
agree with the Defendant. There is no error of law in the Defendant's approach.

37. By ground 3, the Claimant contends that the Defendant failed to give adequate reasons for rejecting
the expert evidence. The CG Decision rehearsed the expert evidence in some detail. The Defendant
concluded that mental health issues could not explain the inconsistencies between accounts and the
mental health issues could be attributed to causes other than trafficking. That is undoubtedly a conclusion
to which the Defendant was entitled to come. Indeed, Dr Wootton herself accepted that there were
multiple causal factors. The decision-maker was bound to consider whether there were alternative causes
for the mental health problems exhibited by the Claimant (see MN at §121(6)).

38. Specifically, the decision-maker was aware, because it is set out in the Guidance, that inconsistencies
or lies do not necessary mean that the claim must be rejected. Credibility must be objectively assessed
taking all the evidence into account. It appears that was done, in this case. There is no error of law in the
approach to the expert evidence or the reasons given for rejecting it.

39. Finally I come to Ground 1, which is the overarching submission that the Defendant failed to apply
anxious scrutiny; or, as the point developed at the hearing, in essence that the Defendant got it wrong,
because the Defendant should have accepted the Claimant's explanations for her earlier lies, as they are
now set out in the witness statement dated 7 March 2019.  This ground is untenable. It was plainly open
to the Defendant to reject the Claimant's latest account, given the background of repeated dishonesty in
the accounts given to officials and to police. That account was of trafficking outside the UK; but it was also
a purported explanation of the various lies told in the past: all of this was rejected by the Defendant. The
lies advanced by the Claimant were on matters of central importance, namely, whether she had been
trafficked in the UK. Those lies were of great significance (note MA (Somalia) at §33, referred to above).
The reasoning provided in the Conclusive Grounds covers a number of pages, pages 9 to 14 in particular
containing a detailed analysis of the areas where that evidence conflicted or was unsatisfactory.


-----

40. As a sub-head of this ground, the Claimant argued that the Defendant had failed to obtain the texts
referred to in the CG Decision.  These were texts between Sean and Mira, the Claimant's sister,
suggesting that something was going to happen to the Claimant, and that the Claimant was off to have a
happy life. The Defendant does not have those texts. I accept the Defendant's submissions on this point:
there has never been any dispute about the gist of those texts so there was no need for the Defendant to
investigate them or obtain them. These texts were put to the Claimant by the police in interview and she
gave no comment. The texts undermined the Claimant's suggestion to the police in her interview that she
had taped up her own hands as an impulsive act (this was her second explanation for that night). The texts
suggested that the act was planned, the police put that point and the Claimant gave no answer. She was
represented at this interview, she was well and able to face questioning, and the decision-maker was
entitled to include reference to the texts, and that line of questioning by the police, in the CG Decision.

41. In answer to the Claimant's case, it is not appropriate to pick and choose selected passages from the
CG Decision. Nor is it appropriate to pore over this letter with a lawyer's eye looking for infelicities. The
CG Decision must be given a fair reading as a whole and noting that it was not written by a lawyer but an
official, and was subject to the second pair of eyes according to standard practice.

42. Taken overall, the CG Decision sets out the unsurprising conclusion that the Claimant has failed to
establish, to the required standard, that she has been the victim of trafficking. The decision-maker is not
dismissing her account as untrue, rather the decision-maker is saying that it is not possible to conclude that
it is probably (or more likely than not to be) true. It may or may not be. That is a justified conclusion.  This
latest account followed a patchwork of earlier lies. A lack of confidence in the Claimant's veracity is
understandable.

43. This CG Decision is careful and thorough. It demonstrates a high standard of reasoning.

**Application to adduce further evidence**

44. It is necessary to determine the application to adduce further evidence. I have read it de bene esse. It
comprises a further witness statement from the Claimant and a witness statement from her sister about the
disputed events and accounts which are considered in the CG Decision. Although it is said to answer the
Defendant's evidence, in reality this is yet more evidence to try to explain away the inconsistencies and
conflicts of the existing accounts given by the Claimant. This evidence goes to the merits of the CG
Decision and it could have been provided earlier. In addition, it is not relevant to the issues which I have
had to decide, which relate to whether the decision-maker erred in law.

45. I refuse the application to admit this evidence.

**Conclusion**

46. This claim is dismissed. The application to admit further evidence is refused.

47. I thank both counsel for their helpful submissions.

**End of Document**


-----

