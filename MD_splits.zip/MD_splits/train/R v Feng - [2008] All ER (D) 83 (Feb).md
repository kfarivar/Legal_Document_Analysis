# R v Feng [2008] All ER (D) 83 (Feb)

[2007] EWCA Crim 2567

Court of Appeal, Criminal Division

EnglandandWales

Dobbs J and Judge Goddard QC

18 October 2007

**Sentence – Imprisonment – Length of sentence – Facilitating the arrival into the United Kingdom of another**
**person for the purposes of sexual exploitation – Facilitating travel within the United Kingdom of another**
**person for the purposes of sexual exploitation – Defendant convicted after trial – Judge imposing**
**concurrent sentence of eight years' imprisonment – Judge making recommendation for deportation –**
**Whether sentence too long – Whether deportation order should be made.**
Abstract

_In the instant case, a sentence of eight years' imprisonment had been too long, and a recommendation for_
_deportation had not been apt, where the defendant, aged 24, was convicted of two counts of facilitating the arrival_
_into the United Kingdom of another person for the purposes of sexual exploitation and two counts of facilitating_
_travel within the United Kingdom of another person for the purposes of sexual exploitation. The offences for which_
_the defendant had been convicted were serious; however, within themselves, they were not the worst of its category_
_of offence. Moreover, when sentencing the judge had failed to carry out a proper balancing exercise of the_
_mitigating and agrravating factors. Accordingly, the recommendation for deportation and sentence would be_
_quashed, and sentence substituted by a sentence of four years' imprisonment._
Digest

The defendant, aged 24, contacted a man, R, in Brazil and asked him if he knew of any girls who would like to work
in his restaurant in England. R asked M if she wished to do so and she agreed. She in turn asked her friend, S, who
was also keen to go. Money was put into R's account by the defendant to buy passports and clothing for the young
women, and plane tickets to Heathrow were paid for. The women arrived at Heathrow where, after obtaining tourist
visas, were met by the defendant. He took them to London and introduced them to a man. The women were then
taken for a meal, then to shops where they were bought lingerie. At that point the women became suspicious. Their
passports were taken away from them and they were told they would have to work as prostitutes. They were then
taken to a brothel in Portsmouth. M was forced to work as a prostitute. S refused, and was handed back to the
defendant. The police raided the brothel in Portsmouth and the defendant was arrested and charged with two
counts of facilitating the arrival into the United Kingdom of another person for the purposes of sexual exploitation
and two counts of facilitating travel within the United Kingdom of another person for the purposes of sexual
exploitation. He pleaded not guilty to the offences. He was subsequently convicted of the offences by a jury. He was
of previous good character. There were no reports in front of the sentencing judge, but prison reports described his
conduct as excellent and courteous to all. The judge imposed a sentence of eight years' imprisonment on each
count to run concurrently. He also made a recommendation for deportation. The defendant appealed against his
sentence.

He submitted, inter alia, that the sentence imposed by the judge was too long in the light of the fact that it was a
single transaction; the sentences were not aggravated by violence or threats of violence; and no coercion was used


-----

on the women. He further submitted that, in the circumstances, the recommendation for deportation should not
have been made.

The appeal would be allowed.

In the instant case, there had been force in the argument that the sentence imposed was too long. Taking into
account both the mitigating and aggravating features in the instant case, the appropriate sentence was one of four
years' imprisonment. The recommendation for deportation, was a recommendation which had been in the judge's
discretion. The court had to consider the potential detriment of the offender remaining in the jurisdiction. Even if the
offender had no previous convictions, a recommendation could be made where the offence was a serious one, of a
deliberate character, and one which could undermine public policy. The offences for which the defendant had been
convicted were serious. However, within themselves, they were not the worst of its category of offence. The judge
had noted, when sentencing, that offences of the instant kind were in effect a form of modern slavery. However, in
the instant case aggravating features akin to slavery had not been present. Whilst the defendant was associated
with the person who ran the brothel, that person had fled the jurisdiction and there had been no evidence that the
defendant had been in any way associated with the brothel. Although reference was made to the defendant's
character and personal circumstances, there was no assessment of his future behaviour, the judge not having had
the benefit of a pre-sentence report in front of him, needed therefore to make such an assessment himself. If had
made an assessment, he had failed to express clearly and in detail the factors which militated in favour of the
recommendation to deport and why. In all the circumstances, given the facts of the offences, strong mitigation and
the lack of evidence pointing to any future concerns about the defendant, the recommendation had not been apt.

Accordingly, the recommendation for deportation and sentence would be quashed, and sentence of eight years'
imprisonment substituted by a sentence of four years.

Adrian Farrow (assigned by the Registrar of Criminal Appeals) for the defendant.

Phillip Shorrock (instructed by the Crown Prosecution Service) for the Crown.
Tunde Gbadamosi  Barrister.

**End of Document**


-----

