DEPARTMENT Respondent 2019 Scot (D) 16/2

# LY also known as YZ (or ZY) Petitioner against THE SECRETARY OF STATE
 FOR THE HOME DEPARTMENT Respondent 2019 Scot (D) 16/2

[2019] CSOH 13

OUTER HOUSE, COURT OF SESSION

Lord Beckett

Petitioner: Ms Irvine; Drummond Miller LLP

Respondent: Webster QC; Office of the Advocate General

14 February 2019

**Lord Beckett**

[1]     In the early hours of 24 August 2014, the petitioner found herself on the streets of Glasgow, barefoot and in
a state of distress. She sought the assistance of a passer-by who called the police on her account. The police
attended and spoke with the petitioner who said that she was LY, a national of China, born in September 1993. She
was traumatised and it was difficult to engage with her, but in due course she was referred via the National Referral
Mechanism to the Home Office as a potential victim of trafficking. On 28 August 2014, the Home Office, as
Competent Authority, concluded that there were reasonable grounds to believe that the petitioner had been a victim
of trafficking.

[2]     On 6 March 2018, the Home Office, as Competent Authority, conclusively recognised the petitioner as a
victim of trafficking in relation to her experiences in the United Kingdom but not as a victim of trafficking in Denmark
and China. She was granted discretionary leave to remain until March 2019. On 16 March 2018 the petitioner was
refused asylum on the basis that there would be a sufficiency of protection on her return to China. These
proceedings do not relate to the refusal of the petitioner's claim for asylum which is subject of appeal proceedings
before the First-tier Tribunal.

[3]     In this petition for judicial review the petitioner ostensibly seeks declarator to the effect that two decisions
made on 6 March 2018 were unlawful:

∙   that the petitioner in relation to her departure from China and entry to and presence in Denmark is not a
victim of trafficking;

∙   in rejecting the petitioner's true identity as being LY.

However, in the course of the hearing before me on 10 January 2018, Ms Irvine invited the court instead to reduce
the decision of 6 March 2018 insofar as expressed in the following passage in a decision letter of same date:

“It has therefore been decided that you are not a victim of human trafficking from China to Denmark for the
purposes of forced labour or sexual exploitation.”

**Relevant law**


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

[4]     Directive 2011/36/EU of the European Parliament and of the Council of 5 April 2011 on preventing and
combating trafficking in human beings and protecting its victims, and replacing Council Framework Decision
2002/629/JHA, provides in Article 2:

“Offences concerning trafficking in human beings

1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or transfer
of control over those persons, by means of the threat or use of force or other forms of coercion, of abduction, of
fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of
payments or benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation.

2. A position of vulnerability means a situation in which the person concerned has no real or acceptable
alternative but to submit to the abuse involved.

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, including begging, slavery or practices similar to slavery, servitude, or
the exploitation of criminal activities, or the removal of organs.

4. The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual, shall
be irrelevant where any of the means set forth in paragraph 1 has been used.

5. When the conduct referred to in paragraph 1 involves a child, it shall be a punishable offence of trafficking in
human beings even if none of the means set forth in paragraph 1 has been used.

6. For the purpose of this Directive, 'child' shall mean any person below 18 years of age.”

[5]     The Council of Europe Convention on Action against Trafficking in Human Beings (the Trafficking
Convention) was ratified by the UK on 1 April 2009. It provides in Article 4:

“ARTICLE 4

_Definitions_

For the purposes of this Convention:

a 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person, for the purpose of exploitation.
Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs;

b The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

c The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered 'trafficking in human beings' even if this does not involve any of the means set forth in
subparagraph (a) of this article;

d 'Child' shall mean any person under eighteen years of age;


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

e 'Victim' shall mean any natural person who is subject to trafficking in human beings as defined in this article.”

[6]     As part of implementing its obligations under the Trafficking Convention, the UK government created the
National Referral Mechanism (NRM) in 2009.

[7]     The European Convention on Human Rights (ECHR) provides in Article 4:

“ARTICLE 4

_Prohibition of slavery and forced labour_

1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. For the purpose of this Article the term 'forced or compulsory labour' shall not include:

(a) any work required to be done in the ordinary course of detention imposed according to the provisions of
Article 5 of this Convention or during conditional release from such detention;

(b) any service of a military character or, in case of conscientious objectors in countries where they are
recognised, service exacted instead of compulsory military service;

(c) any service exacted in case of an emergency or calamity threatening the life or well-being of the
community;

(d) any work or service which forms part of normal civic obligations.”

[8]     In Rantsev v Cyprus and Russia (2010) 51 EHRR 1 the ECtHR held that trafficking within the scope of
Article 4(a) of the Trafficking Convention falls within the scope of the ECHR Article 4 prohibition of slavery and
forced labour. In paragraph 288 the Court explained that Article 4 entails a procedural obligation to investigate
situations of potential trafficking which must be capable of leading to the identification and punishment of the
individuals responsible. It may extend to taking operational measures to protect victims or potential victims of
trafficking, paragraph 286, subject to questions of proportionality in the application and prioritisation of resources. In
paragraph 289 the Court explained that Member States are obliged in cross-border trafficking cases to co-operate
effectively with the relevant authorities of other states.
**Respondent's guidance**

[9]     The Home Office publishes guidance based on the Trafficking Convention, “Victims of modern slavery –
Competent Authority Guidance,” of which Version 3, issued on 21 March 2016, was in force on 6 March 2018. It is a
substantial document which gives information to staff in the Competent Authorities in the Home Office and UK
Human Trafficking Centre to help them decide whether a person referred under the NRM is a victim of trafficking.

[10]     At page 28 of the guidance certain myths about modern slavery are identified and discussed, the first of
which is, “The person did not take opportunities to escape so is not being coerced.” It is then explained that whilst
remaining in an exploitative situation could indicate a willingness to remain there and/or an absence of coercion
there can be many other reasons why someone may choose not to escape such a situation including fear of reprisal
for self or family, vulnerability and lack of knowledge of one's environment.

[11]     At page 30 the guidance provides:

“As noted in the Office of the United Nations High Commissioner for Refugees (UNHCR) guidelines on
international protection:

'An important aspect of this definition is an understanding of trafficking as a process comprising a number of
interrelated actions rather than a single act at a given point in time. Once initial control is secured, victims are


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

generally moved to a place where there is a market for their services, often where they lack language skills and
other basic knowledge that would enable them to seek help. While these actions can all take place within one
country's borders, they can also take place across borders with the recruitment taking place in one country and
the act of receiving the victim and the exploitation taking place in another. Whether or not an international
border is crossed, the intention to exploit the individual concerned underpins the entire process.' “

[12]     The guidance identifies from the terms of the Trafficking Convention that modern slavery includes human
trafficking and identifies the essential components of action, means and the purpose of exploitation before noting
that in the case of a child there need not have been any means because a child cannot give informed consent.
Accordingly, the guidance states at page 32:

“A potential victim of trafficking who may have been a victim as a child, but [is] only identified and referred into
the NRM after reaching adulthood is treated under child criteria in assessing whether they were trafficked. The
practical effect of this is that they do not have to meet the means test.”

[13]     Also at page 32, the guidance notes that physical coercion as a means includes threat of force against the
victim and their family members.

[14]     Commencing at page 97, guidance is given about the assessment of credibility and competent authorities
are enjoined to consider both the external and internal credibility of material facts. The competent authority must
take into account mitigating circumstances including trauma, feelings of shame and painful memories which may
provide reasons why a potential victim of trafficking may be incoherent, inconsistent or delays in giving details of
material facts. The effects of trauma on consistency and lack of detail are identified but it is also noted that a victim
of trafficking is likely to be able to describe what they saw, heard, felt and thought about events in a way which
someone who has not had such experiences could not.

[15]     At page 99 the guidance states:

_“Difficulty recalling facts_

As a result of trauma, victims in some cases might not be able to recall concrete dates and facts and in some
cases their initial account might contradict their later statement. This may be connected to their traumatic
experience. However, the need to be sensitive does not remove the need to assess all information critically and
objectively when the Competent Authority considers the credibility of a case.”

In submissions, counsel for the petitioner placed heavy reliance on the first two sentences. Counsel for the
respondent observed that the final sentence is also important and should not be lost sight of.
**Petitioner's account**

[16]     The petitioner maintains that she is LY, born in September 1993 in Jilin Province, in the north-east of
China where the languages spoken are Mandarin and Korean. She says that when she was 6 she moved with her
mother, who had remarried, to Guangdong Province in the south-west of China where the languages spoken are
Cantonese and Mandarin. The petitioner's stepfather physically and sexually abused her as a child.

[17]     The petitioner claims that in or around 2009, when she was 15, she was sold by her stepfather to an
organised criminal gang as payment for debt and left China without her mother after the Chinese New Year. She
was taken by car to an airport in China but she was not able to say what airport it was or give any details about it.
She was taken to Denmark. The petitioner was accompanied on the flight to Denmark by a man called A Zhen. She
was sedated. The petitioner was met at the airport in Denmark by a man called A Nai under whose control she was
kept throughout her time in Denmark. He enrolled her in classes at a design and technology school, under an alias
identity which would later come to be identified to the petitioner as YZ or ZY with a date of birth in August 1990. She
was taught in a language which she did not understand. Whilst enrolled in the school and thereafter, she was
forcibly prostituted by Mr Nai who also forced her to work in the evenings at a restaurant and as a night cleaner in a


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

hospital. She was told that if she did not comply her mother would be harmed. She was physically threatened and
her finger was cut with a meat slicer.

[18]     The petitioner says that she was taken to London in 2010 under the YZ alias identity when she was about
16. Mr Nai accompanied her on the flight to London during which she was again sedated and he took her to a
house in a place which she later learned was London. The petitioner was forced to work as a prostitute there and
elsewhere on a daily basis over the course of four years. In August 2014 she was driven to Scotland in order to
have sex with a particular client but she escaped after a fight broke out between the client and the petitioner's driver
in the early hours of 24 August 2014 when she made contact with the police as already described.
**Undisputed facts**

[19]     The respondent accepted that the petitioner had been ill-treated and sexually abused by her stepfather as
a child in China but did not consider that that part of her account amounted to trafficking. This conclusion is not
challenged.

[20]     The respondent accepted evidence, and its import, from a clinical psychologist, Dr Sharon Doherty, who
reported in 2015 after examining the petitioner and reviewing the available information since her arrival in the UK.
Dr Doherty concluded that the petitioner continued to experience core PTSD symptoms of intrusions, hyperarousal,
avoidance of trauma reminders and symptoms of low mood, albeit the frequency of symptoms was reducing over
time. The petitioner was observed to employ a lot of energy to avoid difficult feelings and memories such that when
reminded of memories of her trafficking and the loss of her mother she became low, tearful and fearful. She was
considered to meet the diagnostic criteria for PTSD.

[21]     When the petitioner's fingerprints were taken in November 2014, they were found to match a UK Visa
application submitted in Denmark in 2010 in the name YZ, Chinese national born in August 1990. A bank statement
and a letter of support from Kea “University”, Copenhagen were submitted along with the visa application which
also disclosed that a previous passport issued to YZ had expired so that a renewal passport had been sought and
issued at the Chinese Embassy in Copenhagen. Investigations established that the visa application was submitted
in person at the British Embassy in Copenhagen on 28 June 2010 and that fingerprints were taken and processed.
A particular Chinese passport in the name YZ was submitted in support of the application. The passport had been
issued by the Chinese Embassy in Copenhagen on 16 November 2009. This must have required personal
attendance at the Chinese Embassy by the petitioner who must have produced either a passport or identity card.

[22]     The petitioner has denied knowledge of obtaining a passport in this identity and of the visa application. All
that the petitioner had been able to say about this was that she had had her photograph taken on one occasion in a
building in Copenhagen which looked like a shop. She made no reference to renewing her passport and applying
for a visa at the Chinese and British embassies in Copenhagen. The petitioner has not produced to the respondent
any evidence from the Chinese Embassy in the UK to support her true identity being LY.
**The decisions of 6 March 2018**

[23]     The relevant decisions were given in two letters dated 6 March 2018. Acceptance that the petitioner was
the victim of trafficking in relation to her experiences in the UK was set out in a three page letter. In a detailed letter
of 22 pages (the decision letter), the allocated NRM case-worker explained why it was not accepted that the
petitioner was a victim of trafficking from China to Denmark for the purposes of forced labour or sexual exploitation.

[24]     The decision letter commences by noting the petitioner's details as YZ also known as LY and notes that
she is from China, female and the dates of birth associated with both identities are noted. There is a brief synopsis
of the petitioner's account followed by an extensive list of the materials considered. The decision-maker proceeds to
set out a structured assessment of the available information, the law, relevant guidance and reasons for the
conclusions reached. The fundamental difficulty for the petitioner, as explained at page 11, was that the decisionmaker did not accept the credibility of her account in material respects and accordingly attached little weight to
evidence emanating from her in those respects. The reasons for this assessment, and its legal effect, were
explained in detail between pages 11 and 22.


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

[25]     At pages 15-17 the petitioner's account is considered in the light of information submitted in support of the
ZY visa application relating to Kea “University”, information obtained from Kea and inferences drawn therefrom. The
decision-maker concluded that the petitioner must have applied prior to 15 March 2009 for a 2 year programme for
which the entrance requirements appear to include at least 1 year of higher education. She could not have started
the course before the summer intake in 2009. At page 16 there is a consideration of reasons why it would not be
possible to register at Kea in the name YZ and remain unaware of the YZ identity. The petitioner's account that she
did not know the name of Kea or its location was found implausible given her statements that at times she travelled
there alone by public transport. The interrelationship of the time when the petitioner must have ceased studying at
Kea is noted not to fit with her statement of when she came to the UK. At page 17 the petitioner's account that she
did not know the location of a Chinese Restaurant where she said she was forced to work, or where she had lived,
but to and from where she said that she travelled alone was not considered plausible.
**The grounds on which the decisions are challenged and the position of parties**

[26]     Founding on _Mandalia v_ _Secretary of State for the Home Department [2015] 1 WLR 4546Ms Irvine_
contended that the decision-maker had erred in law by failing to apply the relevant guidance in certain specified
respects:

∙   Failing to recognise trafficking as a process and compartmentalising the assessment of the petitioner's
history. In particular, on the petitioner's account Mr Nai featured both as controlling the petitioner in
Denmark and bringing her to London and taking her to a house there. Having accepted these facts in
relation to the UK, the decision-maker had erred in failing to give effect to their significance in relation to
what occurred in Denmark.

∙   Overestimating and misapplying the significance of the petitioner not being subject to control at all
times in Denmark given the definition of “means” and the fact that the petitioner claimed to be a child when
in Denmark.

∙   This is also said to be an error of law over and above a failure to follow guidance.

∙   Failure to take account of the petitioner's diagnosis of PTSD and her account that she was at times
sedated and rejecting the significance of the mitigating circumstances provided by PTSD by rejecting the
medical evidence on the basis that there was no suggestion that the petitioner suffers from cognitive
impairment.

[27]     It was said to have been irrational to accept the petitioner's evidence as to how she arrived in the UK with
a person implicitly accepted to be her trafficker whilst rejecting her evidence that she was trafficked in Denmark.

[28]     The second general attack related to the question of the petitioner's identity.

[29]     Ms Irvine submitted that the respondent had attached significance to the ZY passport being genuine
without noticing that it might be a genuine document obtained by fraudulent means or a genuine document which
had been altered, and in doing so failed to give effect to guidance, including Home Office Country Information for
China and readily ascertainable information relating to China.

[30]     It was also said to have been a material error to fail to take account of the positive outcome of a
“telephone identity interview” conducted with the petitioner on 10 March 2016.

[31]     Ms Irvine departed from any reliance on Article 8 of the ECHR. Whilst the petition referred to a number of
international legal instruments being violated by the respondent, ultimately there was no separate argument
presented. Ms Irvine contended that through whichever legal lens the situation was examined, the same errors had
been made by the respondent which had the same effect.

[32]     Ms Irvine did not seek to maintain that the respondent was at fault by refraining from carrying out further
investigation into the petitioner's true identity.


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

[33]     Ms Irvine did not seek to make anything of information referred to in the amended paragraph 6 of the
petition as having been obtained in November 2018, accepting that it had not been before the decision maker and
that if the petitioner wishes to make anything of it she would have to ask the respondent to reconsider the case.

[34]     Both Ms Irvine and Mr Webster adopted and expanded on their notes of argument and I have considered
all of the written and oral submissions made on either side.
**Analysis**

[35]     Mr Webster accepted that a failure to follow relevant departmental guidance would in the circumstances of
this case amount to the kind of legal error at common law which would permit the court to exercise its supervisory
jurisdiction and I proceed on that basis.

[36]     Parties agreed that I should approach the case on the footing that there was a need: ”for decisions to
show by their reasoning that every factor which might tell in favour of an applicant has been properly taken into
account” the approach proposed by LJ Carnwath in R (YH) v Secretary of State for the Home Department _[[2010] 4](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
_[All ER 448 at paragraph 24 and adopted in the trafficking context by Sir Stephen Silber in R (SF (St Lucia)) v Home](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
_Secretary [2016] 1 WLR 1439at paragraph 104._

[37]     As Mr Webster observed, this approach recognises a requirement for materiality; it is factors which might
tell in favour of the applicant which must be shown by reasoning to have been properly taken into account. It
remains the case that there must be an error of law before the court can intervene, mere disagreement with the
decision cannot be sufficient as Sir John Dyson explained in giving the judgment of the Supreme Court in _MA_
_(Somalia) v_ _Secretary of State for the Home Department_ _[2010] UKSC 49 at paragraphs 43-45 albeit he was_
discussing an appeal from a specialist tribunal.

[38]     I do not accept the contention that the petitioner erred in law by failing to treat the petitioner as a child
when considering if her account of what occurred in China and Denmark constituted trafficking. At page 7-8 of the
decision letter the nature of human trafficking per the Trafficking Convention is summarised and the different
assessment applicable in the case of a child is identified.

[39]     At pages 18-21, the Trafficking Convention criteria of (a) action, (b) means and (c) purpose in relation to
both China and Denmark were considered. It is clear that the decision-maker recognised that if the petitioner was
under 18 at the material times, which she would have been if she is LY born September 1993, “means” would not
need to feature. At page 19, in relation to China, the decision-maker states in terms: “Therefore you are not
required to meet part 'b' for this aspect of your account.” The conclusion reached was that in China, the petitioner
was a victim of child abuse but not human trafficking.

[40]     For Denmark, whilst the description of the process could have been better expressed on page 20, it is
nevertheless made clear that the decision-maker proceeded on the hypothesis, derived from the LY identity, that
the petitioner was a child in Denmark so that the “means” criterion was not applicable. The assessment at page 20
of whether the means criterion was made out is explicitly stated to have been considered, “for the sake for
completeness.”

[41]     There are a number of references to the petitioner not being subject to control at all times in Denmark, but
they should be understood in context. The first point to note is that, whilst the guidance identifies the proposition
that a person did not take an opportunity to escape means that they were not coerced as a myth, it also
acknowledges that it is nevertheless capable of pointing in that direction as I have noted above at para [10]. The
decision maker took care to note that the petitioner's account included:

“You claim to have been threatened that your mother would be harmed if you failed to comply with your alleged
traffickers demands. You also claim to have been beaten and further claim to have been locked within two
premises in Denmark.”


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

[42]     Having made that observation, the letter continued at page 20 (albeit this section was only “for the sake of
completeness:”)

“…It is noted you travelled alone, by public transport to and from university, therefore you had either access to
funds to purchase a travel ticket or you had a travel permit on your possession.

You also claim to have to have travelled to the unknown Chinese restaurant or takeaway alone. Furthermore,
your account of travelling to various establishments alone contradicts your claim to have been locked within
premises at two unknown locations in Denmark.

In line with the assessment above, it is not considered you experienced a threat or use of force or other form of
coercion with regards to this aspect of your account.”

[43]     This passage is an illustration of what I consider to be the second and more important point. I apprehend
that reference to the petitioner not being under control at all times in Denmark is primarily considered, alongside
other pertinent facts and inferences relating to Denmark, and internal contradictions within the petitioner's account,
as undermining the credibility of the petitioner's claim to have been trafficked in Denmark.

[44]     The decision-maker was aware from the materials before her that the petitioner claimed to have been
sedated at certain times and made explicit reference to this at pages 3 and 5 of the decision letter. This did not
disentitle the decision-maker from considering that the absence of any detail about the airport from which she left
China was surprising and a weakness in her account, particularly when viewed alongside other objective facts
which cast doubt on the petitioner's account of the circumstances in which she came to be in Denmark. This
assessment at the foot of page 17, which was not particularly fundamental, was made against a background of
mitigating circumstances having been acknowledged.

[45]     The medical information generally, and that from Dr Doherty in particular, was given detailed consideration
at pages 5-7 of the decision letter. At page 18 the decision-maker noted an aspect of the guidance:

“Whilst it is accepted that the trauma resulting from a trafficking experience can lead to some victims being
unable to recall facts, it is equally as (sic) reasonable to assume that a potential victim of trafficking relating an
experience that occurred to them will be more expressive and include sensory details such as what they saw,
heard, felt or thought about an event, than someone who has not had this experience.”

[46]     The analysis of medical evidence at pages 5-7 forms the background which is referred to at page 18 in the
following passage complained of by the petitioner:

“As noted above a Psychological Report and correspondence from medical professionals have been received.
It is noted that you were diagnosed as suffering from PTSD and all medical evidence submitted has been fully
considered. However, it is noted that within the various information received regarding your mental health, no
suggestion has been made that you suffer from any form of cognitive impairment, to explain your inability to
recount certain facts regarding your alleged experiences from China within Denmark.”

[47]     This suggests acceptance of the evidence about trauma and not rejection of it. I consider this passage to
demonstrate that the decision-maker was fully aware of the PTSD diagnosis and other related information but,
whilst it was accepted and taken account of, it was not considered to provide sufficient mitigation for parts of the
petitioner's account where there was a surprising lack of detail, some of which were set out at pages 17 and 18.
Indeed it is very difficult indeed to envisage how the symptoms and consequences of PTSD could account for some
of the most fundamental difficulties in the petitioner's account which I consider below; for example her claim to know
nothing (prior to flying to London) of the ZY identity in relation to which she was involved in obtaining documentation
at two embassies in Copenhagen and in which she studied at Kea over a period of months.

[48]     Turning to the point mentioned at para [27] above, I am not persuaded that the decision-maker did accept
the petitioner's account of how she came to the UK. She accepted in the three page letter of 6 March 2018 that the
petitioner's e periences ithin the UK constit ted trafficking b t that is as far as it ent Against a backgro nd of


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

the decision-maker finding that the petitioner's account lacked credibility and should be afforded little weight, I am
not persuaded that this demonstrates acceptance of the petitioner's account about who came with her to London
and what he did thereafter.

[49]     More generally, I am not persuaded that there was anything irrational about accepting part of the
petitioner's account whilst rejecting other parts. In the first place, as a matter of generality a finder of fact is entitled
to accept one part of an account from a witness whilst rejecting another part. Secondly, insofar as the UK is
concerned, there was a body of supportive evidence such as the circumstances of the petitioner coming to the
attention of the police in Glasgow and evidence of her PTSD and all of the information from TARA (Trafficking
Awareness Raising Alliance), Community Psychiatric Nurses and Dr Doherty's psychological assessment of the
petitioner's condition in 2015. Not only was there material available to support her account of her experiences within
the UK, on the face of it there was no reason to doubt it.

[50]     The position relating to Denmark was different and it had implications which bore relevantly on the
circumstances in which the petitioner left China. It was a reasonable inference that the petitioner must have applied
to participate in a course at Kea before March 2009, at which time on her own account the petitioner may well have
been in China, although that cannot be known with certainty. The paucity of information which the petitioner could
provide as to the airport by which she says she left China was considered. Even allowing for the care which must
be taken where an account comes from someone who had been traumatised, the respondent was entitled to
consider this to be a weakness in the credibility of the petitioner's account for the reasons given.

[51]     It was also a reasonable inference that somebody must have paid fees for the petitioner's attendance at
Kea. On the information available at the time, it was reasonable to conclude that those fees would have exceeded
12000 Euros. As the decision-maker noted, this did not sit easily alongside an account of the petitioner being sold
and trafficked to settle a debt. The analysis of information and the conclusion that the petitioner must have known of
the identity of ZY born August 1990 was a reasonable one which tended to undermine the credibility of the
complainer's account that she had no knowledge of that identity. The petitioner must have attended at the Chinese
and British Embassies in Denmark in order for her photograph to be in the passport and for her to have obtained a
visa to enter the UK. Even allowing for the risk of succumbing to a myth, and allowing for the petitioner's
explanation that threats were made to her own safety and that of her mother, her account of relative freedom of
movement at times in Denmark, whilst not inevitably destructive of her being a trafficked person there, was capable
of undermining aspects of her account, particularly when viewed alongside the factors identified relating to the ZY
passport and the petitioner's admitted attendance at what must have been Kea.

[52]     I am not persuaded that the decision-maker erred by failing to consider trafficking as a process. The
petitioner's whole account of events over more than five years was considered against relevant law and guidance,
but the evidence available in relation to different chapters of that account was different in quantity and quality as I
have discussed in the preceding paragraphs. The specific point about Mr Nai is discussed at para [48] above.

[53]     Whilst the respondent ascertained that the petitioner had used an identity and travel documents in the
name ZY born September 1990, at no time was a conclusion reached that this was the petitioner's true identity. The
letters of 6 March 2018 proceeded on the basis of both identities and facts were considered on the hypothesis that
the petitioner's true age and date of birth was that which she stated in giving the name LY, as she consistently did
in her dealings with investigative and therapeutic agencies and individuals in the UK. The primary importance of the
ZY identity is that related facts and circumstances about passports, a visa and the means of their acquisition, and
information from Kea which was gleaned therefrom, were apt to cast considerable doubt generally on the
petitioner's account of what went on in Denmark and why she came to be there.

[54]     Given the conclusions I have reached in the preceding paragraph, I consider there to be no substance in
the argument that the decision-maker failed to consider possibilities other than the ZY passport being genuine and
obtained by the petitioner. The decision-maker's treatment of the ZY passport and identity discloses no error of law.
In any event, as Mr Webster submitted, had this been a live issue the approach of the Upper Tribunal in Tanveer
_Ahmed v_ _Secretary of State for the Home Department [2002] INLR 345 at paragraphs 35-36 would have been_


-----

DEPARTMENT Respondent 2019 Scot (D) 16/2

germane. In the petitioner's case it could not be maintained that the decision-maker failed to consider the
information relating to identity as a whole.

[55]     I find no substance in the argument that the absence of an explicit reference to the impression formed
over the telephone, that the petitioner's accent was consistent with her coming from one part of China and not
coming from another, was a material failure to have regard to relevant information. It seems likely that this
information was amongst the UKVI notes to which reference was made in the decision letter. However, even if it
was missed, this fact could not provide any meaningful support for any part of the petitioner's account which was
rejected as lacking credibility. It might have had some slight significance in supporting her general account of
moving from one part of China to another when her mother took up with another man, but the respondent accepted
that the petitioner was sexually abused as a child in China. That acceptance deprives this point of any force at all.
**Decision**

[56]     I am not persuaded that the decision-maker made any material error in law in reaching the decision
complained of which was reasonably open to her on the information before her. Accordingly the petition is refused.
**Expenses**

[57]     I shall reserve all questions of expenses.

Crown Copyright

**End of Document**


-----

