# JR v Advocate General for Scotland 2024 Scot (D) 18/6

[2024] CSOH 64

Outer House, Court of Session

Lady Poole

20 June 2024

**SCOTLAND – JUDICIAL REVIEW – IMMIGRATION – CERTIFICATION OF PROTECTION AND HUMAN**
**RIGHTS CLAIMS AS CLEARLY UNFOUNDED – PERMISSION TO PROCEED – TRANSFER TO UPPER**
**TRIBUNAL**
Abstract

_The Outer House of the Court of Session granted permission for a judicial review petition by an Albanian asylum_
_seeker, challenging a Home Office decision to certify his protection and human rights claims as clearly unfounded_
_[under s 94 of the Nationality, Immigration and Asylum Act 2002, to proceed on some of the grounds in the petition,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
_and refused it on others. Thereafter it transferred the application for judicial review to the Upper Tribunal (UT) for_
_determination of the grounds on which permission had been granted. The court held that in the circumstances of_
_this particular case it was appropriate for it to exercise its discretion to transfer the petition to the UT. The UT might_
_be in a particularly favourable position to determine applications for judicial review involving application of the_
_certification review principles. The parties' views did not provide any strong reason against transfer, and there was_
_no evidence that transfer would result in increased cost, delay, or insurmountable procedural difficulties. Given that_
_the court had written submissions before it and had heard argument on permission, considerations of delay and_
_expense suggested that the court should determine the issue of permission prior to transfer. The grounds in paras_
_49 and 55 of the petition passed the test for permission but those in paras 44 to 48 did not._
Digest

**Background**

The petitioner was a national of Albania. He claimed asylum in the UK on 13 February 2023. His application was
refused on 8 January 2024. He sought judicial review of a decision of the Home Office to certify his protection and
[human rights claims as clearly unfounded under s 94 of the Nationality, Immigration and Asylum Act 2002 (NIAA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
_[2002). Certification had the effect that the petitioner was not entitled to appeal the decision on his claims to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
[First-tier Tribunal (FTT) under s 82 of NIAA 2002. The claim was certified because the decision maker considered](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
that the application was so wholly lacking in substance that it was bound to fail before the tribunal. An oral hearing
was ordered on whether the application for judicial review should be transferred from the Court of Session to the
Upper Tribunal (UT) for determination, and if so at what stage, and whether to grant permission for the petition to
proceed.

**Issues and decisions**

(1) Whether the application for judicial review should be transferred from the Court of Session to the UT for
determination, and if so at what stage.


-----

It had already been accepted in the pleadings that the petition was subject to discretionary transfer under s 20(1) of
[the Tribunals, Courts and Enforcement Act 2007 (TCEA 2007). The petitioner expressed neutrality on the issue of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)
whether it should be transferred. It was said that there was force in the matter being remitted to a specialist tribunal
to which Parliament had given the power to the court to transfer responsibility in appropriate cases. However,
reasons why the court might not do so were that it had the requisite experience and knowledge to determine the
case itself, the right to appeal further without permission would be lost, and the case was different from the one
reported example of a transfer the petitioner had been able to find. The respondent invited the court not to exercise
its discretion to transfer the case. It was suggested that the court was better suited to carry out the review function.
Underlying that view was the fact that cases were not usually transferred in Scotland, with the result that such
cases might be relatively unfamiliar in the UT.

_[Section 20(1) of TCEA 2007 provided: 'Where an application is made to the supervisory jurisdiction of the Court of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61W0-TWPY-Y0TB-00000-00&context=1519360)_
Session, the Court—(a) must, if Conditions 1 and 2 are met, and (b) may, if Conditions 1 and 3 are met, but
Condition 2 is not, by order transfer the application to the Upper Tribunal. Applying the conditions for discretionary
transfer in s 20, condition 1 was met because this petition did not seek anything other than the supervisory
jurisdiction of the Court of Session. Condition 2 was not met, because the subject matter of the petition was not in a
class specified in an Act of Sederunt for mandatory transfer. Condition 3 was met because the subject matter of the
petition was not a devolved Scottish matter, since immigration, including asylum, was a reserved matter in the
_[Scotland Act 1998. Consequently the court had a discretion to transfer the petition to the UT under s 20(1)(b) of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0K7-00000-00&context=1519360)_
_[TCEA 2007. The next stage was to decide if the court was satisfied in all the circumstances that it was appropriate](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)_
to transfer the application, applying r 58.5(3)(b) of the Court of Session Rules. In order to decide whether it was
appropriate to exercise discretion to transfer a qualifying application for judicial review to the UT, regard had to be
had to the circumstances of the particular application before the court. The most significant factor for the court in
this application for judicial review was the nature of the issues for determination. The petition did not raise any point
of general public importance, and was not the first in a number of similar cases which might benefit from being
determined in the Court of Session. The test which had to be applied in this particular type of judicial review, a
challenge to a decision to certify a claim as clearly unfounded, was streamlined and well established. There was
therefore no particular benefit in the case continuing in the Court of Session. The UT had wide experience of
appeals from the FTT in asylum cases, including those raising human rights or humanitarian protection issues. It
was in a particularly favourable position to determine whether human rights and protection claims in a particular
case would be bound to fail before the FTT. Although the court had regard to the parties' views, they did not provide
any strong reason against transfer. The petitioner was in essence neutral. The respondent's views were based on
what was usually done in applications for judicial review in Scotland. But if taken to its logical conclusion, that
[approach would render the discretionary transfer provisions in TCEA 2007 and the Court of Session Rules otiose,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)
which could not have been the intention. There was no evidence before the court that transfer would result in
increased cost, delay, or insurmountable procedural difficulties, and so those were not factors which weighed
against transfer. In all the circumstances, discretionary transfer was appropriate (see [11]-[14] of the judgment).

The next question concerned the stage at which that transfer should be made. The petitioner submitted that the
court should determine permission first if deciding to transfer the case. The respondent submitted that if there were
[to be a transfer, it should occur before permission was determined. One reading of s 20A(2) of TCEA 2007 might be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)
that it was for the UT to determine time bar and permission in transferred cases. However, under s 21(5), steps or
orders already taken or made by the Court of Session in a transferred case were to be treated as taken or made by
the UT. Further, under r 58.5(2) of the Court of Session Rules, a discretionary transfer could be made instead of
determining permission, after determining permission, or at any subsequent hearing. Reading all of those provisions
together, s 20A(2) of _[TCEA 2007 had to be interpreted so that the UT's powers to determine time limits and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)_
permission arose in a discretionary transfer case where those matters had not already been determined by the
Court of Session. That left intact the Court of Session's powers to determine time limits and permission before
transferring, if it wished to do so. The test for permission for judicial review in Scotland was the same whether
determined by the Court of Session or by the UT (s 20A(2)(b) and (3) of _[TCEA 2007). Given that the court had](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)_
written submissions before it and had heard argument on permission, considerations of delay and expense
suggested that the court should determine the issue of permission prior to transfer (see [15] of the judgment).


-----

(2) Whether the court should grant permission for the petition to proceed.

[The petition could only proceed if permission was granted. The statutory tests that had to be applied were in s 27B](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5S2R-9F71-DYCN-C0TP-00000-00&context=1519360)
of the Court of Session Act 1988. The applicant had to demonstrate a sufficient interest in the subject matter of the
application, and the application had to have a real prospect of success. Permission was not to be interpreted as an
insurmountable barrier preventing what might appear to be a weak case from being fully argued in due course. The
authorities had accepted that the petitioner was a victim of **_modern slavery. He was trafficked to work in a_**
cannabis farm in the UK. He said that he was trafficked by men to whom his father owed money. Despite the
respondent's arguments to the contrary, the grounds in the petition focussed between paras 51 and 55 passed the
test for permission. The grounds in paras 49 and 50 also passed the test, to the extent that the matters in them
were relevant to the question of whether the human rights claim would be bound to fail before the FTT (as opposed
to challenging the process before the initial decision maker). In determining those grounds the UT would apply the
principles that the Court of Session would apply in deciding an application to its supervisory jurisdiction (s 21 of
_[TCEA 2007), including the certification review principles. Permission would be refused on the grounds between](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y07S-00000-00&context=1519360)_
paras 44 and 49 of the petition. The grounds in paras 45 and 46, predicated on the petitioner's human rights claim
not having been certified, had no prospects of success. The decision letter of 8 January 2024 had to be read as a
whole. On the first page it stated in terms: 'You do not have a right of appeal against this decision because your
protection and human rights claims have been certified as clearly unfounded under _[section 94 of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-748W-00000-00&context=1519360)_
Immigration and Asylum Act 2002.' The decision letter set out the test applied and recorded a decision 'to refuse
your claim and certify it as clearly unfounded'. While certification decisions were distinct from decisions on the
merits of a human rights or protection claim, it was crystal clear that in this particular decision the human rights
claim as well as the protection claim was certified as clearly unfounded. To the extent that the challenge alleged a
failure to give adequate reasons for the certification of the human rights claim, that was not a relevant challenge in
this particular type of judicial review. The same could be said for the challenge in para 48 of the petition based on
an alleged application of the wrong rules by the initial decision maker. Under the certification review principles, the
same question had to be asked as the person who made the certification decision, of whether the human rights and
protection claims were clearly unfounded. Whether or not the initial decision maker applied the correct passages in
the Immigration Rules or gave detailed enough reasons were matters which were not strictly to the point. The
grounds in paras 47 and 48 also had no real prospects of success. The court therefore granted permission on the
grounds in paras 49 to 55 of the petition, and refused it on the grounds in paras 44 to 48. Thereafter it transferred
the application for judicial review to the UT for determination of the grounds on which permission had been granted
(see [16]-[20] of the judgment).

_Wightman v Advocate General_ _[[2018] CSIH 18, 2018 SCLR 588, 2018 Scot (D) 12/5 at para [9] applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TY6-F641-DYMJ-018D-00000-00&context=1519360)_

_Tsiklauri v Secretary of State for the Home Dept_ _[[2020] CSIH 31, 2020 SC 495 at paras [11], [12] and [14] applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61GF-08J3-GXFD-8043-00000-00&context=1519360)_

**End of Document**


-----

