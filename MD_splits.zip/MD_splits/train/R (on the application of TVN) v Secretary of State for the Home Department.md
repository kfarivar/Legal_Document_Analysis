# R (on the application of TVN) v Secretary of State for the Home Department

## [2021] EWHC 3019 (Admin)

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 11/11/2021

# Catchwords & Digest

## IMMIGRATION - DETENTION – HUMAN TRAFFICKING

 The Administrative Court quashed a decision of the Single Competent Authority (SCA), acting on behalf of the defendant Secretary of State, that the claimant was not a victim of modern slavery in circumstances where the claimant had paid a smuggler to smuggle him into France with the expectation of paid work but had instead been transported to England and coerced into managing a cannabis factory. The claimant had applied for asylum, having served a sentence of imprisonment for his involvement in the factory, but it was refused. On appeal the claimant’s asylum had been refused by the First-tier Tribunal (Immigration and Asylum Chamber) (the FTT) deciding that the claimant had not been trafficked to the UK. The SCA relied on that decision. The court held that the SCA had erred in law in deciding that the FTT decision had damaged the claimant’s credibility before taking account of other supportive or exculpatory evidence which had been supportive of the claimant’s credibility. Further, the SCA had erred in law in primarily asking whether there had been a belief in the claimant’s account of events: the SCA ought to have asked whether, irrespective as to whether it was considered that the claimant was being truthful, the evidence as a whole showed that the claimant was not a victim of trafficking.

# Cases referring to this case


R (on the application of SM) v Secretary of State for the Home Department

_[[2024] EWHC 1683 (Admin), [2024] All ER (D) 19 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6CDB-6583-RRV3-7047-00000-00&context=1519360)_
Considered

# Cases considered by this case

MN v Secretary of State for the Home Department; IXU v Secretary of State for the
Home Department (AIRE Centre and another intervening)


01/07/2024

AdminCt

21/12/2020

CACivD


-----

_[[2020] EWCA Civ 1746, [2021] 1 WLR 1956, [2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
Applied
R (on the application of Dutta) v General Medical Council

_[[2020] EWHC 1974 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60DJ-RBP3-GXFD-84CC-00000-00&context=1519360)_
Considered

MS (Pakistan) v Secretary of State for the Home Department

_[[2020] UKSC 9, [2020] 3 All ER 733, [2020] INLR 460, [2020] All ER (D) 111 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60J0-VFB3-GXFD-805F-00000-00&context=1519360)_
Applied

Uddin v Secretary of State for the Home Department

_[[2020] EWCA Civ 338, [2020] 1 WLR 1562, [2020] 2 FLR 826, [2020] All ER (D) 78](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60YG-FF63-CGXG-041J-00000-00&context=1519360)_
_[(Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YDN-DCS3-CGXG-0274-00000-00&context=1519360)_
Applied

Kimathi and others v Foreign and Commonwealth Office

_[[2018] EWHC 2066 (QB), [2018] All ER (D) 145 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T57-K271-DYBP-N3G4-00000-00&context=1519360)_
Considered

R (on the application of CPRE Kent) v Dover District Council and another

_[[2017] UKSC 79, [2018] 2 All ER 121, [2018] 1 WLR 108, [2018] LLR 305, [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5S06-5W61-DYBP-M2JR-00000-00&context=1519360)_
_[EGLR 1, [2017] All ER (D) 22 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V81-43N2-D6MY-P1WP-00000-00&context=1519360)_
Applied

Carmarthenshire County Council v Y

_[[2017] EWFC 36, [2017] 4 WLR 136, [2018] 1 FLR 361](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMC1-DY9F-G4SR-00000-00&context=1519360)_
Considered

Lachaux v Lachaux

_[[2017] EWHC 385 (Fam), [2017] 4 WLR 57, [2018] 1 FLR 380, [2017] All ER (D) 54](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G1H0-00000-00&context=1519360)_
_[(Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N24-80X1-DYBP-N46K-00000-00&context=1519360)_
Considered

R (on the application of SF) v Secretary of State for the Home Department

_[[2015] EWHC 2705 (Admin), [2016] 1 WLR 1439, [2015] All ER (D) 03 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5H25-6TR1-DYBP-N1YV-00000-00&context=1519360)_
Considered

Gestmin SGPS S.A. v Credit Suisse (UK) Ltd

_[[2013] EWHC 3560 (Comm), [2013] All ER (D) 191 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59V3-FFM1-DYBP-N3B6-00000-00&context=1519360)_
Followed

R (on the application of YH) v Secretary of State for the Home Department

_[[2010] EWCA Civ 116, [2010] 4 All ER 448, [2010] All ER (D) 280 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
Applied

Mibanga v Secretary of State for the Home Department

_[[2005] EWCA Civ 367, [2005] INLR 377, [2005] All ER (D) 307 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG21-DYBP-P50W-00000-00&context=1519360)_
Applied

R v Secretary of State for the Home Department, ex p Doody

[[1994] 1 AC 531, [1993] 3 All ER 92, [1993] 3 WLR 154, [1993] 3 LRC 428, (1993)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60GY-00000-00&context=1519360)
_[Times, 29 June](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PN6-Y2H0-TXX3-200B-00000-00&context=1519360)_
Applied

R v Lucas

[[1981] QB 720, [1981] 2 All ER 1008, [1981] 3 WLR 120](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-614T-00000-00&context=1519360)
Applied


22/07/2020

AdminCt

18/03/2020

SC

12/03/2020

CACivD

02/08/2018

QBD

06/12/2017

SC

30/06/2017

FamCt

02/03/2017

FamD

30/09/2015

AdminCt

15/11/2013

CommlCt

25/02/2010

CACivD

17/03/2005

CACivD

24/06/1993

HL

19/05/1981

CACrimD


-----

**End of Document**


-----

