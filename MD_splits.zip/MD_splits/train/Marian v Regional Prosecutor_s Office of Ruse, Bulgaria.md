# Marian v Regional Prosecutor's Office of Ruse, Bulgaria [2019] EWHC 602
 (Admin)

Queen's Bench Division, Administrative Court (London)

Lewis J

13 March 2019Judgment

**Ms Saoirse Townshend (instructed by Hodge Jones Allen Solicitors) for the Appellant**

**Ms Catherine Brown (instructed by Crown Prosecution Extradition Unit) for the Respondent**

Hearing dates: 7 and 8 March 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**The Honourable Mr Justice Lewis:**

INTRODUCTION

1. This is an appeal from a decision of Deputy Senior District Judge Ikram in the Westminster Magistrates'
Court on 31 August 2018. By that decision, the district judge found that there were no bars under the
_[Extradition Act 2003 (“the Act”) to extradition of the Appellant to Bulgaria pursuant to a European Arrest](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)_
Warrant (“EAW”). He found that extradition was necessary and proportionate and he ordered the
Appellant's extradition to Bulgaria. Permission to appeal was granted by Sir Ross Cranston for the reason
that new evidence in the form of a report by Dr Obuaya, a consultant psychiatrist, might make the district
judge's conclusion wrong.

THE BACKGROUND

The EAW

2. An EAW was issued by the Bulgarian authorities on 5 January 2016. That sought the extradition of the
Appellant for two alleged offences of breach of the law on trademarks. It is alleged that on the first
occasion, on 21 August 2013, the Appellant travelled from Romania in a car driven by another person to
Ruse in Bulgaria where he purchased a total of 847 tracksuits bearing counterfeit well-known brand names
intending to sell them in Romania. The EAW says that the Appellant was stopped at the border, and, as the
Appellant did not have the necessary documents for the purchased products, he surrendered the goods to
the Bulgarian police authorities.

3. On 25 August 2013, it is alleged that the Appellant again went to Ruse with a view to purchasing
tracksuits bearing counterfeit well-known brand names and then re-selling them. It is alleged that a man
named Vasi, and another man, were waiting in the car when the Appellant went to purchase the goods.
Again, it is alleged that they were stopped at the border and as the Appellant did not have the necessary
documentation he surrendered the goods to the Bulgarian police authorities.

4. The EAW was certified by the National Crime Agency on 12 January 2016.


-----

The Appellant's Account of Events

5. The Appellant, Mr Marian, is a 35 year old Romanian national. He grew up in an orphanage in Romania
and had no contact with his parents who are no longer alive. He has a low intelligence level as measured
by his IQ. He has consistently maintained that he began working in Romania for a man known as Vasi. He
has said that Vasi took his identity card from him. He said that lived at Vasi's house and carried out work
for others, on Vasi's instructions, but the Appellant says he did not receive payment for that work. He says
he was beaten on one occasion and was frightened of Vasi.

6. Mr Marian says that he was involved in the two offences comprised in the European Arrest Warrant in
this case on the instructions of Vasi. He says that ultimately Vasi made him travel to Spain where he lived
with Vasi and Vasi's family. He says that he slept on cardboard in the kitchen. He says he was told there
would be a job in construction for him but in fact there was no job. He was forced to beg and told that he
would have to beg in order to obtain money for the flight home to Romania. The Appellant says that he
took his identity card and escaped from Vasi. He says that he went to live in a Red Cross camp and
worked on a strawberry farm. He says that he left Spain and came to the United Kingdom.

7. Mr Marian was arrested in the United Kingdom and was brought before a district judge on 14 October
2017. He was detained in custody and remained there until he was granted bail on 15 December 217. He
went to live at the home of someone suggested by his cellmate. He says that that man took all his money
and made him work unpaid and the man said that Mr Marian would go back to prison if he did not.
Ultimately, on one of the days that he had to report to the police, he told a police officer that he was worried
about staying at the property. That officer contacted the Salvation Army. A minister there arranged for him
to stay at the home of a Romanian pastor.

Victim of Trafficking

8. On 9 February 2018, the **_Modern Slavery and Human Trafficking Unit Competent Authority (“the_**
Authority”) notified the NCA that it had decided that there were reasonable grounds to believe that Mr
Marian was the victim of modern slavery. There was then a 45 day period for reflection. On 24 May 2018,
the Authority confirmed that it had concluded that Mr Marian was the victim of modern slavery.

The Hearing

9. At the hearing before the district judge (which was held on more than one day), the district judge heard
evidence from Mr Marian, and had reports and heard evidence from Dr Walsh and a Bulgarian lawyer, Ms
Asya Mandzhukova-Stoyanova. The district judge had reports from the Group of Experts of Action against
Trafficking in Human Beings (known as GRETA) and the United States' State Department's Trafficking
Reports on Bulgaria for 2017 and 2018. Dr Walsh was a clinical psychologist. She concluded that Mr
Marian met the criteria for a diagnosis of major depressive disorder. She concluded that he had a history of
being passive when in exploitative situations leaving him highly vulnerable to ongoing exploitation. He had
some symptoms of post-traumatic stress disorder but these did not satisfy the criteria a diagnosis of that
condition. He did not display a current risk of suicide but was vulnerable to harm from others.

The Decision of the District Judge

10. In light of the grounds of appeal, it is necessary to consider the district judge's conclusions on only
three issues. First, he considered section 25 of the Act and whether “the physical or mental condition of the
person in respect of whom [the EAW is issued] is such that it would be unjust or oppressive to extradite
him”. He concluded:

“I note his liver condition, per letter dated 31 August 2018 and other health issues raised. I note his
hepatitis condition but it is not 'active'.

Dr Walsh's report concluded he suffers from a severe major depressive disorder and other psychological
difficulties. He is vulnerable and she was of the view that extradition would highly likely to lead to a
deterioration in Mr Marian's mental health. There would be a risk of he being exploited again if returned in
Bulgaria but I note that this has happened even here in the UK.


-----

In my view. Dr Walsh is unable to speak at all on what support would be afforded to the [Requested
Person] in Bulgaria. Risks exist, but they exist in the UK, let alone if extradition were ordered.

Bulgaria, as member within the EU will be presumed to discharge its obligations to comply with its
obligations under the ECHR. Further, no evidence to comply with its obligations under the ECHR. Further,
no evidence has been presented that the care he would receive in Bulgaria would be inadequate so that it
would be oppressive to return him there.

I have not been persuaded that it would be unjust or oppressive to extradite the RP for reason for his
condition/s”

11. Next the district judge considered the submission that there would be a real risk that Mr Marian would
be exposed to a breach of his rights under Article 4 of the European Convention on Human Rights
(“ECHR”). That provides, so far as material, that:

“Prohibition of slavery and forced labour

1. No one shall be held in slavery of servitude.

2. No one shall be required to perform forced or compulsory labour/.

3. [Exceptions].”

12. There is an international treaty dealing with attempts to suppress slavery and trafficking, namely the
Protocol to the United Nations Convention against Transnational Organized Crime, named the Protocol to
Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children, supplementing the
United Nations Convention against Transnational Organized Crime (the “Palermo Protocol”). The
European Union has adopted Directive 2011/36/EU of the European Parliament and of the Council of 5
April 2011 on preventing and combating trafficking requiring Member States to adopt measures to
criminalise trafficking and to protect the victims of trafficking (“the Directive”).

13. The district judge referred to the decision of the Divisional Court in Olga C v The Prosecutor General's
_Office of the Republic of Latvia_ _[2016] EWHC 2211 (Admin) where the Court observed that:_

“A direct appeal to article 4 ECHR would require a requested person to rebut by evidence the strong
presumption that the country concerned would abide by its international obligations under the ECHR: Krolik
_v Poland [2012] EWHC 2357 (Admin) [2013] 1 W.L.R. 490. Alternatively, and by analogy with cases under_
article 3 when the risk of ill-treatment etc. comes from non-state actors, a requested person may, at least in
theory, be able to show by reference to the circumstances of his case that the requesting state cannot
provide sufficient protection: see the discussion in _R (Bagdanovicius) v Secretary of State for the Home_
_Department [2015] UKHL 38; [2005] 2 AC 668.”_

14. In the present case, it was not suggested that the authorities in Bulgaria would subject the Appellant to
treatment which would breach his rights under Article 4 ECHR. Rather, it was suggested that Mr Marian
would be vulnerable to being trafficked by criminals or others if he were returned to Bulgaria. The district
judge noted that to succeed on this ground, the Appellant would need to show that he was at real risk of
being trafficked and that the requesting state (Bulgaria) was not in a position to provide adequate
protection.

15. The district judge noted that he was not bound by the decision of the Authority that Mr Marian had
been trafficked but he stated that he would not go behind that opinion. I assume, therefore, that the district
judge accepted that the Appellant had been a victim of trafficking at some point. The district judge noted
that he was entitled to assume that Bulgaria, as a member of the Council of Europe, would comply with its
obligations under the ECHR.

16. The district judge observed that the US State Department 2017 report noted that Bulgaria was making
significant efforts, and has devoted significant resources, to a written plan which, if implemented would
constitute significant efforts to meet minimum standards. He observed that the most recent, 2018, US State
Department Report had improved the ranking of Bulgaria (moving it from Tier 2 Watch List to Tier 2). That
report indicated that the Bulgarian government had demonstrated significant efforts to address the issue of


-----

trafficking, identifying more victims and convicting more traffickers. He referred to the GRETA report of
2015 which indicated progress had been made in a number of areas although some issues were identified
for immediate action. He noted the evidence of Ms Mandzhukova-Stoyanova. He noted that she had not in
fact been involved in any trafficking cases in Bulgaria and did not have any personal knowledge and he
treated her evidence with caution given her lack of direct knowledge of the relevant issues. He said that
she had given her personal view, based on a reading of the literature, and he was not assisted by her
evidence. He concluded that:

“The RP has been identified a victim of people trafficking and this will be made known to the Bulgarian
authorities. Considering the evidence as a whole, I am of the view that the RP's evidence falls far short of
establishing the propositions that Bulgaria is failing to abide by its international obligations.

I am not persuaded that there is a real risk that the Bulgarian authorities will fail to discharge their duties to
protect the RP from further trafficking.

**I am therefore unable to accede to the argument under Article 4.”**

17. Finally, the district judge turned to the question of whether extradition would be disproportionate
interference with the Appellant's right to respect for his private life under Article 8 ECHR. If extradition were
not compatible with the Appellant's Convention rights, then he would have had to order the discharge of the
Appellant pursuant to section 21 of the Act.

18. First, the district judge held that the Appellant was not a fugitive from justice. That was material as, if
the Appellant had been a fugitive from justice, there would be a strong public interest in not allowing the
United Kingdom to become a safe haven for fugitives from justice: see paragraphs 9 and 48(ii) of the
decision of the Divisional Court in Polish Judicial Authorities v Celinski [2015] EWHC 1274 (Admin).

19. The district judge then set out the factors favouring extradition. The district judge referred to the fact
that the allegations were that the Appellant had on two occasions bought large numbers of tracksuits
bearing counterfeit trademarks with an estimated value of about £97,000. That amount was significant. The
district judge regarded the offences as serious.

20. The district judge considered that it would not be appropriate for him to consider whether the Appellant
was under the control of Vasi whilst allegedly committing these offences in Bulgaria. That was for the trial
court in Bulgaria, and a matter for the relevant authorities in Bulgaria to explore in deciding whether the
Appellant should be prosecuted. Pausing there, Article 8 of the Directive provides that Member States must
ensure that competent authorities are entitled not to prosecute or impose penalties on victims of trafficking
when their involvement in those activities is the result of their being trafficked as defined in the Directive.
The evidence is that Bulgarian law provides that an act is not to be considered culpably committed if it
were performed by a person who is a victim of trafficking and was forced to perform the act as a result of
being such a victim.

21. The district judge (in 2018) said that the offences were alleged to have been committed in 2013 and so
were not old. The Appellant had built up a private life in the United Kingdom but only for a short time as he
arrived here in 2017. He had not established any family life in the United Kingdom.

22. The district judge then considered the factors weighing against extradition. He referred to the fact that
the allegations were not the gravest allegations that a defendant could face. He said that:

“In relation to his own circumstances, I find that the RP is of low intelligence (as measured on IQ), is
suggestable and has health issues including a severe depressive disorder. I also note his liver condition
but there is no indication of what treatment would be required. I accept the argument that he can properly
be described as vulnerable. I find that he has been trafficked into the UK. He has been taken advantage of
whilst even in this country. I accept that, if returned, he would be more vulnerable to being re-trafficked.
That's is the profile of many who are victims of trafficking. On the other hand, the authorities would not be
aware of his history and in accordance with their obligations, look to put in measures to afford him more
protection.


-----

I do not intend to recite all that has been said on his behalf by the various live witnesses and within the
statements that I have read. There is considerable sympathy for him. He has not been here for over a year,
being arrested on arrival into the UK and he clearly has various issues and vulnerabilities.”

23. The district judge concluded that:

“Interference with private rights have to be balanced with the desire that people accused of crimes should
be brought to trial; that people convicted of crimes should serve their sentences and that the UK should
honour its treaty obligations to other countries.

Consideration of Article 8 rights requires balancing exercise and an exercise in proportionality. In this case,
critically, he has been in the UK for a very short period indeed. The simple fact is that he has not built any
significant private life here. That is a very significant factor in the balancing exercise. He has no family here
so he is unable to pursue an argument on the basis of family rights.

In carrying out that balancing exercise, I am not satisfied that extradition would amount to a
disproportionate interference with the RP's Article 8 rights.”

24. The district judge therefore decided that extradition was proportionate and necessary. He ordered that
the Appellant be extradited to Bulgaria.

The Application to Admit New Evidence

25. The Appellant applies to admit new evidence in the form of:

(1) A psychiatric report of Dr Obuaya dated 18 October 2018;

(2) A letter from Dr Lewthwaite dated 1 November 2018 confirming that the Appellant has chronic
hepatitis;

(3) A second addendum proof of evidence from the Appellant setting out the events that have happened
since the decision of the district judge on 31 August 2018; and

(4) Statements from the Appellant's solicitor (Ms Carita Thomas) and his former anti-trafficking support
worker, Ms Carolyn Smith.

26. The Respondent sought to adduce new evidence in the form of a letter dated 4 February 2019 from
the Bulgarian authorities indicating that if the Appellant were extradited then, on his arrival in Bulgaria, he
would undergo “a complex forensic psychiatric and psychological expert examination in order to determine
his fitness to be involved in criminal proceedings”.

27. The proof of evidence of Mr Marian says that after the decision of the district judge, the Romanian
pastor who was assisting him (and gave evidence on his behalf to the district judge) began exploiting Mr
Marian. Mr Marian says that he would work cleaning houses or gardens or he would get work from the
pastor in the form of translating for people trying to open bank accounts. He also says that he worked for
the pastor to get commercial spaces ready to be opened. He was not paid for this work. He had a room
with a bed but often someone else would use this room and he had to sleep on the floor in the office on a
mattress. He had little money to heat the room and frequently could not shower because he was asked to
pay for heating the water and he did not have much money. Following an incident over a mattress, the
Appellant says he was assaulted (by someone else, not the pastor). He contacted the police and Ms
Carolyn Smith, the anti-trafficking support worker. She found him a place at Palm Cove where he has his
own room with heating and fridge for medication. He shares the kitchen and bathroom with other people.

28. Ms Carolyn Smith confirmed in her statement that she received telephone calls form Mr Marian on 3
February 2019 saying that he had been assaulted. She told him to go to hospital and speak to the police.
She said that she was concerned that Mr Marian was being exploited by other Romanians. She managed
to get him a five day placement at a College to take a programme aimed to support and educate survivors
of **_modern slavery and human trafficking and re-build their self-confidence, independence and ability to_**
trust. She then found him accommodation at Palm Cove.


-----

29. Dr Obuaya is a consultant psychiatrist and is a visiting psychiatrist at the Helen Bamber Foundation.
He assessed Mr Marian as meeting the criteria for diagnosis of a severe depressive episode. He agreed, in
that respect, with the diagnosis of Dr Walsh. Dr Obuaya noted that the recommended treatment for such a
severe depressive episode would involve the use of medication and psychological treatment. The
prognosis would be good if those recommendations were implemented.

30. Dr Obuaya also went on to consider the possible mental health consequences if Mr Marian were
extradited to Bulgaria and imprisoned or even if he were subsequently released into the community. He
concluded that Mr Marian woUld struggle to establish a life in Bulgaria if he suffered from depression and
had no adequate personal professional support. Mr Marian has no friends or family in Bulgaria (he is from
Romania and, apart from the allegations involving the two visits in 2013 to Ruse, a town in Bulgaria to
purchase counterfeit tracksuits and possible court appearances there, there is no evidence of him living in
Bulgaria or having any links there). Dr Obuaya said that:

“55. It is likely to be very difficult for him to engage in the tasks needed to establish a new life for himself
there, even if he were to be released subsequently. Severe depression commonly adversely affects
patients' ability to carry out tasks needed to support themselves, such as finding work and accommodation.
I would concur with Dr Walsh that he would also be at risk of further exploitation and abuse if released into
the community in Bulgaria, given his history of being subjected to both exploitation and abuse.”

31. Dr Obuaya considered what would be likely to happen to Mr Marian if he were imprisoned in Bulgaria.
He very fairly noted that he did not have any expertise which would enable him to comment on the
psychological therapy that would be available to Mr Marian in a Bulgarian prison. However, he noted that
the success of interventions aimed at supporting his well-being would be dependent on the establishment
of a “safe” environment for him and the continuation of the bond between him and his therapist. He said in
his report:

“57. If he were extradited to and imprisoned in Bulgaria, where he does not think he will be safe, [Mr
Marian] is unlikely to feel this sense of safety and thus his ability to trust any therapist or other health care
professionals there would be compromised, even if such therapy were available to him in a prison setting.
Thus treatment is less likely to be effective in prison, where he is likely to become withdrawn and the act of
being imprisoned is likely to exacerbate his depressive illness as it will act as an adverse life event (as
noted above in paragraph 41 adverse life events can precipitate depressive episodes: they can also
perpetuate ongoing depressive episodes).

58. It is likely that he would become socially withdrawn if he continues to live in fear for his safety, making it
less likely that he would seek support from mental health services there, assuming they would be available
to him.

59. Furthermore, if [Mr Marian] is extradited before the completion of any further psychological therapy he
may begin in the UK, its discontinuation is likely to be interpreted by him as another loss, cause him
psychological distress, make it less likely that he would seek professional help and possibly further impair
his ability to form trusting relationships in general in future. There is likely to be a similar adverse impact
from the loss of the support he has received ….. in the UK.”

32. Section 27(4) of the Act provides that one of the conditions under which the High Court on appeal may
allow an appeal is if:

“(a) an issue is raised that was not raised at the extradition hearing or evidence is available that was not
available at the extradition hearing;

(b) the issue or evidence would have resulted in the appropriate judge deciding a question before him at
the hearing extradition differently:

(c) if he had decided the issue in that way he would have been required to order the person's discharge”

33. The requirements for the admission of fresh evidence was considered by the Divisional Court in
_Szombathely City Court v Fenyvesi_ _[2009] EWHC 231 (Admin). The material needs to be material which_
either did not exist at the time of the extradition hearing or if it did exist was not reasonably obtainable at


-----

the time of the hearing. The material must be material that would have resulted in the district judge
deciding the question differently. Here the second addendum proof of evidence of Mr Marian, and the
additional witness statements of Ms Carita Smith and Ms Carolyn Smith refer to events which occurred
after the extradition hearing and, therefore, are material which was not available at the time of the hearing.
The evidence of Dr Lewthwaite addresses the Appellant's current condition in relation to his hepatitis. The
report of Dr Obuaya also addresses the current mental state of Mr Marian and was not available at the
hearing could not have been obtained with reasonable diligence. For the reasons set out below, I consider
that all that material is, on the particular factual circumstances of this case, decisive. I therefore admit the
evidence of Dr Obuaya, Dr Lewthwaite, the Appellant's second addendum proof of evidence, and the
statements of Ms Carita Smith and Ms Carolyn Smith. I have considered the evidence from the Bulgarian
authorities dated 4 February 2019 but, ultimately, this did not affect matters and it is not necessary to rule
on the application to admit that evidence.

THE ISSUES

34. Against that background, Ms Townshend for the Appellant submits that:

(1) The extradition of Mr Marian would be a disproportionate interference with the right to respect for his
private life and extradition would therefore be contrary to section 21 of the Act;

(2) The district judge erred in concluding that Mr Marian would not face a real risk of treatment contrary to
Article 4 ECHR;

(3) The district judge erred in concluding that extradition would not be unjust or oppressive and so contrary
to section 25 of the Act.

THE FIRST ISSUE – DISPROPORTIONATE EFFECT ON THE RIGHT TO

RESPECT FOR PRIVATE LIFE

35. Ms Townshend for the Appellant submits that the only relevant factor favouring extradition is the public
interest is in upholding extradition arrangements. The district judge found that the Appellant was not a
fugitive and so the public interest in not allowing individuals to escape from justice and seek a safe haven
in the United Kingdom did not apply. Ms Townshend submitted the offences were not serious and there
had been delay. In addition, either there was a risk of the Appellant being re-trafficked if he were returned
to Bulgaria, or alternatively, if he were returned, then the Bulgarian authorities would have to accept that he
had been trafficked and so he could not be found guilty of a crime, having regard to Article 8 of the
Directive and the requirements of Bulgarian law. In all the circumstances, extradition would result in a
disproportionate interference with his rights under Article 8 ECHR

36. Ms Brown for the Respondent submitted that there was no real risk of Bulgaria failing to comply with
relevant obligations in relation to people who had been trafficked. Equally, it should not, she submitted, be
assumed that because the competent authorities in the United Kingdom accepted that the Appellant had
been trafficked, so would the Bulgarian authorities. Those authorities were entitled to make their own
assessment of the Appellant and to decide if the offences were committed whilst he was being trafficked
and as a result of being trafficked. Ms Brown accepted that the court was entitled to take account the fact
that there had been a finding by the UK Authority that the Appellant had been trafficked and to consider the
mental health evidence relating to the effect of that on the Appellant, the impact of return to Bulgaria in
those circumstances and all other relevant factors.

Discussion

37. The factor in favour of extradition in the present case is the weighty public interest in extradition in that
people accused of crimes should be brought to trial: see per Baroness Hale at paragraph 8(4) of her
judgment in _HH v Deputy Prosecutor of the Italian Republic [2013] 1 A.C.338; and paragraph 9 of the_
judgment of the Divisional Court in Celinski _[2015] EWHC 1274 (Admin)._

38. The factors against extraditing involve a combination of the particular factual circumstances in this
case First there is the fact that the offences are as they are described in the EAW trade mark offences


-----

involving the purchase for re-sale of counterfeit goods, that is goods bearing a particular brand name
where the owner of the brand has not consented to their use, and thereby causing loss to the owners of the
exclusive right. The offences are alleged to have occurred on two occasions and involve substantial
amounts of goods. They are serious allegations but, as the district judge held, they are not the gravest
allegations that a defendant could face.

39. Secondly, the Appellant has built up a private life in the United Kingdom. Thirdly, there is the passage
of time since the alleged offending. That is said to have occurred in August 2013. That is almost five and a
half years ago. The passage of time is not the result, on the evidence, of delay on the part of the Bulgarian
authorities (who would not have known where the Appellant was) nor of the Appellant (as he was found by
the district judge not to be a fugitive and was not released on conditions or subject to attendance at any
further specified hearing or location).

40. Fourthly, there is the fact that the Appellant has been found to be the subject of trafficking at some
stage. I accept it cannot be assumed, that because the competent Authority in the United Kingdom has
accepted that an individual has been trafficked, that the authorities in the requesting state will necessarily
accept that conclusion. The authorities in a requesting state are entitled to make their own assessment to
determine whether or not a person had been trafficked. They may have different and additional evidence.
Furthermore, they are entitled to determine whether the particular offences were the result of the person
being trafficked or are, in fact, unconnected with the trafficking.

41. I recognise that, on the facts of this case, the likelihood is that the Bulgarian authorities would accept
the finding of the UK Authority that the Appellant had been trafficked. I accept that given the basis on which
that decision appears to have been made – at the very least, that the Applicant was under the control of
the man, Vasi, who forced him to beg in Spain – that the Bulgarian authorities may well find that the
offending was linked with Mr Vasi controlling the Appellant. The EAW says that the Appellant was in a car
on one occasion with Vasi. The Appellant is Romanian and has no connection with Bulgaria so it may be
that the Bulgarian authorities are unlikely to have material available to them that was not available to the
UK Authority. Nonetheless, I accept that a court should not assume that the Bulgarian authorities will find
he was trafficked, or find that the offence was linked with the trafficking so that the Appellant would not be
prosecuted on return or would not be found criminally culpable. Those are matters for the Bulgarian
authorities or courts to assess if he is returned.

42. Nevertheless, as Ms Brown for the Respondent accepts, this Court can take into account the fact that
the Authority in the UK has decided that the Appellant has been trafficked at some stage. This court can
take account of the effects of being trafficked on the Appellant and the evidence now available from Dr
Obuaya of the likely consequences if the Appellant were extradited to Bulgaria. He is a man of low IQ. He
has suffered a severe depressive episode. If he is extradited and imprisoned in Bulgaria, he will be unlikely
to think that he is safe, given what has happened to him. Thus, according to Dr Obuaya, treatment in
prison, if available, is likely to be less effective as he is likely to become withdrawn and less likely to seek
help from mental health services if he is in fear for his safety. The imprisonment, according to Dr Obuaya,
would exacerbate the Appellant's depressive illness. Such an event would, in the particular circumstances
of the Appellant, precipitate depressive episodes and perpetuate existing depressive episodes. If the
Appellant were released into the community in Bulgaria (for example, if he were granted bail), Dr Obuaya's
opinion is that the Appellant would struggle to establish a new life in Bulgaria without adequate personal
and professional support. The Appellant has, of course, no ties with, and no friends or family in, Bulgaria.
He comes from Romania. Dr Obuaya's assessment is that the Appellant would be likely to find it very
difficult to engage in the tasks needed to establish a new life in Bulgaria and he would be at risk of further
exploitation and abuse given his history. The Appellant would lose the support mechanisms that he has
established in the United Kingdom.

43. Given the particular combination of circumstances in this case, that is, the nature of the alleged
offences, the passage of time, the fact that the Appellant has been the victim of trafficking, his mental
health and vulnerability, and the real problems he would now face if he were sent to Bulgaria, this is a case
where returning him now to Bulgaria for these offences would involve a disproportionate effect on his right
to respect for private life If the district judge had had the fresh evidence of Dr Obuaya and the further


-----

evidence of the Appellant's vulnerability, he would have reached a different decision on this issue and he
would have been required to discharge the Appellant pursuant to section 21 of the Act. I will therefore allow
the appeal, quash the order for the extradition of the Appellant and order that the Appellant be discharged,
pursuant to section 27(4) and (5) of the Act.

THE SECOND AND THIRD ISSUES – ARTICLE 4 ECHR AND OPPRESSION

44. In the light of my conclusions on the first issue, I can state my conclusions on the second and third
issues briefly. There is no basis for concluding that the district judge erred in his conclusion in relation to
Article 4 ECHR. The Bulgarian authorities may be presumed to comply with their obligations under Article 4
ECHR (and the obligations under the Directive). The evidence relied upon by the Appellant, including the
GRETA report, the two US State Department reports and the personal opinions of the Bulgarian lawyer, do
not begin to discharge the presumption that the Bulgarian authorities would discharge their obligations to
the Appellant if he were returned. Similarly, the evidence does not establish that it would be unjust or
oppressive to return the Appellant. The real problem in the present case is not so much the risk of retrafficking if he is returned to Bulgaria or any question that return would be oppressive as the impact on his
mental health and the fact that it would disproportionate to extradite him now, for these particular alleged
offences, given the likely adverse effect on his mental health if he were returned.

CONCLUSION

45. This appeal is allowed on the basis that given the particular combination of circumstances in this case,
that is, the nature of the alleged offences, the passage of time, the fact that the Appellant has been the
victim of trafficking, his mental health and vulnerability, and the real problems he would now face if he were
sent to Bulgaria, this is a case where extraditing him now to Bulgaria for these alleged offences would
involve a disproportionate effect on his right to respect for private life. The appeal on each of the other two
grounds fails. In view of the conclusion on the first issue, the order that the Appellant be extradited is
quashed and his discharge is ordered.

**End of Document**


-----

