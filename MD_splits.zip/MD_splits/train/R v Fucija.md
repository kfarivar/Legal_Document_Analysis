# R v Fucija [2024] EWCA Crim 616

Court of Appeal, Criminal Division

Dingemans LJ, Farbey J and Judge De Bertodano

17 May 2024Judgment

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

__________

Computer Aided Transcript of Epiq Europe Ltd,

Lower Ground Floor, 46 Chancery Lane, London, WC2A 1JE

Tel No: 020 7404 1400; Email: rcj@epiqglobal.co.uk (Official Shorthand Writers to the Court)

_________

The Applicant appeared in person

_________

**JUDGMENT**

**MRS JUSTICE FARBEY:**

1. On 13 February 2023 in the Crown Court at Stoke‑on‑Trent before His Honour Judge Fletcher CBE, the

applicant, then aged 25, pleaded guilty to one count of producing a controlled drug of class B, namely cannabis.
On the same day the judge sentenced him to nine months' imprisonment.

2. The applicant renews his application for an extension of time of 161 days in which to apply for leave to appeal
against conviction following refusal by the single judge. He applies also for leave to rely on fresh evidence relating
to his status as a victim of modern slavery.

3. The fresh evidence comprises a positive conclusive grounds decision by the Home Office under the National

Referral Mechanism and a report by Bernie Gravett who describes himself as an "anti‑human trafficking expert".

The lengthy report supports the conclusion that the applicant is a victim of modern slavery. We have also been


-----

provided with a fresh witness statement from the applicant. In that statement the applicant claims that he pleaded
guilty only because he had grown tired of spending time under curfew as part of his bail conditions and wanted his
case to end. He did not feel that he was guilty of an offence and believed that he had a statutory defence under
[section 45 of the Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

4. The applicant today has provided us with a succinct written document setting out the points he wishes to make.
We have taken that document into consideration.

5. The facts of the offence are set out in the Court of Appeal Office summary and may be briefly stated. On 21

April 2021 police made a forced entry into premises in Newcastle‑under‑Lyme. Both the applicant and his

co‑accused Emiljan Haka were inside the premises where four rooms were being used to cultivate cannabis. The

average yield from the 75 plants seized could produce up to 5,796 grams of skunk cannabis worth up to £57,960 if
sold as individual street deals. The set up at the premises was assessed as being capable of producing three such
crops each year.

6. The applicant's mobile phone was seized. Messages between the applicant and Haka at the material time
included discussion about going out of the house. In one message the applicant referred to going to London in the
following terms:

"I came London last night but I am going back I have got work tomorrow."

7. In another message the applicant said:

"I will come to London now have you got time to have a coffee?"

8. A message sent three days before his arrest provided the applicant with a PIN to enter a chain of gyms. None of
the messages included any reference to being taken against his will or being compelled to carry out work.

9. The applicant and Haka were both arrested and subsequently interviewed by the police. They both made no
comment in response to each of the questions that they were asked. Haka changed his plea to guilty on 25 March
2022 and was sentenced on the same day. The applicant meanwhile had submitted a written defence case
statement in which he claimed that he had been forced to commit the offence by Albanian gangsters. He claimed
that he was a victim of modern slavery.

10. The applicant later changed his plea to guilty on a basis of plea accepted by the prosecution. The written basis
of plea states among other things that the applicant was initially trafficked to the United Kingdom by Albanian
traffickers with the promise of legitimate work. He was however required by the traffickers to work in the cannabis
farm to repay his debt to his traffickers.

11. It is relevant to note that having claimed political asylum the applicant had been referred to the National
Referral Mechanism on 27 July 2019. On 21 August 2019 the Home Office made a positive reasonable grounds
decision. On 23 August 2019 the applicant was granted immigration bail and appears to have absconded. On 21

April 2021 he was arrested for the present offence. On 14 June 2021 he was re‑referred to the National Referral

Mechanism by Staffordshire Police.

12. As we have already said, on 13 February 2023 the applicant was sentenced for the present offence. He had
already effectively served his sentence on remand in custody or on qualifying curfew but he was detained under
immigration powers. On 23 February 2023 he was granted immigration bail. On 16 March 2023 the Home Office
made a positive conclusive grounds decision finding on the balance of probabilities that the applicant was a victim
of modern slavery both in Albania and in the United Kingdom.

13. The grounds of appeal which are now renewed make no criticism of the judge's approach to sentence. Rather,
the applicant contends that his conviction is unsafe because, as demonstrated by the conclusive grounds decision


-----

and by Bernie Gravett's report, he is a victim of modern slavery. Had this been known before he pleaded guilty
the prosecution would not have proceeded. Alternatively the applicant would have had a statutory defence.

14. In his document handed up today the applicant has told us that he felt under pressure owing to the delay in
receiving the conclusive grounds decision. His potential trafficking situation was not addressed in the criminal
proceedings.

15. The prosecution have lodged a Respondent's Notice and Grounds of Opposition in which they resist the
application for leave to appeal. The Notice confirms that counsel and a specialist prosecutor within the CPS
Appeals and Review Unit, neither of whom had any involvement with the case at first instance, have independently
reviewed the case in light of the conclusive grounds decision. The respondent's position is that if the applicant's
account of his offending is true, then he should not have been prosecuted. However the prosecution do not accept
that the account is true, pointing to the text messages which demonstrate that the applicant was a party to
conversations that are inconsistent with being forced to cultivate cannabis. The prosecution therefore depart from
the conclusion of the Home Office on the grounds that there is good reason to do so. That is a legitimate approach.

16. We have considered the relevant documents and the merits of the grounds of appeal afresh. The recognition
of a person as a victim of **_modern slavery does not necessarily extinguish his or her culpability and does not_**
provide an automatic defence to a criminal charge. The questions whether a person has a section 45 defence and

whether it is not in the public interest to prosecute are fact‑sensitive. As we have indicated, the defence case

statement places the applicant's claim to be a victim of modern slavery at its centre.

17. There is further reference to his having been trafficked in his basis of plea. In these circumstances, it cannot
possibly be said that he was unaware that he could raise modern slavery as an issue in the proceedings or that he
was unable to take advice about how being a victim of **_modern slavery could assist him. There is nothing to_**
suggest that he was not properly advised in relation to all possible legal avenues, including the possibility of a
section 45 defence, before he entered a guilty plea.

18. As the single judge noted, the applicant chose to abandon his defence and decided not to await the Conclusive
Grounds Decision. His plea was unequivocal. He chose to enter it. We can see no factors that would arguably
vitiate it.

19. The prosecution considered the applicant's situation at the time in accordance with the evidence as it then
existed. It is not arguable that the case should have been stopped.

20. The prosecution in light of the grounds of appeal have reviewed the case in accordance with law and guidance.
We agree with the Respondent's Notice that there are no arguable grounds for considering that the prosecution of
this applicant was or could be an abuse of process or that the prosecution should not have proceeded. Even if they
are admissible, nothing in the new report or the applicant's witness statement could make any difference to our
decision. The fresh evidence cannot undermine his guilty plea.

21. For these reasons, we refuse to extend time because it would serve no purpose. We would refuse leave to
appeal.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground Floor, 46 Chancery Lane, London, WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

