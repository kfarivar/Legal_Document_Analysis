# R (on the application of KTT) v Secretary of State for the Home Department

 [2021] All ER (D) 05 (Nov)

[2021] EWHC 2722 (Admin)

Queen's Bench Division, Administrative Court (London)

Linden J

12 October 2021

**IMMIGRATION - HUMAN TRAFFICKING - REFUSAL OF DISCRETIONARY LEAVE**
Abstract

_The Administrative Court allowed the appeal by the claimant Vietnamese national, who had been brought to the UK_
_by people traffickers and had been forced to work as a prostitute following arrival in the UK. She had appealed_
_against the decision by the defendant Secretary of State to refuse her claims for asylum and human rights_
_protection. The Secretary of State had accepted that she had been a victim of modern slavery in other countries._
_However, in accordance with the Secretary of State's then policy which was set out in Version 2 of 'Discretionary_
_Leave for Victims of Modern Slavery' (the MSL Policy), the Secretary of State had rejected the claimant's claims. In_
_agreement with the claimant, the court held that the MSL Policy was contrary to art 14 of the Council of Europe_
_Convention on Action Against Trafficking in Human Beings 2005 because it failed to permit the grant of MSL to a_
_victim on the ground that she had to remain in the UK to advance an asylum/protection claim which had been based_
_on the fear of being re-trafficked if she was returned to her country of origin._
Digest

The judgment is available at: [2021] EWHC 2722 (Admin)

**Background**

The claimant was a Vietnamese national aged 33. For a period of approximately six months in 2016, the claimant
had been forced to work as a prostitute in Vinh City before being brought to the UK by people traffickers in
November 2016. Her journey took her through various countries where she was also forced to work as a prostitute
and, for a period of approximately 21 months after her arrival in the UK, she was subjected to further forced labour
including as a prostitute and on cannabis farms. The claimant had significant mental health issues as a result of her
experiences of being trafficked, including Post Traumatic Stress Disorder and Anxiety and Depressive disorder, for
which she took anti-psychotic and anti-depressant medication. MSL would mean that she was eligible for Universal
Credit which, she calculated, was worth more than six times the payments she currently received. She would also
have access to the labour market and to education and training, all of which, she said, would assist to recover from
her experiences of trafficking. There was also evidence that her insecure immigration status was contributing to the
issues with her mental health.

On 17 April 2018, a positive reasonable grounds decision was made in her case and, on 31 October 2019, the
defendant Secretary of State accepted that she had been 'a victim of modern slavery in Vietnam, Russia, Ukraine,
unconfirmed countries, France and the UK during 2015-2018 for the specific purposes of sexual exploitation, forced
labour forced criminality' (the conclusive grounds decision). Meanwhile, on 22 January 2019, the claimant had


-----

made claims for asylum and human rights protection. Those claims were based on a fear of being trafficked again if
she was returned to Vietnam. They had yet to be determined at the time of the conclusive grounds decision.

In accordance with her then policy (the so-called 'scheduling rule') which was set out in Version 2 of 'Discretionary
Leave for Victims of **_Modern Slavery' (the MSL Policy), dated 10 September 2018, on 31 October 2019, the_**
Secretary of State also decided that any decision as to the grant of discretionary leave (modern slavery leave or
'MSL') would be postponed until after the determination of her claim for asylum/protection. However, the decision on
MSL was brought forward and, on 21 July 2020, the claimant's application was refused. Following a review in
response to the claimant's pre-action protocol letter, the refusal was maintained on 17 August 2020 (the Decision).

The claimant challenged the Decision on four grounds. Ground 2 was not pursued and Ground 4 was stayed.
Ground 3 was advanced as an alternative to Ground 1 and the claimant confirmed that that ground would only arise
if she was wrong on Ground 1.

**Issues and decisions**

Whether the MSL Policy was contrary to art 14 of the Council of Europe Convention on Action Against Trafficking in
Human Beings 2005 (ECAT).

The claimant submitted that she should have been granted MSL in accordance with art 14(1)(a) ECAT on the basis
that it was necessary for her to remain in the UK owing to her personal situation, namely in order to pursue her
asylum and human rights claims based on her fear of being re-trafficked if she was returned to Vietnam. That, she
argued, was the effect of art 14.1(a) ECAT as a matter of construction. As, she stated, the Secretary of State's
stated policy was to comply with art 14, the refusal of leave in her case was unlawful.

Pursuant to art 14 of ECAT: '1. Each party shall issue a renewable residence permit to victims, in one or other of
the two following situations or in both: (a) the competent authority considers that their stay is necessary owing to
their personal situation; (b) the competent authority considers that their stay is necessary for the purpose of their
co-operation with the competent authorities in investigation or criminal proceedings' (see [6] of the judgment).

It was well established that ECAT leave was a temporary form of leave that enabled a victim of trafficking to receive
support (through access to the labour market, education and mainstream benefits) to facilitate recovery from
trafficking and/or to facilitate co-operation with a criminal investigation into trafficking. It was generally granted for a
period of 30 months, although it could be granted for a longer or shorter period in individual cases. It was not a
route to settlement in the UK (see [7] of the judgment).

Having considered the relevant case law, the question whether the Secretary of State's decision was compatible
with art 14(1)(a) ECAT was potentially justiciable provided that the Secretary of State's stated policy was to make
decisions in relation to discretionary leave in accordance with the requirements of that provision (see [59] of the
judgment).

As already noted, the version of the MSL Policy which was in force at the time of the decision to postpone the
determination of the claimant's application for MSL was Version 2. The authorities had held that it was in principle
permissible to postpone decisions on MSL until the outcome of the applicant's asylum application. However, the
fact that there had been, in practice, substantial delays between the making of a positive conclusive grounds
decision and the determination of the victim's application for asylum/protection gave rise to a material risk that, in a
significant number of cases, victims would lose basic trafficking support and be reduced for a considerable period of
time to support from the National Asylum Support Service, the level of which was not consistent with the UK's
obligations under arts 12(1) and (2) and 14(1) ECAT. In response to, the MSL Policy had been amended to modify
the scheduling rule, although not until 9 October 2020 (Version 3). The relevant version at the time of the Decision
under challenge in the present proceedings was therefore Version 2. The Policy was amended again on 10
December 2020 (Version 4)(see [63], [64] of the judgment).

On balance, the claimant's interpretation of art 14 ECAT would be preferred, which was based on an ordinary
reading of the text of the provision and consistent with its purpose. The reality of the Secretary of State's argument


-----

on interpretation was that art 14(1) should be read as if it said that the issuing of the residence permit should be
necessary, whereas the language of the provision clearly required consideration of whether the stay was necessary
in which case the permit had to be issued. Indeed, the requirement to consider whether 'their stay is necessary' left
room for it to be the case that the victim was staying in any event. The provision then asked whether the stay was
necessary for a particular reason or purpose, in which case a residence permit, with attendant benefits and
advantages, was required to be issued. The language did not appear to regard the residence permit as solely for
the purpose of facilitating a stay which would not otherwise be possible, although that could be an important
function of such a permit. Rather, the point of the residence permit was at least in part to trigger additional
advantages (see [89] of the judgment).

Applying the language of art 14 could not be considered to be an overly technical approach, or inconsistent with the
approach required by the Vienna Convention. Further, the approach suggested by the language was consistent with
the aims of ECAT including the aim of protecting and assisting the victims of trafficking. The Secretary of State's
suggested interpretation of art 14 was significantly less likely to further those aims given that it had the
consequence of reducing the likelihood that a residence permit would be issued, with the beneficial consequences
to which the Secretaryof State referred. Indeed, the effect of the Secretary of State's argument was that ECAT
contemplated that provided that a signatory state had a policy of not removing victims of trafficking, or perhaps a
law to that effect, they never need issue residence permits pursuant to art 14. In the context of the UK, asylum
seekers who relied on fear of re-trafficking would rarely, if ever, be eligible for MSL because such leave would not
be necessary to facilitate their stay given ss 77 and 78 of the Nationality, Asylum and Immigration Act 2002. That
position would hold good under art 14 however powerful their case based on other personal circumstances, such as
the need for medical or other assistance for reasons related to their experiences of being trafficked. The Secretary
of State's argument would also hold good in a case where the victim's stay was 'necessary for the purpose of their
co-operation with the competent authorities in investigation or criminal proceedings' (namely under limb (b) of art
14(1) as well). On his approach, the fact that such a person had made a claim for asylum would disentitle them from
a residence permit pursuant to art 14(1)(b)(see [90], [91] of the judgment).

In agreement with the claimant, para 183 of the Explanatory Memorandum tended to support the view that the
broad intention of art 14(1)(a) was to require that a residence permit be issued to confirmed victims of trafficking
when it would be unreasonable to compel them to leave the relevant territory, and it was accepted that it was
implicit in the fact that Parliament had accepted that a person should not be removed while their asylum/protection
claim was outstanding, that a stay for that purpose was generally necessary. It followed from that that a stay in
order to pursue a claim for asylum based on the fear of being re-trafficked might be necessary owing to the victim's
personal situation. In addition to those points, reading arts 10, 12 and 14 ECAT together, it seemed to be clear that
ECAT drew a distinction between those who merely might not be removed and those who were lawfully in the UK.
That distinction was important because it meant that art 14(1) advisedly required the issuing of a residence permit
where a victim qualified under limbs (a) and/or (b), and it contemplated that a recognised victim of trafficking who
needed to stay for one of those specified purposes would have greater advantages than would otherwise be the
case. If their stay was necessary for the relevant purposes it therefore was not sufficient merely to refrain from
removing them, and nor was it permissible to withhold the advantages which would otherwise accrue to them if they
had been lawfully in the UK. If that was so, the fact that the focus of art 14(1)(a) and (b) was on whether the stay
was necessary, rather than whether the issuing of a permit was necessary, was consistent with the scheme of the
Convention as well as the words of art 14 itself. (see [93], [94] of the judgment).

Version 2 of the MSL Policy did not accurately reflect the requirements of art 14 ECAT, essentially because it
reflected the Secretary of State's analysis of art 14, with which the court disagreed. There was also no statement
that the fact that a victim of people trafficking had made an asylum/protection claim could be a ground for granting
discretionary leave, or example to that effect. On the contrary, under Version 2, the scheduling rule was to the
opposite effect given that it meant that MSL would not be granted where an asylum/protection claim had been made
because the decision as to the grant of MSL would be postponed in such a case. The fact of the asylum/protection
claim was therefore a reason to defer an application for MSL rather than to grant it (see [105] of the judgment).

It was therefore apparent that Versions 3 and 4 did not take the stance taken by the Secretary of State given that
they contemplated that there might be cases where a grant of MSL was appropriate notwithstanding that there was


-----

an outstanding asylum/protection claim. However, in agreement with the claimant, the reasonable reader of
Versions 3 and 4 as a whole would conclude that the fact of an asylum/protection claim based on the fear of being
re-trafficked was relevant to the question whether to defer a decision on MSL but was not, of itself, a potential
reason to grant MSL. On the basis of that interpretation, then, the MSL Policy remained misleading as to the effect
of art 14(1)(a) ECAT and would induce decisions by caseworkers which were inconsistent with its requirements
and, therefore, inconsistent with the Secretary of State's policy of compliance with art 14(1)(a) (see [110] of the
judgment).

On the basis of the analysis set out, the decision in the claimant's case was contrary to the Secretary of State's
policy of compliance with art 14(1)(a) ECAT. Essentially, that was because the Decision letter considered whether
the grant of MSL was necessary to protect and assist the claimant's recovery and concluded that it was not. The
decision-maker found that such treatment as the claimant required was available in Vietnam and there were
therefore no medical grounds for discretionary leave. The decision-maker had also considered the risk of retrafficking or becoming a victim of modern slavery if the claimant was to return to Vietnam and had concluded that
the degree of risk was not such as to warrant MSL. The decision maker had not considered whether the fact that
the claimant had made an asylum/protection claim based on the fear of re-trafficking, and therefore needed to stay
in the UK to pursue that claim, had been a basis for granting MSL. The approach taken by the decision-maker had
therefore been broadly in accordance with the aspects of Version 3 of the MSL Policy, although that document had
not then been promulgated (see [112] of the judgment).

Ground 1 would be upheld, with the result that Ground 3 did not arise (see [113] of the judgment).

_MN v Secretary of State for the Home Department; IXU v Secretary of State for the Home Department (AIRE_
_Centre and another intervening)_ _[2020] EWCA Civ 1746, [2021] 1 WLR 1956,_ _[[2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
considered

Application allowed.

Chris Buttler QC and Zoe McCallum (instructed by Duncan Lewis) for the claimant.

Robin Tam QC and William Irwin and Emily Wilsdon (instructed by the Government Legal Department) for the
Secretary of State.
Neneh Munu Barrister.

**End of Document**


-----

