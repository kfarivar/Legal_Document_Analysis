# R (on the application of SM) v Secretary of State for the Home Department

 [2024] All ER (D) 19 (Jul)

[2024] EWHC 1683 (Admin)

King's Bench Division, Administrative Court (London)

Sarah Clarke Kc (Sitting As A Deputy Judge Of The High Court)

1 July 2024

**IMMIGRATION – LEAVE TO REMAIN – VICTIM OF TRAFFICKING**
Abstract

_The Administrative court allowed the claimant's judicial review of the competent authority's decision that there were_
_no reasonable grounds to believe that the claimant 17 year old Albanian national was a victim of trafficking/modern_
**_slavery. The claimant had obtained a false passport and travelled to the UK via Germany and when interviewed on_**
_arrival had stated that he was stressed because he was in debt to the person helping him into the UK. On_
_reconsideration the competent authority suggested that the claimant was smuggled into the UK and was not a_
_victim of trafficking because he was not forced to carry out any work against his will or under any menace of_
_penalty. The court held that the competent authority's decision when taken as a whole, and applying a fair and_
_contextual approach, had not shown, expressly or by implication, that the relevant factors in favour of the claimant_
_had been taken into account. The decision had correctly stated that the focus was on the question of whether there_
_were reasonable grounds to believe that the claimant was transported 'for the purpose of exploitation' applying_
_ordinary language and common sense. However, there was no reference to paras 2.23-2.24 of the 'Modern_
**_Slavery: Statutory Guidance for England and Wales' under_** _[s 49 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)_ **_Modern Slavery Act 2015. Given the_**
_claimant's circumstances, it was clearly a case under the 'what if someone hasn't yet been exploited' section of the_
_guidance which made clear that a person could be a victim of trafficking even if they had not yet been exploited and_
_that it was the purpose that was key rather than whether or not the exploitation had actually occurred._
Digest

The judgment is available at: [2024] EWHC 1683 (Admin)

**Background**

The claimant (SM) was an Albanian national, born in 2004. In 2021, SM obtained a false passport and travelled to
the UK via Germany. He was detained by the immigration services on arrival and interviewed and a 'Welfare Form:
Unaccompanied Children' was completed. During that interview, SM stated that he was stressed because he was in
debt of £15,000 to the person helping him into the UK and that he wanted to feel safe. The defendant Secretary of
State referred the claimant into the National Referral Mechanism (NRM) to decide whether he was a victim of
[trafficking (VoT). The NRM was regulated by policy guidance provided under s 49 of the Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)
[(MSA 2015) named the 'Modern Slavery: Statutory Guidance for England and Wales' (the guidance). The Single](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Competent Authority (SCA) acting on behalf of the Secretary of State issued a negative first stage reasonable
grounds decision that although SM had been consistent in his account and there were no credibility concerns, the
'purpose' condition was not met because the events were not deemed to constitute modern slavery and therefore
there were no reasonable grounds to believe that the claimant was a VoT/modern slavery. In 2023, the claimant
applied for reconsideration of that decision having included a witness statement, his asylum interview record and an


-----

expert report to demonstrate that he was transported for the purpose of exploitation. The SCA issued its
reconsidered decision that SM was not a VoT but that he was smuggled into the UK instead on the basis that he
was not forced to carry out any work against his will or under any menace of penalty. The claimant applied for
judicial review of that decision.

**Issues and decisions**

Whether the SCA's decision that there were not reasonable grounds to suspect that SM was a VoT was irrational in
that it failed to take into account all relevant considerations and failed to follow and rationally apply the guidance in
terms of relevant factors to be considered.

_R (on the application of Hoang) v Secretary of State for the Home Department_ _[[2015] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G91-1T31-DYBP-N2W2-00000-00&context=1519360)_
_[(D) 228 (Jun) considered that if a decision might or might not stand up to more detailed scrutiny, or prove well](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G91-1T31-DYBP-N2W2-00000-00&context=1519360)_
founded on a more detailed analysis then a positive reasonable grounds decision should be made, to allow enough
time and support for a proper conclusive grounds decision to be made. The initial filter should not be elevated to a
detailed summary determination of the ultimate credibility of the case advanced (see [29], [73] of the judgment).

The summary of the information in the SCA's decision excluded important matters which were directly relevant to
the reasonable grounds decision to be taken, and which were supportive of the claimant's case. The summary of
the contents of his witness statement excluded his fear of being exploited, there was no summary of his interview.
Based on the finding that there were no credibility concerns, the SCA thereby confirmed that it accepted SM's
evidence, which meant that the SCA had be taken to accept that SM had a genuine fear of exploitation for the
reasons expressed by him in his witness statement and interview. In addition, the SCA decision-maker must have
accepted that a 17 year old Albanian child entered into an arrangement which created a £15,000 debt obligation
which he had no means to pay, a fact which must have been obvious to the provider of the passport. Those
circumstances therefore required the SCA decision-maker to consider whether that created a situation of debt
bondage and how that debt would ever be repaid other than by some form of **_modern slavery. Further, the_**
contextual background was capable of showing a recognised pattern of trafficking from Albania to the UK which
were consistent with the circumstances as described by SM but were not addressed. They were plainly relevant to
the assessment of whether there were reasonable grounds to believe that SM was transported for the purposes of
exploitation and it was incumbent on the SCA decision-maker to consider those and explain why they nevertheless
did not amount to reasonable grounds in order to meet the requirement that a high quality of reasoning was
required in a reasonable grounds decision which engaged fully with the case advanced by the person concerned
due to the importance of the decision as a potential gateway to important rights including the right to a conclusive
grounds decision (see [57], [58], [62], [63] of the judgment).

The SCA's decision when taken as a whole, and applying a fair and contextual approach, had not shown, expressly
or by implication, that the relevant factors in favour of SM had been taken into account. The guidance had to be
carefully applied and decision letters had to include a full and detailed consideration explaining the reasons for the
decision. The SCA's decision had correctly stated that the focus of the decision was on the question of whether
there were reasonable grounds to believe that SM was transported 'for the purpose of exploitation' applying
ordinary language and common sense. However, there was no reference in the SCA's decision to paras 2.23-2.24
of the guidance. Given that SM was apprehended at the point of entry to the UK, it was clearly a case under the
'what if someone hasn't yet been exploited' section of the guidance contained in those paragraphs which it made
clear that a person could be a victim of trafficking even if they had not yet been exploited and that it was the
purpose that was key rather than whether or not the exploitation had actually occurred (see [65], [67], [68] of the
judgment).

Further, no weight had been given to the expert report from the specialist advisor on human trafficking and child
exploitation contrary to paras 14.28 – 14.33 of the guidance. If, as the Secretary of State contended, her opinion
was dismissed by the SCA decision-maker as speculation, then it was incumbent on the decision maker to address
that head on in the SCA decision and explain why. That manifestly did not happen, the opinion of the expert was
not considered at all, and the subsequent attempts to suggest to the contrary were ex post facto. The SCA's
decision did not consider the relevant factors and guidance which assisted SM in establishing reasonable grounds


-----

and was therefore irrational in that it failed to take into account all relevant considerations, and failed to follow and
rationally apply the Secretary of State's own guidance in terms of relevant factors to be considered (see [71], [73],

[74] of the judgment).

The SCA's decision was unlawful. Accordingly, it would be quashed and remitted for reconsideration (see [75], [76]
of the judgment).

_VCL v UK (2021) 73 EHRR 9 considered_

_R (on the application of Hoang) v Secretary of State for the Home Department_ _[[2015] EWHC 1725 (Admin), [2015]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G91-1T31-DYBP-N2W2-00000-00&context=1519360)_
_[All ER (D) 228 (Jun) followed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G91-1T31-DYBP-N2W2-00000-00&context=1519360)_

_R (on the application of FM) v Secretary Of State For The Home Department_ _[[2015] EWHC 844 (Admin), [2015] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FM2-VRV1-DYBP-N4M7-00000-00&context=1519360)_
_[ER (D) 300 (Mar) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FM2-VRV1-DYBP-N4M7-00000-00&context=1519360)_

_R (on the application of TVN) v Secretary of State for the Home Department_ _[2021] EWHC 3019 (Admin)_
considered

_MN v Secretary of State for the Home Department; IXU v Secretary of State for the Home Department (AIRE_
_Centre and another intervening)_ _[2020] EWCA Civ 1746, [2021] 1 WLR 1956,_ _[[2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
considered

_R (on the application of Sarkisian) v Immigration Appeal Tribunal_ _[[2001] EWHC Admin 486, [2001] All ER (D) 329](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_
_[(Jun) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SPK-6KS0-TWP1-71JB-00000-00&context=1519360)_

_Mibanga v Secretary of State for the Home Department_ _[[2005] EWCA Civ 367,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG21-DYBP-P50W-00000-00&context=1519360)_ _[[2005] All ER (D) 307 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JT01-DYBP-N1K8-00000-00&context=1519360)_
considered

_R (on the application of Y) v Secretary of State for the Home Department_ _[[2012] EWHC 1075 (Admin), [2012] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55MS-4XH1-DYBP-N232-00000-00&context=1519360)_
_[ER (D) 103 (May) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55MS-4XH1-DYBP-N232-00000-00&context=1519360)_

_R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State for the Home Department_
_(Equality and Human Rights Commission intervening)_ _[[2018] EWCA Civ 1395, [2018] 1 WLR 4922, [2018] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
_[(D) 38 (Jul) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_

Claim allowed.

Taimour Lay (instructed by BHT Sussex) for the claimant.

Michael Biggs (instructed by Government Legal Department) for the Secretary of State.

**End of Document**


-----

