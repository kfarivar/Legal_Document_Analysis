# Minister for Justice and Equality v Harrison [2020] IEHC 29

Irish High Court

Binchy J.

24 January 2020Judgment

_[[2020] IEHC 29](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XWC3-RSRP-M3SH-00000-00&context=1519360)_ **THE HIGH COURT**

**[2019 No. 355 EXT]**

**BETWEEN**

**MINISTER FOR JUSTICE & EQUALITY**

APPLICANT AND

**EAMONN RONALD HARRISON**

**RESPONDENT**

JUDGMENT of Mr. Justice Binchy delivered on the 24th day of January, 2020

1. By this application, the applicant seeks an order for the surrender of the respondent to the United Kingdom
pursuant to a European Arrest Warrant dated 30th October, 2019 (“the EAW”). The EAW was issued by District
Judge Michael Snow, a District Judge of the Magistrates' Court sitting at Westminster Magistrates' Court as issuing
judicial authority.

2. The EAW was endorsed by the High Court on 31st October, 2019, and the respondent was arrested and brought
before this Court on 1st November, 2019.

3. This application was first opened in this Court on 21st November, 2019, on which date this Court made an order
pursuant to s. 20 of the European Arrest Warrant Act 2003 (as amended) (“the Act of 2003”) requiring the provision
of additional information. The letter requesting this information was sent to the Central Authority in the United
Kingdom on

26th November, 2019. A reply was sent not by that authority, but by the Crown

Prosecution Service, Organised Crime Division, London (“CPS”) on 4th December, 2019. The reply comprises a
letter of that date and a 36 page document entitled “Response to request for additional Information”. The hearing of
this application then proceeded before this Court and was heard over the 12th and 13th December, 2019.

4. At the hearing of the application, I was satisfied that the person before the Court is the person in respect of
whom the EAW was issued and in any case this was not denied by the respondent.

5. I was further satisfied that none of the matters referred to in ss. 22, 23 and 24 of the Act of 2003 arise and that
the surrender of the respondent is not prohibited for any of the reasons set forth in any of those sections. An


-----

objection was raised, however, on behalf of the respondent, that his surrender is prohibited by s. 21A of the Act of
2003, and I address that later in this judgment.

6. The EAW states at para. (b) that the decision on which the EAW is based is an arrest warrant dated 29th
October, 2019, issued at Chelmsford Magistrates' Court by Justice of the Peace, Mr. C. Stokes and describes the
type of warrant as being: “Accused”.

7. At para. (c) of the warrant it is stated that the maximum length of the custodial sentences or detention orders
which may be imposed upon the respondent, if convicted of the offences referred to in the EAW are:

(1) Manslaughter – life imprisonment;

(2) Conspiracy to commit a human trafficking offence under s. 2 of the Modern Slavery Act, contrary to s. 1(1) of
[the Criminal Law Act 1977, Immigration Act 1971 – life imprisonment and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

(3) Conspiracy to assist unlawful immigration under s. 25 of the Immigration Act 1971, contrary to s. 1(1) of the
Criminal Law Act 1977 – 14 years' imprisonment.

[(Later in the EAW, at para.s (e)(2) and (e)(3), the reference to the Criminal Law Act 1977 is mistakenly stated as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)
the Criminal Law Act 1971. However, in the further information of

4th December, 2019, reference to the Criminal Law Act of 1971 is corrected to the Criminal Law Act of 1977.)

8. It is apparent from the above that the requirements as to minimum gravity of each of the offences referred to in
the EAW are met.

9. At para. (e) of the EAW it is stated that the warrant relates to a total of 41 offences. Particulars of the offences
are briefly stated and since this is an issue of some significance in this application, I will set out the same exactly as
stated in the EAW, as follows:

_“The case against Eamon Harrison relates to the trafficking and subsequent deaths of 39 people within an_
_artic trailer unit GTR1 28D. At 01:38 on Wednesday 23_

_October 2019 Essex Police received a call from the East of England Ambulance Service stating that they_
_were getting reports of 25 illegal immigrants not breathing within a lorry in the area of Eastern Avenue, Waterglade_
_Industrial, West Thurrock, Essex. Police attended the scene. The driver of the lorry was standing at the back of_
_the trailer. He was later identified as Maurice Robinson. Inside the trailer was a total of 39 people, 8 females and_
_31 males who were all deceased. Enquires revealed that the trailer unit GTR1 28D had been delivered by a lorry_
_BB221 3BP to Zeebrugge, Belgium before being transported to the UK where it was collected by_

_Maurice Robinson from the Port of Purfleet, Essex. On 22 October 2019 Eamon Harrison has been_
_identified as the driver of the lorry BB221 3BP which was used to deliver the trailer unit GTR1 28D to the port in_
_Zeebrugge. CCTV, taken several hours before at a truck stop in Veurne, Belgium shows Eamon Harrison to be the_
_driver of BB221 3BP. That lorry deposited the trailer unit, GTR1 28D at Zeebrugge for its onward transmission to_
_Purfleet, Essex. A shipping notice provided at Zeebrugge when the tractor unit arrived at the gate was signed in the_
_name_

_'Eamonn Harrison'. Eamon Harrison travelled back to Ireland in the lorry BB221 3BP via a ferry from_
_Cherbourg, France.”_

10. Particulars of the offences alleged against the respondent are set out immediately after the narrative above, as
follows:

_“(1) Manslaughter – contrary to common law_


-----

_The offence is made out if it is proved that the accused intentionally did an unlawful and dangerous act_
_from which death inadvertently resulted._

[(2) Conspiracy to commit a human trafficking offence under section 2 of the Modern Slavery Act 2015, contrary to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C254-00000-00&context=1519360)
_section 1(1) of the Criminal Law Act 1971 (sic). A person commits an offence if the person arranges or facilitates_
_the travel of another with a view to them being exploited;_

[(3) Conspiracy to assist unlawful immigration under section 25 of the Immigration Act 1971, contrary to section 1(1)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFF0-TWPY-Y0G4-00000-00&context=1519360)
_of the Criminal Law Act 1971 (sic). A person commits an offence if he does an act which facilitates the commission_
_of a breach of immigration law by an individual who is not a citizen of the European Union._

_The offence of conspiracy is made out if a person agrees with any other person or persons that a course_
_of conduct shall be pursued which will necessarily amount to or involve the commission of any offence or offences.”_

11. Two paragraphs on from the particulars of the offences set out above, it is stated by the issuing judicial
authority that:

_“I am satisfied that a Crown Prosecutor in the Crown Prosecution Service, whose function is to decide_
_whether or not to prosecute an individual for the alleged commission of criminal offences, has decided to charge the_
_person named herein and to try him for the offences specified above and for which this warrant is issued.”_

12. Thereafter, at para. (e) I, the issuing judicial authority has ticked the box referable to

“trafficking in human beings”, leaving un-ticked the remaining boxes in this part of the EAW. At para. (e) II, under
the heading “full description of offences not covered by section I above:” it is stated:

_“Manslaughter, contrary to common law_

_Conspiracy to assist unlawful immigration under section 25 of the Immigration Act_

_1971, contrary to section 1(1) of the Criminal Law Act 1971 (sic).”_

13. Undated points of objection were initially delivered in response to the EAW. Thereafter, amended points of
objection were delivered in response to both the EAW, and the additional information furnished by the CPS on 4th
December, 2019. For the purpose of this judgment, reference hereafter to the points of objection is to the amended
points of objection. Before addressing the same however, it is necessary to summarise the additional information
submitted by the CPS by letter dated 4th December, 2019. As mentioned above, this information was provided in
response to a letter sent by the Central Authority in this jurisdiction, at the direction of this Court, pursuant to s. 20
of the Act of 2003. That letter requested, inter alia, the following:

1. Clarification as to which of the offences the issuing judicial authority claims fall within Article 2.2 of the
Framework Directive (sic). This clarification was sought in light of contradictory statements in the EAW.

In its reply to this enquiry, the CPS stated that it is invoking Article 2.2 of the Framework Decision in respect of all
of the offences described in the EAW.

2. Detailed particulars were requested in relation to each of the 41 offences referred to in the EAW, but on the
basis that all of the manslaughter offences could be grouped together on the assumption that the circumstances
alleged to have caused death in each case are identical. In reply, the names of all of the deceased are provided. It
is stated that the charges of manslaughter are “at present” put on an alternative basis:

(i.) The unlawful act of manslaughter on or before 24th October, 2019, carried out through assisting the unlawful
immigration of 39 persons into the UK with a view to them being exploited before, during or after the journey or

(ii.) Gross negligence manslaughter on or before 24th October, 2019, on the basis that the respondent owed a duty
of care to the deceased persons, which he breached by transporting them in the trailer unit GTR1 128D, attached to


-----

tractor lorry B221 3BP, and by delivering the trailer unit containing those persons to Zeebrugge Port in Belgium on
22nd October, 2019, and causing them to travel unaccompanied inside the trailer unit on a ferry crossing journey of
nine hours and that the said breach of duty caused the death of the deceased during this journey.

14. It is alleged that the respondent drove the trailer unit in which the deceased were being transported to
Zeebrugge on 22nd October, 2019. Prior to that, it travelled around Belgium and France, arriving in Zeebrugge at
13:54 hours. The cargo is recorded as biscuits. CCTV footage from Zeebrugge Port at the time identifies the
respondent as the driver who delivered the trailer in which the deceased were transported. The trailer was loaded
on to the MV Clementine one hour later at 14:55 hours, and that vessel set sail just five minutes later, at 15:00
hours. No request was made to connect the trailer to an electricity supply for refrigeration, and port officials
confirmed that the refrigeration unit was not turned on. The journey to Purfleet Port usually takes around nine hours.

15. The MV Clementine arrived Purfleet Port at 00:30 hours on 23rd October, 2019, and the trailer unit was
unloaded at 00:56 hours and was collected by a lorry cab number B3901BH which left the port with the trailer at
01:08 hours on 23rd October, 2019. At 01:38 hours on that date, the driver of that vehicle, Mr. Maurice Robinson
telephoned the emergency authorities informing them that there were immigrants in the trailer and that they were
not breathing. When paramedics arrived at the scene, they found 39 bodies in the back of the trailer and all were
dead. Mr. Robinson was arrested on suspicion of murder. After Mr. Robinson's arrest, on the same day, a Mr.
Ronan Hughes made a number of phone calls to the respondent. It is stated in the additional information that Mr.
Hughes recruited Mr. Robinson and the respondent in his haulage business.

16. While the results of post-mortem examinations are awaited, early indications are that all of the deceased died
from hypoxia (starvation of oxygen). Hyperthermia may also have been a factor in their deaths. The refrigeration
unit in the trailer was not switched on. The temperature records in the trailer indicate that from 10:35 hours on
Tuesday 22nd October the temperature in the unit rose consistently until 22:55 hours on that day when it reached
its highest level of 38.5 degrees. Thereafter it steadily reduced. Bloody hand prints were observed on the inside of
the lorry door.

17. It is stated that the exact time and place of death is not known. Coast guard data indicates that the MV
Clementine entered UK territorial waters at 19:43 hours on 23rd October, 2019 (this would appear to be an error
and should instead state 22nd October, 2019).

18. Mobile telephones of the deceased were examined and it is stated that analysis of the material downloaded
from those phones demonstrates that some of the victims died in UK territorial waters. Audio recordings on the
devices after the vessel entered UK territorial waters record multiple voices, and persons struggling to breathe.

19. Other information regarding the activities of the respondent is also provided. It is stated that the respondent is
believed to have been involved in the transportation of illegal migrants from Zeebrugge Port to Purfleet Port on
10th/11th October, 2019, and again on 17th/18th October, 2019. On the latter occasion, the same trailer as that
used to transport the deceased migrants on 22nd/23rd October, 2019 was used. The respondent was identified as
being the driver.

20. It is stated that on 9th May, 2018, the respondent was stopped at Coquelles, France, driving a trailer unit in
which 18 Vietnamese migrants were discovered. Ronan Hughes was named as the haulier. Mr. Robinson has
admitted, at interview, to smuggling migrants into the UK on several occasions and having been paid, by Ronan
Hughes, £1,500 per person smuggled. Mr. Robinson has pleaded guilty to conspiracy to assist unlawful
immigration and to one count of money laundering. Charges of manslaughter against him are ongoing.

21. A Mr. Christopher Kennedy was arrested on 22nd November, 2019, and has admitted to being the driver of the
lorry used in the operations of 11th October, 2019, and 18th October, 2019. He has been charged with two
offences of conspiracy, one in respect of human trafficking and the other in relation to assisting unlawful
immigration.

22. It is stated that there is “a wealth of circumstantial evidence” namely CCTV evidence, ANPR data evidence,
telephone evidence and cell site analysis relating to Harrison, Hughes, Robinson, Kennedy and others on relevant


-----

dates from the UK, CCTV, ANPR data, surveillance and other evidence from other countries (Belgium, Bulgaria,
France and the Netherlands) from which reasonable inferences may be drawn.

23. It is stated that mobile telephone data and other evidence indicate that Ronan Hughes was in contact with Mr.
Robinson and the respondent throughout October, and that it is believed that the respondent discarded his mobile
telephone after 23rd October. However, a study of his telephone records indicate that it was used on dates
between 21st October and 25th October, 2019.

24. Although the fate of the deceased migrants received extensive publicity, the respondent made no effort to
contact police in the UK or other law enforcement authorities, in spite of his role in delivering the trailer in which they
were transported to Zeebrugge Port. Instead, he discarded his mobile telephone, thereby obstructing the course of
any investigation of his communications using that device.

25. Returning to the letter seeking further information, the issuing judicial authority was asked to provide detailed
information of the acts of the respondent relied upon for the purposes of charging him with each individual offence,
and in particular where each and every constituent element of each offence is alleged to have taken place. The
letter also requested full and detailed particulars in respect of the conspiracy in which it is alleged the respondent
was involved.

26. Two offences of conspiracy are alleged against the respondent, a conspiracy to assist unlawful immigration
contrary to s. 1(1) of the Criminal Law Act 1977 and the offence of conspiracy to commit a human trafficking offence
under s. 2 of the Modern Slavery Act 2015 (the “Act of 2015”), contrary to s. 1(1) of the Criminal Law Act 1977.

27. For the purposes of each of these offences, under s. 1(1) of the Criminal Law Act 1977 (in the United Kingdom)
if a person agrees with any other person to pursue a course of conduct which, if carried out in accordance with their
intentions, will either involve the commission of an offence or offences by any one or more of the parties involved,
or would do so but for the existence of facts which render the commission of the offence or offences impossible, he
is guilty of conspiracy to commit the offences or offences in question.

28. In addition to the information provided above in relation to each of the conspiracies in which the respondent is
alleged to have been involved, further information is provided in relation to the incidents of 10th/11th October, 2019,
and 17th/18th October, 2019. In relation to the incident of 10th/11th October, 2019, it is stated that the respondent
dropped a trailer off at Zeebrugge Port. That trailer was picked up by Mr. Kennedy at Purfleet Port. He drove to
Orsett Golf Course where he dropped off 15-20 people who were collected by waiting cars. Mr. Kennedy admitted
being the driver of the vehicle that picked up the trailer but denied any knowledge of involvement in people
smuggling.

29. In relation to the incident of 17th/18th October, the respondent has been identified as the person who collected
a cargo of biscuits from a biscuit factory using tractor unit B221 3BP, which was carrying trailer GTR1 28D. He was
later identified as the driver who dropped that trailer at Zeebrugge Port where it is recorded as having a cargo of
one tonne of biscuits. However, it is believed that people were also smuggled in the trailer containing the biscuit
load. The trailer was collected at Purfleet Port by Mr. Kennedy and again travelled to Orsett Golf Course, where it
was met by three vehicles.

30. The cargo of biscuits was delivered to the intended customer, who refused to accept delivery on the grounds
that the cargo had been damaged. Details of the activities of Mr. Kennedy and Mr. Hughes in this operation are
provided. Mr. Kennedy is stated to have acknowledged his role in collecting the trailers, and also acknowledged the
interference with the cargo. It is stated that he has said, presumably in a statement, that somebody must have
been in the trailer in view of the damage to the cargo.

31. It is claimed that the available evidence for all of the operations of 10th/11th October, 17th/18th October and
22nd/23rd October, 2019, indicate that the illegal migrants were not free to walk away on their arrival into the UK;
that they were collected by cars on their arrival, suggesting an intention to exploit those persons, contrary to s. 2(1)
of the Act of 2015.


-----

32. The issuing judicial authority was also asked to clarify whether or not any of the offences are alleged to have
been committed outside the territory of the United Kingdom. In response to this, it is stated that both conspiracies
were made inside the UK, it being the prosecution's case that the agreement to commit the offences in each case
was made in the UK. In relation to the manslaughter offences, it is stated that there is credible evidence that the
deceased died in UK territorial waters. However, in the event that any of the victims died abroad, it is stated that
jurisdiction is established to prosecute the respondent pursuant to s. 9 of the Offences Against the Persons Act
1861.

33. The issuing judicial authority was invited to comment on an assertion of the respondent that he is an Irish
citizen travelling, at the time of the alleged offences, on an Irish passport. At the hearing of the application, it was
accepted that the latter was an error i.e. that the respondent was in fact travelling on a British passport. The CPS
confirmed that the respondent is a British citizen and is the holder of a British passport. However, the respondent
has also deposed that he is an Irish citizen and holds an Irish passport. The error in his affidavit of 27th November,
2019, was to the effect that he was travelling on an Irish passport at the time of his arrest, whereas he accepts that
he was travelling on a British passport at the time.

Points of objection

34. The amended points of objection filed on behalf of the respondent run to almost six pages. However, they may
be summarised as follows.

35. The additional information provided by the CPS by letter of 4th December, 2019, is inadmissible because it is
not information within the meaning of s. 20 of the Act of 2003, as it does not emanate from a judicial authority.
Further, the information is not admissible without formal proof as it is not a document within the meaning of s.
11(2A) of the Act of 2003 and nor is it admissible pursuant to s. 12(8) of the Act of 2003.

36. The additional information purports to expand to an impermissible degree the facts and matters relied upon by
the applicant, as well as his reliance on Article 2.2 of the Framework Decision and extraterritorial jurisdiction, all of
which go beyond the legitimate role and purpose of additional information within the meaning of s. 20 of the Act of
2003 or an additional document within the meaning of s. 11(2A) of the Act of 2003.This objection and the preceding
objection were referred to by counsel for the respondent as being a “preliminary issue”, and I will adopt that
description of them hereafter.

37. The surrender of the respondent is prohibited by s. 44 of the Act of the 2003 because the allegations against
the respondent indicate that the actions which he is alleged to have carried out, were carried out by him outside the
territory of the United Kingdom, and no information has been provided to demonstrate how those actions would, if
committed outside of the territory of the State, constitute criminal offences within the State.

38. There are set out six different reasons as to why the surrender of the respondent is prohibited by s. 44 in
relation to the 39 offences of manslaughter, as follows:

1. The EAW does not state where the deceased persons died. Further, any acts of the respondent which are
alleged to amount to the offence of manslaughter are alleged to have been done in Belgium.

2. The respondent is a British citizen and an Irish citizen, and has not been at any time ordinarily resident in the
State within the period of 12 months preceding the date of commission of the alleged offences.

3. No information is provided in the EAW as to the basis on which the United Kingdom asserts extraterritorial
jurisdiction.

4. The English statutory provisions relied upon in the additional information are out of date and/or inapplicable and
do not provide a basis for extraterritorial jurisdiction.

5. The English statutory provisions relied upon in the additional information received have no equivalent in Irish
law.


-----

6. The additional information contradicts the statement in the EAW that extraterritorial concerns do not arise.

39. It is separately pleaded that the surrender of the respondent is prohibited by s. 44 of the Act of 2003 in relation
to the alleged offences of conspiracy to commit human trafficking and conspiracy to assist unlawful immigration.
The first three reasons given are in each case the same as the first three reasons addressing the same issue as
regards the offences of manslaughter. In relation to the offence of conspiracy to commit human trafficking, the
following additional pleas are advanced:

1. There is no offence in this State corresponding to the offence contrary to s. 2 of the Modern Slavery Act 2015;

2. The acts of the respondent referred to in the additional information do not demonstrate the commission of any
offence contrary to the Act of 2015;

3. In the circumstances the offence does not constitute an offence under the law of the State, having been
committed in a place other than the State.

40. The EAW does not comply with s. 11(1A)(f) of the Act of 2003 because the description of the circumstances in
which the offences in respect of which surrender is sought is void for uncertainty and inadequate particulars of the
actions of the respondent in relation to the alleged offences have been provided. Moreover, there is insufficient
information setting out the degree of involvement of the respondent in respect of the offences, and the EAW fails to
identify the places where the offences occurred and therefore fails to demonstrate the jurisdiction of this Court to
order surrender, having regard to s. 44 of the Act of 2003.

41. The acts of the respondent as set out on the face of the EAW do not constitute the offence of manslaughter or
any other offence contrary to Irish law. As a consequence, surrender in respect of the 39 offences of manslaughter
is prohibited by s. 38(1) of the Act of 2003. Similarly, the acts of the respondent as set out in the EAW do not
constitute an offence under Irish law which would correspond to an offence contrary to s. 25 of the Immigration Act
1971.

42. The applicant is not entitled to rely on s. 38(1)(B) of the Act of 2003 and/or the provisions of Article 2(2) of the
Framework Decision to disengage the requirement to prove correspondence of the offences described in the EAW,
with offences in this jurisdiction. Seven separate reasons are provided in support of this plea:

1. The facts of the offences are not set out with sufficient particularity.

2. It is unclear which of the offences, if any, are “ticked box” offences.

3. The offences of conspiracy to commit the offence of human trafficking, as an inchoate offence is not an offence
within Article 2.2 of the Framework Decision.

4. The information received from the CPS contains no description of acts by the respondent which would comprise
the offence of conspiracy to commit the offence of human trafficking under the law of the United Kingdom, and
therefore the ticking of the box in respect of the offence, for the purposes of Article 2.2 of the Framework Decision is
a “manifest error”.

5. The purported indication on the part of the issuing judicial authority/CPS that manslaughter falls within the ticked
box relating to “murder, grievous bodily injury” is a manifest error;

6. The purported reliance on Article 2.2 in relation to the offence of conspiracy to assist illegal immigration contrary
to s. 25 of the Immigration Act 1971 is also a manifest error.

7. Accordingly, there is confusion on the face of the warrant (and the additional information) in relation to this issue,
such that it is unlawful for this Court to order the surrender of the respondent in relation to all or any of the offences
described in the EAW.


-----

43. The offence provided for in s. 2 of the Act of 2015, does not correspond to any offence under Irish law, and nor
do any of the acts of the respondent as described in the EAW,

which might amount to an offence under that provision, amount to an offence under Irish law.

44. Similarly, none of the actions of the respondent as described in the EAW as being contrary to s. 25 of the
Immigration Act 1971, correspond to any offence under Irish law.

45. The surrender of the respondent is prohibited because the EAW does not identify the name of the
representative District Judge of the Magistrates' Court in para. (i) of the warrant.

46. Surrender of the respondent is prohibited by s. 37 of the Act of 2003 because it would breach his constitutional
right to fair procedures and to a fair trial in circumstances where the facts comprising the offences are not set out
with sufficient detail or particularity so that the protection for speciality purposes in s. 22 of the Act is provided.

47. The surrender of the respondent is prohibited by s. 21 of the Act of 2003, because the additional information
received from the CPS discloses that the prosecutor has not yet determined the cause or place of death or the
basis on which it might be alleged that the respondent has committed manslaughter. Accordingly, there has been
no decision to charge and try the respondent for these offences, and the presumption set forth in s. 21A of the Act
of 2003 is rebutted.

48. I turn now to address the arguments raised on behalf of the parties in relation to each of the points of objection.

The preliminary issue

49. By way of preliminary issue, the respondent claims that the additional information supplied by the CPS by letter
on 4th December, 2019, and accompanying documentation is not admissible having been provided by the CPS,
and not by the issuing judicial authority. Moreover, the extent of the information provided by way of the additional
information is so voluminous as to effectively amount to a rewriting of the EAW as to be impermissible, even if the
information was provided by the issuing judicial authority. In support of these arguments, the respondent relies
upon the decisions of the Supreme Court in the cases of Minister for Justice, Equality & Law Reform v. Sliczynski

_[2008] IESC 73 and Rimsa v. Governor of Cloverhill Prison [2010] IESC._

50. In _Sliczynski one of the issues which the Supreme Court was required to consider was the admissibility of_
documents which had been received by the Central Authority here from the Polish court, which documents had
been signed in each case by a District Court Judge. The High Court in its decision had ruled the documents
admissible and had relied upon the same in its decision. In his appeal, the respondent contended that the High
Court Judge erred in law because the documentation concerned offended the rule on hearsay in the absence of
direct proof as to its contents. At p. 6 of his decision Fennelly J., having referred to Articles 7 and 15 of the
Framework Decision stated:

_“It is clear from the foregoing provisions that the Framework Decision intends that the executing Judicial_
_Authority may both seek and receive further information_

_related to a warrant from the issuing Judicial Authority and take into account that information for the_
_purpose of deciding whether an order for surrender should be made on foot of the warrant. It is important to note_
_that such information emanates from a Judicial Authority, one of the characteristics of which is its independence in_
_the exercise of its functions. Given that the simplified system of surrender of which the Framework Decision speaks_
_is based, inter alia, on mutual respect between Judicial Authorities it is quite logical that the Decision would make a_
_provision for one Judicial Authority, the executing one, to rely on information provided to it by the other Judicial_
_Authority, the issuing one. In all events that is what the Decision provides for.”_

51. On p. 7, Fennelly J. continued:

_“If further information is transmitted by the requesting Judicial Authority either on its own initiative or_
_following a request it is the function of the Central Authority to transmit it to the Executing Judicial Authority, in this_


-----

_country, the High Court. Section 20 must be interpreted in the light of the objectives of the Framework Decision and_
_its provisions. In my view it specifically gives effect to Article 15(2) and (3) of the Directive. In so providing I am_
_satisfied that the Oireachtas intended, consistent with the obligations of the State pursuant to the Framework_
_Decision, that the High Court would have available to it the information provided by the issuing Judicial Authority_
_and would have full regard to that information, in addition to information provided in the European Arrest Warrant_
_itself, for the purpose of deciding whether a person should be surrendered on foot of a European Arrest Warrant._
_Moreover to interpret the provisions of the Act otherwise would render them meaningless since if direct evidence_
_had to be given of the information concerned every Judge or member of the issuing Judicial Authority providing_
_information would either have to give evidence personally or swear an Affidavit of matters within their own_
_knowledge. If that were the case the provisions referred to would serve no purpose. Clearly in my view they were_
_intended to ensure that the High Court would have, where required, information from the Judicial Authority_
_concerned in addition to that already contained in the arrest warrant itself._

_Before the High Court can receive and take into account such information it must be established that the_
_information communicated emanates from the Judicial Authority of the requesting State. In this case that has been_
_established by the express averments in the Affidavits lodged on behalf of the applicant in the High Court. In any_
_event the source of the information has not been put in issue.”_

52. This latter point is of some significance and in sharp distinction to this case, where the source of the information
is the CPS. Accordingly, the respondent argues, this information should not be received and considered by the
Court.

53. The respondent also places heavy reliance on the decision of the Supreme Court in the case of _Rimsa v._
_Govenor of Cloverhill Prison and Minister for Justice, Equality & Law Reform_ _[2010] IESC 47. In that case, the_
applicant sought an order for his release from custody pursuant to Article 40.4.2 of the Constitution in
circumstances where he remained detained following the expiration of the period prescribed for surrender by s.
16(5) of the Act of 2003. The date for his surrender had been extended pursuant to an agreement made between
the Central Authority in this State, and the issuing state, which in that case was the Central Authority of the
Republic of Latvia. The case revolved around the interpretation of s. 16(5)(B) of the Act of 2003 (in its form at that
time – it was amended as a result of the decision in Rimsa) which provided:

_“(5) Subject to subsection (6) and section 18, a person to whom an order for the time being in force under_
_this section applies shall be surrendered to the issuing state not later than 10 days after –_

(a) the order takes effect in accordance with subsection (3)…or

(b) such date (being a date that falls after the expiration of that period) as may be agreed by the Central Authority
_in the State and the issuing state.”_

54. The central argument as regards the interpretation of the latter provision revolved around Article 23(3) of the
Framework Decision which provides:

_“3.         If the surrender of the requested person within the period laid down in paragraph 2 is_
_prevented by circumstances beyond the control of any of the Member States, the executing and issuing judicial_
_authorities shall immediately contact each other and agree on a new surrender date. In that event the surrender_
_shall take place within 10 days of the new date thus agreed.”._

55. It was argued on behalf of the applicant in that case that s. 16(5)(B) of the Act of 2003 had to be interpreted in
the light of Article 23(3) of the Framework Decision, which required any extension of the period within which a
person may be surrendered to be agreed as between judicial authorities, and not Central Authorities. The State
(the respondent in that case) acknowledged that the Act of 2003 may be interpreted in the light of the Framework
Decision but argued that it cannot be given a meaning that is contra legem. Since that section of the Act of 2003
expressly permitted the Central Authority in this State to enter into an agreement with the issuing state, then it was
entitled to do so even if Article 23(3) provides such an agreement must be entered into as between judicial
authorities.


-----

56. The Supreme Court held that there was an ambiguity in s. 16(5)(B) of the Act of 2003 insofar as it did not
provide that such an agreement could be entered in to with any particular person or body in the issuing state. As
such, that ambiguity had to be resolved by reference to the Framework Decision, which requires such agreements
to be entered into as between judicial authorities. On the basis of this authority, it is submitted on behalf of the
respondent in this case that the reference in s. 20(1) of the Act of 2003 to the “issuing state” should be interpreted
in light of the Framework Decision, especially in relation to fundamental matters such as the content of that
European Arrest Warrant as prescribed by Article 8 of the Framework Decision. Information of this kind, it is
submitted, must be provided by the issuing judicial authority.

57. To understand this point fully, it is necessary to set out s. 20 of the Act of 2003. It provides:

_“In proceedings to which this Act applies the High Court shall, if of the opinion that the documentation or_
_information provided to it is not sufficient to enable it to perform its functions under this Act, require the issuing_
_judicial authority or the issuing state, as may be appropriate, to provide it with such additional documentation or_
_information as it may specify, within such period as it may specify.”_

Accordingly, having regard to the decision of the Supreme Court in Rimsa, the respondent submits that the words
“issuing state” as appearing in s. 20 of the Act of 2003, should be interpreted as referring to the issuing judicial
authority.

58. In response to this argument, the applicant relies upon the decision of this Court (Donnelly J.) in the case of
_[Minister for Justice & Equality v. AW [2019] IEHC 251. In that case, precisely the same issue as that arising in this](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XV63-RSRP-M234-00000-00&context=1519360)_
case was dealt with by Donnelly J.

i.e. could a Court accept information provided by the CPS pursuant to a request made by the Court under s. 20 of
the Act of 2003? Donnelly J. held that it was open to the Court to accept such information. She addresses the
issue comprehensively in her decision at paras. 67 – 83. She noted that s. 20 of the Act of 2003 provides express
authority for this Court to seek information from either the issuing judicial authority or the issuing state. If the Court
was confined to obtaining such information from the issuing judicial authority only, the reference to the issuing state
would be otiose.

59. As regards the meaning of “the issuing state” Donnelly J. referred to Article 15 of the Framework Decision
which deals with the provision of additional information. Article 15(2) specifically empowers an executing judicial
authority to request supplementary information, but does not require that request to be addressed to the issuing
judicial authority, or that the issuing judicial authority should provide the response. In contrast, Donnelly J. noted,
Article 15(3) provides for the voluntary furnishing of additional information by the issuing judicial authority to the
executing judicial authority.

60. Donnelly J. relied heavily upon the decision of the Court of Justice of the European Union (“CJEU”) in the case
of ML (Generalstaatsanwaltschaft Bremen) [2018] C-220/18 PPU, in which case the CJEU ruled on an assurance
(as regards the prison conditions in which the person whose surrender was sought in that case would, if
surrendered, be detained) that was provided not by the issuing judicial authority, but by the Ministry for Justice of
Hungary. The CJEU held that the executing judicial authority was not precluded from accepting such an assurance,
but that it must evaluate the same by carrying out an overall assessment of the information available.

61. In AW, the Court carried out such an assessment and noted that the CPS was an emanation of the State of the
United Kingdom and there was no reason to doubt either the _bona fides of the CPS or the authenticity of the_
information it provided in response to the request. Donnelly J. referred to the decision of the Supreme Court
(Fennelly J.) in Minister for Justice, Equality & Law Reform v. Stapleton _[2007] IESC 30 wherein he stated:_

_“The principle of mutual recognition applies to the judicial decision of the judicial authority of the issuing_
_Member State in issuing the Arrest Warrant. The principle of mutual confidence is broader. It encompasses the_
_system of trial in the issuing Member State.”_


-----

62. Referring to the principle of judicial supervision which lies at the core of the Framework Decision, Donnelly J.
stated, at para. 77 of her decision:

_“The principle of judicial supervision is one which in accordance with recital 8 is one which is primarily to_
_be carried out by the executing judicial authority. The process is commenced by an EAW issued by a competent_
_judicial authority in the issuing state. Without such a judicial decision, there is no request for surrender within the_
_meaning of the Framework Decision or the Act of 2003. However, in the context of taking a decision on the_
_execution of that judicial decision in this member state, the High Court as executing judicial authority, must take into_
_account all of the information provided to it by the issuing state. The fact that information is not provided by the_
_issuing judicial authority, is a factor that the executing judicial authority must take into account when making a_
_decision to surrender in reliance on that information.”_

63. Donnelly J. concluded on this point in her judgment at para. 83 in the following terms:

_“This Court must apply mutual trust and confidence to the information that has been received by (sic) the_
_public prosecution of another Member State. In the absence of any real or substantive objection to the bona fides of_
_that response, it may provide the basis for the consideration of whether clarity in respect of the nature and number_
_of the offences has been obtained and whether there is in fact correspondence of offences.”_

64. It was acknowledged on behalf of the respondent that in general terms this Court is bound by decisions made
by another judge of this Court. However, it is submitted that the decision of Donnelly J. in AW does not confer a
“carte blanche” on the authorities of the issuing state. While it is accepted that certain things may be supplemented
whether by way of a request made pursuant s. 20 of the Act of 2003 or pursuant to s. 11(2)(A) of the Act of 2003,
these sections must be read harmoniously with the Framework Decision and it is not open to the authorities of the
issuing state to put all of the information in documentation that is separate to the EAW, and nor is AW authority for
such a proposition. It is submitted that when Donnelly J. gave judgment in AW, she did so at a time when s. 20
included s. 20(2) which conferred power on the Central Authority to

make requests for additional information, but that power has since been removed by way of amendment to s. 20. It
is submitted that Donnelly J. relied quite heavily on s. 20 in the form that it was when she made her decision, the
implication being that she might have made a different decision if she was dealing with the amended s. 20, such as
in this case.

65. It was further submitted that this case may be distinguished from AW in that in this case it is arguable that the
warrant as originally issued did not comply with s. 11 of the Act of 2003, and that compliance with that section in
this case is dependent, to an excessive extent, upon information delivered some five or six weeks after the arrest of
the respondent which was delivered not by the issuing judicial authority, but by the CPS.

66. It was also submitted on behalf of the respondent that even if this Court rejects the argument on this
preliminary point, a separate issue arises out of AW and that is that the decision in that case clearly indicates that it
is not open to the CPS to apply to amend the EAW to correct an error. In that case, there was an error in the EAW
(according to the

CPS) insofar as it did not indicate an intention to rely on Article 2(2) of the Framework Decision in respect of certain
offences. However, the CPS did not ask the Court to amend the warrant, but simply explained why the error
occurred.

67. In this case, just one box has been ticked for the purposes of Article 2(2) of the Framework Decision i.e. that
relating to trafficking human beings. Accordingly, it is not now open to the CPS to seek to invoke Article 2(2) in
relation to any of the other offences.

Decision on the preliminary issue

68. While the decision of the Supreme Court in _Sliczynski would suggest that additional information provided_
pursuant to s. 20 of the Act of 2003 must emanate from the issuing judicial authority, the statement to that effect in


-----

_Sliczynski was made in the context of a different factual matrix and, more importantly, where that Court was not_
asked to address the question now under consideration. In contrast, the decision of Donnelly J. in _AW not only_
addressed this same question, but did so in the context of the same Central Authority i.e. the CPS. Moreover, the
decision of Donnelly J. placed some significant reliance on the decision of the CJEU in ML, a decision which was
handed down in 2018, 10 years after the decision of the Supreme Court in Sliczynski. I agree with and adopt the
analysis of the issue by Donnelly J. in AW.

69. In accordance with ML, and as Donnelly J. did in AW, in circumstances where additional information has not
been provided by the issuing judicial authority, it is necessary to consider that information by reference to all of the
information placed before the Court by the competent authorities, including the issuing judicial authority, of the
requesting state, in this case the United Kingdom. In the context of this application, the starting point of that
analysis must be that in providing the additional information, the senior prosecutor of the CPS has twice stated in
her letter enclosing the additional information (which letter also addresses specific queries) that she is writing “on
_behalf of the relevant judicial authority”. While this is stated in response to specific information furnished, and not in_

relation to the entire letter, it is clear that that information at least is being provided on behalf of the issuing judicial
authority. However, even though the letter does not say so expressly, I think it is a reasonable inference to draw
that the entire contents of the letter are being provided on behalf of the relevant judicial authority.

70. Secondly, the additional information has been provided by the CPS. As was made clear in the decision of
Donnelly J. in AW, and as indeed counsel for the applicant in this case submitted to the Court, this is the practice of
the United Kingdom. Once the EAW has been issued by an issuing judicial authority, that authority is not usually
involved in providing information in response to queries received from the executing state. Neither the integrity nor
competence of the CPS is impugned in any way. Accordingly, there is no reason to doubt the authenticity of the
information or the _bona fides of the CPS. The Court is obliged to receive and treat the information provided in_
accordance with the principle of mutual confidence referred to by Fennelly J. in _Stapleton, which in turn reflects_
Article 10 of the Framework Decision.

71. While it is true that the information provided in the EAW as regards the circumstances of the offences alleged
against the respondent was somewhat scant, nonetheless the EAW itself was issued by a District Judge and was,
therefore, subject to the judicial scrutiny and supervision envisaged by the Framework Decision. The additional
information, while providing considerably more detail than the EAW, is in no way inconsistent with or contradictory
of the information provided in the EAW. Moreover, there is nothing in the additional information provided that would
cause this Court to have any concern that the issuing judicial authority might not have issued the warrant if this
information was contained in it in the first place; on the contrary, the additional information is supportive of the
information set forth in the EAW. Although the additional information is very voluminous, in contrast to that given in
the EAW, it does not in any way alter the character of the allegations being made against the respondent, the
charges that it is intended to bring against him (save that, as regards the manslaughter charges it is stated these
may be brought on an alternative basis, details of which are provided) or the penalties that he will face if convicted
of the offences set forth in the EAW. All of this being the case, it is my view that the additional information should
be admitted for the purpose of the Court's consideration of this application. The preliminary objection must
therefore be rejected.

Section 44 Objection

72. Section 44 of the Act of 2003 provides:

_“44. A person shall not be surrendered under this act if the offence specified in the European arrest_
_warrant issued in respect of him or her was committed or is alleged to have been committed in a place other than_
_the issuing state and the act or omission of which the offence consists does not, by virtue of having been committed_
_in a place other than the State, constitute an offence under the law of the State.”_

73. The respondent contends that the alleged offences were not committed in the issuing state i.e. the United
Kingdom. The respondent further contends that any acts on the part of the respondent which are alleged to amount
to the offence of manslaughter are alleged to have been done in Belgium The respondent relies on the statement


-----

at paragraph 3.22 of the additional information in which it is stated that the exact time and place of death is not
known, and submits that, while at a later stage in the additional information, from paragraphs 3.24 onwards the CPS
surmises that at least some of the victims were alive when the MV Clementine entered UK territorial waters, it is
clear that the CPS does not assert that all of the victims died inside UK territorial waters. Accordingly, it is
submitted, this engages s. 44 of the Act of 2003 in relation to the manslaughter charges.

74. The question that then arises is whether or not offences of manslaughter that may have occurred outside of the
jurisdiction of the United Kingdom, the issuing state, constitute offences under the law of the State. If so, a further
question that arises, by reason of the decision of the Supreme Court in the _Minister for Justice, Equality & Law_
_Reform v. Bailey_ _[[2012] 4 IR 1, is whether or not the authorities in the United Kingdom would be entitled to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CVB-NMX1-F0JW-R3XK-00000-00&context=1519360)_
prosecute for an offence of manslaughter if the situation were reversed i.e. if this State was the requesting state, the
United Kingdom the requested state and the offences were alleged to have been committed outside of the
jurisdiction of this State.

75. Both of these questions are answered through the provisions of s. 9 of the Offences Against the Person Act,
1861. In the United Kingdom, this section provides:

_“9.        Where any murder or manslaughter shall be committed on land out of the United Kingdom,_
_whether within the Queen's dominions or without and whether the person killed were the subject of Her Majesty or_
_not, every offence committed by any subject of Her Majesty in respect of any such case, whether the same shall_
_amount to the offence of murder or of manslaughter, or of being an accessory to murder or manslaughter, may be_
_dealt with, inquired of, tried, determined, and punished in any county or place in England or Ireland in which such_
_person shall be apprehended or be in custody, in the same manner in all respects as if such offence had been_
_actually committed in that county or place: provided, that nothing herein contained shall prevent any person from_
_being tried in any place out of England or Ireland for any murder or manslaughter committed out of England or_
_Ireland, in the same manner as such person might have been tried before the passing of this Act.”_

76. The references to Ireland remain in this section of the Act as it applies in the United Kingdom. However, this
section has been amended in this country and in its present form now states:

_“9.        Where any murder or manslaughter shall be committed on land out of [area of application of_
_laws of the State], and whether the person killed were [an Irish citizen] or not, every offence committed by [any_
_citizen of Ireland] in respect of any such case, whether the same shall amount to the offence of murder or_
_manslaughter, may be dealt with, enquired of, tried, determined, and punished in any county or place the [area of_
_application of the laws of the State] in which such_

_person shall be apprehended or be in custody, in the same manner in all respects as if such offence had_
_been actually committed in that county or place; provided, that nothing herein contained shall prevent any person_
_from being tried in any place out of [the area of application of the laws of the State] for any murder or manslaughter_
_committed out of [the area of application of the laws of the State], in the same manner as such person might have_
_been tried before the passing of this Act.”_

Conclusion on s. 44 Objection - Manslaughter Charges

77.  The respondent acknowledges that he is a citizen of both Ireland and of the United Kingdom. The parties are
in agreement as to the legal effect of s. 9 of the Offences Against the Person Act, 1861, in its form in each
jurisdiction. That is the parties agree that where an Irish citizen commits manslaughter outside the jurisdiction of the
State, that act constitutes an offence under the laws of the State, and may be prosecuted in the State, regardless
as to where the offence occurred and as to the nationality of the victim. The provision has precisely the same effect
in the United Kingdom. This means that there is reciprocity as required by the Supreme Court in Bailey. It is clear
therefore that even if some of the victims died outside of the territorial waters of the United Kingdom, their deaths
constitute an offence under the laws of the State (assuming of course that the offences are otherwise proven). The
objection advanced under s. 44 of the Act of 2003 insofar as it relates to the manslaughter charges must therefore
be rejected.


-----

S.44 Objection - Conspiracy to commit a human trafficking offence

78. However, this objection is also raised in relation to the offence of conspiracy to commit a human trafficking
offence, though not in relation to the offence of conspiracy to assist unlawful immigration. As regards the latter, it is
accepted that the corresponding offence in this jurisdiction is s. 2 of the Illegal Immigrants (Trafficking) Act 2000
and that that offence may be prosecuted by the authorities in this state on a extraterritorial basis, and that the
equivalent provision in United Kingdom law similarly confers jurisdiction to prosecute on an extraterritorial basis.
However, in relation to the offence of conspiracy to commit a human trafficking offence, it is submitted firstly that
there are no acts on the part of the respondent set out in the EAW which could amount to such an offence and
therefore the United Kingdom has no jurisdiction to try the respondent for the same. For the same reason, the
respondent could not be prosecuted in this state for such an offence in circumstances where the actions of the
respondent constituting the offence have not been set out. Accordingly, s. 44 of the Act of 2003 prohibits surrender
in respect of this offence.

79. Secondly, it is submitted that the actions of the respondent as described are said to have taken place in
Belgium. While it is accepted that the Act of 2015 in the United Kingdom and the Criminal Law (Human Trafficking)
Act 2008 in this jurisdiction permit each state to prosecute for offences under these Acts regardless of where they
are committed, it is submitted that these acts have no application for the reasons given in the preceding paragraph,
and so therefore the extraterritorial jurisdiction conferred by these Acts are of no assistance to the applicant.

80. In response to all of this the applicant argues that the charges of conspiracy are in no way affected by s. 44 of
the Act of 2003 because it is clear from the additional information that it is claimed that the conspiracy took place
within the United Kingdom, and it is on that basis that jurisdiction is asserted. The applicant relies, inter alia, upon
the following paragraphs of the additional information:

_“3.71.         However, as set out, above, it is the prosecution's case that the agreement (conspiracy)_
_was made within the UK._

3.81 The prosecution's case is that HARRISON has been involved in arranging or facilitating the travel of the 39
_deceased persons. There were meetings and telephone conversations which took place between co-conspirators in_
_the UK._

3.82 CCTV evidence, ANPR data and cell-site analysis also place HARRISON and his coconspirators in the UK at
_relevant times and on relevant dates. However,_

_HARRISON is a UK national so the relevant section that applies for jurisdiction in his case is section 2(6)_
_of the 2015 Act. He commits the offence regardless of where the arranging or facilitating takes place or where the_
_travel takes place._

_3.84 There is ample evidence to show in this case that part of the arranging and facilitation took place in_
_the UK and the travel consisted in the arrival in or entry into or travel within the UK._

_4.7        Conspiracy to commit human trafficking offence - The essence of the conspiracy is the_
_agreement. The Prosecution submits the agreement was made in the United Kingdom. To prove the existence of_
_the agreement, the Prosecution seeks to rely on the acts done in furtherance of the agreement. There is evidence_
_of telephone calls and meetings between HARRISON and the other co-conspirators which took place in the UK as_
_set out in the particulars above.”_

Conclusion on s. 44 Objection as regards conspiracy to commit human trafficking offence

81.  As stated at para. 4.3 of the additional information, the essence of the conspiracy is the agreement. It is stated
repeatedly in the additional information that there is evidence of activities in which the respondent was involved in
which he and his co-conspirators, who are named, arranged for the travel and entry into the UK of the deceased
migrants. While it is true to say that there is very little information in relation to activities that would constitute human
trafficking, the issuing judicial authority has ticked the box associated with this offence, and it follows therefore that


-----

in considering the s. 44 objection to this offence, I am not required to consider the quality of the evidence for the
offence but only where it occurred. It is clearly asserted that the agreement constituting the conspiracy was made in
the United Kingdom and that being the case surrender in respect of this offence is not prohibited by s. 44 of the Act
of 2003.

Failure to comply with s. 11(1A) of the Act of 2003

82. It is claimed that there has been a failure on the part of the issuing judicial authority to comply with s. 11(1A) of
the Act of 2003 and furthermore that the additional information received from the CPS is not a document within the
meaning of s. 11(2A) of the Act of 2003 (and accordingly is not admissible pursuant to that section), and nor is it
admissible pursuant to s. 12(8) of the Act of 2003.

83. There have been numerous decisions over the years which have addressed the importance of the EAW
containing the required information, so that the party whose surrender is requested will have clarity as to, inter alia,
the offences for which surrender is sought, and the penalties that those offences attract. In _Minister for Justice,_
_Equality & Law Reform v. Connolly_ _[[2014] 1 IR 720, Hardiman J. stated, at para. 31:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JT5-72W1-F0JW-R08V-00000-00&context=1519360)_

_“I consider it to be an imperative duty of a court asked to order the compulsory delivery of a person for trial_
_outside the State to ensure that it is affirmatively and unambiguously aware of the nature of the offences for which it_
_is asked to have him forcibly delivered, and for which he may be tried abroad, and of the number of such offences.”_

84. While accepting that the issuing judicial authority is not under an obligation to prove the case against the
respondent, it is submitted on behalf of the respondent that issues relating to s. 38 and s. 44 of the Act of 2003
cannot be resolved because of the deficit of information in the EAW.

85. In relation to the manslaughter offences, it is claimed that there is little information as to the degree of
participation of the respondent in relation to these charges. It is claimed on behalf of the respondent that having put
forward one basis for manslaughter in the EAW

i.e. that the respondent intentionally did an unlawful and dangerous act from which death inadvertently resulted, in
the additional information the CPS has stated that it may rely on gross negligence as an alternative basis to
establish manslaughter. It is submitted that it is not open to the prosecutors to put forward alternative options, and
furthermore in neither case, is there sufficient information set forth in the EAW or the additional information.

86. It is also submitted that large portions of the information supplied by the CPS relate to third parties and not the
respondent, and that this suggests that the respondent is being treated as guilty by association with others. It is not
stated that the respondent knew that there were persons in the trailer which it is alleged he deposited at the port in
Zeebrugge. Nor is there any information as to when or where the persons entered the trailer. Since s. 11(1A)(f)
requires that the EAW specify the degree of involvement or alleged degree of involvement of the respondent, this is
wholly inadequate.

87. In substance, it is submitted that the EAW, and the additional information, say very little more about the
conduct of the respondent other than that he delivered the trailer to Zeebrugge at 13:54 hours on 22nd October,
2019, and that the trailer in question was loaded on the MV Clementine in Zeebrugge at 14:55 hours. There is then
a reference to phone calls being made by Mr. Ronan Hughes to the respondent on 23rd October, 2019, after the
arrest of Mr. Robinson, and it is also stated that the respondent discarded his mobile phone which was used by him
for contacting Mr. Hughes.

88. It is submitted that such information as has been provided in relation to the conduct of the respondent does not
form a basis for a charge of manslaughter and, in circumstances where the cause of death (as at the date of the
hearing of this application) remains unknown, there must be a question as to whether or not the EAW is being used
in order to hold the respondent pending consideration of whether and on what basis manslaughter charges may be
brought against him.


-----

89. Moreover, as regards the contact between Mr. Hughes and the respondent, it is stated that the respondent was
recruited as a lorry driver by Mr. Hughes, and contact between employer and employee is to be expected. Since no
allegation is made in relation to Mr. Hughes, inferences should not be drawn from that contact.

90. Finally, in relation to the charge of manslaughter, it is submitted that it is difficult to avoid the conclusion that the
respondent in being sought for prosecution of the manslaughter charges on the basis that he was the driver of the
truck which deposited the trailer in Zeebrugge, with nothing more to support that allegation. It is submitted that this
is not sufficient to meet the requirements of s. 11(1A)(f) of the Act of 2003. Similar arguments are made on behalf
of the respondent in the context of arguing that the acts of the respondent could not constitute the offence of
manslaughter in this jurisdiction, and I will address those arguments in that context later.

91. It is also submitted that the particulars of the conspiracy charges both in relation to unlawful immigration and
human trafficking are set out in general terms, and are no more than to the effect that the respondent conspired
with others (who are named) between the specified dates to commit the offences. Reliance is also placed (by the
applicant) upon events that occurred in May 2018, 10th/11th October, 2019, and 17th/18th October, 2019 (see
para. 19 above), but it is submitted that these are entirely separate incidents and do not assist the Court in relation
to the events that occurred on 22nd October, 2019.

92. In response to this, it is submitted on behalf of the applicant that the allegations against the respondent as set
forth both in the EAW and in the additional information are adequate for the purposes of s. 11(1A)(f) of the Act of
2003. The respondent refers to several authorities in which this issue was considered, including the cases of
_Minister for_

_Justice, Equality & Law Reform v. Desjatnikovs_ _[[2009] 1 IR 618, Minister for Justice,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XGT-RWW0-YBF4-K2F1-00000-00&context=1519360)_

_Equality & Law Reform v. Stafford [2009] IESC, Minister for Justice, Equality & Law Reform v. Jarzebak_

_[[2010] IEHC 472, and Minister for Justice, Equality & Law Reform v. Cahill](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XK63-RSC8-21MB-00000-00&context=1519360)_ _[2012] IEHC 315. In this latter case, in a_
passage upon which the applicant relies, Edwards J. stated, as regards the requirements of s. 11(1A)(f):

_“The…objective… is to enable the respondent to know precisely for what it is that his surrender is sought._
_A respondent is entitled to challenge his proposed surrender and in order to do so needs to have basic information_
_about the offences to which the warrant relates. Among the issues that might be raised by a respondent are_
_objections based upon the rule of specialty, the ne bis in idem principle and extra-territoriality to name but some. In_
_order to evaluate his_

_position, and determine whether or not he is in a position to put forward an objection that might_
_legitimately be open to him to raise, he (and also his legal advisor in the event he is represented) needs to know, in_
_respect of each offence to which the warrant relates, in what circumstances it is said the offence was committed,_
_including the time, place, and degree of participation in the offence by the requested person.”_

93. It is submitted that it is well established that there is no requirement for the issuing state to establish a prima
_facie case in the European Arrest Warrant. Indeed, Counsel for the respondent accepts that this is so.  In the case_
of _Minister for Justice, Equality & Law Reform v. Phillip Baron_ _[2012] IEHC 180, Edwards J., in addressing the_
issue, stated:

_“It is sufficient if the information both specifically asserts a link and gives a general outline of the basis for_
_that assertion, or alternatively sets forth sufficient alleged circumstantial facts that would, if proven, allow a court to_
_infer the necessary link. It is not necessary, however, to provide every detail of the proposed evidence by means of_
_which the circumstances in question might be established in Court.”_

94. It is necessary to bear in mind that at this juncture that I am dealing only with the objection that the particulars
of the offences given in the EAW do not comply with s. 11(1A)(f) of the Act of 2003. It is agreed that the particulars
given need not amount to even a prima facie case in relation to the offences alleged. The purpose of the section
has been interpreted as meaning that the person whose surrender is sought should know from the warrant the
purpose for which his/her surrender is required. The person concerned is entitled to sufficient particulars for two


-----

reasons, firstly in order to be able to raise any of the objections permitted by the Act of 2003, and secondly so that if
his or her surrender is ordered, the purpose for the surrender is clear. It is well established in order to meet these
requirements, clarity in the warrant is required.

Conclusion on s. 11(1A) Objection

95. Firstly, I have already ruled above that the additional information provided by the CPS, on behalf of the issuing
judicial authority, may be admitted for the purposes of the consideration of this application. Although that
information was provided pursuant to a request made under s. 20 of the Act of 2003, in my opinion it may also be
considered information provided for the purposes of s. 11(2A) of the Act of 2003 which provides:

_“(2A) If any information to which subs. (1A) (inserted by s. 72(a) of the Criminal Justice_

_(Terrorist Offences) Act 2005) refers is not specified in the European Arrest Warrant, it may be specified in_
_a separate document.”_

96. The central objection raised on behalf of the respondent as to non-compliance with s. 11(1) of the Act of 2003
is that particulars of the circumstances in which the offences were committed are not sufficiently clear, and nor is
the degree of alleged involvement of the respondent in the commission of those offences.

97. I will first address the objection that the description of the circumstances in which the offences were committed
is deficient. The respondent is to be charged with 41 offences, made up of 39 offences of manslaughter, and two
offences of conspiracy, the first being a conspiracy to commit a human trafficking offence under s. 2 of the Modern
**_Slavery Act 2015 in the United Kingdom, and the second being a conspiracy to assist unlawful immigration contrary_**
to s. 25 of the Immigration Act 1971 of the United Kingdom.

98. It is clear from the information provided that each of the 39 manslaughter charges arises from the same set of
circumstances i.e. all of the deceased persons were transported in a

trailer unit the Port of Zeebrugge in Belgium and from there to the Port of Purfleet in the United Kingdom, and
thereafter towards their destination in the United Kingdom. The ferry crossing alone took nine hours. The
refrigeration unit in the trailer was turned off and there was no cooling of any kind, causing the temperature in the
trailer unit to reach a high of 38.5 degrees during the journey. Although at the time of this hearing the precise cause
of death was uncertain, it is likely that all of the deceased died of hypoxia, or oxygen starvation.

99. The circumstances in which the misfortunate migrants died could hardly be more clear. The only details of any
significance that are missing are the circumstances in which they came to be on board the trailer unit in the first
place. But those details are not necessary for the purposes of this application. The circumstances in which the
victims died are clearly set out and in sufficient detail for the purposes of this application.

100. As to the degree of involvement of the respondent, it is true that neither the EAW nor the additional
information allege that the respondent was responsible for placing the victims in the trailer, or that he had any
knowledge of their presence therein. This issue requires further exploration in the context of another objection
raised on behalf of the respondent i.e. that the acts alleged against the respondent do not correspond to the offence
of manslaughter in this jurisdiction, which I address below. But for the purpose of the objection grounded upon noncompliance with s. 11(1A)(f) I believe that when the EAW and the additional information are read as a whole, this
Court is entitled to draw an inference that it is alleged that the respondent, at a minimum, knew that the migrants
were in the trailer at the time that he transported them to Zeebrugge and left there for onward transportation to
Purfleet. Such an inference is entirely logical because it is also alleged that the respondent was involved in a
conspiracy to assist in unlawful immigration, and a separate conspiracy to commit a human trafficking offence.

101. As to the conspiracy charges, in the context of an allegation, what more could be said? The respondent and
others are alleged to have been involved in a conspiracy to bring immigrants into the United Kingdom illegally. It is
further alleged that these activities were not confined to assisting illegal immigration, but also involved exploitation
of those brought into the United Kingdom, such as to constitute exploitation of those persons, contrary to the Act of


-----

2015. Information regarding the involvement of the respondent and his co-conspirators in such activities on
previous occasions is provided. The extent of the respondent's involvement in these activities is, at a minimum,
alleged to have been

the transportation of the migrants to the Port of Zeebrugge. For the purposes of s. 11(1A)(f) of the Act of 2003, I
consider that there is sufficient information regarding the degree of involvement of the respondent in the alleged
offences of manslaughter and conspiracy to assist in unlawful immigration.

102. As regards the offence of conspiracy to commit a human trafficking offence, very limited information is
provided. Reliance appears to be placed on two matters, the first being the exploitation of the migrants on the
journey itself ( related to the cost and conditions of the journey) and the second, which is based on observation of
previous activities in which the respondent and his co-conspirators were allegedly involved, is that it is unlikely that
the victims would have been free to do as they pleased had they arrived safely. To the extent that this constitutes
an offence, the degree of involvement of the respondent appears to be that this was all part of the same conspiracy
that involved assisting illegal immigration into the United Kingdom, in respect of which for this purpose I have
already decided that there is sufficient information in the EAW and the additional information. Since the two
conspiracies are inextricably linked, I believe that there is sufficient information in the EAW and in the additional
information provided in relation to this offence also. As the authorities make abundantly clear, there does not even
have to be sufficient information in the EAW or the additional information to establish a prima facie case; applying
the test set out by Edwards J. in Minister for Equality & Justice v. Phillip Baron referred to above, the information
provided both specifically asserts a link between the respondent and the alleged offences, and gives a general
outline of the basis for that assertion, or alternatively sets forth sufficient alleged circumstantial facts that would, if
proven, allow a court to infer the necessary link. As the Court further observed in that case, it is not necessary that
every detail of the proposed evidence by means of which the circumstances in question might be established in
Court should be provided.

Objection to invocation of Article 2(2) of the Framework Decision - Manifest Error

103. In the EAW, the issuing judicial authority ticked the box for just one of the offences prescribed by Article 2(2)
of the Framework Decision, that relating to trafficking in human beings. In the additional information, the CPS stated
that it was intended to invoke Article 2(2) in relation to all offences. However, at the hearing of this application,
counsel for the applicant informed the Court that he was seeking to rely on Article 2(2) in respect of the trafficking
offence only, and accordingly he accepts that it is necessary to demonstrate correspondence in relation to the
manslaughter offences and the offence of conspiracy to assist unlawful immigration. I address this below, but first it
is necessary to address the argument advanced on behalf of the respondent that the invocation of Article 2(2) in
relation to the conspiracy to commit a human trafficking offence is a “manifest error”.

104. The respondent contends that the invocation of Article 2(2) in respect of the offence of conspiracy to commit a
human trafficking offence is a manifest error on the part of the issuing judicial authority such that it should not be
entitled to rely on Article 2(2), and should instead be required to demonstrate correspondence between the acts
relied upon in relation to this offence with an offence under the law of the State, as required by s. 38 of the Act of
2003. It is submitted that there is no information at all in the EAW or in the additional information that would suggest
that the respondent engaged in the trafficking of any person.

105. Under s. 2(1) of the Act of 2015, in the United Kingdom, a person commits an offence if he arranges or
facilitates the travel of another person with a view to that person been exploited. It is clear from this section and also
s. 2(4) of the same act that under UK law the offence of trafficking in human beings involves an element of
exploitation and control and not just the simple facilitation of illegal immigration. The absence in the EAW of any
intention to exploit the migrants upon their arrival in the UK demonstrates that there is no evidence at all such as to
indicate the commission of an offence under the Act of 2015.

106. The offence of trafficking of persons under Irish law is provided for in s. 4 of the Criminal Law (Human
Trafficking) Act 2008. The various ingredients of the offence in this section include coercion, threats, deception,
abuse and use of force. There is no indication in the EAW or in the additional information as to the presence of any


-----

of these factors or any of the other factors set out in that section in the treatment of those who died while being
transported to the United Kingdom.

107. Accordingly, it is submitted, it follows that the applicant should not be entitled to rely on the invocation of
Article 2(2) in relation to this offence, as it is a manifest error. It is submitted that in the case of Minister for Justice v
_Devlin_ _[[2010] 1 IR 97, Peart J.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5230-9RH1-F0JW-R1YV-00000-00&context=1519360)_

acknowledged that the court could disregard the fact that an offence had been ticked and require proof of
correspondence between the alleged acts and the offence in Irish law in circumstances where there is a manifest
error on the face of the warrant.

108. In response to this, it is submitted on behalf of the applicant, firstly, that the statement in the EAW that “the
_case against Eamon Harrison relates to the trafficking and subsequent death of 39 people within an artic trailer unit”_
in itself is enough to disprove any suggestion of a manifest error.

109. It is further submitted that the Supreme Court has made it clear in its decision in the case of the Minister for
_Justice, Equality and Law Reform v. Ferenca_ _[[2008] 4 IR 480 that it is entirely a matter for the requesting state to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WDH-NHM0-YBF4-K065-00000-00&context=1519360)_
invoke Article 2(2). In para. 22 of his decision, Murray C.J. stated “Article 2 only applies to the specified offences in
_Article 2.2 and it is for the issuing states to identify any offence in relation to which surrender is sought, as defined_
_by its own law, as being one of the offences listed in Article 2.2”. In para. 114 of the same judgement, Macken J._
stated: “Article 2.2 of the Framework Decision gives no right to an executing Member State to go behind the listed
_offences, once ticked, to require correspondence…”_

110. The applicant also relies upon the case of Minister for Justice, Equality and Law Reform v. Ciupe, a decision
_of Edwards J. in this Court delivered on 13th September, 2013, having quoted extensively from Ferenca, stated:_

_“where a box is ticked and the basis for the issuing state having done so is not obvious, giving rise to a_
_suggested manifest error, a court might proceed in a number of ways. In some cases the raising of a query using_
_the procedure under section 20 of the Act of 2003 and aimed at clarifying the intention of the issuing judicial_
_authority would be the most appropriate way of proceeding. However, in other cases the court might consider it_
_appropriate to proceed to make a specific finding of manifest error and disregard the ticking of the box. In yet other_
_cases the appropriate thing to do might be to make no specific finding of error but rather for the court to proceed of_
_its own motion to consider the issue of correspondence notwithstanding that box is ticked e.g., in a case where it_
_appears that correspondence will be demonstrable in any event, in which case the respondent's objection would be_
_otiose in practical terms, and the raising of a query using the section 20 procedure could serve only to delay an_
_inevitable outcome._

_The point that requires to be stressed here is that the existence of an error would have to be truly_
_“manifest” and the only reasonable conclusion, before an executing court would be justified in disregarding the_
_ticking of a box on the grounds of error. Having regard to the Supreme Court's clear and unequivocal statement in_
_Ferenca that it is for the issuing state to decide whether or not its national law defines the particular conduct which it_
_alleges against the person whose surrender is sought, as one of the offences listed in Article 2.2, it follows that it_
_will only be in the rarest of cases that an error would be truly manifest, as opposed to being suspected at the level_
_of possibility. Accordingly, it seems to me that an executing court should exhibit considerable reticence about_
_engaging positively with an objection to reliance by an issuing judicial authority upon Article 2.2 of the framework_
_decision on the grounds of alleged manifest error, and that it should only do so in circumstances where it can be_
_totally satisfied from what is contained in the face of the warrant that there has indeed been an unintended but_
_significant drafting error involving the inappropriate ticking of a particular box in the Article 2.2 list”_

111. Counsel for the applicant also relied upon the later decision of Donnelly J. in the Minister for Justice, Equality
_and Law Reform v. Fassih, 2nd February, 2017, in which the Court reiterated the principles set forth in Ferenca and_
_Ciupe. Counsel further submitted that this line of authority would apply with equal force to the inchoate offence of_
conspiracy to commit a tick box offence, and relies upon the decision of Peart J. in the case of Minister for Justice,
_[Equality and Law Reform v. O'Sullivan [2011] IEHC 230, in which case Peart J.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XKH3-RSC8-223V-00000-00&context=1519360)_


-----

ordered the surrender of the respondent in respect of the offences of conspiracy to commit fraud. Similarly, in the
case of _Minister for Justice, Equality and Law Reform v. McGowan, Donnelly J. rejected an argument that she_
should look behind the invocation of Article 2(2) in respect of an inchoate offence.

Conclusion on “Manifest Error” objection

112. The authorities on this issue are very clear. It is entirely a matter for the requesting state whether or not to
invoke Article 2(2) of the Framework Decision in respect of an offence. The requested state is not entitled to go
behind this invocation save in cases of manifest error. In Ciupe, Edwards J. suggested that the error must be in the
nature of a drafting error. In Devlin, Peart J. gave an example of another kind of error which is so glaring as

to be manifest, where the box for fraud was ticked, but the surrender of the respondent was sought for a very
different kind of offence, such as murder. Neither of these examples apply in this case. There is no manifest error. It
is not at all difficult to see how the facts alleged against the respondent could include a human trafficking offence,
including conspiracy to commit such an offence. This Court is not concerned with the strength of the evidence
indicated in the EAW or in the additional information, when considering whether or not there has been a manifest
error. I am satisfied beyond any doubt that this is not one of those very rare cases in which the Court can or should
disregard or override the choice of the issuing judicial authority to invoke Article 2(2) of the Framework Decision for
an offence.

Section 38 Objection

113. The respondent further objects to his surrender on the grounds that the offences described in the EAW do not
correspond to offences under the law of the State, having regard to the requirement set forth in s. 5 of the Act of
2003 which provides:

_“5-         For the purposes of this act, an offence specified in a European Arrest Warrant corresponds_
_to an offence under the law of the State, where the act or omission that constitutes the offence so specified would, if_
_committed in the State on the date on which the European Arrest Warrant is issued, constitute an offence under the_
_law of the State.”_

114. Having found, as I have, that this Court is bound by the ticking of the box that refers to trafficking in human
beings, it is of course not necessary for the applicant to demonstrate correspondence as regards the offence of
conspiracy to commit a human trafficking offence. The applicant accepts, however, that it is necessary to
demonstrate correspondence in relation to the manslaughter offences and the offence of conspiracy to assist
unlawful immigration.

115. Dealing with the latter offence first, the applicant argues that the acts of the respondent as described in both
the EAW and the additional information, viewed as a whole, would, if committed in the State, constitute the offence
of conspiracy contrary to s. 71(1) of the Criminal Justice Act 2006, because the conspiracy relates to the carrying
out of an act that would constitute a serious offence (as defined in s. 70 of that Act), that offence being an offence
contrary to s. 2(1) of the Illegal Immigrants (Trafficking) Act 2000. That section provides:

_“2(1) A person who organises or knowingly facilitates the entry into the State of a person whom he or she_
_knows or has reasonable cause to believe to be an illegal immigrant or a person who intends to seek asylum shall_
_be guilty of an offence and shall be liable –_

(a) on summary conviction, to a fine not exceeding £1,500 or to imprisonment for a term not exceeding 12 months
_or to both,_

(b) on conviction on indictment, to a fine or to imprisonment for a term not exceeding 10 years or to both.”

116. The definition of “serious offence” in s. 70 of the Criminal Justice Act 2006 is an offence for which a person
may be punished by imprisonment for a term of four years or more. The respondent did not dispute that these are
the relevant statutory provisions in the State for the purposes of establishing correspondence of the offence of
conspiracy to assist unlawful immigration However the respondent contends that there is no factual basis of any


-----

kind set forth in the EAW or the additional information which indicates that the respondent organised entry of illegal
immigrants into the United Kingdom or that he was involved in a conspiracy to do so. No information is provided as
to when the victims entered the trailer or in what circumstances, or that the respondent knew of their presence in
the trailer. Nor is there any information provided as regards meetings or phone calls in which the respondent was
involved whereby he was a party to a plan to facilitate the entry into the United Kingdom of the deceased migrants.
Accordingly, it is submitted, the applicant has failed to establish correspondence in relation to this offence.

117. The applicant contends that looking at the information as a whole, the following facts are relevant:
(1) Firstly, it is stated that the respondent is involved in a conspiracy to traffic illegal immigrants into the United
Kingdom.

(2) Secondly, it is stated that he and another named individual were recruited to activity this by a third named
individual.

(3) It is stated that another driver was paid £1,500 per person for these activities, and on one occasion was paid a
total of £25,000.

(4) It is stated that on 9th May, 2018, the respondent was stopped with a trailer unit containing eighteen
Vietnamese migrants.

(5) It is stated that on 10th/11th October, 2019, the respondent is believed to have been the driver of a truck that
delivered a trailer of illegal immigrants to the same port, crossing the same channel.

(6) It is stated that on 17th/18th October, 2019, the respondent delivered more illegal immigrants to the same port.
Further information is provided as to what happened when these immigrants arrived in the United Kingdom.

(7) It is stated that there is evidence of mobile phone contacts between the coconspirators, including the
respondent, and a wealth of other circumstantial evidence in this regard.

(8) It is stated that the respondent was responsible for depositing the trailer in which the misfortunate deceased
migrants were transported, at Zeebrugge Port.

(9) Shortly after one of the co-conspirators was arrested, it is stated there was phone contact between the
respondent and another co-conspirator, and, thereafter, the respondent disposed of his phone.

(10) Finally, is also stated that the respondent did not contact law enforcement agencies, despite the fact that he
was the person who transported the trailer, when the deaths of the migrants became known and received
widespread publicity.

118. It is submitted on behalf of the applicant that the Court is entitled to have regard to all of the facts as stated,
including those that would amount to circumstantial evidence, and that the court is entitled to draw inferences from
those facts. All of that being the case, if the acts described in the EAW and the additional information were
committed in the State, those acts would constitute an offence contrary to s. 71(1) of the Criminal Justice Act 2006.

Conclusion on s.38 Objection in relation to offence of conspiracy to assist unlawful immigration

119. The test for establishing correspondence with in offence in this jurisdiction is set out in the decision of Minister
_for Justice and Law Reform v. Dolny_ _[2009] IESC 48. In that case, Denham J. (as she then was) stated:_

_“In addressing the issue of correspondence, it is necessary to consider the particulars on the warrant, the_
_acts, to decide if they would constitute an offence in the State. In considering the issue, it is appropriate to read the_
_warrant as a whole. In so reading the particulars it is a question of determining whether there is a corresponding_
_offence. It is a question of determining if the acts alleged were such that if committed in this jurisdiction they would_
_constitute an offence. It is not a helpful analogy to consider whether the words would equate with the terms of an_


-----

_indictment in this jurisdiction. Rather it is a matter of considering the acts described and deciding whether they_
_would constitute an offence if committed in this jurisdiction.”_

120. In the additional information, there is detailed information provided in respect of the activities the respondent
and other named persons in relation to three previous incidents involving transportation of illegal migrants. The role
of the respondent in these events is described. Names of the others involved in the events are also provided. It is
stated that there is evidence of communications between the respondents and his co-conspirators. One of those coconspirators, Mr. Robinson, was the driver of the lorry that collected the trailer from Purfleet Port. He has pleaded
guilty to the offence of conspiracy to assist unlawful immigration. Finally, the respondent is said to be the person
who drove the trailer to Zeebrugge Port, with the migrants on board.

121. In my view, if all of these acts were committed in the State, it would surely be the case that they would
constitute an offence under the law of the State, contrary to s. 71 of the Criminal Justice Act 2006. I therefore
dismiss the respondent's objection under this heading

Section 38 Objection - Manslaughter Charges

122. Counsel for the applicant submits that the facts alleged against the respondent in the EAW and the additional
information fall well short of the criteria required to establish either manslaughter by criminal negligence or
manslaughter by a criminal and dangerous act. In order to establish the offence of manslaughter by criminal
negligence, it is not enough to establish ordinary negligence; there is a requirement for negligence in a very high
degree. Counsel referred the Court to the authority of _The People (AG) v. Dunleavy_ _[[1948] IR 95. In that case,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W4W-0FG0-YBF4-K2VV-00000-00&context=1519360)_
Davitt J. set out at p. 102, the instructions that should be included in a charge to a jury in respect of the charge of
manslaughter by criminal negligence. These include:

(a) [not relevant]

(b) That they [the jury] must be satisfied that negligence upon the part of the accused was responsible for the death
in question.

(c) That there are different degrees of negligence, fraught with different legal consequences; that ordinary
carelessness while sufficient to justify a verdict for a plaintiff in an action for damages for personal injuries, or a
conviction on prosecution in the District Court for careless or inconsiderate driving, falls far short of what is required
in a case of manslaughter; and that the higher degree of negligence which would justify a conviction on prosecution
in the District Court for dangerous driving is not necessarily sufficient.

(d) That before they could convict of manslaughter, which is a felony and a very serious crime, they must be
satisfied that the fatal negligence was of a very high degree; and was such as to involve, in a high degree, the risk
or likelihood of substantial personal injury to others.

123. It is submitted that on the facts as alleged, there is no evidence of gross negligence on the part of the
respondent. There are no facts alleged that are sufficient to establish that he breached any duty of care, because
there is no allegation that he was in any way involved in the entry of the migrants into the trailer, or even that he
knew they were there.

124. As regards manslaughter by a criminal and dangerous act, the respondent relies on the decision of the
Supreme Court in The People (AG) v. Crosbie _[[1966] IR 490. In that case, Kenny J. stated:-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RH9-2B70-TXX6-91PJ-00000-00&context=1519360)_

_“When a killing resulted from an unlawful act, the old law was that the unlawful quality of the act was_
_sufficient to constitute the offence of manslaughter. The correct view, however, is that the act causing death must_
_be unlawful and dangerous to constitute the offence of manslaughter. The dangerous quality of the act must,_
_however, be judged by objective standards and it is irrelevant that the accused person did not think that the act was_
_dangerous.”_


-----

125. It is submitted that none of the information provided gives any indication of what the respondent did that was
objectively dangerous. Moreover, here again it is not alleged anywhere in the information provided that the
respondent put the migrants in the trailer, that he knew they were in the trailer or that he knew how many people
were in the trailer. The latter, it is submitted, is a highly material consideration in circumstances where the cause of
death, assuming that it was caused by suffocation, may well have been influenced by the number of people in the
trailer. It is submitted that the Court is being invited to infer too much and the Court should not do so. There are
facts that are essential to establishing correspondence with the offence of manslaughter in this jurisdiction (whether
by criminal negligence or by a criminal and dangerous act) that are not stated in the EAW, and which could very
readily have been stated. It is submitted that they are not stated because that information is not available. All of that
being the case, correspondence with the offence of manslaughter in this jurisdiction, on the basis of the factual
information provided, is not established.

126. The applicant does not dispute the criteria for establishing the offence of manslaughter. The principal
difference between the applicant and the respondent in relation to this aspect of the matter is the extent to which
the Court is entitled to draw inferences. Counsel for the applicant submits that what the Court must do is look at the
acts stated in the information provided in the round and as a whole, and submits that it is manifest from the
additional information that what is being alleged is that the respondent and his co-conspirators knew that the
migrants were in the trailer because he and his coconspirators were involved in a conspiracy to facilitate the entry of
people, illegally, into the United Kingdom from as far back as May, 2018.

127. The applicant relies, inter alia, on all of the information summarised in para. 117 above. On the basis of this
information, it is submitted that it is clearly being alleged that since he was a conspirator in the enterprise, the
respondent not only knew that all of those people were in the trailer, but he facilitated their presence there. The act
of transporting people in this manner, in a sealed container for onward transportation in a ferry to the United
Kingdom, in a journey lasting nine hours, is manifestly dangerous. So, therefore, it is clear that the acts concerned
were not just unlawful, but sufficiently dangerous as to meet the criteria for the offence of manslaughter by a
criminal and dangerous act in this jurisdiction.

Conclusion on s. 38 Objection - Manslaughter Offences

128. Central to the decision of the Court on this issue is whether the Court may draw inferences from the
information provided, and, if so, to what extent. It is well settled that the Court is obliged to consider the information
provided in the EAW and in the additional information as a whole, and this is not disputed. No authority has been
cited to me that declares that the Court may not draw such inferences as are reasonable from the information
provided. In my opinion, having regard to the duty the Court has to give effect to the Framework Decision, that it
has been held that refusal to surrender should only arise in exceptional cases, and that this is an administrative and
not a substantive proceeding, the Court is entitled to draw such inferences as are reasonable to draw from the
information provided, and I will proceed accordingly.

129. While it is true that the information provided does not state that the respondent himself was responsible for
placing the migrants in the trailer or even that he knew they were there, or, that if he did, how many of them were
there, nonetheless I think it is a reasonable inference to draw that this is what is alleged as against the respondent.
This is apparent, in my view, from the conspiracy charges. It is clearly not being alleged that the respondent was
merely the driver; it is alleged that he was a party to an agreement to facilitate the commission of a breach of
immigration law and, separately, an agreement to commit a human trafficking offence. Necessarily this means that
it is alleged that he was involved, at least to some degree, in the planning of the enterprise, as well as being a party
to its execution. It follows from this, that, although not stated, the case against the respondent must include an
allegation that, at a minimum, he was aware of the presence of the migrants in the trailer, if not that he actually led
them there himself. Moreover, additional information indicates that those involved were being paid per migrant, and
so it is highly unlikely that a person involved carrying out these actions would not, in his own self-interest, be aware
of the number of people being transported.

130. So, therefore, for the purposes of the consideration of this issue, I am satisfied that it is reasonable for the
Court to draw the inference that the case being made against the respondent is that he knew there were migrants in


-----

the trailer, and that he knew the numbers involved. Another inference that I believe it is reasonable to draw is that it
is also alleged that the migrants were locked in a sealed container. In the course of submissions, counsel for the
applicant referred, on a number of occasions, to the trailer unit being sealed, and no issue was taken with this
assertion. In any case, I think this may reasonably be inferred, because the trailer was a refrigerated unit, and such
units are automatically sealed once the doors are closed, even if the refrigeration is not turned on. Furthermore, it is
reasonable to infer that it is alleged that the migrants were locked in to the trailer, or for whatever reason had no
way of escaping from it, because otherwise they would surely have done so. Bloody hand prints were observed on
the inside of the doors.

131. In the context of manslaughter by a criminal and dangerous act, the question that then arises is whether or not
the acts of the respondent i.e. those expressly stated in the EAW and in the additional information, as well as those
facts which I have inferred, are of a character that is sufficiently objectively dangerous so as to constitute the
offence of manslaughter in this jurisdiction? It seems to me that it is difficult to form any other conclusion. The acts
alleged are clearly unlawful, involving, as they do, assisting unlawful immigration. The migrants were in a container
which it may reasonably be inferred is alleged to have been locked and sealed. They were in that container, for a

period of unknown duration, before it was deposited in Zeebrugge. The ferry crossing was to last nine hours, and
they would remain in the container for a further unstated period after the crossing, pending their delivery to the preplanned destination.

132. On an objective basis, it is difficult to see how locking so many people in such a small (relative to the numbers
involved) sealed space for such a lengthy period could be regarded as other than highly dangerous. It seems very
likely that the migrants died of suffocation, but the fact is that on a journey such as this, anything could go wrong
and the misfortunate migrants would have no means of escape. The additional information provided included a
statement, at para. 3.20, that there were bloody handprints on the inside of the lorry door, suggesting that efforts
may have been made to prise the doors open from the inside. All of this being the case, I am satisfied that, while
much of the case to be made against the respondent is based on circumstantial evidence, nonetheless, if all of the
acts alleged, expressly or by inference, occurred in this jurisdiction, the respondent would be found to have
committed an unlawful and dangerous act sufficient to constitute the offence to manslaughter in this jurisdiction
Accordingly, I reject the objection that correspondence with the offence of manslaughter has not been established.

Section 21A Objection

133. Section 21A of the Act of 2003 requires the High Court to refuse to surrender a person, who has not been
convicted of an offence specified therein, if the Court is satisfied that a decision has not been made to charge the
person with, and try him or her for that offence in the issuing state.

134. However, s. 21A(2) provides that where a European Arrest Warrant is issued in respect of a person who has
not been convicted of an offence specified therein, it shall be presumed that a decision has been made to charge
the person and try him or her for that offence in the issuing state, unless the contrary is proved.

135. At para. (e) II of the EAW the following is stated by the issuing judicial authority:

_“I am satisfied that a Crown Prosecutor in the Crown Prosecution Service, whose function it is decide_
_whether or not to prosecute an individual for the alleged commission of criminal offences, has decided to charge the_
_person named herein and to try him for the offences specified above and for which this warrant is issued.”_

136. It is submitted on behalf of the respondent that that decision of the CPS must have been made at the time of
the issue of the EAW. In that part of the EAW dealing with the nature and legal classification of the offences, the
offence of manslaughter contrary to common law is identified. It is then stated that this offence is made out if it is
proved that the accused intentionally did an unlawful and dangerous act from which death inadvertently resulted. In
the additional information it is stated that, at present, the case against the respondent is put on an alternative basis:

(i.) The unlawful act of manslaughter, the unlawful act being the substantive offence(s) of assisting the unlawful
immigration of 39 Vietnamese deceased persons into the UK and/or arranging or facilitating the travel of the 39


-----

persons into and within the UK with a view to them being exploited before, during or after the journey; or in the
alternative

(ii.) Gross negligence manslaughter on or before 24th October, 2019, in that he owed a duty of care to the 39
deceased persons, and that he breached this duty by transporting them in a trailer to Zeebrugge Port in Belgium on
22nd October, 2019, and caused the 39 deceased persons to travel unaccompanied inside the trailer unit on the
MV Clementine on a ferry crossing journey lasting approximately nine hours from Zeebrugge to Purfleet Port, and
the breach caused the deaths of the deceased.

137. It is submitted on behalf of the respondent that the CPS still does not know the cause of death and nor has a
decision been made as to the charge to be brought against the respondent i.e. a manslaughter charge based on an
unlawful and dangerous act, or a

manslaughter charge based on gross negligence.

138. Without post-mortem results identifying the precise cause of death, it is not possible to assert a breach of any
alleged duty of care on the part of the respondent so as to establish gross negligence. Furthermore, the prosecutor
is not in a position to identify what the respondent did that was dangerous. It is not claimed that the respondent
placed the migrants in the trailer or that he knew of their presence, or that if he did, that he was aware of how many
people were present or of any consequent danger that might be caused by so many people being in the trailer for
nine or more hours.

139. For all of these reasons, it is submitted that it cannot be the case that a decision has been taken to put the
respondent on trial for manslaughter, since there is so much uncertainty about the basis on which the charge is
going to be alleged. It is further submitted that all of this is sufficient to displace the presumption contained in s.
21A(2) of the Act of 2003.

140. In response to this, it is argued on behalf of the applicant that, as a matter of general principle, in the context
of the Framework Decision, Member States are bound to accept the judicial decisions of the judicial authority of the
issuing Member State in issuing the arrest warrant, and must also afford trust and confidence in the information
provided by the issuing judicial authority and the issuing state. Accordingly, unless there is evidence of mala fides
this Court is entitled to rely on the representation of the issuing judicial authority that the surrender of the
respondent is required for the purpose of conducting a criminal prosecution in respect of the offences described in
the EAW including manslaughter offences.

141. It is submitted that it is well established by the authorities that the creation of the presumption in s. 21A(2) of
the Act of 2003 places a burden on the person objecting to surrender to rebut that presumption by adducing cogent
and concrete evidence that no decision to charge has been taken. The applicant refers to the decision of Minister
_[for Justice, Equality & Law Reform v. Ostrovskij [2006] IEHC 242.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XH73-RS61-S3V6-00000-00&context=1519360)_

142. In relation to the argument that it appears the CPS has not yet decided on the basis upon which to advance
the charge of manslaughter, it is submitted that it is not at all uncommon for a prosecutor to advance a
manslaughter charge on alternative bases, and that does not in any way undermine the decision to charge and try
for the offence. The applicant relies on the decision of Minister for Justice, Equality & Law Reform v. Olsson _[[2011]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:554N-SRP1-F0JW-R08N-00000-00&context=1519360)_
_[1 IR 384, wherein O'Donnell J. stated, at paras. 33 and 34:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:554N-SRP1-F0JW-R08N-00000-00&context=1519360)_

_“[33] When s. 21A speaks of 'a decision' it does not describe such decision as final or irrevocable, nor can_
_it be so interpreted in the light of the Framework Decision. The fact that a further decision might be made eventually_
_not to proceed, would not therefore mean that the statute had not been complied with, once the relevant intention to_
_do so existed at the time the warrant was issued. The Act of 2003 does not require any particular formality as to the_
_decision; in fact, s. 21 focuses on (and requires proof of) the absence of one. The issuing state does not have to_
_demonstrate a decision. A court is only to refuse to surrender a requested person when it is satisfied that no_
_decision has been made to charge or try that person. This would be so where there is no intention to try the_
_requested person on the charges at the time the warrant is issued. In such circumstances, the warrant could not be_
_for the purposes of conducting a criminal prosecution_


-----

_[34] The requirement of the relevant decision, intention or purpose can best be understood by identifying_
_what is intended to be insufficient for the issuance and execution of a European arrest warrant. A warrant issued for_
_the purposes of investigation of an offence alone, in circumstances where that investigation might or might not_
_result in a prosecution, would be insufficient…”_

143. The applicant also relies on the decision of Hunt J. in the case of Minister for Justice &

_[Equality v. Viplentas [2016] IEHC 46 where, after referring to the decision of the Supreme](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XR83-RSJG-B2WS-00000-00&context=1519360)_

Court in Olsson and also the decision of the Supreme Court in _Minister for Justice, Equality & Law Reform v._
_Michael McArdle_ _[[2005] 4 IR 260 he stated:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RHY-V0R0-TXX6-908C-00000-00&context=1519360)_

_“The presumption in favour of charge and trial is not displaced by the fact that procedures in the_
_requesting state contain an element of further investigation, or require the respondent to be present for the_
_purposes of those procedures.”_

144. It is further submitted that the fact that post-mortem results are not currently available is entirely irrelevant to
the question of whether or not there is a decision to try and it is simply not correct to suggest that a cause of death
is not asserted. Moreover, it is submitted that the Court should also take into account that two of the respondent's
alleged co-conspirators, Mr. Robinson and Mr. Kennedy have already been charged with offences arising at these
events. Mr. Robinson has already pleaded guilty to conspiracy to assist unlawful immigration and money
laundering, and manslaughter charges AGAINST him are pending.

Conclusion on Section 21A Objection

145. The first observation to make is that no evidence of any kind has been adduced to rebut the presumption set
forth in s. 21A(2). The Court has been invited to conclude that notwithstanding an express statement in the EAW
that a decision to charge and try the respondent for the offences in the EAW has been taken, the Court should
conclude, from the fact that the manslaughter charges may be advanced on an alternative basis, and

that post-mortem results were not available at the time of the issue of the EAW, that no decision could have been
taken. These facts are also relied upon to displace the statutory presumption in favour of the decision to charge
and try the respondent.

146. In my opinion, the arguments advanced on behalf of the respondent in this regard fall very far short of what is
required before a Court could either reject the express statement in the EAW or conclude that the statutory
presumption has been rebutted. I have no doubt at all that, at the date of the issue of the EAW, the CPS had the
intention to charge and try the respondent with the offence of manslaughter. It is open to the CPS to advance the
charge of an alternative basis if it chooses to do so. The fact that final postmortem results were not available to the
CPS at the time does not mean that the CPS did not have sufficient information available to it to make the decision
to charge and try the respondent. On the contrary it clearly did as demonstrated by the fact that one of his alleged
co-conspirators, Mr. Robinson, was on 25th November, 2019, facing manslaughter charges. This is apparent from
para. 3.40 of the additional information in which it is stated that:

_“On 25th November, 2019, Robinson appeared before the Central Criminal Court for a plea and trial_
_preparatory hearing. He pleaded guilty to conspiracy to assist unlawful immigration and one count of money_
_laundering. He requested more time from the Court to consider materials served in respect of the manslaughter_
_charges and another money laundering count before being arraigned on those counts.”_

147. In my opinion, for all of these reasons, the objection to surrender based on s. 21A(2) of the Act of 2003 must
also be dismissed.

Other Objections


-----

148. Other objections raised on behalf of the respondent as referred to in paras. 45 and 46 above were not argued
or pursued at hearing and do not require decision.

149. Having dismissed all of the objections of the respondent to this application, it follows that this Court will make
an order, pursuant to s. 16 for the surrender of the respondent to the United Kingdom in connection with the
charges set forth in the EAW.

**End of Document**


-----

# Minister for Justice and Equality v Harrison [2020] IECA 159

Irish Court of Appeal

Birmingham P, Edwards and Donnelly JJ

12 June 2020Judgment

**THE COURT OF APPEAL**

**[Neutral Citation Number [2020] IECA 159](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XVX3-RSRP-M34X-00000-00&context=1519360)**

**Record No.: 2020/61**

**Birmingham P.**

**Edwards J.**

**Donnelly J.**

BETWEEN/

**MINISTER FOR JUSTICE AND EQUALITY**

**RESPONDENT**

**-AND-**

**EAMONN HARRISON**

**APPELLANT JUDGMENT of Ms. Justice Donnelly delivered this 12th day of June, 2020**

1. The appellant's contention in this appeal is that the High Court, for the purpose of the execution of a European
Arrest Warrant (hereinafter, “EAW”), is not entitled to rely upon additional information provided by a prosecuting
authority rather than by the issuing judicial authority. The appellant's submissions were premised on the basis that
the additional information provided by the prosecuting authority was information required to be contained in the
EAW pursuant to the provisions of the Council Framework Decision of the 13th June, 2002 on the European Arrest
Warrant and the Surrender Procedures between Member States (hereinafter, “the Framework Decision”) and the
European Arrest Warrant Act, 2003 as amended (hereinafter, “the Act of 2003”).

2. In a judgment delivered on the 24th January, 2020, the High Court (Binchy J.) ordered the surrender of the
appellant to the United Kingdom in respect of the 41 separate offences. There were 39 offences of manslaughter,
an offence of conspiracy to facilitate illegal immigration and an offence of conspiracy to engage in human trafficking.
The EAW was issued in respect of the alleged participation by the appellant in the deaths of 39 people who were
found dead in the back of a trailer which had entered the United Kingdom of Great Britain and Northern Ireland
(hereinafter, “the UK”) from the port of Zeebrugge, Belgium.

[3. The facts of the case are fully set out in the judgment of Binchy J. found at [2020] IEHC 29 and it is unnecessary](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XWC3-RSRP-M3SH-00000-00&context=1519360)
to repeat them in detail here. Since that judgment, the UK authorities have indicated that they are not pursuing the


-----

offence of conspiracy to commit an offence of human trafficking contrary s. 2 of the UK Modern Slavery Act, 2015
and to the relevant conspiracy provisions. The issue of whether that offence was sufficiently delineated in the EAW
and the separate additional information together with related

issues of the requirement (or otherwise) to establish double criminality, had occupied a great deal of the time in the
High Court and in written submissions to this Court.

4. While it is no longer necessary to consider whether surrender on that particular offence should be ordered, the
fact that the EAW contained only “a ticked box” pursuant to Article 2(2) of the Framework Decision in respect of the
offence of human trafficking is relevant to the submissions made on this appeal. If Article 2(2) is invoked by an
issuing judicial authority, there is no requirement for double criminality (or correspondence) with an offence in the
executing State to be established. The UK Crown Prosecution Service (hereinafter, “the CPS”) had provided, via
the UK central authority, additional information requested by the High Court. In that additional information, the CPS
“confirm[ed]” “on behalf of the relevant issuing judicial authority” that all three types of offences were covered by the
“invocation of Article 2(2)” in the warrant. The respondent, as applicant in the High Court, did not seek to rely upon
Article 2(2) in respect of the manslaughter or illegal trafficking offences and instead proffered corresponding
offences. The High Court accepted that the acts alleged in respect of those offences corresponded with offences in
this jurisdiction.

The Content of the EAW and the Additional Information

5.  It is appropriate to repeat in full the description of the offence set out in the EAW at part (e): “The case against
Eamon (sic) Harrison relates to the trafficking and subsequent deaths of 39 people within an artic trailer unit GTR1
28D. At 01:38 on Wednesday 23 October 2019 Essex Police received a call from the East of England Ambulance
Service stating that they were getting reports of 25 illegal immigrants not breathing within a lorry in the area of
Eastern Avenue, Waterglade Industrial, West Thurrock, Essex. Police attended the scene. The driver of the lorry
was standing at the back of the trailer. He was later identified as Maurice Robinson. Inside the trailer was a total of
39 people, 8 females and 31 males who were all deceased. Enquiries revealed that the trailer unit GTR1 28D had
been delivered by a lorry BB221 3BP to Zeebrugge, Belgium before being transported to the UK where it was
collected by Maurice Robinson from the Port of Purfleet, Essex.

On 22 October 2019 Eamon (sic) Harrison has been identified as the driver of the lorry

BB221 3BP which was used to deliver the trailer unit, GTR1 28D to the port in Zeebrugge.

CCTV, taken several hours before at a truck shop in Veurne, Belgium shows Eamon (sic)

Harrison to be the driver of BB221 3BP. That lorry deposited the trailer unit, GTR1 28D at

Zeebrugge for its onward transmission to Purfleet, Essex. A shipping notice provided at

Zeebrugge when the tractor unit arrived at the gate was signed in the name 'Eamonn HARRISON.' Eamon (sic)
Harrison travelled back to Ireland in the lorry BB221 3BP via a ferry from Cherbourg, France.

Nature and legal classification of the offence(s) and the applicable statutory provision/code:

“1)  Manslaughter – contrary to common law

The offence is made out if it is proved that the accused intentionally did an unlawful and dangerous act from
which death inadvertently resulted.

2) Conspiracy to commit a human trafficking offence under section 2 of the Modern

Slavery Act 2015, contrary to section 1(1) of the Criminal Law Act 1971


-----

A person commits an offence if the person arranges or facilitates the travel of another with a view to them being
exploited;

3) Conspiracy to assist unlawful immigration under section 25 of the Immigration Act

1971, contrary to section 1(1) of the Criminal Law Act 1971

A person commits an offence if he does an act which facilitates the commission of a breach of immigration law by
an individual who is not a citizen of the European Union.

The offence of conspiracy is made out if a person agrees with any other person or persons that a course of
conduct shall be pursued which will necessarily amount to or involve the commission of any offence or offences.”

6. The additional information was requested by Binchy J. on the 21st November, 2019. It appears that the
necessity for this request was raised by the respondent (the applicant in the High Court). The respondent raised
the issue having received the points of objection, but it appears that this was not necessarily a concession that this
EAW was defective. The order of the High Court records that the letter was to be sent to the issuing judicial
authority requesting a direct reply from the issuing judicial authority, and the contents of the letter are in a schedule
to the High Court order. The request for information was transmitted by the central authority of this State to the UK
central authority. The request did not contain within it a specific request that the information should come from the
issuing judicial authority.

7. The UK central authority transmitted two separate documents. The first was a letter signed by a Ms. Iguyovwe
of the Crown Prosecution Service. She attached another document to that letter entitled “Response to Request for
Additional Information”. In the letter with respect to two matters, Ms. Iguyovwe stated that she was confirming those
matters on behalf of the issuing judicial authority.  One matter was that she confirmed that the issuing judicial
authority sought to invoke Article 2(2) in respect of all three types of offences and apologised that it was not
contained in the warrant. Another was some very slight further information specifying that the 39 deaths related to
the migrants who died in the articulated lorry and that the conspiracy charge was in respect of an agreement to
facilitate the unlawful entrant of migrants into the United Kingdom. Later in the response, there is far greater detail
on the circumstances leading to the deaths of those in the trailer, but it was stated that the investigation was
ongoing.

The Provisions of the European Arrest Warrant Act, 2003 (as amended)

8. Section 20(1) of the Act of 2003 provides:

“In proceedings to which this Act applies the High Court shall, if of the opinion that the documentation or
information provided to it is not sufficient to enable it to perform its functions under this Act, require the issuing
judicial authority or the issuing state, as may be appropriate, to provide it with such additional documentation or
information as it may specify, within such period as it may specify.”

9. The phrase “or the issuing state, as may be appropriate” was added after “issuing judicial authority” by virtue of
the provisions of Criminal Justice (Terrorist Offences) Act, 2005. The word “shall” after “High Court”, was
substituted for the word “may” by the Criminal Justice (International Co-operation) Act, 2019 with effect from the 4th
September, 2019, thus predating the issuance of this EAW. Subsection (2) of s.20 of the Act of 2003 made similar
provision for the central authority to seek additional information. This subsection was deleted by s. 4 of the Criminal
Justice (International Co-Operation) Act, 2019, also with effect from the 4th September, 2019.

10. Section 11 of the Act of 2003, in so far as relevant, provides:

“(1) A European arrest warrant shall, in so far as is practicable, be in the form set out in the Annex to the
Framework Decision […]

(1A) Subject to subsection (2A), a European arrest warrant shall specify –


-----

[…]

(b) the name of the judicial authority that issued the European arrest warrant, and the address of its principal
office, […]

(d) the offence to which the European arrest warrant relates, including the nature and classification under the law
of the issuing state of the offence concerned, […]

(f) the circumstances in which the offence was committed or is alleged to have been committed, including the
time and place of its commission or alleged commission, and the degree of involvement or alleged degree of
involvement of the person in the commission of the offence […]

(2) Where it is not practicable for the European arrest warrant to be in the form referred to in subsection (1), it
shall include such information, additional to the information specified in subsection (1A), as would be required to be
provided were it in that form.

(2A) If any of the information to which subsection (1A) […] refers is not specified in the European arrest warrant,
it may be specified in a separate document.”

The Provisions of the Framework Decision

11. Article 8 of the Framework Decision, in so far as relevant, provides:

“Content and form of the European arrest warrant

1. The European arrest warrant shall contain the following information set out in accordance with the form
contained in the Annex: […]

(d) the nature and legal classification of the offence, particularly in respect of Article 2;

(e) a description of the circumstances in which the offence was committed, including the time, place and degree of
participation in the offence by the requested person;”

12. Article 15 of the Framework Decision provides:

“Surrender decision

1. The executing judicial authority shall decide, within the time-limits and under the conditions defined in this
Framework Decision, whether the person is to be surrendered.

2. If the executing judicial authority finds the information communicated by the issuing Member State to be
insufficient to allow it to decide on surrender, it shall request that the necessary supplementary information, in
particular with respect to

Articles 3 to 5 and Article 8, be furnished as a matter of urgency […]

3. The issuing judicial authority may at any time forward any additional useful information to the executing judicial
authority.”

13. The definition of an EAW as set out in Article 1, reflecting Recital 5, as “a judicial decision issued by a Member
State with a view to the arrest and surrender by another Member State of a requested person…” has been
considered.

14. The principle of mutual recognition in Recitals 2 and 6 of the Framework Decision is also relevant together with
Recital 10 which provides that the mechanism of the EAW is based upon a high level of confidence between
Member States.


-----

The High Court Judgment

15. Having recited the arguments of the appellant and the respondent, the trial judge commenced at para. 68 to
address the issues relevant to this appeal. He did so by adopting the analysis of the issue by the High Court in the
case of _Minister for Justice & Equality v. A.W._ _[[2019] IEHC 251 (hereinafter, “A.W.”) and he distinguished the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XV63-RSRP-M234-00000-00&context=1519360)_
decision of the Supreme Court in Minister for Justice, Equality and Law Reform v. Sliczynski _[2008] IESC 73. The_
_A.W. decision will be discussed further in this judgment._

16. Binchy J. held that in accordance with the decision of the CJEU in M.L.

_(Generalstaatsanwaltschaft Bremen) [2018] C-220/18 PPU (hereinafter, “M.L.”) and the_

decision in A.W., it was necessary to have regard to all of the information provided by the competent authorities in
the issuing State. The trial judge said he was satisfied that the additional information was conveyed by the UK
central authority, but also that the senior specialist prosecutor in the CPS was providing the information on behalf of
the issuing judicial authority. At para. 69, Binchy J. stated as follows:

“In the context of this application, the starting point of that analysis must be that in providing the additional
_information, the senior prosecutor of the CPS has twice stated in her letter enclosing the additional information_
_(which letter also addresses specific queries) that she is writing 'on behalf of the relevant judicial authority'. While_
_this is stated in response to specific information furnished, and not in relation to the entire letter, it is clear that that_
_information at least is being provided on behalf of the issuing judicial authority. However, even though the letter_
_does not say so expressly, I think it is a reasonable inference to draw that the entire contents of the letter are being_
_provided on behalf of the relevant judicial authority.”_

17. Binchy J. went on to refer to the practice of the UK authorities to send additional information from specialist
agencies of the State rather than from the judiciary. He stated at para. 70: 
“As was made clear in the decision of Donnelly J. in AW, and as indeed counsel for the applicant in this case
_submitted to the Court, this is the practice of the United Kingdom. Once the EAW has been issued by an issuing_
_judicial authority, that authority is not usually involved in providing information in response to queries received from_
_the executing state. Neither the integrity nor competence of the CPS is impugned in any way. Accordingly, there is_
_no reason to doubt the authenticity of the information or the bona fides of the CPS. The Court is obliged to receive_
_and treat the information provided in accordance with the principle of mutual confidence referred to by Fennelly J. in_
_Stapleton, which in turn reflects Article 10 of the_

_Framework Decision.”_

18. Binchy J. noted that the information came from the CPS and neither its integrity nor competence was impugned
in any way. He held that accordingly there was no reason to doubt the authenticity of the information or the bona
_fides of the Crown Prosecution_

Service. In accordance with the principles set out in _Minister for Justice, Equality and Law Reform v. Stapleton_

[2008] 1 I.R. 669, he was obliged to treat the information in accordance with the principles of mutual confidence.

19. The trial judge also noted that the information in the EAW, albeit scant, had been issued by a judge and was
therefore subject to judicial scrutiny. There had been nothing inconsistent or contradictory in the additional
information with that contained in the EAW. There was nothing that altered the characteristic of what was alleged
against the appellant. There was nothing that gave him cause for concern that a judge might not have issued the
EAW. He was of the view that the information should be admitted.

20. Having admitted the information, Binchy J. held that there was no issue but that the information was sufficient
to establish correspondence and that the issue of extraterritoriality (s. 44 of the Act of 2003) could be resolved.
Indeed, in the present appeal, it seems that in light of the withdrawal of the request for surrender on the human
trafficking charge, and if the additional information is taken into account, the appellant takes no issue on the
sufficiency of the information provided correspondence of offences or the issue of extra territoriality On this basis


-----

the present appeal is focused on the admissibility of the additional information and a related issue of how necessary
this information was for the purpose of considering whether the conditions for surrender had been met.

**The Decision of the CJEU in M.L.**

21. The case of M.L. dealt with how the concerns of the executing judicial authority over prison conditions in the
issuing Member State could or should be satisfied prior to ordering surrender. The executing judicial authority in
Germany referred a number of questions to the CJEU about the extent of the enquiry it must make into those
conditions. One of the questions raised an issue of the consequences which flow from the provision of additional
information where the executing judicial authority is unable to ascertain if said information came from an authority
within the issuing State other than from the issuing judicial authority itself.

22. The CJEU found as follows:

“108. It should be recalled that Article 15(2) of the Framework Decision explicitly enables the executing judicial
_authority, if it finds the information communicated by the issuing Member State to be insufficient to allow it to decide_
_on surrender, to request that the necessary supplementary information be furnished as a matter of urgency. In_
_addition, under Article 15(3) of the Framework Decision, the issuing judicial authority may at any time forward any_
_additional useful information to the executing judicial authority._

109. Moreover, in accordance with the principle of sincere cooperation set out in the first subparagraph of Article
_4(3) TEU, the European Union and the Member States are, in full mutual respect, to assist each other in carrying_
_out tasks which flow from the Treaties (judgment of 6 September 2016, Petruhhin, C 182/15, EU:C:2016:630,_
_paragraph 42)._

110. _In accordance with those provisions, the executing judicial authority and the issuing judicial authority may,_
_respectively, request information or give assurances concerning the actual and precise conditions in which the_
_person concerned will be detained in the issuing Member State._

111. The assurance provided by the competent authorities of the issuing Member State that the person concerned,
_irrespective of the prison he is detained in in the issuing Member State, will not suffer inhuman or degrading_
_treatment on account of the actual and precise conditions of his detention is a factor which the executing_

_judicial authority cannot disregard. As the Advocate General has noted in point 64 of his Opinion, a failure_
_to give effect to such an assurance, in so far as it may bind the entity that has given it, may be relied on as against_
_that entity before the courts of the issuing Member State._

112. When that assurance has been given, or at least endorsed, by the issuing judicial authority, if need be after
_requesting the assistance of the central authority, or one of the central authorities, of the issuing Member State, as_
_referred to in Article 7 of the Framework Decision, the executing judicial authority, in view of the mutual trust which_
_must exist between the judicial authorities of the Member States and on which the European arrest warrant system_
_is based, must rely on that assurance, at least in the absence of any specific indications that the detention_
_conditions in a particular detention centre are in breach of Article 4 of the Charter._

_[…]_

_114. As the guarantee that such an assurance represents is not given by a judicial authority, it must be_
_evaluated by carrying out an overall assessment of all the information available to the executing judicial authority.”_

Ultimately, the CJEU answered the relevant question as follows:

“117. […] [T]he executing judicial authority may take into account information provided by authorities of the
_issuing Member State other than the issuing judicial authority, such as, in particular, an assurance that the_
_individual concerned will not be subject to inhuman or degrading treatment within the meaning of Article 4 of the_
_Charter.”_


-----

**The Decision in Minister for Justice and Equality v. A.W.**

23. In A.W., the applicant was sought for surrender by the United Kingdom. The applicant challenged the provision
of additional information by the CPS rather than the issuing judicial authority. The High Court (Donnelly J.), relying
on the decision in M.L., ruled that the information was admissible.

24. In analysing the issue, the High Court stated:

“73. Article 15 of the Framework Decision provides for the situation where an executing judicial authority may find
_that the information provided to it by the issuing member state is insufficient to allow it to decide on surrender. It_
_cannot be considered merely accidental that Article 15(2) and Article 15(3) use different language to describe the_
_manner in which additional useful information may be either requested by or forwarded to the executing judicial_
_authority. Article 15(2) permits the executing judicial authority to seek further information. It does not however_
_require that the additional information be furnished by the issuing judicial authority. Furthermore, Article 15(2)_
_refers to a situation where information communicated by the issuing member state is insufficient. Article 15(3) on_
_the_

_other hand allows the issuing judicial authority at any time to forward additional useful information._

74. In the view of this Court, the case of ML puts beyond doubt any question of whether information may only be
_received from an issuing judicial authority. At para. 108, having referred to Article 15(2) which permits an executing_
_judicial authority to request that the necessary supplementary information be furnished as a matter of urgency, the_
_CJEU went on to state:-_

_'In addition, under Article 15(3) of the Framework Decision, the issuing judicial authority may at any time_
_forward any additional useful information to the executing judicial authority.'_

_In the view of this Court, that is an indication that the sub paragraphs of Article 15 are to be considered_
_separately. That indication of the CJEU is further emphasised by the reference in para. 109 to the principle of_
_sincere cooperation set out in the first sub-paragraph of Article 4(3) Treaty on European Union ('TEU') in which it is_
_said that the ' European Union and the Member States are, in full mutual respect, to assist each other in carrying_
_out tasks which flow from the Treaties.'_

75. Paragraph 110 of the decision in ML refers to the executing judicial authority and the issuing judicial authority
_being permitted respectively to request information or give assurances concerning the actual and precise conditions_
_in which the person concerned will be detained in the issuing member state. Paragraph 112 refers to an assurance_
_that is being given or at least endorsed by the issuing judicial authority. In ML it was noted that the assurance was_
_given by the Hungarian Ministry of Justice. It was not endorsed or provided by the issuing judicial authority. At_
_para.114, the CJEU stated:-_

_'As the guarantee that such an assurance represents is not given by a judicial authority, it must be_
_evaluated by carrying out an overall assessment of all the information available to the executing judicial authority.'_

76. The other cases referred to by the respondent above, did not preclude information being obtained from other
_sources. Indeed, cases such as Aronyosi and Caldararu and Tupikas expressly considered that that might be the_
_position. In the case of Bob Dogi, the reference to the obtaining of the information from the judicial authority of the_
_issuing member state pursuant to Article 15(2) be read in the context of what was being argued in that particular_
_case._

77. Even if the request is made of the issuing judicial authority, the decision in ML clearly envisages the reply being
_provided by a competent authority of the member state. That reply must be assessed by the executing judicial_
_authority. The principle of judicial supervision is one which in accordance with recital 8 is one which is primarily to_
_be carried out by the executing judicial authority. The process is commenced by an EAW issued by a competent_
_judicial authority in the issuing_


-----

_state. Without such a judicial decision, there is no request for surrender within the meaning of the_
_Framework Decision or the Act of 2003. However, in the context of taking a decision on the execution of that judicial_
_decision in this member state, the High Court as executing judicial authority, must take into account all of the_
_information provided to it by the issuing state. The fact that information is not provided by the issuing judicial_
_authority, is a factor that the executing judicial authority must take into account when making a decision to_
_surrender in reliance on that information._

78. This Court must also have regard to s.20 of the Act of 2003. Section 20 provides express authority for both the
_Central Authority and the High Court to seek information from either the issuing judicial authority or the issuing_
_state. The purpose of this information can only be to assist in the carrying out of the functions under the Act of_
_2003. In light of the specific provisions of s.20, this Court must be entitled to rely upon the receipt of that_
_information in making its determination as otherwise the enabling provision would be otiose. The Oireachtas cannot_
_be considered to have legislated in vain. In those circumstances, the Act of 2003 must be interpreted as permitting_
_the High Court to rely upon the information obtained from a competent authority within the issuing state. That_
_provision would apply even if the Framework Decision did not permit the obtaining of such information. To hold_
_otherwise would be to act contra legem to the provisions of the Act of 2003. On the basis of the decision in ML and_
_the express provisions of Article 15 of the Framework Decision, it is however clear that the provisions in s.20 are_
_not in any way in opposition to the provisions of the Framework Decision. I am therefore satisfied that, the_
_information provided by the CPS in the UK is information to which I may have regard._

79. _The information provided by the CPS, is information that is provided by a competent authority of the United_
_Kingdom; the public prosecution service. It has not been suggested, by way of evidence or by way of submission,_
_that the CPS is an institution inherently unreliable or is specifically unreliable in the present case. At most what the_
_respondent submitted was that within the context of the UK legal system, they are an adversary to the respondent_
_in the present case. While the CPS may be the moving party in relation to the criminal proceedings in the UK, for_
_the present purposes, as a prosecution authority of a member state, they are informing this Court that the_
_respondent will be prosecuted in respect of certain matters.”_

25. Having dealt with facts specific to the A.W. case, the High Court stated:

“82. The EAW in the present case sets out twelve offences in respect of which the respondent's surrender is
_sought for prosecution. The information provided by the CPS provides further clarification in respect of each of_
_those offences certain matters. The provision of such information as the location of the conspiracies as being in_
_Liverpool, the nature of the firearms and ammunition, the identity of the co-conspirators and the role of this_
_respondent as a controlling mind, cannot be described as anything other than information which clarifies the details_
_of the offences alleged against him (where such information may be necessary). This has been provided by the_
_CPS, the public prosecution service in England and Wales, and therefore a prosecuting authority within the United_
_Kingdom. There is no reason whatsoever to doubt the authenticity of the information and the bona fides of the_
_public prosecution service._

_83. This Court must apply mutual trust and confidence to the information that has been received by the_
_public prosecution authority of another member state. In the absence of any real or substantive objection to the_
_bona fides of that response, it may provide the basis for the consideration of whether clarity in respect of the nature_
_and number of the offences has been obtained and whether there is in fact correspondence of offences.”_

The Submissions of the Parties on this Appeal

26. The appellant and respondent greatly assisted with the disposal of this appeal with cogent and clear written
and oral submissions.

27. In written submissions filed on behalf of the appellant, it was indicated that what was at issue in this appeal was
the correctness of the decision in A.W. and the applicability of it to the facts of the present case. In particular, the
appellant submitted:


-----

a) the High Court in A.W. misconstrued the reference to “the issuing State” which should have been interpreted in
light of the Framework Decision.

b) the High Court in _A.W. misconstrued Article 15 of the Framework Decision by failing to give it a harmonious_
interpretation. It cannot be inferred from the specific reference in Article 15(3) to the “issuing judicial authority” that
the reference to “the issuing State” in Article 15(2) implies that additional information which is required by Article 8
can be sent by any public body in the issuing State.

c) the High Court in _A.W. misconstrued the effect of_ _M.L. in two ways: first, the principle of mutual trust and_
recognition was not applied by the CJEU in that case to information which emanated from the executive branch of
the State; secondly, the decision does not extend to mandatory information which is required to be in the warrant
itself, as opposed to information which is extraneous to the warrant and related to prison conditions, a matter which
was peculiarly within the knowledge of the executive branch.

d) the High Court in _A.W. took into account the power of the Minister, as central authority, to seek information_
under s. 20(2), which was then contained in the Act of 2003. However, s. 20(2) has since been deleted and it is
submitted that this was done because it was realised that the central authority was clearly not the appropriate body
to seek additional information having regard to Articles 7 and 15(2) of the Framework Decision.

e) The facts in _A.W. were entirely different to the present case as the additional information did not constitute_
virtually all of the information which should have been included in the warrant in the first place and did not contradict
the substantial information contained in the warrant.

28. In the course of the oral submissions, counsel for the appellant clarified that she was not making the case that
“issuing State” in s. 20 could only mean the issuing judicial authority. Instead, she relied upon the requirement of
the High Court to seek additional information from “the issuing judicial authority or the issuing state, as may be
appropriate.” In her submission, the issue turns on whether it was “appropriate” for the CPS to reply on issues
which were fundamental, such as matters pertaining to Article 2(2) and other matters which ought to have been
contained in the EAW in compliance with

Article 8. Therefore, in her submission, for matters outside the core requirements of the EAW such as prison
conditions or system of trial, information could be received from the issuing State.

29. A fair synopsis of the appellant's main contention in this appeal is that information, which is specifically required
by Article 8 of the Framework Decision to be stated in the EAW, can only be provided by a judicial authority.
Counsel submitted that where this information was not provided, surrender should be refused. The grounds for
refusing to surrender went further than those grounds set out in Article 3 to 5 of the Framework

Decision and incorporated a requirement that the legality of the process must be satisfied.

She relied upon the decision of the CJEU in the case of Parchetul de pe lângă Curtea de Apel Cluj v. Niculaie Aurel
_Bob-Dogi (Case C-241/15) (hereinafter, “Bob Dogi”) to support her contention. In Bob Dogi, the Hungarian system_
permitted the domestic warrant to also constitute the EAW. The CJEU held:
“Article 8(1)(c) of the Council Framework Decision 2002/584/JHA of 13 June 2002 on the European arrest
_warrant and the surrender procedures between Member_

_States, as amended by Council Framework Decision 2009/299/JHA of 26 February 2009, is to be_
_interpreted as meaning that the term 'arrest warrant', as used in that provision, must be understood as referring to a_
_national arrest warrant that is distinct from the European arrest warrant._

_Article 8(1)(c) of Framework Decision 2002/584, as amended by Framework Decision 2009/299, is to be_
_interpreted as meaning that, where a European arrest warrant based on the existence of an 'arrest warrant' within_
_the meaning of that provision does not contain any reference to the existence of a national arrest warrant, the_
_executing judicial authority must refuse to give effect to it if, in the light of the information provided pursuant to_
_Article 15(2) of Framework Decision 2002/584 as amended and any other information available to it that authority_


-----

_concludes that the European arrest warrant is not valid because it was in fact issued in the absence of any national_
_warrant separate from the European arrest warrant.”_

30. Counsel also submitted that s. 20 had to be interpreted in light of the Supreme Court decision in _Rimsa v._
_Governor of Cloverhill Prison and Anor._ _[2010] IESC 47 which interpreted s. 16 of the Act of 2003 in line with the_
Framework Decision so as to restrict the meaning of the phrase “issuing State” to mean “issuing judicial authority”.

31. It was also submitted that the decision in M.L. was not authority for the proposition that a body other than the
issuing judicial authority may provide information required under the Framework Decision. Counsel referred to
para. 53 of the judgment and to para. 104 which refers to a dialogue between the issuing and executing judicial
authorities. The general position is that requests for information should come from the issuing judicial authority. In
_M.L., prison conditions were at issue and that, she submitted, was quite different from information required to be in_
the EAW from the outset.

32. Counsel submitted that there was also no consideration by the CJEU of the proposition that a prosecutor who
was neither an issuing judicial authority nor even a central authority may provide information that should have been
in the EAW. Counsel relied on the recent set of cases: P.F. (Case C-509/18); J.R; Y.C. (Joined Cases C-566/19
_and C626/19 PPU);_ _Openbaar Ministerie (Swedish Public Prosecutor's Office) (Case C-625/19 PPU); and_
_Openbaar Ministerie (Public Prosecutor, Brussels) (Case C-627/19 PPU) in which the designation of prosecutors as_
issuing judicial authorities was subject to a proportionality check. This was the essence of effective judicial
protection. Counsel submitted that this case was stronger as the CPS was not an issuing judicial authority under
UK law. Counsel submitted that it had no status therefore, under English law.

33. Since the oral hearing, this Court and the appellant were informed by the Chief State Solicitor that a question
has been referred to the CJEU by a Slovakian executing judicial authority in _M.B. and_ _Generálna prokuratúra_
_Slovenskej republiky (Case C-78/20). The question is as follows: “Must the requirements which a European Arrest_
_Warrant must satisfy as a judicial decision under Articles 1(1) and 6(1) of the Framework Decision_

_2002/584 be applied also to supplementary information provided pursuant to Article 15(2) thereof, where,_
_for the purposes of the decision of the executing judicial authority, it substantially supplements or changes the_
_content of the arrest warrant originally issued?” The appellant sought leave to address this Court as to the_
desirability of making a reference in the present case. Apart from submitting that the reference concerned the same
issue as raised in this case, the appellant submitted that as he was in custody, it would guarantee an expedited
hearing before the CJEU in contradistinction to the

Slovakian reference. I will address the issue of a reference later in this judgment.

34. Counsel relied upon the case law of the CJEU which, she submitted, highlighted the importance of the
fundamental rights provision in the Charter of Fundamental Rights of the European Union (hereinafter, “the EU
Charter”). In particular, counsel relied upon the right to liberty and security under Article 6 of the EU Charter and
the corresponding provision of Article 5(2) ECHR which provides for the right, on arrest, to “be informed promptly

[…] of the reasons for his arrest and of any charge against him.” It was submitted that the rights provided for in
Article 8 were not trivial but important matters

which allow the requested person to understand the basis for the EAW, the offences with which he is charged and
to permit him to challenge his surrender. In this latter respect, counsel relied upon the matters identified by the
High Court in Minister for Justice and Equality v. Cahill _[2012] IEHC 315._

35. The appellant took serious issue with the reliance on the phrase used by the CPS that the response was made
on behalf of the issuing judicial authority. Counsel for the appellant pointed to an absence of any indication that this
was in fact permitted under English law. In any event, if English law did allow “the CPS to conduct the role of the
issuing judicial authority” this should be stated in the EAW in accordance with the legal principles emanating from
the CJEU decision in Piotrowski (Case C-367/16). There was no statement of delegation to the CPS by the issuing
judicial authority. The appellant submitted however that the issuing State was not at liberty within the EAW system
to decide themselves who may be designated as an issuing judicial authority. The appellant also submitted that the


-----

principle of mutual trust and confidence does not apply to assertions which run contrary to the information in the
EAW, which did not identify the CPS as having any role at all.

36. In light of Article 8, which is in mandatory terms, the information required therein could only be given by the
issuing judicial authority. It was submitted that Article 15 was a mechanism for the issuing judicial authority to
supplement information in the European arrest warrant. It was submitted that Article 15(3), which referred to the
volunteering of information by the issuing judicial authority, made clear that the supplementary information in Article
15(2) should be sought from the issuing judicial authority.

37. In the appellant's submission, the above interpretation of Article 15 was required by the Framework Decision
(Recital 5 and Article 1(1)) as the EAW was a “judicial decision issued by a Member State with a view to the arrest
and surrender by another Member State of a

requested person.” By extension, s. 20 had to be given the same interpretation.

38. The appellant relied upon the Sliczynski in that regard, although counsel acknowledged that Sliczynski centred
around whether the additional information had to be provided on affidavit. The appellant submitted that there was
no Supreme Court or CJEU case which does anything other than state that the issuing judicial authority must
provide the information.

39. The appellant submitted that it was necessary to recall that mutual recognition and mutual trust and confidence
were two different things, relying on a number of cases such as Minister for Justice v. Stapleton [2008] 1 I.R. 669;
_Piotrowski; Minister for Justice and Equality (Deficiencies in the system of justice) (C-216/18 PPU); and P.F. For_
mutual recognition to operate there must be compliance with the Framework Decision, which requires judicial
production of the information required to be in the European arrest warrant.

40. Counsel submitted that the type of additional information that could be provided under Article 15 did not apply
to the mandatory information required to be in the EAW itself.

Counsel for the appellant submitted that if the additional information could be given by a person or body who was
not the “issuing judicial authority” and could amount to the provision of virtually all of the information required by
Article 8, the system of judicial cooperation established by the Framework Decision would be completely set at
nought.

This would undermine the clearly stated position of the CJEU as set out in P.F., para. 25:

“However, the principle of mutual recognition proceeds from the assumption that only European arrest warrants,
_within the meaning of Article 1(1) of Framework Decision 2002/584, must be executed in accordance with the_
_provisions of that decision. It follows from that article that such an arrest warrant is a 'judicial decision', which_
_requires that it be issued by a 'judicial authority' within the meaning of Article 6(1) of the framework decision.”_

41. The appellant submitted therefore, that the principle of mutual recognition does not extend to _ad hoc_
arrangements by which a body in the issuing State, without any information as to its legal authority to do so,
purports to fulfil the duties of the issuing judicial authority lawfully designated in that State. On the contrary, the
executing judicial authority should require compliance with the Framework Decision.

42. The respondent relied on the statement of the legal principles set out in A.W. and submitted that they applied
with equal force to these proceedings. The respondent took issue with each of the points made by the appellant as
to why the above principles were incorrect. Moreover, the respondent focused upon the information in the EAW and
pointed to the two judicial processes it had been subjected to prior to the arrest of the respondent in this jurisdiction.
The issuing judicial authority had issued the EAW and was thus satisfied that there was compliance with the
Framework Decision as set out in the law of the UK. As the EAW indicated, a domestic warrant had been issued
for the arrest of the appellant for the offences set out in the European arrest warrant. The EAW had also been
subjected to a process of endorsement by the High Court in this jurisdiction, prior to the arrest of the appellant.

Analysis and Determination


-----

43. In my view, the issues raised in this appeal require the Court to address three matters. The first is the nature
and extent of the information in the EAW and the endorsement process in the High Court. The second is the
correct interpretation of s. 20 and the third concerns the approach of the CJEU to the requirements of the
Framework Decision and in particular, its decision in _M.L. Naturally these matters will overlap but I consider it_
helpful to start with that general outline.

44. This Court, at the hearing of the appeal, raised the issue of whether there was sufficient information in the
original EAW for the purpose of resolving the issue of whether the provisions for surrender have been met.
Submissions were made by both parties on this point. The appellant submitted there was no sufficient information
for the reasons set out herein. The appellant also pointed to the manner in which the proceedings had progressed
in the High Court, in particular where the respondent had at the very least encouraged the High Court to seek
further information pursuant to s. 20 of the Act of

2003. The respondent submitted that there had be no formal concession that there was inadequate information but
accepted that certain areas for further enquiry had been raised by the respondent before the High Court. This was
in circumstances where the absence of certain information may have caused the High Court (or an appellate court)
to refuse surrender, where such risk could have been averted by seeking the information.

45. I am satisfied that regardless of how the further request for information arose in the High Court, this Court is
entitled to consider whether the information in the original EAW was sufficient for surrender. The issue of the
sufficiency of information and whether Article 8 and s. 11(1A) has been complied with formed a central aspect of the
appeal. The final determination of this Court is whether the order to surrender the appellant was validly made
based upon the sufficiency of the information. In those circumstances, it is of necessity that the Court would
examined the nature of the information in the original EAW as well as in the additional information. Ultimately, this
Court must decide whether the

High Court decision to surrender was validly made. It is also of particular note that the Court invited the parties to
address this aspect of the case.

**_Was sufficient information provided in the EAW?_**

46. The most relevant provisions of s.11(1A) have been set out above. The provisions of s. 11(1A) generally mirror
the requirement of Article 8 of the Framework Decision. Despite the contention of the appellant that “virtually the
entire of the information required to be in the European arrest warrant is contained in a letter from the CPS” this is
patently not the case. There was no dispute about the fact that the EAW had identified the appellant as the
requested person, that it identified the issuing judicial authority together with its contact details and the EAW stated
and identified that a domestic warrant was in existence for his arrest. Moreover, while the appellant submitted that
there was no compliance with sub-section (d), in that it did not state the offences to which the EAW relates or their
nature and classification, I am satisfied that this submission is untenable. The EAW clearly identifies the 41
offences (the only reasonable and indeed possible inference is that 39 of those were manslaughter offences in
relation to each of the 39 persons found dead inside the trailer), it identifies the statement of offence as per UK law
and it identifies the particular statutory code in relation to the trafficking offences (both the underlying substantive
offence and the provisions relating to the conspiracy offences). In respect of the manslaughter offences, the EAW
identifies that manslaughter is an offence contrary to common law. It furthermore identifies that this offence is
proved if the appellant intentionally did an unlawful and dangerous act from which death inadvertently resulted. The
EAW also identifies the maximum penalties in respect of each offence.

47. The appellant's case, therefore, was addressed primarily to the failure to comply with s. 11(1A)(e) of the Act of
2003 i.e. to a purported failure to provide details of the circumstances in which the offence was committed and in
particular, the degree of involvement of the person in the commission of the offence. This latter requirement
reflects the phrase “degree of participation” set out by Article 8 of the Framework

Decision. Degree of participation is the wording used in the form of the EAW annexed to the Framework Decision.


-----

48. Subsection 11(1A)(e) of the Act of 2003 has been the subject of repeated pronouncements by the Supreme
Court and High Court. It was quite correctly not questioned at this appeal that the subsection did not require a
statement of the evidence in relation to the offences. It was accepted, in accordance with the decision of the

Supreme Court in _Minister for Justice and Equality v. Stafford_ _[2009] IESC 83, that the EAW does not have to_
establish a strong case or even a prima facie case. In _Stafford, the case against the requested person was a_
circumstantial one and the Supreme Court accepted that nonetheless, the requirements under the Act of 2003 and
Framework Decision were satisfied.

49. In Minister for Justice v. Dolny _[2009] IESC 48, the Supreme Court stated:-_

“In addressing the issue of correspondence it is necessary to consider the particulars on the warrant, the acts, to
_decide if they would constitute an offence in the State. In considering the issue it is appropriate to read the warrant_
_as a whole.”_

Although this dicta relates to the issue of correspondence of offences, I am satisfied that it is also applicable to all
matters that require to be determined prior to surrender.

50. There is extensive case law on the purpose for which the information required in s.11(1A) must be given. In
_Cahill it was stated:-_

“The fact that there is a precise description of the facts of the case is important, even though the issue of double
_criminality is not required to be considered. It is important that there be a good description of the facts. An arrested_
_person is entitled to be informed of the reasons for his arrest and of any charge against him in plain language which_
_he can understand. Also, in view of the specialty rule, the facts upon which a warrant is based should be clearly_
_stated."_

51. The appellant took the view that this information includes information relevant to the issue of extra-territoriality.
That information is not specifically required under the provisions of the Framework Decision. I say this because the
issue of extra-territoriality is not a mandatory ground of refusal in the Framework Decision and the form of the EAW
set out in the annex specifically states at (f) “Other circumstances relevant to the case:

(optional information): NB This could cover remarks on extraterritoriality….”

52. This appeal raised the issue of whether there was insufficient information in relation to the degree of
participation. The appellant submitted that there was no indication of the unlawful and dangerous act that underlay
the offences of manslaughter. In my view, that is not a sustainable argument; the only possible inference from the
EAW as a whole in this regard, is that the unlawful and dangerous act is the facilitation of the breach of immigration
law by means of the use of the trailer to bring the unfortunate victims into

the UK unknown to immigration officials. It is noted that the appellant never contested that the High Court was
entitled to draw a reasonable inference from the information in the warrant.

53. It is worth noting at this point that as part of his complaint about the information from the CPS, the appellant
referred to the fact that the CPS gave a second basis for the proffering of the manslaughter charge i.e. it would be
prosecuted also as gross negligence. This intended basis has now been withdrawn in the more recent letter from
the Crown Prosecution Service. The relevance of this point can be quickly dispensed with. In the first place, the
present issue is about the information in the EAW and thus only the information found in the EAW need be taken
into account. Thus, the focus must be on whether the information in the EAW was sufficient to establish
correspondence and to provide the relevant degree of participation in that regard. Secondly, as the CJEU has
accepted, there is nothing unlawful or improper in an issuing State changing aspects of the charge against a person
who is surrendered provided the general charge remains the same. In Leymann and Pustovarov (Case C-388/08
_PPU), the CJEU was asked to consider the provisions of Article 27(2) of the Framework Decision relating to the rule_
of speciality. The CJEU held that:

-----

“it must be ascertained whether the constituent elements of the offence, according to the legal description given
_by the issuing State, are those in respect of which the person was surrendered and whether there is a sufficient_
_correspondence between the information given in the arrest warrant and that contained in the later procedural_
_document. Modifications concerning the time or place of the offence are allowed, in so far as they derive from_
_evidence gathered in the course of the proceedings conducted in the issuing State concerning the conduct_
_described in the arrest warrant, do not alter the nature of the offence and do not lead to grounds for non-execution_
_under Articles 3 and 4 of the Framework Decision.”_

54. In Leymann and Pustovarov, even though the individuals were convicted in respect of a different narcotic than
that recited in the details of the offence for which they were surrendered, there was no breach of the speciality
provisions of the Framework Decision. By analogy, I am quite satisfied that where there is information in the EAW
sufficient to establish correspondence, it is immaterial to the issue of whether the person should be surrendered on
that offence if the issuing judicial authority (or prosecution authority) indicate that there may be an additional legal
basis upon which the person can be prosecuted for the same offence.

55. I will return to the key issue of whether there is sufficient evidence in this particular warrant. Given the
information that was subsequently provided, it might have been preferable if some of that information had been
provided in the original warrant. Whether an ideal amount of information is contained in the EAW is not the test, it is
one of sufficiency. The experience of these courts when dealing with EAW's from across the other 27 Member
States has been that the amount of information provided varies enormously, not just from Member State to Member
State but from one judicial authority

to another in a Member State. Sometimes much more information than necessary is provided. This makes the
EAW more time consuming to read, particularly where there are pages and pages of extraneous information
provided in a translation that is less than flowing. Occasionally when the information provided is insufficient to
ensure that the requested person knows the reason why he is being sought and that the executing judicial authority
can make a decision as to whether the legal requirements have been met for surrender, the executing judicial
authority is required to seek further information.

56. I will now consider if there was sufficient information in the EAW to demonstrate correspondence (or double
criminality) in respect of each of the offences alleged against the appellant with an offence in this jurisdiction. In
relation to the conspiracy charge, the appellant submits that there is no statement of fact in respect to an agreement
which is the essence of a conspiracy charge. As set out above, the EAW stated that a conspiracy is committed if a
person agrees with one or more persons to a course of conduct that will necessarily amount to the commission of a
criminal offence. The EAW set out that a person commits the offence of assisting unlawful immigration where they
do an act which facilitates the breach of immigration law by an individual who is not a citizen of the European Union.
Although the EAW does not specifically address the fact that the persons in the trailer were not EU citizens, that is
the only reasonable inference one can draw from the charges proffered. Importantly, part (e) of the EAW opens
with the statement: “The case against Eamon (sic) Harrison relates to the trafficking and subsequent deaths of 39
people within an artic trailer unit GTR1 28D”. The EAW goes on to describe the appellant's role in delivering the
trailer to the port in Zeebrugge from where it was transported to the UK and collected by another lorry driver. In the
context of a description of acts in an EAW or any extradition document, the words must be given their ordinary
meaning (See Attorney General v. Dyer [2004] 1 I.R. 40).

57. In my view, taking the EAW as a whole and drawing reasonable inferences, it is clearly being alleged that the
appellant was in an agreement to commit an act which facilitated a breach of immigration law. His agreement was
to the facilitation of that breach by delivering the trailer to the port of Zeebrugge for onward transport to the UK, with
its tragic cargo of 39 would-be immigrants by unlawful means into that country. The trailer containing the 39 people
was to be collected by another. The manner in which this would be proved i.e. the evidence upon which he will be
tried if surrendered, is unnecessary to include in the European arrest warrant.

58. In relation to the manslaughter charges, as I have already stated, the unlawful and dangerous act is clearly the
act of facilitating a breach of immigration law by bringing the immigrants into the United Kingdom in the back of an
articulated trailer. No other inference is reasonable or even possible. His degree of participation was to deliver the


-----

trailer with the 39 people seeking to illegally enter the UK to the port of Zeebrugge from whence they would be
transported to the UK. Those circumstances are set out in the warrant. In my view, the portrayal of his role in the
EAW is sufficient to comply with the requirement of the Act of 2003 and the Framework Decision. By playing this
role he has personally facilitated an act of illegal immigration and the dangerous element was the fact

that the transportation was over a significant period in the rear of an artic trailer unit. That is sufficient to establish
manslaughter in this jurisdiction, there being a corresponding offence of illegal immigration and the act being
objectively dangerous.

59. In light of the above finding, there is no longer any necessity to go further with the issue raised on this appeal.
For that reason, the issue referred to the CJEU by the Slovakian judicial authority has no bearing on this Court's
decision which has the result of upholding the order of surrender made by the High Court in respect of this
appellant. Article 267 preliminary references are only to be made in respect of relevant questions where the
decision is necessary to give judgment. I have carefully considered the appellant's request for a further hearing. I
am satisfied however that the issue (or question) raised is not necessary for the purpose of giving judgment, it is
also unnecessary to accede to the request for a further hearing on whether this court should make a similar
reference. To hold such a hearing in these circumstances would serve no purpose and amount to a waste of
valuable judicial resources and unnecessarily increase legal costs.

60. I have considered however whether this Court should give its views on the issue raised by the appellant in
these proceedings as to the identity of the entity providing additional information. As the issue has been fully
ventilated before this Court and may be relevant for further consideration in the Supreme Court in the event of leave
to appeal being granted, I am of the view that it is appropriate to address the issue within this judgment. I will also
address whether a further hearing on the issue of this Court making its own reference would have been required.

**_Did the Act of 2003 and the Framework Decision require the additional information to be_**
**_furnished by the issuing judicial authority?_**

61. Prior to addressing the issue of the interpretation of s. 20 of the Act of 2003 and Article 15 of the Framework
Decision, it is instructive to consider the judicial processes that have been undertaken in respect of this particular
European arrest warrant. The appellant's primary contention is that mutual recognition is reserved for judicial
decisions. In the UK, there has been an initial judicial consideration in the domestic context resulting in the issue of
a warrant for his arrest. A separate consideration took place by a different judicial authority as to whether an EAW
should issue. On the basis of the facts set out in the EAW and in accordance with the principles of mutual
recognition of judicial decisions and mutual trust in those decisions, the executing judicial authority in this
jurisdiction was bound to accept that it was considered lawful and proportionate to issue the warrant. Thus, there
was a decision by a judicial authority that sufficient facts had been set out in the EAW to indicate the circumstances
of the offences and the degree of the appellant's involvement. It was then a matter for the executing judicial
authority in this jurisdiction to assess if that was in fact correct for the purpose of the execution of the EAW and the
order of surrender.

62. In this jurisdiction, an EAW cannot be executed by a member of An Garda Síochána until the High Court has
endorsed it for such execution under the provisions of s. 13 of the Act of 2003. The High Court may only endorse
the EAW where it is satisfied that there has been compliance with the Act of 2003. At the point when the EAW is
presented to the

High Court for execution, the High Court may refuse to endorse, may request further information or it may endorse.
It appears that in the present case, the possibility of further information being requested may have been raised at
that stage. It was only after the points of objection were served, that the request was made.

63. The endorsement stage is carried out ex parte. The decision that there is compliance with the Act of 2003 is
inherently a provisional one, subject to argument and reconsideration. It is a “vetting” process, where EAW's which
patently do not comply with the Act of 2003 are either refused endorsement, or further information is sought to
permit possible endorsement. As to why an EAW may be refused, an example may be where surrender is sought
for conduct which does not correspond to any offence in this jurisdiction Rather than permit a situation to arise


-----

where a person who could not possibly be surrendered on the EAW would be arrested, the EAW is refused at an
early point. In every case, the High Court will be alert to the possibility of whether there is correspondence of
offences, but the High Court may decide that if one offence corresponds, that is sufficient until further information
arrives. No such information was sought at the correspondence stage here. There is weight, albeit limited weight,
to be given to the fact that there was at least a provisional conclusion by the High Court that correspondence was
made out in respect of each offence in the warrant. That fortifies me in the view I held above, namely that the EAW
contained sufficient information to assess compliance with the Act of 2003.

64. The fact that there has been judicial consideration of the matters in the EAW by the issuing judicial authority is
relevant to the appellant's submission that all of the information required to be in the EAW must come from an
issuing judicial authority. It is now established by the CJEU that while an issuing judicial authority may be a public
prosecutor, there must be some type of judicial oversight of the process as well as a guarantee of independence of
the prosecutor. The CPS is not the issuing judicial authority and, in any event, the appellant submitted that there
was no oversight in respect of the information provided by the issuing judicial authority. Moreover, counsel
submitted that as the information is required by virtue of the provisions of s. 11 to be treated as part of the EAW, it
is clear that the Act of 2003 requires it to be provided by an issuing judicial authority as designated by the issuing
member state (and in compliance with the Framework Decision).

65. The appellant's argument set out in para. 34 above, that the information required must comply with the
provisions of Article 5(2) ECHR but did not do so, is not, to my mind, a convincing one. The EAW contained a clear
indication of the nature of the charges the appellant would be facing on surrender to the UK and also a great deal of
information about his role in it. In the context of an Irish charge sheet, an accused might simply be told that he was
being arrested and charged with for example, an offence of unlawful killing of a person, identified in some manner,
on a given date. Further information would be given prior to the trial for the purpose of a defence. Indeed, in the
present case there was no application for his release on the basis of inadequate information. On the contrary, the
issue was reserved to the question of whether he could be surrendered on this particular EAW.

Interpreting the provisions of s.20

66. It is trite law to say that s. 20 must be interpreted in light of the objectives of the Framework Decision. Fennelly
J. in Sliczynski observed that “it specifically gives effect to

_Article 15(2) and (3) of the Directive (sic).” The appellant submitted that the Supreme_

Court in Sliczynski and Minister for Justice, Equality and Law Reform v Rodnov (Unreported, ex tempore, Supreme
_Court, Murray C.J., 1st June 2006) referred to the information being provided by the issuing judicial authority. I am_
satisfied that as the precise issue at stake here was not argued in those cases and as they were decided prior to
the decision of the CJEU in _M.L., the_ _dicta from those cases concerning the issuing judicial authority does not_
amount to binding authority.

67. The Supreme Court in Rimsa held that the reference to “issuing state” in s. 16 concerning the rearrangement of
the time fixed for surrender had to be interpreted in accordance with Article 23(3) of the Framework Decision. That
Article referred to the time being rearranged by the issuing judicial authority and the executing judicial authority.
The decision in _Rimsa was a perfect example of an interpretation in accordance with the objectives of the_
Framework Decision and using the corresponding Article to interpret the Irish provisions.

68. What is instructive in Rimsa is that the Supreme Court could not read the provision in s. 16, which permitted the
Irish central authority to arrange the date, in a manner consistent with Article 23(3) so as to be understood as a
reference to the executing judicial authority. The Supreme Court held that to do otherwise would be to read the Act
of 2003 contra legem which of course, is not permitted.

69. By contrast with Article 16 of the Framework Decision, Article 15(2) does not restrict the information to that of
the issuing judicial authority. In the absence of that clarity, the appellant submits that a harmonious interpretation of
the Framework Decision requires Article 15(2) to be read as requiring the information to be provided by the issuing
judicial authority when the additional information relates to essentials which should have been in the European


-----

arrest warrant. The detail of that argument will be addressed further below. Suffice to say at this stage, that no
clear contraindication is given in Article 15(2) that would demand an interpretation of s. 20 that only the issuing
judicial authority may provide information as set out in Article 8.

70. Section 20 refers separately to the issuing State and to the issuing judicial authority. Indeed, the legislative
history demonstrates that the reference to the “issuing State” was added into the section by an amendment in 2005.
The section permits the request to be made to either the issuing judicial authority or the issuing State as
appropriate, to provide the High Court with the information. The appellant confirmed at the oral hearing that the
case was being presented on the basis that it was not appropriate that information that was required to be
contained in the EAW pursuant to Article 8 could be provided by the issuing State.

71. In my view, the analysis of the High Court in A.W. at para. 73 as to the different language between Article 15(2)
and (3) is correct. Ultimately, there is no requirement set out in

Article 15(2) that information be provided by or through the issuing judicial authority. Indeed, the Article expressly
refers to Article 8 but also to Articles 3-5, which are the grounds for mandatory and optional refusal to surrender and
to guarantees that must be given. Moreover, there is reference in Article 15(2), to the information being furnished
as a matter of urgency. That indeed may be part of the consideration of the “appropriate” body to send on the
information.

The M.L. Decision

72.  The M.L. case specifically dealt with the provision of information by the executive branch of the Member State
as distinct from the issuing judicial authority (or any judicial authority). The relevant portions of the judgment have
been set out above. The appellant also relied upon para. 104 to demonstrate that the process of obtaining
additional information is a dialogue between the issuing and executing Member States. In my view, the manner in
which the CJEU ruled in M.L. makes clear that information may be provided by the issuing State and is not required
to only be provided by the issuing judicial authority: “the executing judicial authority may take into account
_information provided by authorities of the issuing Member State other than the issuing judicial authority, such as, in_
_particular, an assurance that the individual concerned will not be subjected to inhuman or degrading treatment_
_within the meaning of Article 4 of the Charter.” Thus, the CJEU was satisfied that there was no general restriction_
on the provision of information by a non-judicial authority of the issuing Member State.

The Bob-Dogi Decision

73. The appellant also referred to the Bob-Dogi decision to demonstrate that a refusal to execute an EAW was not
confined to the grounds set out in Articles 3 and 4 of the Framework Decision but extended to the legality of the
EAW itself. The appellant referred to paras. 63, 64 and 65 of the judgment.  In the appellant's submissions, the
_Bob-Dogi case concerned the essentials to be found in the EAW and by extrapolation, the_ _M.L. decision did not_
affect the requirement for those to be given by the issuing judicial authority.

74. In my view, the Bob-Dogi case identifies that there are certain fundamental necessities for the execution of an
EAW. Indeed, the seminal decisions of Aranyosi (Case C-404/15) and then M.L. also indicate that where certain
fundamental rights will not be protected (freedom from inhuman and degrading treatment and right to a fair trial)
surrender must be refused. The grounds for refusal to execute an EAW in the Framework Decision made no
express reference to fundamental rights. In Bob-Dogi, at para. 63, the CJEU identified that the grounds for nonexecution were premised on the basis that the EAW will satisfy the requirements as to lawfulness of that warrant as
laid down by Article 8(1). The CJEU specifically referred to Article 8(1)(c) laying down a requirement of lawfulness
which must be observed if the EAW is to be valid. Failure to comply with it must in principle lead to a refusal to
surrender. The CJEU did go on to say that the issuing judicial authority must be given an opportunity to provide
information in accordance with Article 15(2) to establish whether there was such a domestic warrant. Even with that
information, the executing judicial authority may take into account other information in assessing whether to
surrender.


-----

75. In my view, the reference in _Bob-Dogi to Article 15(2) and to the issuing judicial authority being given the_
opportunity to provide information is not dispositive of the issue of whether information may be provided by an
organ of the issuing Member State other than the issuing judicial authority. Even in _Bob-Dogi, it was clearly_
acknowledged that other information could be put before the executing judicial authority. While that may have
referred to information placed by the requested person, it is an acknowledgement that the executing judicial
authority has an obligation to take on board all information before it when assessing legality. I also take the view as
found in para. 76 of _A.W., that the CJEU in_ _Bob-Dogi did not seek to lay down a general requirement as to all_
information in Article 8 being required to be obtained from the issuing judicial authority. The decision must be read
in the context of what was at issue in that case. By contrast, the issue of the provision of information by an
authority other than the issuing judicial authority was directly raised in M.L.. The CJEU accepted that it could be
received and assessed in the manner set out in the judgment as referred to above.

The imperative to surrender in accordance with the Framework Decision

76. What most of the decisions of the CJEU have in common is a strict injunction to executing judicial authorities
that the Framework Decision requires that requested persons be surrendered promptly in accordance with its
provisions. For example, in Aronyosi and Căldăraru (Case C-404/15) the CJEU stated at para 78 and 79:

“Both the principle of mutual trust between the Member States and the principle of mutual recognition are, in EU
_law, of fundamental importance given that they allow an area without internal borders to be created and maintained._
_More specifically, the principle of mutual trust requires, particularly with regard to the area of freedom, security and_
_justice, each of those States, save in exceptional circumstances, to consider all the other Member States to be_
_complying with EU law and particularly with the fundamental rights recognised by EU law (see, to that effect,_
_Opinion 2/13, EU:C:2014:2454, paragraph 191)._

_In the area governed by the Framework Decision, the principle of mutual recognition, which constitutes, as_
_is stated notably in recital (6) of that Framework Decision, the 'cornerstone' of judicial cooperation in criminal_
_matters, is given effect in Article 1(2) of the Framework Decision, pursuant to which Member States are in principle_
_obliged to give effect to a European arrest warrant (see, to that effect, judgment in Lanigan, C 237/15 PPU,_
_EU:C:2015:474, paragraph 36 and the caselaw cited).”_

77. Of course, the seminal nature of the Aranyosi decision was that the CJEU held that there could be limitations
on the principles of mutual recognition and mutual trust in exceptional circumstances such as those where
fundamental rights are at issue. The CJEU in _Minister for Justice and Equality (Deficiencies in the System of_
_Justice) held that refusal to execute is an exception which must be interpreted strictly._

78. In a more recent case than Bob Dogi, which concerned the execution of an additional sentence in the issuing
State which had not been mentioned in the EAW, the CJEU gave

its own interpretation of what was held in Bob-Dogi. In the case of I.K. (Case-551/18

_PPU), at para. 43 the CJEU stated: -_

“The Court has also held that those provisions are based on the premiss that the European arrest warrant
_concerned will satisfy the requirements as to the lawfulness laid down in Article 8(1) of the framework decision and_
_that failure to comply with one of those requirements as to lawfulness, which must be observed if the European_
_arrest warrant is to be valid, must, in principle, result in the executing judicial authority refusing to give effect to that_
_warrant (see, to that effect, judgment of 1 June 2016, Bob-Dogi, C 241/15, EU:C:2016:385, paragraphs 63 and 64)”._

79. In _M.L. the CJEU again stressed that a stringent assessment must be made as to whether there are_
exceptional circumstances that justify non-surrender. As part of that assessment, the executing judicial authority
may consider information supplied by another agency of the Member State. It must also be noted that the decision
in Aranyosi and M.L. both post-date the decision in Bob-Dogi. In my view, nothing in those cases nor in Bob-Dogi
itself, supports the appellant in his argument that only information contained in Article 8 can be supplied by the


-----

issuing judicial authority. The executing judicial authority is entitled to consider material provided to it by sources
other than the issuing judicial authority.

Mutual recognition and mutual trust

80. The appellant's point that mutual trust and mutual recognition are separate concepts is not contested. The
principle of mutual recognition is built on the concept of mutual trust. There is mutual trust between Member States.
Moreover, the entire system of extradition (and not just the surrender system of the Framework Decision) was
based upon a certain level of trust and confidence between the State parties to the extradition arrangements (for
example, see para. 10.3 of Attorney General v. O'Gara _[2012] IEHC 179). Thus, there is a residual trust between_
countries in any extradition arrangements though the extent of that trust may vary. Mutual trust within the EU is at a
very high level.

81. It is of course the position that the CJEU in M.L. specifically referred to mutual trust in the context of information
coming from the issuing judicial authority and stated that it must be relied upon. In the context of an assurance
coming from another source, the executing judicial authority had to carry out its assessment in light of all the
information presented to it. That is not a statement by the CJEU that mutual trust does not apply between Member
States. On the contrary, the difference in the approach between the judicial assurance and the assurance by a
State organ reflects the uniqueness of the mutual recognition system which operates at a high level of mutual trust
between judicial authorities. There is always a level of mutual trust between Member States, but an executing
judicial authority is bound to give information provided by a non-judicial authority greater scrutiny than information
provided by another judicial authority.

82. In the present case, the EAW contained virtually all of the information required (accepting for the present
purposes that some was missing) under Article 8(1) of the Framework

Decision. For the purpose of the present argument, it is considered that what may have been missing was further
information on the degree of participation in the alleged offences to the extent necessary for the executing judicial
authority to carry out its functions. As stated previously, an issuing judicial authority in the UK issued the EAW in
apparent lawful compliance with UK law. This was entirely unlike the situation in BobDogi where the EAW did not
contain specific information about a domestic warrant which was a clear requirement of Article 8(1)(c) of the
Framework Decision. Even then, the executing judicial authority was required to undertake a consideration of all
information in its possession prior to making a decision on execution.

The assessment made by the High Court on this EAW

83. The High Court had before it an EAW that was issued by an issuing judicial authority in the UK, which in turn
was based upon a domestic warrant issued for this appellant. At the point where objection was made to surrender,
the High Court sought further information from the issuing judicial authority. Information was provided through the
UK central authority by way of a letter and enclosed a response from a member of the CPS which is the public
prosecution authority in England and Wales. Contrary to what was claimed in submissions by the appellant, this
was not contradictory or inconsistent with the information in the European arrest warrant. Indeed, that was an
express finding of the High Court Judge and that finding was not appealed by the appellant. Moreover, the
appellant has not challenged the _bona fides of the prosecutor or the contents of the information, nor has the_
appellant put forward any other version of facts or law to contradict a single piece of the information (the appellant
has put forward information from news outlets as to the progress of cases against other persons). In short, there is
nothing to cast any doubt whatsoever on the accuracy of the information provided by the Crown Prosecution
Service.

84. The appellant has taken issue with the reliance by the trial judge on the principle of mutual confidence referred
to by Fennelly J. in _Stapleton which in turn reflects Article 10 of the Framework Decision, citing_ _M.L. and the_
different standard. There is an artificiality about this argument. The High Court was, in accordance with M.L. and
_Bob-Dogi, obliged to consider the information before it. In the absence of any challenge whatsoever to its_
authenticity or the bona fides of the CPS, there was simply no reason to reject it. Indeed, the reality is and was that


-----

the appellant's objection has been based on a process argument (albeit one made in the context of the protection of
fundamental rights) that only an issuing judicial authority could provide the information required by Article 8.

85. The objective behind the Framework Decision is to have a simplified system of surrender and the CJEU has
expressly permitted assurances/information (including in particular those relating to the absolute right such as
freedom from inhuman and degrading treatment) to be provided by an organ of the issuing State other than the
issuing judicial authority. In those circumstances, it is untenable that the executing judicial authority could be
prohibited from taking into account information provided by the prosecuting authorities which expanded upon the
circumstances of the offences as set out in the European Arrest Warrant. Indeed, it is precisely the type of
information that the

prosecuting authorities would have in its possession, rather than the issuing judicial authority.

86. The High Court was entitled to consider the information provided by the Crown

Prosecution Service. That additional evidence laid to rest any possible doubts there may have been that the full
details referred to in Article 8(1) of the Framework Decision had not been set out in the European arrest warrant.

Conclusion

87. In the course of this judgment, I have concluded that the original EAW, although somewhat terse, had
contained the information required for this Court to carry out its functions. In particular, the details in the EAW,
when read as a whole, gave sufficient indication of the acts for which the appellant was sought, to permit the Court
to conclude that correspondence between offences could be established. Although that was not the precise means
by which the High Court came to the conclusion that correspondence had been established, it is nonetheless
appropriate for this Court to do so.

88. I have also, for the sake of completeness, and should any application for leave to appeal to the Supreme Court
be made, considered the appellant's primary point as to whether the High Court was entitled to consider information
furnished to it by the prosecution rather than the issuing judicial authority. I have considered that both s. 20 of the
Act of 2003 and Article 15(2) of the Framework Decision permitted the High Court to do so. Having considered the
information, the High Court conducted an appropriate assessment of the information and correctly concluded that
all the conditions for surrender to the issuing State had been met.

89. In relation to the question referred by the Slovakian judicial authority to the CJEU, in light of my findings in
respect of the sufficiency of the information provided in the EAW, a reference is not necessary for the purpose of
giving judgment that the order of the High Court to surrender the appellant should be upheld.  Although I have
been clear in the course of this judgment that the High Court was entitled to consider this information and to
conduct the appropriate assessment of that information for the purpose of considering whether the conditions for
surrender had been met, but for the fact that this case was decided on the basis set out above, it would have been
appropriate for the Court to hold a

further hearing as to whether there should have been a referral.  I note that the appellant submits that it is
significant that the CJEU did not deal with this under Article 99 of the Rules of Procedure of the Courts of Justice
(as amended) by way of reasoned order. This permits the CJEU at any time to decide in that fashion where the
answer may be deduced from existing case law or where the answer admits of no reasonable doubt. The fact that
no such decision has been made up to this point may or may not be relevant to whether the issue can be said to be
clear. Certainly, the fact that this appellant is in custody on this matter alone (and thereby likely to be granted an
expedited hearing) is a reason to give serious consideration to making a reference rather than awaiting the decision
in the Slovakian case. I must repeat however that the necessity for a reference to the CJEU does not arise on the
basis of this judgment and therefore there is no need to arrange a further hearing to consider such a reference.

90. For all the foregoing reasons I would dismiss the appeal with the proviso that the Order of the Court should
reflect the fact that his surrender is no longer sought for the offence of conspiracy to commit human trafficking.


-----

91. The Order dismissing this appeal (with the above proviso) should not be perfected until 10 days have elapsed
since the delivery of this judgment by electronic means. Should the appellant desire a stay on the Order of
surrender for the purpose of seeking leave to appeal to the Supreme Court, then he should so notify the Court of
Appeal Registrar and the Chief State Solicitor of his intention to do so within 5 days of the date of electronic delivery
of this judgment. If required to sit, the Court can reconvene within the 10 day period.

92. As this was a case where the appellant had the benefit of the Legal Aid – Custody Issues Scheme in the High
Court, and as he remains in custody and in light of the issues in the case, it is proper in the circumstances to
recommend payment by the State of the costs of the appellant of this appeal including solicitor and two counsel in
accordance with the said scheme.

93. As this judgment is being delivered electronically, it is appropriate to record the agreement of the other
members of the Court.

**Birmingham P.: I agree with this judgment and the proposed orders.**

**Edwards J.: I agree with this judgment and the proposed orders.**

**End of Document**


-----

