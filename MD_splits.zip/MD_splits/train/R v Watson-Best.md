# R v Watson-Best [2023] EWCA Crim 693

Court of Appeal, Criminal Division

Macur LJ, Choudhury J, Constable J

7 June 2023Judgment

MS H RAWAT appeared on behalf of the Appellant Watson-Best.

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

MR JUSTICE CHOUDHURY:

1. The appellant was sentenced to 3 years' imprisonment for one count of robbery, and three sentences of
1 year, 6 months' and 1 year for possession of a bladed article, fraud, and a further count of possession of
a bladed article respectively to run concurrently. The applicant was also sentenced under a further
indictment to 5 years' imprisonment for blackmail, which is to run consecutively, thus making a total of 8
years' imprisonment. He appeals against the sentence for blackmail with leave of the single judge.

2. The background to these sentences may be stated as follows. On 23 February 2021, at around 11.30

in the evening, Ms Ilda Duka and her boyfriend were walking from a side street to a take‑away shop on

Walworth Road SE17, when they were approached by the appellant and another male, Malik Hutchinson.
The pair confronted the couple, grabbing the boyfriend and demanding his coat, which was worth £1,000.

The boyfriend refused. Hutchinson then produced a Rambo‑style knife and threatened to stab both

victims. The appellant also threatened to stab the victims, touching his waistband but no knife was seen.
The appellant then stole Ms Duka's mobile phone and bank card, and about an hour later both assailants
were captured on CCTV at an off-licence shop trying unsuccessfully to use the stolen bank card to make a
purchase.

3. On 24 February 2021, the day after the robbery, the appellant and Hutchinson were seen by uniformed
officers on the escalator at Stockwell Station. Both appeared to reverse direction when they saw the
officers, and so both were stopped and searched. Each was found in possession of a large, concealed
Rambo knife.

4. Between 26 July and 4 August 2021, when he was on police bail, the appellant sent a series of
threatening text messages to Ms Clayton a young woman with a child aged 2 at the time Ms Clayton's


-----

partner (nicknamed "GT") was at the time in prison on remand awaiting trial. The appellant was a

co‑suspect with GT in another police investigation. On the dates mentioned the appellant contacted Ms

Clayton and issued various demands for money. These demands were purportedly to satisfy a debt
apparently owed to the appellant by a mutual acquaintance of the appellant and GT known as "T Money".
The appellant regarded Ms Clayton as a soft target to satisfy the debt. She was vulnerable, in that she had
a young child, and her partner was not around to protect her.

5. Initial contact was made on 26 July 2021, when Ms Clayton received a message from a mobile
telephone number ending 362, introducing the sender as "Roots", which was the appellant's street name,
and stating that he needed to speak to GT. Ms Clayton was on the telephone to her partner at the time
and offered to convey any message. Roots said that this would be “too hot”. Ms Clayton finished the call
with her partner, having established that he did know Roots. Ms Clayton was then called by Roots, who
complained to her that he was owed £250 by T Money. It was apparent that the appellant knew that Ms
Clayton knew T Money to be an associate of her partner. Roots said that Ms Clayton needed to get T
Money to pay him the money or she would have to pay it herself. He then began to threaten her stating: "I
know where you live. I can get people to come to your house right now. I can get people to sort out you
and your kid". Ms Clayton was concerned for her child. She told Roots that she did not have any money
for him but would try to find T Money. After some time spent agonising over what to do, Ms Clayton called
the police and reported what had happened. A few days later Ms Clayton received a further text message
from Roots, late at night, complaining that: "This T Money yut ain't run me my bread" stating that she was
the connection to T Money and she was therefore involved. Ms Clayton tried to protest that she was
nothing to do with it and that T money was GT's friend, but Roots responded that as GT was not there, she
was GT. Ms Clayton again protested but Roots responded that she would either have to get T Money to
pay up or raise the money herself and that if she did not, "things are getting done tomorrow". Ms Clayton
again tried to placate the appellant, stating that she did not want to put her family in danger. He responded
with the words "this is bare missed deadlines".

6. During the text exchanges, Roots sent a video to Ms Clayton showing a male in a black balaclava

brandishing a sawn‑off shotgun. Ms Clayton was understandably terrified and offered to pay the money

out of her wages, which she would receive on 5 August. Roots reluctantly agreed to defer the debt until
that time. Ms Clayton also spoke to her partner's mother, who knew T Money, and got her to encourage
him to pay the money. She then texted Roots when she understood that he had done so. Roots replied
that only some of the money had been paid and that there was still a debt outstanding. The appellant was
arrested shortly thereafter.

7. On 16 November 2021, the appellant (by then aged 20) pleaded guilty to the robbery of the couple, the
bladed article offences and fraud. On 27 May 2022, following a trial at Inner London Crown Court, the
appellant (by then aged 21) was convicted of the blackmail offence against Ms Clayton. He was sentenced
for all offences on 4 November 2020 by Mr Recorder Wood KC (“the judge”).

8. In sentencing the appellant for blackmail, the judge noted that Ms Clayton did not owe any money to the
appellant and was entirely innocent. He noted that the appellant's threats had left Ms Clayton terrified and
worried about police coming to the house in case he was watching. She was worried about going out and
leaving the house and described standing at her window looking outside to see if any trouble was coming.
She even had to move from her home because of the threats following a police risk assessment.

9. Having noted mitigating factors, including the fact that the appellant was relatively lightly convicted, and
aggravating factors, including that the offence was committed whilst on police bail, the judge fixed upon a
sentence of 5 years' imprisonment for blackmail to run consecutively with the 3 years for the robbery.

10. Ms Rawat, in helpful submissions on the appellant's behalf, submits that the sentence of 5 years'
imprisonment for blackmail was manifestly excessive. This was, Ms Rawat submits, not a case involving a
threat to reveal private and intimate details of the victim, and so did not fall into the more serious category
of blackmail offences. Shorter sentences than the present one had been imposed by the Court of Appeal
in cases such R v Greer [2005] EWCA Crim 2185 and R v Connelly (1989) Cr App R(S) 541, for threating


-----

conduct involving more direct acts such as holding a knife to the victim's neck and inflicting actual injury. In
[R v Mincher [2016] EWCA Crim 1528, where a sentence of 5 years was imposed, the defendant had 184](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M06-JNV1-F0JY-C3W3-00000-00&context=1519360)
previous convictions including a previous conviction for blackmail and the offending had taken place over a
period of years. These features were not present, it is said, in the appellant's case. Ms Rawat also
contends that the judge failed to give sufficient weight to the appellant's mitigating factors including his age,
minimum previous convictions and a finding of conclusive grounds with regard to modern slavery.

11. The offence of blackmail can take many forms, ranging from threats to disclose compromising
information, to demands for the repayment of a debt with menaces. Whilst the former may sometimes be
considered more serious than the latter, the appropriate sentence in each case will depend on the facts.
The anguish suffered by a mother, who is the subject of threats to harm her and her child, may well be
comparable to (if not more serious than) the corrosive harm caused by a threat to disclose embarrassing
information. Similarly, a threat made via modern channels of communication such as social media,
especially when accompanied by a video of a masked man brandishing a weapon, may be just as terrifying

for the recipient as a threat made face‑to‑face.

12. We note that blackmail has no specific Guidelines to guide the sentencing court. Regard must
therefore be had to the Overarching Guidelines. These direct that reference should be had to relevant
decisions of the Court of Appeal. analogous offences, and, of course, the maximum for the offence in
question. The maximum for blackmail is 14 years' imprisonment. Analogous offences would be
intimidatory offences such as threats to kill. There are the Court of Appeal authorities to which reference
has been made and to which we have had regard. It appears to this Court that the culpability of the
appellant, on the facts of this case, was high. Threats of serious violence were made repeatedly over a
period of time to a young mother, including a threat to harm her child. We bear in mind, however, that the
degree of actual violence was minimal and, in this regard at least, the facts of this case can be
distinguished from those which are apparent in the cases of Greer and Connelly. However, the degree of
harm was, in our view, at least as serious as in those cases, given the impact on mother and child of the
threats made and the consequence of having to leave their family home.

13. Taking all of these matters into account, and of course the matters of mitigation to which the judge did
have regard, we have come to view that, notwithstanding the seriousness of the offence, and having
regard to totality, the overall sentence of 8 years' was manifestly excessive. We consider that, serious as
the offending was, an overall sentence of 6½ years would be appropriate and would be just and
proportionate in the circumstances.  Accordingly, the appeal in this case is allowed to this extent: the
sentence of 5 years for blackmail is quashed and replaced with one of 3 years and 6 months'
imprisonment. This will run consecutively to the sentence of 3 years' detention in a young offender's
institute for the other offences. The different types of custodial sentence are explained by the fact that the
appellant was aged 21 when convicted of the blackmail but only 20 when he pleaded guilty to other
offences. This is in accordance with sections 227 and 262 of the Sentencing Act 2020.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

