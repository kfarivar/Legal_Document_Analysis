# R v Rooney (Martin) and Others [2019] EWCA Crim 681

CA, CRIMINAL DIVISION

201702521

Holroyde LJ, Andrews J, HHJ Lucraft

Thursday, 4 April 2019

04/04/2019

1. LORD JUSTICE HOLROYDE: Martin Rooney (Senior), Bridget Rooney, Patrick Rooney, John Martin Rooney
and Martin Rooney (Junior) stood trial in the Crown Court at Nottingham on an indictment containing eight counts.
At the conclusion of the trial, on 5 May 2017, all five were convicted on count 1, which charged them with
conspiracy to require a person to perform forced or compulsory labour, which for convenience we shall refer to as
"FCL". Martin Rooney (Senior) was also convicted on count 2 of an offence of unlawful wounding. He was
subsequently sentenced to 8 years and 6 months' imprisonment on count 1, 2 years 3 months consecutive on count
2, a total of 10 years 9 months. Bridget Rooney was sentenced to 7 years' imprisonment on count 1. Patrick
Rooney was also convicted on count 4 of assault occasioning actual bodily harm and on counts 7 and 8 of two
offences of theft. He had in addition pleaded guilty to offences of cheating the public revenue and fraud by abuse
of position. He was sentenced to a total of 15 years 9 months' imprisonment, comprising 10 years 6 months on
count 1, 1 year 9 months consecutive on count 4, 1 year 3 months concurrent on count 7, 2 years consecutive on
count 8, 1 year concurrent for cheating the Revenue and 1 year 6 months consecutive for fraud.

2. John Martin Rooney was also convicted on counts 5 and 8 of theft. He had pleaded guilty to two offences of
fraud and had also been convicted of cheating the public revenue. He was sentenced to a total of 15 years and 6
months' imprisonment, comprising of 9 years 6 months on count 1, 18 months concurrent on count 5, 2 years
consecutive on count 8, 10 months concurrent for cheating the Revenue and 4 years and 3 years for the offences of
fraud, those sentences being concurrent the one with the other but consecutive to other sentences.

3. Martin Rooney (Junior) was also convicted on count 3 of assault occasioning actual bodily harm. He was
sentenced to 5 years 6 months' imprisonment on count 1 and 1 year 3 months consecutive on count 3, a total of 6
years and 9 months. Two other defendants, Gerry Rooney and Lawrence Rooney, had each pleaded guilty to a
substantive offence of requiring a person to perform FCL. They were each sentenced to 6 years' imprisonment.

4. All seven appellants appeal against their respective sentences by leave or limited leave of the single judge. The
five who were convicted after trial also renew their applications for leave to appeal against conviction following
refusal by the single judge.

5. The appellants are all members of the travelling community. At all material times they were based in the
Lincolnshire area, in particular at a travellers' site known as Drinsey Nook. Patrick Rooney and John Martin
Rooney, who are twin brothers, ran a business known as "Lincolnshire Driveways". It was the prosecution case
that the appellants were all involved in forcing or compelling a number of men to work in the business of
Lincolnshire Driveways and also in scrap metal dealing and house clearing for little or no pay and in unsafe
conditions.  The men were also required to maintain the Drinsey Nook site as directed by the appellants.


-----

6. It is alleged that they were provided with substandard accommodation, facilities and food. The appellants were
said to have manipulated and controlled these men by withholding pay, feeding their vulnerabilities and addictions
such as to alcohol or cannabis, holding them in debt bondage and defrauding some of their income from pensions
or benefits. At the heart of the prosecution case was the allegation that the complainants were being required to
perform FCL, which at the material time was an offence contrary to section 71 of the Coroners and Justice Act
2009. That provision has subsequently been repealed and replaced by section 1 of the Modern Slavery Act 2015.

7. Count 1 of the indictment charged a conspiracy between 6 April 2010 (when section 71 of the 1999 Act came
into force) and 30 April 2015. Ten complainants were named as the persons who had been required to perform
FCL.  The other counts in the indictment charged specific incidents of violence, theft and fraud.

8. The prosecution case was that for most of the indictment period the appellants were living in close proximity to
one another. There was evidence that workers were moved around between one defendant and another. It was
alleged that all the appellants were involved in requiring the complainants to perform FCL in order to fund the
comfortable life styles and high quality accommodation which the appellants enjoyed.

9. The prosecution relied on the testimony of nine witnesses who were either workers employed by the appellants
or witnesses to relevant events.  The prosecution adduced evidence to the effect that the workers were required to
work for long hours in poor conditions, but received little or no pay; that some were kept in a position of debt
bondage; that violence was used or threatened against them; and that they were accommodated in squalid living
conditions. The prosecution further alleged that the workers were restricted in gaining access to their own identity
documents and had little freedom of movement. The vulnerabilities of individual workers were exploited. There
was evidence as to the bad character of the defendants and as to the finding at Drinsey Nook of a large amount of
stolen property. Evidence was given about a particularly serious assault on a worker called King, who had declined
to make any statement about the incident and had died before the trial began.

10. The defence case, in general terms, was that none of the complainants had in fact been required to perform
FCL, from which it followed that there was no conspiracy to require them to do so.  The defence challenged the
prosecution evidence, relied on the bad character of the complainants as undermining their credibility and pointed
to the differing experiences and treatment of individual complainants in order to undermine the prosecution case of
there being a single conspiracy.

11. Only Patrick Rooney gave evidence in his own defence. He denied all of the allegations against him, saying
that he had not been in business with his twin brother, his father or any other family member. He said that over
time more than 100 men had worked for him but none of them had been forced to do so. He agreed that those he
had employed included a number of the complainants, including Crockett (the victim of the offence charged in count
4). He accepted that he had hit Crockett on an occasion when he had intervened in an argument. He denied
however that he had forced Crockett to work, said that Crockett was always paid and alleged that Crockett was a
heroin addict who was lying about his experiences. Patrick Rooney also denied that he had assaulted a worker
called Guy (the complainant in count 2), or asked him to do anything illegal. He denied ever having employed the
complainant Chapman (the victim of the offence alleged in count 3) and denied that he had assaulted him.

12. The other appellants, as we have said, did not give evidence.  The case for Martin Rooney (Senior) accepted
that he was the senior family member living at the Drinsey Nook site but denied that he was responsible for the
conduct of others. He denied being party to any coercion of any worker or any ill treatment.

13. Bridget Rooney's case was that she was not involved in the running of any business and had no knowledge of
the terms on which anyone had been employed. She denied any knowledge of the workers living on the site.

14. John Martin Rooney's case was that he was not involved in any conspiracy. He had been involved in the
running of Lincolnshire Driveways until June 2013, but his workers had always been properly paid and none had
been compelled to work. It was further his case that the workers were accommodated and fed properly.


-----

15. The case for Martin Rooney (Junior) was similarly a denial of involvement in the conspiracy and a denial that
any of the complainants had worked for him.  He accepted knowing that workers lived on the site and worked for
other members of the family but denied any knowledge of ill treatment or violence.

16. The trial was a lengthy one, lasting some 5 months. It is apparent from the many transcripts which this court
has read that it was a difficult trial for all concerned.  The judge had to make a number of rulings. These included
rulings admitting prosecution evidence that some of the workers were employed in the cultivation, collection and
delivery of cannabis, and evidence as to stolen property being found at the site. He gave a ruling rejecting a
submission of no case to answer at the conclusion of the prosecution evidence. Most importantly, for present
purposes, he made three rulings refusing applications to discharge the jury.

17. Before reviewing those unsuccessful applications to discharge the jury, it is relevant to note that a jury which
had first started to hear the trial had been discharged when it had emerged that one of their number had improperly
conducted research outside court and had told other jurors about his findings.

18. The first of the three applications to discharge the jury which are relevant to this appeal arose out of events in
February 2017. A juror reported to a member of the court staff that the juror had seen Patrick Rooney talking in the
street to an apparently homeless person. That oral report was relayed to the judge but was not put into writing.
The judge informed counsel that morning that there had been such a sighting but did not indicate that it had been
made by a juror. Later that day leading counsel for the prosecution enquired whether it had been a member of the
jury who had raised the matter. Leading counsel for Patrick Rooney made a similar enquiry.  The judge, at that
stage, declined to answer the question, taking the view that it was not a relevant matter.

19. On the following day other counsel joined in asking to be informed whether the observation had been made by
a member of the jury. They indicated that if it had been, that fact would affect the submissions as to what, if
anything, should be said by way of direction to the jury.  The judge again took the view that the identity of the
person who had made the observation was not material and again declined to answer the enquiry.

20. Further submissions were made over the following days and eventually the judge questioned the juror
concerned, in the presence of the defence but in the absence of other jurors. The juror indicated that he had made
the observation and passed the information on to a member of the court staff.  He had also told other jurors what
he had seen but had indicated to them that he did not regard it as a matter of any concern.

21. The judge also obtained and read to counsel a note in which the court official reported what had happened.
The judge gave a direction to the jury that they must try the case on the evidence.

22. Application was then made by all defence counsel to discharge the jury.  The judge refused that application.
He noted that it was common ground that Patrick Rooney was in the habit of speaking to people who were
homeless. The juror's observation therefore could only reflect in a positive way on Patrick Rooney's case.  The
judge indicated that when the matter had first been reported to him, the level of concern indicated had been so low
that he did not regard it as necessary to require any note to be made. Subsequent enquiries had borne out that
initial assessment as to the low level of concern. The judge was satisfied that the directions which he had given
had met any realistic concerns which had been expressed about the situation. That there was nothing close to a
circumstance requiring the discharge of the jury. He emphasised the strong interest in maintaining the progress of
the trial and the need to avoid further delays.

23. In mid‑March 2017, a number of jurors began to express concern as to whether one of their number (referred to

as "Juror 11") was concentrating fully upon the case. Juror 11 was brought into court and asked by the judge to
consider over the weekend whether it would be possible for her to continue to discharge her functions as a juror.
On the following Monday, Juror 11 indicated that she could. She had previously asked if the court could rise at 3.00
pm on the Tuesday of the following week. Because previous requests of a similar nature in the long course of the
trial had been made on medical grounds, the judge assumed that this request related to some kind of medical
appointment. However, other jurors then indicated in a note that they were concerned that Juror 11 in fact wished
to attend a football match that evening and had lied about her reason for asking the court to rise early.  The court


-----

did in any event conclude shortly after 3.00 pm that afternoon, but two ushers subsequently reported in writing that
as the jury were leaving there had been an angry argument between two of the jurors (Nos 3 and 7) at the end of
which Juror 7 was described as being "in a distraught state".

24. Subsequent enquiries revealed there had been a serious personality clash and, without opposition from
counsel, Juror 7 was discharged.  The judge declined to discharge the jury as a whole, concluding that there was
no ground for serious concern that the remaining 11 jurors would not be able to be true to their oaths or
affirmations.  The judge also refused a prosecution application to discharge Juror 3, who was reported to have
used foul abuse towards Juror 7.  The judge concluded that Juror 3 may have overstepped "the marks of good
taste and appropriate respect" but there was nothing to suggest he was incapable of being true to his oath or
affirmation.

25. Later, in March 2017, it became necessary for the judge to discharge another juror, this time on grounds of

ill‑health. Thus, the jury was reduced to 10 members.

26. The catalyst for the third application to discharge the jury was the broadcasting of a television documentary
about criminal proceedings against a different family of travellers, which it was feared would have a prejudicial
effect upon these appellants if it were viewed by any juror.  The judge gave the jury a specific direction not to watch
that programme. It subsequently appeared that a juror possibly had viewed the programme. At the same time,
complaints arose about rude and bullying behaviour between members of the jury. After discussions with counsel
the judge made enquiries of each juror in turn, in the presence of the defendants and counsel, as to the matters
which had been raised. One juror confirmed that he had seen part of the television programme but explained that
he had gone into a room in which his partner was watching the programme and had left when he realised what it
was. Each of the jurors was asked whether he or she felt able to express views freely in the jury room and felt that
all other jurors were able to speak freely.

27. On 28 March 2017, in the light of those enquires and the answers given, all counsel, including counsel for the
prosecution, applied to the judge to discharge the jury. Prosecuting counsel summarised the concern which had
been raised about the behaviour of individual jurors and the conflicting accounts which had been given in the
responses to the enquiries made of the jury. Prosecuting counsel submitted that there had been irrevocable
contamination of the jury from the television programme and that there was a real danger that a number of the
jurors had not revealed the truth about the extent of the viewing and the discussions which had taken place around
it. She submitted that events had shown that the jury had become dysfunctional and that the time had come to
grasp the nettle and to discharge the jury because no adverse verdict which might result could be said to be safe.
She added that there was a real danger that the jury had ceased to function collectively. Although the trial had, by
that stage, lasted some 4 months, she and all defence counsel applied for the jury to be discharged.

28. The judge, in his ruling, reflected on the position of a jury in a long trial, particularly when, as in this case,
arrangements had been made to accommodate them separately from other jurors in the building. He referred to the
personality differences within the jury and to the emergence of the fact that one juror had watched some or all of the
television documentary. In the light of the enquiries which he had made the judge was satisfied that the juror had
seen part of that programme in the circumstances which he had stated and that it was not "a blatant disregard of
the judicial direction". The judge observed that it was an unfortunate matter and it would have been better if it had
been reported at the time; but, in his judgment, it was far from fatal. As to that juror disseminating information, the
judge accepted that there would have been greater cause for concern if the juror had promptly embarked on a
course of telling other jurors about the programme. That however was not what the juror had done. He had kept
the matter to himself and had mentioned it to others after some time only because of repeated references by Patrick
Rooney, when giving evidence, to his perception that the police wanted to lock him away for a long time.

29. In those circumstances, whilst it was unfortunate that the juror had felt compelled to make some reference to
the television programme, the judge did not regard it as being an irreparable problem. There had been a difference
of perception amongst the other jurors as to whether they should report what they had been told. But the judge was
satisfied that the jury were not being irresponsible. His overall view was that they found themselves in something of


-----

a dilemma as to what should be done and that in those circumstances nothing had happened which could not be
remedied by judicial direction.

30. The judge acknowledged the concerns expressed by counsel but said that he had received the very clear
message from the jury that all of them felt capable of freely expressing their views and all felt capable of working
together as a properly functioning jury. The circumstances surrounding the viewing of part of the television
documentary did not alter his characterisation of difficulties amongst the jury as being due to personality clashes.
He rejected the suggestion that the jury was dysfunctional. He said that in his view:

"This jury is entirely functional. There is a clear commitment to work together, a clear ability to respect the views of
others whilst freely expressing their own views and a desire and a clear ability to follow directions."

31. The trial therefore proceeded and in due course the judge summed the case up. Detailed submissions had
been made to him about his proposed directions of law, in the light of which the judge had made some alterations to
his draft. In the event he provided the jury with a document which contained in effect a bullet point summary of
what he was to say in his oral directions.

32. In relation to count 1 the written summary began by quoting the terms of section 71(1)(b) of the Coroners and
Justice Act 2009:

"(1) A person commits an offence if—

(b) he/she requires another person to perform forced or compulsory labour... and the circumstances are such that
he/she knows or ought to know that the other person is being required to perform forced or compulsory labour."

33. In his oral directions the judge asked the jury, at this point, to insert a heading "Thoughts" before the next part
of his written summary. He said:

34.

"... the next bit is just thoughts. It is not so much law as a way to approach it, thinking for you."

The judge went on to say at page 19C of the transcript:

"Now, forced or compulsory labour ‑‑ and I will use that shorthand, FCL, from time to time, that is what I mean ‑‑ is

not defined in the statute, the Act of Parliament that created the offence so there is no easy form of words that you
can get from the Act of Parliament. That is probably deliberate because it recognises that there is a whole variety
of circumstances that were meant to be covered by this offence...

At, what seemed to me the extreme ends of the scale, I have spelt out what is it not. It is not simply being
underpaid. At the other end of the scale, it is not unlawful imprisonment, someone actually being imprisoned.

The next bit is a continuation of the thought, it is not the law, it is a way of looking at it, three component parts,
ladies and gentlemen. A means: and that is one or more of the threat or use of force or punishment, the threat of
implementation of some other sanctions. Coercion, deception, abuse of power or exploitation of ... vulnerability.
And, as a result of the means, an individual provides a service. In other words, the service is not provided, not
offered, voluntarily.

As to service... there are many examples of service in law but in this case we are concerned with labour."

35. The judge then asked the jury to insert some further words taken from the speech of one of the defence
counsel namely "cause and effect". The judge explained:

"It is the same sort of approach here, means leading to service is effectively the same way of expressing cause and
effect, the one must be related to the other. The effect must be the result of the cause."


-----

36. The judge then asked the jury to write on their copy of his written summary a heading "The law". He repeated
that there was no statutory definition of FCL but indicated that what he was about to say was "the best guidance I
can give you to what is forced or compulsory labour, so this is the law".

The judge's direction was in these terms:

"What is required... is some physical or mental constraint and some overriding of a person's will as a result of which
that person supplies labour. You can understand why I have set that out in bold for you.

If we read on, many of the barristers have used these words: 'Work extracted from any person under menace of
any penalty and for which that person has not offered himself voluntarily'. That expresses in different words the

same concept.  The words in italics which use menace of penalty to my mind are rather more old‑fashioned than

the words in bold. They actually stem from an international Convention of the 1930s, that is where those italicised
words come from, hence the language is perhaps not as modern as the more modern language that I have set out
in bold.  The concept is the same, the concept of forced or compulsory labour is the same and that is where you
must focus."

37. Later in his direction, and again by reference to what was in the written summary, the judge directed the jury to
consider all of the circumstances, including a number which he specifically listed. The list referred to levels of pay,
the judge at this point reiterating that if the only failing was to pay less than should have been paid, then the offence
had not been proved. The other matters listed were hours of work; consent; working conditions; contract of
employment/employment rights; food; living conditions; use or threat of violence; freedom of movement; access
to/availability of identity documents; benefit payments/how were they claimed; where did the money go; and

workers' vulnerabilities/help or exploitation. At a later stage of the summing‑up the judge returned to those

headings and expanded upon them. In relation to the topic of consent, he emphasised this was a very important
topic for the jury to consider and asked them to note that consent means:

"... genuine consent and you assess that. It requires an exercise of free will. And again, if you go back to my
directions on what forced or compulsory labour means in law, you will get help there."

38. The jury returned the guilty verdicts which we have indicated and the judge subsequently imposed the
sentences to which we have referred.

39. We turn to the grounds of appeal against conviction. We have been assisted by extensive written and oral
submissions on behalf of all appellants and the Crown. We have considered carefully the many points which have
been made. It is necessary for us to summarise those submissions and we mean no disrespect to counsel's
industry by doing so.

40. There are two principal grounds of appeal which are common to all or most of the five appellants and to which,
for convenience, we shall refer as grounds 1 and 2. These two grounds are differently expressed in the respective
submissions but we can take the submissions collectively.  The first ground challenges the decisions of the judge
not to discharge the jury on any of the three occasions to which we have referred, in particular the third occasion.
The second common ground of appeal in which all but Bridget Rooney join is that the judge's direction as to the law
relating to count 1 was wrong.

41. Those two grounds are opposed by the respondent, as indeed are other grounds of appeal advanced by
individual appellants, to which we will come shortly. Counsel for the respondent acknowledge their previous
submission in support of discharging the jury but submit, upon mature reflection, that the judge was correct to
refuse that and the preceding applications.

42. As to the first of the two principal submissions, counsel in their written and oral submissions have carefully
taken us through the relevant details of the three applications to discharge the jury. We can express our
conclusions comparatively briefly. As to the first of the three applications, it is apparent that the judge did not
initially view what had happened as a jury irregularity and therefore did not think that there was any reason to fear


-----

that the jury could or would be deflected from returning true verdicts. Nonetheless, we have no doubt that he
should have informed counsel of the matter which had been reported to him and should have considered, at the
outset, any submissions from counsel as to how best to proceed. We are bound to say that we do not understand
why the judge did not proceed in that way. Had that course been taken, it would, in our view, quickly have emerged
that the matter was of no significance. It is regrettable that it was not dealt with in that way. Ultimately however, the
appropriate enquiries were made, and we see no basis for thinking that these events rendered any verdict unsafe.
The judge was undoubtedly correct to proceed on the basis that the observation was consistent with the
defendant's case and therefore could not be prejudicial to the defence. Moreover, as was apparent to the judge,
the defendant was shrewd enough to take advantage of this incident when giving his evidence.

43. As to the second of the applications, the judge was faced with a difficult situation. It is apparent that the trial
was not only a long one but a wearing one for all participants. It is very regrettable that personality clashes had
arisen within the jury and equally regrettable that there was some clearly inappropriate behaviour on the part of one
or more of the jurors.  In such circumstances, the trial judge must, above all, be concerned with whether a fair trial
remains possible.  The judge's focus was correctly directed in that regard. He was rightly alive to the stresses
upon a jury in a long trial, increased, as they were, by the arrangements that had been made, for good reason, in
respect of their accommodation. He did what he could to alleviate the practical difficulties which arose. Appropriate
enquiries were again made and an appropriate decision was taken as to the discharge of one juror. It cannot, in our
view, be said that the judge was wrong to conclude that the remaining jurors could be true to their oaths and
affirmations and that the continuing trial would be fair.

44. When the third application was made, the judge clearly gave it very careful thought. It was a bold decision to
refuse to discharge the jury when all counsel before him supported the application. However, such a decision is

pre‑eminently one for the trial judge, who is in the best possible position to gauge the mood of the jury and to make

an objective assessment of whether a fair trial could continue.  The decision may sometimes be a difficult one and,
as in this case, a lonely one.  The judge's ruling on this third application was, in our view, an impressive and
accurate analysis. For the reasons he gave, he was, in our view, entitled to refuse the application to discharge.
The challenge to that decision accordingly fails. As subsequent events proved, the anxieties understandably felt by
all counsel were clearly overcome by the remaining jurors. There is nothing to indicate that they did not continue to
go about their duties conscientiously.

45. We turn to consider the second principal ground. Section 71(2) of the Coroners and Justice Act 2009 provides
that references to requiring a person to perform FCL are to be construed in accordance with Article 4 of the
Convention on Human Rights. Article 4.2 of that Convention states that no one shall be required to perform forced
or compulsory labour. In Van der Mussele v Belgium (1984) 6 EHRR 163, the European Court of Human Rights
defined FCL in terms which frequently have been adopted in subsequent cases "...the term forced or compulsory
labour means all work or service which is exacted from any person under the menace of any penalty and for which
the said the person has not offered himself voluntarily."

46. It is common ground between the parties that the word "labour" must be given a broad meaning and is not
confined to manual labour. The European Court of Human Rights has published a guide to Article 4 which notes
that reference to forced labour brings to mind the idea of physical or mental constraint whilst compulsory does not
extend to every form of legal compulsion or obligation. It is clear from the case law that the penalty which is
threatened may go as far as physical violence or restraint but it can also take subtler forms of a psychological
nature, such as threats to denounce to the authorities a worker whose employment status is illegal.  The
assessment of whether a service required to be performed falls within the definition of FCL must take into account
all the circumstances of the case in the light of the underlying objectives of Article 4.

47. In Siliadin v France (2005) 43 EHRR 287, a teenage girl who had arrived in France from Togo was required to
work for 15 hours each day without any rest days and without being paid. Her passport was confiscated by her
employer, and promises that she would be educated and her immigration status would be regularised were not
kept.  The court held that although she had not been under the menace of any penalty she had been in an
equivalent situation in the light of the seriousness of the threat she could have felt as a young person, unlawfully
present in a foreign country and afraid of being arrested In the circumstances including in particular the fact that


-----

she was a minor, it could be considered that her service had been extracted under menace of penalty. It was clear
that she had not performed the work of her own free will.

48. The appellants particularly invite the court's attention to two documents, which it is accepted are not binding
judicial authority but are nonetheless relevant and helpful: a global report published in 2009 by the International
Labour Organisation under the title "The cost of coercion"; and the guide published by the European Court of
Human Rights in relation to Article 4, to which we have just referred and which was most recently updated in
December 2018. These documents contain useful summaries of the jurisprudence.  The appellants put forward a
number of principles extracted from the case law and from relevant guidance. In particular, they submit that FCL is
not a subjective view of a worker having to remain owing to the lack of alternative employment opportunities
elsewhere.  The reference to a "penalty" therefore does not include situations of pure economic necessity, such as
the worker who feels he must remain in his job because of the actual or perceived lack of other employment
opportunities. Low wages or poor working conditions are not in themselves the same as FCL. The appellants
accept that the vulnerability of the alleged victim of FCL will be one of the circumstances relevant to the assessment
of a menace, and that the greater the vulnerability the more care has to be taken as to whether any consent is
genuine. They emphasise however that FCL is a serious violation of human rights. They criticise the judge's
directions as failing to convey to the jury that the essential question is whether a particular worker is able to
exercise his own free will and withdraw his labour if he wants to. They also submit that the judge's directions failed
adequately to convey to the jury the seriousness of the interference with individual autonomy which is involved in
FCL and the judge thus set the bar for conviction too low.

49. The applicants further criticise the judge's written and oral directions in a number of respects. First, they say
that the judge in his "thoughts" gave a checklist of what could amount to a menace of penalty and wrongly included
in that list deception, abuse of power or exploitation of vulnerability, which in themselves it is submitted could not
amount to a menace of penalty. Secondly, they say that a direction expressed in terms of a means and a service
was inappropriate and was based on a document published to provide guidance for Social Services or the
Probation Service. Thirdly, they criticise the judge's statement that if FCL is to be proved what is required is "some
physical or mental constraint and some overriding of a person's will as a result of which that person supplies
labour". The use of the word "some", submit counsel, dilutes the legal requirement. As we understand it, this is not
a complaint that the direction was inaccurate in relation to causation, it is a complaint that the word "some" qualifies
the words which follow and allows the jury to convict when the evidence proves nothing more than some minor
aspect of constraint.

50. In reply to those specific criticisms the respondent submits that the written and oral directions were correct in
law.  The "thoughts" were expressly designated as such and the jury were told that they were not directions of law.
The respondent emphasises that the purpose of the legislation is to protect the vulnerable. It should not therefore
be read in a restrictive way which defeats that purpose. As _Siliadin shows, the menace of penalty need not be_
direct and need not be issued by the same person as requires the victim to undertake FCL.

51. The respondent also points to what was said at paragraph 42 of the decision in this court in R v K(S) [2011] 2
Cr App R 34:

"42. Where 'forced or compulsory labour' is concerned, the menace of a penalty can be exerted in various ways. It
can be direct; it can also be indirect. Constraint can be mental or physical. It can be imposed by force of
circumstances. Where it is alleged that one person has been compulsorily employed by another, the level of pay he
or she has received, if any, may have evidential importance. It may point to coercion; it may bear on an employee's
ability to escape from his or her employer's control. On its own, however, a derisory level of wages is not
tantamount to coercion."

52. In the present case the respondent submits that the judge gave a very clear direction that low wages in
themselves could not prove the offence.

53. The respondent further submits that the Convention is a living instrument which must be read in the light of "the
notions concurrently prevailing in democratic states". Counsel rely on the recent decision in Chowdury v Greece


-----

[2017] ECtHR (application no. 21884/15), in which the relevant jurisprudence was reviewed by the European Court
of Human Rights. At paragraphs 95 and 96 of the judgment in that case the court said:

"95. The Court also observes that the applicants did not have a residence permit or a work permit. The applicants
were aware that their irregular situation put them at risk of being arrested and detained with a view to their removal
from Greece. An attempt to leave their work would no doubt have made this more likely and would have meant the
loss of any hope of receiving the wages due to them, even in part. Furthermore, the applicants, who had not
received any salary, could neither live elsewhere in Greece nor leave the country.

96. The Court further considers that where an employer abuses his power or takes advantage of the vulnerability of
his workers in order to exploit them, they do not offer themselves for work voluntarily. The prior consent of the victim
is not sufficient to exclude the characterisation of work as forced labour. The question whether an individual offers
himself for work voluntarily is a factual question which must be examined in the light of all the relevant
circumstances of a case."

54. We regard that as an important passage, because of the emphasis it places on the need for a jury to consider
all the circumstances of the case when deciding whether a worker who has been subject to FCL had offered himself
voluntarily for that work. In our judgment, a direction to a jury on a charge, contrary to section 71(1)(b) of the
Coroners and Justice Act 2009, must impress upon the jury the need for them to consider all the circumstances of
the case in deciding whether all the ingredients of the offences have been proved.  The provisions of the Modern
**_Slavery Act which, as we have indicated repealed and replaced section 71 of the 2009 Act and also increased the_**
maximum sentence for an offence of this nature from 14 years to life imprisonment, are explicit in this regard.
Subsections (3) to (5) provide:

"(3) In determining whether a person is being held in slavery or servitude or required to perform forced or
compulsory labour, regard may be had to all the circumstances.

(4) For example, regard may be had—

(a) to any of the person's personal circumstances (such as the person being a child, the person's family
relationships, and any mental or physical illness) which may make the person more vulnerable than other persons;

(b) to any work or services provided by the person, including work or services provided in circumstances which
constitute exploitation within section 3(3) to (6).

(5) The consent of a person (whether an adult or a child) to any of the acts alleged to constitute holding the person
in slavery or servitude, or requiring the person to perform forced or compulsory labour, does not preclude a
determination that the person is being held in slavery or servitude, or required to perform forced or compulsory
labour."

55. It is common ground between the parties, and we think it clear, that Parliament in enacting that provision did
not intend to change the law but rather to confirm that which had not previously been made explicit in the statute.

56. We have therefore considered carefully whether the judge's written and oral directions satisfied that
requirement. We have concluded that they did. They made clear to the jury the ingredients of the offence which
must be proved and that all the circumstances must be considered, with low pay being a relevant factor but not in
itself sufficient to amount to FCL. The list of relevant considerations which the judge identified was appropriate and
sufficient. We do not accept that the judge watered down the ingredients of the offence either in his directions or by
expressing his "thoughts" in terms which the jury may have wrongly assumed to be a direction of law. We agree
with the appellant's counsel that there will be circumstances of exploitation of workers which do not amount to this
offence: for example, where an employer merely pays very low wages or flouts health and safety requirements.
The judge's directions did however make clear that more than that must be proved.

57. We do not accept the submissions that the directions permitted the jury to convict on the basis of no more than
a finding that the workers undertook the work out of "pure economic necessity". We doubt if that is in any event a


-----

helpful phrase to use in the context of this offence, because, in our view, it begs the question: in order to decide
whether the ingredients of the offence were proved a jury would have to consider how and why the economic
necessity arose. Nor do we accept the submissions that the judge's directions permitted the jury to convict on the
basis of a "mere abuse of power" by the appellants or wrongly failed to direct the jury to consider whether a worker
could "take it or leave it". Both of those phrases, although superficially attractive, similarly beg the question. What is
required is an assessment of all the circumstances to see whether all the ingredients of the offence identified in Van
_der Mussele have been proved. In our judgment, the directions given by the judge sufficed to bring that essential_
instruction home to the jury.

58. With all respect to the judge, we do think that four criticisms of his directions can properly be made. First,
whilst we fully understand the practical difficulties of revising and reprinting written directions in the light of a late
amendment consequent upon something said in closing speeches, we think it unfortunate that the judge resorted to
asking the jury to make manuscript amendments to his written summary. By doing so, he ran the risk that the only
document which he had provided for the jury to be available during their deliberations as a reminder of his
directions would become less clear. Secondly, we think it was undesirable for the judge in his oral directions to
move as he did between directions of law and what he designated as "thoughts" though, as we have said, we are
satisfied he made the distinction clear. Thirdly, and in the light of the first two points, we think it would have been
preferable for the judge also to provide the jury with a route to verdicts document which would have spelled out the
questions they needed to ask themselves. We are however satisfied that those deficiencies, whether viewed
individually or collectively, did not undermine the oral and written directions which he correctly gave.

59. The fourth point we would make is that we accept that the inclusion of the word "some" in the passage we have
quoted was capable of introducing a degree of ambiguity, because the phrase might be read as meaning either
some form or some degree of physical or mental constraint. We do not however accept that this point carries the
force which counsel for the appellants ascribed to it. Read in the context of the directions as a whole, we think it
clear that the judge's meaning was that the prosecution must prove some form of physical or mental constraint.
The alternative reading would be wholly inconsistent with the following words "some overriding of a person's will".

60. We note moreover that in _Rantsev v Cyprus and Russia [2010] ECHR 22, at [276], the European Court of_
Human Rights used the same terms when it said:

"For 'forced or compulsory labour' to arise, the Court has held that there must be some physical or mental
constraint, as well as some overriding of the person's will."

61. For those reasons, notwithstanding some concerns about the manner and the terms in which the directions of
law were given, we conclude that they were sufficient and satisfactory in the circumstances of this case.  The
deficiencies we have noted do not undermine the safety of the convictions on count 1.

62. We next turn to the further grounds of appeal against conviction advanced by individual applicants. Patrick
Rooney puts forward seven further grounds of appeal. In summary, he contends that his convictions are unsafe

because the summing‑up was unfair, the judge should have allowed a submission of no case to answer, the judge

was wrong to admit evidence about the beating of King and about what counsel refers to as "extraneous
criminality", allegations relating to stolen property found at Drinsey Nook should not have been tried together with
the conspiracy and the judge behaved unfairly. John Martin Rooney also advances a ground of appeal which
challenges the admission of evidence of "extraneous criminality".

63. We can deal with these grounds of appeal shortly, because, in our view, the reasons why they cannot succeed
were comprehensively explained by the single judge in his reasons for refusing leave on the papers. In very brief

summary, there is no substance in the submission made only by Patrick Rooney that the summing‑up was unfair.

The evidence of the workers was plainly sufficient for there to be a case to answer, notwithstanding that there were

jury points to be made about inconsistencies in their evidence and concessions made in cross‑examination.  The

prosecution were entitled to adduce evidence of the beating of King, which they contended was a punishment
beating intended to enforce discipline and deter any disobedience by other workers. The jury were informed that


-----

before his death King had told the police that he had not been beaten and had not made a witness statement.  The
jury could consider that response in the light of the evidence of a worker who said he was an eyewitness to the
beating and could decide where the truth lay. The evidence of extraneous criminality related to matters such as
workers being named as tenants in housing benefit frauds, or workers being directed to drive without insurance or
to make off without paying for goods and services. As the single judge pointed out, such evidence was admissible
either on the basis that it had to do with the offence charged or as bad character evidence of a propensity to exploit
vulnerable workers. It also tended to rebut the defence that the workers had been treated humanely and with
respect. The evidence relating to stolen property at the site was also admissible to support the allegations made by
a number of the workers that they had been directed to steal items. Count 7, which related to theft of a large item of
stolen property found at the site and in respect of which there was evidence that a medically unfit worker had been
used, was properly joined in the indictment as an example of conduct relevant to count 1. An application to sever
count 8 had been raised at the trial but had then been abandoned and there was no merit in it. As to the criticisms
made of aspects of the judge's conduct, they amounted to isolated matters in the absence of the jury and provide
no arguable basis for challenging the convictions.

64. For those reasons, we conclude that the two collective grounds of appeal (grounds 1 and 2) raised arguable
points and we therefore grant leave in respect of them, but we dismiss the appeals against conviction. The
renewed applications for leave in respect of the remaining grounds of appeal advanced by Patrick Rooney and
John Martin Rooney raise no arguable point and those applications are refused.

65. We turn to the appeals against sentence. We consider first the challenge made in the renewed applications to
the level of sentencing which the judge felt appropriate in respect of count 1. We must begin by mentioning briefly
four previous decisions of this court.

66. In Attorney‑General's Reference Nos 2, 3, 4 and 5 of 2013 (R v William Connors and Ors) [2013] 2 Cr App R

(S) 71 members of an extended family of travellers, who had been convicted of offences including conspiracy to
require a person to perform forced labour and conspiracy to hold a person in servitude, were sentenced to terms of

up to six‑and‑a‑half years' imprisonment.  The case was referred to this court on the grounds that the sentencing

was unduly lenient.  The court, taking into account the advantage which the trial judge had of seeing and hearing
the victims, concluded that the sentences were lenient but not unduly so. However, at paragraph 10 the court
emphasised the seriousness of offences of this nature, saying:

"Exploitation of fellow human beings in any of the ways criminalised by the legislation represents deliberate
degrading of a fellow human being or human beings. It is far from straightforward for them even to complain about
the way they are being treated, let alone to report their plight to the authorities so that the offenders might be
brought to justice.  Therefore when they are, substantial sentences are required..."

67. In _R v Josie Connors & Ors [2013] EWCA 1165, the court was again concerned with offenders who had_
required workers to undertake FCL and had in some instances also committed offences of violence against

workers. The court there made clear that the decision on the recent Attorney‑General's Reference in the earlier

case of _Connors was not a guideline case: an important feature of it was the weight given to the assessment of_
criminality made by the trial judge in imposing sentences which were undoubtedly lenient. In the case of _Josie_
_Connors and Ors, the total sentences imposed range from 4 years to 11 years. None of those sentences was_
found to be even arguably manifestly excessive in length.

68. In _Joyce_ _[[2017] EWCA Crim 337 the offender pleaded guilty to offences including two of FCL. His appeal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NC1-RF61-F0JY-C1KN-00000-00&context=1519360)_
against a total sentence of 5 years 10 months' imprisonment was dismissed. At [26] the court pointed out that the
seriousness of the offence of FCL was shown by the recent increase in maximum penalty. At [27] the court
described three of the offences as relating to a campaign of bullying of a family whom the appellant had forced to
work for him over a period of years, subjecting them to threats and, on occasion, actual violence if they dared to
object to his demands. The appellant had made the lives of the principal victim and his family a misery.  The
impact had been severe.  The court indicated that a sentence of 6 years, before credit for plea, would not have
been excessive on the facts of those counts.


-----

69. In Attorney‑General's Reference (R v Zielinski) [2017] EWCA Crim 758, the offender was sentenced to a total

of 4 years' imprisonment, following his conviction of offences including conspiracy to require another to perform
FCL, contrary to section 1 of the **_Modern Slavery Act 2015. He and others had conspired, over a period of 9_**

months, to trick Polish nationals to travel to the UK on the promise of well‑paid work. Their victims had been put to

work in regular employment, but had most of their wages taken by the offenders and were forced to live in appalling
conditions. They were threatened and, on occasions, assaulted to force them to comply with the demands of the
conspirators. The court was satisfied that the sentences were unduly lenient and increased the total term to one of
7 years' imprisonment.

70. It is apparent from those decisions that offending of this nature, involving as it does a very serious interference
with the personal autonomy of the victim or victims, calls for severe punishment. As to the level of sentence, it is
clear that the first of the two Connors cases cannot be regarded as sitting a benchmark.  The sentences there were
lenient, but there were particular reasons why this court did not feel able to regard them as unduly lenient. The level
of sentence imposed in the other cases to which we have referred must be seen in the context of the facts of those
cases, including in particular the number of victims and the duration of the offending.

71. In the present case the features of the offending which made it necessary for the judge to impose lengthy
sentences included the duration of the conspiracy, the number of workers who were required to undertake FCL, the
physical conditions in which they were accommodated, the physical demands of the work which they were required
to undertake and the derisory level of pay which they were given.

72. We do not agree with the judge's view that the decision in Joyce marks a necessary upwards trend in every
case because each case depends on its own facts. It is the circumstances of the offending and the harm caused by
it which are important. What Joyce does illustrate is that the level of sentencing in the first Connors case must be
seen in the context of the particular circumstances of that case.

73. With these considerations in mind, we turn to consider the specific facts found by the judge in the present case.
In his sentencing remarks the judge described Drinsey Nook as the hub of wholesale exploitation of vulnerable men
made to perform forced labour. In addition to the conspiracy, Martin Rooney (Senior), Patrick Rooney and Martin
Rooney (Junior) had been convicted of offences of violence against workers and Patrick Rooney and John Martin
Rooney had been convicted of theft. The judge said that violence was a consistent theme and that the victims were
cowered into submission.

74. As to the conspiracy, the judge said that the appellants had preyed upon men who were vulnerable and easy to
manipulate by reason of their homelessness, alcoholism and mental health problems.  The appellants had
exploited their victims' natural desire to find useful employment, somewhere to regard as home and some place in
society. They were often picked off the streets and offered work promising money, shelter and food, but the
accommodation provided was, at best, basic and often squalid. With the odd exception there was no running water,
little heating and until much later there were no toilet facilities. Any electricity supply was routed illegally and
dangerously from a nearby pylon. Once on site the men would be put to work, which involved hard manual labour
laying block paving or tarmacking drives. They worked from dawn to dusk, six and sometimes seven days a week,
in all weather, usually without a break and only rarely were they provided with food or drink. No appropriate
clothing and no safety equipment was provided until much later, and only then as a paltry response once the police
had the appellants under close watch.

75. At other times the men would be required to work on the Drinsey Nook site undertaking building, maintenance,
gardening and tidying the family's mess. None were ever truly free to leave at all. Many of the tasks they were
compelled to perform involved breaking the law, stealing fuel for vehicles, driving illegally, stealing items which
could be used in building works and involvement in the cultivation of cannabis. Initially some workers were paid at
the rate promised but over time the amount paid dwindled, excuses were made and payment was late or not made
at all. Sometimes payment was not monetary but was in the form of cheap cider which promoted a dependence
upon alcohol and provided another means of control over the workers. Food was also used as a means of control.
Over time these workers had less and less to call their own and little, if any, money. They were living in miserable,


-----

squalid conditions, dependent upon alcohol and dependent upon the family for food. Many of the men were, or
would have been, entitled to State benefits. Those who did not claim benefits became more dependent. Those
who were registered for benefits had substantial funds siphoned off by the appellants.

76. In our judgment, that summary by the judge of some of the features of the count 1 offence, to which we would
add the duration of the conspiracy and the number of workers who were required to undertake FCL, makes plain
that count 1 charged grave offending. We would add that at the end of this 5-month trial, no one was in a better
position than the judge to assess the criminality involved.

77. There is, at present, no sentencing guideline in respect of offences of FCL.  The judge considered the
sentences imposed in the cases of Connors and Joyce. He regarded the latter, as we have said, as illustrating an
upward trend in the level of sentencing. The judge went on to consider the cases of the individual appellants and
made findings as to the nature and extent of their respective involvement. Those findings were challenged on
behalf of the appellants. Having considered the detailed response to those challenges, which has been provided by
the respondent, we are satisfied that the judge was entitled to make the findings he did as to the relative roles
played within the conspiracy by each of the family members and as to the nature of any other offending for which
individuals were responsible.

78. Martin Rooney (Senior) was convicted of the conspiracy (count 1) and of unlawful wounding (count 2). The
victim of the wounding was a worker named Guy, who has learning difficulties and suffers from ataxia. He was
struck on the forehead and suffered an open wound caused by a heavy ring which the appellant was wearing. He
received no treatment and is left with a permanent scar.

79. This appellant, now aged 59, had previous convictions for offences of dishonesty and violence, though the last
of those convictions have been in 2007. He was granted leave by the single judge to argue that the consecutive
sentence of 2 years 3 months' imprisonment imposed on count 2 was manifestly excessive because it involved an
element of double counting and because it failed to have sufficient regard to the principle of totality. He renews his
application for leave on the ground that the sentence on count 1 was in itself manifestly excessive in length.

80. Mr Harrison submits that there was no evidence that Martin Rooney (Senior) had initiated the abuse of
vulnerable workers; he was in declining health; and there was a distinction between his level of involvement and
that of others which should have been reflected in a lesser sentence. Mr Harrison submits that the sentence on
count 2 should have been concurrent and that the imposition of a significant consecutive sentence did involve some
double counting.

81. In our judgment, the judge was, as we have said, in the best position at the conclusion of this long trial to
assess the relative culpability of those who have been convicted of count 1. The sentence of 8 years 6 months on
that count was stiff, but the count represented grave offending. We reject the submission that the judge failed
adequately to distinguish this appellant from others in terms of role and level of involvement. We see no basis for
challenging the sentence on count 1.

82. We accept however, that the offence charged in count 2, whilst it added significantly to the appellant's
criminality and merited a consecutive sentence, should not have increased the total term by as much as it did. On
grounds of totality, we allow this appeal to the extent of quashing the sentence of 2 years 3 months on count 2 and
substituting a sentence of 15 months consecutive to the sentence on count 1. The total sentence is thus reduced
by 1 year to 9 years 9 months' imprisonment.

83. Bridget Rooney, now aged 57, has many previous convictions for offences of dishonesty but her only previous
custodial sentence was a short suspended sentence in 2007. She was given leave to appeal against her sentence
on count 1, on the grounds that the judge wrongly increased the sentencing level established by previous decisions,
took too high a starting point and failed to give sufficient weight to her role in the conspiracy, which is said to have
been secondary to others, or to her personal mitigation.

84. Ms Clark's submissions in support of those grounds were well presented but we are unable to accept them.
The judge was in the best position to assess this appellant's role and we are not persuaded that he made any error


-----

in doing so. He was, in our view, entitled to conclude that, had she wished to do so, this appellant could have
prevented at least some of what other members of her family did to the unfortunate workers. Her appeal against
sentence accordingly fails and is dismissed.

85. Patrick Rooney was convicted of the conspiracy (count 1), he was convicted on count 3 of assault occasioning
actual bodily harm. The victim was a worker called Crockett, a vulnerable man who was punched repeatedly in the
face. This appellant was also convicted of two offences of theft, of a camping pod worth £5,000 (count 7) and of a
large quantity of bricks valued at £14,700 (count 8). The latter offence was committed jointly with his twin brother
John Martin Rooney. In addition, this appellant had pleaded guilty to offences of cheating the Revenue and a fraud
in relation to the sale of the former home of one of the workers.

86. The appellant, now aged 33, has previous convictions for offences of dishonesty and driving offences. He was
given leave to appeal against the consecutive sentences imposed on counts 4 and 8, on the grounds of totality and
possible double counting, and against a consecutive sentence imposed on the separate indictment for offences of
fraud, again on the grounds of totality. He renews his application for leave to appeal against his sentence on count
1.

87. On his behalf Mr Bartfeld QC argues that the judge made some factual errors, perhaps as a result of the
passage of time between the relevant evidence being given and sentencing. He submits that the assault charged in
count 4 involved only punches which resulted in bruises, and that the imposition of a consecutive sentence for that
offence resulted in an excessive total. He also challenges the length of the sentence on count 1, relying on a
comparison with the sentencing in the case of William Connors & Ors.

88. We are not persuaded by the submissions relating to count 1. Whilst the judge was, in our view, wrong to say
that Joyce indicated a rising trend and whilst the sentence was a stiff one, it was, in our view, merited by the gravity
of the offending.  The judge was, in our view, entitled in principle to pass a consecutive sentence in respect of the
distinct unrelated criminal conduct. But in so doing we are persuaded that he reached an overall tariff that was too
high. To address this we allow the appeal of this appellant to the extent of quashing the consecutive sentence on
count 8 and substituting for it a concurrent sentence of 18 months' imprisonment.  The total sentence is thus
reduced by 2 years to 13 years 9 months.

89. In addition to being convicted of the conspiracy on count 1, John Martin Rooney was convicted of the theft of
bricks with his twin brother (count 8) and the theft of a cheque from an elderly man (count 5), the latter offence
involving a gross breach of trust.  The appellant was also convicted of cheating the Revenue and he had pleaded
guilty to two offences of fraud relating to the sales of properties.

90. This appellant, also of course now aged 33, was given leave to appeal against the sentences imposed on
counts 5 and 8, on grounds of totality and possible double counting, and against the consecutive sentence imposed
on a separate indictment for the offences of fraud, again on the grounds of totality. He too renews his application
for leave to appeal against his sentence on count 1, on grounds similar to those raised on behalf of his twin brother.

91. Once again, we see no merit in the challenge to the sentence on count 1 but greater force in submissions
made as to totality. We adopt the observations we have just made about the approach to consecutive sentences
taken by the judge in respect of Patrick Rooney but also our observations about the length of the overall sentence
which that approach produced. We accept the submission of Mr Cockings QC, that as regards the sentence
passed for the overall criminality, the judge made insufficient allowance for totality. We therefore allow this appeal
to the limited extent that we quash the consecutive sentence of 2 years imposed on count 8 and substitute for it a
concurrent sentence of 18 months. Thus the total sentence is reduced by 2 years to 13 years 6 months'
imprisonment.

92. Martin Rooney (Junior) was convicted of the conspiracy (count 1) and of assault occasioning actual bodily harm
(count 3). The victim of the count 3 offence was a worker called Chapman, who is diabetic.  The appellant
repeatedly punched him in the face until he fell down, at which point Chapman's phone was taken from him and he
feared that he would be furthered injured.


-----

93. This appellant, now aged 25, has three previous convictions including for an offence of handling stolen goods
for which he was sentenced to 3 years' imprisonment in 2015. He was given leave to appeal against the
consecutive sentence of 15 months on count 3, on grounds of totality and possible double counting. He renews his
application for leave to appeal against sentence on count 1, on the ground that the judge gave insufficient weight to
his limited role.

94. We are unable to accept Mr Di Francesco's submissions in support of these grounds of appeal. It must be
remembered, when assessing this appellant's role, that he was convicted on count 1 of an offence of conspiracy
and must therefore share to some extent in the overall criminality of the conspiracy. Seen in that context, the

submissions made by Mr Di Francesco, based on the acceptance by one worker in cross‑examination that he did

much less work for this appellant than the prosecution alleged and the judge found, even if correct (which in the
light of the response by prosecuting counsel is far from clear) do not affect the overall assessment made by the
judge of this appellant's role. The consecutive sentence for the offence of assault occasioning actual bodily harm
was not wrong in principle and, in this instance, we are not persuaded that the judge gave insufficient weight to
totality.  The renewed application is refused and this appeal against sentence is dismissed.

95. Gerry Rooney, now aged 47, has convictions for offences of dishonesty and driving offences. He pleaded
guilty to a substantive offence relating to a single worker. He has leave to appeal against his sentence on the
ground that the judge failed sufficiently to distinguish his offending from that of those who were convicted of the
conspiracy and failed to give sufficient weight to his personal mitigation.

96. We see some force in Mr Greenhalgh's submissions. The substantive offence of which this appellant was
convicted was undoubtedly serious, involving, as it did, the requirement for a vulnerable man to undertake FCL.
But the judge's notional sentence after trial of 8 years was, in our view, too long when compared with the sentences
on those convicted of the conspiracy. We also accept that for this appellant, who prior to sentence had been the
sole carer for his son, imprisonment will be particularly hard to bear because of concern for his son and that the
judge failed to give sufficient weight to this aspect of his personal mitigation. In our judgment, the appropriate
sentence after trial would have been around 5 years 6 months' imprisonment. We therefore allow this appeal to the
extent that we quash the sentence of 6 years' imprisonment and substitute a sentence of 4 years 3 months.

97. Lawrence Rooney, now aged 49, has many convictions for public order and driving offences. In 2016 he was
sentenced to 5 years' imprisonment for fraud. He has leave to appeal against his sentence, following his guilty plea
to a substantive offence relating to a single worker, on the grounds that the judge failed to give sufficient weight to
the fact that the appellant was not involved with other workers and failed to take account of totality given that this
sentence will run consecutively to the sentence already being served. As with Gerry Rooney, this appellant
pleaded guilty to a serious substantive offence, the victim in his case being particularly vulnerable because of a
serious leg injury. This appellant was not convicted of being a participant in the conspiracy. Bearing that in mind,
and having regard to the sentences imposed on those who were found guilty of count 1, we accept Mr Huston's
submission that the judge took too high a starting point.

98. Lawrence Rooney did not have the personal mitigation available to Gerry Rooney; but we accept that in his
case some further allowance should have been made to reflect totality in the light of the fact that he was already
serving a substantial sentence to which this sentence will be consecutive. In all the circumstances, we agree with
the judge's view that these last two appellants should be sentenced in the same way as each other. We therefore
allow Lawrence Rooney's appeal to the extent that we quash the sentence of 6 years' imprisonment and substitute
one of 4 years 3 months' imprisonment.

99. That concludes the judgment but to assist all concerned, including the appellants, we will just summarise the
effect of what we have just said:

1. Save for the applications in respect of grounds 1 and 2, all renewed applications for leave to appeal against
conviction are refused.


-----

2. The application by John Martin Rooney, for an extension of time to renew his application for leave on grounds 1
and 2, is granted.

3. All applications for leave to appeal against conviction on grounds 1 and 2 are granted.

4. The appeals against conviction are all dismissed.

5. All renewed applications for leave to appeal against sentence are refused.

6. The appeals against sentence of Bridget Rooney and Martin Rooney are dismissed.

7. The appeals against sentence of Martin Rooney (Senior), Patrick Rooney, John Martin Rooney, Gerry Rooney
and Lawrence Rooney are allowed to the following extents. Martin Rooney (Senior), the sentence on count 2 is
quashed, 15 months' imprisonment consecutive to the sentence on count 1 is substituted, making a total sentence
of 9 years 9 months; Patrick Rooney, the sentence on count 8 is quashed, 18 months' imprisonment concurrent
with the sentence on count 1 is substituted, making the total sentence one of 13 years 9 months; John Martin
Rooney, the sentence on count 8 is quashed, 18 months' imprisonment concurrent with the sentence on count 1 is
substituted, making a total sentence of 13 years 6 months; Gerry Rooney, the sentence imposed below is quashed
and a sentence of 4 years 3 months' imprisonment is substituted; Lawrence Rooney, the sentence imposed below
is quashed and a sentence of 4 years 3 months' imprisonment is substituted.

100. Mr Bartfeld and Mr Cockings, the effect of the orders we have made is that representation orders will be
granted to all relevant applicants in respect of the appeal against conviction on grounds 1 and 2. In the particular
circumstances of this case, we are taking the unusual course of specifically indicating that we are satisfied that the
representation in this complex case of Patrick Rooney and John Martin Rooney required the services of both
Queen's Counsel and junior counsel and so in your cases the respective representation orders will be extended
accordingly. Although we have put it in those terms, of course, other applicants benefited from the instruction of
leading counsel on behalf of two of their number.

(A short while later)

101. MR BARTFELD: I am grateful to Mr Young for noticing something that may not have been clear from the
Criminal Appeal Office summary.  The sentences imposed for counts 7 and count 8 on the trial indictment were
expressly consecutive to the sentence on count 1 but concurrent with one another. Your Lordships amended count
8's sentence to be 18 months concurrent with the count 1 sentence and then expressed what we assume was the
intention of that would create a reduction in the total sentence of 2 years. Because count 7 was consecutive to
count 1 concurrent, the effect of that would in fact only be to reduce the sentence by 6 months. In order to achieve

the stated aim‑‑

102. LORD JUSTICE HOLROYDE: ‑‑ I am with you. You mean the way it was pronounced meant that in relation

to each of 7 and 8, each individually was consecutive to the count 1 sentence, even though they were concurrent
with one another.

103. MR BARTFELD: Indeed. If the aim were to effect an overall reduction of 2 years the simplest route would be
to amend the sentence on count 7 to be concurrent with count 1 and that would achieve the aim of getting to 13
years and 9 months.

104. LORD JUSTICE HOLROYDE: Yes. Whoever spotted that ‑ well done. But you are quite right; our intention

for both the two appellants concerned was that the overall sentence would come down by 2 years. You are right Mr
Bartfeld that the way to achieve that is to say what we have said about count 8 but also now to say that the count 7
sentence will run concurrently with the count 1 sentence.

105. Mr Young, does any similar problem arise in relation to John Martin?

106 MR YOUNG: No in his case


-----

107. LORD JUSTICE HOLROYDE: I am just trying to do the arithmetic.

108. MR YOUNG: He was not on count 7.

109. HIS HONOUR JUDGE LUCRAFT: The problem appears to be on count 7.

110. LORD JUSTICE HOLROYDE: I think you are right.

111. Very good. It looks like that was the one thing that needed correcting and I hope we have now corrected to
everyone's dissatisfaction.

112. MR BARTFELD: My apologies for not noticing.

113. LORD JUSTICE HOLROYDE: No, I think that you can claim that you are not alone in not noticing it. Thank
you.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

114. Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

