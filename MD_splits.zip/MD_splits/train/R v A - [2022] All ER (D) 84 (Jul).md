# R v A [2022] EWCA Crim 988

Court of Appeal, Criminal Division

Dame Victoria Sharp P, Fraser and Hill JJ

19 July 2022Judgment

**Mr Alexander Wright (instructed by T V Edwards LLP) for the Appellant**

**Mr Louis Mably QC and Alisdair Smith (instructed by CPS) for the Respondent**

Hearing dates : 4 July 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

Section 1 of the Sexual Offences (Amendment) Act 1992 applies in this case. No matter relating to any
complainants shall be included in any publication during their lifetimes if it is likely to lead members of the public to
identify them as the persons against whom offences were committed. Reporting restrictions therefore apply in this
case.

**Dame Victoria Sharp, P.:**

_Introduction_

1. This application for permission to appeal has been referred to the Full Court by the Registrar. We granted
permission to appeal at the hearing, and proceeded to hear the appeal. Because reporting restrictions apply in this
case, and there is a familial relationship between the complainant and the appellant, we shall refer to them both
using those terms.

2. Between 21 and 25 February 2022, the appellant, who was then 21 years old, stood trial in the Crown Court at
Snaresbrook before HHJ Casey and a jury on five counts of sexual assault contrary to section 3 of the Sexual
Offences Act 2003 (the 2003 Act). On 25 February 2022, he was convicted on two counts, counts 4 and 5 and
acquitted of three counts, counts 1 to 3. On 29 April 2022, the appellant was sentenced by the trial judge to a total
of 10 months' imprisonment, suspended for two years. He became subject to the notification requirements under
Part 2 of the 2003 Act for a period of 10 years and a Restraining Order was made, forbidding contact with the
complainant.

3. The grounds of appeal are in summary first, that the prosecution's application made prior to the trial under
section 28 of the Youth Justice and Criminal Evidence Act (the 1999 Act) should not have been granted. This was
because the relevant legislation in force at the time did not permit the evidence of the complainant to be adduced by
way of pre-recorded evidence under section 28 in circumstances where though she was 16 when she gave her
ABE (achieving best evidence) interview, she was 18 by the time the application under section 28 was made.
Secondly, at the ground rules hearing which then took place, the judge inappropriately restricted the questions the
defence proposed to ask in cross examination. In the result, on either or both grounds, it is submitted that the
appellant's conviction is unsafe.


-----

_Facts_

4. The facts in brief are as follows.

5. The appellant was born in the United Kingdom but was taken by his parents to live in Saudi Arabia when he was
young. For the next few years, he and his parents lived there but the family returned to the United Kingdom every
summer to visit and stayed with family members. The appellant and the complainant are cousins (his mother, and
the complainant's mother, are sisters). The complainant lives with her mother in her grandmother's house. In 2011,
when the appellant was 10 years old, his family returned to the United Kingdom, but the pattern of family visiting
remained. This meant that the appellant and his brothers would often stay at the house where the complainant
lived, with the visitors sleeping on the sofa, or sometimes on the floor in her bedroom.

6. In December 2018, the appellant was 18 and the complainant was 16. The complainant's account was that
during the night of 29 December 2018, the appellant climbed into bed with her, and sexually assaulted her. There
were two sexual assaults on that occasion (counts 4 and 5). He entered her bedroom and she told him to get out, to
no avail. The first assault involved him fondling and sucking her breasts; she told him to stop but he did not do so.
He then moved his hands down into her pyjama shorts and touched her vagina. She called him a “filthy prick” at
which point he did stop, left her bedroom and slept elsewhere. She said that at no point did she consent to this
activity. The complainant's account was corroborated by her boyfriend who was on the telephone to her at the time;
he heard someone enter her bedroom and her telling someone to leave.

7. The complainant had previously exchanged Instagram messages with a friend in which she expressed concern
that the appellant was visiting and said he had “touched her up” before (the allegations relating to “touching up”
formed the basis of counts 1 to 3). The friend suggested the complainant should come and sleep at her house, but
the complainant feared this would worry her mother who had not been told of the earlier incidents. Her friend
advised the complainant to keep her boyfriend on the telephone and to put something heavy behind her bedroom
door to make it harder for the appellant to come into her bedroom.

8. On 30 December 2018, the complainant gave her account of what had happened to her friend, her boyfriend
and her mother. On 9 January 2019, the complainant and her mother attended a specialist facility for victims of
sexual assault where she was spoken to by specialist officers. On 30 January 2019, the complainant – who was still
16 - recorded her ABE interview. Thereafter, the appellant attended the police station on a voluntary basis and was
interviewed in the presence of his solicitor. His account was that the complainant consented to the touching of her
breasts. He denied he had touched her under her shorts.

9. The central issues for the jury to determine were, for count 1 whether any touching was sexual or just part of
play fighting, for counts 2 to 3 whether the incident happened at all, and for counts 4 and 5 whether the appellant
had touched the complainant's vagina as she had alleged and whether there was consent, or at least a reasonable
belief in consent, to the touching of the breasts. The principal evidence at trial came from complainant in the form of
pre-recorded evidence: her evidence in chief which consisted of her ABE interview and her cross examination, prerecorded under section 28 of the 1999 Act. The prosecution also called other evidence including from the
complainant's friend and her boyfriend. The appellant did not give evidence at trial but adduced evidence from his
mother regarding what the complainant had said after the incident.

_Relevant chronology_

10. The complainant was born on 20 July 2002. At the time of the alleged assaults (on 29 December 2018) and her
ABE interview, she was 16. By the time the appellant was charged (in September 2020) the complainant was 18.
The appellant's case was sent to the Crown Court on 21 December 2020.

11. On 7 January 2021, when the complainant was still 18, the prosecution applied for the complainant's evidence
in cross examination to be adduced by way of pre-recorded video evidence pursuant to section 28 of the 1999 Act.
The prosecution submitted that a witness qualified for this special measure if she was under 18 at the time of her
ABE interview. The application was opposed by the defence. The defence did not oppose the admission of the
complainant's ABE interview as her evidence in chief. It was submitted however that as she had reached the age of


-----

18 by the time of the section 28 application, the statutory provisions did not apply in her case, and she should be
cross-examined over a live link. On 4 February 2021, HHJ del Fabbro heard the section 28 application. On 11
February 2021, he gave a ruling in which he allowed the prosecution's application.

12. On 22 April 2021, the ground rules hearing was held before the same judge. HHJ del Fabbro had directed that
questions be served in advance of the ground rules hearing, and the defence served a list of 208 questions. The
prosecution objected to about 40 of those questions, and having heard argument, the judge directed that the
questions objected to should take the form proposed by the prosecution. On 29 April 2021, the complainant's cross
examination and re-examination took place and were video recorded.

_Statutory provisions_

13. There have been a number of statutory developments over a period of years which have been designed to
improve the quality of evidence in cases where witnesses are vulnerable, including by reason of their age.

14. The 1999 Act has been amended over time and the relevant sections of that Act as amended are now as
follows:

“Section 16 Witnesses eligible for assistance on grounds of age or incapacity.

(1) For the purposes of this Chapter a witness in criminal proceedings (other than the accused) is eligible for
assistance by virtue of this section—

(a) if under the age of 18 at the time of the hearing; or

(b) if the court considers that the quality of evidence given by the witness is likely to be diminished by reason of any
circumstances falling within subsection (2).

…

(3) In subsection (1)(a) “the time of the hearing”, in relation to a witness, means the time when it falls to the court to
make a determination for the purposes of section 19(2) in relation to the witness.”

15. Section 16(2) does not apply to this case.

16. Section 17 of the 1999 Act concerns witnesses in fear or distress about testifying, and complainants in sexual
offences and modern slavery offences. Section 17(4) of the 1999 Act provides as follows:

“(4) Where the complainant in respect of a sexual offence…… is a witness in proceedings relating to that offence
(or to that offence and any other offences), the witness is eligible for assistance in relation to those proceedings by
virtue of this subsection unless the witness has informed the court of the witness' wish not to be so eligible by virtue
of this subsection.”

17. Section 17(4) of the 1999 Act was not in force at Snaresbrook Crown Court at the time material to this appeal,
because that section of the 1999 Act was not specified in the relevant Commencement Order (see para 25 below).

18. Section 18 is headed “special measures available to eligible witnesses” and provides:

“(1) For the purposes of this Chapter—

(a) the provision which may be made by a special measures direction by virtue of each of sections 23 to 30 is a
special measure available in relation to a witness eligible for assistance by virtue of section 16; and

(b) the provision which may be made by such a direction by virtue of each of sections 23 to 28 is a special measure
available in relation to a witness eligible for assistance by virtue of section 17;

but this subsection has effect subject to subsection (2).


-----

(2) Where (apart from this subsection) a special measure would, in accordance with subsection (1)(a) or (b), be
available in relation to a witness in any proceedings, it shall not be taken by a court to be available in relation to the
witness unless—

(a) the court has been notified by the Secretary of State that relevant arrangements may be made available in the
area in which it appears to the court that the proceedings will take place, and

(b) the notice has not been withdrawn.

(3) In subsection (2) “relevant arrangements” means arrangements for implementing the measure in question which
cover the witness and the proceedings in question.

(4) The withdrawal of a notice under that subsection relating to a special measure shall not affect the availability of
that measure in relation to a witness if a special measures direction providing for that measure to apply to the
witness's evidence has been made by the court before the notice is withdrawn.

(5) The Secretary of State may by order make such amendments of this Chapter as he considers appropriate for
altering the special measures which, in accordance with subsection (1)(a) or (b), are available in relation to a
witness eligible for assistance by virtue of section 16 or (as the case may be) section 17, whether—

(a) by modifying the provisions relating to any measure for the time being available in relation to such a witness,

(b) by the addition—

(i) (with or without modifications) of any measure which is for the time being available in relation to a witness eligible
for assistance by virtue of the other of those sections, or

(ii) of any new measure, or

(c) by the removal of any measure.”

19. Section 19 deals with special measures generally:

“Special measures direction relating to eligible witness

(1) This section applies where in any criminal proceedings—

(a) a party to the proceedings makes an application for the court to give a direction under this section in relation to a
witness in the proceedings other than the accused, or

(b) the court of its own motion raises the issue whether such a direction should be given.

(2) Where the court determines that the witness is eligible for assistance by virtue of section 16 or 17, the court
must then—

(a) determine whether any of the special measures available in relation to the witness (or any combination of them)
would, in its opinion, be likely to improve the quality of evidence given by the witness; and

(b) if so—

(i) determine which of those measures (or combination of them) would, in its opinion, be likely to maximise so far as
practicable the quality of such evidence; and

(ii) give a direction under this section providing for the measure or measures so determined to apply to evidence
given by the witness.


-----

(3) In determining for the purposes of this Chapter whether any special measure or measures would or would not
be likely to improve, or to maximise so far as practicable, the quality of evidence given by the witness, the court
must consider all the circumstances of the case, including in particular—

(a) any views expressed by the witness; and

(b) whether the measure or measures might tend to inhibit such evidence being effectively tested by a party to the
proceedings.”

20. Section 21 of the 1999 Act provides as follows:

**“Section 21 Special provisions relating to child witnesses**

(1) For the purposes of this section—

(a) a witness in criminal proceedings is a “child witness” if he is an eligible witness by reason of section 16(1)(a)
(whether or not he is an eligible witness by reason of any other provision of section 16 or 17);

(b) [repealed in 2009] . . . and

(c) a “relevant recording”, in relation to a child witness, is a video recording of an interview of the witness made with
a view to its admission as evidence in chief of the witness.

(2) Where the court, in making a determination for the purposes of section 19(2), determines that a witness in
criminal proceedings is a child witness, the court must—

(a) first have regard to subsections (3) to (4C) below; and

(b) then have regard to section 19(2);

and for the purposes of section 19(2), as it then applies to the witness, any special measures required to be applied
in relation to him by virtue of this section shall be treated as if they were measures determined by the court,
pursuant to section 19(2)(a) and (b)(i), to be ones that (whether on their own or with any other special measures)
would be likely to maximise, so far as practicable, the quality of his evidence.

(3) The primary rule in the case of a child witness is that the court must give a special measures direction in relation
to the witness which complies with the following requirements—

(a) it must provide for any relevant recording to be admitted under section 27 (video recorded evidence in chief);
and

(b) it must provide for any evidence given by the witness in the proceedings which is not given by means of a video
recording (whether in chief or otherwise) to be given by means of a live link in accordance with section 24.”

(4) The primary rule is subject to the following limitations—

(a) the requirement contained in subsection (3)(a) or (b) has effect subject to the availability (within the meaning of
section 18(2)) of the special measure in question in relation to the witness;

(b) the requirement contained in subsection (3)(a) also has effect subject to section 27(2); ...

(ba) if the witness informs the court of the witness's wish that the rule should not apply or should apply only in part,
the rule does not apply to the extent that the court is satisfied that not complying with the rule would not diminish the
quality of the witness's evidence; and

(c) the rule does not apply to the extent that the court is satisfied that compliance with it would not be likely to
maximise the quality of the witness's evidence so far as practicable (whether because the application to that


-----

evidence of one or more other special measures available in relation to the witness would have that result or for any
other reason).

(4A) Where as a consequence of all or part of the primary rule being disapplied under subsection (4)(ba) a
witness's evidence or any part of it would fall to be given as testimony in court, the court must give a special
measures direction making such provision as is described in section 23 for the evidence or that part of it.

(4B) The requirement in subsection (4A) is subject to the following limitations—

(a) if the witness informs the court of the witness's wish that the requirement in subsection (4A) should not apply,
the requirement does not apply to the extent that the court is satisfied that not complying with it would not diminish
the quality of the witness's evidence; and

(b) the requirement does not apply to the extent that the court is satisfied that making such a provision would not be
likely to maximise the quality of the witness's evidence so far as practicable (whether because the application to
that evidence of one or more other special measures available in relation to the witness would have that result or for
any other reason).

(4C) In making a decision under subsection (4)(ba) or (4B)(a), the court must take into account the following factors
(and any others it considers relevant)—

(a) the age and maturity of the witness;

(b) the ability of the witness to understand the consequences of giving evidence otherwise than in accordance with
the requirements in subsection (3) or (as the case may be) in accordance with the requirement in subsection (4A);

(c) the relationship (if any) between the witness and the accused;

(d) the witness's social and cultural background and ethnic origins;

(e) the nature and alleged circumstances of the offence to which the proceedings relate.”

……..

(8) Where a special measures direction is given in relation to a child witness who is an eligible witness by reason
only of section 16(1)(a), then—

(a) subject to subsection (9) below, and

(b) except where the witness has already begun to give evidence in the proceedings, the direction shall cease to
have effect at the time when the witness attains the age of 18.

(9) Where a special measures direction is given in relation to a child witness who is an eligible witness by reason
only of section 16(1)(a) and—

(a) the direction provides—

(i) for any relevant recording to be admitted under section 27 as evidence in chief of the witness, or

(ii) for the special measure available under section 28 to apply in relation to the witness, and

(b) if it provides for that special measure to so apply, the witness is still under the age of 18 when the video
recording is made for the purposes of section 28,

then, so far as it provides as mentioned in paragraph (a)(i) or (ii) above, the direction shall continue to have effect in
accordance with section 20(1) even though the witness subsequently attains that age.”

21 The explanatory notes for section 21(8) and (9) subsections say this:


-----

“103. Subsection (8) provides that, if a court makes a special measures direction in respect of a child witness who
was eligible for special measures on grounds of youth only, and the witness turns 17 before beginning to give
evidence, the direction will no longer have effect. But if such a witness turns 17 after beginning to give evidence, the
special measures provided for him will continue to apply. The intention is to reduce confusion for the witness and
the court.

104. Subsection (9) provides that if a witness gave video-recorded evidence in chief or was cross-examined on
video before the trial when he was under 17, but since turned 17, the video recording will still be admissible as
evidence.”

22. Section 22 extends the provisions of section 21 to other witnesses, in addition to child witnesses, in the
following terms:

“Section 22  Extension of provisions of section 21 to certain witnesses over 18

(1) For the purposes of this section—

(a) a witness in criminal proceedings (other than the accused) is a “qualifying witness” if he—

(i) is not an eligible witness at the time of the hearing (as defined by section 16(3)), but

(ii) was under the age of 18 when a relevant recording was made;

(b) [repealed in 2009]… and

(c) a “relevant recording”, in relation to a witness, is a video recording of an interview of the witness made with a
view to its admission as evidence in chief of the witness.

(2) Subsections (2) to (4) and (4C) of section 21, so far as relating to the giving of a direction complying with the
requirement contained in section 21(3)(a), apply to a qualifying witness in respect of the relevant recording as they
apply to a child witness (within the meaning of that section).”

23. Section 27 deals with ABE evidence. It is headed “Video recorded evidence in chief” and provides (in part) that:

“(1) A special measures direction may provide for a video recording of an interview of the witness to be admitted as
evidence in chief of the witness.

(2) A special measures direction may, however, not provide for a video recording, or a part of such a recording, to
be admitted under this section if the court is of the opinion, having regard to all the circumstances of the case, that
in the interests of justice the recording, or that part of it, should not be so admitted.”

In the subsequent sub-sections of section 27, more detailed provision is made for situations in which only a part of
the ABE interview is played, a witness is called for cross-examination, and other circumstances which are not
relevant to the instant case.

24. The relevant parts of Section 28 provide as follows:

“Section 28  Video recorded cross-examination or re-examination

(1) Where a special measures direction provides for a video recording to be admitted under section 27 as evidence
in chief of the witness, the direction may also provide—

(a) for any cross-examination of the witness, and any re-examination, to be recorded by means of a video
recording; and

(b) for such a recording to be admitted, so far as it relates to any such cross-examination or re-examination, as
evidence of the witness under cross-examination or on re-examination, as the case may be.


-----

(2) Such a recording must be made in the presence of such persons as Criminal Procedure Rules or the direction
may provide and in the absence of the accused, but in circumstances in which—

(a) the judge or justices (or both) and legal representatives acting in the proceedings are able to see and hear the
examination of the witness and to communicate with the persons in whose presence the recording is being made,
and

(b) the accused is able to see and hear any such examination and to communicate with any legal representative
acting for him.”

25. Section 28 of the 1999 Act was brought into force in relation to Snaresbrook Crown Court by statutory
instrument, the _[Youth Justice and Criminal Evidence Act 1999 (Commencement No 18) Order 2020 (the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61F0-TWPY-Y1GJ-00000-00&context=1519360)_
Commencement Order). That Order brought section 28 into force from 24 August 2020 if two conditions are
satisfied. The first condition is that proceedings take place before one of a number of specified Crown Court
locations. Snaresbrook is included in that list. The second condition is that the witness is eligible for assistance by
virtue of section 16 of the 1999 Act.

_The parties' submissions_

26. Mr. Alexander Wright appeared for the appellant, as he did at the section 28 application, the ground rules
hearing and the trial. He submitted, as he did before HHJ del Fabbro, that section 16(1)(a) of the 1999 Act makes a
witness eligible for assistance only if they are under the age of 18 at the time of the hearing. Section 16(1)(3)
clarifies that “the time of the hearing” refers to the time of the hearing of the application for special measures i.e.
when it falls to the court to make a determination for the purposes of section 19(2) in relation to the witness. For
present purposes, this was on 4 February 2021. Since this was after the complainant became 18, section 16(1)(a)
did not apply. It follows that the Commencement Order conditions were not satisfied, the section 28 procedure was
not available and the (cross examination) evidence from the complainant taken in this form should not have been
adduced at the appellant's trial. Though the complainant's evidence in chief could properly be given by way of her
recorded ABE interview, she should have been cross examined over the live link and in the usual way, that is,
without notice of the defence questions to the prosecution and the court. The judge's ruling was therefore wrong as
a matter of law; and the use of the section 28 procedure undermined the safety of the appellant's conviction.

27. As for the ground rules hearing, Mr Wright submitted that some of the changes made at the prosecution's
invitation to the questions proposed by the defence, also had a serious effect on the fairness of the appellant's trial.
His principal example concerned one question which in the original defence draft was in this form: “So as soon as
you told him that you were not happy he stopped? This was changed at the judge's direction to this: “Did he stop as
soon as you told him you were not happy?”

28. Mr Louis Mably QC for the respondent, who did not appear below, provided a helpful analysis of the relevant
legislation. He also identified what was described in his written submissions, as a possible route for the judge to
have concluded that the section 28 procedure was available in this case. He did not press this point in oral
argument however, but realistically and fairly identified the reasons why this court might take the view that the
judge's interpretation of the relevant legislation was erroneous. In the result, Mr Mably's main focus was on the
issue of safety of the appellant's conviction. He submitted that it cannot be said that the making of the section 28
direction or its implementation at trial, affected the safety of the appellant's conviction. Further, to the extent there
was any restriction on the questions that could be put in cross examination, this was not improper and cannot be
said to have rendered the appellant's conviction unsafe.

_Discussion_

29. It is helpful to start with a summary of how the material parts of the legislative scheme for special measures
operates under the current legislation. A witness is eligible for special measures assistance if section 16 of the 1999
Act or section 17 applies. Section 16 applies in the case of a witness aged under 18 at the time the court is
considering the special measures application (and in certain circumstances not material here). The complainant had
attained the age of 18 by the time of the prosecution's application for a measure under section 28 and therefore


-----

she was not eligible under section 16. She was however eligible for assistance under section 17(4) of the 1999 Act
which applies in the case of a complainant in respect of a sexual offence. Section 18 provides that in the case of a
witness eligible under section 17, the special measures available are those set out in sections 23 to 28 which
include evidence by live link (section 24), video recorded evidence in chief (section 27) and video recorded cross
examination and re-examination (section 28).

30. Section 19(2) provides that where a witness is eligible for assistance under section 16 or section 17, the court
is empowered to make a special measures direction. When considering making a direction, the court must
determine whether any of the measures available in relation to the witness would be likely to improve the quality of
the witness's evidence, and, if so, which of those measures would be likely to maximise the quality of the evidence.
Having made a determination in that regard, the court must make a direction accordingly. The court's
determinations pursuant to section 19(2) are subject to a “primary rule” set out in section 21 which serves as a
presumption in the case of a witness eligible by virtue of section 16(1)(a) (that is, aged under 18 at the time of the
court hearing to consider the making of a direction), and who has been interviewed on video with a view to the
recording being admitted as his or her evidence in chief. In such a case, subsection (3) provides that the primary
rule is that the court must make a direction for the recording, or recordings to be admitted in evidence in chief under
section 27, and for any evidence given by the witness which is not given by means of video recording (whether in
chief or otherwise) to be given by live link under section 24.

31. Section 22 extends the primary rule in the case of a qualifying witness, namely a witness who was aged under
18 at the time the recording was made, but who has attained that age at the time of the hearing. In such a case, the
primary rule is extended to the extent that the court must direct that the recording be admitted as evidence in chief
under section 27. The complainant was a qualifying witness in this regard. The special measure we are concerned
with here, video recorded cross examination, is provided for by virtue of section 28 and pursuant to section 18, is
available in the case of a witness eligible for assistance by virtue of section 16 and section 17. Importantly however,
at the material time, namely when the application for the special measure was made (on 4 February 2021) section
28 was only partially in force for Snaresbrook: it was only in force for witnesses eligible for assistance by virtue of
section 16

32. In our view, it is plain from an ordinary reading of the relevant legislation, including the Commencement Order,
that the appellant's submissions on the availability of section 28 at the material time, are correct. The complainant
was not eligible for assistance by virtue of section 16, because of her age at the time the section 28 application was
made, and this was the only route available because of the terms of the Commencement Order.

33. We are unable to accept the way round this difficulty proposed by the prosecution below and accepted by HHJ
del Fabbro. The judge accepted that the primary rule as extended to the witness by virtue of section 22, made the
section 28 special measure available in her case. This was on the basis that the wording of the primary rule in
section 21(3)(b) in relation to live links, indicated that the rule permitted a direction for video recorded evidence
“otherwise” than evidence in chief.

34. As Mr Mably accepted however, section 22 does not extend the primary rule to a qualifying witness in respect
of the live link provision where the words “or otherwise” are contained: section 21(3)(b). The rule is only extended in
respect of recorded evidence in chief: section 21(3)(a), and see section 22(2). In any event, in its natural and
contextual meaning, the phrase “or otherwise” in section 21(3(b) caters for the position where a video recorded
cross examination has been directed in an appropriate case. The provision does of itself make available a measure
under section 28, or make any particular measure available. It simply informs the court how it should proceed in the
case of measures that are available by virtue of section 18, read with sections 16 and 17. Nothing in section 21 or
section 22 directly, or by way of a deeming provision, makes a witness eligible under section 16 for section 28
purposes, or otherwise makes a measure under section 28 available. It follows that the route adopted by the judge,
namely that sections 21 and 22 of 1999 Act when read together permitted the pre-recording of the complainant's
cross-examination pursuant to section 28, whereas her age at the time did not, does not accord with the meaning of
the statutory scheme. Nor does it accord with the terms of the Commencement Order which plainly restricted the
operation of section 28 to a witness eligible under section 16 only.


-----

35. This conclusion is consistent with the terms of the relevant Criminal Practice Direction. This provides as
follows:

“Criminal Practice Direction V Evidence 18E: Use of s.28 YJCEA 1999; Pre-recording of Cross-examination and
Re-examination for Witnesses Captured by s.16 YJCEA 1999 18E.1

When Section 28 of the Youth Justice and Criminal Evidence Act 1999 (s.28 YJCEA 1999) is bought into force by
Statutory Instrument for a particular Crown Court, under that SI, a witness will be eligible for special measures
under s.28 if (i) he or she is under the age of 18 at the time of the special measures determination; or (ii) he or she
[suffers from a mental disorder within the meaning of the Mental Health Act 1983,or has a significant impairment of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0F8-00000-00&context=1519360)
intelligence and social functioning, or has a physical disability or a physical disorder, and the quality of his or her
evidence is likely to be diminished as a consequence.”

36. The question that then arises is whether the use of the section 28 procedure in these circumstances affected
the safety of the appellant's conviction. We are not persuaded that it did. First, in our view, the admission of the
recording is a procedural irregularity the mere fact of which does not invalidate the proceedings, or affect the safety
of the conviction. Secondly, it seems to us that this part of the appellant's case is based on a misconception,
namely that the receipt of the pre-recorded cross examination of a witness is unfair to a defendant without more.
Different measures have been adopted over time for the receipt of evidence to refine and improve the criminal trial
process – including the use of screens, live links and the receipt of pre-recorded evidence. Provided the relevant
safeguards are in place, there is nothing inherently unfair to a defendant in the jury receiving such evidence. In this
context we note that during the course of the application before HHJ del Fabbro, the judge asked Mr Wright
whether there would be any prejudice (to the defence) if the section 28 procedure were to be adopted, and Mr
Wright expressly accepted there would not be.

37. We note too that in the course of the summing up, about which no criticism is made, the jury were given
specific directions on the different ways that they had received evidence during the trial. The trial judge said:
“Obviously you have had evidence on oath from the witness box. However, it has been presented to you in other
forms too. In this case there have been the pre-recorded, video interview and then cross-examination. The status of
this evidence would have been no different had it been given from the witness box; it is the same. Such measures
are now routine in the Crown Court and is certainly not a matter that should be held against the defendant in any
way. Their use therefore has no weight in the case and must not affect your deliberations.”

38. We turn next to the issue of the ground rules hearing. The gravamen of Mr Wright's submissions before us did
not concern the holding of the ground rules hearing per se, but what was described in the written grounds as an
“improper restriction on questioning.” This related, as earlier indicated, to amendments made by the court to
questions which the defence proposed to ask in cross examination, following objections by the prosecution.

39. We start by noting two points. First, directions were given about this feature of the evidence in the summing
up, where the trial judge said: “Regarding the pre-recorded cross-examination carried out by Mr Wright for the
defence, as [the complainant] was quite young he was not permitted to question and in particular challenge [the
complainant] in the same way, or for the same amount of time, as a defence advocate would have questioned and
challenged an older witness. This does not mean, however, that [the complainant's] evidence is not disputed, and
you should not regard the limited manner of the questions as in any way lessening the extent to which it is
disputed.” Secondly, the Criminal Practice Directions (at PD1A) provide in relation to vulnerability, that: “1. The
overriding objective requires that in order to deal with a case justly, the court should ensure, so far as practicable,
that the parties are on an equal footing and can participate fully in proceedings, and that the parties and witnesses
can give their best evidence. The parties are required to help the court to further the overriding objective at all
stages of civil proceedings. 2. Vulnerability of a party or witness may impede participation and also diminish the
quality of the evidence. The court should take all proportionate measures to address these issues in every case.”

40. Turning then to the specific issues raised, there is, with respect to Mr Wright, little merit in this ground of
appeal. The appellant was not prevented from cross examining the complainant on any topic Mr Wright considered
relevant to the defence. Further, the changes made to the questions drawn to our attention were, in our judgment


-----

both “light touch” and sensible; they did not alter the substance or the nature of the questions, or disguise or change
the way that the complainant's evidence was tested, let alone lead to answers that would not otherwise have been
given and could not be challenged. During the course of the ground rules hearing, Mr Wright made the point to the
judge with regard to the questions under consideration, that the complainant was no longer a child. The judge was
obviously aware of this, as he was that this was a sensitive case in which an allegation of sexual assault was made
by one young family member against another – and where, as the judge observed, the complainant was barely out
of her teens. In the result, the adjustments made were in our judgment unobjectionable and proportionate in all the
circumstances, simply splitting one question into two for example, or slightly simplifying the language used or
converting some of the closed statements to be put, to open questions.

41. We do not accept either that Mr Wright's ability to challenge the complainant was compromised. Mr Wright
relied on one matter in particular. The complainant said in cross examination that she had to tell the appellant twice
before he stopped. This was something she had not said in her ABE interview. The judge had indicated at the
ground rules hearing that Mr Wright would be able to ask a follow up question in such circumstances, i.e. if matters
were mentioned in cross examination that were not in the complainant's ABE interview. In relation to the
interchange highlighted by Mr Wright, this is precisely what happened (in a part of the cross examination to which
attention was specifically drawn in the summing up).

42. For the reasons we have identified, the section 28 procedure was not available in this case. We are not
satisfied however that its use or the decisions made at the ground rules hearing, affected the safety of the
appellant's conviction. This appeal is, accordingly, dismissed.

**End of Document**


-----

