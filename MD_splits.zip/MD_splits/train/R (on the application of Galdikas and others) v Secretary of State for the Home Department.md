# R (on the application of Galdikas and others) v Secretary of State for the
 Home Department

## [2016] EWHC 942 (Admin), [2016] 1 WLR 4031, [2016] All ER (D) 181 (Apr)

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 26/04/2016

# Catchwords & Digest

## IMMIGRATION - LEAVE TO REMAIN – VICTIM OF TRAFFICKING – CLAIMANT VICTIMS OF TRAFFICKING BEING UNABLE TO CLAIM STATE BENEFITS – CLAIMANTS ISSUING JUDICIAL REVIEW PROCEEDINGS – WHETHER EUROPEAN LAW REQUIRING PROVISION OF ASSISTANCE AND SUPPORT – WHETHER EUROPEAN CONVENTION APPLYING ALTHOUGH NOT INCORPORATED INTO ENGLISH LAW – WHETHER FIRST DEFENDANT SECRETARY OF STATE MISDIRECTING SELF AS TO PERIOD SUPPORT DUTY CONTINUING – EUROPEAN PARLIAMENT AND COUNCIL DIRECTIVE 2011/36, ART 11 – CONVENTION ON ACTION AGAINST TRAFFICKING IN HUMAN BEINGS, ART 12.

 Immigration – Leave to remain. The Administrative Court partially allowed the claim for judicial review by the claimant victims of trafficking. It held that part of the first defendant Secretary of State's guidance 'Victims of Modern Slavery: Competent Authority Guidance (July 2015)' was unlawful, as it did not allow victims of trafficking or their legal representatives to request discretionary leave to remain on the grounds of agreeing to assist the police with their enquiries.

# Cases referring to this case


EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v
Secretary of State for the Home Department

_[[2022] EWCA Civ 307, [2023] QB 351, [2022] 3 WLR 353, [2022] INLR 213, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
_[ER (D) 70 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
Considered


17/03/2022

CACivD


-----

# Cases considered by this case

R (on the application of BG) v Secretary of State for the Home Department

_[[2016] EWHC 786 (Admin), [2016] All ER (D) 74 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_
Considered

Detention Action v Lord Chancellor; Subnom R (on the application of Detention Action)
v First-tier Tribunal (Immigration and Asylum Chamber)

_[[2015] EWCA Civ 840, [2016] 3 All ER 626, [2015] 1 WLR 5341, [2016] INLR 79,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KBH-RH61-DYBP-M40J-00000-00&context=1519360)_
[(2015) Times, 09 September, [2015] All ER (D) 314 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GJP-MGW1-DYBP-N3X0-00000-00&context=1519360)
Applied

R (on the application of SG and others (previously JS and others)) v Secretary of State
for Work and Pensions

_[[2015] UKSC 16, [2015] 4 All ER 939, [2015] 1 WLR 1449, [2015] PTSR 471, (2015)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HHT-9M41-DYBP-M3F7-00000-00&context=1519360)_
[Times, 03 April, [2015] All ER (D) 197 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJ9-DSF1-DYBP-N3KY-00000-00&context=1519360)
Considered

G v Director of Legal Aid Casework (British Red Cross Society intervening)

_[[2014] EWCA Civ 1622, [2015] 3 All ER 827, [2015] 1 WLR 2247, [2014] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GNX-7641-DYBP-M1YX-00000-00&context=1519360)_
_[157 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DVH-JYB1-DYBP-N2KV-00000-00&context=1519360)_
Considered

R (on the application of Atamewan) v Secretary of State for the Home Department

_[[2013] EWHC 2727 (Admin), [2014] 1 WLR 1959, [2013] All ER (D) 61 (Sep)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:599S-X571-DYBP-N3C4-00000-00&context=1519360)_
Considered

R (on the application of Lumba) v Secretary of State for the Home Department; R (on
the application of Mighty) v same

_[[2011] UKSC 12, [2012] 1 AC 245, [2011] 4 All ER 1, [2011] 2 WLR 671, (2011) Times,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_
24 March, [2011] All ER (D) 262 (Mar)
Considered

JH Rayner (Mincing Lane) Ltd v Department of Trade and Industry

[[1990] 2 AC 418, [1989] Ch 72, [1989] 3 All ER 523, [1989] 3 WLR 969, [1990] LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60RX-00000-00&context=1519360)
_[(Const) 193, [1990] BCLC 102, (1989) Times, 27 October, [1988] Lexis Citation 2500](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KP9-CMW1-DYJ0-82T4-00000-00&context=1519360)_
Considered

Hetherington, Re

[[1990] Ch 1, [1989] 2 All ER 129, [1989] 2 WLR 1094, [1989] Lexis Citation 2053](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-6151-00000-00&context=1519360)
Considered

**End of Document**


12/04/2016

AdminCt

29/07/2015

CACivD

18/03/2015

SC

15/12/2014

CACivD

06/09/2013

DC

23/03/2011

SC

26/10/1989

HL

23/01/1989

ChD


-----

