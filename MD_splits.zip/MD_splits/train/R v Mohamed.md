# R v Mohamed [2024] EWCA Crim 782

Court of Appeal, Criminal Division

Popplewell LJ, Hilliard J, HHJ Dean

2 July 2024Judgment

NON-COUNSEL APPLICATION

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. MR JUSTICE HILLIARD: On 21 July 2023, in the Crown Court at Cardiff, the applicant was convicted
of nine counts involving the supply of class A drugs, one count of being concerned in the production of a
controlled drug and one count of possessing criminal property. On 21 September 2023, he was sentenced

to a total of seven‑and‑a‑half years' imprisonment. The co‑accused, Yaser Mohamed, the applicant's

brother, was convicted of four of the offences and sentenced to three‑and‑a‑half years' imprisonment.

2. The applicant now renews his application for an extension of time of 56 days in which to seek leave to
appeal against conviction and for a representation order after refusal by the single judge.

3. It was alleged that the applicant and his brother had supplied class A drugs (heroin and crack cocaine).
The applicant was found in possession of controlled drugs and the police found £22,343.94 in cash and
evidence of the production of crack cocaine at his flat.

4. The applicant's defence was that he was a victim of Modern Slavery. The applicant said he was told
by a drug dealer that the applicant's brother owed him money and both brothers would have to sell drugs to
pay off the debt. He said that he was threatened with violence if he did not comply.

5. The trial of the applicant and his brother had reached the stage where the applicant was giving
evidence. At one point in his evidence he said that he did not wish to answer any further questions. The
reason for this is not apparent. The transcript records the applicant saying: "They just seem like they was
working together." The judge said: "They were not working together. They were trying to work out what
your answer was in terms of clarifying what was being said." It is possible that this is a reference to some
communication between the applicant's counsel and someone else.


-----

6. The judge said there would be a break. In the absence of the jury, he said that he would have to give
the applicant a warning that if he refused without good cause to answer any questions, an adverse
inference could be drawn from that. But he said that such a warning would have to be given in the
presence of the jury.

7. However, the judge then decided to give the warning to the applicant in the absence of the jury but
before allowing him an opportunity to see his counsel. The applicant said that he understood the warning
but did not feel he could carry on with his current barrister. The judge said that they would continue with
the trial and he would have to represent himself, although it was better for him if he was represented.

8. The court then adjourned for lunch. The applicant's counsel told the judge that the applicant wished to
sack him and his solicitor and possibly represent himself. The judge said he would give the applicant a
note in which he had set out the benefits of being represented and of what the applicant would be expected
to do if he represented himself. The judge said that the case had proceeded for over a week and that the
case had been outstanding for a considerable period of time. He gave the applicant time to read the
document and to consider his position.

9. On his return to court, the applicant said that he wanted time to find a new barrister and solicitor. The
judge said that the trial would be proceeding. It had been running for a week and only a small part of it
remained. The judge said he could have his old lawyers back or do it himself. The applicant said he
wanted to find someone else and was not confident in representing himself but if he had to represent
himself then he would do that.

10. The jury returned. The judge told them that the applicant was representing himself, as he was entitled
to do, and that it had no bearing on the verdicts. The judge warned the applicant about the possible
consequences of not answering questions. In the event, the applicant did answer questions. The trial then
continued with him representing himself. In due course, he was convicted by the jury.

11. The applicant now advances his own written grounds of appeal which we appreciate will not have
been easy for him to do. He says that the judge should have discharged the jury, ordered a retrial and
allowed him to instruct a new legal team. He says there was a conflict in the evidence about where some

drugs were found and that interviews were not heard during the trial ‑ although it is not clear which

interviews he is referring to.

12. We have carefully considered the points which have been made. It is clear that a judge has a
discretion whether or not to continue a trial in the circumstances which arose here and whether or not to
allow a defendant new representation: see for example Stovell [2006] EWCA Crim. 27. The applicant had
been represented throughout the prosecution case. The judge made the options very clear to him. The
trial had advanced to a late stage. It was open to the judge to conclude that the trial should continue rather
than incur the delay and expense of a retrial. The earliest offences dated back to the later part of 2019.
There would have been further delay if there was to be a retrial. The case was not a complex one. We
note that the applicant's case was the same as his brothers. His brother continued to be represented and
his counsel would inevitably have covered much of the ground which concerned the applicant. The

summing‑up was a fair one and the legal directions were sufficient. The applicant's defence was set out.

There was ample opportunity during the trial for any points about where drugs were found to be explored
and for questions to be asked about interviews. The applicant has not explained why these points could
matter.

13. Having taken an overall view of the matter, we are satisfied that there are no arguable grounds for
saying that any of the applicant's convictions is unsafe. In these circumstances, there is no purpose to be
served in granting the extension of time. Accordingly all these applications must be refused.

14. **Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the**
proceedings or part thereof.

Lower Ground Floor, 46 Chancery Lane, London, WC2A 1JE


-----

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

