# XY v Secretary of State for the Home Department

## [2024] EWHC 81 (Admin), [2024] 1 WLR 2272, [2024] All ER (D) 01 (Feb)

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 23/01/2024

# Catchwords & Digest

## IMMIGRATION - MODERN SLAVERY – REFUSAL OF LEAVE TO REMAIN BASED ON UNPUBLISHED POLICY

      The High Court allowed the application for judicial review by the claimant Albanian national against the defendant Secretary of State’s refusal to consider his entitlement for leave to remain in the UK as a victim of modern slavery pending the determination of his asylum claim. The claim for entitlement was made pursuant to the Secretary of State’s policy in accordance with art 14(1)(a) of the Council of Europe Convention on Action against Trafficking in Human Beings 2005 which provided that a discretionary leave could be considered where the competent authority had made a positive conclusive grounds decision that an individual was a victim of slavery and had satisfied one of the relevant criteria. Following the judgment in R (on the application of KTT) v Secretary of State for the Home Department, [2021] All ER (D) 05 (Nov) that leave to remain could be obtained on ground that stay was necessary to pursue an asylum claim based on fear of re-trafficking, the claimant had contended that the policy contravened the law on the basis that the Secretary of State had operated a ‘secret policy’, where its officials had been instructed not to render decisions in cases where confirmed victims of slavery were seeking asylum on the grounds of fear of re-trafficking. The court held, among other things, that the defendant had adopted a policy or practice in the light of KTT, which was not given effect by amending or supplementing the published policy. The Secretary of State could have explained in the policy that until the ultimate stage of the KTT litigation was known, it would not render decisions in respect of those covered by the declaration in KTT. The Secretary of State had breached its duty of candour for failure to disclose the existence of the unpublished policy and had taken two decisions regarding the claimant’s entitlement to not served those decisions on the claimant. 

# Cases referring to this case

R (on the application of FH) v Secretary of State for the Home Department

_[[2024] EWHC 1327 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C69-BT43-RRSM-B27J-00000-00&context=1519360)_
Considered


04/06/2024

AdminCt


-----

R (on the application of Oji) v Director of Legal Aid Casework

_[[2024] EWHC 1281 (Admin), [2024] 4 WLR 53](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C4C-HV03-RS2F-V343-00000-00&context=1519360)_
Explained

# Cases considered by this case

R (on the application of IAB and others) v Secretary of State for the Home Department
and another

_[[2023] EWHC 2930 (Admin), [2024] 1 WLR 1876, [2023] All ER (D) 116 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69PJ-2G73-RRY3-04JM-00000-00&context=1519360)_
Considered

EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v
Secretary of State for the Home Department

_[[2022] EWCA Civ 307, [2023] QB 351, [2022] 3 WLR 353, [2022] INLR 213, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
_[ER (D) 70 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
Considered

R (on the application of KTT) v Secretary of State for the Home Department

_[[2021] EWHC 2722 (Admin), [2022] 1 WLR 1312, [2021] All ER (D) 05 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6406-MM63-GXF6-850H-00000-00&context=1519360)_
Applied

R (on the application of JP) v Secretary of State for the Home Department; R (on the
application of BS) v Secretary of State for the Home Department

_[[2019] EWHC 3346 (Admin), [2020] 1 WLR 918, [2020] All ER (D) 65 (Jan)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y1K-3F63-CGXG-03S4-00000-00&context=1519360)_
Considered

R (on the application of Balajigari) v Secretary of State for the Home Department and
other appeals

_[[2019] EWCA Civ 673, [2019] 4 All ER 998, [2019] 1 WLR 4647, [2019] INLR 619,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_

_[[2019] All ER (D) 134 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W0H-B402-8T41-D41B-00000-00&context=1519360)_
Explained

R (on the application of PK (Ghana)) v Secretary of State for the Home Department

_[[2018] EWCA Civ 98, [2018] 1 WLR 3955, (2018) Times, 08 March, [2018] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RP8-P361-DYBP-N228-00000-00&context=1519360)_
_[86 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RP8-P361-DYBP-N228-00000-00&context=1519360)_
Explained

R (on the application of Kyeremeh) v The Secretary of State for the Home Department
(2017)

_[[2017] EWCA Civ 213](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5ND3-H9N1-F0JY-C02W-00000-00&context=1519360)_
Considered

G v Director of Legal Aid Casework (British Red Cross Society intervening)

_[[2014] EWCA Civ 1622, [2015] 3 All ER 827, [2015] 1 WLR 2247, [2014] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GNX-7641-DYBP-M1YX-00000-00&context=1519360)_
_[157 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DVH-JYB1-DYBP-N2KV-00000-00&context=1519360)_
Explained

Malcolm v Ministry of Justice

_[[2011] EWCA Civ 1538, [2011] All ER (D) 98 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54GS-P1T1-DYBP-N13B-00000-00&context=1519360)_
Considered

R (on the application of Lumba) v Secretary of State for the Home Department; R (on
the application of Mighty) v same

_[[2011] UKSC 12, [2012] 1 AC 245, [2011] 4 All ER 1, [2011] 2 WLR 671, (2011) Times,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_
24 March, [2011] All ER (D) 262 (Mar)


24/05/2024

AdminCt

17/11/2023

AdminCt

17/03/2022

CACivD

12/10/2021

AdminCt

10/12/2019

AdminCt

16/04/2019

CACivD

13/02/2018

CACivD

03/02/2017

CACivD

15/12/2014

CACivD

14/12/2011

CACivD

23/03/2011

SC


-----

Applied
R (on the application of Anufrijeva) v Secretary of State for the Home Department

_[[2003] UKHL 36, [2004] 1 AC 604, [2003] 3 All ER 827, [2003] 3 WLR 252, [2003] INLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6160-00000-00&context=1519360)_
[521, (2003) Times, 27 June, [2003] All ER (D) 353 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWK1-DYBP-N12P-00000-00&context=1519360)
Explained

**End of Document**


26/06/2003

HL


-----

