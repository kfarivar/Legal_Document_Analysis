# R (on the application of EL) v Secretary of State for the Home Department

 [2018] EWHC 968 (Admin)

Queen's Bench Division, Administrative Court (London)

Judge Evans-Gordon (sitting as a Judge of the High Court)

26 April 2018Judgment

**Ms Catherine Robinson (instructed by Duncan Lewis) for the Claimant**

**Dr Christopher Staker (instructed by the Treasury Solicitor) for the Defendant**

Hearing date: 24th January 2018

- - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

**Her Honour Judge Evans-Gordon:**

1.  In this claim the claimant, an Albanian national, challenges the defendant's decision of 24 October
2016 (“the decision letter”) to the effect that she is not a victim of trafficking. Her application for asylum
was refused on 8 September 2017, no doubt, in large part, because of the negative decision letter: I have
not seen the refusal of asylum decision. There is also a preliminary issue as to whether or not the
standard of scrutiny to be applied to the decision is one of anxious scrutiny and whether or not this is a
greater level of scrutiny than is usually the case. I am grateful to both counsel for their assistance.

The Facts

2.  As there is no dispute as to the defendant's account of the claimant's factual case as contained in the
decision letter, I will summarise it rather than set it out in full. The claimant, who was born on 24th January
1990, first met a man called Marko in about 2004, when she was 14 and living with her parents and
siblings in Burrell, Northern Albania. Marko was about 20 at the time. She states that after two or three
months of meeting him, during which time he flirted with her, he raped her. He continued to rape her over
the next three years threatening her and physically harming her to prevent disclosure. Alternatively, after
six to eight months of the rape, the claimant developed feelings for Marko, the relationship became
consensual and he no longer mistreated her. At the end of 2007/beginning of 2008, when the claimant
would have been nearly, or just turned 18, her parents received a marriage proposal for her from another
man, AL. When she told Marko of this he disappeared, and she did not see him again for some years.

3.  The claimant married AL in May 2009 and moved to his home town of Arapaj, Durres but he was out of
the country a lot, working. Approximately a year later she met Marko again, while on a visit to her parents.
She was not happy to see him and felt that he followed her. She asked him to leave her alone, but he
would not do so. She then entered a consensual sexual relationship with him. The claimant became


-----

pregnant at around the same time but was clear that the baby was her husband's because of the dates.
The claimant chose to stop seeing Marko following the birth of her child: the child was born on 6 February
2011.

4.  The claimant next met Marko again in 2015. In May or June of that year she told her husband that
Marko would not leave her alone but did not reveal her previous sexual relationships with him. AL started
to doubt her fidelity and said that the marriage was over, but she should continue to stay with his parents to
look after them: they were not told of the end of the relationship between AL and the claimant. Nor did the
claimant tell her own parents what had happened, but she did tell her 14 or 15-year-old brother, E. She
also told Marko who, it appears, was already a friend of E notwithstanding the 16-year age disparity. Marko
invited her to live with him in Italy and said he would look after her son. The claimant refused but later
agreed when Marko said he would also take her brother E with them. Marko, it appears, had already
spoken separately to E about this.

5.  The claimant, her son and E left Albania for Italy on 5 July 2015. They travelled on to France within a
day where they met Marko who had not travelled with them. In France the claimant lived with Marko and
her son while E stayed with friends of Marko. Nothing untoward occurred during this time. On 5 October
2015 the claimant, her son and E tried to enter the United Kingdom using forged documents but were
stopped by the authorities. Following their release, they were collected by friends of Marko's and taken to
a building where they met a woman named Selima. Selima told the claimant that she would have to work
as a prostitute to pay them for the forged documents. When the claimant spoke to Marko on the telephone
he said that E's life was in her hands; if she worked as a prostitute, E would be free to do as he pleased.
The claimant did not see E again.

6.  The claimant began work as a prostitute and saw two to four clients each night while Selima looked
after the claimant's son. She would visit one client at his home approximately 30 minutes' drive away. The
client would pick her up and she would take her son with her. As that client saw her distress on several
occasions he offered to pick her up as usual one night and let her go. This happened on 16 December
2015. The client took the claimant and her son to a place where there were lots of lorries and the claimant
agreed with a lorry driver that he would take them to the United Kingdom in exchange for her gold
jewellery: this he did.

7.  On 17 December 2015 the claimant had an initial screening interview at the Asylum Interview Unit in
Croydon which made a referral to the NRM on 18th December 2015. At the time the claimant was
pregnant with her second child. On 31 December 2015 the competent authority made a positive
reasonable grounds decision and the claimant and her son were accommodated pending a conclusive
grounds decision. The claimant's second child was born on 11 August 2017: the claimant says she does
not know the identity of the father. As stated above, the competent authority made a negative conclusive
grounds decision on 24 October 2016.

8.  On 23 December 2016 the claimant's solicitors sent a letter before action to the Defendant who replied
on 9 January 2017 maintaining the negative conclusive grounds decision. The claim was issued on 3
February 2017. Permission was refused on paper by John Cavanagh QC, sitting as a Deputy High Court
Judge but granted at a subsequent oral hearing on 15 August by Peter Marquand, sitting as a Deputy High
Court Judge.

The Issue

9.  There is no suggestion that the competent authority misunderstood the claimant's case on the facts
which, in essence, it found to be incredible and therefore determined that, on balance of probabilities, the
claimant was not a victim of trafficking. The issue concerns the competent authority's approach to the
credibility of the claimant in light of the fact that she was a child during the early part of her relevant history.
It is said that the defendant either did not apply her policy or misapplied it. The relevant policy is that set
out in the document 'Victims of Modern Slavery – Competent Authority Guidance' (v.3.0, 21 March 2016)
(“the Guidance”).

The Legal Framework


-----

10. Before turning to the Guidance, it might be helpful, briefly, to set out the system applicable in such
cases. Following the United Kingdom's adoption of the Council of Europe Convention on Action against
Trafficking in Human Beings, CETS No. 197 (“the Convention”), which was never incorporated into English
law, the Government established a National Referral Mechanism (“NRM”) to give effect to its obligations
under the Convention. The NRM's objective is to aid the identification and support of victims of trafficking,
to make it easier for all relevant agencies, such as the Home Office, the Police, local authorities, the
National Crime Agency and others, to cooperate and share information about potential victims and to
facilitate potential victims' access to support services, accommodation and advice. To achieve this
objective, the government has established the UK Human Trafficking Centre (“the UKHTC”) and appointed
certain officials within it and the Home Office as 'competent authorities' who are the decision-makers.

11. The first step in the NRM is the identification and referral of potential victims to the UKHTC by officials
or organisations, known as 'First Responders'. The UKHTC may deal with the case itself or send it to the
most appropriate competent authority within the Home Office to determine. The competent authority must
first determine whether it 'suspects but cannot prove this person is a potential victim of human trafficking';
this is called a reasonable grounds decision.  The 'suspect but cannot prove' test is a relatively low
threshold, lower than the civil standard of proof or conclusive grounds test, perhaps the equivalent of a
_prima facie case or an arguable case. This decision should be made within five working days of referral to_
the NRM. Once a competent authority has made a positive reasonable grounds decision the potential
victim is given a 45-day recovery and reflection period and any necessary support while the competent
authority makes a substantive decision. The support provided includes accommodation, health services
and counselling services. The test for making the substantive or conclusive grounds decision is whether
“on the balance of probabilities, there are sufficient grounds to decide that the individual being considered
is a victim of human trafficking”.

12. The claimant also refers to Article 11 of the European Directive 2011/36/EU in her skeleton argument
however, no substantive submissions were made to the effect that there has been a breach or
misapplication of that Directive and, in any event, it appears that the only relevant part is Article 11 (4)
which states that “Member States shall take the necessary measures to establish appropriate mechanisms
aimed at the early identification of, assistance to and support for victims, in cooperation with the relevant
support organisations”. As the defendant points out, it is clear that the means of implementation of that
Directive is a matter for each member state: see, e.g. The Queen (on the application of Galdikas & Ors) v
_Secretary of State for the Home Department & Ors [2016] EWHC 942 (Admin) at [26]. The claimant also_
refers to article 4 of the European Convention on Human Rights but, again, she does not identify in what
way, if any, it is said that such rights have been breached. It appears to be relied on merely to support a
contention that the appropriate level of scrutiny is 'anxious scrutiny'.

13. The Guidance provides assistance to the competent authorities in the assessment process. It deals
with myths and realities and sets out the components of human trafficking. There are three basic
components: action, means and exploitation. The means by which a person is trafficked applies only to
adult victims and not to child victims. Action means recruitment, transportation, transfer, harbouring or
receipt of a victim or victims. The means are the threat or use of force, abduction, fraud, deception, the
abuse of power or of a position of vulnerability and the giving or receiving of payments or benefits.
Apparent consent is irrelevant if one of those means have been used. The 'means' element is irrelevant for
a child victim because children cannot give informed consent.

14. As the application of the Guidance is key to this case I set out those parts that have been specifically
drawn to my attention (references are to the internal page numbers of the Guidance):

“A potential victim of trafficking who may have been a victim as a child, but only identified and referred into
the NRM after reaching adulthood is treated under child criteria in assessing whether they were trafficked.
The practical effect of this is that they do not have to meet the means test. [32 of 129]”

“Psychological coercion refers to the threat or the perceived threat to the victim's relationships with other
people. Examples of psychological coercion include: blackmail ….


-----

There does not necessarily have to be a direct personal relationship in psychological coercion. It could
refer to wider issues, for example social stigma. This is particularly relevant in cases involving sexual
exploitation or other forms of sexual violence.

Other examples include:

- grooming - where vulnerable individuals are enticed over time to take part in activity in which they may
not be entirely willing participants (for example, a trafficker may present themselves as a 'boyfriend' in a
sexual exploitation case)

- 'Stockholm syndrome' - where due to unequal power, victims create a false emotional or psychological
attachment to their controller.

In both of these examples the individuals can often first appear to be 'willing participants'. Due to their age
and dependent status, children are especially vulnerable to physical and psychological coercion ……

There are also more complex cases where victims have been trafficked and subjected to exploitation in
their own countries, and after escaping their situation travel to the UK to continue working in similar
industries without such obvious control over movement or freedom.

An example of this may be where a child has been sexually exploited in their home country and then
travels to the UK as an adult to work in prostitution. At first it may appear the individual is a willing
participant, but you must consider any progression of control and coercion when you make your decision.

[33 of 129]

In cases of potential child victims, you must remember that it is not possible for a child to give informed
consent, so you do not need to consider the means used for the exploitation - whether they were forced,
coerced or deceived etc. You must also keep in mind the child's:

- added vulnerability

- developmental stage

- possible grooming by the perpetrator” [44 of 129]

15. The Guidance also gives assistance on the assessment of credibility when making either a reasonable
grounds or a conclusive grounds decision. It provides as follows [97 of 129]:

“Competent Authorities are entitled to consider credibility as part of their decision-making process at both
the reasonable grounds and conclusive grounds stages. When Competent Authority staff are assessing the
credibility of an account, they must consider both the external and internal credibility of the material facts.

If they fit the definition of human trafficking or modern slavery, there is reliable supporting evidence and
the account is credible to the required standard of proof, the Competent Authority should recognise the
person as being a victim of human trafficking or modern slavery.

In cases of child trafficking, the Competent Authority must keep in mind the child's:

- added vulnerability

- developmental stage

- possible grooming by the traffickers and modern slavery facilitators

Assessing credibility: material facts

In assessing credibility, the Competent Authority should assess the material facts of past and present
events (material facts being those which are serious and significant in nature) which may indicate that a
person is a victim of human trafficking or **_modern slavery. It is generally unnecessary, and sometimes_**
counter-productive, to focus on minor or peripheral facts that are not material to the claim.

The Competent Authority should assess the material facts based on the following:

- are they coherent and consistent with any past written or verbal statements?


-----

     - how well does the evidence submitted fit together and does it contradict itself?

    - are they consistent with claims made by witnesses and with any documentary evidence submitted in
support of the claim or gathered during the course of your investigations?

Where there is insufficient evidence to support a claim that the individual is a victim of modern slavery (for
example where the case is lacking key details, such as who exploited them or where the exploitation took
place) staff at the Competent Authority are entitled to question whether the reasonable grounds or
conclusive grounds threshold is met. However, you must also consider whether you need more
information.” [97-98 of 129]

16. At 101 of 129, the Guidance provides that the competent authority must give due weight to the reports
and views of any organisation supporting the individual and must take into account any medical reports
submitted, particularly those from qualified health practitioners. When considering expert reports the
experience and qualifications of the expert will be relevant in relation to weight but if there are “clear, robust
reasons” why the reasonable or conclusive grounds test is not met, there is no requirement to accept the
assessment of an expert report simply because it states the reasonable or conclusive grounds test is met.
As a matter of fairness, the Guidance provides that any interviewer must ensure that all significant
inconsistencies are put to the applicant at interview [116 of 129].

The Preliminary Issue

17. It is common ground that the usual or Wednesbury (Associated Provincial Picture Houses Ltd v Wednesbury
_Corp. [1948] 1 KB 223)_ grounds of judicial review apply: the issue is whether the decision of the competent
authority was unlawful or _Wednesbury_ unreasonable. The dispute arises over whether the court should simply
scrutinise the decision of the competent authority or subject it to a higher level of such scrutiny known as 'anxious
scrutiny'. What this means was set out by Carnwath LJ in R (YH) v Secretary of State for the Home Department

_[2010] EWCA Civ 116 at [24] when he said_

“ …. the expression in itself is uninformative. Read literally, the words are descriptive not of a legal principle
but of a state of mind: indeed, one which might be thought an 'axiomatic' part of any judicial process,
whether or not involving asylum or human rights. However, it has by usage acquired special significance as
underlining the very special human context in which such cases are brought, and the need for decisions to
show by their reasoning that every factor which might tell in favour of an applicant has been properly taken
into account. I would add, however, echoing Lord Hope, that there is a balance to be struck. Anxious
scrutiny may work both ways. The cause of genuine asylum seekers will not be helped by undue credulity
towards those advancing stories which are manifestly contrived or riddled with inconsistencies.”

He had earlier said, at paragraph [12], that the 'anxious scrutiny' principle meant that the benefit of any
realistic doubt will be given to the claimant.

18. Cranston J. further expanded upon this in R (BG) v SSHD [2016] EWHC 786 (Admin) at [56]-[59] when
he said “…. anxious scrutiny does not mean that the court “should strive by tortuous mental gymnastics to
find error in the decision under review when in truth there has been none” ….. what a competent authority
must do in this type of case is to take into account relevant considerations expressly identified in the
policies as well as those which, albeit not expressly identified, are obviously material to a person's case.”
Another way of looking at it is to say that the more significant the right interfered with or the more serious
the consequences for the claimant the more cogent will be the justification required for the interference, to
borrow a phrase from Lord Sumption in a 2014 lecture.

19. There are, of course, no immediate consequences for the claimant as a result of the competent
authority's decision; however, I recognise that the decision is likely to have had a significant impact on her
subsequent, failed application for asylum. However, in my judgment it is not necessary for me to
determine whether there is a meaningful difference between mere scrutiny of a decision or anxious
scrutiny, or whether the latter is the appropriate test in this case. I am content to subject the decision to
anxious scrutiny by which I mean I shall adopt the approach set out by Carnwath LJ (as he then was) as


-----

further explained by Cranston J and consider whether the competent authority showed, by its reasoning,
that every factor in the claimant's favour was considered.

**The Conclusive Grounds Decision**

20. The competent authority concluded that the claimant's account was incredible and consequently found
that she was not a victim of trafficking. The reasons given for finding the claimant to be incredible were
(the term used by the decision maker is it inconsistent' but it is plain that on some occasions she means
implausible) :

i) despite being in an on/off relationship with Marko for over 11 years the claimant did not know his
surname date of birth or any details of his family;

ii) the claimant's allegations that her sexual relationship with Marko became consensual after eight months
with no further physical abuse was inconsistent with her statement that he had raped her for three years
and physically abused her by burning her face with cigarettes throughout that period;

iii) the claimant's account that Marko was following her and would not leave her alone was inconsistent
with her statement that she entered a consensual sexual relationship with him both in 2010/2011 and in
2015;

iv) the claimant's account that she lived with her husband and his parents was inconsistent with the Family
Certificate records from Albania which indicated that the claimant lived only with her husband and her son;

v) the Albanian Border and Migration Department records show that the claimant's husband only left
Albania once for the three days in November 2014 which was inconsistent with her claim that he lived
largely abroad and was rarely in Albania;

vi) despite originally refusing to move to Italy with Marko because she did not wish to bring shame upon
her family, taking her 15-year-old brother with her made her departure acceptable in some unspecified
way;

vii) it was inconsistent to wish to start a new life with her boyfriend, Marko, yet wish to take her young
brother with her as the latter would be a tie to her family and her past life and be a financial burden;

viii) the claimant asserted that she left Albania on 5 July 2015, but information supplied by the Albanian
authorities indicated that she left on 5 August 2015;

ix) it appeared implausible that, after an 11-year relationship, including some months in France living
happily together, Marko should suddenly force the claimant into prostitution;

x) while subject to enforced prostitution there was a significant inconsistency between an assertion that
the claimant was confined to her own room and that of her son but also able to use other facilities such as
the kitchen;

xi) the claimant's account of severe restriction was inconsistent with being allowed to depart
unaccompanied with a client on a regular basis and being able to take a four-year-old child with her on
such occasions. Her explanation that she was allowed to take her child because he cried in her absence or
that the client paid extra to allow her to bring her child with her was implausible as he was primarily paying
for her sexual services and a four-year-old child was a potential hindrance to such services.

**The Grounds**

21. The only ground on which the claimant relies is that the defendant's decision that the claimant is not a
victim of trafficking is unlawful and/or unreasonable and/or irrational on the following basis:

i) the defendant's assessment of the claimant's credibility is not lawful given the approach to assessing
credibility as set out in the Guidance and given the information provided by the claimant;

ii) the defendant's decision is irrational as it concludes that the information from Hestia does not provide
any mitigating reasons in terms of the claimant's credibility


-----

However, the claimant now seeks permission to rely on an additional ground and that is the decisionmaker's failure to put the information received from the Albanian authorities to the claimant before reaching
her decision.

**Decision**

22. The claimant asserts that the defendant failed to take into account the fact that Marko started to abuse
her when she was a child and therefore fails to apply the relevant parts of the Guidance. The Guidance, it
is said, requires the case to be assessed as if the claimant were a child therefore matters such as
additional vulnerability, developmental stage and possible grooming need to be expressly considered, at
least as far as her account of her relationship with Marko as a child is concerned. The decision maker also
failed to consider whether there was a progression of control and coercion into adulthood arising out of
Marko's childhood exploitation of the claimant. It is also asserted that the defendant failed to consider the
claimant's vulnerability to grooming or Stockholm syndrome in considering the claimant's credibility. The
decision maker failed to follow the approach laid down in The Queen (on the application of) FK v Secretary
_of State for the Home Department [2016] EWHC 56 (Admin) at paragraph [27] which provides: “Given the_
_nature of the Guidance, and the level of detail that it provides in relation to the consideration of credibility_
_and trafficking claims, a high standard of reasoning is required from the competent authority in order to_
_demonstrate a careful and conscientious analysis of the relevant factors which have to be taken into_
_account when assessing credibility.”_

23. During submissions Ms Robinson expressly abandoned any reliance on Stockholm syndrome but
relied on a progression of control and coercion which started when Marko sexually exploited the claimant
as a child. She says that the decision doesn't acknowledge such a progression. It seems to me that a large
part of the claimant's case is that because it is said she was subject to sexual abuse as a child she must be
believed about this in the light of her added vulnerability, stage of development and possible grooming so
that nothing more is required. It must be assumed that, notwithstanding the significant breaks in the
relationship between the claimant and Marko and the implausibility of her accounts of subsequent events,
the reason she left Albania with him was because he was continuing to exercise control over her.

24. In my judgment there is no evidence to support a contention that the claimant was groomed by Marko
for the purposes of sexual exploitation beyond his own personal gratification. There is no suggestion that
he was grooming her for a life of prostitution; indeed, the claimant's own case is that she was blackmailed
in France. In any event, the claimant does not appear to have been under Marko's control after his first
departure as, following a brief affair, it was the claimant who ended the relationship in 2011. Further, the
reasons given by her for refusing to go with Marko initially and then later agreeing to go negate such a
suggestion, as the decision maker found. It was open to her to make that finding on the evidence. Absent
any factual basis for a claim that Marko was grooming the claimant for prostitution from the outset or during
childhood, it does not seem to me that the decision maker was obliged to consider such a scenario. The
situation may have been different had there been a continuous relationship between the claimant and
Marko with him exercising control over her actions or decisions.

25. I do not accept that the decision maker incorrectly approached the question of the credibility of the
alleged sexual exploitation of the claimant as a child. The tailored parts of the Guidance go to the issues of
the components of child trafficking and the assessment of the credibility of children. I agree with Mr Staker,
that the claimant is attempting to conflate these two separate elements of the Guidance. The claimant was
not trafficked as a child and was not interviewed as a child. Her credibility was properly assessed as an
adult. The decision maker recognised that, if trafficking started when the claimant was a child, the 'means'
element would have been irrelevant. However, the decision maker disbelieved the whole of the claimant's
account therefore the 'means' element was irrelevant in any event. Neither is this a complex case of the
type envisaged by the Guidance where a child is sexually exploited and forced into prostitution as a child
and then continues that occupation, apparently of his or her own volition, as an adult. Indeed, it is the
essence of the claimant's case that she did not voluntarily act as a prostitute nor, if it were relevant, is there
any suggestion that she did so voluntarily after leaving France.


-----

26. The decision maker acknowledged that Marko had been in a relationship with the claimant over a
period of 11 years albeit on an on/off basis. Reading the decision letter fairly, as a whole, I am not satisfied
that the decision maker fell into error by assuming that there could have been no exploitation by reason of
Marko being the claimant's boyfriend; on the contrary, the decision maker based her decision on specified
inconsistencies and implausibility of the claimant's account.

27. In my judgment the decision maker correctly identified the task and set out the relevant principles in the
decision letter. The decision maker also correctly set out the Guidance in relation to credibility at the outset of her
decision. She plainly had in mind the fact that some of the events allegedly occurred during the claimant's
childhood as she recognised that the 'means' by which the claimant was said to be a victim of trafficking was
irrelevant or inapplicable. The reality is that the decision maker simply didn't believe anything the claimant said to
her.

28. The inconsistencies and implausibility relied upon are not attributable to delayed disclosure or
incoherence but on the claimant's coherent account offered during her two interviews. The decision is not
irrational on this basis and the conclusion was open to the decision maker on the evidence.

29. It is also said that the decision is irrational because it asserts that the information from Hestia, the
organisation providing support to the claimant, did not provide any mitigating reasons in relation to the
claimant's credibility. That letter was written in July 2016. As far as is material, it reads as follows:

“[The claimant] presents as a traumatised person who is unwilling to discuss her previous experiences.
Due to this she has decided not to proceed with counselling. When she does divulge information regarding
her experiences she becomes distressed and displays common signs of trauma in victims of human
trafficking.

…..

[The claimant] presents as a vulnerable person from my observations during key sessions, anxious to put
her past behind her.”

30. The Hestia letter was expressly referred to by the decision maker in the decision letter and is recorded
as part of the material which she read. While that letter refers to the claimant's distress when she was
prepared to disclose some information, which was consistent with being trafficked, it also stated that the
claimant was unwilling to discuss her experiences. While that may have been the case as far as
counselling is concerned, the claimant was plainly willing to give detail, and did give such detail, in her
interviews. Her unwillingness to talk and her distress with her counsellor did not go to the credibility of
what she in fact said to the interviewers therefore it was open to the decision maker to decide that the
Hestia letter did not address or mitigate the claimant's lack of credibility. In accordance with the Guidance
the decision maker gave “clear, robust reasons” why the conclusive grounds test is not met. The decision
maker's conclusion was clearly open to her on the material before her and I am satisfied that she
considered all relevant matters. The application fails on this basis also.

31. I will give permission to the claimant to rely on her additional ground namely the failure to put the
material from the Albanian authorities to the claimant before reaching her decision. As set out above the
Guidance provides that “all significant inconsistencies are put to the applicant at interview”. The complaint
is that two matters were not put to the claimant: the first is the inconsistency between her stated date of
departure from Albania and the date recorded by the Albanian authorities. The second is the difference
between claimant's account of living with her parents in law and the Albanian authorities' information which
suggested that she lived only with her husband and her son.

32. I agree with Mr Staker that the decision maker does not appear to have placed any reliance on the
different dates of departure from Albania that have been given. In my judgment, a small inconsistency such
as this is highly unlikely to have made any difference to the decision which was based on more substantial
matters. While the decision maker did appear to rely on the difference between the claimant's account of
her living arrangements in Albania and those provided by the authorities this inconsistency does not
appear to me to be determinative or to have had a significant impact on the outcome. If one removes both


-----

those items from the list of inconsistencies and implausibility there would still be ample material on which
the decision maker could have reached her conclusion. Accordingly, the application fails on this basis
also.

**End of Document**


-----

