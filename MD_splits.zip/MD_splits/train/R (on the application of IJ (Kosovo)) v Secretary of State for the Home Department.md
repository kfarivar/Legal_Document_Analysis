# R (on the application of IJ (Kosovo)) v Secretary of State for the Home
 Department [2020] EWHC 3487 (Admin)

Queen's Bench Division, Administrative Court (London)

Bourne J

18 December 2020Judgment

Alex Goodman (instructed by Duncan Lewis) for the Claimant

Zane Malik (instructed by the Government Legal Department) for the Defendant

Hearing date: 25 November 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Bourne :**

_Introduction_

1. The Claimant, a citizen of Kosovo, has now been determined to be a victim of trafficking and a refugee.
Her claim arose, and permission for it was granted, when her asylum claim was still being considered by
the Defendant. By a condition imposed on her under Paragraph 360A of the Immigration Rules, she was
not permitted to take up employment in a post that fell outside the Shortage Occupation List (“SOL”). By a
decision made on 2 January 2020, the Defendant refused to exercise her residual discretion outside the
Immigration Rules to allow the Claimant to take up employment in a post as a cleaner that would fall
outside the SOL.

2. The claim challenges the lawfulness of (1) the Defendant's decision(s) maintaining the SOL condition,
(2) the Defendant's relevant policy guidance and (3) rule 360A itself, on the basis that these are or were
not in accordance with ECHR Articles 4 and/or 8 read with Article 12 of the Council of Europe Convention
on Action against Human Trafficking (“ECAT”) and associated law and guidance, and or infringed common
law principles of clarity and transparency and/or discriminated against trafficking victims contrary to Article
14 ECHR in conjunction with Articles 4 and/or 8.

3. After the hearing but before judgment in the present case, Mostyn J gave judgment in R (EOG) v SSHD

_[2020] EWHC 3310 (Admin). He decided, having regard to ECAT Article 10 (referred to at [11] below) and_
to the delays which are endemic in the NRM process, that the Defendant's policy on discretionary leave
contains an unlawful lacuna by not providing for any grant of discretionary leave to remain on an interim
basis to those who have received a reasonable grounds decision but, as yet, no conclusive grounds
decision (or grant of asylum). The lacuna had particular impact on the claimant in that case because she
had a time-limited visa which permitted her to work but, on its expiry, became subject to the prohibition on
working pending a further decision.

4. I indicated that the parties were free to make any supplemental submission on that case if so advised. I
received concise submissions from Mr Goodman, to which I have had regard as appears below.


-----

_The facts_

5. The essential facts are as follows:

i) The Claimant, who was born on 31 December 1984, was trafficked to the UK on 31 December 2017.

ii) On 9 March 2018 the Claimant, having come to the attention of the Defendant, was detained.

iii) On 19 March 2018 a decision was made that there were no reasonable grounds to regard her as a
victim of trafficking.

iv) On 23 March 2018 she made a claim for asylum.

v) On 10 September 2018 the Defendant promulgated a policy (which has since been declared unlawful)
that if an alleged victim of trafficking claimed asylum, their application for Discretionary Leave to Remain as
a victim of trafficking would not be determined until after their asylum claim.

vi) On 6 March 2019 the Claimant issued a civil claim against the Defendant and Bedfordshire Police
relating to her detention, the failure to identify her as a victim of trafficking and associated breaches of her
data rights and human rights.

vii) On 7 March 2019 a decision was made that there were reasonable grounds to regard her as a victim of
trafficking.

viii) On 10 May 2019 she requested permission to take up a non-SOL offer of employment (a request
subsequently reiterated and refused from time to time in the form of bail conditions from 15 May 2019
onwards, leading to a judicial review claim which was compromised on the basis that the refusal would be
reconsidered).

ix) On 2 January 2020 the Defendant made the decision under challenge, again refusing permission for
the Claimant to work outside the SOL, on the basis that her circumstances did not distinguish her from
other asylum seekers.

x) This claim was issued on 2 April 2020. Pepperall J granted permission on 5 June 2020.

xi) On 14 July 2020 the Defendant (1) decided that there were conclusive grounds to regard the Claimant
as a victim of trafficking, but (2) refused to grant her discretionary leave to remain in the UK on the grounds
that her asylum claim was outstanding.

xii) On 5 October 2020 the Defendant granted the Claimant asylum as a refugee. She was granted a work
permit on 13 October 2020.

_Is the claim academic?_

6. Since about 7 weeks before the hearing, the Claimant has ceased to be subject to the rule/policy under
challenge and so no longer seeks practical relief from its effects. The change in her circumstances gave
rise to an interlocutory application on her behalf to modify the grounds and to adduce some further
evidence. Shortly before that was to be dealt with on paper, the Defendant indicated a wish to rely on a
contention that the claim was now academic and requested an order that today's hearing be confined to
that question.

7. These matters came before Lieven J who, on 9 November 2020, declined the invitation to limit today's
hearing to the question of whether the claim is academic, while observing that that issue could be raised at
this final hearing.

8. In the event, and given that the substantive arguments have been fully aired, Mr Malik on behalf of the
Defendant no longer seeks to persuade me not to deal with the substantive case.

9. In those circumstances I will proceed to the substantive issues. It would in any event have been my
view that the questions in the case are of some importance and must affect a significant number of
individuals, whether or not other judicial review cases are believed to be pending. Also, the Court granted
permission in the knowledge that the claim could be rendered academic at any time, at least for the


-----

Claimant, by a grant of asylum. At that stage the Court could have postponed the determination of the
claim until after a final decision on asylum but did not do so.

_Legal framework_

10. The UK is a party to ECAT, an international Treaty ratified in 2008. It has been administratively
implemented in the UK by a process for identifying and supporting victims of trafficking known as the
National Referral Mechanism (“NRM”). The Defendant has published policies which are intended to give
effect to the UK's ECAT obligations. Therefore the correct implementation of those policies is justiciable,
although ECAT has not been incorporated into domestic law: see PK Ghana [2018] 1 WLR 3955.

11. Article 10.2 of ECAT provides:

“Each party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other parties and relevant support organisations. Each party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in article 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in
article 12, paragraphs 1 and 2.”

12. When a person is referred to the NRM as a possible victim of trafficking, an assessment takes place to
determine whether there are “reasonable grounds” to consider that they may be such a victim.

13. A positive reasonable grounds decision means that the individual is entitled to a basic level of support
(“basic trafficking support”) under article 12.1 and 12.2, which provide:

“1. Each party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least: (a) standards of living
capable of ensuring their subsistence, through such measures as: appropriate and secure accommodation,
psychological and material assistance; (b) access to emergency medical treatment; (c) translation and
interpretation services, when appropriate; (d) counselling and information, in particular as regards their
legal rights and the services available to them, in a language that they can understand; (e) assistance to
enable their rights and interests to be presented and considered at appropriate stages of criminal
proceedings against offenders; (f) access to education for children.

2. Each party shall take due account of the victim's safety and protection needs.”

14. Basic trafficking support continues during a period of “recovery and reflection”. This is required by
article 13 of ECAT to be at least 30 days and in the UK has been set at 45 days. Policy guidance indicates
that the Defendant expects to make a “conclusive grounds” decision, as to whether the person is a victim
of trafficking, as soon as possible thereafter.

15. If by the end of the recovery and reflection period there has not been a conclusive grounds decision,
basic trafficking support stops. However, an individual who has also claimed asylum will be entitled to
asylum support, though the financial component of asylum support is less than that of basic trafficking
support.

16. A positive conclusive grounds decision triggers a further 45 days of basic trafficking support. It also
means that the individual will have the benefit of article 14.1 of ECAT, which provides:

“1. Each party shall issue a renewable residence permit to victims, in one or other of the two following
situations or both: (a) the competent authority considers that their stay is necessary owing to their personal
situation; (b) the competent authority considers that their stay is necessary for the purpose of their cooperation with the competent authorities in investigation or criminal proceedings.”

17. In practice, however, a residence permit may not be issued immediately, or at all, because of the
interaction between the NRM system and the asylum system.


-----

18. The “renewable residence permit” referred to in article 14, in the UK, is a grant of discretionary leave to
remain (“DLR”), usually for a period of 30 months. It is not a route to settlement in the UK, but is a
temporary arrangement to facilitate recovery from trafficking and/or co-operation with a criminal
investigation into trafficking. Under the Defendant's policy, Discretionary leave considerations for victims of
**_modern slavery, discretionary leave is to be granted when the Defendant considers it “necessary owing to_**
personal circumstances” or “necessary to pursue compensation” or, at the request of the victim or the
police, where the victim is helping police with their enquiries.

19. By contrast, a successful claim for asylum usually leads to a grant of leave to remain for 5 years, and
is a route to settlement in the UK. Meanwhile article 14.5 provides:

“… each party shall ensure that granting of a permit according to this provision shall be without prejudice to
the right to seek and enjoy asylum.”

20. It is therefore not unusual for an individual to be referred to the NRM as a possible victim of trafficking
and to seek asylum at the same time.

21. As I have said, on 10 September 2018 the Defendant published a policy under which no decision
would be made on leave to remain under ECAT until a person's entitlement to any other form of leave,
including asylum, had been determined.

22. A person who receives DLR under Article 14 is thereupon “lawfully resident” in the territory of the UK,
and thereby acquires further entitlements under Article 12:

“3. In addition, each party shall provide necessary medical or other assistance to victims lawfully resident
within its territory who do not have adequate resources and need such help.

4. Each party shall adopt the rules under which victims lawfully resident within its territory shall be
authorised to have access to the labour market, to vocational training and education.”

23. Similarly, those to whom asylum is granted are entitled to those benefits including full access to the
labour market.

24. This case concerns access to the labour market by individuals who have been referred to the NRM
and who have claimed asylum but whose cases have not yet been determined.

25. I also note that the EU in 2011 enacted a Directive on preventing and combating trafficking in human
beings and protecting its victims (Directive 2011/36/EU). It makes detailed provision about detecting
trafficking and prosecuting traffickers, as well as prevention and compensation. Article 11 of the Directive
requires “measures to ensure that assistance and support are provided to victims” before, during and for a
time after the prosecution of their traffickers. By paragraph 5, these measures:

“shall include at least standards of living capable of ensuring victims' subsistence through measures such
as the provision of appropriate and safe accommodation and material assistance, as well as necessary
medical treatment including psychological assistance, counselling and information, and translation and
interpretation services where appropriate.”

26. It is also necessary to consider the general law concerning rights to work of those who are subject to
immigration control.

27. Those not having the right of abode in the UK may live, work and settle there by permission only:
_[Immigration Act 1971 section 1(2). By section 3 of the 1971 Act, persons with limited leave to enter the UK](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y0R5-00000-00&context=1519360)_
may be made subject to conditions restricting their work and their stay in the UK may be regulated by
provision in the Immigration Rules made under section 3(2).

28. The position of those seeking asylum in the EU is addressed by Article 11 of Directive 2003/9/EC:

“1. Member states shall determine for a period of time, starting from the date on which an application for
asylum was lodged, during which an applicant shall not have access to the labour market. 2. If a decision
at first instance has not been taken within one year of the presentation of an application for asylum and this


-----

delay cannot be attributed to the applicant, Member States shall decide the conditions for granting access
to the labour market for the applicant.

3. Access to the labour market shall not be withdrawn during appeals procedures, where an appeal against
a negative decision in a regular procedure has suspensive effect, until such time as a negative decision on
the appeal is notified.

4. For reasons of labour market policies, Member States may give priority to EU citizens and nationals of
States parties to the Agreement on the European Economic Area and also legally resident third-country
nationals.”

29. This rule, whereby after one year an asylum seeker may request a right to work but is not entitled to
such a right, is given effect in the UK by Part 11B of the Immigration Rules:

“360. An asylum applicant may apply to the Secretary of State for permission to take up employment if a
decision at first instance has not been taken on the applicant's asylum application within one year of the
date on which it was recorded. The Secretary of State shall only consider such an application if, in the
Secretary of State's opinion, any delay in reaching a decision at first instance cannot be attributed to the
applicant.

360A If permission to take up employment is granted under paragraph 360, that permission will be subject
to the following restrictions:

(i) employment may only be taken up in a post which is, at the time an offer of employment is accepted,
included on the list of shortage occupations published by the United Kingdom Border Agency (as that list is
amended from time to time);

(ii) no work in a self-employed capacity; and

(iii) no engagement in setting up a business.

360B If an asylum applicant is granted permission to take up employment under paragraph 360 this shall
only be until such time as his asylum application has been finally determined.”

30. An asylum seeker who is allowed to work will therefore be restricted to jobs on the Migration Advisory
Committee's “Shortage Occupation List” (“SOL”) published by the Home Office.

31. The SOL is a list of skilled jobs, many very specialised. It includes various categories of doctors,
nurses and therapists, teachers in a few specified subjects, IT professionals, social workers, engineers,
chefs with a certain level of expertise and artists of a number of specified kinds. The Migration Advisory
Committee estimates that it covers about 1% of UK employment.

32. It seems reasonable to assume that very few if any of the individuals who come to the UK in
circumstances comparable to those of the Claimant will be able to occupy such positions. The SOL
restriction prevented the Claimant from taking up the job (as a cleaner) which she was offered.

33. The contention at the heart of the claim is that the SOL restriction and its application to the Claimant
are or were inconsistent with the requirement under ECAT Article 12 to implement “legislative or other
measures as may be necessary to assist victims in their physical, psychological and social recovery”.

_Ground 1_

34. By this ground, Mr Goodman on behalf of the Claimant contends that the Defendant's decision on 2
January 2020 (and which was maintained thereafter), was unlawful because of a failure to take account of
and/or act in accordance with material considerations.

35. The material considerations are said to be:

i) the Defendant's obligations to trafficking victims, considered in the context of the delay in dealing with
the Claimant's case;


-----

ii) a positive obligation on the Defendant to assist victims of trafficking in psychological and social
recovery;

iii) medical evidence dealing with the potential benefit to the Claimant of being able to work.

36. As to the first of these, Mr Goodman emphasizes the length of the delay. Resolving the Claimant's
case has been a lengthy process. Just about a year passed between her escape from her captors and the
“reasonable grounds” decision. The ensuing period before a conclusive grounds decision, which under
policy is “expected” to be not much more than the 45 days allowed for recovery and reflection, was over 16
months. Even then, nearly 3 more months elapsed before the grant of asylum and issue of a work permit.

37. This should also be seen in the context of this Court having declared that the policy by which a
decision on DLR is deferred until after a decision on asylum is unlawful. In R (JP and BS) v Secretary of
_State for the Home Department [2020] 1 WLR 918, Murray J held that the delay caused by that policy,_
coupled with the cessation of basic trafficking support, meant that the policy (1) was not consistent with the
United Kingdom's obligations under article 14.1 of ECAT and (2) unlawfully discriminated against those
possible victims of trafficking who were also asylum seekers.

38. As to the second consideration, Mr Goodman points to ECAT Article 12.1 and its requirement to
implement such “measures as may be necessary to assist victims in their physical, psychological and
social recovery”. After a conclusive grounds decision this is fortified by the Article 12.4 requirement for
“access to the labour market”. Mr Goodman contends that access to the labour market may, even before a
conclusive grounds decision, be a necessary “measure” and was so on the facts of this case.

39. Mr Goodman further points out that delay in the system was relevant in _EOG (see [3] above),_
contending that Article 12 underpins Ground 1 just as Article 10 underpinned the claim in EOG.

[40. Mr Goodman also refers to the Modern Slavery Act 2015 (which implements provisions of Directive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
2011/36/EU) and statutory guidance issued under it. Section 49 requires the Defendant to issue guidance
about “arrangements for providing assistance and support to persons who there are reasonable grounds to
believe may be victims of slavery or human trafficking”. That guidance was published in March 2020, after
the main decision under challenge in this case. It provides:

“Access to the labour market, vocational training and education

15.74. Adult victims are able to access the labour market, education and vocational training providing they
have an immigration status that allows them to do so.

15.75. If there is any reason why a support worker believes that the victim working would be inappropriate,
it should be clearly explained to the victim in a language they understand. However, adult victims with the
right to work are eligible to work while in the NRM. Victims with the right to work should be allowed to seek
employment.”

41. For the third consideration, and also in additional support of the second, Mr Goodman refers to the
medical evidence on which the Claimant relied in her asylum and trafficking claims and in further
representations to the Defendant. In particular:

i) A report dated 12 July 2018 by a consultant psychiatrist, Dr Wootton, diagnosed post-traumatic stress
disorder, severe depressive disorder and generalised anxiety disorder and panic disorder and found that
her symptoms were affected by being under continuing stress for reasons including having “no meaningful
activity” and “lack of finances”.

ii) A report dated 8 August 2019 by a clinical psychologist, Dr Falk, expressed the view that “a right to work
_would assist [her] recovery” and “The first step in treatment of depression, as indicated in a range of_
_psychological models of treatment (i.e. Cognitive Behavioural Therapy) and in the NICE guidelines, is_
_behavioural activation. This is the acknowledgement that being more active can have a positive impact on_
_one's wellbeing. A primary way to become more active, and also have more social contact, is through_
_work”._


-----

42. Mr Goodman also refers to medical evidence which was quoted by Murray J in JP and BS (see [37]
above) at [81] (and referred to with approval at [165]):

“… delay in granting ECAT leave (or some other form of leave to remain) to a victim of trafficking makes it
much more difficult for the victim to engage fully in and thereby benefit from trauma-focused work.

[Professor Katona] considers that 'prolonged indefinite uncertainty of waiting for a decision is also clinically
distressing and destabilising' and that the inability of a victim of trafficking, without some form of leave to
remain, to work or study:

'… can increase survivors' social isolation which is further aggravated by the difficult financial
circumstances in which they have to subsist pending the conclusion of the NRM identification process.
Even in circumstances where survivors receive some emotional support through the NRM, they
nonetheless cannot lead full and free lives and are constrained economically, which increases stress and
can increase vulnerability to further exploitation. All these factors can contribute to prolonged mental ill
health and worsen long-term prognosis. This may in turn impede their ability to give evidence, either in
their own immigration cases, for the purpose of accessing their legal rights and entitlements, or in providing
witness evidence for police investigations.'”              (emphasis added)

43. The decision letter of 2 January 2020 described itself as “a grant of permission to work in principle” but
recited that “employment is restricted to posts listed on the [SOL list]”. It noted that a request had been
made for an exercise of discretion outside the Immigration Rules on the basis that the Claimant was a
victim of trafficking, that she had mental health issues and that work would assist her recovery and make
her less vulnerable.

44. The letter referred to statistics about the incidence of mental health issues among victims of trafficking
and asylum seekers generally, and drew the conclusion:

“Taking these statistics into account, whilst it is noted that being a VoT and having mental health issues is
a distressing situation this is not sufficient to distinguish you from other asylum seekers awaiting a decision
on international protection claims. Over half of those in the 2009 survey above [relating to refugees] were
'likely to have PTSD', one in five reported suicidal thoughts and more than one in five asserted that they
had attempted suicide. The 2015 study above [relating to trafficked young people] highlights that over half
of those studied were 'positive for depression', one in three had 'anxiety disorder' and approximately one in
four had PTSD. More than one in ten had suicidal thoughts or had attempted suicide. Therefore,
distressing as your situation is, this does not distinguish you from any other asylum seeking applicant who
asserts they are a VoT.”

(emphasis added)

45. The letter pointed out that vulnerability to being taken advantage of could also be addressed by doing
voluntary work. It asserted that “the SOL is not discriminatory and is rational, proportionate and lawful”, and
concluded:

“… whilst the Official acting on behalf of the Secretary of State has given careful consideration as to
whether it is appropriate to exercise discretion in your case and give PTW outside of the SOL, it is
considered that you have not evidenced that your circumstances are distinct from those of a large number
of asylum seekers in the UK”. In all the circumstances, it is not appropriate to exercise discretion in your
case. Your personal circumstances, including the fact that there are reasonable grounds of believe [sic]
that you are a victim of trafficking, your mental health issues and delay in making a decision on your
asylum claim, when considered in the round, do not justify departure from the usual position and the
exercise of residual discretion in your favour.”

(emphasis added)

46. Mr Goodman submitted that this conclusion was irrational. In noting the submission that employment
would assist the Claimant's recovery, it disregarded the fact that she had a right under ECAT article 12 to
be assisted in her recovery. It wrongly considered whether she had distinguished herself from a sub

-----

category of victims of trafficking, rather than from asylum seekers generally. It wrongly applied a “bright
line” rule instead of correctly exercising a discretion.

47. In the alternative, Mr Goodman submits that the decision was, for the same reasons, a
disproportionate breach of the Claimant's right to respect for her private life under ECHR Article 8. He
[prays in aid Lutalo [2011] EWHC 2042 (Admin), in which this Court held that restrictions on a right to work](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53G6-J7C1-F0JY-C07C-00000-00&context=1519360)
are in principle capable of amounting to an interference with an individual's Article 8 rights.

48. Mr Malik submitted, first, that rule 360A and the SOL arrangements are lawful. He relied in particular
on the judgment of Hickinbottom J in _R (Rostami) v Secretary of State for the Home Department [2013]_
_EWHC 1494 (Admin). There it was held that asylum seekers have no general right to work. The SOL, the_
Court ruled, has the public policy objective of ensuring that asylum seekers are granted access to the
labour market without adversely impacting on UK and other EU citizens, and does not offend against the
EU principle of proportionality. The Judge said at paragraph 92(iv-vi) that in the policy area in the scope of
immigration, social benefits and economic strategy the State has a wide margin of appreciation, that a
measure will not be regarded as disproportionate unless it is “manifestly inappropriate” and that “bright line”
rules are generally acceptable.

49. It is also notable that Hickinbottom J held at 92(xii):

“Leaving aside the obvious financial benefits that accrue from employment, I do not find that the inability to
work, in itself, has had any significant adverse effect on the Claimant, or on asylum seekers as a whole.
He, and they, suffer from low income and generally being in limbo, during consideration of their asylum
applications; but not specifically from an inability to work. There is no compelling evidence that the
Claimant, or asylum seekers generally, suffer to any significant extent by an inability to make social contact
through work.”

50. Hickinbottom J also rejected the suggestion that the SOL rule offends against ECHR Article 8. He
followed the decision of the Court of Appeal in R (Negassi) v Secretary of State for the Home Department

_[2013] EWCA Civ 151, which ruled (at [38] per Maurice Kay LJ) that Article 8 does not embrace “the right_
_of a foreign national, who has no Treaty, statutory or permitted right of access to the domestic labour_
_market, to an entitlement to work”._

51. So, Mr Malik submitted, the Defendant could simply have applied rule 360A. In fact she went further
and considered whether to exercise her residual discretion in the Claimant's favour. The decision letter
shows that regard was had to the considerations which the Claimant relied on. It cannot be said that the
decision reached was not open to the Defendant.

52. In my judgment the decision letter clearly shows that regard was had to the effects of delay and to the
Claimant's mental health issues. As Mr Malik submitted, the weight to give to each factor was for the
Defendant to decide. The decision was not irrational in the sense of being one which no reasonable
decision maker could have reached.

53. Nor did the Defendant unlawfully fetter her discretion. It is clear that rule 360A was not treated as a
“bright line” rule. Instead the Defendant rightly recognised that the individual case could be considered on a
discretionary basis.

54. Nor, in my judgment, can it be said that the Defendant wrongly directed herself on the effect of ECAT
article 12. It seems to me that in the letter, read in context, the Defendant did effectively ask herself
whether the “measure” of an unrestricted permission to work was “necessary to assist [the Claimant] in

[her] physical, psychological and social recovery”.

55. It is significant that it is article 12.4 which concerns access to the labour market. That paragraph has
effect only in relation to those who have received a residence permit following a positive “conclusive
grounds” decision: see JP and BS at [27-29] per Murray J. Even then, the obligation of the State under that
paragraph is only to “adopt the rules under which victims lawfully resident within its territory shall be
authorised to have access to the labour market”.


-----

56. Accordingly, I do not accept that ECAT imposes a positive obligation to afford access to the labour
market in favour of a person who has received a positive “reasonable grounds” decision but, as yet, no
conclusive grounds decision. It follows that the Defendant in making her decision did not err by failing to
have regard to such an obligation. In that respect the case is different from EOG, where it was held that the
Defendant's policy did not properly implement the rights of those in receipt of a reasonable grounds
decision.

57. I also do not consider that the decision maker failed to understand and to take into consideration the
Claimant's contention that she as a victim of trafficking was in a situation which was distinct from that of
asylum seekers generally. Admittedly the language used in the passages quoted and emphasized at [42]
and [44] above does refer to the questions both of whether her circumstances were distinguishable from
those of other asylum seekers generally and of whether they were distinguishable from those of other
potential victims of trafficking who were claiming asylum. Overall, however, it is clear that the first of those
two questions was asked and answered.

58. Applying Rostami, the decision also did not appear to engage ECHR Article 8 (notwithstanding what is
said about the “ambit” of Article 8 under Ground 3 below), but in any event, for all of the foregoing reasons,
the decision did not infringe it.

59. In submissions following the circulation of this judgment in draft, Mr Goodman suggested that Ground
1 should nevertheless succeed to the extent that, after the conclusive grounds decision of 14 July 2020,
the failure to grant an unrestricted permission to work continued until 13 October 2929, just after the grant
of asylum. That, however, was not the pleaded Ground 1, and could not have been, because the claim was
issued around 3 months before the conclusive grounds decision. This claim was not argued as a challenge
to a decision, policy or practice of withholding unrestricted permission to work for the period between a
conclusive grounds decision and an asylum decision. Such a challenge would require consideration of the
effect of article 12.4 of ECAT in between a conclusive grounds decision and an ensuing grant of a
residence permit. That, as I have said, is outside the scope of Ground 1.

_Ground 2_

60. It is common ground that in spite of the mandatory terms of rule 360A which provide that any
permission to work “will” be subject to the SOL restriction, the Defendant nevertheless has a residual
discretion to consider granting a wider permission to work in individual cases. That discretion is
acknowledged, and applied, in the decision letter of 2 January 2020.

61. Ground 2 complains that the Defendant's published policy does not acknowledge this discretion or
explain how it is to be applied.

62. The current policy, which is used to provide guidance to caseworkers, is entitled Permission to work
_and volunteering for asylum seekers, Version 8.0. The relevant passage simply states the mandatory rule_
in these terms:

“If an asylum seeker or failed asylum seeker is granted permission to work (subject to the exceptions listed
in the section on Applications from asylum seekers with existing leave), this must be restricted to jobs on
the Shortage Occupation List (SOL), published by the Home Office.”

63. Mr Goodman points out that the present case illustrates the potentially misleading effect of this policy.
It was applied to the Claimant on 24 May 2019 in a decision which stated that there was “no scope” for
non-SOL employment. In a pre-action protocol response letter on 23 August 2019, it was claimed on behalf
of the Defendant that “there is no discretion in the policy”. The contrary was accepted only after judicial
review proceedings had been issued.

64. In the present case, Mr Goodman contends, the decision maker appeared to apply a test of whether
the Claimant could distinguish her case from that of other asylum seekers, but there is no published
guidance or instruction which states that this is the right test or guides caseworkers on how to apply it.

65. Mr Goodman places reliance on R (W, a child) v Secretary of State for the Home Department [2020]
_EWHC 1299 (Ad_ _i )_ [2020] HRLR 12 hi h d th l f l f bli h d i t ti t


-----

caseworkers on the policy of granting leave to remain in the UK on condition that the application have “no
recourse to public funds” (“NRPF”).

66. The case is potentially useful in two ways. First, the Divisional Court noted at [37] that the Immigration
Rules (which under section 21(f) of the Human Rights Act 1998 are treated as subordinate legislation for
the purposes of that Act) must be read and given effect in a way which is compatible with ECHR rights or, if
and to the extent that that is not possible, the Defendant must ignore them. Second, the test in a challenge
to guidance, as stated at [57], is whether there is a real risk that in “a significant number of cases” the
application of the guidance will lead to a breach of ECHR rights or some other rule of law.

67. In W the Court ruled that the instructions failed to make clear that, to avoid a breach of ECHR Article 3,
a NRPF condition must not be imposed or it must be lifted where, on the available evidence, the applicant
was at imminent risk of destitution. Instead it merely indicated that caseworkers had a discretion which
could be applied in such a case. That gave rise to a real risk of unlawful decisions in a significant number
of cases.

68. Mr Goodman also places reliance on PK Ghana (see [10] above). There the Court of Appeal quashed
policy guidance which provided that a victim of trafficking should be granted DLR if his or her personal
circumstances were “compelling”. This failed to reflect the obligation under ECAT article 14 to grant a
residence permit to a person if it was “necessary owing to their personal situation”. In particular it failed to
identify the purpose for which the stay was “necessary” in accordance with the objectives of ECAT,
creating a risk that decision makers would apply a threshold higher than that required by ECAT.

69. Hickinbottom LJ in PK Ghana ruled that the relevant objective of ECAT, expressed in its preamble and
article 1, in the case of PK was “the protection and assistance of victims of trafficking”. Article 14 of ECAT
required a decision maker to assess whether the grant of a residence permit was necessary for that
objective (or any other primary objective stated in ECAT).

70. Mr Goodman submits that the guidance in the present case is even more inadequate. It does not
acknowledge the existence of a discretion at all, although the existence of one has been admitted. It
provides no guidance on how to apply the discretion. Still less does it explain that a discretionary decision
granting permission to work outside the SOL is required if it is a “measure” which is “necessary to assist
victims in their physical, psychological and social recovery” as per ECAT article 12, and that what is
“necessary” must be identified in light of the primary objectives of ECAT, as in PK.

71. Mr Malik relies on R (Munir) v Secretary of State for the Home Department [2012] 1 WLR 2192and R
_(Thebo) v Entry Clearance Officer [2013] EWHC 146 (Admin) for the proposition that, when a provision of_
the Immigration Rules is framed in mandatory terms, it is acceptable for the Defendant to retain a residual
discretion to decide cases outside the rule as a safety net for cases which would otherwise be too harsh.

72. Mr Malik also points to _Gurung v Secretary of State for the Home Department [2013] EWCA Civ 8,_
where the Court of Appeal upheld the lawfulness of a policy which provided that a particular category of
adult children of Gurkha military veterans would not normally be granted discretionary permission to settle
in the UK, but that discretion might be exercised in “exceptional circumstances”. Lord Dyson explained that
this did not lead to unacceptable legal uncertainty and said at [22]:

“It is inherent in any policy which permits a departure from a general rule in exceptional circumstances that
there may legitimately be scope for different views as to whether there are exceptional circumstances on
the facts of a particular case. There is implicit in the exercise of any discretion the risk that different
decision-makers can legitimately make different decisions on what appear to be indistinguishable facts.
The range of reasonable (and therefore legitimate) responses may be wide. This is the inevitable
consequence of giving a decision-maker a discretion. But that does not mean that a discretionary rule or
policy is unlawful on grounds of uncertainty.”

73. Mr Malik distinguishes the case of PK Ghana on the ground that it concerned ECAT article 14 which
imposes a mandatory requirement, whereas this case concerns article 12, which does not.


-----

74. In this case, Mr Malik submits, one sees the application of a real and effective residual discretion.
Although it was not exercised in the Claimant's favour, it nevertheless showed that individual cases are
assessed on their merits, according to a Claimant's circumstances, as ECAT requires.

75. In my judgment, the Defendant's response does not really meet the Claimant's objection. The parties
agree that in deciding what if any permission to work can be given to a potential victim of trafficking, it is
necessary for the decision maker to exercise a discretion on the individual facts rather than applying the
“bright line” rule stated in paragraph 360A of the Immigration Rules. In those circumstances, as Mr
Goodman says, the lack of any reference to the discretion obviously makes the guidance misleading.

76. I also accept Mr Goodman's submission that in applying the discretion, the decision maker must have
regard to the primary objectives of ECAT. As in the case of _PK Ghana, caseworkers should be directed_
accordingly. I do not agree with Mr Malik's submission that any difference between articles 12 and 14 of
ECAT makes PK distinguishable. Article 12 requires that the State “shall adopt” the necessary measures,
while article 14 requires that the State “shall issue” a permit if it considers it necessary1.

77. Guidance on article 12 therefore will be unlawful if it creates a real risk of unlawful decisions being
made in a significant number of cases. The present lack of clear and focused guidance, in my judgment,
creates that risk.

78. Ground 2 therefore succeeds, and there will be a declaration that the guidance is defective because it
does not identify the discretion or the ECAT objectives which are relevant to its exercise. How that defect is
rectified will be a matter for the Defendant.

_Ground 3_

79. By Ground 3 the Claimant contends that (1) the framework of rule 360A and the guidance and (2) the
decision in her case unlawfully discriminated against her, contrary to ECHR Article 14 in conjunction with
Article 4 and/or Article 8.

80. The alleged discrimination is of the kind identified by the ECtHR in Thlimmenos v Greece [2001] 31
EHRR 15, i.e. a failure “to treat differently persons whose situations are significantly different” (per the
ECtHR at [44]).

81. It is therefore necessary to consider a sequence of questions. These can be arranged in different ways
and should not be “rigidly compartmentalised”. For present purposes I take the formulation used by Murray
J in JP and BS (see [37] above):

i) Are the matters complained about within the ambit of a right protected by the European Convention on
Human Rights?

ii) Has there been a difference in treatment between two persons who are in an analogous situation (or, in
this case, a failure to treat differently two persons whose situations are different)?

iii) Is that difference (or lack of difference) of treatment on the ground of one of the characteristics listed, or
an “other status” referred to in, Article 14?

iv) Is the differential treatment objectively justified, in the sense that it had a legitimate aim to which it bore
a reasonable relationship of proportionality?

82. As to the first question, the parties agree that the “ambit” of a Convention right is wider than its
“scope”. Treatment will fall within “scope” if it potentially infringes a Convention right. But in an Article 14
case, the treatment will fall within the “ambit” of another Article if it merely has a “more than tenuous link
with the core values” protected by that other Article, which is a less exacting test. See _R (JCWI) v_
_Secretary of State for the Home Department [2020] EWCA Civ 542 at [104] per Hickinbottom LJ (with_
whom Henderson LJ agreed).

83. Mr Goodman submits that the decision and the policy relating to the Claimant's right to work are within
the ambit of ECHR Articles 4 and 8.

84 Article 4 provides in particular:


-----

“Prohibition of slavery and forced labour

1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

85. Article 8 provides:

“Right to respect for private and family life

1. Everyone has the right to respect for his private and family life, his home and his correspondence.

2. There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security,
public safety or the economic well-being of the country, for the prevention of disorder or crime, for the
protection of health or morals, or for the protection of the rights and freedoms of others.”

86. Mr Goodman submitted that the policy and the decision concerning permission to work for a potential
victim of trafficking manifestly are within the ambit of both Articles. The right to work, he says, has obvious
implications for private life and psychological integrity. He points to the ECtHR case of Sidabras v Lithuania
(2006) 42 EHRR 6, in which a restriction on the right to work of those who, before independence, had
worked for the KGB did not infringe Article 8 but did infringe Article 14 in conjunction with Article 8.

87. Moreover, in _R (K and AM) v Secretary of State for the Home Department [2018] EWHC 2951_
_(Admin), Mostyn J held (at [37]) that the policy on basic trafficking support (and a change to the amount_
paid to those in receipt of it) was within the ambit of Article 4, because that Article carries with it “positive
obligations to provide appropriate support and assistance to the victims of the conduct which is referred to
there”.

88. Meanwhile in JP and BS it was agreed that the policy of deferring decisions on ECAT leave until after
their asylum claims was within the ambit of Articles 4 and 8. So the Defendant there did not dispute that the
timing of an ECAT leave decision had a more than tenuous link with the right not to be subjected to slavery
or servitude and with the right to respect for a person's private life.

89. As in the case of Ground 1 above, Mr Malik responds by relying on _Negassi (and its application in_
_Rostami) for the proposition that the SOL rule and its application to an individual do not engage Article 8._

90. One problem with that submission is that Negassi and Rostami were claims under Article 8, not Article
14. In other words, they were on the issue of “scope” rather than “ambit”. So although they decide that a
refusal of permission to work to a foreign national who has no right to work does not infringe Article 8, it
does not necessarily follow that such a refusal lacks a “more than tenuous link” with the rights protected by
Article 8.

91. Furthermore, this is not a case of a simple refusal of permission to a person with no right to work.
Rather it involves a decision which simultaneously grants a right to work but imposes a limit on it. Although
_Sidabras was a very different case (involving limits placed on what would otherwise be a citizen's_
unfettered right to work under domestic law), it applied the Court's earlier ruling in Niemietz v Germany to
the effect that:

“Respect for private life must also comprise to a certain degree the right to establish and develop
relationships with other human beings. There appears, furthermore, to be no reason of principle why this
understanding of the notion of 'private life' should be taken to exclude activities of a professional or
business nature since it is, after all, in the course of their working lives that the majority of people have a
significant, if not the greatest, opportunity of developing relationships with the outside world.”

92. I accept Mr Goodman's submission that when the State confers a right to work but in terms qualified or
limited by the SOL rule, that has a more than tenuous connection with the individual's Article 8 rights even
if it does not infringe them. That is because the limitation makes it much harder, and in many cases
impossible, for the individual to obtain paid work. It may prevent them from working at all, thereby exposing


-----

them to a risk of isolation and affecting their self-esteem. It is likely to prevent them from earning, which will
affect their independence and standard of living.

93. The case is therefore within the ambit of Article 8. But even if it were not, it would in my judgment be
within the ambit of Article 4 by parity of reasoning with K and AM (see [87] above), because the grant or
refusal of either an unlimited or a qualified right to work has a more than tenuous connection with the right
of a trafficking victim to receive appropriate support and assistance.

94. I then turn to the second question or pair of questions, whether there has been a failure to treat
differently persons whose situations are significantly different.

95. Mr Goodman identifies those persons as asylum seekers such as the Claimant who are actual or
potential victims of trafficking, as compared with the generality of other asylum seekers. The alleged failure
consists of applying the SOL rule rigidly to all asylum seekers instead of exercising a discretion on a caseby-case basis in which the Defendant must ask herself whether an unrestricted permission to work is a
necessary measure to assist a victim of trafficking who has mental ill-health and is seeking ECAT leave in
his or her physical, psychological and social recovery.

96. As I have said in relation to the other grounds above, the position is that although both Rule 360A and
the published guidance state the SOL limitation in mandatory terms, in practice a discretion is now
exercised. In the Claimant's case the decision maker considered whether her personal circumstances
justified a departure from those mandatory terms but decided that they did not.

97. Given the situation in practice, there is room for debate about whether Ground 3 clears the hurdle of
showing differential (or in this _Thlimmennos-type case non-differential) treatment. But as I will go on to_
explain at [107] below, on the facts of the present case that question merges into the question of
justification.

98. For present purposes I continue to the question of whether the treatment is on the ground of
something that is a “status” for the purpose of Article 14. In K and AM (above), Mostyn J said at [38]:

“Next, claimants must show that they have been discriminated against by virtue of their “status”, as none of
the other grounds mentioned in Article 14 are applicable. Again, I am in no doubt that their status as
potential victims of trafficking is a qualifying status for the purposes of Article 14, and in fairness Mr
Sheldon QC only argued the contrary faintly.”

99. That case too was (inter alia) a complaint of a failure to treat asylum-seeking victims of trafficking
differently from other asylum seekers. The question of status is not materially different in the present case
and was not contested by Mr Malik. I apply the same conclusion as was reached in K and AM.

100. That leads me to the final question of whether the measure under challenge bore a reasonable
relationship of proportionality to a legitimate aim.

101. In this regard it is necessary to give separate consideration to the Immigration Rules, the guidance
and the decision in the Claimant's case.

102. In respect of Immigration Rule 360A, Mr Goodman concedes that he cannot succeed, at least in this
[Court. That is because of the high threshold which applies to a challenge to “legislation” under the Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[Rights Act 1998 (the Immigration Rules being defined as “legislation” for that purpose as I have said). The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
challenger must show that the rule is “incapable of being operated in a proportionate way in all or nearly all
cases”: see, for example, R (Joint Council for the Welfare of Immigrants) v Secretary of State for the Home
_Department_ _[2020] EWCA Civ 542 at [118] per Hickinbottom LJ. It is not in dispute that any defect can be_
cured by applying a sufficient residual discretion outside rule 360A, so that aspect of the challenge fails.

103. In respect of the guidance in Permission to work and volunteering for asylum seekers, Version 8.0,
the test is less stringent. As I said at [66] above by reference to the case of W, a challenge to guidance will
succeed where there is a real risk that in “a significant number of cases” the application of the guidance will
lead to a breach of ECHR rights or some other rule of law.


-----

104. Mr Goodman relies, as under Ground 2, on the fact that the guidance tells caseworkers that they
“must” apply the SOL rule and makes no reference to any residual discretion, let alone to any criteria for
exercising it. Therefore, he submits, the risk of discriminatory application is made out.

105. Mr Malik submitted again that Article 8 is inapplicable (and that Article 4 is likewise inapplicable
because it does not provide any relevant individual with a right to work). That apart, he relied on the fact
that caseworkers do apply a wide discretion in practice.

106. Nevertheless, as under Ground 2, I have concluded that the lack of reference to a discretion in the
guidance does create a real risk that caseworkers will fail to have sufficient regard to the particular
circumstances, and the ECAT rights, of those who claim to be victims of trafficking, and of their decisions
thereby being discriminatory in the Thlimmenos sense.

107. That is how Ground 3 clears the hurdle of showing discriminatory treatment as well as a lack of
justification. Once discrimination in that sense is made out, the Defendant does not advance any factual
justification for its existence, and indeed could not do so in view of her acceptance that a residual
discretion should be applied in cases of this kind.

108. There will therefore be a declaration that the guidance is unlawful for that reason too. Again, the
appropriate changes will be for the Defendant to frame.

109. Finally I turn to the individual decision in the Claimant's case. It seems to me that this part of the
challenge, which was not developed before me in detail, fails for similar reasons to Ground 1. The
Claimant's personal circumstances were taken into account, and therefore there was no discrimination
consisting of a failure to consider the ways in which her case might differ from that of other asylum
seekers. The contention that the decision maker discriminated against her by concluding that her
circumstances did not compel a grant of unlimited permission to work implies that the law requires such a
grant in all cases analogous to hers. That is not my finding, although there may be persuasive arguments
for such a grant in cases of this kind.

110. Ground 3 therefore succeeds in respect of the guidance but not in respect of Immigration Rule 360A
or the individual decision.

_Conclusion_

111. Ground 1 of this claim fails, Ground 2 succeeds and Ground 3 succeeds to the extent stated above.

_Costs_

112. I have received concise written submissions from both sides, and do not consider that any more
detailed submissions as to costs are required.

113. In my judgment the Claimant, having obtained important declarations about the guidance, is the
successful party. She failed on Ground 1 and so, as Mr Malik points out, the decision making in her
individual case was upheld. Nevertheless, it seems to me, firstly, that it was not unreasonable for her to
raise that ground in the circumstances of her case including the long delay in resolving it, and secondly,
that the great bulk of the costs would still have been incurred if Ground 1 had been omitted.

114. I will therefore apply the “general rule” stated in CPR 44.2(2)(a), and the Defendant will be ordered to
pay the Claimant's costs.

**End of Document**


-----

