EWHC 3268 (QB)

# R (on the application of MN) v Secretary of State for the Home Department
 (AIRE Centre intervening) [2018] EWHC 3268 (QB)

Queen's Bench Division, Administrative Court (London)

Farbey J

29 November 2018Judgment

**Ms Shu Shin Luh (instructed by Simpson Millar LLP) for the Claimant**

**Mr Gwion Lewis** and Mr William Irwin (instructed by **Government Legal Department) for the**
**Defendant**

**Ms Stephanie Harrison QC, Mr Ronan Toal and Ms Gemma Loughran (instructed by Herbert Smith**
**Freehills LLP ) for the Intervener**

Hearing dates: 16 and 17 October 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

MRS JUSTICE FARBEY

**MRS JUSTICE FARBEY :**

**Introduction**

1. The claimant has applied for judicial review of a decision that she is not a victim of trafficking. The
decision was taken by the competent authority ('CA') on behalf of the Secretary of State for the Home
Department under the National Referral Mechanism ('NRM'). The function of the NRM is to identify victims
of trafficking under the Council of Europe Convention on Action against Trafficking in Human Beings
('ECAT'). The relevant guidance to be applied under domestic law was 'Victims of **_modern slavery –_**
Competent Authority guidance'; version 3; 21 March 2016).  I shall refer to this as the CA guidance.

2. Under the CA guidance, the identification of a person as a victim of trafficking is a two-stage process.
The first part is the 'reasonable grounds decision' which acts as an initial filter designed to determine
whether someone is a 'potential' victim of trafficking (p.50). At this stage, when the CA receives a referral
under the NRM, it must decide whether it is 'reasonable to believe' that a person is a victim of trafficking on
the information available (p.50). According to the CA guidance, this standard of proof will be satisfied
where the CA 'suspects but cannot prove' that a person is a potential victim (p.19). It is a 'relatively low
threshold' (p.20). The second stage involves further inquiry and leads to a 'conclusive grounds decision' as
to whether someone 'is in fact a victim' (p.50).  At this second stage, the CA must consider whether there


-----

EWHC 3268 (QB)

is sufficient information that the individual is a victim on the balance of probabilities. The key issue in this
case is whether the balance of probabilities is an appropriate standard; or whether a lower standard must
be applied by virtue of the United Kingdom's human rights obligations.

3. I heard submissions over the course of two days from Ms Shu Shin Luh on behalf of the claimant and
Mr Gwion Lewis (together with Mr William Irwin) on behalf of the Secretary of State. Given the importance
of the issue, the AIRE Centre was granted permission to intervene. I am grateful to Ms Stephanie Harrison
QC together with Mr Ronan Toal and Ms Gemma Loughran for their submissions on the intervener's
behalf.

**The Facts**

4. The claimant is an Albanian national. On 3 November 2012, she arrived in the United Kingdom by air,
apparently from Italy. Upon being interviewed by immigration officials, she claimed to be coming for work
and said that she was not involved in human trafficking. She was removed to Italy on the following day.
On 26 February 2013, having returned to the United Kingdom, she claimed asylum. She underwent a
screening interview on the same day in which she told the interviewing officer that a man whom she was
intending to marry had taken her from Albania to Italy where she had been sold to another man as a
prostitute. That other man had beaten and raped her. She was forced to work as a prostitute under
surveillance in a house until it was raided by police. In the chaos of the raid, she managed to escape. She
made her way to a nearby airport and flew to Albania. When her traffickers tried to track her down, she left
Albania and came to the United Kingdom via Italy.

5. On 14 March 2013, the claimant underwent a full asylum interview. It is a central part of the Secretary
of State's case that there were significant discrepancies between her account at screening and her account
in interview. I shall return to the discrepancies later.

6. In light of the nature of the asylum claim, the Secretary of State referred the case under the NRM in
order for the CA to make a decision as to whether the claimant was a victim of trafficking. On 21 March
2013, the CA made a reasonable grounds decision in the claimant's favour. Following further investigation,
the CA wrote to the claimant on 27 September 2013 to inform her of a negative conclusive grounds
decision, i.e. that she was not considered to be a victim of trafficking.

7. On 28 January 2015, the Secretary of State refused the claimant's asylum claim on the basis (among
other things) that it was not credible. The claimant appealed to the First-tier Tribunal ('FTT'). At her appeal
hearing on 24 June 2015, the FTT was provided with a short witness statement in which the claimant gave
her response to the issues raised in the Secretary of State's written reasons for refusal of asylum. Ms Luh
drew my attention to the brevity of the statement and criticised the previous solicitors who settled it. That
criticism is unfounded: there is no evidence that the solicitors did anything other than faithfully reflect the
extent of their client's instructions. In any event, the FTT (which is a specialist tribunal cognisant of the
difficulties faced by vulnerable appellants) saw and heard the claimant give evidence.

8. In the conspicuously detailed and careful decision which followed, the FTT dismissed the appeal in the
following terms:

'I have rejected the Appellant's factual claim in its entirety and so it follows that she has no well-founded
fear of persecution and/or is not at risk of serious harm on return to Albania. She is not entitled to asylum,
humanitarian protection or protection under Article 3 of the ECHR'.

Despite the FTT's negative findings, on 21 November 2016, the Secretary of State agreed to reconsider
the conclusive grounds decision. In support of the reconsideration, the claimant's present solicitors
submitted a large quantity of documentation. I need not mention it all. It suffices to note that, in reaching
its decision, the CA considered three witness statements from the claimant. The first statement set out in
detail her claim to have been trafficked. The second statement is said to have provided an update on her
counselling sessions and other matters relating to accommodation and support. The third witness
statement contained the claimant's response to questions raised by the CA in relation to her account and in
relation to information hich the Secretar of State had obtained from the Albanian a thorities


-----

EWHC 3268 (QB)

9. Various reports were submitted including: (i) a letter from Hannah Rees who was a Counselling Coordinator at North London Rape Crisis ('NLRC'); (ii) a letter to the claimant's GP by Dr Rebecca Johnson
who was part of the Haringey Complex Care Team and who had carried out a psychological assessment of
the claimant; and (iii) a report by Mirjam Klann Thullesen who has expertise in the area of **_modern_**
**_slavery, specifically human trafficking.  By a letter dated 7 August 2017, the CA informed the claimant of_**
the decision that, on the balance of probabilities, she was not assessed as being a victim of trafficking.
The reasons for the decision are contained in a 'Consideration Minute' running to over thirty pages.  In
summary, the Secretary of State did not believe the claimant's account of past events.

10. The CA noted that Ms Rees's report was based on a written NLRC assessment and oral
communication with the claimant's treating counsellor. Ms Rees had not directly obtained the information
on which she relied to reach her conclusions. The report concluded that the claimant's mental health
difficulties were consistent with her account of trafficking but did not explore other alternative causes.
There were inconsistencies between the claimant's account as set out in Ms Rees's report and her
accounts elsewhere. In relation to Ms Rees's report, the CA concluded:

'Taken in the round with the rest of your claim, this report is not considered mitigation for credibility
issues…. In fact, it only serves to produce further inconsistencies'.

11.  In considering Dr Johnson's report, the CA noted the report's conclusion that the claimant was
experiencing severe Post Traumatic Stress Disorder (PTSD), low mood and feelings of shame and guilt as
a result of traumatic experiences in her past. The claimant had described 'frequent and distressing
intrusive memories and flashbacks of specific moments during the trafficking and sex working'.
Nevertheless, the CA noted further inconsistency between the claimant's account to Dr Johnson and her
accounts elsewhere. Dr Johnson appeared to have taken the claimant's account at face value without
considering any alternative aetiology for her PTSD. The CA concluded:

'Dr Johnson's report hinges on accepting your narrative as factual; however for the reasons given
throughout this letter, your entire account lacks plausibility and consistency. Moreover…you have failed to
offer convincing evidence with regards to any aspect of your claim, outside of your Albanian
nationality…For these reasons, Dr Johnson's report does not add weight to your claim'.

12. In analysing Mirjam Thullesen's report, the CA weighed the 'notable discrepancies' between the
account which the claimant gave to Ms Thullesen and previously submitted information. The CA noted Ms
Thullesen's professional opinion that the claimant's narrative contained a significant number of trafficking
indicators and was broadly consistent with the experience of other Albanian victims of trafficking. Ms
Thullesen considered it unlikely that the claimant had fabricated the key features of her experiences or that
she was feigning emotional and psychological difficulties. On the other side of the scales, the CA weighed
Ms Thullesen's failure to deal adequately with inconsistencies in the claimant's account; her failure to
consider alternative explanations for the claimant's symptoms of trauma; and her admitted inability
ultimately to assess the claimant's credibility. Having balanced these various factors, the CA concluded
that 'little weight' could be given to Ms Thullesen's findings.

13. The CA's decision sets out numerous aspects of the claimant's account which were inconsistent with
one another or which the CA considered implausible. The decision-maker took into consideration that the
trafficking case relied on the same narrative as the asylum claim, which the FTT had rejected. The FTT's
credibility findings were not decisive but were 'considered in the round' with the rest of the evidence. In
short, the CA carefully considered each aspect of the evidence but disbelieved the claimant's account of
past events.

14. By a claim form lodged on 13 October 2017, the claimant sought to challenge the CA's decision on
several grounds. On 1 February 2018, Cockerill J granted permission to apply for judicial review on a
single ground, namely that the CA had applied an unlawful standard of proof at the conclusive grounds
stage. Cockerill J refused permission on two other grounds concerning (respectively) the general
assessment of the claimant's credibility and the CA's approach to the independent reports submitted in
support of the trafficking claim The claimant renewed her application for permission in relation to these


-----

EWHC 3268 (QB)

two latter grounds. Lane J ordered that the renewal hearing take place at the substantive hearing. I heard
full argument on all grounds.

15. The claimant provided the Court with a number of statements (from herself and others) that post-dated
the decision under challenge. It is well-established that the rationality of a decision cannot be judged by
evidence that was not before the decision-maker at the date of the decision. The purpose of these
statements was unclear but Ms Luh did not in general deploy them in any event. She did, however, refer
briefly to a recent statement by Professor Cornelius Katona who is Medical Director of the Helen Bamber
Foundation. His statement and its exhibits were extensive, running to over 150 pages, but they contained
only general background documentation relating to the difficulty which victims of trafficking and asylum
seekers often have in presenting their claims. The statement makes no mention of the claimant's situation
and does not deal with her case. It is of no assistance in determining any of the live issues in these
proceedings.

**Legal background**

_Article 4 ECHR_

16. Article 4 of the European Convention on Human Rights ('ECHR') provides that no one shall be held in
slavery or servitude, and no one shall be required to perform forced or compulsory labour.  The European
Court of Human Rights ('ECtHR') has confirmed that article 4 'enshrines one of the basic values of
democratic societies' making no provision for exceptions or for derogation (Rantsev v Cyprus and Russia
(2010) 51 EHRR 1 para 283).  Trafficking - as defined by ECAT - falls within the conduct that is prohibited
by article 4, which entails a procedural obligation to investigate potential trafficking (Rantsev paras 282 and
287). In the sphere of immigration, a State's rules must address concerns relating to 'encouragement,
facilitation or tolerance of trafficking' (Rantsev para 284).

_ECAT and the Trafficking Directive_

17. The purposes of ECAT are set out in article 1. They are threefold: to prevent and combat trafficking in
human beings; to protect the human rights of the victims of trafficking through a comprehensive framework
and effective investigation and prosecution; and to promote international co-operation on action against
trafficking.

18. The definition of trafficking is contained in article 4:

'For the purposes of this Convention:

a "Trafficking in human beings" shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs;

b The consent of a victim of “trafficking in human beings” to the intended exploitation set forth in
subparagraph (a) of this article shall be irrelevant where any of the means set forth in subparagraph (a)
have been used'.

19. The process for identification of victims of trafficking falls under article 10. The key provision is article
10(2) which states:

'Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the


-----

EWHC 3268 (QB)

competent authorities and shall likewise ensure that that person receives the assistance provided for in
Article 12, paragraphs 1 and 2'.

20. Article 10 contemplates a two-stage identification process. At the first stage, the competent authority
must identify whether there are reasonable grounds for believing that a person has been a victim of
trafficking. If reasonable grounds exist, a signatory State must not remove the person from its territory.
The State must also provide assistance under article 12. This means that the State must assist in the
physical, psychological and social recovery of victims (article 12(1)) and take due account of the victim's
safety and protection needs (article 12(2)). The State must also at this stage provide the person with a
recovery and reflection period of at least 30 days. The period must be 'sufficient for the person concerned
to recover and escape the influence of traffickers and/or to take an informed decision on co-operating with
the competent authorities' (article 13(1)). During this period, the State is unable to enforce any expulsion
order and the person must be authorised to stay in the territory.  The recovery and reflection period is 45
days in the United Kingdom.

21. In relation to the identification process, the Explanatory Report to ECAT comments (at paragraph 132)
:

'The Convention does not require absolute certainty – by definition impossible before the identification
process has been completed – for not removing the person concerned from the Party's territory. Under the
Convention, if there are “reasonable” grounds for believing someone to be a victim, then that is sufficient
reason not to remove them until completion of the identification process establishes conclusively whether
or not they are victims of trafficking'.

In line with ECAT's protective purpose, a person will be permitted to remain in a State on this low standard
of proof and to receive assistance as soon as this standard is met.

22. Having made this initial assessment, the competent authorities will then identify - under article 10(2) whether the person is the victim of an offence of trafficking in human beings. This second stage of the
identification process will lead to a conclusive decision. As I have mentioned, the Secretary of State has
adopted the term 'conclusive grounds' for this latter stage. Mr Lewis told me that this description does not
mean that the CA will require absolute certainty but it is intended to mark the conclusion (i.e. completion) of
the identification process.

23. A person who is, at the completion of the process, identified as a victim of trafficking will have certain
rights that do not exist at the reasonable grounds stage. Those rights are set out in articles 14 to 16.
Under article 14, a State is under a duty to issue a renewable residence permit to victims if the competent
authority considers that their stay is necessary 'owing to their personal situation' or 'for the purpose of their
co-operation with the competent authorities in investigation or criminal proceedings' (article 14(1)). The
non-renewal or withdrawal of a residence permit is 'subject to the conditions provided for by the internal law
of the Party' (article 14(3)).  There is a duty to ensure that granting a residence permit 'shall be without
prejudice to the right to seek and enjoy asylum' (article 14(5)).

24. Article 15 deals with compensation and legal redress but none of the parties made much mention of it,
so I shall not say more about it here. Article 16 deals with the repatriation and return of victims to another
State (such as the victim's country of origin). The returning State must have due regard to the rights,
safety and dignity of the victim (article 16(2)). Child victims shall not be returned to a State if there is an
'indication' that such return would not be in the best interests of the child (article 16(7)). To this extent,
article 16 mandates a standard of proof for the non-expulsion of children (an 'indication') but not adults.

25. I was also taken in detail to Directive 2011/36/EU (5 April 2011) on preventing and combating
trafficking in human beings and protecting its victims (which replaced Council Framework Decision
2002/629/JHA). The Directive 'establishes minimum rules concerning the definition of criminal offences
and sanctions in the area of trafficking in human beings' and 'introduces common provisions, taking into
account the gender perspective, to strengthen the prevention of this crime and the protection of the victims
thereof' (article 1).  A person should be provided with assistance and support 'as soon as there is a


-----

EWHC 3268 (QB)

reasonable-grounds indication' for believing that he or she 'might have been trafficked' (eighteenth recital).
The Directive refers to a 'victim' of trafficking in the context of State duties 'after completion of the
identification process' (eighteenth recital). That is consistent with the Secretary of State's submission that
the conclusive grounds stage marks the completion of a process designed to determine who can properly
be regarded as a victim.

26. Article 11(1) of the Directive lays down a duty on States to ensure assistance and support to victims
'before, during and for an appropriate period of time after the conclusion of criminal proceedings' against
traffickers. Assistance and support should be provided as soon as the competent authorities 'have a
reasonable-grounds indication for believing that the person might have been subjected to' trafficking
offences (article 11(2)). In this respect, the Directive mirrors article 10(2) of ECAT.

_Domestic policy_

27. The United Kingdom has sought to give effect to its obligations under ECAT and the Directive in the
NRM which operates through guidance, notably the CA guidance to which I have referred above. It was
not in dispute that, if the CA guidance fails to give effect to an obligation imposed by ECAT, then that
failure could give rise to an error of law susceptible to judicial review (R (PK (Ghana)) v Secretary of State
_for the Home Department_ _[2018] EWCA Civ 98 at [34])._

28. A person who is found on conclusive grounds to be a victim of trafficking may be granted discretionary
leave under a specific policy ('Discretionary leave considerations for victims of **_modern slavery'; version_**
2.0; 10 September 2018). The policy is concerned with the grant of discretionary leave to victims of
trafficking 'based on their individual circumstances' where they 'do not qualify for other leave such as
asylum or humanitarian protection'.  In deciding whether to grant discretionary leave, the Secretary of
State will consider (among other factors) whether 'there is a significant and real risk in light of objective
evidence that the person may be re-trafficked'.

**The Parties' submissions**

29. Against this legal background, I turn to the parties' submissions on the appropriate standard of proof to
be applied at the conclusive grounds stage of the identification process. On behalf of the claimant, Ms Luh
submitted that the standard at all stages ought to be 'credible suspicion' which she equated with
'reasonable grounds for suspicion'. This submission was founded on the proposition that trafficking within
the meaning of article 4 of ECAT falls within the scope of article 4 ECHR which, like articles 2 and 3 ECHR,
imposes absolute obligations on States. Article 4 ECHR imposes a positive obligation on the State to take
operational measures to protect victims or potential victims. That positive obligation arises where there is a
'credible suspicion' that an individual has been or is at immediate risk of being trafficked or exploited
(Rantsev para 286). The requirements of a 'credible suspicion' correspond broadly with the concept of
'reasonable grounds' in article 10(2) of ECAT.

30. Ms Luh's submission would have the result that the standard of proof at both the reasonable grounds
stage and the conclusive grounds stage would be identical. She confronts this consequence by submitting
that trafficking claims are, in their nature, claims for protection like claims for refugee status under the
Refugee Convention 1951.  She submits that the assessment of whether a person is a victim of trafficking
is a matter of evaluation like the process of refugee status determination. The question whether someone
has been trafficked is not like civil litigation and does not involve a choice between two conflicting accounts
but an evaluation of the claimant's account only, which may be incomplete because of the inherent
difficulties of gathering evidence and the inherent stress suffered by victims of trafficking. Ms Luh pointed
to the 'psychological indicators of modern slavery' such as fear, anxiety, self-blame and shame ('Victims
of **_modern slavery – frontline staff guidance'; version 3; 18 March 2018; p.18). These sorts of factors,_**
which impede trafficking victims in establishing their account of past events, are the same or analogous to
the well-recognised difficulties faced by those fleeing persecution (as adumbrated for instance in _HK v_
_Secretary of State for the Home Department_ _[2006] EWCA Civ 1037 at [27]).  A lower standard of proof_
should apply in trafficking cases just as it does in refugee cases.


-----

EWHC 3268 (QB)

31. Ms Harrison QC on behalf of the intervener put forward a number of arguments which seem to me to
amount to three fundamental submissions. First, as a matter of interpretation, there is nothing in ECAT to
support the balance of probabilities as the standard of proof in conclusive grounds decisions.  There is no
reference to the balance of probabilities in any part of ECAT or the Directive; nor may such a standard be
implied.

32. Secondly, ECAT and the Directive lay down duties to protect victims of trafficking that encompass the
duty to permit victims to stay in the United Kingdom if their human rights would be breached by expulsion.
Non-expulsion obligations under ECAT are a form of, or analogous to, non-refoulement obligations under
the Refugee Convention or article 3 ECHR. The same, lower standard of proof should apply. Thirdly, the
question whether a person is a victim of trafficking is a matter of evaluation not fact. It may well involve not
only an analysis of what has happened to a person in the past but also a prospective analysis of what will
happen in the future. This sort of analysis has the same sort of character as the assessment of risk under
the Refugee Convention and article 3 ECHR. For this reason too, the same standard of proof should
apply.

33. On behalf of the Secretary of State, Mr Lewis submitted that the question whether a person is a victim
of trafficking is a question of fact not evaluation. The question is retrospective in the sense that the
decision-maker must consider whether what has happened to the claimant (i.e. his or her experiences in
the past) falls within the trafficking definition. Unlike decisions relating to non-refoulement, there is no
element of prospective risk assessment. The intervener's submissions that trafficking claims raise the duty
of non-refoulement in the same way as asylum or ECHR claims is contrary to authority, namely _MS_
_(Pakistan) v Secretary of State for the Home Department [2018] EWCA Civ 594; [2018] 4 WLR 63._

34. Mr Lewis submitted that ECAT lays down no standard of proof at the conclusive grounds stage. In the
absence of any binding standard under ECAT, it is the Secretary of State's function to set the standard.
Unless the Secretary of State's decision to apply the balance of probabilities is irrational, the Court should
not interfere. In circumstances where decision-makers are carrying out factual assessments, the Secretary
of State has rationally chosen to apply the balance of probabilities, which is a simple standard well-known
to English law. The Secretary of State's position is consistent with ECAT's two-stage identification
process.  There could be no logical purpose in setting the same standard of proof for the conclusive stage
as the reasonable grounds stage: it would amount to undertaking the same decision-making process twice.

35. It is convenient to consider the question of the standard of proof in accordance with what I have called
Ms Harrison QC's three principal submissions. Before I do so, I shall turn first to submissions that I heard
about the general human rights context.

**Human rights context**

36. Ms Luh (supported by Ms Harrison QC) emphasised that any discretion vested in the Secretary of
State must be exercised consistently with the United Kingdom's international human rights obligations and
its duties to protect the victims of trafficking. In her skeleton argument she submitted that the purpose of
identification procedures is 'to determine what protective measures the state is obliged to provide' and that
the 'paramount objective of the EU instruments (and their adoption into domestic law) is to protect victims
of trafficking'. I was reminded (for example) that the Directive respects fundamental rights (thirty-third
recital). There should be an 'integrated, holistic and human rights approach to the fight against trafficking'
(seventh recital) and it is 'necessary for victims of trafficking…to be able to exercise their rights effectively'
(eighteenth recital). These are undoubtedly important statements of principle which should underlie State
practice. However, my task is to resolve a very specific question and one which requires intense scrutiny
of international and domestic law. Resort to broad statements (however important those statements may
be) underestimates the complexity of the particular analytical task which the Court must carry out. I do not
derive much assistance from this sort of general statement.

37. Ms Luh also drew a parallel with the State's operational duties to protect individuals from violent
offences against the person. The right to life under article 2 ECHR imposes a positive obligation on States


-----

EWHC 3268 (QB)

to take measures to protect an individual from a 'real and immediate risk to life' (Osman v United Kingdom
29 EHRR 245 para 116). The ECtHR has held that article 4 may in certain circumstances require a State
to take operational measures to protect an identified individual if there are circumstances giving rise to a
'credible suspicion' that an individual is at 'real and immediate risk' of being trafficked (Rantsev para 286).
It followed, Ms Luh submitted, that the threshold of 'real risk' or 'credible suspicion' was appropriate to the
whole of the identification process under article 10(2) of ECAT which has the same protective purpose. I
reject that submission. A conclusive grounds decision in the trafficking context is not in itself concerned
with the sort of operational duties on the police that were the subject of Osman and Rantsev. The United
Kingdom's operational obligations under articles 2 and 4 ECHR are independent of ECAT. They are not an
automatic yardstick for the interpretation or application of ECAT's more particular obligations.  I heard
detailed submissions on the 'credible suspicion' and 'real risk' thresholds in the context of article 4 ECHR
as discussed in R (TDT) v Secretary of State for the Home Department _[2018] EWCA Civ 1395. However,_
that case was concerned with different issues and I did not ultimately find it to be of great assistance in
considering the particular questions that arose for determination in this case.

**Interpretation of ECAT and Directive**

38. Ms Harrison QC's interpretation argument rested mainly on article 11(2) of the Directive. As I have set
out above, article 11(2) frames the threshold for the first stage of the identification process as whether the
competent authorities have a 'reasonable-grounds indication' for believing that the person might have been
trafficked. Emphasising that the Directive refers to an _indication of trafficking at this first stage, Ms_
Harrison QC submitted that the two-stage process does not entail two different standards of proof. Rather
it involves the CA asking itself two different questions. The question at the first stage is whether there is an
indication that a person might be a victim of trafficking. The question at the second stage is whether a
person is a victim of trafficking. Both questions are capable of being answered by reference to a
'reasonable grounds' standard of proof. The different stages are not concerned with different levels of
certitude but with different sorts of assessment. The first assessment is speedy and summary, so that
potential victims of trafficking receive protection as soon as practicable. The second stage is the outcome
of investigation and inquiry, which allows the decision-maker to conclude with more confidence that the
person is a trafficked person, such that there is no lack of logic in applying the same standard of proof at
each stage.

39. I asked Ms Harrison QC to formulate the difference between the two standards more precisely. She
relied on the precise wording of article 10(2) in relation to the reasonable grounds stage: reasonable
grounds for believing that a person might have been trafficked. As to the conclusive stage, she submitted
that the standard of proof should be framed as whether there are reasonable grounds for believing that a
person has been trafficked. She submits that these are two cogent yet different yardsticks. In my view, the
distinction between these two standards is hard to fathom. It is not a distinction that is well-recognised in
domestic law. It is not simple to state. It does not in my view reflect the task of the decision-maker at the
second stage of the identification process which is unarguably different from the task at the first stage. The
retention of a 'reasonable grounds' standard at both stages of the identification process would not make
sense.

40. Ms Harrison QC further submitted that the question at the first stage is simply whether a person is a
potential victim of trafficking, which reflects the wording of the CA guidance. She submitted that that is a
different question to whether a person is a victim. It would not be over-complex for decision-makers to
determine this latter question on the lower standard. I do not however think that, by using the words
'potential victim', the CA guidance is intending to do anything other than explain to caseworkers in simple
language that the bar must not be set too high at the reasonable grounds stage. A 'potential victim of
trafficking' is a person who satisfies the relatively low threshold applicable at the stage of the reasonable
grounds decision (TDT at [34]). The words 'potential victim' are intended to reinforce the lower standard at
the first stage.  They are not in my judgment intended to imply anything about the standard of proof at the
second stage.


-----

EWHC 3268 (QB)

41. As regards the process of identification, article 10(2) of ECAT stipulates the standard of proof at the
first stage: reasonable grounds to believe. This is not the only indication of a standard of proof in the
European instruments. For instance, by virtue of article 13(2) of the Directive, States must ensure that a
person is presumed to be a child (in order to receive immediate access to assistance, support and
protection) provided that there are 'reasons to believe' that the person is a child. It seems that the drafters
of the European instruments have decided in specific instances expressly to impose a standard of proof.

42.  Article 10(2) of ECAT is however silent as to the standard to be applied at the second stage. I do not
think that any particular standard may be implied from article 10. Nor does it seem that any other provision
of ECAT assists with this question. I do not accept Ms Harrison QC's submission that, if the drafters of
ECAT had intended a standard higher than reasonable grounds, it would have been expressed in ECAT
itself and she cites no authority for such a principle of interpretation. In the absence of either an express or
implied standard within ECAT, the standard of proof at the conclusive grounds stage is a matter of policy
for the Secretary of State's discretion.

43. The Secretary of State has set the standard as the balance of probabilities. In my view, that is an
appropriate standard. It is a standard of proof that is well-recognised in domestic law. It is simple to state.
It reflects the CA's task at the conclusive stage, which is to decide whether or not a person is - as a matter
of fact - a victim of trafficking. There would be little or no purpose in having a two-stage process of
identification unless the first stage was distinct from the second stage. A summary decision on the basis of
reasonable grounds is appropriate as a means of determining who is entitled to the sort of immediate
protection which ECAT bestows. A substantive decision, taken after reasonable inquiry, may properly be
taken on a higher standard. On conventional principles, no challenge lies to the Secretary of State's
decision to adopt the balance of probabilities save on grounds of irrationality. I do not think that the
threshold of irrationality is met.

**The Principle of non-refoulement**

44. Ms Harrison QC's second principal argument concerns the United Kingdom's obligations under the
Refugee Convention 1951 and article 3 ECHR. Her essential point is that the higher standard of proof in
trafficking cases may put the United Kingdom in breach of its international obligation of non-refoulement.

45. The principle of non-refoulement is essentially the principle of international law that a State will not
expel an individual to a country where he or she is at risk of serious ill-treatment such as (but not limited to)
torture or loss of liberty. The duty of non-refoulement extends to refugees who are those with 'well-founded
fear of being persecuted for reasons of race, religion, nationality, membership of a particular social group
or political opinion' (Refugee Convention; article 1A(2)). The duty itself arises from article 33(1) of the
Refugee Convention which states:

'No Contracting State shall expel or return (“refouler”) a refugee in any manner whatsoever to the frontiers
of territories where his life or freedom would be threatened on account of his race, religion, nationality,
membership of a particular social group or political opinion'.

46. In deciding whether a person satisfies the refugee definition, the Secretary of State must consider
whether that person has demonstrated a reasonable degree of likelihood that he or she would be
persecuted in the country of origin (Regina v Secretary of State for the Home Department, Ex parte
_Sivakumaran_ [1988] AC 958). That standard has become known as the 'lower standard of proof' and I
shall refer to it as such.

47. The lower standard of proof in asylum cases is not a matter of policy but of law. It arises from the
proper interpretation of the Refugee Convention (Sivakumaran at 998G). An asylum claimant must
demonstrate 'well-founded fear of being persecuted'. The words 'well-founded' in their nature mean
something less than the degree of certitude that a party must demonstrate in civil litigation. In deciding
whether a person has well-founded fear, the Secretary of State does not assess the person's past or
present situation but must consider what might happen to the person if expelled to his or her country of
origin (Sivakumaran at 993D). The issues for a decision-maker under the Refugee Convention are


-----

EWHC 3268 (QB)

'questions not of hard fact but of evaluation' (Karanakaran v Secretary of State for the Home Department

[2000] 3 All ER at 477a). They involve a prospective analysis of risk which is 'a matter of degree and
judgment' (Sivakumaran at 996E-F) apt to be expressed in terms of likelihood rather than established fact.
The lower standard is also consistent with the 'relative gravity of the consequences of the court's
expectation being falsified' (Sivakumaran at 994H citing Regina v Governor of Pentonville Prison, Ex parte
_Fernandez [1971] 1 WLR 987per Lord Diplock at p.994).  It is consistent with the duty of anxious scrutiny_
which arises from the threat to life or liberty that may arise from a flawed decision (Sivakumaran at 997A
citing _Regina v Secretary of State for the Home Department, Ex parte Bugdaycay [1987] AC 514, 537)._
The lower standard ensures the United Kingdom's compliance with its international obligations: a riskbased precautionary approach recognises the inherent difficulty of predicting future events and so helps to
ensure that the United Kingdom does not refoule refugees (Karanakaran at 469f-g).

48. The application of the Sivakumaran standard has been considered by the courts in a number of wellknown and important cases. In Kaja v Secretary of State for the Home Department [1995] Imm AR 1, the
Immigration Appeal Tribunal (as it then was) held that there was no distinct divide between (on the one
hand) proof of present or past facts on which an asylum claim was based and (on the other hand) proof of
future risk. The assessment of whether a person has well-founded fear of being persecuted is a one-stage
process which treats all relevant evidence in the same way. In applying the _Sivakumaran standard, the_
decision-maker will need to take into account all evidence to which some credence may be attached, even
if it is not probably true. This approach does not mean that there should be a more ready acceptance of
fact as established as more likely than not to have occurred. It does however create a more positive role
for uncertainty, which is as applicable to evidence of past events as to any other evidence.  In short, there
is no 'probabilistic cut-off' because 'everything capable of having a bearing has to be given the weight,
great or little, due to it' (Karanakaran at 479d).  The lower standard is the single applicable standard
across all questions of fact.

49. The United Kingdom is bound by similar obligations under article 3 ECHR which prohibits torture and
inhuman or degrading treatment or punishment. The prohibition is absolute, enshrining one of the
fundamental values of democratic societies and making no provision for exceptions or derogation (Saadi v
_Italy (2009) 49 EHRR 30 para 127 and cases cited there). The expulsion of an individual by a State is_
prohibited where substantial grounds have been shown for believing that the person concerned, if expelled
from the territory, faces a real risk of being subjected to treatment contrary to article 3 (Saadi para 125 and
cases cited there).  The determination of the question whether there is a risk of ill-treatment involves an
examination of 'the foreseeable consequences of sending the applicant to the receiving country, bearing in
mind the general situation there and his personal circumstances' (Saadi para 130). An assessment under
article 3 amounts therefore to a prospective analysis of risk on a lower standard of proof which may be
regarded as the same standard and as requiring the same approach as the Refugee Convention (MT v
_Secretary of State for the Home Department_ _[2007] EWCA Civ 808; [2008] QB 533 at [159] – [162]). Mr_
Lewis accepted (and I agree) that similar reasoning applies to the absolute obligations under articles 2 and
4 ECHR. As those latter two obligations do not appear to add anything to the parties' submissions, I shall
refer in the remainder of this judgment to the Refugee Convention and article 3 alone.

50. ECAT does not have the same objectives as either the Refugee Convention or article 3. Its objectives
[were considered in Secretary of State for the Home Department v H [2016] EWCA Civ 565; [2016] Imm AR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)
1272. In that case, Burnett LJ (with whom Cobb J and the President of the Family Division agreed)
observed at [31] that ECAT is:

'concerned with the immediate treatment to be accorded to those in respect of whom there are reasonable
grounds to believe that they are victims of trafficking. It is also concerned with their medium term treatment
for immigration purposes in the event that it is accepted administratively that they have been trafficked. It is
also concerned with the criminalisation of behaviour associated with trafficking and the need to investigate
and prosecute offences.'

51. Burnett LJ (at [31]) characterised the task of the CA as being:


-----

EWHC 3268 (QB)

'to decide whether there are reasonable grounds to believe that a person has been trafficked and then, if
appropriate, whether he has in fact been trafficked. The purpose of doing so is to provide humanitarian
support, to allow the cooling off period and then to inform immigration decisions'.

52. I do not think that the Court of Appeal in H was intending to elide the scheme of ECAT with the United
Kingdom's non-refoulement obligations when referring to the function of trafficking decisions as informing
immigration decisions.  True it is that the Court went on to say (at [35]) that the CA guidance 'is concerned
with the welfare of putative victims and then their treatment for immigration purposes'. However, the
question whether the duty to grant a residence permit under ECAT was co-extensive with the United
Kingdom's non-refoulement obligations under other international treaties was not before the Court. The
Court did consider the relationship between the CA guidance and procedural obligations under article 4
ECHR.  It held (at [35] and [41]) that the application of the guidance is not the mechanism by which the
United Kingdom satisfies those obligations and that the obligations imposed by ECAT are not to be read
over directly into the procedural obligations under article 4. The Court was careful not to amalgamate
duties under different international instruments.

53. Ms Luh referred to the now well-established principle that the ECtHR will interpret the ECHR
consistently with other elements of international law (Demir v Turkey (2009) 48 EHRR 54 paras 85-86).
That principle has essentially been applied to the interpretation of article 4 ECHR by reference to ECAT
(Chowdury and others v Greece (2017) App 21884/15 para 104). Nothing in _Chowdury or elsewhere_
compels me to conclude that the United Kingdom's non-refoulement obligations fall to be read across to
article 10(2) of ECAT. In my judgment, ECAT and the Directive establish a separate scheme for the
identification and protection of victims of trafficking. They impose different obligations on States to those
imposed by the Refugee Convention and article 3 ECHR.

54. The ability of ECAT to sit alongside other human rights obligations is to be found in ECAT itself.
Article 40(4) states that nothing in ECAT affects rights, obligations and responsibilities of States and
individuals under international human rights law and the principle of non-refoulement under the Refugee
Convention.  Article 14(5) of ECAT states that the granting of a residence permit to victims of trafficking is
'without prejudice to the right to seek and enjoy asylum'. The Directive too is 'without prejudice to the
principle of non-refoulement' (tenth recital). These various provisions in ECAT and the Directive recognise
that other, additional international obligations may be owed to victims of trafficking. They undermine the
submission that the Secretary of State must as a matter of law give force in the CA guidance to nonrefoulement obligations.

55. A decision that someone has been trafficked can be relevant to the question whether he is at risk of
being re-trafficked on return to his country of origin (MS Pakistan at [83]). To this extent, the trafficking
decision may be relevant to a prospective analysis of risk in the asylum process. However, ECAT 'is
intended to give victims of trafficking particular protection and assistance' (PK (Ghana) at [56]).  The
Secretary of State is under no legal obligation to merge one process with the other.

56. The distinction between the United Kingdom's obligations under ECAT and its non-refoulement
obligations is reflected in the Secretary of State's policies about the grant of leave to enter or remain. The
policy of granting discretionary leave to victims of trafficking states that it is intended to provide an
additional ground for remaining in the United Kingdom 'based on…individual circumstances' where the
victim does not qualify for other leave 'such as asylum or humanitarian protection'.  The policy is not a
substitute for, or an addition to, the United Kingdom's non-refoulement obligations.

57. The distinction between asylum decisions and trafficking decisions was analysed in _MS (Pakistan)._
The case concerned the Secretary of State's appeal against a decision of the Upper Tribunal which had
considered and accepted MS's claim to have been a victim of trafficking. The Court of Appeal was
concerned with the question of the Upper Tribunal's jurisdiction to consider questions that arise under
ECAT. The Tribunal's jurisdiction is statutory (see sections 82 and 84 of the Nationality, Immigration and
Asylum Act 2002). Following AS (Afghanistan v Secretary of State for the Home Department [2013] EWCA
_Civ 1469; [2014] Imm AR 413, the Court of Appeal held that trafficking decisions are not appealable_


-----

EWHC 3268 (QB)

immigration decisions under the 2002 Act. It is therefore not generally open to the Tribunal to re-determine
the question whether a person is the victim of trafficking under ECAT. Flaux LJ (with whom Sharp and
Gloster LJJ agreed) held at [70]:

'Of course, a trafficking decision, whether positive or negative, may well be relevant to the issue before the
tribunal as to the lawfulness of the removal decision. However, an appellant can only invite the tribunal to
go behind the trafficking decision and re-determine the factual issues as to whether trafficking has in fact
occurred if the decision of the authority is shown to be perverse or irrational or one which was not open to
it'.

58. The only remedy against a negative conclusive grounds decision is judicial review. Appeals to the
FTT and onwards to the Upper Tribunal should not be used as a forum for indirect challenges to trafficking
decisions which do not have the same status as adverse asylum decisions (MS (Pakistan) at [81]). While
the question of whether a person has been trafficked may be relevant to whether he or she may be
expelled from the United Kingdom, the two questions are different.

59.  Mr Lewis submitted that MS (Pakistan) means that if the CA has determined certain factual matters in
the trafficking context, it is not open to the Tribunal to reconsider those same matters in the context of an
asylum appeal. The Tribunal is bound on the facts by the CA's assessment of the evidence underpinning a
trafficking claim - even if those same facts are part of an asylum claim or an article 3 claim. Ms Harrison
QC submitted that, if the ratio of MS (Pakistan) has the reach for which Mr Lewis contends, the Tribunal on
an asylum appeal would be bound by the CA's factual assessment made on the balance of probabilities
rather than the lower standard which the Tribunal is bound to apply in the asylum sphere. That would
create what Ms Harrison QC called a 'protection gap'.

60. In my judgment, Ms Harrison QC's submissions on this point are to be preferred. I do not accept that
the Court in _MS (Pakistan) was intending such a radical departure from well-established principle as Mr_
Lewis's submissions would imply. The judgment in _MS (Pakistan) was limited to issues arising under_
ECAT. It did not make any change to the function of the Tribunal in asylum or article 3 cases; nor did it
change any aspect of the standard of proof in those cases, with which it was not concerned.

61. The Court in _MS (Pakistan) was concerned with a Tribunal decision which had held that MS, as a_
victim of trafficking, had been entitled to certain benefits under ECAT and that, by reason of errors in the
CA's trafficking decision, there was a prohibition against removing MS from the United Kingdom. However,
the question of asylum was not before the Court of Appeal. By that time MS's protection claim, based on
the risk of re-trafficking, had fallen away: on this issue, the Tribunal had found against MS on the facts.
Flaux LJ recognised (at [81]) that a decision that someone has been trafficked can be relevant to future risk
in the asylum context, but it was not that part of the Tribunal's reasoning which the Court of Appeal
impugned.

62. The Court's conclusion was (at [88]) that the Upper Tribunal had 'effectively substituted itself' for the
CA in relation to matters under ECAT which cannot fall for consideration on appeal. That conclusion does
not touch the question of the standard of proof in asylum and article 3 claims. It does mean that appellants
before the tribunal who seek to rely on specific obligations under ECAT will get short shrift.

63. In my judgment, the appropriate standard for the assessment of a claim to have been trafficked will
depend on the legal issue to which it is relevant. If the issue is whether a person will suffer persecution
under the Refugee Convention or ill-treatment prohibited by article 3 ECHR, the lower standard will apply.
If the issue is whether a person has the specific rights available to victims of trafficking under ECAT, the
standard has been rationally set by the Secretary of State as the balance of probabilities. I am fortified in
taking this issue-based approach by _RM (Sierra Leone) v Secretary of State for the Home Department_

_[2015] EWCA Civ 541 at [35] (cited in_ _AS (Guinea) v Secretary of State for the Home Department and_
_another_ _[2018] EWCA Civ 2234 at [55]). In that case, Underhill LJ applied an issue-based approach to the_
standard of proof to be applied in determining a person's nationality. He held that the same question may
require different standards, depending on whether it was relevant to an asylum claim or some other claim.


-----

EWHC 3268 (QB)

64. In principle, it is possible that the Secretary of State may reject a trafficking claim on the balance of
probabilities but accept the same evidence in an asylum claim on the lower standard. I doubt that the
different standard would make a practical difference in every case. It would be unlikely to make a
difference in the present case, where the claimant has at every stage been disbelieved. Nevertheless, the
United Kingdom's non-refoulement obligations mean that the Secretary of State must have systems in
place to determine an asylum claim on the lower standard, even if the CA has rejected a similar claim for
the purpose of ECAT.  I would be straying beyond the issues in this case if I were to comment on the
Secretary of State's asylum processes on which I did not in any event hear submissions. The claimant's
asylum claim has been rejected and her appeal failed. She seeks to challenge a subsequent decision on
her trafficking claim and I am not concerned with the risks of returning her to Albania.

**Question of fact**

65. Having concluded that trafficking decisions are different in their nature to asylum decisions, it follows
that the considerations which underpin the lower standard of proof under the Refugee Convention and
article 3 ECHR do not necessarily apply in trafficking decisions. It was not in dispute that, under article
10(2), the purpose of the identification process is to establish whether a person 'has been' the victim of the
offence of human trafficking. In simple terms, a person is the victim of an offence if he or she has suffered
criminal behaviour. I see no reason to treat victims of trafficking differently. There was some suggestion in
oral submissions that the reference to the threat of force in the definition of trafficking means that a person
may be a victim of trafficking by reference to future events. I do not accept that a person who has been
threatened with force is somehow in a different position to someone who has suffered force. Either way,
the State must assess whether the person has suffered the crime of trafficking. In distinction to the asylum
process, it is a retrospective analysis, concerned with past events and not with future risks.

66.  The ultimate question at the conclusive grounds stage is whether a person has in fact been trafficked.
The question is concerned with a person's history. It is a question of fact. A decision-maker will need to
apply the facts of the case to the correct legal framework but the question is one of fact not judgment.
Provided that the CA reaches factual conclusions that were open to it and directs itself properly on the law,
this Court will not interfere.

67. I was urged to consider the very severe consequences of getting a trafficking decision wrong.  That
may be so, but the gravity of the consequences does not convert a question of fact into a question of
speculation about future risk (AS (Guinea) at [46]). The human rights context does not alter the task of the
decision-maker to apply the facts as found to the relevant legal framework (MT v Secretary of State for the
_Home Department at [97] and [109] –[110])._

68. For these reasons, the balance of probabilities is a lawful standard of proof and this ground of
challenge fails.

**Other grounds**

69. I am able to deal more briefly with the two other grounds upon which the claimant relies.  They both
concern the CA's assessment of the credibility of the claimant's trafficking claim. Before I turn to the
individual grounds, I shall deal with one overarching point. In her submissions on the claimant's credibility,
Ms Luh contended that the CA in this case had erred in its approach because it had not demonstrated on
the face of the decision that it had followed the approach in Karanakaran.  I understood her to criticise the
CA on the basis that it had listed the various reasons for refusal and applied the balance of probabilities
uniformly to each item in the list. She submitted that that was not the holistic approach laid down by
_Karanakaran which held that it is 'only at the end point that, for want of a better yardstick, a probabilistic_
test is applied'. The balance of probabilities comes into play as 'the final touchstone' for testing the overall
effect of the evidence (Karanakaran at 477g-h).

70. Ms Luh criticised the CA's decision without pointing to any instance in which the CA guidance is
inconsistent with the Karanakaran approach. There is no duty on the CA to set out its decision in some
fixed way or to reflect the language of a legal case The CA must apply the Secretary of State's guidance


-----

EWHC 3268 (QB)

The guidance is not a document for lawyers. It is a working document for the Secretary of State's
caseworkers who have the difficult and sensitive task of deciding who is a victim of trafficking. The overall
effect of the guidance must be to ensure that the CA's caseworkers apply the right legal approach.
Provided that the guidance has the correct legal effect, it need not itself be written in the language of a
judgment. It is in the interests of victims of trafficking that guidance for officials acting on behalf of the
Secretary of State is clear and simply worded so that it enables them to get the answer right. The CA
guidance, as drafted, enables caseworkers to take _Karanakaran-compliant decisions. If it is properly_
applied, the decision-maker will have taken a Karanakaran-compliant decision. Ms Luh's submissions on
_Karanakaran are more a disagreement with drafting style than a meaningful challenge to the CA's detailed_
decision.

71. Turning to the remaining grounds on which the claimant relies, Ms Luh submitted that the CA was
bound to regard the inconsistent and implausible aspects of the claimant's account as marginal and as
incapable of undermining the credibility of the overall claim. She submitted, in any event, that the CA was
irrational in treating tensions in the claimant's evidence as amounting to real inconsistencies. Ms Luh
summarised her submissions in a helpful schedule of references to the evidence on which the CA relied.
While I am grateful for the schedule, she has in my judgment put forward a series of essentially factual
challenges which are inapt for the Court's consideration in judicial review proceedings. I do not propose to
go through her schedule in detail, which in truth highlights the very many areas of the claimant's testimony
which give rise to difficulties. Two examples will suffice. In her asylum interview, the claimant said that
she left Albania and travelled to Italy by plane. In a witness statement prepared by her present solicitors,
she said that she went by ferry. In a further statement, she reiterated that she went by ferry and attributed
the inconsistency to a blur in her mind. The Secretary of State is plainly correct to say that she has given
an inconsistent account and plainly entitled to reject her explanation.

72. In her asylum interview, the claimant said that the Italian police did not stop any of the women who
were fleeing from the house at the time of the raid. She told Ms Thullesen that she saw policemen 'talking
to everyone' at the reception of the house. She attributed this difference to an error or misunderstanding in
her interview.  The Secretary of State was entitled to conclude that she has given inconsistent accounts
and entitled to reject her explanation.

73.  The accumulation of inconsistencies – across many different elements of the trafficking claim - is
capable in my judgment of undermining the claimant's credibility. Absent irrationality or some other public
law error by the CA, it is not the role of this Court to conclude that the difficulties are merely tensions on the
margins. The CA was well within its discretion to regard her various accounts as inconsistent and
implausible in material respects.

74.  Finally, Ms Luh contended that the CA was irrational or unreasonable in concluding that nothing in the
medical and other expert evidence was capable of mitigating the weight to be placed on the discrepancies
in the claimant's account. I do not agree. The Secretary of State accepts Ms Thullesen's expertise but her
report cannot be a trump card. The Secretary of State (delegating his function to the CA) is the primary
decision-maker whose function is to determine whether a person is a victim of trafficking under ECAT. The
task of identifying victims of trafficking is an executive task and is not a matter of expert opinion. The
claimant cannot show that the CA's treatment of Ms Thullesen's report was erroneous in point of law.  Nor
is there any error of law in the CA's treatment of Dr Johnson's or Ms Rees's reports.

75. In summary, the CA did not believe the claimant's account that formed the basis of her trafficking
claim. The CA took the view that her account of past events contained significant inconsistencies which
fatally undermined it. The claimant's attempt to impugn the decision is an attempt to assault the decisionmaker's factual conclusions in a manner which is not open to her in judicial review proceedings. On these
other grounds, therefore, I refuse permission to apply for judicial review.

76. For these reasons, this application is dismissed.

**End of Document**


-----

