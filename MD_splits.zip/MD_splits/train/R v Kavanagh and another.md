# R v Kavanagh and another [2022] EWCA Crim 1121

Court of Appeal, Criminal Division

Whipple LJ, Cutts J, HHJ Michael Chambers

8 July 2022Judgment

MR O. RENTON appeared on behalf of the First Appellant.

MR T. E. CLARK QC appeared on behalf of the Second Appellant.

MR M. SHAW appeared on behalf of the Respondent.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

HIS HONOUR JUDGE MICHAEL CHAMBERS Q.C.:

1 The appellants, Harley Kavanagh, born on 19 May 2004 (now aged 18) and Isaac Wallace Greaves,
born on 5 April 2003 (now aged 19) appeal against sentence with leave of the full court.

2 On 22 July 2021 in the Crown Court at St Albans before HHJ R Foster and a jury, Harley Kavanagh
(then aged 17) and Isaac Wallace Greaves (then aged 18) were convicted of the offences set out below.

3 On 29 October 2021, before the same judge, Kavanagh (then aged 17) and Wallace Greaves (then
aged 18) were sentenced as follows:

    - Count 1 (conspiracy to commit robbery contrary to s.1 of the Criminal Law Act 1977) – an extended
sentence of 17 years' custody.

    - On Count 2 (conspiracy to commit grievous bodily harm contrary to s.1 of the Criminal Law Act) – an
extended sentence of 17 years' concurrent.

4 In respect of the first defendant, Kavanagh, the total sentence was an extended determinate sentence
pursuant to s.254 of the Sentencing Act 2020 comprising of a custodial term of 12 years' detention and an
extended licence period of five years.

5 In respect of the co‑appellant, Wallace Greaves:

    - Count 1 (conspiracy to commit robbery) – an extended sentence of 17 years.

    - Count 2 (a conspiracy to commit grievous bodily harm with intent) – again, an extended sentence of 17
years concurrent


-----

6 Total sentence, again, an extended determinate sentence comprising a custodial term of 12 years'
detention and an extended licence period of five years.

The Facts

7 Between 1 December 2019 and 20 September 2020, Harvey Kavanagh, Isaac Wallace Greaves, Kobi

Nelson and Kai Henry‑Smith were involved in conspiracies to commit robbery and grievous bodily harm

with intent. They targeted people they believed were drug dealers.

8 The prosecution was based in essence on four incidents.

The First Incident

9 On 9 December 2019 Oscar Deed, a known drug dealer, was lured to York Road in St Albans. Deed

pulled up in his car and was ambushed. The telephone evidence showed that Henry‑Smith, Kavanagh and

Wallace Greaves were involved in the incident, along with others. A nearby witness contacted the police at
18.43 and said that there were four or more attackers wearing hoodies. The group were armed with a

machete and another knife. Deed did not co‑operate with the prosecution, but did tell police that he had

been attacked with a knife. He received surgery to repair the tendons in his hands. Later medical
evidence showed Deed had also sustained stab wounds in the thigh, chest and forehead. The attack
came to an end after nearby security lights were activated by a householder.

The Second Incident

10 At 13.43 on 21 December 2019 there was an attempt to rob Jamal Lewis that took place in Artisan
Crescent, St Albans. There was no evidence that Lewis was a drug dealer, but the group thought that he
was one. Lewis had initially been approached by the group the night before, but on that occasion had
managed to escape into nearby shops. On 21 December Lewis was forced to take refuge in his car. He

was followed by Henry‑Smith, Nelson and Wallace Greaves, who were driven across St Albans to Artisan

Crescent by Mason Monaghan, who was acquitted of any involvement in the conspiracies at trial. When
Lewis parked, the group ran out and stabbed the tyres to his vehicle. The car was searched for drugs, but
none were found. Lewis escaped to some nearby woods and telephoned 999. There was no evidence

that Kavanagh had been directly involved in this attack, but he was in contact with his co‑conspirators that

day.

The Third Incident

11 At approximately 18.34 on 13 January 2020, Lemar Hoyte was attacked in Cotlandswick, London
Colney. He sustained serious injuries, including the loss of two fingers; the end of his nose was severed

and surgeons were unable to re‑attach it; a bleed on the brain; part of his scalp had been severed from his

head; a skull fracture; stab injuries to his collar bone, shoulder blade and elbow; a broken arm; slash marks
to the head; the loss of several teeth and slash wounds to both wrists that were repaired with pins and
springs. Those injuries could indeed result in the loss of the use of both hands.

12 Following the attack, Hoyte was taken to the specialist trauma unit at St Mary's Hospital in Paddington.
He was interviewed by police and described having been followed. During his attempt to flee, he tripped
and was attacked by two men armed with a large sword and baton. The trial judge concluded the two
directly responsible were Kavanagh and Wallace Greaves. We will return to that when dealing with the
grounds of appeal.

The Fourth Incident

13 The final incident took place on 23 September 2020. Dawood Al‑Abaidy was attacked as he left a

Sainsbury's supermarket in London Colney. Al‑Abaidy was a convicted drug dealer known to Kavanagh.

He was cornered by a group. Someone was in possession of a knife. Al‑Abaidy was punched to the face


-----

and knocked to the ground. He was robbed of cash and Apple ear‑pods. He was able to identify

Kavanagh, because his balaclava had dropped. The incident only came to an end after intervention from
Sainsbury's staff. There was no evidence of who the others involved in the attack were.

Previous Convictions

14 Harley Kavanagh, as we have stated, born on 19 May 2004 was 17 and so during the course of the
conspiracy was 15/16 years old. He had previous convictions, including possession with intent to supply
Class B drugs and eight convictions of simple possession.

15 Isaac Wallace Greaves, 18, born on 5 April 2003, was 16/17 years old during the conspiracy period.
He had previous convictions, including five convictions for six offences and, again, possession with intent
to supply of Class B drugs.

16 The co‑defendants Kai Henry‑Smith were 18 and Kobu Nelson 19.

Submissions Regarding Sentence by the Prosecution

17 The prosecution submitted that given the ages, as set out above, the provisions of the Sentencing of
Children and Young Persons Guideline should be taken into account. The prosecution emphasised that,
judged as individual offences, the most serious incidents in this conspiracy would plainly fall within
Category 1A of the section 18 guideline. Relevant consideration included: the use of knives, swords and
machetes; the level of planning involved in these attacks; the link to the drugs trade; the group nature of

the offending, and the infliction of devastating and life‑changing injuries to the victims.

18 However, this they said was a conspiracy involving multiple offences, some of extreme violence. The
court was referred to the case of R v McArdle _[[2021] EWCA Crim 1490, a decision of this court. That was](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63VJ-4XJ3-CGX8-00GC-00000-00&context=1519360)_
a case involving conspiracy to wound with intent. The victim, a drug addict who had either lost or stolen
drugs given to her by her dealer, was attacked by three men pursuant to an agreement to mutilate her.
She sustained deep lacerations to the scalp, face and arms. This court described its ending as "horrific by
design". In that case, the sentencing judge went beyond the guideline to impose a life sentence on the
defendant who actually inflicted the wounds. This court observed:

"Without losing sight of the fact that the present case involved a conspiracy, the sentencing guideline for
wounding with intent makes clear both (a) that a case of particular gravity reflected by multiple features of
culpability could merit upward adjustment from the starting point before further adjustment for aggravating
and mitigating features, and (b) that in some cases having considered the factors increasing seriousness
and those reducing seriousness or reflecting personal mitigation, it may be appropriate to move outside the
identified category range.

This was a case of particular gravity with, as the judge explained, multiple features of culpability. The
factors increasing seriousness identified by the judge were of particular strength. The notional determinate
term of 18 years set by ... the trial judge ... was not excessive..."

19 The Crown submitted in the present case the court was entitled in a case such as this to go beyond the
range indicated by the sentencing guideline. There were multiple factors increasing seriousness in this
case and the court was concerned not with a single offence, but with an overarching agreement to commit
multiple offences, involving the attack and mutilation of persons believed to be rival drug dealers.

20 The Crown did not distinguish between individual offenders. All were party to the overall agreement.
Not all incidents were equally violent in the result. The third victim suffered particularly extreme violence,
whilst other victims were able to defend themselves to varying degrees and to avoid the same level of
injury. The intention underlying each incident was, the Crown inferred, the same. All defendants who
participated in this conspiracy understood that the aim in each case was to inflict grievous bodily harm by
the use of swords and machetes.

Sentencing Remarks


-----

21 Having regard to their degree of participation and culpability and their antecedents, the judge treated
Kavanagh and Wallace Greaves the same. He applied the guidelines on offences of wounding with intent
to cause grievous bodily harm. He found that there was high culpability, because of the significant degree
of planning and the use of dangerous weapons. He found that there was harm Category 1, because there
were particularly grave injuries. For an adult committing one offence, the starting point would be 12 years'
custody with a range of 10 to 16 years. He said that it would have been appropriate to go outside the
upper sentence range, because of the number and severity of the offences, presumably pursuant to the
principles set out in R v McArdle. He said that personal mitigation in respect of each defendant brought it
back down.

22 The judge had regard to the purpose behind the guidelines for sentencing young offenders and children
and in particular the need to discount the sentence. Kavanagh had been 15 and 16 during the conspiracy
dates. Wallace Greaves had been 16 and 17. The sentencing judge reduced it to by only 25 per cent,
because of what he described as the sophisticated nature of their criminality, evidenced by the planning
and their antecedents.

23 In Kavanagh's case, he said that the facts of the case and his view of Kavanagh's developmental age
did not justify a larger reduction. He adopted "the same reasons" when he came to sentence Wallace
Greaves. In each case, having started at 12 years, he moved up to 16 years to reflect the number of
offences and then discounted it by 25 per cent. In fixing the sentence on Count 2, he aggregated their
criminality in respect of the robbery conspiracy on Count 1 and made the sentences concurrent. He made
the finding of dangerousness in each case, based on the seriousness of the offending and applying the
principles illustrated in R v McArdle. He considered an extended sentence to be the best way of protecting
the public from the risk they presented. In each case, he extended the licence by five years.

Grounds of Appeal

24 On 12 April 2022, the full court granted leave to both appellants on the following grounds:

     - Ground 1 – the trial judge was not justified in finding to the criminal standard that these two appellants
were the two assailants involved in the attack that took place on 13 January 2020 in the Cotlandswick area
of St Albans. That is the third incident.

     - Ground 2 – greater discount should have been made in respect of the age of the appellants.

25 In addition to well‑prepared and helpful written submissions, this court has had the benefit of oral

submissions ably and precisely made by Mr Clark QC on behalf of Wallace Greaves and Mr Renton on
behalf of Kavanagh. We have also heard equally helpful submissions in response from prosecuting
counsel Mr Shaw.

Ground 1

26 We have considered whether it was open to the trial judge to make this finding to the criminal standard

in the light of the summing‑up and all the material placed before us, including the submissions from the

defence and the prosecution to which we have referred.

27 On 13 January 2020 the victim of the third attack, Lamar Hoyte, had gone to an address in
Cotlandswick in St Albans to visit friends, leaving his car in a nearby car park. In an apparent attempt to
lure him out of the address, his car was attacked with bricks. When he later went to investigate this, he
was chased from the car park by a group of youths. As he ran to try to escape his attackers, he slipped
and fell. He described in his ABE recorded interview in hospital after surgery being set upon on the floor
by two youths, one armed with a baseball bat or metal pole and one with a Samurai sword. In what was a
sustained attack, he suffered a number of serious injuries consistent with being attacked with a sword,
including the end of his nose being amputated.

28 Witness evidence described the assailants as then heading north from the scene of the attack across a
school playing field. This route would have taken the attackers past the St Albans Irish Club. CCTV
bt i d f th t l ti i d d t d t th l t id tifi d b li ffi d i d d


-----

accepted to be these two appellants, Kavanagh and Wallace Greaves, walking past the camera heading
away from Cotlandswick towards the A414 shortly after the attack.

29 Cell site analysis of the mobile phone of Harley Kavanagh placed him both in the vicinity of the incident

and showed his phone had been in contact with Roslyn Wallace Greaves, his co‑appellant's mother,

shortly after the attack. A statement was obtained from the mother in which she confirmed that she had
been contacted by her son who was asking for a lift home to ensure he was back for his curfew and that
his brother had used her car to collect both these appellants.

30 Evidence from an ANPR some 50 metres from the entrance to the Irish Club showed that Ms Wallace
Greaves' car did indeed pass the entrance of the Irish Club at a time when the CCTV showed the two
youths were collected by a vehicle.

31 At trial, both appellants accepted that they had been correctly identified on the CCTV and were heading
away from Cotlandswick, but denied involvement in the incident.

32 Kavanagh gave evidence in his own defence. Isaac Wallace Greaves did not. When cross‑examined,

Kavanagh drew on a map the route that both he and Isaac Wallace Greaves had taken from his home
address just south of Cotlandswick to where they were seen on the CCTV at the Irish Club. He indicated
that he and Wallace Greaves had in fact passed the front door of the property outside which the assault
had occurred at a time when it was likely to have been taking place.

33 We have heard argument before us from the respondent's counsel, Mr Shaw, emphasising the timings.
The evidence is compelling. Also emphasised was the fact that Kavanagh claimed to have seen no attack
nor the victim lying on the grassed area nor any other persons who could be alternative candidates for the
attack. Hoyte's evidence was that although initially he was chased in the car park by a group, there were
only two males who pursued him and attacked him.

34 In our judgment, there was a strong and compelling circumstantial case implicating these two
appellants as being the two assailants. In addition, the sentencing judge, as of course being the trial judge,
was also able to apply the principles of cross-admissibility when having regard to the evidence as a whole
when considering the issue of identity in relation to this particular incident. It is a high hurdle to cross when
challenging a factual finding made by a judge who has sat through the evidence in a trial. Accordingly, we
are therefore satisfied that not only was the learned judge well placed to make such a finding, but he was
able to make such findings to the criminal standard and we do not disturb such a ruling.

Ground 2

35 It is submitted on behalf of each of the appellants that 25 per cent was insufficient discount to reflect
the ages and level of maturity at the time of the conspiracy, notwithstanding the seriousness of the case.
We note that the full court refused leave to argue that the sentence for an adult following a trial of 16 years
was wrong in principle or manifestly excessive. We respectfully agree with that decision. Paragraph 6.46
of the guidelines of the Sentencing Council on Children and Young Persons provides:

"When considering the relevant adult guideline, the court may [our emphasis] feel it appropriate to apply a
sentence broadly within the region of half to two thirds of the adult sentence for those aged 15 – 17 ... This
is only a rough guide and must not be applied mechanistically. In most cases when considering the
appropriate reduction from the adult sentence the emotional and developmental age and maturity of the
child or young person is of at least equal importance as their chronological age."

36 Whatever the seriousness and apparent culpability of the underlying offending, these remain very
important guidelines when considering the issue of age. Real weight should be attached to the principle

aims of sentencing children and young persons; namely, to prevent re‑offending and the welfare of the

individual child or young person. The seriousness of the offending should be reflected when assessing the
starting point of the sentence at step one and then adjusting it to reflect aggravating and mitigating factors,
as was done in the present case in reaching 16 years.


-----

37 Although it is a matter of judicial discretion, we would expect a sentencing judge to give cogent reasons
before departing from the guideline. In determining the discount, regard should be had to the emotional
and developmental age and maturity and any departure from the guidelines should be clearly explained by
reference to those factors.

38 In the present case, the appellants were aged 15/ 16, and 16/ 17, respectively at the time. The concise
sentencing remarks by the learned judge on this aspect, regrettably, do not fully set out in detail the
reasons why he departed from the guideline in discounting for age less than one third. There remains a
concern that in attaching weight to criminal sophistication the concepts of seriousness and developmental
maturity were being elided. The passing reference to developmental age in Kavanagh's case does not

dispel this concern. We note that pre‑sentence reports on both defendants which were before the

sentencing court suggest a lack of maturity as a factor contributing to their criminal conduct. In addition,
Wallace Greaves was reported to have been found to be a victim of modern slavery. A psychiatric report
on him indicated that he was suffering from an adjustment disorder with predominant disturbance of
conduct, for which treatment was suggested. Having regard to the ages of each of the defendants in the
context of these reports, we are persuaded that insufficient weight was attached to their ages and level of
maturity.

39 The difference between the appellants in age and maturity was marginal so we propose to deal with
them in a similar manner. In our judgment, having assessed the adult sentence after a trial, the custodial
term of 16 years should have been discounted by one third in each case. The judge was right to make a
finding of dangerousness and to assess that the public would best be protected by the making of an
extended sentence and, indeed, that has been conceded before us. Therefore, we vary the sentences on
Counts 1 and 2 in respect of each appellant concurrently to an extended sentence of 15 years; the
custodial element to be ten years and eight months and the extended licence to be four years and four
months.

40 To that extent, this appeal against sentence is allowed.

__________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge_**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge

**End of Document**


-----

