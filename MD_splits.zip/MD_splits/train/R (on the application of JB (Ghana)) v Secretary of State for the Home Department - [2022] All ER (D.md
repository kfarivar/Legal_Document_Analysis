# R (on the application of JB (Ghana)) v Secretary of State for the Home
 Department [2022] All ER (D) 73 (Oct)

[2022] EWCA Civ 1392

Court of Appeal, Civil Division

EnglandandWales

Bean, Peter Jackson and Baker LJJ

25 October 2022

**IMMIGRATION – FINANCIAL SUPPORT – CLAIMANT BOTH AN ASYLUM SEEKER AND A VICTIM OF**
**_MODERN SLAVERY_**
Abstract

_The Court of Appeal, Civil Division, dismissed the Secretary of State's appeal against the Administrative Court's_
_decision that, as both an asylum seeker and a victim of modern slavery, the respondent had been entitled to £65_
_[per week, pursuant to para 15.37 of a Home Office document entitled 'Modern Slavery Act 2015 – Statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
_Guidance for England and Wales' (the MSAG), regardless of the fact that during the period in question he had also_
_[been provided with temporary support under s 95 of the Immigration and Asylum Act 1999 and temporary asylum](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61R0-TWPY-Y0HB-00000-00&context=1519360)_
_accommodation on a full board basis. The court held that para 15.37 of the MSAG had categorically set out the_
_above conclusion and had made no distinction between self-catered and catered accommodation, nor had it said_
_anything about any offset for the value of meals which had bee provided by the latter. It was not clear that, as_
_submitted by the defendant, the drafter of para 15.37 had made an 'obvious error' in that they had not intended for_
_someone in the claimant's position to receive a top-up to bring his total payments to £65. The court's construction of_
_para 15.37 of the MSGA was consistent with the terms of the Victim Care Contract, between the Home Office and_
_the Salvation Army, and the answers given in a 'Frequently Asked Questions' document which had been sent by the_
_Home Office to the Salvation Army._
Digest

The judgment is available at: [2022] EWCA Civ 1392

**Background**

JB was a national of Ghana who purportedly arrived in the UK in 2011. In 2019, he was arrested as an illegal
entrant and taken into immigration detention where he claimed asylum. While in immigration detention, under the
National Referral Mechanism (NRM), JB became entitled to support as a 'potential victim of trafficking'. The NRM
provided the machinery for determining whether someone was a potential or confirmed victim of trafficking and for
ensuring they received the appropriate support. Support was delivered to potential victims in England by the
Salvation Army as prime contractor (and by its subcontracted support providers) pursuant to the Victim Care
Contract (VCC) made between the Home Office and the Salvation Army. JB issued a claim for judicial review. He
[sought additional (and backdated) payments, increasing his financial support from £35 (under the Immigration and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
_[Asylum Act 1999 regime) to £65 per week, on the basis that he had been entitled to that amount under the terms of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)_
[a Home Office document entitled 'Modern Slavery Act 2015 – Statutory Guidance for England and Wales' (the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
MSAG) issued by the Home Secretary in 2020 (the 2020 Guidance). The Administrative Court decided that, as both


-----

an asylum seeker and a victim of modern slavery, JB had been entitled to £65 per week, pursuant to para 15.37 of
the MSAG, regardless of the fact that during the period in question he had also been provided with temporary
[support under s 95 of the Immigration and Asylum Act 1999 (IAA 1999) and temporary asylum accommodation on a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61R0-TWPY-Y0HB-00000-00&context=1519360)
full board basis. The judge held that there was no ambiguity. The policy was clear as it stated that a person who
was both potential victim and an asylum seeker receiving financial support under, in the case, s 95 IAA would
receive a total of £65 per week. The Secretary of State appealed.

**Issues and decisions**

Whether the appeal should be allowed. It was submitted that on a correct interpretation of the March 2020
Guidance, the level of financial payments was intended to turn upon the nature of the accommodation provided
[(self-catering or full-board), not on the regime under which it was provided (whether it was provided under IAA 1999](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
or the VCC).

The judge had been correct for the reasons he had given. Paragraph 15.36 of the 2020 Guidance drew a distinction
between catered and self-catered VCC and if the matter ended there, JB would not have been entitled to payments
of £65 per week. But the matter did not end there, because of the inclusion in the document of para 15.37. That
stated in categorical terms that if a potential victim of trafficking was also an asylum seeker and receiving asylum
support, a further payment was to be made to him to make a total (including the asylum support) of £65 per week.
Nothing was said about any offset for the value of meals provided in catered accommodation; nor was any
distinction made between claimants who were in catered accommodation and those who were in self-catered
accommodation. It would not have been difficult to draft a paragraph making such a distinction, and an amended
scheme was introduced five months later (see [64] of the judgment).

It seemed a reasonable inference that the reason why para 15.37 in the March 2020 version read as it had done
was because the practice before the onset of the pandemic was that people in JB's position would typically spend
only a short time (4-6 weeks was a common period) in catered accommodation before being moved on. Although
the document was issued on 24 March 2020, it had been drafted before the onset of the pandemic and the
beginning of the series of lockdowns. That was not that was not a reason to change the plain and obvious meaning
of para 15.37 (see [65] of the judgment).

There was no merit in the Secretary of State's argument that since JB was not in fact 'receiving financial support' (in
[the sense of cash payments) under the IAA 1999 for a period beginning on 24 March 2020 that placed him outside](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
para 15.37 (see [66] of the judgment).

Nor could it be said that para 15.37 contained an obvious error. The construction of para 15.37, which the judge
found to be correct, was consistent with the terms of the VCC between the Home Office and the Salvation Army;
and also with the answer given to 'question 2' in the FAQs document first issued by the Home Office in January
2020 and re-issued soon after the promulgation of the guidance in 2020 (see [69] [71] of the judgment).

The appeal would be dismissed (see [74] of the judgment).

_R (on the application of EM) v Secretary of State for the Home Department_ _[2018] EWCA Civ 1070, [2018] 3 CMLR_
[1152, [2018] 1 WLR 4386, [2018] All ER (D) 113 (May) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCR-C3C1-DYBP-N2GW-00000-00&context=1519360)

_R (on the application of K and another) v Secretary of State for the Home Department_ _[2018] EWHC 2951 (Admin),_

[[2019] 4 WLR 92, [2018] All ER (D) 50 (Nov) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TPV-5BX1-DYBP-N303-00000-00&context=1519360)

_R (on the application of Ghulam and others) v Secretary of State for the Home Department_ _[2016] EWHC 2639_
_[(Admin), [2016] All ER (D) 06 (Nov) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2T-YN91-DYBP-N3B8-00000-00&context=1519360)_

_R (on the application of Raissi) v Secretary of State for the Home Department_ _[[2008] EWCA Civ 72, [2008] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SN8-84C0-TWP1-61HP-00000-00&context=1519360)_
_[1023, [2008] QB 836, [2008] 3 WLR 375, (2008) Times, 22 February, [2008] All ER (D) 215 (Feb) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SN8-84C0-TWP1-61HP-00000-00&context=1519360)_


-----

_Mahad (previously referred to as AM) (Ethiopia) v Entry Clearance Officer_ _[[2009] UKSC 16, [2010] 2 All ER 535,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YF1-VH60-Y96Y-G05J-00000-00&context=1519360)_

[[2010] 1 WLR 48, (2009) Times, 21 December, [2009] All ER (D) 156 (Dec), 153 Sol Jo (no 48) 34, [2010] INLR 268](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XB5-CNX0-Y96Y-H145-00000-00&context=1519360)
considered

[Decision of Peter Marquand (sitting as a deputy judge of the High Court) [2021] EWHC 3417 (Admin) affirmed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64B0-MGX3-GXF6-83VK-00000-00&context=1519360)

Lisa Giovannetti KC and Colin Thomann (instructed by Government Legal Department) for the appellant, the
Secretary of State.

Chris Buttler KC and Ayesha Christie (instructed by Duncan Lewis) for the respondent, JB.
Tara Psaila, Barrister.

**End of Document**


-----

