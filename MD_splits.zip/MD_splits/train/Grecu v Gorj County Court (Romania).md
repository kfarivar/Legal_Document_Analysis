# Grecu v Gorj County Court (Romania) [2022] EWHC 2056 (Admin)

Queen's Bench Division, Administrative Court (London)

Thornton J

29 July 2022Judgment

**Martin Henley (instructed by AM International Solicitors) for the Claimant**

**David Ball (instructed by the CPS) for the Defendant**

Hearing date: 19th July 2022

- - - - - - - - - - - - - - - - - - - - 
Approved Judgment

_This judgment was handed down by the Judge remotely by circulation to the parties' representatives by_
_email and release to the National Archives. The date and time for hand-down is deemed to be 15:00pm on Friday_
_29th July 2022._

**The Hon. Mrs Justice Thornton:**

**Introduction**

1. This is an appeal against an order, made on 5 November 2021, for the Appellant's extradition to
Romania to serve a sentence of seven years six months, for convictions relating to the trafficking of two
teenage girls from Romania to Italy for sexual exploitation.

2. The grounds of appeal before the Court are that extradition would be an unjustified interference with the
Appellant's rights under Articles 4 and 8 of the European Convention on Human Rights (ECHR). An appeal
based on Article 3 of the Convention is stayed pending the outcome of the decision of the Divisional Court
in Marinescu, Rusu and Varlan v Romania (CO/4624/2020, CO/4507/2020, CO/4353/2020).

**Factual Background**

3. On 6 September 2015, the Appellant, with the help of others, “recruited, guided, transported and
transferred” a 15-year-old girl over the Romanian border to Italy using forged identification documents. On
2 December 2015 the Appellant did the same, this time with a 16-year-old girl. The purpose of transporting
the girls was “their sexual exploitation in Italy.” As part of the offending the Appellant was involved in the
production of two counterfeit identity documents for the 15-year-old, and two counterfeit powers of attorney
for the 16-year-old.

4. The Appellant was subsequently convicted of having “initiated and set up a criminal group” with two
others to traffic people, including minors, for sexual exploitation. The Appellant was present at the trial,
after which a sentence of 6 years was passed, on 21 January 2019, by Gorj County Court.

5. The Appellant was also present at the hearing of the case on appeal, represented by a lawyer of her
choice.  Her appeal was dismissed by the Craoiva Court of Appeal on 20 February 2020 and her sentence
was increased from 6 years to 7 years 6 months. The sentence of her co-defendant, her brother, Costinel


-----

Constantin Breazu, was reduced to 6 years. The Appellant's other co-defendant, her ex-partner, Stamiou
Dumitru Daniel, was sentenced to 14 years in custody.

6. The Respondent seeks the Appellant's extradition on the basis of a European Arrest Warrant issued on
4 March 2020 and certified by the National Crime Agency on 15 January 2021.

7. On 19 January 2021 the Appellant was arrested in the UK. Whilst in custody at HMP Bronzefield, she
was referred to the Home Office's National Referral Mechanism, a framework for identifying potential
victims of modern slavery.  On 16 July 2021 the Single Competent Authority issued a decision there were
reasonable grounds to conclude the Appellant is a victim of modern slavery.

8. An Extradition hearing was held on 15 October 2021. On 5 November 2021, her extradition was
ordered.

9. On 10 November 2021, the Appellant lodged an appeal. Permission was refused on the papers. The
Appellant renewed her appeal and applied to adduce fresh evidence, which included an unsigned and
undated statement from the Appellant's current partner stating that in the event she is extradited he will not
be a carer for her son Antonio Stanoiu and intends to leave him in the care of the local authority.

10. At an oral permission hearing on 8 April 2022, permission was granted on the grounds that extradition
would not be compatible with the Appellant's rights under Articles 3, 4 and 8 of the European Convention
on Human Rights (s21 Extradition Act 2003).

11. By a decision dated 13 June 2022, the Single Competent Authority under the national referral
mechanism for **_modern slavery decided that there are not currently conclusive grounds to identify the_**
Appellant as a victim of modern slavery.

12.  Shortly before the appeal hearing on 19 July 2022, the Appellant applied to stay her appeal on Article
3 ECHR pending the outcome of the decision of the Divisional Court in _Marinescu, Rusu and Varlan v_
_Romania (CO/4624/2020, CO/4507/2020, CO/4353/2020). The Respondent had no objection to a stay and_
accordingly the substantive hearing proceeded on the basis that the issues before the Court are whether
the District Judge was wrong to order extradition on the basis of Article 4 and Article 8 ECHR.

**Legal framework**

_Test for a successful appeal_

13. The High Court can only allow an appeal against an order for extradition if the first instance judge,
“ought to have decided a question before him…differently” or evidence is available that was not available
at the extradition hearing, which would have required the first instance judge to discharge the extradition
order (s27(2) Extradition Act 2003). The test is frequently said to be that the decision of the District Judge
can only be successfully challenged if it is demonstrated to be “wrong” (USA v Giese (No 1) [2015] EWHC
_2733 (Admin) §15); Love v USA [2018] EWHC 172 (Admin), §26; Surico v Italy [2018] EWHC 401 (Admin),_
§27)).

_Article 4 ECHR_

14. Article 4 of the ECHR provides that:

1 No one shall be held in slavery or servitude.

2 No one shall be required to perform forced or compulsory labour.

15. The UK is a signatory to the European Convention Against Trafficking ("ECAT"), which includes an
obligation on Contracting states to identify potential and actual victims of "modern slavery". **_Modern_**
**_slavery includes human trafficking, slavery, servitude and forced labour. The UK has chosen to implement_**
its obligation by the introduction of the National Referral Mechanism (“NRM”), a framework for identifying
and referring potential victims of **_modern slavery and ensuring they receive appropriate support.  Law_**
enforcement agencies, local authorities and immigration officials and other public authorities who
encounter potential victims of **_modern slavery are required to refer those individuals to the NRM._**


-----

Following a referral, decision-making is carried out by the "Single Competent Authority " in two stages.
The first stage is a decision whether the decision-maker suspects but cannot prove that the individual is a
victim of **_modern slavery. This is referred to as a "reasonable grounds" decision. If that decision is_**
positive, the second stage is a "conclusive grounds" decision as to whether, on the balance of probabilities,
the individual is a victim of modern slavery. A conclusive grounds decision requires evidence gathering. A
positive conclusive grounds decision could provide a basis for the individual to make applications under the
immigration system, for example for asylum, leave to remain and/or family reunion (R (BVN) v Secretary of
[State for the Home Department [2022] EWHC 1159 (Admin), §3)).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65FY-VS43-CGX8-02BR-00000-00&context=1519360)

_Article 8 ECHR_

16. Article 8 ECHR provides that:

“1) Everyone has the right to respect for his private and family life, his home and his correspondence

_2) There shall be no interference by a public authority with the exercise of this right except such is in_
_accordance with the law and is necessary in a democratic society in the interests of national security public_
_safety or the economic well being of the country for the prevention of disorder or crime for the protection of_
_health or morals or for the protection of the rights and freedoms of others.”_

17. The question raised under Article 8 is whether the interference with the private and family life of the
person whose extradition is sought is outweighed by the public interest in extradition. There is a constant
and weighty public interest in extradition that those accused of crimes should be brought to trial; the UK
should honour its international obligations and should not become a safe haven for fugitives. That public
interest will always carry great weight, but the weight varies according to the nature and seriousness of the
crime involved. Family life will usually form part of the matters considered by the Court in the requesting
state in sentencing. After finding the facts the first instance judge should ordinarily set out the factors
favouring extradition and those militating against it in a 'balance sheet' before coming to a conclusion on
whether to order extradition. The Appeal Court should only interfere if the first instance Court made the
wrong decision (HH v Deputy Prosecutor of the Italian Republic, Genoa [2013] 1 AC 328§8) (Celinski v
Poland [2015] EWHC 1274 (Admin); [2016] 1 WLR 551§5-13).

_Fresh evidence_

18. In Hungary v Fenyvesi and another [2009] EWHC 231 Admin, it was said that the test in the
Extradition Act that evidence is available on appeal that was not available at the extradition hearing is 'a
_strict test consonant with the parliamentary intent and that of the Framework Decision, that extradition_
_cases should be dealt with speedily and should not generally be held up by an attempt to introduce_
_equivocal fresh evidence which was available to a diligent party at the extradition hearing. A party seeking_
_to persuade the Court that proposed evidence was not available should normally serve a witness_
_statement explaining why it was not available' (32). The threshold is high. The Court must be satisfied that_
the evidence would have resulted in the judge deciding the relevant question differently.  In short, the
evidence must be decisive (35).

**The decision of the District Judge:**

19. In coming to his decision to order extradition, the District Judge heard evidence from the Appellant and
her current partner Mr Alex Obeanu, with whom she has a daughter, born on the 7 April 2020.  The father
of her son, Antonio Stanoius, born on 15 April 2014, is her co-defendant and ex-partner, Stamiou Dumitru
Daniel, currently serving a custodial sentence of 14 years for his role in the trafficking which he, the
Appellant, and her brother were convicted.

20. The District Judge set out the Appellant's account of matters including her “very difficult, toxic,
childhood” when she was physically and sexually abused by her brother. Her ex-partner was described by
her as very abusive and controlling and a perpetrator of domestic violence against her. She said in her
proof that “The police were involved but nobody could really help me”. The Judge referred to evidence of


-----

the Appellant's admission to the Accident and Emergency department on 23 June 2017 for lacerated and
contused hands. The Judge recorded the following relevant evidence:

_“Ms Grecu maintained her innocence in respect of the extradition offences. She said she initially attended_
_the trial as a witness, travelling from her home in Italy. She said she attended the police station, where the_
_police handcuffed her to a radiator and questioned her. She was then told she was a suspect and was_
_required to enter a plea (which was not guilty) at court the following day. She asserted that she told her_
_counsel, who was also representing Daniel, that Daniel, “had controlled me, but he [counsel] never_
_mentioned it in court.” She said that Daniel threatened to kill her if she said anything against him and, on_
_one occasion, he, “smashed my head with his knee in the van” on the way to court._

_…..She said Daniel has powerful connections and has been threatening her and her family recently (22)_

_….She said Daniel is constantly calling Mr Obeanu from prison, making threats to kill her (25)_

_….._

_She said there are video recordings of Daniel making threatening calls from prison recently. She has not_
_reported this to the police in the UK because, “it all started two weeks after I was arrested in January_
_2021.” The threatening messages from Daniel were to Mr Obeanu by WhatsApp and Facebook as well as_
_by phone call. (31)”_

21. The Judge came to the following findings in relation to the question of violence against the Appellant:

“45. Having seen and heard Ms Grecu give evidence, I accept that she has been subjected to some
_degree of violence by others over the years but I am not prepared to accept that this was at the hands of_
_Daniel her ex-partner or at the hands of her brother Breazu. There was a constant theme of victimhood_
_during Ms Grecu's evidence which I found less than convincing. The fact is in Romania she stands_
_convicted of the offences in the warrant, after trial and appeal. It is not for me to make any separate_
_determination in respect of Ms Grecu's guilt or innocence. I note that it plainly suits Ms Grecu's narrative to_
_blame her co-defendants for involving her in the very serious criminality of which she has been convicted._
_There is no independent evidence for Ms Grecu's assertions about being harmed by Daniel (or by her_
_brother). From what I know of his offending, Daniel appears to be a sophisticated criminal and I accept the_
_evidence of Mr Obeanu that he has received threatening phone calls from Daniel. However, what I have_
_been told of the calls indicates that Daniel is aggrieved at being excluded from the life of his son Antonio,_
_rather than being supportive of Ms Grecu's wider assertions. Insofar as Ms Grecu suggested that there are_
_video recordings of Daniel making threatening calls from prison in Romania, I have not been provided with_
_these or seen them documented and I reject that evidence. I did not believe the RP's account of having_
_been assaulted by Daniel in a shared prison van on the way to the trial court (an account for which there is_
_no supporting evidence)” (§ 45)._

22. In addition, he found that the Appellant was a fugitive from justice:

_“I am entirely satisfied so that I am sure that Ms Grecu is a fugitive from justice as a matter of law. Mr_
_Henley did not seek to argue otherwise. On the basis of the facts discussed above at paras 28 to 30 it is_
_clear that she chose to leave Romania in the knowledge that she had been convicted and had a substantial_
_custodial sentence to serve. She left within days of the imposition of the sentence at first instance. In so_
_doing, the RP knowingly and deliberately placed herself beyond the reach of Romania's legal process.”_
(§46)

23. His findings in relation to Mr Obeanu were as follows:

_“48. Alex Obeanu struck me as an honest witness, who wishes to do his best for the RP and for their_
_daughter Helen and for Antonio, whom he regards and loves as his own son. His taking responsibility for_
_the children comes at considerable financial and personal cost. It is commendable that Mr Obeanu has_
_taken this responsible stance. Having observed Mr Obeanu give evidence and having regard to the section_
_7 report, I am sure it is in the children's best interests.”_

24. Turning to consider article 4 of the ECHR, the District Judge observed that:


-----

_73. Mr Henley raised article 4 as an issue for the first time during the extradition hearing. He did not raise it_
_in his Statement of Issues or otherwise give notice of the point before the hearing. For the foregoing reason_
_and due to lack of court time, I made directions for Mr Henley to put submissions on article 4 in writing and_
_for Mr Ball to respond. I am grateful to both counsel for their comprehensive written submissions, which I_
_have considered in full. I need not rehearse them in their entirety here._

25. Having summarised the submissions before him, he concluded as follows:

_76. I do not accept the factual premise on which Mr Henley's argument is based. On the evidence before_
_me the RP had not been trafficked nor has she been a victim of modern slavery – in Romania, the UK, or_
_anywhere. I did not understand Ms Grecu to say that she had been in her evidence. What she said was_
_that she had been the victim of repeated violence and domestic abuse at the hands of Daniel and her_
_brother (and, previously, of sexual abuse by her brother). The issue of_ **_modern slavery seems to have_**
_arisen because HMP Wandsworth saw fit to make the relevant referral. I agree with Mr Ball that the RP_
_would not have a defence in this country under section 45. In any event, if that were so there would be an_
_irrefutable argument in respect of dual criminality, which Mr Henley has not raised. I also accept the high_
_standard – risk of flagrant breach – that must be met, and it simply is not met in this case. I accept there is_
_a presumption that Romania will act in accordance with the international instrument to which it is party, and_
_with the Directive, and there is no reason to believe the presumption is displaced. Finally, I accept that_
_these extradition proceedings should not be delayed because of the NRM reasonable grounds decision. In_
_addition to the authorities to which Mr Ball referred, I have in mind the observations of the Lord Chief_
_Justice in Polish Judicial Authority v Celinski [2016] 1 WLR 551at paras 51 to 53 as well as the recent_
_decision in R v Brecani [2021] EWCA Crim 731.”_

26.  Turning to Article 8 he directed himself on the relevant legal principles (as to which there is no
complaint); set out the submissions before him; identified the factors favouring extradition and those
militating against it, before concluding as follows:

_I have concluded that the factors which favour extradition outweigh those which militate against it in this_
_case. The RP is a fugitive with a very substantial sentence to serve for grave crimes. Her family life in this_
_country is of short duration. As undesirable as it is for Ms Grecu to be separated from her children, they are_
_in good care with Mr Obeanu. Mother and children must inevitably be separated for the duration of the RP's_
_sentence, as would be the case if she were a domestic offender sent to prison in this jurisdiction for grave_
_offences. The factors militating against extradition are insufficient, both individually and cumulatively, to_
_overcome the imperative of extradition.”_

**Evidence since the District Judge's decision**

27. Evidence emerging since the District Judge's decision includes an unsigned and undated statement
from the Appellant's current partner which states that in the event, she is extradited he will not be a longterm carer for her son Antonio Stanoiu and intends to leave him in the care of the local authority. An
addendum statement from the Appellant, dated 24 March 2022 explains her significant anxiety and
concern about the prospect of Antonio going into care and the 'devastating psychological impact' on him of
losing his mother, stepfather and sister. She says that none of her family members have expressed a
willingness to care for Antonio.

28. In addition, a decision by the Single Competent Authority under the National Referral Mechanism that
there are not currently conclusive grounds to identify the Appellant as a victim of **_modern slavery was_**
issued on 13 June 2022. The essential conclusions reached are as follows:

1 **_Modern slavery occurs in Romania and Italy and they are countries where individuals are subject to_**
exploitation.

2 The Appellant has been broadly consistent in her account and there are not considered to be any
credibility concerns.


-----

3 Whilst the Appellant's account of the actions of her brother may indicate that she was the victim of abuse
and sexual assault, this did not amount to exploitation as she had not performed any work under the
menace of penalty, including domestic work.

4 Whilst the Appellant had claimed she had been falsely accused of trafficking, she has made no claim
regarding being trafficked herself and had instead alluded to suffering abuse/domestic violence. However,
domestic abuse does not constitute modern slavery.

5 Romania is considered to have a robust judicial system in place to allow for the competent prosecution
of traffickers and weight is given to her convictions as a perpetrator of trafficking rather than a victim.

**Submissions**

29. On behalf of the Appellant, it was submitted that the Judge applied the wrong legal test in his
consideration of Article 4, namely that the basis on which extradition ought to be refused is a flagrant
breach of Article 4 rights rather than a real risk of Article 4 mistreatment. The Judge's finding that the
Appellant had been subject to violence by a third party was a central finding and was irrational. No party
had suggested to the Judge that anyone other than the Appellant's ex-partner and brother were
responsible for the violence. The finding that 'There was a constant theme of victimhood during Ms
_Grecu's evidence which I found less than convincing' was grossly unfair and irrational. Victims of sexual_
violence have long been disbelieved. This is a classic case of coercive control. On Article 8, a further
development since the decision by the District Judge is that Mr Obeanu will not take responsibility for the
Appellant's son in the event of her extradition with the effect that Antonio may well end up in care.
Accordingly, the balance falls firmly in favour of refusing extradition.

30. On behalf of the Judicial Authority it was submitted that the test is whether Romania would afford the
Requested Person no protection to any infringement under Article 4 on her return (a flagrant breach test).
[Nonetheless, it is apparent from the case of MST v Eritrea [2016] UKUT 0043 (IAC) that this is not a settled](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J17-2WG1-F0JY-C38X-00000-00&context=1519360)
area. However, the Appellant fails on the facts whichever test is applied. As regards Article 8, the Court
should be astute to the risk of the family altering its position as regards care of the Appellant's son in order
to bolster their case. Due to the seriousness and length of the sentence compounded by the Appellant's
fugitive status, extradition remains proportionate.

**Discussion**

_Article 4_

_The legal test for refusing extradition_

31. It was common ground that the test engaged in relation to Article 3 rights is the existence of strong or
substantial grounds for believing that the person concerned, if extradited, faces a real risk of being
subjected to torture or to inhuman or degrading treatment of punishment in the requesting country (R
(Ullah) v Special Adjudicator [2004] 2 AC 323).  It was common ground that a 'real risk' is a lower
threshold than the balance of probabilities (Sivakumaran [19988] 1 AC 958).

32. In support of his submission that the test is a 'flagrant denial' or 'gross violation' of Article 4, Mr Ball
pointed to Lord Bingham's analysis in Ullah that

“While the Strasbourg jurisprudence does not preclude reliance on articles other than article 3 as a ground
_for resisting extradition or expulsion, it makes it quite clear that successful reliance demands presentation_
_of a very strong case. …. Where reliance is placed on article 6 it must be shown that a person has suffered_
_or risks suffering a flagrant denial of a fair trial in the receiving state: Successful reliance on article 5 would_
_have to meet no less exacting a test. The lack of success of applicants relying on articles 2, 5 and 6 before_
_the Strasbourg court highlights the difficulty of meeting the stringent test which that court imposes.” (§24)_

33. Mr Ball also cited the case of Rwanda v Nteziryayo [2017] EWHC 1912 (Admin) §62 and the decision
of the European Court of Human Rights in Othman v UK (2012) 55 EHRR 1, §232.


-----

34. I accept that the cases relied on by Mr Ball refer, in broad terms, to the flagrant breach test as applying
to all Articles of the Convention, save for Article 3. Nonetheless, none of the cases are directly concerned
with Article 4 rights. In my view, there is some suggestion in Ullah, which was concerned with freedom of
conscience and religion under Article 9, that Article 4 rights may be akin to Article 3 in this context:

_“16 Authority on the applicability in a foreign case of article 4 of the convention… is scant. The house was_
_referred only to one admissibility decision … The respondents are probably right to submit that a claim_
_under article 4, if strong enough, would succeed under article 3. But it would seem to be inconsistent with_
_the humanitarian principles underpinning the convention to accept that, if the facts were strong enough, a_
_claim would be rejected even if it were based on article 4 alone.”_

35. Mr Ball conceded that this is not a settled area. He properly drew the Court's attention to a decision of
the Upper Tribunal in MST v Eritrea _[[2016] UKUT 00443 (IAC), in which the Tribunal considered the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M17-W5M1-F0JY-C374-00000-00&context=1519360)_
applicability of Article 4 in the context of military service in Eritrea. The Upper Tribunal expressed concern
about the application of a flagrant breach threshold and pointed to the scope for heavy factual overlap
between Articles 3 and 4 before expressing the view that “ It would be odd if the same set of facts showing
_that there was a real risk of a person being exposed to slavery or servitude or forced labour could result in_
_a finding of a violation of Article 3 but not of Article 4, by virtue of the latter requiring a higher threshold”._
The Tribunal went on to apply both tests.

36. In the present case, the District Judge applied a 'flagrant breach' test and concluded that the test was
not met.  For present purposes I propose to assess the facts by reference to both tests and to consider the
correct test should it become necessary to do so.

_The District Judge's assessment of violence inflicted on the Appellant - irrationality_

37. Mr Henley submitted that the District Judge was irrational in finding; firstly, that the Appellant had been
subject to violence from others, but not from her brother or partner and secondly; in finding that 'there was
_a constant theme of victimhood' during Ms Grecu's evidence' which he 'found less than convincing'._

38. Mr Henley's submissions were forensically focussed on the first five lines of the relevant paragraph of
the judgment (§45) but it is necessary to consider them in the context of his analysis, and the evidence, as
a whole.

39. The central judicial finding was that the District Judge was not persuaded that the Appellant had been
subject to violence by her brother or partner. It is apparent from a review of paragraph 45 as a whole that
the basis of his reasoning for this conclusion was as follows:

1 an absence of independent evidence of violence by the co-defendants (There is no independent
_evidence for Ms Grecu's assertions about being harmed by Daniel (or by her brother))._

2 the Appellant's conviction as a perpetrator of trafficking alongside her ex-partner and brother as codefendants ('The fact is in Romania she stands convicted of the offences in the warrant, after trial and
_appeal. It is not for me to make any separate determination in respect of Ms Grecu's guilt or innocence)._

3 motive: (it plainly suits Ms Grecu's narrative to blame her co-defendants for involving her in the very
_serious criminality of which she has been convicted)._

4 an assessment that threats by the Appellant's ex-partner may be explained by exclusion from the life of
his son Antonio, rather than being supportive of Ms Grecu's wider assertions about his violence towards
her.

5 doubts about the Appellant's credibility (There was a constant theme of victimhood during Ms Grecu's
_evidence which I found less than convincing)_

40. It is well established that the threshold for a successful irrationality challenge is high. I am not
persuaded that the threshold is met. The high point of Mr Henley's case in this regard is the 2017
photographs from the hospital but they only provide evidence of violence against the Appellant (which the
Judge accepted) but no assistance as to the identity of the perpetrator(s).  On the material before the
Judge it cannot be said that there was anything irrational about his conclusion that he was not persuaded


-----

that the violence had been administered by the Appellant's brother or ex-partner. Read fairly, his reference
to the 'constant theme of victimhood during Ms Grecu's evidence' is no more than an assessment of the
Appellant's credibility.  In reality, Mr Henley's submissions amounted to a disagreement with the District
Judge's conclusions. Extradition appeals are not re-hearings of evidence. Courts normally have to respect
the findings of fact made by the district judge, especially if he has heard oral evidence, as here (Love v
USA [2018] EWHC 172 (Admin), at §25-26).

_The District Judge's decision on Article 4_

41. Mr Henley sought to develop his case that the Judge had come to the wrong decision on Article 4 by
submitting that the evidence of domestic violence towards the Appellant amounted to coercive control
which had forced the Appellant into criminality, (namely the trafficking of the young girls from Romania to
Italy) and which amounted to exploitation and modern slavery. The Appellant had been in the hands of a
group who would 'reacquire her' on return and by sending her back the Court will be putting her at risk.

42. There are however a number of insurmountable difficulties with Mr Henley's case.

43. Firstly, it is apparent from his ruling that the District Judge, who heard oral evidence, did not accept the
factual premise that the Appellant has been, and will be, the victim of **_modern slavery. Having heard_**
evidence, he pointed out that the Appellant had not put forward a case to say that she was the victim of
**_modern slavery. What she had said was that she had been the victim of repeated violence and domestic_**
abuse at the hands of her ex-partner and brother. I accept Mr Henley's submission that victims of modern
**_slavery may not be aware that they are being exploited and may have consented to elements of their_**
exploitation or accepted their situation.  The NRM Guidance highlights this as a feature of **_modern_**
**_slavery cases. However, other difficulties remain with the Appellant's case._**

44. Secondly, the effect of Mr Henley's submissions is to seek to undermine the Appellant's convictions for
trafficking in the Romanian Courts. Mr Henley quite properly accepted that it was not open to him, or this
Court, to go behind the convictions.  Thus, as the District Judge pointed out, the fact remains that the
Appellant was convicted as a perpetrator of the exploitative crime of trafficking. She was not considered a
victim of exploitation. Mr Henley accepted that Romania is a signatory and subject to the Trafficking
Convention, the Trafficking Directive and Article 4 European Convention on Human Rights. As such there
is a presumption that Romania will comply with these international obligations. Any attempt to displace
such a presumption requires “clear, cogent and compelling evidence” (Krolik v Poland [2013] 1 WLR 490;
§4). Mr Henley sought to rebut the presumption by a suggestion that the issue of modern slavery may not
have been fully understood by the Appellant or her legal representative in Romania, before correctly
conceding that there was no evidential basis upon which to advance this argument. Moreover, at its heart,
**_modern slavery is about duress, a well understood concept.  Mr Henley also sought to submit that the_**
Romanian police had failed the Appellant and would not therefore be able to protect her on return.
However, the only evidential basis for this submission is one line in the Appellant's statement in relation to
the allegations of domestic violence that “the police were involved but nobody could really help me'.

45. Thirdly, the Conclusive Grounds decision, issued after the District Judge's ruling, concludes that the
Appellant is not a victim of trafficking or modern slavery, which underscores the correctness of the District
Judge's decision.   As well as attaching weight to the Appellant's convictions as a perpetrator (not victim)
of trafficking, the decision concludes that domestic violence and sexual assault does not constitute
**_modern slavery.  Mr Henley was unable to point the Court to any legal analysis to undermine this_**
proposition. Mr Henley pointed to the positive assessment of the Appellant's credibility. He also pointed to
the acceptance in the Conclusive Grounds decision that the Appellant has been subject to domestic abuse
and submitted it provides further demonstration of the District Judge's irrationality in refusing to accept the
Appellant had been subject to domestic violence. However, in MS (Pakistan) v Secretary of State for the
Home Department [2020] 1 WLR 1373the Court indicated that, in the context of immigration, the First-Tier
Tribunal was better placed than the NRM to decide whether the appellant was a victim of trafficking.  The
NRM is a paper-based exercise, whereas the District Judge heard evidence, including cross examination
of the Appellant. Moreover, there is a significant disparity between the evidence the Appellant gave in the
extradition proceedings and those she gave to the Single Single Competent Authority In her trafficking


-----

claim she explained that after living with her sister in Romania for 2-3 months her sister's husband decided
to sell her into an arranged marriage.. In her proof there is no mention of being sold into an arranged
marriage. She simply says that she met the person she married around 2013.

46.  Fourthly, as Mr Ball pointed out, the Appellant's ex-partner is in prison for 14 years so it is unclear how
he can present a threat on the Appellant's return.  In response, Mr Henley pointed to the evidence in the
Appellant's proof that her ex-partner attacked her in prison. However, the District Judge addressed this
incident and attached no weight to it in the absence of independent corroboration.  As regards the
Appellant's brother it is of note that the Appellant's sentence for trafficking was increased on appeal to a
longer sentence than that of her brother.

47. Accordingly, taking the evidence in the round, I am not persuaded that either legal test for refusing
extradition on grounds of Article 4 is satisfied.  I am not persuaded that there are strong or substantial
grounds for considering there is a real risk the Appellant will become a victim of modern slavery again on
her return to Romania because I am not persuaded that she has been the victim of **_modern slavery to_**
date. Nor am I persuaded that there are strong grounds to consider that the Appellant risks suffering a
flagrant denial of her Article 4 rights in the event she returns to Romania.  There is a presumption that
Romania will comply with its international obligations in relation to modern slavery and the Appellant has
failed to persuade the Court of any clear, cogent or compelling evidence to the contrary.

_Article 8_

48. The evidence relied on by Mr Henley on this ground is a two-line statement by Mr Obeanu that in the
event the Appellant is extradited to Romania he will not be a long term carer for her son Antonio and
intends to leave him in the care of the Local Authority. The statement is unsigned and undated, which Mr
Henley conceded was unfortunate. The Court was told at the hearing that there is a signed and dated
statement in existence which would be provided to the Court. It has not been.

49. The judgment of the District Judge records the Appellant as giving evidence that 'Antonio regards Mr
_Obeanu as his father. He has no relationship with his biological father'.  The judgment refers to a section_
7 report by a social worker in which the social worker states that “Mr Obeanu reported that if Ms Grecu will
_be extradited to Romania he will remain in the UK with the children and will continue to care for them…”._
Further, and significantly, the Judge assessed Mr Obeanu as

'an honest witness, who wishes to do his best for the RP and for their daughter Helen and for Antonio,
_whom he regards and loves as his own son' (emphasis added)_

50. The evidence raises unanswered questions as to why Mr Obeanu has changed his mind having told
both the District Judge and the social worker that he intended to care for Antonio. No explanation has
been provided in the two-line statement.  Mr Ball submitted that the Court should be wary about accepting
an apparent volte face by the family and suggested it was a change of position designed to favour the
Appellant's case against extradition.

51.  Further, Mr Ball pointed to evidence which, he submitted, indicated that it cannot be assumed that
Antonio will end up in the care of the local authority.  The Appellant's father (Antonio's grandfather) also
lives in the West Midlands, with the Appellant's sister (Antonio's aunt). The section 7 report refers to the
Appellant's mother (Antonio's grandmother) staying with the family in the West Midlands when she visited.
The report describes her as 'an important support for the children and “she will stay with them as long as
she can”. I accept that the evidence from Antonio's aunt was that she assisted Mr Obeanu with childcare
for a few weeks after the Appellant's arrest but was, and remains, unable to do more as a working single
mother of two who also looks after her father.  Her evidence was accepted by the District Judge. In
addition, Mr Henley submitted that Antonio's grandmother has a job in Romania so is unable to do any long
term childcare. Nonetheless, the evidence demonstrates wider family involvement in Antonio's life, to date.

52. Antonio's interests are a primary consideration, but they are not the primary or paramount
consideration (HH v Deputy Prosecutor of the Italian Republic, Genoa [2013] 1 AC 338(Lady Hale §11). At
its highest, if accepted as credible, the fresh evidence indicates uncertainty over Antonio's future care.


-----

The gravity of the Appellant's offending and the fact that she is a fugitive from justice may be said to place
the public interest in extradition at, or around, its highest.  I have carefully considered the factors for and
against extradition and the new evidence. I have arrived at the view that the new evidence is not decisive,
for the reasons explained above. It cannot be said that it would have resulted in the District Judge deciding
the Article 8 assessment differently, although I accept it makes the decision on proportionality more finely
balanced than previously.

**CONCLUSION**

53. For the reasons set out above, the appeal fails.

**End of Document**


-----

