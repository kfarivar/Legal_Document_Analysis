# R v AAJ [2021] EWCA Crim 1278

CA, CRIMINAL DIVISION

202000803 B4, 202000805 B4, 20200464 B3, 20200465 B3

Carr LJ, Spencer J, HHJ Michael Chambers QC

Thursday, 29 July 2021

29/07/2021

LADY JUSTICE CARR:

Introduction

1 We have before us two applications for leave to appeal against conviction and sentences, together with
applications for extensions of time (of more than four years) and an application to rely on fresh evidence pursuant to
s.23 of the Criminal Appeal Act 1968. In circumstances where, as set out below, the applications are unopposed,

they have been referred to the full court by the Registrar for a “rolled‑up” hearing.

2 We grant the necessary extensions of time. The reasons for the delay are explained by the appellant's
vulnerabilities and it is in the interests of justice to do so. We also grant leave to proceed on the substantive
appeals which arise out of the following events.

3 On 2 November 2015 in the Crown Court at Bournemouth before HHJ Harrow ("the Bournemouth Judge") the
appellant, then aged 18, pleaded guilty to two counts of possession with intent to supply class A drugs (crack
cocaine and heroin). On 17 December 2015, before the same court, he was sentenced to 18 months' detention in a
Young Offender Institution on each count, such sentences to run concurrently to each other.

4 On 18 January 2016, in the Crown Court at Isleworth before HHJ Edmunds QC ("the Isleworth Judge") the
appellant, still aged 18, pleaded guilty again to two counts of possession with intent to supply class A drugs (crack
cocaine and heroin). On the same date, before the same court, he was sentenced to 18 months' detention in a
Young Offender Institution on each count, such sentences to run concurrently to each other and to the sentences
imposed for the Bournemouth matters. The Isleworth Judge also made a recommendation for deportation of the
appellant as a foreign national involved in serious offending and having received a sentence of 12 months'
detention or more.

5 Both judges imposed a surcharge order in the sum of £100, when in fact the sum should have been £20
(because of the appellant's age at the time of commission of the offences). The Bournemouth Judge also imposed
a Criminal Courts Charge, which should not have occurred (again because the appellant was under 18 when the
offences were committed).

6 The basis of the appeals is that the appellant was at all the material times a victim of trafficking for the purpose of
exploitation, something not recognised at the time of conviction or sentence. To this end, we have had the benefit
of expert assistance from Ms Ahluwalia for the appellant and Mr Johnson for the respondent; we express our
gratitude for that assistance.


-----

7 As a preliminary matter, we have been invited to make an anonymity order under s.11 of the Contempt of Court
Act 1981. The starting point is the importance of the principle of open justice. Anonymity orders can only be
justified where they are strictly necessary. Any application should be closely scrutinised. Anonymity orders operate
to restrict what is said in open court and stem from the court's inherent powers to make orders for the conduct of its
proceedings in a manner consistent with the need to protect the interests of the proper administration of justice.
The circumstances when it may be appropriate to make such an order have been considered in R v L; R v N _[[2017]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
_[EWCA Crim 2129 (at [9] to [15]) and referred to in R v O](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_ _[2019] EWCA Crim 1389 at [2] and [48]._

8 At the heart of these appeals are matters concerning the forced criminal exploitation of the appellant whilst under
the age of 18. The facts are similar to those in R v N. We are satisfied that it is necessary in the interests of justice
to make an anonymity order. The appellant is now a recognised credible child victim of trafficking and he may have

a genuine and well‑founded fear of reprisal. We order accordingly.

The Facts

9 The appellant was born on 15 April 1997. The offences to which he pleaded guilty were committed when he was
17 years old.

The Bournemouth Matters

10 On the evening of 6 January 2015 a drug user, Mr Brewin, was stopped by the police. He was in possession of
a lock knife and a quantity of Class A drugs separated into 28 individual packages hidden in his rectum. In the early
hours of the next day, 7 January 2015, the police accompanied Mr Brewin back to his flat where they found the
appellant sitting on the sofa. As the police moved to arrest the appellant, he was seen to flick a sock under the
sofa. The sock was found to contain a large number of small packages of cocaine and heroin with a total street
value of just over £6,000. Approximately £350 in cash was also found on the sofa, together with other drugs
paraphernalia elsewhere in the flat. The appellant was said to live in London and was found in possession of a
return rail ticket from Clapham to Bournemouth.

11 The prosecution case was that, although he may well have been acting under the direction of others, he had

taken the drugs from London to Bournemouth in order to sell them from the flat in Bournemouth ‑ a method known

as "cuckooing".

12 The appellant mainly gave a “no comment” interview to the police. He simply stated he had forgotten how he
had got down to Bournemouth.

13 He initially entered guilty pleas on 2 November 2015 on the basis that he was a mere custodian. The matter
was then sent down for a Newton Hearing. However, on 17 December 2015 the appellant made an application to
vacate his guilty pleas on the basis that his instructions now disclosed a defence of duress. The Bournemouth
Judge granted an adjournment for defence counsel to take further instructions in this regard. During that time, the
appellant stated that he had not brought the drugs down from London, but had been told to sell the drugs by a
person in Bournemouth, whom he did not wish to name. He was in fear that he would be "taken into the countryside
and killed" if he did not do as instructed.

14 The Bournemouth Judge refused the application to vacate the guilty pleas. In his judgment it was inappropriate
to do so, because the appellant had been represented by experienced counsel when he entered his pleas and had
not mentioned any account of alleged duress in interview, to previous counsel or the probation services.

15 Defence counsel then submitted that the difference between the prosecution case and the defence case would
not be material for sentencing purposes. The Bournemouth Judge agreed. No Newton Hearing took place and the
Bournemouth Judge moved directly to sentence.

The Isleworth Matters


-----

16 On 14 April 2015, the day before the appellant's 18th birthday and whilst he was on bail in respect of the

Bournemouth matters, an off‑duty un‑uniformed police officer, DC Laura Milne, intervened in an altercation between

the appellant and two other males at Clapham train station. What she saw gave her concerns for the appellant's
welfare; she called for uniformed police to assist her. Her account is important; it was given contemporaneously.
The "boy" to whom she refers is the appellant, as follows:

"... I saw a black‑skinned male aged 15 years wearing a fisherman‑style hat pulled closely down over his eyes. A

muscular light‑skinned black male aged in his late twenties was grabbing hold of the boy from behind and appeared

to be trying to snatch his mobile phone from the boy's right hand. The boy was trying to march on away from the

man. It did not look like a normal robbery situation, as the boy had a stern‑looking expression on his face and he

appeared as though he was trying to get away from the man without trying to draw attention to the situation.

The light‑skinned male was looking around as if he was looking for someone. The light skinned male said, as if to

some passerby who had mentioned it, 'call the police'. He did not say it as if he needed the police. He said it as if
he had done nothing wrong and was justifying his actions by agreeing that they should call the police. I stood in
front of the pair as onlookers were concerned. I said quite loudly 'Stop. Stop. Get off him. I am a police officer.
What's happening?' The boy said that he did not know the man, yet the man was saying to him, 'Is this how you
want to play it?' I was confused as to what was going on, but it was apparent I could not let the boy go as it
appeared as though the man wanted to hurt him. I did not know at that time whether this was a gang related
matter.

I started to call 999 and, as I did so, a light‑skinned pretty female approached me and told me that the boy needed

to leave. I could not let that happen as at the time the man had walked over to a nearby platform, platform 9, and
was calling down to someone. The boy kept saying he needed to go and I stated that I could not protect him if he
walked off.

Train station staff now arrived to assist me and a white female I now know to be Ruth Shulver who worked for
Surrey Police had stopped as she too had witnessed some of what had happened. I was trying to establish from
the boy what had happened and he kept saying he did not know the man and that he was coming back from his
uncle's as he had just collected his birthday present. It was at this point that I noticed the boy was carrying four
bags which appeared full of property ...

The boy ... appeared desperate to leave. I was concerned that the man may be calling others to assault the boy ...

I then asked that it be put to him that he knew the man and asked him outright if this was a gang‑related matter or

whether he was in a gang. The boy stated that he was not and that he did not know the man. This did not appear
to be the case. The man then returned and kept saying 'Is this how you want to deal with this? It will be you that
end up nicked ..."

17 We take this opportunity to commend DC Milne for her brave interventions; others in her position might well not
have acted as she did.

18 When the uniformed officers arrived, the appellant's demeanour changed and he was searched. He was found
to be in possession of over 100 individual packages of cocaine and heroin within a jacket in a shopping bag with a
total street value of approximately £1,300. He also had lists of names and phone numbers and a quantity of cash
(£200) on him.

19 In interview the appellant declined to answer questions, but he gave a prepared statement in which he denied
possession of the drugs on this occasion. However, he set out details of recently being kidnapped and forced to
sell drugs.

Pre‑sentence Report and Mental Health Needs Assessment


-----

20 Both courts had the benefit of a full Pre‑Sentence Report. It recorded that the appellant had indicated that he

had gone to Bournemouth for a party. He had gone to the flat where he was arrested with a friend, who then left
telling him to look after the sock. He claimed that he did not know that there were drugs in the sock. This account
of course amounted to a denial of the offences in question. The appellant also told the report writer that he had

started offending in 2014 when he moved into semi‑independent housing in Lambeth. He met some drug dealers

who told him that he could make money selling drugs for them. The report writer considered the pro‑criminal peer

group to be a contributory factor in the offending.

21 The appellant had been born in Cameroon, but came to the United Kingdom aged 12 with his mother. After a

family breakdown, he was taken into care and at the time of sentence was in semi‑independent housing. He was

not in education or employment. Having had various immigration applications refused, he no longer had a legal
right to remain in this country. He had previously been assessed by the court mental health team and diagnosed as
suffering from depressive conduct disorder, which caused him to be impulsive and aggressive. He had suffered
emotional and physical abuse as a child. The report writer considered the appellant to pose a high risk of
reoffending and a medium risk of harm. However, she also considered him to be a highly vulnerable individual with
an extremely fragile emotional state. He had attempted suicide twice and did not present as having the physical or
cognitive capabilities of an adult. This might leave him vulnerable to manipulation from others, especially in a
criminal environment.

22 The Isleworth Judge also had before him a Mental Health Needs Assessment dated 2 September 2015. The
appellant was known to the Child and Adolescent Mental Health Services due to issues with his care by his birth

mother, but there had been a lack of engagement. He had been re‑referred in 2014 due to his unusual behaviour

and pervasive low mood. He had tried to take his own life on two previous occasions, by walking into oncoming
traffic. He had been diagnosed as suffering from Depressive Conduct Disorder with a repetitive and persistent
pattern of dissocial, aggressive or defiant conduct with enduring and marked depression and mood. He reported a
difficult childhood and an abusive relationship with his birth mother, resulting in him being taken into care. He
wished to have a relationship with her, but it would appear that the mother did not want any contact. He reported
using cannabis regularly and there were queries over whether this was affecting his mental health. The report
writer concluded:

"It is clear that he is a complex and vulnerable individual. He has experienced a traumatic and confusing childhood.
There is psychiatric history suggestive of emerging personality disorder traits that require further assessment and
additional substance misuse problems."

The Immigration Proceedings

23 In January 2016 the Secretary of State issued a decision to deport the appellant. Human rights grounds
submissions were made for the appellant in response and he also claimed asylum. That claim was refused.

24 On 4 September 2018 the Home Office, acting as competent authority ("the Competent Authority"), found that
there were reasonable grounds to believe that the appellant was a victim of **_modern slavery ("the reasonable_**
grounds decision").

25 On 25 February 2019 the Competent Authority concluded that indeed he was such a victim (“the positive
conclusive grounds decision”). The appellant had given a credible account of having been transported to several
countryside locations for the purposes of forced criminality. His account was broadly consistent. The Competent
Authority accepted that he was forced into criminality by being given Class A drugs to carry by the individuals who
had recruited him.

Fresh Evidence


-----

26 As indicated, the appellant applies for leave to adduce fresh evidence. Such evidence may be admitted on the
issue of whether a conviction, even if based on an unequivocal guilty plea, is safe: see R v LZ _[[2012] EWCA Crim](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56BM-1H31-F0JY-C33X-00000-00&context=1519360)_
_[1867.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56BM-1H31-F0JY-C33X-00000-00&context=1519360)_

27 There are three categories of evidence:

i) First, social services records. The appellant was in foster care at the time of the index offences. The records
include contemporaneous notes highlighting the appellant's explanations for past absences on the basis that he
been taken to different parts of the country to hold and deliver drugs for older men whom he would not name for
fear of repercussion. They also record the appellant had been taken to places which he did not recognise or
identify and that his telephone was taken away from him;

ii) Secondly, the positive reasonable grounds and positive conclusive grounds decisions;

iii) Thirdly, a clinical psychology report by Dr Katherine Boucher dated 10 October 2017. Dr Boucher speaks to the
appellant's long-term childhood abuse both physical and sexual. On one occasion he was raped. His mother was
emotionally abusive to him. He started smoking cannabis in 2013 and crack cocaine in 2015. In Dr Boucher's
opinion the appellant meets the diagnostic threshold for a depressive and borderline personality disorder and
anxiety disorder and major depression.

28 We grant leave to adduce this fresh evidence. It is necessary and expedient in the interests of justice to do so.
To admit the positive reasonable grounds and positive conclusive grounds decisions is not inconsistent with the
recent judgment of this court in R v Brecani [2021] EWCA Crim 731. Such material can be used as a tool to assess
the safety of a person's convictions: see [40] in particular. It is perfectly proper to admit it in evidence as relevant
material on this basis. It is not a question of admitting the evidence for the purpose of trial.

Grounds of Appeal

The Bournemouth Matters

29 Ms Ahluwalia submits for the appellant that, whilst recognising that it should be a rare circumstance in which
withdrawal of an unequivocal guilty plea should be permitted, the Bournemouth Judge's decision to refuse to vacate

was wrong in principle. There were evident trafficking indicators of forced criminality and county‑lines exploitation.

No reference was made to Articles 19 and 33 of the United Nations Convention on the Rights of the Child. These
provide, amongst other things, for the obligations on State Parties to take all appropriate measures to protect the
child from all forms of exploitation and to prevent the use of children in the illicit trafficking of narcotic drugs.

30 Secondly, she submits that the police and the Crown Prosecution Service (“the CPS”) failed in relation to their
positive obligations to investigate trafficking indicators and to consider that the appellant was a victim of
exploitation. Reliance is placed on Article 4 of the European Convention on Human Rights (“Article 4”) and SM v
_Croatia (application nos 60561/14) at [58] and [60]; and on_ _VCL and AN v United Kingdom (application nos_

77587/12 and 74603/12) at [199]. Once the features of forced criminality and county‑lines exploitation were

evident, the appellant should have been referred into the national referral mechanism. Additionally, the CPS is said
to have failed to apply its own published policy on modern slavery and trafficking. It ought to have reviewed the
prosecution and properly applied the public interest test.

31 Thirdly and finally, Ms Ahluwalia relies on the fact that the respondent accepts that the appellant was a victim of
trafficking and that there was sufficient nexus between that status and the offending such that the convictions are
now conceded to be unsafe. Realistically, Ms Ahluwalia recognises that this third ground is sufficient of itself to
dispose of this appeal and it is not necessary for her to rely on the first and second of grounds advanced. However,
those grounds have not been formally abandoned.

32 In terms of sentence, it is said that, had the court been aware of the appellant's status and the full details of his
exploitation, the sentences of 18 months' detention would never have been imposed.


-----

The Isleworth Matters

33 Here Ms Ahluwalia submits that, despite the clear indicators of trafficking at the time of arrest and as set out in
interview, no referral was made to the national referral mechanism. Again there was a failure properly to investigate
matters in line with Article 4. The police and the CPS failed to comply with their obligations under international
convention and did not apply their published guidance. Ms Ahluwalia also relies on the respondent's concession
that the convictions are unsafe. The sentences are said, again, to have been manifestly excessive, once the
appellant's true status and the extent of his exploitation are understood.

34 In response, as heralded, the respondent accepts that, applying the relevant law, the appellant's convictions are
unsafe. There is credible evidence that the appellant is a victim of trafficking and that there was a nexus between
the offending and the trafficking. The appellant was a child at the time of both sets of offences and thus the need to
demonstrate compulsion does not apply. The offending does not reach the level of criminality for it to be in the
public interest to prosecute a child victim of modern slavery.

35 In conclusion, whilst recognising that the ultimate assessment of the safety of a conviction is one for this court,
the respondent does not oppose these applications.

Discussion and Analysis

36 The Council of Europe Convention on Action against Trafficking in Human Beings 2004 and the European
Union Directorate 2011/36/EU on Preventing and Combating Trafficking in Human Beings and Protecting its Victims
impose international law obligations on the United Kingdom, which, amongst other things, seek to protect victims of
human trafficking.

[37 The alleged offending here took place before the Modern Slavery Act 2015 (“the MSA”) came into force (on 31](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
July 2015). This court in R v CS and Le _[[2021] EWCA Crim 1341 has confirmed that the statutory defence in s.45](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63KR-6VH3-GXF6-83BY-00000-00&context=1519360)_
of the MSA does not apply retrospectively.

38 The relevant principles are, therefore, to be found in the pre‑existing case law which has been described as

"now well‑travelled territory" (see R v EK _[[2018] EWCA Crim 2961 at [39]). The principles can be found in particular](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-V2S2-8T41-D4NJ-00000-00&context=1519360)_

in R v VSJ _[2017] EWCA Crim 36; [2017] 1 Cr App R 23 (“VSJ”) at [20] to [22]; and R v GS_ _[2018] EWCA Crim_
_1824 at [76]._

39 We summarise them, so far as material, as follows:

i) Where there is a) reason to believe that a defendant has been trafficked for the purpose of exploitation b) no
credible common law defence of duress or necessity but c) evidence of compulsion, then the prosecutor has to
consider whether it is in the public interest to prosecute;

ii) The court's power to stay is a power to ensure that the state has complied with its international obligations and
properly applied its mind to the possibility of not imposing penalties on victims. If proper consideration has not been
given, then a stay should be granted. Where it has been given, the court should not substitute its judgment for that
of the prosecutors;

iii) Where this court concludes that the trial court would have stayed the indictment had an application been made,
the proper course is to quash the conviction;

iv) There is no blanket immunity from prosecution for victims of trafficking. Thus, if there is no reasonable nexus of
connection between the offence and the trafficking, generally a prosecution should proceed. If some nexus
remains, then whether or not to prosecute depends on various factors, including the gravity of the offence, the
degree of continuing compulsion and the alternatives reasonably available to the defendant. Each case is fact
specific;


-----

v) The real question is the extent to which the offences charged, or of which the defendant has been found guilty,

are integral to or consequent upon the exploitation of which the person was a victim, a truly fact‑sensitive decision.

Sometimes culpability will be extinguished. Sometimes it may be diminished, but, nevertheless, significant. In
others it may provide no more than a colourable excuse for criminality;

vi) The reason for diminution or extinction of culpability is not merely from age, but also where there is the realistic
alternative available but to comply with a dominant force of another individual or group;

vii) The decision of the competent authority as to whether or not a person has been trafficked for the purpose of
exploitation is not binding on the court, but, unless there is evidence to contradict it or significant evidence that has
not been considered, it is likely that the courts will respect the decision;

viii) In the case of children there is sufficient nexus if the offence is a direct consequence of the trafficking. It is not
necessary to show compulsion.

40 In our judgment it is not necessary to analyse this case through the lens of international instruments. Rather,
the exercise is to apply the principles laid down in _VSJ in particular; those principles give effect to the relevant_
international obligations.

41 When those principles are applied, the appellant's convictions can be seen to be unsafe and the appeals must
be allowed. There is no proper basis on which to depart from the Competent Authority's findings, including that the
trafficking was for the purpose of being forced to engage in the supply of controlled drugs. The appellant's
offending was a direct consequence of the trafficking. Given that the appellant was a child at the time, the question
of compulsion does not arise.

42 Whilst being involved in the supply of Class A drugs is plainly a serious matter, in circumstances where the
appellant was a child victim of **_modern slavery, it would not have been in the public interest to prosecute the_**
appellant on either indictment. Thus, in our judgment the trial courts would have stayed the indictments, had
applications been made on a properly informed basis.

43 In these circumstances, it is not necessary to consider whether the Bournemouth Judge erred in refusing to
allow the appellant to vacate his guilty pleas or whether the CPS or the police failed in their obligations. Further, the
appeals against sentence are no longer relevant.

Conclusion

44 For these reasons, we quash the convictions. The consequential sentences fall away.

__________

**End of Document**


-----

