# R (on the application of JS) v Secretary Of State For The Home Department 

 [2020] EWHC 500 (Admin)

QBD, ADMINISTRATIVE COURT

CO/4373/2017

HHJ Allan Gore QC

Friday, 21 February 2020

21/02/2020

THE JUDGE:

1 By order made without a hearing, Nicola Davies LJ granted permission to the claimant to apply for judicial review
of the negative conclusive grounds decision of the defendant, dated 19 June 2017, permission having been refused
by Timothy Brennan QC sitting as a Judge of the High Court, but without a hearing, on 7 November and also by
Peter Eggers QC also sitting as a Judge of the High Court at an oral renewal hearing on 19 December 2017.

2 By the decision under challenge, the defendant decided that the claimant was not a victim of human trafficking
from Albania to Belgium for the purposes of sexual exploitation or any kind of exploitation, and therefore that he did
not require a period of leave to enter or remain for any reason associated with being the victim of trafficking, and
she also decided not to believe that the claimant was a victim of slavery, servitude, or forced or compulsory labour,
and that he did not require any leave to remain in the UK.

3 Before I turn to the substantive issues, there are three preliminary issues that I have dealt with. The first is the
question of whether the grant of permission is “limited” in the sense suggested by paragraph 1 of the defendant's
skeleton argument. Correctly, this is no longer pursued by the defendant. It is a misinterpretation of the order of
Nicola Davies LJ. True it is that she identified “reasons” for granting permission, but those reasons do not limit or
restrict the grounds that may be relied upon.

4 The second preliminary matter is that the defendant seeks permission by application notice dated 28 January
2020 “to adduce two short witness statements in response to the claimant's skeleton argument”. In that no objection
is now taken to that course, no further mention of it need be made other than to reflect that the overwhelming bulk
of the first statement from Rebecca Louise Redmond, dated 27 January 2020, is argument or submission that adds
little or nothing to what I have to decide, and the second statement from Catherine Nicholas, dated 28 January
2020, is even less helpful in that the documents referred to, whatever the history concerning their disclosure, were
identified in paragraphs 37-41 of the detailed grounds on behalf of the defendant, dated 29 May 2019, and
exhibited thereto and are now contained in the hearing bundle at section 2, pages 62-67. The history of their
disclosure has no bearing on the decision that I now have to make in the substantive hearing.

5 Thirdly, the claimant's skeleton argument simply objects to the failure to disclose those documents and makes no
submission to the effect that the defendant was not entitled to consider this material or take it into account when
she came to her decision. I was not surprised, therefore, that Mr Collins, counsel who appears for the claimant, told
me that Ground 2 of the challenge is not proceeded with.


-----

6 I turn then to the substantive issues for me to decide. Despite the admirable industry of counsel in their written
and oral submissions, referring me to many authorities and decided cases, there is no dispute that there are really
only two issues for me to decide in this case, both of which are matters of fact or judgement. None of the
authorities, in fact, assist me or illuminate what it is that I must decide.

7 The first issue is whether the decision maker in this case gave adequate “anxious scrutiny” to the decision which
she was obliged to make, there being no dispute that if the defendant cannot satisfy the court that anxious scrutiny
was given to that decision or, in the alternative, if the claimant satisfies the court that anxious scrutiny was not
given, the decision must be quashed. I am reminded, correctly, that, in this regard, it is not for me to substitute my
decision for that of the decision maker. Furthermore, it is not for me to decide whether the decision was irrational or
_Wednesbury unreasonable, although, of course, were I so to find, that would be some evidence that the decision_
was not given the required anxious scrutiny.

8 The second issue is whether the defendant has failed to demonstrate adherence to or compliance with her own
Guidance and, if she has not, whether her failing was such as to justify the quashing of her decision.

9 The context in which these issues fall to be decided is as follows and is largely undisputed as to fact. The
claimant Albanian national was born on [a date]. His father died in September 2013. His bereaved mother entered
into a relationship with a man called Petrit who came to live with her and her children, including the claimant. The
claimant obtained a passport from the relevant authority, which was valid from 7 April 2014. He left Albania in July
2014 and travelled to Belgium and, later still, he travelled to the United Kingdom, arriving on 21 July 2014. He
claimed asylum on 22 July 2014 and his case was referred to the National Referral Mechanism (“NRM”) on 23 July
2014. That referral arose because he claimed that he was taken into a gang by Petrit and then trafficked out of
Albania and into Belgium for the purpose of exploitation, and that, while in Belgium, he was viciously sexually
assaulted and raped by gang members. He described escaping from them and travelling to the UK where he
arrived “clandestinely” although nothing turns on the manner of his arrival. He was one month short of his [an age]
birthday on his arrival in the UK.

10 There is some factual dispute that I turn to later in this judgment as to some of the dates of these events, and
therefore the order in which they took place. For present purposes, it suffices for me to record that, on 28 July 2014,
the NRM made what, to adopt the nomenclature, was a “positive reasonable grounds” decision. As a result, the
claimant attended a Screening Interview on 13 August 2014 and a substantive Asylum Interview on 12 June 2015.
That interval of approaching a year was described by Mr Collins as “not unusual”, and I observe that by then the
claimant was out of the hands of the alleged traffickers and abusers and was but 10 weeks short of his 18th
birthday.

11 These investigations led to the making, again to adopt the nomenclature, of a “negative conclusive grounds
decision” dated 19 June 2017, which is the decision under challenge. It is in fact dated 19 June 2019, which is
clearly an error as it is date-stamped as received by the claimant's solicitors on 21 June 2017. Appended to the
letter is a ten-page, typed narrative of the reasons for the decision, typically unpaginated and not divided into
paragraphs which is unhelpful. The narrative concludes that:

“It has, therefore, been decided that you are not a victim of human trafficking from Albania to Belgium for the
purposes of sexual exploitation or any kind of exploitation. It has, therefore, been decided that you do not require a
period leave for any reason associated with being a victim of trafficking.

Similarly, it is not believed that you are a victim of slavery, servitude or forced/compulsory labour and do not,
therefore, require any leave.”

As a consequence of that decision, the claimant's solicitors wrote a pre-action protocol letter; despite which, on 10
August 2017, the defendant upheld her decision and this claim for judicial review was then issued by claim form
filed on 18 September 2017.

12 As I have already stated, Timothy Brennan QC refused permission without a hearing and Peter Eggers QC did
so upon oral renewal. The claimant sought permission to appeal to the Court of Appeal, and on 19 November 2018


-----

Nichola Davies LJ granted permission to apply for judicial review and directed the matter to be returned to the
Administrative Court. The matter came before me for substantive hearing on 18 February 2020.

13 The referral from the NRM, dated 23 July 2014, under the heading “Brief Applicant History”, records that:

“The applicant claims he left Albania on 5/07/14 by air to Belgium. he claims he left Belgium on 21/07/2014 by
lorry arriving in the UK on the same day…

The applicant has submitted a copy of his passport, he claims his passport was taken by the gang who took him to
Belgium. He has been accepted as age claimed.

Applicant claims his father passed away when it was electrocuted last September 2014.”

I digress to observe that, bearing in mind that this report was dated 23 July 2014, to date this event as occurring in
September 2014 is clearly an error on the part of the NRM.

14 To return to the “Applicant History”,

“he claims his mother started going out with a man called Petrit Xhana. He claims the man was ill-treating him and
later sold him to a criminal gang two months after he lost his father.” I digress to observe that that would be before
Christmas 2013.

Returning to the quotation from the applicant history,

“He claims he saw Petrit talking to the criminal gang and claims he was given something by them. He claims he
was taken to Belgium by these [sic] criminal gang on 5 July 2014 and was locked in a room. He claims they
promised to find him work. He claims they started being violent towards him and he claims, about 10 days after, two
men entered the room where he was kept and raped him and forced him to touch them. He claims he had never
met them before and that they were different from the men who took him to Belgium. He claims he did not know any
of the names. He claims he then left the room immediately. He claims he was scared and could not go back to
Albania.”

15 There is no dispute about the accuracy of the transcript of the questions and answers given during the
screening interview on 13 August 2014. Relevant questions and answers under the headings “Documentation” and
“Health” include the following:

“2.1.  Have you ever had your own national passport showing your correct name and DoB?

A   Yes, I had. It was lost in Belgium.

2.2  Do you have your own national passport with you today?

A.  No. It was lost...

2.4   Have you ever had your own national identity card?

A   Yes, it is in Albania.

Q   military identity card or,

A   No

Q    driving license?

A    No

...


-----

3.1.  Do you have any medical conditions or disabilities?

A   No”

This document is signed by the claimant under declarations that the information given is correct and complete, and
that it is an offence to deceive when being interviewed.

16 There is no dispute about the accuracy of the transcript of the questions and answers given during the Asylum
Interview on 12 June 2015. Relevant questions and answers include the following:

“13.  When did your father pass away?

A.  7 September 2013.

14. Did anyone else live at this address?

A  After my father passed away my mother's boyfriend moved in. Petrit Xhana.

34.  When did your mother first start her relationship Petrit?

A  Before a year completed after my father's death, Petrit Xhana. He moved into my house in June.

Q.  2014?

A  Yes…

36. When did you personally first meet Petrit Xhana?

A  I met him at my house, when he came with my mother.

37. Do you know when this was?

A  In June.

38.  Was this when he moved in?

A.  Yes...

57.  You mentioned that Petrit said he would find you a job.  When did he first say this?

A.  In the beginning of July, when he came in the house he said he would find me a job. And he joined me to a
gang. So to go with the gang outside the country for better life [sic].

58.  How long after he first moved in did he first mention this?

A  In July...

99. Do you know their names? (this is a reference to the men that the claimant travelled with from Albania to
Belgium)

A  No...

120.  When was the first time you met anyone from the gang?

A  In July. Petrit got me involved in this gang...

125.  What day are you referring to?

A B In July, I can't remember the date...


-----

131.  Can you tell me what happened on the day that you were attacked? A: They entered in the room, they
started pulling my trousers by force and they started raping me [I omit the rest of the answer] …

132.  Who entered into the room?

A.  2 men.

133 Was it the same two men that were in the house with you for the two weeks?

A   Yes.”

The signature to this document simply confirms receipt of it.

17 An official document provided by the British Embassy in Tirana, but apparently extracted from an Albanian
border and migration database, confirmed the issue to the claimant of a passport valid from 7 April 2014, asserted
that he was recorded to have travelled out of Albania by air from Tirana International Airport to Brussels on 4 July
2014, and it records “national ID card number: none”.

18 The reasons appended to the decision letter contained the following:

“Immigration Details.

You state that you left Albania 5 or 6 July 2014…

Case Summary. The salient points of your case are as follows…

c) In your NRM referral you stated that your mother started going out with Petrit Gjana and two months after your
father's death he sold you to a criminal gang.

d) Alternatively you met Petrit Xhana after he moved into your family home in June 2014. You had first met Petrit
in June 2014 when he came with your mother and moved in. This was the first time you had met him. He was
violent towards you and your brother, your mother did not intervene. In the beginning if [sic] July when Petrit came
to the house he told you that he would find you a job.

e) Petrit was arranging a job outside Albania to give you a better life as he told you there were no jobs in Albania.
You agreed to this as you were not happy at home and felt that he wanted to evict you. Petrit first mentioned this to
you in July 2014…

g) You travelled with two or three of the gang to Belgium and do not know their names as you had not met them
before. You left Albania 'on 5[th] July 2014 actually 6[th] July 2014'…

i) You were at the house for two weeks before the men came into your room and sexually assaulted you. On the
following day when they were bringing you food you ran out through the open door and escaped. Alternatively this
occurred on the same day the men assaulted you...”

19 Later on in that letter, under the heading, “Conclusive Grounds Decision”, the following is recorded:

“For the reasons set out below, it is considered that you are not a credible witness and therefore, limited/no weight
is attached to your evidence...

In your Asylum Interview at question 34 and 37 you state you first met Petrit in June 2014 when he moved into the
family home with your mother. At question 57 you state 'in the beginning of July, when he first came to the house'.
You then clarified that the first time you met Petrit was June 2014. You have therefore provided an internally
inconsistent account particularly as you stated you left Albania on either the 5 or 6 July 2014 although your Travel
Movement result actually dates this as 4 July 2014. In both your NRM referral and Asylum Interview you state your
father died in September 2013. However, in your NRM referral, you state that Petrit came into your life within two


-----

months of this event which is before Christmas 2013 and significantly before June/July 2014 timeframe in your
Asylum Interview and coincided with the finishing of the school year…

You state the first time you discussed getting a job outside Albania with Petrit was in July 2014 and that you left
Albania on 5 or 6 July 2014. You are very specific as to the date you state you left Albania although on a number of
other occasions you state you give only the month of events. You felt that Petrit wanted to get you out of the house
but you do not know why this was, he would beat you and your brother and told you he would help you to get a job.
Despite less than a week elapsing between this conversation and you leaving Albania you state that you know the
gang were stealing, robbing and threatening in Albania and that Petrit knows senior police and government officials
because you were with him when he met them on the streets although you were not allowed to come near them.
You cannot name the gang, believe there to be twelve members but can only give three names, do not know who
the leaders is [sic] or the roles of any of the gang. It is considered that your level of knowledge of these points is
inconsistent with your assertion that you know the nature of the activities the gang were involved in or Petrit's
contracts [sic]. Your logic that Petrit was a member of the gang because he included you is considered to be
speculative on your part however you were willing to go with these people as you believed they would find you a job
and it was a way to leave Petrit. Your basis for Petrit being a member of this gang is because he was bad man and
mistreated your family at home. You state you met the gang in July and the Travel Movement Record shows you
left on 4 July 2014. You also state that the first time you discussed working abroad was in July which leaves a very
minimal timeframe in which to make any arrangements.

Your passport was issued on 7 April 2014. You had with you a photocopy this when you arrived in the UK and
state that this was because it was in your jacket which you were wearing when you ran out of the room. In your
Screening Interview you state that your passport was lost in Belgium however in your Asylum Interview you state it
was retained by the men in the house. You also state that your ID card remains in Albania however the Travel
Movement Record indicates that you do not have a national ID card issued. The obtaining of your passport in April
2014 strongly suggests that you had an intention to travel prior to the conversation with Petrit and prior to meeting
Petrit. Given that your father had been the sole breadwinner in the family and your mother did not work, the
expense of a passport would have been an unnecessary one if you were not planning to travel. The cost of the
passport is 50 Euros and can be obtained with the ID card and no further family involvement for those over sixteen
years of age.

You state that once in Belgium 'we' were placed in the house. You later state you do not know where the other
men went and you were with two different men in Belgium and there was only you and them at the property. You
were with these two men for two weeks but were unaware of their names despite the men speaking to you in
Albanian and to each other in a foreign language. You state they had not threatened you prior to the assault, gave
you an explanation for why you were not to go out and provided you with food while promising to find you work. The
men prepared you food because you were unable to do this for yourself and told you that you were not allowed to
move around the other rooms of the house. When you were asked to describe the house you replied with 'it was a
simple house'. It was only after you were assaulted that you became concerned that the men intended to plan
something for you other than to find a job.

You state you left Albania with two or three people; it is considered reasonable to expect that you would be able to
recall the number of people you were travelling with and their names. It is also considered reasonable that after two
weeks of staying with the two men you would have established their names given you state you were not initially
concerned about their treatment of you as you believed they would find work.

You have given a detailed description of being the victim of a sexual assault sold by the two men who you state
threatened to harm you if you told anyone about this. You have stated that you escaped either on the same day as
the assault or alternatively on the following day. No significant weight is placed on this discrepancy as you were
clearly upset by these events which are considered to be the description of being the victim of a sexual assault…

Consideration has been given as to whether there are mitigating circumstances in relation to your account.


-----

No evidence has been received to suggest that you were suffering from any mental, psychological or emotional
trauma and you have not received any counselling. Consideration has been given to your age at the time of these
events you were seventeen years old. It is considered that your age alone does not mitigate for the difference
between your NRM referral and the Asylum Interview such as when you met Petrit and whether you were sold to
the gang or not. There is no medical evidence submitted that may account for these inconsistencies. It is
considered there are no mitigating circumstances in your case and therefore, due to the internal inconsistencies
your account, your credibility has been damaged to the extent that your claim to have been exploited cannot be
believed.”

20 Before leaving the decision letter, it is noteworthy that, it accepted - and there is no dispute - that **_modern_**
**_slavery is prevalent in Albania and Belgium and that both are countries where children are subject to exploitation._**
Moreover, there is specific reference to certain “Guidance to Competent Authorities”. There is no dispute that the
passages cited in the decision letter are all from the generic sections of that document. There is no dispute that the
reasons appended to the decision letter did not refer to what Mr Collins submits to be relevant guidance specific to
child victims of modern slavery which are in the following terms:

“Determining whether a child is a victim of modern slavery

To determine whether a child is a victim of **_modern slavery, Competent Authority staff need knowledge and_**
understanding about child victims of **_modern slavery, as characteristics and issues may be different to adult_**
victims.

In cases of potential child victims, you must remember that it is not possible for a child to give informed consent,
so you do not need to consider the means used for the exploitation – whether they were forced, coerced or
deceived etc. You must also keep in mind the child's:

∙ added vulnerability

∙ developmental stage

∙ possible grooming by the perpetrator

No child's case should be considered without contacting individuals who specialise in children from a Local
Authority.”

That is from internal page 44 of version 3.0 of the Competent Authority Guidance (“the Guidance”).

21 That Guidance continues later in the following terms:

“When the Competent Authority assesses the credibility of a claim, there may be mitigating reasons why a
potential victim of human trafficking or **_modern slavery is incoherent, inconsistent or delays giving details of_**
material facts. The Competent Authority must take these reasons into account when considering the credibility of a
claim. Such factors may include, but are not limited to, the following:

∙ trauma (mental, psychological, or emotional)

∙ inability to express themselves clearly

∙ mistrust of authorities

∙ feelings of shame

∙ painful memories (including those of a sexual nature)

Children may be unable to disclose or give a consistent credible account due to additional factors such as:

∙ their age


-----

∙ the on-going nature of abuse throughout childhood

∙ fear of traffickers or modern slavery facilitators, violence, or witchcraft.”

That extract is from internal page 99 of the Competent Authority Guidance.

22 Mr Fisher, who appeared for the defendant, in paragraph 32 of his skeleton argument, by reference to all of the
evidence that I have now set out, relies on the following inconsistencies as undermining the credibility of the
claimant, the identification of which in the decision letter demonstrates, he submits, that anxious scrutiny was given
and that this challenge should fail. Those inconsistencies are as follows.

23 Firstly, the date of death of the claimant's father, 2013 or 2014. I have already demonstrated that this is not an
inconsistency, but simply an error on the part of the official who completed the NRM referral.

24 Secondly, whether Petrit came into the claimant's life within two months of the death of his father, i.e. before
Christmas 2014, or in June or July 2014. There are in fact only two sources that could support the earlier date. One
is the answer to question 36 in the Asylum Interview, but in my judgment there is no real inconsistency here
because I construe that answer as a referral to when Petrit moved into his mother's house, and there is no
inconsistency as to that date. That is supported by and consistent with paragraph 5 of the claimant's witness
statement dated 13 July 2017 in support of this claim, and also with paragraph 6 of his earlier witness statement
dated 5 July 2014. The second source is the assertion in the NRM referral of being sold to the gang two months
after he lost his father. That account is second-hand hearsay not confirmed in a witness statement with signed
statement of truth and not contemporaneously acknowledged or accepted by the claimant. I attach little or no weight
to that reference and therefore reject the submission of inconsistency on this issue.

25 Thirdly, there is and can be no dispute that the claimant has been inconsistent as regards his passport,
variously saying that it was lost, left behind or taken from him. I accept that this inconsistency is significant.

26 Fourthly, does he or does he not possess an ID card? Just because the Albanian border and immigration
database has no record of it, does not mean that he did not have one. His consistent account is that he did. What
he said in this regard, both in the screening interview and in the asylum interview is supported by and consistent
with what he said in paragraph 9 of his witness statement, dated 9 July 2017. There is therefore, in my judgment,
nothing in this point.

27 Fifthly, it is submitted that there is inconsistency in the history as to whether he was introduced to or sold into
the gang. The source of the latter is the same sentence in the NRM referral that I have attached little weight to for
reasons I have already expressed, and therefore I do not accept that there was significant inconsistency in this
regard either.

28 Sixthly, there is no inconsistency about recollection of names, but simply the expression of opinion on the part
of the decision maker that that absence of names lacks credibility. The claimant however has consistently
maintained that he did not know names and there is no evidence to refute that.

29 Seventhly, true it is that in the Asylum Interview there is inconsistency as to whether Petrit moved into the
claimant's mother's home in June or July 2014, but I do not consider that to be significant or sinister because, at
that time, there would have been no particular reason to regard that date as particularly memorable. Rather, it is the
events that occurred after that event that then become sinister and memorable in the mind of the claimant.

30 Eighthly, true it is that there are gaps in the claimant's evidence about membership, identity and leadership of
and the roles within the gang, but the claimant's account in this regard has been consistent throughout. In addition,
reliance is placed on the inconsistency concerning the date of travel, but it is difficult to ascribe sinister significance
to this inconsistency when Rebecca Redmond, at para.13 of her witness statement, concedes that “this is a minor
discrepancy”.


-----

31 Finally, the decision maker drew attention to discrepancies in the accounts regarding events in Belgium before
the claimant's escape, but promptly discounted them in the decision letter and discounted their significance,
accepting that the claimant was clearly upset by these events and was the victim of sexual assault.

32 I am forced to conclude that the only inconsistency that is serious and significant, in that it may be regarded as
undermining the credibility of the account given by the claimant, is the history relating to what became of his
passport. That is significant because, in my judgment, a young adult can be expected to understand and to
articulate the difference between losing something, something being taken from you, and something being left
behind. In my judgment, however, that inconsistency on its own is not sufficient of itself to justify the decision
reached, and to have taken into account the various other matters identified in the decision letter as relied upon, for
the reasons that I have now given were of doubtful utility, is inconsistent with a finding of anxious scrutiny that I am
invited to make. That is sufficient to enable me to conclude that Ground 1 of the challenge is made out and the
decision of the defendant must be quashed.

33 However, for the sake of completeness and out of deference to the submissions that have been addressed to
me in this regard, in my judgment, the decision letter demonstrates, contrary to the submissions of Mr Collins, that
the decision maker did take into account trauma and painful memories suffered by the claimant and also took into
account his age, simply rejecting that age “alone” mitigated for the discrepancies relied upon. Moreover, for the
reasons identified in section 3 of the Screening Interview and in particular Item 3.1, the decision maker was entitled
to conclude that the claimant was not suffering from any mental, psychological or emotional condition constituting
mitigating circumstances to be taken into account in assessing credibility.

34 I turn then to the third ground of challenge. The Competent Authority Guidance provides in relation to proposed
negative conclusive grounds decisions that:

“To make sure the decision taken is in line with policy, a second caseworker or manager who has appropriate
experience in human trafficking or **_modern slavery work, must review a negative National Referral Mechanism_**
(NRM) decision. Details of the officer responsible for the second pair of eyes review must be recorded on CID
(Home Office only) and the file (Home Office and UKHTC).”

That is at page 54 of the Guidance.

35 The decision letter is signed by Hazel Stancliffe in person. To the right of her signature, there appears a “PP”
signature that may or may not be Ms Stancliffe's, but which is ascribed to Clare Thomasson who is described as
“Acting Operational/Technical Specialist Lead NRM Hub”.

36 Mr Fisher invites me to find that she was the second pair of eyes for this purpose. The basis for his submission
to that effect is as follows. Firstly, Rebecca Redmond, in paragraph 3 of her witness statement, describes herself as
having essentially the same role as Ms Thomasson. Secondly, in pargraph .24 of her witness statement, she
asserts that a second pair of eyes review was undertaken on 30 May 2017 and that fact was noted within Home
Office files.

37 In my judgment, it is troubling that the source of what appears to be a hearsay assertion is not identified. There
is no witness statement from the alleged reviewer. There has been no disclosure of other documents or entries
demonstrating compliance with the requirements of the Guidance. The word “must” appears twice in the passage in
the Guidance that I have identified. There is no witness statement from the decision maker to confirm that she
knows from her own personal knowledge that the second pair of eyes review was undertaken. Indeed, there is no
explanation that entitles me to conclude that Ms Thomasson was the second pair of eyes for this purpose. It would
have been simple, straightforward and inexpensive for these matters to have been addressed in the evidence. They
have not been.

38 I am not satisfied, in those circumstances, that it can be demonstrated on a balance of probability that the
mandatory requirements of the Guidance have been complied with and therefore, in my judgment, the decision of
the defendant must be quashed on the third ground relied upon by the claimant.


-----

39 Accordingly, the order that I make is that the decision, mis-dated 19 June 2019 but in fact made on 19 June
2017, is quashed.

MR COLLINS: My Lord, you will recollect that Mr Fisher and I agree with your take on matters - that costs should
follow the event. Just one other thing, given the nature of part of the account, which, of course, has been accepted
throughout, can I ask for anonymisation?

THE JUDGE: Has that not already been directed?

MR COLLINS: Not that I am aware of.

THE JUDGE: Has it been canvassed with the defendant and is there any objection to me asking, even though he
may be in the invidious position of not being an authorised advocate, the representative of the defendant---
MR COLLINS: I do hold higher rights authority

THE JUDGE: Any objection to anonymisation? Strictly speaking, it ought to have been dealt with at a much earlier
stage. I mean the basis of it is not that he was a child at the time, but it is the personal nature of the information
revealed in the course of the hearing and of course in the terms of the judgment that I have given, and that would
normally be a proper basis under CPR 39 for making the anonymity order now sought. Would there be any
objection to that?

SOLICITOR FOR THE DEFENDANT: There is no objection and I simply note that an anonymity order was granted,
had been applied previously in the Court of Appeal.

MR COLLINS: In the Court of Appeal. That is normal as you know, my Lord.

THE JUDGE: And does that not continue unless the order is revoked? So, do I actually need to make a
freestanding order? If you consider that I do need to do so, I am happy to do so, but once anonymised, always
anonymised unless there is an application to set aside, is there not? Or have I got that wrong?

MR COLLINS: I do not believe there was an application to anonymise in the Court of Appeal---
THE JUDGE: So, it was an order of the court's own motion. But it is still an order.

MR COLLINS: I do not think it was an order. I think every case of this type which goes to the Court of Appeal would
be anonymised as “JS v Albania”.

THE JUDGE: Okay. Well, belt and braces, I am content, since there is no objection, to make that order. Mr Collins,
it is going to unfortunately increase your labours because the view that I take - I know others do not agree with me is that the anonymity order has to be separate from the substantive order in the litigation, and the reason for that is
that it has to contain the liberty to any person to apply to set aside or vary the order. I normally provide that that
requires seven days' notice to the parties, and, of course, that should be freestanding and entirely separate from
the substantive order in the litigation.

So, I am going to invite you to submit to the associate, please, not only a minute of order dealing with the
substantive orders that I make, but a separate anonymity order please. The other reason why that is necessary is
that I think they have to be published on the judicial intranet. I am not entirely convinced of the utility of peppering
that otherwise valuable source of information with literally hundreds of anonymity orders that are not really
illuminating to any users of that internet service, but there it is.

You are legally aided as well, so the costs order that I must make I think in those circumstances, unless, again,
there is any objection to that, is that the defendant pay the claimant's cost of the application to be subject to detailed
assessment on the standard basis if not agreed, together with a detailed assessment of the claimant's costs
pursuant to the public funding certificate, the usual legal aid order.


-----

Anything else gentlemen?

MR COLLINS: No.

THE JUDGE: For my part, I ought not to leave this case without acknowledging and thanking both Mr Collins and
Mr Fisher for both their written and oral advocacy in this case, and I would be grateful if you were to relay those
observations to Mr Fisher since he cannot be with us today. I am grateful, and it is particularly noteworthy and
frankly refreshing that, although this case was given a time estimate of two and a half hours, in fact, if I recall
correctly, you managed to conclude it in an hour and a half, giving me adequate time to reflect on my decision and
prepare it, for which I am grateful.

Anything else, gentlemen? Thank you very much indeed.

__________

**End of Document**


-----

