# R v Cooper [2019] EWCA Crim 2394

CA, CRIMINAL DIVISION

201901601/C2

Holyrode LJ, Warby J, HHJ Munro QC

Wednesday, 13 November 2019

13/11/2019

MR JUSTICE WARBY:

1. On 14 February 2019 in the Crown Court at Snaresbrook, Che Cooper was convicted of wounding with intent,
[contrary to section 18 of the Offences Against the Person Act 1861. On 1 April 2019, he was sentenced by HHJ](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)
Hammerton to detention for a period of 42 months, pursuant to section 91 of the _[Powers of Criminal Courts](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1DG-00000-00&context=1519360)_
_[(Sentencing) Act 2000. The Judge also made a restraining order for 7 years under section 5 of the Protection from](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1DG-00000-00&context=1519360)_
Harassment Act 1997.

2. Applications for leave to appeal against conviction and against sentence were refused by the single Judge.
Today, the challenge to the sentence has been renewed before the Full Court by Miss Booker, who appeared for
the applicant below.

3. The charge arose from a stabbing that took place on Westport Street, Tower Hamlets, in London E1, at about
2.30 in the afternoon of 4 April 2018. The victim, whom we shall call “AQ”, was on Westport Street with friends.
The applicant was in the area as well, along with two others, Santino Dymiter and Sabir Noor. This group spotted
AQ, and the three of them walked towards him. Dymiter was on the phone. He approached the victim and spoke to
him. He referred to an individual called Mohammed Choudhury. The victim heard Dymiter say on the phone:
"Jumel, should I stab him?" The victim panicked, punched Dymiter and ran. He was chased by the applicant and
others; he tripped and fell. Dymiter then stabbed him twice, once to the spine and once to the shoulder. One of the
wounds was between five and seven centimetres long and penetrated the victim's lung. Noor joined in and
punched the victim.

4. The victim managed to escape, but later collapsed in a block of flats. An ambulance was called, and he was
taken to hospital, where he stayed for five days, undergoing an operation to drain blood from his lungs. He
discharged himself on 9 April 2018.

5. The stabbing and the punching were done by Dymiter and Noor. The applicant did not physically join in the
attack itself, but he was in the attackers' group, he watched the attack and, at the point that AQ managed to escape
the applicant moved towards him as if to give chase again. He and the others then abandoned the chase and
jogged away.

6. The background to all of this was a dispute between AQ and Mohammed Choudhury. It was Choudhury to
whom Dymiter had been speaking on the phone.

7. The applicant, Dymiter, Noor and Choudhury were arrested. In interview the applicant put forward a prepared
statement denying participation in the offence and thereafter answered “no comment” to all questions asked. He


-----

was indicted along with Dymiter, Noor and Choudhury, the prosecution case being one of joint enterprise. Dymiter
pleaded guilty. Noor and Choudhury were convicted, along with the applicant.

8. The prosecution case against the applicant was that although he did not stab the victim or strike him, he took an
active part in a joint enterprise to attack AQ, helping or encouraging Dymiter, with the intention that AQ should
suffer really serious injury. The jury evidently accepted that this was so.

9. The applicant was born on 18 August 2001, and was therefore 16 at the time of the offence. At that time, he
was of previous good character. By the time of sentence, he had accumulated two convictions for five offences, all
committed after the stabbing. Four of these offences concerned conspiracies to supply controlled drugs.

10. Before us, as there was before the sentencing judge, is a document from the National Crime Agency which
concluded that the applicant was the victim of modern slavery. We shall return to that document. The Judge also
had a favourable report from a company with which the applicant had started as a trainee, expressing the hope that
he would be able to start an apprenticeship with them in due course.

11. In addition, the sentencing judge had the advantage of a pre‑sentence report which revealed a troubled

background. The applicant was adopted at the age of four, but the relationship with his adoptive parents broke
down when he was 15. They had felt unable to manage his emotional and physical behaviour. He had been in
care from 2016, and was permanently excluded from College in December 2018. It was agreed that he was at risk
of gang culture, drug abuse and criminal behaviour. It was reported that he had difficulty understanding the severity
of his actions and the consequences he could face as a result. He was quick to minimise his involvement in
criminal activity and often dismissive when his offending behaviour was challenged. He was assessed as posing a

high risk of serious harm and a high likelihood of re‑offending.

12. In his favour, it was reported that he had learning difficulties that exacerbated his vulnerability to adults with pro
criminal attitudes and the PSR reported that there were positive reasonable grounds to conclude that he was a
victim of modern slavery. The report recorded his regret about his involvement in the offence and sympathy to the
victim. He was said to show insight, understanding that his actions could have had catastrophic consequences for
the victim and for himself, and that they were both lucky this had not occurred. The probation proposal was an 18
month youth rehabilitation order with 18 months supervision, unpaid work of 100 hours, four months electronically
monitored curfew and three months exclusion from Tower Hamlets.

13. That is not a disposal that recommended itself to the sentencing judge. He took the view that whilst Dymiter's
role as the stabber was the most serious, standing back, having heard all the evidence, the other three participants
all bore the same level of responsibility for the wounding. The starting point for each of them was eight years'
custody. That was reduced by half in the applicant's case to reflect his age. The sentence was further reduced by
six months to reflect his difficult personal circumstances and his good character

14. In support of the overall submission that the sentence was manifestly excessive, three grounds of appeal were
originally presented. It was argued that the sentence failed properly to reflect the applicant's true role in the
offending; that it failed properly to reflect the principles that apply when sentencing children; and that it did not take
adequate account of his personal mitigation.

15. The single judge was unimpressed by any of those points, concluding that the Judge was well placed when
sentencing to assess the true culpability of each defendant, and could not be criticised for his approach to the
discount for youth.

16. Having considered the single judge's reasoning, Miss Booker has abandoned the complaint about the discount
for age, and about the applicant's role in the offending. She has focused the renewed application on the proposition
that the applicant's case should have received different and more lenient treatment compared to the other accused,
due to the distinguishing features of his personal mitigation. Unusually, but very helpfully, Miss Booker has
prepared brief written submissions explaining why issue is taken with the single judge's rejection of this ground of


-----

appeal and she has elaborated this argument before us today when she has appeared pro bono, for which we are
most grateful.

17. Miss Booker identifies two features that she submits are of significance. First, that the applicant was the
youngest and most vulnerable of the defendants with social circumstances, as set out in the reports before the
court, which were particularly difficult. Secondly, she relies on the assessment of the National Crime Agency that
he was a victim of modern slavery. The second submission relies on the NCA document we have mentioned. It is
one-page document dated 18 March 2019, and therefore some two weeks before the sentencing hearing, issued by
the NCA, and headed "Decision Notification". It states that the MSHTU has concluded that the above individual,
that is to say Cooper, "is a victim of **_modern slavery". The letters MSHTU stand for_** **_Modern Slavery Human_**
Trafficking Unit. The document contains no further information, explaining that finding, and Miss Booker has
candidly told us today that she is unable to provide any further evidence or information about the basis on which
that finding was made. She asks nonetheless, rhetorically, whether it can be right for sentencing to take place
without giving such a finding due weight in favour of the applicant. She suggests that in this case it was not given
any real weight, when the sentence imposed on this applicant is compared with those imposed on others.

18. In our judgment, Miss Booker was right not to press on with the first and second grounds of appeal. It was
clearly legitimate for the sentencing Judge to conclude that, all things considered, there was no distinction to be
made between these defendants so far as culpability is concerned. There was no reasonable basis for challenging
the 50% reduction for the applicant's youth.

19. When it comes to personal mitigation, we do not consider it helpful to focus on comparisons with the

sentencing of co‑defendants. The real issue is whether, having regard to the guidelines, the personal mitigation

justifies the conclusion that the sentence imposed on this applicant was manifestly excessive. It is certainly true
that his offending occurred against the background of a very difficult upbringing, and that the applicant's
circumstances were challenging; but we cannot accept that those matters provide such powerful personal mitigation
that the sentence of 42 months detention can be described as manifestly excessive.

20. The fact that, as it appears, he was a victim of modern slavery may explain his exploitation as a drugs mule,
and is a matter for sympathy. Doubtless it would be a significant factor in sentencing for his drug offending. It may,
as Miss Booker suggests, support the view that he is a vulnerable character. That may be why the judge said, as
he did, that it was a “relevant” factor. But we have already explained our conclusion on that aspect of the case. For
our part, we have been unable to see how else the court can give this limited and somewhat opaque information
weight or significance when considering the appropriate sentence for this separate offence of joint enterprise
wounding, committed some time before the drug offending took place and, on all the material before us, entirely
outside the drug dealing context.

21. For those reasons, this renewed application is refused.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400 Email: rcj@epiqglobal.co.uk

**End of Document**


-----

