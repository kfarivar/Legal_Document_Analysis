# Sheikh v The Law Society of England and Wales and others [2024] EWHC
 2185 (Ch)

Chancery Division

Mr Justice Mellor

21 August 2024Judgment

**Ms ANAL SHEIKH appeared in person**

Hearing date: 16 August 2024

- - - - - - - - - - - - - - - - - - - - 
**APPROVED JUDGMENT**

This judgment was handed down remotely at 10.30am on Wednesday 21 August 2024 by circulation to Ms Sheikh s
by e-mail and by release to the National Archives.

.............................

MR JUSTICE MELLOR

**Mr Justice Mellor:**

1. On Tuesday 13 August 2024, Ms Anal Sheikh appeared in the Chancery Interim Applications Court in
the course of a busy vacation week, having earlier provided three bundles of documents to my clerk. I did
not have time on that occasion to review the bundles but I did ask Ms Sheikh whether she had issued her
application notice which appeared in draft in her bundles. She evaded providing an answer to that relatively
simple question. The net result of the short exchange was that I asked her to return on Thursday 15 August
2024, once I had had an opportunity to review her materials.

2. Enquiries in the intervening period revealed the following matters, which are important background.

Important Background

3. First, that on 26 March 2019, on the application of Her Majesty's Attorney General for England & Wales
(then Sir Geoffrey Cox QC), an Order had been made against Ms Sheikh as Defendant under section 42 of
the Senior Courts Act by Coulson LJ and Stuart-Smith J sitting as a Divisional Court of the Administrative
Court of the Queen's Bench Division. This was an 'all proceedings order' – see section 42(1A). Provisions
of that Order of particular relevance are as follows:

'3) Any civil proceedings instituted by the Defendant in any court or tribunal before the making of this order
shall not be continued by her without the leave of the High Court

4) No application (other than one for leave under section 42(3) of the Senior Courts Act 1981) shall be
made by the Defendant, in any civil proceedings instituted in any court or tribunal by any person, without
the leave of the High Court.

9) This order is to remain in force indefinitely.'


-----

4. An Order in those terms is, as I understand matters, the highest form of restraint available for a
vexatious litigant. Such an Order is only made in the very worst cases.

5. Second, the reasons for the making of that Order were explained at length in a Judgment given by
Coulson LJ and Stuart-Smith J, the neutral citation for which is [2019] EWHC 763 (Admin). Appendix 1 to
that Judgment contains a list of 31 judgments concerning Ms Sheikh being those judgments which could
then still be found (i.e. it was not an exhaustive list).

6. That list starts with the Judgment of Park J. on 1[st] July 2005, the neutral citation of which is Anal Sheikh
_v Law Society_ _[2005] EWHC 1409 (Ch) in Claim no. 'HC05200441'. This was the reserved judgment of_
Park J. following an 8-day trial in which he explained his reasons for concluding that the Law Society
should be directed to withdraw the notices of intervention into the practice of Ashley & Co, of which she
was the sole proprietor from 1993 onwards. It appears that there was a successful appeal by the Law
Society, albeit that it did not then seek to re-intervene in her practice: see [2006] EWCA Civ 1577 at [108109] per Chadwick LJ, Tuckey and Moore-Bick LJJ agreeing).

7. The list then continues with a whole series of judgments in the Red River Litigation (Red River UK Ltd &
_Ismail Dogan v (1) Rabia Sheikh and (2) Anal Sheikh) and associated claims brought by Ms Sheikh._

8. As their Lordships found in that Judgment:

i) At [19], 'judges have regularly complained about the groundless basis of Ms Sheikh's claims and
applications'; and

ii) At [22], 'there are numerous findings of vexatious conduct or abuse of process on the part of Ms
Sheikh.'

iii) Further, in [23], their Lordships cited particular and separate examples of adverse findings relating to
Ms Sheikh's vexatious conduct. Although it is not necessary to repeat the passages quoted by their
Lordships, it is relevant to note that the examples were taken from the following judgments:

a) Of Briggs J (as he then was), in his substantive judgment in the Red River litigation, 15 November 2007

_[2007] EWHC 2654 (Ch)_

[b) Of Henderson J of 21 May 2008 in Red River, [2008] EWHC 1380 (Ch)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P144-00000-00&context=1519360)

c) Of Burnett J of 15 July 2009, in Anal Sheikh v Marc Beaumont [2009] EWHC 2332 (QB)

[d) Of Norris J of 17 November 2009 in Red River, [2009] EWHC 2935 (Ch)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X40-7PD0-YBF6-71GH-00000-00&context=1519360)

[e) Of Lang J of 6 May 2015 in Rehman v Bar Standards Board, [2015] EWHC 1507 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G33-5RV1-F0JY-C26X-00000-00&context=1519360)

f) Of Hickinbottom J of 25 May 2016, also in Rehman, [2016] EWHC 1199 (Admin)

g) Of Patterson J of 3 July 2015, [2015] EWHC 1923 (QB)

h) Of Turner J of 13 July 2017, [2017] EWHC 1772 (QB)

[i) Of Jay J in June 2018, [2018] EWHC 1644 (QB)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SPD-BHN1-F0JY-C3MJ-00000-00&context=1519360)

9. These considerations led to the Court's summary in [27]:

'For the reasons summarised in the previous three sub-sections of this judgment, I am in no doubt that Ms
Sheikh has habitually or persistently and without any reasonable ground instituted vexatious proceedings
or made vexatious applications. Indeed, beyond her forlorn attempt to reargue the Red River litigation for
the umpteenth time, Ms Sheikh offered no basis for any other conclusion. As she herself said, albeit in a
slightly different context, “once the Red River fraud falls away, every single thing falls away”.'

10. There is one other characteristic of the Court's Judgment which should be noted, even though it is
obvious: it was the accumulation of vexatious conduct by Ms Sheikh in the _individual proceedings or_
applications which led the Court to make the 'all proceedings order' against Ms Sheikh. Furthermore, as


-----

will be seen below, that order followed the making of several Civil Restraint Orders ('CROs') against Ms
Sheikh.

Ms Sheikh's application

11. Thus, although she did not identify it as such on the first occasion, the application which Ms Sheikh
was actually making to me was an application for leave under section 42(3) of the Senior Courts Act 1981
to issue her draft application notice. In fact, as I explain below, Ms Sheikh seeks leave not only to issue
applications in a number of proceedings (all but one, long since concluded), but also to initiate fresh
proceedings.

12. When she returned on Thursday 15 August 2024, Ms Sheikh provided me with yet further documents.
In one of those, she provided answers to the questions I had posed on Tuesday and did identify that she
needed leave or permission to issue her application. I had a very full list that Thursday and I indicated I
needed to read further into her documents. Ms Sheikh then returned on Friday morning and I allowed her
to address me for approximately 30-40 minutes. She utilised that time efficiently, with an articulate but
impassioned set of submissions which highlighted her principal complaints and grievances. She
emphasised her passion by saying she felt no purpose in living and would like to die, and has felt that way
since 2006.

13. Although the time for her oral submissions was relatively short, last week and over the weekend I
spent several hours reading the files and additional documents she presented to ensure I had a sufficient
grasp of what her request for leave would entail. One possible course was to adjourn her application to be
heard at the start of the new term, on the basis that Ms Sheikh had not demonstrated that her application
was so urgent that it had to be determined in the vacation. However, having read into her application, I
decided that to determine her application would be the best use of judicial resources.

14. The test I must apply is set out in section 42(3) and comprises two elements: leave can only be given
for the institution or continuance of, or the making of an application in any civil proceedings if the High
Court is satisfied that:

i) the proceedings or application are not an abuse of the process of the court and

ii) there are reasonable grounds for the proceedings or application.

15. Her unissued application notice dated 26 July 2024 identifies Ms Sheikh as Claimant and, as
Defendants: (1) Law Society of England & Wales and (2) the Solicitors Regulation Authority. The claim
number is stated as HC05C00441, and it would appear that this is the same claim as tried by Park J., albeit
there appears to be a typographical error in the claim number as identified in the HTML version of his
judgment on BAILII, which I quoted above. Numerous other additional defendants are identified in Ms
Sheikh's documents.

16. The Order which the Court is asked to make in this draft Application Notice is worded as follows:

1. An expedited order in Case 3 ordering the Defendants to pay me the balance of my remortgage monies
Overview Cases 1-39 Page 121

2. A substantive order in Cases 3-26 the draft at Overview Page 118-120

17. In section 10 of her draft Application Notice, she identifies the following information that she will be
relying upon in support of her application:

1. 'Letter to Chancery Division Judges En Banc (by a full panel).' This comprises some 40 pages of
submissions.

2. 'Overview of cases 1-39 ('the Overview').' This comprises some 318 pages.

3. 'The Documents listed at Page 28 of the Overview'.

18. In section 11, she identifies herself as vulnerable and as a victim of torture, of **_modern slavery, as_**
having been made homeless and a victim of 'numerous ECHR Convention and UN Convention violations'.


-----

The documents filed in support

19. As already indicated, the documentation which Ms Sheikh filed in support was voluminous, but she
told me there was much more besides. Since she delivered the original three files of material to me on
Tuesday 13 August, she has continued to generate and provide me with additional substantial documents.
My reading indicates that Ms Sheikh repeats the same complaints and requests in different ways.

20. It is evident that the origin of Ms Sheikh's grievances is the intervention by the Law Society in 2005
into her practice of Ashley & Co. This was the subject of the case tried by Park J. (i.e. action no
HC05C00441) and which concluded with the judgment of the Court of Appeal. This is also one of the
cases which Ms Sheikh now seeks to revive (amongst others), even though they have long since been
finally concluded.

21. It is not possible, without reproducing large sections of her lengthy documents, to explain the full scale
of the claims and litigation for which Ms Sheikh seeks permission, but I will attempt a summary.

22. First, she seeks to reopen some 37 'cases'. I put the word 'cases' in inverted commas because each
'case' identified seems to be a judgment or decision in a particular claim or intervention or sometimes a
group of judgments. Her 'cases' appear to have two main features in common: first, all have been
concluded and all but one (case 6) were concluded years ago; second, they all involved or seek to involve
Ms Sheikh in some capacity, even if it is anticipatory as regards Case 6 and Cases 8-24, being 'The Other
Schedule 1 Intervention Cases'. Thus:

i) Cases 1 and 2 are Claim No. HQ05X00547 Lloyds Bank v Anal Sheikh, and the judgments of Aitken J
and Cresswell J. In that claim, Ms Sheikh seeks to initiate an inquiry under the cross-undertaking but that
would first require a finding that the freezing injunction was wrongly granted against her.

ii) Cases 3 and 4 are _Anal Sheikh v the Law Society, and the judgments of Park J, and of Briggs and_
Henderson JJ.

iii) Case 5 is David Herman Holder v Law Society [2002] EWHC 1559, the judgment of Peter Smith J.

iv) Case 6 is _The Solicitors Regulation Authority v Soophia Kahn_ _[[2022] EWHC 45 (Ch) (labelled as](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HR-5643-GXF6-82RD-00000-00&context=1519360)_
'Soophie Kahn's Unlawful Imprisonment'), the judgment of Leech J.

v) Case 7 appears to involve several solicitors' practices: Ahmed & Co, Biebuyck Solicitors, Dixon & Co
and the practices of Mr Zoi and is labelled 'The Compensation Fund Case', judgment of Collins J.

vi) Cases 8-24 are 'The Other Schedule 1 Intervention Cases', albeit that Schedule 1 appears to identify
some 28 cases.

vii) Case 25 is the second intervention into Ms Sheikh's former firm in January 2008 which she labels (in
common with all the interventions) as 'fraudulent'.

viii) Case 26 is HC07C02257 _Ismail Dogan & Red River (UK) Ltd v Anal Sheikh & Rabia Sheikh,_
judgments of Rimer, Kitchin, Briggs, Mann & Lewison JJ.

ix) Case 27 is R (on the application of Anal Sheikh) v Solicitors Disciplinary Tribunal & the Law Society,
judgment of Collins J.

x) Case 28 is Anal Sheikh v The Law Society, Judgment of King J.

xi) Cases 29-36 involve Anal Sheikh v Marc Beaumont, HQ09X00657, but also seem to involve Red River
and various Judges, Simon, Burnett, Spencer, Tugendhat, Nicola Davies, Patterson, Turner & Jay JJ.
Cases 31-36 are identified as the First-Seventh 'Fraudulent CRO's'.

xii) Case 37 is labelled 'Ban for Life 2019' and is evidently a reference to the Order and Judgment of
Coulson LJ and Stuart-Smith J which I have discussed above.

23. It will be noted in relation to Cases 3 and 4 that Ms Sheikh does not refer to the Judgment of the Court
of Appeal which reversed the decision of Park J. It is apparent that the Judgment of Park J. [2005] EWHC


-----

_1409 (Ch) is the one Judgment of which Ms Sheikh approves, and one may infer (in so far as it is_
necessary to do so) that Ms Sheikh seeks to set aside the Judgment of the Court of Appeal.

24. It must also be noted that these 37 'cases' involve (a) re-opening, re-arguing and setting aside all the
judgments made against Ms Sheikh, including the seven CROs as well as the 'all proceedings order' made
against her in 2019, but also (b) the commencement of various sets of proceedings to set aside the various
interventions and other judgments which did not involve her (see e.g. case 6, cases 8-24).

25. Second, whilst it might be thought that pursuing those 37 matters is ambitious enough, it is apparent
that does not accurately encompass the scope of Ms Sheikh's application and ambitions. So, in addition to
apparently seeking to reargue and reverse all those decisions (save only for the Judgment of Park J.), Ms
Sheikh seeks to go much further. To give a flavour of what Ms Sheikh seeks to ask the Court to do, I will
set out her first eleven requests as set out in her 'Letter to Chancery Judges en banc'. Before doing so, it is
necessary to point out that when Ms Sheikh refers to 'the court' she seems to require that all 18 of the
current Chancery Judges must sit en banc:

'The court is asked to set aside every one of the estimated 5000 – 20,000 interventions undertaken by the
Law Society since 1974 where the intervention has been undertaken under the Law Society's Fraudulent
Procedure (which is all of them).

The court is asked to order the Law Society to pay £1.2bn to the solicitors whose lives it has destroyed or,
where they are deceased, to pay their families. ... The majority by far are from the black and ethnic
communities.

The court is asked to order the Bar Mutual, or barristers personally, to reimburse **£71m to the**
Compensation Fund.

The court is asked to order the Law Society's agents, such as Russell Cooke LLP and Devonshires to
reimburse a minimum of £638m to the Compensation Fund

The court is asked to order the Law Society to pay **£4.6m** to King Charles III, representing the bona
vacantia it has stolen from him.

The court is asked to order the Law Society to refund Practising Certificate Fees and Compensation Fund
Contributions paid by several hundreds of thousands of solicitors since 1974 where the money has been
wasted in sham investigations, sham litigation and to commit fraud.

The Solicitors Disciplinary Tribunal is asked to prosecute the 50 Presidents of the Law Society responsible
for the Intervention Fraud since 1974.

The Solicitors Disciplinary Tribunal is asked to prosecute the 1200 solicitors who have appeared in sham
court proceedings since 2000 to further the Intervention Fraud.

The Bar Standards Board is asked to prosecute 300 barristers, including 20-30 King's Counsel and
possibly also the Lady Chief Justice.

The court is asked to commit leading 20-30 King's Counsel to prison for contempt of court.

The court is asked to commit a former Attorney General Sir Geoffrey Cox KC to prison for contempt.'

26. In line with those requests, Ms Sheikh appears to address the claims she now wishes to bring to a
very wide cast of individuals. Her cast list starts with King Charles III, the Rt Hon Lucy Powell, Lord
President of the Council, the Chancellor of the High Court, the Lady Chief Justice, the Master of the Rolls
and the President of the Supreme Court. She then lists all 18 of the current Chancery Judges, followed by
the Counsel and solicitors who appeared (either for or against her) in litigation to which Ms Sheikh was a
party. The list then continues with a long list of counsel and solicitors identified as 'The Lawyers in the
Schedule 1 Cases'. Her list continues with a list of Judges who have made decisions in certain of her cases
1-37 (albeit Ms Sheikh appears to exclude those Judges who made decisions in the Red River litigation),
the '150 Recorded Barristers' who are alleged to have 'misadvised their clients and misled the court for
_nearly five decades about the Law Society's power of intervention under Schedule 1 of the Solicitors Act_


-----

_1974', the Members of various committees of the House of Commons and Lords, various academics, the_
Law Commissioners, concluding with various UN Special Rapporteurs and various lawyers' organisations.

27. In her documents, Ms Sheikh invokes 'the Post Office Scandal' and contends that 'The Law Society's
_Intervention Fraud is a miscarriage of justice more preposterous and more depraved than the Post Office_
_Scandal.' It would appear that recent developments in the Post Office Scandal have triggered Ms Sheikh's_
attempts to resurrect the cases decided against her and to widen the inquiry into all intervention cases.

28. It is clear that Ms Sheikh alleges a very wide-ranging conspiracy which embraces all the Judges who
have made decisions against her (including, in particular, in the _Red River litigation, all 7 of the Civil_
Restraint Orders made against her, and the 'all proceedings order' in 2019), all the counsel and solicitors
involved in those decisions, including counsel and solicitors who acted on her behalf, as well as numerous
others.

29. Finally, I should mention three interim orders which Ms Sheikh contends should be made as a matter
of urgency:

i) First, in case 3, 'an order directing the Law Society or Weightmans LLP to return the £254,000 Sheikh
NRAM remortgage proceeds';

ii) Second, in case 6 [to bring to an end] 'Sophie Khan's unlawful imprisonment'

iii) Third, 'Torture is being practised in the UK; I am being tortured'.

30. There is much more detail and there are many more allegations made in Ms Sheikh's documents, but
what I have summarised above suffices for present purposes.

Discussion

31. In [10] above, I drew attention to the fact that it was the accumulation of vexatious conduct in individual
applications and cases by Ms Sheikh which led to the making of the 'all proceedings order' against her in
2019.

32. From the summary I have outlined above, it can be seen that Ms Sheikh desires to be far more
ambitious in the scope of the very wide-ranging litigation she now seeks to pursue.

33. I have come to the clear conclusion that I should not give the leave or permission which Ms Sheikh
requests.

34. The provision of leave under section 42(3) to Ms Sheikh would unleash a tidal wave of re-litigation
and/or fresh litigation. I am satisfied every part of it would be an abuse of process, on one or more of the
following bases:

i) First, Ms Sheikh seeks to re-open litigation (e.g. Red River) which concluded with final decisions years
ago.

ii) Second, she seeks to intermeddle in other litigation (e.g. Case 6 and the Schedule 1 Interventions) also
finally concluded, in which, as far as I can tell, she had no involvement at the time of the original cases.

iii) Third, Ms Sheikh seems to have appointed herself as the standard bearer for any solicitor aggrieved by
an intervention by the Law Society, but her application(s) fail to appreciate that, if anyone is to strike down
or revise the intervention powers provided to the Law Society by section 35 of and Schedule 1 to the
Solicitors Act 1974, that is a matter for Parliament and not the Chancery Judges sitting en banc.

iv) Furthermore, if the complaint is over the _exercise_ of those powers, the time for a complaint in an
individual intervention to be aired and investigated is at the time of the intervention and in the light of the
individual facts. This is the case, notwithstanding that an intervention into a solicitor's practice often has
devastating consequences. Ms Sheikh took the opportunity to complain about the intervention into her
practice at Ashley & Co and those matters were the subject of the trial before Park J., as reviewed by the
Court of Appeal. Ms Sheikh has not identified any ground for re-opening, let alone overturning the decision
of the Court of Appeal in her case, nor the decisions in any of the other intervention cases.


-----

35. Furthermore, it is plain (and I so find) that there are no reasonable grounds for either the cases she
seeks to re-open and re-argue or the new proceedings she seeks to bring. In relation to the interventions,
her generalised assertions of cruel, inhuman and degrading treatment (allegedly amounting to torture) and
her allegation that the whole intervention procedure is fraudulent, have no substance. Her conspiracy
theories are pure fantasy yet involve allegations of the utmost seriousness which, applying section 42(3), I
must not allow to be pursued.

36. In these circumstances, I must dismiss Ms Sheikh's application for leave, and I do so whilst also
certifying it was totally without merit.

37. Although I found it necessary to set out Ms Sheikh's _allegations at some length in this Judgment to_
indicate the scale of the litigation Ms Sheikh seeks leave to pursue, it should clearly be understood that
these are just allegations which she seeks to make. I am bound to observe that in making these allegations
and seeking to pursue them, Ms Sheikh appears to have lost all touch with reality and reason. She would
be well advised to relinquish her obsession with the Law Society's powers of intervention and to accept the
final decisions which have been made against her.

A Postscript

38. It is clear that if I was to do anything other than give Ms Sheikh the leave she seeks, I will be accused
by Ms Sheikh as being part of the wide-ranging conspiracy against her. Whilst I was preparing this
judgment (and before I had given any intimation of my decision), Ms Sheikh started to email some of her
'key' documents to every clerk to a Chancery Division Judge in three emails. Via my clerk, and whilst I was
still considering her request for leave, I asked Ms Sheikh to refrain from sending her documents to the clerk
to every Chancery Judge, since the section 42(3) procedure is that the question of leave is decided by the
High Court, and ordinarily exercised by a single Judge. Her swift response was that it was necessary, inter
alia, because (and I quote):

'3) Mr Justice Mellors [sic] was not a court but a public authority within the meaning of HRA who is in the
course of violating my Convention rights.

4) That the judgment is most certainly going to be another false instrument and an instrument of money
laundering. See in particular File 10, Tab 2, Page 8-9, in which I allege that the CROS are being used as
an instrument of theft.'

which rather proves my point.

A further Postscript

39. After the hand down of the original version of this Judgment, Ms Sheikh asked me to amend that
version in two respects. The first is a revision to the final sentence of [12] into the form shown above. The
second was her request to record that all of her allegations are consequential and dependent upon the
following question:

'Is there a law governing the Law Society's interventions into Solicitors Practices, by which is meant
entering the Solicitor's offices without a court order, sometimes using force, freezing the Solicitor's Banked
Money without a court order, having the Solicitor's Banked Money transferred to its own account without a
court order, removing the Solicitor's Documents without a court order, again sometimes using force, and
having the Solicitor's Mail redirected without a court order; and if there such a purported law, is it
sufficiently clear, unambiguous and certain to be able to be implemented by the Law Society and to be
applied by the judiciary?'

40. She suggested 'That is an important point which will put the allegations, which sound wild and
_unfounded, into the proper context.'_

41. The reason I did not include this question in the original version of this Judgment is because the
answer to it appears to be obvious: Yes, there is a law governing the Law Society's interventions into
Solicitors Practices. The powers exercisable on intervention by the Law Society and the Court are


-----

contained in Part II of Schedule 1 to the Solicitors Act 1974, as interpreted in case law, on the facts of each
individual case.

**End of Document**


-----

