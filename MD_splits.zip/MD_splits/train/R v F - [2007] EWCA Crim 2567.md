# R v F [2007] EWCA Crim 2567

COURT OF APPEAL (CRIMINAL DIVISION)

DOBBS J DBE, JUDGE GODDARD QC (sitting as a judge of the Court of Appeal, Criminal Division)

18 OCTOBER 2007

18 OCTOBER 2007

**Sentence — Imprisonment — Length of sentence — Facilitating the arrival into the United Kingdom of**
**another person for the purposes of sexual exploitation — Facilitating travel within the United Kingdom of**
**another person for the purposes of sexual exploitation — Defendant convicted after trial — Judge imposing**
**concurrent sentence of eight years' imprisonment — Judge making recommendation for deportation —**
**Whether sentence too long — Whether deportation order should be made**

A Farrow for the Appellant

P Shorrock for the Crown

Registrar of Criminal Appeals; Crown Prosecution Service

**DOBBS J DBE:**

(reading the judgment of the court)

**[1] On 3 May 2007 in the Portsmouth Crown Court, this 24-year-old Appellant was convicted after trial of two**
counts of facilitating the arrival into the United Kingdom of another person for the purposes of sexual exploitation
and two counts of facilitating travel within the United Kingdom of another person for the purposes of sexual
exploitation. He was sentenced to eight years on each count to run concurrently. A recommendation for deportation
was made.

**[2] He appeals against sentence by leave of the single judge.**

**[3] The facts are these. In 2005 the Appellant contacted a man called R in Brazil and asked him if he knew of any**
girls who would like to work in his restaurant in England. R asked M D O if she wished to do so and she agreed.
She in turn asked her friend S D A, and she also was keen to go. Money was put into R's account by the Appellant
to buy passports and clothing for the young women, and the plane tickets to Heathrow were paid for. At São Paolo
Airport in Brazil, the women were met by unknown persons who gave them some sterling, in order to trick United
Kingdom immigration into believing that they had enough money to support themselves when they applied for a
visa.

**[4] On 5 May 2005 the women arrived at Heathrow where, after obtaining tourist visas, they were met by the**
Appellant. He took them to London and introduced them to a man called C. They went for a meal in Chinatown, and
then the women were taken to a shop where they were bought lingerie. At that point they became suspicious. Their
passports were taken from them and they were told they would have to work as prostitutes. The Appellant then
handed them over to C and he took them to a brothel in Portsmouth. M D O then was forced to work as a prostitute,
but she was not physically threatened. But her friend S D A refused, so she was taken back to London, handed
back to the Appellant who took her to a house in Manchester


-----

**[5] On 19 May the police raided the brothel in Portsmouth, and as a result the story emerged.**

**[6] This Appellant, being 24 years of age, was of previous good character. There were no reports in front of the**
sentencing judge, but some prison reports described his conduct as excellent, that he was polite and courteous to
all the reports from staff were described as very good.

**[7] When sentencing the judge noted that although the offences were specified offences, he found that it was not**
possible to find that the Appellant posed a significant risk and thus the dangerousness provisions did not apply.

**[8] The judge made a recommendation for deportation, noting that the Appellant was close to the action in this**
case, and thus his remaining in the United Kingdom would be a potential detriment. We will deal with that aspect
later.

**[9] Turning to the main ground of appeal, which is that the sentence was too long, counsel relies on the following.**
This was a single transaction, which was accepted by the sentencing judge. The offences were not aggravated by
violence or threats of violence. No coercion was used on the women. They were not falsely imprisoned, nor badly
treated, and were not kept incommunicado. Each had a mobile phone in order to keep in contact. The lady who
worked sent money back to Brazil, and therefore was able to keep some of her earnings. The Appellant had limited
involvement and he had no role in running the brothel. The only gain identified to him was some £1,200 paid into his
account by Mr C. He was of previous good character and he had a good work record since arriving in this country in
2002. He is a family man.

**[10] Counsel points out that the Sentencing Guidelines Council Guideline suggests a starting point of two years**
where there has been no coercion, with a range of one to four years on conviction. The higher bracket has a
sentencing range of four to nine years, with a starting point of four years.

**[11] It was accepted that there was a relatively high degree of planning and two victims, and their passports**
confiscated. But it is submitted that the offences fall on the border of the two categories contained in the guideline,
where four years was appropriate.

**[12] We take the view that there is force in counsel's arguments with regard to the length of sentence. It is not clear**
whether the guideline was available to the judge at the time, although not in force until some ten days after the date
of sentence. If it had been drawn to the judge's attention, we have no doubt that the sentence would not have been
as high.

**[13] Taking into account both the mitigating and aggravating features in this case, in our judgment the appropriate**
sentence is one of four years' imprisonment. We quash the sentence of eight years and substitute for it a sentence
of four years.

**[14] We now turn to the second issue in the grounds of appeal, namely the recommendation for deportation.**

**[15] We note, first of all, that this is a recommendation which is in the judge's discretion. The court has to consider**
the potential detriment of the offender remaining in the jurisdiction. Even if the offender has no previous convictions,
a recommendation can be made where the offence is a serious one, of a deliberate character, and one which can
undermine public policy.

**[16] The offences for which this Appellant was convicted are serious. However, within themselves they are not the**
worst of this category of offence, as has been demonstrated by the result in the first half of this appeal.

**[17] The judge noted when sentencing that offences of this kind are in effect a form of modern slavery. However,**
in this particular case those aggravating features akin to slavery were not present. Whilst the Appellant was
associated with the person who ran the brothel, that person has now fled the jurisdiction and there is no evidence
that this Appellant was in any way involved with the brothel.

**[18] Although reference was made to the Appellant's character and personal circumstances, there was no**
assessment of his future behaviour, the judge not having the benefit of a pre-sentence report in front of him. He


-----

needed therefore to make such an assessment himself. If he did make an assessment and balancing act, he failed
to express clearly and in detail the factors which militated in favour of the recommendation and why.

**[19] In our judgment, given the facts of the offences, strong mitigation and the lack of evidence pointing to any**
future concerns about this Appellant, the recommendation was not apt. We therefore quash the recommendation for
deportation. We point out, however, that by doing so it does not follow that this Appellant will not ultimately be
deported, as that will be a decision for the Secretary of State in the light of the conviction, whether it be with or in
the absence of a recommendation by this court.

**[20] To that extent, this appeal against sentence is allowed. Thank you very much Mr Farrow.**

Appeal allowed.

**End of Document**


-----

