# Rotherham Metropolitan Borough Council v G (A child) and others [2016]
 EWHC 2660 (Fam)

Family Division

Cobb J

25 October 2016Judgment

**Frances Heaton QC and Rebecca Foulkes** (instructed by Local Authority Solicitor) for Rotherham
Metropolitan Borough Council

**M (mother of G) and F (father of G) were neither present nor represented**

**Jonathan Wilson (instructed by Foys solicitors) for G (the subject of the proceedings)**

**NN appeared in person**

**HH, LL & MM were neither present nor represented**

**Cathryn McGahey QC and William Irwin (instructed by the South Yorkshire Police Legal Service) for the**
South Yorkshire Police

**Keina Yoshida (instructed by Brid Jordan, Senior Editorial Lawyer) for Times Newspapers Limited**

Hearing dates: 19 – 21 and 25 October 2016

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

THE HONOURABLE MR JUSTICE COBB

This judgment was delivered in public.

There is a Reporting Restriction Order in place.

The judge has given leave for this version of the judgment to be published on condition that (irrespective of what is
contained in the judgment) in any published version of the judgment the anonymity of the children, members of their
family and the four associated males must be strictly preserved.  All persons, including representatives of the
media, must ensure that this condition is strictly complied with.  Failure to do so will be a contempt of court.

**The Honourable Mr Justice Cobb:**

_The applications_


-----

1. There are two applications before the court, issued within the High Court's inherent jurisdiction by
Rotherham Metropolitan Borough Council (“Rotherham Council”), in respect of a vulnerable young person
who I shall refer to as Child G. They are:

i) An application in wardship; within this application, Rotherham Council has sought orders to protect Child
G (female) from what it believed to be child sexual exploitation by four males who I identify as HH, LL, MM
and NN. (These four males are described in this judgment as 'associated males'; they are associated with
Child G, but – as I explain a little below [17](iii) – have minimal associations with each other). This
application was issued on 18 August 2016;

ii) An application for a Reporting Restriction Order to protect the identification of Child G, her family
members, and the four associated males. This application was originally issued on 22 August 2016, and
amended on 7 October 2016 to include provision for lifelong anonymity.

2. The application in wardship was first considered by Keehan J in the High Court in London at a hearing
without notice to any of the parties on 18 and 25 August 2016, and later by MacDonald J on notice to the
parties, on 8 September. The application was listed for final hearing before me in Leeds on 19 October.
Interim injunctive orders had been made separately by both Keehan and MacDonald JJ, to protect Child G
from those associations; interim Reporting Restriction Orders had also been made at those hearings,
which had been held in public, to prohibit the publication of the names of Child G and the four males.

3. I granted the application of the Times Newspapers Limited to conduct the substantial part of this final
hearing in public. That said, early in the hearing, I was expressly invited by Ms Heaton QC to hold, and
indeed did hold, a short private hearing in which only the representatives and parties to the wardship
(counsel for local authority and counsel for Child G) were present in court, in conformity with the default
rule under _rule 27.10 FPR 2010. In this short hearing, Ms Heaton advised me that Rotherham Council,_
having considered with South Yorkshire Police the evidence filed for this final hearing, no longer
considered it appropriate to pursue its applications for injunctions, and would seek to persuade me to
discharge the existing interim injunctions; Ms Heaton indicated that Rotherham Council would seek no
further orders within the wardship. I was advised that the Council nonetheless would seek lifelong
extensions of the Reporting Restriction Orders.

4. Child G, the only other represented party in the wardship, and who did not support applications for
injunctions against LL and MM in any event, did not oppose Rotherham Council's proposed course in
seeking no further orders in the wardship; both parties accepted that whatever was agreed, the proposal
would have to be subject to my approval.

5. Before I had asked the accredited members of the press to withdraw from court for this short hearing,
and having no hint of what was to be shared with the court, I enquired whether Ms Heaton had in mind the
provisions of rule 27.11 and PD27B FPR 2010 (i.e. the ordinary expectation of the attendance in private
hearings of duly accredited representatives of news gathering and reporting organisations); she confirmed
that she did.  It was apparent by the end of the short hearing that nothing of relevance to the litigation had
in fact been said which could not, and/or should not, be shared with South Yorkshire Police, the associated
males, and/or the press. I gave Ms Heaton time to apprise the other parties of what she had advised me.
Later in the public hearing, at my suggestion, she repeated that which she had told me in private. I set out
this history to highlight that I consider that it was unnecessary for the court to sit in private for that part of
the case, and/or to exclude the press from attending. It is unfortunate that by inviting me to do so, an
appearance may have been given that information was given to the court to which the interested parties
would be denied access.

6. The application for the lifelong Reporting Restriction Order was essentially uncontentious insofar as it
relates to Child G, The Times Newspaper Limited arguing that it was not necessary for such an order to be
made, but it would not be of itself objectionable. However, in relation to the four associated males, the
order was opposed by The Times Newspapers Limited. In the circumstances I heard evidence from the
Detective Sergeant supervising the Child Sexual Exploitation Team and the Detective Chief Inspector
responsible for managing the child sexual exploitation work of the South Yorkshire Police; I had received


-----

uncontested written evidence from the social workers. I heard submissions from all parties, and
representations directly from Mr. Andrew Norfolk a journalist at The Times Newspaper.

7. I reserved judgment for a short time to reflect on the arguments.

_Context and comment_

8. Before describing the case in a little more detail, I wish to make these general observations.

9. Nobody can doubt the evil of child sexual exploitation; this occurs when a young person (or a third
person or persons) receives a reward – which can be food, accommodation, drugs, alcohol, cigarettes,
affection, gifts, money – in return for performing, and/or others performing on them, sexual activities. In all
cases, those exploiting the child/young person have power over them by virtue of their age, gender,
intellect, physical strength and/or economic or other resources. Violence, coercion and intimidation are
common, involvement in exploitative relationships being characterised in the main by the child or young
person's limited availability of choice resulting from their social/economic and/or emotional vulnerability.
Child sexual exploitation is an increasing phenomenon affecting children and young people, male and
female, of all backgrounds and from all communities right across the UK. It has been a particular concern
to local authorities in densely and multicultural urban areas of the country. It has been, as the report of the
'Independent Inquiry into Child Sexual Exploitation in Rotherham' (August 2014) (Alexis Jay OBE) makes
clear, a particular issue in Rotherham. This hearing took place in a week in which the issue has been
given further prominence by the convictions of eight males from Rotherham for offences of rape, indecent
assault, and false imprisonment of teenage girls in that town over a four-year period. The Times
newspaper and Mr. Norfolk in particular have been instrumental in exposing and highlighting this
pernicious activity in press coverage extending over nearly six years.

10. This Local Authority, as all local authorities, has a heavy responsibility for the safeguarding of young
people from child sexual exploitation; the South Yorkshire Police, in common with its law-enforcement
colleagues around the country, have a similar duty conscientiously to investigate and prosecute such
sexual crimes. These bodies have a collective responsibility to work in partnership in the discharge of their
respective duties, to share information conscientiously, and to maintain clear focus throughout their
investigations about their common objectives.

11. That this case concludes now with the local authority seeking no further injunctive order does not
reflect a failure on the part of the safeguarding investigation; nor does it reflect an overly-hasty rush to
justice without proper consideration of the evidence. I am satisfied that Rotherham Council had proper
cause swiftly to take steps to protect a young person when the evidence appeared to indicate that she was
at serious risk. I am equally satisfied that, on the evidence then available, Keehan and MacDonald JJ were
right to make interim injunctive orders. Having considered the totality of the evidence with care myself at
this stage (and specifically the matters in [17] below), I am equally satisfied that Rotherham Council has
taken the appropriate course in seeking no further injunctive relief now.

_Background_

12. I outline the background to these applications only to the extent that it is necessary to explain my
reasoning for approving the orders I propose to make.

13. Child G is a white female young person, in her late-teens. She first came to the attention of the social
services of Rotherham Council in 2012, when safeguarding issues were raised by her school about her
poor state of mental health and general vulnerability. These concerns have only periodically subsided over
the course of the last four years; cumulatively, the concerns have, over that period, somewhat increased.
For lengthy periods Child G did not attend school; on numerous occasions, she disappeared from home,
and was reported to the police as a missing child. She has self-harmed in different ways, on many
occasions; she has been known to misuse prescribed drugs, and use non-prescribed drugs. Her mother
and father struggled at times to manage her behaviours. In 2014, reports were received that she was
spending time in the company of, and indeed was in relationships with, an Asian man or men. It was
known that she had personal and sexual relationships, sequentially, with NN, HH, and LL (in that order).


-----

There were concerns about the nature of those relationships; there was evidence that NN and HH
physically assaulted her. At one time she complained to the police that she was being controlled by HH,
and that he had attended at her home uninvited; on occasion, HH caused criminal damage to her home. It
was known that he has a number of convictions, including for offences associated with drugs and violence.
LL has convictions, but MM and NN do not. Child G reported to the police that she was fearful of HH. It is
not clear to me, from the information provided for this specific application, why steps were not taken earlier
to protect Child G by way of an order under Part IV of the Children Act 1989 (care or supervision), but I
[note that for a period, Child G was accommodated by Rotherham Council under section 20 Children Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1TN-00000-00&context=1519360)
_1989._

14. On 12 August 2016 Child G went missing; she was located by the police in a hotel room with LL. MM
had been to the hotel with them, but had returned home. Child G was not known to have an association
with either LL or MM. Among the items found with them in the hotel were vodka, cannabis, condoms, and
Asian female clothing. Police protection was immediately sought for Child G. The officers attending at the
scene believed that she was the victim of child sexual exploitation by LL and potentially the other males;
she was immediately conveyed to, and placed in, a safe house. LL and MM were arrested on suspicion of
trafficking for sexual exploitation contrary to _[section 2 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C254-00000-00&context=1519360)_ _[section 3 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C26B-00000-00&context=1519360)_ **_Modern Slavery Act 2015._**
They were interviewed under caution, and were co-operative. LL maintained that he was Child G's current
boyfriend, MM that he had simply driven LL to the hotel, and had not met Child G before.

15. When the protective regime of the police orders expired, the application for injunctive relief against the
four associated males was brought, with the permission of the court, under the inherent jurisdiction in
wardship. No one disputes that a local authority has the _locus to bring an application of this type as a_
matter of law. For my part, I confirm my view that:

i) Wardship can be an appropriate vehicle for the obtaining of injunctions of this kind; paragraphs 1.1 & 1.2
of _PD12D of_ _FPR_ 2010 reflect that the “most common” injunctions made in this jurisdiction are those “to
prevent an undesirable association” (para.1.2(b)); and

ii) The result which Rotherham Council pursued was not one which, on the facts of this case, could be
achieved otherwise than in the exercise of the court's inherent jurisdiction; there was reasonable cause to
believe that if the court's inherent jurisdiction was not exercised with respect to the child she was likely to
[suffer significant harm (section 100(4) and (5) Children Act 1989). Part IV of the Children Act 1989 was not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C289-00000-00&context=1519360)
by now available (per section 31(3)); although other forms of protective order are theoretically available in
cases of this kind – such as Sexual Harm Prevention Orders [SHPO] (sections 103A–K of the _[Sexual](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)_
_[Offences Act 2003) and Sexual Risk Orders (section 122A ibid.) – these can only be made on the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)_
application of the police or the Director General of the National Crime Agency, and in the case of the
SHPO, can only be applied to anyone convicted or cautioned of a sexual or violent offence. Thus they are
not available here at the instigation of the local authority.

16. The applications issued here corresponded with those which had been made by the local authority in
_[Birmingham City Council v Riaz & Others [2014] EWHC 4247, [2015] 2 FLR 763 ('Birmingham CC v Riaz](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G22T-00000-00&context=1519360)_
_No.1'), where Keehan J described the actions of the authority, acting to protect a victim of child sexual_
exploitation, as “bold and innovative” ([158]), and endorsed “the use of the inherent jurisdiction to make
injunctive orders to prevent [child sexual exploitation]”; in that case, he said that such an application
“strikes at the heart of the _parens patriae jurisdiction of the High Court. I am satisfied that none of the_
statutory or the "self-imposed limits" on the exercise of the jurisdiction prevent the court from making the
orders sought by the local authority in this case” ([46]). In _London Borough of Redbridge v SNA [2015]_
[EWHC 2140, [2016] 1 FLR 994 at [37], Hayden J declined to sanction the use of the inherent jurisdiction](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMP1-DY9F-G4W3-00000-00&context=1519360)
where the proposed order against an individual was designed to protect “'any female under 18 years of
age'”. He indicated that extending: “the scope of the inherent jurisdiction to children who are neither known
nor subject to any proceedings, is to go beyond the parameters of its reach. However well-intentioned the
ambition to prevent child sexual exploitation generally, this is ultimately to make a utilitarian calculation of
social policy. The framework within which such children should be safeguarded and protected is for
Parliament to create and for the Courts to enforce”. The instant case is more akin to the situation in


-----

_Birmingham City Council v Riaz No.1, and had I felt it necessary or appropriate to make substantive_
orders, I would have done so.

17. There was, in my judgment and on the papers before me, sufficient and ostensibly reliable evidence
on which Rotherham Council could reach the view that Child G was potentially the subject of sexual
exploitation. The authority had conducted a child sexual exploitation screening, which had revealed that
Child G appeared to present with a preponderance of strong indicators of child sexual exploitation. In the
final analysis, and with the benefit of further evidence, including more detailed information from the South
Yorkshire Police, the authority is no longer of the same mind. It has concluded that:

i) While Child G remains vulnerable to child sexual exploitation, the evidence, when considered in the
round, did not support a conclusion that these four males, or any of them, were engaged in that form of
abuse;

ii) Many of the concerns about Child G's abusive treatment by any of the four associated males was
largely historic, and not current;

iii) There is little to link the four associated males to each other; there is limited evidence that HH knew
NN, and no evidence that either HH or NN knows LL and/or MM; Child G knew them in different contexts,
and had formed personal relationships with three of them at different times; there is no evidence to indicate
any gang activity;

iv) There is no evidence that MM has caused Child G any harm at all, or that he met her more than once
on 12 August; Child G did not support the grant of injunctions against LL or MM;

v) It was wrong, or at least disproportionate, to seek orders against the four associated males given that
the concerns about Child G could be, in the view of the authority, satisfactorily addressed in other ways
(see [18](i)-(iv) below).

18. No one reading the statements of evidence, or I apprehend the outline above, will be unconcerned
about Child G. She is a damaged, chaotic, young person, of that I am in no doubt. Tragically, she has
been the victim of physical, emotional and sexual abuse from different quarters over a number of years.
There is evidence that she was involved in dysfunctional relationships in the past with one or more of the
associated males, but insufficient evidence to support a finding that this amounted to child sexual
exploitation by any or all of them. Rotherham Council has indicated that it feels able to protect Child G in
ways other than by injunction by offering her services, including:

i) One-to-one counselling in relation to her general health and sexual health;

ii) Support from the mental health services, and advice from a family support counsellor to assist her to
understand issues of safety in her relationships and protection from exploitation;

iii) The allocation of a personal advisor to support her re-accessing education and/or seeking employment;

iv) Delivering support from her allocated social worker, with whom she now has a broadly co-operative
relationship;

v) Offering social work support to Child G's parents.

I have seen a detailed care plan, of which these are the headline components.

_Inter-agency decision-making_

19. Before leaving the substantive issues, I wish to raise a concern about decision-making in this case. In
September 2015, a dedicated team (the 'Evolve team') was set up in Rotherham to work with victims of
child sexual exploitation; the team comprises social workers, police officers, representatives from
Barnardo's, a specialist nurse, a CAMHS worker and a Personal Adviser for Child Exploitation; the team
operates from offices in the same building.  On 9 August, at a meeting between social workers and police,
a plan to apply for wardship in relation to Child G was discussed, with a view to placing her in secure
accommodation; the South Yorkshire Police knew of, and supported, this plan. Following the incident
described at [14] above Rotherham Council resolved to issue wardship proceedings but instead of


-----

applying for an order authorising secure accommodation, decided to seek injunctions against the four
associated males. By a lapse in communication within the team, South Yorkshire Police were not told of
this change in approach.  A further meeting was held on 15 August between police officers and social
workers; the plan to apply for wardship was again agreed between them, but the detail of the specific relief
to be sought was not discussed.  On 17 August Rotherham Council social workers told South Yorkshire
Police officers that the wardship application would be made on the following day. On 18 August, the
application was made. From that date, South Yorkshire Police became involved in the present litigation,
specifically in relation to the application for Reporting Restriction Orders. When South Yorkshire Police
filed its evidence, it was apparent that, while it had concerns about Child G, it did not actively support the
application for injunctions against the four associated males; it confirmed the position set out at [17](i)-(iv)
above, indicating separately that there was currently insufficient evidence to justify a police application for a
Sexual Risk Order (see [15](ii) above), albeit police enquiries and investigations were still ongoing. Its
formal position at this final hearing was 'neutral' on whether the injunctions were granted or not.

20. I was advised that this is the first application of its kind made by Rotherham Council. Lessons plainly
need to be (and I am told have been) learned from the manner in which it brought the issue to court. While
well-intentioned, there was a failure in the collective responsibility to work in partnership, and the members
of the team lost focus in their joint investigation – see again [10] above. In future, there needs to be, and I
am told there will be, full consultation not only between the safeguarding professionals of the team, but
also between the legal services departments for the council and the police; this dialogue needs to be
commenced at the outset of the investigation and be maintained. Focused and clear lines of
communication between the safeguarding agencies need to be observed at all times. As a result of the
lessons learned, Rotherham Council is to conduct a full learning review under the Rotherham Safeguarding
Children's Board, with the aim of establishing a more detailed protocol to address cases of child sexual
exploitation.

_Conclusion on the injunctions_

21. Having regard to the matters discussed above, I indicated at the conclusion of the hearing on 21
October that I was content to discharge the injunctions against the four associated males, and make no
further injunctive order.

_Reporting Restriction Orders_

22. The application under the inherent jurisdiction for Reporting Restriction Orders has been brought to
seek the protection of anonymity for Child G and her family, and the four associated males; the application
in its modified form seeks protection for their respective lifetimes. The inherent jurisdiction provides the
vehicle which enables the court to conduct the necessary balancing exercise between the competing rights
under the _Convention for the Protection of Human Rights and Fundamental Freedoms (the European_
Convention on Human Rights (ECHR)), most notably _Article 8 and_ _Article 10.  In considering this_
application, I balance on the one hand the “right” of the individual “to respect for his [or her] private and
family life” (Article 8(1)), and on the other “the right to freedom of expression” which is deemed to include
the right “to hold opinions and to receive and impart information and ideas without interference by public
authority and regardless of frontiers” (Article 10(1)).

23. The _Article 10(1) right is qualified by_ _Article 10(2) which refers specifically to the “duties and_
responsibilities” inherent in freedom of expression, and indicates that such a freedom “may be subject to
such formalities, conditions, restrictions or penalties as are prescribed by law and are necessary in a
democratic society”, in order to maintain a range of particular 'interests'. _[Section 12(4) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y00H-00000-00&context=1519360)_ _Human_
_Rights Act 1998 further provides that:_

“The court must have particular regard to the importance of the Convention right to freedom of expression
and, where the proceedings relate to material which the respondent claims, or which appears to the court,
to be journalistic, literary or artistic material (or to conduct connected with such material), to –

(a) the extent to which –


-----

(i) the material has, or is about to, become available to the public; or

(ii) it is, or would be, in the public interest for the material to be published;

(b) any relevant privacy code”.

24. The law in this area has been conveniently and most helpfully summarised by MacDonald J in London
_Borough of Sutton v MH & Others (No.2)_ _[2016] EWHC 1371 (Fam) at paragraphs [57-63], and specifically_
at [58]. I do not propose to replicate that here, but note and gratefully adopt his summary.  I add these
further observations.

25. Sir Mark Potter P in A Local Authority v W and others [2005] EWHC 1564, described (at [53]) each
article of the ECHR as yielding “a fundamental right which there is a pressing social need to protect”. Sir
Mark Potter emphasised in that case the importance of avoiding a mechanistic approach to the opposing
factors, based “upon the basis of rival generalities”, but encouraged the court on an application of this kind
to undertake conscientiously the “intense focus on the comparative importance of the specific rights being
claimed in the individual case” before applying the cross-check of proportionality. Article 8 embraces the
concept of “unwanted access to private information and unwanted access to [or intrusion into] one's …
personal space”: this is what Tugenhadt J in _Goodwin v NGN Ltd & VBN [2011] EWHC 1437 (at §85)_
described as "confidentiality" and "intrusion". Intrusion into one's personal space includes interference into
the life of the family aswell as the private life of the individual.

26. In Goodwin v NGN Ltd & VBN [2011] EWHC 1437 (at §85) Tugenhadt J fairly observed that:

“…what is of interest to the public is not the same as what it is in the public interest to publish. Newspaper
editors have the final decision on what is of interest to the public: judges have the final decision what it is in
the public interest to publish.”

Tugenhadt J's point had been framed in a different but complementary way by Lord Rodger of Earlsferry in
_Re Guardian News and Media Ltd_ _[2010] UKSC1 [2010] 2 AC 697@§63 when he said:_

“What's in a name? "A lot", the press would answer. This is because stories about particular individuals are
simply much more attractive to readers than stories about unidentified people. It is just human nature. And
this is why, of course, even when reporting major disasters, journalists usually look for a story about how
particular individuals are affected.”

27. Thus it is that The Times Newspapers Limited seek to avoid the risk of disembodied reporting, and
seek to have the right to publish the names of the four associated males.

28. An unusual aspect of this case is that Rotherham Council and South Yorkshire Police seek _lifelong_
protection for all five subjects. On this aspect, I have been referred to and respectfully adopt the approach
of Moore-Bick LJ in JX MX v Dartford and Gravesham NHS Trust [2015] EWCA Civ 96 at [17] ('JX MX'),
wherein he described:

i) The principle of open justice which has long been considered to be of the utmost importance (see [5]);

ii) The existence of accepted exceptions to that principle (see [13]), and Viscount Haldane L.C. (at 437) in
_Scott v Scott_ _[[1913] AC 417, Lord Reed J.S.C. in A v British Broadcasting Corporation [2014] UKSC 25,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDH0-TWXJ-21JT-00000-00&context=1519360)_

[2014] 2 WLR 1243, esp. at [23-41], all cited;

iii) The obvious derogation from the principle of open justice involved in such an application (see [17]);

iv) The requirement to consider the necessity of such an order, and whether a less extensive order would
suffice (see [17]);

v) The issue of whether the public interest in publishing a report justifies the curtailing of the individual's
right to respect for their private and family life (see [25] and [27]).

29. Keehan J in Birmingham City Council v Riaz _[2015] EWHC 1857 (Fam) ('Birmingham City Council v_
_Riaz No.2') considered specifically the application of the principles of the JX MX decision in the context of_
an application such as that before me now. I adopt his comments at [13]:


-----

“It might be thought that the decision of the Court of Appeal in _JX MX,_ in recognising that life-long
anonymity orders should normally be granted in a particular class of case, i.e. infant or protected party
settlement approval hearing, does not sit easily with the long line of authorities emphasising the importance
of open justice and the freedom of the press. For my part, I would not share that view. Rather the decision
reflects the emphasis the courts now place on the need to accord due respect to the _Article 8 rights of_
litigants, especially of children, young people and protected parties balanced against the Article 10 rights of
the press and broadcast media. The position is encapsulated in the observation of Moore-Bick LJ when he
said [at [29]]:

"The public undoubtedly has an interest in knowing how that function is performed and the principle of
open justice has an important part to play in ensuring that it is performed properly, but its nature is such
that the public interest may usually be served without the need for disclosure of the claimant's identity."

I respectfully agree.”

(1) Child G

30. No party asserts that there is any public interest in identifying Child G through press or other media
report. It is not suggested that the freedom to publish a story naming her prevails over her right to respect
for her private and family life.  There is no question but that she is a very vulnerable young person, and it
is acknowledged across the board here that publicity about her situation is only likely to cause her
additional and irredeemable harm. That much is uncontroversial.

31. The Times Newspaper Limited submits that no injunctive order is necessary, advising me that it has no
intention of reporting any information leading to the identification of Child G. I understand The Times'
position, and accept its commitment to protect Child G's identity. However, I do consider that an order is
necessary: first, because The Times is but one media organisation with an interest in these issues, and the
protection which she deserves ought to be clear to all media and other organisations. Secondly, Child G
[has a statutory right to anonymity under sections 1 and 2 of the Sexual Offences (Amendment) Act 1992,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y1NG-00000-00&context=1519360)
[given that LL and MM have been arrested on suspicion of committing offences under the Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
_[Act 2015; there is a value in having this right explicitly recognised by specific order.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

(2) Four associated males

32. Different considerations apply to the four associated males.

33. The Times Newspaper Limited understandably and rightly draws attention to the importance of
transparency and openness of judicial process as vital to the rule of law (R (Guardian News & Media Ltd) v
_City of Westminster Magistrates Court & the Govt. of the USA [2013] QB 618, and see the essential_
principle identified by Moore-Bick LJ in JX MX, at [27] above). Ms Yoshida emphasises the public interest
in informed and meaningful debate about the grave issue of child sexual exploitation, and asserts that the
value of media reporting is significantly diminished if there is no opportunity to personalise the stories with
the names of those alleged to have been involved. In those circumstances, the organisation wishes to be
able to identify the four associated males as having been the focus of this joint investigation and subject of
interim injunctions preventing contact with Child G; The Times draws attention to the fact that none of the
four associated males have actually made representations to the court about their rights (in fact MM did
subsequently send a letter to the court, from which I have quoted an extract at [42] below).

34. The Times Newspapers Limited rightly observed that a lifelong Reporting Restriction Order is a
significant interference with the rights of journalists, media organisations, and the public. On the first day of
this hearing, The Times carried a leader headed “Keep Justice open” in which it argued broadly against
anonymity for those suspected of commission of sexual offences, contending that the remedy is for the
police and prosecutors to exercise greater rigour in their investigations of offences of this kind.

35. I recognise the importance of public informed debate about the issue of child sexual exploitation. My
concern is to balance the public interest in promoting that debate and in the media's right to publish stories
about investigation into the same, against the right to privacy of those allegedly directly concerned. This
requires, as Sir Mark Potter said _A Local Authority v. W and others, “intense focus on the comparative_


-----

importance of the specific rights being claimed in the individual case”. In considering the balance of the
right to publish and the right to privacy in this case concerning these four males, I have carefully
considered the points made by Ms Yoshida, which I have summarised in [33] and [34] above. But intense
focus has had to be brought to five particular magnetic factors here:

i) None of the four associated males has been convicted of any wrongdoing; no findings are sought
against them, and no findings are made about them;

ii) The four associated males have been the subject of interim injunctions (made without hearing evidence)
but are not to be the subject of injunctions going forward;

iii) If these were criminal proceedings, and the males were charged with criminal offences, the 2015 Home
Office Guidance (below) may offer some protection as to their anonymity prior to any conviction;

iv) Naming the four associated males may have the effect of identifying Child G by presenting a 'jigsaw' of
specific information relating to her. This would have a profoundly harmful effect on Child G, as everyone
acknowledges, and may operate as a deterrent to other victims of Child Sexual Exploitation in reporting
similar offending;

v) Child G may face the recriminations from her four male associates if they are named.

36. (a) **No findings or convictions: I start by considering the case of** _Birmingham CC v Riaz No.1._
There, Keehan J held that the males had forfeited their right to anonymity by virtue of their conduct. At

[149] he said this:

“Publicity about these respondents may cause embarrassment, distress or anxiety to the respondents or to
members of their respective families and friends. Such would not have occurred if they had not engaged,
as I have found they did, in the sexual exploitation of a vulnerable young female”.

37. By contrast, in these proceedings, I am considering the position of four young men who are to be
treated as having not behaved in this way; Keehan J quite specifically declined to comment on whether he
would have ruled as he did had he not made adverse findings and injunctive orders against any of the
respondents (see Birmingham CC v Riaz No.1 at [154]). It should be noted that in this case neither HH nor
NN have even been arrested, let alone charged or prosecuted for offences relating to Child G. LL and MM
remain on police bail and will be so for a further two weeks; no charging decision has yet been made. By
the Local Authority's application not to pursue further its applications for injunctions in the wardship, and
their associated application to discharge the orders without any determination of the evidence, no findings
are sought against the four men in the family court, let alone made.  It follows that I must proceed to
determine this application for a Reporting Restriction Order in respect of them on the basis that they are
innocent of the wrongdoing of which they were originally suspected. As is well known in family and civil
law fields, the “law operates a binary system in which the only values are 0 and 1. The fact either
happened or it did not” (Lord Hoffman in Re B [2008] UKSC 35 at [2]):

“If the party who bears the burden of proof fails to discharge it, a value of 0 is returned and the fact is
treated as not having happened. If he does discharge it, a value of 1 is returned and the fact is treated as
having happened.”

38. The allegation of exploitation is therefore to be treated as having returned the value of 0; it did not
happen. In one respect, these young men stand in a similar position to defendants in criminal proceedings
against whom the prosecution has offered no evidence, or where the jury has acquitted or been directed to
acquit.  But as Ms McGahey QC observed in argument, and I accept, they would arguably be in a worse
position were they to be named following this judgment, as they would not be able to point to any public
recognition of their defence, or formal acknowledgment, record, verdict, or statement, of their innocence.

39. (b) Interim injunctions: I next ask myself what is the public interest in naming these four men in the
press as persons against whom injunction proceedings were once brought, interim injunctions (without
evidence being tested) once made, but in respect of whom in the end no findings were sought, let alone
made? In my judgment there is no, or if any, negligible, such public interest. As it happens, the evidence
reveals that MM had the most minimal involvement in Child G's life having only met her briefly on the date


-----

in August when the police exercised their powers of protection. On the other hand, there is a substantial
risk that, given the strength of feeling in Rotherham and elsewhere about those who engage in child sexual
exploitation and similar offences, they would be perceived to be perpetrators or likely perpetrators, and
pilloried and/or targeted in their communities if they were known to have been under suspicion in this way.
As The Times newspaper observes in its own leader, to which I have referred earlier (see [34] above):
“False rape and abuse accusations can inflict terrible damage on the reputations, prospects and health of
those accused. For all the presumption of innocence, mud sticks”.  There is, I acknowledge, an
unfortunate truth within that remark. I am satisfied that the rights enjoyed by the four associated males,
and also to their wider families, to a private and family life would be significantly disrupted if they were to be
named in the media. There is an obvious risk of reprisals, which play out at worst by overt hostility in the
community, damage to themselves or their homes, or at least by subtler forms of ostracism, difficulties in
personal relationships, disruption to their employment or their prospects of employment.

40. (c) Protection from the HO Guidance: In considering the issues in this case, I have been invited to
consider that the associated males may indeed be entitled to a degree of anonymity if the allegations are to
be pursued in the criminal court; it is argued, with justification, that they should not be worse off in the
family court. In this respect I was referred to the Guidance on _Part 2 of the_ _Sexual Offences Act 2003_
issued by the Home Office (March 2015) which, in this respect, I found instructive. It reads as follows:

“It is a basic principle of the justice system in this country that justice is dispensed in public and restrictions
should only be imposed where it is in the interests of justice to do so. However, concerns have been
expressed about the likelihood of an application for an order under Part 2 of the 2003 Act drawing attention
to the presence of sex offenders in the community. These concerns can be magnified if the application is
for an order that can only be made in respect of convicted sex offenders if the police have concerns about
the immediate risk they pose to the community. Whilst the police and the courts are, in fact, acting together
to secure improved protection of the public (including protection of the offender from the criminal activity of
others), any increase in public disorder not only diverts police resources but could encourage and allow the
defendant to abscond from the arrangements the public protection agencies have put in place to manage
the risks he or she poses. Therefore, it has become normal practice in some police areas, when applying
for an order of this type, for an application to be made to the court at the outset of proceedings (in general
with the support of the defendant) for an order under section 11 of the Contempt of Court Act 1981
prohibiting the publication of the defendant's name and address. It is for the court to decide whether such a
prohibition is necessary. Police forces may consider adopting similar practice where appropriate.”

41. (d) Jigsaw identification: The central argument advanced on behalf of South Yorkshire Police, a case
which is strongly supported by Rotherham Council, is the contention that if I were to name any of the four
male associates, this could or probably would lead by way of 'jigsaw' identification to the unmasking of
Child G as the subject of these proceedings. The risk of 'jigsaw' identification has to be carefully
considered by judges and lawyers whenever a family judgment is being published, particularly where the
judgment relates to families living in close-knit communities, as they do here (see, for recent examples H v
_[A (No 1) [2015] EWFC 58, H v A (No 2) [2015] EWHC 2630 (Fam), and Re J (A minor)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GFY-3NW1-F0JY-C1R2-00000-00&context=1519360)_ _[2016] EWHC 2595_
_(Fam)). Rotherham has already been named in press reports of the interim stages of this case, and there_
is therefore one significant geographic identifying feature already in the public domain.

42. The risk of 'jigsaw' identification in this particular case is heightened by the fact that, according to MM
“a large section of our community is aware that [LL] was dating [Child G] and thus it would not be a difficult
task for people to establish the identity of Child G”. Moreover, one of Child G's friends is, to the knowledge
of the police, aware of Child G's association with all four of the males; she would readily be able to make
the link between the four males and Child G. She would, in this way, be alerted to the underlying concern
of child sexual exploitation, about which she may currently be unaware. This friend is not someone who is
likely to have any interest in keeping the information about this association to herself; the speed and
simplicity of communication through any one of the multiple forms of social media raises a substantial risk
that within a short space of time the identity of Child G as the subject of suspected sexual exploitation
would be widely disseminated. There is no reason to suppose that there is only one friend who knows of
these connections; the more friends that know, the greater the risk. It is further known, separately, that a


-----

member of LL's family knows a member of Child G's family, and is aware of the connection between Child
G and LL. Naming LL from these proceedings would be very likely, through this connection, to advertise
Child G's identity to a wider circle of people.

43. The implications of identifying Child G as the subject of this investigation may extend far beyond her
own predictable distress; the Detective Chief Inspector of the South Yorkshire police in his written
statement said this:

“Rotherham has been subject of negative publicity from the Jay and Casey reports. In the wake of those
reports, the South Yorkshire Police and Rotherham Council have been making efforts to encourage victims
of child sexual exploitation to come forward and report matters, so that measures can be taken to protect
those victims. Anything which damages those efforts to build confidence in the local community, and in
particular among the victims of child sexual exploitation hampers efforts to tackle exploitation in
Rotherham.

The South Yorkshire Police works extremely hard to engage with both victims and survivors of child sexual
exploitation in Rotherham and across South Yorkshire. Reaching out to these vulnerable people often
living within hard to reach communities is undoubtedly built upon the foundations of trust and confidence in
our service. An integral part of building trust is to reassure victims of the right to anonymity and this is often
essential to victims having the confidence to come forward and speak with officers about what has
happened to them. I have no hesitation in saying that any 'jigsaw identification' of Child G will seriously
impact on the confidence of victims to come forward to the South Yorkshire Police and other forces
nationally to report forms of abuse including child sexual exploitation. In my professional opinion, this would
have a detrimental effect on the fight against child sexual exploitation within our communities.” (emphasis
by underlining added).

His concern with regard to the wider implications for victims was more emphatically expressed in oral
evidence, describing the consequences as “potentially catastrophic” to the work being undertaken by the
Rotherham Evolve team to reduce and/or eradicate child sexual exploitation in its area.

44. (e) Recriminations to Child G. There is a real possibility – i.e. one that cannot sensibly be ignored –
that if the four associated males are publicly named, they may seek some form of retaliation against Child
G for having exposed them through these proceedings. At least two of these men are believed to have
abused Child G in the past, emotionally and physically; the police have identified a risk that they in
particular could turn on her in such circumstances. While this unacceptable prospect has not been
dominant in my decision-making, I cannot ignore it, and have accordingly given it some weight in my
overall reckoning.

_Conclusion_

45. As I have indicated earlier in this judgment, there is a significant public interest in the investigation and
detection of child sexual exploitation, in the state's protection of its victims, and in the prosecution of those
who perpetrate it. There is national public interest in the incidence (indeed the prevalence) of this crime in
the area of Rotherham. For this reason, I decided that it would be right to hold the final hearing of these
applications in public, and to name the relevant council. I have no doubt that the media have an important
part to play in raising public awareness of this particular type of offence, and in reporting on the court's
approach to it.

46. It is rightly uncontroversial in this case that Child G's identity should be protected now and for the
future. She is an extremely vulnerable young person; it would be devastating to her to be named publicly
in the press as the subject of this application, and a strong deterrent to other young people who may
consider coming forward to report offending of this type. Having listened carefully to the evidence of the
relevant senior officers, I am satisfied that if I named the associated males, Child G would be quickly
identified in the local community in which she lives. That is sufficient on its own to justify the anonymity of
the four males. However, quite apart from that factor, I have reached the firm conclusion that there is no
true public interest in naming the four associated males, against whom, in the end, no findings have been
sought or made. The _Article 8 rights of the associated males would be in my judgment significantly_


-----

violated were they to be publicly exposed in the media as having been implicated to a greater or lesser
degree, but not proved to be engaged, in this type of offending. Their rights, on these facts, predominate
over the _Article 10 rights of the press to report their names while not inhibiting the press from reporting_
more widely about this case. I have cross-checked these conclusions against the measure of
proportionality and have unhesitatingly concluded that no lesser order will suffice; the injunction will
therefore extend for their lives until or unless earlier varied or discharged.

47. Thus, for the reasons set out, I propose to grant the Reporting Restriction Orders as sought by
Rotherham Council and South Yorkshire Police.

48. That is my judgment.

**End of Document**


-----

