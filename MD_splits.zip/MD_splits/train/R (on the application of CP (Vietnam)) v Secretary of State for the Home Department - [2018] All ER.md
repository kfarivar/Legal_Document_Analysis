(Sep)

# R (on the application of CP (Vietnam)) v Secretary of State for the Home
 Department [2018] All ER (D) 07 (Sep)

[2018] EWHC 2122 (Admin)

Queen's Bench Division, Administrative Court (London)

Karon Monaghan QC sitting as a deputy judge of the High Court

6 August 2018

**Immigration – Trafficking people for exploitation – Missing potential victim of trafficking**
Abstract

_Immigration – Trafficking people for exploitation. The competent authority's decision, that there had been sufficient_
_information to make a negative conclusive grounds decision, and the decision itself had been irrational and unfair,_
_and the making of the conclusive grounds decision was additionally made in breach of the defendant Secretary of_
_State's guidance and constituted a public law error. The Administrative Court further held that the whole period of_
_the claimant's detention had been unlawful and he was entitled to compensatory damages for the period lasting 70_
_days._
Digest

The judgment is available at: [2018] EWHC 2122 (Admin)

**Background**

On 14 March 2016, the claimant Vietnamese national was encountered by police officers. One of the officers
completed a referral form in respect of the claimant and submitted it to the National Referral Mechanism (the NRM).
The claimant said that, after his release from custody, he was picked up from a street by men and re-trafficked.

On 20 March, the defendant Secretary of State concluded that there were reasonable grounds to believe that the
claimant had been a victim of modern slavery (human trafficking). The decision letter was sent to the claimant at
the address held by the police. On or around 21 April, a further letter was sent to the claimant inviting him to an
interview. That letter was returned to the Secretary of State resulting in a note being placed on her records on 27
April that the claimant was not at the address to which the letter had been sent. On 28 September, following an
email from the officer-in-the-case, the competent authority decided that there was an adequate basis for making a
conclusive grounds decision, notwithstanding the absence of further contact with the claimant, and that decision
was negative.

Subsequently, the claimant was found in a cannabis factory. He was prosecuted for the production of Class B
controlled drugs – cannabis – and abstracting electricity. In April 2017, he was sentenced to four months
imprisonment following a plea of guilty to both offences.

On 11 May, a notice of a decision to deport the claimant was emailed to the prison. On 23 May, the Secretary of
State ordered the claimant's detention under immigration powers. Following an asylum-screening interview on 6
June, in which the claimant gave a similar account to that which he had given on 2 May, a referral was made to the
NRM on or around 8 June


-----

(Sep)

On 30 June, the claimant wrote to the competent authority, stating that he wished to submit that he was a victim of
re-trafficking. On 3 July, there was then a referral to the NRM for consideration of the (re-)trafficking claim. On 7
July, the competent authority decision-maker notified the NRM that she had decided to extend the time for the
making of the reasonable grounds decision by two weeks because she had only been allocated it on 5 July and it
was a complex case.

On 24 July, the claimant issued judicial review proceedings, challenging the Secretary of State's failures to properly
progress his trafficking claim and to subject him to immigration detention for a period of 70 days. On 3 August, the
claimant was released from detention. On 8 September, a positive reasonable grounds decision was made.

Application allowed.

**Issues and decisions**

(1) Whether the Secretary of State's failure to suspend the investigation into his trafficking claim in 2016 and
instead proceed to make a negative conclusive grounds decision had been in breach of the 'Victims of **_Modern_**
**_Slavery – Competent Authority Guidance' (2016), had been irrational and had violated art 4 of the European_**
Convention on Human Rights.

By no later than the 27 April 2016, the competent authority ought to have appreciated that the claimant had been
likely to be missing. That much had been clear from the returned letter and the entry on the file noting that the
claimant had not been at the address to which the letter had been sent (see [64] of the judgment).

The guidance did not prevent the decision-maker from making a negative conclusive grounds decision if sufficient
information was available to make that decision, notwithstanding that the potential victim of trafficking was missing.
Further, if the competent authority concluded that there was sufficient information to reach a conclusive grounds
decision and then made a negative conclusive grounds decision, that was challengeable only on _Wednesbury_
grounds, applying the heightened degree of scrutiny required (see [66] of the judgment).

However, the competent authority could not rationally have concluded that it had had sufficient information to come
to a (negative) conclusive grounds decision. The account in the officer-in-the-case's email had, at the very least,
required probing if the differing accounts - as between that given by the arresting officer contemporaneously
recorded in the NRM referral and that given in the email - were to be reconciled. However, the competent authority
had simply not grappled with the inconsistencies in those accounts or sought to resolve them (see [67] of the
judgment).

Accordingly, the competent authority's decision, that it had had sufficient information to come to a negative
reasonable grounds decision, had been irrational and unlawful. It ought to have been clear to the competent
authority that further information had been required and, if inquiries could not be progressed because of the
claimant's absence, the investigation ought to have been suspended. The failure to do so had been both irrational
and in breach of the Secretary of State's guidance (see [69] of the judgment).

Further, the competent authority's reasons for coming to a negative conclusive grounds decision did not
demonstrate that it had carefully analysed the relevant factors, including the contemporaneously recorded
indicators of trafficking. There had been a failure to undertake any fair or proper consideration of whether the
claimant had been trafficked and, for that reason too, the decision reached was irrational, unfair and unlawful (see

[70] of the judgment).

With respect to art 4 of the Convention, given the width of the protective obligation inherent in art 4, there might be
circumstances where an investigation of some sort was required if the protective obligation was to be properly
discharged. The procedural (investigative) duty imposed an obligation on states to investigate cases of alleged
trafficking and to identify those responsible for trafficking crimes, and in the present jurisdiction that obligation
rested with the police (see [76] of the judgment).


-----

(Sep)

The competent authority had had sufficient material on 15 March 2016 to raise a credible suspicion that the
claimant had been trafficked, and the competent authority had reached a positive reasonable grounds decision on
the basis of it shortly afterwards, and absent some steps to protect him, he had been at real and immediate risk of
being re-trafficked. That was so given what it had known from the referral about the claimant, and about what was
widely known about the trafficking and re-trafficking of young Vietnamese men, particularly into work in cannabis
farms (see [82] of the judgment).

The competent authority had taken no steps to protect the claimant when the referral had first been made on 15
March 2016, though it had come to know quickly that he had been going to be released from police custody. There
had been no steps taken to ensure that claimant had had somewhere safe to go on his release, though his potential
vulnerability had been evident from the referral. The art 4 duty and the guidance were not co-extensive, but the
guidance was a helpful indication of what could readily have been done by way of protective measures (see [83] of
the judgment).

The protective duty was not an absolute one: it had to be interpreted in a way which did not impose an impossible
or disproportionate burden. However, the competent authority had arrangements in place. It had been aware that
the claimant had been going to be released and had done nothing to ensure that proper arrangements had been in
place ensuring that he could access that safe accommodation. Thereafter, there had been no steps taken to alert
the police either to search for him or to flag him as a missing person so that, if he was found, protective measures
could be put in place. Neither of those things would have imposed a disproportionate burden. Far from taking
protective steps, the competent authority had done nothing to secure the claimant's safety and instead had
progressed to a conclusive grounds decision thereafter, including in their records a note that the claimant had been
deemed not to be trafficked so that, when in March 2017, the claimant had been found again, he had been
presumed not to be a trafficking victim with the consequence that no further steps had been taken for a very long
time to provide protection. All of those matters constituted breaches of the protective obligation under art 4 (see [84]
of the judgment).

_Hoang v Secretary of State for the Home Department_ _[[2016] EWCA Civ 565 applied; R (on the application of TDT,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
_by his litigation friend Topteagarden) v Secretary of State for the Home Department (Equality and Human Rights_
_Commission intervening)_ _[[2018] All ER (D) 38 (Jul) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_

(2) Whether the Secretary of State ought to have appreciated by no later than 2 May 2017 that the claimant's status
as a potential victim of trafficking had needed investigating.

Consistent with the Secretary of State's guidance, a referral to the NRM should have been made on or shortly after
2 May 2017 and the Secretary of State had acted in breach of her stated policy and unlawfully in failing so to do.
Instead, the referral had not been made at all until on or around 8 June 2017, over five weeks later, by which time
the claimant had already been in immigration detention (see [88] of the judgment).

Thereafter there had been considerable delay in processing the claimant's trafficking claim. There was no
explanation why it had taken three weeks to decide that the claim had been a duplicate. Further, when the
Secretary of State had recognised the claim as one of re-trafficking, it had still taken over nine weeks for a
reasonable grounds decision to be made, notwithstanding that the claimant had been in detention (see [89] of the
judgment).

Nevertheless, where there had been significant delay, as there had been in the claimant's case, it was incumbent
upon the Secretary of State to provide some good explanation for it. Otherwise there would be a breach of the
Secretary of State's policy on the making of such decisions. No explanation for the considerable delay had been
provided: there was a dearth of evidence pointing to any reason for the delay. Resources (though not relied upon by
the Secretary of State) and complexity had been adverted to at times, but with no detail or particulars provided (see

[90] of the judgment).

The failure to refer the claimant to the NRM on or shortly after 2 May 2017, when a referral had not been, but ought
to have been made and the Secretary of State's largely unexplained failure to expeditiously investigate the


-----

(Sep)

claimant's status for the purposes of coming to a reasonable grounds decision when a referral had ultimately been
made on 8 June and then on 3 July, had been in breach of the Secretary of State's policies and unlawful. There
was no breach of art 4 by reason only of the failures to investigate (see [91] of the judgment).

(3) Whether the whole period of the claimant's immigration detention had been unlawful, having regard to the
Secretary of State's policies.

It was not established on the evidence in the case that the claimant would have been detained had the breaches of
policy not occurred. If the conclusive grounds decision had not been made on 28 September 2016, but instead the
investigation suspended, an extant reasonable grounds decision would have been in place at the commencement
of the claimant's immigration detention (or at least it was not suggested otherwise) and, based on the evidence, the
claimant would have been released (see [95], [109] of the judgment).

Accordingly, the whole period of the claimant's detention had been unlawful and he was entitled to compensatory
damages for the period lasting 70 days (see [110] of the judgment).

_R (on the application of EO) v Secretary of State for the Home Department_ _[[2013] All ER (D) 248 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58GB-3YF1-DYBP-N1R1-00000-00&context=1519360)_
distinguished; R (on the application of Em) v Secretary Of State For The Home Department (2016) _[[2016] EWHC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JRG-H3S1-F0JY-C34N-00000-00&context=1519360)_
_[1000 (Admin) distinguished;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JRG-H3S1-F0JY-C34N-00000-00&context=1519360)_ _R (on the application of Adesanya) v Secretary of State for the Home Department_

_[[2016] All ER (D) 14 (Jun) distinguished;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JY7-PFT1-DYBP-N1M3-00000-00&context=1519360)_ _R (on the application of Lumba) v Secretary of State for the Home_
_Department; R (on the application of Mighty) v same_ _[[2011] 4 All ER 1 applied; R (on the application of Kambadzi) v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_
_Secretary of State for the Home Department_ _[[2011] 4 All ER 975 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54B9-S6Y1-DYBP-M426-00000-00&context=1519360)_

Louise Hooper (instructed by Duncan Lewis Solicitors Ltd) for the claimant.

William Hansen (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

