supplementary reasons)

# R (on the application of Ellis) v Secretary of State for the Home Department
 (discretionary leave policy; supplementary reasons) [2020] UKUT 82 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Chamberlain J

5 February 2020Judgment

**Representation:**

For the Applicant:   Mr. Paul Turner, Counsel, instructed directly

For the Respondent:  Mr. Nicholas Ostrowski, Counsel, instructed by the Government Legal Department

(1) _Extra-statutory immigration policies should be interpreted in accordance with the objective meaning that a_
_reasonable and literate person would ascribe to them._

(2) _The Home Office discretionary leave policy should not be read as saying that, once it is decided that an_
_individual continues to qualify for further leave on the same basis as before, he must automatically be granted_
_indefinite leave to remain after 6 years' continuous discretionary leave unless at the date of decision he falls within_
_the restricted leave policy. The word 'normally' is used advisedly, so as to maintain the maximum possible_
_discretion. Where a policy governs what is to happen in the normal case, it remains open to the decision-maker to_
_take a different course in a particular case, provided he or she takes account of the policy and has reason for_
_considering the case to be abnormal._

(3) _There are four categories of cases in which supplementary reasons, supplied in response to an actual or_
_threatened legal challenge, may be relied upon: first, to 'elucidate' reasons previously given; secondly, to constitute_
_a 'fresh decision'; thirdly, to consider material not before the decision-maker at the time when the earlier decision_
_was taken; and fourthly, to acknowledge that the original decision was flawed but simultaneously make a new one_
_to the same effect._

[(4) Even if the original decision is held to be unlawful, relief must be withheld pursuant to s.31(2A) of the Senior](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y172-00000-00&context=1519360)
_Courts Act 1981 if a further decision shows that it is highly likely that the outcome would not have been substantially_
_different, unless the proviso in s.31(2B) applies._

**DECISION AND REASONS**

**Introduction**

1 The Claimant, Mr Michael Ellis, seeks judicial review of decisions of the Secretary of State on 21 March 2019 and
16 April 2019 to refuse his application for indefinite leave to remain ('ILR') and instead to grant him 3 years'
Discretionary Leave ('DL').

2 Permission to proceed was initially refused on the papers, but was granted after an oral hearing on 18 October
2019 by Upper Tribunal Judge Norton-Taylor, limited to one ground. This was that the decision was unlawful given
that the Secretary of State's policy governing the grant of DL outside the Immigration Rules, contained in the


-----

supplementary reasons)

_Asylum Policy Instruction: Discretionary Leave, version 7.0, published on 18 August 2015 ('the DL Policy'), provides_
that those who have already completed two 3-year periods of DL should 'normally' be granted ILR.

**Background**

3 Mr Ellis is a national of Jamaica. He entered the UK as a visitor on 7 August 2000. His leave to remain was
extended to 26 January 2001. He married Jennen Blair in 2002 and, on 13 August 2003, applied for leave to remain
as the spouse of a settled person. That decision was refused, but not until 29 October 2010. In the intervening
period, he had met his current wife, Tinisha Elliston, with whom he had two children, both British citizens, born on 5
September 2006 and 6 December 2012.

4 On 23 February 2010, Mr Ellis claimed asylum. That claim was refused on 29 October 2010 and his appeal rights
were exhausted on 25 June 2011. In the meantime, on 26 March 2010, he was sentenced to 12 months'
imprisonment for obtaining property by deception.

5 After the exhaustion of his appeal rights, Mr Ellis applied for leave to remain. DL was granted for 3 years from 14
September 2011 to 13 September 2014. On 9 September 2014, he made an application to extend that leave. That
was granted on 5 April 2016, for a further 3 years. So, by 9 March 2019, when he made the application which
triggered the challenged decision, he had been in the UK lawfully, pursuant to two grants of DL, for 7 ½ years.

6 There had, however, been one potentially significant change of circumstances. On 1 March 2017, Mr Ellis had
been sentenced to 4 months' imprisonment for perverting the course of justice.

**Mr Ellis's application for ILR**

7 On 9 March 2019, Mr Ellis applied for ILR using form SET LR. This is the form applicable to applications for
settled status or ILR on the basis of long residence. He declared his criminal convictions and, in the box seeking
'evidence of an active relationship with a child or parent or medical evidence such as evidence of ill health', said
this:

'I need to stay in the UK for the [sic] my children and my wife. I am an active father in my children's life. I attend and
participate in my children's extracurricular activities, I take them to school and attend the school events (sports
days, summer fairs etc). I participate in the fundraising events they attend Boy Scouts, Guitar Lessons, Swimming
Lessons, Football Lessons and Jigsaw Art School. My wife is a Senior Staff Nurse in a Hospital and she works 150
hours a month commuting four hours a day to North West London where she works a mixture of Long Day Shifts,
Night shifts and Weekend shifts, including during holidays. There is no OFSTED Registered childcare provider
available from the time she starts work to the time she finishes, I am the only available person to take care of our
children whilst she works especially during her unsociable working hours. I contribute to the running of my church
by donating equipment, food and provide my services (catering) when our church have events.'

**The Secretary of State's decision of 21 March 2019**

8 On 21 March 2019, an official acting on behalf of the Secretary of State wrote to Mr Ellis in these terms:

'We have considered your application and you do not qualify for indefinite leave to remain. The reasons for this are
set out in Annex A to this letter.

However, we are satisfied that you would fall to be granted limited leave to remain of 36 months on the basis of
continuing to satisfy the Discretionary Leave policy, were you to make a valid application for such leave. The
detailed reasons for this are set out in Annex A.'

9 Annex A set out Mr Ellis's immigration history and noted his two custodial sentences. Under the heading
'Reasons you do not qualify for a grant of indefinite leave to remain', it said this:


-----

supplementary reasons)

'We are not satisfied that you meet the requirements of 276B(i)(a) of the Immigration Rules because you do not
have 10 years lawful leave to remain in the United Kingdom. Your first period of DL was granted on 14 September
2011, you have therefore only completed 7 years, 6 months of continuous lawful leave in the United Kingdom.'

10 It was also pointed out it was less than 7 years since the end of the sentence imposed as a result of his second
conviction and that this was a ground for refusal of ILR under paragraph 322(1C)(ii) of the Immigration Rules. This
was then said:

'Therefore, having considered all the circumstances of your particular case, it has been concluded that you have
failed to establish that there are any significantly compelling reasons which justify granting you settlement here on
an exceptional basis.

As your application is not being sought for a purpose covered by the Immigration Rules and falls for refusal on the
basis of your criminal convictions, it is refused under Paragraph 322(1) & 322(1C)(ii) of HC 395 (as amended).'

11 Under the heading 'Reasons you would qualify for a grant of discretionary leave', after noting that the
application had been considered under Appendix FM and paragraphs 276ADE(1)-CE and on the basis of
exceptional circumstances, the Secretary of State said this:

'We are satisfied that you continue to meet the requirements of the discretionary leave policy.'

**The claim for judicial review**

12 After pre-action correspondence, Mr Ellis issued a claim for judicial review on 3 June 2019. The first ground of
challenge was that, in the light of the policy on DL, the grant of 3 years' DR, rather than ILR, was unlawful. It was
said that the decision-maker 'erred by having no proper regard to [Mr Ellis's] circumstances and little regard to the
policy'. As I have said, this is the only ground in respect of which permission to proceed was granted.

**The Secretary of State's supplementary letter**

13 After permission was granted, the Secretary of State sent a further letter, dated 25 November 2019, to Mr Ellis.
It was signed by the same decision-maker (whose code was LIVSET 5) and said this:

'As you are aware, your application was the subject of a decision letter dated 21 March 2019 which you have
challenged by way of judicial review. This letter supplements the decision letter dated 21 March 2019.

We have considered your application and you do not qualify for indefinite leave to remain. The reasons for this are
set out in Annex A to this letter.

However, we are prepared to exercise discretion to grant more limited leave because your circumstances have not
changed since the first grant of Discretionary Leave, but we are not prepared to exercise discretion to grant
settlement. The detailed reasons for this are set out in Annex A.'

14 Annex A was similar to the previous version, save that the heading at the end read 'Reasons we are prepared
to exercise the discretion to grant more limited leave' and in the final paragraph said this:

'We are prepared to exercise discretion to grant more limited leave because your circumstances have not changed
since the first grant of Discretionary Leave, but we are not prepared to exercise discretion to grant settlement
considering the criminality that is detailed above.'

**The relevant provisions of the Immigration Rules and policy**

15 Mr Paul Turner, who appeared for Mr Ellis and made helpful submissions, accepts that Mr Ellis's application did
not satisfy the relevant provisions of the Immigration Rules. It is therefore not necessary to burden this decision with
detailed citation of those Rules. In short, the Secretary of State was correct to note that what was required under
paragraph 276B(i) was 10 years' continuous lawful residence in the United Kingdom (Mr Ellis had only 7 ½ at the


-----

supplementary reasons)

time of application) and that in any event he fell for refusal under the general grounds for refusal in paragraphs
276B(iii) and 322(1C)(iii) (because it was less than 7 years since the end of his last custodial sentence).

16 Mr Turner accepts that Mr Ellis used the wrong form for an application for leave to remain outside the Rules
(SET (LR) rather than SET O), but he submitted – in my judgment correctly – that this did not matter because the
Secretary of State went on to consider his application under the DL Policy in any event.

17 The title of the DL Policy (Asylum Policy Instruction: Discretionary Leave) is misleading because, as is made
clear in §1.1, it 'explains the limited circumstances in which it may be appropriate to grant DL and applies in both
asylum and non-asylum cases applying from within the UK'. The policy is 'intended to cover exceptional and
compassionate circumstances and, as such, should be used sparingly'. At §1.2, under the heading 'Background'
this is said:

'The Immigration Rules are designed to cover the vast majority of circumstances in which migrants will be granted
leave because they are entitled to remain in the UK. However, there are a small number of Home Office policies
that recognise there may be individuals who do not meet the requirements of the Immigration Rules, but there are
none the less exceptional and/or compassionate reasons for allowing them to remain here.'

18 §1.4, headed 'Application in respect of children and those with children', provides as follows:

'The application of this guidance must take into account the circumstances of each case and the impact on children,
or on those with children, in the UK. Section 55 of the Borders, Citizenship and Immigration Act 2009 places an
obligation on the Secretary of State to take account of the need to safeguard and promote the welfare of children in
the UK when carrying out immigration, asylum and nationality functions.

In practice, this requires a consideration to be made of the best interests of the child in decisions that have an
impact on that child. This is particularly important where the decision may result in the child having to leave the UK,
where there are obvious factors that adversely affect the child, or where a parent caring for the child asks us to take
particular circumstances into account. All decisions must demonstrate that the child's best interests have been
considered as a primary, but not necessarily the only, consideration…

…

In cases where it is considered appropriate to grant DL, caseworkers must also consider whether to exercise
discretion in relation to the length of leave to be granted. This is because a decision about duration of leave granted
outside the rules is an immigration function to which section 55 applies. The length of leave must be decided on the
individual facts of the case. While granted 30 months' leave will generally be appropriate, leave may be granted for
shorter or longer periods, including, in particularly compelling circumstances, indefinite leave to remain.
Caseworkers must demonstrate they have had regard to the child's best interests when considering the type and
length of leave granted following a decision to grant leave under the DL policy.'

19 The principles to be applied when deciding whether to grant leave are set out in §3. §3.6 requires caseworkers
to consider the impact of an individual's criminal history before granting any leave. The following guidance also
appears:

'In cases where there are exceptional reasons for granting DL to someone with a criminal history who does not fall
within the restricted leave policy, the duration of leave to be granted, up to 30 months will depend on the individual
circumstances of the case.'

20 Duration of leave is dealt with at §5. Mr Turner initially relied on §5.1, which provides as follows:

'Where removal is no longer considered appropriate following consideration of the exceptional factors set out in
paragraph 353B of the Immigration Rules and guidance in chapter 53 of the Enforcement Immigration Guidance
(EIG), 30 months' DL should be granted, unless one of the following situations applies:


-----

supplementary reasons)

- where the UK border agency (as it was) made a written commitment that the case would be considered either
before 20 July 2011 or before 9 July 2012, but failed to do so, and it is later decided that a grant is appropriate

- where the UK Border Agency (as it was) made a decision either before 20 July 2011 or before 9 July 2012 that a
grant of leave on the grounds then listed in Chapter 53 was not appropriate, but after that date reconsider that
decision and – on the basis of the same evidence (i.e. the evidence available to the original caseworker) – it is
decided that the earlier decision was wrong and leave should have been granted

Where the above applies and the relevant date was before 20 July 2011, Indefinite Leave to Remain (ILR) outside
the rules should be granted. This is because before 20 July 2011 ILR was normally granted in cases which met the
exceptional circumstances criteria in Chapter 53. Where the above applies and the relevant date was before 9 July
2012, three years' DL should be granted, with the person normally becoming eligible to apply for settlement after 2
periods of 3 years' DL (6 years' continuous leave). This is because from 20 July 2011 to 8 July 2012 the UK border
agency (as it was) granted three years DL in cases that met the exceptional circumstances criteria in Chapter 53.'

21 Mr Turner initially placed considerable weight on this part of the policy, but for reasons I shall explain the point
he was seeking to derive from §5.1 is in any event evidenced from §10.1.

22 Further leave applications are dealt with in §7, which provides as follows:

'This section applies to those granted and an initial period of DL on or after 9 July 2012. See section 10 on
Transitional Arrangements for cases where DL was granted before 9 July 2012.

In most cases, a person will not become eligible to apply for settlement until they have completed a continuous
period of 120 months' (10 years') limited leave.'

23 The transitional arrangements are set out in §10. At §10.1, under the heading 'Applicants granted DL before 9
July 2012', the following appears:

'Those granted leave under the DL policy in force before 9 July 2012 will normally continue to be dealt with under
that policy through to settlement if they continue to qualify for further leave on the same basis as the original DL
was granted (normally they will be eligible to apply for settlement after accruing 6 years' continuous DL (or where
appropriate a combination of DL and LOTR, C section 8 above)), unless at the date of decision they fall within the
restricted leave policy.

Caseworkers must consider whether the circumstances prevailing at the time of the original grant of leave continue
at the date of the decision. If the circumstances remain the same, the individual does not fall within the restricted
leave policy and the criminality thresholds do not apply, a further period of 3 years' DL should normally be granted.
Caseworkers must consider whether there are any circumstances that may warrant departure from the standard
period of leave. See Section 5.4 [which deals with modern slavery cases, including trafficking].'

**Submissions for Mr Ellis**

24 Mr Turner's submissions on behalf of Mr Ellis may be summarised as follows. The original decision of 21 March
2019 dealt in some detail with the claim for ILR under the Immigration Rules, but the section dealing with the grant
of DL was terse. That part of the decision did no more than state a conclusion: that the decision-maker was
satisfied that Mr Ellis continued to meet the requirements of the discretionary leave policy. It gave no reason at all
for concluding that it was appropriate to grant 3 years' DL rather than ILR, which would have been 'normal' under
the DL policy for a person in Mr Ellis's position who could show a continuous period of 6 years' lawful residence. In
that respect it was unlawful. The supplementary letter of 25 November 2019, which postdated the issue of this
claim, should not be admitted in evidence because it is an attempt to bolster the original decision by adding a
reason that was not previously given: that Mr Ellis's criminality itself supplied a reason for departing from the
'normal' position under the policy. Reliance was placed on the judgment of Underhill LJ (with which Beatson and
Black LJJ agreed) in _Caroopen v Secretary of state for the Home Department_ _[2016] EWCA Civ 1307, [2017] 1_


-----

supplementary reasons)

WLR 2339. Even if the supplementary letter were admissible, it too was inadequately reasoned. There was no
consideration of the factors advanced by Mr Ellis as relevant to his application – in particular the low level of the
criminality in his case, the extent of his relationship with his children and his family circumstances more generally.

**Submissions for the Secretary of State**

25 For the Secretary of State, Mr Ostrowski submitted that the 21 March 2019 decision letter had to be read as a
whole. For that proposition, reliance was placed on Zoumbas v Secretary of State for the Home Department _[2013]_
_UKSC 74, [2013] 1 WLR 3690, at [19] (Lord Hodge, delivering the judgment of the court). Read in that way, the first_
of the paragraphs quoted at [10] above should be understood as applicable to the refusal of ILR under the DL policy
as well as to the refusal of ILR under the Immigration Rules. The letter clearly set out Mr Ellis's history of criminality
and it was obvious that this was the reason for granting 3 months' DL, rather than ILR. That reflected a rational and
(if it is necessary so to submit) correct interpretation of the DL policy and a lawful application of it. (Reliance was
placed on the decisions of Maurice Kay J in R (Gashi) v Secretary of State for the Home Department [2003] EWHC
1198, [13]-[15], and Beatson J in R (K) v Secretary of State for the Home Department [2010] EWHC 3102, [45], for
the proposition that, in the immigration field at least, it is for the Secretary of State to interpret her own policy,
subject only to rationality review.) In any event, the supplementary letter should be admitted. It was merely an
elucidation of the reasons given in the earlier decision and so fell into the first category set out at [30] of Underhill
LJ's judgment in Caroopen. If that were wrong, it was a new decision, which was adequately reasoned. That being
so, there would therefore be no point in granting relief in respect of the first decision. Indeed, such relief would be
barred by s. 31(2A) of the Senior Courts Act 1981, because it is not only 'highly likely', but inevitable, that the
outcome would have been the same irrespective of any failure to give reasons in the first decision.

**My conclusions**

26 The sole ground of challenge for which permission has been granted is that the decision to grant 3 years' DL,
rather than ILR, was unlawful in this case given that, under the DL policy, a person in Mr Ellis's position would
'normally' be granted ILR.

The duty to give reasons

27 What counts as adequate reasons depends on the circumstances. In South Buckinghamshire District Council v
_Porter (No. 2) [2004] 1 WLR 1953, Lord Brown said this at [36]:_

'The reasons for a decision must be intelligible and they must be adequate. They must enable the reader to
understand why the matter was decided as it was and what conclusions were reached on the “principal important
controversial issues”, disclosing how any issue of law or fact was resolved. Reasons can be briefly stated, the
degree of particularity required depending entirely on the nature of the issues falling for decision. The reasoning
must not give rise to a substantial doubt as to whether the decision-maker erred in law, for example by
misunderstanding some relevant policy or some other important matter or by failing to reach a rational decision on
relevant grounds. But such adverse inference will not readily be drawn. The reasons need refer only to the main
issues in the dispute, not to every material consideration. They should enable disappointed developers to assess
their prospects of obtaining some alternative development permission, or, as the case may be, their unsuccessful
opponents to understand how the policy or approach underlying the grant of permission may impact upon future
such applications. Decision letters must be read in a straightforward manner, recognising that they are addressed to
parties well aware of the issues involved and the arguments advanced. A reasons challenge will only succeed if the
party aggrieved can satisfy the court that he has genuinely been substantially prejudiced by the failure to provide an
adequately reasoned decision.'

28 This passage has been applied generally in public law cases, including in the immigration field: see _RG_
_(Ethiopia) v Secretary of State for the Home Department [2006] EWCA Civ 339, [36] (Keene LJ)._

The correct approach to the interpretation of non-statutory immigration policies


-----

supplementary reasons)

29 In Gashi, Maurice Kay J considered a challenge to a decision taken under the Secretary of State's policy on the
exercise of discretion in safe third country cases. The Secretary of State made two alternative submissions: first
that his interpretation accorded with the 'true construction' of the policy; second, and in the alternative, that it was
reasonably open to the Secretary of State to read the policy in that way: see at [5]. Maurice Kay J rejected the first
submission at [6]-[12]. In the course of rejecting the second, at [14], he posed the question 'was the construction
placed upon [the policy] by the Secretary of State nevertheless reasonably open to him?' At [15], he answered that
question in the negative.

30 In R (Raissi) v Secretary of State for the Home Department _[2008] EWCA Civ 72, [2008] QB 836, the Court of_
Appeal held that, in interpreting an ex gratia compensation scheme made by a minister, the test was to ask what a
reasonable and literate man's understanding of it would be, not whether the meaning attributed to it by the decisionmaker was a reasonable one.

31 The issue was considered further in R (SS) v Secretary of State for the Home Department _[2008] EWHC 2069_
_(Admin), at [18]-[22]. There, Blair J cited_ _Raissi, noted that there was 'force' in the submission that what he_
described as the _Gashi approach (that the interpretation of policy was for the minister subject only to rationality_
review) should be applied to policy whose purpose was to provide 'guidance to decision-makers within the
department': see at [21]. However, as he made clear at [22], he did not need to determine the point.

32 In K, at [45], Beatson J observed that Gashi had decided that the court should ask whether an interpretation of
policy was Wednesbury reasonable, noted that it had not been cited to the court in Raissi and suggested that the
principles applicable to a policy directed 'solely internally' may differ from those applicable to a policy that was
'substantially published'.

33 For my part, I do not consider that _Gashi is authority for the proposition for which Beatson J cited it in_ _K. In_
_Gashi, there was no need for Maurice Kay J to decide the correct approach to the interpretation of policy because_
the claim succeeded even on the Secretary of State's deferential approach. As I read Maurice Kay J's decision, he
did not in fact decide which approach was the right one. But even if Gashi had decided what Beatson J thought it
decided, I would not follow it, even in the context of extra-statutory immigration decisions.

34 There are some jurisdictions where decision-makers subject to administrative law are permitted to interpret for
themselves the norms that govern their action, subject to review on a reasonableness or rationality standard. This is
the approach adopted in United States federal courts under the _Chevron doctrine (Chevron USA Inc. v Natural_
_Resources Defence Council Inc. 467 US 837 (1984)), which applies to the interpretation of statutes as well as_
policy. The UK courts have never adopted this approach to the interpretation of statute. There were some planning
and environmental cases concerned with the interpretation of policy, however, in which a similar approach was
adopted: see e.g. Cranage Parish Council v First Secretary of State _[[2004] EWHC 2949 (Admin), [2005] 2 P&CR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG31-DYBP-P4F0-00000-00&context=1519360)_
23, [44]-[48] (Davis J). All this, however, predates three significant Supreme Court cases. In _Mahad v Entry_
_Clearance Officer_ _[2009] UKSC 16, [2010] 1 WLR 48, at [10], Lord Brown (with whom the other members of the_
court agreed) held that the Immigration Rules were to be construed objectively by the court. In _R (Kambadzi) v_
_Secretary of State for the Home Department_ _[2011] UKSC 23, [2011] 1 WLR 1299, at [36], Lord Hope (with whom_
Lord Kerr agreed) held that it is for the courts, not the Secretary of State, to interpret the Operational Enforcement
Manual. And in _Tesco Stores v Dundee City Council_ _[2012] UKSC 13, 2012 SC (UKSC) 278, a planning case_
concerned with the interpretation of a development plan, Lord Reed (with whom Lord Brown, Lord Kerr and Lord
Dyson agreed) said this at [18]:

'The development plan is a carefully drafted and considered statement of policy, published in order to inform the
public of the approach which will be followed by planning authorities in decision-making unless there is good reason
to depart from it. It is intended to guide the behavior of developers and planning authorities. As in other areas of
administrative law, the policies which it sets out are designed to secure consistency and direction in the exercise of
discretionary powers, while allowing a measure of flexibility to be retained. Those considerations suggest that in
principle, in this area of public administration as in others (as discussed, for example, in R (Raissi) v Secretary of


-----

supplementary reasons)

_State for the Home Department [2008] QB 836), policy statements should be interpreted objectively in accordance_
with the language used, read as always in its proper context.'

35 The considerations mentioned by Lord Reed in this passage are, in my judgment, no less applicable to extrastatutory immigration policies such as the DL Policy than they are to development plans. The DL Policy is intended
to promote consistency in the treatment of a very large number of applications. Once a policy such as the DL Policy
is published, it is difficult to see why the principles applicable to its interpretation should differ according to whether
it is directed internally to decision-makers or intended to be relied upon by the public. Whatever the purpose of the
Secretary of State in publishing it, members of the public are entitled to, and do, rely on it in deciding whether to
spend considerable sums of money in making applications for leave to remain. It would be inimical to legal certainty
if the Secretary of State were permitted (even subject to rationality review) to interpret it other than in accordance
with the objective meaning that a reasonable and literate person would ascribe to it.

36 Auburn, Moffett and Sharland, in Judicial Review: Principles and Procedure (Oxford, 2013) at §21.45, identify
the approach attributed by Beatson J to Maurice Kay J in Gashi as founding a possible exception to the general rule
of objective interpretation in cases concerning the interpretation of non-statutory immigration policies. At §21.46,
however, they say this:

'It is difficult to see this exception to the general rule being applied in the future, as the principled justification for
adopting an objective approach to the interpretation of policies applies just as much, if not more so, in the
immigration context as in other contexts: immigration decisions can be of acute importance to individuals and
immigration policies may be applied across very many cases. Further, in light of the fact that policies must usually
be published, the reason for the exception is likely to fall away. In addition, the fact that such policies are likely to
impact on individuals' Convention rights also makes it likely that they will have to be accorded a consistent and
accessible meaning.'

I agree.

The true construction of the DL Policy

37 §5.1 of the DL Policy, on which Mr Turner initially placed considerable weight, is not – on its true construction –
applicable here at all. §5.1 makes clear the usual duration of DL should be 30 months. The exceptions are the
cases falling within the two bullet points. Mr Ellis's case plainly does not fall within either of these: there was no
written commitment in his case to consider the case before any particular date; and there was no decision at any
stage that any earlier decision had been wrong. The paragraph appearing after the bullet point starts with the words
'Where the above applies'. This shows that it applies only to cases falling within one or other of the two bullet points
above. Since this case did not fall within either of those two bullet points, the paragraph had no application to this
case.

38 §10.1 does, however, apply. In my judgment, the true meaning of the passages set out at [23] above is as
follows.

39 First, those (such as Mr Ellis) granted leave under the DL Policy in force before 9 July 2012 will 'normally'
continue to be dealt with under that policy if they continue to qualify for further leave on the same basis, unless they
fall within the restricted leave policy. Mr Ostrowski accepts that, because the Secretary of State decided that Mr
Ellis continued to qualify for leave and did not fall within the restricted leave policy, he fell to be dealt with in
accordance with the DL Policy applicable before 9 July 2012.

40 Second, the DL Policy applicable before 9 July 2012 was that those who had accrued 6 years' continuous leave
would 'normally' be eligible for ILR. The words used are 'eligible to apply for ILR', but the context here includes the
second paragraph quoted at [23] above. When those paragraphs are read together, a reasonable and literate
reader would understand that – at least in a 'normal' case – an individual who has already been granted 3 years' DL
will be granted a further 3 years' DL on the second application and ILR on the third.


-----

supplementary reasons)

41 Third, caseworkers should consider whether there are circumstances that warrant a departure from the norm.
The policy does not specify what might justify such a departure, but a criminal conviction since the last occasion
when the matter was considered could, in principle, plainly do so.

42 It follows from the above that I do not read the DL Policy as saying that, once it is decided that an individual
continues to qualify for further leave on the same basis as before, he must automatically be granted ILR after 6
years' continuous DL unless at the date of decision he falls within the restricted leave policy. The word 'normally' is
used advisedly, so as to maintain the maximum possible discretion. Consistently with the usual position in
administrative law, where a policy governs what is to happen in the normal case, it remains open to the decisionmaker to take a different course in a particular case, provided he or she takes account of the policy and has reason
for considering the case to be abnormal.

The challenge to the decision of 21 March 2019

43 The decision of 21 March 2019 must be read as a whole, bearing in mind that its author is not a lawyer.
Nonetheless, I am unable to accept Mr Ostrowski's submission that the first paragraph set out at [10] above can be
seen as giving a reason for the grant of 3 years' DL, rather than ILR, under the DL Policy. It is not simply that the
position of that paragraph strongly suggests that it was directed to the Immigration Rules. The content does not
address the question that the DL Policy required the decision-maker to answer. The conclusion that 'you have failed
to establish that there are any significantly compelling reasons which justify granting you settlement here on an
exceptional basis' reflects the wording of paragraph 353B of the Immigration Rules (which poses the question
whether there are 'exceptional circumstances which mean that removal from the United Kingdom is no longer
appropriate'). But it is not apt to address the separate and quite different question arising under §10.1 of the DL
Policy: whether there are reasons for departing from the 'normal' position that a person granted DL prior to 9 July
2012 would be eligible for ILR after 6 years' continuous DL. Indeed, it is not clear that the decision-maker directed
his or her mind to the duration of leave at all.

44 As to the text under the heading 'Reasons you would qualify for a grant of discretionary leave', that merely
reports a conclusion that the decision-maker is satisfied that Mr Ellis continues to meet the requirements of the
discretionary leave policy. I agree with Mr Turner that no reason, let alone an adequate one, is given for departing
from the 'normal position' that ILR will be granted. Indeed, the terms of the decision do not enable me to be satisfied
that the decision-maker had the DL Policy in mind at all.

45 I have borne in mind that Mr Ellis's application was made on form SET (LR). That being so, it may be that no
criticism could have been levelled at the decision-maker had he or she not considered whether to grant DL at all.
But the decision-maker did choose to consider DL and, having done so, had to consider it in accordance with the
DL Policy and consistently with the constraints imposed by public law. For the reasons I have given, the decision of
21 March 2019, read on its own and without reference to the later reasons, was unlawful for two reasons. First,
because it contained nothing to indicate that the DL Policy had been considered at all. Second, because (in any
event) it gave no reason for departing from the 'normal' position that ILR would be appropriate after 6 years'
continuous leave for an applicant in Mr Ellis's position.

The admissibility of the supplementary letter

46 In _Caroopen, at [30]-[33], Underhill LJ identified four categories of cases in which supplementary reasons,_
supplied in response to an actual or threatened legal challenge, may be relied upon.

47 First, there are the cases in which supplementary reasons are admitted to 'elucidate' reasons previously given.
Here, it is important to bear in mind the distinction between reasons which are truly elucidatory and those which are
[wholly new: see the analysis of Stanley Burnton J in Nash v Chelsea College of Art and Design [2001] EWHC 538](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P22C-00000-00&context=1519360)
_[(Admin), at [27]-[36], distinguishing R v Westminster City Council v Ermakov [1995] EWCA civ 42, [1996] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P22C-00000-00&context=1519360)_
_[302. As Underhill LJ made clear at [30] of Caroopen, however:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-602S-00000-00&context=1519360)_


-----

supplementary reasons)

'even in a case where there was no explicit statutory duty to give reasons the courts should approach attempts to
rely on subsequently provided reasons with caution; and… that was particularly so in the case of reasons put
forward after the commencement of proceedings and where important human rights are concerned'.

48 Second, there are cases where supplementary reasons do not cure any defect in the original ones, but
constitute a 'fresh decision' which (if lawful) makes it futile to require reconsideration. Reference was made to the
decision of Upper Tribunal Judge Jordan in Kerr v Secretary of State for the Home Department _[2014] UKUT 493_
_(IAC), in which he had quashed the original decision but declined to require its reconsideration and ordered the_
applicant her costs up to the date of the supplementary letter.

49 In the third category are cases where the supplementary reasons relate to material not before the decisionmaker at the time when the earlier decision was taken. Here, although as a matter of analysis the supplementary
reasons constitute a fresh decision, it may be appropriate to consider this new decision as part of the challenge to
[the first: see e.g. R v Secretary of State for the Home Department ex p. Turgut [2000] EWCA Civ 22, [2001] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-60GN-00000-00&context=1519360)
_[ER 719.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-60GN-00000-00&context=1519360)_

50 Fourth, there are cases where the Secretary of State acknowledges that the original decision was flawed but
simultaneously makes a new one to the same effect. Here, although the reason for reconsideration is different,
Underhill LJ held at [33] of Caroopen that the principles identified in Turgut should also be applied.

51 Finally, Underhill LJ observed that the four categories may often be 'blurred in practice' and accepted that it was
open to the Secretary of State to contend, first, that the original reasons were adequate; second, that if not, the new
reasons cured the defect; and third, that if that too failed, the new reasons constituted a fresh decision.

52 I turn first to Mr Ostrowski's submission that the reasons given in and attached to the letter of 25 November
2019 can be seen as elucidating those given on 21 March 2019 so as to cure any defect in the latter. The covering
letter of 25 November 2019 claims that '[t]his letter supplements the decision letter of 21 March 2019'. It might be
said that, by this formulation, the decision-maker hedged his or her bets as to which of the _Caroopen categories_
applied, but he or she certainly did not say in terms that the reasons given were an elucidation or further
explanation of those on which the original decision was made (rather than fresh reasons constituting a new
decision). Nor was there any evidence from the decision-maker, or anyone else, to assist in identifying the reasons
for the original decision. There is also force in Mr Turner's submission that, in circumstances where the original
decision gave no reason at all for granting 3 years' DL rather than ILR, there was nothing to elucidate, so that any
reason given was bound to be a new one. In any event, in line with the caution urged by Stanley Burton J in Nash
(endorsed by Underhill LJ in Caroopen), I would in general be very reluctant in a case such as this to admit reasons
proffered for the first time in a document produced after the grant of permission, contemporaneously with the
Detailed Grounds of Defence, when there had been no attempt to produce such reasons either in response to the
pre-action correspondence or in the summary grounds contained in the Acknowledgement of Service. I have
therefore concluded that the reasons contained in and attached to the letter of 25 November 2019 are not
admissible to elucidate or explain the reasons for the earlier decision of 21 March 2019. The latter falls to be
considered on its own and therefore, for the reasons I have given, was unlawful.

53 The letter of 25 November 2019 (including the new Annex A) must, therefore, be seen as constituting a fresh
decision. It was accompanied by the Detailed Grounds of Defence, which acknowledged the 'normal' position under
§10.1 of the DL Policy. The cover letter indicated that the decision-maker was prepared to grant limited DL, but 'not
to exercise discretion to grant settlement'. The new Annex A provided what the earlier one had not: a reason for
granting limited DL, rather than ILR. The reason was 'the criminality that is detailed above'. As was apparent from
what was stated 'above', this included not only the 12-month sentence imposed in 2010, which was known about
before the first grant of DL in 2011, but also the 4-month sentence for perverting the course of justice imposed in
February 2017, which was a new development since Mr Ellis's last application. Read in context, the reasons given
in the 25 November 2019 letter and the new Annex A, though hardly impressive, did not give rise to doubt as to
whether the DL Policy had been properly applied and did supply a reason that was logically capable of constituting
a basis for treating this case as abnormal for the purposes of §10.1 of the DL Policy. Although this was an


-----

supplementary reasons)

application for DL outside the Immigration Rules, paragraph 322(1C)(iii) attests to the significance that criminality
resulting in a custodial sentence of less than 12 months can have.

54 During the course of the hearing I raised the question whether the decision of 25 November 2019 could be
impugned for failure to comply with s. 55 of the Borders, Citizenship and Immigration Act 2009, to which reference
is made in §1.4 of the DL Policy quoted at [18] above. The last part of that passage is of some relevance:

'Caseworkers must demonstrate they have had regard to the child's best interests when considering the type and
length of leave granted following a decision to grant leave under the DL policy'.

Ultimately, however, it would in my judgment be wrong to entertain such a challenge when it had not been pleaded
and was not within the sole ground on which permission to proceed was granted. Insofar as it might be said that the
failure to consider the impact of the decision on Mr Ellis's children (or partner) was part and parcel of the reasons
challenge, there are two important contextual factors which must be borne in mind. First, it is not immediately
obvious what direct effect a decision to grant limited DL (rather than ILR) would have on Mr Ellis's two children, who
are British citizens. Second, and relatedly, although Mr Ellis mentioned his children and partner on his application
form (see [7] above), he did so as support for the submission that 'I need to stay in the UK'. The challenged
decision allows him to stay in the UK for the time being. There was nothing in what he had said to suggest any
particular direct effect on his children or partner of the decision as to the duration of DL to be given. In the
circumstances of the case, the effect of the duration decision on Mr Ellis's children and partner was not, in the
language of Lord Brown in the South Buckinghamshire case, among the 'main issues in the dispute'. There was,
therefore, no duty to give reasons which addressed any such effect.

55 In all the circumstances, I consider that the letter of 25 November 2019, read together with the new Annex A,
gave a legally adequate reason for concluding that Mr Ellis's case should not be treated as a 'normal' one: namely,
his criminality.

56 So, although the later reasons are inadmissible to cure the defect in the earlier ones, they constitute a fresh
decision, which is legally valid. This case therefore falls into the second category identified by Underhill LJ in
_Caroopen. It would be futile to require the decision-maker to retake the 21 March 2019 decision. A similar situation_
obtained in _Kerr, where Upper Tribunal Judge Jordan decided that the appropriate course was to quash the first_
decision but grant no further relief. Kerr, however, was decided in 2014, before the coming into force of s. 31(2A) of
the Senior Courts Act 1981, which applies to judicial review in this Tribunal by virtue of s. 15(5A) of the Tribunals,
Courts and Enforcement Act 2007. Section 31(2A) requires the refusal of relief 'if it appears to the court to be highly
likely that the outcome for the applicant would not have been substantially different if the conduct complained of had
not occurred', unless it is appropriate to disregard this requirement 'for reasons of exceptional public interest'
(pursuant to s. 31(2B)).

57 Here, the 'conduct complained of' is the failure, in the light of the DL Policy, to give adequate reasons in the
decision of 21 March 2019. Because the later, adequately reasoned decision of 25 November 2019 was made by
the same decision-maker and had the same outcome, it is (now) possible to be confident that, but for the conduct
complained of, the outcome would have been the same. Section 31(2A) therefore applies: see by analogy R (British
_Telecommunications plc) v HM Treasury_ _[2018] EWHC 3251 (Admin), [2019] Pens LR 9, [199] (Hamblen LJ and_
Whipple J). Because this claim raises no issue of exceptional public interest, s. 31(2B) does not apply. It follows
that I am required to refuse relief.

**Result**

58 Although the challenged decision of 21 March 2019 was unlawful, it has been superseded by a fresh decision
with the same outcome contained in the letter of 25 November 2019 and its Annex. That decision, taken by the
same decision-maker, was lawful. Pursuant to s. 31(2A) of the Senior Courts Act 1981, the claim therefore falls to
be dismissed.

**The Hon. Mr Justice Chamberlain**


-----

supplementary reasons)


5 February 2020

**End of Document**


-----

