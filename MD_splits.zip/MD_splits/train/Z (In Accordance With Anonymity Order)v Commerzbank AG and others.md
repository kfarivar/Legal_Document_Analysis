# Z (In Accordance With Anonymity Order)v Commerzbank AG and others

 [2024] EAT 11

Employment Appeal Tribunal

Kerr J

12 February 2024Judgment

**Mr Ross Beaton (instructed by Advocate) appeared for the Appellant**

**Ms Claire McCann (instructed by GQ Littler) appeared for the Respondents**

Hearing date: 23 January 2024

- - - - - - - - - - - - - - - - - - - - 
**JUDGMENT**

**SUMMARY**

**Anonymity; holiday pay; costs in employment tribunal; costs in the appeal**

The tribunal had correctly and lawfully decided to revoke orders (i) requiring the appellant (the claimant below) to
remain anonymous and (ii) imposing reporting restrictions preventing the disclosure of his identity, after his
evidence was found to be false and his claims dismissed.

Neither the _[Sexual Offences (Amendment) Act 1992 nor article 6 or 8 of the European Convention on Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)_
Rights entitled the claimant to continuing anonymity.

The tribunal had been entitled to dismiss his claim for outstanding holiday pay.

The tribunal was justified in making an order that the claimant pay a contribution to the respondents' costs of
£20,000.

The appeal therefore failed on all grounds.

The claimant's conduct of the appeal had been unreasonable in three respects. He was ordered to pay a
contribution of £5,362 towards the respondents' costs. THE HONOURABLE MR JUSTICE KERR:

**Introduction**

1. This appeal proceeds on three miscellaneous grounds following unsuccessful claims by the appellant, the
claimant below, determined in the London Central Employment Tribunal in 2021 and 2022. The claims were mainly
for various kinds of discrimination. The tribunal disbelieved the claimant's evidence and dismissed all the claims.
The first point of appeal challenges the decision to revoke two orders protecting the claimant's identity. The second
point is whether the tribunal was wrong to dismiss his claim for outstanding holiday pay. The third is whether the
tribunal was justified in ordering the claimant to pay a contribution of £20,000 towards the respondents' costs.


-----

2. Numerous procedural steps were taken, mainly by the claimant, in the weeks and months leading up to the
hearing of this appeal. I do not yet need to go into the details save to say that I reject the claimant's application (not
supported by Mr Beaton) to rely on a statement from a Mr Olayinka Taiwo about holiday pay. That evidence could
have been deployed before the tribunal below and does not affect any of the existing grounds of appeal; it would
require permission to raise a new ground in support of the holiday pay claim, which would be wholly inappropriate at
such a late stage.

3. The reserved decision dismissing all the claims came after a hearing from 19-27 October 2021 before
Employment Judge Snelson, sitting with Ms C. Ihnatowicz and Mr D. Clay, sent to the parties on 14 February 2022
(with minor slip rule corrections on 27 May 2022). That included rejection of the holiday pay claim, the subject of
the second issue in this appeal.  The subsequent decision on consequential matters, giving rise to the first and
third points of appeal, was made following a further hearing on 26 May 2022 before the same tribunal, followed by a
reserved decision dated 5 July 2022.

**Facts**

4. On 1 May 2019, the claimant, a black British man of Nigerian heritage, started working for the first respondent
bank (the bank) as a “know your client” analyst. His employment did not go smoothly but he managed to pass his
accreditation process at the second attempt and to pass his probation.

5. The claimant became discontent with colleagues and his employer on several counts. He alleged discrimination
against the bank and various individual respondents including, as he later alleged, sexual harassment and an
alleged sexual assault on him in or about October 2019 by the sixth respondent, Ms Q (as she remains pursuant to
an anonymity order challenged by no one). He had various meetings with colleagues and managers (which he
covertly recorded) including some of the respondents, where issues causing mutual discontent were discussed.

6. The claimant took a total of five days' leave during his time with the bank, from May to November 2019, plus
three bank holidays. It is common ground that he did not work on Thursday 7, Friday 8 and Monday 11 November
2019. The holiday pay dispute below was about whether those three days were taken as holiday or were days of
sick leave. The amount in issue which depended on that issue was a little under £600.

7. The claimant was dismissed with pay in lieu of notice on 21 November 2019. He made a complaint to the City of
London police the same day, of an alleged assault on him that day, following his exit from the bank's premises
which was encouraged by security personnel. The police took no further action on the complaint. To be clear, it
was not a complaint of sexual assault falling within section 1(1) of the Sexual Offences (Amendment) Act 1992, a
statute to which I will return shortly.

**Proceedings in the tribunal**

8. The claimant then brought his various claims in more than one set of proceedings. I need not for present
purposes rehearse the detailed procedural and case management history, which was tortuous and complex. The
claims were robustly defended by the bank and the other respondents who, eventually, all came to be represented
by the same solicitors and counsel, also representing all the respondents in this appeal. The scope of the claims
was reduced by the making of deposit orders in the case of some of the claims and the deposits then not being
paid.

9. Confining my account to what is relevant to this appeal, I start with a preliminary hearing held remotely on 20
January 2021 before Employment Judge Brown. Both sides were represented by counsel. EJ Brown gave a
detailed written judgment on numerous preliminary and interlocutory issues. She thereby narrowed the issues and
brought them into sharper focus. There was no anonymity application from the claimant or from Ms Q, the sixth
respondent, who by then had been served. The litigation was conducted publicly, in the normal way.

10. EJ Brown dealt with some disclosure issues at a telephone hearing on 8 July 2021. She made certain
disclosure orders the next day. At this stage, the identities of the claimant and Ms Q were still on the publicly
available record and there was no restriction on publishing them or information that could reveal who they are.


-----

Then on 21 July 2021, the first and sixth respondents jointly applied for an anonymity order and restricted reporting
order in respect of Ms Q, against whom the claimant was alleging sexual assault and sexual harassment. The next
day, the claimant applied for an anonymity order and restricted reporting order in respect of himself.

11. The applications came before EJ Brown at a telephone hearing on 9 September 2021, when both sides were
represented by counsel. Various arguments were made against the applications or parts of them. I need not set
out all the arguments. A representative of a media organisation opposed the restricted reporting order applications,
[but not the anonymity applications. The judge and the parties referred to the Sexual Offences (Amendment) Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
_[1992 (the 1992 Act), section 11 of the Employment Tribunals Act 1996 (the 1996 Act), rule 50 of the ET Rules of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)_
Procedure 2013 (rule 50); and to Soole J's decision in A. v. X _[[2019] IRLR 620 (EAT).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VR1-M8F2-8T41-D2SK-00000-00&context=1519360)_

12. In the case of the claimant, basing her decision on the 1992 Act and Soole J's comments on it, the judge found
that the claimant was “already protected” for life by section 1 of the 1992 Act (paragraph 43). She also decided that
she should make the same order in the interests of justice, under rule 50(3)(b), “to give effect to” the 1992 Act
(paragraph 45). She also made a restricted reporting order “of indefinite duration” (paragraph 46) in respect of the
claimant, under rule 50(3)(e).

13. At paragraphs 47 and 48, the judge referred to the Convention right to freedom of expression, but held that it
was proportionate to protect the claimant's article 8 right to privacy, because (paragraph 48) “the test of strict
necessity is satisfied in the case of a victim of an alleged sexual offence”.

14. In the case of Ms Q on whom, the judge reasoned, the protection of the 1992 Act was not bestowed, similar
orders would be made but (paragraph 49) “of limited duration until promulgation of the liability judgment in this
case”. Again, she referred to the principle of freedom of expression, but found it was outweighed by Ms Q's
concern for her privacy and article 8 rights.

15. In the case of Ms Q, the judge reasoned that (paragraph 55) “[p]ost-promulgation restrictions fall outside the
statutory exception limited in time by s 11(1)(b) [of the 1996 Act]”. Therefore, the “test of strict necessity” applied
and it would be “premature to make a decision on post-promulgation restrictions” until later, when further evidence
would be available.

16. Those decisions were embodied in three formal orders (the privacy orders). The first was an anonymity order
dated 9 September 2021 applying to both the clamant and Ms Q. It applied in the claimant's case “indefinitely” and
in Ms Q's case “until promulgation of judgment or further order”. The judge also made two separate restricted
reporting orders of the same date, one relating to the claimant, which “remains in force indefinitely”; and the other
relating to Ms Q and her husband, which “remains in force until promulgation of the liability judgment … unless
revoked earlier”.

17. The liability hearing then took place on 19-27 October 2021, as I have said. Both sides were represented by
counsel. There was an agreed list of issues. The reserved decision was not a good outcome for the claimant. The
tribunal said his account was false and made up. They dismissed all the claims, using strong language to describe
the claimant's lack of truthfulness. The bank has since made an application in the High Court, yet to be determined,
for permission to bring contempt proceedings against the claimant arising from the tribunal's finding that his account
was fabricated.

18. The tribunal gave detailed reasons for regarding the claimant (see paragraph 96) as “a witness contemptuous
of his duty to tell the truth and unworthy of belief”. The reasons also included, materially for this appeal, those
supporting its decision on the holiday pay claim, which the tribunal dismissed. I will return to what the tribunal said
about that claim when considering the holiday pay ground of appeal.

19. The judge directed that any application relating to any anonymity order or restricted reporting order should be
made within six weeks from the date the liability judgment was sent to the parties. The respondents did apply in
March 2022 to lift the anonymity and restricted reporting orders in respect of the claimant and to extend the
equivalent orders indefinitely in the case of Ms Q. The respondents also made an application for costs.


-----

20. EJ Snelson held a case management hearing on 14 April 2022 in advance of the “consequentials” hearing
scheduled to start on 26 May 2022. He directed written outline submissions by 19 May and, in relation to the
respondents' costs application:

**“(3) No later that 5 May 2022 the Claimant shall deliver electronically to the Respondents'**
**representative:**

**(a) written notification as to whether he intends to argue at the hearing that, in considering their**
**costs application, the Tribunal should have regard to his means and his ability to pay any costs awarded**
**(hereafter his 'ability to pay');**

**(b) if he does so intend, copies of all documents on which he intends to rely on the subject of his**
**ability to pay; and**

**(c) …..**

**(4) If the Claimant states, pursuant to para 2(a) above, that he intends to argue that the Tribunal**
**should have regard to his ability to pay, he shall, no later than 12 May 2022, deliver to the Respondents'**
**representative a statement in his name, signed and dated, setting out such information as to his means as**
**he may wish to disclose in support of that argument.”**

21. The respondents' applications relating to costs and to vary the privacy orders came before the full three
member tribunal on 26 May 2022, by video link, when the respondents were represented by counsel and the
claimant appeared in person, though he also had the benefit of written submissions from his counsel, mainly on the
issue whether his anonymity should continue.

22. In its reserved judgment of 5 July 2022, the tribunal granted the application that the claimant pay a contribution
of £20,000 towards the respondent's costs. I will return to the tribunal's reasoning in support of that decision when
considering the third ground of appeal, where the claimant asserts that the costs order was wrongly made and
should be set aside.

23. The tribunal then turned to the applications relating to the privacy orders. They addressed first those made in
respect of Ms Q and her husband. These were varied so as to have “indefinite effect”. There is no challenge to
that decision in this appeal and, whatever discomfort I may feel about the indefinite duration of those orders (with no
“sunset” or lapsing provision, requiring a conscious decision to extend the duration of the order periodically), I am
not seised of any application to alter the tribunal's order and have no power to do so (and Ms Q would have to have
an opportunity to be heard before any change were made to the duration of the orders protecting her identity).

24. The tribunal then turned to the privacy orders in respect of the claimant. These were revoked, subject to a
temporary stay to allow for an appeal. Again, I will return to what the tribunal stated in its reserved decision in
support of its conclusion that the privacy orders in favour of the claimant should be revoked, when I come to
consider the first ground of appeal, challenging the decision to revoke the privacy orders in favour of the claimant
and seeking to restore EJ Brown's orders.

**Proceedings on appeal**

25. Such were the three decisions of the tribunal corresponding to the three permitted grounds of this appeal. The
claimant brought various appeals against various components of the decisions against him, in different notices of
appeal. The appeals were duly sifted and for the most part not allowed to proceed further, but three exceptions
emerged from the process, corresponding to the three surviving grounds of appeal.

26. On 21 September 2022 His Honour Judge Tayler, who had allowed the anonymity ground of appeal to proceed
to a full hearing, made an order (sealed the next day) preserving the tribunal's temporary stay on the lifting of the
anonymity order in respect of the claimant pending determination of the appeal or earlier order. Her Honour Judge
Tucker made a similar order in other appeals, to the same effect, on 16 December 2022 (sealed on 30 December
2022)


-----

27. The permitted grounds were reformulated following a “rule 3(10)” hearing on 29 March 2023 before Mr Matthew
Gullick KC sitting as a judge of this appeal tribunal, in the following terms, approved by him:

**“Ground 1**

**The ET erred in law in revoking the anonymity and restricted reporting orders that applied to the**
**Claimant, having regard to the provisions of Rule 50 of the Employment Tribunal Rules 2013 read with the**
**_[Sexual Offences (Amendment) Act 1992, the terms of the original Order of EJ Brown and whether there was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)_**
**a material change of circumstances that warranted revoking the permanent Orders that EJ Brown had**
**made.**

**Ground 2**

**The ET erred in failing to consider whether the Claimant was “off sick” and therefore unable to**
**take his annual leave as opposed to whether or not there was agreement that the Claimant take a period of**
**sick leave.**

**Ground 3**

**On the issue of costs, the Tribunal erred when considering the issue of means and/or reached a**
**decision that was perverse.**

**(a) The Tribunal took into account the Appellant's ability to earn within the regulated sector which**
**would inevitably be severely curtailed by findings of fact made by the Tribunal in its liability judgment;**

**(b) The Appellant's bank statements showed that the Appellant was on universal credit and**
**therefore had personal savings of less than £16,000. The Tribunal therefore had sufficient information on**
**the Appellant's capital position.”**

28. With that rather long introduction, but covering only the small proportion of the extensive procedural history
necessary to determine this appeal, I can turn to the merits of the rather serendipitous grounds of appeal. I will
address them in the order of their numbering rather than in chronological order.

**First ground of appeal: revocation of the orders preserving the claimant's anonymity**

29. The first ground of appeal is that the tribunal erred in revoking the anonymity and reporting restriction orders in
favour of the claimant. The claimant says the tribunal wrongly withdrew the protection of the 1992 Act, misused its
powers under rule 50 of the ET Rules of Procedure and wrongly found that there had been a material change of
circumstances since EJ Brown had made the two privacy orders in favour of the claimant.

30. In the reserved decision of 5 July 2022, the tribunal referred to rule 50 of the ET Rules of Procedure, to
sections 7 and 11 of the 1996 Act and to various cases concerned with privacy and open justice, to some of which I
will return shortly. They then referred to sections 1 and 3 of the 1992 Act and to Soole J's decision in A v. X at [70],
observing at paragraph 38:

**“[t]here appears … to be no direct authority on whether, and if so how, the Tribunal should**
**endeavour to give effect to the 1992 Act.”**

31. I will set out in full most of the tribunal's reasoning supporting its decision to revoke the privacy orders relating
to the claimant. They stated as follows:

**“70 Has there bee[n] a material change of circumstances sufficient to enable the Tribunal to**
**consider revoking the original anonymity order? Plainly, there has. The exceedingly serious allegations on**
**which the Claimant based his application for anonymity have been considered, comprehensively dismissed**
**and found to be false and, in large part, made up. The foundation on which EJ Brown necessarily**


-----

**approached the application, namely that the Claimant was relying on sincere allegations advanced in good**
**faith, has been exploded.**

**71 Ms Chan submitted that the Tribunal had no power to revoke the anonymisation order in**
**respect of the Claimant because the 1992 Act contained no such power. We disagree. The order itself was**
**not made under the 1992 Act (which does not have anything to do with Employment Tribunals) but under**
**the 2013 Rules, r50. The power to revoke lies under the 2013 Rules, r29. The argument that no direction has**
**been made under the 1992 Act, s3(2) [footnote 3] and therefore there is no power to revoke under r29 is**
**misconceived.**

**[Footnote 3:] 3 Such direction may only be made “at a [criminal] trial” by a justice of the peace or**
**Crown Court judge (s3(6)). There has been no criminal trial. Indeed, not surprisingly, no criminal charge**
**was ever brought against Q (see generally ss1(2) and (3) and 6(3)).**

**72 We agree with Ms McCann that the correct approach is to exercise our case management**
**powers under r29 in light of, and in keeping with the spirit and intention of, the 1992 Act. This approach**
**recognises that the protection under the 1992 Act is automatic and, in principle, permanent. The underlying**
**policy objective is clear: to ensure that victims of sexual offences are not discouraged from making**
**complaints for fear of facing distressing publicity. Eloquent of that purpose is the express stipulation that a**
**s3 direction is not to be given only because of the outcome of the trial (s3(3)). A complainant in a rape case**
**must not be at risk of losing her anonymity simply because the Defendant is acquitted. We agree with Ms**
**McCann (submissions, para 27) that great care must be taken before any inroads are made into the s1**
**protection. But we also agree with her further contention that our procedural rules enable us remove or**
**relax that protection in special circumstances. We cannot accept the contrary view, namely that any**
**allegation ostensibly within the reach of the 1992 Act attracts protection which is lifelong and irrevocable**
**regardless of a judicial finding subsequently made following a comprehensive hearing that it was false to**
**the point of being simply made up. Such was and is our finding and the necessary logic, from which we do**
**not shrink, is that the application for privacy orders made on the strength of it was equally dishonest and**
**the resulting orders were secured on the basis of gross and wilful misrepresentations. We simply cannot**
**accept that the law is powerless to separate the Claimant from a protection to which, as is now apparent,**
**he was never entitled. It is to us unthinkable that our procedural law, founded on the overriding objective of**
**deciding cases justly, could contemplate such a bizarre and unjust result. We cannot disagree with Ms**
**McCann that if it did, it would make a mockery of the protection which the 1992 Act is designed to enshrine.**

**73 If we are right so far, the next question is, How should we resolve the balancing exercise**
**between competing interests? We agree with Ms McCann that it is material here that the privacy orders**
**secured by the Claimant involved derogating from the open justice principle and freedom of expression.**
**We have explained why, in our view, extending the anonymisation protection the case of Q would entail a**
**minor derogation. By contrast, we do not consider that permitting the Claimant's protection to last**
**indefinitely could sensibly be seen as having a similar effect. His is a most unusual story and we can well**
**see why it would be of considerable interest to the press and the public. His identity would be a matter of**
**legitimate interest given the Tribunal's findings, in the way that Q's would not. Against the interests of open**
**justice and freedom of interest, we see no countervailing argument based on the Claimant's Convention**
**rights. If, as we have held, he did not have a sustainable right to litigate anonymously, it cannot be said that**
**his right to respect for his private life would be violated as a consequence of the anonymity being lost.**

**74 Would revoking the anonymity order in the Claimant's case undermine the vital interest which**
**the 1992 Act seeks to protect? In our judgment, it would not. To be clear, we regard this as a wholly**
**exceptional case and we see no possible reason for fearing that our decision could affect public**
**confidence in the principle that those who raise complaints of sexual offences can do so without their**
**identities becoming known.**

**75 For all these reasons, we conclude that the Respondents have demonstrated that the**
**exceptional measure sought by their application … is both proper and necessary.”**


-----

_Open justice generally and in tribunals_

32. This ground of appeal raises questions about open justice, rightly proclaimed as a high principle of our law,
protecting the public against arbitrary decision making and keeping judges and courts publicly accountable. Open
justice has never been under more pressure. It has to hold its own against proliferating sources of and uses of
powers to derogate from it. The anonymisation of individual litigants is now more widespread than ever and no
longer just in family law cases.

33. Apart from the longstanding common law power to derogate from open justice where necessary to do justice,
Convention rights (especially article 8 ECHR) may provide another and broader basis for doing so. Statutory
[derogation provisions are also sometimes enacted. Examples are the Contempt of Court Act 1981 and, relevant to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0M0-TWPY-Y1JF-00000-00&context=1519360)
this case, the 1992 Act. Specialist tribunals also tend to have their own procedural law powers to reduce the
openness of their proceedings. Sometimes those powers are drawn more widely than the general law; and they
may be too eagerly invoked, as we saw recently in _Lu v. Solicitors' Regulation Authority_ _[2022] EWHC 1729_
_(Admin)._

34. In the present case, there are four relevant strands of legislative and judicial authority of potential relevance to
the two privacy orders made in favour of the claimant. They are the common law; the article 8 Convention right; the
1992 Act; and the 1996 Act read together with rule 50 of the ET Rules of Procedure 2013. I was referred by
counsel to all these sources of law and related cases. There was no real disagreement between the parties about
their impact, other than in the case of the 1992 Act. I can therefore address the other relevant law quite briefly,
without extensive citation.

35. I will take as read the principle of open justice and derogations from it applying the common law or article 8,
balanced against freedom of expression under article 10; as expounded in authorities such as Scott v. Scott _[[1913]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDH0-TWXJ-21JT-00000-00&context=1519360)_
_[AC 417; Attorney-General v. Leveller Magazine Ltd [1979] AC 440; section 12 of the Human Rights Act 1998; In re](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDH0-TWXJ-21JT-00000-00&context=1519360)_
_S (a Child) (Identification: Restrictions on Publication) [2005] 1 AC 593;_ _Re Officer L [2007] 1 WLR 2135;_ _Re_
_Guardian News and Media Ltd [2010] 2 AC 697; and Khuja v. Times Newspapers Ltd [2019] AC 161._

36. Whereas the common law permits the court to control its own arrangements and procedures for the conduct of
legal proceedings before it, for example by receiving material in private or restricting access to information before
the court in some other way, for example, by using initials or pseudonyms to protect the identity of particular
persons, reporting restrictions must be statutory; the common law does not empower the court to impose them. As
Lord Sumption pointed out in Khuja at [16], “[r]eporting restrictions are different. The material is there to be seen
and heard, but may not be reported. This is direct press censorship.”

_The 1992 Act_

37. Ms McCann helpfully traced the history of the 1992 Act to its origins in the report of the Heilbron Committee in
1975. It is best explained in Rook and Ward on Sexual Offences, 6[th] edition at 29.11 and 29.12, worth quoting in
full (omitting some footnote references):

**“29.11 The Heilbron Committee, reporting in 1975 on the law of rape [Report on the Advisory**
**_Group on the Law of Rape, Cmnd. 6352 (1975)], recommended the creation of a general rule protecting the_**
**anonymity of the complainant in a rape case. The Committee stated [paras 153-157]:**

**'Public knowledge of the indignity which [the complainant] has suffered in being raped may be**
**extremely disturbing and even positively harmful, and the risk of such positive knowledge can operate as a**
**severe deterrent to bring proceedings.'**

**It recommended that, to be fully effective, anonymity should commence from the making of a**
**complaint to the police or, in the case of a private prosecution, when proceedings are formally started by**
**complaint to a magistrate.**


-----

**[29.12 In response, Parliament enacted s.4(1) of the Sexual Offences (Amendment) Act 1976, which](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0SN-00000-00&context=1519360)**
**created a general rule restricting publication of the identity of a complainant of a 'rape offence' together**
**with a strong presumption against lifting the restriction. A 'rape offence' was defined to cover rape,**
**attempted rape, aiding, abetting, counselling and procuring rape or attempted rape, and incitement to rape.**
**[Parliament subsequently enacted provisions in the Sexual Offences (Amendment) Act 1992 which extended](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)**
**the statutory protection of anonymity to complainants of most other sexual offences. This had the effect of**
**creating two parallel regimes dealing with anonymity in sex cases. To address this, provisions were**
**included in the YJCEA [Youth Justice and Criminal Evidence Act] 1999 extending the 1992 Act to all sex**
**offences, including rape, and repealing the 1976 Act. However, these provisions were not immediately**
**brought into force. Before they were, the scope of the 1976 and 1992 Acts was significantly amended by the**
**_[Sexual Offences Act 2003, with effect from 1 May 2004. That Act amended the definition of 'a rape offence'](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)_**
**in the 1976 Act to cover all the offences of rape and penetration created by the 2003 Act itself. But it also**
**amended the scope of the 1992 Act to cover almost all the sexual offences created by Pt 1 of the 2003 Act,**
**including the offences of rape and penetration. The effect was to create a substantial overlap between the**
**two regimes dealing with anonymity in sex cases. This untidy situation was resolved on 7 October 2004,**
**[when the provisions of the YJCEA 1999 were brought into force, extending the 1992 Act to all sex offences](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61F0-TWPY-Y1GJ-00000-00&context=1519360)**
**(with some exceptions, discussed below) and repealing the 1976 Act. Accordingly, as matters stand, the**
**anonymity of complainants of sex offences, including offences of rape and penetration, is secured by the**
**1992 Act.”**

38. Section 1(1) of the 1992 Act prohibits identification or publishing of material likely to lead to identification of a
complainant where “an allegation has been made” against a person that the person has committed an offence to
which the 1992 Act applies against the complainant. Where the person is “accused” of such an offence, the same
prohibition against identification or publication of material likely to lead to identification applies: section 1(2). A
person is “accused” of the offence if (by section 6(3)) an information is laid, he appears before a court charged with
the offence, he is sent by a court for trial in the crown court, or a bill of indictment is preferred charging him with the
offence.

39. Section 1 does not require or empower the trial court to make an order mirroring the prohibitions in section 1 of
the 1992 Act; there is no need for such an order; the prohibition is statutory and therefore automatic; see _In re_
_Press Association v. Cambridge Crown Court [2013] 1 WLR 1979, per Lord Judge CJ giving the judgment of the_
court at [15] and [16]. Breach of the prohibition is an offence, punishable by a fine, under section 5 of the 1992 Act.

40. By section 1(4), the section does not prohibit publication of matter “consisting only of a report of criminal
proceedings other than proceedings at, or intended to lead to, or on an appeal arising out of, a trial at which the
accused is charged with the offence.” Thus, the prohibitions in section 1 do not extend to a report of a subsequent
trial of the complainant for perjury or doing acts tending and intended to pervert the course of justice: R. v. Beale

[2017] EWCA Crim 1012, per Sharp LJ (as she then was) giving the judgment of the court at [14].

41. The prohibitions in section 1 have effect subject to any direction under section 3 (section 1(3)(b)). Before a trial
for an offence within the 1992 Act, the judge may remove the prohibition to induce witnesses to come forward, if the
defendant's trial would otherwise be substantially prejudiced (section 3(1)). At or after trial, the judge may relax the
section 1 restriction if he or she considers the prohibitions are a substantial and unreasonable restriction on
reporting of the proceedings and that it is in the public interest to relax or remove the restriction (section 3(2)). But
(by section 3(3)) a direction under section 3(2) must not be given “by reason only of the outcome of the trial”.

42. Ms McCann drew to my attention further noteworthy commentary concerning the making of an “allegation”, in
_Arlidge, Eady and Smith on Contempt, 5[th] edition, at 8-20:_

**“8-20 Originally, protection was afforded only from the time when a suspect was charged. This**
**seemed to miss the point of the recommendation to a large extent. Its purpose was not limited to the actual**
**course of criminal proceedings, but was also directed to the encouragement of complainants not to hold**
**back from making complaints. Unless they are protected during that especially vulnerable period prior to**
**anyone being charged, the policy objective would be frustrated. Eventually, amendments were made to the**


-----

**Act to deal with this problem; protection is now granted from the moment “where an allegation has been**
**[made” [footnote 55]. This change was effected by the Criminal Justice Act 1988 s.158. The provisions are](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHJ0-TWPY-Y0DP-00000-00&context=1519360)**
**[now to be found in the Sexual Offences (Amendment) Act 1992 s.1(1) (as amended).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y1NG-00000-00&context=1519360)**

**[Footnote 55:] No doubt the legislature contemplated that such an “allegation” would ordinarily be**
**made by the victim (perhaps to the police, a social worker, or to a parent or carer), whereas in O'Riordan v**
**_DPP_** **_[[2005] EWHC 1240 (Admin) … when the abductor was being interviewed by the police a number of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG71-DYBP-P32N-00000-00&context=1519360)_**
**[sexual offences came to light. When he was arrested for an offence under the Indecency with Children Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CMY0-TWPY-Y1G3-00000-00&context=1519360)**
**_[1960,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CMY0-TWPY-Y1G3-00000-00&context=1519360)_** **and the** **_[Sexual Offences (Conspiracy and Incitement) Act 1996 s.2, this was said to constitute an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9KN0-TWPY-Y0JX-00000-00&context=1519360)_**
**allegation to which the prohibition upon publication in the 1992 Act applied: see the judgment at [6].”**

43. In non-criminal proceedings, the impact of section 1 of the 1992 Act has been considered on several
occasions. In this appeal tribunal, Soole J gave extensive consideration to issues of anonymity and reporting
restrictions in _A. v. X_ _[[2019] IRLR 620. His analysis proceeded from, among other things, the premise that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VR1-M8F2-8T41-D2SK-00000-00&context=1519360)_
protection of the 1992 Act applied to the claimants in the employment tribunal, whose claims included the
commission against them of sexual offences falling within the scope of the 1992 Act: see the judgment at [4], [62]
and [70]. There was no challenge to that premise.

44. The claims in A. v. X were made in the tribunal and thus, applying literally the words in section 1(1) of the 1992
Act, it was a case where “an allegation has been made” to the employment tribunal of an offence within the scope
of the 1992 Act; but I can find nothing in the report of the case to suggest that any formal complaint had been made
to a person or body with potential criminal justice responsibilities, such as a police officer, prosecuting authority,
safeguarding body or social worker.

45. Next comes _Plymouth City Council v. ABC_ _[[2022] EWHC 2426 (Ch), a decision of His Honour Judge Paul](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66HT-9V33-GXF6-84MK-00000-00&context=1519360)_
Matthews, sitting as a judge of the High Court at Bristol, on 30 September 2022. The judgment is sub-headed
“[i]ssue dealt with on paper”. The defendant was not represented but the claimant was, by counsel. Soole J's
decision in _A. v. X was not cited. The underlying civil claim was that the defendant employee had downloaded_
personal data and confidential information otherwise than for her employment duties.

46. The judge had earlier refused to make an order that she remain anonymous. The defendant sought to appeal
against another later refusal of anonymity by the same judge. Her proposed grounds of appeal included reliance on
the 1992 Act, a point not argued previously. Judge Matthews refused permission to appeal but gave a written
judgment on the 1992 Act issue as he thought “it would assist the Court of Appeal if I stated my views on the point”.

47. In those unusual circumstances, the judge's reasoning is _obiter, but of interest. The claimant employer_
submitted that the 1992 Act had no application. The proceedings were not related to the commission of any offence
covered by the 1992 Act. There was no allegation in the proceedings that such an offence had been committed.
The defendant responded that the proceedings were related to earlier proceedings between her and a former
partner and that she wished to refer to her history of surviving domestic abuse as part of her defence to the claim.

48. The judge noted at [10] that the defendant had brought employment tribunal proceedings against the claimant,
Plymouth City Council, and claimed to have sought anonymity in those proceedings invoking (among other things)
the 1992 Act. The judge did not agree that she had sufficiently invoked the 1992 Act in those proceedings. He
then considered whether the defendant could rely on the 1992 Act in the civil proceedings before him and decided
that she could not but, in case he was wrong, went on to consider the impact, if any, of the 1992 Act in those
proceedings.

49. At [23], Judge Matthews said of section 1(1):

**“The Act in section 1(1) specifically refers to “an allegation [having] been made that an offence to**
**which this Act applies has been committed against a person”, and “the person against whom the offence is**
**alleged to have been committed”. The natural meaning of these words is to refer to the case of a person**
**who is charged with having committed such an offence against another person, and criminal proceedings**


-----

**being instituted. But they can also be read as applying to a case where one person has accused another,**
**whether in civil proceedings or indeed out-of-court, of having committed such an offence.”**

50. He then referred to a case in which Sales J (as he then was) had been considering the administration of the
estate of the late Jimmy Savile: National Westminster Bank plc v. Lucas _[2014] EWHC 653 (Ch). At [24] and [25]_
Judge Matthews quoted from Sales J's judgment. A concern had arisen that the executors might be barred by the
1992 Act from identifying to others alleged victims of Savile, who might want to make claims against the estate
under a proposed scheme.

51. Sales J did not have to decide whether the 1992 Act had any application (see his judgment at [55]). He was
concerned about the issue “because no-one had presented any detailed reasoned argument to me to explain why
this would be the effect of the 1992 Act (and I was doubtful, absent such argument, that it would be) … .”  Instead,
an amendment to the proposed scheme was agreed requiring any alleged victim to consent to her identity being
revealed to the extent necessary to enable the claim to be assessed.

52. After considering that and another inconclusive authority in a family law context (the decision of Keenan J in
_Birmingham City Council v Riaz_ _[[2016] 1 FLR 797), Judge Matthews expressed his view (at [30]) that:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMR1-DY9F-G096-00000-00&context=1519360)_

**“'allegation' in section 1(1) of the 1992 Act refers to a formal allegation made in criminal**
**proceedings, that is, where a criminal charge has been made. Accordingly, in my judgment, the Act does**
**not apply in the present case.”**

53. A few months later, on 16 February 2023, His Honour Judge Wayne Beard gave judgment in a case dealing
with anonymity and reporting restrictions, A v. Choice Support (formerly MCCH Ltd) _[2023] EAT 18. He recorded at_

[5] that there was an issue about any right to waive anonymity under the 1992 Act. It appears to have been
assumed, without debate, that the protection of the 1992 Act applied to the claimant. Neither of the decisions in A.
_v. X and Plymouth City Council v. ABC is mentioned in the judgment._

54. His Honour Judge Beard's account of the facts included at [13] that the claimant's allegations included that she
had been raped by one “EA”, a co-worker and “that the incident was reported to the police, but the Claimant
withdrew her support of the police inquiry into the allegation of rape.” The judge bore in mind (see his judgment at

[40]) the statutory protection in section 1 of the 1992 Act, which, it appears, everyone assumed was applicable.

_Section 11 of the 1996 Act and the ET Rules of Procedure_

55. Section 11 of the 1996 is part of a suite of provisions (see also sections 10, 10A, 10B and 12) enabling rules to
be made providing for derogations from open justice in employment tribunal proceedings in certain circumstances.
Section 11 provides so far as material here:

**“(1) Employment tribunal procedure regulations may include provision—**

**(a) for cases involving allegations of the commission of sexual offences, for securing that the**
**registration or other making available of documents or decisions shall be so effected as to prevent the**
**identification of any person affected by or making the allegation, and**

**(b) for cases involving allegations of sexual misconduct, enabling an employment tribunal on the**
**application of any party to proceedings before it or of its own motion, to make a restricted reporting order**
**having effect (if not revoked earlier) until the promulgation of the decision of the tribunal.**

**….**

**(6) In this section—**

**…..**


-----

**“sexual misconduct” means the commission of a sexual offence, sexual harassment or other**
**adverse conduct (of whatever nature) related to sex, and conduct is related to sex whether the relationship**
**with sex lies in the character of the conduct or in its having reference to the sex or sexual orientation of the**
**person at whom the conduct is directed,**

**[“sexual offence” means any offence to which section 4 of the Sexual Offences (Amendment) Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0SN-00000-00&context=1519360)**
**[1976, the Sexual Offences (Amendment) Act 1992.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)**

56. So there is a link between the rule making provision in the 1996 Act and the scope of “sexual offences” in the
1992 Act. I should also mention section 7 of the 1996 Act, a generic provision about employment tribunal
procedure rules and the making thereof by the Secretary of State. They may cover the various processes and
procedures necessary for the operation of the tribunals: appointment of members, hearing cases together, requiring
witnesses to attend, documents to be disclosed, hearings to be held, and so forth. By section 7(1) they may contain
“such provision as appears to him to be necessary or expedient with respect to proceedings before employment
tribunals”.

57. Rule 50 of the ET Rules of Procedure 2013 provides as follows, so far as material:

**“50 - Privacy and restrictions on disclosure**

**(1) A Tribunal may at any stage of the proceedings, on its own initiative or on application, make an**
**order with a view to preventing or restricting the public disclosure of any aspect of those proceedings so**
**far as it considers necessary in the interests of justice or in order to protect the Convention rights of any**
**person … .**

**(2) In considering whether to make an order under this rule, the Tribunal shall give full weight to**
**the principle of open justice and to the Convention right to freedom of expression.**

**(3) Such orders may include—**

**(a) an order that a hearing that would otherwise be in public be conducted, in whole or in part, in**
**private;**

**(b) an order that the identities of specified parties, witnesses or other persons referred to in the**
**proceedings should not be disclosed to the public, by the use of anonymisation or otherwise, whether in**
**the course of any hearing or in its listing or in any documents entered on the Register or otherwise forming**
**part of the public record;**

**(c) an order for measures preventing witnesses at a public hearing being identifiable by members**
**of the public;**

**(d) a restricted reporting order within the terms of section 11 or 12 of the Employment Tribunals**
**Act.**

**(4) Any party, or other person with a legitimate interest, who has not had a reasonable opportunity**
**to make representations before an order under this rule is made may apply to the Tribunal in writing for the**
**order to be revoked or discharged, either on the basis of written representations or, if requested, at a**
**hearing.”**

58. I should also mention rule 29 of the ET Rules of Procedure 2013, which enacts a general power to make case
management orders and to vary, suspend or set aside such orders “where that is necessary in the interests of
justice”. It is common ground that a good reason must be shown for varying or setting aside an earlier case
management order, i.e. a material change of circumstances or where the earlier order had been made on the basis
of a material omission or misstatement: Serco Ltd v. Wells [2016] ICR 768, per His Honour Judge Hand QC at [43].


-----

59. In the context of an employment tribunal claim, the complex interaction of rule 50, common law derogation from
open justice and derogations applying Convention rights, was considered by the Court of Appeal in _Millicom_
_Services UK Ltd. v. Clifford [2023] ICR 663. That authority demonstrates how sophisticated may be the analysis of_
individual bases for seeking derogations on varying grounds: the interests of justice, Convention rights and, more
particularly on the facts, protection of employees' safety, unwillingness to give evidence or contest a claim unless
derogations were made and the protection of confidentiality obligations under an employment contract.

_Submissions_

60. The claimant's submissions, made through Mr Beaton, can be paraphrased as follows. The privacy orders
made by EJ Brown were properly made under rule 50. The complaints were of sexual misconduct and a sexual
offence (a sexual assault) on the claimant by Ms Q. The claimant enjoyed the protection of the 1992 Act. Although
he had begun the claim as a named litigant, once the anonymity order and reporting restrictions order in his favour
had been made, he had a legitimate expectation of anonymity and, as the 1992 Act provides, that it would be
lifelong.

61. The tribunal's finding in its liability judgment that the claimant's allegations were false and in large part made up
was not a material change of circumstances justifying the revocation of EJ Brown's two privacy orders protecting
the claimant. The tribunal thereby removed the lifelong protection of the 1992 Act to which the claimant was
entitled, Mr Beaton contended. The tribunal's view that the claimant did not have a sustainable right to litigate
anonymously, once his allegations against Ms Q had been found to be false, was wrong.

62. Alternatively, Mr Beaton submitted, the tribunal should have carried out a proper balancing exercise for the
purpose of deciding whether the claimant's rights under article 6 (fair trial rights) and especially article 8 (the right to
respect for his private or family life) were outweighed by the right of others to freedom of expression under article 10
of the Convention. Mr Beaton argued that the tribunal failed to weigh the claimant's rights in the scales, on his side
of the balance, or wrongly accorded them no weight.

63. Mr Beaton submitted in oral argument that since the protection of the 1992 Act applied to the claimant
throughout his life, it remained an offence under section 5 of the 1992 Act to identify the claimant irrespective of the
fact that the tribunal had, after the liability judgment, revoked EJ Brown's two orders. The protection endured
without the need for any order of a court or tribunal. The same would be the position if this appeal tribunal should
uphold the revocation of EJ Brown's two orders. To avoid incongruity, the appeal tribunal should not decide this
appeal, and the tribunal should not have decided below, to lend authority to a state of affairs that was at odds with
the criminal law.

64. For those reasons, Mr Beaton submitted that the first ground of the appeal should be upheld, the appeal should
be allowed and the two privacy orders of EJ Brown should be restored. Alternatively, if that was wrong, the appeal
tribunal should allow the appeal and itself conduct the balancing exercise having regard to the claimant's rights
under articles 6 and 8 and the interests of justice including the very restricted circumstances in which (under section
3 of the 1992 Act) a court can remove the protected person's right to anonymity.

65. For the respondents, Ms McCann referred to the account of open justice in the context of employment
tribunals, of Simler P (as she then was) in Fallows v. News Group Newspapers Ltd [2016] ICR 801, from which the
following principles can be derived. The open justice principle is grounded in the public interest irrespective of any
particular public interest in the facts of the case. Where article 8 rights are relevant, a balancing exercise is
required separately for each relevant article 8 right; there must be an intense focus on the comparative importance
of the competing rights in the factual circumstances of the case; neither article 8 nor article 10 rights have
precedence over the other; and the least interference consistent with protecting the competing rights should be
imposed.

66. Permanent privacy orders should be very rare, Ms McCann submitted. Orders made under rule 50 but outside
the statutory exceptions in section 11(1)(a) of the 1996 Act (and deriving their vires from section 7 of that Act) can
only be made where the test of strict necessity is met: per Soole J in _A. v. X at [60(6)]. The same test of strict_


-----

necessity applies where the order is made within the terms of section 11(1)(a) (ibid., at [60(2)]). Post-promulgation
reporting restriction orders, i.e. outlasting the decision on liability, must meet that test and should be very rare.

67. Ms McCann made detailed written and oral submissions which I can paraphrase briefly. They amounted to a
robust defence of the tribunal's reasoning and decision. The tribunal was right, she said, to find that there had been
a material change of circumstances – namely, the finding that the claimant's case had been advanced dishonestly –
and that there was ample justification for its conclusion that the claimant was no longer entitled to the privacy orders
to protect his rights, either under the 1992 Act or article 8 of the Convention.

68. Ms McCann submitted that the 1992 Act did not protect the claimant because (as put in her skeleton argument)
“no formal allegation of a sexual assault had ever … been made by [the claimant] in the context of potential or
actual criminal proceedings”. There was no “allegation” within section 1(1) of the 1992 Act. Still less had any
person been “accused” of a relevant sexual offence, i.e. charged with one, within section 1(2) and 6(3). The
reasoning of Judge Matthews in _Plymouth City Councl v. ABC was sound and should be followed, Ms McCann_
submitted.

69. The tribunal had been right to decide that the 1992 Act did not cover allegations made in employment tribunal
proceedings. EJ Brown had been wrong to decide otherwise when making the privacy orders in the claimant's
favour. Even if section 1(1) of the 1992 Act did apply to allegations made in an employment tribunal, the tribunal
should still apply the test of strict necessity when considering the derogations from open justice contended for. By
analogy with section 1(4) of the 1992 Act and the reasoning in R. v. Beale, the protection could not continue once
the claimant's perjured evidence had been exposed.

_Reasoning and conclusions_

70. As noted earlier, there was no real dispute between the parties about the law, except on the question whether
or how the 1992 Act impacts, or may impact, on employment tribunal proceedings or other non-criminal
proceedings. I will therefore start with the 1992 Act. The key question is the scope and interpretation of section
1(1). It is headed “Anonymity of victims of certain offences”. The lifelong anonymity protection applies “[w]here an
allegation has been made” that a sexual offence within the Act has been made against the alleged victim.

71. The first point is that the language used in the 1992 Act is very much the language of the criminal law. By
section 2(1) it applies to criminal offences “against the law of England and Wales”. Section 2 is, indeed, headed
“Offences to which this Act applies”. It defines the offences within the Act by reference to the content of the criminal
law. Many of the offences included within section 2 are created by statute. They are identified by reference to the
statute and sometimes the section number creating the offence (for example, by reference to section 2 of the
**_Modern Slavery Act 2015 creating the offence of human trafficking)._**

72. Next, the subject matter of section 1 is (in the case of section 1(1)) an allegation of or (in the case of section
1(2)), a charge of, an actual criminal offence. The language of section 1 does not refer to conduct which, if proved,
would amount to the commission of one of the offences. The words used speak of an allegation or charge of
actually committing such an offence. That would mean, in criminal proceedings, that the crime must be proved
beyond reasonable doubt; whereas, an allegation in an employment tribunal or other civil claim of conduct
amounting to a sexual offence within the 1992 Act need only be proved on the balance of probabilities.

73. In my judgment, the words “an allegation has been made” in section 1(1) refer to the making of an allegation in
circumstances which raise, or are intended to raise, a real possibility that a criminal charge will follow. Section 1(1)
relates to the pre-charge phase, while section 1(2) relates to the post-charge phase of the process. I do not think
the lifelong anonymity provided for in section 1(1) is triggered by, say, an allegation made informally by one friend to
another in a public house (e.g. “I saw him walk up behind her unawares and touch her indecently”).

74. While under section 1(1) the making of the allegation must raise, or be intended to raise, a serious prospect of
further investigation and perhaps a criminal charge, the use of the passive mood (“an allegation has been made”)
without saying by whom, indicates that it need not be made by the alleged victim herself. Indeed, in O'Riordan v.
_DPP, it appears that no allegation was made by the alleged victim but the protection of the 1992 Act was held to_


-----

apply. Thus, a complaint by a parent to police that their child has been sexually assaulted would trigger anonymity
for the child.

75. I do not think section 1(1) includes the making of an allegation in civil, family or tribunal proceedings of conduct
which, if charged and tried in a criminal court and proved beyond reasonable doubt, would lead to conviction for a
criminal offence falling within the 1992 Act. A claimant who in tribunal, family or other civil (i.e. non-criminal)
proceedings alleges such conduct need only prove it on the balance of probabilities. I think section 1(1) should be
construed _eiusdem generis with the rest of the 1992 Act, which nowhere mentions civil, family or tribunal_
proceedings.

76. In my judgment, therefore, an “allegation” in section 1(1) must not just be of conduct amounting to a crime; it
must be made in circumstances where it has the potential to be tried as a crime. I agree with the thrust of Judge
Matthews' reasoning in the _Plymouth City Council case. But I do not think it was accurate to say at [30] that_
“'allegation' in section 1(1) … refers to a formal allegation made in criminal proceedings, that is, where a criminal
charge has been made”. Where a criminal charge has been made, section 1(2), not section 1(1), applies because
the person is “accused”.

77. I think the accurate formulation is that “allegation” in section 1(1) refers to a formal allegation made in the
context of potential criminal proceedings, where a criminal charge may be brought. The paradigm case is a
complaint to police. Other complaints made seriously and intended to or likely to be acted upon might be to a
prosecuting authority, a safeguarding body, a social worker or social services department or other person with
professional responsibility for taking the complaint further through the criminal justice system.

78. It follows that I do not think an “allegation” in section 1(1) includes, without more, an allegation made in civil,
family or tribunal proceedings of conduct that, if committed, would be one of the sexual offences covered by the
1992 Act. That is sufficient to decide the point of difference between the parties in this appeal about the impact of
the 1992 Act. There is no suggestion that, on the facts here, the clamant or anyone else has ever made against Ms
Q a formal allegation, in the context of the criminal law, of a sexual offence committed against the claimant.

79. If my interpretation of section 1 of the 1992 Act is correct, it follows that EJ Brown was wrong to conclude that
the claimant was entitled to the protection of the 1992 Act; and that the subsequent tribunal, EJ Snelson presiding,
was right to decide that the claimant did not have that protection and was not entitled under the 1992 Act to lifelong
anonymity. A difficulty remains that in other cases, though not this one, the requirement in section 1(1) will be
satisfied on the facts: a serious complaint of a sexual offence will have been made, usually to police, by the time the
allegation of the same conduct is made in an employment tribunal.

80. That appears to have been the position in A v. Choice Support (formerly MCCH Ltd); though not, as far as I can
tell, in A. v. X. Indeed, in A. v. Choice Support, Judge Wayne Beard recounts at [40] that after “the incident was
reported to police”, “the Claimant withdrew her support of the police inquiry into the allegation of rape”. In such a
case, there appears to be no means of removing the 1992 Act's protection. Once the allegation has been made,
lifelong anonymity protection can only be removed in accordance with the Act's provisions; under section 1(4), if
there is, say, a subsequent trial for perjury; or under section 3, if the judge decides to relax the restriction.

81. An order under section 3 can only be made by a crown court judge or justice of the peace. Neither section 1(4)
nor section 3 has any traction in an employment tribunal (nor in other civil or family proceedings). If the tribunal
were to find, as in this case, that the claimant's evidence about the sexual offence is false, would it be powerless to
remove the 1992 Act's lifelong anonymity protection? It might be thought anomalous and at odds with the principle
of open justice and the article 10 right to freedom of expression if that were the position.

82. The cross-reference to the 1992 Act in the definition of “sexual offence” in section 11(6) of the 1996 Act, the
rule making provision which (together with section 7 of the 1996 Act) authorises the making of rule 50, suggests
that parliament had in mind the possibility that the protection of the 1992 Act could apply in cases where the same
conduct is alleged as a criminal matter and in employment tribunal proceedings. It appears that, in such a case,
any privacy order would be made under rule 50. Obviously, a tribunal in such a case would want to avoid any clash
with the criminal law disclosure of a protected person's identity being an offence under section 5 of the 1992 Act


-----

83. The lacuna appears to be that the tribunal has no power corresponding to that of a crown court judge or justice
of the peace to remove the protection of the 1992 Act, where a false complaint has been made to police and its
falsity is exposed in the tribunal proceedings. It may be that the remedy lies with parliament. In the present case,
the difficulty does not arise because no criminal allegation against Ms Q of sexually assaulting the claimant was
ever made. For present purposes, that is all I need to say about the relationship between the 1992 Act and
employment tribunal proceedings.

84. I come to the other submissions of the parties, apart from those dealing with the 1992 Act. I think the position
is straightforward: the respondents' submissions are well founded and the claimant's submissions are not. The
tribunal's analysis of the 1992 Act is not quite the same as mine, but the differences do not affect the correctness of
the tribunal's order revoking the two privacy orders. The tribunal straightforwardly exercised its power under rule 29
of the ET Rules of Procedure to revoke them based on a substantial, indeed fundamental, change of
circumstances.

85. The tribunal was plainly right to decide that there was a material change of circumstances once it had found
that the claimant's account given in his evidence was in large part false and, in particular, that his complaints of
sexual harassment and sexual assault against Ms Q were fabricated. It is difficult to think of a more striking change
of circumstances. The tribunal was therefore amply justified in revisiting the two privacy orders made by EJ Brown.

86. The tribunal then went on to address, as it was obliged to under rule 50, the balance of Convention rights.
Leaving aside the balance struck in the case of Ms Q, in respect of whom there is no appeal, the tribunal was right
to place substantial weight on the public interest in the author of a dishonest account being identified, as against the
lack of any “countervailing argument based on the Claimant's Convention rights” since “he did not have a
sustainable right to litigate anonymously” and therefore “it cannot be said that his right to respect for his private life
would be violated as a consequence of the anonymity being lost.” (paragraph 73).

87. That reasoning is, in my judgment sound, I accept the submissions of Ms McCann to that effect and I reject the
submissions of Mr Beaton that there was no material change of circumstances and that the tribunal's balancing
exercise in relation to Convention rights was flawed. The first ground of appeal therefore fails and the orders
revoking the anonymity and reporting restrictions orders in respect of the claimant will stand.

**Second ground of appeal: the holiday pay claim**

88. The second ground of appeal is that the tribunal erred in failing to consider whether the Claimant was “off sick”
and therefore unable to take his annual leave, as opposed to whether or not there was agreement that the Claimant
would take a period of sick leave.

89. In relation to the holiday pay claim, the tribunal in its reserved judgment of 14 February 2022 (corrected on 27
May 2022) stated:

**“The 1998 Regulations**

**28 The effect of reg 14 of the 1998 Regulations is to entitle a worker whose employment ends part-**
**way through a leave year to compensation where the leave entitlement accrued up to termination is greater**
**than the leave taken up to that date. Nothing turns here on the wording of the provision: the parties are**
**divided only on the relevant facts.**

**…**

**63 The Claimant was on sick leave on 5 and 6 November 2019. Asked by Ms Mehta what was**
**wrong he stated (by a text of 6 November) that he had food poisoning and back pain but his main problem**
**was “low mood” and feeling “worthless” as a result of her remark about him being “lucky” to have passed**
**his probation.**

**64 Following some consecutive days of pre-booked annual leave, the Claimant returned to work on**
**12 November**


-----

**…**

**The claim under the 1998 Regulations**

**95 The Claimant took five days' leave plus the three bank holidays which fell between 1 May and 21**
**November 2019. He gave oral evidence to the effect that the three days of annual leave on 7, 8 and 11**
**November were, by agreement, converted to sick leave. That evidence, we find, was false.**

**….**

**The claim under the 1998 Regulations**

**118 Given our factual findings above, the Claimant's claim under the 1998 Regulations inevitably**
**fails. It was agreed that his annual leave entitlement up to the date of termination was 17 days, inclusive of**
**three bank holidays. He took eight days' leave (of which three were bank holidays) and so was entitled to**
**compensation for nine day's pay. It was common ground that he received payment which, on that basis,**
**was correctly calculated.”**

90. Mr Beaton submitted that the claimant booked 7, 8 and 11 November 2019 as annual leave; then on 7
November he became sick and remained sick through the weekend of 9 and 10 November and on the Monday, 11
November. Under the bank's sick leave rules there was no requirement for a medical certificate because the
absence was less than seven days. Since the claimant had informed his manager, Ms Mehta (the fifth respondent)
of his sickness, the days at issue, 7, 8 and 11 November 2019, should have been treated as sick leave and should
not have counted as days of annual leave.

91. The tribunal was wrong, Mr Beaton submitted, to require of the claimant that he should reach an agreement
with his line manager to treat the three days in question as sick leave. The issue was not whether an agreement
was reached. The Working Time Regulations 1998, as interpreted in case law (which I need not analyse here since
it is not challenged), require only that on falling sick he should inform his line manager that he was unfit for duty and
therefore the days off should count as sick leave and not annual leave.

92. For the respondents, Ms McCann showed me pleadings, correspondence, a list of issues and written
submissions showing that the claimant's case shifted during the course of the proceedings below. At first, he had
alleged that his request to convert the three days in question from annual leave to sick leave was “refused”. He did
not contend for any agreement until, contradicting his earlier position, his witness statement was filed. This was the
evidence he gave and on which he was cross-examined, evidence which the tribunal found to be “false”.

93. In his then counsel's closing submissions, the contention became that the claimant had satisfied the
requirements in the bank's handbook on sick leave because he was in fact sick on those three days and no medical
certificate was required, the absence being for less than seven days. However, the evidence before the tribunal
was that he had texted Ms Mehta on 6 November 2019 reminding her that he was due to start annual leave the next
day.

94. Further, Ms McCann pointed out, it was not put to Ms Mehta below that the claimant was actually sick on 7, 8
and 11 November and had self-certified to her as off sick on those three days, nor that there was any “agreement”
that the three days would be treated as sick leave. The respondents' unchallenged evidence, which the tribunal
was entitled to accept, was that the claimant went on annual leave on those three days. The tribunal was equally
entitled to reject as “false” the claimant's account that he reached any agreement with Ms Mehta to treat the three
days as sick leave.

95. It follows, Ms McCann submitted, that on a fair reading of the tribunal's decision, they rejected the contention
that the claimant was actually unfit for duty on those three days; and found that he made no request to convert the
three days to sick leave and that there was no agreement to that effect. She referred me to the claimant's last text
message to Ms Mehta (which was before the tribunal) in the exchange on 6 November 2019, where the claimant,
after describing symptoms that had kept him from working that day (food poisoning, back pain and low mood),


-----

ended the message with the words “[p]lease note, my leave start tomorrow”, making no mention of it being sick
leave.

96. I can deal with this ground of appeal quite briefly. In my judgment, there is no real merit in it. I accept that the
claimant changed his case; at first saying that he had informed Ms Mehta that he was sick; then that she had
agreed to treat the three days as sick leave, a point not put to Ms Mehta in her cross-examination; and then in
closing submissions that the requirements of the bank's handbook had been met. I also bear in mind that the
tribunal, in the same decision, gave detailed reasons, in passages I have not set out here, for finding the claimant to
be a dishonest and untruthful witness.

97. The tribunal clearly found that the claimant's evidence of an agreement with Ms Mehta was false. The claimant
cannot go behind that finding. The tribunal also found, and the claimant did not deny, that the three days in
question had been pre-booked as annual holiday. It is true that the tribunal did not say in terms, as they might have
done, that the claimant was fit for duty and not sick on those three days. But it is inconceivable that they could have
found that the evidence about an agreement was false yet the evidence about being actually sick was true.

98. That is an unrealistic suggestion which would be inconsistent with the changes to the claimant's case as the
proceedings developed; the finding that the claimant was in general a dishonest witness; the text message of 6
November giving three different reasons for being off sick on that day and the previous day; and the concluding
words of his last text to Ms Mehta on 6 November, “my leave start tomorrow”, with no mention of sick leave.

99. In the light of those matters, I agree with Ms McCann that the tribunal's decision should be read as including a
rejection of the proposition that the claimant was in fact sick on 7, 8 and 11 November 2019. The second ground of
appeal therefore fails.

**Third ground of appeal: the costs order made against the claimant**

100. The third ground of appeal is that, in addressing the costs application against the claimant, the tribunal erred
when considering the issue of means or reached a decision that was perverse. The tribunal gave its reasons for
granting the costs application as part of the reserved decision of 5 July 2022, in the following way. At paragraph 12,
the tribunal noted:

**“12 The Claimant did not comply with the order of 14 April, which (among other things) required**
**him to state by a specified date whether he intended to rely on his means as a ground for resisting the**
**costs application and, if so, to make disclosure by a specified date of the documents to which he proposed**
**to refer for that purpose. Very shortly before the hearing he disclosed a small selection of documents said**
**to be relevant to his means.”**

101. The tribunal referred to rules 76 and 84 of the ET Rules of Procedure, relating to costs. The tribunal then set
out, uncontroversially, the law relating to the operation of those rules. Their reasoning and conclusion in support of
the decision on costs needs to be set out in full:

**“45 The Respondents limited their application to £20,000, the maximum sum awardable without a**
**detailed assessment. The costs which they actually incurred up to the end of the trial came to many times**
**that sum.**

**46 The burden of the costs application was that the Claimant had dishonestly and cynically**
**pursued a series of complaints based on evidence which he knew to be false and that in so doing he had**
**brought claims which had no reasonable prospect of success and/or had acted unreasonably in bringing**
**them and/or in his conduct of them.**

**47 The Claimant resisted the application. He argued that he had been entitled to bring his claims**
**and the fact that he had lost should not result in him being condemned in costs. An award of costs was an**
**exceptional measure. He also challenged a number of the findings in our judgment and reasons, although**
**we tried to explain that those matters were closed and could not be revisited. In addition, he advanced the**


-----

**argument that we should somehow be guided by a decision of the Dartford County Court refusing the**
**Respondents costs following their successful defence of a short-track claim which he had brought against**
**them in that court. Finally, he contended that, in view of his very limited means, the Tribunal should make**
**no, or no substantial, costs order, even if it would otherwise judge a substantial award to be appropriate.**

**48 In our view, the Claimant's conduct in bringing and persisting with his claims, or at least a large**
**proportion of them, was not merely unreasonable but disgraceful. To concoct, as he did, allegations of**
**sexual harassment by Q was beneath contempt. As serious (although not calculated to cause pain and**
**distress to any individual) was his act of manufacturing evidence. More generally, time and time again, he**
**rested claims on alleged facts which were at best so distorted or exaggerated as to bear no relation to real**
**events and at worst simply invented. It is, we think, hard to imagine a more obvious case of unreasonable**
**conduct in the bringing and pursuit of litigation. So much for the 2013 Rules, r76(1)(a).**

**49 We prefer to leave r76(1)(b) to one side. A cynical manipulator might make up claims so skilfully**
**that the Tribunal might struggle to say, after the event, that they had had no reasonable prospect of**
**success. The fact that they had ultimately failed would not by itself warrant that assessment. We prefer not**
**to wrestle with the question whether, on an objective analysis, the claims, which the Claimant knew to be**
**bogus, were doomed to fail.**

**50 Our reasoning under r76(1)(a) determines the first question identified … above. The Tribunal**
**has jurisdiction to make a costs order.**

**51 Should we exercise the jurisdiction and, if so, how? Subject to the question of means, we are**
**quite satisfied that the Claimant's conduct merits a costs order and that it would be unjust to the**
**Respondents to decline to make one. We might ask, if this is not a proper case for the exercise of the**
**discretion, what is?**

**52 Should we take account of means? The documentary evidence provided by the Claimant as to**
**his means was minimal. His answers to questions from Ms McCann and the Tribunal were short on detail**
**and uninformative. We are unable to place confidence in his evidence, although we are careful not to make**
**the mistake of assuming that, because of our findings at trial, he cannot be believed on anything. On**
**balance, we find that he has been out of work since his dismissal by the Respondents in November 2019**
**and is living wholly or very largely on state benefits. It seems that he has separated from his wife and is**
**living in private rented accommodation. He has two school-age children to support. We treat him as**
**currently cash-poor, albeit with a substantial earning capacity as someone with financial sector experience**
**who commanded an annual salary of some £50,000 when with the Respondents. The capital picture is**
**much less clear. He told us that he had co-owned a property with his wife and that he had transferred his**
**share to her and that she had paid him “a contribution”. We were shown no documents**

**relating to this transaction.**

**53 We have decided not to have regard to the Claimant's ability to pay. This is because he has not**
**supplied us with sufficient information backed by evidence to enable us to make a reasonable assessment**
**of his capital position. In the commentary accompanying the order made on 14 April, the judge included**
**these remarks:**

**9. The question of ability to pay is important. I draw attention to the Employment Tribunals Rules**
**of Procedure 2013, rules 74-84. Rule 84 says that, in considering whether to make a costs order and, if so,**
**how much to award, the Tribunal may have regard to the paying party's ability to pay. If the Claimant**
**wishes the Tribunal to take that factor into account he must follow my Order ...**

**10. If the Claimant's means are in issue, it is for him to decide what information he wishes to share**
**with the Respondents and put before the Tribunal. The Tribunal cannot advise, but it is a statement of the**
**obvious that sparse or selective disclosure will carry less weight than comprehensive disclosure.**


-----

**It is a matter of regret that he did not heed the guidance offered.**

**54 If he finds himself in due course facing enforcement proceedings in relation to our costs**
**judgment, the Claimant will have a fresh opportunity to argue (at that stage in the county court) that his**
**means should be taken into account. There again, sparse and selective disclosure will not serve his**
**interests.**

**55 Ability to pay not being a 'live' consideration, what sum should be awarded? In our judgment,**
**the answer is plain. If the Claimant's means do not bear on the decision, the proper award is the sum**
**sought, £20,000, which represents a small fraction of the costs to which, entirely without justification, the**
**Respondents have been put.”**

102. Mr Beaton, for the claimant, submitted that the tribunal went wrong because it made findings of fact relevant
to the claimant's means, yet professed that it would not have regard to his ability to pay. The findings made — that
the claimant was living on benefits, was out of work and “cash-poor” — pointed inexorably against him being able to
meet a costs order for anything like £20,000. The documents the claimant produced included bank statements
showing payment of universal credit to him. The respondents did not dispute below that he was receiving universal
credit payments.

103. The tribunal should have taken judicial notice, Mr Beaton argued, of the universal credit capital threshold of
£16,000. He asserted that to qualify for universal credit you have to have less than £16,000 capital. The tribunal
should therefore have concluded that the claimant necessarily had less than £16,000 available and self-evidently
could not meet a costs of award of £20,000.

104. As for the finding that the claimant had potential good earning capacity, Mr Beaton submitted that the tribunal
had overlooked the point that its own damning findings against him combined with revocation of the anonymity
order and reporting restrictions order would obviously curtail the claimant's earning capacity. For those reasons, he
submitted, the decision on costs was perverse.

105. For the respondents, Ms McCann submitted that the tribunal had decided against taking account of the
claimant's means and ability to pay because it could not place any confidence in his evidence. Rule 84 confers a
discretion on the tribunal to take account of the paying party's ability to pay, using the word “may”. The tribunal was
not obliged to do so. Ms McCann referred me to the decision of His Honour Judge Richardson in _Jilley v._
_[Birmingham and Solihull Mental Health NHS Trust,UKEAT/0584/06/DA, 21 November 2007, at [44], referring to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N6J-T0W1-F0JY-C1M1-00000-00&context=1519360)_
old rule 41(2):

**“Rule 41(2) gives to the Tribunal a discretion whether to take into account the paying party's ability**
**to pay. If a Tribunal decides not to do so, it should say why. If it decides to take into account ability to pay,**
**it should set out its findings about ability to pay, say what impact this has had on its decision whether to**
**award costs or on the amount of costs, and explain why. Lengthy reasons are not required. A succinct**
**statement of how the Tribunal has dealt with the matter and why it has done so is generally essential.”**

106. Here, Ms McCann submitted, the tribunal in its reasoning had done exactly what Judge Richardson said
should be done. The reasoning was quite full, was there to be seen and unimpeachable. There is no flaw in the
reasoning, nor the conclusion that the claimant should be ordered to pay the full £20,000 claimed and left to ask for
time in any county court enforcement proceedings, where his means would be taken into account.

107. The assertion that the claimant must have less than £16,000 as he was in receipt of universal credit was not
made to the tribunal, which cannot be criticised for not taking it into account. Furthermore, the claimant accepted
below that he had previously had some equity in a co-owned property and had received a “contribution” when his
share was transferred to his wife after they separated. The tribunal was also, Ms McCann said, entitled not to take
into account the claimant's earning capacity in the regulated sector. The high perversity threshold was not close to
being met.


-----

108. I find the tribunal's decision sound and find no basis for interfering with it. The discretionary wording of rule 84
is rather strange because it is very difficult to ignore evidence of ability to pay if it is put before a tribunal, however
flawed and inadequate it may be. This tribunal, while saying it did not take account of ability to pay, in a sense did
so because, rightly, it had regard to the evidence relevant to that issue. What it did not do is accept the adequacy
of that evidence or decide that the claimant should be protected by his impecuniosity against liability for the full
amount claimed.

109. The tribunal's reasoning undoubtedly measured up to the standard set by Judge Richardson in the Jilley case.
There is no lack of clarity in the tribunal's reasoning. The claimant could have been much more forthcoming about
his financial position and would have received proper consideration of evidence about it, but opted for late and
selective disclosure, not heeding the warning given in the tribunal's earlier narrative on 14 April 2022.

110. The argument concerning the £16,000 capital threshold was not made below and was not a matter for taking
judicial notice. It was first raised by then counsel, Mr Oliver Isaacs, at the rule 3(10) hearing on 31 March 2023.
The source of the rule was not provided to me. It is unclear what counts as “capital”. Nor does receipt of universal
credit prove entitlement to receive it. It may or may not be properly payable; it could be paid to a person not entitled
to receive it, who has capital above the threshold which the benefit paying body does not know about.

111. I find nothing wrong with the tribunal's decision on costs, which I uphold. The third and final permitted ground
of appeal therefore fails.

**Conclusion: disposal of the appeal**

112. For those reasons, the appeal fails on all grounds and will be dismissed. The judgment and order of this
appeal tribunal will initially be issued without including the claimant's name, but is likely to be reissued with the
name of the claimant included in the event that there is no application for permission to appeal to the Court of
Appeal within the statutory time limit, or in the event that any application for permission to appeal, or any appeal, is
unsuccessful.

**Postscript: the respondents' application for costs incurred in the appeal**

113. The respondents applied on 15 January 2024 for an order that the claimant pay part of their costs incurred in
the appeal. They claimed £17,055.50 plus VAT of £3,411.10, i.e. £20,466.60. The application was sent to the
claimant and Mr Beaton that day. It is said that the claimant's conduct of the appeal was unreasonable on four
counts: regarding preparation of the appeal bundle; concerning an application to extend time for exchange of
skeleton arguments; in responding to the respondents' amendment of its respondents' answer; and in applying to
rely on a new witness statement.

114. I saw no unfairness in hearing the costs application at the hearing on 23 January 2024. The claimant has
prior experience of costs being sought against him and has previously been told about the benefits of early and full
disclosure of documents relied on relating to his means. He produced no such documents. He attended the
hearing remotely with my permission and was ably represented by Mr Beaton who appeared in person at the
appeal tribunal and helpfully put the arguments on the claimant's behalf against any costs order being made against
him.

115. By rule 34A(1) of the Employment Appeal Tribunal Rules 1993, so far as relevant here, I have the power to
make a costs order where “it appears .... that there has been … unreasonable conduct in the … conducting of
proceedings by the paying party …. .” By rule 34B(2) the appeal tribunal “may have regard to the paying party's
ability to pay when considering the amount of a costs order.”

116. The respondents' first claim is that about 30 hours of solicitor time, mostly charged at £440 per hour plus VAT,
but with just over three hours charged at £595 plus VAT per hour, had to be spent on the appeal bundle because of
the claimant's unreasonableness in dealing with this issue. Over 13 hours of solicitor time is claimed for the drafting
of a single letter (21 pages long), plus 80 per cent of a further 17.5 hours spent on “[g]eneral work on bundles, (e.g.


-----

review of correspondence from the claimant, responding to the same, review of the claimant's draft bundle
indexes)”.

117. The respondents' written submissions include the point that they asked the claimant to agree to the
respondents taking “carriage of creating the appeal hearing bundles”. The claimant then, it is said, unreasonably
generated lengthy and expensive correspondence by asking for irrelevant documents to be included in the bundles,
not cooperating and failing to play his part in producing proper indexes and draft bundles. The respondents'
solicitors were drawn into expensive exchanges about these matters; hence the large amount claimed and the
many hours spent on them by solicitors.

118. The claimant, unrepresented, had a poor track record of cooperating, as the respondents knew. The
directions in the appeal, as normal, placed responsibility for producing properly indexed bundles on both parties but,
with hindsight, it would have been better if the respondents had sought, and the appeal tribunal had directed, that
the respondents alone should produce the main appeal bundle, leaving the claimant free, if he wished, to seek
permission to rely on or add further documents at the hearing. I would have so directed, if necessary of my own
motion, had I been managing the appeal.

119. I accept that there was some unreasonableness in the claimant's conduct of the exchanges about bundles.
They created an extra burden for the respondents' solicitors and for appeal tribunal staff. I do not, however, accept,
that it would be fair to visit anything like the whole amount claimed on the claimant, an unrepresented litigant whose
objectively unreasonable conduct stemmed in part from ignorance of proper conduct and procedures. The
respondents, recognising this, could have made a positive application to the appeal tribunal for a direction along the
lines I have indicated.

120. Taking a broad brush view and making an estimate based on reading the correspondence, the reasoning
above, my impressionistic division of responsibility leads me to award £2,000 (excluding VAT) of costs to the
respondent under this first heading.

121. Next, the respondents claim £574.50 for costs incurred as a result, they say, of unreasonable pursuit of an
application for an extension of time to file the claimant's skeleton argument supporting the appeal. The claimant
had some assistance from Mr Beaton at that stage and he was able to exchange skeletons by the then deadline of
4pm on 9 January 2024. In fairness to him, it was not his role to advise on directions or conduct correspondence.
It is true that once skeletons had been exchanged the claimant's application became unnecessary, but it did not
become unnecessary until the deadline day itself, by which time it was already being addressed by the appeal
tribunal.

122. The confused procedural history is set out in the reasons for an order made on 9 January 2024 by Mr Bruce
Carr KC sitting as a judge of the appeal tribunal. The complaint is that the claimant “doggedly pursued” his
application to extend time for filing of skeletons when it was unnecessary to do so because his counsel was ready
to exchange on 9 January 2024. In the event, Mr Carr KC allowed an application to appeal from a direction of the
Registrar and extended time for filing and exchange of skeletons until 12 January 2024.

123. It is said nonetheless that it was unreasonable of the claimant to pursue his application. The gist of the
complaint appears to be that he already had what he wanted. I do not find that the claimant's counsel of prudence
in continuing with the application in case it were needed (which for all he knew it could be) reaches the threshold of
unreasonableness. He did, after all, win his appeal to Mr Carr KC, whose order was not made until the very day the
original deadline was to expire.

124. Third, the respondents claim £1,783 plus VAT, representing between three and four hours of solicitor time,
complaining that the claimant unreasonably pursued an application relating to the amendment of the respondents'
answer to the grounds of appeal. These, it will be recalled, had been amended in the form of the three permitted
grounds on which I have adjudicated, above.

125. The respondents' solicitors had explained in correspondence in December 2023 that the appeal bundle
should not contain obsolete material about grounds of appeal not permitted to go forward. Ever mistrustful of his


-----

adversaries, the claimant began to question whether the respondents, who had indeed amended their respondents'
answer, had been given permission to do so. The order of Mr Gullick KC made on 24 April 2023 (sealed on 2 May
2023) following the rule 3(10) hearing did not include liberty to the respondents to amend their respondents'
answer.

126. A chronology produced by the respondents indicates that they applied on 4 May 2023 for an extension of four
weeks to file an amended respondents' answer dealing with what had become the second and third grounds of
appeal, i.e. concerning holiday pay and costs. The chronology indicates that the on 12 May 2023, the Registrar
varied Mr Gullick's order and permitted an amendment to the respondents' answer, which was then filed in
amended form on 21 June 2023.

127. That was all standard and would not normally be controversial, but in correspondence in December 2023, the
respondents complain, the claimant got it into his head that the respondents had somehow impermissibly amended
the respondents' answer. The respondents cite from tedious and unproductive email correspondence on the
subject, which is said to be unreasonable on the claimant's side, causing the respondents unnecessarily to incur the
claimed £1,783 plus VAT until the issue was put to bed by an order of His Honour Judge Tayler on 8 January 2024.

128. Mr Beaton pointed out that the claimant's ignorance of normal procedure made it understandable that he
would regard the respondents as attempting to have two bites of the cherry in relation to their respondents' answer.
However, I agree with the respondents that the claimant's stance in the correspondence was unreasonable; even
without much legal help at the time and not being an expert in the procedures of the appeal tribunal, it should have
been obvious to him that the respondents' answer needed to be brought up to date to respond to the permitted
grounds of appeal.

129. Fourth and finally, the respondents claim £1,579 plus VAT as costs expended – 3.7 hours of solicitor time – in
dealing with the claimant's misconceived application to rely on a new witness statement of Mr Taiwo, which Mr
Beaton could not support on the basis of the existing permitted grounds of appeal and which I rejected at the start
of this judgment. Mr Beaton submitted that the error in misunderstanding the irrelevance of Mr Taiwo's evidence to
the existing grounds was pardonable given the claimant's lack of legal experience and training.

130. However, the claimant had acquired some experience of procedures in the tribunal below. He could have,
and I am confident would have, desisted from his application to adduce irrelevant evidence if he had taken counsel
from Mr Beaton on the point. I do not seek to pry into privileged conversations, but I am entitled to infer, and do
infer, that either he did not ask Mr Beaton's view or, if he did, he did not heed it. I think the threshold of
unreasonableness is crossed in that instance and I would in principle award the £1,579 (exclusive of VAT) claimed
under this final head.

131. For those reasons, I would in principle award the combined sum of £5,362 (excluding VAT) under the first,
third and fourth heads of complaint. I did not hear argument on the point, but cannot see why I should add any VAT
to that amount. I see no reason why the amount of VAT payable by the bank to its solicitors cannot be reclaimed as
input tax when the bank makes its next VAT return after paying its solicitors' fees for the appeal.

132. That leaves the question of the claimant's means and ability to pay. I do take that issue into account, under
rule 34B(2), recognising that the evidence I have is not comprehensive or complete. It is unfortunate that the
claimant did not produce any relevant documents. On instructions, Mr Beaton said he remains out of work and on
benefits. Ms McCann suggested, not without reason, that his word should not be trusted; and she suggested that
he could be hiding assets. I think it is unlikely he is hiding assets; he tends to dissipate any he has in fruitless
litigation, unfortunately.

133. I think the most likely position is that he remains out of work and living on universal credit and, if he has any
capital, it is probably not substantial. It is also a matter of record that he owes the bank £40,000 under a costs
order recently made by Lavender J in ongoing contempt proceedings, which the claimant has until 25 May 2024 to
pay. He has not satisfied any part of the £20,000 costs order made by the tribunal below, which I have upheld. He
therefore owes the bank £60,000 and has not paid any of it. I am told that no enforcement proceedings have been
brought


-----

134. That £60,000 liability is direct and clear evidence against the claimant's ability to pay, over and above the
circumstantial evidence that he remains out of work and on universal credit, without substantial capital. There is a
prospect that he may become liable for further costs if the substantive contempt proceedings are successful. I am
therefore not eager to add to his existing costs liabilities. On the other hand, it is in principle just that the claimant
bear responsibility for the costs incurred through his unreasonable conduct. Taking account of ability to pay does
not preclude the making of an order the paying party is not currently able to satisfy.

135. After reflection, I am persuaded that the claimant should be required to contribute £5,362 towards the
respondent's costs of the appeal. I do not appear to have any express power to grant time to pay. If I had the
power, I would direct that payment must be made by 25 November 2024, six months after the £40,000 awarded by
Lavender J falls due. I will direct that in any enforcement proceedings the county court should be told that I
envisage time to pay being extended in that way.

136. I conclude this judgment by recording my sincere thanks to both counsel for their clear, concise and eloquent
submissions; and especially to Mr Beaton for making my task easier by acting pro bono for the claimant and once
again proving the importance of and our dependence as judges on the excellent services of the organisation
Advocate, through which Mr Beaton was instructed.

**End of Document**


-----

