# Chief Constable of Kent Police and another company v Taylor [2023] EWHC
 2687 (KB)

King's Bench Division

Mrs Justice Steyn DBE

27 October 2023Judgment

**Kate Wilson (instructed by Clyde & Co LLP) for the Claimants**

The Defendant did not appear and was not represented

Hearing date: 25 October 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.00am on 27 October 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

THE HON. MRS JUSTICE STEYN DBE

**MRS JUSTICE STEYN :**

**Introduction**

1. The Claimants, the Chief Constable of Kent Police ('the Chief Constable') and Berrymans Lace Mawer
LLP ('BLM'), apply for the committal of the Defendant, Mr Daryll Sturgess Taylor, for contempt. The
Claimants allege that the Defendant has breached one prohibitory order (namely, paragraph (1)(a) of an
order made by Saini J dated 28 March 2022 ('the First Order')), and two mandatory orders (namely,
paragraph (2) and (3) of the First Order, as amended by paragraphs (1) and (2), respectively, of an Order
made by Saini J dated 2 February 2023 ('the Second Order')).

**Proceeding in the absence of the Defendant**

2. The Defendant did not attend the hearing of the Claimants' contempt application and he was not
represented. He did not communicate with the Court or the Claimants to give any explanation for his
absence or to seek an adjournment. The Claimants contended that, exceptionally, I should proceed to
determine the contempt application in his absence rather than issue a bench warrant to secure his
attendance.

3. I gave an ex tempore judgment on 25 October 2023 addressing this issue. It is unnecessary to reiterate
what I said in that judgment. In short, while recognising that in this context the power to proceed in the
Defendant's absence should be exercised “with great caution”, and with close regard to the fairness of the
proceedings, I was satisfied that I should proceed to determine the application, having regard (among other
matters) to my findings that the Defendant was undoubtedly aware of the hearing (having been given
notice of it repeatedly including in person) the history demonstrated that he had clearly and deliberately


-----

chosen to waive his right to attend, and bearing in mind the important public interest in contempt
proceedings concerning alleged failure to comply with orders being dealt with swiftly and decisively, a
principle which applies with even greater force where what is alleged is a continuing breach or failure to
[comply: Oliver v Shaikh [2020] EWHC 2253 (QB), Nicklin J, [28].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60P1-PSN3-GXFD-82S4-00000-00&context=1519360)

**The law of confidence proceedings**

4. The orders that the Claimants allege the Defendant has breached were made in the context of a Part 8
claim issued by the Claimants on 31 January 2022. The claim against him was made in the law of
confidence.

5. The background to the law of confidence claim was that Mr Taylor was suing the Chief Constable for
damage alleged to have been done to his front door by police officers on 15 January 2020 when they
entered his property, and seized various items, in execution of a search warrant. Mr Taylor was arrested
and subsequently charged with possession of indecent images of children. He pleaded guilty and on 29
June 2020 he was sentenced to 9 months' imprisonment. See _Chief Constable of Kent Police v Taylor_

_[[2022] EWHC 737 (QB), Saini J, [3] and [21]-[22].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:653Y-23F3-CGX8-02FB-00000-00&context=1519360)_

6. On 12 April 2021, the Chief Constable applied to strike out and/or for summary judgment on Mr Taylor's
claim. On 11 January 2022, the Chief Constable succeeded in obtaining summary judgment. See _Chief_
_Constable of Kent v Taylor, Saini J, [23]._

7. BLM acted for the Chief Constable in Mr Taylor's claim for damages. In preparation for the hearing of
the Chief Constable's application, on 22 December 2021 employees of BLM sent Mr Taylor an automated
invitation to use Collaborate, which is a secure, encrypted, cloud-based file sharing tool for sharing
documents. This was to enable him to view the video evidence that the Chief Constable intended to rely on
[at the hearing on 11 January 2022. See Chief Constable of Kent v Taylor [2022] EWHC 737 (QB), Saini J,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:653Y-23F3-CGX8-02FB-00000-00&context=1519360)

[24].

8. Contemporaneously, BLM were acting for the Chief Constable in another claim brought by a minor
('KDI') who alleges breaches of his rights pursuant to articles 3, 4 and 8 of the European Convention on
Human Rights. KDI is a vulnerable young person who has been found by the Single Competent Authority
to be a victim of modern slavery. In KDI's claim, an anonymity order was made by the County Court on 21
December 2020 (and sealed on 8 January 2021) to protect his identity. See _Chief Constable of Kent v_
_Taylor, Saini J, [8], [13]-[15]._

9. On 6 January 2022, an employee of BLM uploaded to Collaborate three videos of KDI being arrested
and searched and two videos of KDI's police interviews ('the Videos'). This was so that counsel instructed
in KDI's claim could access them. Unfortunately, “for technical reasons which are not clear”, Mr Taylor was
inadvertently granted access to the Videos: Chief Constable of Kent v Taylor, Saini J, [26], [35].

10. The evidence before Saini J was that BLM's data log showed that between 8:04am and 8:16am on 7
January 2022 Mr Taylor downloaded three video files of KDI's arrests and one data file that relates to
DVDs containing KDI's police interviews. BLM's Information Security Officer considered it unlikely that Mr
Taylor had been able to view the two videos of KDI being interviewed, but he would have been able to view
the three videos of KDI being arrested: Chief Constable v Taylor, Saini J, [32], [34].

11. Mr Taylor promptly alerted BLM to the error. In an email sent at 8.13am on 7 January 2022 to an
employee of BLM via Collaborate, he stated:

“I Daryll Taylor stil [sic] have access to your uploads despite them having no relation to me.

This is a serious privacy violation.

Contact your IT to fix this.

Technical illitracy [sic] is no excuse, do not let this happen again.”

Two minutes later, he sent a further email to BLM's “Collaborate Help” email account to similar effect: Chief
_Constable v Taylor, Saini J, [28], [29]._


-----

12. However, he then refused to cooperate with BLM's requests to delete the copies he had downloaded,
instead sending “what can fairly be described as somewhat bizarre responses including demands for
_monetary payment of several thousand pounds, for his cooperation”: Chief Constable v Taylor, Saini J, [4],_

[28]-[29], [36]-[37], [42]-[47]. Consequently, the Chief Constable and BLM issued the law of confidence
claim on 31 January 2022.

13. Mr Taylor did not file an Acknowledgment of Service or any evidence in response to the claim. But he
appeared, and made submissions on his own behalf, at the (remote) hearing of the law of confidence claim
on 25 March 2022: Chief Constable v Taylor, Saini J, [32], [34]. Saini J found for the Claimants, giving his
[reasons in a judgment handed down on 30 March 2022: Chief Constable of Kent v Taylor [2022] EWHC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:653Y-23F3-CGX8-02FB-00000-00&context=1519360)
_[737 (QB).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:653Y-23F3-CGX8-02FB-00000-00&context=1519360)_

**The First Order**

14.  Saini J made the First Order on 28 March 2022. It contains a penal notice in the following terms:

“PENAL NOTICE

**If you Daryll Sturgess Taylor do not comply with this Order you may be held to be in contempt of**
**court and imprisoned or fined, or your assets may be seized. Any other person who knows of this**
**Order and does anything which helps or permits the said Defendant to breach the terms of this**
**Order may also be held to be in contempt of court and may be imprisoned, fined or have their**
**assets seized.”**

15. The First Order provides so far as relevant:

“IT IS ORDERED THAT:

**Injunction**

(1) The Defendant is restrained from:

(a) Retaining, accessing, disclosing or otherwise howsoever using the files he downloaded from the
Collaborate system on or about 7 January 2022 ('the Police Videos') or any of them; or from

(b) Disclosing any of the information contained within the Police Videos to any other person.

**Provision of information**

(2) The Defendant shall, by 4pm on Monday 11 April 2022, prepare, swear and serve on the Claimants, an
affidavit containing the following information:

a. Full particulars of the downloading and making of copies of the Police Videos;

b. Full particulars of all devices and locations (including cloud storage) where the Defendant has stored
and/or caused to be stored copies in any format of the Police Videos or any information derived from them,
setting out what is stored in each such location, and when it was stored there; and

c. Full particulars of any disclosures by the Defendant of the Police Videos or any information derived from
or relating to them, including but not limited to: the names and full contact details of all persons and entities
to whom such disclosure have been made, the date of disclosure, what was disclosed, and the
circumstances of the disclosure.

**Deletion**

(3) The Defendant shall, on Thursday 14 April 2022 at 12 noon, attend BLM's offices at 30 Fenchurch
Street, London, EC3M 3BL (or at any alternative date, time or location that is mutually agreed in writing),
bringing with him all media or devices on which the Police Videos or any information form them has at any
time been stored, and shall there permit an independent IT expert nominated by the Claimants (supervised
by a solicitor of the Second Claimant) to permanently delete all electronic copies of the Police Videos on
the Defendant's media or devices and/or otherwise in the control of or accessible to the Defendant (or to
verify the Defendant's deletion of the same). The Claimants shall pay the costs of this deletion exercise,


-----

including the costs of the independent IT expert. The independent IT expert shall not disclose to any
person any matter discovered on the said media or devices and shall be strictly limited to deletion of the
Police Videos and ensuring that the deletion has been carried out. The IT expert shall provide an
undertaking to the High Court agreeing to limit the IT expert's task as aforesaid.”

16. A copy of the First Order was served on the Defendant by the Court on 28 February 2022, and BML
sent him a copy of the Order under cover of a letter dated 31 March 2022. However, personal service of
the First Order was only effected on 13 May 2022 (i.e. after the time for compliance with paragraphs (2)
and (3) had expired): statement of Neil Buchanan (Process Server) dated 14 May 2022.

17. In his judgment, Saini J observed that:

“4. … Mr Taylor made plain at the hearing before me that he had no intention of complying with any orders
I made.

…

58. …. His attitude at the hearing (in effect that he would not comply with any orders I made) underlined to
me the importance of more than merely prohibitory orders.

…

60. The Claimants seek a further order for an independent IT expert to undertake the permanent deletion
exercise. This was strongly resisted by Mr Taylor on the basis that it was a violation of his privacy and also
on the basis that it was a 'waste of time' because it is very easy to hide things on a computer and the
expert would not be able to identify this. He said on more than one occasion that such an order would be
'pointless' and in any event he would not comply with it. That was his main submission in opposition and he
made it politely and firmly on a number of occasions.

…

68. The Order I will make will be endorsed with a Penal Notice. As I have said, Mr Taylor has repeatedly
asserted in his submissions to me that he has not intention of complying with any orders I may make. I
have informed Mr Taylor of the potential consequences of a failure to comply and that he should seek
independent legal advice. …”

**Correspondence following the First Order**

18. On 31 March 2022 BLM sent Mr Taylor a copy of the First Order. Their letter drew attention to the
penal notice and the fact that breach of the order may constitute a contempt of court. They summarised
what Mr Taylor was required to do in accordance with paragraphs (2) and (3) of the First Order.

19. Mr Taylor's short response in an email dated 31 March 2022, sent at 17:58, was:

“Fuck off and die.”

20.  On 12 April 2022 BLM sent Mr Taylor a further copy of the First Order, noting that it required him to
serve a sworn affidavit on them by 11 April 2022. The letter stated:

“We have not received your affidavit and you are therefore in breach of the [First] Order.

We remind you that there are very significant consequences for failing to comply with the [First] Order as it
provides that:

'If you Daryll Sturgess Taylor do not comply with this Order you may be held in contempt of court and
imprisoned or fined, or your assets may be seized.'

We ask that you serve your sworn affidavit (containing all the information required under paragraph 2 of the
Order) on us by return, failing which we reserve our right to take steps to have you held in contempt of
court.”

In the same letter, BLM also reminded Mr Taylor of the order requiring him to attend their office at midday
on 14 April 2022 with all his media or devices on which the Police Videos have been stored


-----

21. Mr Taylor sent an email response the same day, 12 April 2022, at 16:19:

“Fuck you, fuck your company, fuck the courts and fuck London

I hope you all die

Souless [sic] drones

Yours sincerely

Daryll Taylor”

22. On 14 April 2022, BLM provided Mr Taylor with a copy of the undertaking from the independent IT
expert that they had filed with the Court in accordance with the First Order. Mr Taylor's one word email
response, sent on 14 April at 20:38, was: “Die”.

23. On 3 January 2023, the Claimants applied to vary the dates for the Defendant to comply with
paragraphs (2) and (3) of the First Order. The Claimants' solicitors served the application notice and
supporting documents on Mr Taylor under cover of a letter dated 4 January 2023. Mr Taylor responded by
email on 4 January 2023 at 13:13:

“Do not contact me again, and die in the most painful way possible you filthy parasite.”

**The Second Order**

24. On 2 February 2023, having considered the Claimants' application without a hearing, Saini J made the
Second Order. The Second Order contained a penal notice in the same terms as the First Order (see
paragraph ý14 above).

25. The recitals recorded, among other matters, that the Defendant had failed to comply with paragraphs
(2) or (3) of the First Order and that the Court was satisfied that he had been served with the Application
Notice (by which the Claimants sought to vary the First Order).

26. The Second Order provides:

“The [First] Order is varied as follows:

1. The date in paragraph (2) of the [First] Order is varied to 3 April 2023.

2. The date, time and location specified in paragraph (3) of the [First] Order are varied to 6 April 2023 at 12
noon, at Clyde & Co, St Botolph Building, 138 Houndsditch, London, EC3A 7AR (or at any alternative date
or time that is mutually agreed by all the parties in writing).

3. No order for costs.

4. This Order having been made without a hearing, the Defendant may apply to vary or discharge the
Order but any application must be made by Application Notice to be issued, filed and served by 4.30pm on
24 February 2023.”

27. In his observations on the Second Order, Saini J noted:

“I agree that the Defendant should be given a further opportunity to comply with the [First] Order and I have
provided more generous periods for compliance than those sought in the draft order. The Defendant's
abusive responses to the Claimants' correspondence are regrettable. If the Defendant obtains permission
to appeal then a stay of the Order may be justified but the present court or the Court of Appeal can address
that matter. At present, the Defendant must comply and I encourage him, again, to seek independent legal
advice. The Defendant risks penalties for contempt of court if he continues to ignore the court's orders.”

28. The reference to an appeal addressed the fact that the Defendant had made an application on 1 April
2022 for permission to appeal to the Court of Appeal against the First Order which had not been
determined when the Second Order was made. In his grounds of appeal Mr Taylor stated that BLM were
“the ones clearly in the wrong”. He said:


-----

“In the end I alone in my honesty to seek the end of their leaking of sensitive information receive
punishment.

I refused to tell [BLM] anything they asked as they could use I [sic] to avoid punishment and quickly move
on. Also I had no need to tell them anything as I would any person or organization as we don't have
compelled speech as a principle of freedom.

In the case of a police officer investigating I would have chosen to reveal my side to them for clarity in their
investigation. However this never happened as there is no justice.”

29. In relation to the terms of the First Order, Mr Taylor stated in his grounds of appeal that he had “no
_particular issue” with the injunction in paragraph 1, but objected to the “needless aggression” and_
suggested the order should also be imposed on the Claimants. He objected to paragraphs 2 and 3 of the
First Order as being, respectively, compelled speech and violation of his privacy.

30. The Defendant's application for permission to appeal did not seek a stay of execution of the First
Order. By an order dated 16 February 2023 Lewison LJ refused the Defendant permission to appeal.

31. The Second Order was personally served on Mr Taylor, together with a letter from the Claimants'
solicitor dated 6 February 2023, by Mr Buchanan, on 8 February 2023. Mr Buchanan's statement of 13
February 2023 states that he personally served Mr Taylor at his home address. He recognised Mr Taylor
(having served documents on him before, including, I note, on 1 February 2022 when the Defendant had
identified himself by admission). Mr Taylor declined to accept service and so Mr Buchanan effected
personal service by placing the documents at his feet.

**Correspondence following the Second Order**

32. The letter from the Claimants' solicitors dated 6 February 2023 informed him that the Second Order
“provides you with a further opportunity to comply with the Order Mr Justice Saini made against you last
_year”. The letter drew attention to the penal notice, stating that if he did not comply with the order, “we_
_intend to apply to the court for an order for your committal for breaching the Order”. The letter reiterated_
what Mr Taylor was required to do, and by when, in accordance with paragraphs 2 and 3 of the First Order
as varied by paragraphs 1 and 2 of the Second Order.

33. On 28 March 2023, the Claimants' solicitor sent Mr Taylor an email reminding him that he was required
to serve a signed affidavit on 3 April 2023. The Claimants' solicitor sent Mr Taylor a further copy of the
Second Order.

34. On 4 April 2023, the Claimants' solicitor wrote to Mr Taylor that they had not received the affidavit that
he was required to serve the day before, and asked for it to be sent by return. The Claimants' solicitor also
reminded Mr Taylor of the requirement to attend their office on 6 April 2023 at noon, and highlighted Saini
J's observation on the Second Order (attaching a further copy).

35. On 5 April 2023, the Claimants' solicitor provided Mr Taylor with a fresh undertaking from the
independent IT expert (in view of the fact that the expert was now instructed by Clyde & Co rather than
BLM). The email gave Mr Taylor directions as to where to go and who to ask for when attending their office
the following day.

36. Mr Taylor did not respond to any of this correspondence. He did not serve any affidavit or attend the
Claimants' solicitors' office.

**The History of the Contempt Proceedings**

37. On 26 June 2023, the Claimants made a contempt application, supported by an affidavit of Nicholas
Gibbons, a solicitor and Legal Director of Clyde & Co LPP, with whom BLM merged on 1 July 2022. Mr
Gibbons affirmed his affidavit before a Commissioner for Oaths on 3 July 2023.

38. The contempt application was made under CPR part 23, using form N600. The form contained the
following warning to the Defendant:


-----

“If upon determination of this application you are held to be in contempt of court you may be imprisoned or
fined, or your assets may be seized”.

39. In addition, it set out his rights in accordance with CPR 81.4 (2)(i) to (s), including:

“You have the right to be legally represented in the contempt proceedings

You are entitled to a reasonable opportunity to obtain legal representation and to apply for legal aid which
may be available without any means test.

…

If you do not attend the hearing, the court may proceed in your absence. Whether or not you attend, the
court will only find you in contempt if satisfied beyond reasonable doubt of the facts constituting contempt
and that they do constitute contempt.

…”

40. On 30 June 2023, Nicklin J made an order for a directions hearing on 25 July 2023 ('the 30 June
Order'). That order included on the front page in red font the following words:

“NOTICE TO THE DEFENDANT

**The Applicants have made a Contempt Application (a further copy of which is served with this**
**Order) alleging that you are in contempt of court. You should read it carefully, and note particularly**
**the section on page 3 headed: “YOUR RIGHTS”. This is a serious matter.**

**A DIRECTIONS hearing will take place on TUESDAY 25 JULY 2023, at 10.30am at the Royal Courts**
**of Justice, Strand, LONDON WC2A 2LL.**

**YOU MUST ATTEND THIS HEARING. If you fail to do so, a warrant for your arrest may be issued by**
**the Court pursuant to CPR 81.7(2). You are advised to seek legal advice. Legal aid is available for**
**advice and representation in respect of the Contempt Application.**

**DO NOT IGNORE THESE PROCEEDINGS.            ”**

41. The 30 June Order listed the Directions Hearing at 10.30am on 25 July 2023 (para 1), stated “The
_Defendant MUST attend the Directions Hearing” (para 2), and gave directions for the Claimants to file a_
sworn affidavit of Mr Gibbons (para 3(a)), personally serve the contempt application, sworn affidavit and a
copy of the 30 June Order on the Defendant para (3(b)), and to file a certificate of service confirming
compliance with paragraph 3(b) (para 4). Paragraph 5 made provision for any party to apply to vary or
discharge the 30 June Order by application notice to be issued, filed and served by 4.30pm on 7 July 2023.

42. In the reasons given in the 30 June Order, Nicklin J stated at (B):

“As noted above, the Defendant is advised to seek and obtain legal advice and representation and to do so
as soon as possible. Legal Aid is available. The Defendant MUST attend the hearing on 25 July 2023. If
the Defendant foresees any difficulties in attending on this date, then he must contact the Court explaining
what those difficulties are. If the Defendant fails, without reasonable excuse, to attend the hearing a
warrant for his arrest may be issued.”

43. The Claimants complied with the 30 June Order. A Certificate of Service dated 6 July 2023, enclosing
a signed statement of Neil Buchanan (Process Server), confirms that the contempt application (including
the Claimants' response to questions 7 and 8), the (affirmed) affidavit of Mr Gibbons (and exhibit thereto)
and the sealed 30 June Order were personally served on the Defendant at his home address on 5 July
2023 at 7.30am. Mr Buchanan states that the Defendant opened the door to him and he immediately
recognised the Defendant as Mr Daryll Taylor (see paragraph ý31 above). The Defendant refused to take
the documents and pushed the door closed. Mr Buchanan then posted the documents through the
letterbox while the Defendant could be seen through the frosted glass to be stood on the other side of the
door, and Mr Buchanan informed him through the door that he had been personally served.


-----

44. I note that although the 30 June Order directed the Claimants to serve a “further” copy of the contempt
application, that order was in fact made before the contempt application had been served. However, I am
satisfied beyond reasonable doubt that the Defendant was duly personally served with the contempt
application and supporting affidavit, as well as the 30 June Order on 5 July 2023.

45. The Defendant did not attend the hearing on 25 July. He had contacted the Court by email on 24 July
2023 and stated that he was unable to attend the directions hearing. Following an exchange of emails
between the Court and the Defendant, and the Defendant's failure to provide information required by the
Court, the Court directed the Defendant to attend the hearing in person. On 25 July, on the Court being
satisfied that the Defendant had failed or refused to attend the directions hearing, as he had been ordered
to do, Nicklin J issued a warrant for the arrest of the Defendant to secure his attendance at the adjourned
directions hearing.

46. The Defendant was duly arrested and brought to court for the adjourned directions hearing, which took
place on 27 July 2023. At the hearing on 27 July, Nicklin J made an order releasing the Defendant from
custody forthwith ('the 27 July Order') and he gave directions in an order dated 27 July 2023 and sealed on
28 July 2023 ('the 28 July Order'). The latter order stated on the front page, in red:

“NOTICE TO THE DEFENDANT:

**The Contempt Application has been fixed for hearing on 25 October 2023 at 10.30am at the Royal**
**Courts of Justice, Strand, LONDON WC2A 2LL.**

**YOU MUST ATTEND THIS HEARING. If you fail to do so, a further warrant for your arrest may be**
**issued by the Court pursuant to CPR 81.7(2). You are advised to seek legal advice. Legal aid is**
**available for advice and representation in respect of the Contempt Application.”**

47. The final recital to the 28 July Order notes that the Court informed the Defendant of his rights as a
defendant to the Contempt Application. In other words, he was directly informed by Nicklin J of each of the
rights specified in CPR 81.4(2)(i) to (s) (see paragraph ý24 above).

48. The 28 July Order stated, so far as relevant:

“IT IS ORDERED AND DIRECTED AS FOLLOWS:

1. The Contempt Application will be heard by a Judge of the Media and Communications List with a time
estimate of 1 day on 25 October 2023 ('the Hearing').

2. The Defendant must attend the hearing.

3. The Defendant has the right to remain silent. If he wishes to give written evidence in response to the
Contempt Application, he should file and serve any written evidence on which he wishes to rely by 4.30pm
on 2 October 2023 and state in his evidence whether he contests the application or not. Whether or not the
Defendant serves written evidence, he may (if he wishes) give oral evidence at the Hearing of the
Contempt Application.

4. By 4.30pm on 16 October 2023, the Defendant must inform the Claimants whether he requires Nicholas
Gibbons to attend the Hearing to be available to be cross-examined on his affidavit. If the Defendant fails
to comply with this Paragraph, Mr Gibbons must attend the Hearing.

5. The Claimants must prepare an indexed and paginated bundle for the Hearing ('the Hearing Bundle').

6. The Claimants must file and serve on the Defendant the Hearing Bundle no later than 10am 5 working
days before the Hearing.

7. The Claimants must file and serve a Skeleton Argument and any authorities no later than 10am 3
working days before the Hearing.

8. The Defendant may file and serve a Skeleton Argument and/or authorities on which he wishes to rely
and, if he does, he should do so no later than 10am on the working day before the Hearing.”


-----

Paragraph 10 of the 28 July Order granted liberty to apply to vary the directions and gave specific
directions as to what the Defendant should do if he required more time to obtain legal advice and/or
representation.

49. The Claimants complied with paragraphs 5, 6 and 7 of the 28 July Order, serving the Hearing Bundle,
authorities bundle and their skeleton argument on the Defendant by post and email. The Defendant did not
comply with paragraph 4 of the 28 July Order and so Mr Gibbons attended the hearing on 25 October
2023, travelling from France to do so. The Defendant did not file or serve any evidence, skeleton argument
or authorities pursuant to paragraphs 3 and 8 of the 28 July Order (or otherwise), and there was of course
no requirement on him to do so, those directions being permissive.

50. On 3 August 2023, the Claimants served on the Defendant a copy of the sealed 28 July Order.

51. On 9 August 2023, the Claimants' solicitor sent an email to the Defendant stating:

“… During the hearing, you informed the Judge that you no longer have access to the computer you had at
the time of the incident when you accessed/downloaded/stored the police videos. You also informed the
Judge that the computer had been seized by the police and was currently in their possession.

The Judge informed you that you must provide us with specific details about when the computer was
seized, by whom it was seized and what was seized. Once we receive this information from you, we can
consider making an application to the court for an independent IT expert to be given access to your
computer in order to confirm that the police videos are deleted. On the face of it, this could enable you to
comply with the Orders of Mr Justice Saini and it could assist you when you have to attend court on 25
October 2023 to determine the outcome of the contempt application against you.

In order for me to make enquiries with the Police about your computer, can you please provide the
following:

1. Confirmation of the date and tie that your computer was seized by the police.

2. Confirmation of which police force seized your computer and the names of the investigating officers.

3. A copy of the receipt that the police gave to you for your computer.

4. A copy of any communication that the police have sent to you about your computer since it was seized.

5. Details of where your computer is being held.

… I reiterate the comments made to you by the Judge at the hearing. The Judge said that if it is presently
out of your control to comply with the Order, you need to cooperate with us to make sure that you can
comply.

…In addition to the above and to enable you to comply with the Order, can you please provide details of
the following information:

a. Full particulars of the downloading and making of copies of the police videos;

b. Full particulars of all devices and locations (including cloud storage) where you stored and/or caused to
be stored copies in any format of the police videos or any information derived from them, sett out what is
stored in each such location, and when it was stored there; and

c. Full particulars of any disclosure by you of the police videos or any information derived from or relating to
them, including but not limited to: the names and full contact details of all persons and entities to whom
such disclosure have been made, the date of disclosure, what was disclosed, and the circumstances of the
disclosure.”

As Ms Wilson acknowledged, the first sentence of the second paragraph of the above quotation does not
reflect an order made by the Court.

52. The Defendant responded by email on 11 September 2023:

“The computer isn't in my possession, as I stated at court.


-----

Proof is provided attached.

However, the leaked information was accessed on my phone, which could be made available to an
independent party, within my area.”

53. The Defendant attached to his email a copy of a “search record”. This document was provided by Kent
Police. It identifies that the Defendant's address was searched on 15 June 2023 and the items seized
which included:

“external hard drive

mobile phone

Tablet

Samsung hard drive

NAS Hard drive holder + 2 H/D

Sim card, Synology H/D + 2

Frartel base, Tower unit”

54. On 27 September 2023, the Claimants' solicitor sent the Defendant an email requesting further
information asking him to sign a consent form to enable them to contact Kent Police on his behalf. In the
absence of a response, the Claimants' solicitor sent further emails on 3 October 2023, 11 October 2023
and 17 October 2023.

55. In response to an enquiry directed to Kent Police, the Head of Legal Services at Kent Police
responded to the Claimants' solicitor on 17 October 2023 confirming that the items seized on 15 June 2023
remained in the Police's possession. The Claimants' solicitor sent the response from Kent Police to the
Defendant on 18 October 2023 and asked him to:

“1. Identify on the search record which devices you used to access / download / store / makes copies of the
police videos.

2. Identify any other device that is not on the list of items seized by the Police which you used to access /
download / store / make copies of the police videos (in your email on 12 September 2023, you said you
used your mobile phone to access the police videos).

3. Confirm whether you consent to an independent IT expert examining the devices that you have identified
(in relation to points 1 and 2) for the purpose of permanently deleting all electronic copies of the police
videos on your devices.”

56. The Defendant did not respond and, as I have said, he did not attend the hearing on 25 October 2023.

**Particulars of Alleged Contempt of Court**

57. In Part 12 of their Contempt Application the Claimants state:

“1. The Defendant did not serve an affidavit providing the information identified in paragraph (2) of the First
Order by 4pm on 11.04.22.

2. The Defendant has not served any affidavit or any other document on the Claimants providing any of the
information identified in paragraph (2) of the Order or, by any other means, provided that information to the
Claimants.

3. The Defendant did not attend the Second Claimant's offices at noon on 14.04.22.

4. The Defendant did not serve an affidavit providing the information identified in paragraph (2) of the First
Order by 4pm on 3 April 2023.

5. The Defendant did not attend the office of the Claimants' solicitor at noon on 6 April 2023.


-----

6. The Defendant has taken no steps to enable the inspection by an independent IT expert of his devices
and/or media to which he downloaded the Police Videos.

7. The Defendant has not sought any extensions of time to comply with his obligations or to vary the
arrangements to enable the deletion of all copies of the Police Videos he has made and/or to permit
inspection of his media and devices to confirm that all copies have been deleted.

8. The Defendant's failure to act and/or his continuing failure to act as set out above constitute breaches of
paragraphs (2) and (3) of the First Order and paragraphs (1) and (2) of the Second Order and, thereby,
contempt of court.

9. Further, it is to be inferred from the Defendant's failure to act, as set out above, and to comply with
paragraphs (2) and (3) of the First Order and paragraphs (1) and (2) of the Second Order that he retains
copies of the Police Videos and/or some of them and is thereby in breach of paragraph (1)(a) of the First
Order and in contempt of court.”

58. However, fewer grounds of contempt are relied on than would appear from the application. In view of
the fact that the First Order was not _personally served on the Defendant before the time for compliance_
with paragraphs (2) and (3) of that Order had expired, and having regard to CPR 81.4(c), the matters set
out in paragraphs 1-3 of Part 12 of the Contempt Application are not relied on as grounds of contempt.
Accordingly, there is no allegation that the failure to serve an affidavit by 11 April 2022 in accordance with
paragraph (2) of the First Order or the failure to attend BLM's offices on 14 April 2022 in accordance with
paragraph (3) of the First Order constitute a contempt of court on the part of the Defendant.

59. The grounds pursued are, in short:

i) The Defendant did not swear and serve on the Claimants an affidavit containing the information
identified in paragraph (2) of the First Order by 3 April 2023, contrary to paragraph (2) of the First Order as
varied by paragraph (1) of the Second Order (Ground 4);

ii) The Defendant did not attend Clyde & Co's offices on 6 April 2023 with his devices to enable the
independent IT expert to delete copies of the Police Videos and/or any information derived from them,
contrary to paragraph (3) of the First Order as varied by paragraph (2) of the Second Order (Grounds 5 to
7); and

iii) Contrary to paragraph 1(a) of the First Order, the Defendant retained the Police Videos (Ground 9). In
light of the seizure of the Defendant's devices on 15 June 2023, the Claimants' skeleton argument stated
that they do not press their application that the Defendant has retained material since that date. However,
in her oral submissions Ms Wilson retracted that concession insofar as she alleged the Defendant retains
material on his mobile phone.

**The law**

60. The claimant bears the burden of proof. The criminal standard applies: the Court must be satisfied
beyond reasonable doubt, in other words so that it is sure, that the defendant committed the alleged
breach. Where there are a number of matters alleged to be a contempt, the Court is required to address
each ground separately and be sure in relation to each ground.

61. Conduct in the form of disobedience to a court order may amount to a contempt of court. As the
authors of Arlidge, Eady & Smith on Contempt (5[th] ed., 2017) state at §12.5:

“It is obvious that any civilised society depends upon the authority and effectiveness of orders made in its
courts. There is thus a public interest in seeing that orders are enforced.”

See, to similar effect, the White Book 2023, vol.1, 81CC.16.

62. A person is guilty of contempt of court by breach of an order only if all of the following factors are
proved beyond reasonable doubt:

i) The order which is alleged to have been breached is unambiguous.


-----

ii) Having received notice of the order the defendant did an act prohibited by the order or failed to do an
act required by the order within the time set by the order.

iii) The defendant intended to do the act or failed to do the act as the case may be. It is the act constituting
the breach which must be deliberate (rather than merely inadvertent). An intention to commit a breach is
not necessary (although intention or lack of intention to flout the law may be relevant to penalty).

iv) The defendant had knowledge of all the facts which would make the carrying out of the prohibited act or
the omission to do the required act a breach of the order. However, as Rose LJ observed in _Atkinson v_
_Varma [2020] EWCA Civ 1602, [2021] Ch 180, at [54], when addressing the mental element required for a_
finding of contempt:

“…once it is proved that the contemnor knew that he was doing or omitting to do certain things, then it is
not necessary for the contemnor to know that his actions put him in breach of the order; it is enough that as
a matter of fact and law, they do so put him in breach.”

v) In the context of an application for committal for an alleged breach of a mandatory order, the Court must
be sure not only that the defendant has not done what he was required to do, but also that it was within the
power of the defendant to do it at the date fixed for compliance.

(See Cuadrilla Bowland Ltd v Persons Unknown [2020] EWCA Civ 9, Leggatt LJ at [25]; FW Farnsworth
_[Ltd v Lacy [2013] EWHC 3487 (Ch), Proudman J at [20], In re L-W (Children) Enforcement and Committal:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59TV-6HK1-F0JY-C30G-00000-00&context=1519360)_
_Contact) [2010] EWCA Civ 1253, [2010] 1 FLR 1095, Munby LJ at [34; the White Book 2023, vol.1,_
81CC.16 and 81CC.18.)

63. CPR Part 81 sets out procedural requirements and, together with the common law, provides
safeguards for the defendant. CPR 81.4(2)(c) provides:

“A contempt application must include statements of all the following, unless (in the case of (b) to (g)) wholly
inapplicable—

…

(c) confirmation that any such order was personally served, and the date it was served, unless the court or
the parties dispensed with personal service”.

**Ground 4: alleged breach of paragraph (2) of the First Order as varied by paragraph (1)**
**of the Second Order**

_What did paragraph (2) of the First Order, as varied by paragraph (1) of the Second Order, require the_
_defendant to do, and is that order unambiguous?_

64. The plain meaning of the order was that the Defendant was required to prepare, swear and serve on
the Claimants, by no later than 3 April 2023, an affidavit. In that affidavit, he was required to provide (a) full
details of his downloading or copying of the Police Videos (i.e. those he had downloaded from Collaborate
on or about 7 January 2022), (b) full details of all devices on which, and all locations where, he has stored
(or caused to be stored) the Police Videos or any information derived from them, including setting out what
he has stored and when he has stored it on each device or in each location; and (c) full details of any
disclosures he had made of the Police Videos or any information derived from them. I am satisfied to the
criminal standard that the order is clear and unambiguous.

_Was the First Order, as varied by the Second Order, personally served on the defendant prior to the date_
_for compliance?_

65. Having regard to the affidavit of Mr Gibbons, the certificates of service that have been provided, and
the statements of Mr Buchanan to which I am referred, and in the absence of any reason to doubt that
evidence which is consistent with the correspondence, I am sure that the First Order was personally served
on the defendant by Mr Buchanan on 13 May 2022 (paragraph ý16 above) and the Second Order was
personally served on the defendant by Mr Buchanan on 8 February 2023 (paragraph ý31 above).


-----

Accordingly, both orders were personally served on the defendant more than seven weeks before the
deadline for service of his affidavit was due to expire.

_Did the Defendant fail to do what was required of him by the date for compliance?_

66. The uncontested evidence of Mr Gibbons is that the Defendant did not serve an affidavit on his firm.
His evidence is consistent with the contemporaneous correspondence drawing attention to the Defendant's
failure to serve an affidavit (see paragraph ý34 above). There is no evidence to the contrary: neither the
Court nor the Claimants received any affidavit from the Defendant by 3 April 2023, or at all. Moreover, I
agree with Ms Wilson that this was not a failure of form: the Defendant provided nothing responsive to the
order. The stance he has taken is of a piece with his stated intention, prior to their imposition, not to comply
with any order Saini J might make (see paragraph ý17 above).

67. In the circumstances, and on the evidence, I am satisfied to the criminal standard that the Defendant
breached paragraph (2) of the First Order as varied by paragraph (1) of the Second Order; the failure was
deliberate rather than merely inadvertent; and the Defendant knew that he was omitting to prepare, swear
and serve on the Claimants an affidavit containing the required information.

_Was it within his power to comply at the date fixed for compliance?_

68. Various of the Defendant's devices were seized by Kent Police on 15 June 2023. It is conceivable that
the seizure of his devices could have had some impact on the Defendant's ability since that date to provide
“full particulars” of the required information. For example, it might have hampered his ability to check which
device(s) he used to download the Police Videos, or the date(s) on which he did so, although it would not
have made it impossible for him to prepare, swear and serve an affidavit providing such particulars as he
could from memory .

69. However, whatever the position may have been since 15 June 2023, at the date for compliance (i.e. 3
April 2023), the devices were in his possession. There is nothing in the evidence that gives rise to any
doubt that it was within the Defendant's power to swear and serve an affidavit by 3 April 2023. He chose
not to do so.

70. It follows that the Claimants have discharged the burden of proving to the criminal standard that the
Defendant committed contempt of court by failing to comply with paragraph (2) of the First Order as varied
by paragraph (1) of the Second Order.

**Grounds 5-7: alleged breach of paragraph (3) of the First Order as varied by paragraph**
**(2) of the Second Order**

_What did paragraph (3) of the First Order, as varied by paragraph (2) of the Second Order, require the_
_defendant to do, and is that order unambiguous?_

71. The plain meaning of the order, insofar as it imposed any obligations on the Defendant, was that the
Defendant was required to attend the office of Clyde & Co (at St Botolph Road, 38 Houndsditch, London
EC3A 7AR) at 12 noon on 6 April 2023. The order allowed for the parties to agree in writing an alternative
date and time but they did not do so. The Defendant was required to take with him on 6 April 2023 all
media or devices on which the Police Videos or any information from them had at any time been stored,
and to permit an independent IT expert nominated by the Claimants to permanently delete all electronic
copies of the Police Videos on such media or devices (or to verify that they had already been deleted). I
am satisfied to the criminal standard that the order is clear and unambiguous.

_Was the First Order, as varied by the Second Order, personally served on the defendant prior to the date_
_for compliance?_

72. I have addressed this issue in paragraph ý65 above. As I have said, I am sure that the First Order was
personally served on the Defendant on 13 May 2022 and the Second Order was personally served on him
on 8 February 2023. Accordingly, both orders were personally served on the Defendant more than eight
weeks before the date on which he was required to attend Clyde & Co's office


-----

_Did the Defendant fail to do what was required of him by the date for compliance?_

73. The Contempt Application signed by Mr Gibbons affirms that the Defendant did not attend the office of
the Claimants' solicitors at noon on 6 April 2023. That is supported by the uncontested evidence of Mr
Gibbons that the Defendant failed to submit his devices and accounts for inspection by an independent IT
expert and took no steps to comply with the order requiring his attendance at Clyde & Co's office. I am
satisfied beyond reasonable doubt that the Defendant failed to attend the Claimants' solicitor's office at
noon on 6 April 2023, he failed to take his media and devices on that occasion, and he failed to give the
independent IT expert access to enable the Police Videos to be permanently deleted (or their prior deletion
to be verified). Again, I agree with Ms Wilson that this was not a failure of form: the Defendant did not take
any steps to facilitate inspection of his media or devices.

74. I am satisfied to the criminal standard that the Defendant breached paragraph (3) of the First Order as
varied by paragraph (2) of the Second Order; the failure was deliberate rather than merely inadvertent; and
the Defendant knew that he was failing to attend the Claimants' solicitor's office and failing to take, and
permit access to, his media and devices in accordance with the terms of the orders.

_Was it within his power to comply at the date fixed for compliance?_

75. As I have said, various of the Defendant's devices were seized by Kent Police on 15 June 2023. They
remain in the possession of Kent Police. Consequently, since that date, it has not been possible for the
Defendant to take those devices to the Claimants' solicitor's office for inspection. However, it is clear that at
the date fixed for compliance, that is, 6 April 2023, the devices were in his possession. There is nothing in
the evidence that gives rise to any doubt that it was within the Defendant's power to attend the Claimants'
solicitor's office at noon on 6 April 2023, to take his media and devices with him, and to allow the
independent IT expert access to enable the Police Videos to be permanently deleted (or their prior deletion
verified). The Defendant chose not to comply.

76. It follows that the Claimants have also discharged the burden of proving to the criminal standard that
the Defendant committed contempt of court by failing to comply with paragraph (3) of the First Order as
varied by paragraph (2) of the Second Order.

**Ground 9: alleged breach of paragraph 1(a) of the First Order**

_What did paragraph (1)(a) of the First Order require the Defendant to refrain from doing, and is that order_
_unambiguous?_

77. Paragraph 1(a) of the First Order unambiguously prohibited the Defendant from retaining the Police
Videos, which were identified in clear terms as the files he had downloaded from the Collaborate System
on or about 7 January 2022. Paragraph 1(a) also prohibited access, disclosure or use of the Police Files,
but no allegation has been made by the Claimants of any breach of that part of the order.

_Service of the First Order_

78. As I have said, I am sure that the First Order was personally served on the defendant on 13 May 2022
(see paragraphs ý16 and ý65 above).

_Did the Defendant retain the Police Videos, or any of them, after the First Order was personally served on_
_him?_

79. The Claimants acknowledge that this part of their application is wholly reliant on the Court inferring
from all the circumstances, and in particular the fact that – as I have now found – the Defendant failed to
comply with paragraphs (2) and (3) of the First Order, as varied to give him more time for compliance.

80. In light of the seizure of the Defendant's devices on 15 June 2023, the Claimants acknowledge that
since then the Defendant has not retained the material, save to the extent that Ms Wilson contended that
he may retain it on his mobile phone. In support of this argument she relied on the Defendant's statement
in an email dated 11 September 2023 that “the leaked information was accessed on my phone, which


-----

_could be made available to an independent party, within my area”. I do not consider that this email provides_
a secure foundation for concluding to the criminal standard that the Defendant was still in possession of the
phone on which the Police Videos were accessed, given that the search record clearly shows that a mobile
phone was seized by Kent Police, still less that the Police Videos were still on that phone. Accordingly,
insofar as the Claimants' allegation was based on retention of the Police Videos since 15 June 2023, I
have no hesitation in rejecting it.

81. However, the Claimants' primary argument is that the Court can safely infer that in the period from 13
May 2022 when the First Order was personally served on the Defendant until his devices were seized on
15 June 2023 he retained the Police Videos.

82. I am not persuaded that this allegation of contempt has been made out to the criminal standard of
proof. My reasons are as follows:

i) Saini J referred to evidence from a data log which showed that the Defendant had downloaded three
videos of KDI's arrest and one data file relating to the videos of his police interview (albeit it was
considered unlikely he would have been able to view the latter) on 7 January 2022. Bearing in mind this
evidence, and the Defendant's emails on 7 January 2022 in which he alerted BLM that he had access, I am
satisfied that he downloaded them and so would have held them on that date. But the question is whether
he still held them more than four months later when the First Order was personally served on him.

ii) Ms Wilson submits that Saini J must have found, albeit applying the civil standard, that the Defendant
still held the Police Videos when he made the First Order on 28 March 2022. That may be so, although
paragraph (3) referred to the possibility that the independent IT expert might verify the Defendant's deletion
of the Videos (albeit that would have encompassed the possibility of deletion prior to attendance at BLM's
office). But in any event, I am concerned with the position from 13 May 2022, and have to apply the
criminal standard of proof.

iii) The Defendant did not seek the Police Videos. It is not material to which he wished to have access. He
recognised that the access he was inadvertently given was a violation of another's privacy, and he very
promptly drew it to BLM's attention, expressly asking for the error in granting him access to be rectified.
Although far from determinative, this is a factor in considering whether I can be sure he retained the Police
Videos more than four months later.

iv) I do not consider that it can be inferred from the Defendant's lack of cooperation with the Claimants or
his breach of the mandatory orders that he had any desire to retain the Police Videos. It is apparent that he
considered it outrageous that BLM was making demands of him, and threatening him with litigation, when
he was not the party at fault for leaking confidential information. It is equally apparent that he considered
the mandatory orders, compelling him to speak and to give access to his media and devices, was a
violation of his rights. The restraining order was in a different category. It is apparent from his grounds of
appeal submitted on 1 April 2022 that the prohibition on retaining the Police Videos was not, in itself, an
order he considered objectionable. His only expressed concern in relation to paragraph 1 of the First Order
was with what he regarded as “needless aggression” in its implementation, and that the party that had
leaked the information was not also made subject to a similar order. The Defendant's view of the position
was misguided but it is nonetheless pertinent in considering whether I can infer, beyond reasonable doubt,
that he retained the videos on and after 13 May 2022.

v) I bear in mind that the Defendant has never asserted that he has deleted the Police Videos. It can
reasonably be said that he could very easily have said so if that was what had occurred. That is of course
true. But the inference I draw is that even if he had deleted the Police Videos at an early stage, or before
13 May 2022, or indeed at any time since, he would not have been prepared to inform the Claimants or the
Court because he was resistant to being compelled to explain what he had done. In his grounds of appeal
the Defendant said that he refused to tell BLM “anything they asked as they could use [it] to avoid
_punishment and quickly move on”, but that he would have chosen to reveal his side if the matter had been_
investigated by a police officer to give them “clarity in their investigation”. It seems to me that there is a real
possibility that the Defendant had already deleted the Police Videos but he was not prepared to tell BLM


-----

that he had done so because if the matter was resolved in that way BLM could avoid the punishment he
considered they deserved for inadvertently disclosing KDI's confidential information to him.

83. The Defendant's breaches of the mandatory orders mean that there is no certainty as to whether KDI's
confidential information remains on any of the Defendant's devices or media. That is deeply unsatisfactory.
But that is not the test in addressing this allegation of contempt. For the reasons I have given I cannot be
sure that the Defendant retained the Police Videos at any time during the period since 13 May 2022.

84. Accordingly, I dismiss the allegation that the Defendant has acted in contempt of court by breaching
paragraph (1)(a) of the First Order.

**Conclusion**

85. For the reasons I have given, I find that the Defendant has acted in contempt of court by breaching
paragraphs (2) and (3) of the First Order, as varied by paragraphs (1) and (2), respectively, of the Second
Order. I reject the allegation that the Defendant has acted in contempt by breaching paragraph (1)(a) of the
First Order.

86. I adjourned the hearing in respect of penalty in order to give the Defendant the opportunity to consider
this judgment, and to ensure that he has an opportunity to put forward any matters in mitigation on which
he may rely at that hearing, which he is required to attend.

**End of Document**


-----

