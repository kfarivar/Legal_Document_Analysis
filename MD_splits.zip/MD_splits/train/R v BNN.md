# R v BNN [2024] EWCA Crim 991

Court of Appeal, Criminal Division

Macur LJ, Stacey J and Judge Michael Chambers KC

22 August 2024Judgment

**Mr R Kherbane (instructed by Birnberg Peirce) for the Applicant**

**Mr A Johnson (instructed by Crown Prosecution Service) for the Respondent**

Hearing dates : 19 July 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 22 August 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

ANONYMITY

No publication shall refer to the name of the Applicant.

This order is made pursuant to section 11 of the Contempt of Court Act 1981.

**Macur LJ :**

1. The Applicant seeks an order for anonymity under section 11 of the Contempt of Court Act 1981. The
Respondent submits that, regardless of outcome of this application and prospective appeal, that there is
good reason to afford this protection since the Applicant has previously been found to be a VOT, and a
previous criminal prosecution in 2016 was abandoned accordingly.

2. We have regard to the important principle of open justice and have scrutinised the application, but in the
circumstances, we agree that the applicant's welfare requires that his anonymity is preserved. In these
circumstances the applicant's name has been anonymised by the assignment of the three random initials
“BNN”.

Introduction:


-----

3. On 3rd November 2021 the applicant pleaded guilty on re-arraignment to one count of producing a
controlled drug of Class B (cannabis). On the same date he was sentenced to 9 months imprisonment
which brought about his immediate release from custody. Consequential orders were made.

4. His application for an extension of time (510 days) in which to seek leave to appeal against conviction
has been referred to the full court by the Registrar, who also granted a representation order for fresh
counsel. Mr Kherbane appears on his behalf.

Background summary:

5. The applicant is a Vietnamese national of previous good character. He says he was born on 17th
September 1976 in the city of Hai Phong in Vietnam. He worked with the Vietnamese military between
1997 and March 2015. He joined the Communist Party in 2003 before later defecting. In 2011 he applied
for and in 2012 was granted a loan from the military bank in Vietnam to purchase fishing equipment for his
fishing farm. He was unable to repay this loan due to the collapse of his business. He and his family
became indebted to the triads or well-known “Black Society” in Vietnam. Members of the triads made
threats against him, and eventually in 2015 trafficked him to the United Kingdom through Russia, China,
and France, where he was forced to work for them to repay his debt.

6. On 10th February 2016 he was arrested by Hertfordshire Police; ultimately, he was not charged with
any offence. On the following day, he claimed asylum and was referred by an immigration officer through
the National Referral Mechanism (“NRM”) to the Single Competent Authority (“SCA”). He was released
from police custody. Whilst being taken by taxi to accommodation in Birmingham, he disappeared after
stopping to use the bathroom at Northampton Services. He claimed that he was abducted by his traffickers
and taken back to the premises at which he had been previously working.

7. In November 2016, he was hospitalised at Kings College Hospital. A member of the nursing staff made
a fresh NRM referral.

8. On 22nd March 2018, the SCA made a positive Conclusive Grounds Decision (“CGD”). The decision
maker considered that whilst there were discrepancies in his account, they were minor and not sufficient to
damage his credibility. It noted that Hertfordshire Police had stated “from what we were told and advice
from my Sgt., he was clearly a victim of Human Trafficking and was to be NFA for the cannabis factory”.
They concluded that on “all the evidence in the round … the [applicant] was subjected to forced criminality
in the UK”.

9. Subsequently, he made a claim for asylum, which was refused on 8th May 2019. The FTT made
positive findings as to BNN's trafficking and re-trafficking within the UK but refused the immigration claim
for humanitarian protection because, (a) BNN's legal representatives had not produced expert evidence or
country guidance during proceedings as to why he could not, for example, relocate internally within
Vietnam to avoid traffickers or the triads, and (b) the judge found that he may be able to do so.

10. By 20th June 2019 he had exhausted all rights of appeal. Mr Kherbane informs us that his Asylum
Support payments stopped in December 2019 (albeit that the 2021 CGD states that this did not happen
until January/February 2021.) BNN said he initially lived in a hotel before moving to share a flat in Ilford. In
March 2020 he moved to live with a Vietnamese friend with whom he stayed until March 2021. When that
came to an end he was left without accommodation, food or money. He met people in China Town London
who offered to help him.  He was taken to Leicester.

Facts of the extant offence:

11. In February 2020, JB leased a house he owned in Leicester to two Chinese nationals, DT and LH.

12. On Friday, 19th March 2021, police officers attended the property in response to information that it
was being used to cultivate cannabis. The electricity supply to the property appeared to have been
bypassed. They forced entry and found 342 cannabis plants growing in five different areas with a
significant retail value.


-----

13. The applicant was present and attempted to flee but was ultimately apprehended. Two mobile phones
were seized from him. When later interviewed he answered “no comment” to all questions. He refused to
divulge the PIN of one of the phones.

14. PO Kirt, the police drug expert concluded that:

“The cannabis plants being grown … had the necessary equipment, and evidence of, the ability for each
plant to reach full maturity and harvest. It is my opinion that [BNN] was acting as a “gardener”, cultivating
cannabis on a commercial scale on behalf of or in cooperation with an organised crime network who have
the means to set up sophisticated cannabis production facilities on an industrious scale in order to sell
cannabis for cash profit”.

15. BNN's first court appearance was on 22nd March 2021 before the Magistrates' Court. His case was
sent to the Crown Court for trial, and he was remanded in custody.

16. On 28th April 2021he made an application for bail to the Crown Court. His representative stated, inter
alia, that:

“[BNN] has indicated in his instructions that he was threatened and forced to remain at the property … The
defence will look into this matter further and whether BNN has a defence under the Modern Day (sic)
Slavery Act”.

The application was refused.

17. On 4th May 2021 the applicant appeared at a Plea and Trial Preparation Hearing via video link
represented by Ms Power of counsel. She noted on the DCS side bar, “D threatened with force to remain
at the premises. Acted under compulsion. D may have a defence under the **_[Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
(s45)”. The CPS indicated on the PTPH form there was no intention to obtain disclosable material from a
third party.

18. At the outset of the hearing, the judge asked counsel “is any government department involved in
assessing the defendant as a victim of modern slavery?” Ms Power replied that she did not know but had
been trying to find out. The judge then said:

“I'm giving you ten minutes. I can tell you this... 342 plants – can you translate this. 342 plants worth nearly
£250,000. The courts are familiar with people being put under pressure to come to the UK from Vietnam. If
the defendant pleads guilty today now, he will get a lot of credit for that plea. I give an indication that my
maximum sentence would be in the region of twenty-four months' imprisonment. He would have to serve
half of that, which is twelve months' imprisonment. I think he has been on remand since March 2021. So, if
he pleads guilty today, he has probably served his sentence and soon he would be taken from prison to a
detention centre with a high probability of him being deported back to Vietnam as soon as possible. If he
pleads not guilty and members of the public have to decide if he is guilty or not, the starting point for a
prison sentence for a significant category 2 is four years' imprisonment. It's his choice; I'm giving you
sentence”.

19. No application had been made for a Goodyear indication. The case was adjourned for Ms Power to
take instructions. When the case returned to court, she indicated that her conference had been “fruitless”.
The applicant was arraigned and entered a not guilty plea. Towards the conclusion of the hearing, the
Judge addressed the applicant, in terms:

“The courts are extremely busy at the moment because of the coronavirus pandemic. This means there is
no 100 per cent guarantee that your case will finish in November 2021. If the delays are really bad, you
may be kept in prison for longer, waiting for your case to conclude. I am ordering you to stay in prison”.

20. On 12th August 2021 the applicant was again referred through the NRM to the SCA.

21. On 26th August 2021 the SCA decided that there were reasonable grounds to suspect that he was a
victim of trafficking. A hearing had been listed on that day for an update on the NRM referral. Counsel then
appearing did not seem to be aware of the positive reasonable grounds decision made by the SCA. The
judge commented, again unsolicited:


-----

“Look, I'll be frank with you. In my experience, very, very few cases, even with a conclusive grounds
decision in favour of the defence, lead to the prosecution turning turtle and saying we are not proceeding
with this prosecution. Of course, there's a handful of cases where they do…” and that if the ongoing NRM
process continued past the currently fixed 1 November 2021 trial date, “the Defendant may very well have
served any sentence he would receive on conviction”.

22. On 3 September 2021, the CPS were notified that the Applicant had been the subject of a positive
reasonable grounds decision.

23. On 8 September 2021, the CPS responded to note that they would, “reconsider the case by reference
to the public interest test once the conclusive grounds decision had been received.”

24. Following a 'mention' in the Crown Court on 23 September 2021 Mr Bell, defence counsel, produced a
short attendance note for the benefit of his instructing solicitor that has been uploaded on to the Digital
Case System. The note includes the following: “Reading between the lines, the Judge clearly takes the
view that this case will not proceed to trial - either the Crown will drop it, or the Defendant will plead - and
the sooner the nettle is grasped the better. He may be right.”

25. On 3 October 2021, a defence case statement was uploaded which, in addition to taking issue with
“any assertion that (BNN) knew that the drugs were in fact … cannabis” he “will rely upon the fact that his
vulnerability was exploited by others”, that he was “vulnerable due to dire financial constraints and his
status in this country once having been trafficked to the UK” and that he received no remuneration for the
“few days” he had spent at the premises looking after the plants prior to his arrest.

26. On 8 October 2021 a note of the prosecution review indicated:

“The Police have provided an immigration document which confirms D was a victim of modern slavery in
2018 and that parts of his claim in this referral is supported the fact he did stay at an address in Ilford after
this. This document will be disclosed. With regards to the NRM referral – further examination is being made
regarding his claims that he was in contact with police and social services on 10/02/2016 and the fact that
he was treated at Kings College Hospital in London from April 2016 – October 2016. Thus, a PND check
and medical records have been sent to the various departments. These have been sent and we are
awaiting a reply.

I am also told the phone was not sent for further triage by the OIC after the initial stage of triaging failed
following D not providing his PIN. It would appear therefore that we would have little to rebut the
defendants claim of modern slavery as the phone has not gone.”

27. On 26th October 2021, the review referred to information that had been provided by other police
forces. It noted that the Applicant had previously been arrested for the cultivation of cannabis, but that no
further action had been taken due to him “claiming that he was trafficked and forced to look after the
plants.”

28. It is also noted that the Applicant had been stopped by British Transport Police during the COVID
pandemic restrictions on 6th May 2020 at Sheffield Railway Station, and the circumstances “discredits his
defence of being trafficked / a slave. He was clearly stopped on his own by police and chose not to tell
them that he was a victim of human trafficking”, but then also notes that whilst “this would assist to
disprove his claims of being a modern slave but has a limited amount of value as it is from 06/05/20”.
Further noted was that “clearly the defendant had access to mobile phones which were found on his
person. One of these phones has been triaged, the other which he has refused details for. He has however
not chosen to call the police during this time and notify us of him being kept at the address against his will.
He has not given police details to access the phone which would surely give some indication as to whether
or not he is being kept at the address against his will. At this stage even without the SCA decision I am of
the view we would continue with the prosecution based on the evidence at the scene in terms of living
standards, he [sic] fact D had two phones, one of which he would not provide the PIN for and that he tried
to escape from the police. Counsel's advice however remains outstanding.”


-----

29. On the following day, the review noted that further disclosure had been made. It noted the final SCA
decision was outstanding. It commented that whether the aforementioned material regarding the previous
arrest for cultivation in Hertfordshire, and the stop of the defendant in Sheffield, had been provided to the
SCA was unknown, but “this however will not affect whether we run the trial.”

30. On November 3, the case was listed for trial before HHJ Spencer KC, who had had no previous
involvement with the applicant. The applicant was represented by counsel (now deceased) and was
assisted throughout by an interpreter. The case was called on and application made for the applicant to be
rearraigned.

31. The applicant duly entered a guilty plea. A handwritten endorsement was signed by the applicant. It
stated:

“1. I will plead guilty to the offence of producing a controlled drug.

2. I do not accept this was my cannabis.

3. I was coerced and intimidated into playing the role of a gardener for three days.

4. I accept that this still puts me into a “lesser role” for the offence.

5. I hope that this mitigation and other matters will enable the judge to pass a sentence that matches the
time I have already served or close to it.

6. This is my decision.”

32. Prosecution counsel opened the case, and noted that, no monies were recovered from BNN, and that
“the sophistication of the operation is beyond the means and capabilities, respectfully, of this defendant”.
Prosecution counsel confirmed that BNN had previously been trafficked and had asserted he had been retrafficked. He noted, “the Crown accepts that there will have been, in his past, that degree of coercion and
pressure.” (Emphasis added)

33. There was no pre-sentence report.

34. In mitigation, counsel stated that BNN was “set to work for a Chinese gang … who trafficked him
ultimately to this country” and that whilst “falling short of a defence, he was nonetheless subjected to
coercion to become involved in this. The only reason he was here was because of the influence of this
gang and that is why he did what he did”. (Emphasis added)

35. In his sentencing remarks, the judge said that “This sadly is a familiar tale... controlled by others who
put them to work... I have considerable sympathy with you. From a starting point of twelve months'
imprisonment, … I think the right discount is 25 per cent; that is a sentence, therefore, of nine months'
imprisonment. You have more than served that, given that you have been in custody since your arrest on
19 March. That means you will be released later today.”

36. In response to subsequent McCook/ waiver of privilege inquiries, defence counsel observed: “The
position with [BNN] on the date I represented him was that he was fully aware that a defence under the
**_Modern Slavery Act was being explored on his behalf. Indeed he had made a statement to this effect that_**
I have forwarded with my last email. The position that appertained to [BNN] on the date I represented him
was this: i) We / he could have continued to explore the potential defence of him being a victim of modern
**_slavery; ii) We could continue to trial with the prosecution not accepting the proposed defence; iii) He_**
could accept the charge and plead Guilty. It was his instructions that he wanted to plead Guilty. That is why
the manuscript document I have drafted and also forwarded with my last email was drafted. The issue of
his having been coerced into the conduct constituting the offence was then used in mitigation in order to
persuade the judge to accept a lesser categorisation and a lesser sentence. [BNN] was not advised by me
that he had no defence under the **_Modern Slavery Act. To the contrary he was told again – what he_**
already knew – that the defence was being explored on his behalf. He made the decision to plead Guilty
and it was only at that point that it was accepted in mitigation that there was no (longer) a defence under
that Act. I hope this explains the position although I'm afraid it may not be of any assistance to [BNN] in his
current position.”


-----

Events after court proceedings and fresh evidence

37. The SCA had regard to the 2016 NRM, asylum interviews and other submitted documents, including a
witness statement from BNN dated 12 October 2021 prepared specifically in relation to the NRM referral.

38. His account as to his experiences from March 2021 was summarised as follows:

“In March 2021 you met people in China Town, London who offered to help you. A man called 'Aythong'
brought you to Leicester after offering you a job cleaning and painting a house for up to 3 or 4 days. After 3
or 4 days you were taken to Harrow Road where you were you would be doing the same job. However, on
arrival at the property, you were told to look after cannabis plants. You were threatened – told you would
be beaten, put in a van and returned to Vietnam. You remained at the property until your arrest on
19/03/2021.”

Whilst that account was found “not particularly detailed” it was “plausible and consistent.” He was “subject
to recruitment and transportation…deceived, subject to threat and placed in a position of vulnerability [and]
subjected to forced criminality.”

39. On 21 December 2021 the SCA determined that “Looking at the evidence in the round, it is considered
that your account has met the required threshold, namely on the balance of probabilities, it is more likely
than not to have occurred.

Decision: Applying the standard of proof on the balance of probabilities, it is accepted that you were a
victim of modern slavery.”

40.  In a witness statement dated 17th October 2022 the applicant sets out his account of how he came to
enter a guilty plea to the following effect:

A discussion took place in a meeting room. He was told that if he pleaded guilty, counsel would ask the
judge to pass a sentence allowing him to be released that day, “but he warned me that if I maintained my
not guilty plea, I could be sentenced to 36 months, or between 5 to 7 years in prison”. BNN stated that he
“felt very afraid when the barrister told me this, but I also felt confused because the advice to plead guilty
was different to the previous advice that I had received, that I could plead not guilty”. He was very anxious
that day, because it was “very difficult being in prison.” The main factor weighing on his mind “was the
prospect of immediate release from prison … compared with the prospect of being in prison for up to 7
years if I was found guilty after a trial.” The applicant says, “I told the barrister I would plead guilty to being
coerced and intimidated into looking after the plants”, but that after the conference concluded, he began to
have “some doubts about why the barrister was advising me to plead guilty”. He indicated that he tried to
get the attention of the custody staff but failed. “From that point it felt as though everything happened really
quickly and I did not understand what was going on. He did not understand why, having pleaded guilty and
been told by the judge that he had already served his sentence, he was not released from custody.”

41. Following his release from detention, on 29th December 2021, the Applicant was taken to a Salvation
Army safehouse.

Application for an extension of time in which to apply for leave to appeal and admission of fresh evidence
[pursuant to section 23 CAA 1968.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1KR-00000-00&context=1519360)

42. In orthodox fashion, we “examine the merits of the underlying grounds before the decision is made
whether to grant an extension of time”. See O _[2019] EWCA Crim 1389._

Grounds of Appeal

43. There are three draft, alternate grounds of appeal that the conviction is unsafe because:

The applicant entered an equivocal guilty plea; (alternatively)

His plea was entered as a result of undue pressure; (alternatively)


-----

The Crown Prosecution Service did not apply its own guidance on taking steps to investigate, gather
relevant information and to await the SCA conclusion in order to properly decide whether to prosecute a
victim of trafficking.

44. The fresh evidence upon which the Applicant seeks rely comprises:

a. First-tier Tribunal (Immigration and Asylum Chamber) Determination dated 7th March 2019;

b. Psychologist report of Dr Amy Chisholm dated 20th April 2022;

c. Two sets of positive Conclusive Grounds Decisions by the SCA dated 4th April 2018 and 2nd December
2021;

d. Two reports produced by the Helen Bamber Foundation, containing clinical observations about the
applicant dated 6th July 2022, and 12th January 2023; and

e. The bundle of additional documents requested by the prosecution during the present proceedings
including his asylum interview records dated January 2018, National Referral Mechanism (“NRM”) dated
12th August 2021, witness statement taken by SKR Legal Solicitors dated 12th October 2021, and
responses to the SCA questionnaires completed by SKR Legal Solicitors dated 14th October 2021.

45. Mr Johnson for the Respondent take no issue that we should consider the fresh evidence _de bene_
_esse but seeks to cross examine the Applicant on issues going to the facts of the extant offence and_
circumstances surrounding his plea rather than the circumstances in which he was originally trafficked to
the UK. He accepts that the SCA appears to analyse BNN's circumstances to some extent within the
decision minute but notes that this amounts to little more than setting out the Applicant's account and
accepting it.

46. The SCA had placed “significant” weight to a report from the United States Department of State, which
provides generic information which would support “just about any account by an Albanian or Vietnamese
national alleging they were forced to cultivate cannabis in the United Kingdom.”

47. Mr Johnson submits that this is a case which falls into the category hypothesised in AAD and Others

_[[2022] EWCA Crim 106 at [108]; the finding of trafficking in the context of the extant offence is based on](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
hearsay evidence from the Applicant, most significantly, the Applicant's witness statement dated 12th
October 2021. The SCA itself noted that the account was “not particularly detailed”, although finding it was
“plausible and consistent”.

48. BNN attended the hearing before us with an interpreter. He has remained throughout with no visible
sign of distress in the court room surroundings. At the outset of the hearing we heard extensive
submissions from Mr Kherbane as to why the Applicant should not be required to give evidence regardless
of any accommodation that could be made in terms of special measures, and despite the indication from
Mr Johnson as to the narrow confines of the topics he intended to cover, as indicated above, and, what is
more, that BNN's evidence may result in the Respondent conceding that it was not in the public interest to
prosecute and nor to maintain opposition to the application and appeal.

49. Nevertheless, Mr Kherbane tenaciously argued that BNN's evidence on these matters was
unnecessary in the context of :(i) the known facts of the offence and the domestic circumstances in which
he was observed to be living at the time of his arrest; (ii) the transcripts of the court hearings at which plea
was discussed and ultimately tendered; and (iii) that it would be detrimental to the applicant's well-being
having regard to the psychologists reports referred to in (b) and (d) of paragraph [44] above.

50. We were not persuaded by Mr Kherbane's submissions in these regards. As to the facts of the offence,
the Applicant made no comment in interview, and his subsequent account of how he came to be housed in
the East Midlands lacked detail. Once in police custody there was no apparent good reason for him to
refuse to divulge the PIN to the mobile phones.

51. As to the Court trial process, the contents of the prosecution opening, plea in mitigation and
sentencing remarks do not supply the deficiencies of information or corroborate the assertions in BNN's
witness statement as to how he came to make his plea. The witness statement dated 17 October 2022 is


-----

at odds to Counsel's response to McCook/ waiver of privilege inquiries which seeks to provide a context to
the transcripts of the PTPH and hearing at which the plea was tendered.

52. As to vulnerability, the report of Dr Chisholm, a clinical psychologist, whose opinion that BNN
consistently presented with symptoms of PTSD explicitly based on being beaten and exploited and met the
diagnostic criteria for a Major Depressive Episode, subsequently agreed by the Helen Bamber Foundation
and Dr Angeliki Argyriou, do not suggest that he is unfit to give evidence or would be unable to give
evidence on the issues indicated above. The reports indicate his apparent difficulties or distress to be in
relation to his recall of the traumatic events of his actual trafficking from Vietnam. His 'memory problems'
were assuaged by a specified method of interview.  That he is said to be vulnerable by his previous
experience of trafficking is based almost entirely on the Applicant's own account. As indicated in _AFU_

_[[2023] EWCA Crim 23 at [90] and the authorities cited therein, “The extent to which expert evidence can be](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
of assistance when assessing an account of trafficking will likely depend on the extent to which it relies on
the accuracy of an individual's untested account of events”.

53. Overall, we regarded aspects of the information given by BNN and upon which this application centres
to be “unsatisfactory and untested”. Consequently, we indicated to Mr Kherbane that it would be
“preferable” that BNN give evidence to assist with the proper resolution of the issues in this appeal. (See
_AAD @ [108].) BNN declined to do so._

54. We were left in little doubt that this had been his settled intention prior to his attendance at Court. We
draw no adverse inference from this refusal but are obviously unable to obtain clarification of lacunae or
apparent inconsistencies in his account to assist our consideration of the submissions made on his behalf.

Grounds 1 and 2

Equivocal plea

55. This Court in R v Tredget _[[2022] EWCA Crim 108; [2022] 4 WLR 62, identified three categories of case](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
in which an appellant can submit that, notwithstanding a guilty plea, his or her conviction is unsafe,
including as is relevant to grounds 1 and 2 in this case, where it is asserted that the plea was equivocal or
vitiated by improper pressure. The “circumstances relied on by the appellant need to be established by him
or her.”

56. We have not benefitted from hearing the Applicant give evidence in amplification of his statement of 20
October 2022 as to what happened at the time of entering his guilty plea. The transcripts do not establish
that the Applicant's plea was equivocal. No caveat was stated at the time of plea, and defence Counsel
explicitly mitigated on the basis that the exploitation of BNN fell “short of a defence.” We find no reason to
disregard defence counsel's response to the McCook/ waiver of privilege inquiries as indicated above.

[57. This Court in BEP [2022] EWCA Crim 1881 dealt with similar circumstances as appertain here. In that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69YY-WV63-RRM0-74SM-00000-00&context=1519360)
case there was no suggestion that the defendant had not been advised of the possible section 45 defence,
but he wished “to get as much credit as possible for a guilty plea.” The fact that the applicant in that case,
as did the applicant in this, maintain his account of coercion and exploitation in mitigation and received a
correspondingly reduced sentence, does not establish that he equivocated in what is an objectively
unambiguous and deliberate plea of guilty. The applicant had a retained freedom of choice to continue to
trial.

58. There is nothing in this ground.

Improper pressure

59. Mr Johnson accepts that it is “at least arguable” that pressure was placed on the Applicant to plead
guilty during the PTPH. We agree. It was not appropriate for the Judge to give an unsolicited indication of
sentence not least that it seemed 'wide of the mark' in accordance with the Sentencing Guidelines; see
_Rees_ _[2023] EWCA Crim 487 at [29]. However, the Applicant did not enter a guilty plea then, or even very_
shortly thereafter. If he had, it would be essential to understand whether this had “narrowed the proper
ambit of his freedom of choice”: Nightingale _[[2013] EWCA Crim 405 at [16].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_


-----

60. In the absence of oral evidence from the Applicant, we are unable to be satisfied that there was a link
between what was said at the PTPH and the decision months later to enter a plea. The endorsement he
signed makes clear that the decision to make guilty was his decision. The late Mr Anning's account is, the
Respondent submits, clear and reliable, and demonstrates that the decision to enter a guilty plea was
freely made. We find no reason to disregard defence counsel's response to the McCook inquiries.

61. This ground is unarguable.

Ground 3

Abuse of process

62. “The Crown Prosecution Service Guidance on **_Modern Slavery, Human Trafficking and Smuggling”_**
clearly defines the “Prosecutors Obligations” when deciding whether to prosecute a defendant who might
be a VOT or VOS under international law. Our reading of the CPS file, duly disclosed in these proceedings,
corroborates the several concessions realistically made by Mr Johnson that this Guidance was
“regrettably” not observed or applied by the reviewing lawyer. This ground is arguable, and we grant
permission to appeal.

63. First, the Applicant's potential status as a victim of trafficking should have been identified earlier in the
proceedings. There was factors indicative of trafficking present when the Applicant was arrested. The
Applicant should have been referred through the NRM to the SCA by the police pursuant to their duty
under section 52 of the 2015 Act. Second, the initial approach taken by the reviewing prosecutor focussed
on whether the section 45 defence had been raised, when Guidance required him to independently
consider whether the issue arose. Third, whilst the reviewing prosecutor had the issue of modern slavery
clearly in mind, the reviews then undertaken did not expressly follow the stepped approach required by the
Guidance and there was no direct reference to the policy.

64. In AFU this Court summarised at [113] two different approaches that the Court might take, depending
on how a case had been dealt with at first instance:

“The authorities emphasise that the decision to prosecute is ultimately for the prosecution, and not the
court. Where the prosecution has applied its mind to the relevant questions in accordance with the
applicable CPS guidance, it will not generally be an abuse of process to prosecute unless the decision to
do so is "clearly flawed" (see AGM at [12] and R v BYA _[[2022] EWCA Crim 1326 at [20]). The court does](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66KY-GB03-CGX8-00J1-00000-00&context=1519360)_
not intervene merely because it disagrees with the ultimate decision to prosecute: see AAD at [119].

However, if CPS guidance has been disregarded, such that the question of whether to prosecute has not
been properly considered (or considered at all), the court can intervene more readily: see AGM at [13] and

[56]. It will then be open to the court to consider the public interest question without trespassing on ground
which has been appropriately considered by the prosecution authorities.”

65. It is not, however, 'for the appellate court to substitute its own view, but rather to review the decision to
prosecute by reference to considerations of including those of rationality and procedural fairness': see AFU
at [117].

66. Mr Kherbane submits that BNN's history of exploitation, which he contends is appropriately traversed
and analysed in the CGD, corroborated by the circumstances in which the applicant was found to be living
in the premises on 19 March 2021 and relative low seriousness in the nature of the offence concerned
renders the decision to prosecute an abuse of process.

67. At the outset, we reject the argument that the offence was not serious per se. The extent of the
cannabis growth involved in this case was not de minimus.

68. We are not satisfied that the SCA decision survives detailed forensic examination. Absent oral
evidence from BNN we challenged Mr Kherbane on the source of certain of his submissions. Accordingly,
Mr Kherbane invited us to watch a video exhibit regarding the conditions in which BNN was living at the
time of his arrest. We did so, however, the Conclusive Grounds Determination in this respect is based


-----

upon the evidence of PO Kirt, who had been supplied details by officers attending the scene. We do not
agree that the hearsay description, upon which the SCA and Mr Kherbane relies, is portrayed in the video.

69. It does not appear to us that the video evidence is determinative of BNN being present under
compulsion or only of recent occupancy. There were several issues that call for an explanation. First, there
is indication of male and female footwear and significant quantities of underwear – some obviously recently
laundered and drying. There is a well-stocked fresh fruit bowl and a large number of canned drinks and a
thermos flask, several bowls and glasses. The living quarters are cramped, by reason of the utilisation of
the bedrooms and what had been the living room for cultivation of cannabis. The bedding is not sparse and
apparently clean. The kitchen is well provisioned with bowls, eating utensils, washing up liquids etc. The
outside toilet is clean and provisioned. The terraced house had front and back locking doors with the keys
in place. Whilst lack of physical constraint is not determinative of enforced compulsion and restriction
through fear of repercussions, the failure of BNN to bolt and secure the doors internally does not
corroborate his account that he stayed within the premises fearful of robbers.

70. Further, as regards the two telephones in BNN's possession, the Conclusive Grounds decision states:
“However, Leicester Police stated that there was 'nothing deemed of evidential value for either the offence
of cultivation of cannabis or with regards to slavery of the defendant on either of the mobile phone devices”
(Additional information). This is an inaccurate summary of the information contained in the extract from the
Crime Report. One telephone was accessed manually and revealed ingoing and outgoing calls. The SIM
card of the second mobile phone did not reveal any pertinent evidence, however, the excerpt also records
“As the iPhone has a passcode that the suspect has refused to provide, I am unable to complete a triage
on this phone.”

71. Finally, the SCA were unaware of BNN's presence in Sheffield in May 2020. This issue may of course
be a red herring but does not sit easily in BNN's account of his movements in the UK.

72. Neither the 2019 FTT decision nor the documents in [44] above aid our consideration of the issue of
abuse of process.

73. The psychological reports proceed based on BNN's self-asserted participation in the offence in 2021
under coercion. The fact of his diagnosed PTSD and 'vulnerability' may weigh in the public interest balance
but are not necessarily indicative of “extremely diminished culpability” as Mr Kherbane suggests.

74. As explained in R v V [2020] EWCA Crim 1355, at [25]:

“as is clear from the terms of section 45, the statutory defence does not arise automatically on proof that a
person was the victim of trafficking. Neither the international conventions relating to human trafficking, nor
our domestic legislation affords automatic immunity from prosecution in these cases. The effect of both
international and domestic legislation is that a number of questions of fact must be addressed to determine
whether the defence is satisfied in a case where there is credible evidence that the defendant is a victim of
trafficking. These are, by reference to the domestic provisions: … [section 45 (1) (b) – (d)]

In other words, the degree of compulsion on the defendant and the alternatives reasonably available to him
or her are critical features of the analysis. The offence must be committed as a direct consequence of or in
the course of trafficking or slavery and the criminality must be significantly diminished or effectively
extinguished because no realistic alternative was available but to comply with the dominant force of
another."

75. We do not accept Mr Johnson's submissions that a prosecutor is entitled to avoid making a decision
on 'public interest grounds' in any case in which there is an ambiguous factual position; see AFU at [138].

76. Nevertheless, examining the circumstances in this case, we agree with Mr Johnson that it is readily
apparent that all 'gardeners' are exploited to some extent by virtue of their position in the drug supply
chain. BNN was obviously 'vulnerable' because of his lack of status and Asylum Support funding which
may well have led him into criminality. However, this was a serious offence. BNN's ability to seek help for
his predicament arose from his length of time living independently in the UK, his association with and
experience of the Salvation Army, other charities and NHS services, his ability to travel independently as


-----

indicated by his trip to Sheffield, and use of the mobile phones in his possession. The Applicant's decision
not to pursue a section 45 defence is relevant. His lack of co-operation in the police investigation when in a
place of safety is pertinent.

77. Consequently, we see no reason to reject the Respondent's submission that a decision to prosecute
BNN regardless of the availability of a section 45 defence and bearing in mind all relevant factors in due
accordance with the CPS Guidance would be reasonable; see _Henkoma_ _[2023] EWCA Crim 808 at [38]_
and [39].

78. We are in no doubt that the conviction is safe. The appeal is dismissed.

**End of Document**


-----

# R v BNN

_[[2024] EWCA Crim 991](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6D37-0JB3-RRYT-732T-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 22/08/2024**

# Catchwords & Digest

**SENTENCE - LENGTH OF SENTENCE – WHETHER CONVICTION UNSAFE**

The Court of Appeal, Criminal Division, dismissed the defendant’s appeal against conviction. The
defendant, a Vietnamese national, had pleaded guilty on re-arraignment to one count of producing a controlled drug
of Class B (cannabis) and had been sentenced to nine months’ imprisonment which brought about his immediate
release from custody. There were three alternate grounds of appeal that the conviction was unsafe on the basis
that: (i) the defendant had entered an equivocal guilty plea; (ii) the defendant’s plea had been entered as a result of
undue pressure; and (iii) the Crown Prosecution Service (SCA) did not apply its own guidance on
on taking steps to investigate, gather relevant information and to await the SCA conclusion to decide whether to
prosecute a victim of trafficking properly. The court held that, on the ground of unequivocal plea, the transcripts did
not establish that the defendant’s plea had been equivocal. No caveat had been stated at the time of plea, and the
defence counsel had explicitly mitigated on the basis that the exploitation of the defendant fell ‘short of a defence’.
On the ground of improper pressure, in the absence of the defendant’s oral evidence, it was not satisfied that there
was a link between what was said at the Plea and Trial Preparation Hearing and the defendant’s decision months
later to enter a plea. On the ground of abuse of process, a decision to prosecute the defendant, considering all
relevant factors and following the CPS guidance, would be reasonable and would not constitute an abuse of
process. Accordingly, the conviction was safe.

# Cases considered by this case

R v Henkoma

_[[2023] EWCA Crim 808, [2023] All ER (D) 76 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68R8-41V3-RSCM-J4W2-00000-00&context=1519360)_
Considered

R v Rees

_[[2023] EWCA Crim 487, [2023] All ER (D) 64 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6887-D3F3-RRNV-23FS-00000-00&context=1519360)_
Considered


14/07/2023

CACrimD

19/04/2023

CACrimD


R v AFU 20/01/2023


-----

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

R v BEP

_[[2022] EWCA Crim 1881](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69YY-WV63-RRM0-74SM-00000-00&context=1519360)_
Considered

R v Tredget

_[[2022] EWCA Crim 108, [2022] 4 WLR 62](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
Considered

R v AAD and others

_[[2022] EWCA Crim 106, [2022] 1 WLR 4042](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
Considered

R v O

_[[2019] EWCA Crim 1389, [2019] All ER (D) 56 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W67-WPX2-D6MY-P3GR-00000-00&context=1519360)_
Considered

R v Nightingale

_[[2013] EWCA Crim 405, [2013] 2 Cr App Rep 69, (2013) Times, 26 March](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_
Considered

**End of Document**


CACrimD

04/11/2022

CACrimD

08/02/2022

CACrimD

03/02/2022

CACrimD

31/07/2019

CACrimD

13/03/2013

C-MAC


-----

