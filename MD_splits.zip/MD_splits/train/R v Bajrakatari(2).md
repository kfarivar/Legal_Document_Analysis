# R v Bajrakatari [2023] EWCA Crim 1117

Court of Appeal, Criminal Division

Males LJ, Holgate J, Hilliard J

31 August 2023Judgment

MS A SMART appeared on behalf of the Applicant.

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

LORD JUSTICE MALES:

1. On 9 March 2023, in the Crown Court at Cardiff before HHJ Parry, the applicant, Besnik Bajrakatari
(then aged 27) pleaded guilty to being concerned in the production of cannabis. He was sentenced to 16
months' imprisonment. His application for leave to appeal against conviction was refused by the single
judge and has not been renewed but the single judge noted that there may be valid grounds for an appeal
against sentence and therefore referred to the full court an application for an extension of time for leave to
appeal against the sentence.

**_The Facts_**

2. On 6 February 2023, police officers executed a warrant at Ebenezers, Bridgend Road in Bridgend in
South Wales. Ebenezers was a converted chapel that had previously been used as a carpet shop which
had closed some months before. The applicant was detained in the upstairs area of the property, which
was found to be a cannabis factory. Three of the rooms were being used to grow cannabis plants. One
room had 62 mature plants, another had 57 and a third, 27. All of these rooms we re-equipped with
lighting, a watering system and several carbon filters. Modifications had been made to each room to
maximise the growing potential and limit the scope for discovery of the operation. The electricity meter at
the address had been bypassed.

3. The applicant was arrested. He made no significant comment. Several phones were seized from the
property.  The applicant did not provide the PIN numbers so these could not be downloaded.  The
estimated yield of the cannabis to be harvested from the address was between some 4,000 and 12,000
grams. We are told that, based on current prices, the potential value of the cannabis was between
£16,000 and £62,000, although that seems a rather large range.


-----

4. The applicant was aged 27 at sentence and was of previous good character. He is an Albanian national
who is in this country illegally.

5. The judge said that the applicant was “the latest man to come from Albania and to cause harm here in
South Wales”. He noted that the applicant was making money and was able to pay privately for legal
advice. He said it was a significant operation although the applicant was a small cog acting effectively as a
gardener, although he did have a key to leave and was acting freely. He described the applicant as
performing a lesser role with an amount of cannabis which could have generated significant commercial
profit, so the level of harm fell into category 2 within the Sentencing Guidelines, giving a starting point for
sentence of 12 months, which was aggravated by the fact that electricity was bypassed. In view of the
applicant's plea, he gave him 25 per cent credit. He noted also that the applicant was to be sentenced as
not having committed any further offences but said that the sentences must be a warning to others
because “no doubt once you leave another will take your place”. He then imposed the sentence of 16
months' custody.

6. After his sentencing the applicant instructed new solicitors, who made an application for leave to appeal
against conviction, on the ground that the possibility of a defence under section 45 of the Modern Slavery
Act 2015 had not been properly investigated. The single judge refused leave to appeal on that ground,
which he regarded as hopeless. It appears to us that he was right to do so.  The applicant pleaded guilty
after being properly advised by the counsel who represented him at the PTPH and there are reasons for
thinking that such a defence would have faced considerable difficulty. In particular, the applicant had a key
to the property and could have left at any time. The element of compulsion was therefore lacking.

7. However, the single judge pointed out that there appeared to be valid grounds for an appeal against
sentence. He said:

“Although your current legal team had not raised it when submitting grounds of appeal against conviction, I
was troubled by the sentence imposed. The agreed starting point under the guidelines [category 2, lesser
role] was 1 year's custody. You were of previous good character and entitled to a 25% discount. The

Judge, to arrive at 16 months after a 25% discount must have taken a pre‑plea discount starting point of

about 22 months, almost double the starting point. The only aggravating feature identified by the judge was

the electricity was by‑passed, a specified aggravating factor under the guidelines but one almost inevitably

involved in category 2 cannabis production. The judge made no mention of your lack of previous
convictions. The Judge's other comments, that you were 'the latest man to come from Albania to cause
harm in South Wales' cannot have been used as an aggravating factor as being Albanian is not one, and
there was no evidential basis for treating South Wales as an area especially hard hit by illegal cannabis
grows [see the need for a proper basis for a finding of 'established evidence of community impact', in the
specified aggravating features in the guidelines and Criminal Practice Directions VII Sentencing:

Community Impact Statements, Archbold 5A‑358].

A prison sentence was inevitable but it is arguable the Judge passed too long a sentence.”

8. The single judge therefore referred the matter to the full court.

9. We agree with the single judge's observation regarding the length of the sentence. It is apparent that
the judge must have taken a sentence in excess of 20 months as the sentence which he would have
imposed after trial. However, while that is within the range identified in the Sentencing Guidelines for an
offence of this nature, the judge did not explain how he arrived at the sentence, and it is not easy to see
how he could have done so. The starting point within the Guidelines for a category 2 lesser role case,
which is what this was agreed to be and is the basis on which the judge sentenced the applicant, is one of
12 months' imprisonment.  The judge expressly noted that this was the starting point. The only
aggravating feature which he identified was the fact that electricity was bypassed. We would accept that
this could have justified some modest increase from the starting point although it is an almost inevitable
feature of such a case. Moreover, some reduction was required to take account of the absence of any
previous convictions. The judge mentioned this but did not explain how it affected his sentence.


-----

10. It appears that the judge considered that an element of deterrence was necessary. Although we can
understand his frustration, there is no basis for thinking that the position in South Wales is different from
elsewhere in the country, or that the prevalence of this kind of offending was not taken into account by the
Sentencing Council when it promulgated the Guideline. If sentences are going to increase sentences
above the level set out in the Guideline, in order to include an element of deterrence, there must be a
sound evidential basis on which to do so. As the Guideline points out, a community impact statement will
be of assistance in such a case. Overall, we consider that the appropriate sentence, in accordance with
the Guideline, would have been 1 year's imprisonment after trial, so that the sentence after taking account
of the applicant's plea at the PTPH would be one of 9 months' imprisonment.

11. In these circumstances, we grant the necessary extension of time. We grant leave to appeal against
sentence. We quash the sentence of 16 months' imprisonment imposed by the judge and we impose in its
place a sentence of 9 months' imprisonment. It has not been suggested that this should be suspended,
and, in any case, the applicant has now served the custodial element of this sentence.  The ancillary
orders made by the judge are not affected. The prison authorities will need to check whether there is any
constraint on the applicant's immediate release due to immigration considerations in view of the fact that he
is not legally in this country, and it is likely, we understand from Ms Smart, who has represented him this
morning, that he will be deported.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

