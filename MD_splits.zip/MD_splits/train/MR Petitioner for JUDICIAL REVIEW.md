# MR Petitioner for JUDICIAL REVIEW P165/19[2019] CSOH 52

Court of Session (Outer House)

FURTHER NOTE OF REASONS BY LORD BRODIE

Pursuer: Caskie; Drummond Miller LLP (for Jain, Neil & Ruddy, Solicitors, Glasgow)

Defender: R MacLeod; Office of the Advocate General

9 July 2019

**FURTHER NOTE OF REASONS BY LORD BRODIE**

[[1]     This petition for judicial review was put before me for decision, in terms of RCS 58.7 and section 27B of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5S2R-9F71-DYCN-C0TP-00000-00&context=1519360)
Court of Session Act 1988, as to whether permission to proceed should be granted. In a previous Note of Reasons I
indicated to parties that I was minded to refuse permission as I was not then satisfied that the petitioner had real
prospects of success in establishing that the decision of 20 November 2018 which she sought to review was
unlawful. I therefore ordered an oral hearing in order to be addressed on the point, as envisaged by the Practice
[Note (see Dinsmore v Scottish Ministers [2019] CSOH 18).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V1V-G1V2-D6MY-P04G-00000-00&context=1519360)

[2]     That hearing was held on 18 June 2019 when I was addressed by Mr Caskie, Advocate, on behalf of the
petitioner and Mr Roderick MacLeod, Advocate, on behalf of the respondent who is the Advocate General acting on
behalf of the Secretary of State for the Home Department. Having considered their respective submissions, I
decided to refuse permission for the petitioner's application for judicial review to proceed. My reasons are as
follows.

[3]     The petitioner is Ms MR. By way of petition she seeks to review the decision of the Secretary of State
Home Office, intimated by letter dated 20 November 2018, that the petitioner is not a victim of human trafficking.
The respondent has lodged answers to the petition. In this Note I use the expression “respondent” to include the
official of the Competent Authority who made the decision of 20 November 2018.

[4]     The plea-in-law of the petition is: “The decision the petitioner is not a victim of trafficking being unlawful et
_separatim irrational reduction should be granted as sought”. Having heard Mr Caskie, I understood the petitioner to_
present a reasons challenge rather than a Wednesbury challenge, albeit that as Mr Caskie observed, where there
are no reasons or inadequate reasons for a decision, the decision can be regarded as an irrational one. The
petitioner's position is set out in statement 11:

“…no reasonable Secretary of State could conclude other than that the petitioner meets the second of the
criteria for being a victim of human trafficking. In any event the Secretary of State has failed to provide any
reasons whatsoever in respect of the conclusion that the behaviour to which the petitioner was subjected was
not in fact deception, placing her in a position of vulnerability and abusing their power over her. The failure to
provide adequate reasons to permit the informed reader to understand the basis upon which the Secretary of
State reached the conclusion that he did, means that the decision is an unlawful one.”

[5]     The test for permission which is applicable in a case such as the present is set out in section 27B of the
1988 Act as follows:


-----

“27B Requirement for permission

(1) No proceedings may be taken in respect of an application to the supervisory jurisdiction of the Court unless
the Court has granted permission for the application to proceed.

(2) Subject to subsection (3), the Court may grant permission under subsection (1) for an application to
proceed only if it is satisfied that—

(a) the applicant can demonstrate a sufficient interest in the subject matter of the application, and

(b) the application has a real prospect of success.”

[6]     The expression “real prospect of success” is to be understood by reference to _Wightman_ v _Advocate_
_[General 2018 SC 388 at paragraph 9.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDH2-8T41-D00R-00000-00&context=1519360)_

[7]     Attached to the respondent's decision letter is an annex giving reasons for his decision. It is headed
“Conclusive Grounds Consideration Minute”. It includes the information that the petitioner entered the UK on 19
August 2003 with a multiple visit visa valid until 12 February 2004. The petitioner made no immediate attempt to
regularise her continuing stay in the UK. She worked for a family of Indian origin until 2010 in circumstances which
is characterised as “domestic servitude” in the petition. She submitted a further Leave to Remain application on 22
January 2011 (there would appear to have been an earlier application in 2008). This was refused. I have not
noticed any reference to further contact with any relevant authority before July 2016 when the petitioner claimed
that her entry into the UK and her history there until 2010 had constituted human trafficking. On 27 July 2016 the
respondent, as the Competent Authority, acting under the National Referral Mechanism in respect of non-European
Economic Area nationals, decided that there were reasonable grounds to believe that the petitioner had been a
victim of human trafficking. That “reasonable grounds decision” gave rise to certain obligations on the part of the UK
towards the petitioner, with a corresponding degree of protection, by virtue, _inter alia, of the Council of Europe_
Convention on Action Against Trafficking in Human Beings (“ECAT”) (see ECAT articles 10(2), 12 and 13; _MS_
_(Pakistan) v Secretary of State for the Home Department [2018] 4 WLR 63at paras 20 to 22)._

[8]     With a view to the implement of its international obligations under, inter alia, ECAT, the UK government has
instituted the National Referral Mechanism. The respondent has issued guidance to officials. At the time which was
relevant to consideration of the petitioner's status that guidance included Victims of human trafficking – competent
_authority guidance, 24 October 2013 (the “2013 Guidance”) which made provision for decision-making as to_
whether an individual was a “victim” of trafficking in human beings as defined by article 4 of ECAT (the current
guidance would appear to be Victims of modern slavery - competent authority guidance, 29 April 2019). Provision
was made in the 2013 Guidance for a “conclusive grounds decision” to finally determine the status of those in
respect of whom there were reasonable grounds to believe that they were the victims of trafficking. The decision of
20 November 2018 which the petitioner seeks to challenge was a “conclusive grounds decision”. An adverse
conclusive grounds decision is not subject to appeal. Nor can it be made subject of an indirect challenge in the
course of an appeal in terms of section 82(1) of the Nationality Immigration and Asylum Act 2002, as amended,
against a removal direction, other than in limited circumstances (MS (Pakistan) para 69). Thus if the decision of 20
November 2018 is to be challenged by the petitioner it would seem that it must be by judicial review. The
respondent does not suggest otherwise.

[9]     A conclusive grounds decision that a person has been a victim of trafficking does not give that person an
automatic right to remain in the UK but article 14 of ECAT provides that a person found to have been a victim shall
be issued with a residence permit if the competent authority considers their stay is necessary owing to their
personal situation, and further provides that if a victim submits an application for another kind of residence permit
regard should be had to the fact that she has held a residence permit issued in conformity with article 14.
Accordingly, that a person has been found to have been a victim of trafficking will be relevant if that person applies
for discretionary leave to remain in the UK (see Home Office, _Discretionary leave considerations for victims of_
**_modern slavery_** version 2.0 of 10 September 2018). It follows that the petitioner has a sufficient interest in


-----

challenging (by an application for judicial review) the decision of 20 November 2018 that she is not a victim of
trafficking.

[10]     Whether the petitioner is a victim of trafficking is a mixed question of fact and law in that it involves the
application of legal criteria to the primary facts in an instant case with a view to determining whether the instant
case meets the legal criteria. That may involve an element of assessment or appreciation. In the present case, the
respondent has accepted the veracity of the petitioner's account, as summarised in statements 5 and 6 of the
petition, of how she came to enter the United Kingdom and her circumstances while working there. The question for
the respondent therefore came to be whether the petitioner was to be regarded as a victim of trafficking in human
beings as that expression is defined in article 4 of ECAT.

[11]     In terms of article 4,"Trafficking in human beings" shall mean the recruitment, transportation, transfer,
harbouring or receipt of persons, by means of the threat or use of force or other forms of coercion, of abduction, of
fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of exploitation.
Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of organs.

[12]     The respondent analysed human trafficking as so defined as having three components: an action, which is
achieved by a means, for the purpose of exploitation which shall at a minimum have certain features. He accepted
the action; there had been recruitment. He did not accept the means and he did not accept that the degree of
exploitation included any of the minimum features. As I understood Mr Caskie, while he might have argued that no
reasonable decision-maker could have concluded that the petitioner's account did not demonstrate relevant means,
he accepted that it was open to a reasonable decision-maker to conclude that the petitioner's account did not
amount to her having been placed in a position of servitude (or any other of the minimum features of exploitation).
However, he did argue that on any view the petitioner's account placed her case on the margins of trafficking; in
other words she had been recruited, that recruitment had involved deception and fraud and that she had been
exploited by being placed in a condition which could reasonably be regarded as that of domestic servitude, as
opposed to being the employee of bad employers. In these circumstances, Mr Caskie submitted the respondent
was bound to give particularly clear reasons for his decision, at least if the decision was to be on the bad employers
side of the line. It was Mr Caskie's submission that the respondent had failed to do so. Mr MacLeod for his part
submitted that the respondent's reasoning was entirely adequate.

[13]     It is uncontroversial that, generally speaking, a decision-maker must give proper and adequate reasons for
his decision that deal with the determining issues in an intelligible way. The decision must leave the informed reader
in no substantial doubt as to what the reasons for it were. However, so long as the reasons are adequate the
decision-maker is entitled to express them concisely. When considering the adequacy of reasons, it is necessary to
take into account the nature of the decision, the context in which it has been made, the purpose of the reasons and
the context in which they are given: South Bucks District Council v Porter (No 2) [2004] 1 WLR 1953at paragraph

[36], _Uprichard_ v _Scottish Ministers_ 2013 SC (UKSC) 219 at paragraphs [44] and [47] (both cases on planning
decisions but of more general application).

[14]     In order to make the conclusive grounds decision of 20 November 2018 the respondent had to consider
whether the petitioner's account of the facts brought her within the definition of a “victim” of “trafficking in human
beings” which is provided by article 4 of ECAT. In that the wording of the definition is in rather broad terms that
involved an element of judgement as to the proper exercise of which there may be room for a difference in view.
Particularly when it comes to determining whether a certain condition amounts to “servitude”, the judgement is one
of degree. There is no suggestion of error in law on the part of the respondent. In my opinion, by contrasting the
definition with what he sees as the material facts, the respondent provided adequate and intelligible reasons for his
adverse decision. He did not consider that the petitioner's recruitment had been by any of the prohibited means and
he did not consider that the circumstance of her work between 2003 and 2010 constituted servitude and he explains
why in the pre-penultimate, penultimate and final pages of the Conclusive Grounds Consideration Minute. That
explanation is in the form of reiterating the aspects of the petitioner's narrative which, in the respondent's view, point


-----

away from the means and purpose elements in the trafficking criteria. I find it difficult to see what more the
respondent might be expected to do when making a decision of this sort.

[15]     Of course when deciding on whether to grant permission to proceed the Lord Ordinary is not being asked
to reach a substantive decision. In order to grant permission he must merely be satisfied that the application can be
said to have real prospect of success. I have not been so satisfied.

**End of Document**


-----

