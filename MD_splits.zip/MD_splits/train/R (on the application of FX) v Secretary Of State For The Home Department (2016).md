# R (on the application of FX) v Secretary Of State For The Home Department
 (2016) [2016] EWHC 1908 (Admin)

QBD, ADMINISTRATIVE COURT

CO/3896/2015

Dove J

22/02/2016

CO/3896/2015

**[Neutral Citation Number: [2016] EWHC 1908 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KDN-W891-F0JY-C1DX-00000-00&context=1519360)**

**IN THE HIGH COURT OF JUSTICE**

**QUEEN'S BENCH DIVISION**

**THE ADMINISTRATIVE COURT**

Royal Courts of Justice

Strand

London WC2A 2LL

Monday, 22 February 2016

**B e f o r e:**

**MR JUSTICE DOVE**

**Between:**

**THE QUEEN ON THE APPLICATION OF FX**

**Claimant**

v

**SECRETARY OF STATE FOR THE HOME DEPARTMENT**

**Defendant**

Computer‑Aided Transcript of the Stenograph Notes of

WordWave International Limited

Trading as DTI


-----

8th Floor, 165 Fleet Street, London EC4A 2DY

Tel No: 020 7404 1400 Fax No: 020 7404 1424

(Official Shorthand Writers to the Court)

**Mr Chris Buttler (instructed by Deighton Pierce Glynn Solicitors) appeared on behalf of the Claimant**

**Ms Catherine Rowlands (instructed by the Government Legal Department) appeared on behalf of the Defendant**

(Ms Emma Dring appeared at the read‑out judgment)

J U D G M E N T

(Approved)

Crown copyright©

1. MR JUSTICE DOVE: The claimant is a national of Ethiopia and she seeks judicial review of the defendant's
decision of 20 May 2015 that there are no reasonable grounds to consider that she has been the victim of
trafficking.

2. The circumstances of her case are as follows. The claimant was married with three children when she lived in
Ethiopia. She is a Muslim and began to experience persecution on account of her religion, including in particular an
occasion where she was beaten and mistreated. She and her husband determined that she would have to leave
Ethiopia. They found an agent and arrangements were made for her to travel to Italy. Her undisputed account of
events in relation to her case is reported in a National Referral Mechanism form, which was compiled by a Salvation
Army minister to whom the claimant had been referred by the national referral process. The form provided as
follows:

i. "On March 11th 2014 I travelled with my own passport on a lane ticket that the brokers had arranged to Italy and
I arrived at the airport and a man named Sulaman met me at the airport and took me to his house. At the airport he
took my passport saying that he needed it to organise the next part of the journey. He was not good, he took me to
his house but though I had food and drink and a toilet I was locked in my room. This was over a week. The only
other time my door was opened was when he allowed one of his friends a key to my room and he became my pimp
and made me a business lady. When his friend came in the room he tried to make me drink alcohol but I don't drink
so they gave me juice. They pulled out a knife and told me not to scream and they raped me (this took [FX] a lot of
_effort to say asking if she needed to say and crying intensively)._

ii. Pretending to help me Sulaman said he could see my heart pain in this situation and said that he had arranged
for me to go to Holland. On the 18th March I flew to Holland on a red and white airline. Sulaman organised
everything only giving my passport at the airport telling me that someone would meet me at the other end.

iii. In Holland a man names Abdullah approached me and asked if I was [FX] and I told him I was. I was taken to
his home and he saw that I was very emotionally sick from the experience and kept my passport but took me to the
Holland immigration office to try and claim asylum in Holland. At this office I was fingerprinted and it was found I
had a visa for Italy and so was told I would be sent to the camp and then from there I would be returned to Italy.
The camp was in Dorenta. ...

iv. I was in the camp till September but during this time a man called Wede Koreneal said he would help me get to
Canada but first we would have to go to France where he could link me up with people who could help me. I left the
camp with him and took a train to France. I cannot remember seeing any place names but when [we] got off the

train we were in lots of trees 'jungle' and walked for 1‑2 hours and then arrived on a camp where I was invited to

stay until the people came who would help me. I was scared as there was nothing else about there. I was given a
tent on my own. Kashi was the leader and on that first day I found out that they were bad people as they came as a
group and when I tried to escape they grabbed me and I have scars on my body because of their grabbing and they


-----

watched on as the leader raped me. For the next 6 months I was raped whenever they were drunk by any of the
men in the camp. I cannot say it was every day but it felt like it was most of the time.

v. (At this point [FX] self harmed by hitting herself with her hand on her forehead hard and telling me she did not
_like me through scream crying, I offered to stop but we kept going to finish story.)_

vi. After 6 months even though my religion forbids I tried to end my life. Kashi then organised for me to go to
Canada through UK. First I had to go on a lorry which I was put on in the middle of the night. When we were taken
out of the lorry I asked where we were and they said UK. At this point I had had enough and I asked for the police.
I was pointed in the direction of the reception of the lorry park and they called the police."

3. The form which was completed contained a list of potential factors which were relevant to trafficking. The
questionnaire was completed by the Salvation Army minister as follows:

i. "General indicators

ii. ...

iii. 2. Expression of fear of anxiety ‑ Yes

4. Signs of psychological trauma (including Post Traumatic Stress Disorder) ‑ Yes

5. Injuries apparently a result of assault or controlling measures ‑ Yes

6. Evidence of control over movement either as an individual or as a group ‑ Yes

7. Restriction of movement and confinement to the workplace or to a limited area ‑ Yes

8. Passport or documents held by someone else ‑ Yes

9. Lack of access medical care ‑ Yes

10. Limited social contact ‑ Yes

11. Limited contact with family ‑ Yes

i. 17. Being placed in a dependency situation ‑ Yes."

12. In a separate part of the form, there was a similar questionnaire to be answered in relation to sexual
exploitation. Again, the Salvation Army minister completed this part of the form as follows:

i. "Indicators of sexual exploitation

ii. 7. Person subjected to crimes such as abduction, assault or rape ‑ Yes."

13. On arrival in the UK on 21 February 2015, the claimant claimed asylum and she was made the subject of a
screening interview. In the course of that exercise, she stated as follows:

i. "3.4. Is there anything else you would like to tell me about your physical or mental health?

ii. I have suffered physical torture in ETH and I have been raped many times in the jungle.


-----

iii. 7.1. Have you been subject to any forced work or other type of exploitation in your country of origin, en
**route or within the UK?** _If answer is YES, please use continuation sheet to give brief details that can be used for_
_an NRM referral (who/where/what/when/how)_

iv. ETH physical torture. Europe I was raped many times in Calais. I was treated like a toilet."

14. In relation to that last question, it will be evident from the quotation that there is a question on the form which
prompts the interviewer to obtain further brief details for the purposes of the National Referral Mechanism process,
and a continuation sheet is provided on the form for that further material to be noted upon. No further details were
obtained from the claimant.

15. Against the background of this material and other information which was obtained from government and
international sources in Italy and the Netherlands, the defendant proceeded to make a reasonable grounds
decision. In relation to that decision there is both a minute and a decision letter. For the purposes of this judgment
I propose to refer exclusively to the minute as it is fuller in terms of its text and reasoning. There is no distinction
whatsoever between the recording of the decision in either the minute or the decision letter.

16. From the minute, it appears that the claimant claimed asylum initially in the Netherlands on 26 March 2014.
Whilst initially she had not mentioned to the Dutch authorities any involvement with Italy, in a later interview with
Dutch immigration officials she confirmed that she had travelled through Italy and thence onto Amsterdam. She
stated in that interview that she had been drugged and raped whilst she was in Milan. The Dutch authorities
therefore established that she had travelled to Italy with an Italian visa, and thus, on 19 May 2014, Italy accepted
responsibility for the claimant. The claimant then absconded whilst she was in the Netherlands and therefore could
not be returned to Italy.

17. The minute goes on to record the substance of the decision reached in relation to the claimant in the following
terms:

i. "It is considered that the claimant's version of events appears to support a narrative of an opportunistic crime of
rape at the hands of people smugglers, rather than human trafficking for the specific purpose of sexual exploitation.
Undoubtedly, the claimant has found it extremely traumatic to speak of the events in Italy and in France; however
the information clearly supports a human smuggling rather than a trafficking motivation and purpose. This is also
supported by the fact that the second man involved in the people smuggling network ('Abdullah') did not seek to
exploit her and brought her to the Dutch authorities so that she could claim asylum.

ii. The facts of the claimant's case have been considered in line with the above definition of trafficking in order that
a Reasonable Grounds decision can be made. As noted above, it is considered that the claimant has provided an
internally consistent account and that any variances in her account can reasonably be accounted for on the
evidence available, even at the low threshold of 'I suspect but cannot prove'. The narrative is almost certainly that
of a vulnerable woman horribly abused by opportunistic criminals. The claimant has undeniably had great difficulty
in recounting the traumatic events of the crimes committed against her in Milan, Italy and in Calais, France;
however these horrific crimes are not themselves indicative of trafficking for sexual exploitation, which is why we
need to look at whether her experiences meet the Convention definition of human trafficking.

iii. There are considered to be six sets of movements, which might be considered relevant to the claimant's human
trafficking claim.

iv. I shall consider the claimant's experiences in Italy, the Netherlands and France in light of the trafficking
definition.

v. Movement from Ethiopia to Italy and from Italy to the Netherlands

vi. Firstly, there are three reported movements involving Italy.

2. Movement from Ethiopia to Milan, Italy (11‑12 March 2014).


-----

3. Movement within Italy (Airport to agent's home 'Sulaman') (12 March 2014). Movements numbered 1, 2 and 3
appear to have been made to facilitate the claimant's paid travel from Ethiopia to Canada via the UK.

4. Movement from Milan, Italy to Amsterdam, the Netherlands ('organised by Sulaman') (18 March 2014).

i. Action ‑ part 'a'

ii. In order to be considered to meet part 'a' of the Convention definition, the claimant must have been subjected to
an act of recruitment/transportation/transfer/harbouring or receipt. The subject was transported from Ethiopia to
Italy and subsequently harboured in Italy by the agent, thus fulfilling part 'a' of the trafficking decision.

iii. Means ‑ part 'b'

iv. In order to be considered to meet part 'b' the claimant must have been
recruited/transported/transferred/harboured/received:

v. 'by means of threat or use of force or other form of coercion/of abduction/of fraud/of deception/of abuse of
power/of a position of vulnerability/of giving or receiving payments or benefits to achieve the consent of the person
having control over another person'.

vi. As the subject paid for the facilitation of her travel from Ethiopia to Europe and did not do this under direct
coercion, the 'means' part of the definition cannot be wholly confirmed. However, it could be argued that the
claimant was in a position of vulnerability as a woman on her own in a foreign country dependent on agents. It is
therefore considered that (erring on the side of caution) the claimant meets part 'b' of the human trafficking decision
for the movement from Ethiopia to Italy and movement within Italy.

vii. Purpose ‑ part 'c'

viii. In order to be considered to meet part 'c', the claimant must have been subjected to an act of
recruitment/transportation/transfer/harbouring or receipt for the purpose of exploitation. The purpose of the
movements described above cannot be verified as having been for the purpose of exploitation. It is therefore
considered that the claimant does not meet part 'c' of the definition for movement from Ethiopia to Italy and within
Italy.

ix. Movement from the Netherlands to France

x. The final set of movements were made by the person Wede Koreneal from the Netherlands to France and the

movement by 'Kashi' from Calais, France ('Jungle') to the UK (20‑21 February 2015). These movements were

wholly unconnected to the smuggling facilitation from Ethiopia to Italy and from Italy to the Netherlands.

xi. Action ‑ part 'a'

xii. In order to be considered to meet part 'a' of the Convention definition, the claimant must have been subjected to
an act of recruitment/transportation/transfer/harbouring or receipt. The claimant was subjected to an act of
transportation, although this was voluntary, it could be considered as fulfilling part 'a' of the Convention definition.

xiii. Means ‑ part 'b'

xiv. In order to be considered to meet part 'b' the claimant must have been
recruited/transported/transferred/harboured/received:

xv. 'by means of threat or use of force or other form of coercion/of abduction/of fraud/of deception/of abuse of
power/of a position of vulnerability/of giving or receiving payments or benefits to achieve the consent of a person
having control over another person'.


-----

xvi. As the subject voluntarily entered into the facilitation of her travel from the Netherlands to France and from
France to Canada via the UK and the claimant did not do this under coercion the 'means' part of the definition
cannot be confirmed. The claimant was not abducted, potentially deceived, nor forced to provide consent out of a
position of vulnerability, nor did she give or receive payments or benefits to achieve the consent of a person having
control over another person.

xvii. It is, therefore, considered that the claimant does not meet part 'b' of the definition for this part of her
experiences.

xviii. Purpose ‑ part 'c'

xix. In order to be considered to meet part 'c' the claimant must have been subjected to an act of
recruitment/transportation/transfer/harbouring or receipt for the purpose of exploitation.

xx. The purpose of the latter movements described above cannot be confirmed as being for the purpose of
exploitation.

xxi. The claimant was likely the victim of horrific opportunistic crimes committed against her by 'Sulaman' and his
friend, and again later by 'Kashi' and the other men, whilst she was staying at the camp in Calais, France, however
again the claimant was not being trafficked specifically for this purpose."

18. Subsequent to the decision which was reached and recorded in the form of the minute from which I have just
quoted, further evidence has been garnered in support of the claimant's case. This material was not relied upon by
Mr Buttler, who appears on behalf of the claimant, directly in relation to the decision because, as he was keen to
point out correctly, none of this material was before the decision maker. It is, however, relied upon by him as being
relevant to the severity of the claimant's mental health symptoms and supportive of his submission that there was a
necessity for further time to be afforded to her in order to enable her to overcome her symptoms and achieve a
psychological recovery so as to assist her in making her case in respect of her claim to having been trafficked.

19. In brief, the further evidence subsequent to the decision is as follows. Firstly, there is a witness statement from
the claimant's solicitor which explains the severe distress which was exhibited by the claimant whilst her solicitor
was taking her instructions. At one point, the claimant started to slap her face with her hand very hard. Such was
her solicitor's concern about the distress that taking the statement was causing that she stopped taking instructions

and brought the statement‑taking to a close.

20. The second piece of evidence is a letter which was written to the defendant by the claimant's GP. In that letter,
the claimant's GP observes as follows:

i. "I am writing in my capacity as GP to [FX]. She registered as our patient in April this year when she was
dispersed to Gloucester. She has been seen in the surgery three times. She came to us on mirtazapine, zopiclone
and olanzapine all of which are used to treat depression and anxiety. Since registering with us she has been seen
by the local mental health services who recommended an increase in her dose of mirtazapine. GARAS has also
being organising counselling for her to help her to come to terms with the fact that she was raped while in Italy as a
migrant from Ethiopia.

ii. I was very disturbed when she came to see me today asking me to give her something to help her die. This is
completely out of line with how she has presented to us previously when she has told us that she would never
contemplate suicide since it is against her religion.

iii. I understand that in recent days she has received notification that she is going to be sent back to Italy. This
notification is the trigger for the sudden deterioration in her mental health. She is terrified of being returned to the
place where she suffered such traumatic sexual abuse and she considers death a preferred option.

iv. She was highly agitated in the consultation, crying and tearing at her face with her nails so that she made
herself bleed. I had some difficulty in calming her down and persuading her that there was still hope and a future


-----

for her. I have prescribed her some diazepam tablets in the short term to manage her acute mental distress, but
clearly she needs much longer to pursue help through counselling so as to find healing from the trauma she has
suffered.

v. I consider that in these circumstances it would be highly inappropriate for her to be returned to Italy and I think
there is a real danger she will try to take her own life if this decision is not withdrawn."

21. The third piece of evidence is that the claimant was assisted whilst living in Gloucester by Gloucestershire
Action for Refugees and Asylum Seekers ("GARAS"). GARAS are the organisation that were referred to in the
letter from the GP. On 15 June 2015, GARAS wrote to the defendant in the following terms:

i. "[FX] presented herself as a very vulnerable woman who is desperate to find a safe place. She has disclosed to
me that she has been raped repeatedly in Italy and the Netherlands. She is still in shock about what has happened
to her and is very difficult to engage with, but occasionally expresses her hopelessness and her terror on being
deported to Italy. She is tearful most of the time and exists in a state of extremely low mood and frequently says
that she will be 'better to die'.

ii. I am keen that she seeks a medical examination regarding the sexual assaults, but at the moment she is too
traumatised to undertake this.

iii. I have referred [FX] for urgent counselling at GARAS and despite the waiting list one of the Counsellors has
been able to see her."

22. Prior to the decision under challenge in these proceedings, the claimant's claim to asylum had been certified by
the defendant on safe third country grounds on 9 April 2015 on the basis that she could be properly returned to
Italy. That decision is presently the subject of a separate judicial review and her solicitors in that case
commissioned a report from Dr Alison Battersby, who is a consultant psychiatrist. This is the fourth element of the
evidence obtained since the decision.

23. Dr Battersby elicited a consistent statement from the claimant in examination in relation to the history of her
circumstances. During her description of the events which occurred to her in Italy, the claimant had an intense
flashback whilst giving her account and struck herself hard across the face and became extremely distraught, crying
profusely. Having recounted events as they occurred to her in the Netherlands, she described her experience in
the Jungle in Calais in France in the following terms:

i. "She had a small tent and was introduced to a leader called Kashi. She told me that women didn't go there on
their own so she was very much the exception. She laughed when I asked about water, toilets and food and told
me there weren't any. She said that they just used what they could find and went to the toilet outdoors. She told
me that she was regularly raped whilst in the jungle in Calais. Kashi would rape her most but any other man that
wanted to would do the same especially after drinking. She said she couldn't remember how many times she had
been raped. She said that when men escaped to the UK new men would arrive and they would also rape her when
they wanted. She told me that every minute there felt like a week. She said that it was as though she was one of
the men's tools and they would pick her up and use her/rape her whenever they wanted. She told me that they
looked like human beings but they are like animals. The first day she had tried to resist the rape and in the struggle
had scarred her leg. She told me she had 'been defeated'. She repeated that they were animals several times ...
When asked about other rapes after the first she said that there were a lot more than this one. She confirmed that
all of the rapes had been vaginal. I asked why she didn't just leave the jungle and seek help from the authorities.
She stared straight at me and told me that I just didn't understand the situation. She asked where I thought she
could have gone. She explained that she wasn't allowed to leave and had been brought back. She was unsure of
where to go and who to seek for help. She was distrustful of everyone. She said she had no choice but to stay
there and wish for it to end. She got so desperate that despite her religious beliefs being strongly against suicide,
she took an overdose of paracetamol hoping that this would end her suffering. She was in a lot of physical pain but
had no access to medical care or a phone. She had no one who could take her to help. Someone saw she had
taken the pills and made her vomit. At this point she was allowed to leave and came to the UK."


-----

24. Following the examination, Dr Battersby diagnosed very severe post‑traumatic stress disorder and moderate

depressive disorder. The claimant's presentation was, she opined, "highly consistent" with someone who had
experienced sex trafficking. Given the severity of her symptoms, Dr Battersby's view was that the claimant would
need many months of counselling to forge a secure therapeutic relationship with her counsellor before she could be
comfortable discussing her experiences prior to coming to the UK. Dr Battersby explained that this would take
many months of highly specialised treatment. She stated:

i. "Having witnessed her reaction to discussing the traumatic events in my interview and read the other extreme
reactions she has had in the same circumstances, in my opinion, it is highly unlikely that taking a witness statement
about the sexual violence would be productive. I would also be of the opinion that it would not be ethical to try and
elicit further details of or ask her to repeat her account of traumatic experiences as it will be highly likely to result in

further significant self‑injury. I have prepared in excess of over 100 medicolegal reports on individuals who are

seeking asylum and I have not previously made this recommendation which indicates the extreme nature of her
response."

25. The law and policy

26. The Council of Europe Convention on Action against Trafficking in Human Beings contains within it the
following definition of trafficking at Article 4:

i. "Article 4 ‑ Definitions

ii. For the purposes of this Convention:

(a) 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of
the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve
the consent of a person having control over another person, for the purpose of exploitation. Exploitation shall
include, at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced
labour or services, slavery or practices similar to slavery, servitude or the removal of organs;

(b) The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph (a)
of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used..."

27. It was agreed by both counsel in the case firstly that this definition should be understood as having three
ingredients: first, the action which is defined as the "recruitment, transportation, transfer, harbouring or receipt of
persons". The second ingredient is the means: "the threat or use of force or other forms of coercion, of abduction,
of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments
or benefits to achieve the consent of a person having control over another person." The third element of the
definition under Article 4 is the purpose of the exploitation, which is further defined in minimum terms within the
express provisions of Article 4.

28. It was common ground between the parties, and in my view undoubtedly accurate, that to come within the
definition it is necessary to demonstrate all of the three ingredients, and that within each of the ingredients it is
necessary to establish one of the identified types of activity which is described. Thus it is necessary to establish
first whether any one of the identified actions has occurred to the potential victim; if it has, then in relation to that
action it needs to be demonstrated that it was achieved by one of the means; and then, in turn, for the purpose of
exploitation, in at least one of the forms identified within the definition.

29. Guidance is provided in relation to the Convention's application in particular in respect of the approach which
should be taken to Article 4. The guidance provides as follows:

i. "77. Thus trafficking means much more than mere organised movement of persons for profit. The critical
additional factors that distinguish trafficking from migrant smuggling are use of one of the means listed (force,


-----

deception, abuse of a situation of vulnerability and so on) throughout or at some stage in the process, and use of
that means for the purpose of exploitation.

ii. 78. The actions the Convention is concerned with are 'recruitment, transportation, transfer, harbouring or receipt
of persons'. The definition endeavours to encompass the whole sequence of actions that leads to exploitation of the
victim.

iii. 81. The means are the threat or use of force or other forms of coercion, abduction, fraud, deception, abuse of
power or of a position of vulnerability, and giving or receiving payments or benefits to achieve the consent of a
person having control over another person.

iv. 83. By abuse of a position of vulnerability is meant abuse of any situation in which the person involved has no
real and acceptable alternative to submitting to the abuse. The vulnerability may be of any kind, whether physical,

psychological, emotional, family‑related, social or economic. The situation might, for example, involve insecurity or

illegality of the victim's administrative status, economic dependence or fragile health. In short, the situation can be
any state of hardship in which a human being is impelled to accept being exploited. Persons abusing such a
situation flagrantly infringe human rights and violate human dignity and integrity, which no one can validly renounce.

v. 84. A wide range of means therefore has to be contemplated: abduction of women for sexual exploitation,
enticement of children for use in paedophile or prostitution rings, violence by pimps to keep prostitutes under their
thumb, taking advantage of an adolescent's or adult's vulnerability, whether or not resulting from sexual assault, or
abusing the economic insecurity or poverty of an adult hoping to better their own and their family's lot. However,
these various cases reflect differences of degree rather than any difference in the nature of the phenomenon, which
in each case can be classed as trafficking and is based on use of such methods.

vi. 87. Under the definition, it is not necessary that someone have been exploited for there to be trafficking in
human beings. It is enough that they have been subjected to one of the actions referred to in the definition and by
one of the means specified 'for the purpose of' exploitation. Trafficking in human beings is consequently present
before the victim's actual exploitation."

30. Article 10 of the Convention is procedural, and Article 10(1) provides a requirement for the competent authority
to provide trained and competent people to identify victims of trafficking. Article 10(2) introduces the reasonable
grounds stage by precluding the removal of people in relation to whom there are reasonable grounds to believe
they have been trafficked before the identification process has been completed. Article 10(2) provides as follows:

i. "Article 10 – Identification of the victims

ii. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as appropriate
in collaboration with other Parties and relevant support organisations. Each Party shall ensure that, if the competent
authorities have reasonable grounds to believe that a person has been victim of trafficking in human beings, that
person shall not be removed from its territory until the identification process as victim of an offence provided for in
Article 18 of this Convention has been completed by the competent authorities and shall likewise ensure that that
person receives the assistance provided for in Article 12, paragraphs 1 and 2."

31. Again, guidance is provided to assist in the operation of the Convention and in respect of Article 10 it provides
as follows:

i. "131. Even though the identification process is not completed, as soon as competent authorities consider that
there are reasonable grounds to believe that the person is a victim, they will not remove the person from the
territory of the receiving states. Identifying a trafficking victim is a process which takes time. It may require

exchange of information with other countries or Parties or with victim‑support organisations, and this may well

lengthen the identification process. Many victims, however, are illegally present in the country where they are being
exploited. Paragraph 2 seeks to avoid their being immediately removed from the country before they can be
identified as victims. Chapter III of the Convention secures various rights to people who are victims of trafficking in


-----

human beings. Those rights would be purely theoretical and illusory if such people were removed from the country
before identification as victims was possible.

ii. 132. The Convention does not require absolute certainty – by definition impossible before the identification
process has been completed – for not removing the person concerned from the Party's territory. Under the
Convention, if there are 'reasonable' grounds for believing someone to be a victim, then that is sufficient reason not
to remove them until completion of the identification process establishes conclusively whether or not they are
victims of trafficking."

32. The provisions of Article 10 are backed by Article 13. Article 13 of the Convention provides as follows:

i. "Article 13 – Recovery and reflection period

1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when there are
reasonable grounds to believe that the person concerned is a victim. Such a period shall be sufficient for the person
concerned to recover and escape the influence of traffickers and/or to take an informed decision on cooperating
with the competent authorities. During this period it shall not be possible to enforce any expulsion order against him
or her."

33. Once more, the operation of the Convention is assisted and informed by guidance associated with it in the
following terms:

i. "173. Article 13(1) accordingly introduces a recovery and reflection period for illegally present victims during
which they are not to be removed from the Party's territory. The Convention contains a provision requiring Parties to
provide in their internal law for this period to last at least 30 days. This minimum period constitutes an important
guarantee for victims and serves a number of purposes. One of the purposes of this period is to allow victims to
recover and escape the influence of traffickers. Victims recovery implies, for example, healing of the wounds and
recovery from the physical assault which they have suffered. That also implies that they have recovered a minimum
of psychological stability. Paragraph 3 of Article 13, allows Parties not to observe this period if grounds of public
order prevent it or if it is found that victim status is being claimed improperly. This provision aims to guarantee that
victims' status will not be illegitimately used.

ii. 174. Other purpose of this period is to allow victims to come to a decision 'on cooperating with the competent

authorities'. By this is meant that victims must decide whether they will cooperate with the law‑enforcement

authorities in a prosecution of the traffickers. From that standpoint, the period is likely to make the victim a better
witness: statements from victims wishing to give evidence to the authorities may well be unreliable if they are still in
a state of shock from their ordeal. 'Informed decision' means that the victim must be in a reasonably calm frame of
mind and know about the protection and assistance measures available and the possible judicial proceedings
against the traffickers. Such a decision requires that the victim no longer be under the traffickers' influence."

34. Against this background, the content of the decision upon referral under Article 10(2) is, in my view, clear. It is
a preliminary threshold decision and is there to ensure that on the one hand temporary protection is afforded to
those about whom there are reasonable grounds to believe on the available material that that person has been a
victim; on the other hand, if there are no reasonable grounds to believe a person has been a victim on the basis of
the material available, then the referral is brought to a conclusion and taken no further. Within the minute on this
decision it will be recalled that reference is made to the "standard of proof" at this stage being "I suspect but cannot
prove". This latter phrase is one which also appears in the defendant's guidance on how to take decisions of this
kind. Whilst the point does not arise directly or perhaps even indirectly in this case, in my view caution must always
be exercised when seeking to recast or gloss a definition from a test, especially where, as here, the words in the
Convention are, to my mind, perfectly clear and straightforward. The simple issue is whether, taking account of
evaluating the available material, which will include not simply a claimant's account but also all other relevant
matters (such as in the present case reports as to the circumstances of Italy and the Netherlands), there are
reasonable grounds to believe that the person was a victim of trafficking. No further gloss is, in my view, required
or for that matter necessarily desirable. For instance, the potential difficulty of the phrase "standard of proof" is that


-----

it could be seen to contain the inference that the claimant has at this stage to "prove" their case in some way, shape
or form. The reality is, when applying the provisions of the Convention, they do not; all that needs to be shown is
that there are reasonable grounds for the belief that they may have been the victim of trafficking.

35. The task of the court when reviewing a decision of this kind is not to retake it. The court has to examine the
decision so as to ensure that the decision maker firstly has correctly understood and interpreted and applied the
relevant test necessary to reach a proper and lawful decision. Further, the court will apply Wednesbury principles
to see whether there has been an error of law. Those principles are, as is well known, whether or not the decision
maker has taken account of matters which were immaterial or left out of account matters which were material to the
decision. Further, they involve an examination of whether or not the decision is one which falls within the bracket of
reasonable decisions that a decision maker might have reached. It is also necessary for the court to examine
where a decision maker has a policy (as in this case) whether or not the policy has been applied; or, alternatively, if
it has not been applied, whether adequate and appropriate reasons for not applying it have been provided. In this
case, the claimant relied upon the policy which is contained within the defendant's "Victims of **_Modern Slavery:_**
Competent Authority guidance" as the defendant's policy in taking decisions of this kind. That policy provides in
particular, in so far as relevant to the present case, as follows:

i. "12.6. When the Competent Authority may need to make further enquiries

ii. Where it appears that the reasonable grounds test may be negative the Competent Authority must contact the
first responder and/or support providers, police and Local Authority as appropriate to discuss their decision and give
them the opportunity to provide any further information/evidence that may be available including any known
evidence highlighted by the first responder and/or support providers which has not yet been sent to the Competent
Authority.

iii. Where a decision may be negative the Competent Authority should make reasonable enquiries in a collaborative
manner with agencies involved in the case, bearing in mind the relatively low threshold of the reasonable grounds
test as well as the limited 5 day timescale in which they are expected to take a decision where possible."

36. Further submissions were made by Mr Buttler in respect of the investigation duty when there is a referral of the
kind in this case. In particular, Mr Buttler draws attention to Rantsev v Cyprus and Russia (2010) 51 EHRR 1, in
which at paragraph 282 the court concluded that trafficking fell within the scope of Article 4 of the European
Convention on Human Rights. As a result, the court found that there were procedural consequences in relation to
the investigation of allegations of breaches, as follows:

i. "288. Like arts 2 and 3, art 4 also entails a procedural obligation to investigate situations of potential trafficking.

The requirement to investigate does not depend on a complaint from the victim or next‑of‑kin: once the matter has

come to the attention of the authorities they must act of their own motion. For an investigation to be effective, it
must be independent from those implicated in the events. It must also be capable of leading to the identification and
punishment of individuals responsible, an obligation not of result but of means. A requirement of promptness and
reasonable expedition is implicit in all cases but where the possibility of removing the individual from the harmful

situation is available, the investigation must be undertaken as a matter of urgency. The victim or the next‑of‑kin

must be involved in the procedure to the extent necessary to safeguard their legitimate interests."

37. Finally in this review of the law it is necessary for the court to scrutinise the reasons which have been given for
the decision so as to ensure that they are legally adequate and appropriate.

38. The grounds in brief

39. In ground 1 it is submitted on behalf of the claimant that the decision maker failed to make any finding as to
whether the claimant was harboured in Italy or Calais and to address this part of her undisputed account on the
basis that the act involved was solely that of transportation when, on the available facts, harbouring had also been
demonstrated at least to the extent of the claimant's account giving reasonable grounds to believe that she had
been harboured. The means (coercion, by locking her in the house in Italy) and together with reliance on her


-----

vulnerability in Calais were never examined by the decision maker; nor, for that matter, was the purpose of those
actions, namely sexual exploitation. This, it was submitted, was an error of law in failing to apply the definition
contained within the Convention systematically and compendiously and failing to ask the questions which were
required by it.

40. Ground 2 is procedural in character: it is the failure to properly investigate the claimant's case in accordance
with the defendant's policy. It is submitted that the defendant made no enquiries of the claimant at the screening
interview or otherwise, and failed to apply her own guidance by proceeding to a negative decision without reverting
back to the first responder or the claimant's support providers. Had the defendant done so, further information
would have emerged. It was submitted that it was also necessary to afford the claimant further time to allow, in
accordance with the guidelines on the Convention, the claimant to recover from the trauma of the ordeals that she
had endured. Thus it was submitted in accordance with Article 13 that the claimant ought to have been afforded a
minimum period in order to recover her mental stability so as to provide a full and proper account of what had
happened to her. These submissions were framed both in a failure to comply with policy and also a failure to give
the claimant a proper and effective practical investigation of her case, thereby amounting to a breach of Article 4 of
the ECHR and, in addition, the procedural expectations of the trafficking Convention.

41. Conclusions

42. There was a potential danger in the defendant's submissions advanced by Ms Rowlands on the defendant's
behalf that the question which was framed by her for the court was cast too widely. Ms Rowlands submitted that
the issue for the court was "whether the claimant was the victim of trafficking or whether she was the victim of
opportunistic sexual violence whilst being smuggled"; or whether the sexual violence of which the claimant was a
victim was "incidental" to her being brought to the UK. In my view, that is far too widely drawn as the question for

the court. In fact, premised on a reasonable‑grounds basis, it may well be a version of the question for the original

decision maker. As set out above, the task of the court is not to retake that decision: the court's task is to scrutinise
the decision which has been reached (which, in this case, is that there are no reasonable grounds to believe that
the claimant had been trafficked) so as to see whether or not there has been any error of law in that

decision‑making process.

43. Notwithstanding that the enquiry as properly understood is narrower than retaking the decision, I am satisfied
that in this case there is substance in the claimant's criticisms in relation to ground 1.

44. The defendant is of course correct to say that simply being smuggled from one country to another and enduring
sexual assault or rape will not bring a person into the definition of trafficking in and of itself. However, the other side
of that coin is that, when undertaking decisions of this kind, careful attention needs to be paid to the account of a
person who is claiming to be trafficked to see whether any aspects of their evidence engage the definition of
trafficking. Whilst it may have been legitimate for the purposes of decision making for the defendant in this case to
disaggregate the claimant's accounts into "movements", it was important whilst doing so to realise that the definition
of trafficking in terms in particular of acts is not confined to when people are moved from place to place. An
appreciation of this is evident in the analysis of the first movement scrutinised by the defendant, since, in the
reasons, it is accepted that the claimant was harboured whilst she was in Italy. However, having concluded that the
means for trafficking in respect of her being locked in the apartment in Italy were satisfied as falling within the
definition of part 'b' (as the decision maker coined it), whether the harbouring was for the purpose of exploitation
was a matter about which the defendant reached no reasoned conclusion. The conclusion is expressed to be in
relation to the "movement from Ethiopia to Italy and within Italy", and clearly reads as if relating to transportation
and not harbouring. Furthermore, the purpose element is rejected because it "cannot be verified". It is entirely
unclear from this what the defendant expected beyond the account which the claimant had provided and which she
had accepted and was undisputed. Furthermore, it is, as I have set out, unclear that there was any separate
consideration in relation to purpose in respect of the harbouring aspect of this part of the claimant's account.

45. If it was the defendant's position that locking the claimant in a room which was only unlocked to permit an
associate of a person harbouring her to have access to her and rape her, and that this did not provide reasonable


-----

grounds to believe that she was harboured for the purposes of sexual exploitation, then in my view it is perfectly
clear that that required greater reasoning in order both to understand and to justify the decision which had been
provided. Thus, in relation to this first aspect of ground 1, I am satisfied that the claimant is correct that the element
of harbouring in relation to the purpose ingredient of the definition was not examined by the defendant in this aspect
of the decision, and further that the reasons provided are inadequate and unlawful.

46. In relation to the third "movement" from the Netherlands to France, whilst there is consideration as to whether
the claimant was transported during this phase of her account, there is no consideration of whether in her time at
the Jungle she was harboured for a relevant means and purpose. Ms Rowlands, rightly, in my view, pointed out by
referencing the French text of the Convention alongside the English test that whilst "harbour" is not further defined,
it should properly be regarded as having a broader meaning that simply "keep", and should, within that breadth of
meaning, include provision of shelter and accommodation as potentially giving rise to the relevant act within the
definition.

47. Ms Rowlands further submitted that there was no material upon which the defendant could have found that the
claimant's stay in the Jungle was anything other than purely voluntary. The difficulty, in my view, with that
submission is firstly there is no evidence that that was in fact the defendant's conclusion. In reality, the decision is
entirely silent on that point and her submission reads reasoning into that which has been provided. Secondly, it
was, in my view, a relevant question to consider on the basis of the claimant's account, as it was at that stage
before the defendant, whether she had been harboured at this point in her account. It is a relevant question which
has simply not been addressed in the record of the decision maker. Whilst it is not for the court to determine the
answer to that question, I am not prepared to conclude, as was suggested on behalf of the defendant, that the
answer to that question would inevitably be the same, or likely to be not substantially different, in the sense that it
would be inevitable that it would be concluded that she was not harboured at that stage of her account. Such a
submission involves the contemplation that the claimant was a willing volunteer for residing in circumstances which
involved the regular infliction of serious sexual violence upon her. That, in my view, at least calls for some enquiry
as to why it was she remained in those circumstances. It cannot be said that it is inevitable that there are no
reasonable grounds to believe she was harboured and as such no reasonable grounds to believe she was
trafficked. That is a question which ought to have been addressed on the evidence which was before the defendant
and the reality of the defendant's decision is that it is simply not engaged with at all.

48. Thus in my view, in respect of this part of the decision ground 1 is also made out. The defendant failed to
properly examine all aspects of the definition of trafficking arising out of the claimant's account and therefore failed

to address all of the relevant questions which the Convention and a lawful decision‑making process required.

Furthermore, even if the defendant were right and in fact a decision was reached that it was simply not possible for
harbouring to arise, that is not expressed in the reasons, which were inadequate.

49. Whilst these conclusions would in themselves suffice to justify quashing the defendant's decision, there are
some elements of ground 2 which I have formed the view should also be addressed. There is no explanation
provided in the decision as to why the defendant's policy in relation to how to proceed when it appears that the
reasonable grounds decision may be negative was not followed. No further contact was made either with the first
responder or any other agencies at the time when it became apparent that the decision in the claimant's case was
likely to be adverse to her. No opportunity was afforded to the claimant or anyone on her behalf to provide any
further information.

50. It was contended on behalf of the defendant by Ms Rowlands that the guidance in this respect which I have
quoted above only applies when there is to be an adverse credibility finding. That is a submission I am simply
unable to accept, on the basis that it is not what the guidance actually says; the guidance places no such limitation
on its application.

51. Further it was said on behalf of the defendant, and in particular in relation to the points arising under Article 4 of
the ECHR, that there was nothing to be investigated and therefore a duty to investigate simply did not arise in this
case. Again, I am unable to accept these submissions. Firstly, the defendant's guidance itself, read practically and
in a straightforward manner, advises that where it appears that the reasonable grounds decision is going to be


-----

negative, the defendant should contact the various parties involved and provide the opportunity for further evidence
to be made available. Whilst it would be wrong to approach the issue which arises in this part of the case from the
perspective of hindsight, it can be noted by way of illustration that after the decision had been taken significant new
material emerged and is set out above both in relation to the claimant's account in particular as to the

circumstances why she did not leave the Jungle and also in respect of her mental well‑being.

52. Secondly, I cannot accept these submissions because the decision itself, read on its face, is not indicative of
there being nothing to be investigated or enquired into further. As set out above, the purpose of the movement from
Ethiopia and within Italy was not accepted because its purpose could not be "verified". Ms Rowlands said that that
meant that there was no room for a finding of trafficking as opposed to smuggling. To my mind, that would be a
very odd use of language and in particular the use of the word "verified". A far more normal understanding of
something not being verified would be that it was unproven or required further confirmation. That understanding
and plain reading of the decision demonstrates the role that further enquiry and investigation could have played at

the time when decision‑making was occurring.

53. Further, and as set out above, the circumstances of the claimant remaining in the Jungle called for further
investigation, in my view, before the suggestion she may have been harboured could be altogether dismissed.
Thus in relation to ground 2 there was, in my judgment, a failure to apply the defendant's policy where it appears
that the reasonable grounds decision would be negative, and further no reasons were provided or could be inferred
for the failure to apply the policy. This amounts to a clear error of law. That suffices to satisfy me that the
claimant's submissions under ground 2 should be supported.

54. In the circumstances, there is no need for me to reach conclusions on the claimant's wider submissions as to
whether or not in this case or more generally the level of enquiry which was undertaken was both practical and
effective so as to discharge the duty under Article 4 of the ECHR.

55. Conclusions

56. For the reasons which I have set out above, the claimant succeeds in this judicial review on both grounds
which have been brought before the court.

**End of Document**


-----

