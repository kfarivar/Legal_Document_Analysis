guidance)

# R (on the application of SV) v Secretary of State for the Home Department
 (ECAT: lawfulness of policy guidance) [2022] UKUT 39 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Lane J, Upper Tribunal Judge Allen and Upper Tribunal Judge Smith

7 December 2021Judgment

**Representation:**

For the applicant: Mr A. Bandegani, instructed by Wilson Solicitors LLP

For the respondent: Ms E. Wilsdon, instructed by the Government Legal Department

_1)        The fact that:_

_(i)        the European Convention Against Trafficking in Human Beings (“ECAT”) is not a part of_
_domestic law; but_

_(ii)        the Secretary of State for the Home Department has decided to give effect to ECAT by means_
_of a policy,_

_is not a reason for a court or tribunal to refuse to examine the lawfulness of that policy by reference to the_
_judgments in R (A) v Secretary of State for the Home Department [2021] UKSC 37 (“A”) and R (BF Eritrea) v_
_Secretary of State for the Home Department [2021] UKSC 38 (“BF (Eritrea)”)._

_(2)        The ECAT and the policy guidance are not to be read together as merely a single policy of the_
_respondent, which may be judicially scrutinised in its entirety and declared unlawful if found in any respect to be_
_internally inconsistent. Despite not being incorporated into domestic law, ECAT is not itself a policy of the_
_respondent, whose terms can be changed or abrogated by her. ECAT remains an international set of obligations._
_Accordingly, when seeking to establish the appropriate public law mechanism for assessing the lawfulness of the_
_respondent's policy guidance, it is essential to recognise that the respondent has chosen to give ECAT normative_
_effect, with the policy guidance being a set of instructions to her caseworkers on how to make decisions that give_
_effect to ECAT._

_(3)        This means that the lawfulness of the Secretary of State's policy instructions to caseworkers_
_on how to make decisions that give effect to ECAT falls to be determined by reference to the test (based on Gillick v_
_West Norfolk and Wisbech Area Health Authority [1986] AC 112), which was approved in A and BF (Eritrea), for_
_assessing the lawfulness of policies that give guidance on the meaning and effect of the law; namely, can the policy_
_be operated in a lawful way; or does it impose requirements which mean that a material and identifiable number of_
_cases will be dealt with in an unlawful way?_

**JUDGMENT**

**_A. INTRODUCTION_**


-----

guidance)

1. The applicant is a citizen of Albania. She claims to have arrived in the United Kingdom on 28 March 2014 and
was first referred into the respondent's National Referral Mechanism (NRM) on 14 April 2014. The referral resulted
in a positive reasonable grounds decision but a negative conclusive grounds decision on the issue of whether the
applicant was a victim of modern slavery.

2. The applicant also claimed asylum but that was refused and a subsequent appeal was dismissed.

3. The applicant was again referred to the NRM in May 2016, receiving a positive reasonable grounds decision on
16 June 2016 and, this time, (after judicial review proceedings) a positive conclusive grounds decision on 4 June
2019.

4. On 3 June 2019, the respondent decided not to grant the applicant discretionary leave to remain in the United
Kingdom. That decision was, however, challenged and on 25 September 2020, the respondent granted the
applicant twelve months' discretionary leave.

5. That decision was itself challenged and on 18 March 2021, the respondent granted the applicant 30 months'
discretionary leave. The 30 months were stated to run from the date of the initial grant of discretionary leave on 25
September 2020.

6. The applicant has been diagnosed with complex post-traumatic stress disorder (CPTSD). The International
Society for Traumatic Stress Studies guidelines for CPTSD recommend a three-phase approach to treatment,
focussing initially on stabilisation through the understanding and control of symptoms, followed by work on
processing of traumatic memories and, finally, a phase of social and psychological integration.

7. The decision of 18 March 2021 stated that 30 months' discretionary leave had been granted “to allow [the
applicant] to access the 3 phased intervention treatment recommended” in a psychiatric report dated 25 September
2020. The leave was said to have “been granted in accordance with the Modern Slavery DL policy”.

8. In response to the earlier decision to grant twelve months' leave, those acting for the applicant had supplied the
respondent by letter dated 6 January 2021 with a medical report of Professor Katona. In that report, Professor
Katona stated that the three stage treatment process would vary from each person according to their specific
mental health needs. In order for therapy to be effective, the “key principle” was that the individual concerned “has
sufficient sense of safety and security”. Professor Katona considered that the applicant's treatment was likely to
take “well over a year from its inception” and that “unlimited leave to remain would make the best clinical sense” for
the applicant. The treatment would involve “considerably more than 25 weeks” and the delays in granting her
leave, together with the limited nature of the leave, had created uncertainty and continuing fear of returning to
Albania, which Professor Katona considered impeded the creation of subjective safety and security for her.

9. The covering letter opined that Professor Katona's report supported the submission on the applicant's behalf that
the grant of twelve months was insufficient in her case. The letter also said that the report highlighted a situation “in
which there is a failure to consider the individual circumstances of the case in only granting the applicant twelve
months' leave to remain, illustrating the unlawful nature of the DLR policy which leads to uncertainty and arbitrary
decision-making – rendering the policy unlawful”.

**_B. EUROPEAN CONVENTION AGAINST TRAFFICKING IN HUMAN BEINGS /_**
**_RESPONDENT'S POLICY: DISCRETIONARY LEAVE CONSIDERATIONS FOR VICTIMS OF MODERN_**
**_SLAVERY (VERSION 4.0)_**

10. The applicant's judicial review of the decision of 25 September 2020 became (through the filing of amended
grounds on 25 March 2021) a challenge to the decision of 18 March to grant 30 months' leave to remain. It does so
by reference to the respondent's policy “Discretionary leave considerations for victims of modern slavery”, which is
said to be unlawful, in that it fails properly to reflect, or give effect to, the European Convention against Trafficking in
Human Beings 2005. This Convention (hereafter ECAT), entered into by the member States of the Council of


-----

guidance)

Europe including the United Kingdom, is an international treaty, which binds this country as a matter of international
law. ECAT has not, however, been incorporated by legislation into domestic law.

11. Under Article 12(3) of ECAT, the State must provide necessary medical or other assistance to victims lawfully
resident within its territory who do not have adequate resources and need such help. Article 12(5) requires States
to take measures, where appropriate and under the conditions provided for by its internal law, to co-operate with
non-governmental organisations, other relevant organisations or other elements of civil society engaged in
assistance to victims. Article 12(7) requires services to be provided on a consensual and informed basis, taking
due account of the special needs of persons in a vulnerable position.

12. For our purposes, the key provision of ECAT is Article 14:
“Article 14

**Residence permit**

1. Each Party shall issue a renewable residence permit to victims, in one or other of the two following situations or
in both: a the competent authority considers that their stay is necessary owing to their personal situation; b the
competent authority considers that their stay is necessary for the purpose of their co-operation with the competent
authorities in investigation or criminal proceedings.

2. The residence permit for child victims, when legally necessary, shall be issued in accordance with the best
interests of the child and, where appropriate, renewed under the same conditions.

3. The non-renewal or withdrawal of a residence permit is subject to the conditions provided for by the internal law
of the Party.

4. If a victim submits an application for another kind of residence permit, the Party concerned shall take into
account that he or she holds, or has held, a residence permit in conformity with paragraph 1.

5. Having regard to the obligations of Parties to which Article 40 of this Convention refers, each Party shall ensure
that granting of a permit according to this provision shall be without prejudice to the right to seek and enjoy asylum.”

13. The Explanatory Report to ECAT has this to say about Article 14:
“182. The two requirements laid down in Article 14, paragraph 1, for issue of a residence permit are that either the
victim's stay be 'necessary owing to their personal situation' or that it be necessary 'for the purpose of their
cooperation with the competent authorities in investigation or criminal proceedings'. The aim of these requirements
is to allow Parties to choose between granting a residence permit in exchange for cooperation with the law
enforcement authorities and granting a residence permit on account of the victim's needs, or indeed to adopt both
simultaneously.

183. Thus, for the victim to be granted a residence permit, and depending on the approach the Party adopts, either
the victim's personal circumstances must be such that it would be unreasonable to compel them to leave the
national territory, or there has to be an investigation or prosecution with the victim co-operating with the authorities.
Parties likewise have the possibility of issuing residence permits in both situations.

184. The personal situation requirement takes in a range of situations, depending on whether it is the victim's
safety, state of health, family situation or some other factor which has to be taken into account.”

14. The respondent's policy guidance “Discretionary leave considerations for victims of modern slavery” has had
a number of iterations. The version with which we are concerned is 4.0, published on 8 December 2020.

15. Version 4.0 begins by stating that the policy guidance “explains the circumstances in which it may be
appropriate to grant discretionary leave to remain (DL) to individuals confirmed as victims of modern slavery by the


-----

guidance)

National Referral Mechanism (NRM), and the considerations that must be made before such a decision is made.”
The introduction also states that the policy guidance “deals with extending DL or curtailing leave as necessary”.

16. Under the heading “Related external links” there are electronic links to the judgment of the Court of Appeal in
PK (Ghana) v The Secretary of State for the Home Department [2018] EWCA Civ 98; [2018] Imm AR 961 and to
the “Council of Europe Convention on Action against Trafficking in Human Beings” (i.e. ECAT).

17. At page 5 of 16, the policy guidance states that a person will not qualify for DL solely because a conclusive
grounds decision has been made that they are a victim of modern slavery. “There must be reasons based on their
individual circumstances to justify a grant of DL”. Discretionary leave may be considered where a positive
conclusive grounds decision has been made and the person satisfies one of the following criteria:

- leave is necessary owing to personal circumstances,

- leave is necessary to pursue compensation,

- victims who are helping police with their enquiries.

18. The policy guidance then deals, in some detail, with each of those three categories.

19. On page 10 of 16, the policy guidance says that a positive conclusive grounds decision does not result in an
automatic grant of immigration leave. However, unless the person concerned has an outstanding asylum claim,
automatic consideration (for non-EEA victims) “should normally be given at the same time, or as soon as possible
afterwards, to whether a grant of discretionary leave is appropriate under this policy”.

20. At page 11 of 16, the policy guidance explains that a person who has been granted DL under the policy and
who wishes to extend it for a further period must make an application to the Home Office, using a specified form.
“Further periods of DL may be granted where the individual continues to meet the eligibility criteria set out in this
policy”.

21. On page 12 of 16, we find the following:
“Requests for indefinite leave to remain

There is no requirement to issue indefinite leave to remain (ILR) to confirmed victims of modern slavery, and the
threshold for a grant of ILR outside the Immigration Rules is a high one. Victims of modern slavery granted DL
under this policy are not considered to be on a route to indefinite leave to remain in the UK.”

22. On page 14 of 16 there is this:
“Standard grant of leave periods

Where DL under this policy is granted for medical treatment it should normally be for up to 30 months. When the
initial leave expires, a further period of leave may be granted on application.

A grant of DL to assist in police enquiries or for the purposes of pursuing a compensation claim should be for the
time considered necessary depending on the circumstances, up to a maximum of 12 months in the first instance.

For a longer periods (sic) of DL to be granted there must be sufficient evidence to demonstrate that the individual
circumstances of the case can be distinguished to a high degree from other cases.

…

Cases involving children


-----

guidance)

In cases involving children, the best interests of the child is regarded as a primary consideration. (although not
necessarily the only consideration) and one that can affect the duration of leave granted. See section 55 of the
Borders, Citizenship and Immigration Act 2009 for further guidance, and Article 14(2) of the Council of Europe
Convention on Action against Trafficking in Human Beings.

Where the child or their parent meets the criteria for a grant of DL based on modern slavery, consideration should
be given to factors such as the length of residence in the UK, where the child was born, and the strength of the
evidence to suggest that the child's life would be adversely affected by a grant of limited leave rather than indefinite
leave to remain (ILR). This does not alter the expectation that in most cases a standard period of up to 30 months
will be appropriate.

Parents of children granted extended leave must separately demonstrate that there are compassionate factors, in
their own right, to warrant departure from the standard grant of DL under this policy. The onus is on the applicant to
provide the evidence to support their case.”

**_C. THE APPLICANT'S CHALLENGE_**

23. The applicant brings three grounds of challenge. The first is that the respondent's DLR policy guidance is
unlawful “because it is unclear and too imprecise to form part of a policy capable of being operated lawfully”. In
particular, it is contended that if “normally” up to 30 months should be granted, it is unclear how a grant of DLR in
excess of 30 months can, at the same time, be “standard”. Further, it is said to be unclear which “other cases” must
be distinguished in order for a longer period of DL to be granted; and what precisely are the circumstances of the
relevant other cases that fall to be distinguished. Third, it is said to be unclear what is meant by the threshold for a
grant of ILR outside the Immigration Rules being “a high one” and whether and to what extent the criterion is
different to the requirement on page 14 of 16 that the case in question must be capable of being distinguished “to a
high degree from other cases”, in order for a longer period of DLR to be granted.

24. Ground 2 rests on the contention that the purpose of the respondent's policy guidance is to give effect to the
United Kingdom's international obligations as a signatory to ECAT. In PK (Ghana), Picken J, at first instance, said it
was common ground that the policy guidance “was intended to, and purported to, give effect to the [ECAT]; and
that, if it failed to give effect to [ECAT], then that would be a justiciable error of law”. Hickinbottom LJ recorded that,
before the Court of Appeal “after some consideration and after taking instructions, Miss Bretherton, who also
appeared for the Secretary of State below, confirmed that concession” (paragraph 34).

25. In PK (Ghana), the claimant contended that the respondent's policy guidance, as then in force, was
inconsistent with Article 14 of ECAT. The guidance stated that the grant of discretionary leave to a victim of
trafficking might be appropriate “if their circumstances are compelling”.

26. Hickinbottom LJ held that the requirement that the circumstances be “compelling” did not properly reflect Article
14 of ECAT, which provided that the criterion for granting a residence permit was whether the “stay is necessary
owing to their personal situation”. The court accordingly declared that the relevant policy guidance was unlawful.

27. Ground 2 prays PK (Ghana) in aid. The claimant submits that by “normally” limiting a grant of leave to 30
months, requiring the case to be distinguished to “a high degree” from other cases, when deciding whether to grant
longer periods of leave beyond, or towards the top end of, the 30 months; and imposing a “high” threshold where
requests for ILR are made, the policy guidance exceeds the requirements of ECAT.

28. Ground 2 also argues that the policy guidance is unlawful (as being contrary to ECAT) because it requires the
parents of children who have been granted more than 30 months' leave to show that there are “compassionate
factors, in their own right, to warrant departure from the standard grant of DL” for those parents.

29. Ground 3 argues that, in deciding to grant the applicant no more than 30 months' DLR, the respondent failed in
her decision dated 19 March 2021 to explain why she had “rejected the opinion of Dr Katona that a longer period of
DLR, including ILR, was clinically appropriate and necessary for the purposes of [the applicant's] treatment”.


-----

guidance)

**_D. THE PROCEEDINGS_**

30. Permission to bring judicial review proceedings was refused on the papers on 26 April 2021 but granted by
Upper Tribunal Judge Allen at a renewal hearing on 19 May 2021.

31. The substantive hearing took place on 17 September 2021. On that date, Counsel informed the Tribunal that
Linden J had reserved judgment in a case involving a challenge to the policy guidance, as it bears on recognised
victims of trafficking who have made a protection claim and who are not, as a result, removeable from the United
Kingdom whilst the claim is undecided and any consequent appeal still pending: sections 77 and 78 of the
Nationality, Immigration and Asylum Act 2002. Before Linden J, submissions had been made regarding the status
of the concession recorded at paragraph 34 of PK (Ghana); and more generally as to the relationship between
ECAT and the policy guidance.

32. Following the handing down of the judgment in Linden J's case (R (KTT) v Secretary of State for the Home
Department [2021] EWHC 2722 (Admin)), we received written submissions on behalf of the applicant (19 October)
and the respondent (26 October), and a reply thereto by the applicant (4 November). The Tribunal is grateful to Mr
Bandegani and Ms Wilsdon for the high quality of their oral and written submissions.

**_E. SUPREME COURT JUDGMENTS_**

33. In order to explain why the relationship between ECAT and the policy guidance has recently become a
contentious issue, it is necessary to examine three judgments of the Supreme Court, handed down in 2021.

34. The first is R (SC & Ors) v Secretary of State for Work and Pensions & Ors [2021] UKSC 26. This concerned a
judicial review of the so-called two-child limit in respect of child tax credit under the _[Tax Credits Act 2002 (as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y06B-00000-00&context=1519360)_
amended). It was asserted that the two-child limit unlawfully discriminated against the claimants, contrary to
Articles 8/14 of the ECHR, in particular in the light of the United Kingdom's obligations under the United Nations
Convention on the Rights of the Child.

35. The Supreme Court held that, whilst the best interests of a child would be a relevant consideration in assessing
whether differential treatment was justifiable under Article 8/14, it was not appropriate to seek to apply an
unincorporated treaty, such as the Convention on the Rights of the Child, in reaching a determination; or to make a
decision whether, in adopting the measure in question, the United Kingdom had complied with its obligations under
the Convention. This flowed from the fundamental principle that an unincorporated treaty does not form part of the
law of the United Kingdom.

36. The second and third Supreme Court judgments form a pair. They are R (A) v Secretary of State for the Home
Department [2021] UKSC 37 and R (BF Eritrea) v Secretary of State for the Home Department [2021] UKSC 38.

37. A concerned a policy known as the Child Sex Offender Disclosure Scheme Guidance. The claimant submitted
that the guidance was unlawful, in that it did not make sufficient provision for the police to consult him before
making disclosure about his offences to a member of the public who makes enquiry about him in circumstances
where the claimant is in contact with children. The claimant was a convicted sex offender.

38. The judgment of Lord Sales and Lord Burnett noted that policies “are different from law” but that, in the last
decades, “the courts have given policies greater legal effect”. In a parallel development “there has been an
increase in judicial review of the contents of policies” (paragraphs 3 and 4).

39. In A, the Supreme Court affirmed the importance of the decision of the House of Lords in Gillick v West Norfolk
and Wisbech Area Health Authority [1986] AC 112. This concerned Department of Health and Social Security
guidance to health authorities on family planning services, including a section on contraceptive advice and
treatment for young people. The claimant sought a declaration that the guidance gave advice which was unlawful
and wrong. She succeeded in the Court of Appeal on the grounds that a girl under 16 was incapable either of
consenting to treatment or of validly requiring a doctor not to seek the consent of her parents; and that the guidance


-----

guidance)

was contrary to law, in that any doctor who treated a girl under 16 without such consent, other than in an
emergency, would be infringing her parents' rights (paragraph 30). The House of Lords reversed the decision of the
Court of Appeal.

40. At paragraph 34, the Supreme Court noted that Lord Scarman, in Gillick, made explicit “that it was not the role
of policy guidance to eliminate all uncertainty regarding its application and all risk of legal errors by doctors”. The
policy was “to be read objectively, having regard to the intended audience”. The drafter of a policy was “not
required to imagine whether anyone might misread the policy and then to draft it to eliminate that risk”. Rather, it
was “only if the guidance, on a reasonable reading of it, positively encouraged a doctor to think that he was
authorised to prescribe without the parent's consent whenever he thought fit that it would be unlawful”.

41. Of particular relevance are the following passages from the Supreme Court's judgment:
“38. In our view, Gillick sets out the test to be applied. It is best encapsulated in the formulation by Lord Scarman
at p 182F (reading the word 'permits' in the proper way as 'sanction' or 'positively approve') and by adapting Lord
Templeman's words: does the policy in question authorise or approve unlawful conduct by those to whom it is
directed? So far as the basis for intervention by a court is concerned, we respectfully consider that Lord Bridge and
Lord Templeman were correct in their analysis that it is not a matter of rationality, but rather that the court will
intervene when a public authority has, by issuing a policy, positively authorised or approved unlawful conduct by
others. In that sort of case, it can be said that the public authority has acted unlawfully by undermining the rule of
law in a direct and unjustified way. In this limited but important sense, public authorities have a general duty not to
induce violations of the law by others.

…

40. There are further reasons which indicate that this is the appropriate standard. If the test were more demanding
there would be a practical disincentive for public authorities to issue policy statements for fear that they might be
drawn into litigation on the basis that they were not sufficiently detailed or comprehensive. This would be contrary
to the public interest, since policies often serve useful functions in promoting good administration. Or public
authorities might find themselves having to invest large sums on legal advice to produce textbook standard
statements of the law which are not in fact required to achieve the practical objectives the authority might have in
view. Also, if the test were of the nature for which Mr Southey contends, the courts would be drawn into reviewing
and criticising the drafting of policies to an excessive degree. In effect they would have a revising role thrust upon
them requiring them to produce elaborate statements of the law to deal with hypothetical cases which might arise
within the scope of a policy. Such a role for the courts cannot be justified. Their resources ought not to be taken up
on such an exercise and it would be contrary to the strong imperative that courts decide actual cases rather than
address academic questions of law.

41. The test set out in Gillick is straightforward to apply. It calls for a comparison of what the relevant law requires
and what a policy statement says regarding what a person should do. If the policy directs them to act in a way
which contradicts the law it is unlawful. The courts are well placed to make a comparison of normative statements
in the law and in the policy, as objectively construed. The test does not depend on a statistical analysis of the
extent to which relevant actors might or might not fail to comply with their legal obligations: see also our judgment in
_BF (Eritrea)._

…

46. In broad terms, there are three types of case where a policy may be found to be unlawful by reason of what it
says or omits to say about the law when giving guidance for others: (i) where the policy includes a positive
statement of law which is wrong and which will induce a person who follows the policy to breach their legal duty in
some way (ie the type of case under consideration in Gillick); (ii) where the authority which promulgates the policy
does so pursuant to a duty to provide accurate advice about the law but fails to do so, either because of a
misstatement of law or because of an omission to explain the legal position; and (iii) where the authority, even
though not under a duty to issue a policy decides to promulgate one and in doing so purports in the policy to


-----

guidance)

provide a full account of the legal position but fails to achieve that, either because of a specific misstatement of the
law or because of an omission which has the effect that, read as a whole, the policy presents a misleading picture
of the true legal position. In a case of the type described by Rose LJ, where a Secretary of State issues guidance
to his or her own staff explaining the legal framework in which they perform their functions, the context is likely to be
such as to bring it within category (iii). The audience for the policy would be expected to take direction about the
performance of their functions on behalf of their department from the Secretary of State at the head of the
department, rather than seeking independent advice of their own. So, read objectively, and depending on the
content and form of the policy, it may more readily be interpreted as a comprehensive statement of the relevant
legal position and its lawfulness will be assessed on that basis. In the present case, however, the police are
independent of the Secretary of State and are well aware (and are reminded by the Guidance) that they have legal
duties with which they must comply before making a disclosure and about which, if necessary, they should take
legal advice.

47. In a category (iii) case, it will not usually be incumbent on the person promulgating the policy to go into full
detail about how exactly a discretion should be exercised in every case. That would tend to make a policy unwieldy
and difficult to follow, thereby undermining its utility as a reasonably clear working tool or set of signposts for
caseworkers or officials. Much will depend on the particular context in which it is to be used. A policy may be
sufficiently congruent with the law if it identifies broad categories of case which potentially call for more detailed
consideration, without particularising precisely how that should be done. This was the approach adopted by Green
J in R (Letts) v Lord Chancellor (Equality and Human Rights Commission intervening) _[2015] EWHC 402 (Admin);_

[2015] 1 WLR 4497('Letts').

…

63. We agree that this is a fundamental distinction for the purposes of analysis. If it is established that there has in
fact been a breach of the duty of fairness in an individual's case, he is of course entitled to redress for the wrong
done to him. It does not matter whether the unfairness was produced by application of a policy or occurred for
other reasons. But where the question is whether a policy is unlawful, that issue must be addressed looking at
whether the policy can be operated in a lawful way or whether it imposes requirements which mean that it can be
seen at the outset that a material and identifiable number of cases will be dealt with in an unlawful way.

64. In our view, reading the _Refugee Legal Centre case in this way in line with_ _Gillick_ removes the risk of
misunderstanding it as stating an unprincipled and vague test. If one simply asks whether a policy creates an
unacceptable risk that an individual will be treated unfairly (which is to say, unlawfully), there is a danger that this
could be taken as a freestanding principle distinct from that in _Gillick, as seems to have been envisaged in_
_Tabbakh._

65. First, it is unclear what the relationship of such a principle is with the authoritative guidance given in Gillick. If
the principle were that a policy is unlawful if it creates an unacceptable risk that an individual will be treated
unlawfully, that is a substantially wider principle than that stated in _Gillick_ and inconsistent with it. There is no
sound conceptual basis for separating out unlawfulness due to unfairness from unlawfulness for any other reason.
Secondly, a test whether a policy creates an “unacceptable risk” that an individual will be treated unfairly or
unlawfully provides no criterion of what makes a risk count as unacceptable. The distinction drawn in _Tabbakh_
between whether a policy is inherently unfair or it just leaves a risk of unfairness arising in the ordinary course of
individual decision-making is similarly unclear. A determinate criterion is required to distinguish the two cases in a
principled way. Gillick supplies it. Thirdly, a test for the lawfulness of a policy based on “unacceptable risk” or the
like would be a new departure in public law and cannot be regarded as an incremental extension from existing
principle. On the contrary, as we have explained, in our opinion it would subvert existing principle. By contrast, if
the test of inherent unfairness is applied by reference to the principle in Gillick, the law supplies a reasonably clear
criterion of unlawfulness which has a sound foundation in principle. Fourthly, without such a foundation, the
assertion of such a power of review by the courts, in relation to functions (the operation of administrative systems
and the statement of applicable policy) which are properly the province of the executive government would
represent an unwarranted intrusion by the courts into that province. Anchoring the lawfulness of policy to the


-----

guidance)

principles articulated in _Gillick_ avoids that outcome. Fifthly, if one moves away from that principled foundation,
there is a risk that a court will be asked to conduct some sort of statistical exercise to see whether there is an
unacceptable risk of unfairness, as was urged upon the court in the BF (Eritrea) appeal: see our judgment in BF
_(Eritrea) at paras 35 and 41. But a court is not well equipped to undertake such an analysis based upon_
experience. In principle, the test for the lawfulness of a policy should be capable of application at the time the
policy is promulgated, which will be before any practical experience of how it works from which statistics could be
produced. The test for the lawfulness of a policy is not a statistical test but should depend, as the Gillick test does,
on a comparison of the law and of what is stated to be the behaviour required if the policy is followed. Both aspects
of this test are matters on which the court is competent and has the authority to pronounce.”

42. At paragraph 74, the Supreme Court disapproved of the judgment of the Divisional Court R (W) v Secretary of
State for the Home Department [2020] EWHC 1299 (Admin), which held that a policy would be unlawful “if it leads
to unlawful results in 'a significant number of cases'”, as well as the test derived from the Court of Appeal judgment
in BF (Eritrea) that “policy guidance would be unlawful if there is 'a real risk of the guidance leading to an unlawful
result in a more than minimal number of cases'”.

43. In BF (Eritrea), handed down on the same day as A, the Supreme Court relied upon its judgment in
that case to overturn the majority judgment of the Court of Appeal which had held that the respondent's
policy guidance for Immigration Officers, assessing whether an asylum seeker appears to be a child, was
unlawful.

44. In BF (Eritrea), the policy guidance was issued in the light of paragraph 16(2A) of Schedule 2 to the
Immigration Act 1971. This introduced restrictions on the place and duration of immigration detention, in
the case of an unaccompanied child. Applying the “Gillick principle”, the Supreme Court held:
“65. … The Secretary of State would have been entitled to have no policy at all as regards the application
of paragraph 16(2A) of Schedule 2 to the 1971 Act, or a policy which simply directed attention to the rule in
that provision. It would be odd to conclude that, although the Secretary of State was under no obligation to
say anything at all about the statutory rule, if she did promulgate a policy in relation to it she suddenly
came under an obligation to specify in her policy that the rule should only be applied if any margin of error
had been eliminated, by using 23 (or 25) as the relevant cut-off age to identify a person as a child instead
of 18.”

**_F. THE RELATIONSHIP BETWEEN ECAT AND THE POLICY GUIDANCE_**

45. We have already noted the “concession” in PK (Ghana). Earlier, a similar concession was recorded by
the Divisional Court in R (Atamewan) v Secretary of State for the Home Department [2014] 1 WLR 1959.
Aikens LJ noted the following:
“55. Mr Eadie submitted in relation to the NRM decision that the key question was whether the policy set
out in the Guidance (particularly in relation to 'historic' trafficking cases) was sufficient to comply with the
UK's international obligations under CAT. He accepted, at least in this court, that although CAT had not
been transposed into domestic law by legislation and so did not have 'direct effect', insofar as the
Guidance purported to give effect to the terms of CAT and failed to do so, that would be a justiciable error
of law. He also accepted that to the extent that the NRM Decision was itself based on the terms of the
Guidance, if they were, in turn, based on an erroneous interpretation of CAT, then the NRM Decision could
be challenged by Judicial Review because that decision would then have been based on a misdirection as
to the legal basis for the relevant wording of the Guidance.”

46. At paragraph 69, the Divisional Court held, in terms, that the guidance “purports to set out [UK
government policy] in a manner consistent with the provisions of the [ECAT]”.

47. In R (Galdikas) v Secretary of State for the Home Department [2016] 1 WLR 4031, Sir Stephen Silber
(who had been part of the Divisional Court in Atamewan) held at paragraphs 48 to 52 that he was not
bound by the concession made by Mr Eadie QC in Atamewan. This was because the concession had
been made “at least in” the Divisional Court and in any event had merely been assumed to be correct. Sir


-----

guidance)

Stephen therefore determined the issue himself, holding that it was, indeed, the policy of the respondent to
apply ECAT when considering applications for discretionary leave to remain (paragraph 65).

48. The respondent's position before us was, broadly, the same as her position had been before Linden J;
namely, that the Supreme Court judgment in SC means that so much of the concessions as concern the
justiciability of challenges brought by reference to ECAT must no longer be relied upon. Linden J rejected
that argument (paragraph 52).

49. At this point, we first encounter the question of whether the Upper Tribunal should follow the legal
findings of Linden J. As explained in Willers v Joyce (No 2) _[2016] UKSC 44, puisne judges are not_
technically bound by decisions of their peers, but should generally follow a decision of a court of coordinate jurisdiction, unless there is a powerful reason for not doing so (paragraph 9). The same approach
has been taken by the Upper Tribunal, in relation to decisions of the High Court: The Kingsbridge Pension
[Fund Trust v Downs [2017] UKUT 237 (LC).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NRJ-0YN1-F0JY-C4J8-00000-00&context=1519360)

50. On the “justiciability” issue, we are in no doubt that there is no “powerful reason” for us to decline to
follow Linden J. Not only is his decision, with respect, not plainly wrong; it is manifestly correct. The
respondent has greatly over-stated the significance of the judgment in SC, as it bears on the issues with
which we are concerned.

51. We have seen that the concession in Atamewan was made expressly on the basis that ECAT had not
been transposed into domestic law and therefore did not have “direct effect”. Neither the parties nor the
Divisional Court were under any misapprehension in that regard. The principle that an international treaty
needs to be incorporated by domestic legislation in order to have direct effect has been part of our law
since at least the judgment of the House of Lords in JH Rayner (Mincing Lane) Ltd v Department of Trade
and Industry [1990] 2 AC 418.

52. In similar vein, Sir Stephen Silber at paragraph 61 of Galdikas was fully alive to the significance of
ECAT being “an unimplemented treaty”. He could see no reason why the respondent could not,
nevertheless, adopt a policy based wholly or partly on such a treaty.

53. We also see no reason to depart from the conclusion of Linden J that the concession recorded in PK
(Ghana) formed part of the Court of Appeal's ratio in that case and was not merely assumed by the Court
of Appeal to be correct (paragraphs 53 to 59).

54. Nevertheless, the fact that the respondent may, in the past, have had a policy to give effect to ECAT in
the United Kingdom, by means of her own policy guidance to caseworkers, does not mean that she must
continue indefinitely to do so. Since ECAT has no independent normative status, the respondent could
adopt a policy that, henceforth, she will not seek to give effect to ECAT (regardless of her international
obligations), when making decisions concerning **_modern slavery; or that she will give effect to some_**
provisions of ECAT, but not others.

55. As it had been before Linden J, the respondent's position before us on this issue was somewhat
puzzling. Her position caused Linden J to undertake a detailed analysis of version 4 of the policy guidance
and its predecessors, in order to determine whether, as matter of interpretation, the policy guidance does
currently have the purpose of guiding caseworkers to make decisions that are in accordance with ECAT.

56. In carrying out this analysis, Linden J observed that, under the section of the policy guidance headed
“Related external links”, there are hyperlinks both to PK (Ghana) and to the ECAT. He also observed that,
in the policy guidance, the three categories of case where discretionary leave (DL) may be considered
precisely mirror the three categories arising from Article 14.1 of ECAT; namely, personal circumstances,
pursuing compensation (like personal circumstances, an aspect of “personal situation” in Article 14.1(a))
and helping police with their enquiries (paragraphs 71 to 76). At paragraph 77, he noted the statement of
Mr Tam QC on behalf of the respondent that the respondent's policy was to comply with ECAT. Linden J
held that it “would therefore be surprising if, exceptionally, the intention was that ECAT did not apply under

[the policy guidance]” (paragraph 77).


-----

guidance)

57. All this led Linden J to conclude at paragraph 79 that the policy guidance “overwhelmingly
demonstrates a commitment to take decisions as to discretionary leave in accordance with ECAT albeit, for
reasons which I will explain, the requirements of Article 14 have not been fully appreciated”.

58. Before us, Ms Wilsdon advanced no submissions on this issue that had not, in substance, featured
before Linden J. We see no reason to depart from his finding that, as was the position with its
predecessors, version 4.0 of the policy guidance is intended to guide the respondent's caseworkers to take
decisions which are in accordance with ECAT. Like Linden J, we do not find that there is any reason to
conclude that the respondent's policy is to implement some, but not all, of the provisions of ECAT.

**_G. DETERMINING THE LEGALITY OF THE POLICY GUIDANCE_**

59. In KTT, Linden J, having reached the conclusion that the Secretary of State's policy was to take
decisions as to discretionary leave in accordance with ECAT, went on to consider the correct interpretation
of Article 14(1)(a) of ECAT, as it bore on the question before him. As we have seen, this question was
whether KTT's stay in the United Kingdom, in order to pursue a claim for international protection based on
her fear of re-trafficking, meant that it was “necessary” for her to be issued a residence permit, in order to
comply with Article 14; or whether the statutory provisions that precluded her from being removed from the
United Kingdom meant such a permit was unnecessary. Linden J addressed this “interpretation” issue,
beginning at paragraph 81 of his judgment.

60. With one proviso, we agree with Ms Wilsdon that Linden J's findings on the “interpretation” issue have
no material bearing on the decision we must reach in the present judicial review. The proviso concerns the
way in which a domestic court or Tribunal should interpret ECAT. In Nautical Challenge Ltd v Evergreen
Marine (UK) Ltd [2021] 1 WLR 1436, the Supreme Court held, at paragraph 38, that international
conventions should be interpreted by reference to “broad and general principles of construction rather than
any narrower domestic law principles”. Those general principles include the general rule of interpretation,
set out in Article 31.1 of the Vienna Convention on the Law of Treaties 1969. This provides that a treaty
shall be interpreted in good faith in accordance with the ordinary meaning to be given to the terms of the
treaty in their context and in the light of the treaty's object and purpose.

61. We agree with Linden J that we should follow that approach in construing ECAT, in order to decide
whether the Secretary of State's policy guidance on a further grant of discretionary leave, requests for
indefinite leave to remain and standard grant of leave periods, is unlawful.

62. Let us take stock. We have concluded that the policy of the respondent is to give effect to ECAT; and
that the policy guidance is to be interpreted as the mechanism by which the respondent seeks to do so.
This is the basis on which we must decide the specific challenge brought by the claimant against the policy
guidance.

63. In doing so, it seems to us that the Supreme Court judgments in A and BF (Eritrea) affect the way in
which the concessions in Atamewan and PK (Ghana) – and the corresponding finding of Sir Stephen Silber
in Galdikas - fall to be understood.

64. The Supreme Court judgments in A and BF (Eritrea) concern policies which, in some way or other,
relate to provisions of domestic law. At paragraph 46 of the judgment in A, the Supreme Court identified
three categories of case where a policy may be found to be unlawful by reason of what it says or omits to
say about that law, when giving guidance for others. The third category is:
“Where the authority, even though not under a duty to issue a policy, decides to promulgate one and in
doing so purports in the policy to provide a full account of the legal position but fails to achieve that, either
because of a specific misstatement of the law or because of an omission which has the effect that, read as
a whole, the policy presents a misleading picture of the true legal position.”

65. Where the Secretary of State issues guidance to her own staff explaining the legal framework in which
they perform their functions, the Supreme Court held that the context is likely to be such as to bring it within
that third category:

-----

guidance)

“The audience for the policy would be expected to take direction about the performance of their functions
on behalf of their department from the Secretary of State at the head of the department, rather than
seeking independent advice of their own. So, read objectively, and depending on the content and form of
the policy, it may more readily be interpreted as a comprehensive statement of the relevant legal position
and its lawfulness will be assessed on that basis.”

66. As we have seen, the Supreme Court's test for assessing lawfulness, based on Gillick, is whether the
policy could be operated in a lawful way or whether it imposes requirements which mean that a material
and identifiable number of cases will be dealt with in an unlawful way. As the court said at paragraph 41, if
the policy directs its audience to act in a way that contradicts the law, it is unlawful. The courts are wellplaced to make a comparison of normative statements in the law and in the policy, objectively construing
both.

67. The test does not, however, depend on a statistical analysis of the extent to which relevant actors
might or might not fail to comply with their legal obligations. For this reason the Supreme Court rejected
the higher threshold, by which a policy's lawfulness is to be judged by reference to whether there is an
unacceptable risk that an individual would be treated unlawfully: paragraphs 63 to 65; and paragraph 74,
disapproving the test adopted in R(W) of whether there is a “real risk of unlawful outcomes in a 'significant'
or 'more than minimal' number of cases”.

68. In the present case, of course, ECAT is not a part of domestic law. We do not, however, consider that
this is a valid reason for failing to examine the lawfulness of the respondent's policy guidance through the
lens of A and BF (Eritrea). It would be strange if the very fact that ECAT does not have an independent
normative quality were to result in the policy guidance being subjected to a higher degree of public law
scrutiny, than would be the case if ECAT did have independent legal force.

69. At paragraph 78 of KTT, Linden J recorded that:
“There was an interesting discussion at the Hearing as to whether it made a difference if the treaty was
written out in full in the form of a policy document, at one extreme, or simply stated that the policy of the
government was that decisions as to discretionary leave would be taken in accordance with ECAT, on the
other. My view is that the form does not matter. What matters is the question whether the stated policy
conveys to the reasonable reader that this is the approach which will be taken.”

70. For the purposes with which Linden J was concerned at that point of his judgment, the question of
form did not matter. Linden J was at that point considering whether a legal connection between ECAT and
the policy guidance was established. He held that it was; and we respectfully agree.

71. In order to decide the nature of the legal relationship between ECAT and the policy guidance, the
question is, however, important. The ECAT and the policy guidance are not to be read together as merely
a single policy of the respondent, which may be judicially scrutinised in its entirety and declared unlawful if
found in any respect to be internally inconsistent. Despite not being incorporated into domestic law, ECAT
is not itself a policy of the respondent, whose terms can be changed or abrogated by her. ECAT remains
an international set of obligations. Accordingly, when seeking to establish the appropriate public law
mechanism for assessing the lawfulness of the respondent's policy guidance, it is essential to recognise
that the respondent has chosen to give ECAT normative effect, with the policy guidance being a set of
instructions to her caseworkers on how to make decisions that give effect to ECAT.

72. For these reasons, we find that the lawfulness of the policy guidance falls to be determined according
to the principles set out in A and BF (Eritrea). This does not, of course, mean that earlier decisions, in
particular PK (Ghana), were wrong. In PK (Ghana) by directing her caseworkers to ask whether a victim's
circumstances were “compelling”, instead of whether they were such as to make it “necessary” to grant
discretionary leave, the respondent plainly fell foul of the Gillick test, as articulated and explained by the
Supreme Court.

**_H. DECIDING THE GROUNDS_**


-----

guidance)

73. We can now turn to the applicant's grounds of challenge.

**_Ground 1_**

74. As we have seen, ground 1 asserts that the respondent's policy guidance is unlawful because it is
unclear and imprecise, as regards the length of DL, when granted for the purpose of enabling the individual
to receive medical treatment. In oral submissions, Mr Bandegani informed us that this ground was no
longer being advanced as a free-standing ground of challenge. Indeed, Mr Bandegani said that the thrust
of the applicant's criticism of the policy guidance was not that it was too vague but, rather, that it was too
detailed; and that its detail was incompatible with ECAT.

75. For completeness, however, we record that we in any event reject ground 1. The ground is
fundamentally inconsistent with the points made by the Supreme Court at paragraph 47 of A. The present
case is, in reality, a “category (iii) case”, as described in paragraph 46, with the result that the Supreme
Court's observations at paragraph 47 apply: there is no requirement for the policy guidance “to go into full
detail about how exactly a discretion should be exercised in every case.”

**_Ground 2_**

76. Ground 2 seeks, in effect, to align the applicant's present challenge with that of the claimant in PK
(Ghana). Just as the Court of Appeal held that the use of “compelling” constituted a materially different test
from that contained in ECAT, based on whether a person's stay is “necessary”, the applicant submits that
instructing caseworkers “normally” to limit a grant of DL to (at most) 30 months places a presumptive cap
on the duration of leave. The requirement for caseworkers to distinguish individual circumstances to a
“high degree” from other cases, when deciding whether to grant longer periods of leave beyond or towards
the top end of the “up to 30 months” of DLR is, likewise, unlawful; as is the imposition of a “high” threshold
where requests are made for indefinite leave to remain. Finally, the “expectation” in cases involving
children of DLR up to 30 months with a “separate” requirement on parents who wish to secure a longer
period of leave is also unlawful. In all these respects, Mr Bandegani says that the relevant passages of the
policy guidance do precisely what the Court of Appeal in PK (Ghana) held that the respondent could not
do; namely, exceed the requirements of ECAT.

77. There are a number of problems with ground 2. First, there is no evident incompatibility of
terminology, as between the policy guidance and ECAT, as there was between the former policy
guidance's use of “compelling” and ECAT's use of “necessary”. The second problem stems from the first.
Unlike PK (Ghana) and KTT, the present challenge does not concern the core question of whether a
residence permit (here, DL) should be granted. We are concerned with the length of the residence
permit/DL. But ECAT has nothing to say about the length of any residence permit, other than that it must
be “renewable” (Article 14.1), which is a point in favour of the respondent, as it suggests that an initial
residence permit may well not be coterminous with the period of stay which is “necessary owing to [the
individual's] personal situation”.

78. Paragraph 182 of the Explanatory Report also assists the respondent. As we have seen, this makes it
plain that a residence permit may be issued either on the basis that the victim's stay is “necessary owing to
their personal situation” or that it is necessary “for the purpose of their co-operation with the competent
authorities in investigation or criminal proceedings”. Paragraph 182 says that the aim of these
requirements “is to allow Parties to choose between granting a residence permit in exchange for cooperation with the law enforcement authorities and granting a residence permit on account of the victim's
needs, or indeed to adopt both simultaneously”. It would, therefore, be permissible for the respondent to
grant a period of leave by reference to the victim's anticipated co-operation with the police (Article 14.1(b)),
even where the victim's mental or physical health needs would point to the necessity of them being granted
a longer period of leave under Article 14.1(a).

79. In the light of this, the applicant faces a serious problem in contending that the language of the policy
guidance is unlawful. Even adopting the required purposive construction of ECAT, there is no clear linkage
between what is “necessary” to trigger the obligation to grant a residence permit and the duration of any


-----

guidance)

such permit. This means that signatory States have at least a significant measure of discretion in
determining the duration of such permits. That, in turn, makes it difficult to say the wording of the policy
guidance is such as to lead to a material and identifiable number of cases being dealt with “unlawfully” by
caseworkers, in the sense of being incompatible with ECAT.

80. Even if the test of necessity is to be followed when caseworkers are deciding upon the duration of DL,
we consider that the language used in the policy guidance is unexceptionable. The first point to notice is
that on page 11 of 16, under the heading “Further grants of discretionary leave”, appropriate provision is
made for further periods of DL to be granted “where the individual continues to meet the eligibility criteria
set out in this policy”. As we have already noted by reference to paragraph 182 of the Explanatory Report,
the eligibility criteria do not have to be addressed simultaneously. In any event, the policy guidance
imposes no threshold for granting further leave. All that is required is for the individual to meet the relevant
criteria, which, in the case of Article 14.1(a), will be that it “is necessary owing to their personal situation”.

81. On page 12 of 16, under the heading “Requests for indefinite leave to remain”, the policy guidance
says that the threshold for a grant of ILR outside the Immigration Rules “is a high one”. That is entirely
correct, as a matter of fact. Indefinite leave to remain stands at the apex of the forms of leave that can be
granted under the Immigration Acts. Even where leave is granted in response to an individual's rights
under the ECHR, it is normally limited in nature, albeit renewable and with the potential to lead to ILR in
due course.

82. The policy guidance is, at this point, doing no more than alerting caseworkers to the obvious fact that
there needs to be a cogent reason to grant ILR to a person whose eligibility for any form of leave to remain
will often depend solely upon Article 14 of ECAT. If the position were otherwise, ECAT would make major
inroads into the competence of signatory States in the immigration field. Particularly in view of what we
have held at paragraphs 77 and 78 above, we do not find that the signatories to ECAT intended such a
result. We shall have more to say on this issue at paragraph 88 below.

83. On page 14 of 16, under the heading “Standard grant of leave periods”, it is stated that where DL is
granted for medical treatment, this should normally be for up to 30 months; although when the initial leave
expires, a further period of leave may be granted on application. This paragraph is immediately followed
by one which says that in the case of assisting police enquiries, or for the purposes of pursuing a
compensation claim, leave should be for the time considered necessary depending on the circumstances,
up to a maximum of twelve months in the first instance. As we have explained, the effect of paragraph 182
of the Explanatory Report is such that it would in theory be perfectly possible for the respondent to decide
to grant twelve months' leave, for the purposes of assisting police enquiries, even though the individual
concerned required medical treatment, which could have resulted in up to eighteen months' more leave
being granted.

84. Even on its own terms, the first paragraph, concerning medical treatment, is in any case lawful.
Bearing in mind that we are concerned with a policy, there is no material difficulty with the concept of DL
being granted “normally … for up to 30 months”. Where the evidence indicates a need for medical
treatment of, for example, twelve months, the policy permits twelve months' leave to be granted.

85. The third paragraph, which is common to both the medical treatment and police/compensation
categories, provides that for longer periods of DL to be granted there must be sufficient evidence to
demonstrate that the individual circumstances of the case “can be distinguished to a high degree from
other cases”.

86. Mr Bandegani strongly attacked this particular phrase. Again, however, what the applicant must show
is whether the phrase is such that a material and identifiable number of cases will be dealt with unlawfully
by the caseworkers operating by reference to it. In this regard, it must be remembered – as the applicant
was at pains to point out – that the policy guidance contains a hyperlink to ECAT. Caseworkers can,
therefore, be expected to be conversant with Article 14, when making decisions as to the length of DL.


-----

guidance)

87. Unlike the case in PK (Ghana), there is, here, no requirement to apply a test which is plainly
incompatible with the language of ECAT. The phrase needs to be read in the light of the fact that the initial
period of DL in medical treatment cases can, normally, be up to 30 months; and that further periods of DL
can be granted where the relevant eligibility criteria continue to exist.

88.  Once these points are grasped, it can be seen that the phrase “distinguished to a high degree…”, like
the phrase “is a high one” in the passage concerning ILR, does no more than to indicate to the caseworker
that there needs to be a good reason before granting a longer period than 30 months. Importantly, the
words do not require the caseworker to find that the longer period of stay has to be shown to be more than
merely “necessary owing to [the individual's] personal situation”. Rather, the words require a careful
examination of the relevant circumstances, so as to ensure that the longer period really is “necessary”.

89. This leads to the final aspect of ground 2, concerning the grant of leave to parents of children. So far
as concerns children themselves, the policy guidance is plainly free from difficulty. Specific reference is
made to the section 55 duty to make the child's best interests a primary consideration. There is also a
specific reference at this point to Article 14.2 of ECAT. The best interests consideration can lead to a
decision that the child should be granted ILR, albeit that “the expectation [is] that in most cases a standard
period of up to 30 months DL will be appropriate”.

90. The next paragraph of the policy guidance, beginning “Parents of children granted extended leave …”
is likewise unexceptionable in requiring the parent to demonstrate factors in their own right to warrant
departure from the standard grant of DL. The description of these factors as “compassionate” is no way
comparable to the use of “compelling” in the former guidance, which troubled the Court of Appeal in PK
(Ghana). As with cases not involving children, the language on page 15 of 16 of the policy guidance
cannot reasonably be read as an instruction to caseworkers to do anything which is contrary to Article 14.1
or 14.2 of ECAT. On the contrary, the language is intended to assist the caseworker to assess the very
different types of case that fall to be determined under the overarching test of necessity. It must also be
remembered that the parent (as opposed to the child) may not be a victim of modern slavery.

91. Ground 2 accordingly fails.

**_Ground 3_**

92. Ground 3 is now confined to the proposition that the respondent was obliged to explain why she
rejected the opinion of Professor Katona that a longer period of DLR, including ILR, was clinically
appropriate and necessary for the purposes of treatment.

93. We do not find that this ground is made out. The letter of 6 January 2021 from the applicant's
solicitors, which enclosed the report from Professor Katona, set out at paragraph 2 a series of findings by
the Professor. As we have seen, these included, but were by no means limited to, the finding that
unlimited leave to remain “would make the best clinical sense” and that treatment for CPTSD can only take
place “if the individual has a sufficient sense of security”. Significantly, paragraph 3 of the letter said that it
was “clear that the findings in Professor Katona's report clearly support our submission that the grant of 12
months is insufficient in the applicant's individual case”. It was not suggested by the solicitors that anything
in Professor Katona's report meant that only the grant of indefinite leave to remain constituted what was
“necessary” owing to the applicant's “personal situation”. That was unsurprising, given the terms of
Professor Katona's comments on ILR, which did not contend that nothing less than ILR was “necessary”,
merely that it was desirable or optimal. In short, read overall, the letter was effectively contending that the
grant of twelve months leave would be legally insufficient; nothing more.

Against that background, there is nothing unlawful in the terms of the decision letter. As we have already
set out, this stated that a total of 30 months' leave had been granted “to allow your client to access the 3
phased intervention treatment recommended” in the preliminary psychiatric report of 25 September 2020.
The timescale in that report would be covered by the grant of 30 months' leave. In the circumstances, the
decision letter did not need to engage with Professor Katona's view that indefinite leave to remain would
make the best clinical sense.


-----

guidance)

**_I. DECISION_**

The application for judicial review is dismissed.

**Direction Regarding Anonymity – Rule 14 of the Tribunal Procedure (Upper Tribunal)**
**Rules 2008**

Unless and until a Tribunal or court directs otherwise, the applicant is granted anonymity. No report of these
proceedings shall directly or indirectly identify her or any member of her family. This direction applies both to the
applicant and to the respondent. Failure to comply with this direction could lead to contempt of court proceedings.

Mr Justice Lane

The Hon. Mr Justice Lane

President of the Upper Tribunal

Immigration and Asylum Chamber

7 December 2021

**End of Document**


-----

