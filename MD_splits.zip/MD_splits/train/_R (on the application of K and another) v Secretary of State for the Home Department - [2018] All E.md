(Nov)

# *R (on the application of K and another) v Secretary of State for the Home
 Department [2018] All ER (D) 50 (Nov)

[2018] EWHC 2951 (Admin)

Queen's Bench Division, Administrative Court (London)

Mostyn J

8 November 2018

**Immigration – Trafficking people for exploitation – Sibsistence payments**
Abstract

_Immigration – Trafficking people for exploitation. The 42% cut in the weekly cash amount payable to potential_
_victims of human trafficking who were seeking asylum from £65 to £37.75 was irrational and perverse, as well as_
_being outside the tightly confined variation power within the contract between the defendant Secretary of State and_
_the Salvation Army for the provision of services. Accordingly, the Administrative Court quashed the contract change_
_and held that the claimants were entitled to be repaid at the rate of £27.25 per week from the date that the cut had_
_been imposed on them until the date of repayment._
Digest

The judgment is available at: [2018] EWHC 2951 (Admin)

**Background**

The defendant Secretary of State entered a contract with the first interested party (the Salvation Army) for the
provision of subsistence, counselling, medical care, and legal advice and assistance to certain potential victims of
human trafficking. The parties agreed that the Salvation Army would provide 'service users' with subsistence
payments in cash in accordance a table, which included that service users accommodated by the authority and in
receipt of subsistence payments through that service were entitled to £65 minus the amount of subsistence
received from the authority (the weekly subsistence payment for asylum-seekers being £37.75). The strict terms of
the contract did not permit the Home Office either to initiate a variation, let alone to impose one unilaterally, save in
the case of an emergency.

In October 2017, reforms to the National Referral Mechanism were announced to align subsistence rates provided
to victims of modern slavery to those received by asylum seekers. In February 2018, a revised contract change
notice sent to the Salvation Army provided a fixed sum for (asylum-seeking) victims of trafficking of £27.25.
Therefore, the £27.25 would be deducted from the £37.75 asylum money, reducing that to £10.50 and ensuring that
the overall payment received by that class of victim was only £37.75, in line with other asylum seekers.

Accordingly, the weekly cash amount payable to potential victims of human trafficking who were seeking asylum
was cut by 42% from £65 to £37.75. The claimants issued judicial review proceedings, contending that the cut was
unlawful. They sought the quashing of the decision that brought about the cut and compensation at the weekly rate
of £27.25.

Application allowed


-----

(Nov)

**Issues and decisions**

Whether the plain meaning of the contractual term concerning subsistence payments was a mistake and it had
never been intended that a victim of trafficking who was seeking asylum should get more than the weekly
subsistence payment for general asylum seekers, namely £37.75.

The cut had been a very substantial one imposed unilaterally by the Home Office. The decision had been taken on
a false basis and could not stand. There had been no common mistake which had needed to be rectified. Rather, it
had been a partial implementation of the policy announced in October 2017, although it had not been done in a
procedurally correct or fair way, and had been dressed up as a rectification of a mistake. In public law terms, the
decision could be characterised as irrational and perverse, as well as being outside the tightly confined variation
power within the contract (see [21], [22] of the judgment).

Accordingly, the contract change would be quashed. The claimants and anyone else subjected to the cut were
entitled to be repaid at the rate of £27.25 per week from the date that the cut had been imposed on them until the
date of repayment (see [32] of the judgment).

_R (on the application of ZV) v Secretary of State for the Home Department_ _[[2018] EWHC 2725 (Admin) criticised.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5THF-NB01-F0JY-C2JK-00000-00&context=1519360)_

Nathalie Lieven QC and Shu Shin Luh (instructed by Wilson Solicitors LLP) for the first claimant.

Chris Buttler and Ayesha Christie (instructed by Simpson Millar LLP) for the second claimant.

Clive Sheldon QC and Joe Barrett (instructed by Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

