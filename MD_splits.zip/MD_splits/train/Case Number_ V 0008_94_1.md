# Case Number: V 0008/94 [1994] Lexis Citation 4951

BESCHWERDEKAMMERN DES EUROPÄISCHEN PATENTAMTS; BOARDS OF APPEAL OF THE EUROPEAN
PATENT OFFICE; CHAMBRES DE RECOURS DE L'OFFICE EUROPEEN DES BREVETS

Howard Florey Institute

Fraktion der Grünen im europäischen Parlament

Paul Lannoye

DECISION of 08 December 1994

**DNA encoding human protein**

**Novelty (yes)**

**Inventive step (yes)**

**Discovery (no)**

**Contrary to morality (no)**
_Headnote:_

I. A DNA fragment encoding a human protein, such as human H2- relaxin or its precursors, does not lack novelty by
virtue of having always been present in the human body (point 4 of the reasons).

II. The isolation and characterisation of a DNA fragment encoding a human protein does not represent a discovery
(point 5 of the reasons).

III. The isolation of mRNA encoding a human protein from human tissue is not immoral, nor is the patenting of a
DNA fragment encoding human proteins intrinsically unethical (point 6 of the reasons).

Boards of appeal: Opposition Division

Application Number: 83307553.4

Language of the proceedings: EN

Published in OJ: 1995/388

Relaxin

EPC Art 052(2)(a), EPC Art 053(a), EPC Art 054, EPC Art 056, EPC Art 099(1), EPC Art 100(a), EPC R 055, EPC
R 100(1)


-----

Please find following the claims of EP-B-112149 for readers' convenience:

Claims of EP-B-112 149

1. A DNA fragment encoding human H2-preprorelaxin, said H2- preprorelaxin having the amino acid sequence set
out in Figure 2.

2. A DNA fragment encoding human H2-prorelaxin, said H2- prorelaxin having the amino acid sequence set out in
Figure 2 with the exception that the signal sequence is excluded.

3. A DNA fragment encoding a polypeptide having human H2- relaxin activity, said polypeptide having an A-chain
and a B- chain comprising the following amino acid sequences:

A-Chain

Gln Leu Tyr Ser Ala Leu Ala Asn Lys Cys Cys His Val Gly Cys Thr Lys Arg Ser Leu Ala Arg Phe Cys

B-Chain

Asp Ser Trp Met Glu Glu Val Ile Lys Leu Cys Gly Arg Glu Leu Val Arg Ala Gln Ile Ala Ile Cys Gly Met Ser Thr Trp
Ser Lys Arg Ser Leu.

4. A DNA fragment encoding the signal A, B or C peptide chains of human H2-relaxin or any combination of two or
more of said chains; wherein said peptide chains have the following amino acid sequences:

Signal Peptide

Met Pro Arg Leu Phe Phe Phe His Leu Leu Gly Val Cys Leu Leu Leu Asn Gln Phe Ser Arg Ala Val Ala

A-Chain

Gln Leu Tyr Ser Ala Leu Ala Asn Lys Cys Cys His Val Gly Cys Thr Lys Arg Ser Leu Ala Arg Phe Cys

B-Chain

Asp Ser Trp Met Glu Glu Val Ile Lys Leu Cys Gly Arg Glu Leu Val Arg Ala Gln Ile Ala Ile Cys Gly Met Ser Thr Trp

Ser Lys Arg Ser Leu

C-Chain

Ser Gln Glu Asp Ala Pro Gln Thr Pro Arg Pro Val Ala Glu ale Val Pro Ser Phe Ile Asn Lys Asp Thr Glu Thr Ile Asn
Met Met Ser Glu Phe Val Ala Asn Leu Pro Gln Glu Leu Lys Leu Thr Leu Ser Glu Met Gln Pro Ala Leu Pro Gln Leu
Gln Gln His Val Pro Val Leu Lys Asp Ser Ser Leu Leu Phe Glu Glu Phe Lys Lys Leu Ile Arg Asn Arg Gln Ser Glu
Ala Ala Asp Ser Ser Pro Ser Glu Leu Lys Tyr Leu Gly Leu Asp Thr His Ser Arg Lys Lys Arg.

5. A double-stranded DNA fragment encoding human H2- preprorelaxin, characterized in that it comprises a coding
strand and a complementary strand corresponding to the complete mRNA sequence:

AUG CCU CGC CUG UUU UUU UUC CAC CUG CUA GGA GUC UGU UUA CUA CUG AAC CAA UUU UCC AGA
GCA GUC GCG GAC UCA UGG AUG GAG GAA GUU AUU AAA UUA UGC GGC CGC GAA UUA GUU CGC
GCG CAG AUU GCC AUU UGC GGC AUG AGC ACC UGG AGC AAA AGG UCU CUG AGC CAG GAA GAU
GCU CCU CAG ACA CCU AGA CCA GUG GCA GAA AUU GUG CCA UCC UUC AUC AAC AAA GAU ACA GAA
ACC AUA AAU AUG AUG UCA GAA UUU GUU GCU AAU UUG CCA CAG GAG CUG AAG UUA ACC CUG UCU
GAG AUG CAG CCA GCA UUA CCA CAG CUA CAA CAA CAU GUA CCU GUA UUA AAA GAU UCC AGU CUU
CUC UUU GAA GAA UUU AAG AAA CUU AUU CGC AAU AGA CAA AGU GAA GCC GCA GAC AGC AGU CCU


-----

UCA GAA UUA AAA UAC UUA GGC UUG GAU ACU CAU UCU CGA AAA AAG AGA CAA CUC UAC AGU GCA
UUG GCU AAU AAA UGU UGC CAU GUU GGU UGU ACC AAA AGA UCU CUU GCU AGA UUU UGC UGA

6. A double-stranded DNA fragment encoding human H2-prorelaxin, characterized in that it

comprises a coding strand and a complementary strand corresponding to the following mRNA sequence:

GAC UCA UGG AUG GAG GAA GUU AUU AAA UUA UGC GGC CGC GAA UUA GUU CGC GCG CAG AUU
GCC AUU UGC GGC AUG AGC ACC UGG AGC AAA AGG UCU CUG AGC CAG GAA GAU GCU CCU CAG ACA
CCU AGA CCA GUG GCA GAA AUU GUG CCA UCC UUC AUC AAC AAA GAU ACA GAA ACC AUA AAU AUG
AUG UCA GAA UUU GUU GCU AAU UUG CCA CAG GAG CUG AAG UUA ACC CUG UCU GAG AUG CAG CCA
GCA UUA CCA CAG CUA CAA CAA CAU GUA CCU GUA UUA AAA GAU UCC AGU CUU CUC UUU GAA GAA
UUU AAG AAA CUU AUU CGC AAU AGA CAA AGU GAA GCC GCA GAC AGC AGU CCU UCA GAA UUA AAA
UAC UUA GGC UUG GAU ACU CAU UCU CGA AAA AAG AGA CAA CUC UAC AGU GCA UUG GCU AAU AAA
UGU UGC CAU GUU GGU UGU ACC AAA AGA UCU CUU GCU AGA UUU UGC UGA

7. A double-stranded DNA fragment encoding the signal peptide. A, B or C peptide chains of human H2preprorelaxin or a combination of any two or more of said chains characterized in that it comprises a coding strand
and a complementary strand corresponding to the appropriate mRNA sequence or combination of the mRNA
sequences given below:

Signal Peptide

AUG CCU CGC CUG UUU UUU UUC CAC CUG CUA GGA GUC UGU UUA CUA CUG AAC CAA UUU UCC AGA
GCA GUC GCG

A-Chain

CAA CUC UAC AGU GCA UUG GCU AAU AAA UGU UGC CAU GUU GGU UGU ACC AAA AGA UCU CUU GCU
AGA UUU UGC

B-Chain

GAC UCA UGG AUG GAG GAA GUU AUU AAA UUA UGC GGC CGC GAA UUA GUU CGC GCG CAG AUU
GCC AUU UGC GGC AUG AGC ACC UGG AGC AAA AGG UCU CUG

C-Chain

AGC CAG GAA GAU GCU CCU CAG ACA CCU AGA CCA GUG GCA GAA AUU GUG CCA UCC UUC AUC AAC
AAA GAU ACA GAA ACC AUA AAU AUG AUG UCA GAA UUU GUU GCU AAU UUG CCA CAG GAG CUG AAG
UUA ACC CUG UCU GAG AUG CAG CCA GCA UUA CCA CAG CUA CAA CAA CAU GUA CCU GUA UUA AAA
GAU UCC AGU CUU CUC UUU GAA GAA UUU AAG AAA CUU AUU CGC AAU AGA CAA AGU GAA GCC GCA
GAC AGC AGU CCU UCA GAA UUA AAA UAC UUA GGC UUG GAU ACU CAU UCU CGA AAA AAG AGA

8. A process for the production of a DNA fragment as set out in any one of claims 1 to 7, characterized in that it
comprises screening a human cDNA clone bank using as a probe a fragment of human H1-relaxin DNA.

9. A process as claimed in claim 8, characterized in that the said fragment comprises nucleotides of C-peptide/Apeptide coding region of the human H1-relaxin DNA.

10. A DNA transfer vector, characterized in that it contains a cDNA deoxynucleotide sequence corresponding to a
gene or DNA fragment as defined in any one of claims 1 to 7.

11. A DNA fragment, or DNA transfer vector as claimed in any one of claims 1 to 7 and 10, characterized in that
one or more natural codons or their cDNA equivalents are replaced by another codon which codes for the same
amino acid.


-----

12. A DNA transfer vector as claimed in claim 10 or 11, characterized in that it is a bacterial plasmid.

13. A DNA transfer vector as claimed in claims 10 or 11, characterized in that it is a bacteriophage DNA.

14. A cell transformed by a transfer vector as claimed in any one of claims 10 to 13.

15. A process for making a DNA transfer vector for use in maintaining and replicating a deoxynucleotide sequence
coding for human H2-preprorelaxin or a sub-unit thereof according to any one of claims 1 to 7, characterized in that
it comprises reacting said deoxynucleotide sequence with a DNA molecule prepared by cleaving a transfer vector
with a restriction enzyme.

16. A process for making a fusion protein comprising an amino acid sequence consisting of all or part of the amino
acid sequence of human H2-prorelaxin as its C-terminal sequence and a protein of a prokaryotic protein as its Nterminal sequence, characterized in that it comprises incubating a microorganism transformed by an expression
transfer vector comprising the appropriate deoxynucleotide sequence.

17. A process for synthesising human H2-prorelaxin comprising the A and B peptides separated from each other by
a C peptide, characterized in that it comprises incubating a micro-organism, transformed by an expression transfer
vector comprising a deoxynucleotide sequence coding for said human prorelaxin under conditions suitable for
expression of said sequence coding for human prorelaxin, and purifying human prorelaxin from the lysate or culture
medium of said micro-organism.

18. A fusion protein comprising an amino acid sequence characterized in that it consists of all or part of the amino
acid sequence of human H2-prorelaxin as its C-terminal sequence and a portion of a prokaryotic protein as its Nterminal sequence.

19. Synthetic human H2-preprorelaxin having the amino acid sequence as set out in Figure 2.

20. Synthetic human H2-prorelaxin having the amino sequence as set out in figure 2 with the exception that the
signal sequence is excluded.

21. A polypeptide having human H2-relaxin activity, said polypeptide having a disulphide bonded A-chain and Bchain comprising the following amino acid sequences:

A-Chain

Gln Leu Tyr Ser Ala Leu Ala Asn Lys Cys Cys His Val Gly Cys Thr Lys Arg Ser Leu Ala Arg Phe Cys

B-Chain

Asp Ser Trp Met Glu Glu Val Ile Lys Leu Cys Gly Arg Glu Leu Val Arg Ala Gln Ile Ala Ile Cys Gly Met Ser Thr Trp
Ser Lys Arg Ser Leu.

ORDER

For the above reasons it is decided that the grounds for opposition do not prejudice the maintenance of the patent
as granted. The opposition is therefore rejected in accordance with Article 102(2) EPC.

© 2001. European Patent Office.

**End of Document**


-----

