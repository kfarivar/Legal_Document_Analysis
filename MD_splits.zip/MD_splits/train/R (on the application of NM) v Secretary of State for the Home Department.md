# R (on the application of NM) v Secretary of State for the Home Department

 [2017] EWHC 2798 (Admin)

Queen's Bench Division, Administrative Court (Leeds)

Judge Saffman (sitting as a Judge of the High Court)

12 December 2017Judgment

**Miss L Mair for the Claimant**

**Miss N Barnes for the Defendant**

Hearing date: 1 and 2 November 2017

Date draft circulated to the Parties: 8 November 2017

Date handed down 12 December 2017

- - - - - - - - - - - - - - - - - - - - 
I direct that, pursuant to CPR PD 39A para 6.1, no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

**JUDGMENT**

_Introduction_

1. In this case, the claimant, NM, a national of Malawi, challenges a decision made on 29 September 2016 by
which the defendant, the Secretary of State for the Home Department acting in her capacity as the Competent
Authority, rejected her claim that the claimant was a victim of human trafficking (the Decision). By her claim form,
the claimant seeks, amongst other things, an order quashing the Decision and a mandatory order requiring the
defendant to reconsider the Decision.

2. Article 4 (a) of _The Council of Europe Convention on Action against Trafficking in Human Beings_ (The
Convention)1 defines trafficking in human beings as:

“The recruitment, transportation, transfer, harbouring or receipt of persons by means of the threat or use of force or
_other forms of coercion, of abduction, of fraud, deception, of the abuse of power or of a position of vulnerability or of_
_the giving or receiving of payments or benefits to achieve the consent of a person having control over another_
_person, for the purpose of exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of_
_others or other forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery,_
_servitude or the removal of organs.”_

3. It is undisputed that the definition gives rise to 3 interlocking components all of which need to be present before
human trafficking of an individual is established. These are:

a. An “action” – the person concerned must have been subject to an act of recruitment, transportation, transfer,
harbouring or receipt – which is achieved by


-----

b. A “means” – consisting of the threat or use of force or other form of coercion, of abduction, of fraud, of
deception, of abuse of power, of a position of vulnerability, of giving or receiving payments or benefits to achieve
the consent of a person having control over another person – for the purpose of

c. “Exploitation” – sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude,
forced criminality or the removal of organs.

4. By the Decision, the defendant concluded that there were insufficient grounds, on the balance of probabilities, to
believe that the claimant had been “a victim of **_modern slavery (human trafficking or slavery, servitude or_**
_forced/compulsory labour).”_

5. In the summary to the “Conclusive Grounds Consideration Minute” the defendant stated:

“Following the guidance to Competent Authorities the decision maker does not have to be certain that **_modern_**
**_slavery (human trafficking or slavery, servitude or forced/compulsory labour) did occur, the correct test is that it is_**
_more likely than not to have taken place. Based on the information available, it is considered that you do not meet_
_the 3 constituent elements of the trafficking definition or 2 constituent elements of slavery, servitude and_
_forced/compulsory labour on the “balance of probabilities” and as such it is not accepted conclusively that you are a_
_victim of modern slavery.”_

6. It has to be said that it is not immediately clear to me what the 2 constituent elements of slavery, servitude and
forced/compulsory labour to which the summary refers actually are.

7. Slavery, servitude and forced or compulsory labour are prohibited by Article 4 European Convention on Human
_Rights. Article 4 ECHR provides that no one shall be held in slavery or servitude and no one shall be required to_
perform forced or compulsory labour. The claimant does not argue that she was held in slavery or servitude but she
does contend that she was a victim of compulsory (or forced) labour.

8. It is right that there are 2 constituent elements of forced/compulsory labour. _The International Labour_
_Organisation Forced Labour Convention (Convention 29) 1930 defines forced or compulsory labour as:_

“All work or service which is exacted from any person under the menace of any penalty and for which the said
_person has not offered himself voluntarily.”_

It is common ground that in order for forced labour to be established the victim must be working under both
“menace of penalty” and their services must not be voluntarily given.

9. Referring back to paragraph 6 above, the claimant contends that insofar as the Decision concludes that, even on
her account, either or both of these 2 elements are not met then the Decision is irrational and/or otherwise unlawful.

10. It will be remembered that the definition of “exploitation” for the purpose of the Convention2 includes a situation
where the person concerned is a victim of forced labour. If the exploitation has taken that form and there has also
been “an action” and “a means” as I have set out above, then the victim meets the criteria for being a victim of
trafficking.

11. In the “Decision” recorded at the end of the Consideration Minute the defendant stated:

“It has, therefore, been decided that you are not a victim of human trafficking within Malawi for the purpose of
_sexual exploitation or from Malawi to the UK for the purpose of domestic servitude. It has therefore been decided_
_that you do not require a period of leave for any reason associated with being a victim of trafficking._

_Similarly, it is not believed that you are a victim of slavery, servitude or forced/compulsory labour and do_
_not, therefore, require any leave.”_

12. The Decision which the claimant seeks to challenge by way of judicial review is the final conclusive decision of
the defendant. Article 10 of the Convention provides for the Competent Authority to identify victims of human


-----

trafficking by a two-stage process. At the initial stage the Competent Authority must consider whether there are
reasonable grounds to believe that a person has been the victim of trafficking. The second stage involves a more
in-depth analysis of the application in order to establish whether, on balance, the evidence indicates that the
applicant has actually been a victim of trafficking.

13. In this case the claimant was found to have met the test at the first stage but the defendant concluded that she
had failed to establish that she was the victim of trafficking on the balance of probabilities for the purpose of the
second, conclusive stage.

14. By a Judicial Review Claim Form issued on 23 December 2016 the claimant challenged the Decision on the
basis that it was irrational or otherwise unlawful on 3 grounds. The first was that the decision lacked anxious
scrutiny, the second was that there had been a flawed approach to issues of the credibility of the claimant and the
third ground alleged a breach of Article 4 ECHR.

15. On 3 March 2017 Jay J granted permission on the second ground (which in the proceedings before me has
been called the “Credibility Ground”) but refused it on the first and third ground. The substantive matter upon which
permission had been given came before me on 29 June 2017. I gave permission for the claimant to amend the
claim to include the contention that the Decision was also irrational or otherwise unlawful in that it was based upon
a conclusion that the claimant's circumstances, even on her own account, did not meet the criteria necessary to
establish human trafficking. At the same hearing on 29 June 2017 I gave the claimant permission to pursue that
ground at the substantive hearing. This new ground has been referred to during the course of this substantive
hearing as the “Definitional Ground”.

16. The claimant in this case has been represented by Miss Lucy Mair of counsel and the defendant by Miss
Natasha Barnes of counsel. I am grateful to both for their very helpful and skillful skeleton arguments and oral
submissions.

_The Background_

17. The Consideration Minute sets out in some detail the circumstances by which the claimant contends that she
came to the attention of the Competent Authority for the purpose of it becoming necessary for the Competent
Authority to conclude whether she was indeed the victim of human trafficking.

18. The claimant asserted that she is a national of Malawi born in April 1986. She married in Malawi and had a
child. Her husband died in 2012 and as a result she became impoverished. She was forced to turn to prostitution for
the purpose of supporting herself and her child and to bring food into her mother's household with whom she had
become obliged to reside when she became a penniless widow with a dependent child.

19. In early 2013 she learnt from a friend of an opportunity to work as a nanny in the UK. She was introduced to a
person by the name of Caro in February 2013 and was told by Caro that such a job was available and involved
looking after one very young child for which she would receive £300 per month after the first 3 months. She would
receive nothing in the first 3 months to defray the cost of her travel to the UK.

20. She arrived in the UK on 8 March 2014 having got here by a circuitous route involving flight stopovers in
Kenya, France, Eire and Northern Ireland before finally ending up in London. She was accompanied on this journey
by Caro. They were met at the airport in London by a British woman, Anne-Marie to whom Caro gave the claimant's
passport. Anne-Marie transported the claimant to her house in Leeds. There she was introduced to Anne-Marie's
infant daughter, Eve. She remained with Anne-Marie until 22 September 2014 when she presented herself at a
local police station in circumstances to which I shall come shortly.

21. During the 6 months that she lived at the home of Anne-Marie she was required to get up at 6am to look after
Eve as well as to undertake all the house cleaning, washing, cooking and ironing. Her daily duties did not stop until
Eve had been put to bed and even then, she was on call if Eve needed comforting and so her working hours
exceeded 12 per day. She had one day off per week but then too she was on call in the event that Eve needed
attention. She received no money, not even after the three-month period during which she had expected no pay.


-----

Occasionally Anne-Marie bought necessities for her including a coat and she provided her with necessary toiletries
but she received no cash. She was not minded to ask for payment. In the “case summary” section of the Decision it
is recorded that the claimant did not ask for her wages because she was scared that she may be asked to leave.
Furthermore, in Malawian culture it is “rude” to ask for one's wages. She thought perhaps that Anne-Marie could not
afford to pay her but that ultimately, she would pay her when her finances allowed.

22. She was not confined to Anne-Marie's house. She was free to leave the house and did so for the purpose of
taking Eve to a park very close to the house. Eventually, in about August 2014, in the course of her visits to the
park, she met another woman, Didi, who lived close by and with whom the claimant then built up a passing
acquaintance.

23. She did not leave the house for purposes other than taking Eve to the park, not even on her day off. She
preferred to use that day to do her washing and to “relax”. It is right to add that she had no money with which to
fund any excursions on her day off or indeed at any other time.

24. Anne-Marie worked as a nurse, usually on a night shift. Anne-Marie had a boyfriend, Frank who used to stay at
Anne-Marie's house from time to time including evenings when Anne-Marie was working. Frank started to make
unwelcome sexual overtures to the claimant which included sexually assaulting her. The claimant felt that ultimately
these assaults would culminate in Frank raping her. She resolved to leave the house before that happened and on
22 September she made her way to Didi's home in the hope that she could give her sanctuary.

25. Didi did not feel able to allow the claimant to stay with her but did agree to take her to a women's refuge. When
that could not be found Didi dropped her off at Killingbeck Police Station. Didi did not accompany the claimant into
the police station, she merely dropped her there.

26. It is not clear with what complaint the claimant presented at the police station but it is clear that the police
enquiries led them to conclude that she was an illegal immigrant and she was accordingly arrested on that ground.
It seems clear however that her presentation at the police station caused the police to consider whether she was a
victim of trafficking and as result the National Referral Mechanism for Potential Adult Victims of Trafficking (NRM)
was invoked and the appropriate referral was made. A referral is made on a pro forma which, amongst other things,
draws attention to 20 general indicators of trafficking. PC Simon Green who completed the NRM form, noted that
there was evidence that the claimant met 5 of the 20 indicators namely:

- evidence of control over movement

- passport or documents held by somebody else

- limited social contact

- limited contact with family

- does not know home or work address

27. He also noted that she met some of the indicators of forced labour namely:

- no or limited access to earnings or labour contract

- dependence on employer for a number of services for example work, transport and accommodation

And that she met one indicator of domestic servitude namely:

- Living with and working for a family in a private home

28. It is by reason of her referral under the NRM that it became incumbent upon the defendant to embark upon the
two-stage process referred to above to determine whether, on balance, the claimant was indeed a victim of
trafficking.


-----

29. On 7 November 2014 the claimant underwent an asylum screening interview3. On 24 November 2014 she
made a witness statement and on 1 December 2014 she had an asylum interview. In the course of the hearing
before me reference was made to her witness statement and her asylum interview but the Decision makes it clear
that it was reached having assessed all 3 documents together with further submissions dated 24 November 2014, 4
December 2014 and 26 February 2016, email correspondence dated 12 September 2016 with the police officer to
whom the claimant reported at Killingbeck police station (PC Green) and email correspondence from City Hearts, a
charity providing safe houses, support and counseling for vulnerable and exploited people.

30. The NRM referral form contains observations by PC Green to the effect that “numerous attempts were made
_for her to name landmarks, shops, streets et cetera” but that the claimant “did not know her address or anything_
_nearby besides the park.”_

31. It is right that the police did not undertake any further investigation relating to the possibility of the commission
of the crime of human trafficking. The email of 12 September 2016 I refer above sent by PC Green makes that
clear. It does not suggest however that the decision not to make any further enquiries was based upon the view that
no crime had been committed but rather the email gives the impression that the police simply felt that, in the
absence of a surname or any real means of establishing who the trafficker was, they could really take it no further.

32. In her asylum interview the claimant was asked where Anne-Marie lived. She was not able to say. She was
asked if she noticed any landmarks near to where Anne-Marie lived. Other than to say that there is a house and the
road and nearby there was a park where she would sometimes take Eve she was unable to further elucidate. Nor
was she able to put a name to the park or give any information which might enable Anne-Marie's home to be
identified. Similarly, she was unable to provide details of Anne-Marie's or Frank's surname.

33. When she was asked whether she had seen any letters or documents which might have contained AnneMarie's surname her reply was “I was not interested in other things. Most of the time she (Anne-Marie) was around
_so I just find it convenient (not) to take any of her letters.”_

34. Thus, in the same way as she was unable to provide help in locating Anne-Marie's home, she was also unable
to provide any help in locating Anne-Marie by her surname or indeed via her place of work. All she apparently knew
was that Anne-Marie worked in a hospital some 2 to 5 miles from the house.

_The Credibility Ground_

35. The Decision states as follows:

_“…… For the reasons set out below, it is considered that you are not a credible witness and therefore, no_
_weight is attached to your evidence.”_

36. It is right to say that the reasons “set out below” are not set out in one specific part of the Decision letter but
appear to be set out over 2 parts. One part immediately after the citation of extracts from the Guidance to
Competent Authorities (to which I shall come below) and the other part under the section referring to “mitigating
_circumstances”._

37. In the first part, the Decision states as follows:

_“You state that you worked for Anne-Marie from March to September 2014 but cannot provide her or_
_Frank's surnames, the address of the property you lived at or any landmarks to identify the area by. You also state_
_that you took Eve to the park twice a week by using the key on the windowsill of the house, you cannot provide any_
_details that will help to identify this park beyond it having a children's play area. Your inability to provide any such_
_details such as an address or local landmarks is inconsistent with your account of living at the property for 6 months_
_and regularly taking the little girl to the local park. You state Anne-Marie is a nurse but you do not know the hospital_
_she worked at.”_

38. Under the section referencing “mitigating circumstances” the Decision states as follows:


-----

“Consideration has been given to further submissions including information from City Hearts and West Yorkshire
_Police submitted in support of your claim. However, as set out below, it is not accepted that these provide mitigation_
_in your case and therefore, due to the internal inconsistencies in your account, your credibility has been damaged to_
_the extent that your claim to have been exploited cannot be believed._

_You presented to West Yorkshire Police and having been spoken with were advised that as you could not_
_provide surnames, the address or any details that would enable the house to be identified that was no actionable_
_information that they could take forward. You state that Didi took you to the police station and dropped you off as_
_she stated that she could not be there. You state that you could see her house from yours and although she may_
_have been able to provide additional information to assist the police, as she left and you have not indicated having_
_any ongoing contact there was insufficient information to enable the police to investigate your allegations further. As_
_such there is no further information available which may have supported your account._

_Your further submissions include a letter from the counseling service which you accessed from City Hearts_
_and an update of your current circumstances after you finished these sessions. The counsellor's letter refers to your_
_circumstances leading up to your arrival at City Hearts but is not more specific as to what the counsellor_
_understands the circumstances to be. The letter also refers to the general uncertainty of your situation. Various_
_symptoms are reported however again there is no specificity as to what these are attributed to. By your own_
_account you have indicated being mistreated by clients in Malawi and being the victim of attempted assaults by_
_Frank either of which are deemed to be potentially linked to the symptoms you reported to the counsellor. This_
_information has been taken in good faith and provides no further support to your account of being trafficked as the_
_information within it does not refer to any specific circumstances. The information provided gives no explanation for_
_your lack of knowledge of the address or surname of the woman you state you lived with for 6 months._

_In summary, based on the available evidence and their respective assessments above it is not accepted_
_that you are a victim of modern slavery and your case is rejected in full below.”_

39. The letter from City Hearts referred to above is dated February 2016. It is not actually referred to in the list of
information which the defendant considered in connection with this application but clearly it was one of the
documents that was considered. It simply confirms that the relevant counsellor has been working with the claimant
since December 2014. The claimant has had 23 sessions aimed at providing some therapy for the claimant's fragile
mental state and it confirms that there are significant indicators pointing to her suffering from trauma symptoms. It is
right to say that it does not shed any light on what has caused the trauma -related condition from which the claimant
suffered. The Decision points out that any traumatic stress could equally be as a result of the horrendous situation
in which she found herself in Malawi or the unwanted sexual attention from Frank rather than it being evidence of
her having been trafficked.4

_The Guidance for Competent Authorities_

40. The Guidance for Competent Authorities to which I refer above is a document published on 21 March 2016
under the title “Victims of **_Modern Slavery – Competent Authority Guidance” (the Guidance). It is a very lengthy_**
document running to 129 pages but it has specific sections commencing on page 97 on “How to assess credibility
_when making a Reasonable Grounds or Conclusive Grounds decision.”._

41. It is trite law that if a decision maker publishes a policy or guidance about how particular decisions will be made
or a particular power will be exercised, the decision maker will err in law if, without explanation, he departs from that
guidance. See Lumba v Secretary of State for the Home Department _[2011] UKSC 12; [2012] 1 AC 245._

42. I do not intend to cite from the Guidance at great length. The following entries at page 97, under the heading
“Assessing credibility – general” were specifically drawn to my attention by counsel. Those preceded by an asterisk
are actually reproduced in the Decision letter.

_Competent Authorities are entitled to consider credibility as part of (my emphasis) their decision-making_
_process._


-----

_The Competent Authority must consider both the external and internal credibility of the material facts._

_*In assessing credibility the Competent Authority should assess the material facts of past and present_
_events (material facts being those which are serious and significant in nature) and which may indicate that a person_
_is a victim of human trafficking or modern slavery._

_The Competent Authority should assess the material facts based on the following:_

_Are they coherent and consistent with any past written or verbal statements?_

_How well does the evidence submitted fit together and does not contradict itself?_

_Are they consistent with claims made by witnesses and with any documentary evidence submitted in_
_support of the claim or gathered during the course of your investigations?_

_*Where there is insufficient evidence to support a claim that the individual is a victim of modern slavery_
_(for example where the case is lacking key details, such as who exploited them or where the exploitation took_
_place) staff at the Competent Authority are entitled to question (my emphasis) whether the Reasonable Grounds_
_or Conclusive Grounds threshold is met. However, you must also consider whether you need more information._

43. And at page 98 under the heading “Assessing credibility – detail and consistency”

_*The level of detail with which a potential victim presents their claim is a factor (my emphasis) when the_
_Competent Authority assesses credibility. It is reasonable to assume that a victim giving an account of their human_
_trafficking or_ **_modern slavery experience will be more expressive and more likely to include sensory details (for_**
_example what they saw heard, felt or thought about the event than someone who has not had this experience._

_Where there is insufficient evidence to support a claim that the individual is a victim of human trafficking or_
**_modern slavery the Competent Authority is entitled to question (my emphasis) whether the Reasonable Grounds_**
_or Conclusive Grounds threshold is met. However, they must also consider whether they need more information._

_*It is also reasonable to assume that a potential victim who has experienced an event will be able to_
_recount the central elements in a broadly consistent manner. A potential victim's inability to remain consistent_
_throughout their written and oral accounts of past or current events may lead the Competent Authority to disbelieve_
_their claim. However, before the Competent Authority come to a negative conclusion, they must first refer back to_
_the first responder or other experts witnesses to clarify any inconsistencies in the claim._

_Due to the trauma of human trafficking or modern slavery, there may be valid reasons why a potential_
_victim's account is inconsistent or lacks sufficient detail.”_

44. And at page 98 under the heading “Assessing credibility – mitigating circumstances” it is said that:

_Competent Authority staff need to know about the mitigating circumstances which can affect whether a_
_potential victim's account of human trafficking or_ **_modern slavery is credible. When the Competent Authority_**
_assesses the credibility of the claim, there may be mitigating reasons why a potential victim of human trafficking or_
**_modern slavery is incoherent, inconsistent or delays giving details of material facts. The Competent Authority must_**
_take these reasons into account when considering the credibility of a claim. Such factors may include, but are not_
_limited to the following:_

_Trauma (mental, psychological, or emotional)_

_inability to express themselves clearly_

_mistrust of authorities_

_feelings of shame_


-----

_painful memories (including those of a sexual nature)_

_Discussion concerning credibility ground_

45. First, it is important to record that it is accepted that the onus is on the claimant to establish that, on the balance
of probabilities, she is the victim of trafficking but Miss Mair emphasises that the process is an inquisitorial one, as
is necessary to ensure that the claimant's human rights are guarded in the process. This is why the guidance
indicates that, when necessary, further information must be obtained.

_The claimant's submissions_

46. The claimant asserts that the defendant's decision to attach no weight to the claimant's evidence on the basis
that she was not a credible witness was irrational and/or otherwise unlawful on the basis that:

a. The defendant failed to adhere to the Guidance

b. The defendant failed to take into account all factors that were in the claimant's favour

c. The defendant took immaterial factors into account

d. The defendant has concluded that it is inappropriate to attach any weight to the claimant's evidence

e. The defendant has conflated plausibility with credibility and concluded that because she considers the claimant's
evidence to be implausible it is therefore incredible.

_Failing to adhere to Guidance_

47. It is clear that the Decision has been made on the basis that the defendant simply does not accept the account
given by the claimant. That view appears to have been taken on the basis that, albeit she lived at Anne-Marie's for
6 months or so, she has been unable to provide details, such as the surname of Anne-Marie and/or Frank or any
details that could assist in determining the location of Anne-Marie's home. The point made by Miss Barnes is that
essentially the claimant has not provided any details which would enable her account to be corroborated and that
failure wholly undermines her credibility.

48. Miss Mair's point is that the defendant has treated this absence of detail as fatal to credibility but in doing so
she has departed from the Guidance in a number of respects. First, and by reference to the extracts from the
Guidance cited above, credibility is merely part of the decision-making process, it is not the entirety of the process.
Secondly, insufficient evidence entitles the competent authority to **question whether the Conclusive Grounds**
threshold has been met, it does not say that insufficient evidence entitles the competent authority to reject the claim
on the basis that the threshold has not been met. The point is emphasised yet further in the Guidance by the
observation that the level of detail with which a potential victim presents their case is a factor in the assessment of
credibility. It is not determinative.

49. Miss Mair argues that it is the absence of detail which has specifically caused the defendant to conclude that
the claimant's evidence not only does not meet the threshold but is evidence to which no weight can be attached. It
is argued that this is a wholly unjustified departure from the Guidance.

50. Finally, Miss Mair refers me R ota Mutesi v SSHD _(2015) EWHC 2467 (Admin) where the court held that:_

“The guidance demands a high standard of reasoning from the Competent Authority and rightly demands that if a
_decision is to turn on lack of credibility, the Competent Authority must carefully analyse the relevant factors and_
_explain her reasoning about credibility in her decision. It is unfair and unlawful for the Competent Authority to shy_
_away from grappling with the issue of credibility”._

51. Miss Mair also points out that in that case the claimant had not disclosed surnames of the people by whom she
was trafficked, nor indeed did she know to where she had been taken. In that case however the court took the view


-----

that that was not inconsistent with her having been trafficked. The same result pertained in Hounga v Allen (2014)
UKSC 47. Although in these cases it is right to point out that the alleged victims were children.

_Failing to take into account all factors that were in the claimant's favour._

52. The competent authority must consider both the external and internal credibility of the material facts. In the
Decision the defendant accepts the conclusions reached in the US State Department Trafficking in Persons Report
2016 to the effect that that both Malawi and the UK are countries where the subjection of women to slavery and
exploitation is prevalent. That objective evidence, it is argued, does not appear to have been factored into the
defendant's consideration of the claimant's claim at all.

53. Furthermore, the defendant has apparently ignored the fact that, other than her failure to supply surnames and
an address or other information which could identify Anne-Marie, the claimant has supplied a great deal of detail.
She has described the family unit, she has given a description of Anne-Marie, she has described her working day
including what she fed Eve, she has described in great detail how it was that she was transported to the UK and
from London to Anne-Marie's home. She explained why it was that she knew that she was accommodated in Leeds
but not where in Leeds (because the city name was mentioned and she was vaguely familiar with the name through
the exploits of Leeds United).

54. Miss Mair argues that it is irrational to take the view that the claimant has failed to provide “key details”5. She
accepts that a surname and address could be “key details” but argues that the details that the claimant gave were
also “key details”. In any event, for the purpose of an NRM referral, a lack of knowledge as to where one has been
accommodated is actually an indicator of trafficking.

55. It is argued that the decision makes no reference to the detail which has been supplied but rather it focuses
exclusively on the failure to supply a surname or an address.

56. Furthermore, no recognition has been given to the fact that the claimant's account has been internally
consistent throughout. Indeed, it is pointed out by Miss Mair that the Decision makes clear that it is “internal
_inconsistencies” which have damaged the claimant's credibility “to the extent that your claim to have been exploited_
_cannot be believed”. Miss Mair points out that there really are no significant internal inconsistencies and that to_
base a decision as to credibility on internal inconsistencies which do not actually exist is irrational.

57. It is further argued that no weight has been attached to the fact that the claimant's evidence was not overly
damning of her treatment by Anne-Marie. Indeed, the fact that she had some freedom to leave the house is used as
a basis for the defendant contending that one might have expected her to be able to identify some local
landmarks/street names. One might have thought, it is argued, that unless they are honest, persons seeking to
argue that they have been exploited may be tempted to exaggerate the sorry state in which they found themselves.
Miss Mair argues that the claimant's failure to do so adds to her credibility.

58. There has been, it is argued, a failure to take account of the corroborative value of additional evidence. The
evidence from City Hearts has been dismissed on the basis that it fails to specify why it was that the claimant
attended on City Hearts. The Decision states:

“The counsellor's letter refers to your circumstances leading up to your arrival at City Hearts but is not more specific
_as to what the counsellor understands the circumstances to be. The letter also refers to the general uncertainty of_
_your situation. Various symptoms reported however again there is no specificity as to what these are attributed to._
_By your own account you have indicated being mistreated by client Malawi and being the victim of attempted_
_assaults by Frank either of which are deemed to be potentially linked to the symptoms you reported to the_
_counsellor”_

59. No regard has been had to the email of 12 September 2016 to be found at B73 of the bundle which, as I
understand it, emanates from City Hearts which specifically states that the claimant was given counseling “due to
_her trafficking experience”._


-----

60. Further, no regard appears to have been had to the fact that the claimant presented herself to a police station,
albeit that she was taken there by her friend. The defendant appears to have attached no regard to the fact that she
was an illegal immigrant and the fact that presenting to a police station in the circumstances is not what might be
expected unless the illegal immigrant was concerned about matters even more pressing than their illegal presence
in the UK. In fact, at the police station the claimant was arrested on suspicion of entering the country illegally.

61. Miss Barnes points out that the attendance at the police station could have been prompted simply by the fact
that she had been sexually assaulted by Frank and feared it may happen again and that it had nothing to do with
exploitation. The point made by the claimant is that whilst that may be the position, it is also true that it may not and
the Decision simply fails to address that issue at all.

_Taking account of immaterial facts_

62. In addition, the interpretation placed by the defendant on the fact that West Yorkshire police have not taken this
matter further in the form of an investigation into trafficking appears to be that that was because West Yorkshire
police did not believe the claimant.

63. The Decision makes reference to the email from West Yorkshire police to which I have referred above. That
email stated:

_“(The claimant) was only arrested on suspicion of entering the country illegally and was dealt with entirely_
_by immigration. There does not appear to have been any further investigations carried out. In her initial disclosure to_
_myself she was only able to give first names; she did not provide surnames or addresses.”_

64. The decision letter states that thus:

“You presented to West Yorkshire police and having been spoken with were advised that as you could not provide
_surnames, the address or any details that would enable the house to be identified there was no actionable_
_information that they could take forward.”_

65. Miss Mair argues that the defendant's decision to interpret the email from the police on the basis that it did not
provide actionable information is irrational. It clearly did provide actionable information but it was simply information
that could not be followed up because of the absence of detail. Indeed, Miss Mair points out that PC Green in his
minute of his interview with the claimant dated 23 September 2014 specifically states that “there are trafficking
_issues involved”._

_Failure to attach any weight to the claimant's evidence_

66. The point made by Miss Mair here is that the decision to attach no weight to the evidence of the claimant is
irrational. She argues that the claimant may have been on thinner ice in relation to this aspect of her claim if the
defendant had contended that such weight as could be attached to the claimant's evidence as supporting a finding
that she had been trafficked was outweighed by evidence going in the other direction. That however has not been
the approach that the defendant appears to have taken. It has simply dismissed the claimant's evidence in its
entirety as being unreliable.

67. Furthermore, it is argued that in reaching her decision the defendant has cherry picked. She has accepted the
claimant's evidence where it suited her to do so and where she believed that it supported the conclusion that the
claimant had not been trafficked. Thus, the defendant appears to accept that the claimant may have needed
counseling from City Hearts because of the deplorable situation she found herself in in Malawi or because she was
subject to Frank's sexual harassment. Indeed the Decision specifically states that “this information (about events in
_Malawi and Frank's conduct) has been taken in good faith and provides no support to your account of being_
_trafficked…..”. It is irrational, argues Miss Mair, for the defendant to accept what the claimant says for the purpose_
of dismissing the input of City Hearts while at the same time saying that no weight is attached to her evidence.

_Conflating credibility with plausibility._


-----

68. The claimant's point is that the Decision makes it clear that the defendant has dismissed the claim because it
does not conform to the defendant's speculative view as to what knowledge a young woman such as the claimant
would have of her trafficker.

69. It is argued by Miss Mair that this fails to have regard to the special need for caution when assessing credibility
or improbability in cases such as this. At paragraph 14 of the Amended Detailed Statement of Facts and Grounds
Miss Mair makes reference to HK v SSHD (2006 EWCA 1037 paragraphs 28 to 30. That case was an asylum case
but of course the principles set out in it would apply equally in a case relating to trafficking.

70. In that case Neuberger LJ (as he then was) had this to say:

28 “Further in many asylum cases, some, even most, of the appellant's story may seem inherently unlikely but that
_does not mean that it is untrue. The ingredients of the story, and the story as a whole, have to be considered_
_against the available country evidence and reliable expert evidence, and other familiar factors, such as consistency_
_with what the appellant has said before and with other factual evidence (where there is any)._

_29        inherent probability, which may be helpful in many domestic cases, it can be a dangerous,_
_even a wholly inappropriate, factor to rely on in some asylum cases. Much of the evidence will be preferable to_
_societies with customs and circumstances which are very different from those of which the members of the fact-_
_finding tribunal have any (even second-hand) experience......_

_30        inherent improbability in the context of asylum cases was discussed at some length by Lord_
_Brodie in Awala v Secretary of State (2005) CSOH 73. At paragraph 22 he pointed out that it was “not proper to_
_reject an applicant's account merely on the basis that it is not credible or not plausible. An applicant's account is not_
_credible is to stay is a conclusion”. At paragraph 24 he said that rejection of a story on grounds of implausibility_
_must be done “on reasonably drawn inferences and not simply on conjecture or speculation.” He went on to_
_emphasise, as did Pill LJ in Ghaisari, the entitlement of the factfinder to rely “on his common sense and his ability,_
_as a practical and informed person, to identify what is or is not plausible”. However he accepted that “there will be_
_cases where actions which may appear implausible if judged by …. Scottish standards, might be plausible when_
_considered within the context of the applicant's social and cultural background”._

71. In Y v SSHD (2006) EWCA 1223 at 25 Keene LJ pointed out that the approach of a decision maker to issues of
credibility included the fundamental one that:

“He should be cautious before finding an account to be inherently incredible, because there is a considerable risk
_that he will be over influenced by his own views on what is or is not plausible……….. It is therefore important that_
_(the decision-maker) should seek to view an appellant's account of events in the context of conditions in the country_
_from which the appellant comes.”_

72. The learned judge however made clear in paragraph 26 that in appropriate cases the decision maker is entitled
to find “that an account of events is so far-fetched and contrary to reason as to be incapable of belief”.

73. Apart from her argument that the Decision conflates plausibility with credibility Miss Mair argues that it is simply
irrational to take the view that the absence of details as to surname and address makes this account “so far-fetched
_and contrary to reason as to be incapable of belief”. As to the conflation, she argues that it is clear that the_
defendant has taken the view that it is inherently improbable that the claimant would not know Anne-Marie's
address or Anne-Marie's surname and has thus considered that her account is implausible and that, as a result, the
credibility of the claimant is totally undermined. That, she argues, is contrary to the principles enunciated in the
cases referred to above.

74. Miss Mair also argues, on the authority of _Mutesi to which I have referred to above, that there has been no_
careful analysis of the relevant factors by the defendant or an explanation by the defendant in the Decision of her
reasoning about credibility. Much less has there been the high level of reasoning that ought to be required where
the evidence of the person concerned is simply rejected out of hand.


-----

75. Finally, Miss Mair takes issue with the whole approach of the defendant and the fact that credibility has been
assessed as being essentially non-existent and then later on in the decision, the defendant seeks to have regard to
mitigating circumstances. Miss Mair argues that this is an unprincipled approach. It results in there being a finding
of a lack of credibility and then a further consideration of mitigating features and whether those provide a reason to
row back from the finding of no credibility. She argues that that is not an approach with which the courts should
concur.

_The defendant's submissions_

76. The defendant does not shrink from conceding that the decision to attach no weight to the claimant's evidence
is based upon her failure to produce details of surnames and addresses or the means by which those can be
ascertained. Miss Barnes points out that the details which the claimant was unable to supply were legion especially
in the context of a woman who had lived in this house for 6 months. They were an inability to provide details not
only of Anne-Marie's surname and address but also:

- Frank's surname

- the hospital where Anne-Marie worked

- any details to identify the park where the claimant took Eve

- any local landmarks to identify the area

77. Miss Barnes argues that it was perfectly rational and reasonable for the defendant as the Competent Authority
to conclude that, in the absence of all this crucial information and on the basis that that information was the only
means by which the evidence of the claimant could be corroborated, the claimant's evidence could not be accepted.
This is particularly so because there had been no good explanation for the failure to provide this vital information.

78. Miss Barnes points out that the Guidance itself expressly provides that a lack of detail can give rise to justifiable
doubts as to the veracity of the claimant's assertions. It is of course accepted by Miss Mair that absence of detail
can give rise to an entitlement to question assertions but not an entitlement to dismiss them out of hand. Indeed,
Miss Mair points out that the Guidance does specifically provide for inconsistency being a basis for disbelieving the
claim. That, she argues, is to be distinguished from how the Guidance directs the approach to a lack of detail. The
latter simply gives rise to an entitlement to “question” whether grounds have been made out.

79. Miss Barnes argues for example that the defendant was entitled to find it incredible that the claimant would not
have seen any post delivered to the house from which she could have learnt Anne-Marie's surname. As for the
claimant's explanation given to the immigration officer during her asylum interview that “she (Anne-Marie) was
_around so I just find it convenient not to take any of her letters”, Miss Barnes points out that this seems hardly_
consistent with evidence that Anne-Marie worked night shifts as a nurse.

80. Equally, Miss Barnes argues that it is incredible that in simply walking around the area to and from the park she
could not establish where Anne-Marie's house was. The claimant's evidence in this regard is that she merely went
to the park which was opposite the home with Eve. She did not leave the house on other occasions. As a result,
she had no opportunity to take note of street names or landmarks. Miss Barnes argues that it is not irrational for the
defendant to take the view that that explanation has the ring of inauthenticity. If nothing else, it would not explain
why the claimant is unable even to remember the house number which presumably she would have seen on each
occasion she re-entered the house from the park. Miss Barnes accepts that occasionally trauma can cause a victim
of trafficking to be unable to recount salient details but that ought not to be the position here. This was a claimant
who was not a child who, even on her own account, was not ill treated physically and was free to come and go. It is
reasonable for the defendant to conclude in the circumstances that it is not trauma which is the cause of the
claimant's failure to supply the details which the defendant can reasonably expect.

81. Miss Barnes accepts that the claimant's account has been generally internally consistent but does not accept
that that is some sort of card which trumps everything else. In short, her consistency does not explain her failure to


-----

provide the information, or indeed any information, which may enable her account to be corroborated by other
sources.

82. As for the contention that the defendant's approach is unprincipled on the basis that there is a finding that no
weight is to be attached to the claimant's evidence and then mitigating circumstances are invoked with a view to
establishing whether they give cause to reconsider the original conclusion, Miss Barnes' position is that the
approach taken by the defendant accords with the Guidance which specifically states that mitigating circumstances,
which can affect whether a potential victim's account of human trafficking is credible, are to be considered as a
separate issue. Miss Barnes' position is that it is clear that the question of the claimant's credibility has been
considered in the round.

83. In so far as the form completed by PC Green in the context of the referral into the NRM, Miss Barnes makes
the point that that form is simply a gateway into the question of whether trafficking has been established.
Thereafter, and for the purpose of the reasonable grounds and the conclusive grounds decisions, different
considerations are in play.

84. As to that part of the Decision which refers to internal consistency as having damaged the claimant's
credibility6, Miss Barnes argues that that misconstrues what the defendant actually had in mind by her reference to
internal inconsistencies and that what was in mind in using that phrase in the Decision was the fact that the “inability
_to provide details such as an address or local landmarks was inconsistent with the claimant's account of living at the_
_property for 6 months and regularly taking the little girl to the local park”._

85. Finally, Miss Barnes argues that even if the defendant had not separated issues of credibility into a finding of a
lack of credibility and then a consideration of mitigating circumstances and even if she had specifically supplied
greater detail as to her reasons for reaching the conclusion she did then her findings would have been the same.
She refers me to s31(2A) Senior Courts Act 1981 to the effect that the grant of relief must be refused “if it appears
_to the court to be highly likely that the outcome for the applicant would not have been substantially different if the_
_conduct complained of had not occurred”._

_Conclusion as to credibility ground_

86. I am satisfied that the claimant's credibility ground is in fact made out and that in that respect the Decision is
irrational or otherwise unlawful.

87. Essentially, I am persuaded by the arguments put by Miss Mair which I set out above. I accept that a failure by
the claimant to produce any evidence which is capable of corroborating her account will inevitably lead the
defendant to question it but it seems to me that that absence of detail has not simply caused the defendant to
question the account, it has caused the defendant to completely reject the account and thereby give the claimant's
evidence no weight at all. It seems to me that that cannot be right and the defendant's contention that it completely
strips the claimant's evidence of any credibility goes too far. In effect, on the basis of Y v SSHD, to which I refer
above, that conclusion would only be available to the defendant “if the account of events is so far-fetched and
_contrary to reason as to be incapable of belief”. I do not accept that that is so._

88. If that was the defendant's view and even if she were entitled to hold it, it is in my view incumbent upon her to
set out in detail and with a high standard of reasoning how and why she arrives at her decision that the claimant
has no credibility. In so far as she does so simply by pointing out that there has been a failure to provide the details
necessary to identify Anne-Marie or where she lives, then in my view that is not enough. The letter does not
demonstrate the high standard of reasoning or the careful analysis that Mutesi stipulates is necessary. It does not
make any reference to other issues that affect credibility many of which I have referred to above from paragraphs
52 to 61.

89. Furthermore, it seems to me that there is an irrationality in, on the one hand, saying that no weight is attached
to the claimant's evidence but then, on the other, attaching weight to that evidence as an explanation for the
counseling provided by City Hearts.


-----

90. There is also a failure to take account of the fact that the email from City Hearts to which I refer in footnote 4
above was to the effect that counseling had been given to the claimant “due to her trafficking experience”. The
decision insofar as it addresses the letter from City Hearts and concludes that there is no specificity about it is
actually simply wrong when considered alongside this email.

91. Furthermore, at various points in the decision the defendant indicates that she has reached a decision because
of “internal inconsistencies” in the claimant's account. The difficulty is that there are no real inconsistencies in her
account. Miss Barnes sought to explain the reference to inconsistencies by reference to the earlier paragraph in the
Decision in which the context of the use of the word is that the claimant's inability to provide details such as an
address for local landmarks is “inconsistent” with having lived at the property for 6 months and taking Eve to the
park. It has to be said that whilst that is a possible explanation, it is not the one that immediately springs to mind
when reading the Decision. That could just as easily be an ex post facto rationalisation by Miss Barnes as to why
the defendant has concluded that “internal inconsistencies” damage the claimant's credibility. If that was actually in
the mind of the defendant when she cited “internal inconsistencies” as being such a damaging factor to the
claimant's credibility then it is an unfortunate choice of words bearing in mind that there are hardly any material
internal inconsistencies in the claimant's account.

92. As regards the s31(2A) 1981 Act point, it may be that even the strict adherence to the Guidance and the
particular circumstances of this case may cause the Competent Authority to conclude that the claimant has failed to
establish on balance that she is the victim of trafficking but I am not satisfied that that is sufficiently likely to engage
the s31 defence which requires it to be “highly likely” that the outcome would have been the same.

_The Definitional Issue_

93. It is necessary to consider the definitional issue because the defendant has concluded that, even if the
claimant's account had been accepted, she does not meet the criteria for establishing her status as a victim of
human trafficking. If that was so then this judicial review would fall to be dismissed on the basis that the finding that
it was irrational to attach no credence to the claimant's evidence is academic on the basis that, even if it had been
accepted in full, the claimant could not succeed.

94. The decision makes it clear that the defendant does not accept that the claimant is a victim of modern slavery.
The claimant does not assert that she is the victim of slavery which is defined as “the status or condition of a person
_over whom any or all of the powers attaching to the rights of ownership are exercised”. She asserts that she has_
been the victim of **_Modern Slavery in the sense that_** **_Modern Slavery includes trafficking, slavery, servitude or_**
forced/compulsory labour. Her position is that she has been trafficked, the exploitative element of which, in her
case, is the necessity for her to undertake forced/compulsory labour.

95. In the Decision, the defendant addresses the definition of “Slavery, Servitude and Forced or Compulsory
Labour”. It is common ground that the definitions involve a hierarchy. The most wretched condition in which a victim
can find him or herself is slavery, the next worst is servitude and the least worst is forced/compulsory labour. I have
set out in paragraph 8 above the definition of forced/compulsory labour.

_The claimant's submissions_

96. The first complaint made by the claimant is that, having set out that definition and recognising that there is a
hierarchy, the Decision appears to focus on whether the claimant has met the criteria to establish that she is a
victim of domestic servitude rather than the less demanding, third tier in the hierarchy namely compulsory/forced
labour. Servitude, domestic or otherwise, is an aggravated form of forced/ compulsory labour. The feature that
distinguishes servitude in any of its forms from forced/ compulsory labour is that a victim in servitude is likely to feel
that their condition is permanent. That element of perceived permanence is not a necessary constituent of forced
labour.

97. There is, argues Miss Mair, a confusion in the mind of the defendant as to the basis upon which the claimant
puts her case. Miss Mair argues that the decision addresses at length domestic servitude (and sexual exploitation)


-----

and in effect concludes that those have not been made out. There is no separate or relevant consideration of forced
labour in the context of the claimant's position.

98. In short, Miss Mair argues that there has been a consideration by the defendant as to whether the claimant
meets the higher test of being in domestic servitude rather than simply the lower test of being a victim of
compulsory or forced labour.

99. Secondly, Miss Mair makes the point that the Decision draws a distinction between events in Malawi (wrongly
described in the Decision as Nigeria) and those in the UK. She argues that this is an artificial distinction because
events in Malawi inform events in the UK particularly on the issue of whether the claimant is a vulnerable person.

100. Vulnerability is obviously an important consideration. It will be recalled that the second of the 3 interlocking
components of trafficking is the “means” component which consists of the threat or use of force or other forms of
coercion by, amongst other things, abuse of a position of vulnerability. Miss Mair's position is that the claimant
stayed with Anne-Marie even though she was not paid and was working extremely long hours because she had
nowhere else to go. She was an illegal immigrant who ran the risk of being deported if the authorities discovered
her. If she was deported back to Malawi then her position there could be considerably worse even than it had been
before because her abandonment of Anne-Marie may have caused embarrassment to her traffickers which may
have had ramifications for the claimant and would have been yet an added, hideous dimension to the claimant's life
in Malawi. Miss Mair argues that the false dichotomy which the defendant has drawn between events in Malawi and
the UK has caused the defendant to conclude that the “means” component for trafficking has not been met in the
UK because all that the claimant has established is that she was deceived into expecting to be paid after 3 months
and this did not happen. Miss Mair argues that that completely ignores the claimant's position of vulnerability which
would be clear had there been a consideration of matters in the round.

101. In addition, Miss Mair argues that the claimant herself pointed the defendant in the right direction. In her
answers to question 143 of the asylum interview she makes clear that she remained with Anne-Marie because she
had shelter and a roof over her head and had food without having to resort to selling her body. In addition, in her
witness statement at paragraph 17 she specifically says that she was scared that she would be asked to leave if
she asked for money.

102. Thus, the claimant argues that had the claimant's evidence been accepted then it would have been clear that
she had been subjected to an act of transportation and thus met the “action” component of the definition of
trafficking. Similarly, if her evidence had been accepted the defendant would have had to accept that that
transportation would have been achieved by abuse of a position of vulnerability and that accordingly the “means”
component of the definition had been met and the only real question would then be whether the claimant had been
exploited by being forced into labour.

103. It was in this context that in relation to ground 2 most of the argument centred. The issue was whether it was
irrational or otherwise unlawful for the defendant to conclude that even on the claimant's evidence she had not been
the subject of forced labour. Miss Mair's position is that there does not appear to have been a consideration of the
claimant's specific position at all in the context of forced labour but that in any event, if the claimant's evidence were
accepted it would have been irrational to conclude that her work had been extracted from her other than under the
menace of a penalty or that she had offered her services voluntarily.

104. It should be said that the Decision does not appear to specifically address issues of menace of penalty or the
issue of whether the claimant's services were offered voluntarily at all. It is right to say that the Decision does refer
to these concepts in the sense that the Decision letter defines what forced or compulsory labour is by reference to
the Forced Labour Convention but there does not appear, on the face of the decision, to be a specific application of
those concepts to the claimant's case.

_Menace of a penalty_

105. In Van Der Mussele v Belgium (application number 8919/80 23 November 1983) the ECtHR had to consider
what was meant by menace of any penalty. In that case the court held that a Belgian trainee lawyer who alleged


-----

that he had been subjected to forced labour by having to provide pro bono representation to a client during his
pupillage may be able to establish menace of a penalty on the basis that his refusal to provide pro bono
representation may result in his name being struck off the roll of pupils and thus prevent his ultimate registration as
an advocate. The court held that “these prospects are sufficiently daunting to be capable of constituting the menace
_of a penalty”._

106. Equally, in MS (Trafficking – Tribunal's Powers – Art 4 ECHR Pakistan _[(2016) UKUT 00226 (IAC) the court](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JSS-BXX1-F0JY-C1FK-00000-00&context=1519360)_
acknowledged that _“penalty need not necessarily take the form of physical violence or restraint. It can assume a_
_more subtle mantle, usually of a psychological nature, embracing conduct such as threats to denounce a victim to_
_the police or immigration authorities”._

107. Miss Mair refers me to the views of commentators in particular Ms Drew and her text “Human Trafficking –
_Human Rights Law and Practice” in which she is clear that menace of any penalty has to be construed broadly, to_
include the exploitation of vulnerability.

108. The Decision states as follows:

_“The circumstances you describe with Anne-Marie are deemed to be dissimilar to those set out above as_
_you were not mistreated beyond not receiving the expected payments. By your own account the reason that you left_
_was Frank's behaviour, not your dissatisfaction with Anne-Marie who you stated treated you alright”._

109. Miss Mair makes the point that in so far as the Decision is founded on the basis that the claimant was not a
victim of trafficking because she was not mistreated beyond not receiving her expected payments, then it is wrong
in law because mistreatment is not necessarily a precondition for the establishment of menace of a penalty.

110. Furthermore, she argues that any conclusion reached by the defendant that the claimant had not established
that her labour was involuntary was irrational. It appears that that was the defendant's finding on the basis that the
summary at the very end of the Decision letter argues that the claimant has not established either of the 2
constituent elements of slavery, servitude and forced/compulsory labour. It will be recalled that in paragraphs 6 to
11 above I address my concerns about exactly what the defendant is saying here. On the assumption that I am right
that, in addition to concluding that she has not established menace of penalty, the defendant also does not accept
that the claimant's labour was involuntary then I deal with that principle.

_Voluntary_

111. In _MS the fact that workers actually came back from Pakistan to work for the alleged trafficker, having_
previously worked for him, did not mean that their labour was voluntary. Even though they were not prisoners, they
were effectively trapped and controlled, because they were unable to work legally elsewhere.

112. In Van Der Mussele it was said:

_“The court would recall that Mr Van Der Mussele had voluntarily entered the profession of advocate with_
_knowledge of the practice complained of. This being so a considerable and unreasonable imbalance between the_
_aim pursued – to qualify as an advocate – and the obligations undertaken in order to achieve that aim would alone_
_be capable of warranting the conclusion that the services exacted of Mr Van Der Mussele in relation to legal aid_
_were compulsory despite his consent.”_

113. In his case it was not felt that there was this considerable imbalance but the case is authority for the clear
principle that if there is such an imbalance then a person cannot be seen as actually in reality consenting to the
supply of his labour even though he does indeed supply it.

114. Miss Mair also points out that there is persuasive authority of the proposition that where somebody supplies
labour at less than the minimum wage, as was clearly the position here, then that too is evidence of a lack of
consent.


-----

_“It is obvious that ordinarily no-one would willingly supply labour or service for another for less than the_
_minimum wage, when he knows that under the law he is entitled to get a minimum wage for the labour or service_
_provided by him. It may therefore be legitimately presumed that when a person provides labour or services against_
_receipt of remuneration which is less than the minimum wage, he is acting under the force of some compulsion_
_which drives him to work though he is paid less than what he is entitled under the law to receive …… It may be_
_physical force which compels a person to provide labour or services to another or it may even be compulsion_
_arising from hunger or poverty or want of destitution. Any factor which deprives a person of a choice of alternatives_
_and compels him to adopt a particular course may properly be regarded as 'force' and if Labour or service is_
_compelled as result of such force it would be forced labour” 7_

115. Miss Mair argues that the fact that the claimant was not a prisoner and had some limited freedom to leave the
house with Eve or even, on her day off, without her, does not mean that she gave her labour voluntarily. Nowhere,
she argues, does the Decision deal with the fact that it was essentially the claimant's evidence that she had
nowhere else to go and if she did, no money (or passport)8 to get there and that she stayed in the house until she
could bear Frank's advances no longer because at least she had shelter and food without having to resort to selling
her body.

_The defendant's submissions_

116. Miss Barnes argues that it is clear that the defendant had in mind the 3 separate categories of slavery,
servitude and forced labour because they are specifically referred to in the Decision. There is no basis for
contending that the Decision has been made on a basis other than a consideration by the defendant of whether the
claimant has established that she is the victim of forced labour. It is clear, Miss Barnes argues, that the defendant
understood the distinct concepts and applied them.

117. In so far as the Decision only makes reference to domestic servitude (and sexual exploitation), it is clear that it
is not meant to relate solely to those concepts but also forced labour. Miss Barnes points out that the Guidance
itself aids the defendant in this context. In the section headed “trafficking: exploitation – forced labour” at page 35 of
the Guidance it specifically says:

_“For forced labour within the home, see the domestic servitude section”_

The reader is then referred to page 36 of the Guidance which has been quoted verbatim in the Decision.

118. Miss Barnes argues that Miss Mair's criticism that the Decision is in error by drawing a dichotomy between
events in Malawi and in the UK is misplaced. There is a clear focus on events in the UK because, in the context of
this case, how the claimant was treated in the UK is critical. This is because there is no obvious dividing line beyond
which labour is forced labour and prior to which it is not. It is all a matter of context. She directs me to a text by
_Skrivankova in which that academic argues that:_

“there is a blurred line between the point at which a situation transgresses from labour exploitation to forced
_labour”._

119. Skrivankova also points out that:

“substandard working conditions are not forced labour per se, neither is the lack of viable economic alternatives that
_make people stay in such situations (unless those are actively abused to induce and control the victim.”_

120. Miss Barnes argues that in the context of this case, the claimant would not have left had it not been for
Frank's conduct and that conduct cannot be a factor in assessment of whether she was subjected to forced labour.

121. Miss Barnes contends that there is no menace of a penalty here. Anne-Marie did not physically or verbally
abuse her or threaten her either with expulsion from the house or reporting her to the authorities. The position
therefore is distinguishable from that which existed for example in Hounga. Whilst it is true that Anne-Marie held the
claimant's passport, Miss Barnes points out that in fact the claimant never asked Anne-Marie for it.


-----

122. In reality, the menace of a penalty identified by the claimant is loss of home and food but she was never
threatened with these sanctions and it would be odd, argues Miss Barnes, if these were seen as automatically a
menace of a penalty when that scenario can exist in many perfectly innocent situations such as, for example an au
pair living in a family home.

123. At paragraph 10 of her supplemental skeleton arguments, Miss Barnes argues that the claimant has simply
failed to particularise what threat of a penalty Anne-Marie held over her.

124. As for the issue of the voluntary or involuntary nature of her employment, Miss Barnes argues that the
claimant did have a choice, even on her own evidence. She could leave at any time and this is illustrated by the fact
that eventually she did so and when she did it was not because of events triggered by Anne-Marie's behaviour but
by Frank's conduct. The claimant specifically admits that in question 142 of her asylum interview.

125. In any event, the absence of an alternative option but to stay does not necessarily mean that there is a lack of
consent to the supply of labour. It is all a matter of context and in the context of this claim there was nothing
irrational in the defendant concluding that the claimant was offering her services on a voluntary basis because she
was not badly treated by Anne-Marie at any time. She thus fell on the less sinister side of Skrivankova's blurred line
that I refer to in paragraph 118 above.

126. As Miss Barnes points out, the claimant was:

- Free to come and go. She was not permanently locked into the house, she knew where the key was to open the
door.

- She appeared to have some control over what she did during the day with Eve.

- Anne-Marie appears to have bought some items for the claimant when requested.

- She had Saturdays off and preferred to spend them at the home “relaxing”.

127. In her asylum interview she specifically says that Anne-Marie was “okay” with her. Miss Barnes argues that
this is not the hallmark of an exploitative situation or the coercion of somebody into work against their will.

128. In response to the observations made by the Indian Supreme Court in the _People's Union for Democratic_
_Rights case that I refer to above, Miss Barnes points out that in R v SK_ _(2011) EWCA Crim 1691 the court held that:_

“Where it is alleged that one person has been compulsorily employed by another, the level of pay he or she has
_received, if any, may have evidential importance. It may point to coercion; it may bear on an employee's ability to_
_escape from his or her employers control. On its own, however, a derisory level of wages is not tantamount to_
_coercion.”_

_Conclusion as to definitional ground_

129. Whilst I recognise that there is some strength in the contentions by Miss Barnes on behalf of the defendant, I
am satisfied that the defendant's conclusion that, even on the claimant's own account, she did not meet the criteria
for establishing herself as a victim of trafficking was irrational/unlawful.

130. In my judgment, the manner in which the Decision is laid out in the letter of 29 September 2016 betrays an
erroneous approach to the issue of the claimant's status.

131. It is correct that the Decision sets out the relevant definitions of human trafficking and also sets out the 3
components necessary for that to be established. In addition, it sets out the definition of compulsory labour.
However, it does appear on the face of the Decision that the defendant considered the “exploitation” component in
the definition of trafficking in the context of whether the claimant had been subjected to servitude, albeit domestic
servitude, and sexual exploitation. There is no separate heading in the Decision dealing with forced labour, as there
is for domestic servitude and sexual exploitation. It is clear that there is a hierarchy and it is unclear why the


-----

defendant appears to have considered this matter only in the context of whether the defendant was in servitude or
sexually exploited. I do not overlook the steer given by the Guidance to which I refer in paragraph 117 above but
the claimant is, in my view, entitled to expect the Decision to specifically address issues relating to exploitation by
way of forced labour rather than (or at least in addition to) domestic servitude and sexual exploitation.

132. I observe that there is really a total absence of any reference to menace of a penalty or the question of
whether the claimant's services were offered on a voluntary basis in the context of the claimant's specific
circumstances. This itself suggests that scant, if any, consideration was given to whether the claimant met the
criteria for trafficking on the basis that she was exploited for the purposes of forced labour.

133. Furthermore, the conclusion that the claimant was not in domestic servitude (or forced labour) appears to be
based upon the premise that she was not mistreated beyond not receiving the expected payments. That is not the
test for forced labour, the test is whether she was under menace of a penalty and whether her services were
voluntarily given. As I have said above, there appears to be no analysis of that in the context of the specific
circumstances surrounding the claimant's case.

134. In my view, it is also right to say that the dichotomy that the defendant has drawn between events in Malawi
and those in the UK is one that cannot be sustained because one may feed into the other. It is events in Malawi
which may be the cause of the claimant's vulnerability in the context of the second component of trafficking.

135. The defendant has taken the view that the claimant does not meet the “means” component of trafficking
because she has not established that she was subjected to threat or use of force in the manner required by that
second component. That of course includes whether she was in a position of vulnerability. The defendant appears
to have concluded that she does not meet that second component because she was deceived as she expected to
be paid after 3 months but was not paid. There is no separate analysis of whether she was in a position of
vulnerability. There is no reference to vulnerability, in contradistinction to at least a reference being made to that in
the consideration of the “means” component in the context of events in Malawi.

136. Miss Barnes' submission that trafficking for exploitation of forced labour must have been in the mind of the
defendant because the concept is referred to in the Decision is not sufficiently convincing. There is simply no
application of the general principles to the circumstances of this case other than the observation that the claimant
was not mistreated. An applicant seeking to establish that he/she has been the victim of trafficking is entitled to
know that full and proper analysis of the claim has been given and that can only be achieved if the Decision
demonstrates how general principles have been specifically applied to that applicant's claim. There is in my view
the lack of the “high standard of reasoning” that Mutesi calls for.

137. I do not overlook Miss Barnes' submissions in relation to the absence of menace of penalty and the absence
of evidence of involuntary services or indeed her submissions as to the evidence which positively supports the
contention that the services were voluntary.

138. It may be that in this case a full and detailed analysis of the evidence and the claimant's credibility may lead to
a conclusion that she was not trafficked but it is irrational in my judgment to contend that her evidence cannot lead
to that conclusion. The fact that the claimant's circumstances, as the defendant on a proper analysis finds them to
be, may not cross the threshold necessary to establish trafficking is not the issue here. It is worth emphasising that
the challenge is to the defendant's conclusion that they simply cannot.

139. Furthermore, the difficulty is that none of what Miss Barnes has referred to in the context of menace of a
penalty and voluntary supply of labour has found its way into the Decision. In the end, as I have said, the Decision
makes no reference to forced labour other than in generic terms. It is only after a consideration of domestic
servitude and sexual exploitation that the defendant concludes that “in line with the assessment above, it is not
_considered you meet Part C (exploitation) of the definition (of trafficking)”._

140. In my judgment, it is right that the defendant should reconsider this application. In so far as the defendant
doubts the credibility of the claimant the decision should set out the factors which have been balanced in making
that decision and they should be applied to the claimant's specific application including how they impact upon her


-----

claim that, in her case, exploitation for the purposes of trafficking took the form of forced labour. It may be that the
result will be the same but the claimant is entitled to know that her actual claim has been critically and properly
analysed.

141. Finally, I should say that I am not satisfied that had the appropriate and proper critical analysis been made the
outcome would have been the same such that s31(2A) Senior Courts 1981 is invoked. I do not accept that there is
a sufficiently high degree of likelihood that the outcome would have been the same to justify engaging that defence
and I reject therefore the defendant's submission that the claim should fail at this stage on that basis.

_Proposed Order_

142. I propose to quash the Decision and require the defendant to reconsider the claimant's claim that she is a
victim of trafficking.

_Final remarks_

I am grateful to counsel for their very able assistance in this matter.

HH Judge Saffman

1signed by the UK government on 23 March 2007, ratified on 17 December 2008 and which came into
force on 1 April 2009.

2by which I mean the Council of Europe Convention on Action against Trafficking in Human Beings.

3she claimed asylum on that date.

4it is right to say however that there is another email in the court bundle emanating from City Hearts and
which appears to be dated 12 September 2016 and which is at bundle B 73 of the hearing bundle in which City
Hearts indicate that the claimant was given counseling "due to her trafficking experience”.

5a phrase referred to in the Guidance

6See paragraph 38 above.

7People's Union for Democratic Rights v Union of India and others. A decision of the Indian Supreme
Court reported at 1983 1 SCR 456.

8the evidence being that Anne-Marie held the claimant's passport.

**End of Document**


-----

