# R (on the application of BT) v Secretary of State for the Home Department

 [2018] EWHC 584 (Admin)

Queen's Bench Division, Administrative Court (London)

Anne Whyte QC (sitting as a Deputy High Court Judge)

23 March 2018Judgment

**Emma Fitzsimons (instructed by Duncan Lewis) for the Claimant**

**Emily Wilsdon (instructed by GLD) for the Defendant**

Hearing dates: 14 March 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Anne Whyte QC:**

1. The claimant has the benefit of anonymity and will be referred to throughout these proceedings as “BT”.

2. On 22 January 2018 the claimant filed applications for interim relief (release from detention) and
permission to apply for judicial review. On 23 January 2018 Lang J ordered that the claimant's applications
be listed for an oral hearing. Other case management directions were made. The claimant was given leave
to file and serve an application to amend his grounds upon receipt of disclosure from the defendant. This
hearing has therefore been listed to determine the application for permission and interim relief and an
application by the claimant to adduce further evidence.

3. The Court was notified on 13 March 2018 that the defendant (“SSHD”) intended to release the claimant
to a Salvation Army address on 14 March. That being so, the application for interim relief is no longer
pursued.

4. BT is Vietnamese. He entered the UK illegally, possibly in 2014. He was detained under immigration
powers on 5 May 2017 following completion of a 3-year custodial sentence imposed on 22 April 2016 for
cannabis (a class B controlled drug) production. The defendant accepted that the claimant is a victim of
human trafficking. The defendant made a positive Reasonable Grounds decision on 17 August 2016 and a
positive Conclusive Grounds decision on 3 October 2016. These decisions were made whilst the claimant
was serving his sentence of imprisonment. The Conclusive Grounds decision accepted that he had been
the subject of trafficking in Russia and had been trafficked to the UK but in light of the crown court judge's
sentencing remarks and inconsistent accounts declined to conclude that he had been forced into criminality
in the UK. He did not challenge that decision.

5. He claimed asylum in May 2016 and this was refused in May 2017. This claim and his human rights
claim were certified under sections 94 and 94B of Nationality, Immigration and Asylum Act 2002. That
decision was swiftly reviewed in the light of the Supreme Court ruling in Kiarie & Byndloss v SSHD [2017]
_UKSC 42 though maintained with the distinction that it was acknowledged that he now had an in country_
right of appeal.


-----

6. He has been recognised as a victim of torture, the defendant regarding him on 9 October 2017 as an
Adult at Risk at level 2 after a Rule 35 Report referred, for the first time, to injuries sustained at the hands
of his traffickers in Russia. The claimant has some underlying health issues. He is epileptic and has had
seizures whilst in detention. A report prepared for the purpose of his asylum claim by a psychotherapist
called Susan Pagella and dated 25 October 2017 concluded that he was suffering from PTSD and that
detention in criminal custody and at the immigration detention centre in question was significantly
detrimental to his health. His asylum claim has proceeded through the usual channels. Having been
refused asylum, as described above, he lodged an appeal with the First Tier Tribunal (“FTT”) in late July
2017. It was anticipated that this claim would be expedited and resolved within 4 months. There were a
couple of adjournments of hearings but ultimately on 29 November his appeal was dismissed. Within a
couple of weeks he had been granted leave to appeal and on or about 30 January 2018 his appeal was
successful and his case remitted to the FTT.

7. His detention was subject to regular reviews. The progress and anticipated timetable of the asylum
claim and appeal were noted during the reviews. During each review an assessment was made of the risk
of absconding and re-offending and risk of harm to the public, if released. During the reviews each of these
risks was assessed as “high”, it being noted that BT had no ties in the UK, was liable to deportation, had no
legal basis for remaining, no financial self-sufficiency and that the nature of his conviction meant that he
posed a risk of harm to the public. No serious health concerns were identified. The defendant's decision to
release the claimant now is said to have been occasioned by a change in circumstances namely the recent
remission of his asylum appeal to the FTT with no hearing date in sight and the issue of these proceedings,
the combined effect of which suggests that his removal cannot be effected now within a reasonable period
of time.

8. The claimant submits in his original Grounds that his detention is unlawful relying on various grounds.
The timing of his claim was triggered by the fact that the Upper Tribunal granted him leave to appeal the
decision of the FTT. In Amended Grounds dated 22 February 2018 he also seeks to challenge (a) the
failure to investigate his trafficking claim, in breach of article 4 of the Council of Europe Convention Against
Trafficking in Human Beings 2005 and (b) the failure to grant him discretionary leave as a victim of
trafficking. The defendant submits that these additional two grounds are free standing of the general
complaints about unlawful detention and are inexcusably out of time. Although the application for
permission is split into eight separate grounds, six relate to a claim that the detention was unlawful. In
summary, it is said that the detention was unlawful on a rolling basis as follows:

i) from the start, on the basis that the claimant ought to have been released as a victim of trafficking who
did not pose any threat to public order, alternatively

ii) that by late July when his appeal to the FTT was lodged it should have been apparent on Hardial Singh
grounds that his removal could not be effected within a reasonable time, alternatively

iii) By late October the defendant should have been aware from the Pagella report that detention was
positively harmful to the claimant and this ought to have occasioned his release.

**Application to rely upon further evidence dated 2 March 2018**

9. The claimant has issued an application seeking permission to rely upon a bundle of supplementary
documents including amended grounds for judicial review. The defendant neither consents to nor opposes
the application but points out that the delay, in her view, is not obviously justified and that if admitted, the
court should consider with care what weight to attach to the additional documentation. Having considered
the additional documents, I do not consider that the defendant is prejudiced by their admission although I
agree that some could have been filed sooner. In those circumstances, I accede to the application.

**Relevant Law and Policy**

10. Permission will be granted only where the court is satisfied that there is an arguable ground for judicial
review which merits full investigation at a full hearing ie a ground which could succeed.


-----

11. BT's sentence of imprisonment was in excess of 12 months. That being so, section 32 of the **UK**
**Borders Act 2007 requires the defendant to deport him unless any of the exceptions in section 33 apply.**
Section 36 confers on SSHD a power to detain such a person. That power to detain will be subject to the
_Hardial Singh principles._

12. The defendant's published policy Victims of **_Modern Slavery – Competent Authority Guidance_**
relevantly reads at p57 [my emphasis]:

“Action 7: consider whether a potential victim can be released from detention

If the potential victim of trafficking or modern slavery is in immigration detention they will normally need to
be released on TA or TR by the Home Office unless in the particular circumstances, their detention can be
justified on grounds of public order.

The decision letter advises the person that they have been granted 45 days for recovery and reflection on
TA or TR to remain in the UK whilst a conclusive grounds decision is made on their case. This does not
grant any leave to enter or remain.

Therefore a detained person is usually released from immigration detention if they receive a positive
reasonable grounds decision and where they are released, the Competent Authority which dealt with
persons case whilst detained must pass the case on to a non-detained Competent Authority (UKVI) at this
point for the conclusive grounds decision to be made unless there are exceptional reasons why this is not
possible.”

13. In _Rantsev v Cyprus_ (2010) 51 EHCR, the Court held that Article 4 of the Council of Europe
Convention Against Trafficking in Human Beings 2005 imposed obligations on states including “a
procedural obligation to investigate situations of potential trafficking…for an investigation to be effective, it
must be capable of leading to the identification and punishment of individuals responsible”.

[14. The Immigration Act 2016: Guidance on Adults at Risk in Immigration Detention advocates a “case-by-](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
case evidence-based assessment of the appropriateness of detention of an individual considered to be at
particular risk of harm”. Available evidence graded is into levels (1, 2 or 3). For these purposes, two levels
are relevant:

“Level 2 evidence is: professional evidence (e.g. from a social worker, medical practitioner or NGO), or
official documentary evidence, which indicates that the individual is an adult at risk-should be afforded
greater weight. Individuals in these circumstances will be regarded as being at evidence level 2Level 3
evidence is: professional evidence (e.g. from a social worker, medical practitioner or NGO) stating that the
individual is at risk and that a period of detention would be likely to cause harm – for example, increase the
severity of the symptoms or condition that have led to the individual being regarded as an adult at risk should be afforded significant weight. Individuals in these circumstances will be regarded as being at
evidence level 3.”

15. In all cases, the decision maker should assess whether there is a realistic prospect of removal within a
reasonable amount of time. Evidence in support within the meaning of this Guidance needs to be balanced
against any immigration control factors in deciding whether the individual should be detained, including
length of time in detention, public protection issues, compliance issues.

16. The relevant guidance issued under Chapter 55b EIG: Adults at Risk in Immigration Detention echoes
the guidance described above. In respect of foreign national offenders (“FNOs”), the Guidance provides as
follows:

“For this purpose, the public interest in the deportation of foreign national offenders (FNOs) will generally
outweigh a risk of harm to the detainee. However, what may be a reasonable period for detention will likely
be shortened where there is evidence that detention will cause a risk of serious harm…”

17. The Guidance lists various indicators which may be relevant to the decision to detain including the
impact of detention on mental health and whether the individual has been a victim of torture of human


-----

trafficking. The Guidance also provides more detail about assessing cases falling within evidence levels 2
and 3, as referred to above.

18. A failure to follow published policy will amount to an error of law.

19. Rule 34 of the Detention Centre Rules 2001 requires every detained person to be given a physical and
mental examination by the medical practitioner within 24 hours of his admission to the detention centre.

**Ground 1: Detention is unlawful given his status as an accepted victim of trafficking**

20. This amounts to an assertion that the entirety of the detention is unlawful because the claimant had
been accepted to be a victim of trafficking in 2016, well before his immigration detention commenced.

21. Miss Fitzsimons, on behalf of the claimant, contends that although available guidance permits the
detention of victims of trafficking who are FNOs, that should only be in exceptional circumstances and that
the “public order” justification for detention in the Competent Authority Guidance, cited in paragraph 12
above does not apply here. The presumption to release should have prevailed and it is said that the
defendant failed to follow her own Guidance because detention was simply not necessary.

22. Miss Wilsdon, for the SSHD, accepts the existence of the presumption but justifies its disapplication
here on the basis that the defendant was entitled to assess the claimant as a FNO who posed a high risk of
re-offending and absconding and who has received a significant sentence of imprisonment for an offence
that causes harm to the public.

23. I do not accept the Claimant's submission that in paragraph 68 of _R (on the application of Das) v_
_SSHD_ _[2014] EWCA Civ 45, Beatson LJ was suggesting in this context that “exceptional circumstances”_
means someone who poses a high risk of killing someone. Das did not concern a FNO. Regardless of the
fact that by early 2018 in a release referral, the defendant had noted that BT's Offender Manager had
assessed BT as presenting a low risk of harm to the public, the claimant has not demonstrated an arguable
case that the defendant failed to follow her own Guidance.  The claimant's arguments fail to give sufficient
accord to the 2007 Act, to the relevance of cannabis cultivation to public order, to the detention reviews
and to the general presumption that the public interest in deporting FNOs (even those who are victims of
trafficking) generally outweighs the risk of harm to adults deemed to be at risk.

**Ground 2: The failure to undertake a review of detention in light of Pagella Report**

24. The Pagella report was prepared, not for the purpose of challenging detention but for the purpose of
the claimant's asylum appeal. It is said that it was served on the defendant's presenting officer in late
October 2017 within the asylum proceedings and that this ought to have triggered the defendant's common
law duty of inquiry (to ensure that detention is appropriate) and a prompt review of the claimant's detention.
In this regard, Miss Fitzsimons relied upon the first instance decision in Das: [2013] EWHC (Admin) 682 to
suggest that if the official dealing with the asylum appeal knew about the report, then given the parallels
between asylum and detention, this ought, as part of the duty of inquiry, to have been brought to the
attention of the official authorising detention. Had this happened, she argues, the defendant would or
should have assessed the claimant as a level 3 adult at risk and any balancing exercise about risk of harm
to the claimant versus the need to deport FNOs would have fallen in his favour, prompting his release. It is,
she says relying on Das, no defence, that the detention official was not provided with a copy of the Pagella
report. She was not able to say why, given the relevance now attached to the report for detention
purposes, it was not brought to the attention of the relevant immigration detention officials by the claimant's
solicitors at the time.

25. In response, the defendant denies that it is reasonable to suggest that the relevant presenting officer in
asylum proceedings ought to have forwarded the report to those tasked with reviewing the separate issue
of the claimant's detention. In any event, the report was considered in the detention review dated 9
February 2018 and it did not justify the claimant's release.

26. The facts of _Das were very different. There, a report from a consultant psychiatrist concerning the_
effect of detention on the mental health of the Ms Das was sent to the SSHD for the purpose of asylum and


-----

then sent to the judicial review team at the UKBA. The detention decision-making unit knew about the
existence of the report and failed to take steps to read it before detaining Ms Das, causing the judge to
conclude that the report had avoidably been ignored at two points. That is long way from the facts of this
case and I do not find Ground 2 to be arguable.

**Ground 3: Detention is unlawful under the Adults at Risk policy**

27. This is very closely linked to Ground 2 and hinges on the argument about the claimant being, because
of the Pagella report, a level 3 adult at risk as summarised in paragraph 23 above. By failing to categorise
him as such from late October, the claimant says the defendant failed to adhere to her own policy. Again, I
find that this ground is not arguable, in part because I do not find that the SSHD's Authorising Officer ought
to have been aware of the report and for the following additional reasons:

i) At its height, Ms Pagella said that it appeared to her that “being incarcerated both in prison and at [the
_relevant detention centre] is significantly detrimental to BT's current mental health…”. She did not go so far_
as to say that he was not fit for immigration detention or that any specified period of detention would
increase the severity of any symptoms. Her report was not aimed at examining the effect of detention on
BT in the short or medium term or considering the healthcare facilities available to BT at the centre. It was
aimed at linking BT's emotional state with his history of trafficking. It did not confirm that his detention was
likely to lead to a risk of significant harm.

ii) Even if that is wrong, at the time of the report it was still assumed that BT's removal could be fixed
relatively quickly. The defendant still, after assessment, considered that BT presented a level of public
protection concern, along with high risks of absconding and re-offending that justified detention.

iii) BT's health situation was considered during detention reviews and assessed as being appropriately
managed through the Healthcare system. In addition, when the Rule 35 report was received (notably
before Ms Pagella's report had been written), it was noted that the GP had not indicated that a period of
detention was likely to worsen BT's situation or cause him further harm.

iv) Once the report was brought to the attention of the relevant Authorising Officer, it was considered. The
detention review of February 2018 made express reference to the report and noted that that the claimant
remained fit for detention.

**Ground 4: Hardial Singh**

28. The claimant alleges that the third principle was infringed i.e. that at no stage was there a reasonable
prospect that he could be removed within a reasonable period of time. In an amendment to this ground, he
also asserts that his detention was unlawful from the outset because of the ramifications of the Supreme
Court ruling in _Kiarie & Byndloss, handed down on 14 June 2017. By this he means, that it should be_
presumed that throughout his detention and even before the judgment, he had an in-country right of appeal
which would by necessary implication mean that his detention was never going to be limited to a
reasonable period of time.

29. His appeal to the FTT was dated 31 July 2017 and dismissed on 28 November 2017. He was granted
leave to appeal the FTT decision on 19 December 2017. The asylum claim was being considered within
the DIA process. Emergency travel documents were agreed at various intervals from June 2017 and even
once lapsed could be resurrected within 2 to 3 weeks. The asylum timetable was recorded in each
detention review and it was considered that removal could be achieved within 3 months. By virtue of the
chronology and for the reasons set out at paragraphs 52 to 66 of the Summary Grounds of Defence, I do
not find this arguable. The amended ground in respect of Kiarie is likewise not arguable because:

i) It fails to take into account the decisions of R (on the application of DN) v SSHD _[2018] EWCA Civ 273_
and _R (on the application of AB) v SSHD_ _[[2017] EWCA Civ 59 and their respective reliance upon](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MV9-SB91-F0JY-C4CT-00000-00&context=1519360)_
paragraph 62 of the judgment of Sullivan LJ in R (on the application of Draga) v SSHD [2012] EWCA Civ
_842._


-----

ii) After judgment had been handed down in _Kiarie, the defendant undertook a prompt review of the_
claimant's detention, acknowledging that he should now be regarded as having an in-country right of
appeal and bearing this in mind when gauging the future asylum timetable.

**Ground 5: The failure to carry out a Rule 34 assessment**

30. I do not find this ground arguable. When the claimant was transferred from custody to the first
detention centre on 16 May 2017, he was seen in reception by a nurse who was able to access his health
records from the prison. On 17 May he was seen by a doctor. At that stage he did not disclose information
that might suggest he had been a victim of torture. Upon his transfer to a second centre in mid-August
2017 he disclosed information which prompted a Rule 35 appointment, which it seems the claimant did not
attend. Further referrals were then made, resulting in an examination on 5 October 2017.

31. Furthermore, even had a Rule 35 report been prepared earlier, there is no reason to suggest that the
outcome would have been any different.

**Ground 6: The failure to provide support to the Claimant as a victim of trafficking**

32. The claimant does not submit that this ground is relevant to his detention. In oral submissions, Miss
Fitzsimons clarified that the support which ought to have been offered was the intensive trauma therapy
recommended by Ms Pagella in her October 2017 report.

33. I do not find this ground, as advanced, to be arguable. For the first year of his detention BT was within
a custodial environment. Upon release, he was assessed within the National Referral Mechanism which
might be said to be part of a support process and one of the ways in which the UK complies with its
obligations under the Convention. The adoption of procedures and policies by government ministers – not
least the Competent Authority Guidance also underpins the structure of support available. Throughout his
immigration detention BT had access to healthcare services and solicitors.

**New Ground 7: Failure to investigate claims of trafficking in violation of Article 4**

34. Upon examination of the amended Grounds, this allegation relates not to a failure to investigate claims
of trafficking but of failure to investigate as early as 2016 one aspect of the claimant's trafficking claim,
namely whether he was forced to cultivate drugs once in the UK. When pressed, Miss Fitzsimons refined
her complaint to a failure by the SSHD to ask the claimant more questions about this aspect of the
potential trafficking when he said in his asylum screening interview on 4 July 2016 that he had been forced
to grow cannabis. At that time he was serving his sentence of imprisonment. He did not appeal his
conviction although apparently, he now intends to seek leave, out of time, to do so.

35. The defendant contends that this complaint is out of time because it does not form part of the rolling
allegations of unlawful detention. On the day of the hearing, I was provided with and I have considered a
Note on Timeliness drafted by Miss Fitzsimons.

36.  The referral to the NRM led to a positive reasonable grounds decision dated 17 August 2016. The
conclusive grounds decision dated 3 October 2016 did consider the extent to which the claimant had been
trafficked and in particular whether he had been forced into criminality. In deciding that BT's circumstances
did not meet the criteria for forced criminality in the UK, the defendant bore in mind the fact that the Circuit
Judge sentencing BT had been satisfied to the criminal standard that there had been a certain degree of
reciprocity between BT and those on whose behalf he had “gardened”. As I have indicated, BT, who had
the benefit of legal representation, did not challenge the Conclusive Grounds decision.

37. The amendment to the claim therefore comes some 16 months after the defendant made that decision
and even a little longer than 16 months after what might be said to be the failure to investigate BT's claim
of trafficking with in the UK. Unlike grounds relating to allegations of unlawful detention, it cannot be said to
be a continuing breach for the purposes of time and I find that it is out of time. In any event, within a
relatively short period of time after of his screening interview, his assertions of UK trafficking were explored
with him. There is nothing to suggest that more rigorous enquiries would have affected the defendant's
view about the need to detain or deport the claimant. The ground is not arguable.


-----

**New Ground 8: Failure to grant the Claimant discretionary leave**

38. This ground was first pleaded on 22 February 2018. The refusal to grant leave was dated 3 October
2016. Although, as with Ground 7, Miss Fitzsimons endeavoured to categorise this as part of the unlawful
detention grounds, it is not. It is a decision which determines whether or not the claimant can lawfully
reside in the UK and it is out of time.

39. In advancing this ground, the claimant relies upon the judgment in PK (Ghana) v SSHD _[2018] EWCA_
_Civ 98 which was handed down on 13 February 2018. In that case, the Court of Appeal concluded that the_
Competent Authority Guidance failed to reflect adequately, in one material respect, the obligations imposed
upon the state by Article 14 (1)(a) of the Trafficking Convention. As with Ground 4, it is suggested that this
decision imports, retrospectively, a taint on the decision to refuse the claimant discretionary leave. I do not
find that analysis to be sustainable.

40. Accordingly the application for permission is refused.

41. The parties should now endeavour to agree a draft consent order and if that is possible the draft
should be communicated to the court using the email address at the head of this judgment by 2pm on 21st
March 2018. If no agreement is possible, the parties are to make written submissions as to the respective
orders that are sought, such submissions to be limited to 2 sides of A4, to specify any reason why such
submissions should not be considered by the court on paper and to be emailed to the court by 2pm on 21
March. If there is agreement that this exercise can be conducted on paper, the parties need not attend the
hand down.

**End of Document**


-----

