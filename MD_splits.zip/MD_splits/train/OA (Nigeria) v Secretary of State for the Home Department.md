# OA (Nigeria) v Secretary of State for the Home Department [2018] EWHC 681
 (Admin)

Queen's Bench Division, Administrative Court (London)

Peter Marquand sitting as a deputy judge of the High Court

28 March 2018Judgment

**Ms Raggi Kotak (instructed by Wilsons Solicitors LLP) for the Claimant**

**Mr Neil Sheldon (instructed by Government Legal Department) for the Defendant**

Hearing date: 15th March 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Peter Marquand:**

**Introduction**

1. The Claimant challenges a decision of the Defendant dated 20 June 2017 following his solicitor's
request for reconsideration of a negative Reasonable Grounds Decision dated 19 December 2016 made
under the National Referral Mechanism (NRM) for identifying victims of **_modern slavery (this includes_**
human trafficking, slavery, servitude and forced or compulsory labour). The Claimant's case is that a
refusal to do so was irrational and unlawful.

2. The Claimant is a Nigerian national. His mother had been living in the UK whilst the Claimant, as a
child, remained in Nigeria with his grandmother and half-brothers. The Claimant says he was maltreated
and moved to live with his aunt, however, he was neglected and forced to do household chores and sell
food on the street. The Claimant's mother discovered this and arranged for him to come to the UK as a
child visitor. The Claimant's mother made various applications to remain in the UK, but these were
refused.

3. By July 2016, the Claimant was an adult.  On 26 October 2016 the Claimant was detained under
immigration powers. The Claimant claimed asylum and made a human rights claim on 31 October 2016
and these claims were rejected by the Defendant and certified under section 94(1) of the Nationality,
Immigration and Asylum Act 2002 (NIAA) as clearly unfounded.

4. On 12 December 2016, Wilsons Solicitors LLP in a duty advice surgery, advised the Claimant to seek
support from the welfare officer as in their opinion there were clear indications that the Claimant was a
victim of **_modern slavery. On 13 December 2016, the Claimant's case was referred to the NRM for an_**
assessment. On 19 December 2016 a negative Reasonable Grounds Decision was made.

5. Subsequently, the Claimant's solicitors obtained an expert report from Dr Naomi Wilson, chartered
clinical psychologist, which was sent to the Defendant on 5 June 2017 with a request to reconsider the
Reasonable Grounds Decision. In a letter dated 20 June 2017, the Defendant referring to its policy stated
that such requests were not accepted from solicitors.


-----

**The legal framework**

6. The United Kingdom Government signed the Council of Europe Convention on Action Against
Trafficking in Human Beings on 23 March 2007 and it came into force on 1 April 2009. The NRM is the
process through which victims of modern slavery are identified and provided with support. The process is
set out in 'Victims of Modern Slavery – Competent Authority Guidance' (the “Guidance”) and the relevant
version is the third, published on 21 March 2016.

7. The process operates by suspected cases of modern slavery being referred to a 'first responder'. The
first responders are specified statutory authorities and non-governmental organisations and the Home
Office is one such authority. There are 17 other first responders, including the Salvation Army. Solicitors
are not designated as first responders. The first responder's role is to identify a potential victim and make a
referral to the 'Competent Authority'. The two designated competent authority decision-makers are the UK
Human Trafficking Centre (UK HTC) within the National Crime Agency and the Home Office. There are
seven parts of the Home Office that undertake the Home Office role as a Competent Authority, including
UK Visas and Immigration NRM HUB and Detained Asylum Casework.

8. A Competent Authority goes through a two-stage process. First, a decision is made on whether there
are 'Reasonable Grounds' to believe an individual is a victim of **_modern slavery. The threshold is a low_**
one: 'I suspect but cannot prove'. The consequences of such a decision are significant. The potential victim
is offered a minimum of 45 days of support (reflection and recovery period) and consideration is given to
matters such as granting temporary admission and release from detention. After the reflection and
recovery period a competent authority must decide conclusively whether the person is a victim of modern
**_slavery. This is decided on a 'balance of probabilities' and is referred to as the 'Conclusive Grounds'_**
decision. If a positive Conclusive Grounds decision is made, the consequences for the victim in terms of
the support that they receive and consideration of Discretionary Leave to Remain are significant.

9. Page 91 of the Guidance is headed “Appeals against a reasonable grounds or Conclusive Grounds
decision.” It states:

“If a legal representative…requests a reconsideration from the Competent Authority they should be notified
that:

'Our policy in the published competent authority guidance clearly sets out that reconsideration requests of
NRM decisions may only be made by first responders or support providers involved in the case. You are
not the first responder or support provider involved in this NRM case so under the published guidance we
cannot reconsider the NRM decision based on your request. There is no breach of our policy as you are
not entitled to make a reconsideration request in our guidance.

It is open to you to request reconsideration via a first responder or a support provider involved in the case.
If a support provider or first responder submits a reconsideration request in this case it may be considered
in line with the published guidance.'”

10. There is a positive obligation on the Defendant to investigate potential victims of modern slavery and
to protect and assist victims. There is no dispute between the parties on the legal framework.

**The material facts**

11. On 13 December 2016 the Claimant, acting in person, filed a Judicial Review Claim Form in the Upper
Tribunal Immigration and Asylum Chamber. The decision that he challenged was the certification under
section 94(1) NIAA dated 29 November 2016. The Claimant's solicitors sent a pre-action protocol letter
dated 23 December 2016 to the Defendant. Amongst other matters it challenged the negative Reasonable
Grounds Decision dated 19 December 2016 and the certification of the asylum claim. By letter dated 5
January 2017 the Defendant confirmed its two previous decisions and on the following day served an
Acknowledgement of Service to the Claimant's judicial review.

12. In a letter dated 5 June 2017 the Claimant's solicitors wrote to the Defendant's solicitors, the
Government Legal Department (GLD), enclosing a copy of an expert report dated 2 April 2017 prepared by


-----

Dr Naomi Wilson, chartered clinical psychologist. The letter included extracts from Dr Wilson's report and
the following relevant passages:

“On 19 December 2016 your client acting as a Competent Authority made a Negative Reasonable Grounds
decision in respect of our client's claim to be a victim of modern slavery.

…

We recently received a copy of Dr Naomi Wilson's medico-legal report, which we enclose for your
reference.

…

Plainly in the light of Dr Wilson's conclusions we submit that your client's negative Reasonable Grounds
decision and your client's certification decision are unsustainable.

For the reasons given above as well as previously, and in the light of Dr Wilson's findings in her medicolegal report we invite your client to reconsider: (i) her Reasonable Grounds decision dated 19th of
December 2016; (ii) her decision to refuse and certify our client's asylum claim dated 29th of November
2016.

With a view to saving the Upper Tribunal's time and costs we enclose a draft consent order of your client's
consideration…'

13. The GLD's letter in response dated 20 June 2017 contains the decision that is challenged by the
Claimant. It stated:

“You have requested that my client reconsider her decision of 29 November 2016 and the medico-legal
report from Dr Naomi Wilson dated 27 February 2017.

My client is not prepared to agree to your proposed consent order. In respect of your request to reconsider
your client's trafficking claim, the Respondent's stated policy on such reconsideration is contained in her
Guidance titled 'Victims of modern slavery – Competent Authority Guidance', Version 3.0:

[The letter then reproduces the quote from the Guidance referred to at paragraph 9 above.]

In respect of your client's asylum claim, your client has the alternative remedy of submitting further
representations under paragraph 353 of the Immigration Rules.

As matters presently stand, the report you rely upon post-dates the decision under challenge and there is
no unlawfulness in the Respondent failing to consider it.

The Respondent does not therefore agree the Consent Order you propose.”

14. The claim was transferred to the High Court under an order dated 1 August 2017 for jurisdictional
reasons. The order permitted the Claimant and Defendant to file amended pleadings. The Claimant's
solicitors served a further pre-action protocol letter dated 6 September 2017 on the GLD. That letter
recorded five challenges including:

“'The [Defendant's] decision to refuse to reconsider the negative reasonable grounds decision in respect of
our client's trafficking claim because a solicitor made the reconsideration request'”

15. In the section on trafficking the letter deals with the GLD's letter dated 20 June 2017 and states:

“In our letter dated 5 June 2017, we requested that you reconsider the reasonable grounds trafficking
decision in the light of the substantial evidence in Dr Wilson's medico-legal report, which confirms our
client's vulnerability and confirmed that our client's presentation is consistent with his biographical history of
exploitation and trafficking

Notably there is no requirement to meet a fresh claim test in trafficking decisions.

As stated above you declined to reconsider the reasonable grounds decision because we in our capacity
as our client's solicitors, rather than a first responder or support provider had made the request.


-----

As you will be aware you are the first responder in our client's case. Notably the Salvation Army declines to
make reconsideration requests in circumstances such as our client's because they say that the request has
to come from the original first responder. Insofar as this is the case it is irrational to refuse to accept the
request from us under the circumstances.”

There was no response by the GLD to this letter. The Claimant served amended grounds for judicial review
dated 20 September 2017 now including the challenge to the decision of 20 June 2017.

16. The Claimant's solicitors wrote to the Salvation Army on three occasions, 23 November, 27 November
and 6 December 2017 asking them as a first responder to make a referral to the competent authority in
light of Dr Wilson's medico-legal report. On each occasion the Salvation Army declined to make that
referral on the basis that they were not the first responder in the Claimant's case. The Salvation Army in an
e-mail of 6 December 2017 referred to the Guidance and pointed out that a request for reconsideration
must be made by a support provider or first responder involved in the case.

**The Ground of challenge**

17. At an oral renewal hearing before Philip Mott QC (sitting as a Deputy High Court Judge) the only
ground upon which the Claimant obtained permission is as follows:

“The defendant's decision of 20th June 2017, to refuse to reconsider the claimant's trafficking conclusive
decision because it is made by a solicitor, rather than a first responder or support provider is (i) irrational;
and (ii) otherwise unlawful.”

18. The Claimant was refused permission on the other grounds, in particular, a challenge to the policy in
the Guidance of excluding solicitors from the list of first responders. Leave to apply was granted to reopen
that ground if the claimant in _R (SW) v SSHD CO/4926/2017 was successful. The Claimant made an_
application to vacate the hearing before me and to stay the proceedings behind SW but Andrew Thomas
QC (sitting as a Deputy High Court Judge) refused that application by order dated 7 March 2018.

**The Parties' submissions and discussion**

19. The Claimant's case is that the Defendant is under a positive obligation to identify victims of trafficking
and that obligation is a continuous one. The report of Dr Wilson identifies that the Claimant was not fit to go
through the interview processes and it identifies his mental health condition is secondary to trafficking and
other experiences. The Claimant points out that the Defendant is both a competent authority and a first
responder and a refusal to reconsider based on the report being provided to it as a competent authority by
a solicitor is irrational when it could accept the report as a first responder. The Defendant's submissions
are that the Claimant's solicitors letter of 5 June 2017 was sent during litigation specifically inviting the
competent authority to reconsider its reasonable grounds decision. The response from the GLD was in
accordance with the Defendant's policy and quoted that policy exactly. The policy itself is not under
challenge and there can be no question of any irrationality or unlawfulness when informing the Claimant's
solicitors that their request fell outside the scope of the policy.

20. The letter from the Claimant dated 5 June 2017 was clearly directed to the Defendant in its role as
competent authority. The letter expressly uses that terminology and invites the Defendant as competent
authority to reconsider the reasonable grounds decision. The letter has also been sent in the context of
ongoing litigation to persuade the Defendant to retake both the reasonable grounds decision and the
certification decision in the light of Dr Wilson's evidence. The response of the Defendant correctly points
out that as Dr Wilson's report was not before the decision maker it is not something that has to be taken
into account in relation to the challenges against the original decisions.

21. At this stage, the Claimant does not raise the point with the Defendant that it is also a first responder
and request that it act in that capacity to refer Dr Wilson's report to the competent authority. Furthermore,
the Claimant has not yet tried to approach another first responder or identified the problem that is
subsequently encountered, when the Salvation Army declined to act. The Claimant's solicitors do not know
at this point if the Salvation Army will be prepared to make a referral. They cannot make that point to the
Defendant as on the facts it has not arisen The first time the Claimant's solicitor raises this potential


-----

difficulty with the Defendant is in the letter dated 6 September 2017 (see paragraph 14) when it is stated
that the Defendant was also the first responder. In that letter there is a reference to the Salvation Army
declining to make reconsideration requests, but this must have been based on the solicitor's general
knowledge as the correspondence with the Salvation Army does not take place until November/December
2017.

22. The Claimant's case conflates the response of 20 June with subsequent events when the Salvation
Army said it would not make the referral. If on the 20 June that was known, then it may be that a refusal to
reconsider would be irrational and/or in breach of legal obligations towards potential victims of **_modern_**
**_slavery as there would seem to be no other way of the new information being considered. However, what_**
the Defendant did was to follow its own published policy (which is not subject to challenge in this case).
That policy has been developed taking into account a number of considerations about why referrals are not
accepted from solicitors. It is not irrational or otherwise unlawful to follow the published policy when the
factual position as at the 20 June matched the policy guidance exactly and the Claimant was not left in a
position where there was no question of the material being considered. The Defendant's decision properly
characterised was not a refusal to reconsider the Reasonable Grounds Decision, but rather a decision to
follow the Guidance and inform the Claimant's solicitors of the way in which Dr Wilson's report should be
handled. The decision was not unlawful.

**Conclusion**

23. For the reasons I have given, the ground of challenge fails. Accordingly, this claim is dismissed.

**End of Document**


-----

