# R v BEP [2022] EWCA Crim 1881

Court of Appeal, Criminal Division

Lady Justice MacUr DBE, Mr Justice Holgate, The Recorder Of The Royal Borough Of Kensington and Chelsea
(His Honour Judge Edmunds Kc) (Sitting As A Judge Of The Court Of Appeal Criminal Division)

4 November 2022Judgment

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**
**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**Mr S Parham appeared on behalf of the Applicant**

**Mr A Johnson appeared on behalf of the Crown**

**____________________**

**J U D G M E N T**

Friday 4[th] November 2022

**LADY JUSTICE MACUR: I shall ask Mr Justice Holgate to give the judgment of the court.**

**MR JUSTICE HOLGATE:**

**Introduction**

1. The applicant applies for an anonymity order under section 11 of the Contempt of Court Act 1981.  We have
had regard to the observations in R v L and N _[[2017] EWCA Crim 2129 at [9] to [15] and R v GS](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_ _[2018] EWCA Crim_
_1824, [2018] 4 WLR 167 at [5]. The principle of open justice applies. Any departure from that principle must be_
strictly necessary. In this case we have not had the benefit of any submissions from the media. We have therefore
scrutinised the matter closely. Given that the prosecution has not challenged the conclusions of the Single
Competent Authority referred to below that the applicant is a victim of modern slavery for the reasons it gives, we
consider that it is strictly necessary to make an anonymity order in respect of the applicant, who will be referred to
as "BEP".

2. In July 2019 in the Crown Court at Harrow before Her Honour Judge Francis the applicant pleaded guilty on rearraignment to one count of producing a Class B drug. On 19[th] July he was sentenced to eight months'
imprisonment. The court ordered a second count concerned with the abstraction of electricity to lie on the file in the
usual terms.


-----

3. The applicant's application for an extension of time of 965 days within which to seek leave to appeal against
conviction has been referred to the full court by the single judge. The applicant is represented by Mr Sam Parham,
who did not appear in the court below.

4. The application to extend time relies partly upon (1) a conclusive grounds decision issued in August 2019 that
the applicant is a victim of trafficking and (2) reports from a consultant psychologist, Michael Smyth, in September
and November 2019, stating that the applicant is a vulnerable adult diagnosed with severe complex PTSD and
comorbid major depressive disorder as a consequence of his trafficking.

5. Plainly the timing of those documents does not explain the long delay which occurred between the end of 2019
and December 2021, a period of about two years. For that purpose the applicant relies upon a witness statement
from Philippa Southwell, the applicant's current solicitor. She says that her firm was not instructed until January
2020. She relies upon the delays she experienced in obtaining necessary documentation. However, it appears that
material from immigration lawyers was received by July 2020, and the provision of information by the trial solicitors
was completed by December 2020. In that month papers were sent to newly instructed counsel to draft and advise
on grounds of appeal. The transcripts of the Crown Court proceedings were provided in March 2021. It is not clear
why that took so long, given that only four pages of transcript needed to be produced and that had been requested
as far back as June 2020. But, more importantly, draft grounds of appeal were not provided by counsel until August
2021. The solicitors commented promptly on that document, but the finalised advice and grounds were not
provided until November 2021. In December 2021, _McCook responses were sought and provided. In our_
judgment, the overall delay has not been justified. It certainly cannot be attributed to the need to obtain documents
after new solicitors were instructed, as the witness statement seeks to do. Nevertheless, the fundamental question
is whether it is in the interests of justice to grant the extension of time sought. That depends upon the justice of the
case and an examination of the merits of the proposed grounds of appeal.

**The Facts**

6. In March 2019, a search warrant was executed at a two bedroom maisonette in London.  The applicant, an
Albanian national, the sole occupant, was asleep on a mattress in the kitchen.

7. Cannabis plants were found growing in rooms on the ground floor and in the upstairs bedrooms. Hydroponics
equipment had been installed along with air ducting. There were some smaller plants in an incubator and a drying
room had been set up with harvested cannabis plants hanging to dry out. The electricity had been bypassed and a
new switchboard had been installed with wires leading into all of the rooms. There were 67 cannabis plants with an
estimated yield of around 7 kilograms, together with three bags of dried, harvested cannabis weighing about 2.5
kilograms.

8. The applicant was arrested. He confirmed his name but said that he could speak only limited English. In
interview he answered "No comment" to all questions and served a prepared statement which stated:

"I was arrested today at an address I have been living at. I am a victim of modern slavery. I came here
from France and the people who facilitated my arrival charged me £10,000, which I have to pay off within
12 months.

I do not wish to answer any questions at this time due to concerns for my own safety. I fear I would be a
target for violence by not paying off the debt or speaking to police."

Thereafter, he answered "No comment" to all questions.

9. In summary, the applicant's counsel submits that the conviction is unsafe because, firstly, the applicant would
have been able successfully to rely upon a defence under section 45 of the **_Modern Slavery Act 2015 and_**
secondly, the applicant's guilty plea was equivocal.

10. We note that the applicant does not advance any argument involving abuse of process. The applicant accepts
that he was properly advised and he makes no criticism of his legal team in the court below. He also accepts that
his decision to change his plea to guilty was "freely made".


-----

11. Mr Andrew Johnson, on behalf of the prosecution, submits that the plea was not equivocal. He submits that it
is not open to the applicant to go behind his guilty plea in this application.

12. The applicant also seeks leave under section 23 of the Criminal Appeal Act 1968 to introduce fresh evidence in
the form of the following documents:

1. Referral by the National Referral Mechanism, dated 26[th] March 2019;

2. The Single Competent Authority's reasonable grounds decision, dated 8[th] May 2019;

3. The SCA's conclusive grounds decision letter, dated 9[th] August 2019;

4. The SCA's minute sheet on conclusive grounds, dated 9[th] August 2019;

5. Positive conclusive grounds minute, dated 9[th] August 2019;

6. Medico-Legal Report of Michael Smyth, dated 5[th] September 2019;

7. Home Office screening interview, dated 8[th] October 2019;

8. Medico-legal Report of Michael Smyth, dated 5[th] November 2019;

9. The applicant's witness statement, dated 25[th] November 2021.

13. We have been invited by both parties to consider this material de bene esse. Mr Parham did not seek to call
the applicant, and Mr Johnson did not ask for him to be made available for cross-examination. He added that the
prosecution does not seek to challenge the witness statement or the conclusive grounds decision letter of the SCA
for the purposes of the application before this court. He submits that, even taking those documents at face value,
the proposed grounds of appeal are unarguable; the plea was not equivocal. We accepted the parties' invitation to
receive the material de bene esse.

**The Applicant's Plea in the Crown Court**

14. When the applicant first appeared in the magistrates' court, he indicated a not guilty plea. He said that the real
issue in the case was "duress/modern slavery. I was forced to commit the offence".

15. At a plea and trial preparation hearing in the Crown Court on 24[th] April 2019 the applicant was arraigned and
entered not guilty pleas. So far as the production of cannabis was concerned, he identified the issue for trial as
"section 45 MSA 2015 defence". The trial was placed in a warned list commencing on 16[th] September 2019.

16. On 8[th] May 2019 the Single Competent Authority made a positive reasonable grounds decision. In his Advice
on Appeal, Mr Parham accepts that the applicant was clearly advised about the availability of the section 45
defence and that the change of plea was instigated by him contacting his solicitors and telling them that he wanted
to plead guilty. He also accepts that the advice given by the trial lawyers was appropriate and that no criticism is
made of them.

17. It is clear from the McCook material that on 6[th] June 2019 the applicant contacted his solicitors informing them
that he wanted to plead guilty and asked if he could be sentenced early if he did. He said that the reason for
pleading guilty was that inmates had advised him to plead guilty as he would receive a shorter sentence.

18. On 19[th] June 2019, defence solicitors visited the applicant in custody. Their note states:

"Client adamant he wants to plead guilty. Is annoyed he wasn't told to at PTPH."

The applicant was advised that the outcome of the NRM referral was still to be announced and that it might be
better to wait for that. The solicitor added:

"But based on instructions, he appears not to be victim of modern slavery."

"Client understands the risk, but certain wants to plead. He doesn't want to risk losing credit. Wants to be
produced. Denies electricity abstraction, but will plead if has to."


-----

During the same visit, the applicant signed a handwritten note in these terms:

"1. I [BEP] wish to plead guilty. I understand that I am currently awaiting a decision on a NRM referral but
having considered my options I wish to plead guilty and be sentenced as soon as possible. I do not wish to
continue with my section 45 modern slavery defence. I have been fully advised of my options. I want to
get as much credit as possible for a guilty plea."

The note was also signed by the Albanian interpreter.

19. On 20[th] June 2019, in accordance with their instructions, defence solicitors wrote to the Crown Court at Harrow
stating that the applicant had instructed them to ask for the case to be listed as soon as possible for him to enter a
guilty plea to cultivation of cannabis.

20. On 1[st] July 2019, the applicant was re-arraigned. He pleaded guilty. He had previously signed a handwritten
note in the following terms:

"I [BEP] wish to plead guilty to the offence of producing cannabis. I've been advised by my solicitor … and
discussed my wish with him. I've confirmed my choice with my barrister today and been advised on
sentence. I make this decision of my own free will. I understand that if I'm not guilty I should plead not
guilty. I wish to plead guilty."

The note was also signed by the Albanian interpreter.

21. In addition, Her Honour Judge Francis made this entry on the DCS:

"Preliminary assessment re NRM accepts that he may have been trafficked and potentially he had a
defence under section 45 though he was adamant that he did not want to await the full assessment and
wanted to get his plea in. This is still relevant to sentence (especially in terms of role) and PSR will be
needed."

22. At the sentencing hearing itself the judge made another entry on the DCS:

"Lesser role – evidence he had been trafficked and was under compulsion, though he has refused to take
matter further and advance defence under Modern Slavery Act."

23. In her sentencing remarks the judge said:

"Although it might have been open to you to put forward a defence under the **_Modern Slavery Act, you_**
have decided to enter a guilty plea and it falls to me to punish you for what you have done.

Having reviewed the Sentencing Guidelines, I consider this matter falls into Category 2 because the
quantities of cannabis being grown were significant, and were for commercial use. I take the view that your
role in producing this cannabis was a lesser role, in light of the fact that you were being compelled to do
the work that you were doing. The starting point on sentences for such an offence is one year's
imprisonment and although you did not enter a guilty plea at the first opportunity, in light of the
complications provided to us by the Modern Slavery Act, I am going to give you maximum credit for that
plea which means that

the sentence I impose is one of eight months' imprisonment."

24. We note that the witness statement of the applicant, which is the subject of the application to adduce fresh
evidence, does not attempt to explain his decision to plead guilty.

**_Modern Slavery Investigation_**

_Interview_

25. The applicant was interviewed by police in relation to his assertion that he was a victim of modern slavery. He
said that, having fallen into financial difficulties, he had left Albania on 11[th] September 2018 and travelled through


-----

Europe. On 13[th] September 2018 he arrived in Roscoff in Brittany. He attempted to enter the United Kingdom
illegally on two occasions, but was caught both times. He then met an agent in Roscoff who said that he would get
him into the United Kingdom for £10,000. It was agreed that he would work for 12 months to repay the debt. The
applicant said that he was not given any information about the work at the time. He was transported into the UK by
lorry.

26. The applicant started to work in a warehouse where cannabis was being grown, but he did not want to do such
work. He managed to find a construction job instead. He paid about £2,000 to the traffickers, but was told that it
was not enough and that he would have to work for them again. He moved to the house in which he was arrested.
By that time he had been there for about two months. The house was already set up with the cannabis farm when
he arrived. The applicant was told he would be kidnapped if he did not pay back his debt to the traffickers.

_National Referral Mechanism_

27. Following his interview, the applicant's case was referred to the National Referral Mechanism ("NRM") on 26[th]
March 2019 because the applicant was a potential victim of trafficking, modern slavery and forced criminality.

28. On 8[th] May 2019 the Single Competent Authority ("SCA") issued a decision letter that there were reasonable
grounds to conclude that the applicant was a victim of modern slavery.

29. On 9[th] August 2019, the SCA concluded that the applicant was a victim of modern slavery. The decision was
based upon two witness statements from the applicant, one dated 26[th] March 2019 and the other undated. The
decision maker broadly accepted the account reported by the applicant, which was similar to that which he had
previously given to the police. Likewise, the applicant's witness statement dated 25[th] November 2021, which is the
subject of the application to adduce fresh evidence, gives a similar account but in greater detail.

30. The fresh evidence from Mr Smyth does not take the matter any further. On the subject of trafficking, his
reports rely upon the account given by the applicant.

**The Applicant's Submissions**

31. In R v Tredget _[[2022] EWCA Crim 108; [2022] 4 WLR 62 at [153] to [173], the court identified three categories](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
of case in which an appellant can submit that, notwithstanding a guilty plea, his or her conviction is unsafe:

1. Cases where the plea was equivocal or unintended (for example, where the plea of guilty was vitiated
by improper pressure, or was compelled as a matter of law by an incorrect, adverse ruling by the trial judge
which left no arguable defence to be put before the jury);

2. Cases where there is a legal obstacle to the defendant being tried for the offence, where an abuse of
process is involved;

3. A small residual category where it is established that the applicant did not commit the offence and the
plea was therefore false, such as where it is proved that he could not have committed the offence because
he was in prison at the time.

32. In his written submissions Mr Parham argued that the applicant's case falls within the first category. In oral
submissions he faintly suggested that it could also be considered as an example of a false plea under the third
category. This submission was not developed and was not supported by any authority. Counsel recognises that it
would represent an extension of established authority, and we have not been given any sound basis upon which
the court could accept this novel line of argument. We need not consider it any further.

33. Returning to the primary submission, the applicant accepts that he was correctly advised by his legal team as
to the availability of the section 45 defence, and that he was also advised that he could wait for the NRM/SCA
process to conclude. But Mr Parham submits that the plea was equivocal because, although it was entered freely
following legal advice, the applicant maintained that he was a victim of modern slavery and that this explained his
participation in the offending. It is said to have been equivocal because at no point did the applicant accept his
guilt and at no stage did he accept that the section 45 defence was not available to him Mr Parham submits that


-----

the applicant's assertion that he was a victim of trafficking was subsequently confirmed by the SCA and has not
been disputed by the prosecution, either at first instance or on appeal. He was sentenced on the basis that he had
been trafficked and that there was compulsion present in his case. Far from being seen as unreliable, his account
has been accepted on a number of occasions.

**Discussion**

34. We are grateful to counsel for their written and oral submissions.

35. In Tredget the court stated at [173] that a common element across the three categories in which a conviction
may be held to be unsafe is:

"… that the circumstances relied on by the appellant need to be established by him or her. That is merely
an application of the normal rule that it is for an appellant to demonstrate that his conviction is unsafe. …"

Accordingly, for the first category, the matters vitiating the plea, as to why the plea was equivocal or unintended,
must be demonstrated. In the present case it is not suggested that the plea was unintentional. It plainly was made
freely and deliberately.

36.  Clearly, this is not a case where a plea of guilty was compelled as a matter of law by an incorrect, adverse
ruling by a trial judge which left the defendant with no arguable defence to put before a jury (see Tredget at [155]).
Nor is it suggested that there was any improper pressure. Nor is it a case where the defendant's trial lawyers failed
to advise on a defence, or gave incorrect legal advice in that regard, which deprived the defendant of a defence
which probably would have succeeded, as in R v Boal [1992] QB 591(see also Tredget at [157] to [159]).

37. In what sense then is it being suggested that the guilty plea in this case was "equivocal"? The answer from Mr
Parham is that although the applicant was intent on entering a guilty plea, he did so whilst maintaining his not guilty
instructions, namely that he was a victim of modern slavery who had been compelled to undertake criminal work
in order to pay off a debt to traffickers. Alternatively, he says that the plea was equivocal because at no point did
the applicant accept guilt, and at no stage did he accept that the section 45 defence was not available to him.

[38. On the issue of whether the applicant accepted his guilt, it is necessary to return to R v Asiedu [2015] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FW9-9W11-F0JY-C09M-00000-00&context=1519360)
_[Crim 714; [2015] 2 Cr App R 95, where Lord Hughes stated at [19] that a defendant who pleads guilty is making a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FW9-9W11-F0JY-C09M-00000-00&context=1519360)_
formal admission in open court that he is guilty of the offence. Ordinarily there is nothing unsafe about a conviction
based on the defendant's own voluntary confession in open court by making an unambiguous and deliberate plea of
guilty. Lord Hughes said at [31] that although a defendant will be advised that a guilty plea will be reflected in credit
against sentence, that does not alter his freedom of choice. He will be advised that such a plea would amount to a
confession and only he knows the true facts. If he is guilty, the fact that the choice between admitting the truth and
nevertheless denying it may be difficult does not alter the effect of choosing to admit it.

39. We do not accept that a defendant has to accept that a defence is not available to him in order to render his
guilty plea unequivocal. Unsurprisingly, no authority has been cited to support that proposition. A defence may be
available to a defendant, but he may decide to accept advice on the risk that it may not succeed and plead guilty in
order to obtain a reduction in sentence. A plea of guilty in such circumstances does not render the plea equivocal.
That is a perfectly proper choice which is open to a defendant. It does not result in a conviction which is unsafe.

40. On analysis, the applicant's case comes down to his assertion that he maintained his instructions that he was a
victim of modern slavery. Mr Parham relies upon the NRM process which was followed from March 2019, and
which culminated in a positive conclusive grounds decision in August 2019. In addition, before she passed
sentence, the judge was aware of the positive reasonable grounds decision in May 2019. But Mr Parham does not
seek to make any criticism of the judge. We agree that no such criticism could be made. She was told that the
applicant was adamant about not relying upon a section 45 defence and not waiting for the outcome of the NRM
process. In our judgment, the fact that that process was ongoing and that the judge treated the applicant's role as
"lesser" because of compulsion did not render the applicant's decision to plead guilty equivocal.


-----

41. In R v V [2020] EWCA Crim 1355, Simler LJ, giving the judgment of the court, explained at [25] the distinctions
between the decision of the competent authority on victim status and the applicability of the defence under section
45, the latter being entirely a question of fact for a jury to decide:

" Moreover, as is clear from the terms of section 45, the statutory defence does not arise automatically on
proof that a person was the victim of trafficking. Neither the international conventions relating to human
trafficking nor our domestic legislation affords automatic immunity from prosecution in these cases. The
effect of both international and domestic legislation is that a number of questions of fact must be addressed
to determine whether the defence is satisfied in a case where there is credible evidence that the defendant
is a victim of trafficking. These are, by reference to the domestic provisions:

(i) whether he was compelled either by another person or by his circumstances to do the act which
constitutes the offence (section 45(1)(b));

(ii) whether the compulsion was attributable to slavery or being or having been a victim of trafficking
(section 45(1)(c)); and

(iii) whether a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act (section 45(1)(d)).

In other words, the degree of compulsion on the defendant and the alternatives reasonably available to him
or her are critical features of the analysis. The offence must be committed as a direct consequence of or in
the course of trafficking or slavery and the criminality must be significantly diminished or effectively
extinguished because no realistic alternative was available but to comply with the dominant force of
another."

42. At [27] Simler LJ stated:

"Beyond that, there remains the general jurisdiction derived from section 2(1) of the Criminal Appeal Act
1968 to 'allow an appeal against conviction if … the conviction is unsafe'. Whether the defendant was fit to
plead, knew what he was doing, intended to plead guilty and did so without equivocation and after
receiving expert advice will be highly relevant to the question of whether or not the conviction is unsafe.
But if without fault on his part he was deprived of what was in all likelihood a good defence in law and with
the benefit of correct advice there would probably have been an acquittal so that an injustice has been
done, this court may intervene: see R v Boal (1992) 95 Cr App R 272 and R v K _[[2017] EWCA Crim 486.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NHG-R6Y1-F0JY-C538-00000-00&context=1519360)_
We emphasise, as this court has done repeatedly, that it is only exceptionally that it will be prepared to
intervene in such a situation. The court will require to be satisfied that the defence would quite probably
have succeeded so that a clear injustice has been done."

43.  In the present case, the records kept by the applicant's solicitors show that the applicant was properly advised
about the section 45 defence. As we have said, Mr Parham makes no criticism of that advice. On 19[th] June 2019,
the solicitors advised the applicant that it might be better to wait for the outcome of the NRM process. But, of
course, that outcome was not certain. The solicitors advised on the merits of the section 45 defence. It is recorded
by them that the applicant understood the risk. The applicant considered the options and decided of his own free
will that he did not wish to rely upon the section 45 defence. In addition, we note that this is not a case in which any
question mark has been raised over the capacity of the applicant to plead guilty, notwithstanding the mental health
issues considered subsequently by Mr Smyth.

44. The mere fact that the applicant continued to rely upon the NRM referral process does not mean that he
continued to maintain a defence under section 45, so as to render his guilty plea equivocal. The fresh evidence
upon which the applicant seeks to rely does not address the advice that was given, or the reasons why the
applicant chose to plead guilty. Instead, the court has to rely upon the McCook material available to it.

45. Mr Johnson accepts on behalf of the prosecution that on the material now before this court, the applicant would
have had at least a real prospect of successfully relying upon the section 45 defence. But, in our judgment, that is
consistent with there being a risk that that defence would not succeed in front of a jury. As Lord Hughes pointed out
in _Asiedu, defendants in criminal trials may be confronted with a difficult choice when deciding whether or not to_


-----

plead guilty. Even where that is so, that does not alter the effect of their choice to admit guilt. Such circumstances
are insufficient to render a guilty plea equivocal.

46. For these reasons, we do not accept that the proposed grounds of appeal are arguable. It is not arguable that
the conviction is unsafe. In these circumstances we refuse the application for the extension of time needed for
making an application for leave to appeal against conviction.

_____________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

