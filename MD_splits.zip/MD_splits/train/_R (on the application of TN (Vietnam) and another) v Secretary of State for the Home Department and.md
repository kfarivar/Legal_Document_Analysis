[2017] EWHC 59 (Admin)

# *R (on the application of TN (Vietnam) and another) v Secretary of State for
 the Home Department and another [2017] EWHC 59 (Admin)

Queen's Bench Division, Administrative Court (London)

Ouseley J

20 January 2017Judgment

**Ms Nathalie Lieven QC, Ms Charlotte Kilroy** (instructed by **Messrs Duncan Lewis) for the** **First**
**Claimant**

**Ms Stephanie Harrison QC and Ms Louise Hooper (instructed by** **Messrs Duncan Lewis** ) for the
**Second Claimant**

**Mr Robin Tam QC, Ms Natasha Barnes, Ms Belinda McRae (instructed by the** **Government Legal**
**Department) for the First Defendant**

**Ms Julie Anderson (instructed by the Government Legal Department) for the Second Defendant**

Hearing dates: 11-14 October 2016

**Approved Judgment**

**MR JUSTICE OUSELEY :**

1. These two challenges represent a further round in the contests over the lawfulness of aspects of the
detained fast track system for the determination of asylum claims and appeals.

2. I set out part of the earlier history in paragraphs 25-37 of my judgment in Detention Action v Secretary
_of State for the Home Department [2014] EWHC 2245, referred to in these proceedings as DA1. DA2 is my_
judgment on consequential orders. The earliest cases had been concerned with the lawfulness of detention
for fast track decisions on asylum claims by the Secretary of State for the Home Department, SSHD.  The
appeal system was not then involved. Its introduction to the DFT is described in paragraphs 53-54 of DA1.
The Immigration and Asylum Appeals (Fast Track Procedure) Rules 2003 were introduced.

3. The fairness of the DFT decision-making system was considered in R (Refugee Legal Centre) v SSHD

_[2004] EWCA Civ 1481, [2005] 1 WLR 2219, but the appeal process was only considered in the context of_
whether it could correct failings which occurred before the SSHD's adverse decision on the asylum claim.
The lawfulness of those Rules was not challenged.

4. Next, the Asylum and Immigration Tribunal (Fast Track Procedure) Rules 2005 SI 2005 No 560 were
promulgated, the 2005 FTR. These covered appeals, and remained in force until 20 October 2014 when
the Tribunal Procedure (First-tier Tribunal) (Immigration and Asylum Chamber) Rules 2014 SI 2014
No.2604, the 2014 Rules came into force. The new Fast Track Rules, the 2014 FTR, were in the Schedule
to the 2014 Rules, which also contained the Principal Rules,.

5. DA1 concerned a challenge to the lawfulness of the operation of the initial decision-making system in
the detained fast track. The 2005 FTR were not the subject of that challenge, and were not directly argued


-----

[2017] EWHC 59 (Admin)

to be unfair or unlawful. I found that the operation of the system up to the start of the appeal stage was
unlawful, because unfair, in a number of respects.

6. The 2014 FTR, however, were the subject of direct challenge by Detention Action in _R (Detention_
_Action) v First-tier and Upper Tribunals (Immigration and Asylum Chambers), Lord Chancellor and SSHD_

_[2015] EWCA Civ 840, [2015] 1 WLR 5341, DA6, as it was called before me. On 29 July 2015, the Court of_
Appeal dismissed the Lord Chancellor's appeal against the Order of Nicol J dated 16 June 2015 in DA5,

_[2015] EWHC 1689 (Admin) declaring that the 2014 FTR and related Tribunal Procedure (Upper Tribunal)_
Procedure Rules 2008  were  ultra vires. They were quashed. Permission to appeal to the Supreme Court
was refused.

7. The Court of Appeal did not specify any consequences which were to follow for appeals which had
already passed through that process under the 2014 FTR. The upshot however was that Mr Clements,
President of the First-tier Tribunal, decided in _Alvi and others v SSHD_ on 4 August 2015, after hearing
some argument, that judicial review applications in the FtT to quash decisions reached under the 2014
FTR were better dealt with by the alternative remedy of setting aside the decisions under Rule 32 of the
Tribunal Procedure (First-tier Tribunal) (Immigration and Asylum Chamber) Rules 2014. Rule 32 empowers
the FtT to set aside and remake a decision if it considers that to be “in the interests of justice” where “there
has been some other procedural irregularity”, e.g. other than documents not being sent or a party not being
present. Hearing appeals under ultra vires rules constituted the procedural irregularity. Mr Clements added
simply that it was in the interests of justice for such decisions to be set aside, a conclusion he reached
without further reason or qualification. He set them aside of his own motion and so the time limit for an
application (14 days from notice of the decision for someone in the UK and 28 days for someone outside
the UK) did not apply. The appeals were then treated as pending. The SSHD, he said, could apply to take
advantage of R32, if so minded.

8. The practice of the FtT now in relation to decisions made under the 2014 FTR is that an application to
set them aside is required, but that the decisions are then set aside of the FtT's own motion: the FtT
President has drafted a standard form letter for applicants who seek to have their appeal decisions set
aside, saying that their FtT decision was made under the 2014 FTR, and inviting him of his own motion to
set aside the Tribunal's decision under R32. So the time limit in R32 is not applied to prevent the
application succeeding. Nor is any information required about any unfairness in fact in the determination of
the individual appeal. It also appears that removal from the UK, after dismissal of an appeal, has not
prevented appeal decisions being set aside.

9. A standard Home Office letter of September 2015, referring to the President's draft letter, gave
appellants 14 days to notify it that an application had been made, after which, in the absence of such an
application, removal steps would be taken. It invited those who had brought judicial review proceedings
based on the unlawfulness of the 2014 FTR to use R32 instead. Mr Tam QC for the SSHD explained that
the SSHD had not taken issue with the FtT President's ruling for essentially practical reasons related to the
number of appeals affected, and their comparative recentness, though the SSHD had concerns about it.

10. However, the decision in DA6 led to challenges to the 2005 Fast Track Rules. On 11 January 2016, Mr
Clements promulgated a ruling that 50 applications to set aside decisions reached under the 2005 FTR
should be adjourned while the Administrative Court ruled on the lawfulness or otherwise of the 2005 FTR.
Both Claimants are among the applicants to the FtT. One factor was that the FtT, unlike the Administrative
Court, could make no general declaration that the FTR were ultra vires, but would have to rule on the
lawfulness of the Rules by way of individual applications.

11. The resolution of the vires of the 2005 FTR was ordered by Cranston J on 14 June 2016 in the context
of these two claims, as lead but not test cases. There isa large number of claims raising the same issue.

12. I add that the vires of the 2003 FTR are also now being raised, but in other proceedings.

**Were the 2005 Fast Track Rules ultra vires?**


-----

[2017] EWHC 59 (Admin)

13. This argument arises as a result of the decision in DA6. The Claimants say that it follows from that
decision, which is binding on me, that the 2005 FTR are equally ultra vires. The Defendants say that the
decision is not strictly binding and I should not follow it. I start with DA6.

14. The 2014 FTR were made under s22 of the 2007 Tribunals, Courts and Enforcement Act, empowering
Tribunal Procedure Rules to be made, so far as material “with a view to securing (a) that in proceedings
before the First-tier Tribunal and Upper Tribunal, justice is done”, that the system is accessible and fair,
and that proceedings are handled quickly and efficiently.

15. Lord Dyson MR, with whom Briggs and Bean LJJ agreed, held at [8]  that the legality of the FTR had
to be judged by reference to that empowering provision, noting the possible tension between the need for
fairness and accessibility, and speed and efficiency. He adopted generally the principles proposed by Mr
Eadie QC for the SSHD for determining whether a system for challenging adverse decisions was so unfair
as to be unlawful, carrying an unacceptable risk of unfairness to asylum seekers; [27]. He concluded that
“the timetable for the conduct of these appeals is so tight that it is inevitable that a significant number of
appellants will be denied a fair opportunity to present their cases under the FTR regime.” [38F].  He
rejected the argument that there were adequate safeguards against that in Rule 12 of the 2014 FTR,
empowering adjournment for up to 10 days if justice required and, more importantly, Rule 14, which
required the appeal to be dealt with by the Principal Rules and not the FTR, if the Tribunal were satisfied
that the appeal could not be determined justly within the FTR timescales. The correct balance had not
been struck in the 2014 FTR.

16.  Lord Dyson said in summary:

“45. To summarise, in my view the time limits are so tight as to make it impossible for there to be a fair
hearing of appeals in a significant number of cases. For the reasons that I have given, the safeguards on
which the SSHD and the Lord Chancellor rely do not provide a sufficient answer. The system is therefore
structurally unfair and unjust. The scheme does not adequately take account of the complexity and difficult
of many asylum appeals, the gravity of the issues that are raised by them and the measure of the task that
faces legal representatives in taking instructions from their clients who are in detention. It seems to me that
some relaxation of the time limits is necessary, but it is not for the court to prescribe what is required to
remedy the problem. A lawful scheme must, however, properly take into account the factors to which I
have referred, whilst, I acknowledge, giving effect to the entirely proper aim of processing asylum appeals
as quickly as possible consistently with fairness and justice.”

17. The 2005 FTR were made under s106, as amended, and s112 of the Nationality, Immigration and
Asylum Act 2002. That section set out detailed powers which do not bear on the issues, but also contained
in s106(1A) a general duty, in language not materially different to s22 of the 2007 Act, that “In making rules
under subsection (1), the Lord Chancellor shall aim to ensure that proceedings before the Tribunal are
handled as fairly, quickly and efficiently as possible.” Like s22, it empowered rules to confer on tribunal
members responsibility for ensuring that proceedings were indeed handled in that way. When the short life
of the Asylum and Immigration Tribunal ended, and its functions were transferred to the First-tier Tribunal
in 2010, the Transfer of Functions Order 2010 SI No. 21 provided for the 2005 FTR to have effect as if they
were Tribunal Procedure Rules. There is therefore no distinction in terms of vires between the provisions
empowering the 2005 and the 2014 FTR.

18. Neither party pointed to any material difference between the structure and content of the 2005 and
2014 FTR. There is none, or at least none helpful to the SSHD. The crucial timescales, and the
adjournment powers and powers to transfer out, which contain the safeguards, are not materially different.
The 2014 FTR gave appellants one more day in which to submit appeals, and under the 2005 FTR cases
could only be transferred out “in exceptional circumstances”. In _SH (Afghanistan) v SSHD_ _[2011] EWCA_
_Civ 1284, however, that provision was held to be irrelevant since there was no basis for holding that_
appeals could be determined unjustly were the circumstance not exceptional. But Ms Lieven QC, for the
Claimants on the general issues, is right that the language of the 2005 FTR had an emphasis which was
removed in the 2014 FTR.


-----

[2017] EWHC 59 (Admin)

19. Although Mr Tam submitted that the SSHD could not now obtain evidence about how the 2005 FTR
had operated in practice over their lifetime, there was no positive evidence before the court that there had
been significant changes over time. More importantly, as the 2014 FTR were in force only from 20 October
2014, almost all of the statistical evidence about the operation of the fast track appeal system presented to
Nicol J and to the Court of Appeal in DA5 and 6 was drawn from the more recent operation of the system
under the 2005 FTR. There was no suggestion that, in the recent years to which that evidence related at
any rate, there was any significant difference between the way the appeal system operated under the 2005
and the 2014 FTRs. The further evidence before me was not designed to show that.

20. The Court of Appeal did not base its judgment on any analysis of the way the detained fast track
system operated up to the receipt of the adverse SSHD decision. Its attention was focused on the appeal
system, from receipt of the adverse decision of the SSHD, the process governed by the FTR at issue.

21. On that basis, I find it difficult to see how I could, let alone why I should, reach a different view on the
vires of the 2005 FTR from that reached by the Court of Appeal on the vires of the 2014 FTR. The time and
manner in which the challenge to the 2005 FTR was brought may give rise to different issues, as to remedy
or consequences, from those which the Court of Appeal might have had in mind when dealing with FTR in
force only from October 2014, in a challenge commenced quite early in 2015. In fact, however, the Court of
Appeal made no comment about what would or should happen to appeals which had been heard under the
2014 FTR. It envisaged Rule changes to govern the future.

22. Mr Tam contended however that the decision in DA6 did not deal with the 2005 FTR, and a decision
on the vires of the 2005 FTR should not be reached by comparing the two texts, but on the basis of
evidence as to how the system operated under them, and in the context of the operation of the detained
fast track more generally. Safeguards were present, and I should not depart from observations I had made
in DA1 on the vires of the 2005 FTR. He did not challenge directly the principles applied by the Court. He,
however, contended that its factual views were not binding, and that the 2005 FTR were not structurally
unfair. He also pointed out that the detained fast track had developed while the 2005 FTR were in force,
such that a conclusion that the FTR operated unfairly and unlawfully at one point in time could not mean
that they always operated in that manner; for example the number of appeals under the FTR in 2013 was
nearly twice that in 2007, and was three times higher, as a percentage of total asylum appeals.

23. For the purposes of this argument, he presented a variety of statistics about the detained fast track
processes up to the stage of the SSHD's decision on the claim, because the removal of an individual at
that stage from the detained fast track made it more likely that those remaining, whose appeals were heard
under the FTR, were dealt with fairly within those timescales. He also presented statistics about the way in
which the safeguards had operated, taking issue with the applicability of the Court of Appeal's conclusions
on the operation of the 2014 FTR to the operation of the 2005 FTR.

24. Further evidence was provided by Mr Smith, Head of the Detained Fast Track, comparing the
operation of the two sets of Rules, and stating that the evidence for the whole period 2005-2014 was
incomplete. The complexity of cases within the 2005 FTR had varied over the years. For much of the time
when the FTR 2005 were in operation, the case load was much smaller than towards the end, so there was
less pressure on the lawyers, and the timetable up to the SSHD's decision would have given appellants
longer overall to prepare their cases. There was evidence that the time between decision and appeal was
usually greater under both FTRs than the FTRs specified. The evidence however also showed that the
percentage of appeals transferred out or adjourned was lower under the 2005 FTR, and a lower
percentage were adjourned before the hearing. The adjournments were for 12 -14 days, (average median). Ms Ghelani, solicitor at Migrants' Law Project, took issue with how much of this was really new, or
presented a full picture anyway.

25. Mr Tam pointed to the absence of explanation by the Court of Appeal of what it had made of the
evidence provided to it about the operation of the safeguards of adjournments or transfers out of the fast
track, as supporting his contention that I should not feel bound in relation to the 2005 FTR by what the
Court of Appeal had decided in relation to the 2014 FTR, especially in the light of this further evidence. The


-----

[2017] EWHC 59 (Admin)

Court of Appeal did not mention the earlier filtering processes or that 25 per cent of the 960 cases heard
during the operation of the 2014 FTR were adjourned or transferred out, and 25 percent of that 25 percent
were so dealt with before the day of the hearing; the rest, which amounted to over 18 percent of all FTR
appeals, were adjourned or transferred out on the day of the hearing. It was doubtful if the Court had fully
appreciated the facts, particularly in the light of the argument, which it accepted, that it was unfair to have
to apply for an adjournment or transfer out, on the day of the appeal, to the judge who would then hear the
appeal, if the adjournment application were unsuccessful.  It could not therefore be said that the 2005 FTR
were so unfair throughout their lifetime that they were ultra vires, simply because the 2014 FTR were. On
the contrary, the FTR should be found to have operated fairly on the evidence.

26. I have examined a schedule produced at my request by Mr Tam, principally the work of Ms McRae
and the SSHD team, which showed the evidence before the Court of Appeal in DA6 and what was new
before me. Although I have not gone through all the documents referred to, there are a number of features
to highlight. First, the Court of Appeal had before it data which related to the operation of the fast track
appeal system under the 2005 FTR. Indeed, very little related to the operation of the 2014 FTR. Second,
the topics covered by the data before the Court of Appeal relate to the issues it considered. The data
before me but not before the Court of Appeal, which also includes data before me for DA1, also relates to
those same issues. It covers different periods of operation, though much is related to the more recent
years, and the data does not purport to be a complete data set for the topics to which it relates. It does
cover, albeit in different form or time frame, the same points as were before the Court of Appeal in terms of
numbers of cases, appeals, adjournments and transfers out by Tribunal decision. Third, the material which
appears to be additional before me covers the numbers released from the detained fast track before the
appeal process for certain periods (from DA1), the mean and median times between the adverse SSHD
decision and appeal, excluding adjournments, aimed at showing that these were longer than the FTR
required and so that the FTR operated more flexibly than understood by the Court of Appeal, the duration
of the adjournments, as set out above, the total number adjourned or transferred out of the detained fast
track, as set out above, the number of cases adjourned before and on the day of the hearing, as set out
above. Fourth, the Schedule highlights how limited were the references to the data in oral argument before
the Court of Appeal, though there were references to the data on adjournments and transfer out, and, on
various points, to DA1. But clearly more had been read than was referred to.

27. Mr Tam's points on the statistics were disputed: Ms Ghelani said that the mean and median calendar
days were irrelevant as a point of distinction, since the Rules looked to working days. There was no
difference in the significant nationalities in the detained fast track. The types of claim, and the nature of the
individuals did not change. The new evidence did not show that the percentages of adjournments and
transfers out was higher under the 2005 FTR; in fact they were higher under the 2014 FTR. The evidence
before the Court of Appeal was that only a very small percentage of cases were adjourned on a paper
consideration before the hearing. I accept her points.

28. In my judgment, the Court of Appeal's conclusions that the FTR 2014 did not meet the requirements of
the rule-making power, that the timetable was too tight and not remedied by the safeguards, begin with its
description of the work to be done for an appellant in detention after an adverse decision, as set out by Ms
Ghelani; [20-21]. None of that was controversial. The Court understood, at least from judicial experience,
what the appeals could involve by way of complexity and credibility and, though there may have been
evidence as well, again that is not controversial; [19 and 37]. It had in mind the contrast with the Principal
Rules, the fairness of which was not disputed.

29. Lord Dyson set out its task as judging whether the FTR were legal by reference to the rule-making
power, and whether it had been exercised “with a view to securing” the five objectives. The principles to be
applied were those put forward on behalf of the Secretary of State. Lord Dyson added [30] that the
question was “whether there is systemic or structural unfairness inherent in the FTR such as to render
them ultra vires.” This involved an examination of the FTR in the context in which they operate, but not an
examination of their practical operation. For this purpose, it used the principles in [27], the essence of
which was whether the unfairness was inherent in the system itself, and took as the “core question”


-----

[2017] EWHC 59 (Admin)

whether the system had the flexibility to react appropriately to ensure fairness. The context, summarised
above and in [38], led to the conclusion that the timetable was “so tight that it is inevitable that a significant
number of appellants will be denied a fair opportunity to present their cases under the FTR regime.” This
was so notwithstanding the acceptance by the Court, [38], that the tribunal judges were independent and
impartial specialists.

30. The Court's concern was with the material which could be presented to the FtT judges in the light of
the constraints on appellants. Hence its focus on the safeguards. Rule 12, adjournment, did not provide a
real answer because of the ten-day limit. The power to transfer out was inadequate (i) because of the
difficulty of taking the search for evidence sufficiently far, particularly where credibility was at issue, to
persuade the Tribunal that the prospect of a fruitful outcome warranted removal from the fast track, (ii) the
problem that this process would require the gaps in the evidence to be identified, but if unsuccessful, the
appellant would then have to say that he could nonetheless succeed, (which would show that there was no
need to take it out of the fast track); (iii) there would be a momentum in favour of carrying on, on the day of
the hearing; and (iv) FtT judges in the fast track would know that routine transfers out could lead to a
breach of the rules giving them “responsibility for ensuring that proceedings before the Tribunal are
handled quickly and efficiently.”

31. Mr Tam is right that the Court does not say what it made of the data. But there is a reason for that. The
Court did not decide that the FTR were lawful in content, but operated unfairly so as to make the system
unlawful. If that had been its decision, the vires challenge would have failed. Its judgment is not based on
data, and in particular is not based on the level of transfers out or adjournments. It is based on reading the
FTR against the background of the tasks to be done, the increased difficulties of doing them in detention,
the issues which arise on appeals, the tight timetable, and its judgment, in that general context, of the
inadequacy of the safeguards to provide sufficient systemic flexibility. Its view of that inadequacy is not
based on percentages of cases adjourned or transferred, leading to a view that a qualitative judgment
about effectiveness and systemic fairness could be derived from a given percentage. Its view was simply
that a significant number of cases were treated unfairly. No percentage of adjournments or transfers out
could disprove that.

32. I note in passing that the Court of Appeal made very little comment on the data in argument though
such comments as there are, (e,g, transcript pages 42-43) suggest that the case was not going to turn on
data.

33. This also disposes of one point made by Mr Tam as to why there should be no declaration that the
FTR 2005 were ultra vires. He said that as the vires depended on evidence as to their operation in
practice, and that practice varied over time, a declaration could not say that they had always been ultra
vires; and on the other hand it would be absurd for Rules to be intra vires one day and ultra vires the next.
But the answer is that the vires of the FTR is not dependant on nor does it vary with operational practice.
That is not the basis of the decision. They are or are not ultra vires by reference to the empowering
provision in the context for which they were made as expounded by the Court of Appeal, all of which would
have been to the mind of the rule-maker.

34. I see no real value in deciding whether or not I am strictly bound by the Court of Appeal in relation to
the 2005 FTR, on a close examination of the ratio decidendi, and whether I may not be bound by one or all
factual findings. I cannot see a basis for distinguishing the 2005 FTR from the 2014 FTR, whether by
reference to the empowering statutory provisions or the terms of the FTRs themselves. If the decision of
the Court of Appeal had turned on specific factual evidence about the operation in practice of the FTR
2014, it would have been right to consider the vires of the 2005 FTR against whatever evidence was
produced, though the fact that the data before the Court of Appeal related so much to the operation of the
2005 FTR would make it a difficult task to come to a different conclusion, and the further evidence
produced to me does not at first blush have any very marked differences. However, for the reasons I have
given, that would be to misunderstand the basis of the Court of Appeal's decision. The data provides no
basis for coming to a different conclusion, because it was not a data based conclusion.


-----

[2017] EWHC 59 (Admin)

35. Even if not strictly bound, I am bound to regard the Court of Appeal decision as highly persuasive, and
I would have to be very clear about the existence of serious errors in its decision before I could conclude
that it was wrong and not to be followed. I am not of that view, and I shall apply its decision in this case to
the 2005 FTR. This means that consideration of the evidence could not alter that conclusion, though it
might be relevant to whether any particular decision was fair, if that were to be the right test.

36. I accept Ms Lieven's point that the SSHD before Nicol J argued that there should be a stay because
the system had been in operation for a decade or more, that the Court of Appeal was well aware of the
2005 FTR and no one suggested to it that there were any material differences between the two sets of
FTRs. That does not mean that there was some silent ruling that what was decided about the 2014 FTR
must necessarily lead to the same remedy over the 2005 FTR. This point does not add to the argument
here. I see what was argued before Nicol J moreover as relating to the fact that the system had been in
operation for a long time without challenge and so continuing its existence pending appeal would create no
serious problem.

37. Mr Tam also argued that I should not follow the Court of Appeal decision because in effect it found that
the FtT judges were not doing their job properly, operating the safeguards as required; they were required
to take cases out of the fast track if the case could not be decided justly within it. This was indeed one of
the grounds upon which the SSHD unsuccessfully sought permission to appeal to the Supreme Court,
which found that the appeal had no reasonable prospects of success. This argument is a misreading of
the Court of Appeal's decision. It did not make the finding that Mr Tam attributed to it, and had it done so I
would have been surprised if the Supreme Court had regarded an appeal as lacking reasonable prospects
of success. It expressly found, [38], the FtT judges to be independent, impartial and specialist. But the
passage continues: “…who can usually be trusted to get the right answer on the basis of the material that
_is presented to them. I am also sure that they do their best to comply with the overriding objective of_
dealing with appeals justly.” The italicisation is Lord Dyson's. His point at that stage was that the tight
timetable prevented them having material which enabled the appellant to present his case fairly. So the
injustice was not down to them but to the tight timetable. When he considered the operation of Rule 12, its
limitation was inherent in the terms of the Rule itself. Rule 14 failed as a safeguard, not because, contrary
to what he said in [38] the judges were not doing what they thought was just, but because the system of
the FTR created unfairness to the appellant in presenting the very case for transfer, and conflicting
objectives would impede regular transfer out. The expectation of the Rules was that the time limits would
be observed. I cannot regard that as a suggestion that the judges did not do their duty; it was rather that
the Rules, by objective and content, created a strong bias or presumption in favour of keeping the case in
the fast track.

38. Mr Tam also prayed in aid what I had said in DA1, [184], about the vires of the FTR. As I was not
bound by the decision in DA6, I should apply what I had already said. I cannot agree. The vires of the 2005
FTR was not the subject of the challenge. The appeal system in the 2005 FTR nonetheless was raised
because it was said to add to the problems faced by those in the fast track process, or at least not to help
them. It was not explicitly argued that the FTR were ultra vires, but the FTR were criticised for unfairness,
and the absence of a Case Management Review Hearing was highlighted. The argument about the FTR
could easily imply a vires attack, rather than simply an argument about the absence of a corrective
mechanism. I concluded that I should therefore comment on the vires, and the extent to which I thought
that the difference between the FTR and Principal Rules created unlawful unfairness in the whole process,
rather than imply that I thought there was a vires point missed by the Claimant. But my comment cannot be
persuasive to me in the light of the judgment of the Court of Appeal, even were its decision not strictly
binding on me.

39. The fact that the FTR may have operated fairly at times, or that many appeal decisions may have been
reached fairly under them, does not mean that the FTR were not nullities on the reasoning of the Court of
Appeal. Indeed, on the Court of Appeal's decision, though the FTR operated unfairly in “a significant
number of cases”, sufficient to make them ultra vires, a conclusion which needed no greater precision on


-----

[2017] EWHC 59 (Admin)

the proportion of appeals in which the FTR operated unfairly, the majority of appeals determined under
them may have been determined fairly.

40.  Accordingly, I have concluded that the FTR 2005 were ultra vires.

41. I should add that I have read the relevant parts of the judgment of HHJ Anthony Thornton QC, sitting
as a High Court Judge, in R(Hameed and Jabeen) v SSHD _[2016] EWHC 1579 (Admin), but without being_
persuaded in the circumstances that I should follow it unless satisfied it was wrong. I thought I should
reach my own conclusions on the issues, on the rather fuller arguments that I heard.

**Should a declaration be made to that effect?**

42. Ms Lieven submitted that, if I reached the conclusion which I have, a declaration should be granted to
the effect that the FTR 2005 were ultra vires. The two cases had been selected as lead cases, and the FtT
needed a decision to begin the process of deciding how to handle the many applications before it. There
was no basis for a time objection, because the lawfulness of the FTR could be considered in a challenge to
any executive decision which relied on the outcome of an appeal reached under the FTR 2005, whether a
decision on a fresh claim or on detention. It did not matter that a claimant was out of time to challenge the
original appeal.

43. In any event, time could and should be extended, since these two cases had been selected to enable
a decision on vires to be reached for the benefit of all other cases raising the same point, some of which
would be in time; the rights at issue required the highest standards of fairness; individuals faced systemic
difficulties in dealing with cases in the FTR, and hence in challenging the vires of the FTR; an NGO had
brought the challenge to the FTR 2014.

44. Mr Tam contended that, even if the FTR 2005 operated unfairly at times, I should not declare them to
be ultra vires, because the Claimants were out of time to challenge them, a blanket decision would be
inappropriate as the Rules no longer operated, and a significant number of individuals will have had their
appeals heard fairly. A targeted approach would meet the circumstances of the individual case, as I had
thought in DA1 was the appropriate way of dealing with the variable effects in individual cases of systemic
unfairness in the operation of the detained fast track system.

45. A declaration that the FTR 2005 were ultra vires would undermine the public interest in finality in
litigation, or at least it would do so if the consequences were as Ms Lieven contended. Claimants would be
able to treat their individual adverse decisions over the whole period of operation of the FTR 2005 as
nullities. These challenges were in reality collateral challenges to decisions which the Claimants could
have challenged at the time on the very grounds upon which they challenge them now. Even decisions
reached fairly under the FTR 2005 and about which no complaint had been made, and decisions
favourable to the individual, would all be nullities. Over 10000 decisions would be affected.

46. In my judgment, Mr Tam's arguments about granting a declaration that the FTR 2005 were ultra vires
stem from a concern about the consequences of such a declaration, at least as contended for by Ms
Lieven. She in turn endeavoured to soften the logic of her arguments, realistically recognising the pointless
problems which they could create in the fullness of their logic. But the real question to my mind is whether
the refusal of a declaration would alter the consequences of a conclusion that the FTR 2005 were ultra
vires, a conclusion now stated but not yet formally declared.

47. The difference between holding that the FTR 2005 were ultra vires for the purposes of then
considering the lawfulness of the appeal decisions, and the consequences if those decisions were held
unlawful, and granting a declaration that the FTR 2005 were ultra vires, is no more than formal. Obviously,
it enables an appeal to be brought against the Order so declaring. It binds the parties, and as a declaration
of public law, it would be applicable to all affected. But I cannot see that the consequences of my holding
the FTR to be ultra vires, but not declaring them to be ultra vires, would be any different in terms of the way
applicants could exploit it, or in terms of the FtT's reaction, or in the problems which it might create for
dealing with those who had had adverse appeal decisions years ago but only now challenged them. Such
a declaration sa s nothing of conseq ences an more than does m holding the FTR to be ltra ires


-----

[2017] EWHC 59 (Admin)

48. The decision of the Supreme Court in Ahmed v HM Treasury _[2010] UKSC 2 and 5, [2010] 2 AC 534_
at 690[5-8]  on whether to suspend a declaration that two terrorism asset freezing orders were invalid, and
quashing them, is also of some assistance. The declaration had been made; the issue was whether it
should be suspended until valid replacement orders could be made. Lord Phillips said that suspension
would not alter the position in law but a stay, on a declaration that the Order was unlawful, would leave
doubt as to whether the Order was lawful meanwhile, and so conflict with and muddle the clear decision
that it was not lawful. That is not the exactly the same problem as here, since I am being asked not to
make a declaration at all. But what Lord Phillips said is also apposite in this case. A holding that the FTR
2005 were ultra vires, yet a refusal so to declare, would lead to uncertainty as to the status of that holding
for other cases, and whether I had intended different consequences to flow, as a result. That would be a
very undesirable consequence of refusing to grant a declaration.

49. This is strongly reinforced by R(Hunt) v North Somerset Council _[2015] UKSC 51 at [12]: it will usually_
be appropriate, where a court finds that a public body has acted unlawfully to make a declaratory order to
reflect the court's findings.

50. The pragmatic considerations, that the FtT needs to know the position for the purposes of R32
applications, and that these two cases have been chosen as lead cases for the resolution of that issue,
also weigh against Mr Tam's submissions, although those considerations cannot force these two claims to
provide an answer to an issue which their proper resolution does not require. But it is inevitable that the
vires of the FTR have to be ruled on to resolve the arguments that the appeal decisions and subsequent
decisions are unlawful. Their vires, intra or ultra, cannot just be assumed.

51. I did not find Mr Tam's arguments about delay persuasive either, in the light, I emphasise, of the way in
which the procedures in these two cases developed. The issue now could only go to discretion anyway,
since permission has been granted in both cases, notwithstanding delay arguments at least in TN. And it
would have to be a very powerful point to prevent relief being granted in respect of what, after full
argument, has been found to be an unlawful act.

52. **TN's appeal against the refusal of her asylum claim was dismissed on 22 August 2014. Removal**
Directions were set for December 2014 either in September or November 2014. Judicial Review
proceedings were commenced against the removal decisions on 9 December 2014, and were refused
permission on 23 June 2015, and thus concluded. Further Removal directions were set, and further
representations were submitted, leading to adverse decisions on 20 August 2015. These proceedings were
begun on 20 August 2015, challenging those two decisions. Permission was refused on paper and the
claim marked as totally without merit on 7 October 2015. A further adverse decision responding to further
representations was sent on about 13 October. Although this decision was not formally challenged, the
related removal decision had been challenged, and the 13 October letter had been seen as simply
maintaining the earlier stance.

53. The challenge was not a direct challenge to the vires of the FTR 2005, or to the appeal decision itself.
The FTR 2005 vires issue arose because the later decisions, it was said, took into account that earlier
appeal decision, made under what were said to be ultra vires FTRs. The issues raised by the grounds of
challenge to the decisions, however, as distilled by Underhill LJ granting a stay on removal on 6
November 2015, included that the 2005 FTR were systemically unfair and therefore ultra vires for the
same reasons that the 2014 FTR were ultra vires; the adverse decision on the asylum appeal was liable to
be set aside, and so it could not be relied on as justifying the later decisions as they were infected by the
unfairness of the original Fast Track appeal decision. Underhill LJ commented that setting aside an appeal
decision appeared to be for the FtT. The SSHD argued before him, unsuccessfully, that permission should
be refused on the grounds that the challenge to the asylum appeal decision was out of time. Accordingly,
part of TN's argument which now has to be considered, is that the later decisions are unlawful because the
appeal decision was of no effect, because the FTR 2005 were ultra vires. Although she was out of time to
bring a direct challenge to the FTR 2005 and the appeal decision under it, as I read his decisions, Underhill
LJ formulated and then permitted the claim as including a direct challenge to both the FTR and the appeal


-----

[2017] EWHC 59 (Admin)

decision, as well as to the later decisions both on the grounds of the invalidity of the appeal decision and
on the straightforward application of the test in WM (DRC) v SSHD _[2006] EWCA Civ 1495._

54. US brought his proceedings initially in UTIAC on 15 July 2014, challenging refusals by the SSHD to
accept further representations as amounting to a fresh claim. He was well within time. His appeal had
been dismissed on 29 May, and permission to appeal refused by UTIAC on 12 June 2014. Permission in
the judicial review proceedings was refused by UTIAC on paper on 12 May 2015 and, on oral renewal on
16 September 2015, the claim was adjourned and transferred to the Administrative Court, as it included a
claim for wrongful detention. On 9 December 2015, he made an application to the FtT to have his appeal
decision set aside on the grounds that the 2005 FTR were ultra vires.

55. On 16 February 2016 Lang J granted permission to amend the grounds, and by implication to amend
the claim form, joining the Lord Chancellor as Second Defendant. Cranston J granted permission to bring
the amended proceedings on 10 June 2016, (omitted from the order) linking US and TN as lead cases on
the issue relating to the vires of the 2005 FTR. It is not clear to what extent any delay issues were raised
before Lang J or Cranston J; the amendments were permitted well after the expiry of the three months from
the adverse appeal decision. Mr Tam said that the challenge to the vires of the FTR was out of time; it was
not brought until 19 months after the appeal decision, when the grounds of challenge were amended. The
July 2014 proceedings, issued in the Upper Tribunal did not and could not challenge the vires of the FTR
2005.

56. The permitted amended grounds challenge the 2005 FTR on the grounds that they were ultra vires,
that the FtT decision of 19 May 2014 and all subsequent SSHD decision on further representations were
therefore unlawful, that his case should not have been considered in the detained fast track process at all,
and that, in any event, all the subsequent SSHD decisions refusing to treat further representations as fresh
claims were unlawful, (23 June, 10 and 14 July, 8 August, 5 September 2014 and 29 November 2015),
both because of their dependence on the unlawful appeal decision and in any event because they should
at least have been recognised as fresh claims, even if refused.

57. The two procedural histories do not make a case for refusing the declaration in the exercise of my
discretion. One way or another, the procedural decisions and interpretation of the grounds, enabled the
challenges to raise, with permission, the lawfulness of the adverse appeal and subsequent decisions, on
the basis that the FTR were ultra vires. That issue has to be resolved, and in my judgment, its resolution
has to be declared in a declaration that the FTR 2005 were ultra vires. That is not to say that in other cases
no delay argument could arise or should fail, but I deal with those issues later.

58. The Lord Chancellor, through Ms Anderson, supported the submissions of Mr Tam. She submitted that
a declaration was not to be granted as a matter of convenience for other decision makers, but only if
necessary for the instant cases. No declaration was necessary because the claimants did not need such a
declaration in order to advance their arguments about the lawfulness of subsequent decisions. A
declaration would simply undermine ten years of judicial decision-making to no useful purpose. I do not
accept that for the reasons above. I appreciate that there may well have been an ill-considered scatter gun
approach to the vires issue in a number of cases before bodies lacking jurisdiction to deal with it, but that
has been sorted out by the various directions in these cases. On the issues thus far, no greater separate
consideration of her submissions is necessary. She also developed thoughtful submissions about the
consequences of a declaration for past appeal decisions and on the continued role of time limits and
discretion, issues which I cover in the next section.

59.  She also contended that the Lord Chancellor should be an Interested Party rather than Second
Defendant, on the grounds that the proceedings were not really against the Lord Chancellor as maker of
the FTR. But that depended on how the proceedings were viewed. I am satisfied that, in these lead cases,
whether the vires of the FTR has been raised directly or indirectly, the Lord Chancellor is an appropriate
defendant, though it would not be normal for her to be joined as defendant rather than as an interested
party, if merely involved indirectly.

60 So I shall declare that the FTR 2005 were ultra vires


-----

[2017] EWHC 59 (Admin)

**The consequences of the declaration**

61. This has an immediate relevance to the two cases, because on Ms Lieven's analysis, the appeal has
not been the subject of a lawful determination, the adverse decision is a nullity, and it only remains for me
to so hold, or for the FtT to set it aside under R32. The subsequent decisions have no effect because they
assume that the appeal has been decided, whether or not they actually drew upon the decision. In any
event, the adverse appeal decisions, reached under an unlawful process, cannot be relied on to support
the subsequent decisions on fresh claims or detention.

62. The first stage in Ms Lieven's submissions is that the declaration that the FTR were ultra vires means
that they were a nullity and of no effect. She cited a number of authorities for this proposition, but that was
not really where the issue was joined. Mr Tam's submissions were more directed to whether the
consequence of the FTR being declared a nullity meant that the appeal decisions were also nullities,
awaiting merely the inevitable Court ruling that they were or a FtT decision setting them aside as was
bound to follow.

63. I consider that this first stage in Ms Lieven's submissions is readily made out.  Hoffman La Roche v
_SSTI [1975] AC 295 at 365,_ _DPP v Hutchinson [1990] 2AC 783 at 819,_ _Boddington v British Transport_
_Police [1999] 2 AC 143 at 155-8, and Lumba v SSHD [2012] 1 AC 245 at [66] all bear it out. I need only_
cite briefly from _Boddington. The defendant was entitled to raise the invalidity of byelaws, made many_
years before, for breach of which he was prosecuted, or the invalidity of an act taken pursuant to them, as
a defence to his prosecution. At p155C, Lord Irvine pointed out that “...the true effect of the presumption

[that subordinate legislation or an administrative act] is lawful is that the legislation or act which is
impugned is presumed to be good until pronounced to be unlawful, but is then recognised as never having
had any legal effect at all.” He cited Lord Diplock in Hoffmann La Roche to the like effect. Later he said,
p158E: “An ultra vires act or subordinate legislation is unlawful simpliciter and, if the presumption in favour
of its legality is overcome by a litigant before a court of competent jurisdiction, is of no legal effect
whatsoever.”

64. The second stage of Ms Lieven's submissions is that the nullity of the FTR from the start, nullifies all
decisions made under them, or at least does so when an application is made to challenge the decisions, or
any subsequent dependant decisions. She relied on the same authorities as she did for the first stage of
her argument.

65. This is where the contest is really joined. Mr Tam submits that it simply does not follow, because the
FTR were a nullity, that all appeal decisions made under them are also nullities, or that all decisions which
flowed from the appeal decisions are in turn equally nullities.

66. Mr Tam submitted first that the appeal decisions were not automatically nullified by the declaration that
the FTR were ultra vires. The appeal decisions remained in force as decisions of a tribunal exercising a
jurisdiction conferred on it by law. They remain in force until set aside or quashed by a court or Tribunal
with the necessary powers. But the provisions of CPR Part 54, and the time limits for bringing judicial
review proceedings, together with the discretionary nature of the remedy, meant that appeal decisions
were not automatically to be quashed. Similarly, the FtT's approach to R32 in relation to appeals
determined under the FTR 2014, without consideration of the fairness of the appeal decision in individual
cases or seemingly of the lapse of time since the decision, may be inapplicable to appeals decided under
the FTR 2005, and may be challenged if applied. The time limits and the interests of justice might not point
to the same approach as adopted in relation to the 2014 FTR appeals. There was nothing inevitable or
automatic about the effect of the declaration that the FTR were ultra vires on the appeal decisions.

67.  Second, the appeals were heard by impartial judges, exercising a jurisdiction conferred on them. The
Court should not quash an appeal decision, nor should it be set aside in the interests of justice, without
consideration of whether there had been actual unfairness in the decision, including an analysis of what
might have been achieved in a more relaxed timetable, and whether or not adjournment or transfer out was
sought, and on what basis it was refused.


-----

[2017] EWHC 59 (Admin)

68. Third, the judicial review time limits should prevent a challenge to a fresh claim decision becoming a
collateral challenge to an earlier appeal decision, if that decision could no longer be challenged directly. It
did not matter for these purposes that the FTR had not been declared a nullity earlier, or that they had now
been declared a nullity. More than 10000 appeals had been decided under the FTR 2005. The litigation
following the decision in DA6 included former appellants seeking orders requiring their return to the UK for
the re-determination of their appeals. There would be no logical reason why appeal decisions favourable
to the appellant should not be set aside if an application was all that stood between the decision and its
nullification. The redetermination of 10000 appeals, which could have raised the question of the lawfulness
of the FTR and of the adverse appeal decisions, but did not, would have very serious practical
consequences for public administration and the administration of justice.

69. Ms Lieven suggested that the picture of 10000 appeal decisions being set aside was unrealistic. The
decisions would not automatically be set aside; an application would be required. The SSHD would not
seek to set aside those she had lost. Those who had been removed would not necessarily apply to the FtT
to have their appeal decisions set aside, and could be dealt with by an out of country appeal. Ms Lieven
also relied on the experience, thus far, of the effect of the nullification of the 2014 FTR, and the FtT's
approach to appeal decisions made under them. 312 applications had been granted in respect of 873
appeals heard. I think that all 2014 FTR applications dealt with by the FtT have been granted, and there
appears to be no time limit on them being made. 59 applications have so far been made under R32 in
relation to appeals under the 2005 FTR. In fact, some have already applied to return to the UK for the
purposes of their now unresolved appeals. And of course, Ms Lieven cannot offer reassurance on behalf
of those for whom she does not act.

70. But Mr Tam's pragmatic considerations and Ms Lieven's riposte, while pointing to the problem, do not
answer the real questions. These are: (1) does the nullification of the FTR 2005 automatically and without
the need for an application to a court of competent jurisdiction, nullify the appeal decision? The answer to
that, in my judgment, is no. (2) Is the court of competent jurisdiction obliged to quash or set aside the
appeal decision on an application being made to it? The answer to that, in my judgment, is also no. That
gives rise to three further questions. (3) To which body, FtT or Administrative Court, should the application
be made? (4) What approach should it adopt to the grant or refusal of such an application? (5) What is the
effect of quashing or setting aside of the appeal decision on subsequent decisions, or of not doing so? I
take these five issues in turn.

71. Issue 1: is an application necessary? It was not really disputed by Ms Lieven and indeed at times
she positively urged, at least as argument developed, that an application of some sort to quash or to set
the appeal decision aside would be required. That is correct. They are good and in force until set aside or
quashed. The procedural errors are not such as to mean that the decisions are so obviously of no effect
that no application is required. Both parties may have acted on them. Either party may be content with the
outcome and not wish to find that their personal circumstances are upset. If an appeal decision were
automatically nullified, it would be automatically nullified regardless of its outcome. The declaration does
not nullify all appeal decisions. The consequences of the invalidity of the FTR 2005 are not that no
decisions have been made, and must henceforth be treated as never having been made; Ms Lieven cannot
escape the consequence if that is right that allowed appeals are also nullities, and nullities too for those
who have left the UK. No jurisprudence supports such a consequence.

72. Issue 2: is the court obliged to set the appeal decision aside or to quash it on the appropriate
**application being made? I do not accept Ms Lieven's general proposition, supported by Ms Harrison QC**
for TN, that the effect of the 2005 FTR being a nullity means that all appeal decisions made under them
were made without jurisdiction or are inevitably unfair, and merely await an application to quash them or to
set them aside. In my judgment, the effect of the nullification of the FTR on the FtT's jurisdiction to
determine the appeal decisions depends on the construction of the 2002 Act and the role of the Rules. If
they were made by a Tribunal with jurisdiction and were not all inevitably unfair, the granting of the
application has to depend on a judgment as to whether the appeal decision in fact was fair or unfair, with


-----

[2017] EWHC 59 (Admin)

whatever approach to that is required, and not on the remorseless logic of some jurisprudential theory
erasing all that was touched by the nullified Rules. I take jurisdiction first.

73. The principal jurisdiction to entertain appeals from decisions of the SSHD is given to the Tribunal, now
FtT, by s82(1) of the Nationality, Immigration and Asylum Act 2002, and amendments. It says simply that:
“Where an immigration decision is made in respect of a person he may appeal to the Tribunal.” S83 is in
like vein. S85 deals with the issues to be decided. The obligations on the Tribunal are set out in s86(2),
which, by s82(1), is expressed to apply on an appeal. The Tribunal “must determine” any matter raised as
a ground of appeal, and any matter which s85 requires him to consider. S86(3) provides for when he must
allow the appeal, and by s86(5), he must otherwise dismiss the appeal.

74. The rule-making power is separate. There is no suggestion in the Act or the later rule-making powers
that the existence of Rules is a precondition to the lawful exercise of the jurisdiction or that the Rules are
required to create the jurisdiction. S106 of the 2002 Act contained the original rule-making power; it simply
said: “The Lord Chancellor may make rules-(a) regulating the exercise of the right of appeal…. (b)
prescribing procedure to be followed in connection with proceedings….” S112 contains nothing material to
this issue. Nothing in s22 of the 2007 Act, under which the 2005 FTR were deemed to have been made,
gives any different impression. There are to be Rules “governing- (a) the practice and procedure to be
followed in the First-tier Tribunal….” The only power which the Rules might be seen as themselves
conferring or as necessary precursors for is the power to confer by rules responsibility on members for
ensuring that proceedings are handled quickly and efficiently.

75. In my judgment, the tribunal judges had jurisdiction to hear the appeals and to reach decisions on
them. If there had been no FTR, the fast track decisions of the FtT would not have been inevitable nullities;
the FTR did not confer jurisdiction. I do not accept Ms Lieven's argument that the Rules were in some way
so bound up with the power to decide appeals that all appeals purportedly made under the 2005 FTR were
made without jurisdiction.

76. It may be that the 2005 Asylum and Immigration Tribunal (Procedure) Rules, the 2005 Principal Rules,
should have been applied instead to detained fast track appeals, and plainly they were not. But if those
Rules applied but were not followed, as would have always been the case, there would have been
breaches of the Rules, procedural irregularities, but no necessary nullification of the appeal decisions for
want of jurisdiction.

77. There have been gaps in the provision of procedural rules for various statutory procedures which offer
some analogous support to my view that their absence does not deprive the statutory body of the power to
decide the issues within its jurisdiction. The Highways Act 1959 set out the procedure for making schemes
for new motorways. Its Schedule obliged the minister to cause a local inquiry to be held if objections were
not withdrawn. After considering the report of the person holding the inquiry, the order could be made. For
many years there were no Highways (Inquiries Procedure) Rules. Other statutory inquiry rules were
applied by analogy. This is part of the background to _Bushell v Secretary of State for the Environment_

[1981] AC 75, p93B-C and 94H -95B. The procedures were therefore left to the discretion of the minister
or person holding the inquiry. Of course, the analogy between that sort of inquiry and an appeal against an
immigration decision is limited, but the question of jurisdiction in the absence of the Rules is much closer.
Jurisdiction was never doubted in _Bushell in the House of Lords, although the absence of rules was a_
frequent matter of controversy at such inquiries.

78. Ms Harrison referred me to R(Ignaoua) v SSHD _[2013] EWCA Civ 1498, [2014] 1WLR 65. In that case_
it was common ground that new SIAC Rules were necessary in order for it to apply closed material
procedures to a challenge to an exclusion direction which had been proceeding by judicial review,
proceedings which the SSHD, wishing to “switch” them to SIAC, purported to use her powers to terminate.
The issue was whether the SSHD had power to terminate judicial review proceedings, at least before they
could proceed in SIAC.  The effect of the absence of procedural rules, in relation to closed material
procedures, appears to have been dealt with as a matter of the practical effect on the ability of SIAC to


-----

[2017] EWHC 59 (Admin)

make progress with the alternative route for a challenge to the direction, rather than as a matter of
jurisdiction. I did not find it advanced the issues much.

79. Mulvenna and Smith v Secretary of State for Communities and Local Government [2015] EWHC 3934
(Admin), Cranston J is of assistance on this aspect, although the context is quite different. The Secretary of
State had exercised his powers to recover for his own decision various traveller appeals relating to the
development of caravan sites in the Green Belt; this had been held to be unlawful on race discrimination
grounds. But the decisions he reached on the appeals themselves stood, as he still had jurisdiction to
determine them. He had not parted with jurisdiction when originally permitting Inspectors to reach the
decision, and remained a lawful decision maker, despite his unlawful recovery decision. This turned on the
statutory scheme; appeals are always appeals to the Secretary of State and his determination of the
appeals was a return, [74], to the “primary statutory locus for the determination of such appeals.” Here, the
FtT is the sole statutory locus for the determination of appeals, and does not occupy that place by virtue of
Rules.

80. Nor can it be said that because the FTR 2005 were nullities, the appeal decisions would have been
inevitably unfair. Their quashing would depend on whether they were unfair in fact, and their setting aside
would depend on whether that was in the interests of justice, an essentially similar test for these purposes.
The possibility that the Principal Rules ought to have been applied instead, but were not, creates
procedural irregularity but no necessary unfairness. The other possibility is that the Tribunal Judge ought
simply to have applied what procedure, and timetable, seemed to him fair in the circumstances, taking
account of the difficulties analysed by the Court of Appeal.  Again the same question arises: was the
appeal decision fair or not? Do the interests of justice require it to be set aside?

81. I disagree with Ms Lieven's submission that the Court of Appeal held that the 2014 FTR created an
unfair process for anyone and everyone; and I also disagree with Ms Harrison's formulation that the Court
of Appeal, having found that the FTR 2014 were “structurally unfair”, found or meant that the fairness of an
individual appeal was irrelevant to its consequential nullity.

82. I emphasise that the Court of Appeal did not hold that all fast track appeals were unfair. It held that a
significant number or proportion were. It did not decide whether that was a majority or not; it did not need to
do so. The “significant number” for the Court of Appeal was whether it was sufficient to make the FTR
2014 ultra vires. Whether the Court thought that that was in fact a large proportion or not, it would not have
taken many unfair appeals occasioned by the provisions of the Rules for them to be ultra vires, since it is
difficult to envisage lawful Rules which provide, systemically, for unfair appeals even on a handful of
occasions.

83. The statutory appeal process from the FtT enabled the unfairness of the procedure before it to be
raised before UTIAC, or on onward appeal to the Court of Appeal or by way of challenge under CPR
54.7A. It either was not pursued, or was pursued unsuccessfully. Either way, that is a further reason why
the appeal decision is not automatically to be set aside or quashed on the appropriate application being
made. Moreover, as I shall come to later, if an application is required, to be successful it must satisfy the
time limits, procedural rules and discretionary powers which govern it. These are important considerations
which I elaborate under issues 3 and 4.

84. This general position is supported by a number of authorities. Mulvenna, above, in paragraphs 64-71,
contains a helpful discussion by Cranston J of the principles involved where one act is a nullity, the making
of the 2005 FTR, and it is the consequence for related acts which is at issue. He referred to what Lord
Steyn had said at [172] in Boddington:

“I accept the reality that an unlawful byelaw is a fact and that it may in certain circumstances have legal
consequences. The best explanation that I have seen is by Dr Forsyth who summarised the position as
follows in 'The Metaphysics of Nullity, Invalidity, Conceptual Reasoning and the Rule of Law', [in C. Forsyth
_& C. Hare, The Golden Metwand and the Crooked Cord: Essays on Public Law in Honour of Sir William_
_Wade (1998)] at p.159:_


-----

[2017] EWHC 59 (Admin)

“It has been argued that unlawful administrative acts are void in law. But they clearly exist in fact and they
often appear to be valid. When this happens the validity of these later acts depends upon the legal powers
of the second actor. The crucial issue to be determined is whether that second actor has legal power to act
validly notwithstanding the invalidity of the first act. And it is determined by an analysis of the law against
the background of the familiar proposition that an unlawful act is void.'”

85. Cranston J continued at [68-71]:

“68. In light of these authorities, the law appears to be this. Unlawful administrative acts are a nullity, but
they are presumed to be valid until the court rules otherwise. Once the court declares them to unlawful it is
confirming that they have been unlawful from the outset, in other words, that they are void, not voidable.
There is the practical problem, that parties may have taken subsequent action assuming these unlawful
acts to be valid. If they are a nullity, subsequent acts taken on the strength of them are also a nullity. The
result might be administrative chaos or even political crisis if a myriad of subsequent acts are void.

69. To avoid the domino effect that all subsequent acts are also a nullity, various solutions have been
posited. One is that in some cases judicial rulings should be given prospective force only. That approach
did not attract the support of the House of Lords in R v Governor of Brockhill Prison Ex p. Evans (no. 2)

_[2001] 2 A.C.19. A second favoured by Professor Paul Craig (Administrative Law, 7th edn (2011)), para._
24-22, is that the court in its discretion may withhold a quashing remedy. Yet there is high authority that,
generally speaking, a party succeeding in a judicial review will be entitled to relief.

70. Thirdly, there is Professor Forsyth's conceptual approach, the theory of the second actor, approved by
Lord Steyn in Boddington. Under this, despite the original act being a nullity, the second actor may have
the power to confer validity on a subsequent act. _R v Wicks is invoked as an example. The theory is_
summarised in a passage earlier in the article, and set out by Lang J in AAM (A Child) v Secretary of State
_for the Home Department [2012] EWHC 2567 (QB) at [104]:_

“[At p.149] In such cases the invalidity of the first act does involve the unravelling of later acts which rely on
the first act's validity. However, the voidness of the first act does not determine whether the second act is
valid. That depends upon the legal powers of the later actor. If the validity of the first act is a jurisdictional
requirement for the valid exercise of the second actor's powers, then, if the first act is invalid, so is the
second. Sometimes it will not be- the tax demand did not need to be valid for the money to be validly paidand sometimes it will be- a valid tax demand could not be made unless the regulations had been properly
made.”

71. In practice, it seems to me that the courts will adopt a combination of techniques, as Professor Mark
Elliot suggests in Beatson, Matthews and Elliot's Administrative Law, 4th edn, (2005), 101: the courts will
be guided by the language of the statutory scheme, its history and policy, but in the exercise of their
discretion will also take account of the consequences which would ensure if they concluded that a power
could only be exercised on the basis of a valid first act. Discretion in the granting of a public remedy may
enter the picture.”

86. None of the cases cited by Ms Lieven really address the issue of whether the absence of fast track
appeal rules makes appeal decisions following that timetable necessarily void at least on application to the
appropriate court. Mr Tam is right that those cases deal with the position where the nullity is in the very
provision which purported to confer the power or jurisdiction on the decision-maker or actor. Hoffman La
_Roche, above, at p365 holds that an ultra vires instrument is incapable of ever having an effect on the_
rights or duties of those it purported to regulate, but that is not the issue here. Boddington illustrates how
the invalidity of a byelaw can be raised as a defence to a prosecution based on it; its nullity prevents it
being relied on as the basis for prohibitory notices and prosecutions for non-compliance with them, but that
is not the issue here. The same applies to _Ahmed, above, and to the SSHD's policy for detention in_ _R_
_(Lumba) v SSHD_ _[2011] UKSC 12, [2012] 1 AC 245; indeed at [66], Lord Dyson pointed out that Anisminic_
_Ltd. v Foreign Compensation Commission [1969] 2 AC 147had held that there was but a single category of_
public law error which led to decision being nullities, so it mattered not whether the decision to detain was
in breach of a statute or of a rule of public law This may all be relevant to what happens if any particular


-----

[2017] EWHC 59 (Admin)

appeal decision is held to be a nullity, but does not bear on whether the consequence of the FTR 2005
being a nullity is that the appeal decisions themselves are all nullities, although made by the body which
had jurisdiction, and not one dependent on the existence of the FTRs.

87. I need to refer to two further cases, the import of which was at issue and much debated. Mr Tam
favoured _Percy v Hall [1997] QB 924a case cited in_ _Boddington and in_ _Lumba, without disapproval, and_
endorsed by the Court of Appeal in _R v Governor of Brockhill Prison ex parte Evans (No.2)_ [1999] QB
1043.  Byelaws were held invalid in the Divisional Court and criminal charges for breaching them were
dismissed. Civil proceedings were then brought by the successful defendants against the constables who
had arrested them for those offences, alleging wrongful arrest and false imprisonment. The Court of
Appeal held, on a preliminary issue, that whether the arrests were tortious had to be determined at the time
of the arrest; the byelaws were apparently and in law to be presumed valid and properly to be enforced.
The fact that they were later found to be invalid did not prevent the constables relying on the defence of
lawful justification, if they had acted in the reasonable belief that the people they arrested were committing
an offence against the byelaw. A declaration that the byelaws were invalid operated retrospectively so that
a person convicted of their breach was entitled to have their conviction set aside; but the declaration did
not transform what was at that time seen to be the lawful performance of a duty into actionably tortious
conduct; p947G-948B, Simon Brown LJ, with whom Peter Gibson LJ and Schiemann LJ agreed. The latter
cautioned, p951-2, against the adoption of a simple approach that all invalid acts were never capable of
having an effect on the rights or duties of parties, as needlessly restricting the possible range of answers
which policy, which I read in a broad legal sense, might require.  (The Court of Appeal, not bound by the
Divisional Court, also considered the issue of validity, and came to a different conclusion from the
Divisional Court.) Its judgment on the issue of lawful justification is obiter, but considered, and after full
argument. This supports Mr Tam's contentions.

88. Ms Lieven relied on _SSHD v Draga_ _[2012] EWCA Civ 842, a detention case arising out of a_
deportation order. Draga was a Kosovan refugee convicted of drug and other offences, and sentenced to
[18 months' imprisonment. An Order, by way of statutory instrument in 2004, made under the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
_[Immigration and Asylum Act 2002,specified certain offences as particularly serious for the purposes of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
deportation. Draga went through the statutory appeal process against the decision to make a deportation
order, including reconsideration, without success. Time for applying for permission to appeal to the Court of
Appeal expired in October 2007. This is an important feature of the case when trying to apply it here. He
applied out of time for permission to appeal to the Court of Appeal and for permission to amend his
grounds to allege that the decision was invalid because the 2004 Order, on which it was based, was itself
invalid. The Court of Appeal in 2008 refused the extension of time, saying that the point should have been
raised very long ago; it was a point which had attracted interested commentary. Nothing daunted, Draga
made further representations to the SSHD who treated them as an application for the revocation of the
deportation order, but rejected them. His judicial review proceedings challenging the refusal to revoke the
deportation order, based on the alleged nullity of the 2004 Order, were stayed to await the decision of the
Court of Appeal which in 2009, in other proceedings, held that the 2004 Order was ultra vires. Nonetheless
the SSHD still continued to refuse to revoke the deportation order, and Draga appealed successfully to the
FtT against that refusal. It was that successful appeal which disposed of the deportation order.

89. At issue in the detention claim, which was what was left of the judicial review, was whether the flawed
decision to make a deportation order, and then actually to make it, invalidated the decision to detain. Percy
_v Hall was among the cases cited. The SSHD argued that the preconditions to detention in paragraphs 2(2)_
and 2(3) of Schedule 3 to the 1971 Immigration Act, giving notice of the decision to make a deportation
order, and the making of the order, provided the necessary statutory authority for the decision to detain. At

[57] Sullivan LJ, with whom Kitchen LJ agreed, and Pill LJ very largely agreed, applying what Lord Dyson
said in Lumba [65-68, 86-88], said that the sole basis for both deportation decisions, which gave rise to the
exercise of detention powers, was the unlawful 2004 Order. “This error was sufficient to render those
decisions [on deportation] unlawful, but did it bear upon, and was it relevant to, the decision to detain under
paragraph 2(2) of Schedule 3?”


-----

[2017] EWHC 59 (Admin)

90. The simple answer, at first blush, that they did, paid insufficient attention to the statutory process, in
which a decision to make a deportation order could be appealed on grounds which included that it was not
in accordance with the law. The fact that an appeal was allowed would not mean necessarily that the
detention was unlawful.  It depended on the precise grounds: e.g. the decision on appeal that A was not a
person liable to deportation or that the decision was made in bad faith, was different from one where the
Tribunal differed from the SSHD in its appraisal of the proportionality of deportation. It was “difficult to
identify any principled basis for distinguishing between those public law errors which will render the
decision to detain unlawful and those which will not.” There was no statutory mechanism for challenging
the lawfulness of detention, but Parliament had established a comprehensive statutory scheme for
determining the lawfulness of a decision to make a deportation order.

91. Between [62 and 67], Sullivan LJ said this:

“ 62. The law, particularly in this field, is constantly evolving, as shown by the number of reported cases.
The fact that a decision by the Court of Appeal or the Supreme Court in a later case, perhaps many years
later, may, with the benefit of hindsight, make it clear that a Tribunal's decision in an earlier case to allow or
dismiss an appeal against a decision to make a deportation order was made on an erroneous legal basis is
not a ground for re-opening the earlier decision by the Tribunal. It would frustrate the operation of the
statutory scheme if the Secretary of State was not able to rely upon the Tribunal's decision, dismissing an
appeal, once time for applying for permission to appeal against the decision had expired, as a lawful basis
for making a deportation order.

63. In the present case, these judicial review proceedings were commenced in June 2008 and the law was
not clarified until the judgment in EN (Serbia) was handed down in June 2009, some 21 months after the
Tribunal's decision. If a Tribunal's decision is not to be treated as finally determining, as between the
parties to an appeal under section 82(1), the lawfulness of a decision to make a deportation order, there
can be no certainty as to whether there is lawful authority for detention under either paragraph 2(2) or 2(3)
of Schedule 3, because at any stage it might be decided in a subsequent case that the legal basis for
making the deportation order – the dismissal of the appeal against the decision to make the order – had
been flawed.

64. If a person subject to a deportation order has not been removed from the UK, a subsequent decision by
the Court of Appeal or the Supreme Court in another case which makes it clear that the Tribunal's decision
to dismiss his appeal against the decision to make the order was made on a flawed legal basis, would be a
proper ground for an application to the Secretary of State to revoke the order, and for appealing against a
decision to refuse to revoke the order, but it would not invalidate either the Tribunal's decision finally
determining the appeal, or the deportation order made in reliance upon that final determination.

65. The position may be tested by reference to the position of the person who is served with notice of a
deportation order, but who does not appeal against the decision under section 82(1). It would frustrate the
operation of the statutory scheme if the Secretary of State was not able to rely upon the fact that no appeal
had been brought within time against the decision to make the order as a lawful basis for proceeding to the
second stage of the process: the making the order itself. A subsequent decision by the Court of Appeal or
the Supreme Court which made it clear that the Secretary of State's decision to make the order had been
made on an erroneous legal basis could not affect the lawfulness of a decision against which there had
been no appeal. A person who appeals against a decision to make a deportation order and has his appeal
"finally determined" by a decision of the tribunal dismissing his appeal cannot be in any better position than
a person who does not appeal.

66. In the present case, Mr. Draga's appeal against the decision to make a deportation order against him
was finally determined when the time for applying for permission to appeal to the Court of Appeal expired
on 26th October 2007 (see paragraph 18 above). In my judgment, when making the deportation order the
following month the Secretary of State was entitled to rely upon the Tribunal's decision dismissing Mr.
Draga's appeal as a final determination that the decision in 2006 to make a deportation order against Mr.
Draga was a lawful decision. It follows that the Secretary of State is entitled to rely on the lawfulness (as


-----

[2017] EWHC 59 (Admin)

determined by the tribunal) of the decision to make a deportation order as lawful authority both for Mr.
Draga's detention under paragraph 2(2) of Schedule 3 from 2nd August 2006 to 27th March 2007, and for
his re-detention under paragraph 2(3) of Schedule 3 when the deportation order was served upon him on
30th November 2007.

67. The fact that there was an out-of-time application for permission to appeal to the Court of Appeal which
was refused does not affect this analysis. Mr. Draga's appeal against the decision to make a deportation
order against him was finally determined in October 2007, prior to the making of the order. The fact that the
Court of Appeal refused Mr. Draga's application for an extension of time only serves to reinforce the
proposition that there is a need for the statutory scheme to provide certainty as to whether or not there is
lawful authority for detention. If the Secretary of State is unable to rely upon a Tribunal's decision in a case
where the Court of Appeal has refused an application for permission to appeal out of time against that
decision, it is difficult to see how there could ever be any firm basis for a decision to detain under
paragraph 2(2) or (3) of Schedule 3.”

92. He then turned to the position after the 2004 Order had been declared ultra vires, in 2009. The SSHD
had tried, on what the Court of Appeal treated as 1 January 2010, to rely on the cessation provisions to say
that Draga was no longer a refugee. But in September 2010, that argument was rejected by the FtT as a
mere device to deport Draga. Detention was unlawful from the moment the SSHD tried to rely on the
cessation device until Draga's release.

93. Pill LJ added that the SSHD would have a reasonable time after the decision declaring the 2004 Order
ultra vires in which to review detention, to consider the application to revoke the deportation order, and to
reassess the situation. He also said, [82], that the fact that the same actor, the SSHD, made both the 2004
Order and took the deportation decisions, did not alter the position; there was also a separate decision to
make the 2004 Order and then to make a deportation order in reliance on it.

94. Mr Tam submitted that this case in fact assisted him and not Ms Lieven. I agree. It shows, like Percy v
_Hall, that the nullification of one executive act or order does not make all related or dependant acts_
nullities. The nullifying of the unlawful 2004 Order did not undo the decision of the Tribunal in 2007; it did
not of itself nullify the later refusal of revocation, nor the detention decisions.

95. I am satisfied that the declaration that the 2005 FTR were ultra vires does not make necessarily make
any, let alone all, of the decisions purportedly made under them ultra vires. Accordingly, decisions which
were made by a Tribunal with jurisdiction, and which were not necessarily unfair require more than the fact
of the declaration which I have made to warrant their being set aside or quashed.

96. Issue 3: which body should rule on whether an individual appeal decision should be set aside
**or held invalid? There are only two candidates: the FtT and the Administrative Court. First, the function of**
setting aside Tribunal decisions from which no appeal route remains available rests with the FtT, not least
because the power to do so is expressly conferred on it, and not on the Administrative Court. Such a power
is the part of the statutory appeal process vested in the FtT and UTIAC. The Administrative Court has a
particular but limited role in the appellate process via CPR 54.7A, in its ability to hold that a refusal of
permission to appeal by UTIAC should be overturned on second appeal grounds. But once the appeal
process is concluded, the only way in which the appeal decision can be set aside is through application to
the FtT under R32. If an appellant, whose appeal rights were exhausted, however far he or she had been
able to take it, sought to challenge the lawfulness of the appeal decision by way of judicial review, they
would be refused permission. Finality in litigation and alternative remedy under R32 would be to the fore in
the reasons why.

97. Of course, I accept that the FtT has no jurisdiction to decide whether the FTR 2005 were unlawful. I
also accept that the Administrative Court is at least the most appropriate Court to decide whether the effect
of nullification is that the appeal decisions were made without jurisdiction. But in principle, once those
decisions have been made by the Administrative Court as they now have been, that Court should not
entertain a direct judicial review challenge to the lawfulness of the appeal decision itself any more than it
would do so in relation to any other judicial review challenge to the lawfulness of an appeal decision The


-----

[2017] EWHC 59 (Admin)

fairness or procedural irregularity in any FtT decision, other than a challenge to the vires of the FTR, could
be raised on an appeal to UTIAC. An unappealed FtT decision, an unchallenged UTIAC appeal decision, a
UTIAC decision refusing permission to appeal terminates the appeal process, and a High Court refusal of
permission under CPR 54.7A to challenge that refusal all end the appeal rights. The appeal decision
stands as lawful, subject to set aside under R32. I see all this as entirely in line with Draga.

98. If the timescale for an application to set aside under R32 is not met and time is not extended under
R4(3), or if the President does not make an order of his own motion, that is simply the consequence of the
application of lawful Rules. The refusal of an application to set the appeal decision aside cannot prise or
leave open the door to a judicial review challenge to that same appeal decision nor do so when the appeal
decision is relied on later by the SSHD in response to further representations. Still less could that happen
in the absence of such an application.

99. It would be wholly inconsistent with the statutory appeals scheme for the Administrative Court itself to
decide that an appeal decision, which has not been set aside, is nonetheless unlawful for the purposes of
considering the lawfulness of subsequent decisions which relied on the appeal decision. The FtT does not
lose its jurisdiction to set the appeal decision aside, even though subsequent decisions had been made in
reliance on it. That might affect its willingness to do so, since the making of a fresh claim by the
unsuccessful appellant itself assumes that the appeal has been validly and finally determined. The FtT time
limits might not permit it either, but I cannot see that as a good reason for the Administrative Court to step
in. Rather, applications for judicial review should not be used to circumvent the time limits and procedures
applicable to the primary remedy. Yet, the indirect but nonetheless real challenge to the appeal decisions
in these cases would be inviting the Administrative Court to do what the FtT has not done.

100. There seems to me to be no real argument as to convenience either, even though the FtT itself has
no judicial review jurisdiction, and so could not cover the fresh claims point directly, whatever
arrangements might be made for UTIAC to exercise its jurisdiction in some concurrent form.

101.  “Never” is not a sound rule in this area, so I would not hold that the Administrative Court has no
jurisdiction to hold that an appeal decision was unlawful as the crucial but indirect attack within a challenge
to subsequent dependent decisions. But it would require very good reason to permit the challenge, if no
successful application had been made to the FtT for the decision to be set aside. I cannot think of one. The
convenience of running such a challenge in tandem with a challenge to later SSHD decisions is no such
reason. It simply invites the evasion of the proper remedy, time limits and discretion. The route to challenge
an appeal decision outside the statutory framework could not be confined to the sort of grounds deployed
here.  A refusal by the FtT to set the appeal decision aside would not constitute a good reason. It is not
for the Administrative Court to exercise the jurisdiction of the FtT. A remedy in the Administrative Court
should not be pursued if an alternative remedy is available, and either fails or is unused.  I see no reason
why the FtT's power is not an adequate remedy, even if it does not lead to the answer desired by the
applicant.

102. Postscript: Mr Tam, in suggesting corrections to the draft judgment, submitted that neither he nor Ms
Anderson had made positive submissions one way or the other about whether the FtT did have jurisdiction
to set aside appeals reached under the 2005 FTR. Instead, they had left the position open. I however had
understood that its jurisdiction was accepted, with the issue being whether the approach adopted by the
FtT to the setting aside of appeals under the 2014 FTR could properly be applied to appeals reached under
the 2005 FTR. That would leave the time limits and so on to be debated. Be that as it may, I do not
consider it appropriate to hear argument about whether the FtT does or does not have jurisdiction, and if
not, the consequences, if any, for the view I have formed about the role of judicial review intruding into the
appeal process, and the limitations which apply to judicial review challenges. Clearly though the FtT could
not afford an alternative remedy if it had no jurisdiction to grant a remedy, however constrained.

103. **Issue 4: what is the correct approach to an application to set aside or to quash an appeal**
**decision? It is not my task to tell the FtT or UTIAC how it should handle applications under R32 to set**
aside appeal decisions made under the FTR 2005 in the light of my decision that the FTR 2005 are ultra


-----

[2017] EWHC 59 (Admin)

vires but that the appeal decisions are not inevitably nullities. Procedural irregularity for the purposes of
R32 might readily be established, and the more so if the 2005 Principal Rules ought to have been applied,
with their different timetable. It will be for the FtT to decide what “the interests of justice” require, and in
particular whether the “interests of justice” can be met without consideration of the impact of the FTR
timetable or procedural irregularity on the fairness of the appeal in each individual case. The FtT may or
may not adopt the same approach as it has over the 2014 FTR, with whatever consequences that may
have. If it does repeat the approach it took in relation to 2014 FTR appeals, it will be for the SSHD to take
issue with that under the Tribunal appeal procedure.

104. The FtT may have to consider the soundness of a possible applicant's argument that he could not
have known of the vires point until after DA6. However, in the light of the nine years' operation of the 2005
FTR, the fact that it was not something peculiar to the 2014 FTR which led to the DA6 challenge, and
someone has to raise a point for the first time, (so why not the disgruntled set aside applicant before it?),
the FtT will also need to consider what Cranston J said in Mulvenna at [49]: the system of public law does
not permit someone to hold back from making a challenge until someone else has succeeded in one that
exposes the point. Obviously, the making of a fresh claim implies acceptance that the appeal is over, and
is not a route to repeat arguments which could and should have been put in the statutory appeal process.

105. However, if, contrary to my primary view, it is open in principle to an applicant to challenge an
adverse appeal decision through judicial review, whether directly or indirectly, through a challenge to its
effect on a subsequent SSHD decision, Mr Tam is right to point to the hurdles which they must overcome
in such an application, since the appeal decisions are lawful until set aside or held unlawful by a decision in
a judicial review challenge. Importantly, the time limits and the role of discretion apply.

106. The general principle in judicial review proceedings brought in time to challenge a particular decision
but where grounds of challenge attack an earlier decision by the same or, as here, another body, the FtT,
in relation to which time has expired, is that the judicial review time limits prevent that challenge to the
earlier decision, unless time is extended. I do not know which of the many distinguished editors of the
White Book wrote the notes to CPR 54.5, but I think it worth quoting what is said at CPR 54.5.1:

“The claimant must, however, challenge the substantive decision that is the real basis of their complaint. A
claimant may, for example, fail to bring a challenge to a particular decision, and may then seek to
challenge some later ancillary or consequential decision or approval of the earlier decision on the ground
that the later decision is unlawful as it is based on the original decision which is also unlawful. In such
situations the courts may find that the time limit begins to run from the date of the earlier decision.”

The editors give an example; I regard the proposition as plainly right. If I am wrong, so too is orthodoxy.

107.  This is what the statutory provisions and CPR 54 in effect provide. S31(6) of the Senior Courts Act
1981 provides that “undue delay” in making an application for judicial review, may lead to the refusal of
permission or relief, if the granting of relief “would be likely to cause substantial hardship to, or substantially
prejudice the rights of, any person or would be detrimental to good administration.” CPR 54.5 requires the
claim form to be filed “promptly”, and in any event “not later than 3 months after the grounds to make the
claim first arose.” The Court has a discretion to refuse permission or relief. I see s31(6) Senior Courts Act
1981, CPR 54 and the Court's discretion  as necessarily to be considered and applied before holding that
a precursor decision to the one actually challenged is unlawful. An application to amend grounds to bring in
a challenge to a different decision, directly or indirectly, in these circumstances requires no less
consideration to the time limits and to the arguability of the case, than would be required had separate
proceedings to mount the same challenge been brought.

108.  It would defeat the purpose of these provisions if the challenge to a later decision could be based on
the unlawfulness of an earlier challengeable decision, time for challenging which had passed, and for
which no extension of time was granted, taking into account the statutory considerations. The fact that an
antecedent decision, whether challenged directly or indirectly, would have been quashed as a nullity had
the challenge to it been brought in time, does not permit a claimant to bring out of time challenges to it


-----

[2017] EWHC 59 (Admin)

without seeking an extension of time, nor does it preclude the exercise by the court of its discretion to
refuse permission or relief.

109. Time runs from the point at which grounds to challenge the decision at issue first arose, not the point
at which a claimant knew of the facts, or knew that they could give rise to a claim. That may be relevant to
whether an extension is granted. The fact that the FTR 2014 were declared ultra vires in 2015, does not
mean that grounds to challenge the vires of the 2005 FTR did not arise in April 2005, and on the receipt of
every adverse appeal decision.  It is an error, not uncommonly made, but error nonetheless, for claimants
in judicial review proceedings to suppose that they do not need to bring a case until someone else
succeeds in a challenge which could have helped them if they had thought of the point themselves earlier; I
agree with what Cranston J said on this in _Mulvenna, above.  Proof of unfairness did not require the_
assembly of data, but an understanding of the context in which the FTR operated. The timetable in the FTR
has affected appeals since 2005 in that context.

110. Nor would it be consistent with the whole approach to the discretionary nature of the court's remedies
for the logic of Ms Lieven's position to apply, so that relief could not be refused in respect of a decision
reached years ago, and not challenged until a subsequent decision in reliance on it was made. And the
opening up of an alternative to the statutory appeal remedies, including an application to set the appeal
decision aside would also go strongly to the exercise of the court's discretion.

111. This is all very different from the position in Boddington for example. Mr Boddington had no reason to
concern himself with the byelaw until he was prosecuted. At that point, it had to be valid for the prosecution
to be successful, the very action at issue depended on the validity of the byelaw. The byelaw's continuing
validity was asserted for the very action being taken. The defence simply denied it. Time and discretion
could not prevent such a defence argument. The closer analogy to the problem here, though all are
imperfect, would be whether the invalidity of the byelaw could be asserted in a challenge to enforcement of
a fine after conviction, without an extension of time for the challenge to quash the conviction. Boddington is
not authority that a challenge to the lawfulness of any subsequent or dependant decision by reference to
the lawfulness of earlier decisions of itself permits, let alone requires, the whole chain of decision-making
to be unravelled without regard to time limits or discretion. The other decisions Ms Lieven referred to do not
contradict that position.

112. That is because the real issue at this stage is the role of finality in litigation and then reliance in taking
later decisions on unchallenged or unsuccessfully challenged decisions applicable to the same individual.
In FTR 2005 cases, the attack will usually be formally directed at decisions made after dismissal of the
appeals, when the earlier appeal decision has become part of the history of the individual claim, and the
attack seeks to re-open what has already been decided against the individual but not challenged
successfully or at all through the statutory appeal process. Without delving into second or third actor
theory, what Cranston J summarised in Mulvenna, and the decisions in Percy v Hall and Draga, above, are
all grist to the mill of a practical solution to the problems of invalid decisions which have been acted on,
rather than a simplistic logic that nullity always begets nullity, and taints its relations with the same
voidness.

113. This all means that the subsequent decisions cannot be quashed on the basis of an earlier allegedly,
even if almost certainly, unlawful appeal decision without the requisite extension of time to challenge that
underlying decision. The question of prejudice to good administration will be to the fore, along with finality
in litigation, and alternative remedies. These issues were raised at the permission stage in at least one of
the individual cases to which I turn, but not with the focus which in other cases they will require on an
individual basis, since there was a strong and proper concern to get these cases under way in order to
examine the vires issue.

114. Even where some such challenge is permitted, for it to be successful there would also have to be a
basis for holding that the decision was unfair beyond that it was reached under the FTR 2005. There is no
presumption of unfairness in relation to appeal decisions under the 2005 FTR. The basis must be
evidenced by reference to disadvantages, specific to the case, which the FTR timetable caused but which


-----

[2017] EWHC 59 (Admin)

the Principal Rules timetable and practice would have avoided, and which led to an unfair process. A high
standard of fairness is required. The SSHD might be able to show that there was no unfairness in reality.
This is not the same at all as requiring the appellant to show that the result would have been different
under a different regime; that is not required. But the claim may require greater justification where no
applications for transfer out of the fast track or for adjournments have been made, and where no attempt
has been made to advance claims or circumstances based on vulnerability, or if no issues about fairness
have been raised during the appeal, or if the evidence which was said to be missing is not provided as part
of a fresh claim made reasonably swiftly after the appeal concluded. The points I have referred to in
relation to the “interests of justice” in the FtT would also be relevant in judicial review cases as to whether
or not time should be extended, and relief granted, if that were a route to relief available for challenging
appeal decisions.

115. Issue 5: What are the effects of the success or failure of an application to set aside the appeal
**decision or to quash it? If an application to the FtT to set aside the appeal decision succeeds, or indeed**
the appeal decision is held to be unlawful, time limits and discretion notwithstanding, there is no answer to
Ms Lieven's contention that the appeal is in effect undetermined and remains for resolution. That means
that the lawfulness of subsequent fresh claim decisions, though not “reasonable grounds” trafficking
decisions, becomes irrelevant. The stage of fresh claims will not yet have been reached. So the review of
them falls away. Conversely, if the appeal decision is not set aside or held to be unlawful, I can see no
reason why it should not be fully relied on by the SSHD in response to fresh claims and in “reasonable
grounds” decisions. Where a challenge can no longer be brought for reasons of time which has expired
and is not extended, the earlier decision is not a nullity, but must be taken to be lawful, and as a lawful
basis for the subsequent decision being challenged.

116. Mr Tam suggested that in considering the lawfulness of the SSHD's decision on fresh claims, the
Court could consider whether she had taken “improper account of the content of the appeal
decision…given the particular circumstances in which the appeal was decided….” This seems to be a
recipe for confusion in relation to a lawful appeal decision, and irrelevant to the consequences of one set
aside or held unlawful as unfair. The issues here do not concern marginal irregularities. If the appellant has
not had a fair opportunity to put his case the decision is unfair. If the decision is unlawful, it is difficult to see
how there could be leeway for the SSHD to take into account some of the views expressed on the appeal
by the FtT. If it was not unlawful or if its lawfulness can no longer be impugned, then the SSHD is entitled
to treat it as lawful and the Court should do likewise. I see nothing but confusion in some half way house,
which could still require examination of the lawfulness and fairness of the decision, and it would not be a
confusion born of some necessary but unhappy application of principle.

117.  This, as I understood it, was rather different from an argument that, where the SSHD accepted that
the detained fast track had or was likely to have been wrongly applied to a claimant for asylum, though the
appeal itself was fair, she might, in considering fresh representations, give greater weight for example to
explanations for delay in raising a point or producing documents.

118. In the light of my conclusions, it only remains now to consider the lawfulness of the subsequent
decisions in the two individual cases on the basis that the appeal decisions were lawful, and I leave to the
FtT consideration of applications to set aside the appeal decisions. But lest that approach be wrong, I will
also consider the lawfulness of the appeal decisions here. This was at issue between the parties.

**The individual cases**

**TN**

119. TN is a national of Vietnam who, when she was encountered in December 2003, claimed to have
arrived recently in the UK. She claimed asylum in January 2004, but absconded, and her claim was
refused for non-compliance with procedural requirements. She was encountered again in 2007, arrested,
gave a false name, was released but again failed to comply with reporting requirements. In May 2011, she
presented herself to the authorities, and made a further claim for asylum based on her fear of religious


-----

[2017] EWHC 59 (Admin)

persecution in Vietnam as a Catholic, and a claim for leave to remain based on seven years' residence.
She also said that she was working in a nail bar and looking after her employer's children all without pay.
She was detained, her fresh claim was refused in 2012 and she was removed to Vietnam.

120. She returned to the UK illegally in around May 2014, and was arrested working illegally in a
Rotherham nail bar on 30 July 2014. At her immigration interview, she said that she had no money or
passport, and that a friend had paid an agent to enable her to travel to the UK. She then claimed asylum,
denied that she had been tortured, and was placed in the detained fast track after screening on 2 August
2014. She was not asked about trafficking. She asked to be released on the grounds that she had recently
miscarried and was in distress, but this was refused. The Detention Centre GP described her as physically
fit and mentally stable.

121. At the substantive asylum interview on 12 August 2014, she said that she had been tortured by
Vietnamese authorities to explain what happened to money collected at the church where she cleaned.
She had scarring. She was not referred for a R35 report. The basis of her claim was that, on return, she
would be mistreated by the Vietnamese authorities, just as her mother had been for saying “bad things
about the government”, and she was also suspected of involvement in the missing money. This had been
the basis for the further submissions refused in 2012, and which had led to her return to Vietnam. She said
that, on return there, she was kept at a detention centre, and was questioned about the money; she
refused to sign a confession and eventually escaped. Her brother and a friend arranged for her to come to
the UK in October 2013. It was on this journey that she was repeatedly raped by a “western man” involved
in bringing people to the UK. This had caused the pregnancy from which she had recently miscarried. She
was not referred to any specialist body such as the Medical Foundation.

122. On 14 August 2014, the asylum claim was rejected. The SSHD did not accept what she said about
her mother; in 2003 she said that she came to the UK to improve her way of life, and in 2014 she said that
she had come to be with her partner of 5 years. It was thought not credible that on neither occasion would
she tell officials about the true reasons for her coming to the UK particularly as she had told officials that
her parents had died in 1990. She admitted lying about various aspects of her claim. She had made a fresh
asylum claim in 2011, on religious grounds; her story was now completely different. She had made no
mention of arrest or detention in Vietnam at her screening interview although she now asserted that that
was the main reason for her return to the UK; her explanation was considered deliberately misleading. It
was not accepted that she was detained on her return, as described, nor for a year, nor that her description
of the prison was credible, nor that she could have escaped were the prison as she described, nor that she
would then remain at her brother's house while the police looked for her; her accounts of that were rather
variable. The scarring could have occurred in any number of ways.

123. Her appeal was heard on 21 August 2014, for which she submitted a witness statement and grounds
of appeal referring to her being trafficked for sexual exploitation, mental distress, but did not say that it was
happening in the UK; her counsel did not pursue a claim based on her experiences on the journey, so no
allegation of sexual trafficking was pursued. Two Vietnamese males were present and gave evidence in
support of her claim. Next day, her appeal was dismissed, and she unsuccessfully sought more time in
which to seek permission to appeal.

124. The IJ dismissed her appeal on the grounds that her claim was not credible. He did not believe that
she had been detained on her return to Vietnam, or able to escape from state detention using a big rock to
climb over the walls of the detention centre; or that she would go to her brother's house which was the
obvious place for the authorities to search for her, nor did he believe her description of how, while there,
she avoided capture because her brother had simply told them she was not there. Nor did he accept that
her mother had been arrested in 2003, as TN had claimed. She had said that she had returned to the UK
to be with her partner of five years, who was one of the men who gave evidence on her behalf. She had
had ample opportunity to explain the basis of her claim, and on the second occasion in 2014 had been well
aware of the asylum process. She had given conflicting evidence about the deaths of her parents more
than once. He referred to other discrepancies, including her failure to mention one of the main planks of


-----

[2017] EWHC 59 (Admin)

her claim, namely her arrest in Vietnam, and about her children. He explained why he gave no weight to
the supportive evidence of the two male witnesses.

125. She had made no reference to sexual exploitation in the UK.

126. An Emergency Travel Document was obtained on 28 October 2014, and Removal Directions were
set for 13 December. But on 9 December 2014, judicial review proceedings were brought against the
decision to set those Directions. The grounds included the claim that her previous lawyers who
represented her at the appeal ought not to have abandoned her claim to have been raped by a “western
man” en route to the UK. This, in my view, is not an allegation or indicator that she was trafficked. An
application for bail was refused by an IJ on 7 January 2015. In March 2015, a search of her room found
two phones. It was not until 23 June 2015, that permission was refused to bring those proceedings.

127. On 7 July 2015, the SSHD wrote to her alerting her to the litigation about the Fast Track Rules,
saying that she should seek advice about whether she might have been prejudiced by any unfairness
resulting from her claim and appeal being processed in the Fast Track. If so, she should submit written
representations in seven days; she did not do so. On 3 August 2015, Removal Directions were again set,
served on 7 August for removal on 21 August.

128. On 19 August 2015, her then solicitors made fresh representations to the SSHD to the effect that she
had been trafficked, that one person who attended her appeal hearing had been a customer, and saying
that she may have been tortured. This was the first claim that she had been trafficked into the UK for
sexual exploitation there, according to the SSHD but Ms Harrison said that there had been a general
assertion about that in 2003 and 2014. The SSHD replied that day, saying that this new allegation was no
more than a last minute attempt by someone, “who had exhausted all other means of appeals and
applications in the UK”, to thwart lawful removal. On 20 August 2015, in a further letter, the SSHD rejected
her further representations as amounting to a fresh claim: this decision referred to the rejection of her 2004
and 2014 asylum applications, the dismissal of her appeal on all grounds, and the refusal of permission to
apply for judicial review of earlier decisions to set Removal Directions. No new evidence had been raised
and so there was no reason to reverse the decision of the IJ. It also referred to the fact that she had been
interviewed on 19 August in connection with her claim to have been trafficked to work in the sex trade, and
that the subsequent referral to the National Referral Mechanism, NRM, had led to an adverse decision, the
negative reasonable grounds decision, based on her lack of credibility. It enclosed the NRM decision.

129. In that decision dated 20 August, the SSHD concluded that there were no reasonable grounds for
believing that she was a victim of trafficking under the NRM.  That letter stated that, “in establishing the
facts of your case”, the NRM form, screening and substantive interview records, her witness statement for
the appeal and the appeal decision itself had been considered, along with further representations  and her
interview which led to the referral. The referral to the NRM had identified a number of indicators. It
considered her credibility by reference first to the fact that she had been found not credible in her asylum
decision and appeal, had provided false details when encountered and had absconded in breach of
reporting conditions, and after removal had illegally re-entered the UK. Next, she made no previous
mention of any sexual exploitation in the UK, when she could have done so in various interviews. This
delay had not been satisfactorily explained. What she now said and what she had said in earlier interviews
were in conflict. There were numerous discrepancies in her account of being raped en route to the UK.
Those are decisions challenged in these proceedings.

130. A Rule 35 Report confirmed that she had scarring and the GP said that she had “concerns” that TN
may have been tortured, and included TN's account of being raped in Vietnam, on the journey to the UK,
where she was then forced into prostitution.  On 20 August, this was rejected as independent evidence of
torture. The SSHD's rejection also referred to TN's long history of breaching immigration law and of
unreliable evidence.

131. Further judicial review proceedings, these proceedings, were lodged. On 20 August 2015, an
injunction was obtained out of hours to prevent removal. The fairness of the appeal decision under the FTR


-----

[2017] EWHC 59 (Admin)

was raised, and the SSHD was told that an application to set it aside was being made to the FtT, as indeed
it was on that same day.

132. A report from Medical Justice dated 28 September 2015 by Dr Bingham, a GP, concluded that TN
had four scars characteristic of a relatively high impact with a blunt object, including two to the head and
one to the pubic area; the overall pattern was “highly consistent” with her history of beatings and rapes.
Rather than fabricating this, Dr Bingham thought that TN was “rather reticent.” Her summary opinion was:
“[TN] reports a sustained history of traumatic experiences over a period of years. Her mental state is typical
of a highly psychologically traumatised individual, meeting criteria for post traumatic stress disorder and
concurrent depression. She has scarring which is consistent and highly consistent with her account.
Considered overall, I found no aspect of the assessment inconsistent with her account and my overall
evaluation is that her presentation is highly consistent with her history of trafficking, imprisonment, multiple
rapes and forced prostitution.” TN was not suitable for detention.

133. TN's further representations were rejected by the SSHD as a basis for a fresh claim by letter
misdated 2 October, since it refers to the decision by Andrews J dated 7 October to refuse permission to
apply for judicial review. The SSHD's decision received on 13 October referred to submissions which it said
had been considered previously, to the fact that TN's appeal had been dismissed, that the judicial review in
UTIAC had failed, and that her latest proceedings had also been refused permission and marked as totally
without merit. It then turned to the fresh submissions which were considered not to create a realistic
prospect of success: sexual assault by prison guards in Vietnam, a high risk of exploitation and abuse if
removed there, and lack of fitness for detention because of her mental state.

134. The SSHD did not accept that Dr Bingham's conclusions as to her physical and mental state were
related to the history which TN had provided “given the serious and fundamental flaws in your own
evidence regarding your background history as raised by the Home Office, an IAC Designated Immigration
Judge, two High Court Judges and a Competent Authority in making their decisions on the same
evidence.” It also appeared that Dr Bingham had not been provided with all the documents relating to TN's
various claims. She had not made the requisite critical evaluation of TN's account, or the repeated
inconsistencies and contradictions in it, before being able properly to conclude that the presentation was
highly consistent with TN's history. It added: “Given that your account of being beaten and raped whilst in
prison in Vietnam was only raised in this medical report, which has not been accepted as determinative of
your claim, and your claim to have been imprisoned in Vietnam has previously been rejected by both the
Home Office and IAC, it cannot be accepted that you were raped and beaten in prison in Vietnam.” The
further representations did not meet the test for a fresh claim.

135. Further Removal Directions were set for November 2015. Permission was refused as totally without
merit, but a stay was ordered by Underhill LJ on 6 November 2015. On 4 July 2016, after further
submissions, he granted permission to apply for judicial review, “on all grounds”, according to the Order,
but it is clear that he did not permit the hopeless misfeasance in public office claim to be pursued; the
challenge to the lawfulness of the SSHD's Competent Authority Guidance is not being pursued. It is clear
that that did include a challenge to the vires of the FTR 2005. The unlawful detention claim has been
stayed by agreement.

136. The decisions now challenged before me are therefore the decisions to remove TN to Vietnam by
Removal Directions set in August 2015, the near contemporaneous decisions of 20 August to refuse to
treat her further representations as a fresh claim and the negative decision on whether there were
reasonable grounds for believing that she was a trafficked person. The claim has not formally been
amended to include a challenge to the further decision in October 2015. However, I shall treat Underhill
LJ's order as giving permission to argue the issues which TN raises, including the lawfulness of the appeal
decision. He did not rule out that issue in his first decision; he did not accept expressly the SSHD's later
submission that such a challenge would be out of time. He made no ruling that the challenge would only be
to the FtT on an application to set aside the appeal decision.


-----

[2017] EWHC 59 (Admin)

137. As I have said, I have concluded that this court should not consider whether the appeal decision was
unlawful as unfair; the route to be followed is an application to set it aside via R32 and the FtT. So I
consider the issue here only on the basis that that conclusion is wrong.

138. Ms Barnes, who argued the detail of TN's case for the SSHD, contended that the claim was out of
time for challenge to the appeal decision. I would have held that it was, for the reasons I have already
given generally, in the absence of a successful application to extend time. I would also have refused
permission to extend time. However, I read the permission decision as giving permission to challenge the
appeal decision, and it follows that delay only arises in the context of a discretionary decision not to grant
relief to an otherwise successful claimant. I do not think that, if the appeal decision was unfair, I should
exercise my discretion in this case to withhold relief on the grounds of delay.

139. Ms Harrison submitted that TN provided a clear and obvious example of an unfair decision reached in
respect of someone who should not have been in the DFT in the first place. There were clear indicators of
trafficking even at the time of her first arrest and more clearly at the substantive interview which,
regardless of any self- disclosure, should have led to investigation and referral to the NRM: she came from
Vietnam, a high risk country for trafficking; she had no documents; she was suspected of working illegally
and in a nail bar, a form of work known to use trafficked women, and in a location known to be linked to
trafficking; she had tried to evade authorities, and had had a recent miscarriage. No trafficking background
material relating to Vietnam was presented. She alleged torture and had visible scarring, yet had no expert
medical evidence and no R35 report had been obtained. Nor had any mental health report been obtained.
Later reports showed that there were issues to be investigated and supportive evidence could be obtained.
Time was obviously too short for the investigation of a complex case, and gathering evidence between
refusal and appeal. Removal of the case from the detained fast track on the grounds of depression and
miscarriage had been refused by the SSHD on 6 August 2014. Fitness for detention and interview was not
the point here; the point was whether the adjudicatory process in the detained fast track could be fair.
Many of these issues had been recognised in DA1, which came out shortly before the appeal in TN. The
SSHD had conceded that the detained fast track operated unlawfully in its failure to identify and release
potential victims of trafficking; PU and Others v SSHD 20 July 2015, Declaration by Blake J in a Consent
Order, that failures to identify indicators that someone was a potential victim of trafficking and to recognise
that the case required further investigation made their claims unsuitable for quick determination in the
detained fast track. The referral to the NRM should have preceded the appeal hearing, and had it done so,
the issue might not have been dropped, where there were two men at the appeal, one described by her as
a boyfriend, and another later as a customer, and the telephones found in her possession in the detention
centre suggested that she was still under the control of traffickers.

140. Ms Barnes submitted that TN had made no request for adjournment or for transfer out of the fast
track on the grounds of a lack of time to prepare her appeal; she had asked to come out for a different
reason right at her entry into the fast track. She was represented at all times. Failure even to try to use the
flexibility in the Rules meant that she could not now contend that the appeal was unfair. There was no
evidence that the shortened time scales in the FTR had prejudiced her case: she had given no evidence as
to why expert medical evidence about ill-treatment of her mental health could not have been obtained by
her lawyers. She had not provided any expert medical evidence for over a year after the dismissal of her
appeal. This evidence could not explain the fundamental flaws in TN's account, including the
inconsistencies in the dates of her parents' deaths. The main background evidence on trafficking was
freely available on the internet, and so there was no basis for supposing that it would have been produced
within the timeframe of the Principal Rules. The inadequacy of time to prepare the case in the fast track,
which was part of the context for the decision in DA6, could not apply where TN had failed to disclose her
claim to have been sexually exploited within the UK. This claim only emerged shortly before she was due
to be removed again, more than a year after her appeal was dismissed. The many adverse credibility
findings related to what she claimed had happened in Vietnam, and nothing said subsequently had
undermined those points. A different timeframe could have made no difference to the decision.


-----

[2017] EWHC 59 (Admin)

141. I am not persuaded that the appeal decision was unfair. There was no real basis for contemplating
that she was a trafficked woman, in the light of her immigration history, the absence of any indication from
her that she had been trafficked despite her knowledge of the asylum system and the risk of return on the
story she had given. The fact that she had scarring did not, without more, mean that there was a need for a
R35 report. She had been seen by the Detention Centre GP. I agree with Ms Barnes that a number of
indicators, such as evading authorities, are consistent with not wanting to be removed from the UK. Merely
asking to be removed from the DFT proves nothing. So I see nothing in her presentation in the DFT to
show that she should not have been in it at all.

142. She was represented throughout by solicitors. She made no application for a R35 report. No
adjournment was sought so that an appointment could be obtained with the Medical Foundation for
example. Transfer out was not sought from the IJ. No adjournment was sought in order to obtain medical
evidence of any sort. There was no indication either made expressly or noted by the IJ from observation,
that the issues which were raised could not be dealt with in that time frame, or that further evidence, oral or
documentary, was awaited or even obtainable.  The possible relevance of what happened on the journey
to the UK was not pursued. The IJ could assess the two men present who gave evidence, knowing that
one was alleged to be a boyfriend. Such further evidence as came did not come within the timeframe that
the application of the Principal Rules would have permitted, but was first presented over a year after the
appeal decision. There is no basis for supposing that the evidence would have been relevant to whether
her claim as advanced to the SSHD or on appeal was credible. There is no evidence that she would have
presented a completely different claim if only she had had more time in which to produce medical evidence
of the sort she did a year later. I note what is said in DA2[8] that applicants' solicitors said that they were
often preparing fresh claims before the substantive appeal was finally determined since they anticipated its
receipt but not quickly enough for the DFT timetable. She made no complaint about the fairness of the
appeal hearing or procedure in her first judicial review proceedings. The further representations leading to
the August decision had provided no evidence that the appeal decision was unfair. It was only in these
judicial review proceedings lodged on 20 August 2015 that the fairness of the appeal proceedings was
raised. Accordingly, I would not have quashed the appeal decision. This does not, formally at any rate,
dispose of the application before the FtT to set aside the appeal decisions.

143. If I had concluded differently on the issue of fairness, I would have quashed the appeal decision. The
subsequent fresh claim decisions would have fallen away, not because they were tainted by unfairness,
which may or may not have been the case, but simply because they assume that there has been a
concluded appeal. That would have been an incorrect assumption. The fresh claim decisions cannot
themselves stand in the place of a fair appeal decision. I would not have refused to quash the unlawful
appeal decision as a matter of discretion in this particular case because permission has been granted, and
issues require resolution, which provides a different context for the consideration of time limits and
discretion from that which is likely to be the rather more common situation in the future.

144. I would also have quashed the “reasonable grounds” decision because it is clearly affected by the
adverse conclusions reached by the IJ. Ms Barnes submitted that the SSHD “did not materially rely” on the
appeal decision in her “reasonable grounds” decision: it was only referred to twice, once for a point of
chronology, and once to the adverse credibility findings. Its findings on sexual exploitation could not come
from the appeal decision because the appeal decision did not deal with that point. The “reasonable
grounds” decision was based on the inconsistencies in the trafficking account, and not the earlier adverse
credibility findings, as the decision explicitly stated. It could refer to the fact that the claims of sexual
exploitation were not made at the appeal, for the purpose of drawing an adverse credibility inference,
without relying on the appeal decision itself. These, I accept, are all good points, but not sufficient on my
reading of the “reasonable grounds” decision. It seems to me clear that the decision was influenced by the
other adverse findings and how the appeal progressed in what, if I had so found, would have been an
unfair process in its application to TN. I cannot hold that the decision would necessarily have been the
same.


-----

[2017] EWHC 59 (Admin)

145. It follows from my conclusion on the lawfulness of the appeal decision that, if it is not set aside by the
FtT, the subsequent decisions cannot be challenged on the grounds that the appeal decision, to whatever
extent it was relied on, was itself unlawful.

146. The next issue for me is therefore whether the fresh claim decisions are unlawful on _WM(DRC)_
grounds. The decision of 2 October 2015 was a separate decision from that of 20 August 2015, and was
directed at Dr Bingham's report. It was not just a decision to maintain the August decision. The October
decision has not been formally challenged because it was wrongly seen as simply maintaining the earlier
decision. The Rules are there to be complied with, partly to avoid this sort of debate. I read Underhill LJ,
however, as permitting all the decisions relevant to this dispute to be raised and resolved. The issues have
been argued and, as no prejudice would be caused, I grant any necessary extension of time to amend and
bring a challenge to the October decision.

147. I would not quash the August decision on its own merits, but I do not spend further time on it in the
light of my conclusion on the October decision. Again, I recognise the force of the criticisms made in the
SSHD's letter about the relationship between what TN had previously said, the assessments of her
credibility, and the history upon which Dr Bingham relied. Lying and contradictions may for some be
indicators of being trafficked, but they may also indicate unwarranted attempts to thwart removal. By the
time Dr Bingham's report was received, however, the claim now supported by the Bingham report, read
with the other evidence previously rejected, could no longer rationally still be dismissed as lacking any
reasonable prospect on appeal. It would not have been unlawful at all to refuse to allow the claim, but that
refusal should have been appealable. Accordingly, I quash the decision of October 2015. The full evidence
will be considered on the further appeal.

148. I then turn to the NRM decision. Ms Harrison submitted that the “reasonable grounds”, or initial filter,
decision was flawed. The decision is simply whether someone is suspected of being a victim. It is a low
threshold. She referred to the US State Department Trafficking in Persons Report of 2015, and the Child
Exploitation and Online Protection Centre (CEOP) Report confirming that Vietnamese women are trafficked
to work in nail bars, often fronts for money laundering and prostitution, and a Daily Mail online report from
March 2015 of a Vietnamese trafficking network in Rotherham operating in the way TN had described.
Home Office Guidance for staff in Competent Authorities on Victims of **_Modern Slavery of July 2015_**
advised that a negative asylum decision should await a conclusive grounds decision from the NRM;
objective indicators of trafficking should be considered, rather than simply relying on a victim to identify
herself as a trafficked person, but here they were ignored. The decision focused overmuch on credibility,
and while internal and external credibility on material facts are relevant, the Guidance advises that trauma
may be a valid reason why a potential victim's account is inadequate; these inadequacies may be
explained by such factors as mistrust of authority or shame. These points were emphasised by Dove J in
_R (FK) v SSHD_ _[2016] EWHC 56 (Admin) at [30-35], and by Sir Stephen Silber in R (SF St Lucia) v SSHD_

_[2015] EWHC 2705 (Admin), [2016] 1WLR 1439notably at [198]._

149. Ms Barnes submitted that the SSHD was not barred by any policy from assessing credibility or taking
inconsistencies in the account into consideration. She had not ignored them, including the fact that TN
worked in a nail bar, as she had done on her earlier stay in the UK. Although the SSHD had not referred to
the CEOP report, itself not relied on in the representations made to her, she had considered the more up to
date US State Department report which covered the same ground. Many indicators of trafficking relied on
by Ms Harrison were equally consistent with the behaviour of someone who had no right to be in the UK.

150. In my judgment, the decision on the material presented in the NRM was lawful. Ms Harrison is right
that this is but an initial filter with a low threshold; caution is required about the weight to be put on
credibility and delay in raising the issue. However, TN's presence in the UK for several years before her
first removal is of real significance. Ms Harrison submitted that there were indications that TN had been
trafficked in to the UK and exploited throughout her first stay from 2003. Yet she did not raise any such
issue even when detained, or when facing removal, or on arrest after return. This degree of failure to raise
the point at any stage requires more than a generalised assertion that this may be a consequence of being
trafficked or of trauma If however she was only trafficked the second time she arrived illegally the


-----

[2017] EWHC 59 (Admin)

indicators Ms Harrison referred to, such as working without pay, lose such significance as they might have
had, because this is what happened through her first stay, without her being trafficked for sexual
exploitation. There was no real evidence of trauma or the circumstances of being trafficked as an
explanation for the delay in raising the issue in her case. Her claim of rape en route shows that she was
willing to talk about traumatic events. She had faced imminent removal on more than one occasion, and so
her raising of it cannot be attributed to her facing imminent removal. There was no real evidence that she
had only very recently escaped the control of others. She had solicitors throughout. I accept Ms Barnes'
point that some of the indicators are equally consistent with the behaviour of someone who has no right to
be in the UK.

151. There was so much which was against her on credibility that the SSHD would have found it very
difficult to reach a different conclusion. TN's claims were full of major inconsistencies, as the decision
letters point out. An adverse decision based on credibility can be perfectly sound. The trafficking indicators
here were weak on any view, separately or in the round. The credibility issues and delay were very strong
adverse points. I do not think that those can rationally be attributed to traumatic experiences, without
cogent evidence. The Bingham report came after the NRM decision and cannot be relied on to show its
unlawfulness. Whether the same decision would now be reached is not the issue. If however, I had
concluded that the NRM decision was unlawful, I would have quashed both it and the August decision on
the fresh claim, as it is clear that the former significantly affected the latter.

**US:**

152.  US is a Pakistan national who entered the UK, aged 24, in December 2009 with leave to remain as
an accountancy student, later extended to 30 October 2014. He returned to Pakistan for about 6 months,
re-entering the UK in January 2012. His leave was curtailed on 30 March 2014 to expire on 28 May 2014.
He was served with notice of intended removal on 1 April 2014. The Home Office interview of 1 April 2014
records US as saying that he is not fit to be interviewed, and was confused and worried. Two days earlier
he had been arrested for a suspected fraud - not pursued. He answered the questions at some length,
saying that he was happy here and, ambiguously, that when he thought of Pakistan, it made him want to
cry; he had always wanted to make his future here. There is no mention of any difficulties in Pakistan,
though there did not appear to be any specific question about that. He was interviewed for Emergency
Travel Documents on 16 April, and on 24 April 2014 was served with Removal Directions for 30 April 2014.

153. He sought asylum by a letter dated 25 April 2014. At his asylum screening interview on 1 May 2014,
he said that he could not return to Pakistan because his ex-girlfriend's mother was trying to kill him. After
screening, he was placed into the detained fast track process. On a number of occasions, he complained
that he was in poor mental health, and sought to delay the process; solicitors asked that he be removed
from the fast track so that he could gather documents and have them translated.

154. At his substantive interview on 12 May 2014, he said that he was “absolutely not well,” mentally or
physically; he was very disturbed mentally and could not proceed. Medical staff had been unable to help
and were just ignoring it; he had headaches and could not sleep. But, after speaking to his solicitor who
was present, he said that he would continue, saying he obviously had no option, otherwise it would go
against him. He was asked if he had any documents: he had asked friends for documents which he had
hoped would be there by now and he would forward them should they arrive; these included an FIR filed at
the police station, when he was stabbed in the arm, and had gone to hospital. The wound had required
many stitches; two fingers had been broken.  But he did not know whether the FIR had been filed on his
behalf or against him. He had been trying without success to contact his family.  He had phoned a friend
in Pakistan to check. He had asked anyone going to Pakistan over the last five years to see if they could
find out about his documents. A friend had come across a document showing that his parents had
disinherited him, and no longer regarded them as their son. He had also undergone an Islamic marriage to
a Czech national living in the UK. The refusal letter came the next day, 13 May 2014.

155. On 9 May 2014, the SSHD had rejected an application for temporary admission as he fitted the DFT
criteria. On 13 May 2014, his solicitors asked the SSHD to remove him from the DFT. His case was too


-----

[2017] EWHC 59 (Admin)

complex; he had medical problems, including mental ones. His medication had run out and he was not
seeing a doctor. They were still gathering and translating documents; some of those he had expected had
now arrived but needed translation. If the case remained in the DFT, further time should be allowed.
Further submissions were made on the asylum claim, and about his wife's position. Background or
objective evidence was referred to. His grounds of appeal complained about the interview as unfair, and
about the effect of his poor mental health.

156. But the refusal letter, which came later that day, then caused his solicitors to cease to act for him; the
merits test for legal aid was no longer met. US however had still expected to be represented at the hearing
of his appeal on 23 May 2014, but obviously was unrepresented. US was given the chance to phone his
solicitors, which he did. The hearing was not adjourned. The IJ records, [38], that US consented to the
appeal proceeding and its procedures were explained to him.

157. He claimed that in Pakistan he had made his girlfriend pregnant, and that her brother had found out.
He was threatened by some people, prominent among whom was a member of Lashkar-e-Tabha. They
attacked him and he had to go to hospital for treatment. He moved around Pakistan before coming to the
UK. He feared that he would be killed by that group if he returned to Pakistan. There was a strong attack
on his credibility by the HOPO.

158. The IJ found first that the asylum claim was weak because of the five-year delay in claiming asylum
after his arrival in the UK. He made no reference to the difficulties now relied on in his immigration
interview on 1 April 2014, stating instead that his main aim in coming to the UK was to complete his
studies, and get a good job. He made a general assertion that he had been advised not to claim asylum,
which the IJ regarded as a diversionary tactic. Second, it was weak because of the delay between his
arrest on 29 March 2014, the notice of intended removal served on 1 April, the service of removal
directions on 24 April for removal on 30 April, with the asylum claim only being made on 26 April 2014.
Third, US had obtained false documentation and was working illegally after expiry of his visa in 2013.
Fourth, his account of the events upon which he relied for his claim had significant weaknesses. Fifth, three
documents he relied on were untranslated copies. He found that no weight could be attached to them.
Sixth, he rejected Duncan Lewis' earlier written submission that the case was too complex for the DFT; it
simply was not. US was clear and focused, fully engaged with the appeal process. Even if he had a
continuing problem as a result of a previous relationship, he could relocate, as a resourceful and intelligent
individual. The relationship with the Czech national was not durable, (he had not seen her since January
2014), and the Islamic marriage not recognised in English law.

159. His application for permission to appeal to the Upper Tribunal was dismissed on 12 June 2014, and
his appeal rights were exhausted. The UT judge described his grounds as rambling. He raised the fairness
of the interview and the process, in the light of what he said were his mental health difficulties and
difficulties obtaining documents.

160. The first letter containing further representations, dated 20 June 2014 and drafted by US, included a
copy of an FIR from May 2009, newspaper articles and information about Lashkar-e-Tabha. It was rejected
by the SSHD's letter of 23 June, the day before removal was due. The refusal letter said that US had
“already been given ample time and opportunity to provide any corroborative evidence” to support his
asylum claim; the representations were submitted simply to delay imminent removal. His claim had been
fully considered, refused and dismissed on appeal. The letter cited the appeal decision extensively. The
documents could not be relied on; no reason had been given as to why they were only produced when they
were rather than earlier; they were entirely self-serving; even if genuine, they were easily obtainable, which
made the timing of their arrival of significance especially in the light of US' immigration history. The latest
submissions, with the material previously considered in the refusal decisions “would not have created a
realistic prospect of success before an immigration judge.”

161. Duncan Lewis & Co began to represent him again. On 24 June 2014, they wrote again to the SSHD.
They referred to the health issues which US had raised at interview and the asserted failure of the
detention centre to provide a R35 report despite it being requested. He had not yet been given the


-----

[2017] EWHC 59 (Admin)

opportunity for a full health examination. They enclosed a medical report from Medical Justice by Dr
Hartree dated 24 June 2014. The SSHD was urged to postpone removal so that the report could be fully
considered. They summarised the report, based on a telephone assessment, medical records and previous
decisions and representations. Dr Hartree was of the opinion that US had a “clinical picture of severe and
agitated depression”; he sounded tearful and unremittingly sad; he had “prominent symptoms of anxiety,
with feelings of panic”, fearful of “being maimed by his (alleged) persecutors in Pakistan”, which, together
with fears of destitution there, dominated his thinking. These were genuine fears, whether realistic or not.
US had described to her psychotic symptoms, involving verbal hallucinations, suggesting a psychotic
depression. He also had trauma-related symptoms, suggesting that he had PTSD. This was all “highly
compatible with his reported history of traumatic experiences” and a genuine subjective fear of persecution.
She thought that his symptoms were genuine and would have been difficult to fake. A further assessment
was recommended and possible treatments included medication and therapy. US was not removed.

162. On 10 July 2014, the SSHD replied to the letter of 24 June 2014, rejecting the further representations
as amounting to a fresh claim. The suggestion that US was not fit to fly had been overtaken by a medical
assessment of 7 July 2014 to the contrary effect. The SSHD said that the points raised in the Medical
Justice report about scarring to the left arm and other scarring, PTSD, anxiety and depression had already
been considered in the asylum decision and on appeal. The IJ had rejected the claim that the scar had
been caused in the way alleged. US had never been formally diagnosed with any mental condition, and so
the report was not accepted as independent evidence of a medical condition, nor was it corroborative, as it
did not state that the injuries were consistent with or could only have been caused in the way suggested.

163. Duncan Lewis submitted further representations by letter of 11 July 2014, following the service of
removal directions for 15 July 2014. It complained that no copy of the 7 July assessment had been
provided to US or to them; the SSHD had not followed the test in _WM (DRC). This was a pre-action_
protocol letter.

164. The SSHD responded on 14 July: there was no evidence that US had ever threatened or attempted
suicide before Dr Hartree's report, even during the appeal. “Indeed, your client's symptoms seem to have
manifested themselves only since it was clear that return to Pakistan was becoming a distinct possibility.”
There was no evidence that he could not be treated adequately in Pakistan. A further letter of the same
date said that a further assessment showed him fit to fly. He would not be granted temporary admission.

165. Dr Marcus, after a face to face interview with another doctor as well, submitted a further report dated
14 July 2014 from Medical Justice. She considered that the large scar on his left arm was typical of a deep
and extensive cut caused by a deliberate attack with a sharp object; it was not a burn, nor likely to have
been self-inflicted. Two scars on the palms of his hand were also consistent with a knife assault. The
overall pattern of those scars and other signs of injury were “highly consistent” with the history given by
US. His psychological symptoms indicated a diagnosis of severe and agitated depression; it was clear that
US had a severe level of psychiatric disturbance with strong suggestions of psychotic depression. She
found nothing to suggest that he was faking symptoms or exaggerating his history. She was not surprised
to find some differences in the way in which he had described his history and symptoms to her and to Dr
Hartree. If he were to be removed, his risk of suicide could become high; he would be extremely unlikely to
be able to work or provide for himself in Pakistan because of his mental state, his difficulty in responding
coherently to questions, following a chain of thought, and because he was agitated and restless. He was
not even fit to fly. He needed therapy and treatment, none of which could be effective unless “he felt secure
from the risk of further ill-treatment.”

166.  Removal Directions were set for 15 July. On 14 July, a further report from Medical Justice by Dr
Marcus concluded that he had a scar consistent with an assault, and severe psychiatric disturbance. These
judicial review proceedings were commenced on 15 July 2014 in UTIAC, and a stay on removal was
granted. US was not released, but by 28 July was being held under general immigration detention powers.

167. On 8 August, the SSHD responded to Dr Marcus' report of 14 July, which appears to have been
submitted with other representations on 25 July. The letter rejected them as amounting to a fresh claim. It


-----

[2017] EWHC 59 (Admin)

commented that US had before always used an Urdu interpreter, but not for his interview with Dr Marcus,
which the SSHD thought undermined her conclusions. She had no particular expertise in the diagnosis of
scarring or of mental health issues, as she was a specialist registrar in genito-urinary medicine and HIV.
She appeared to diagnose depression after a single interview of unknown duration, which would not be
normal, and still said that a further assessment should be undertaken. US had never suggested that he
had been the subject of a knife attack before, and indeed did not so say to Dr Marcus, making her
conclusion on that baseless. Dr Marcus had described US' fear on return as “subjective”, but the letter
noted that the decision-making and appeal process had not accepted that he had a well-founded fear of
persecution. None of the medical practitioners in the detention centre, whom he had seen on several
occasions, had said that US was unsuitable for detention.

168. A Rule 35 report was made by Dr Wallace on 31 August; the doctor repeated what US had told him
about a knife attack by at least 10 men with a connection to Lashkar-e-Tabha, seemingly in disapproval of
his relationship with his then girlfriend. The doctor ticked the box that he had concerns that US “may have
been the victim of torture.” UKBA said that it made no firm finding that the injuries were consistent with his
account; and the report had not expressed concerns about US' continued detention.

169. Dr Marcus responded on 3 September: US had no difficulty communicating without an interpreter;
she had considerable relevant experience; she had made a clear provisional diagnosis, with the doctor
accompanying her, but recommended specialist referral, not just for confirmation of the diagnosis but for
treatment or monitoring; she had taken a careful history of how the wounds leading to the scars were
inflicted; she had only dealt with his mental state and not the credibility of his fears.

170. US, who had sought release from detention on a number of occasions, was released from detention
on 3 September 2014.

171. A further SSHD letter of 5 September 2014, the trigger for which is unclear, returned to the two
medical reports, confirming that they did not amount to a fresh claim, in reliance on the appeal decision.

172. Permission to apply for judicial review was refused by the Upper Tribunal on paper on 12 May 2015.
On oral renewal on 16 September 2015, the claim was adjourned and transferred to the Administrative
Court as it included a claim for wrongful detention.

173. US was by now an absconder, but was encountered during a routine traffic stop and detained on 9
November 2015. US expressed a desire to commit suicide and was placed on special watch. Meanwhile,
Removal Directions had been set for 8 December. On 29 November, the SSHD rejected a R35 report as
amounting to a fresh claim, though on 2 December, she accepted it  constituted independent evidence of
torture; but US remained in detention as Removal Directions for 8 December had been set over 2 weeks
earlier. On 3 December 2015, he was identified by SSHD as a vulnerable individual.  A stay on removal
was refused by Mitting J on 8 December; but the Removal Directions could not be carried out because US
could not be removed from the detention centre.

174. On 9 December 2015, he made an application to the FtT to have his appeal decision set aside on the
grounds that the 2005 FTR were ultra vires. He was again released from detention on 17 December 2015.

175. I was also supplied with a further medical report, from Dr Thomas, a consultant clinical psychologist,
dated 13 September 2016. This has not been considered by the SSHD and no challenge relates to it. But I
observe that the interview took place with an interpreter. The report only mentions medical records from
the detention centres, and not for example from his GP, nor of any treatment sought or received as a result
of the earlier diagnoses, beyond medication which he had been prescribed in the detention centres; there
was no reference to any outside doctor issuing prescriptions. His taking of medicine was disrupted when
he moved between detention centres. She did not ask him whether, and if not why not, he had seen any
doctor or sought any therapy in the light of the previous reports and his current state, as she saw it, during
his periods before and outside detention. She did not even address the point. He had major depressive
disorder and complex PTSD, “entirely caused by the cumulatively traumatic life events which occurred to
him in Pakistan.” She did not think that he was fabricating symptoms. His medicines were seen as unusual


-----

[2017] EWHC 59 (Admin)

individually, and in combination as showing the gravity of his illness. She also offered the opinion that the
UKBA interview “was obtained under duress from a vulnerable individual with a significant psychiatric
condition, clearly stating that he was not well enough to be interviewed”, and the SSHD should not rely on
the inconsistencies it found in his case. He was not presently fit to give evidence. Her primary
recommendation for his mental health was that he be granted leave to remain in the UK so that his fears of
return to Pakistan would be relieved, and he could feel safe and secure.

176. I adopt the same approach to the consideration of the lawfulness of the appeal decision as I did in
TN, because in my judgment the proper course is for the FtT to decide whether or not to set it aside; it
does not matter for this purpose whether the issue is raised as a direct challenge to the appeal decision or
indirectly via a challenge to decision on fresh claims.

177. On the facts here, but for the particular circumstances and orders associated with the need to resolve
the general issues, I would have refused permission to raise the vires of the FTR directly or indirectly.
Indeed, the application to amend the grounds to raise the issue was not made until 19 months after the
appeal decision and 5 months after the Court of Appeal decision in DA6. The vires point was there for
anyone to take; no one needed to await the outcome of the proceedings in DA5 and 6, let alone some
more months on top. Challenges to fresh claim decisions should not become a non-statutory alternative
appeal route.

178. Ms Lieven submitted that US' claim should not have been processed in the DFT because the SSHD
was put on notice by US as to his mental health problems, the need for a medical report was raised, which
subsequent medical reports supported. The question for the SSHD and FtT is not only whether the
individual is suitable for detention, but whether the decision and appeal are suitable for handling in
detention in the fast track timetable; DA1 [154-157].

179. Ms Barnes submitted that there was no evidence to support the contention that US should not have
been in the DFT in the first place. He said nothing about documentation being awaited which would take a
long time to come either at screening or substantive interviews. The representations to the SSHD about
removal from the DFT were unparticularised and vague, and raised no question of torture. He made no
further requests for time to prepare his appeal. He first raised torture at his asylum interview in the context
of a claim that his girlfriend's family had stabbed him in the arm, albeit a year later than he had first said, a
month earlier, when he said simply that he had been stabbed in the arm. A mere claim to have a mental
health condition, or to have been tortured, did not warrant removal from the DFT. There was nothing in the
medical records to suggest that any medical conditions could not be managed in detention: at Dungavel
IRC in April 2014, the notes simply refer to anxiety and poor sleep caused by his current situation. He
stated at medical and later at disability screening at Harmondsworth IRC that he had never suffered from
mental health problems. On 11 May 2014, he complained of anxiety, insomnia, headaches and flashbacks;
an appointment with the mental health nurse was arranged within the week. Next day, he saw the doctor,
complaining of much the same, including nightmares; he was anxious and tearful, but without suicidal or
self-harm thoughts, and was coherent in speech. An anti-depressant was prescribed. A few days later, he
repeated his complaints, and was told that the medicine needed some time to work, as happened a few
days later as well. He failed to attend his appointment with the nurse. Nothing in this history suggested
that he should have been removed from the DFT.

180. I see nothing unlawful about the initial decisions that US' claim should be processed in the DFT. I
accept Ms Barnes' submissions set out above, at least up to the stage when the substantive interview took
place. I do not need to resolve for these purposes whether he should have been removed from the DFT
when the short time span between his first seeing his solicitors and the substantive interview taking place
required removal from the DFT or a postponement of the interview.

181. Ms Lieven submitted that the appeal decision in US' case was unfair and should be quashed. The
FTR appeal timetable prevented US presenting medical evidence which would have corroborated his
account, and which went to his credibility, rejected by the SSHD and FtT. His solicitor was allocated to him
only 2 working days before the substantive interview on 12 May 2014, but he was not told even of this at


-----

[2017] EWHC 59 (Admin)

the time, and asked for the interview to be postponed so that he could give proper instructions, for which
he needed further documents. He would not have had more than a short time beforehand on the day of his
interview in which to speak to his solicitor. He was distressed at the interview and said so, and still needed
documents. The adverse decision of 13 May 2014, and the fact that they could no longer represent him
because of the legal aid merits test, meant that he had less than 3 days' contact with lawyers. He was not
represented on appeal, which came as a surprise to him, and the appeal came on only 7 working days
after the SSHD's decision. He only received legal assistance again after his appeal rights were exhausted.
So he received no legal assistance as to how to pursue what he clearly wanted, which was to leave the
DFT so as to present his appeal properly, even if, being unrepresented, he did not make the correct formal
application. He failed in an application for pre-hearing bail, in which he referred to mental health problems.
In reality, he did raise the absence of time to obtain documents in his application for permission to appeal
against the adverse appeal decision. The IJ did not consider whether the appeal process would be fair.
The claim was not hopeless and the result of an appeal conducted to a fair timetable was not its inevitable
dismissal.

182. The first medical report obtained on 24 June 2014 would have supported the distress he claimed at
interview and on appeal. Medical evidence would also have helped explain US' difficulty in answering
questions, which was also held against him. It could have helped explain inconsistencies over dates,
particularly of the stabbing, (inconsistencies not obviously proven and not put to him), on which the SSHD
and FtT put considerable weight; it could have corroborated his account of the attack in Pakistan, and
shown that there were more problems with internal relocation than the FtT thought in view of its appraisal
of US as a resourceful and intelligent man. It might well have shown that the case was indeed too complex
for the DFT, contrary to what the SSHD and FtT concluded. Time to produce documents was crucial to his
rebutting the adverse credibility points made by the SSHD and accepted by the FtT. He could not address
the adverse findings and factual errors, notably the conclusion that he had knowingly worked unlawfully.
The document curtailing his leave had not been served on him, contrary to what the FtT had thought. He
was refused time by the SSHD to obtain translations of various documents and further evidence, and the
FtT rejected what he did have, if not translated. The documents were ignored, when permission was
refused to appeal against the adverse appeal decision, on the grounds that they should have been in
translation before the FtT.

183. Ms Barnes denied that there was any unfairness in the individual appeal decision. In fact, US had
applied to the SSHD to transfer his case out of the fast track but this had been refused along with the
refusal letter. The FtT in its appeal decision had in fact considered the fairness of the appeal continuing in
the fast track in the light of Duncan Lewis' earlier written representations that it should be removed. The
absence of supporting medical evidence, though part of the SSHD's case, did not form part of the FtT's
reasoning for dismissing the appeal. Medical evidence would not have countered the rejection of the
credibility of the claim in this case, nor affect the conclusions on internal relocation or sufficiency of
protection. The later medical evidence merited little weight. The reports ignored inconsistencies in his
account. US had also denied suffering any mental health problems at his screening interview, and all his
symptoms appeared after he was told that he would be removed on 1 April 2014. This timing was ignored
in the reports. There was no evidenced reason why medical evidence should not have been obtained
within the fast track timetable. US had had ample time in which to collect documentation to support his
claim over the five years he had been in the UK; he said that he had been asking for it over that period.
Although the absence of representation at the appeal appeared to come as a surprise to US, the IJ gave
him time to contact Duncan Lewis, and he then said that he was content to continue. The IJ commented on
his clarity, focus and answering of questions. The FtT, refusing permission to appeal, had dealt with the
alleged factual error about US working illegally, knowingly: it would have made no difference to the force of
the impact of delay in claiming asylum on his credibility.

184. I am satisfied that in this case the appeal process was unfair, and were it for me, I would quash the
decision. The fact that the interview was conducted with so short a period for advice, and was then
followed by the withdrawal of the solicitors means that US had only brief moments for advice. He had
asked for his case to be removed from the DFT because of his health and the need for documents I


-----

[2017] EWHC 59 (Admin)

accept that some of the reasoning about the complexity of the case was vague, but this all did require
consideration against the very limited time for advice, and the fact that he received no legal assistance
after the adverse SSHD decision.

185. No criticism can be made of the solicitor's decision to withdraw. It was clear to the IJ that US had
expected to be represented. That was bound to have affected how US prepared for his case. I recognise
that the IJ gave US the opportunity to say that he did not wish to proceed but he said that he was willing to
do so; however US was clearly unhappy at the turn of events, he continued to complain about his health,
and he lacked documents he hoped to have. He raised the fairness of the appeal decision, though not the
vires issue, in his grounds of appeal, and in his further representations of 20 June 2014. He provided
documents, albeit in unsatisfactory form, and a medical report on 24 June, less than 6 weeks after the
substantive interview, and 2 months after his asylum claim. The timetable in the Principal Rules would
have allowed 5 days between adverse decision and appeal, in detention, and up to 35 days from lodging to
hearing of the appeal, R23(2), with case management hearing and an opportunity to seek an adjournment.
I do not know whether the outcome of the appeal would have been different if conducted either under the
Principal Rules or some fair procedure of the IJ's own devising; but that is not the test. I am clear that the
2005 FTR, in the context in which they operated in this case, meant the appeal was dealt with too fast to
be fair. I cannot say that the evidence produced shortly after the appeal decision would have made no
difference to its outcome. I would quash it if it were for me.

186. Ms Lieven submitted that the SSHD had failed to review US' claim pursuant to the policy instruction
described in DA3, the appeal from my judgment, _[2014] EWCA Civ 1270 [22], and instead had served_
removal directions on US on 10 July 2014, a day after DA1 was handed down, for removal on 15 July. Ms
Barnes responded that the review period after DA1 was after that date, and further representations had
been sought. The claim was issued on 15 July 2014, before the review period had begun. There is nothing
in this point.

187. The consequence would be that the decisions on the further representations, which may otherwise
be lawful, simply fall by the wayside, because they assume that there has been an appeal decision, when,
if it is quashed there has been no such decision at all. The appeal would remain outstanding.

188. However, as the appeal decision is not quashed, and remains to be set aside, if it is, by the FtT, I turn
to the fresh claims decisions on their merits. I consider them on the basis that the appeal decision was
lawful. I regard the question of whether they were tainted by it as irrelevant, though this does not mean that
the effect of the speed of operation of the FTR is to be ignored when considering whether documents could
have been obtained and translated or other evidence could have been obtained for the appeal, nor the fact
that he was unrepresented. There are five decisions: 23 June, 10 and 14 July, 8 August, 5 September
2014 and 29 November 2015. I treat them all as decisions which US has permission to challenge.

189. Ms Lieven submitted that the new evidence submitted after dismissal of the appeal met the low
threshold for holding that there was a fresh claim, refusal of which would have led to an appeal, applying
_WM(DRC). The SSHD's decisions that the further representations did not amount to fresh claim were not_
rational.

190. Ms Barnes gave a number of cogent reasons why the medical evidence now relied on by US was of
little weight: they lacked contemporaneous support, did not address US' ability to present his claim as
judged by the IJ who did see him give evidence, the onset of symptoms, their rapid increase as removals
neared, and yet, despite their growing severity, US apparently went without any treatment when not in
detention, a point which the last report did not even remark upon.

191. I do not accept her submissions however. The first refusal letter rejected the representations on the
grounds that US had had ample time and opportunity to provide corroboration for his claim, and they were
not reliable. That would often be a sound basis for rejecting further representations. But not in this case.
The brevity of the FTR process, the shortness of time to obtain legal advice, and the absence of
representation, coupled with the speed of action required a different approach to how they might be seen
by the rational IJ The first decision was unlawful; its approach to timing ignored very relevant


-----

[2017] EWHC 59 (Admin)

considerations. The related responses of 10 and 14 July dealing with the first medical evidence take a bold
albeit perhaps sustainable approach, but only if the first letter had been satisfactory. However, by the time
of the 8 August response to the first medical report produced after a face to face interview, and more so
after Dr Marcus' response report of 3 September 2014, replied to by the SSHD on 5 September, I regard it
as clear that a rational IJ could find that his case was well-founded. I say that, accepting as I do, that US
should face some rather more searching questions than his medical evidence suggests he has received
from his experts, and they will need to deal with some quite difficult issues as well. The decision of 29
November, read with that of 2 December 2015, shows that the further representations should by then
unarguably have been accepted as making a fresh claim, in the light of all the other further evidence, and
the speed with which the appeal had been heard. It would have been lawful to refuse the claim but that
decision would have been appealable.

192. I quash the fresh claim decisions I have listed. There will now be a further appeal.

**Conclusions**

193. Subject to any submissions from counsel on the precise terms of the order, I declare that the FTR
2005 are ultra vires. I refuse to quash the appeal decisions. I quash the fresh claim decision of 2 October
2015 in the case of TN, and all the fresh claim decisions made in respect of US. I do not quash the NRM
“reasonable grounds” decision nor the 20 August 2015 fresh claim decision in TN's case.

**End of Document**


-----

