# R v Majeed [2023] EWCA Crim 1444

Court of Appeal, Criminal Division

William Davis LJ, Jay J, HHJ Dennis Watson KC

16 November 2023Judgment

MR B NEWTON KC appeared on behalf of the Appellant.

MR A JOHNSON appeared on behalf of the Crown.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

LORD JUSTICE WILLIAM DAVIS:

1 The applicant is an Iraqi national. He has applied for leave to remain in this Country relying on
humanitarian grounds, a claim which has been the subject of litigation.

2 Currently his claim for asylum is in the hands of the Home Office. In some cases that would make it
necessary to make an anonymity order for someone in his position. However, we are very conscious of
the need to preserve open justice, particularly in the context of criminal proceedings.

3 The applicant's counsel today accepts that the strict necessity for anonymity is, in this case, not
immediately apparent. It follows that we do not make an anonymity order. The case is currently listed
under initials. It can be reported under his full name of Sarmand Majeed.

4 Shortly before 4 o'clock in the morning on 14 April 2018 three men went to shop premises at 194
Lewisham High Road. The front door was protected by a shutter. Two of the men pulled the shutter up
sufficiently to allow the third man, Mr Majeed, to get inside the shop. He was in the shop for about 30
minutes. There was a section in the shop where mobile telephones were both on display and stored.
Having emptied a box of vegetables, Majeed moved around that section and filled the box with mobile
telephones and accessories. He then left the shop with what he had taken. The total value was around
£3,000.

5 The shopkeeper discovered what happened about 8.50 that morning. He had CCTV in his shop so he
was able to download a still from the footage which showed Mr Majeed. As well as informing the police the
shopkeeper sent a copy of the still to friends of his, who ran shops in and around Lewisham, just in case
any of them knew the person shown in the still. One of his friends, another shopkeeper, did recognise Mr
Majeed as someone he had seen before hanging around in Lewisham High Road.


-----

6 On 17 April 2018 Mr Majeed went into that man's shop and asked him to charge a laptop. The
shopkeeper immediately called the man whose shop had been burgled. By the time the burgled
shopkeeper had got to the other shop Mr Majeed had left, but within a few minutes he was seen in the
street. The police were called and he was arrested.  He had a significant amount of cash in his
possession. He was interviewed under caution. He was represented by a solicitor, and he provided a
prepared statement which read as follows:

"I was involved in this burglary but only because I was threatened and felt that I had no choice.

I suffer from mental health issues due to being tortured in Iraq. I'm always feeling paranoid and scared.

On the 13th of April I was approached by two males in Lewisham, one was a Kurdish male, the other was a
black male. I know of the Kurdish male he is a dangerous person. They told me to come with them. They
took me and showed me a phone shop. They said that they were going to break in and that I had to go in
and get phones for them. I said that, 'I didn't want to because I don't do this type of thing.' The black male
grabbed me around the throat. This was not too far away from the clock tower. They threatened to beat
me. They said that if I didn't go and get the phones then I have to get them three thousand pounds. I was
scared. I thought they were going to maybe stab me. They broke the shutters and told me to go in and get
items for them. I was not given any money or phones from the store, I wasn't given anything. The cash that
I had on me has nothing to do with the burglary. I receive two hundred and thirty pounds allowance from
Freedom from Torture. My paternal uncle gave me a hundred pounds and the rest I won from a bet on the
Liverpool v Man City game. The reason I was out so late is because I have difficulty sleeping due to my
mental health issues so I usually go out to pass the time unless it's raining. I do not know the black male. I
know of the Kurdish male but I'm too afraid to provide any details as I am afraid what might happen to me. I
do not believe that the police are able to protect me all the time. This is all that I have to say in connection
with this allegation."

He was asked further questions by the police to which he made no comment.

7 Mr Majeed was charged with burglary and sent for trial to the Crown Court sitting at Woolwich. At the
PTPH, His Honour Judge Kinch KC, noted the defence was duress. However, he put the defence on
notice that they should provide the Crown Prosecution Service with sufficient details to allow a referral to
be made under the National Referral Mechanism ("NRM") in relation to criminal exploitation. Mr Majeed
lodged a defence statement in July 2018. He said he had been forced to commit the burglary, as he had
explained in interview. He attached to his defence statement reports from a Dr Rachel Bingham, a General
Practitioner with experience in cases of torture, and someone called Linnet Lee, a Psychological Therapist
working for Freedom from Torture. In the defence statement this was said: "I anticipate these documents
will found a referral to the NCA." The National Crime Agency, of which NCA is an acronym, frequently is
the agency which makes a referral under the "NRM", but it does not itself adjudicate on claims of
exploitation. That is the function of the Single Competent Authority ("SCA"), which is part of the Home
Office.

8 In the event, Mr Majeed's case was referred under the NRM on 5 September 2018 by the Salvation
Army, probably at the behest of Freedom from Torture. The SCA made a positive reasonable grounds
decision, which is the first stage in the referral process, on 12 September 2018. Unfortunately, the
commendable speed with which that decision was made was not known to those representing the
applicant when his case was listed for trial on 12 September.  When the case first was called on there was
discussion between the Judge and counsel about the significance of the reports served with the defence
statement. It appears that the prosecution were given time to consider whether those reports might lead
the Crown Prosecution Service to decide that a prosecution was not in the public interest. It is apparent
that it was decided that the public interest did require a trial, since that is what happened, though we do not
have a transcript of that decision being announced in open court.

9 There was an application to adjourn the trial by the defence to allow them time to obtain what they called
"The Modern Slavery Certification". The application was refused. The enquiries made of the applicant's
legal team at the trial have revealed that they believed that "certification" was required in order to advance
a defence pursuant to section 45 of the Modern Slavery Act 2015 This belief was misconceived It is


-----

now clear that the decision of the SCA is not even admissible in the course of a trial: see _R v Brecani_

_[2021] EWCA Crim 731. What should have been clear to the applicant's legal team was that a defence_
under section 45 of the 2015 Act will depend on the relevant evidence from the defendant and other
sources which may include medical evidence. In the event, no such defence was raised in the course of
the trial. Rather, it was argued that the applicant was entitled to be acquitted because he had acted under
duress.

10 Mr Majeed's evidence at trial was broadly in line with what he had told the police in his prepared
statement. His evidence was that it was the black man who had been the man who had made the threats.
The jury were provided with an agreed fact which read as follows:

"Majeed was seen by Rachel Bingham, a GP at the Medical Foundation Medico Legal Report Service at
Freedom from Torture, on four occasions between November 2016 and January 2017. Dr Bingham
diagnosed him to be suffering from severe Post Traumatic Stress Disorder. He reported to her that he had
been subjected to and witnessed violence including beheadings whilst a prisoner of ISIS in Iraq."

In his evidence to the jury Mr Majeed developed that and explained that the area in which he lived in Iraq
had been taken over by ISIS. He did not know what had happened to his mother and brother who had
completely disappeared. They had been dragged away by ISIS. ISIS had killed somebody in front of him.
He had suffered a fracture to the leg as he tried to run away. He eventually did escape, but not until some
considerable time had passed.

11 The jury were directed in respect of the offence of duress which was the defence left to them. Certain
questions were posed:

"Were threats of serious injury made?

If there may have been, did Majeed act as he did because he genuinely and reasonably believed that if he
did not do so he would be seriously injured immediately or almost immediately?

If there may have been such a belief did Majeed have an opportunity to avoid the threats which a
reasonable person in his position would have taken?

If there may not have been such an opportunity, would a reasonable person of his age and sex, and with
his experiences in Iraq, have done what he did?

The jury were told that if they had got to the last question and the answer was "yes" or "maybe" then the
verdict would be 'not guilty'. The defence of duress was rejected by the jury after a relatively short
retirement.

12 On 12 October 2020, after reconsidering an earlier decision, the SCA issued a positive conclusive
grounds decision in respect of the applicant. The finding was that the applicant had been the victim of
"forced criminality in the United Kingdom on 17 April 2018." It is apparent that this was meant to be a
reference to "14 April 2018", namely the day of the burglary. The material relied on by the SCA essentially
was Mr Majeed's own account, whether in his written statements or in what he had said to Dr Bingham and
Linnet Lee. The decision set out his account in some detail. It did not refer to the evidence that he had
given on oath in the trial. It is apparent from the way in which the decision is set out that the account given
by Mr Majeed varied in relation to potentially important details depending on to whom he was speaking.

13 We summarise the factual matters set out in the decision as follows. Majeed indicated he had first met
the Kurdish man either in Dartford or, alternatively, in Catford. He was prone to go walking around in the
early hours of the morning. On the relevant day he walked to Lewisham. He had been approached by a
man called Sisse, the Kurdish man. That man had told Majeed that he was needed. There then had
arrived a black BMW containing two black men. The decision recorded two alternative accounts, one in
which one of the black men went into a casino, and one in which he did not. In either event, after Mr
Majeed had told Sisse that he did not want to do what Sisse wanted him to do, Sise became very angry
and threatened him. Someone had a knife in their pocket and was saying things in English that Mr Majeed
did not understand. Alternatively, Mr Majeed had said he had not seen a knife, but he thought that the
person did have one from the way he was going towards his pocket He was grabbed and told that if he


-----

did not do what was required of him, he would be beaten to death, and he would have to pay £3,000. It
was explained that Mr Majeed thought that, due to his previous sexual attacks by ISIS, he believed that he
might be subjected to a similar attack on the streets of Lewisham. He then explained how he had
committed the burglary, giving different accounts as to precisely how that had happened at different points.
He concluded by saying that his life had become a nightmare since that day. The criminal gang with whom
he had been associated were well-known and he had given a "no comment" interview through fear of
repercussions. As we have already observed he did not give a "no comment" interview in a strict sense of
the word.

14 The Single Competent Authority considered the proposition that Mr Majeed, when he was in Iraq, had
been a victim of modern slavery. Their conclusion was that he had not been a victim of modern slavery
at that point. The sole conclusion was, as we have already indicated, forced criminality on the day of the
burglary.

15 In our view, the Single Competent Authority decision as to the events in April 2017 was a prime
example of the kind of decision described in Brecani at [61]. It was based almost entirely on the untested
account given by the applicant to varying people, with no reference at all to other relevant material. It
certainly would not have been admissible in any trial. Mr Johnson, who represents the respondent today,
has confirmed it would not have led the Crown Prosecution Service to conclude that prosecution was not in
the public interest.

16 On 26 October 2022 Mr Majeed applied for leave to appeal against his conviction. He required an
extension of time in excess of four years. His applications have been referred to the full court because, on
the face of it, he was seeking to rely on fresh evidence. We do not consider we have any very satisfactory
explanation for the long delay. However, we shall not dwell on that point. What we shall do is consider the
merits of the proposed appeal. If the proposed appeal lacks merit, there will be no point in extending time.

17 The basis for the substantive application for leave is that Mr Majeed had a defence under section 45 of
the 2015 Act which was not put to the jury. That was not his doing. Thus, it is said that justice requires
that his conviction should be quashed. Although he served further evidence that was not available at the
trial, the principal evidence on which he seeks to rely is the evidence of Dr Bingham and Linnet Lee which
was available in September 2018. So, as has been conceded by Mr Newton KC today, this is not in reality
a fresh evidence case. Rather, this is a case in which a defence that was open to Mr Majeed at the time
was never put.

18 We do not propose to rehearse the substantial jurisprudence which has emerged in this court over the
last 10 years or more in relation to cases of modern slavery. Recently the relevant principles were set out
[in R v AAD & Ors [2022] EWCA Crim 106. It is not going to be of any benefit to anyone for us to revisit the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)
well-known principles. For us the simple question is whether the applicant, Mr Majeed, suffered an
injustice because his legal representatives failed to pursue the section 45 defence at trial. The evidence
upon which he now relies was available at trial. The jury heard his account of the events of 14 April 2018,
that account, and other material, being what is said to provide the basis for the conclusion that he was
criminally exploited.

19 The jury heard something of Dr Bingham's evidence by the agreed fact which we have set out, but the
jury did not hear further detail from Dr Bingham, or any evidence from Linnet Lee, because the applicant's
legal team did not consider it appropriate to call the evidence. Whether they in fact would have called the
evidence had a Modern Slavery Act defence been live is open to question.

20 Linnet Lee set out the applicant's account of his position in April and May 2018. That was evidence
which the appellant could have given. Indeed, in substantial measure he did give that evidence. She also
offered an opinion about the applicant having been exploited and coerced. That was an opinion which
would have been inadmissible. There was nothing in Dr Bingham's report which would have added
significantly to the agreed fact, which was already before the jury. As we have noted, Mr Majeed, in his
own evidence, amplified the position that had obtained when he was still in Iraq.


-----

21 The real issue for us is whether the evidence heard by the jury could have been sufficient for them to
conclude that a defence under section 45 was tenable. Section 45(1) reads as follows:

"(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act."

Just as it is for the prosecution to disprove the defence of duress once it is properly raised, so must the
prosecution disprove the defence in section 45(1).

22 Mr Newton argues, quite correctly, that the elements of the defence of duress are not the same as the
elements of a defence under section 45(1). However, on the facts of this case they do bear significant
similarities. The appellant's defence as left to the jury required them to find, as a possibility, that threats of
serious injury (or worse) had been made which led Mr Majeed to commit the burglary. The defence under
the Modern Slavery Act requires a jury to find as a possibility that the defendant was compelled to commit
the offence. As Mr Newton perfectly correctly concedes, on the facts of this case, the compulsion that was
exercised against the applicant was what the other two men had said by way of threats of serious injury.

23 The requirement that the compulsion was, or might have been, attributable to relevant exploitation selfevidently was not mirrored in the directions in respect of duress. That was something that the jury never
had to consider. However, as Mr Newton again concedes, the exploitation in this case was that single
episode which occurred in the early hours of 14 April. The factual background to that episode was left as
part and parcel of the defence which the jury had to consider. In our judgment, there is nothing in the
material relating to Mr Majeed's history in Iraq which could have had any sensible bearing on what
happened in Lewisham. Subsection 1(c) of section 45 of the 2015 Act requires relevant exploitation which
has a statutory meaning. We doubt very much whether there was any evidence sufficient to bring the
applicant's case within section 45 (1)(c).

24 The prosecution undoubtedly proved that, even if the applicant might have done what he did because
of believable threats of serious injury, a reasonable person of the applicant's age and sex, and with his
experiences in Iraq would not have done what the applicant did. In our judgment, there is no sensible
distinction to be drawn between that finding and a conclusion that a reasonable person in the applicant's
position would not have had a realistic alternative to committing the offence, namely the test in section
45(1)(d).

25 It follows that on the facts of this case the jury determined the factual issues which would have arisen
had they been asked to consider the defence in the 2015 Act. The jury rejected his account in respect of
those factual issues. This case is very different from the many instances to be found in previous appeals
before this court, where the defendant pleaded guilty when they might have had a defence under the 2015
Act, or where the factual issues that would otherwise have arisen when considering such a defence were
never examined during the trial. Given the course of the trial in this case, we are satisfied that the defence
under the 2015 Act inevitably would have been rejected. It follows, therefore, that the applicant's
conviction cannot be regarded even as arguably unsafe.

26 In those circumstances we refuse to extend time and all other applications made are refused.

_______________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**


-----

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

