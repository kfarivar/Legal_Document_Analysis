# Kajeepaan and others v Been, Director of Immigration and another [2021] 3
 LRC 270

SUPREME COURT OF THE TURKS AND CAICOS ISLANDSCOURT OF APPEAL OF THE TURKS AND CAICOS
ISLANDS

AGYEMANG CJ

MOTTLEY P, JOHN AND WINDER JJA

1 MAY 202022–24 SEPTEMBER, 2, 9 OCTOBER, 31 DECEMBER 2020

**Habeas corpus — Immigration — Detention pending deportation — Criminal investigation into people**
**trafficking — Delay in investigation due to language barrier and need for translation — Delay in repatriation**
**due to COVID-19 travel restrictions — Whether detention lawful — Grant of refugee status — Whether**
**appeal academic following release of detainees — Entitlement to raise substantial constitutional claims on**
**appeal — Constitution of the Turks and Caicos Islands 2011, s 21 — Immigration Ordinance ss 54(3), 56(4).**

On 10 October 2019 the Royal Turks and Caicos Islands Police Force ('the RTCIPF') intercepted a Haitian sloop in
the territorial waters of the Turks and Caicos Islands. There were 154 passengers on board including 1 Indian and
28 Sri Lankan nationals. Amongst the 28 Sri Lankan nationals were the three appellants. Investigations were
complicated by the language barrier, since the Sri Lankans spoke only Tamil and comprehensive investigations
needed to take place to determine whether the detainees were victims of human trafficking. The Immigration
Enforcement Unit was assisted by the RTCIPF and the Serious Crime Investigation Agency in the UK, involvement
of the latter required significant funding which had to be approved by the Governor in Cabinet. It was two months
after the initial detention that interviews with the detainees commenced following the arrival of UK based
investigators and interpreters. The investigation concluded that the detainees were victims of human trafficking and
the main suspect was identified. Six other detainees were identified as potential witnesses in the criminal
proceedings. The remaining detainees, including the three appellants were to be repatriated. Voluntary Departure
Forms were provided to the detainees but the three appellants refused to sign them claiming that they did not wish

**[*271]**

to return to Sri Lanka for fear of what might happen to them upon return. The declaration of the COVID-19 virus as
an international pandemic by the World Health Organisation and the subsequent closure of borders delayed the
proposed repatriation of the detainees. A writ of habeas corpus was issued on 20 April 2020, returnable on 24 April
2020 when the detainees were brought before the court. Due to social distancing requirements only five persons
could be safely in the hearing room at one time so none of the detainees could be in the room for the entirety of the
hearing. It only became apparent while the Director of Immigration, Derek Been, gave his evidence that Notice of
Intention to Make a Deportation Order had been given. That order had been made without the detainees being
interviewed by an official with knowledge and experience of asylum applications. At the conclusion of the hearing
Agyemang CJ held that the delay of six months in effecting repatriation was not unreasonable in the particular
circumstances of the COVID-19 pandemic. Therefore, the delay in removing the applicants from the Turks and
Caicos Islands did not affect the legality of the detention for the purposes of ss 54(3) and 56(4) of the Immigration
Ordinance. The application to release the detainees or relocate them into residential accommodation was
dismissed. The United Nations Human Rights Commissioner for Refugees ('the UNHRC') subsequently interviewed
and assessed the detainees and found them to be genuine refugees entitled to proper humanitarian care and they
ere registered as s ch The UNHRC req ested their release All of the detainees ere conditionall released on


-----

24 August 2020 after 320 days in detention. The detainees appealed the decision as to the lawfulness of their
detention and complained about the procedures followed during their detention and the hearing of the Writ of
Habeas Corpus. They further sought to bring Substantial Constitutional Claims regarding their detention and
payment of compensation.

**HELD: Appeal allowed.**

(Winder JA (John JA concurring (Mottley P dissenting))) (1) While the release of the detainees was the primary
relief in the Habeas Corpus application, the substantive claim was that the detention was unlawful. Vindication of
that fundamental right was not a mere academic pursuit. Further, the detainees sought to pursue a claim for
compensation for unlawful detention which represented an outstanding matter for which the court was required to
decide. A determination in their favour would also undoubtedly affect their entitlement to costs in the proceedings
below which included the costs of translation services. The terms of their releases were conditional. That suggested
that the issue of lawfulness of the detention may remain an issue which ought to be resolved since it could stand as
a safeguard to further detention. Even if the court had considered the appeal to be academic it would be an
appropriate case for the exercise of the court's discretion to hear it (see [24]–[36], below); R (on the application of
_AA (Sudan)) v Secretary of State for the Home Dept_ _[[2014] All ER (D) 220 (Jun) and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CJG-0GJ1-DYBP-N3TF-00000-00&context=1519360)_ _Hutcheson v Popdog Ltd_
_(News Group Newspapers Ltd, third party)_ _[[2012] 2 All ER 711 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55M4-GCV1-DYBP-M2YC-00000-00&context=1519360)_

**[*272]**

(2) The settled legal principles relative to the power to detain had been offended by the respondent in this case in
that: (i) the power to detain was not used for immigration-related examination, for which it was designed, but was
actually used to investigate the criminal offences; (ii) the period of time for which the appellants were detained was
not reasonable in the circumstances as these were not criminals but vulnerable adults seeking refuge; (iii) there
were barriers to any removal of the appellants and therefore no purpose in properly detaining them while those
barriers existed and no prospect of imminent removal; and (iv) no due diligence or expedition was demonstrated by
the immigration authorities in discharging their responsibilities under the Immigration Ordinance (see [39], [54],
[below); R v Governor of Durham Prison, ex p Singh [1984] 1 All ER 983 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)

(3) The law set out in the Immigration Ordinance provided that the immigration officer was empowered to detain the
detainees on 10 October 2019 upon their entry, by ship, for the purpose of examining them for the purpose of
establishing whether they should be given leave and for what period and on what conditions (if any), or should be
refused leave. The immigration officer could also detain them pending the decision to give or refuse them leave to
enter (see [44], below).

(4) Pursuant to the Turks & Caicos Ministry of Border Control and Labour Operations Manual any person who
expressed a fear of persecution in their country should be interviewed by an official who had knowledge and
experience of interviewing asylum applicants. The evidence was incontrovertible that the detainees were not
detained for immigration purposes but for criminal purposes beyond 10 October 2019. It was clear when the
investigations concluded that there had been no examination of the detainees in respect of their immigration
position. Their detention up to 7 February 2020 when the investigation was concluded was therefore, not for the
lawful purposes provided under the Immigration Ordinance. They had not been interviewed by an immigration
officer as set out under s 54 which formed the basis upon which detainment was permitted (see [45]–[47], below).

(5) Had an examination been conducted by an official with knowledge and experience of interviewing asylum
applicants, it would have been revealed, given the abundance of indications, that the detainees were likely to be
refugees and as such, were not immediately returnable to Sri Lanka. Putting aside the delays in securing the
services of Tamil interpreters the failure to examine the detainees for immigration purposes beyond the arrival of
interpreters in December 2019 was unreasonable and inexcusable (see [48], [49], [53], below).

(6) The requirements of ss 5(3) and 5(4) of the Constitution of the Turks and Caicos Islands, namely, notifying the
detainee of the reasons for the detention in a language that they understood, and the right to instruct a legal
representative, had not been complied with. Those breaches when exercising a discretionary power to detain,


-----

rendered the subsequent detention unlawful (see [50]–[52], below); R (on the application of Lumba) v Secretary of
_[State for the Home Dept, R (on the application of Mighty) v Secretary of State for the Home Dept [2011] 4 All ER 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_
applied.

**[*273]**

(7) The applications for Substantial Constitutional Claims were refused: (i) Habeas Corpus applications were
discrete specialised applications which were not conflated with other relief or constitutional claims. Freestanding
constitutional relief was generally pursued by a separate action in the court below; (ii) even if the claims were made
out they would need to be remitted to the Supreme Court for assessment. There was no prejudice to the appellants
to have to commence a new claim for relief for the unlawful detention; (iii) having been released and it having been
determined that the detention was unlawful, the only benefit to the appellants in adding the Substantive
Constitutional Claims was compensation for unlawful detention. That was akin to false imprisonment for which there
was an adequate remedy available under the common law. Section 21(2) of the Constitution prohibited the court
from considering claims for breaches of fundamental rights if it was satisfied that adequate means of redress were
available under any other law (see [63], below).

(8) The learned judge could hardly be faulted for proceeding with the hearing notwithstanding the
objections/complaints of counsel for the appellants regarding the less than ideal restrictions that had to be put in
place due to the COVID 19 restrictions. In any event having determined that the detention was unlawful, any
detailed interrogation of the procedural fairness was essentially rendered otiose (see [65], below).

(7) Accordingly, the appeal would be allowed; the decision of the Chief Justice would be set aside; and a
declaration that at the time of the hearing of the writ of habeas corpus the detainees were being unlawfully detained
would be granted (see [66], below).

**Observed: (Mottley P) (i) Since the writ of habeas corpus is not a proceeding in suit but a summary application by**
the person detained, and the appellants were no longer in custody, they were not entitled to pursue the writ of
Habeas Corpus to issue. The release of the appellants from custody meant that there was no live issue between
the appellants and the Director of Immigration and, therefore, the appeal would be academic (see [45]–[48], below).

(ii) Taking into account the evidence of the police and the Director of Immigration as to the difficulties they
encountered with the arrival of the detainees it could not be said that the Chief Justice was incorrect in reaching her
decision that the detention was lawful. Even after the declaration as to the status of the detainees as refugees, the
delay of one month was not an unreasonable period of detention (see [65], [72], below).

(iii) An appellant is entitled to raise in an appeal, the fact that his rights as guaranteed under the Constitution have
been infringed or breached and, as such he was deprived of the protection of the law leading to him not having a
fair trial. While that issue may be determined on appeal and the issue of infringement of the constitutional rights
may be taken for the first time during the course of the appeal, that did not infringe the provisions of s 21 of the
Constitution as he is not seeking to bring an action in which he is seeking redress against the person who infringed
his rights (see [87], below).

**[*274]**
**Cases referred to**

_[Abdi v Secretary of State for the Home Dept [1996] 1 All ER 641, [1996] 1 WLR 298, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61BM-00000-00&context=1519360)_

_A-G (at the Relation of Tamworth Corp) v Birmingham, Tame and Rea District Drainage Board_ _[[1912] AC 788,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)_

_[[1911–13] All ER Rep 926, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)_

_[A-G for the Dominion of Canada v Cain, A-G for the Dominion of Canada v Gilhula [1906] AC 542, [1904–7] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-214V-00000-00&context=1519360)_
_[Rep 582, Can PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-214V-00000-00&context=1519360)_

_[A-G v Whiteman [1991] LRC (Const) 536, [1991] 2 AC 240, (1991) 39 WIR 397, [1991] 2 WLR 1200, T & T PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KP9-CMW1-DYJ0-84JR-00000-00&context=1519360)_


-----

_[Ainsbury v Millington [1987] 1 All ER 929, [1987] 1 WLR 379n, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60TC-00000-00&context=1519360)_

_Bethel v Jean-Charles (SCCivApp No 26 of 2018) (17 October 2018), Bah CA._

_[Bowe v R [2006] UKPC 10, [2006] 4 LRC 241, [2006] 1 WLR 1623, (2006) 68 WIR 10, (2006) 21 BHRC 43, Bah](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84MJ-00000-00&context=1519360)_
PC.

_[Bradberry, Re, National Provincial Bank Ltd v Bradberry, Re Fry, Tasker v Gulliford [1942] 2 All ER 629, [1943] Ch](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-605T-00000-00&context=1519360)_
35.

_[Bwllfa and Merthyr Dare Steam Collieries (1891) Ltd v Pontypridd Waterworks Co [1903] AC 426, [1900–03] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDK0-TWXJ-212M-00000-00&context=1519360)_
_[Rep 600, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDK0-TWXJ-212M-00000-00&context=1519360)_

_Chijioke v COP of Saint Vincent and the Grenadines (SVGHCV 232/2010)._

_Chokolingo v A-G (1980) 32 WIR 354, T & T PC._

_Coe v Governor [2014] (2) CILR 465, Cay Is CA._

_Cox v Hakes (1890) 15 App Cas 506._

_[Curwen v James [1963] 2 All ER 619, [1963] 1 WLR 748, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-60WR-00000-00&context=1519360)_

_[Gawler v Raettig [2007] EWCA Civ 1560, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54J2-CR51-F0JY-C4HX-00000-00&context=1519360)_

_Governor of the Turks and Caicos Islands v Proprietors, Strata Plan 108 (CL 38/15), Turks & Caicos CA._

_[Greene v Secretary of State for Home Affairs [1941] 3 All ER 388, [1942] AC 284, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60Y1-00000-00&context=1519360)_

_[Hunte v State [2015] UKPC 33, [2016] 1 LRC 116, (2015) 40 BHRC 633, T & T PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J3S-T981-DYJ0-80W3-00000-00&context=1519360)_

_Hutcheson v Popdog Ltd_ _[[2011] EWCA Civ 1580, [2012] 2 All ER 711, [2012] 1 WLR 782, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55M4-GCV1-DYBP-M2YC-00000-00&context=1519360)_

_[Independent Publishing Co Ltd v A-G, Trinidad and Tobago News Centre Ltd v A-G [2004] UKPC 26, [2005] 1 LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-82RX-00000-00&context=1519360)_
_[222, [2005] 1 AC 190, (2004) 65 WIR 338, [2004] 3 WLR 611, T & T PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-82RX-00000-00&context=1519360)_

_Jockey Club v Buffham_ _[[2002] EWHC 1866 (QB), [2003] QB 462, [2003] 2 WLR 178, UK QBD.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JW41-DYBP-N2H6-00000-00&context=1519360)_

_[Khawaja v Secretary of State for the Home Dept [1983] 1 All ER 765, [1984] AC 74, [1983] 2 WLR 321, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-61BN-00000-00&context=1519360)_

_[Ladd v Marshall [1954] 3 All ER 745, [1954] 1 WLR 1489, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP40-TWP1-61FC-00000-00&context=1519360)_

_[Murphy v Stone Wallwork (Charlton) Ltd [1969] 2 All ER 949, [1969] 1 WLR 1023, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35T0-TWP1-6145-00000-00&context=1519360)_

_Ogle Airport Inc v Competition and Consumer Affairs Commission [2020] CCJ 19 (AJ) GY, CCJ._

_Pigott v R (ANUCRAP2009/0009) (13 April 2015) [2015] ECSCJ No 80, ECSC CA._

_R (C) v London South and West Region Mental Health Review Tribunal [2001]_

**[*275]**

[EWCA Civ 1110, [2002] 1 WLR 176, [2002] 2 FCR 181, [2001] All ER (D) 24 (Jul), UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JT01-DYBP-N0TD-00000-00&context=1519360)

_R (I) v Secretary of State for the Home Dept_ _[2002] EWCA Civ 888, [2003] INLR 196, UK CA._


-----

_[R (on the application of A) v Secretary of State for the Home Dept [2007] EWCA Civ 804, [2007] All ER (D) 467](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N0RV-00000-00&context=1519360)_
_[(Jul), (2007) Times, 5 September, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N0RV-00000-00&context=1519360)_

_[R (on the application of AA (Sudan)) v Secretary of State for the Home Dept [2014] EWHC 2118 (Admin), [2014] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CJG-0GJ1-DYBP-N3TF-00000-00&context=1519360)_
_[ER (D) 220 (Jun), UK Admin Ct.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CJG-0GJ1-DYBP-N3TF-00000-00&context=1519360)_

_[R (on the application of HY) v Secretary of State for the Home Dept [2010] EWHC 1678 (Admin), [2010] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YWF-5BG0-YBF6-70WB-00000-00&context=1519360)_
_[32 (Apr), UK Admin Ct.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y7G-SM60-Y96Y-H210-00000-00&context=1519360)_

_[R (on the application of Khadir) v Secretary of State for the Home Dept [2005] UKHL 39, [2005] 4 All ER 114, [2006]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4H7S-JMY0-TWP1-61NH-00000-00&context=1519360)_
1 AC 207, [2005] INLR 538, [2005] 3 WLR 1, UK HL.

_R (on the application of Lumba) v Secretary of State for the Home Dept, R (on the application of Mighty) v Secretary_
_[of State for the Home Dept [2011] UKSC 12, [2011] 4 All ER 1, [2012] AC 245, [2011] 2 WLR 671, UK SC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_

_[R (on the application of Saadi) v Secretary of State for the Home Dept [2002] UKHL 41, [2002] 4 All ER 785, [2002]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6025-00000-00&context=1519360)_
1 WLR 3131, [2002] INLR 523, UK HL.

_[R v Birmingham City Juvenile Court, ex p Birmingham City Council [1988] 1 All ER 683, [1988] 1 WLR 337, [1988] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60FS-00000-00&context=1519360)_
_[FLR 424, [1988] FCR 175, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G1HN-00000-00&context=1519360)_

_R v Governor of Durham Prison, ex p Singh_ _[[1984] 1 All ER 983, [1984] 1 WLR 704, UK QBD.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)_

_R v Secretary of State for the Home Dept ex p Cheblak_ _[[1991] 2 All ER 319, [1991] 1 WLR 890, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-61K9-00000-00&context=1519360)_

_[R v Secretary of State for the Home Dept, ex p Salem [1999] 2 All ER 42, [1999] AC 450, [1999] 2 WLR 483, UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61HF-00000-00&context=1519360)_
HL.

_Ramesh Lawrence Maharaj v A-G of Trinidad and Tobago (No 2) (1978) 30 WIR 310, T & T PC._

_[Sun Life Assurance Co v Jervis [1944] 1 All ER 469, [1944] AC 111, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP70-TWP1-600N-00000-00&context=1519360)_

_[Tan Te Lam v Superintendent of Tai A Chau Detention Centre [1996] 2 LRC 360, [1997] AC 97, [1996] 4 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-850J-00000-00&context=1519360)_
_[256, [1996] 2 WLR 863, HK PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-605P-00000-00&context=1519360)_

_Trinidad and Tobago A-G v Trinidad and Tobago Civil Rights Association (Civil Appeal No 149 of 2005), T & T CA._

_[Walker v R [1993] 2 LRC 371, [1994] 2 AC 36, Jam PC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82H5-00000-00&context=1519360)_

_Watson's Case (1839) 9 Ad & El 731._

_Ya'axché Conservation Trust v Sabido (Chief Forest Officer) [2014] CCJ 14 (AJ), (2014) 85 WIR 264, CCJ._
**Legislation referred toJamaica**

Constitution of Jamaica 1962.
_Trinidad and Tobago_

Constitution of the Republic of Trinidad and Tobago 1976.

Offences Against the Person Act 1925.

**[*276]**
_Turks and Caicos Islands_

Constitution of the Turks and Caicos Islands 2011.


-----

Emergency Powers (COVID-19) (Amendment) Regulations 2020, (LN 18 of 2020).

Emergency Powers (COVID-19) (No 3) Regulations 2020.

Evidence Ordinance Cap 2:06.

Immigration Ordinance Cap 5.01.

Rules of the Supreme Court 2000.
_United Kingdom_

Fatal Accidents Act 1846.

_[Immigration Act 1971.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

Rules of the Supreme Court (RSC).
**Other sources referred to**

European Convention on Human Rights and Fundamental Freedoms 1950.

_Halsbury Laws of England._

_Oppenheim's International Law (8th edn)._

_Turks & Caicos Ministry of Border Control and Labour Operations Manual._

Vattel Law of Nations.
**Application**

Following an application on behalf of the applicants, Kabilraj Balasundram, Paintamilkavalan Kajeepan, Jeyaseelan
Kumarlingam, Karunakaran Makenthiran Mahendran, Thangauadeual Mailuaganam, Mailvaganam Thangawadevel,
Krisnakumar Nagarathnam, Pratheepan Sadha Nirmaladhasan, Pankajbhaipatel Chiragkumar L, Kohulan
Paramathurai, Parasath Premathansan, Varatharaj Rasaratnam, Gajendran Selvajeyam, Jeseepan Swapalan
Sivapalan and Nathusan Suresan, Simons J (Ag) made an order for a writ of habeas corpus ad subjiciendum
issued on 20 April 2020 directing the first respondent, Derek Been, Director of Immigration, to produce the
applicants before the court. The instant proceeding was the return date. The Attorney General was the second
respondent. The facts are set out in the judgment.

_Tim Prudhoe of Prudhoe Caribbean for the applicants._

_Clemar Hippolyte of Attorney General's Chambers for the respondents._

1 May 2020. The following judgment was delivered.

**AGYEMANG CJ.**

On 31st March 2020, Simons J (Ag) made an order for a writ of habeas corpus ad subjiciendum to issue, returnable
on the 24th of April 2020, and directed at the first respondent herein, to release the applicants herein and then to
produce them before this court. The order contained directions for pretrial

**[*277]**

matters before the return date. The order followed an application made on behalf of the applicants herein under Ord
54 r 3 of the Rules of the Supreme Court 2000 by learned counsel for the applicants: Mr Prudhoe.

The affidavits in support of the application were sworn to by Mr Mikhail Charles, who described himself as a
Litigation Paralegal but explained that he was in fact an attorney admitted to practice in the UK and his native St


-----

Vincent and The Grenadines as well as other jurisdictions within the region; thus, he understood the weighty matter
of making assertions under oath.
**Before Simons J (Ag)**

In the application aforesaid, the respondents inter alia, challenged the bringing of the application by a third party on
behalf of the applicants as well as the legal standing of Mr Prudhoe to bring an application in respect of all fifteen
applicants. This was because on learned counsel's own showing, only three of the fifteen had had his services
retained for them.

In its ruling, the court made a two-pronged ruling in favour of the applicants – upholding the argument made on their
behalf in response to the said objections – that learned counsel (Mr Prudhoe) was entitled to bring the application
on their behalf as they were allegedly held incommunicado and were therefore not in a position to bring their
application themselves, and furthermore, that learned counsel Mr Prudhoe was entitled to represent all the fifteen
applicants. The court reasoned thus: '… I am persuaded by paras 25 to 27 of Mr Prudhoe's Skeleton Argument and
_am satisfied that in respect of these three Applicants at least, there is sufficient reason to believe that they wish to_
_but are unable to make the required affidavits themselves, within the meaning of the Rule. I also agree with Mr_
_Prudhoe's suggestion that if the Writ is to run for these three, it must run for all.'_

The writ as ordered, was duly issued and served along with the requisite notice in accordance with, Ord 54 r 6(4) of
the Rules of the Supreme Court 2000 on the first respondent.

The second respondent the legal representative of the first respondent appeared for the first respondent, and for
the second respondent, the nominal respondent.
**The Facts – Applicants' case:**

The matters antecedent to the bringing of the instant application are contained in six affidavits deposed to by the
said Mikhail Charles, Litigation Paralegal of the office of Prudhoe Caribbean. In the first of these affidavits which
supported the initial application before Simons J (Ag), the deponent alleged the following: that as a result of his
work in the law firm of Prudhoe Caribbean on behalf of one Chelliah who had been arraigned on charges in
connection with immigration offences including human smuggling, it had come to his notice that twenty-nine Sri
Lankan nationals had been detained since the 10th of October 2019 at the Immigration Detention Centre (IDC),
where they were under the control of the Department of Immigration and Border Control through the first
respondent, its Director.

**[*278]**

He deposed further that during a hearing on a _habeas corpus application in respect of the detention of one_
Ariyaputhuram, Ravikkumar, a Sri Lankan national, it was alleged by the respondents therein that the said applicant
had declined legal advice. The respondents allegedly produced as evidence in support of such declining of legal
advice, forms described as Voluntary Departure Forms (Form IS 101) apparently signed by fifteen detainees at the
detention facility. It was this circumstance that prompted learned counsel (Mr Prudhoe) to request a visit to the
facility to see the said detainees. The request did not yield the desired result for no such access was granted to him
as counsel.

It was further deposed on behalf of the applicants that despite the claims made in open court regarding efforts of a
prompt repatriation of the detained Sri Lankans (including the applicants), no such repatriation had been effected.
Furthermore, that no explanation had been given by the respondents as to the legality of the ongoing detention, but
rather, that the first respondent in an email response to learned counsel's enquiries, simply detailed logistical
difficulties in respect of repatriating any of the Sri Lankan detainees.

In the subsequent affidavits, the same deponent averred on behalf of the applicants, that following the notice of
motion that was filed pursuant to the order of the court, it was communicated to learned counsel that three of the
fifteen detained persons, (the second, twelfth and the fourteenth applicants) had requested legal advice. The
deponent averred that the chronology of events indicated that the said requests had been made within an hour of
learned counsel's request for access to all the applicants. Subsequently, the second applicant's sister, the wife of


-----

the twelfth applicant, the mother of the fourteenth applicant, the father of the fifteenth applicant and the wife of the
eleventh applicant made contact with learned counsel asking him to represent the said applicants. Emails
containing the requests for representation were exhibited in respect of the first three. None was shown in respect of
the eleventh applicant, however. According to the deponent, the detaining authority while refusing learned counsel
physical access to the applicants, offered him telephone access which by reason of the applicants' inability to
communicate in English, was rendered pointless because of the departure of Tamil interpreters from the Turks and
Caicos Islands. Even so, that learned counsel had made strenuous efforts to secure the services of a Tamil
translator through whom communication had been made with the second, twelfth and fourteenth applicants. In that
lawyer-client communication, the said applicants were said to have echoed one another in stating these: that they
wanted present learned counsel Mr Prudhoe to represent them; that they did not wish to return to Sri Lanka as they
believed their lives to be in danger there; that they wished to be physically present at the hearing of the application;
that their religious and cultural beliefs as Tamil Hindus were flouted at the detention centre, and that their nutrition
was inadequate (as they were only given bowls of salad or bread as their main meals). The twelfth applicant is
alleged to have stated also that he wished to leave the detention facility because of overcrowding, poor food, lack of
medical care, and the flouting of his religious and cultural beliefs. The fourteenth applicant allegedly stated further
that he was concerned for his mental state if he

**[*279]**

remained at the detention centre and also, that his human rights were not protected at the detention facility. The
second applicant also added that he had become suicidal and that more of the applicants wanted to be represented
by learned counsel.

All of this was to say, that the detainees had been held at the detention centre in conditions that were poor, with no
access to legal advice that at least three of them had requested for.
**Respondents' Case:**

The application was vehemently opposed by the respondents. The first respondent had apparently been
misinformed that the instant application was consolidated with another application: CL 33/20. He therefore filed two
affidavits both of which were said to supplement what had been deposed to in the earlier matter. Another person
(the Assistant Director of Immigration, in charge of the detention facility: Mr Peter Parker) also, labouring under a
similar misapprehension, filed two supporting affidavits also expressed to be supplementary to what was filed in that
prior application.

This circumstance is unfortunate, as no order for consolidation was made by the court. It is my view that as the said
affidavits are not before the court, it will be improper in the determination of the instant application to consider the
said affidavits filed in a different application. I derive some comfort in holding thus as in my view, the respondents'
affidavits filed in support of this application as supplemented by the oral evidence of the first respondent, sufficiently
respond to the matters raised in the applicants' affidavits.

It was the response of the respondents, as contained in their affidavits filed by and on behalf of the first respondent,
that on 10th of October 2019, Immigration officials intercepted a Haitian sloop in Turks and Caicos Islands waters
on which were found among others, twenty-nine Sri Lankan nationals. The present applicants were among the
number. The applicants are therefore illegal immigrants to the Turks and Caicos Islands.

It is the case of the first respondent as contained in his affidavits and as supported by the affidavits of Mr Peter
Parker, that the said illegal Sri Lankan immigrants were detained pending repatriation from the Turks and Caicos
Islands.

In this regard it was deposed that several efforts had been made to effect the repatriation. These efforts included
(per Mr Parker), a preliminary investigation by himself, as supported by investigations of UK counterparts, to ensure
that it was safe to repatriate the detainees to Sri Lanka without fear of human rights abuses. The preliminary efforts
were said to have been followed by travel arrangements with various entities including Inter-Caribbean Airlines who
gave a quotation for the best route which would permit a transit through other countries (preferably Greece where
there would be no fourteen day period of quarantine) to Sri Lanka The efforts of the first respondent were said to


-----

be complemented by that of the International Organization for Migration: IOM-UN Migration (referred to simply as
IOM) in the logistics and the implementation of the removal agendum which included medical screening as well as
screening for

**[*280]**

information on the detainees. The first respondent deposed that the considerable expense involved to effect the
repatriation had been placed before the National Security Council and the Appropriations Committee of the House
of Assembly for monies to be provided.

These efforts to effect repatriation, which were robust, it was deposed, have been gravely hampered by the COVID19 pandemic which has led to the interdiction of international flights not only in Turks and Caicos Islands, but also in
Sri Lanka. More particularly, the first respondent deposed that on the 12th of April 2020, he received
communication from IOM that the interdiction of inbound flights into Sri Lanka's airports imposed by reason of the
COVID-19 pandemic, had been extended from 7th to 21st April 2020, with a possibility of further extension.

Despite these set-backs, the first respondent indicated that the IOM, through its Chief of Party (Sri Lanka), was
engaging with the Sri Lankan Government on behalf of Turks and Caicos Islands to permit for humanitarian
reasons, an inbound flight for the repatriation of the detainees, including the applicants.

It was the case of the first respondent per oral evidence (which somewhat altered the affidavit evidence), that while
repatriation was the course adopted for all the applicants requesting voluntary repatriation, the repatriation would be
staggered for the following reasons: that while all the applicants save three: (the second, twelfth and fourteenth
applicants) had signed Voluntary Departure Forms (IS101), six of them were needed on the Islands as prosecution
witnesses in the case against one of the twenty-nine Sri Lankans intercepted: one Srikajanukan Chelliah. These six
potential prosecution witnesses, it was deposed and repeated in oral testimony, had informed the authorities that
they would wish to be repatriated (voluntarily) after they were done with their testimony as prosecution witnesses.
With respect to these, the Royal Turks and Caicos Islands Police Force had allegedly expressed an intention to
place them in their witness protection programme. With regard to the three applicants who had refused voluntary
repatriation, he averred in oral testimony that administrative arrangements were under way to deport them. The
remaining applicants would, in accordance with their wishes (expressed by the execution of the IS101 Forms in the
presence of a witness) be repatriated as soon as Sri Lankan authorities gave the go-ahead for the in-bound flight to
access its airport.

It was also the case of the respondents that the applicants were detained in proper and healthy conditions in
accordance with the Operational Guidance Manual of the Ministry of Border Control and Labour which was
exhibited in this court. In this regard, the said Peter Parker deposed that to accommodate the social distancing
protocols in place by **Emergency Powers (COVID-19) (Amendment) Regulations 2020, (LN 18 of 2020) the**
detainees (including the applicants) were kept from overcrowding, even during recreational times. Alternative places
of detention he stated, were being located to enable the Immigration authorities to detain illegal immigrants without
compromising their health during the COVID-19 pandemic. He further deposed that the detainees (including the
instant applicants) were kept in cells which were reasonably sized, ranging from 17 by 17 feet, 211/2 feet by 161/2
feet, 181/2

**[*281]**

feet by 11 feet and 16 by 161/2 feet, and able to take twenty detainees. He stated also that all detainees were
supplied with necessary toiletries as well as given access to alcohol-based hand sanitizers in secure settings, they
were well fed with three meals a day supplied by an outside restaurant with provision made for special diet needs
that were brought to their attention, and given medical screening and assessment by doctors and nurses provided
by the Ministry of Health. He averred that none had exhibited signs of mental ill-health or any suicidal tendencies
which state would have been communicated to the authorities, as one of the detainees communicates in English
and has been used to communicate with the rest. Besides this, he deposed, the authorities had received no report
of malnutrition, depression, or threats of suicide from doctors who visit frequently (weekly). He further stated that


-----

the care of the detainees (including the applicants) was supervised by the watchful eyes of the Human Rights
Commission in its regular visits to the facility.

With regard to access to communication, he deposed that by reason of the restriction placed on personal visitation
at the material time by the **Emergency Powers (COVID-19) (Amendment) Regulations 2020, telephone calls**
which had local call capacity were offered to the detainees. However, since that was of little use to detainees who
were new to the Islands, detainees were given access to Whatsapp by the Police and Tamil translators on their
personal telephones to enable them to reach relations abroad, to give them the detentions centre's telephone
numbers to call them on.

Acting Superintendent of Police Mr Willet Harvey also deposed in an affidavit that the Police had become involved
in the case involving the interception of the Haitian sloop which carried a number of Sri Lankan nationals including
the applicants. They were illegal immigrants. He detailed his involvement in criminal investigation of one of the
persons: Srikajamukan Chelliah, a Canadian of Sri Lankan descent who having been convicted of Alien Smuggling
in 2003 in the USA, was suspected to be involved in the offence of human trafficking in the instant matter. It was his
evidence that the investigation involved several criminal investigative bodies and agencies in and outside Turks and
Caicos Islands and that some of the detainees were witnesses in that investigation. Of these, one of them who
spoke English had had his statement taken in English. The remaining detainees allegedly declined access to legal
advice having been informed of their right which was communicated to them by a Tamil translator. Their statements
for the criminal investigation was written down in Tamil and translated into English. These six witnesses were due to
be provided with witness protection facilities, a course of action that had been found to be necessary because they
seemed to have a real fear for their safety back in Sri Lanka due to threats made on their families by reason of the
evidence they were to give in the criminal investigation against Chelliah.

Further affidavit evidence in support of the respondents' case was provided by the Chief Medical Director/Director
of Health Services of the Turks and Caicos Islands: Dr Nadia Astwood who deposed to the efforts made by the
Ministry of Health to curb or combat COVID-19 in the Turks and Caicos Islands as well as rigorous efforts to
monitor the health needs of the detainees

**[*282]**

through regular visits made by a team of doctors and nurses to the facility. She deposed that there was to date, no
COVID-19 infection at the detention centre. Having regard to the measures put in place by the Ministry of Health to
combat the spread of the COVID-19 disease, she made the following recommendation: 'At the moment, we are not
_recommending the release of immigrants outside of direct and immediate removal of the detainees from the Turks_
_and Caicos Islands'._

In my considered opinion, this application raises the following issues for the determination of the court.
_ISSUES:_

1. Whether or not the detention of the applicants was according to law.

2. Whether or not the delay in repatriation has affected the legality of the applicants' detention.

3. Whether or not the applicants are entitled to the relief sought by this application.

In my consideration of these weighty issues (which shall be considered seriatim), I shall have recourse to the
arguments made by counsel on both sides contained in skeleton arguments as expatiated by oral submissions
during the hearing of the application.

I must commend learned counsel on both sides for their industry in research and their resourcefulness in the
application of seminal judgments that throw light on the matters to be considered in the instant application.

As a starting point, I must say that I consider insightful, the dictum of Lord Donaldson MR in one of the cases cited
for my persuasion: R v Secretary of State for the Home Dept ex p Cheblak _[[1991] 2 All ER 319 at 322–323, [1991] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-61K9-00000-00&context=1519360)_
WLR 890 at 894: _'A writ of habeas corpus will issue where someone is detained without any authority or the_
_purported authority is beyond the powers of the person authorising the detention and so is unlawful'_


-----

In the locus classicus: _R v Governor of Durham Prison, ex p Singh_ _[[1984] 1 All ER 983, [1984] 1 WLR 704, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)_
following, later distilled by Dyson LJ in R (I) v Secretary of State for the Home Dept _[2002] EWCA Civ 888, [2003]_
INLR 196, were set out as the limits of the power of detaining authority to detain pending deportation (or removal):

1. The detaining authority must detain only to deport (or remove) the person and can only use the power
for that purpose;

2. The detention must be for a reasonable period;

3. If before the expiry of the reasonable period, it becomes apparent that the removal cannot be effected
within that reasonable period, the detaining authority must not seek to exercise the power of detention;

4. The detaining authority must act with reasonable diligence and expedition to effect the removal.

In the light of these, it is the duty of this court at the return to the instant writ, to enquire into the detention of the
applicants to see whether their detention was lawful in the first place and whether or not it has become

**[*283]**

unlawful in that they have been detained for an unreasonable length of time with no end in sight.

In this regard, it is important for this court to set out the matters that have come before it regarding how the
detention of the applicants came about.

It is common ground that the applicants are illegal immigrants having arrived on a Haitian sloop which was
intercepted by the authorities on 10th October 2019. They were not, under s 4(1) of the Immigration Ordinance
**_Cap 5.01, given permission to enter the country as lawful entrants. In fact, subsequent investigations demonstrated_**
that the journey was perhaps in pursuance of a criminal enterprise. It is for this that criminal investigations involving
some of the detainees have assumed the international dimensions described in the affidavit of Acting
Superintendent of Police Willet Harvey.

The actions of the first respondent with respect to the detainees (including the applicants), was in consonance with
s 54(3) of the Immigration Ordinance Cap 5.01 (described hereafter as 'the Ordinance').

I reproduce the said provision:

Section 54(3) '… person on board a ship or aircraft may, under the authority of an immigration officer, be
removed from the ship or aircraft for detention under this section.'

The persons who were intercepted in the said sloop and detained in consequence were thus deemed to be in
proper legal custody, see: _s 56(4) of the Immigration Ordinance (the Ordinance) which reads: 'A person shall be_
_deemed to be in legal custody at any time when he is a detainee …'_

There is then no question that the persons (applicants included) were illegal immigrants detained lawfully under the
applicable law. I daresay, that upon the interception of the sloop, it was open to the first respondent to have
recourse to a number of procedures to deal with the illegal immigrants. These included, especially because of the
involvement of persons suspected of criminal activity, procedures for their deportation under s 54 or s 95(1)(c) of
_the Ordinance, the institution of criminal proceedings under_ _s 102 of the Ordinance, or their repatriation under_ _s_
_54(2) of the Ordinance._

It is the respondent's case that they chose the last course because the applicants opted for voluntary removal from
Turks and Caicos Islands.

Regarding the exercise of this option, learned counsel for the applicants who maintains in his submission that the
applicants who refused to sign the IS101 Forms do not wish to leave Turks and Caicos Islands, has invited this
court to find that the execution of the IS101 Forms by a number of the applicants in the presence of a Tamil
interpreter and an attesting witness, was suspicious, and the reason for this is that the person whose name has
been set out as the attesting witness wrote the time of the execution as 1pm on all the forms


-----

While the said circumstance is certainly curious, it seems to me that it falls short of proof by any standard that
undue influence was exerted on the applicants to secure their signatures on the forms.

As learned counsel has maintained throughout the proceedings and in all the processes filed in support of this
application, he is counsel for all of the

**[*284]**

detainees who were produced in court (albeit not all at once due to the COVID-19 social distancing restrictions).

It was therefore, if he was persuaded that the signing of the forms was done by the exerting of improper pressure or
some other vitiating circumstance on the applicants, incumbent on him to produce evidence of such improper
pressure on the detainees at the point of, or prior to the signing of the IS 101 Forms, especially as on the face of
each form, it was stated that it was explained to the person in Tamil who then signed it. Since no such evidence
was produced, this court has no reason not to take the IS 101 Forms at face value, that they met the standard of
voluntariness required for their due execution.

I note the evidence that some of the applicants opted for voluntary repatriation by signing the IS101 Forms, but that
three refused to do so. Furthermore, that the presence of six of the applicants was needed to prosecute one of the
detainees for various serious immigration offences. These matters notwithstanding, my reading of ss 50–56 of the
Immigration Ordinance informs my understanding that the power of the first respondent to detain illegal immigrants
or persons denied entry into the Islands is for the ultimate purpose of removing them from the Islands. Therefore,
the failure to repatriate all the applicants detained for the said purpose for no just cause would indeed amount to
unlawful conduct on the part of the first respondent the detaining authority.

The jurisprudence in this regard is overwhelming: that the period of detention impacts on the lawfulness, even
where ab initio, the detention was lawful. Thus where there is the intention to remove or repatriate or deport, such
must be effected within a reasonable time, see: _Chijioke v COP of Saint Vincent and the Grenadines_ (SVGHCV
232/2010). Furthermore, it has been held, that where removal cannot be effected within a reasonable time, removal
could not be said to be pending so as to make it a lawful detention even where the reasonable period could not be
[said to have expired, see: per King J in R (on the application of HY) v Secretary of State for the Home Dept [2010]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YWF-5BG0-YBF6-70WB-00000-00&context=1519360)
_[EWHC 1678 (Admin), [2010] All ER (D) 32 (Apr).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YWF-5BG0-YBF6-70WB-00000-00&context=1519360)_

In the instant matter however, it seems to me that an important distinction must be made between an inability to
achieve the desired objective of removal which may be inferred from evidence led, and difficulty which is
surmountable by the first respondent given time and effort in the present circumstance of the global scourge:
COVID-19. Evidence has been led regarding arrangements made to effect the repatriation of the applicants to their
home country. These were said to have been stalled somewhat by the closures of airports and borders in many
countries, due to COVID-19 that has impacted international travel globally.

The evidence adduced by the respondents on whom the burden lay to establish the lawful detention of persons,
negates a lack of will to achieve the desired objective of removal, or an inability to do so due to an inherent
impossibility in carrying it out. The evidence includes arrangements to secure air transportation for the repatriation
by the first respondent, the involvement of IOM an organization that deals with all aspects of migration, including
repatriations (I take judicial notice of this, see: s 39 of the Evidence Ordinance),

**[*285]**

arrangements to secure funding for the repatriation from the Appropriations Committee of the House of Assembly,
and an active engagement with countries through which the applicants must transit to return to Sri Lanka as well as
Sri Lanka the home country of the applicants. That the first respondent through IOM and its Sri Lankan branch is
seeking to engage with the Sri Lankan Government to reopen its skies on humanitarian grounds to receive the
applicants at this time, is instructive of the lengths to which the first respondent will go to achieve the repatriation.


-----

The impact of COVID-19 on all spheres of life at this time cannot be denied; this is a matter of which the court can
take judicial notice. So great is the impact in fact that this hearing has been conducted in a most unusual manner
that in the ordinary scheme of things would have been open to challenge due to the observance of social distancing
protocols. In these circumstances, the case of the respondents that the delay to repatriate is the result not of inertia
or other blameworthy conduct on the part of the first respondent, but of COVID-19's impact on movement of
persons and air travel, cannot be glossed over or discountenanced.

In Turks and Caicos Islands, the borders, including the airports have remained shut since March, and will not be
open until after May 4 2020, see: Emergency Powers (COVID-19) (No 3) Regulations 2020. But beyond Turks
and Caicos Islands' borders and airports, are the policies of other sovereign countries in response to the COVID-19
crisis, countries of transit for this long journey across continents for the returning applicants, as well as the home
country of the applicants: Sri Lanka.

While I advert my mind to the seminal holding in R v Governor of Durham Prison, ex p Singh _[[1984] 1 All ER 983,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)_

[1984] 1 WLR 704that, inter alia, the detaining authority being under a duty to act promptly to effect the removal,
should not exercise that power unless the removal could be effected within a reasonable time, I am satisfied from
the evidence so far adduced that this is no circumstance in which the first respondent is disabled from effecting the
applicants' removal within a reasonable time.

This court cannot ignore the fact that the applicants are illegal immigrants, nor can it shut its eye to the havoc
wreaked by the COVID-19 pandemic on international travel. I cannot read into the present circumstances, the lack
of an immediate prospect of the applicants being able to return to their home country or at all. This is nothing like
the situation in _Tan Te Lam v Superintendent of Tai A Chau Detention Centre_ _[[1996] 2 LRC 360, [1997] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-850J-00000-00&context=1519360)_
97where the Vietnamese Government rejected all attempts to accept the repatriation of detainees. Having regard to
the peculiar facts of this case, I echo the sentiments of Baroness Hale in _R (on the application of Khadir) v_
_Secretary of State for the Home Dept [2005] UKHL 39,_ _[[2005] 4 All ER 114 at 119, [2006] 1 AC 207 at 211that:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4H7S-JMY0-TWP1-61NH-00000-00&context=1519360)_
_'There may come a time when the prospects of the person ever being able safely to return, whether voluntarily or_
_compulsorily, are so remote that it would irrational to deny him the status which would enable him to make a proper_
_contribution to the community here, but that is another question. It certainly did not arise on the facts of this case'._

In coming to my conclusion that the delay of six months in effecting repatriation is not unreasonable, I have regard
to the conduct of the first

**[*286]**

respondent in all this set out at length before now, regarding the continuing focused efforts of the first respondent as
supported by the IOM-UN to effect the applicants' repatriation. My view is buttressed by the said dictum of Dyson LJ
in R (I) v Secretary of State for the Home Department (supra) (at [48]) that: 'It is not possible or desirable to produce
_an exhaustive list of all the circumstances that are, or may be, relevant to the question of how long it is reasonable_
_for the Secretary of State to detain a person pending deportation … But in my view they include at least: the length_
_of the period of detention; the nature of the obstacles which stand in the path of the Secretary of State preventing a_
_deportation; the diligence, speed and effectiveness of the steps taken by the Secretary of State to surmount such_
_obstacles; the conditions in which the detained person is kept …' I could not agree more in the consideration of this_
matter which presents issues parallel to that case.
**Findings:**

In my judgment, the respondents on whom the burden lay to demonstrate the lawfulness of the applicants'
detention have discharged that burden by showing a continuing intention to repatriate the applicants even in the
face of the travel issues raised by COVID-19 pandemic. The continued engagement of Sri Lankan authorities by
IOM on behalf of the first respondent indicates that the first respondent is not lax regarding his duty to effect the
repatriation.

I am therefore satisfied at this time, that the delay to remove the applicants from Turks and Caicos Islands is for just
cause, and therefore does not affect the legality of the detention. It goes without saying that should the detention of


-----

the said applicants continue even after the restrictions on air travel have eased in both Turks and Caicos Islands
and Sri Lanka, the detention, now lawful will at that point become unlawful.

With regard to the six potential prosecution witnesses, it is my understanding, as contained in the affidavits of the
first respondent and Mr Peter Parker, that they, like the other illegal immigrants, are detained pending removal. The
court has been informed that they are scheduled to give evidence as prosecution witnesses in a case of
considerable importance to the security of Turks and Caicos Islands.

While I have not in my research found any provision entitling the first respondent to detain any persons for the
purpose of their being used as prosecution witnesses, it seems to me that the legality of the continued detention of
the said six applicants for the purpose of removal is not affected by the fact that before the planned removal, they
will be used as witnesses for the prosecution of one of the detainees.

The said circumstance is not unreasonable, as long as the prosecution is conducted without undue delay. Should
there be undue delay of that trial, any delay caused thereby to the repatriation of the said applicants within a
reasonable time, should they remain without charge for any offence (the circumstance under which they may be
placed in lawful custody for any length of time), will render their continued detention at that point, unlawful.

At this time, it is my view that the detention of all the fifteen illegal immigrants (the applicants herein – including the
three who refused

**[*287]**

voluntary repatriation) which was lawful in the beginning as done pending their removal from the Islands, continues
to be lawful in spite of the delay in repatriation caused by the unforeseen circumstance of COVID-19.
**Alternative relief:**

I must at this point advert my mind to a matter canvassed by learned counsel presumably by way of an alternative
relief, which is: that the applicants be removed from the detention centre into alternative accommodation,
specifically, vacant tourist accommodation. The merits of that argument are not clear to me, and I say so for the
following reasons: it is apparent that the said submission is premised on a supposition that the detention centre
(IDC) offers poor housing and inadequate facilities. Indeed, learned Counsel Mr Prudhoe (not having been granted
physical access to the premises) described the conditions there as oppressive. This belief is apparently anchored
on matters deposed to in the affidavit of Mikhail Charles on behalf of the applicants, that the three applicants he
interviewed (the second, twelfth and fourteenth) were united in their complaints regarding alleged poor feeding, lack
of medical care, and overcrowding among other things at the detention centre (IDC).

In the affidavit of Mr Parker, he refuted these assertions and went further to set out at length what he said was
provided at the detention centre for the detainees. These were said to include three meals per day including special
diet meals, as well as the observance of social distancing even at recreational times. He stated further (and this
was confirmed by Dr Nadia Astwood in her own affidavit), that regular visits were made by medical teams from the
Ministry of Health to the facility. Furthermore, he supplied the dimensions of the cells (aforesaid) which would make
them reasonably roomy. Mr Parker further deposed that the Human Rights Commission paid regular visits to the
facility to satisfy itself of the conditions thereat and added that no complaint of mental ill-health or threat of suicide
alleged on behalf of the fourteenth applicant had been noted by the medical teams that regularly visited the facility.
With regard to communication, he set out efforts made by the Detention Centre to provide the detainees access to
communication by providing them with telephones at this time that visits to the detention centre are restricted by the
**_Emergency Powers (COVID-19) (Amendment) Regulations in force._**

To these factual matters deposed in the affidavits of Mr Parker and Dr Astwood, which rebutted the assertions
made on behalf of the applicants by Mr Mikhail Charles, no affidavit was filed in reply on behalf of the applicants to
refute or challenge the assertions.


-----

Thus, what Mr Charles deposed to as having been told by second, twelfth and fourteenth applicants remained bare
assertions unsupported by any cogent evidence, and in fact, rebutted by the unchallenged evidence of the
respondents.

It seems to me then that the respondents have demonstrated on the preponderance of the probabilities, that the
accommodation arrangements at the detention facility are adequate for the purpose. Juxtaposed with this is the

**[*288]**

fluid nature of COVID-19 infection and how the science of infection changes daily. This is something I take judicial
notice of, see: **_s 39 of the Evidence Ordinance Cap 2:06. In this regard, I have considered the affidavit of Dr_**
Nadia Astwood and her recommendation that the applicants not be removed except to be sent out of Turks and
Caicos Islands. It is the case of the first respondent that all the applicants who entered Turks and Caicos Islands
illegally, are due to be removed from the Islands. These include the persons who signed the IS101 Forms, the three
applicants who refused to sign them, as well as the six persons who before their removal will be used as
prosecution witnesses in the case against one of the detainees. On the showing of Mr Parker in his unchallenged
affidavit, all the detainees are at this time, supplied with the necessaries of life. To release such persons pending
their removal from the Turks and Caicos Islands into vacant tourist places to fend for themselves at this time with
the curfew in place (even if less restricted since yesterday), and with very little offered by way of service to cater for
daily needs, will not serve any useful purpose to them or to the community which is doing all it can to combat the
spread of COVID-19.

I am satisfied that on the balance of the probabilities, the respondents have demonstrated that the applicants are
not the subject of unlawful detention.

I hold that the detention of the applicants pending removal is lawful, as pursuant to **_ss 54(3) and 56(4) of the_**
**_Immigration Ordinance Cap 5:01._**

In thus holding, I am mindful of the court's duty to protect and enforce fundamental rights enshrined in the
Constitution of Turks and Caicos Islands, including freedom from the deprivation of liberty and the security of the
person, as well as its caveats set out in s 5, and more particularly **_s 5(2)(h) of the Constitution of Turks and_**
**_Caicos Islands which provide as follows:_**

'5—(1) Every person has the right to liberty and security of person.

(2) No person shall be deprived of his or her personal liberty save in accordance with a procedure prescribed
by law in any of the following cases:

…

_(h) for the purpose of preventing the unlawful entry of that person into the Islands or for the purpose of effecting_
_the expulsion, extradition or other lawful removal from the Islands of that person or the taking of proceedings_
_relating thereto.'_

I decline to interfere with the detention at this time, as the delay in repatriation which gave rise to the application has
been sufficiently explained as justified, and especially as I am satisfied that the first respondent's intention to
repatriate is active and continuing, and there is some prospect of achieving it without unreasonable delay.

The application before this court for the release of the applicants (or in the alternative, a relocation into other
residential accommodation), must therefore fail. It is accordingly dismissed.

I have had regard to the matters placed before me, and to the efforts of counsel to represent the applicants,
including engaging at his own cost, a Tamil interpreter. There will therefore be no order as to costs.

**[*289]**
**Appeal**


-----

Following a writ of habeas corpus ad subjiciendum to issue made by Simons J (Ag) on 31 March 2020,
Paintamilkavalan Kajeepaan, Varatharaj Rasaratnam and Jeseepan Swapalan Sivapalan appealed the decision of
Agyemang CJ of 1 May 2020 finding that the detention of the appellants had been lawful. The respondents were
Derek Been, Director of Immigration, and the Attorney General. The facts are set out in the judgments of Winder JA
and Mottley P.

_Philip Rule and Tim Prudhoe for the appellants._

_Clemar Hippolyte for the respondents._

31 December 2020. The following judgments were delivered.

**WINDER JA.**

**[1] This is an appeal of the decision of the Honourable Chief Justice dated 1 May 2020, whereby she found,**
following a Habeas Corpus application, that the detention of the Appellants at the Immigration Detention Center was
lawful.
**Background.**

**[2] On 10 October 2019, the Royal Turks & Caicos Islands Police Force ('RTCIPF') intercepted a Haitian sloop in**
the territorial waters of the Turks and Caicos Islands ('TCI'). When intercepted, it was discovered that the Haitian
sloop had 154 persons on board including 1 Indian and 28 Sri Lankan nationals. The three Appellants were a part
of the group of Sri Lankan nationals.

**[3] The Respondents' case, both here and in the Court below, was that this interception presented a number of**
complex and significant issues. Firstly, they say that the inability to communicate with the Sri Lankan detainees,
who only spoke Tamil, frustrated the investigation. Secondly, they say that the investigations were prolonged since
it was imperative that comprehensive and proper assessments be carried out on the detainees, to establish whether
they had been the victims of human trafficking and or smuggling to identify who was responsible for it.

**[4] In relation to the latter of the issues, the Respondents say that the capacity and experience within the**
Immigration Enforcement Unit could not support such a complex and sensitive investigation. Further they say that
this necessitated the RTCIPF taking the lead in the investigation. It then unfolded that the RTCIPF itself was forced
to solicit the assistance of more experienced and specialized investigators from the Serious Crime Investigation
Agency in the UK. Such an engagement which required significant and extraordinary funding, it was said, required
parliamentary appropriation following a formal request to the Governor in Cabinet.

**[5] It would not be until early November 2019, following the approval of the House of Assembly, that the**
engagement of investigative services could

**[*290]**

be confirmed. Further, it would not be until 3 December 2019, some two months since initial detention, that
interviews with the detainees commenced, following the arrival of UK based officers and Tamil speaking interpreters
in the TCI.

**[6] Following the investigations by the RTCIPF it was determined that the Haitian sloop intercepted on 10 October**
2020, was engaged in a human trafficking or smuggling operation led by Srikajamukam Chelliah (Chelliah) who was
also found on board. Chelliah, a Canadian national of Sri Lankan descent is believed to be part of a Sri Lankan
based trans criminal operation which engaged in the smuggling of undocumented migrants from Sri Lanka to the
United States through the Caribbean.

**[7] Upon completion of their work the RTCIPF, on 7 February 2020, provided the Immigration authorities with a**
schedule of the Sri Lankan and Indian nationals involved in the investigation along with recommendations for each.
The recommendations fell into three categories:

(1) 1 detainee (Chelliah) was identified as a suspect;


-----

(2)   6 detainees were to be utilized as potential witnesses (for proceedings against Chelliah); and

(3)   All others were to be repatriated.

The Appellants were identified in the class of persons to be repatriated. According to the Respondents, 'once that
_information was received much efforts was placed in determining the ideal way and means to return the Sri Lankan_
_and Indian National to their homeland'. On 7 March 2020, Voluntary Departure Forms (IS101) prescribed under the_
Immigration Ordinance were presented to all of the detainees. The three Appellants were the only Sri Lankan
nationals who refused to sign to IS101 forms. Upon this refusal they were isolated from the other Sri Lankan
nationals.

**[8] The International Office for Migration ('IOM'), which was engaged to assist in the repatriation exercise, arrived in**
the TCI on 9 March 2020. The IOM completed its tasks, related to persons to be repatriated, on 16 March 2020 and
informed the Immigration Department of details relevant to the repatriation then proposed for 24 March 2020. The
IOM advised the Immigration Department that Varatharaj Rasaratnam, Jeseepan Silvapalan and Kajeepan
Paintamilkavalan, the Appellants, had indicated _'that they do not wish to return home as they are afraid of what_
_might happen upon return'. The declaration of the Covid-19 virus as an international pandemic by the World Health_
Organization (WHO) and the subsequent closures of transit countries, and Sri Lanka itself, delayed the possibility of
the proposed repatriation exercise. The Tamil interpreters were repatriated to the UK ahead of a national Covid-19
lockdown at the end of March 2020.

**[9] On 31 March 2020, upon the application of the Appellants (and 12 of the other Sri Lankan nationals), Simons J**
(Ag) made an order for a Writ of Habeas Corpus ad subjiciendum, returnable on 24 April 2020, to be issued. The
Writ of Habeas Corpus was issued on 20 April 2020. The Writ of Habeas Corpus directed the First Respondent to
produce the Appellants (along with the other 12 detainees) before the Court.

**[10] On 23 April 2020, three days after the Writ of Habeas Corpus was**

**[*291]**

issued, and some six (6) months since the initial detention of the Appellants, a Notice of Intention to Make a
Deportation Order was issued by the Minister of Border Control, in respect of the Appellants and served on them at
the Immigration Detention Center.

**[11] The Writ of Habeas Corpus was heard by the Chief Justice, remotely, in accordance with the Emergency**
Powers (Covid-19) (Court Proceedings) Regulations 2020 on 24 April 2020. The Appellants appeared at the
hearing remotely from the detention center. At the hearing, Counsel for the Appellants objected to the quality of the
production of the Appellants upon the Writ. The substance of the Respondents' objection, at the hearing, was that
all of the Applicants to the habeas corpus application were not present in the hearing at the same time. The result
was that they were not able to attend for the entirety of the proceedings. According to the Respondents, as a result
of the size of the hearing room at the detention center and the need for social distancing, only 5 persons could
safely be in the hearing room at any one time. As 15 persons were involved in the hearing, they were brought into
the hearing room in groups of 5. Each of the applicants (including the Appellants) was identified to the court and
thereafter taken away. None of the Appellants was therefore permitted to attend for the entirety of the proceedings.
Despite the challenges, the Chief Justice sought to ensure that applicants were present in the video hearing when
matters specific to them were being raised.

**[12] During the proceedings the First Respondent ('Been') was examined under oath and subject to cross-**
examination. The Appellants' attorneys became aware of the existence of the Notice of Intention to Make a
Deportation Order, for the first time, during Been's evidence.

**[13] At the conclusion of the hearing the Chief Justice reserved her decision which was delivered shortly thereafter**
on 1 May 2020. In her written decision, the learned Chief Justice found, at page 21, as follows:

'It seems to me then that the respondents have demonstrated on the preponderance of the probabilities, that
the accommodation arrangements at the detention facility are adequate for the purpose Juxtaposed with this is


-----

the fluid nature of COVID-19 infection and how the science of infection changes daily. This is something I take
judicial notice of, see: **_s 39 of the Evidence Ordinance Cap 2:06. In this regard, I have considered the_**
affidavit of Dr Nadia Astwood and her recommendation that the applicants not be removed except to be sent
out of Turks and Caicos Islands. It is the case of the first respondent that all the applicants who entered Turks
and Caicos Islands illegally, are due to be removed from the Islands. These include the persons who signed
the IS101 Forms, the three applicants who refused to sign them, as well as the six persons who before their
removal will be used as prosecution witnesses in the case against one of the detainees. On the showing of Mr
Parker in his unchallenged affidavit, all the detainees are at this time, supplied with the necessaries of life. To
release such persons pending their removal from the Turks and Caicos Islands into vacant tourist places to
fend for themselves at this time with the curfew in place (even if less

**[*292]**

restricted since yesterday), and with very little offered by way of service to cater for daily needs, will not serve
any useful purpose to them or to the community which is doing all it can to combat the spread of COVID-19.

I am satisfied that on the balance of the probabilities, the respondents have demonstrated that the applicants
are not the subject of unlawful detention.

I hold that the detention of the applicants pending removal is lawful, as pursuant to ss 54(3) and 56(4) of the
_Immigration Ordinance Cap 5:01. In thus holding, I am mindful of the court's duty to protect and enforce_
fundamental rights enshrined in the Constitution of Turks and Caicos Islands, including freedom from the
deprivation of liberty and the security of the person, as well as its caveats set out in s 5, and more particularly s
_5(2)(h) of the Constitution of Turks and Caicos Islands which provide as follows [emphasis added]:_

“5—(1) Every person has the right to liberty and security of person.

(2) No person shall be deprived of his or her personal liberty save in accordance with a procedure prescribed
by law in any of the following cases:

…

_(h) for the purpose of preventing the unlawful entry of that person into the Islands or for the purpose of effecting_
_the expulsion, extradition or other lawful removal from the Islands of that person or the taking of proceedings_
_relating thereto.”_

I decline to interfere with the detention at this time, as the delay in repatriation which gave rise to the
application has been sufficiently explained as justified, and especially as I am satisfied that the first
respondent's intention to repatriate is active and continuing, and there is some prospect of achieving it without
unreasonable delay. [emphasis added]

The application before this court for the release of the applicants (or in the alternative, a relocation into other
residential accommodation), must therefore fail. It is accordingly dismissed.'

**[14] The parties have lodged an Agreed Chronology to chronicle the events which transpired, including those**
subsequent to the decision of the Chief Justice. There has been no application to admit fresh evidence. However,
insofar as there is an agreement by way of the Agreed Chronology, indicating that certain events have indeed
occurred, it is open to the Court to have regard, to the occurrence of these events, which were relied upon by both
parties in arguing their case. The Court made no objection to the Agreed Chronology at any time during the hearing.
One such significant event in the Agreed Chronology is the decision of the Respondents to voluntarily release the
Appellants subsequent to the hearing before the Chief Justice.

**[15] Beyond acknowledging the occurrence of the events in the Agreed Chronology, the Court ought to restrain**
itself from considering any new factual matter which may be disputed, such as new matters set out in the

**[*293]**


-----

Skeleton Argument of the Appellants. Subject to this, I am satisfied that notwithstanding the submission of the
Appellants, that the court rehear the matter and consider matters occurring before and after the hearing before the
_Chief Justice, this appeal ought to be largely focused on the state of affairs which were in existence before the_
Chief Justice and upon which she found that the Appellants' detention was lawful.

**[16] According to the Agreed Chronology, on 30 April 2020, the Notice of Intent to make a Deportation Order in**
respect of each of the Appellants was emailed to the Appellants' attorneys at the firm of Prudhoe Caribbean.
Between 1 May 2020 and 20 May 2020, the Appellants' attorneys and the Minister of Border Control and Labour
engaged in correspondence with respect to the decision to issue Notices of Intention to deport without first having
the Appellants interviewed by an official with knowledge and experience of interviewing asylum applicants. That
decision became the subject of judicial review applications before the Supreme Court in Civil Action No CL 54/2020.
On 19 June 2020, the Respondents registered the Appellants with the United Nations Human Rights Commissioner
for Refugees ('UNHCR'). On 10 July 2020, the UNHCR, after interviewing and assessing the Appellants, found
them to be genuine refugees entitled to proper humanitarian care and registered them as refugees. The UNHCR
requested that the Respondents release the Appellants.

**[17] As indicated above, the Agreed Chronology also showed that the Appellants and all other Sri Lankan detainees**
were conditionally released on 24 August 2020, after 320 days (or 10 1/2 months) in detention.
**The Appeal**

**[18] The Notice of Appeal in this action was filed on 14 May 2020, and amended on 7 August 2020. Whilst the**
Amended Notice of Appeal spanned 34 pages, the complaints of the Appellants may be identified into 2 broad
areas. These are:

(1)   The challenge to the lawfulness of the detention; and

(2)   Complaints concerning the procedure employed at the hearing of the Writ of Habeas Corpus and the
production of the Appellants.

**[19] These broad complaints are seen in the nature of the Order initially sought by the Appellants, namely that:**

i. the appeal be allowed;

ii. an Order of release forthwith of the Appellants; and/or

iii. a Declaration of the violation of s 5 of the Constitution for the detention for such period as the Court shall
identify;

iv. a declaration that the procedure adopted in the Appellants' cases at the hearing on 24 April 2020 was
deficient and unfair at common law or in violation of s 6 of the Constitution;

v. such further or relief as this Court shall deem fit or as is appropriate, including declaratory relief and/or
compensation pursuant to s 5(7) of the Constitution.

**[20] Upon the release of the Appellants on 24 August 2020, subsequent to**

**[*294]**

the Amended Notice of Appeal, the relief in item (ii) above was abandoned in these proceedings.
_Whether the Appeal is Academic or Moot_

**[21] During the hearing of the appeal, the issue was raised, by the President, of whether the subsequent release of**
the Appellants has rendered the pursuit of this appeal academic or moot. The Respondents had been content to
argue the appeal on its merits as the issue had not been raised by them in their submissions. The issue has since
been embraced by the Respondents and supplemented by a written note. According to the note:

'At the hearing of this appeal the Court asked the parties to consider the effect of the release of the Applicants
on this appeal. Specifically, the court required the parties to address it on whether the appeal is a purely
academic appeal and whether the Court should seek to entertain it


-----

In these circumstances, where the appellants have been released, the Respondents

…

The question arises as to whether this Court can hear academic appeals and, if so, in what circumstances and
subject to what considerations should it do so. The rules governing appeals to this Court are stated in very
broad terms.

Section 4 of the Court of Appeal Ordinance states that the Court shall have jurisdiction to hear and determine
appeals from “any” judgment or order of the Supreme Court given or made in civil proceedings.

It is the Respondent's submission that this despite this seemingly broad jurisdiction of the Court to entertain
any appeal, it is an important feature of our judicial system that this Court decides disputes between the parties
before it and does not pronounce on abstract or hypothetical questions of law where there is no dispute to be
resolved. In general, there must exist between the parties a matter in actual dispute or controversy which this
Court can decide as a live issue.'

**[22] The Respondents relied on the House of Lords decision in** _R v Secretary of State for the Home Dept, ex p_
_[Salem [1999] 2 All ER 42 at 47, [1999] AC 450 at 457, where the court stated:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61HF-00000-00&context=1519360)_

'The discretion to hear disputes, even in the area of public law, must, however, be exercised with caution and
appeals which are academic between the parties should not be heard unless there is a good reason in the
public interest for doing so, as for example (but only by way of example) when a discrete point of statutory
construction arises which does not involve detailed consideration of facts and where a large number of similar
cases exist or are anticipated so that the issue will most likely need to be resolved in the near future'.

**[23] The Appellants have rejected the contention that the appeal was now only academic or moot and that there are**
no longer any outstanding issues

**[*295]**

between the parties. They sought to answer the issue as follows:

'As a preliminary point the [Appellants] invite the Court to note that the issue between the parties remains the
question whether or not the detention was lawful. Although the relief sought is amended, the cause of the
complaint – detention – is wholly unchanged from the Court below.

The question is not rendered academic as a result of the belated release. That release (24 August 2020)
occurred only after the Amended Notice of Appeal, dated 7 August 2020. The Amended Notice of Appeal
seeks an order that “The Appellants' detention was or is now unlawful” … The Court is respectfully referred to
the amended requests for relief … The request for the common law remedy for unlawful detention is express
made there. The [Appellants] seek a remedy for their unlawful detention. In addition, the recognition of the
unlawfulness of the previous detention is capable of acting as a safeguard against future detention, for
example if a ruling is given to establish the unreasonable duration of it or established lack of due diligence and
expedition as was required to address the matters in some respects still unconcluded. …

The [Appellants] seek a remedy for their unlawful detention. In addition, the recognition of the unlawfulness of
the previous detention is capable of acting as a safeguard against future detention, for example if a ruling is
given to establish the unreasonable duration of it or established lack of due diligence and expedition as was
required to address the matters in some respects still unconcluded.'

**[24] There is merit in the Appellants' submission that there remains a lis between these parties, requiring a decision**
by this Court. Whilst the release of the Appellants was the primary relief in the Habeas Corpus application the
substantive claim was that the detention was unlawful. Vindication of this fundamental right is not a mere academic
pursuit. The importance of the court's role was aptly stated by **_Dingemans J_** in the English case of _R (on the_


-----

_[application of AA (Sudan)) v Secretary of State for the Home Dept [2014] EWHC 2118 (Admin), [2014] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CJG-0GJ1-DYBP-N3TF-00000-00&context=1519360)_
_[220 (Jun), at para [2]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CJG-0GJ1-DYBP-N3TF-00000-00&context=1519360)_

'It is established that the Courts will, in order to vindicate the rule of law, “regard with extreme jealousy any
claim by the executive to imprison a citizen without trial and allow it only if it is clearly justified by the statutory
[language”, R v Home Secretary ex parte Khawaja [1984] AC 74 at 122E, [1983] 1 All ER 765, [1983] 2 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-61BN-00000-00&context=1519360)
321. This approach by the courts includes cases of administrative detention of foreign nationals pending
[deportation pursuant to the Immigration Act 1971.'](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

The challenge in the appeal is to the decision by the Chief Justice where she determined that the detention was
lawful. As the Appellants' counsel Mr Rule argues, the issue remains, because they continue to challenge the
decision on appeal whilst the Respondents continue to uphold the decision.

**[25] The Appellants have sought to pursue, in these proceedings, a claim for compensation for unlawful detention,**
identified by them as freestanding constitutional relief. This certainly represents an outstanding matter for which

**[*296]**

the Court is required to decide. Whether the Court entertains the application or determines that it should be pursued
as a separate action, it nonetheless demonstrates that there remain matters between these parties which require
resolution.

**[26] An Order by this Court dismissing the appeal, without determining the issue of the lawfulness of the detention,**
requiring the Appellants to litigate the issue in fresh proceedings, demonstrates the need to determine this issue.
How will another judge of the Supreme Court be able to consider the lawfulness of the Appellant's detention, in the
face of a finding by the Chief Justice that the Appellants were lawfully detained? How could they overcome the
issue of res judicata or issue estoppel? This Court ought not to shirk its responsibility to do justice between the
parties and resolve the issue of the lawfulness of the detention, which has already been fully argued before us.

**[27] Separate and apart from the question of the release of the Appellants, a determination in their favour, as to the**
lawfulness of the detention, would undoubtedly affect the determination of the entitlement to costs in the
proceedings below. This included the costs which had been reserved by Simons J (Ag) on 31 March 2020. This is
especially so where, rather unusually, the Appellants had to cover the costs of providing translation services in the
Habeas Corpus proceedings. The Chief Justice sought to balance this issue in her determination that no costs
ought to be paid. At page 23 of her decision below it is recorded:

'I have had regard to the matters placed before me, and to the efforts of counsel to represent the applicants,
including engaging at his own cost, a Tamil interpreter. There will therefore be no order as to costs.'

Had the Appellants been successful in the court below one would have expected other considerations with respect
to costs would have been made, if only for the recovery of translation services provided for the Court. In the case of
_Trinidad and Tobago A-G v Trinidad and Tobago Civil Rights Association_ (Civil Appeal No 149 of 2005), in
considering this issue of an academic or moot appeal, Warner JA, stated at para 10:

'A Court may choose to hear arguments and hand down a decision which has no practical effect, in order to
clarify the law or give guidance to decision makers; where there is good reason in the public interest or even for
resolving issues as to costs. An example of a case in the first category is **R v Birmingham City Juvenile**
**Court, ex p. Burmingham City Council 1988 1 WLR 337, which concerned conflicting first instance decisions**
on “care” proceedings in the juvenile court. By the time the matter was determined, a care order had already
been made so that the problem was no longer outstanding. Nonetheless the court found that it was appropriate
to declare what the law was.'

**[28] The issue of costs would therefore reflect an outstanding lis between the parties and therefore the classification**
of the appeal as academic or moot would be inappropriate.

**[29] Th** A ll t th t th C t h ld d t i th ti f


-----

**[*297]**

the lawfulness of the detention as the terms upon which the Appellants were released specifically indicated that
they remain subject to further detention. The Appellants relied on the decision in R (C) v London South and West
_[Region Mental Health Review Tribunal [2001] EWCA Civ 1110, [2002] 1 WLR 176, [2001] All ER (D) 24 (Jul) which](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P1DN-00000-00&context=1519360)_
applied _R v Secretary of State for the Home Dept, ex p Salem. In that case, despite the release of C the Court_
determined that the appeal should be heard as (i) the application raised a point of public general importance; and
(ii) the point might prove more than academic interest to C who might find himself detained again in the future.

**[30] The Respondents contend that the Appellants are not subject to an order for deportation while their application**
for asylum is pending (or under appeal). Whilst I accept the Respondents' statement as to the legal position, it is
nonetheless accepted that the terms of the releases are said to be conditional. The voluntary release of the
Appellants and the presence of conditions do suggest that the issue of the lawfulness of the detention may remain
an issue which ought to be resolved by a decision of this Court. A decision on the question of the lawfulness of the
prior detention could stand as a safeguard and caution to further detention.

**[31] In the decision of this Court (differently constituted) in Governor of the Turks and Caicos Islands v Proprietors,**
_Strata Plan 108 (CL 38/15), the respondents successfully argued for the dismissal of the appeal on the basis that_
the appeal was against the finding or reasons but not the judgment or order or determination of the Chief Justice. In
that case, the Chief Justice had found that amendments to the Turks and Caicos Islands Development Manual were
ultra vires and of no effect. The Chief Justice also held that the failure to hold public consultation would lead to the
proposal being quashed. The respondents in that case contended that the appeal was academic and/or moot as
the appellants did not challenge the holding as to the failure to hold public consultations. At para 14 of the decision,
**_Mottley JA (as he then was) accepted the submission and stated:_**

'14. I accept that if the appeal is allowed to continue on the first ground of the judicial review and is successful,
the finding by the Chief Justice on the second ground of the judicial review i.e. the failure to hold proper
consultations would still remain, and on the ground the Chief Justice would still have been entitled to make the
declaration that because of the failure to hold the proper consultations the Amendment are null and void.

15. There is no jurisdiction to entertain an appeal against reasons which does not challenge the order …'

**[32] Mottley JA relied upon the decision in Hutcheson v Popdog Ltd** _[[2011] EWCA Civ 1580, [2012] 2 All ER 711,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55M4-GCV1-DYBP-M2YC-00000-00&context=1519360)_

[2012] 1 WLR 782where it was stated:

'[15] Both the cases and general principle seem to suggest that, save in exceptional circumstances, three
requirements have to be satisfied before an appeal, which is academic as between the parties, may (and I
mean “may”) be allowed to proceed: (i) the court is satisfied that the appeal

**[*298]**

would raise a point of some general importance; (ii) the respondent to the appeal agrees to it proceeding, or is
at least completely indemnified on costs and is not otherwise inappropriately prejudiced; (iii) the court is
satisfied that both sides of the argument will be fully and properly ventilated.

[16] I accept that there would be a real prospect of requirement (i) being met if this appeal went ahead. The
projected appeal would, I accept, potentially raise at least one issue of general importance, although I do not
regard it as a foregone conclusion that either of the two points which have been identified would necessarily be
determined on the projected appeal. In that connection, the two issues Mr Tomlinson contended would have to
be considered on the projected appeal were first, the judge's view that the interim injunction ceased to have
interim effect once Mr Hutcheson and Popdog had effectively settled their differences and, secondly, the
correctness of the decision in Jockey Club v Buffham [2003] QB 462, [2003] 2 WLR 178.'

**[33] The authorities all accept, as do the Respondents, that the Court may, in appropriate circumstances, hear an**
appeal notwithstanding it may be considered academic or moot. In my view, even if I had not found (as I do) that it


-----

is not an academic or moot appeal, this would be an appropriate case for the exercise of the Court's discretion to
hear it. According to Lord Neuberger MR, in Hutcheson v Popdog Ltd this discretion could be exercised in either of
2 instances, which are:

(1)   in an exceptional case; or

(2)   where:

(i)   the court is satisfied that the appeal would raise a point of some general importance;

(ii)   the respondent to the appeal agrees to it proceeding, or is at least completely indemnified on costs
and is not otherwise inappropriately prejudiced;

(iii)   the court is satisfied that both sides of the argument will be fully and properly ventilated.

**[34] What is exceptional has understandably not been defined by Lord Neuberger. Some insight however may be**
gleaned from para [12] of his judgment in Hutcheson v Popdog Ltd, where it was stated:

'[12] The mere fact that a projected appeal may raise a point, or more than one point, of significance does not
mean that it should be allowed to proceed, where there are no longer any real issues in the proceedings as
between the parties. In _Gawler v Raettig_ _[[2007] EWCA Civ 1560, the Court of Appeal refused permission to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54J2-CR51-F0JY-C4HX-00000-00&context=1519360)_
appeal on the ground that the issue it would raise was academic as between the parties. In his judgment, Sir
Anthony Clarke MR gave helpful guidance as to the correct approach in such cases. He said (at [36]) that,
before an appeal could proceed in those circumstances, the court must be satisfied that it would be in the
public interest for the projected appeal to proceed, but he added that it

**[*299]**

would be “a very rare event, especially where the rights and duties to be considered are private and not public”.
Nonetheless, in the following paragraph he emphasised that all must “depend upon the facts of the particular
case” and that he did not “intend to be too prescriptive” '. (emphasis added)

**[35] In** _Ya'axché Conservation Trust v Sabido (Chief Forest Officer)_ [2014] CCJ 14 (AJ), (2014) 85 WIR 264, a
decision of the Caribbean Court of Justice, an application for special leave to appeal from the Court of Appeal of
Belize, permission was granted to hear an appeal notwithstanding it had become academic in nature. Anderson
JCCJ said at para [6]:

'There are compelling features of the present case which would make it appropriate for us to hear the appeal,
though academic. This matter does not concern private law rights but rather a narrow and discrete point of
public law namely the proper construction to be placed on the statutory power of the Administrator to grant
authorization to conduct otherwise forbidden activities within a nature reserve. There are no complex facts to
be sorted or resolved. The issue of statutory interpretation is of great significance to the protection of the
environment in Belize and, in particular, the protection of areas declared for the protection under the Act such
as national parks, nature reserves, wildlife sanctuaries and natural monuments and the underlying principle of
the rule of law. Cases raising similar issues have occurred in the past and are likely to recur in the future.'

**[36] I am of the view that this matter ought to be considered exceptional:**

(1)   As indicated in the preceding paragraphs, there are clearly outstanding issues which remain extant
between these parties, namely:

(a)   the determination of the issue of the lawfulness of the detention;

(b)   the claim for free standing constitutional relief;

(c)   claims for compensation for unlawful detention whether in this case or in the future;

(d)   the issue of costs; and,


-----

**[*300]**


(e)   the fragile voluntary release and the possibility that the Appellants might find themselves in detention
in the future.

(2)   Unlike in the context of Hutcheson v Popdog Ltd this is not simply a question of leave to appeal. The
complete appeal has been heard over a period of 5 days and all issues thoroughly ventilated. This issue, of
whether the appeal would be moot, was never taken by the Respondents in their papers but raised by the
Court suggesting that the Respondents initially had no issue with the prosecution of the appeal.

(3)   The circumstances of this case are distinguishable from that of _Governor of the Turks and Caicos_
_Islands v Proprietors, Strata Plan 108 (CL 38/15) and Ogle Airport Inc v Competition and Consumer Affairs_
_Commission_ [2020] CCJ 19 (AJ) GY, where successful litigants sought to upset certain findings made in
the lower Court. Here, the Chief Justice found against

the Appellants completely. The Appellants not only challenge the reasons which the Chief Justice found
that the detention was lawful but her actual finding of a lawful detention.

(4)   The matter was concerned with the exercise of public law duties, and in particular a review of the
duties and responsibilities of immigration officers in the examination and treatment of detainees intercepted
at sea in the TCI. This is an important matter having regard to the geographical location of the TCI and its
frequent use as a transit point for human trafficking operations and other illegal immigration activities.
Issues of this nature, albeit not as extreme in this case, will undoubtedly arise in the future and the
guidance, which this Court could provide, would be of utmost significance for the police and immigration
authorities as well as the lower courts.

(5)   Important points of principle arise for consideration in this case, which are:

(a)   whether the Respondents could, as they did here, hand over immigration detainees to the police to
conduct criminal investigations into human trafficking; and

(b)   whether the Respondents were entitled to refrain from conducting immigration interviews of persons
placed in their custody for an indefinite period of time and in the context of this case, 6 months up to the
hearing before the Chief Justice.

There is a shortage of reported authorities in this jurisdiction on the fundamental rights issues which arise
for consideration in this dispute.

(6)   This matter required the extraordinary expenditure of public funds through the House of Assembly to
bring in expert investigators and should therefore be given the fullest of ventilation. Additionally, as
indicated by the parties in their respective submissions, the matter garnered widespread domestic and
international attention and as such the matter should be given the fullest of ventilation.



**[37] I am satisfied therefore that this Court ought to proceed to hear the substantive appeal.**
_Whether the Appellants were unlawfully detained_

**[38] Section 5 of the Constitution of the Turks & Caicos provides:**

**'Protection from arbitrary arrest or detention**

**5. (1) Every person has the right to liberty and security of person.**

(2) No person shall be deprived of his or her personal liberty save in accordance with a procedure prescribed
by law in any of the following cases—

_(a) in execution of the sentence or order of a court, whether established for the Islands or some other country,_
in respect of a criminal offence of which he or she has been convicted or in consequence of his or her unfitness
to plead to a criminal charge;

_(b) in execution of the order of a court punishing him or her for contempt of that court or of another court;_


-----

**[*301]**

_(c) in execution of the lawful order of a court made in order to secure the fulfilment of any obligation imposed_
on him or her by law;

_(d) for the purpose of bringing him or her before a court in execution of the lawful order of a court;_

_(e)_ on reasonable suspicion that he or she has committed, is committing or is about to commit a criminal
offence;

_(f) in the case of a minor, under the order of a court or with the consent of his or her parent or legal guardian,_
for the purpose of his or her education or welfare;

_(g) for the purpose of preventing the spread of an infectious or contagious disease or in the case of a person_
who is, or is reasonably suspected to be, of unsound mind, addicted to drugs or alcohol, or a vagrant, for the
purpose of his or her care or treatment or the protection of the community;

_(h) for the purpose of preventing the unlawful entry of that person into the Islands or for the purpose of effecting_
the expulsion, extradition or other lawful removal from the Islands of that person or the taking of proceedings
relating thereto.

(3) Any person who is arrested or detained shall be informed promptly, in a language that he or she
understands, of the reasons for his or her arrest or detention and of any charge against him or her.'

**[39] The legal principles relative to the power to detain persons in the position of the Appellants are fairly well**
settled. Those principles are rooted in the decision of **_Woolf J_** (as he then was) in the case of _R v Governor of_
_Durham Prison, ex p Singh_ _[[1984] 1 All ER 983 at 985, [1984] 1 WLR 704 at 706D. A good distillation of these](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)_
principles is to be found in the dicta of Dyson LJ in the English Court of Appeal case of R (I) v Secretary of State
_for the Home Dept_ _[2002] EWCA Civ 888, [2003] INLR 196. According to Dyson LJ:_

'[46] There is no dispute as to the principles that fall to be applied in the present case. They were stated by
Woolf J in R v Governor of Durham Prison ex parte Singh [1984] 1 WLR 704, at 706D in the passage quoted
by Simon Brown LJ, at para [9], above. This statement was approved by Lord Browne−Wilkinson in _Tan Te_
_Lam v Tai A Chau Detention Centre [1997] AC 97, at 111A−D in the passage quoted by Simon Brown LJ at_
para [12], above. In my judgment, Mr Robb correctly submitted that the following four principles emerge:

(i) The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose.

(ii) The deportee may only be detained for a period that is reasonable in all the circumstances.

(iii) If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not be
able to effect deportation within that reasonable period, he should not seek to exercise the power of detention.

(iv) The Secretary of State should act with the reasonable diligence and expedition to effect removal.

**[*302]**

[47] Principles (ii) and (iii) are conceptually distinct. Principle (ii) is that the Secretary of State may not lawfully
detain a person “pending removal” for longer than a reasonable period. Once a reasonable period has expired,
the detained person must be released. But there may be circumstances where, although a reasonable period
has not yet expired, it becomes clear that the Secretary of State will not be able to deport the detained person
within a reasonable period. In that event, principle (iii) applies. Thus, once it becomes apparent that the
Secretary of State will not be able to effect the deportation within a reasonable period, the detention becomes
unlawful even if the reasonable period has not yet expired.


-----

[48] It is not possible or desirable to produce an exhaustive list of all the circumstances that are, or may be,
relevant to the question of how long it is reasonable for the Secretary of State to detain a person pending
[deportation pursuant to para 2(3) of Sch 3 to the Immigration Act 1971. But in my view they include at least: the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y0W2-00000-00&context=1519360)
length of the period of detention; the nature of the obstacles which stand in the path of the Secretary of State
preventing a deportation; the diligence, speed and effectiveness of the steps taken by the Secretary of State to
surmount such obstacles; the conditions in which the detained person is being kept; the effect of detention on
him and his family; the risk that if he is released from detention he will abscond; and the danger that, if
released, he will commit criminal offences.

…

[56] Taking account of all the circumstances of the case, I am of the opinion that by 29 May 2002, the appellant
had been detained for a period that was longer than was reasonable. I take account of the difficulties facing the
Secretary of State in effecting removals to Afghanistan and the fact that he has been conducting sensitive
negotiations with neighbouring countries to enable removals to take place with their assistance. I also take
account of the fact that the appellant has been convicted of criminal offences for which he was sentenced to 3
years' imprisonment and that he became liable to register as a sex offender. On the other hand, there is no
evidence that he is liable to reoffend. I accept that there is a risk that he will abscond. I find it difficult to assess
the seriousness of this risk, but I am not persuaded on the material that has been placed before this court that
he will probably abscond. The nature of his detention and its effect on him have been summarised by Simon
Brown LJ at para [18] above. Taking account of all these circumstances, I am satisfied that 16 months
detention is unreasonably long.

[57] I would, therefore, allow this appeal on the simple basis that, on an application of principle (ii) above, by 29
May 2002 the appellant had been in detention for an unreasonable period. If I were of the opinion that a
reasonable period had not expired by that date, then I would have to consider principle (iii) and decide whether
it has become apparent that the Secretary of State will not be able to effect deportation within a reasonable
period, I prefer not to express an opinion on this alternative

**[*303]**

question. There are obvious difficulties in deciding when a reasonable period will expire when one has already
decided that a reasonable period has expired.'

**[40] In the English Court of Appeal decision of R (I) v Secretary of State for the Home Dept [2003] INLR 196, Dyson**
LJ stated:

'[48] It is not possible or desirable to produce an exhaustive list of all the circumstances that are, or may be,
relevant to the question of how long it is reasonable for the Secretary of State to detain a person pending
[deportation pursuant to para 2(3) of Sch 3 to the Immigration Act 1971. But in my view they include at least: the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y0W2-00000-00&context=1519360)
length of the period of detention; the nature of the obstacles which stand in the path of the Secretary of State
preventing a deportation; the diligence, speed and effectiveness of the steps taken by the Secretary of State to
surmount such obstacles; the conditions in which the detained person is being kept; the effect of detention on
him and his family; the risk that if he is released from detention he will abscond; and the danger that, if
released, he will commit criminal offences.' (emphasis added)

**[41] The Appellants' complaints, as to the lawfulness of the detention, may be summarized as the following:**

a)   They were not examined by an immigration officer in accordance with the provisions of the IO.

b)   They were not interviewed for the purposes of considering their asylum claims in accordance with the
written policy of the Ministry of Border Control and Labour.

c)   They were not advised of:

(i)   the reasons of the detention;


-----

(ii)   the right to instruct counsel and inability of counsel receive instructions from the Appellants.

d)   All of the elements identified in the case of R v Governor of Durham Prison, ex p Singh _[[1984] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)_
_[ER 983, [1984] 1 WLR 704.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)_

**[42] The Respondents are charged with the burden of showing that the detention was lawful. The learned Chief**
Justice found that:

'on the balance of the probabilities, the respondents have demonstrated that the applicants are not the subject
of unlawful detention. I hold that the detention of the applicants pending removal is lawful, as pursuant to ss
54(3) and 56(4) of the Immigration Ordinance Cap 5:01. In thus holding, I am mindful of the court's duty to
protect and enforce fundamental rights enshrined in the Constitution of Turks and Caicos Islands, including
freedom from the deprivation of liberty and the security of the person, as well as its caveats set out in s 5 …'.

**[43] The Respondents' evidence as to the treatment of the Appellants, up to February 7, 2020, is seen in the**
Affidavit of TCIPF Superintendent Willet Harvey ('the Harvey Affidavit'). Superintendent Harvey, who was the officer

**[*304]**

in charge of the investigation, stated at paras 12, 13, 14, 16 and 18 as follows:

'12. The UK based officers arrived in TCI on the evening of the 25th November later joined by two Tamil
speaking interpreters who arrived from London on Sunday the 1st of December. Their services were secured
through engagement contracts which had to be extended from time to time to facilitate the completion of the
ongoing investigation into the criminal proceedings as well as to conduct specialized interviews. Their contracts
would come to an end on 29th March 2020. As the Senior Investigating Officer from the RTCIPF I worked very
closely with them throughout the process.

13. Interviews commenced with detainees on Tuesday the 3rd December and were recorded on video. There
were ongoing challenges with respect to available resources and further assistance in the form of physical
resources including additional video systems had to be sourced as well as other trained officers from the UK.

14. Through continued investigations and interviews of the remaining detainees, as well as intelligence
received from the Human Rights and Special Prosecutions Section of the United States Department of Justice,
Criminal Division; the United States Attorney for the Southern District of Florida; and the Department of
Homeland Security Homeland Security Investigations (collectively, the U.S. Law enforcement Authorities); the
key investigating team of which I am a part, became aware of the Sri Lanka-based transnational criminal
organization (“TCO”) which was involved in the illicit smuggling of undocumented migrants from Sri Lanka to
the United States before crossing into Canada through Buffalo, New York via the Caribbean (including the
Turks and Caicos Islands). The transport of those illegal migrants would be facilitated through the Caribbean by
way of the Dominican Republic, Haiti, Cuba, Turks and Caicos Islands, and the Bahamas. Others were moved
through South America and Mexico and across the southwest border of the United States.

…

16. The interviews were quite lengthy, challenging and highly complex but were necessary. In the course of the
interview we learned that some of the detainees had left their home over two years ago and their accounts
were long, detailed and harrowing. The interviews have lasted up to six hours in some cases.

…

18. As of midday of the 17.1.2020 we had interviewed eighteen (18) detainees on video as per ABE (Achieving
Best Evidence) and in keeping with TCI Trafficking Ordnance directions that such victims may, in certain
circumstances, give evidence in video. The interview process was concluded on 7th February, 2020.'


-----

**[44] The appropriate starting point in assessing the lawfulness of the detention is an examination of the power of**
the immigration authorities to detain the Appellants. That power arises by virtue of s 54 of the Immigration

**[*305]**

Ordinance. Section 54(1) of the IO provides:

**'Detention of persons liable to examination or removal**

54. (1) A person who may be required to submit to examination under subsection (2), (3) or (4) of section 50 or
under section 51 may be detained under the authority of an immigration officer pending his examination and
pending—

(a) in the case of a person to whom section 50 applies, a decision to give or refuse him leave to enter; or

(b) in the case of a person to whom section 51 applies, a decision whether to recommend his deportation.'

Section 50(2)(c) of the Immigration Ordinance provides:

**'Power of immigration officers to examine persons on entry**

50. (1) An immigration officer may board, and without a search warrant may search any ship or aircraft for the
purpose of exercising his functions under this Ordinance.

_(2) An immigration officer may examine any person who has arrived in the Islands by ship or aircraft for the_
_purposes of establishing—_

(a) whether the person is not an Islander, a British overseas territories citizen or a permanent resident;

(b) if he is not a person within paragraph (a), whether he may or may not enter the Islands without leave; or

_(c) if he may not enter without leave, whether he should be given leave and for what period and on what_
_conditions (if any), or should be refused leave.'_

The law therefore is that the immigration officer was empowered to detain the Appellants on 10 October 2019 upon
their entry, by ship, for the purpose of examining them for the purpose of establishing whether he should be given
_leave and for what period and on what conditions (if any), or should be refused leave. The immigration officer may_
also detain them pending the decision to give or refuse them leave to enter.

**[45] Under the Turks & Caicos Ministry of Border Control and Labour Operations Manual there are references to**
interviews of unlawful entrants. Under the policy manual, dealing with sloops intercepted at sea, it is stated:

'any person who expresses a fear of persecution in their country of origin (or habitual residence) will be
transferred to be interviewed by an official who has knowledge and experience of interviewing asylum
applicants'.

**[46] The evidence in the Harvey Affidavit is incontrovertible that the Appellants were not detained for immigration**
purposes but for criminal purposes, namely to unravel the human trafficking ring and to determine whether the
detainees were victims or involved in the criminal conduct. The immigration authorities outsourced their
investigations to the police, they say, as a result of the complex nature of the investigations. The police authorities
themselves outsourced the investigations to specialist investigators from the

**[*306]**

United Kingdom. When the police investigations ended on 7 February 2020 (4 months into the detention) it was
clear that the investigations which had been conducted were all about the human trafficking investigation and not
any examination of the Appellants with respect to whether they should be given leave and for what period and on


-----

_what conditions (if any), or should be refused leave. The investigation resulted in the identification of Chelliah as the_
human trafficker and charges eventually being laid against him. Six of the detainees had agreed to become
witnesses in the case against Chelliah whilst the remainder (including the Appellants) were earmarked for
repatriation to their home country. The detention of the Appellants, up to 7 February 2020, was therefore not for the
lawful purpose provided for under the IO. They had not been interviewed by an immigration officer for the purposes
of s 54 of the IO.

**[47] Upon completion of the criminal investigation, the Immigration authorities, for the first time, it appears, turned to**
consider the fate of the detainees who had been in their custody since 10 October 2019. That singular
consideration, it seems, was to begin the process to repatriate the detainees whom the police had earmarked for
repatriation. The examination required by s 54 of the IO, which was the basis upon which the Respondent could
detain the Appellants, had not been carried out. On the evidence which was before the learned Chief Justice, such
an examination, could not be said to have taken place prior to 7 March 2020. On that day the Appellants were
presented with IS101 forms seeking their consent to be voluntarily repatriated. On the evidence this is the first
recorded encounter in respect of an immigration related event. Even this encounter, which saw the IS101 form
presented to the Appellants in the presence of an investigator and a Tamil interpreter, could hardly qualify as the
examination contemplated by the IO. In fact, presenting voluntary repatriation forms, presupposed that a decision
had been taken, that the Appellants were to be repatriated (ie refused entry) rather than granted permission to
enter. Respectfully, it was not possible to take such a decision in the absence of an examination.

**[48] The Appellants contend, and I accept, that the forms were presented on 7 March 2020 without the examination**
contemplated by the IO. In fact, there was no evidence that the examination took place even up to the hearing
before the Chief Justice. When the Appellants refused to sign the IS101 forms, it is recorded that they did so on the
basis that they entertained fears of being returned to Sri Lanka. Had the examination, required by the IO taken
place, the written Immigration Policy would have required the immigration officer to cause the Appellants to be
_transferred to be interviewed by an official who has knowledge and experience of interviewing asylum applicants._
This too, on the evidence, clearly did not occur. Either the examination, or the interview, would have revealed that
the Appellants were likely refugees, and not immediately returnable to Sri Lanka.

**[49] Even in the absence of the examination and specialized interview, there was an abundance of indications that**
the Appellants were or could be refugees. These indicia include:

**[*307]**

(a)   At the time of the initial discovery of the Haitian sloop, the Respondents say that immediate concerns
arose that these detainees may be victims of human trafficking or **_modern slavery and therefore_**
potentially vulnerable persons;

(b)   The police accounts of the interviews conducted with the detainees revealed harrowing accounts;

(c)   The Minister of Border Control and Labour (according to the Respondents) was furnished with three
letters from Members of Parliament in Sri Lanka dated 25 January, 2020; 29 January, 2020; and 29
February 2020. These letters disclosed allegedly troubling circumstances for each of the Appellants, details
of security concerns and the very present need for them to be out of Sri Lanka in order for their lives to be
preserved.

(d)   On 14 February 2020, in the course of seeking assistance from the Canadian authorities with respect
to the detainees transiting through Canada, the Canadian authorities refused to assist on the basis of a
fear that the Appellants would seek asylum in Canada; and,

(e)   On 7 March 2020, when the Appellants refused to sign the IS101 voluntary repatriation form, they
each indicated a fear of persecution if they were to be returned to Sri Lanka.

**[50] The evidence of the Respondents also did not reveal compliance with the fundamental rights requirements**
under s 5(3) and 5(4) of the Constitution of the Turks and Caicos Islands, namely:


-----

(i)   that a person detained be informed promptly, in a language that he or she understands, of the
reasons for his or her arrest or detention and of any charge against him or her (s 5(3)); and,

(ii)   that a person who is arrested or detained shall have the right, at any stage and at his or her own
expense, to retain and instruct without delay a legal representative of his or her own choice, and to hold
private communication with that representative (s 5(4)).

Insofar as s 5(4) of the Constitution speaks to the right to retain and instruct a legal representative, the courts have
held that unless the detainer is impressed with the obligation to inform the detainee of that right any such right to
[retain and instruct legal representation is meaningless (See A-G v Whiteman [1991] LRC (Const) 536 at 549–550,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KP9-CMW1-DYJ0-84JR-00000-00&context=1519360)

[1991] 2 AC 240 at 246). The nature of the Respondents' evidence is in terms of what would ordinarily happen and
what the practice was, not that the Appellants in this case were informed. Having regard to the fact that there was a
language barrier, up to early December 2019, such a conversation likely did not occur and if it did, the
Respondents, upon whom the legal burden rests, could easily have indicated. Additionally, as the police interviews
were said to have been video recorded, the ability to prove (or confirm) that it occurred, ought not to have been a
difficult prospect for the Respondents.

**[51] Breaches of public law, such as occurred in:**

(1)   the breach of the written immigration policy; and

(2)   the failure to inform of the right to legal counsel and of the purpose of the detention, when exercising
a discretionary power to detain, renders

**[*308]**

the subsequent detention unlawful (ie amounts to the tort of false imprisonment) if the breach bears on and
is relevant to the decision to detain. See R (on the application of Lumba) v Secretary of State for the Home
_[Dept, R (on the application of Mighty) v Secretary of State for the Home Dept [2011] UKSC 12, [2011] 4 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_
_[ER 1, [2012] AC 245.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_

**[52] There was a mixed-bag of detainees who appeared before the learned Chief Justice. The law requires that the**
immigration authorities, and by extension the Court in considering a detainee's case, consider the circumstances of
his case individually. The Chief Justice's findings however, that their detention pending removal was lawful, reflects
a universal treatment of the detainees which did not properly consider the peculiar nature of these three Appellants.
So, whilst the majority of the detainees in the action below had agreed to be repatriated voluntarily these Appellants
could not have been repatriated in the same manner. The onset of the Covid-19 pandemic and the associated
delays arising from border closures, which appeared to weigh heavily in the learned Chief Justice's reasoning,
could not be said to impact the Appellants' detention as it very likely impacted the other detainees. In fact, as it has
now transpired, the Appellants were not removable by the Respondents, as they were entitled to undergo the
asylum process.

**[53] Clearly, had the examination occurred at the earliest (or most reasonable) opportunity, as it ultimately was,**
subsequent to the Chief Justice's decision, it would have been determined that these Appellants were not
removable without embarking upon the refugee/asylum process. It is accepted that the entry of the Appellants into
the TCI was unlawful and that there were real challenges in communicating with them for the purposes of
conducting the examination of them as required by the IO. Putting aside the delays in securing the services of Tamil
interpreters, or the fact that the authorities did not consider remote means for translation services, the failure to
examine them for immigration purposes beyond the arrival of the Tamil interpreters in early December is
unreasonable and inexcusable.

**[54] I am satisfied that the principles identified in R v Governor of Durham Prison, ex p Singh were offended by the**
Respondents, in large measure, in that:

(1)   the power to detain was not used for the immigration-related examination, for which it was designed,
but actually used to investigate the criminal offences of Chelliah;


-----

(2)   the period of time for which the Appellants were detained was not reasonable in the circumstances
as these were not criminals but vulnerable individuals seeking refuge;

(3)   there were barriers to any removal of the Appellants and therefore no purpose in properly detaining
them while these barriers existed and no prospect of imminent removal; and

(4)   no due diligence or expedition was demonstrated by the immigration authorities in discharging their
responsibilities under the IO.

Respectfully therefore, the decision of the Chief Justice, that the detention of the Appellants was lawful, cannot be
supported and must be set aside.

**[55] Putting aside any question of propriety, having determined that the**

**[*309]**

detention of the Appellants was unlawful, the need to determine whether their continued detention following the
Chief Justice's decision was also unlawful, has become unnecessary.
_Whether the Appellants may pursue constitutional relief in this Appeal_

**[56] The Appellants say that there are two very distinct complaints concerning constitutional violations in this case:**

(1)   The treatment of the Appellants during their detention, including failures or delays in informing them
of the basis for their detention or their right to access a lawyer to address their immigration detention
engaging s 5 of the Constitution ('Substantive Constitutional Claims'); and

(2)   The conduct of the hearing and the production on the Writ of Habeas Corpus. These are issues of
procedural fairness and of complying with the obligation to produce at such a hearing engaging s 6 of the
Constitution. ('Procedural Constitutional Claims')

**[57] The Respondents have raised the issue as to whether the reliefs sought above, which are constitutional in**
nature, may be raised on this appeal. At paras 104, 105, 107 and 108 of their submissions, they state:

'104. Your Lordships are being invited by the Appellants to consider the question [the constitutionality of Reg
4(1)] not as a matter of appeal but as a court of first instance. It is the Respondents submission that the Court
of Appeal does not have any jurisdiction to do. The question of whether or not the said regulation now infringe
the constitutional rights of the Appellants has not yet been considered by the lower court. The jurisdiction of the
Court of Appeal to deliberate upon this question will only arise after it has been considered and adjudicated
upon by the Supreme Court.

105. Section 21 of the Turks and Caicos Island Constitution gives the High Court original jurisdiction to hear
and determine any such application, and to give such directions as may be appropriate for the enforcement of
the protection to which the person concerned is entitled under the provisions of Chapter 1 of the Constitution.

…

107. The Respondent's argument is that the Court of Appeal does not have an original jurisdiction comparable
to the original jurisdiction of the Supreme Court recognized or conferred by section 21(1) and (2) of the
Constitution, and that to order the unconstitutionality of the Emergency Powers (COVID-19) (Court
Proceedings) Regulations 2020 (“the Regulations”) is beyond its jurisdiction as an appellate body reviewing the
trial proceedings, as distinct from the jurisdiction which the Court of Appeal would have had if it were hearing
an appeal from an application to the High Court based on the unconstitutionality of the said Regulations.

**[*310]**

108. The separation of the jurisdiction of the Court of Appeal, as an appellate body in civil proceedings, from
any decision as to the constitutionality of any piece of legislation is apt in these proceedings and must be
carried out '


-----

**[58] The Appellants' response to the objection was to be found at paras 10–12, 16–17, and 18–20 of their**
submissions that:

'11. Section 21 of the Constitution bestows on the Supreme Court an original jurisdiction to hear allegations of
breach of Part 1 of the Constitution. That is an additional cause of action and does not prejudice any other
action an individual may commence: s.21(1); and the similar consideration by the Cayman Islands Court of
Appeal in Coe v Governor [2014] (2) CILR 465 at [82]–[83] identifying the constitutional cause of action did not
replace judicial review. Importantly, on the very language of section 21, it does not exclude this Court
considering such issues raised for the first time: see 21(3).

12. This Court ought not to be prevented from upholding constitutional values and fundamental rights. Any
judgment this Court delivers can fully respect such values. That is consistent with section 19 of the Constitution
Order.

…

16. The granting to the Supreme Court original jurisdiction in respect of alleged breaches of Part 1 of the
Constitution simply prevents its exercise also of an appellate jurisdiction in respect of such allegation.

17. On appeal from Antigua and Barbuda, the Eastern Caribbean Court of Appeal in Rashid A. Pigott v The
Queen ANUCRAP2009/0009 considered whether Section 18(1) and 18(2) of the Antigua and Barbuda
Constitution preclude raising for the first time in the Court of Appeal issues of alleged constitutional breach.
Sections 18(1), 18(2) and 18(3) are strikingly similar to Section 21 of the Constitution and read as follows (and
which are quoted in Pigott at [23]:

…

18. In Pigott the ECCA (Thom JA.) rejected the argument that the appellate court was unable to determine the
issue of alleged constitutional breach [18] on the basis that the lower court has been granted original
jurisdiction. In so deciding Pigott actually granted a declaration as to constitutional breach [47] as to delay
impeding fair trial rights.

19. Pigott relied on two decisions on appeal to the Privy Council from Trinidad and Tobago. In Ramesh
Lawrence Maharaj v Attorney General of Trinidad and Tobago (No.2) (1978) 30 WIR 310 and at 321f-g (Lord
Diplock):

“a party to legal proceedings who alleges [in appellate proceedings] that a fundamental rule of natural justice
had been infringed in the course of the determination of his case, could in theory seek collateral relief in an
application to the High Court … with a further right of appeal to the Court of Appeal … The High Court,
however, has ample

**[*311]**

powers both inherent and under [the Trinidad Constitutional provision] to prevent its process being misused in
this way; for example it could stay the proceedings …”

20. The second Privy Council decision referred in Pigott is Chokolingo v Attorney General (1980) 32 WIR 354
at 359e-f (also Lord Diplock).

“To give Chapter 1 of the Constitution an interpretation which would lead to this result [of parallel remedies]
would in their Lordships' view, be quite irrational and subversive of the rule of law which it is a declared
purpose of the constitution to enshrine.” '

**[59] Section 21 of the Constitution of the Turks and Caicos Islands provides:**

**'Enforcement of fundamental rights**


-----

21. (1) If any person alleges that any of the foregoing provisions of this Part has been, is being or is likely to be
contravened in relation to him or her, then, without prejudice to any other action with respect to the same
matter which is lawfully available, that person may apply to the Supreme Court for redress.

(2) The Supreme Court shall have original jurisdiction—

(a) to hear and determine any application made by any person in pursuance of subsection (1); and

(b) to determine any question arising in the case of any person which is referred to it in pursuance of
subsection (3),

and may make such orders, issue such writs and give such directions as it may consider appropriate for the
purpose of enforcing or securing the enforcement of any of the foregoing provisions of this Part to the
protection of which the person concerned is entitled; but the Supreme Court shall not exercise its powers under
this subsection if it is satisfied that adequate means of redress are or have been available to the person
concerned under any other law.

(3) If, in any proceedings in any court established in the Islands other than the Supreme Court or the Court of
Appeal, any question arises as to the contravention of any of the foregoing provisions of this Part, the court in
which the question has arisen shall refer the question to the Supreme Court, unless, in its opinion, the raising
of the question is merely frivolous or vexatious.'

**[[60] The Respondents relied upon the Privy Council decision in Hunte v State [2015] UKPC 33, [2016] 1 LRC 116,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J3S-T981-DYJ0-80W3-00000-00&context=1519360)**
_[(2015) 40 BHRC 633.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KJ3-1C51-DYBP-W54H-00000-00&context=1519360)_ In that case, during the course of the hearing before the Court of Appeal, the appellants
raised the constitutional complaint that their death sentences ought to be commuted. They argued that the passage
of time since the sentences were passed, rendered them unconstitutional. The Board dismissed the appeal on the
basis that the sentences of death were lawful and mandatory at the time of imposition. It was held that the Court of
Appeal had no jurisdiction under the Supreme Court of Judicature Act [Trinidad] to entertain appeals against

**[*312]**

their sentences. The Court of Appeal had not been asked to do so, but rather the complaint was that the execution
of the sentences of death would be unconstitutional through passage of time. The appellants' appeal to the Privy
Council was dismissed.

**[61] The Board had this to say:**

(a)   Section 14(1)–(2) of the Trinidad Constitution [which is similar to ss 21(1)–(2) of the Turks and
Caicos Islands Constitution] grant original jurisdiction to hear and determine applications as to
constitutional violations to the High Court of Trinidad and Tobago however no such application was made
by Hunte.

(b)   If the Board allowed these appeals against sentences, it would be making an order which the Court
of Appeal would have had no jurisdiction to make and would be exercising an original jurisdiction which it
does not have.

**[[62] In Bowe v R [2006] UKPC 10, [2006] 4 LRC 241, [2006] 1 WLR 1623, the Privy Council, approving Chokolingo,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84MJ-00000-00&context=1519360)**
settled the issue of the undoubted jurisdiction of the Court of Appeal to deal with constitutional challenges which
arose in their courts. That case was a challenge to the mandatory death penalty in The Bahamas. In _Hunte, the_
Privy Council distinguished Bowe v R, and stated:

'[55] The sentence of death passed on the appellants was fixed by law: Offences Against the Person Act 1925,
s 4. If it were argued that the law purportedly imposing a mandatory death sentence was itself unconstitutional,
the Court of Appeal would have jurisdiction to entertain an appeal against such a sentence on the ground that it
was not a lawful sentence at all: _Bowe v R_ _[2006] UKPC 10,_ _[[2006] 4 LRC 241. But in this case there is no](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84MJ-00000-00&context=1519360)_
dispute that the sentence imposed on the appellants was lawful and mandatory.


-----

…

[93] In Bowe v R _[[2006] UKPC 10, [2006] 4 LRC 241, the Privy Council held that virtually identical provisions in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84MJ-00000-00&context=1519360)_
the Court of Appeal Act of The Bahamas did not preclude that court from entertaining the argument that the
death penalty was not, in fact, “fixed by law ” because it would be unconstitutional to impose it. Furthermore, a
challenge to the constitutionality of the penalty did not have to be taken through a separate constitutional
motion under the Bahamian equivalent of s 25 of the Constitution of Jamaica and s 14 of the Constitution of
Trinidad and Tobago, but could be taken on an appeal against sentence. The Constitution obviously
contemplated that the courts could remedy a breach of the constitution if the question arose in ordinary
proceedings before them. The Board distinguished _Walker_ on the basis that there the sentences had been
constitutional when passed – it was only the passage of time which had rendered it unlawful for the sentence to
be carried out (at [11]).'

**[63] Although none of the Substantive Constitutional Claims was sought by**

**[*313]**

the Appellants at the hearing below, the complaints concerning s 5 of the Constitution were before the learned Chief
Justice as part of the challenges to the lawfulness of the detention. In my view this court need not trouble itself with
considering the propriety of the Appellants' application to introduce the Substantive Constitutional Claims. There are
ample reasons for not doing so. These include:

a)   Habeas Corpus applications are discrete specialized applications which are not ordinarily conflated
with other relief or constitutional claims. In fact, a review of the prescribed forms reveals that they do not
allow, as Mr Prudhoe has conceded, for adjustment to expand the nature of the claim. (See Bethel v Jean_Charles_ (SCCivApp No 26 of 2018) (17 October 2018)). Freestanding constitutional relief is generally
pursued by separate action in the court below, even if the judge (as often occurs) determines to hear them
together.

b)   Even if I were satisfied that the Substantive Constitutional Claims were made out, it would still require
the matter to be remitted to the Supreme Court for assessment. That remittal process would require proper
pleadings to be settled and evidence presented. In this vein there is no prejudice to the Appellants to have
to commence a new claim for relief for the unlawful detention. I did not find that the absence of legal aid, as
proffered by the Appellants, was a sufficient basis not to require a new action.

c)   Having been released and it having been determined that the detention was unlawful, the only benefit
which may accrue to the Appellants in adding the Substantive Constitutional Claims, which was not
available under the Habeas Corpus process, is that of compensation for wrongful or unlawful detention.
Compensation for unlawful detention is undoubtedly akin to false imprisonment, which is an adequate
remedy and available under the common law. As much was conceded by Mr Rule on behalf of the
Appellants. Section 21(2) of the Constitution prohibits the Court from considering claims for breaches of
fundamental rights, such as the Substantive Constitutional Claims, if it is satisfied that adequate means of
redress are or have been available to the person concerned under any other law.

The Appellants' applications for consideration of the Substantial Constitutional Claims are therefore refused. It is
open to the Appellants to commence separate proceedings for compensation for their unlawful detention.

**[64] In the Procedural Constitutional Claims, the Appellants complain about the procedure employed by the**
Learned Chief Justice at the hearing of the Writ of Habeas Corpus and the production of the Appellants. In
particular, those complaints may be summarized as follows:

a)   the Appellants were required to attend via live video link rather than in person as was their
preference;

b)   the quality of the production of the Appellants, which did not permit them to attend for the entirety of
the hearing was inadequate and ineffective.


-----

**[*314]**

These claims, which challenge the process utilized by the Chief Justice, arose out of the proceedings below. It is
therefore open to the Appellants to raise these challenges in the Court of Appeal as a part of the challenge to the
decision of the learned Chief Justice. In fact, as these matters arose out of these proceedings, the authorities
suggest that they may not be raised if not taken on appeal. The effect of the Privy Council decision in Independent
_[Publishing Co Ltd v A-G, Trinidad and Tobago News Centre Ltd v A-G [2004] UKPC 26, [2005] 1 LRC 222, [2005] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-82RX-00000-00&context=1519360)_
AC 190is that the Supreme Court should not entertain collateral applications for constitutional redress in respect of
judicial errors where the legal system provides the ability for an appeal.

**[65] The quality of the production was clearly far from adequate. As much was recognized by the Learned Chief**
Justice in her ruling of 1 May 2020, where she stated:

'The impact of COVID-19 on all spheres of life at this time cannot be denied; this is a matter of which the court
can take judicial notice. So great is the impact in fact that this hearing has been conducted in a most unusual
manner that in the ordinary scheme of things would have been open to challenge due to the observance of
social distancing protocols.'

A review of the transcripts however, demonstrates that the Appellants made it clear that they didn't want an
adjournment to permit some alleviation of the production challenges. At page 34 of the official transcript it is
recorded:

'MR. TIM PRUDHOE: Well, let me be clearer about my position. I don't want an adjournment. I have – I face an
invidious choice. The response is not satisfactory because it's quite clear from the current regulations in place
that as a substitute to in-person hearing that the attendance by those being produced on writs of _habeas_
_corpus, (inaudible) he is expressly clear, and this is not a proper production if all that happens in relation to the_
particular applicants is they identify themselves and then led away.

HER LADYSHIP: Mr Prudhoe, at this point I am not sure what your pleasure is because you have heard from
Miss Hippolyte that the room that they could secure to enable them to make the applicants visible to the court
is a small room, and they have to observe social distancing according to regulations. That is what they can do.
We can adjourn this matter while they look for a bigger room, or we can proceed as we are doing. But I will not
put them in one room. I will not put fifteen people in one room that can only take five in order for them to
observe social distancing. It's entirely up to you, Mr Prudhoe.

MR. TIM PRUDHOE: I'm – let me be clear again, I am not asking for adjournment. I am simply stating the
position of the applicants that this is not a proper production. I am ready to proceed.

HER LADYSHIP: And I am saying that, for the purposes of the court, it is a proper production. That's why I took
pains and took so much time to make sure that each one was identified. It's unfortunate that they cannot be in
the same room. But we all know that COVID-19 has turned the

**[*315]**

world on its head, and we are doing the best we can in the circumstances. And if all they can produce is a room
that can take five at once, then I am satisfied with it as the Court. And if you do not object to it, you proceed.

MR. TIM PRUDHOE: I'm obliged. Thank you. Now, that we have been through the materials that are available
to the Court, I am wondering if I may ask the question whether the Court has had the opportunity to read those
materials in a prereading way.'

Putting aside any question as to the lawfulness of the production, it seems that the learned Chief Justice could
hardly be faulted for proceeding with the hearing notwithstanding the objections/complaints of Counsel for the
Appellants. In any event having determined that the detention was unlawful, any detailed interrogation of this matter
has essentially been rendered otiose.
_Di_ _iti_


-----

**[66] In all the circumstances therefore, I would allow the appeal, setting aside the decision of the Chief Justice and**
grant the declaration that at the time of the hearing of the Writ of Habeas Corpus application the Appellants were
being unlawfully detained by the Respondents.

**[67] The Appellants shall be entitled to their costs in the appeal and in the court below, such costs to be taxed if not**
agreed.

**JOHN JA.**

I agree.

**MOTTLEY P.**

**[1] The Turks and Caicos Islands consists of 8 main Islands and more than 22 smaller Islands. The land area of the**
Islands is approximately 616.3 square kilometers. The islands form a chain which stretch north to south. The
borders of the Islands are open without any security except in some of the larger Islands. The Islands are
vulnerable to human trafficking and smuggling. Sri Lanka is an Island in the Indian Ocean about 15560 kilometers
away from the Turks and Caicos Islands ('TCI').

**[2] On 10 October 2019, a Haitian sloop with 154 persons onboard was intercepted in the territorial waters of the**
Turks and Caicos Islands by the Marine Branch of the Royal Turks and Caicos Islands Police Force ('RTCIPF').
Because of the porous nature of the borders of TCI, the immigration authorities have serious concerns about
human trafficking and/or smuggling. On board on the sloop were twenty-eight (28) Sri Lankan nationals (including
the appellant) and one (1) Indian national (all males). The Sri Lankans and the Indian national were detained at the
Immigration Detention Center, where they were under the control of the Department of Immigration and Border
Control. The assistance of the RTCIPF was sought to assist the Immigration Enforcement Unit with the
investigations into the circumstances surrounding the Sri Lankan Nationals being in the territorial waters of the
Turks and

**[*316]**

Caicos Islands. It was a very unusual occurrence to have Sri Lankan nationals illegally or unlawfully seeking to
enter the Turks and Caicos Islands.

**[3] It is a criminal offence under s 102 of the Immigration Ordinance Cap 5.01 ('the Ordinance') for a person to enter**
TCI from any place outside of the Islands unless leave has been given to do so by an Immigration Officer. It was in
these circumstances that the Sri Lankans including the appellants had been detained.

**[4] On 31 March 2020, Simons J (Ag) made an Order for a Writ of Habeas Corpus ad Subjiciendum to be issued to**
the First Respondent as Director of Immigration.
**Judgment of Chief Justice**

**[5] Following a hearing of the application by the Chief Justice on 24 April 2020, judgment was delivered on 1 May**
2020. The Chief Justice stated 'the respondents on whom the burden lay to demonstrate the lawfulness of the
_applicants' detention have discharged that burden by showing a continuing intention to repatriate the applicants_
_even in the face of the travel issues raised by COVID-19 pandemic. The continued engagement of Sri Lankan_
_authorities by IOM on behalf of the first respondent indicates that the first respondent is not lax regarding his duty to_
_effect the repatriation.'_

**[6] The Chief Justice was satisfied that, at that time, the delay in removing the applicants from TCI was for just**
cause, and therefore it did not affect the legality of the detention. She stated that it went without saying that should
the detention of the applicants continue even after the restrictions on air travel had eased in both TCI and Sri
Lanka, the detention, now lawful will at that point become unlawful.


-----

**[7] The Chief Justice concluded that in her view, the detention of all the fifteen illegal immigrants (including the**
appellant who had refused to sign voluntary repatriation) was lawful in the beginning as done pending their removal
from the Islands, continued to be lawful in spite of the delay in repatriation caused by the unforeseen circumstance
of COVID-19.

**[8] The Chief Justice stated that she was satisfied that on the balance of the probabilities, the respondents had**
demonstrated that the applicants were not being unlawfully detained.

**[9] She went on to hold that the detention of the applicants pending removal was lawful, as pursuant to ss 54(3) and**
56(4) of the Ordinance.

**[10] The Chief Justice pointed out that she was mindful of the court's duty to protect and enforce fundamental rights**
enshrined in the Constitution of Turks and Caicos Islands ('the Constitution'), including freedom from the deprivation
of liberty and the security of the person, as well as its caveats set out in s 5, and more particularly s (2)(h) of the
Constitution of the Turks and Caicos Islands.

**[11] The Chief Justice declined to interfere with the detention of the applicant at that time, as she considered the**
delay in repatriation was sufficiently explained as justified, especially as she stated, she was satisfied that the first
respondent's intention to repatriate was active and continuing, and there is some prospect of achieving it without
unreasonable delay.

**[*317]**

**[12] The Chief Justice declared that the detention of the Applicants from 10 October 2019 up to the** _date of the_
_hearing was deemed lawful having regard to all the circumstances and no order for release would be made at that_
time.

**[13] The appellants filed an amended Notice of Appeal against the Declaration of the Chief Justice in which she**
stated that the appellants' detention was deemed lawful and that no release would be ordered.

**[14] The second ground dealt with the appellants' objection, both to the production of the applicants on the Writ of**
Habeas Corpus of 21 April 2020 ('the Writ') via video and audio facilities and the incomplete or partial appearance
in that way of each of the Appellants from the Immigration Detention Centre, South Dock Road, Providenciales.

**[15] The appellants sought Orders from this Court that the appellants' detention was or is now unlawful and**
consequently the appellants should be released from detention. The appellants also sought orders that there was
neither adequate production of the appellants on the Writ nor sufficient appearance of each of the appellants
thereon.

**[16] It is common ground between the parties that the appellants were no longer in custody, having been released**
on 24 August 2020.

**[17] Counsel for the appellants submitted that under the Rules of the Court of Appeal, r 11.1, an appeal before the**
Court of Appeal is by way of re-hearing. Counsel submitted that this Court is therefore required to review the
purported justification for detention advanced by the Respondent subsequent to the hearing of the applications for
habeas corpus. This Court is invited by counsel to reach the contrary conclusion to that reached by the court below
which held that the detention from 10 October 2019 to the date of 24 April 2020 'is deemed lawful having regard to
_all the circumstances and no order for release shall be made at this time'. It was submitted that this Court should_
consider the matter both as at 24 April 2020, by which date it is submitted the detention was already unjustified, but
also as at the date of hearing of the appeal. It was argued that to do otherwise would be a failure on the part of the
Court of Appeal to exercise the vigilant supervision over detention that is the raison d'etre of the court's habeas
jurisdiction and right of appeal to speedily bring the request for the jealous safeguard of and return of liberty before
this Court. It was also contended on behalf of the appellants that this Court should not only review the decision of
the respondents to detain the appellants, but, instead, it has a duty to ascertain for itself whether the decision was
lawful.


-----

**[18] In the written submissions on behalf of the respondent, it was submitted that the appellants are constrained by**
the restriction with respect to the filing of fresh evidence which had not been brought before the judge in the court
below. The evidence sought to be introduced was not 'fresh' evidence as that term is generally understood, for it
was not evidence in existence at the time of trial which could have affected the result. Instead, it was contended
that it is evidence of events that occurred subsequent to the trial judgment. Generally speaking, the need for
certainty and finality leaves no room for the admission of such evidence on appeal.

**[19] Counsel for the respondent submitted that a rehearing as expressly stated in r 11 of the Court of Appeal Rules**
could not be interpreted as a

**[*318]**

rehearing 'in the fullest sense of the word'. It was argued that rehearing on appeal under RSC Orders 55 and 59
were well understood not to extend to rehearings in the fullest sense of the word. Further, it was suggested, that the
Court did not hear the case again from the start but reviewed the decision under appeal giving it the respect
appropriate to the nature of the court, the subject matter and, importantly, the nature of those parts of the decision
making process which were challenged. Ascribing one label or the other is a semantic exercise which does not
answer such questions of substance as arise in any appeal.

**[20] The respondents respectfully submitted that the attribution of the label 'rehearing' is not, other than**
exceptionally, necessary to enable the court upon a hearing by way of review to make the evaluative judgments
necessary to determine whether the decision under appeal was manifestly wrong. The court will not normally
interfere with the exercise of a discretion unless the decision of the lower court was reached on wrong principles or
was otherwise plainly wrong. And this can be done on a hearing by way of review. It was said that Although r 11 of
the Court of Appeal Rules expressly refers to a rehearing, the exercise upon which this Court was engaged was
essentially one of review. In assessing whether the judge was clearly wrong in her assessment that the detention
up to the 24 April, 2020 was lawful, this Court must have a full appreciation of the facts of this case.

**[21] The issue for determination is whether this Court is to have regard to what transpired after 1 May 2020, the**
date on which the Chief Justice delivered her judgment and made the declaration relating to the validity of the
detention of the applicants.

**[22] On 14 September 2020, an Agreed Chronology was filed which showed the following:**

– 23 April 2020 Notice of Intention to Deport – served on the Appellants.

– 1 May 2020 Extension of time granted by the Hon Minister of Immigration to 6 May 2020 for
representations in respect of the Notice of Intention to Deport.
Prudhoe Caribbean letter requesting further time to make representations in respect of Notices
of Intention to Deport sent to Hon Minister of Immigration and bring attention to Respondents'
failure to adhere to and carry out their own policy governing the immigration and thus detention
issues concerning the Appellants.

– 6 May 2020 Letter from Prudhoe Caribbean raising concerns about the insufficiency of the time period
permitted in which to make representations.

– 8 May 2020 Email/Letter correspondence from Hon Minister of Immigration indicating the need to have
evidence of fear of persecution etc and extending time for submission of the same to 14 May
2020.

– 14 May 2020 Letter Correspondence from Prudhoe Caribbean with representations in respect of the
Appellants.

**[*319]**

Notice of Appeal filed on behalf of the Appellants in respect of the 1 May 2020 decision of
Chief Justice Mabel Agyemang.

– 20 May 2020 Appellants' Notice of Motion for Judicial Review of the decision of the Minister of Border
Control and Labour to issue Notices of Intention to deport, without first having them


-----

interviewed by an official with the knowledge and experience of interviewing asylum
applicants.

– 19 June 2020 A1, A2 and A3 undergo UNHCR registration and refugee status determination interviews (part
1 of 2). A's Lawyers unaware.

– 22 June 2020 A1 completes UNHCR process.
A's lawyers unaware.

– 24 June 2020 A2 completes UNHCR process. A's lawyers unaware.
3 affidavits sworn by the Appellants in support of judicial review proceedings (against the
decision on 1 May 2020).

– 10 July 2020 Letter from the UNHCR to the 1st Respondent requesting the release from detention of the
three appellants following their registration as refugees.

– 23 July 2020 Advisory opinions in respect of the Appellants (disclosed to Appellants' lawyers on 11
September 2020) and all make the same recommendation.

– Release from detention of the Appellants takes until 24 August 2020.

– 24 August 2020 Ministry of Border Control and Labour conditionally releases all Sri Lankan detainees from
detention including litigants in CL100 and CL102/2020 – IS96 forms signed without
Respondents' prior notice or consultation with Prudhoe Caribbean in respect of their clients.

**[[23] In determining this issue, I have regard to the following cases: Curwen v James [1963] 2 All ER 619, [1963] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-60WR-00000-00&context=1519360)**
[WLR 748, Murphy v Stone Wallwork (Charlton) Ltd [1969] 2 All ER 949, [1969] 1 WLR 1023.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35T0-TWP1-6145-00000-00&context=1519360)

**[24] In** _Curwen v James, the defendants appealed the amount of damages awarded to the plaintiffs, who had_
remarried before the expiry of the time for giving Notice of Appeal. They sought leave 'under RSC, Ord 58, r 9(2), to
_adduce evidence of the widow's re-marriage on the ground that, if it was granted, they would contend that, by her_
_re-marriage, the widow had not lost the financial support assessed by the judge. The defendants tendered no_
_[evidence as to the amount by which the re-marriage was benefiting the widow.' [Quotation from [1963] 2 All ER 619](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-60WR-00000-00&context=1519360)_
headnote].

**[[25] In his judgment, Sellers LJ stated ([1963] 2 All ER 619 at 622, [1963] 1 WLR 748 at 751–752):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-60WR-00000-00&context=1519360)**

'There is the citation relied on from the speech of Lord Gorell in _A-G v Birmingham, Tame and Rea District_
_[Drainage Board ([1911–13] All ER Rep 926 at p 939; [1912] AC 788 at p 801), where he says:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)_

“Under the Judicature Acts and rules the hearing of an appeal from the judgment of a judge is by way of rehearing, and the court has power to give any judgment and to make any order which ought to have been made,
and to make such further or other order as the court

**[*320]**

may think fit … The court also has power to take evidence of matters which have occurred after the date of the
decision from which the appeal is brought … It seems clear, therefore, that the Court of Appeal is entitled and
ought to re-hear the case as at the time of re-hearing …”

In that case, they sought to adduce fresh evidence of something which they had done afterwards which altered
the effect of the injunction which had been granted.'

**[[26] In his judgment Pearson LJ stated ([1963] 2 All ER 619 at 623–624, [1963] 1 WLR 748 at 754):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-60WR-00000-00&context=1519360)**

'It appears from RSC, Ord 58, r 3(1), that “An appeal to the Court of Appeal shall be by way of re-hearing …”
[As my lord has pointed out, in A-G v Birmingham, Tame & Rea District Drainage Board ([1911–13] All ER Rep](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)
_[926 at p 939; [1912] AC 788 at p 801), Lord Gorell dealt with this matter, and he said in terms](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)_

“It seems clear, therefore, that the Court of Appeal is entitled and ought to re-hear the case as at the time of rehearing …”


-----

It follows, therefore, that, once the evidence of the new event (that is to say, the event which has occurred after
the date of the trial or hearing) has been admitted, the new event should be taken fully into account and the
decision should be given in the light of all the evidence, including the evidence as to the new event which has
occurred—in this case, the re-marriage of the plaintiff, who brought the action under the Fatal Accidents Act,
1846.'

**[27] In** _Murphy v Stone Wallwork (Charlton) Ltd, the House of Lords had to determine whether it would hear_
[evidence of events occurring after the judgment. Lord Pearce stated ([1969] 2 All ER 949 at 952–953, [1969] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35T0-TWP1-6145-00000-00&context=1519360)
WLR 1023 at 1027–1028):

'An appellate court has power to hear evidence of something which has altered the effect of an order of the
court below since that order was made. In A-G (at the relation of Tamworth Corpn) v Birmingham, Tame and
_Rea District Drainage Board, Lord Gorrell said ([1912] AC at p 801; [1911–13] All ER Rep at p 939.):_

“The Court also has power to take evidence of matters which have occurred after the date of the decision … It
seems clear, therefore, that the Court of Appeal is entitled and ought to re-hear the case as at the time of rehearing …”

RSC, Ord 59, r 10(2), dealing with the Court of Appeal's power provides that

“… no such further evidence (other than evidence as to matters which have occurred after the date of the trial
or hearing) shall be admitted except on special grounds.”

**[*321]**

The words in brackets show that no special grounds are needed to justify the admission of evidence of things
that have occurred since the date of trial. In my opinion, your Lordships' House is equally entitled to consider
such evidence. But the cases in which it does so will be exceptional.

In Curwen v James the Court of Appeal in a fatal accident case allowed the defendants to adduce evidence of
the plaintiff widow's remarriage after the trial and reduced her damages accordingly. At the trial the widow had
not been asked about her marriage prospects since she had emotionally broken down in the witness box.
Sellers LJ there said ([1963] 2 All ER at p 622; [1963] 1 WLR at p 752.):

“In the present case … it is desirable that the court should decide the matter on the known fact of the marriage
rather than that it should remain decided on an uncertainty for the future as it stood before the learned judge.”

Harman LJ said ([1963] 2 All ER at p 623; [1963] 1 WLR at p 753.):

“There is an important principle here involved and it is that the court should never speculate where it knows.”

And Pearson LJ said ([1963] 2 All ER at p 624; [1963] 1 WLR at p 755.):

“… I think it right to emphasise what has already been pointed out—that, in this case, the event in question
occurred quite soon after the trial or hearing …” '

**[[28] In his judgment, Lord Upjohn stated ([1969] 2 All ER 949 at 955–956, [1969] 1 WLR 1023 at 1030–1031):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35T0-TWP1-6145-00000-00&context=1519360)**

'On the other hand, where damages have to be assessed on estimates as to the future, the likelihood of
dismissal or further ill-health, or in the case of a widow making a claim under the Fatal Accidents Acts the
probability of her remarriage (these are, of course, only examples), then the court does in proper cases look at
the facts that have happened since judgment. So far as the Court of Appeal is concerned the matter is
governed by the express terms of RSC, Ord 59, r 10(2), giving that court a general discretion to admit evidence
of matters that have happened since the date of the judgment (see the opinion of Lord Gorrell in A-G (at the
[relation of Tamworth Corpn) v Birmingham, Tame and Rea District Drainage Board ([1912] AC 788 at p 801;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)

_[[1911–13] All ER Rep 926 at p 939.)). Your Lordships' House has no similar rules of procedure governing your](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-214G-00000-00&context=1519360)_


-----

Lordships, but I have no doubt that your Lordships have ample power to admit further evidence in cases which
seem proper to your Lordships.

Curwen v James, in the Court of Appeal shows that the jurisdiction must be exercised sparingly and with due
regard to the great principle that a judgment once obtained is not to be disturbed without “solid grounds”. That
case was, in my opinion, plainly rightly decided. I agree

**[*322]**

with all the judgments of the court, but the broad reasons given by Harman LJ ([1963] 2 All ER at p 623; [1963]
1 WLR at p 753.), for allowing the what happened so shortly after the judgment of the Court of Appeal. That
evidence being admitted the judgment is at once shown to be on a false basis and, since the hearing before
your Lordships, the parties have agreed that, if your Lordships propose to allow the appeal, damages should
be increased by an agreed amount. I would allow the appeal and substitute a judgment which recognises the
agreement of the parties.

My Lords, I have already stated that I agree with the judgments in Curwen v James but I want to emphasise my
agreement with what fell from Pearson LJ ([1963] 2 All ER at p 624; [1963] 1 WLR at p 755.), when he
emphasised his anxiety on this question of the admission of evidence as to matters after the judgment. It must
be sparingly but in proper cases unhesitatingly exercised. But where the time allowed for appeal has run out,
whether it be to the Court of Appeal or to your Lordships' House, I would apply a very strict rule indeed. The
great principle “Interest rei publicae ut sit finis litium” comes into its own. Without finally closing the door to a
litigant who, after the time for appeal has passed, wants to re-open the matter by giving evidence of matters
since the relevant judgment, I would think he should only be allowed to re-open the matter in very special and
exceptional cases indeed.'

**[[29] In his judgment, Lord Pearson stated ([1969] 2 All ER 949 at 958–959, [1969] 1 WLR 1023 at 1034–1035):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35T0-TWP1-6145-00000-00&context=1519360)**

'The appellant is seeking to adduce fresh evidence, not as to any event occurring or condition existing before
the date of the judgment appealed from, but only as to an event which has happened after that date. This
makes a difference according to the practice of the Court of Appeal, which I think can usefully be taken into
account in considering what should be done here. RSC, Ord 59, r 10(2) (formerly RSC, Ord 58, r 9(2)),
provides:

“The Court of Appeal shall have power to receive further evidence on questions of fact, either by oral
examination in court, by affidavit, or by deposition taken before an examiner, but, in the case of an appeal from
a judgment after trial or hearing of any cause or matter on the merits, no such further evidence as to matters
which have occurred after the date of the trial or hearing) shall be admitted except on special grounds.”

Thus, in the Court of Appeal no special grounds are needed for the admission of evidence as to matters which
have occurred after the decision of the Court below. The conditions laid down in Ladd v Marshall would not be
applicable, or not fully applicable, in relation to the admission of evidence of such matters. There must,
however, be a discretion to decide whether such evidence is to be admitted or not.

3. …

**[*323]**

4. I think it is useful to take into account another aspect of the practice in the Court of Appeal. Under RSC, Ord
59, r 3(1) “an appeal to the Court of Appeal shall be by way of rehearing …” In A-G (at the relation of Tamworth
_Corpn) v Birmingham, Tame and Rea District Drainage Board, where the continuance of an injunction was in_
question, Lord Gorrell said ([1912] AC at p 801; [1911–13] All ER Rep at p 939.):

“Under the Judicature Acts and Rules the hearing of an appeal from the judgment of a judge is by way of
rehearing, and the Court has power to give any judgment and to make any order which ought to have been
d d t k h f th th d th C t thi k fit Th C t l h t t k


-----

evidence of matters which have occurred after the date of the decision from which the ap-seems clear,
therefore, that the Court of Appeal is entitled and ought to rehear the case as at the time of rehearing …”

[This passage was cited and relied on in Curwen v James ([1963] 2 All ER 619 at pp 622, 623; [1963] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-60WR-00000-00&context=1519360)
748 at pp 751, 752, 754.). That was a case under the Fatal Accidents Act 1846, and the widow had remarried
after the judgment of the trial judge but before the hearing in the Court of Appeal. The damages were reassessed in the light of the known fact of the remarriage. Harman LJ cited _Bwllfa and Merthyr Dare Steam_
_[Collieries (1891), Ltd v Pontypridd Water- works Co ([1903] AC 426 at p 431; [1900–03] All ER Rep 600 at p](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDK0-TWXJ-212M-00000-00&context=1519360)_
_[603.) and Re Bradberry, National Provincial Bank Ltd v Bradberry, Re Fry, Tasker v Gulliford ([1942] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDK0-TWXJ-212M-00000-00&context=1519360)_
_[629 at p 635; [1943] Ch 35 at p 42.), and said ([1963] 2 All ER at p 623; [1963] 1 WLR at p 754.):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-605T-00000-00&context=1519360)_

“'Why should we, when we know that the plaintiff has married, pretend that we do not know it and assess the
damages, as we are assessing them anew here, on the footing that she may or may not marry? As we know
the truth, we are not bound to believe in a fiction.”

I think it is quite clear that if on appeal fresh evidence is admitted as to subsequent events (events occurring
after the date of the judgment appealed from) and the fresh evidence justifies a re-assessment of the damages
should be re-assessed in the light of the relevant facts as known at the date of the re-assessment.'

**[30] I deduce from these cases that when it is sought to introduce evidence of events which occurred after the**
judgment by the trial judge, no special grounds are needed to justify the admission of the evidence unlike the
position when it is sought to introduce evidence of facts or circumstances which existed at the time of the judgment.
No application was made by counsel for the appellants for leave to file an affidavit setting out the events which were
alleged to have occurred since 1 May 2020, the date of the delivery of the judgment by the Chief Justice. The
purported facts which the Court is being asked to take into consideration are those set out in the Skeleton argument
of the appellants. Since objection was taken in the written submissions by counsel for the respondents, I am of the
view that in the

**[*324]**

absence of an application to file and serve an affidavit setting out the relevant facts which the appellants require the
Court to take into consideration, I am of the view that the Court cannot take into consideration and act on the
purported statements contained in the Skeleton Arguments of the appellants. The Court is not aware that the
Statements were accepted by counsel for the respondents. The Court is being called upon to exercise its discretion
in the absence of evidence on which it can do so. I accept that for evidence of events occurring after the judgment,
no special grounds are needed to justify the admission.

**[31] As indicated, no application was made to introduce into evidence, matters which transpired after the judgment.**
While a chronology was without objection introduced by counsel for the appellants, this, in my view, cannot be a
substitute for evidence which could only be admitted by affidavit or an agreed statement of fact by the parties.

**[32] In the absence of evidence, I am of the view that this could lead the Court to make adverse findings relating to**
public officials, without these officials being given an opportunity of being heard. In other words, to make a finding
that the detention of the appellant between the date of the judgment of the Chief Justice and their release, was not
reasonable and could lead to an injustice being created or adverse inferences being drawn against public officials.

**[33] In order to determine whether the detention of the appellants subsequent to the judgment of the Chief Justice**
and the date of their release was reasonable, this Court was being asked to determine an issue without having the
benefit of evidence from the Director of Immigration. Without the appropriate evidence, this could lead to this Court
making findings which would be adverse to the public officials without affording them an opportunity to explain the
circumstances and the reason why the appellants were not released prior to the date on which they were eventually
released.

**[34] It should be borne in mind that the judgment of the Chief Justice made it clear that her findings in relation to the**
detention of the appellants was limited to the period between their unlawful entry on 10 October 2019 in the TCI and


-----

the 24 April 2020. The judgment of the Chief Justice did not relate to the period 1 May 2020 (the date of her
judgment) and the release of the appellants in August 2020.

**[35] This Court is now being asked to make findings on whether the detention, between 24 April 2020 and 24**
August 2020, the date of the release of the appellants, was reasonable. Without evidence as to what transpired
during that period and without the matter being determined at first instance, in my view, the Court should decline to
do this.
**Is the Appeal Academic or Moot?**

**[36] The Court, through the President, ex protio motu, raised the issue whether, having regard to the fact that the**
appellants had been released from custody on 24 August 2020, the appeal had therefore become moot. In the
amended Notice of Appeal, it is stated that the appeal was from part of the Order of the Chief Justice dated 1 May
2020 in which she held that (i) the

**[*325]**

appellants' detention was lawful and no release of the appellants would be ordered, and (ii) that the objection to the
production of the appellants on the Writ of Habeas Corpus via video and audio facilities and the incomplete or
partial appearance of each appellant from the immigration detention center was dismissed. The order sought by the
appellants on appeal was that the detention was and now is unlawful and that the appellants should be released
from detention. Further, that there was neither adequate production of the appellant on the Writ and the application
for the Writ of Habeas Corpus, there being no sufficient appearance of each appellant.

**[37] It is against the background that the appellants were released from custody on 24 August 2020, that it is**
necessary to determine whether the appeal had become academic or moot. In determining whether the appeal had
become academic and/or moot, I have had regard to a number of cases. In R v Secretary of State for the Home
_[Dept, ex p Salem [1999] 2 All ER 42, [1999] AC 450(11 February, 1999), it was contended that the appeal should](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61HF-00000-00&context=1519360)_
continue, even if there was no live issue between the parties, on the ground that there was a question of general
_[public importance. In giving judgment, Lord Slynn of Hadley stated ([1999] 2 All ER 42, [1999] AC 450 at 455–456):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61HF-00000-00&context=1519360)_

'In _Sun Life Assurance Co of Canada v. Jervis_ _[[1944] 1 All ER 469 at 470–471, [1944] AC 111 at 113–114](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP70-TWP1-600N-00000-00&context=1519360)_
Viscount Simon LC said:

“I do not think that it would be a proper exercise of the authority which this House possesses to hear appeals if
it occupies time in this case in deciding an academic question, the answer to which cannot affect the
respondent in any way … I think it is an essential quality of an appeal fit to be disposed of by this House that
there should exist between the parties a matter in actual controversy which the House undertakes to decide as
a living issue.”

In Ainsbury v Millington _[[1987] 1 All ER 929 at 930–931, [1987] 1 WLR 379 at 381Lord Bridge of Harwich, with](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60TC-00000-00&context=1519360)_
whom the other members of the House agreed, said:

“In the instant case neither party can have any interest at all in the outcome of the appeal. Their joint tenancy of
property which was the subject matter of the dispute no longer exists. Thus, even if the House thought that the
judge and the Court of Appeal had been wrong to decline jurisdiction, there would be no order which could now
be made to give effect to that view. It has always been a fundamental feature of our judicial system that the
courts decide disputes between the parties before them; they do not pronounce on abstract questions of law
when there is no dispute to be resolved.” '

**[[38] In Gawler v Raettig [2007] EWCA Civ 1560 (03 December 2007), Sir Anthony Clarke, MR stated:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54J2-CR51-F0JY-C4HX-00000-00&context=1519360)**

'[24] I turn to the principles. We were referred to a number of cases. The theme which runs through them all is
that neither the Court of

**[*326]**


-----

Appeal nor the House of Lords will ordinarily entertain academic appeals. So for example in Sun Life
Assurance v Jervis [1944] AC 111the House of Lords declined to hear an appeal which was concerned with the
respondent's rights under an endowment policy. The issue was one of construction. The terms on which leave
to appeal were given had the effect that the respondent had no financial interest in the appeal and the only
(arguable) public interest would have been to clarify an issue of interpretation for other, hypothetical cases.
Viscount Simon L.C said the House was not interested in “expressing its view on a (mere) legal conundrum”
(see page 113). But he also made it clear (see page 115) that he was not “lay(ing) down a rule for all cases”.

That case thus supports the general principle that academic appeals will not generally be entertained but does
not support an absolute rule in any class of case. Moreover it does not support the proposition that the question
whether or not the court should entertain an academic appeal is one of jurisdiction.

[25] In Ainsbury v Millington (unreported), 12 March 1987, the House of Lords revisited Sun Life Assurance and
essentially followed it. Lord Bridge, with whom the other members of the appellate committee agreed, said that
it has always been a fundamental feature of our judicial system that the courts decide disputes between the
parties between them. They do not pronounce on abstract questions of law when there is no dispute to be
resolved. However, he added that different considerations may arise in relation to what are called “friendly
actions” and conceivably in relation to proceedings instituted specifically as a test case.

[26] In R v SSHD ex parte Salem [1999] 1 AC 450 the House of Lords appear to have drawn a distinction
between a dispute between private law rights between private parties and public law cases. Thus Lord Slynn,
after referring to the two cases to which I have referred and to R v SSHD ex parte Abdi [1996] 1 WLR 298, said
this at page 456G-457B:

“My Lords, I accept, as both counsel agree, that in a cause where there is an issue involving a public authority
as to a question of public law, your Lordships have a discretion to hear the appeal, even if by the time the
appeal reaches the House there is no longer a lis to be decided which will directly affect the rights and
obligations of the parties inter se. The decisions in the Sun Life case and Ainsbury v Millington (and the
reference to the latter in rule 42 of the Practice Directions applicable to Civil Appeals (January 1996) of your
Lordships' House) must be read accordingly as limited to disputes concerning private law rights between the
parties to the case.

The discretion to hear disputes, even in the area of public law, must, however, be exercised with caution and
appeals which are academic between the parties should not be heard unless there is a good reason in the
public interest for doing so, as for example (but only by way of example) when a discrete point of statutory
construction arises which does not involve detailed consideration of facts and where a large

**[*327]**

number of similar cases exist or are anticipated so that the issue will most likely need to be resolved in the near
future.

I do not consider that this is such a case. In the first place, although a question of statutory construction does
arise, the facts are by no means straightforward and in other places the problem of when a determination is
made may depend on the precise factual context of each case. In this very case, the first issue is expressed to
arise “On the facts of this case”; the second issue concerns the question whether the Secretary of State had
any discretion to record and rescind his decision and whether the discretion was exercised rationally and fairly
in the instant case.” '

**[39] In** _Ya'axché Conservation Trust v Sabido (Chief Forest Officer)_ (2014) 85 WIR 264, the issue of an appeal
being academic was considered by the Caribbean Court of Justice. Mr Justice Anderson observed:

'[4] However, there is not an absolute rule that bars the hearing of a matter even if by the time the appeal
reaches this court there is no longer a live issue between the parties. Several Caribbean courts have accepted


-----

that an academic appeal may be heard if it raises an issue of public interest involving a distinct or discrete point
of statutory interpretation which has arisen in the past and may arise again in the future …'

Mr Justice Anderson went on to state:

'[6] There are compelling features of the present case which would make it appropriate for us to hear the
appeal, though academic. This matter does not concern private law rights but rather a narrow and discrete
point of public law namely the proper construction to be placed on the statutory power of the Administrator to
grant authorisation to conduct otherwise forbidden activities within a nature reserve.'

**[40] In Ogle Airport Inc v Competition and Consumer Affairs Commission [2020] CCJ 19 (AJ) GY, the Caribbean**
Court of Justice reaffirmed _that 'while it is settled policy that a court will not hear academic appeals, there is no_
_absolute prohibition against doing so and a court may decide to hear such an appeal in a number of instances as_
_when, for example, there is an unresolved question of public importance such as the interpretation of a statute.' Mr_
Justice Barrow, who delivered the judgment of the Court observed at para [8]:

'In this case there is no issue of public importance. Manifestly, it is the refusal of the Chief Justice to find the
Commission lacked jurisdiction that Ogle wants to appeal. That is a perfectly singular act of judicial
determination based entirely on the particular facts. There is not a smidgen of public interest that hearing an
appeal could serve.'

**[41] In order to determine whether there is a live issue before this Court it is necessary to look at the application**
which was before the Chief Justice – that application was for a Writ of Habeas Corpus. It is accepted that 'the writ of
_habeas corpus for release is a prerogative process for securing the liberty of the_

**[*328]**

_subject by affording the effective means of immediate release from unlawful and unjustifiable detention, whether in_
_prison or in private custody.' See Halsbury Laws of England Vol 88A para 144._

**[42] The Writ of Habeas Corpus is available in cases of wrongful deprivation of liberty. Any illegal detention of a**
person which is incapable of legal justification is the basis of the jurisdiction for the issuing of a Writ of Habeas
Corpus.

**[[43] In Greene v Secretary of State for Home Affairs [1941] 3 All ER 388 at 399–400, [1942] AC 284 at 302, Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60Y1-00000-00&context=1519360)**
Wright stated:

'It is clear that the writ of habeas corpus deals with the machinery of justice, not the substantive law, except in
so far as it can be said that the right to have the writ is itself part of substantive law. It is essentially a
procedural writ, the object of which is to enforce a legal right. The writ is described as being a writ of right, not a
writ of course. The applicant must show a prima facie case that he is unlawfully detained. He cannot get it as
he would get an original writ for initiating an action, but if he shows a prima facie case he is entitled to it as of
right. The first question, therefore, in any habeas corpus proceeding is whether a prima facie case is shown by
the applicant that his freedom is unlawfully interfered with, and the next step is to determine if the return is
good and sufficient. A person unlawfully detained is entitled as of course to obtain a writ of trespass, but an
action of trespass or false imprisonment does not by itself secure the immediate or speedy release of the
plaintiff, if he is still detained when he commences his action. As Littledale J said in Watson's Case, at p 795:

“A party imprisoned has two modes of proceeding, either by action for false imprisonment or by application for
a habeas corpus. In an action for false imprisonment the defendant must prove his justification (if any), and
(except where allowed by express provision to give it under the general issue) he must also set forth the
justification specially on the record. In the return to an habeas corpus no such minuteness of detail is
necessary, nor in any instance that I can find has it been considered necessary to support the return by
affidavit.”


-----

The incalculable value of habeas corpus is that it enables the immediate determination of the right to the
applicant's freedom.'

**[44] Having referred to habeas corpus as a 'right to an instant determination as to the lawfulness of an existing**
_imprisonment', Lord Wright_ [([1941] 3 All ER 388 at 400, [1942] AC 284 at 303) [quoting Lord Halsbury in Cox v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60Y1-00000-00&context=1519360)
_Hakes] pointed that the application for habeas corpus '… was not a proceeding in a suit but was a summary_
_application by the person detained. No other party to that proceeding was necessarily before or represented before_
_the judge except the person detaining, and that person only because he had the custody of the applicant and was_
_bound to bring him before the judge to explain and justify, if he could, the fact of imprisonment. It was, as Lord Coke_
_described it, festinum remedium.'_

**[45] The appellants have been released from custody on 24 August 2020.**

**[*329]**

The issue in this matter was the detention of the appellants pursuant to the provisions of s 5(2)(h) of the
Constitution and the Ordinance. The Writ of Habeas Corpus sought the production of the appellants before the
court in order to determine whether their detention was legal and could be justified under s 5(2)(h) of the
Constitution and the Ordinance. The Chief Justice determined that the detention was not illegal. In other words, that
the Director of Immigration was entitled to detain the appellants under s 5(2)(h) of the Constitution and the
Ordinance. The issue, therefore, on the appeal, is whether the Chief Justice was right in reaching the conclusion
that the detention was lawful. The appellants sought declarations that their detentions were illegal. As stated above,
the Writ of Habeas Corpus is not 'a proceedings in a suit but was a summary application by the person detained'
seeking to ascertain whether their detentions were legal. The appellants were no longer in custody, and in my view,
were not entitled to pursue the Writ of Habeas Corpus to issue. As stated, the Writ of Habeas Corpus is a summary
application designed to ensure the release of a person from detention.

**[46] Even if it could be said that this appeal does raise a matter in the area of public law, I am satisfied that this by**
itself is not a good reason for the appeal to be heard. Insofar as the judgment of the Chief Justice is concerned that
the detention of the appellants from the date of their unlawful entry until the date of judgment was reasonable, is no
longer a real issue as the parties have been released.

**[47] In my view, the release of the appellants from detention on 24 August 2020 meant that there was no live issue**
between the appellants and the Director and for that reason, the appeal would be academic. In this case, the issue
for determination before the Chief Justice was a 'perfectly singular act of judicial determination based entirely on the
_particular facts.' There was 'not a smidgen of public interest that hearing an appeal could serve.'_

**[48] For those reasons, I consider that the appeal is moot.**

**[49] I propose to deal with the issue of the detention of the appellant in two phases – firstly, detention from the**
unlawful entry on 10 October 2019 until 24 April 2020; secondly, from 1 May 2020, the date of the judgment of the
Chief Justice until the date of release 24 August 2020. However, before dealing with these two phases, I will deal
with the power to detain persons who seek to enter the TCI unlawfully. In so doing, it is necessary to have regard to
the provisions of the Constitution and the Immigration Ordinance Cap 5.01.
**Detention to date of judgment**

**[50] The question that needs to be answered, is whether the detention of the appellants from the date of their**
unlawful entry into the Turks and Caicos Islands on 10 October 2019 until 24 April 2020 was reasonable for the
purposes as set out in the Constitution, subject to the procedure in the Ordinance ie to prevent unlawful entry
and/or for the purpose of effecting their unlawful removal from TCI and/or the taking of proceedings relating to their
lawful removal.

**[51] The issue to be determined is whether the detention of the appellants**

**[*330]**


-----

was justified in law. Section 5(2) of the Constitution of the Turks and Caicos Islands provides as follows:

'5. (2) No person shall be deprived of his or her personal liberty save in accordance with a procedure
prescribed by law in any of the following cases—

(a) …

(b)…

(c) …

(d)…

(e) …

(f) …

(g)…

(h) for the purpose of preventing the unlawful entry of that person into the Islands or for the purpose of
effecting the expulsion, extradition or other lawful removal from the Islands of that person or the taking of
proceedings relating thereto.'

**[52] It is clear that the Constitution covers all aspect of the detention of the appellants (a) to prevent unlawful entry;**
(b) for the purposes of effecting their lawful removal from the TCI; and (c) the taking of proceedings relating to their
lawful removal.

**[53] Under s 5(h) of the Constitution, the appellants were subject to be lawfully detained because (a) they were**
attempting to enter the Island illegally, contrary to s 102 of the Ordinance and were therefore liable to being
detained for the purposes of preventing their unlawful entry to TCI; (b) in view of the fact that they were seeking to
enter the Island illegally, the immigration authorities were entitled to detain them for the purpose of effecting the
lawful removal from TCI; (c) the immigration authorities were entitled to detain the appellants for the purposes of
taking proceedings relating to their removal from TCI.

**[54] This section provides that subject to the Immigration Ordinance Cap 5.01 that it is lawful to detain a person for**
(a) purposes of preventing unlawful entry into the island, (b) purpose of effecting the expulsion or lawful removal
from the island or taking proceedings relating to the expulsion or removal of that person. In order for a person to be
deprived of his liberty, it must be shown that his detention is lawful and falls within the exceptions set out in para (h)
of s 5(2)(h).

**[55] Section 5(2) of the Constitution states that the provision contained in that section is subject to any detention**
which is done in accordance with the procedure prescribed by law. For this reason, it is necessary to have regard to
the provision of the Ordinance which deals with the detention of persons who unlawfully seek to enter the Turks and
Caicos Islands. Section 54(1) of the Immigration Ordinance Cap 5.01 provides as follows:

'54 (1) A person who may be required to submit to examination under subsection (2), (3) or (4) of section 50 or
under section 51 may be detained under the authority of an immigration officer pending his examination and
pending—

**[*331]**

(a) in the case of a person to whom section 50 applies, a decision to give or refuse him leave to enter; or

(b) in the case of a person to whom section 51 applies, a decision whether to recommend his deportation.'

**[56] Section 50(2) of the Ordinance provides as follows:**


-----

'(2) An immigration officer may examine any person who has arrived in the Islands by ship or aircraft for the
purposes of establishing—

(a) whether the person is not an Islander, a British overseas territories citizen or a permanent resident;

(b) if he is not a person within paragraph (a), whether he may or may not enter the Islands without leave; or

(c) if he may not enter without leave, whether he should be given leave and for what period and on what
conditions (if any), or should be refused leave.'

**[57] Section 51 of the Ordinance provides:**

'51. (1) An immigration officer may examine a person whom he reasonably suspects—

(a) of having entered the Islands unlawfully; or

(b) of being in the Islands in breach of any condition or restriction of his permit to enter or reside in the Islands.

(2) A person on being examined by an immigration officer under this section may be required to produce any
documents in his possession, custody or control.'

**[58] Section 56(1), (3) and (5) of the Ordinance provides:**

'56. (1) Persons may be detained under section 54 in such places as the Minister may direct, except detained
in accordance with subsections (3), (4) and (5) of that section on board a ship or aircraft.

(2) …

(3) A detainee may be taken in the custody of a police officer, or of any person acting under the authority of an
immigration officer, to and from any place where his attendance is required for the purpose of ascertaining his
citizenship or nationality or of making arrangements for his admission to a country or territory other than the
Islands.

(4) A person shall be deemed to be in legal custody at any time when he is a detainee or is being removed in
pursuance of subsection (3).'

**[[59] In R (on the application of Saadi) v Secretary of State for the Home Dept [2002] UKHL 41, [2002] 4 All ER 785,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6025-00000-00&context=1519360)**

[2002] 1 WLR 3131, Lord Slynn of Hadley stated at para [31] that:

'[31] In international law the principle has long been established that sovereign states can regulate the entry of
aliens into their territory. Even as late as 1955 the eighth edition of Oppenheim's International Law, at pp 675–
676 (para 314) stated: “The reception of aliens is a matter of

**[*332]**

discretion, and every state is by reason of its territorial supremacy competent to exclude aliens from the whole,
[or any part, of its territory”. Earlier in A-G for Canada v Cain, A-G for Canada v Gilhula [1906] AC 542 at 546,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-214V-00000-00&context=1519360)

_[[1904–7] All ER Rep 582 at 584–585, the Privy Council in the speech of Lord Atkinson decided:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-214V-00000-00&context=1519360)_

“One of the rights possessed by the supreme power in every State is the right to refuse to permit an alien to
enter that State, to annex what conditions it pleases to the permission to enter it and to expel or deport from the
State, at pleasure, even a friendly alien, especially if it considers his presence in the State opposed to its
peace, order, and good government, or to its social or material interests: Vattel, Law of Nations, book 1, s.231;
book 2, s.125.”

This principle still applies subject to any treaty obligation of a state or rule of the state's domestic law which
may apply to the exercise of that control. The starting point is thus in my view that the United Kingdom has the


-----

right to control the entry and continued presence of aliens in its territory. Article 5(1)(f) seems to be based on
that assumption. The question is therefore whether the provisions of para (1)(f) so control the exercise of that
right that detention for the reasons and in the manner provided for in relation to Oakington are in contravention
of the Article so as to make the detention unlawful.'

**[60] Earlier in the judgment in Saadi, His Lordship had stated at para [26]:**

'[26] Statutory powers of this kind must be exercised reasonably by government, at any rate in the absence of
specific provision laying down particular timescales for administrative acts to be performed. An analogous
application of this principle is to be found in judgments dealing with the detention of those who are or may be
[subject to deportation. Thus in R v Governor of Durham Prison, ex p Singh [1984] 1 All ER 983 at 985, [1984] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-6161-00000-00&context=1519360)
WLR 704 at 706Woolf J said in relation to the power of deportation:

“As the power is given in order to enable the machinery of deportation to be carried out, I regard the power of
detention as being impliedly limited to a period which is reasonably necessary for that purpose. The period
which is reasonable will depend upon the circumstances of the particular case.” '

His Lordship indicated that the House of Lords in Tan Te Lam v Superintendent of Tai A Chau Detention Centre

_[[1996] 2 LRC 360, [1997] AC 97, had adopted the approach of Woolf J.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-850J-00000-00&context=1519360)_

**[61] The Turks and Caicos Islands reserves the right under the Ordinance to prevent persons from entering the**
Islands without permission. Where persons seek unlawfully to enter the Islands, power is given under s 5(2)(h) of
the Constitution to detain them. This power to detain is subject to the provisions of the procedure set out in the
Ordinance. I accept that the power

**[*333]**

to detain is therefore subject to an implied provision that the length of the detention would be reasonable. It is
therefore necessary to consider whether the detention from the date of the unlawful entry into Turks and Caicos, 10
October 2019 until 24 April 2020 was reasonable.

**[62] In determining whether the time that expired was reasonable, regard must be had to a variety of factors. These**
factors include the state of the Constitutional development of the TCI and limitations contained therein. Regard
must be had to the socio-economic conditions that exist in the TCI. It is not unreasonable to conclude that because
of its size and economy undue hardship would be placed on the economy and budget of the Islands. Access to
persons who are fluent in or able to translate the Tamil language in order to assist with the investigations relating to
whether the applicants were the subject of trafficking including the appellants and all the events leading up to their
arrival in the territorial waters of the TCI. The limited resources of both the immigration authorities and the Police
would have been stretched and as it turns out assistance would have been required from outside.

**[63] In determining whether the length of the detention was reasonable, regard must be had to the evidence of the**
affidavit of Acting Superintendent of Police Willet Harvey who stated, inter alia:

'[12] The UK based officers arrived in TCI on the evening of 25 November later joined by two Tamil speaking
interpreters who arrived from London on Sunday 1 December. Their services were secured through
engagement contracts which had to be extended from time to time to facilitated the completion of the ongoing
investigation into the criminal proceedings as well as to conduct specialized interviews. Their contracts would
come to an end on 29 March 2020. As the Senior Investigating Officer from the RTCIPF I worked very closely
with them throughout the process.

[13] Interviews commenced with detainees on Tuesday the 3rd December and were recorded on video. There
were ongoing challenges with respect to available resources and further assistance in the form of physical
resources including additional video systems had to be sourced as well as other trained officers from the UK.


-----

[14] Through continued investigations and interviews of the remaining detainees, as well as intelligence
received from the Human Rights and Special Prosecutions Section of the United States Attorney for the
Southern District of Florida; and the Department of Homeland Security Homeland Security Investigations
(collectively, the U.S. Law enforcement Authorities); the key investigation team of which I am a part, become
aware of the Sri Lankan based transnational criminal organization (“TCO”) which was involved in the illicit
smuggling of undocumented migrants from Sri Lanka to the United States before crossing into Canada through
Buffalo, New York via the Caribbean (including the Turks and Caicos Islands). The transport of those illegal
migrants would be facilitated through the Caribbean by way of the Dominican Republic,

**[*334]**

Haiti, Cuba, Turks and Caicos Islands, and the Bahamas. Others were moved through South America and
Mexico and across the southwest border of the United States.

[15] We further became aware through intelligence received from the U.S. Law Enforcement Authorities, that
Srikajamukam Chelliah, a Canadian citizen of Sri Lankan descent and the identified alleged smuggler in the
related criminal investigation had been convicted of alien smuggling the United States in 2003 and 2012.

[16] The interviews were quite lengthy, challenging and highly complex but were necessary. In the course of
the interview we learned that some of the detainees had left their home over two years ago and their accounts
were long, detailed and harrowing. The interviews have lasted up to six hours in some cases.

[17] The enquiries to establish the true accounts and status of the detainees proved challenging. The Royal
Turks and Caicos Islands Police had to solicit support from law enforcement within the USA as well as Canada.
This support is ongoing and highlights the cross border international aspect and level of the offending involved
as well as the international concern in this case.

[18] As a midday of the of 17.1.2020 we had interviewed eighteen (18) detainees on video as per ABE
(Achieving Best Evidence) and in keeping with TCI Trafficking Ordinance directions that such victims may, in
certain circumstances, give evidence in video. The interview process was concluded on 7th February 2020.'

**[64] In the affidavit of Derek Been, the Director of Immigration, he stated:**

'[10] On Friday February 7, 2020, Superintendent Willet Harvey of the Royal Turks and Caicos Islands Police
Force via email dated the same date provide a schedule of Sri Lankan and Indian nationals involved in the
investigation along with recommendations for each. At that time he indicated five (5) Sri Lankan Nationals and
one (1) Indian national as potential witnesses. A copy of the said correspondence is exhibited hereto and
marked DB1.

[11] Much efforts was placed in determining the ideal way and means to return the Sri Lankan and Indian
National to their homeland. Options can be seen on email and attachments dated March 2, 2020 and March 6,
2020. A copy of the said correspondence is exhibited hereto and marked (DB2).

[12] The IOM arrived in the Turks and Caicos Islands during the week of March 9th, 2020. On March 16, 2020,
the IOM completed its tasks related to persons to be repatriated and via email dated March 16, 20202 informed
the Ministry of Immigration, Citizenship, Labour and Employment Services and the Immigration Department of
details relevant to the repatriation. The IOM also indicated that as a result of COVID-19 a route change was
necessary but that the proposed date of March 24, 2019 remains but that it was still subject and dependent on
airlines operations and countries keeping their borders open.

**[*335]**

[13] In an email dated March 17, 2020, the IOM provided personal details of clothing to be issued to the
migrant as part of their journey, said correspondence is exhibited hereto and marked (DB3).


-----

[14] On March 17, 2020, the Ministry and Department was informed that due to COVID-19 and the closure of
Sri Lanka until March 31, 2020, the repatriation was not possible on March 24, 2020.

[15] Planning for repatriation is tedious and requires much precision, expertise and dialogue with foreign
governments, inclusive of risk assessments. Great efforts was placed in minimizing the amount of stops and
ensuring that the IOM had requisite staff to enable the transit of repatriated persons.

[16] After the closure of Panama as per email dated March 16, 2020, it was decided that an alternate route
from the Turks and Caicos Islands would be Cuba. The IOM indicated that unlike all other points of transit, they
had little presence in Cuba and required assistance. The request for assistance from the Cuban Government
was immediately source through the Office of the Governor of the Turks and Caicos Islands. See email dated
March 17, 2020. A copy of the said correspondence is exhibited hereto and marked (DB4).

[17] In addition, the use of this route required escorts by the Turks and Caicos Islands Immigration Officers and
also funding of such by the Turks and Caicos Islands Government. A request for quote was made to
InterCaribbean Airlines. A copy of the said correspondence is exhibited hereto and marked (DB5).

[18] As recently as March 26, 2020, the IOM via email continue to communicate and plan for the imminent
departure of the migrants. A copy of the said correspondence is exhibited hereto and marked (DB6), has been
examined and proved unjustifiably costly ranging from US$200,000.00 to US$303,000.00. We have been
notified the relevant Government Authorities for the appropriation of these sums so that repatriation can be
effected as soon as practicable after restrictions have been lifted.

[20] We have been in constant communication with the representatives of the IOM and continue to make
inquires via the internet in relation to Sri Lanka and the situation with respect to arrival of Commercial Airlines
into the country in light of the COVID 19 pandemic. We can confirm that the government of Sri Lanka has
extended its ban on all arriving passengers up to 7 April 2020. According to Sri Lankan authorities, during this
period, aircraft departures, passenger connections, and transits to other flights will be permitted. Flights arriving
without passengers for the purpose of picking up departing passengers will also be permitted but the entry of
commercial flights even with Sri Lankan nationals are currently prohibited.'

**[65] The evidence of Acting Superintendent of Police Willet and the Director of Immigration demonstrated the**
difficulties which confronted the Director of Immigration. The arrival of the 28 Sri Lankan nationals and 1 Indian
national (along with other persons) clearly posed a difficulty for the

**[*336]**

immigration authorities in Turks and Caicos. Taking into consideration the evidence set out in the affidavits of
Superintendent Harvey and the Director of Immigration, I am of the view that the Chief Justice was correct in
coming to her conclusion that the 'the respondents on whom the burden lay to demonstrate the lawfulness of the
_applicants' detention have discharged that burden by showing a continuing intention to repatriate the applicants_
_even in the face of the travel issues raised by COVID-19 pandemic. The continued engagement of Sri Lankan_
_authorities by IOM on behalf of the first respondent indicates that the first respondent is not lax regarding his duty to_
_effect the repatriation.'_
**Period after Judgment to Release, 24 August 2020**

**[66] I now turn to consider the detention of the appellants for the period 1 May 2020 until their release on 24 August**
2020. In so doing, I have regard to the Agreed Chronology to which I previously adverted.

**[67] On 23 April 2020, Notices of Intention to deport the appellants were served on them. This meant that the**
purpose of their detention changed from being detained to prevent their unlawful entry into TCI to being detained for
the purposes of being deported – for the purposes 'of effecting their lawful removal from TCI'. The deportation was
being done pursuant to s 5(2)(h) of the Constitution and the Ordinance.


-----

**[68] In order to determine whether the detention was reasonable, it is necessary to examine the available evidence**
which is limited to the Agreed Chronology. It should be pointed out that, in my opinion, the Agreed Chronology was
nothing more than a statement of the date of occurrences of the events therein listed. It is not, and cannot be,
evidence of the circumstances surrounding or leading up to those events. The Agreed Chronology shows that on 1
May 2020 an extension of time was granted by the Minister Responsible for Immigration to the appellants to the 6
May 2020 for representation to be made in respect of the Notices of Intention to Deport. A further extension was
granted to 14 May 2020. On 20 May 2020, the appellants filed a Notice of Motion for Judicial Review of the
Decision of the Minister Responsible for Border and Labour to issue the Notices of Intention to Deport _without_
_having them interviewed by an official with knowledge and experience of interviewing asylum seekers._

**[69] Between the 19 and 24 June 2020, the appellants applied for registration with the United Nations High**
Commission for Refugees ('UNHCR'). This process was completed on 24 June 2020.

**[70] On 10 July 2020, a letter was received by the Director of Immigration requesting that the appellants be**
released from detention following their registration as refugees. On 23 July 2020, an Advisory opinion was received
from the UNHCR, in respect of the applications for refugee status. The appellants were released on 24 August
2020.

**[71] While the Agreed Chronology shows that on 10 July 2020, a letter from UNHCR was sent to the Director of**
Immigration requesting the release from detention of the three appellants following their registration as refugees,
the Court has no evidence before it to show what steps were required to be taken by the Director before effect
could be given to the request from the UNHCR.

**[*337]**

Similarly, the Agreed Chronology shows that on 23 July 2020, Advisory Opinions in respect of the appellants were
subsequently sent to the Director. Similarly, the Court does not have the benefit of what steps were taken or were
required to be taken by the Director before giving effect to these Advisory Opinions. The Court did not have any
evidence to show what was necessary for the Director to do before he could accede to the request of the UNHCR
and release the appellants from detention.

**[72] Prior to the letter of 10 July 2020 from the UNHCR, the appellants had no status in TCI and were still being**
detained pending their deportation. It was not, in my view, unreasonable to detain the appellants who, up to that
time, had no status in TCI under the Ordinance. The appellants were detained for approximately 1 month after the
Advisory Opinion before being released. I am of the opinion that the period of detention after the service of the
Notices of Intention to deport to the date of release was not unreasonable.

**[73] In reaching this conclusion, I have had regard to the observation by Lord Justice Toulson, as he then was, in R**
_[(on the application of A) v Secretary of State for the Home Dept [2007] EWCA Civ 804, [2007] All ER (D) 467 (Jul),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N0RV-00000-00&context=1519360)_
where he stated at para [54]:

'[54] I accept the submission on behalf of the Home Secretary that where there is a risk of absconding and a
refusal to accept voluntary repatriation, those are bound to be very important factors, and likely often to be
decisive factors, in determining the reasonableness of a person's detention, provided that deportation is the
genuine purpose of the detention. The risk of absconding is important because it threatens to defeat the
purpose for which the deportation order was made. The refusal of voluntary repatriation is important not only as
evidence of the risk of absconding, but also because there is a big difference between administrative detention
in circumstances where there is no immediate prospect of the detainee being able to return to his country of
origin and detention in circumstances where he could return there at once. In the latter case the loss of liberty
involved in the individual's continued detention is a product of his own making.'

**Fundamental Rights and Freedoms of the Individual**

**[74] Counsel for the appellants submitted that, for the avoidance of any doubt, these proceedings raise and he will**
rely upon enforcement of rights under the Constitution of the Turks and Caicos Islands.


-----

**[75] He submitted that by virtue of s 21(1) of the Constitution, if any person alleges that any of his fundamental**
rights have been or is likely to be contravened then, without prejudice to any other action with respect to the same
matter which is lawfully available, that person may apply to the Supreme Court for redress. Counsel stated that this
was by means of the application of these rights both in relation to habeas corpus, and in relation to an alternative
relief sought of relocation of the detention. He pointed out that the Chief Justice dismissed the challenge which is
now being renewed

**[*338]**

and refined in this Court by the grounds of appeal.

**[76] Counsel submitted that the Supreme Court has jurisdiction to determine the issue, and to make such orders,**
issue such writs and give such directions as it may consider appropriate for the purpose of enforcing or securing the
enforcement of any of the protections to which the person concerned is entitled. However, he stated that the
Supreme Court shall not exercise its powers under s 21(2) if it is satisfied that adequate means of redress are
available to the person concerned under any other law. Counsel further submitted that this Court has, in
determining an appeal, the same powers as exercisable by the Supreme Court. By s 21(4) an 'appeal shall lie as of
right to the Court of Appeal from any final determination of any application or question by the Supreme Court under
this section …'.

**[77] Section 1 of the Constitution of the Turks and Caicos Islands provides as follows:**

**'Fundamental rights and freedoms of the individual**

Whereas every person in the Islands is entitled to the fundamental rights and freedoms of the individual, that is
to say, the right, without distinction of any kind, such as race, national or social origin, political or other opinion,
colour, religion, language, creed, association with a national minority, property, sex, sexual orientation, birth or
other status, but subject to respect for the rights and freedoms of others and for the public interest, to each and
all of the following, namely—

(a) life, liberty, security of the person and the protection of the law;

(b) freedom of conscience, of expression and of assembly and association; and

(c) protection for his or her private and family life, the privacy of his or her home and other property and from
deprivation of property save in the public interest and on payment of fair compensation,

the subsequent provisions of this Part shall have effect for the purpose of affording protection to the aforesaid
rights and freedoms, and related rights and freedoms, subject to such limitations of that protection as are
contained in those provisions, being limitations designed to ensure that the enjoyment of the said protected
rights and freedoms by any individual does not prejudice the rights and freedoms of others or the public
interest.'

**[78] Section 5 of the Constitution which deals with 'Protection from Arbitrary Arrest and Detention contains detailed**
_provisions relating to this subject.'_

**[79] Section 5(1) contains the declaration that every person has the right to liberty and security of person.**

**[80] Section 5(2) contains an expression that 'no person shall be deprived of his or her liberty save in accordance**
_with the procedure prescribed by law' and it goes on to set out the exceptions._

Section 5(3) requires that a person who has been arrested or detained shall be informed in a language which he
understands the reason for his arrest or detention and whether he is being charged, and if so, the nature of the
charge against him.

**[*339]**


-----

Section 5(4) establishes inter alia that the person arrested or charged shall have the right without delay to counsel
of his choice.

Section 5(5) states that the person is entitled to remain silent.

Section 5(7) provides that a person who is unlawfully detained or arrested is entitled to compensation from that
person in respect of the arrest or detention.

Section 6 of the Constitution contains provisions which are intended to secure the protection of the law, including
where the person who was arrested was charged with a criminal offence.

Section 6 sets out provisions which apply to persons who have been arrested and charged with a criminal offence.

**[81] A person who has been convicted of a criminal offence in a trial before a judge has a right to appeal to the**
Court of Appeal. In that appeal, the appellant is entitled and has always been entitled to raise the issue that he was
or has been deprived of the protection of law guaranteed by s 6 of the Constitution and that this deprivation led to
him not having a fair trial as guaranteed by the Constitution.

**[82] Such a claim may be raised in the Court of Appeal at the hearing of the appeal, even though it was not, and**
could not be raised, if the infringement about which he complains in the appeal occurred during the trial before the
judge. Further, he may raise on appeal, any infringement of any rights guaranteed to him such as the right to a fair
trial within a reasonable time which would include the hearing of the appeal.

**[83] These infringements may be properly raised in the Court of Appeal for the first time during the hearing of the**
appeal. It is open and has always been open to an appellant as part of his attempt to quash his conviction to allege
and to show that his rights as guaranteed by the Constitution were in fact infringed and that such an infringement
deprived him of the protection of the law and the rights to a fair hearing.

**[84] Section 21 of the Constitution states:**

**'Enforcement of fundamental rights**

21 (1) If any person alleges that any of the foregoing provisions of this Part has been, is being or is likely to be
contravened in relation to him or her, then, without prejudice to any other action with respect to the same
matter which is lawfully available, that person may apply to the Supreme Court for redress.

(2) The Supreme Court shall have original jurisdiction—

a) to hear and determine any application made by any person in pursuance of subsection (1); and

b) to determine any question arising in the case of any person which is referred to it in pursuance of
subsection (3),

and may make such orders, issue such writs and give such directions as it may consider appropriate for the
purpose of enforcing or securing the enforcement of any of the foregoing provisions of this Part to the
protection of which the person concerned is entitled; but the Supreme

**[*340]**

Court shall not exercise its powers under this subsection if it is satisfied that adequate means of redress are or
have been available to the person concerned under any other law.

(3) If, in any proceedings in any court established in the Islands other than the Supreme Court or the Court of
Appeal, any question arises as to the contravention of any of the foregoing provisions of this Part, the court in
which the question has arisen shall refer the question to the Supreme Court, unless, in its opinion, the raising
of the question is merely frivolous or vexatious.


-----

(4) An appeal shall lie as of right to the Court of Appeal from any final determination of any application or
question by the Supreme Court under this section, and an appeal shall lie as of right to Her Majesty in Council
from the final determination by the Court of Appeal of the appeal in any such case; but no appeal shall lie from
a determination by the Supreme Court under this section dismissing an application on the ground that it is
frivolous or vexatious.

(5) The Legislature may by law confer on the Supreme Court such powers in addition to those conferred by this
section as may appear to be necessary or desirable for the purpose of enabling the Court more effectively to
exercise the jurisdiction conferred on it by this section.

(6) Any such law may make, or provide for the making of, provision with respect to the practice and
procedure—

(a) of the Supreme Court in relation to the jurisdiction and powers conferred on it by or under this section;

(b) of the Supreme Court or the Court of Appeal in relation to appeals under this section from determinations
of the Supreme Court or the Court of Appeal; and

(c) of other courts in relation to references to the Supreme Court under subsection (3),

including provision with respect to the time within which any application, reference or appeal shall or may be
made or brought.

(7) In determining any question which has arisen in connection with the interpretation or application of any of
the foregoing provisions of this Part, every court shall take into account any—

(a) judgment, decision, declaration or advisory opinion of the European Court of Human Rights;

(b) decision of the European Commission of Human Rights (“the Commission”) given in a report adopted
under Article 31 of the Convention;

(c) decision of the Commission in connection with Article 26 or 27(2) of the Convention;

(d) decision of the Committee of Ministers of the Council of Europe (“the Committee of Ministers”) taken under
Article 46 of the Convention;

(e) judgment, decision or declaration of a superior court in the United Kingdom on the interpretation or
application of the Convention,

**[*341]**

whenever made or given, so far as, in the opinion of the court, it is relevant to the proceedings in which that
question has arisen.

(8) In subsection (7), references to the Convention are references to it as it has effect for the time being, except
that—

(a) the references in subsection (7)(b) and (c) to Articles 31, 26 and 27(2) are references to those Articles as
they respectively had effect immediately before the coming into force of the Eleventh Protocol;

(b) the reference in subsection (7)(d) to Article 46 includes a reference to Articles 32 and 54 as they had effect
immediately before the coming into force of the Eleventh Protocol; and

(c) the references in subsection (7) to a report or decision of the Commission or a decision of the Committee of
Ministers include references to a report or decision made as provided by paragraphs 3, 4 and 6 of Article 5 of
the Eleventh Protocol (transitional provisions).


-----

(9) In subsections (7) and (8)—

“the Convention” means the European Convention on Human Rights;

“the Eleventh Protocol” means the protocol to the Convention (restructuring the control machinery established
by it) agreed at Strasbourg on 11 May 1994; and

“a superior court in the United Kingdom” means any of the following—

(a) the High Court or the Court of Appeal in England;

(b) the High Court of Justiciary or the Court of Session in Scotland;

(c) the High Court or the Court of Appeal in Northern Ireland;

(d) the House of Lords or the Supreme Court; and

(e) the Judicial Committee of the Privy Council.'

**[85] What is granted by s 21 is the constitutional action against the state for an infringement of the rights**
guaranteed by ss 1 to 20 of the Constitution. Original jurisdiction is granted to the Supreme Court if the aggrieved
party is seeking redress from the State.

**[86] Original jurisdiction is not granted to the Court of Appeal to hear any matter in which the aggrieved party seeks**
jurisdiction. Section 21(4) gives to the Court of Appeal jurisdiction to hear an appeal ('(4) – An appeal shall lie as of
_right to the Court of Appeal from any final determination of any application or question by the Supreme Court under_
_this section, and an appeal shall lie as of right to Her Majesty in Council from the final determination by the Court of_
_Appeal of the appeal in any such case; but no appeal shall lie from a determination by the Supreme Court under_
_this section dismissing an application on the ground that it is frivolous or vexatious')._

**[87] In my view, an appellant is entitled to raise in an appeal, the fact that his rights as guaranteed under the**
Constitution have been infringed or breached and, as such, he was deprived of the protection of the law leading to
him not having a fair trial. It has always been open to an appellant to allege that his fundamental rights as
guaranteed by the Constitution have been breached, and as a result, he has been deprived of the protection of the
law

**[*342]**

resulting in him not having a fair trial. While this issue may be determined on appeal and the issue of infringement
of the constitutional rights may be taken for the first time during the course of the appeal, this does not infringe the
provisions of s 21 as he is not seeking to bring an action in which he is seeking redress against the person who
infringed his rights.

**[88] As stated above, the appeal is dismissed.**

**End of Document**


-----

