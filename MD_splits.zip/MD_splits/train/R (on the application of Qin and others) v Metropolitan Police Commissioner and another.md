# R (on the application of Qin and others) v Metropolitan Police Commissioner
 and another [2017] EWHC 2750 (Admin)

Queen's Bench Division, Administrative Court (London)

Choudhury J

3 November 2017Judgment

**Charles Streeten (instructed by Wilson Barca LLP Solicitor) for the Claimants**

**Stephen Walsh QC and Daniel Mansell (instructed by Metropolitan Police) for Defendant (1)**

Hearing dates: 12 October 2017

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**MR JUSTICE CHOUDHURY :**

**Introduction**

1. These two claims for judicial review and appeal by way of case stated (together, “the claims”) concern
applications made by the Commissioner of Police for the Metropolis (“the Commissioner”) for Closure
Orders under the _[Anti-Social Behaviour, Crime and Policing Act 2014 (“the 2014 Act”) in respect of six](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5BS9-MNJ1-DYCN-C2CP-00000-00&context=1519360)_
massage parlours in Soho which were suspected of operating as brothels. Those applications were
refused on 2 November 2016 by the District Judge (“the DJ”) on the basis that the Commissioner had not
proved the alleged criminal conduct to the requisite standard. The Claimants/Appellants in this matter (to
whom I shall refer as “the Claimants”), who operate massage parlours at the properties concerned, were
therefore successful in resisting the Closure Orders. However, the DJ refused to order costs and
compensation in favour of the Claimants. It is those refusals which form the basis of the claims before me.

**Factual background**

2. Operation Lanhydrock was a joint Metropolitan Police, City of Westminster and **_Modern Slavery and_**
Kidnap Unit Command Investigation into six premises believed to have been systematically operating as
brothels disguised as massage parlours across London's West End and Chinatown. The evidence giving
rise to that belief comprised the following:

a. A number of “reviews” of each of the premises on a website in relation to sexual services offered at the
premises. These services included the alleged availability of “extended sessions” during which clients
engaged in a variety of sexual acts with “masseuses” upon payment of money;

b. Advertisements on another website, described as “London and the UK's biggest erotic and sensual
massage directory”, which appeared alongside pornographic images; and

c. Intelligence from the Safer Neighbourhoods Team and Westminster City Council, including that:

i. informants had reported that women working at the premises were offering sexual services to
customers; and


-----

ii. there had been reports of aggressive touting in the area around the premises by female members of
staff dressed provocatively

**The Closure Notices**

3. Under s.76 of the 2014 Act, the Commissioner has the power to issue Closure Notices in respect of
premises if she is satisfied on reasonable grounds that the use of the premises had resulted, or was likely
soon to result, in nuisance to members of the public or disorder near those premises. Closure Notices have
the effect of preventing any person (except the owner and persons habitually resident there) from entering
or using the premises. Given the evidence available, the Commissioner considered that there were
reasonable grounds for believing that the use of the premises resulted in or was likely to result in nuisance
or disorder. Accordingly, on 20 October 2016, six Closure Notices were issued under section 76(1) of the
2014 Act.

4. Also on 20 October 2016, six search warrants were executed simultaneously at the six premises.
Several items of a sexual nature were found at certain of the premises and at one of the premises, a police
officer walked in on a couple having sexual intercourse in a room upstairs.

**Service of the Closure Notices and subsequent proceedings**

5. The Closure Notices were served under section 79(2) of the 2014 Act. Once the Closure Notices are
served, the Commissioner has a short window of up to 48 hours in which to apply to the Magistrates for a
Closure Order under s.80 of the 2014 Act. A Closure Order may prohibit access to the premises by all
persons for a period of up to three months.

6. In the present case, that application for a Closure Order was made on the following morning, 21
October 2016, to Hammersmith Magistrates' Court. It was agreed that the substantive hearing, to
determine whether Closure Orders should be made by the court under s. 80 of the 2014 Act, should be
adjourned to 27 October 2016. I am told that the solicitor for the premises did object to the continuation of
the Closure Notices, but the Magistrates decided that the continuation of the Closure Notices pending the
full hearing was necessary in respect of all six premises (in accordance with section 81(4) of the 2014 Act).

7. At the adjourned hearing on 27 October 2016, those acting for the premises applied to adjourn
proceedings on the basis that they were seeking permission to judicially review the validity of the Closure
Notices on the grounds that there had been a failure to comply with the requirement under s.76(6) of the
2014 Act to inform persons having an interest in the premises that the notice is going to be issued. It is not
in dispute that the Commissioner did not inform all of the relevant parties that the notice was going to be
issued. The reasons for that, as set out in the police evidence lodged in support of the Closure Order, were
the confidentiality of the operation, the suspected role of some of the interested parties in the organised
criminal network and the nature of the offences being investigated. There was also a concern that some of
the females being required to work at the premises were or may have been victims of trafficking in human
beings, and that informing persons that a Closure Notice was going to be issued would undermine or
compromise police efforts to engage with those victims.

8. This application for a further adjournment was refused by DJ Snow. DJ Snow accepted the
Commissioner's argument that any questions of invalidity of the Closure Notices were a matter for judicial
review and should not delay the Magistrates' determination of the application for Closure Orders. Directions
were made and the substantive hearing was adjourned to 1 November 2016.

9. On 28 October 2016, the Claimants brought an urgent claim for judicial review ('the First JR') against
the Commissioner's decision to issue the Closure Notices and DJ Snow's refusal to hear submissions
regarding non-compliance with section 76(6). It was suggested in the First JR that there be a rolled-up
hearing on 1 November 2016. On 31 October 2016, the Claimants made an application to this Court for
urgent consideration of the First JR by the next day and prior to the substantive hearing in respect of the
Closure Orders. Jefford J refused that application, considering it neither possible, practicable nor
necessary to hold a rolled-up hearing on such an urgent basis.

**The Closure Order hearing**


-----

10. The substantive hearing of the application for Closure Orders therefore went ahead on 1 November
2016 at Hammersmith Magistrates' Court with DJ Matson presiding. All six premises were legally
represented. It was not in dispute at that hearing that the requirement to inform under s.76(6) had not been
complied with. Whilst the Closure Notices had been sought on the basis of likely nuisance and disorder, by
the stage of the hearing, the focus of the Commissioner's case had shifted to the alleged criminal
behaviour on the premises, and the applications for Closure Orders were made on this basis, as permitted
by s. 80 of the 2014 Act.

11. After hearing evidence from a number of witnesses and considering documents presented to her, DJ
Matson decided that whilst, “there are many things in this case which may lead to the suspicion that sexual
services were being carried out at some of these premises”, the test in s.80(5) of the 2014 Act for making
Closure Orders was not satisfied and they should not be made. DJ Matson's decision was issued on 2
November 2016.

**Application for costs and compensation**

12. The premises had remained closed for a period of 13 days from the issuing of the Closure Notices on
21 October 2016 until the refusal of the Closure Orders on 2 November 2016. The massage parlours lost
business in that period. The Claimants made applications for their costs and for compensation in respect of
losses incurred as a result of the Closure Notices. These applications were dealt with on the papers and,
on 27 February 2017, DJ Matson handed down her decision. In dealing with costs, the DJ applied the
principles established in _Bradford Metropolitan District Council v Booth_ [2001] LLR 578 _(“Booth”) and in_
_R(Perinpanathan) v City of Westminster [2010] EWCA Civ 40 (“Perinpanathan”), including that a_
straightforward 'costs follow the event' approach may not be appropriate in cases involving public
authorities acting reasonably in the public interest, and that in such cases the starting point and default
position is that no order for costs should be made. The DJ found that:

“Given the circumstances in this case as a whole, I find that the police acted reasonably and properly in
making the application itself, despite my finding that the grounds were not made out to make the closure
orders.

I also find the need for public authorities to be able to make such applications in the public interest without
financial prejudices (sic) to them, outweigh any financial prejudice the respondents may have suffered in
this case. I therefore dismiss the application for costs.”

13. The DJ also dealt with compensation. Under s.90(5) of the 2014 Act, compensation may be awarded
where the court is satisfied that the applicant for compensation is not associated with the impugned
conduct on the basis of which the Closure Notice was issued, that reasonable steps were taken to prevent
the impugned conduct, that financial loss has been incurred in consequence of the Closure Notice, and
that, having regard to all the circumstances, an award of compensation is appropriate in respect of that
loss. As to compensation, the DJ said as follows:

“In relation to the application for compensation, having regard to all of the circumstances (as required by S
90 (5)(d)) and for the same reasons discussed above, I do not consider it is appropriate to order payment
of compensation and also dismiss that part of the application.”

14. That reasoning was expanded upon in the case stated:

“I did apply the same principles that I'd considered whether to award costs in deciding whether to award
compensation… However, in coming to the conclusion not to award compensation, I applied the same
principles in the authorities above which I considered in relation to the application of costs. That is a need
for public authorities to be able to make such applications in the public interest without financial prejudices
(sic) to them, outweigh any financial prejudice the respondents may have suffered in this case. The use of
the word 'them' in this context in my judgement includes all public authorities and includes payments from
public monies even though the police would not themselves have been liable for payment of any order of
compensation. I took into account the fact that payment from central funds is of course a payment from
public funds.”


-----

15. The DJ went on to state that although the requirements of s.90(5)(a) to (c) of the 2014 were met:

“…the Commissioner had acted properly and reasonably in making the application and therefore, having
regard to all the circumstances (as required by s.90(5)(d)), I came to the conclusion that it was also correct
to refuse the application for compensation.”

16. The DJ also confirmed that she did not take into account the Commissioner's failure to comply with
s.76 (6) in her decisions not to award costs or compensation.

**The First JR**

17. Notwithstanding the fact that they had succeeded in resisting the Closure Orders, the Claimants
persisted with the First JR. Permission was refused in respect of the First JR by Morris J on 27 February
2017 on the basis that the claims were otiose as by then the proceedings in respect of the Closure Notices
had already been resolved in the Claimants favour. However, on the basis that the Claimants' claim in
respect of s.76(6) was strong, Morris J made the provisional order that the Commissioner pay the
Appellants' costs of the application for judicial review incurred up to and including 1 November 2016,
subject to any objections raised by the Commissioner. The Commissioner did object to costs being
ordered.

**The Second JR**

18. The Claimants also applied for permission to seek judicial review of DJ Matson's decision not to award
costs and compensation (“the Second JR”). That claim was brought on three grounds, namely:

a. Ground 1: In determining the applications for costs and compensation the DJ failed to have regard to
the fact that the Closure Notices served by the Commissioner were served in breach of the requirements of
the 2014 Act;

b. Ground 2: In determining whether or not to award compensation from central funds the DJ applied the
wrong test and/or had regard to immaterial considerations;

c. **Ground 3: the DJ's determination of the Applications for costs and compensation 'en bloc' was**
procedurally unfair and/or demonstrates a deficiency in the reasons for the Decision.

19. The Commissioner resisted Grounds 1 and 3.

20. On 18 April 2017, Langstaff J granted permission in respect of Ground 2 which challenged the failure
to award compensation. However, Langstaff J refused permission in relation to the costs aspects under
Grounds 1 and 3 of the Second JR and the application to have the Second JR consolidated with the
renewed application for permission in respect of the First JR, stating that:

“…the renewed application deals with an issue which is at most peripheral to any question of
compensation, and which in any event appears clearly otiose. I do not regard it as either helpful nor
necessary to resolve the question whether the notice was invalid because of a lack of prior notification in
order to decide, at the end of a hearing, whether the Claimants should have their costs. ”

**Appeal by way of Case Stated**

21. On 7 June 2017, the Claimants appealed against DJ Matson's decision by way of Case Stated. The
questions posed by the DJ for determination by this Court are:

“Q1 Was I correct to consider the same authorities and principles in relation to the ordering of costs when
considering whether to award compensation under section 90 Anti-Social Behaviour, Crime and Policing
Act 2014:

Do the same principles apply when considering payment from central funds?

Is the starting point that no order should be made?

Is it necessary to weigh up financial prejudice to the public purse against the need to encourage public
authorities to make such applications when considering whether to away during compensation?


-----

Q2. Should I at the time, have taken account of the Commissioner's failure to comply with section 76(6) of
the Anti-Social Behaviour, Crime and Policing Act 2014 as a relevant factor in deciding whether to award
costs or compensation.”

22.  On 27 June 2017, with the consent of the Commissioner, Supperstone J ordered that the First JR be
listed as a rolled-up hearing, to be heard together with the Second JR and the appeal by way of Case
Stated.

**Relevant Legal Provisions**

23. Section 76 of the 2014 Act, so far as is material, provides:

“76 Power to issue closure notices

This section has no associated Explanatory Notes

(1)A police officer of at least the rank of inspector, or the local authority, may issue a closure notice if
satisfied on reasonable grounds—

(a) that the use of particular premises has resulted, or (if the notice is not issued) is likely soon to result, in
nuisance to members of the public, or

(b) that there has been, or (if the notice is not issued) is likely soon to be, disorder near those premises
associated with the use of those premises,

and that the notice is necessary to prevent the nuisance or disorder from continuing, recurring or occurring.

(2) A closure notice is a notice prohibiting access to the premises for a period specified in the notice.

For the maximum period, see section 77.

(3) A closure notice may prohibit access—

(a) by all persons except those specified, or by all persons except those of a specified description;

(b) at all times, or at all times except those specified;

(c) in all circumstances, or in all circumstances except those specified.

(4) A closure notice may not prohibit access by—

(a) people who habitually live on the premises, or

(b) the owner of the premises,

and accordingly they must be specified under subsection (3)(a).

(5) A closure notice must—

(a) identify the premises;

(b) explain the effect of the notice;

(c) state that failure to comply with the notice is an offence;

(d) state that an application will be made under section 80 for a closure order;

(e) specify when and where the application will be heard;

(f) explain the effect of a closure order;

(g) give information about the names of, and means of contacting, persons and organisations in the area
that provide advice about housing and legal matters.

(6) A closure notice may be issued only if reasonable efforts have been made to inform—

(a) people who live on the premises (whether habitually or not), and

(b) any person who has control of or responsibility for the premises or who has an interest in them,


-----

that the notice is going to be issued.

(7) Before issuing a closure notice the police officer or local authority must ensure that any body or
individual the officer or authority thinks appropriate has been consulted.”

24. Section 77 provides that the maximum period that may be specified in a Closure Notice is 24 hours
unless the conditions of subsection 2 are met in which case the maximum is 48 hours. Those conditions
were met in the present case.

25. Section 78 provides for circumstances in which a Closure Notice may be cancelled or varied and s.79
prescribes the requirements for service of Closure Notices.

26. Section 80 addresses the power of the court to make Closure Orders, applications for which must be
heard no later than 48 hours after service of the Closure Notice. Under s.80(5) the Court can make a
Closure Order if it is satisfied:

“(a) that a person has engaged, or (if the order is not made) is likely to engage, in disorderly, offensive or
criminal behaviour on the premises, or

(b) that the use of the premises has resulted, or (if the order is not made) is likely to result, in serious
nuisance to members of the public, or

(c) that there has been, or (if the order is not made) is likely to be, disorder near those premises associated
with the use of those premises,

and that the order is necessary to prevent the behaviour, nuisance or disorder from continuing, recurring or
occurring.”

27. Section 81(3) and (4) provides that the Court may adjourn the hearing of applications for a maximum
period of 14 days and, in doing so, order that the Closure Notice continue in force pending the adjourned
date.

28. By s.86(1) a person who without reasonable excuse remains on or enters premises in contravention of
a Closure Notice (including a Notice continued in force under s.81) commits an offence.

29. Section 90 of the Act deals with compensation and provides:

“a person who claims to have incurred financial loss in consequence of a closure notice or a closure order
may apply to the appropriate court for compensation

…

(5) On an application under this section court may order the payment of compensation out of central funds
if it is satisfied
(a) that the applicant is not associated with the use of the premises, or the behaviour on the premises, on
the basis of which the closure notice was issued with a closure order made,

(b) if the applicant is the owner or occupier of the premises, that the applicant took reasonable steps to
prevent that use or behaviour,

(c) that the applicant has incurred financial loss in consequence of the notice or order, and

(d) that having regard to all the circumstances it is appropriate to order payment of compensation in
respect without loss.”

**The Issues**

30. It is agreed that there are three principal issues to be determined in these claims:

a. Issue 1: Did the DJ apply the proper test for the award of compensation pursuant to s.90 of the 2014
Act;

b. Issue 2: What are the legal consequences of the Commissioner's failure to comply with s.76(6) of the
2014 Act; and


-----

c. Issue 3: Was the DJ's 'en bloc' approach to costs and compensation correct?

31. The parties' submissions on these issues may be summarised as follows:

_(a) Submissions on Issue 1: The test for compensation_

32. The Claimants say that the proper test for compensation pursuant to s.90(5) of the 2014 Act requires
the Court to apply the four-stage test set out at subsections (a) – (d). Consequently:

a) The starting point is not that there should be no order for compensation. On the contrary, where (as in
this case) subsections (a)-(c) are satisfied, there is a presumption that compensation will be awarded.

b) Compensation is awarded from central funds. Thus, the principles relating to costs awards against
public authorities derived from cases such as Booth and Peripanathan designed to prevent a chilling effect
on regulatory activity, do not apply.

33. The Commissioner does not take issue with the Claimants' submissions on the proper approach to
compensation.

_(b) Submissions on Issue 2: Commissioner's failure to comply with s.76(6)_

34. The Claimants submit that the Commissioner's failure to comply with the statutory requirements for
issuing the Closure Notices is relevant and material to whether, and if so, in what amount, the court should
make an award of compensation and/or costs. In particular, the Claimants submit that:

a) The relevant authorities on costs require the court to have regard to the Commissioner's compliance
with relevant procedural rules, including, in the present case, compliance with s.76(6).

b) The Commissioner's non-compliance was “substantial” since:

i. Section 76(6) is an important procedural safeguard. Its purpose is to consult as well as inform. It
provides an opportunity for those specified to explain why it is unnecessary to issue a closure notice and/or
to take steps to prevent any nuisance or disorder from continuing, occurring, or recurring, thereby removing
the need for a closure order application.

ii. Section 76(6) triggers the requirement for service of the closure notice pursuant to s.79(e).

iii. The search warrant and closure notice procedure should not be conflated. The intention to execute a
search warrant does not negate the requirement to inform those with an interest in the Premises of the
intention to issue a closure notice.

c) The Closure Notices were thus invalid. This was a matter relevant to the determination of costs and
compensation.

35. The Commissioner submits that compliance with s.76(6) in the context of this case was irrelevant to
the question of whether to award costs and compensation because, in the absence of any allegation of a
breach of the Closure Notice (such breach giving rise to a criminal offence), the legality or otherwise of the
Notice had no impact upon the jurisdiction of the Magistrates to make a Closure Order or any decision on
costs at the end of a Closure Order hearing. The Commissioner also contends that there was, in any event,
substantial compliance with s.76; that strict compliance with s.76(6) would have made no difference to the
outcome; and, in the words of DJ Matson, the Commissioner “acted reasonably and properly in making the
_application itself”._

_(c) Submissions on Issue 3: 'En Bloc' determination_

36. The Claimants say in respect of this issue that the relative strength of the Commissioner's case
against the different premises required the question of costs and/or compensation to be determined on a
'premises-by-premises' basis. It is also submitted that the 'en bloc' approach is unfair and amounts to a
failure to give reasons as to why costs were not awarded to each of the parties.

37. The Commissioner submits that DJ Matson was entitled to approach the applications for costs 'en bloc'
given that the premises had been targeted as part of the same police operation the applications for


-----

Closure Orders had been brought together and on the same grounds, and the Commissioner's conduct in
respect of them all was essentially the same. DJ Matson applied the correct legal test when considering
costs and the fact she dealt with them together did not affect this.

38. In relation to the issue of separate consideration of the applications for compensation, the
Commissioner's stance is neutral.

**Discussion and Analysis**

**Issue 1: The proper approach to compensation**

39. The first issue can be dealt with briefly due to the helpful stance taken by the Commissioner in not
taking issue with the Claimants submissions. The essential complaint here is that the Magistrates erred in
law by applying principles relevant to the award of costs to the exercise of their discretion as to
compensation. I begin by considering the power to award costs.

40. The Magistrates' power to award costs arises under s.64 of the _Magistrates Courts Act 1980. This_
provides:

“…on hearing a complaint, a magistrates court shall have power in its discretion to make such order as to
costs… as it thinks just and reasonable”. ”

41. The application of this broad discretion as to costs in the context of public authorities carrying out
enforcement functions was considered in Booth. Lord Bingham CJ held that the question of costs in such
cases could be summarised in three propositions:

“(1) S.64 (1) confers a discretion upon a magistrates' court to make costs as it thinks just and reasonable.
That provision applies both to the quantum the costs (if any) to be paid, but also as to the party (if any)
which should pay them.

(2) What the court will think just and reasonable depend on all the relevant facts and circumstances of the
case before the court. The court may think it just and reasonable that costs should follow the event, but
need not think so in all cases covered by the subsection.

(3) Where a complainant has successfully challenged before justices an administrative decision made by a
police or regulatory authority acting honestly, reasonably, fully and on grounds that reasonably appear to
be sound, in exercise of its public duty, the court should consider, in addition to any other relevant factor
circumstances, both (i) the financial prejudice to the particular complainant in the particular circumstances
if an order for costs is not made in his favour; and (ii) the need to encourage public authorities to make and
stand by honest, reasonable and apparently sound administrative decisions made in the public interest
without fear of exposure to undue financial prejudice if the decision is successfully challenged.” (at [24] to

[26])

42. The last of these principles, which seeks to avoid any 'chilling effect' on the regulatory activities of
public authorities that might arise if costs merely followed the event, was further considered in the case of
_Perinpanathan. After an extensive review of the authorities, Stanley Burnton LJ, said as follows:_

“…(5) Where the principle applies, and the party opposing the order sought by the public authority has
been successful, in relation to costs the starting point and default position is that no order should be made.
(6) A successful private party to proceedings to which the principle applies may nonetheless be awarded
all or part of its costs if the conduct of the public authority in question justifies it. (7) Other facts relevant to
the exercise of the discretion conferred by the applicable procedural rules may also justify an order for
costs. It would not be sensible to try exhaustively to define such matters, and I do not propose to do so.” (at

[40])

43. These principles apply to costs. However, the DJ had applied the same principles to the award of
compensation under s.90 of the 2014 Act on the basis that there would also be financial prejudice to the
police if compensation were awarded. In my judgment, the DJ erred in so doing:


-----

a. Unlike an award of costs, any award of compensation under s.90 of the 2014 Act is made out of central
funds. Thus, there would be no financial prejudice to the paying authority in the event such an order is
made;

b. The absence of financial prejudice to the paying authority means that there will not be any 'chilling
effect' on its regulatory activities in the way that there might be had such compensation to be paid out of its
own budget;

c. The suggestion by the DJ, namely that there is financial prejudice to the particular public authority in
question (and therefore a dissuasive effect on the issuing of Closure Notices) because any award out of
central funds would still mean a payment from public funds, cannot be accepted. It is reasonable to
assume that the reason Parliament provided for compensation to be paid out of central funds is precisely in
order that the police and local authorities can reasonably exercise their powers in respect of Closure
Notices and Orders without the fear of having to pay large sums by way of compensation in the event that
such notices or orders are successfully resisted;

d. There is, therefore, no basis for suggesting (as did the Magistrates in this case) that the starting point or
default position in claims of compensation is that there should be no award. Whether or not an award
should be made depends on all of the matters to be considered under s.90(5) of the 2014 Act.

44. As the decision as to compensation was made on an incorrect legal basis it falls to be quashed. Mr
Streeten, on behalf of the Claimants, invites me to go further and requests that a mandatory order be made
requiring the DJ to award compensation. This request is made on the basis that the requirements for the
award of compensation under s.90 (5) of the 2014 Act were satisfied and the DJ gave no reason as to why
it would not be appropriate to make the award.

45. Section 90 (5) of the 2014 Act provides that the court has a discretion to order the payment of
compensation out of central funds if it is satisfied that the requirements of subsections (a) to (c) are
satisfied, and that, having regard to all the circumstances, it is appropriate to order payment of
compensation in respect of that loss. Mr Streeten submitted that, if it was found that subsections (a) to (c)
were satisfied, then that raised a presumption (albeit not an express statutory one) that compensation
would be awarded unless it was inappropriate to do so. In my judgement, there is no such presumption.
Had that been the intended effect of the section, it could have said that compensation “shall” be awarded in
these circumstances unless it would be inappropriate to do so. Instead, the section expressly confers a
discretion in terms of compensation and requires the court to have regard to “all the circumstances” in
determining whether it is “appropriate” to order payment of compensation. It therefore remains open to the
court not to award compensation even if subsections (a) to (c) are satisfied. However, if it chooses to take
that course it must explain why it is doing so. That is particularly so given that, in order to satisfy
subsections (a) to (c), the court would necessarily have concluded that there was limited culpable
behaviour on the part of the applicants and that they took reasonable steps to prevent the impugned
conduct from occurring. Where a person has incurred loss in those circumstances, it is incumbent upon the
Court, if it decides not to award the statutory compensation, to explain why.

46. In this case, the DJ appears to have decided not to award compensation not because of any conduct
on the part of the Claimants, but because it was considered that the Commissioner had acted reasonably
and properly in making the application. That, to my mind, is to focus on the wrong conduct. Whilst the
Commissioner's conduct may undoubtedly be taken into account as part of the overall circumstances, at
the stage of deciding upon compensation, and having concluded that there was little or no culpable
conduct on the part of the Claimants, and that there was financial loss, it seems to me that it would
primarily be factors related to the Claimants' conduct which might render it appropriate not to award
compensation. No such factors were identified in the DJ's reasons.

47. Notwithstanding the absence of any such factors, it does not seem to me that this Court should make
a mandatory order requiring the DJ to award compensation. To do so would be to usurp the function of the
DJ who is in the best position to consider all of the circumstances that might bear upon the
appropriateness of making such an award, including the particular loss claimed to have been incurred.
Although the DJ did not expressly identify any factors against the award of compensation that was in the


-----

context of an incorrect application of s.90(5) and where it had been assumed that the starting position
should be no award of compensation. Had the DJ approached the matter as required by s.90(5), she may
well have identified other factors which, in her assessment, made it inappropriate to award compensation.
The appropriate course, in my judgement, is for the matter to be remitted to the Magistrates, and for the DJ
to reconsider the issue of compensation without regard to the principles in Booth and Perinpanathan, and
on the basis that subsections (a) to (c) of s.90 are satisfied in order to determine whether, having regard to
all the circumstances, it would be appropriate to order payment of compensation in respect of each of the
Claimants' claimed loss.

48. In view of the above, the answer to each part of the first question of the case stated is in the negative.

**Issue 2: The effect of non-compliance on costs and compensation**

49. The first part of Mr Streeten's submission on this issue is that the relevant authorities on costs required
the Court to have regard to the Commissioner's failure to comply with relevant procedural rules. He relies,
in particular, upon Perinpanathan. The application for costs in that case arose out of the exercise by the
police of seizure powers respect of cash under the _[Proceeds of Crime Act 2002. Once seized, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y037-00000-00&context=1519360)_
Commissioner applied under s.298 of that Act for the forfeiture of the cash. The Magistrates dismissed that
application, accepting evidence produced by the claimant that the cash had been intended for lawful
purposes. However, the Magistrates refused to make an order for costs. This was on the basis that the
police had reasonable grounds for the suspicion that cash had been intended for use in unlawful conduct.
On the claimant's appeal, Lord Neuberger said:

“75 As I have indicated, there is a respectable argument for saying that there should be a presumption that
a person in the position of the claimant should be able to recover the sum of the costs should successfully
defeated the claim by the police to confiscate her money. However, there is also a respectable argument
for saying that there is no such presumption, and that, absent other factors, she should only be able to
recover any costs in so far as they were incurred as a result of the actions of the police in connection with
the detention and claim confiscation of the money which were unreasonable or in some other way open to
criticism. In my view, the resolution of the question as to which of these two views should prevail is really
determined by the decisions to which I referred of the High Court and Court of Appeal over the past 30
years the effect of which is encapsulated in Lord Bingham CJ's principles [in Booth].

…

77 The effect of our decision is that a person in the position of the claimant who has done nothing wrong,
may normally not be able to recover the costs of vindicating her rights against the police in proceedings
under section 298 of the 2002 act, where the police have behaved reasonably. In my view, this means that
magistrates should exercise particular care when considering whether the police have acted reasonably in
the case where there is an application costs against them under section 64. It would be wrong to invoke
the wisdom of hindsight set too exacting standard, but particularly given the understandable resentment felt
by a person in the position of the claimant if an order for costs is made, and the general standards of
behaviour that can properly be expected from the police, it must be right to scrutinise a behaviour in
relation to the seizure, the detention, and the confiscation proceedings, with some care when deciding
whether they acted reasonably and properly.”

50. Mr Streeten submits that the requirement set out in _Perinpanathan, for Magistrates to scrutinise the_
behaviour of the police carefully in order to determine whether they acted reasonably and properly, meant
that the DJ was bound to consider whether there had been compliance with the procedural requirements
for issuing a Closure Notice, and that any failure in that regard necessarily meant that their behaviour could
not be regarded as reasonable and proper. However, in Perinpanathan, it was not alleged, as in this case,
that there was any prior unlawful act or failure to act on the part of the police which rendered the act of
seizure a nullity or invalid. Once the claim of invalidity was raised in the present case, the DJ proceeded on
the basis that any question of validity was a matter for judicial review, and that, furthermore, the facts
giving rise to that claim of invalidity should not be taken into account in determining the issue of costs. The
question is whether the DJ was correct to take that approach.


-----

51. In my judgment, the DJ was correct to do so.

52. The DJ was correct to consider that any challenge to the validity of the Closure Notice was a matter for
judicial review and not within the jurisdiction of the Magistrates' Court: I was referred to the case of _R_
_(Byrne) v Commissioner of Police of the Metropolis_ _[[2010] EWHC 3656 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5230-H681-F0JY-C04T-00000-00&context=1519360)_ _(“Byrne”), in which there_
was an appeal against the decision of the Crown Court that it did not have any jurisdiction to consider an
allegation that the police had failed to have regard to guidance before the issuing of a Closure Notice under
the _[Anti-Social Behaviour Act 2003 (“the 2003 Act”). The provisions as to Closure Notices and Closure](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y0W2-00000-00&context=1519360)_
Orders under the 2003 Act bear some similarity to those under the 2014 Act, except that there was no
equivalent to s.76(6) in the 2003 Act. It is important to note, however, that under the 2003 Act, as under the
2014 Act, it was only once a Closure Notice was issued that an application could be made for a Closure
Order. There was also a requirement under the 2003 Act that a person must have regard to guidance in
discharging the functions under that Act. As to the question of the Magistrates' and the Crown Courts'
jurisdiction to hear challenges in respect of the Closure Notice, Moses LJ said as follows:

“15 The question thus arises as to whether any failures, if there were any failures, by the authorising
officer, are matters which it was open to these appellants to raise in the proceedings before the Crown
Court. The allegation was that Superintendent Morgan failed to comply with the obligation imposed on him
by section 11K to have regard to the Secretary of State's guidance. That failure, so it was said, was a
matter which the Crown Court ought to have considered but failed, by declining to exercise what the court
regarded as a species of prior judicial review analysis.

16 It is not disputed, and cannot be disputed, that the Crown Court, exercising the statutory jurisdiction
conferred upon it by section 11F, must exercise that jurisdiction in a way to achieve the statutory objective
of fairness and justice in the consideration of whether it is right to make a Closure Order or not. This is not
correctly described as an inherent jurisdiction, but rather a jurisdiction to be implied from its statutory
function. In order to achieve the objective of deciding whether to make a Closure Order or not, both the
Magistrates' Court, under section 11B, and the Crown Court on appeal under section 11F, must be able to
deploy implied powers so as to achieve fairness and justice in reaching a conclusion. If authority is wanted
for such a proposition it can be found in the decision of Hickinbottom J in R (V)and the Asylum and
Immigration Tribunal v Secretary of State for the Home Department [2009] EWHC 1902 Admin and in Chief
_Constable of Nottingham v Nottinghamshire Magistrates' Court [2009] EWHC 3182 or [2010] 2 AER 347._
The court is entitled to prevent its processes from abuse and, in exceptional cases, may prevent an
application from being persisted in or continued where it is clear to the court that there is either bad faith or
manipulation of its processes in order to achieve a Closure Order. Examples, possibly far fetched, but
nevertheless easily identifiable, were given in argument where it could be shown that, for example, the
proceedings were being brought in bad faith or for ulterior motives.

17 There was no controversy about the exercise of that traditional and well recognised power, but the
dispute between the parties arose over the question as to whether the court was required to consider a
challenge to the Closure Order on the basis that the superintendent had, as a matter of public law, acted
unlawfully, in that he had failed to consider the guidance that he was required to consider. The classic
example of bringing a collateral challenge in criminal, or for that matter civil, enforcement proceedings on
public law grounds occurs where a public body, in the exercise of its statutory powers, makes an order and
seeks to rely upon that order in bringing proceedings for an offence of breach of the order. In such
circumstances a defendant may raise a public law defence, contending that the order made was outwith
the powers of the authority. In civil proceedings an example of that may be found in Wandsworth London
Borough Council v Winder [1985] AC 461where proceedings were brought for arrears of rent and the
increase of rent made by the local authority was unlawful. In criminal proceedings the paradigm may be
observed in Boddington v the British Transport Police [1999] AC 143. In that case a criminal prosecution
was brought for breach of the by-law prohibiting smoking in a railway carriage. On appeal, the House of
Lords concluded that it was open to the defendant to contend, by way of defence to a criminal prosecution,
that the by-law, or the administrative act of sticking up the notices pursuant to it, was ultra vires and
unlawful. Lord Irvine of Lairg Lord Chancellor, at page 153G to H, said:


-----

“It would be a fundamental departure from the rule of law if an individual were liable to conviction for
contravention of some rule which is itself liable to be set aside by a court as unlawful”.

But he pointed out that the extent to which a public law defence might be deployed in criminal proceedings
would depend upon analysis of the statutory scheme in question. In a case such as _Boddington an_
individual would have no occasion or opportunity for challenging the legality of the acts which ultimately led
to his prosecution (see page 161 at G). He contrasted that situation with cases where administrative acts
were specifically directed at the defendants.

18 The instant case is wholly different. The appellants did not face prosecution for any offence at all. They
did not face an accusation that they had acted in breach of a Closure Notice pursuant to section 11D; it
was not suggested that they had breached the notice, rather they faced an application for a Closure Order,
consideration of which was a matter for the magistrates pursuant to section 11B . There was no allegation
of a breach. In those circumstances, the principle in Boddington, and for that matter in R v Wickes 1998 AC
92has, in my view, no application. This was not a case where it was open to a defendant to mount a
collateral challenge on public law grounds against the basis on which it was alleged he had committed an
offence. True it is that without a Closure Notice no application could have been made for a Closure Order,
but it simply does not follow that because that is the course of the statutory scheme that someone who
faces a Closure Order should be permitted to challenge the lawfulness of the prior Closure Notice.

19 It is true, as Mr Southey points out, that the time for challenging that notice is necessarily limited. I have
already referred to the very short period between the making of a Closure Notice and its service and the
making of a Closure Order. It is necessarily a limited period because the making of a Closure Order is a
severe measure of last resort, as section 11B(4)(c) makes clear. It would defeat its purpose if there were to
be a long delay between the issue of the notice and the making of the order. Nonetheless, the time for
challenging the issue of a notice is the time that it is made and it is open to someone served with a notice,
if that person wishes to challenge the legality of the notice, to do so moving by way of judicial review on
traditional public law grounds.

20 That, in my view, is a sufficient basis to uphold what the Crown Court said when it declined to become
involved in a form of prior judicial review analysis but there is a distinct ground on which that view should
also be upheld. Even if it was open to someone against whom it was sought to make a Closure Order to
raise questions of the legality of the Closure Notice, it is necessary to consider the nature of the complaint
and allegation and the consequences of the illegality asserted. In R v Wickes 1998 AC 92the House of
Lords considered the extent to which the legality of the making of a prior Enforcement Notice could be
raised in proceedings for alleged breach of that notice. In his speech Lord Hoffman considered the
question whether the challenge to the validity of a bylaw could be raised as a defence. He said:

“The question must depend entirely upon the construction of the statute under which the prosecution is
brought. The statute may require the prosecution to prove that the act in question is not open to challenge
on any ground available in public law, or it may be a defence to show that it is. In such a case the justices
will have to rule upon the validity of the Act. On the other hand, the statute may, upon its true construction,
merely require an Act which appears formally valid and has not been quashed by judicial review. In such a
case nothing but the formal validity of the Act will be relevant to an issue before the justices. It is, in my
view, impossible to construct a general theory of the ultra vires defence which applies to every statutory
power, whatever the terms and policy of the statute”. (See page 117B to D)

He then referred to the approach of Webster J in Quietlynn Ltd v Plymouth City Council [1988] QB 114in
which, in the context of those proceedings in relation to a sex establishment licensing code, Webster J
commented that justices should not be expected to assume the functions of a Divisional Court and
consider the validity of decisions made by a local authority. He continued:

“Every decision of the Licensing Authority … under the Act of 1982 is to be presumed to have been validly
made and to continue in force unless and until it has been struck down by the High Court and neither the
justices nor the Crown Court have the power to investigate or decide on its validity” (see page 131).


-----

21 In the instant case the scheme of the Act is that once an authorised police officer of the rank of
Superintendent and above has issued a Closure Notice it is then for the Magistrates' Court to decide
whether it is satisfied of those considerations identified in section 11B(4) and further, I emphasis, to
consider whether as a matter of discretion such an order ought to be made. Thus, the issue of a notice is
merely the trigger for the magistrates' jurisdiction. In the absence of any allegation of a breach of the
notice, the legality or otherwise of the notice has no impact upon the jurisdiction of the magistrates. The
magistrates make their own decision as to whether the conditions are satisfied. If they are, the magistrates
are then required to go on to consider whether, even though those conditions are satisfied, it is right to
make the order. In those circumstances, this is just the sort of statutory scheme to which Lord Hoffman and
Webster J were referring, in which questions of the validity or otherwise of a notice are not questions for
either the justices or, on appeal, for the Crown Court. It is the examination and analysis of the statutory
scheme that dictates a conclusion that the Crown Court was correct. That seems to me to be a further
ground for upholding its conclusion.”

53. I was also referred to the earlier case of Errington v Metropolitan police authority _[2006] EWHC 1155_
_(Admin)_ _(“Errington”) in which Collins J dealt with a similar issue arising under the 2003 Act. In that case it_
was claimed that the Closure Notice was defective on its face and therefore invalid. The Magistrates on
that occasion decided to adjourn its proceedings pending a decision on the issue of invalidity by the High
Court. As to that decision Collins J said as follows:

“14 I have no doubt that that decision was wrong. This court has indicated that in general it is inappropriate
to intervene at an interlocutory stage (see, for example, R v Rochford Justices, ex parte Buck). The court
must decide all issues whether of fact or law for itself and reach its decision. If that decision is, or is alleged
to have been, tainted by any errors of law, a case can be stated or exceptionally judicial review
proceedings can then be brought. It is particularly inappropriate to permit judicial review before the final
decision in cases such as this where speed, and the continuing protection of the public, are of particular
importance. …

16 (1) Is the jurisdiction of the Magistrates' Court to hear the application for a closure order under section 2
of the Anti-social Behaviour Act 2003 dependent upon the existence of a validly issued and served closure
notice under section 1 of the Act? …

21 At the hearing of the application the court should satisfy itself that copies of the notice have indeed been
served as required by section 1(6) so that anyone who would be adversely affected by it, and entitled to
make representations against it because he had control of, responsibility for, or interest in the premises,
had been so far as reasonably practicable, identified and served. One of the purposes of section 1(6) is to
give all those who might be affected by an order, or interested in the premises, notice of the intention to
apply for the control order. If the magistrates are not satisfied that those mandatory steps have been taken
they should then consider whether to exercise their powers to adjourn under section 2(6) and require that
the necessary steps be taken. If persuaded that there are shortcomings, they would be likely to take the
view that the notice should not continue in effect until those necessary steps were taken; thus they would
not exercise their powers under section 2(7) to continue the notice in being.

22 The notice itself, on the face of it, is required to inform of the date and time of the hearing before the
Justices. Obviously if the notice does not contain the necessary information the magistrates will be likely to
indicate that they are not prepared to continue with any hearing until the notice is put in proper form. In that
way the interests of those who are affected by it are preserved while the protection of the public, which
stems from the need for the premises to be closed down, if that is established, is also kept in being.

23 For reasons which will become apparent, I do not think that the jurisdiction to hear the application is
affected by any shortcomings in the notice, although they would affect the validity of the notice so as to
make it impossible to maintain criminal proceedings under section 4(1) or (2) in so far as they depended
upon the validity of the notice. If within the period permitted by the Justices any defects were not cured
then no doubt the application would be likely to be refused. It is important to bear in mind that the closure
notice itself produces an immediate effect in that it prevents anyone other than a habitual resident or the
owner from entering the premises. In addition its breach by any visitor is a criminal offence, as is any


-----

obstruction by any person of the taking of any of the steps which have to be taken under section 1(6) . It
will be a defence to any criminal charge under section 4(1) or (2) in so far as it relates to section 1(6) that
the notice is not a valid notice. Such a defence will have to be considered by the court (see Boddington v
[British Transport Police [1998] 2 All ER 203), but while the issue of a notice, which does not have to be](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-605X-00000-00&context=1519360)
contemporaneous with its authorisation, is an essential pre-requisite to the application to the court, the
court must decide whether an order is needed. The court will consider whatever evidence is put before it in
satisfying itself that each of the paragraphs in section 2(3) applies. That is the protection for the claimant
and anyone adversely affected by the notice which cannot be in force for more than 16 days, that is a
combination of the 48 hours in section 2(2) and the 14 days' adjournment in subsection (6).

24 Whether or not the superintendent had reasonable grounds for his belief will inevitably be irrelevant at
the stage that the magistrates consider whether to make a control order, since they must decide whether in
fact there has been the drug use and whether in fact there is the associated disturbance and so the making
of an order is necessary.

25 In so far as breaches result in criminal offences, the validity of the closure notice must, as I have said,
be established. Since Parliament has laid down mandatory requirements those must be complied with. The
same approach is not necessary in considering an application under section 2 of the Act. It seems to me
that in this respect the approach adopted by the House of Lords in the Attorney General's reference (No 3
[of 1999) [2001] 1 All ER 577 is applicable. A notice must have been issued to enable an application to be](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61J5-00000-00&context=1519360)
made, but the application does not depend, nor does the Act say that it depends, upon the validity of that
notice. The Justices must ensure that those affected have been properly notified and so can appear and, if
they wish, raise objections, but it is for the Justices to decide on the evidence before them whether a
control order is to be made. That process provides all the necessary protection for those affected and does
not frustrate the obvious Parliamentary purpose in permitting the making of control orders for the protection
of those living near such premises. …

37 Accordingly, for the reasons I have given, I would answer the first question raised in the negative. The
magistrates' jurisdiction depends upon an application made under section 2 of the 2003 Act and the
existence of a notice. Any relevant issues relating to the notice and, in particular, whether any persons who
should have been notified have been must be decided by the magistrates. If the magistrates are in any
doubt about whether there has been a proper display of the notice or notification in accordance with
section 1(6), they must ensure that all necessary steps are taken to draw its existence to the attention of
those who otherwise might try to visit the premises and so commit an offence.”

54. It is abundantly clear from these authorities that Magistrates should not generally consider the validity
or otherwise of the Closure Notice in an application for a Closure Order. It is also clear from these
authorities that had there been an attempt to prosecute any of the Claimants for a breach of the Closure
Notices then of course the validity or otherwise of the notices could have been raised by way of defence. In
the present case there is no question of there being a breach of the Closure Notices by any of the
Claimants. The Magistrates' jurisdiction to hear the application for Closure Orders is not affected by any
shortcomings in the Closure Notices.

55. Mr Streeten developed a series of sophisticated submissions in support of his contention that the
scheme under the 2014 Act was such that the failure to comply with s.76(6) ought to have been taken into
account in the determination of costs and/or compensation. It was contended that:

a. The power to make a Closure Notice and a Closure Order are inextricably linked such that one cannot
deal with the latter without considering the validity of the former;

b. Section 76(6) of the 2014 Act imposes an obligation to consult with affected persons prior to issuing a
Closure Notice;

c. The Commissioner's failure to consult rendered the Closure Notice, and any act reliant upon that notice,
a nullity;

d. It could not be said that there was substantial compliance with the s.76(6) within the meaning of _R_
_(Jeyeanthan) v Secretary of State for the Home Department [2009] EWCA Civ 216;_


-----

e. If the Closure Notices were unlawful by reason of any of the above, then it could not be said that the
application for a Closure Order was a “reasonable and proper act” for the purposes of assessing costs.

_(a) Link between Closure Notice and Closure Order_

56. It was submitted that the effect of ss.76 and 80 of the 2014 Act is that the Closure Notice and Order
are “inextricably linked” and that there is no separate power to apply for a Closure Order; they are simply
two stages of a single closure power. I was invited to consider material in Hansard as to the effect of these
provisions. It is well-established that reference may be made to such material if provision in question is
ambiguous or obscure or its literal meaning would lead to absurdity: Pepper v Hart [1993] 1 AC at 634D-E.
In my judgement, however, there is no ambiguity in relation to these provisions, and it would not be
appropriate to consider ministerial statements. In my judgment, any link between these stages does not
preclude the Magistrates from considering the application of a Closure Order even when the Closure
Notice is said to be invalid.

57. Sections 76 to 79 of the 2014 Act deal solely with the powers conferred on the police and local
authorities in respect of Closure Notices. There is no supervisory jurisdiction conferred on the Magistrates'
under these sections. The Magistrates are not, in particular, required to satisfy themselves that any
Closure Notice is valid before considering an application for a Closure Order. Thus, whilst there may be a
link between the Closure Notice and a Closure Order, in that an application for the latter cannot be made
without the former having been issued, there is nothing in the statute that requires the Magistrates to go
beyond confirming that a Closure Notice had been issued. As was the position under the 2003 Act, the
issuing of the Closure Notices merely “triggers the magistrates' jurisdiction” (see Byrne). In my judgment,
the Magistrates did not, in these circumstances, have jurisdiction to determine the issue of the validity of
the Closure Notices.

58. Mr Streeten further submits that, if that is right then, at the very least, the Magistrates should always
adjourn the proceedings before them in order to enable any judicial review challenge to be heard and
determined first. As is apparent from the extracts from Byrne and Errington cited above, such an approach
is considered to be incorrect (see _Errington at [14]). I agree. To adjourn proceedings in respect of a_
Closure Order whenever there is a challenge by way of judicial review in respect of the Closure Notice
would fundamentally undermine the operation of the legislation, which is intended to provide a fast and
flexible remedy in cases of substantial nuisance or disorder.

59. It was suggested that there is some conflict in the authorities as to whether the Court should adjourn
proceedings in these circumstances, given that, in an older case, Quietlynn limited v Plymouth City Council

[1988] 1QB 114, it was held that:

“If a bona fide challenge to the validity of the decision in question is raised before them, then the
proceedings should be adjourned to enable an application for judicial review to be made and determined.
In our view, therefore, except in the case of a decision is invalid on its face, every decision of the licensing
authority under the act is to be presumed to have been validly made and to continue in force unless and
until has been struck down by the High Court; and neither the justices nor a Crown Court have power to
investigate or decide upon its validity.”

60. In my view, a proper reading of that passage in Quietlynn Ltd does not suggest that in every instance
where there is challenge by way of judicial review the proceedings before the Magistrates should be
adjourned. The latter part of the passage refers to the presumption of validity and the continuation in force
of the decision in question until it has been struck down by the High Court. Adjourning proceedings in the
face of an undetermined challenge by way of judicial review would not give effect to that presumption.
However, even if the Claimants' reading of that passage is correct, I note that it predates the decisions of
the House of Lords in Boddington v British Transport Police [1992] 2 AC 143and R v Wickes [1998] AC
92which formed the basis of the judgements in _Byrne and_ _Errington. I was invited not to follow the_
judgments in Byrne and Errington. However, I see no error in the approach taken in those judgments and
see no reason not take the same approach here. Accordingly, I find that the Magistrates were correct in


-----

this case not to adjourn the matter and to leave any issues regarding the validity of the Closure Notice to
the High Court.

_(b) Is there an obligation to Consult?_

61.  Mr Streeten further submitted that s.76 confers a fundamental procedural protection on property
owners and those with an interest in affected properties in that the Commissioner is required to consult
with them prior to issuing a Closure Notice. It is said that this would provide owners and those with an
interest in the premises with an opportunity to explain, if it is the case, that the conduct giving rise to
nuisance or disorder is not occurring such that the issuing of a Closure Notice is not necessary. It is also
said that the failure to comply with this important procedural safeguard renders the Closure Notice a nullity.

62. Dealing first with the contention that s.76(6) requires consultation, it is my judgement that s.76(6) does
not have that effect. I say that for the following reasons:

63. There is a separate, express provision dealing with the obligation to consult under s.76 (7). This
provides that before issuing a Closure Notice the police officer or local authority must ensure that any body
or individual the officer or authority thinks appropriate has been consulted. Given this provision, it is
unnecessary, in my judgment, to import into s.76(6) any further or other obligation to consult.

64. Section 76 itself is in terms that the Closure Notice may be issued only if reasonable efforts have been
made to inform affected persons that the notice is going to be issued. It seems to me that the use of the
words, “is going to be issued”, indicates that, by the stage the obligation to inform arises, the relevant
officer has already satisfied himself within the meaning of s.76 (1) on reasonable grounds that there is
likely to be nuisance or disorder, and that the notice is necessary to prevent that nuisance or disorder from
continuing. Any conclusion that the notice was “necessary” could only have been lawfully reached if, on
reasonable grounds, the relevant officer had concluded that no lesser measure than the issuing of the
notice would suffice. In the circumstances, further consultation with potentially affected persons once the
decision to issue had been made would be otiose. Had the intention behind s.76(6) been to require
consultation with those affected before any decision is made to issue the notice then the subsection would
have been in terms that persons should be informed that a notice “might” be issued or that the authority
was considering issuing one.

65. Reliance was also placed on the case of Westminster City Council v Mendoza _[2001 EWCA Civ 216,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFR1-DYBP-P3H3-00000-00&context=1519360)_
another case dealing with Closure Notices in respect of premises believed to be used as sex
establishments, this time under the _[Local Government (Miscellaneous Provisions) Act 1982](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GSM0-TWPY-Y0BH-00000-00&context=1519360)_ (“the 1982
Act”). In that case, there had been a failure to serve the Closure Notice properly on some of the occupiers
of affected premises, and the issue was whether that failure vitiated subsequent applications. Having
regard to the particular statutory scheme in question, the Court held that the failure to comply with the
procedural requirements did not render the result a nullity. I was also referred to the following passage in
the judgment of Lord Woolf CJ:

“[31] However, as the magistrate found that there had not been adequate service, it is necessary to
consider consequence of the service after the first hearing when the proceedings were adjourned. Mr
Sauter's argument said that the structure of the act required the service on the occupiers of the basement
to take place before the complaint (seeking a closure order) was issued. That argument, if correct, could be
to the disadvantage of those who may subsequently occupy the premises and whose interests might need
to be protected. It seems to me that a proper interpretation of section 41 only requires service of the
principal to have taken place before the complaint is issued. The reason for the two-stage process so far
as the principal is concerned, pursuant to ss.3 & 4 of the Act is to give the operator of the sex
establishment and opportunity to discontinue his activities of which the council makes complaint. The
reason for serving others (apart from the person operating the sex establishment) is to enable them to
protect their interests. As long as they are in a position to attend the hearing, the policy and the objectives
of the Act will be achieved.” (Emphasis added).

66. Mr Streeten sought to persuade me that the reference there to the “opportunity to discontinue”
activities under the 1982 Act is mirrored in the operation of s. 76 (6) of the Act in that the obligation to


-----

inform prior to the issuing of notice would also enable parties to discontinue activities. However, the
opportunity to discontinue in the Mendoza case only arose after the service of the Closure Notice. It does
not, therefore, support Mr Streeten's contention, which relates to a prior stage. In any case, there was an
express provision under the 1982 Act which meant that the Council was obliged to take account of the
discontinuation of illicit activity after the service of the Closure Notice. Under the 1982 Act, the Council had
a discretion to apply for a Closure Order following the service of a Closure Notice and could do so at any
time within a period of not less than 14 days and no more than six months after the service of the Closure
Notice. (Contrast that with the present scheme under which the police or local authority must apply for a
Closure Order and must do so within 48 hours of service of the Closure Notice.) Moreover, the exercise of
the discretion under the 1982 Act was expressly subject to s.4(2) of that Act under which the Council could
not apply for a Closure Order if it was satisfied that the use of the premises as a sex establishment had
been discontinued and that there was no reasonable likelihood of any further breach. There is no such
provision under the 2014 Act. Accordingly, there is no warrant for importing any similar “opportunity to
discontinue” following the Closure Notice here. The very short timetables applicable under the 2014 Act
further militate against there being any such opportunity.

67. I was also taken to the decision of the Supreme Court in Bank Mellat v HM Treasury [2014] AC 700. In
that case, the Treasury had exercised powers under the Counter Terrorism Act 2008 to make an order
prohibiting all persons operating in the financial sector in the UK from entering into or continuing any
transaction with a major Iranian commercial bank. (It will be immediately apparent that the circumstances
of that case, in which considerations of foreign policy and national security played a significant part, are
very far removed from the present case). The order in that case was held to be disproportionate for various
reasons including the fact that the bank had not been consulted prior to the making of the order and had
had no opportunity to make representations. Lord Sumption stated as follows:

“28 I also consider that the Bank is entitled to succeed on the ground that it received no notice of the
Treasury's intention to make the direction, and therefore had no opportunity to make representations.

29 The duty to give advance notice and an opportunity to be heard to a person against whom a draconian
statutory power is to be exercised is one of the oldest principles of what would now be called public law. In
Cooper v Wandsworth Board of Works (1863) 14 CBNS 180, the defendant local authority exercised
without warning a statutory power to demolish any building erected without complying with certain
preconditions laid down by the Act.  …

31 It follows that, unless the statute deals with the point, the question whether there is a duty of prior
consultation cannot be answered in wholly general terms. It depends on the particular circumstances in
which each directive is made. Some directives that might be made under Schedule 7 to the Act could not
reasonably give rise to an obligation on the Treasury's part to consult the targeted entity, for example
because there was a real problem about the implicit or explicit disclosure of secret intelligence or because
prior consultation might frustrate the object of the directive by enabling the targeted entity to evade its
operation, notably in a case involving money-laundering or terrorism. …

32 In my opinion, unless the Act expressly or impliedly excluded any relevant duty of consultation, it is
obvious that fairness in this case required that Bank Mellat should have had an opportunity to make
representations before the direction was made. In the first place, although in point of form directed to other
financial institutions in the United Kingdom, this was in fact a targeted measure directed at two specific
companies, Bank Mellat and IRISL. It deprived Bank Mellat of the effective use of the goodwill of their
English business and of the free disposal of substantial deposits in London. It had, and was intended to
have, a serious effect on their business, which might well be irreversible at any rate for a considerable
period of time. Secondly, it came into effect almost immediately. The direction was made on a Friday and
came into force at 10.30am on the following Monday. It had effect for up to 28 days before being approved
by Parliament. Third, for the reasons which I have given, there were no practical difficulties in the way of
an effective consultation exercise. While the courts will not usually require decision-makers to consult
substantial categories of people liable to be affected by a proposed measure, the number of people to be
consulted in this case was just one, Bank Mellat, and possibly also IRISL depending on the circumstances
of their case I cannot agree with the view of Maurice Kay LJ that it might have been difficult to deny the


-----

same advance consultation to the generality of financial institutions in the United Kingdom, who were
required to cease dealing with Bank Mellat. They were the addressees of the direction, but not its targets.
Their interests were not engaged in the same way or to the same extent as Bank Mallet's.  Fourth, the
direction was not based on general policy considerations, but on specific factual allegations of a kind
plainly capable of being refuted, being for the most part within the special knowledge of the Bank. For
these reasons, I think that consultation was required as a matter of fairness. But the principle which
required it is more than a principle of fairness. It is also a principle of good administration. The Treasury
made some significant factual mistakes in the course of deciding whether to make the direction, and
subsequently in justifying it to Parliament. They believed that Bank Mellat was controlled by the Iranian
state, which it was not. They were aware of a number of cases in which Bank Mellat had provided banking
services to entities involved in the Iranian weapons programmes, but did not know the circumstances,
which became apparent only when the Bank began these proceedings and served their evidence. The
quality of the decision-making processes at every stage would have been higher if the Treasury had had
the opportunity before making the direction to consider the facts which Mitting J ultimately found. …

36 It does not of course follow that a duty of prior consultation will arise in every case. The basic principle
was stated by Lord Reid 40 years ago in Wiseman v Borneman [1971] AC 297, 308, in terms which are
consistent with the ordinary rules for the construction of statutes and remain good law:

“Natural justice requires that the procedure before any tribunal which is acting judicially shall be far in all
the circumstances, and I would be sorry to see this fundamental general principle degenerate into a series
of hard-and-fast rules. For a long time the courts have, without objection from Parliament, supplemented
procedure laid down in legislation where they have found that to be necessary for this purpose. But before
this unusual kind of power is exercised it must be clear that the statutory procedure is insufficient to
achieve justice and that to require additional steps would not frustrate the apparent purpose of the
legislation.” Cf Lord Morris of Borth-y-Gest, at p 309B-C.”

68. I do not consider that there is, by analogy, any similar duty here to consult prior to issuing a Closure
Notice:

a. The 2014 Act expressly provides for a rapid opportunity for affected persons to make representations at
the hearing of the application for Closure Orders. The s.80 hearing goes beyond merely reproducing the
right which should be available on an application for judicial review. At the s.80 hearing, the Magistrates
can make the order only if satisfied of a number of matters including that the order is “necessary” (with all
the safeguards that that entails, including that there is no less intrusive measure that would suffice) to
prevent the behaviour, nuisance or disorder from continuing, recurring or occurring;

b. The timescales under the 2014 Act are far shorter than those which were imposed by the order in the
_Bank Mellat case, and prejudice to goodwill by reason of the interruption of business activity is thereby_
minimised. I do not accept Mr Streeten's submission that the temporary effect of a Closure Notice is such
as to cause irreversible damage to goodwill. Furthermore, unlike the position in the Bank Mellat case, there
is provision under the 2014 Act for compensation in the event that affected persons incur a loss;

c. To require the police to engage in consultation prior to the issuing of the notice would be likely to
frustrate or undermine the purpose of the legislation, which is to provide a “fast and flexible remedy”1 in the
event of serious nuisance or disorder.

69. I accept Mr Walsh QC's submission that the primary purpose of the obligation to inform under s.76(6)
is to enable persons who might be affected by the closure of premises to make such arrangements as may
be appropriate to avoid breaching the notice.

70. Mr Streeten submits that s.76 (6) cannot have the primary purpose contended for by the
Commissioner because if it were to do so it would render the service provisions under s.79 redundant.
Section 79 sets out the requirements to fix a copy of the notice on a prominent place on the premises and
to points of access, any outbuildings, and to give copies of the notice to persons who appear to have
control of or responsibility for the premises, people who live in the premises and any person who does not
live there but who was informed under s.76(6) that the notice was going to be issued. In my judgement, the


-----

service requirements under s.79 serve a different purpose to the obligation to inform under s.76(6). At the
point where persons are being informed that a notice is going to be issued, they would still have the right to
enter the premises and make any arrangements that may be necessary for dealing with the imminent
closure of the premises, whereas once the notice is actually served, pursuant to s.79, affected persons
cannot enter the premises at all.

_(c) Does the failure to comply with s.76(6) mean that the Closure Notice is a nullity?_

71. In order to make good his submission that the failure to comply with the obligation to inform arising
under s.76(6) of the Act rendered the Closure Notice a nullity, Mr Streeten took me to some landmark
administrative law authorities such as Hoffmann La Roche [1975] AC 295, DPP v Hutchinson [1990] 2 AC
83and _Boddington. It is not necessary to cite the passages to which I was taken, which are very well-_
known, and do not, to my mind, advance the Claimants' argument. Perhaps of more assistance in this
context is the judgment in _R (Jeyeanthan) v Secretary of State for the Home Department [2000] 1 WLR_
354 to which I was also taken, and in which the Court of Appeal considered the effect of the failure to use a
mandatory prescribed form in the course of asylum proceedings. Lord Woolf MR (as he then was) held at
(362 C-G):

“… I suggest that the right approach is to regard the question whether requirement is directory or
mandatory as only at most a first step. In the majority of cases there are other questions which have to be
asked which are more likely to be of greater assistance than the application of the mandatory/directory test.
The questions which are likely to arise are as follows

1. Is the statutory requirement fulfilled if there has been substantial compliance with the requirement and, if
so, has there been substantial compliance in the case in issue even though there has not been strict
compliance? (The substantial compliance question.)

2. Is the non-compliance capable of being waived, and if so, has it, or can it and should be waived in this
particular case? (The discretionary question.) I treat the grant of an extension of time for compliance as a
waiver.

3. If it is not capable of being waived or is not waived then what is the consequence of the noncompliance? (The consequences question.)

Which questions will arise will depend upon the facts of the case and the nature of the particular
requirement. The advantage of focusing on these questions is it they should avoid the unjust and
unintended consequences which can flow from an approach solely dependent on dividing requirements in
the mandatory ones, which asked jurisdiction or directory, which do not if the result of non-compliance
goes to jurisdiction it will be said jurisdiction cannot be conferred where it does not otherwise exist by
consent or waiver.”

72. Given the statutory requirement under the 2014 Act that a closure notice may be issued _only if_
reasonable efforts have been made to inform affected persons that the notice is going to be issued, it
seems to me that the requirement is not one that may be waived. Thus, it is necessary to consider whether
there has been substantial compliance with the requirement (as the Commissioner contends) and what are
the consequences of non-compliance.

_(d) Was there substantial compliance?_

73. Mr Streeten submitted that there cannot be substantial compliance given the important consultative
purposes of s.76(6). For reasons already set out above, I do not agree that the provision does have those
purposes. The Claimants were not deprived of an opportunity to make representations. They had that
opportunity at the hearing of the application for the Closure Orders which were to be heard very shortly
after the issuing of the Closure Notices. The Claimants have not suggested that the Closure Order
proceedings themselves were deficient in that respect.

74. In the circumstances, where all the affected persons:

a had notice of the application for a closure order;


-----

b. were present at the hearing of that application; and

c. had an opportunity to make representations (which in the event led to a successful outcome for the
Claimants),

it is clear that there was substantial compliance with the requirements for the issuing of the Closure
Notices. The aim of the legislation in this regard appears to have been achieved and the failure to comply
with s.76(6) has not resulted in any substantial prejudice to any party or individual. Indeed, it is difficult to
see what better consequences could have resulted for the Claimants if there had been strict compliance
with the subsection.

_(e) What are the consequences for the costs decision?_

75. Given my conclusion that the Magistrates were correct to consider that questions of the validity or
otherwise of the Closure Notice are not questions for them, it follows, in my judgment, that those questions,
and the facts giving rise to them, are also not relevant to the determination of costs. If that were not so,
then the Magistrates would, in assessing costs, have to take into account matters in respect of which they
would not have had an opportunity to reach a final determination. That could result in unfairness.
Furthermore, if the Magistrates had expressed a view on the correctness or otherwise of conduct relating
to the challenge on validity, then it could be encroaching onto territory reserved for the Court dealing with
the judicial review.

76. I do not consider that any unfairness would result from the exclusion of matters relating to validity from
the Magistrates' assessment on costs. Insofar as any costs issues might arise out of those matters, then
they could be addressed, if necessary, by the Court dealing with the Judicial Review.

77. The answer to the second question in the case stated is also in the negative.

**Issue 3: En Bloc assessment of costs and compensation**

78. As already set out above, costs are a matter for the Magistrates' discretion. (see paragraphs 40-41
above). It is also important to bear in mind that a more restrictive costs approach applies in cases such as
the present one where the starting and default position is no order as to costs.

79. The Claimants' complaint under this head is that that the DJ should not have grouped the Claimants
together when it came to costs and that she disregarded her own findings as to the differences between
them. The Claimants place heavy reliance on the DJ's conclusion that, “There are many things in this case
which may lead to the suspicion that sexual services were being carried out at some of these premises.”
(Emphasis Added)

80. It was submitted that the reference to “some of these premises” necessarily implies that there was no,
or very little, evidence to give rise to the suspicion in respect of other premises. However, a fair reading of
the entirety of the DJ's judgment reveals that each of the premises was considered in turn, and that at least
some evidence giving rise to a suspicion of sexual activity was present for all of them. That included the
premises at 52 Rupert Street. Although the quantity of evidence in relation to this property was less than
for others, the DJ still found that a search of the premises had disclosed mouthwash, chewing gum, baby
wipes, some form of “sex toy”; and that the property is included on a website where those who pay for
sexual services post reviews. The DJ did not accept the evidence of a police officer as to the effect of a
sign on the wall at this property, which was said to relate to sexual activity, and there was evidence from a
Westminster City Council officer that whilst the premises had a “colourful history” there was nothing
detrimental in its recent history. The DJ's conclusion was that this material was not sufficient to show, on
the balance of probabilities that the person has engaged, or is likely to engage, in criminal behaviour on the
premises. The DJ reached the same conclusion, albeit on the basis of other evidence, for all six premises.

81. Furthermore, there was nothing to distinguish the Police's actions in respect of the six premises. They
were all targeted as part of the same operation; they were the subject of Closure Notices issued in similar
terms; and the applications for Closure Orders had been heard together and pursued on the same bases.
The DJ's conclusion that the Police had acted “reasonably and properly” was applicable to conduct in
t f ll f th i


-----

82. In these circumstances, there was nothing wrong in principle in the DJ taking an overall approach to
costs rather than on a property-by-property basis.

83. Even if costs had been considered on a property-by-property basis, the strong likelihood is that the DJ
would have come to the same conclusion, namely that no costs should be awarded. The different levels of
evidence relating to each of the properties were not such as to render the 'en bloc' approach wholly
inappropriate. The position might have been different had there been no evidence at all to support
proceedings against some of the premises, or if the Police's conduct in respect of some of them fell
markedly below the standard applied to the others. However, as stated above, that was not the case.

84. The Claimants also argue that the DJ's failure to deal with the costs application on a property-byproperty basis necessarily meant that no party was in a position to know why they were not awarded their
costs. As such it was argued that the reasons of the DJ did not meet the standard required by English v
_Emery Reinbold and Strick Ltd_ _[2002] EWCA Civ 605. In my judgement, it was clear to the Claimants why_
costs were not awarded: The default or starting position in cases such as this is that there should be no
order as to costs: See _Bradford MDC v Booth_ [2001] LLR 151. The DJ's reasons, as already discussed,
dealt with each of the properties, and the DJ concluded that the Police had acted reasonably and properly.
The only proper inference to be drawn from the DJs conclusions is that that finding applied to the Police's
conduct in respect of all the properties involved. In my judgement, there was no failure to explain.

85. As for compensation, the Commissioner takes a neutral stance. I have already concluded that the
Magistrates' approach to compensation was incorrect, and I have directed that the matter be remitted for
reconsideration (See Issue 1 above). An 'en bloc' approach to the assessment of compensation would be
unworkable and incorrect. That is because the Magistrates are required by s.90(5) of the 2014 Act to
consider the position of each applicant for compensation separately in order to determine whether they
were associated with the behaviour on the premises concerned and (if they are the owner or occupier of
the premises) whether they had taken reasonable steps to prevent it. Furthermore, if satisfied that the
requirements of s.90(a) to (c) are met then the Magistrates must go on to consider whether it is appropriate
to award compensation in respect of that loss; that is to say the particular loss claimed by the applicant.
That loss might well be different for each applicant depending on the effect that the closure had on their
particular business. In these circumstances, it is incumbent upon the Magistrates to consider the position of
each applicant individually to determine whether compensation should be awarded. For these reasons, in
directing that the matter of compensation be remitted to the Magistrates, I also direct that the position of
each applicant be considered separately.

86. Any inconsistency with the position on costs is justified, in my judgment, by the specific statutory
provisions dictating what is to be taken into account in deciding whether to award compensation.

**Conclusion**

87. For the reasons set out above, I find that:

a. The Claimants succeed in respect of Issue 1 and the assessment of compensation. The matter shall be
remitted for reconsideration in accordance with the terms of this judgment;

b. The Claimants fail in respect of Issue 2 and the effect of the failure to comply with s.76(6) of the 2014
Act;

c. The Claimants fail in respect of Issue 3 insofar as it relates to costs, but succeed insofar as it relates to
compensation.

d. Permission is refused in respect of the First JR.

e. The Second JR succeeds in respect of Ground 2 (proper test for compensation). The DJ's decision as
to compensation is quashed.

88. The parties are to attempt to agree the terms of an order for this Court's approval.

**E d** **f D**


-----

