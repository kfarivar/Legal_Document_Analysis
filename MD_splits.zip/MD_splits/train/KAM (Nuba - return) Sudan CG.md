# KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

C M G Ockelton and Judge Grubb

1 September 2020Judgment

For the Appellant: Mr C Jacobs, instructed by Albany Solicitors

For the Respondent: Mr C Thomann, instructed by the Government Legal Department

(a) _An individual of Nuba ethnicity is not at real risk of persecution or serious ill-treatment on return to Sudan_
_(whether in the Nuba Mountains, Greater Khartoum or Khartoum International Airport) simply because of their_
_ethnicity._

(b) _A returning failed asylum-seeker (including of Nuba ethnicity) is not at real risk of persecution or serious ill-_
_treatment at the airport simply on account of being a failed asylum-seeker._

(c) Prior to the political developments in 2019, individuals who were at risk on return (whether at the airport or in
_Greater Khartoum) were those who were perceived by the Sudanese authorities to be a sufficiently serious threat to_
_the Sudanese Government to warrant targeting._

(d) _The assessment of that risk required an evaluation of what was likely to be known to the authorities and a_
_holistic assessment of the individual's circumstances including any previous political activity in Sudan or abroad and_
_any past history of detention in Sudan. Factors include whether the individual was a student, a political activist or a_
_journalist; their ethnicity; their religion (in particular Christianity); and whether they came from a former conflict area_
_(such as the Nuba Mountains)._

(e) Whilst the question of perception of political opposition underlying (c) above remains the same since the 2019
_political developments, when assessing any risk to an individual now, the effects of the 2019 political developments_
_are relevant and are likely to affect the Sudanese authorities' view of, and attitude towards, those who might be_
_perceived as political opponents. Further, the 2019 political developments are likely to have greatly reduced the_
_interest of the Sudanese government in supressing political opposition by violent or military action._

(f) Internal relocation to Greater Khartoum for a person of Nuba ethnicity must depend upon an assessment of all
_the individual's circumstances including their living conditions, their ability to access education, healthcare and_
_employment. Despite the impoverished conditions and discrimination faced by Nuba when living in the so-called_
_'Black Belt' area of Greater Khartoum, relocating there will not generally be unduly harsh or unreasonable._

**DECISION AND REASONS**

1. This decision provides country guidance on two principal issues. First, what, if any, is the risk of persecution
and/or serious ill-treatment for a person of Nuba ethnicity in Sudan? Second, what, if any, internal relocation option
is available to a person of Nuba ethnicity if at risk of persecution in their home area?

**I. BACKGROUND**


-----

2. The Nuba peoples comprise various non-Arab ethnic groups who are indigenous to, and inhabit, the Nuba
Mountains (in particular the foothills) in South Kordofan State in Sudan.  That area borders the (now) independent
country of South Sudan. The Nuba also live in the Blue Nile State of Sudan. Together these areas are known as
the “Two Areas”. They are a disparate group of tribes (perhaps around 50) lacking any political unity and speak a
number of languages (estimated as over 100). They live in villages, organised in clans or extended family groups,
with clan elders being in authority. The Nuba practise a number of different religions including Islam, Christianity
and traditional African beliefs.

3. Estimates of how many Nuba live in Sudan vary. In 2003, the Sudanese Government estimated there were 1.07
million Nuba in Sudan. Some estimates put the number higher. Many Nuba, as a result of conflict in their home
area, now live in or around the capital, Khartoum which, as “Greater Khartoum”, is comprised of the three urban
conurbations of Khartoum, Khartoum North and Omdurman (also known as the “Three Towns”). Although there is
no verified figure, we heard evidence that put the number of Nuba in Greater Khartoum in the 100,000s. Together
with Non-Arab Darfuris, some sources have estimated that the numbers may be higher reaching as many as 1
million, and some sources estimating as high as 5 million, living in Greater Khartoum. It is said that the joint
Nuba/Non-Arab Darfuri population represents 60% or 70% of the total population of Greater Khartoum (see Joint
Danish Immigration Service and Home Office Fact-finding Missions to Khartoum, Kampala and Nairobi, “Situation of
Persons from Darfur, Southern Kordofan and Blue Nile in Khartoum” (4 August 2016) at para 1.1). Whatever the
correct figure, there is undoubtedly a very sizable population of Nuba living in Greater Khartoum. Most live in
shanty towns in an area called the 'Black Belt' on the outskirts of the conurbation.

4. It is helpful to set out as background a brief summary of the relevant political history of Sudan. We include a
number of factual matters widely reported in the news which took place in Sudan after the October 2019 hearing.

5. Sudan became an independent country in 1956. Its immediately relevant political history dates from June 1989
when a military coup led by Colonel al-Bashir (“al-Bashir”) deposed the existing government and installed a military
government (with him as the Chairman of the Revolutionary Command Council for National Salvation) and created
an Islamic state. In October 1993 al-Bashir appointed himself President with executive and legislative powers.
Sudan became a one-party state under the National Congress Party (the “NCP”).

6. Sudan has seen a number of internal military conflicts between rebel groups and the Government both in the
western Darfur region and in the east and south of the country.

7. A conflict in the Darfur region began in 2003 led by rebel groups including the Sudanese Liberation
Movement/Army (“SLM/A”) and Justice and Equality Movement (“JEM”) arising from dissatisfaction with the
treatment of Non-Arabs in Darfur. The conflict lasted until 2007. The Sudanese Government has been widely
accused of genocide in Darfur, in particular as a result of the actions of its proxy, the Janjaweed militia. As a
consequence, in March 2009 al-Bashir was indicted for war crimes and crimes of genocide and against humanity
before the International Criminal Court in The Hague.

8. In the south of Sudan a further conflict arose between 2003 and 2005 waged against the Sudanese Government
by a coalition of rebel groups, primarily led by the Sudanese People's Liberation Movement (“SPLM”). Following the
signing of a peace agreement between the SPLM and the Sudanese Government in 2006, a referendum in 2011
led to the secession, and creation of the independent country, of South Sudan in 2011.

9. In 2010, in the lead-up to the referendum, a military conflict broke out in the South Kordofan region between the
rebel group, the Sudanese People's Liberation Movement-North (“SPLM-N”) (affiliated to the SPLM) and the
Sudanese Government. The conflict in South Kordofan has been described as creating a humanitarian crisis in that
area and a blockade was in force to prevent humanitarian aid reaching the area until that was lifted in late 2019.
The conflict continued until the Sudanese Government declared a ceasefire in June 2016, initially for 4 months.
The ceasefire has been periodically renewed and remains in place, though this is not to say that sporadic violent
incidents or attacks have not continued to occur.

10. The most recent political changes in Sudan began as a result of events beginning in late 2018 when there were
widespread public protests in particularly in Khartoum The protest movement was initially led by professionals 

-----

the Sudanese Professional Association (“SPA”) - and subsequently a broader coalition of protestors known as the
Forces of Freedom and Change (“FFC”). The protests were motivated by the significant economic down-turn in
Sudan and its day-to-day impact on the price of food and other goods. The protests were sustained and grew in
early 2019.

11. On 11 April 2019, al-Bashir was overthrown by a military coup. He was replaced by a Transitional Military
Council (“TMC”). The protests, however, continued, resulting in a violent crack-down on protestors by the new
Sudanese authorities on 3 June 2019. Nevertheless, the protests continued.

12. On 5 July 2019, the TMC and FFC signed an agreement for a transition to a democratic state. This was
followed by the adoption of a draft constitution on 21 August 2019 and, in September 2019, the creation of a
Sovereign Council (“SC”) comprised of military and civilian members, presently chaired by Lieut-General al-Burhan
(“al-Burhan”). The chair of the SC will change to a civilian in June 2021 and the country to civilian rule after 39
months, i.e. in the summer of 2022. The present Government is led by a respected economist, Prime Minister
Abdalla Hamdok appointed on 21 August 2019. An independent Chief Justice and Attorney-General were
subsequently selected and appointed.

13. Peace talks between the new Sudanese Government and the two factions of the SPLM-N in the Nuba
Mountains and the Blue Nile (led respectively by Abdelaziz al Hilu (“al Hilu”) and Malik Agar) began in the autumn of
2019 in Juba, the capital of South Sudan.  Despite withdrawing at one point, al Hilu subsequently returned to
participate in the talks.

14. In November 2019, the restrictive Public Order law, whose use by the al-Bashir regime was widely recognised
as a means to control how women acted and dressed, was repealed by the new Legislative Council (BBC News,
“Sudan crisis: Women praise end of strict public order law”, 29 November 2019). The Sudanese authorities also
dissolved the NCP, the political party of the former President.

15. In December 2019, al-Bashir was convicted of corruption in Sudan and sentenced to 2 years' detention in a
prison for the elderly (BBC News, “Omar al-Bashir: Sudan ex-leader sentenced for corruption”, 14 December 2019).
In addition, Sudan has begun an investigation into the crimes committed in Darfur under the al-Bashir regime and in
February 2020 the new Sudanese Government agreed to hand over al-Bashir to the ICC to face the March 2009
indictment arising out of the Darfur conflict (BBC News, “Omar al-Bashir: Sudan agrees ex-president must face
ICC”, 11 February 2020).

16. In January 2020, the Sudanese army quelled a brief rebellion in Greater Khartoum by elite troops loyal to alBashir (BBC News, “Sudan army quells Khartoum mutiny by pro-Bashir troops”, 15 January 2020). The rebellion
appears to have been caused by a disagreement over severance pay to members of the General Intelligence
Service (“GIS”) - which had resulted from renaming in July 2019 of the National Intelligence and Security Service
(“NISS”) headed by Salah Ghosh until he was sacked by al-Burhan in April 2019 - which is being overhauled. The
action of the rebels was condemned by both al-Burhan, as head of the SC, and General Mohammed Dagalo (widely
known as “Hemeti” or “Himiti”), a powerful figure in Sudan who previously led the Janjaweed and now leads its
successor, the Rapid Support Force (“RSF”) and who is a member of the SC. In March 2020, the Prime Minister
Hamdok survived an assassination attempt in Greater Khartoum (BBC News, “Sudan PM Abdalla Hamdok survives
assassination attempt”, 9 March 2020). Finally, in July 2020, the Sudanese Government announced new laws
reforming laws from the period of Islamic rule: allowing non-Muslims to drink, sell and import alcohol, removing the
requirement that women have permission from a male relative to travel with their children, abolishing the crime of
apostacy and banning the practice of female genital mutilation (BBC News, “Sudan scraps apostasy law and
alcohol ban for non-Muslims”, 13 July 2020).

**II. THE PARTIES' CASES IN SUMMARY**

17. The appellant's case is that all Nuba (including the appellant), regardless of any political or other profile, face a
real risk of persecution and/or serious ill-treatment contrary to Art 3 of the ECHR on return to Sudan on the basis of
their ethnicity and political opinion because of their perceived association with rebel groups, in particular the SPLMN That position is said to be sustained on two bases


-----

18. First, the Nuba are treated in the same way as non-Arab Darfuris which, the CG cases of AA (Non-Arab
Darfuris – relocation) Sudan CG _[[2009] UKAIT 00056 and MM (Darfuris) Sudan CG [2015] UKUT 000010 (IAC)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XN3-P8Y0-Y9GT-11NY-00000-00&context=1519360)_
recognise, are at risk on return. Secondly, the evidence from the witnesses and background evidence establishes
that there is a real risk of persecution and/or serious ill-treatment to all Nuba (a) in the Nuba Mountains in South
Kordofan; (b) in Greater Khartoum; and (c) on return at the airport. The present situation, despite the developments
in 2019 remains fragile and it remains unsafe to return Nuba asylum-seekers to Sudan.

19. Finally, the appellant contends that internal relocation to Greater Khartoum is not reasonably open to an
individual at risk in their home area.

20. The respondent rejects any analogy with, and reliance upon, the CG decisions relating to non-Arabs from
Darfur. Further, the respondent contends that there is no risk per se to an individual of Nuba ethnicity on return.
The respondent contends that there are no specific categories of individuals who cannot safely be returned – each
case must be assessed on a holistic basis and is fact-sensitive by analogy to the approach of the Upper Tribunal
(“UT”) in IM and AI (Risks – membership of Beja Tribe, Beja Congress and JEM) Sudan CG [2016] UKUT 000188
(IAC). Any risk flows from an individual's perceived political profile or activism and not from the mere fact of being
from a Nuba tribe. The issue is whether the individual's profile or political activity presents (or is perceived to
present) a sufficiently serious threat to the Sudanese regime to warrant targeting. It is the respondent's contention
that the political developments in 2019 have shifted the threat to the Sudanese regime, and by the regime, from a
military to a political dimension.

21. Finally, the Respondent accepts that internal relocation is not available when an individual is at risk from the
Sudanese State. She also accepts that, if there is a serious risk of harm, for example, in Greater Khartoum an
individual cannot reasonably be expected to relocate to the Nuba Mountains. The respondent contends that the
reasonableness of internal relocation from some other area to Greater Khartoum, however, will be fact-sensitive.

**III. THE APPEAL**

22. The appellant is a citizen of Sudan who was born in 1983. He comes from Omdurman, Sudan's second largest
city and part of Greater Khartoum. He is of Nuba ethnicity. He left Sudan on 21 November 2014 and, having
travelled through a number of countries, arrived in the United Kingdom on 31 August 2015 and claimed asylum. His
claim had four elements.

23. First, the appellant claimed that he had left Omdurman in 2009 and moved to the Nuba Mountains. After
conflict broke out there in 2011 between the SPLM-N and the Sudanese authorities, he decided to return to
Omdurman and, he claimed, whilst travelling to Omdurman in 2013 or 2014 (his evidence referred to both dates),
he had been arrested and detained by the government and accused of being a member of the SPLM-N. Secondly,
he claimed to fear the SPLM-N whom he had refused to join. Thirdly, the appellant relied upon sur place activities,
namely a television interview criticising the Government. Finally, he claimed to be at risk from the Sudanese
Government because he was of Nuba ethnicity.

24. On 18 December 2015, the Secretary of State refused the appellant's claims for asylum, humanitarian
protection and under Article 8 of the ECHR.

25. Following the refusal of his claims, the appellant appealed to the First-tier Tribunal (“FtT”). His appeal was
heard by Judge Sweeney on 3 August 2016. Judge Sweeney dismissed the appellant's appeal on all grounds.
Judge Sweeney accepted that the appellant was a Sudanese citizen and of Nuba ethnicity. However, the judge
rejected the appellant's account including that he had left Omdurman to go to the Nuba Mountains and that he had
been arrested and detained by the Sudanese Government whilst returning to Omdurman. The judge concluded
that the appellant would not be at risk from the SPLM-N, not least because they had shown no adverse interest in
him since 2011/12. Finally, the judge rejected the appellant's claim to be at risk because of his sur place activities
because there was no evidence that he had come to the attention of the Sudanese authorities nor was it likely that
his limited activities would do so.


-----

26. The appellant appealed, with permission, to the Upper Tribunal (“UT”). The appellant did not challenge the
judge's adverse credibility finding. The grounds argued that the judge failed to consider the risk to the appellant
because of his Nuba ethnicity in the light of his sur place activities which would result in him being regarded as a
political opponent.

27. In a decision sent on 24 February 2017 (Appendix 2), the UT (UTJ Grubb and DUTJ Chalkley) concluded that
the appellant's grounds were made out and set aside the FtT's decision. The judge's factual findings were
preserved. The appeal was adjourned in order that, at a resumed hearing, the decision could be re-made on the
sole issue of whether the appellant had established that he would be at risk on return to Sudan because of his Nuba
ethnicity. Subsequently, the appeal was identified as one appropriate to give country guidance on that general
issue.

**IV. THE HEARINGS**

28. The substantive appeal to re-make the decision, ignoring intervening case management hearings, was listed on
three occasions between May/June 2018 and October 2019.

29. On 31 May and 1 June 2018, we heard oral evidence from three witness: (1) Dame Rosalind Marsden DCMG
(a former British Ambassador and EU Special Representative to Sudan), (2) Madeline Crowther (Director of Waging
Peace, an organisation which campaigns against human rights abuses in Sudan) and (3) Dr Eric Reeves (a Senior
Fellow at Harvard University's Centre for Health and Human Rights). The latter's evidence was given, not without
technical difficulties, by Skype from the USA.

30. On 30 August 2018, the hearing resumed for submissions. However, it transpired at that hearing that a Home
Office fact-finding visit to Sudan had taken place earlier in August and a report was expected in October. In the
light of that, we adjourned the hearing to await the report and any further evidence or submissions in respect of it.
In the result the report was delayed and only became available in November 2018 (Home Office, “Report of a FactFinding Mission to Khartoum, Sudan” (the “F-FR 2018”)). In January 2019, supplementary reports were prepared
by both Dame Rosalind Marsden and Madeline Crowther in relation to the F-FR 2018.

31. However, the supervening events in Sudan beginning in late 2018 further delayed, with the parties' agreement,
the re-listing of the appeal. At a CMH on 29 August 2019, despite the evolving situation in Sudan it was agreed by
the parties that the appeal should be re-listed in October 2019 in order to hear further evidence (if appropriate) and
final submissions.

32. On 24 and 25 October 2019 the appeal was re-listed when further reports were prepared by, and there was
further oral evidence from, Dame Rosalind Marsden and Madeline Crowther. We received no further evidence from
the parties after the hearing on 24/25 October. Both representatives agreed that only if there was evidence which
changed the 'direction of travel' of a party's case would further evidence be submitted by the parties. In the result,
neither party sought to introduce any post-hearing evidence, despite the events to which we have referred above.
We have referred to news reports above, in order to give context and to show that there has been no change in the
direction of travel. Our decision, however, is made on the evidence we heard, not taking into account any posthearing news reports.

33. Following the 24/25 October hearing, the parties provided us with sequential written submissions ending with
the appellant's response on 5 December 2019. We are grateful to both counsel for their detailed and helpful written
submissions. We are also grateful to them for their helpful written, and for the most part agreed, summary of the
oral evidence given at the initial hearing in May/June 2018.

**V. THE EXISTING COUNTRY GUIDANCE**

34. There is no existing country guidance directly concerned with the Nuba in Sudan.


-----

35. However, existing country guidance recognises that non-Arab Darfuris are at risk on return to Sudan. That was
[accepted by the AIT in AA (Non-Arab Darfuris – relocation) Sudan CG [2009] UKAIT 00056. As summarised in the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XN3-P8Y0-Y9GT-11NY-00000-00&context=1519360)
headnote, the AIT decided:

“All non-Arab Darfuris are at real risk of persecution in Darfur and cannot reasonably be expected to relocate
elsewhere in Sudan.”

36. AA was re-affirmed by the Upper Tribunal in MM (Darfuris) Sudan CG [2015] UKUT 000010 (IAC) where it was
emphasised that the term “Darfuri” was to be understood as an “ethnic term” relating to origins and not a
geographical term such that it covered Darfuris who were not born in Darfur. As a consequence, the UT recognised
that there is a real risk of persecution for a non-Arab Darfuri whatever their home area (e.g. including Greater
Khartoum) in Sudan.

37. Despite the developments in Sudan since December 2018, MM has recently been affirmed by the UT (albeit
without a CG designation) in AAR & AA (Non-Arab Darfuris - return) Sudan [2019] UKUT 282 (IAC). The headnote
reads as follows:

“The situation in Sudan remains volatile after civil protests started in late 2018 and the future is unpredictable.
There is insufficient evidence currently available to show that the guidance given in AA (non-Arab Darfuris [relocation) Sudan CG [2009] UKAIT 00056 and MM (Darfuris) Sudan CG [2015] UKUT 10 (IAC) requires revision.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F27-STW1-F0JY-C4J7-00000-00&context=1519360)
Those cases should still be followed.”

38. The CG decisions, therefore, in respect of non-Arab Darfuris remain at present unchanged, if only because the
Tribunal has not yet had the opportunity to consider fully the position in Sudan following the recent changes.

39. There is one further CG decision we should mention. IM and AI (Risks – membership of Beja Tribe, Beja
Congress and JEM) Sudan CG [2016] UKUT 000188 (IAC) concerned the risk to members of the Beja tribe and
those politically active with the Justice and Equality Movement (“the JEM”) in Sudan. The guidance is detailed and
is summarised in the headnote (emphasis added). It reflects a distinction between those who are (or are perceived
as) politically active and a sufficient threat to the regime, and those who are not (references to “NISS” are to the
former National Intelligence and Security Service, for which see para 16 above):

“1. In order for a person to be at risk on return to Sudan there must be evidence known to the Sudanese authorities
_which implicates the claimant in activity which they are likely to perceive as a potential threat to the regime to the_
extent that, on return to Khartoum there is a risk to the claimant that he will be targeted by the authorities. The task
of the decision maker is to identify such a person and this requires as comprehensive an assessment as possible
about the individual concerned.

2. The evidence draws a clear distinction between those who are arrested, detained for a short period, questioned,
probably intimidated, possibly rough handled without having suffered (or being at risk of suffering) serious harm and
those who face the much graver risk of serious harm. The distinction does not depend upon the individual being
classified, for example, as a teacher or a journalist (relevant as these matters are) but is the result of a finely
balanced fact-finding exercise encompassing all the information that can be gleaned about him. The decision maker
is required to place the individual in the airport on return or back home in his community and assess how the
authorities are likely to re-act on the strength of the information known to them about him.

3. Distinctions must be drawn with those whose political activity is not particularly great or who do not have great
_influence. Whilst it does not take much for the NISS to open a file, the very fact that so many are identified as_
potential targets inevitably requires NISS to distinguish between those whom they view as a real threat and those
whom they do not.

4. It will not be enough to make out a risk that the authorities' interest will be limited to the extremely common
phenomenon of arrest and detention which though intimidating (and designed to be intimidating) does not cross the
threshold into persecution.


-----

5. _The purpose of the targeting is likely to be obtaining information about the claimant's own activities or the_
activities of his friends and associates.

6. The evidence establishes the targeting is not random but the result of suspicion based upon information in the
authorities' possession, although it may be limited.

7. Caution should be exercised when the claim is based on a single incident. Statistically, a single incident must
reduce the likelihood of the Sudanese authorities becoming aware of it or treating the claimant as of significant
interest.

8. Where the claim is based on events in Sudan in which the claimant has come to the attention of the authorities,
the nature of the claimant's involvement, the likelihood of this being perceived as in opposition to the government,
his treatment in detention, the length of detention and any relevant surrounding circumstances and the likelihood of
the event or the detention being made the subject of a record are all likely to be material factors.

9. Where the claim is based on events outside Sudan, the evidence of the claimant having come to the attention of
Sudanese intelligence is bound to be more difficult to establish. However, it is clear that the Sudanese authorities
place reliance upon information-gathering about the activities of members of the diaspora which includes covert
surveillance. The nature and extent of the claimant's activities, when and where, will inform the decision maker
when he comes to decide whether it is likely those activities will attract the attention of the authorities, bearing in
mind the likelihood that the authorities will have to distinguish amongst a potentially large group of individuals
between those who merit being targeted and those that do not.

10. The decision maker must seek to build up as comprehensive a picture as possible of the claimant taking into
account all relevant material including that which may not have been established even to the lower standard of
proof.

11. Once a composite assessment of the evidence has been made, it will be for the decision maker to determine
whether there is a real risk that the claimant will come to the attention of the authorities on return in such a way as
amounts to more than the routine commonplace detention but meets the threshold of a real risk of serious harm.

12. Where a claimant has not been believed in all or part of his evidence, the decision maker will have to assess
how this impacts on the requirement to establish that a Convention claim has been made out. He will not have the
comprehensive, composite picture he would otherwise have had. There are likely to be shortfalls in the evidence
that the decision maker is unable to speculate upon. The final analysis will remain the same: has the claimant
established there is a real risk that he, the claimant, will come to the attention of the authorities on return in such a
way as amounts to more than the routine commonplace detention and release but meets the threshold of serious
harm.”

40. At [203], the UT made brief mention of individuals from South Kordofan and the Blue Nile:

“The problem that the evidence presents is that whilst the categories of those potentially at risk are legion, it is
apparent that not all those falling into a particular category are at risk. It is not enough, therefore, to be a journalist
or a student because not all members of these groups are at risk. So, too, with ethnic or tribal classification. Not all
_non-Arabs are at risk; nor all black Africans are at risk notwithstanding the unchallenged evidence that they are_
_members of the various tribes associated with this group. Not all those from the troubled regions of Darfur,_
_Southern Kordofan or the Blue Nile are at risk. Nor are all those who have been arrested and detained. However, all_
of these matters are factors that are relevant and some, of course, are much more likely to be significant, such as
prior detention and ill-treatment as a result of involvement in activities perceived as being in opposition to the
government. Yet, all of this material must be taken into account.” (our emphasis)

41. So far as we are aware, this is the only reference in the CG cases to those from South Kordofan which must
refer to the Nuba. It places them in the same position as those with whom the UT in IM and AI were concerned, the
risk to whom has to be assessed holistically to determine whether as a result of their activities they are likely to be
perceived as a potential threat to the Sudanese regime.


-----

42. Although not referred to in the headnote, the UT specifically concluded that individuals were not at risk on
return to Sudan merely by reason of being failed asylum-seekers ([222]-[225]).

**VI. THE LEGAL FRAMEWORK**

43. The applicable law was not a matter of contention between the parties. The appellant relies upon the Refugee
Convention and Art 3 of the ECHR. (Reference is also made to Art 2 ('right to life') but we did not understand this to
add anything to the reliance upon Art 3 or the Refugee Convention in this case.)  Consequently, we are not
concerned with, and heard no argument upon, any issue concerning humanitarian protection under Art 15(c) of
Council Directive 2004/83/EC (“the Qualification Directive”). We can, therefore, state the applicable law briefly.

A. Refugee Convention

44. Article 1A(2) of the Refugee Convention, defines a refugee as being a person who:

"owing to well-founded fear of being persecuted for reasons of race, religion, nationality, membership of a particular
social group or political opinion, is outside the country of his nationality and is unable or, owing to such fear, is
unwilling to avail himself of the protection of that country; or who, not having a nationality and being outside the
country of his former habitual residence as a result of such events, is unable or, owing to such fear, is unwilling to
return to it."

(See also Art 2(c) of the Qualification Directive.)

45. A fear of persecution will be well-founded, if the decision-maker is satisfied that there is a reasonable degree of
likelihood (or real risk) that the individual would be persecuted for a Convention reason if returned to his own
country (R v SSHD, ex p Sivakumaran [1988] AC 958 at 197–198, 202, per Lord Keith of Kinkel and at 994, 1000,
per Lord Goff of Chieveley).

46. Whilst caution must be exercised in adding any gloss to the “reasonable degree of likelihood” and “real risk”
standards, where it is said that a particular group, or return in particular circumstances, gives rise to a claim by an
individual who fits that group or circumstance, as the AIT pointed out in AA (Risk for involuntary returnees)
[Zimbabwe CG [2006] UKAIT 00061 at [29}:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MRN-JX80-TWYV-R14V-00000-00&context=1519360)

“ The point is that where risk is said to arise based upon the perception that the appellant falls within a class of
persons he will not be able to demonstrate that he faces a real risk unless the evidence shows that the abuse is
consistently applied to that class of persons.”

47. The AIT added (at [31]) in the context of a claim that all failed asylum-seekers were at risk on return:

“The issue is whether the evidence establishes a real risk. The appellant does not need to show a certainty or a
probability that all failed asylum seekers returned involuntarily will face serious ill-treatment upon return. He needs
to show only that there is a consistent pattern of such mistreatment such that anyone returning in those
circumstances faces a real risk of coming to harm even though not everyone does.”

48. Persecution may arise from sufficiently serious physical or mental ill-treatment, or discrimination by the state:
actions which are “sufficiently serious by their nature or repetition as to constitute a severe violation of basis human
rights” (see Art 9 of the Qualification Directive).

49. The persecution must be “for” one of the stated Convention reasons: relevant in this appeal particularly are
political opinion, religion and race. The last includes “colour, descent, or membership of a particular ethnic group”
(see Art 10.1 of the Qualification Directive). It is immaterial whether the individual possesses the relevant
characteristic (such as political opinion) which attracts persecution provided that such a characteristic is attributed
to (or perceived to be held by) the individual by the persecutor (Art 10.2 of the Qualification Directive).

B. Article 3


-----

50. In respect of Article 3 of the ECHR, the appellant must establish that there are substantial grounds for believing
that there is a real risk of treatment contrary to Article 3, i.e. “torture or inhuman or degrading treatment or
punishment”. This is frequently equated with “serious ill-treatment” or “serious harm” which is reflected in the terms
of Art 15(b) of the Qualification Directive. Further,

“the requirement that there must be substantial grounds for believing that there is a real risk of treatment contrary to
Article 3 on return means not more than that there must be a proper evidential basis for concluding that there [is]
such a real risk.” (AS and DD (Libya) v SSHD [2008] EWCA Civ 289 at [24]).

51. In the context of a claim based upon living conditions in the country of return, Art 3 requires a 'high threshold' to
be met before it will be breached. This is particularly so where the living conditions are “predominantly attributable
to poverty or the state's lack of resources to deal with naturally occurring phenomenon, such as drought” (see Sufi
and Elmi v UK 54 EHRR 209 at [282]).  In SSHD v Said [2016] EWCA Civ 442, the Court of Appeal applied this
approach and at [31], Burnett LJ (as he then was) said this:

“An appeal to article 3 which suggests that the person concerned would face impoverished conditions of living on
removal to Somalia should, as the Strasbourg Court indicated in Sufi and Elmi at para 292, be viewed by reference
to the test in the N case. Impoverished conditions which were the direct result of violent activities may be viewed
differently as would cases where the risk suggested is of direct violence itself.”

(See also Burnett LJ at [18].)

52. Whilst the case of N v UK (2008) 47 EHRR 39 has recently been reconsidered by the Strasbourg Court in
Paposhvili v Belgium [2017] Imm AR 867 and adopted by the Supreme Court in AM(Zimbabwe) v SSHD _[2020]_
_UKSC 17 so as to broaden the category of 'exceptional case' falling within Art 3 in medical/health cases (and here_
by analogy we assume in 'living condition' cases), it remains a rigorous test requiring serious and immediate
suffering reaching the high Art 3 threshold or a significant diminution in life expectancy (see [27]-[31] per Lord
Wilson in AM).

53. Where the humanitarian conditions are the result of a conflict, war or a state's discriminatory policy, the 'high
threshold' required to establish a breach of Art 3 does not apply. In Sufi & Elmi v UK (2012) 54 EHRR 9, the
Strasbourg Court said this at [282]-[283]:

“282. If the dire humanitarian conditions in Somalia were solely or even predominantly attributable to poverty or to
the State's lack of resources to deal with a naturally occurring phenomenon, such as a drought, the test in N. v. the
_United Kingdom may well have been considered to be the appropriate one. However, it is clear that while drought_
has contributed to the humanitarian crisis, that crisis is predominantly due to the direct and indirect actions of the
parties to the conflict. The reports indicate that all parties to the conflict have employed indiscriminate methods of
warfare in densely populated urban areas with no regard to the safety of the civilian population ... This fact alone
has resulted in widespread displacement and the breakdown of social, political and economic infrastructures.
Moreover, the situation has been greatly exacerbated by al-Shabab's refusal to permit international aid agencies to
operate in the areas under its control, despite the fact that between a third and a half of all Somalis are living in a
situation of serious deprivation ...

283. Consequently, the Court does not consider the approach adopted in _N. v. the United Kingdom_ to be
appropriate in the circumstances of the present case. Rather, it prefers the approach adopted in M.S.S. v. Belgium
_and Greece, which requires it to have regard to an applicant's ability to cater for his most basic needs, such as_
food, hygiene and shelter, his vulnerability to ill-treatment and the prospect of his situation improving within a
reasonable time-frame (see M.S.S. v. Belgium and Greece, cited above, § 254).”

54. In AMM and others (conflict; humanitarian crisis; returnees; FGM) Somalia CG [2011] UKUT 00445 (IAC) the
UT identified that the 'high threshold' in N did not apply where the “predominant cause” of the circumstances, said
to give rise to a breach of Art 3, is human actions rather than naturally occurring (at [129]):


-----

“If the predominant cause of the poor living conditions faced by a person is due to human actions in the State in
question, rather than to naturally occurring phenomena, coupled with a lack of resources to deal with those
phenomena, then the high threshold set by N need not be reached.”

C. Internal Relocation

55. Art 8 of the Qualification Directive sets out the legal approach to internal relocation in the case of a person who
is able to show a risk of persecution in their home area. For our purposes, it suffices to set out its adoption, in
substance, in para 399O of the Immigration Rules which is as follows:

“399O(i)  The Secretary of State will not make:

(a)  a grant of refugee status if in part of the country of origin a person would not have a well founded fear of being
persecuted, and the person can reasonably be expected to stay in that part of the country; or

(b)  a grant of humanitarian protection if in part of the country of return a person would not face a real risk of
suffering serious harm, and the person can reasonably be expected to stay in that part of the country.

(ii) In examining whether a part of the country of origin or country of return meets the requirements in (i) the
Secretary of State, when making a decision on whether to grant asylum or humanitarian protection, will have regard
to the general circumstances prevailing in that part of the country and to the personal circumstances of the person.

(iii) (i) applies notwithstanding technical obstacles to return to the country of origin or country of return.”

56. There are two limbs to be considered: (1) will the individual be exposed to a real risk of serious harm in the
place of proposed internal relocation?; and (2) if not, will it be reasonable (or unduly harsh) for that individual to live
in the place of proposed relocation? The issue of reasonableness only arises if there is not a real risk of serious
harm in the place of proposed relocation (see, SSHD v SC (Jamaica) [2017] EWCA Civ 2112 at [39]).

57. The approach to 'reasonableness' and 'undue harshness' as the second limb of the internal relocation test was
analysed by the House of Lords in Januzi v SSHD [2006] UKHL 5 and AH (Sudan) v SSHD [2006] UKHL 49. For
our purposes, as there was no dispute before us on the applicable law, it suffices to set out the helpful summary of
the law, drawing together the earlier cases, by the Court of Appeal in AS (Afghanistan) v SSHD [2019] EWCA Civ
_873. At [61] Underhill LJ (with whom King and Singh LJJ agreed) said:_

“61. I start by summarising the essential points, so far as relevant to this appeal, established by the authorities
about the nature of the exercise required by article 8 of the Directive. I emphasise that this is not intended as a
comprehensive analysis of all the issues raised by the authorities to which I have referred.

(1) By way of preliminary, internal relocation is obviously not an alternative where there is a real risk that the
applicant for asylum will suffer persecution, or serious harm within the meaning of article 15 of the Directive (which
includes treatment which would be contrary to article 3 of the ECHR), in the putative safe haven. We are concerned
with cases where there is no such risk.

(2) The ultimate question is whether in such a case "taking account of all relevant circumstances pertaining to the
claimant and his country of origin, … it is reasonable to expect the claimant to relocate or whether it would be
unduly harsh to expect him to do so". That is the formulation of Lord Bingham in Januzi, repeated in AH (Sudan). It
pre-dates the Directive and is not identically worded: in particular, the reference to whether relocation would be
"unduly harsh" is not present in article 8 but derives from the UNHCR 2003 Guidelines (see Januzi, para. 20). But it
was common ground before us that it states the test required by article 8 [of the Qualification Directive]. When in
doubt it is to that question that tribunals should return.

(3) The test so stated is one of great generality (save only that it excludes any comparison of the conditions,
including the degree of respect for human rights, between those obtaining in the safe haven and those of the
country of refuge – this being the ratio of _Januzi). It requires consideration of all matters relevant to the_


-----

reasonableness of relocation, none having inherent priority over the others (AH (Sudan), para. 13). This is the same
as Lady Hale's description of the necessary assessment as "holistic" (AH (Sudan) paras. 27-28).

(4) One way of approaching that assessment is to ask whether in the safe haven the applicant can lead "a relatively
normal life without facing undue hardship … in the context of the country concerned". That language derives from
the UNHCR Guidelines and is quoted by Lord Bingham with approval in Januzi (para. 20) and also used by Lord
Hope (para. 47); but it does not appear in the Directive or in Lord Bingham's formulation of the test, and it should
not be treated as a substitute for the latter. Rather, it is a valuable way of approaching the reasonableness analysis
– "one touchstone", as Lord Brown puts it (AH (Sudan) para. 42). Its value is because if a person is able to lead in
the safe haven a life which is relatively normal for people in the context of his or her own country, it will be
reasonable to expect them to stay there (AH (Sudan), para. 47).

(5) It may be reasonable, and not unduly harsh, to expect a refugee to relocate even if conditions in the safe haven
are, by the standards of the country of refuge, very bad. That is part of what is decided by _Januzi_ itself, and the
passages quoted at paras. 34 and 35 above reinforce it. It is also vividly illustrated by the outcome of AH (Sudan),
where the House of Lords upheld the decision of the AIT that it was reasonable for Darfuri refugees to be expected
to relocate to the camps or squatter slums of Khartoum. That may seem inconsistent with the suggested approach
of asking whether the applicant would be able lead a "relatively normal life" in the safe haven; but the reconciliation
lies in the qualification "in the context of the country concerned".

(6) Point (5) does not mean that it will be reasonable for a person to relocate to a safe haven, however bad the
conditions they will face there, as long as such conditions are normal in their country. Conditions may be normal but
nevertheless unduly harsh: this is the point emphasised by Lady Hale in _AH (Sudan) and is exemplified by_ _AA_
_(Uganda)._

(7) The UNHCR Guidelines contain a full discussion of factors relevant to the reasonableness analysis. These are
described by Lord Bingham as "valuable" and partly quoted by him (Januzi para. 20); and at para. 20 of her opinion
in AH (Sudan) Lady Hale endorses a submission made in that case by UNHCR which summarises the factors in
question. A decision-maker must consider those factors, so far as material, in each case (though it does not follow
that everything said in the detailed discussion in the Guidelines is authoritative).

(8) The assessment must in each case be conducted by reference to the reasonableness of relocation for the
particular individual.”

58. The burden of proof is upon the appellant to establish the real risk of serious harm in the proposed place of
[relocation (see SMO and others (Article 15(c); identity documents) CG Iraq [2019] UKUT 400 (IAC) at [206]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XWP-T4V3-CGXG-00NS-00000-00&context=1519360)

59. As regards reasonableness or undue harshness, an evaluative and holistic assessment of all the relevant
circumstances is required. In MB (Internal relocation - burden of proof) Albania _[[2019] UKUT 392 (IAC), the UT](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XS9-88G3-CGXG-007N-00000-00&context=1519360)_
stated:

“The burden of proof remains on the appellant, where the respondent has identified the location to which it is
asserted they could relocate, to prove why that location would be unduly harsh, in line with AMM and others
_(conflict; humanitarian crisis; returnees; FGM) Somalia_ CG _[2011] UKUT 445 (IAC), but within that burden, the_
evaluation exercise should be holistic. An holistic approach to such an assessment is consistent with the balancesheet approach endorsed later in SSHD v SC (Jamaica) [2017] EWCA Civ 2112, at paragraphs [40] and [41]. MM v
_Minister for Justice, Equality and Law Reform, Ireland (Common European Asylum System - Directive 2004/83/EC)_
Case C-277/11 does not impose a burden on the respondent or result in a formal sharing of the burden of proof, but
merely confirms a duty of cooperation at the stage of assessment, for example the production of the country
information reports.”

60. The UT in MB pointed out (at [25]) that “[a]n over-emphasis on the overall burden of proof can be a distraction
from that holistic assessment”.

**VII. THE EVIDENCE**


-----

61. The evidence in this appeal developed over the period of time that the appeal took to be completed, not least
due to the political developments in Sudan. Both the oral and written evidence are voluminous. The initial written
and oral evidence in May/June 2018 pre-dated the political developments in Sudan beginning in December 2018
and through 2019. We were provided with further written evidence, and we heard further oral evidence, from two of
the witnesses (Dame Rosalind Marsden and Ms Madeline Crowther) at the hearing in October 2019 but the
evidence of Dr Eric Reeves, given at the May/June 2018 hearing, was not updated and so necessarily did not
address the effects, if any, of the political developments in 2019.

62. Dame Rosalind has had considerable experience in Sudan itself, some of it recent. She has maintained her
interest in the country by high-level diplomatic contact. Much of what she told us she was able to support by
personal experience. Ms Crowther's knowledge of Sudan is derived from her work for a human rights organisation
in London. She has not visited Sudan and does not speak Arabic or any of the languages in which those on whose
behalf she works express themselves. Dr Reeves is an academic with considerable knowledge of Sudan but who
has not been in Sudan since 2003.All three referred to contacts with others who have experience in Sudan, from
whom they derived some of the opinions they incorporated in their evidence. In relation to facts, we attribute more
weight to those derived from direct personal observation by witnesses. That inevitably means that we give
considerable weight to the factual evidence of Dame Rosalind, if rather less to those of the other witnesses. In the
same way, we attribute considerable weight to factual statements in the written reports received in evidence, where
they are based on direct observation. We treat opinions with some caution, bearing in mind particularly whether
they are expressed by a person or body that has any campaigning role. In general, we have attempted to test
expressed opinions against the touchstone of observed facts in order to form our own views on the realities of the
position of Nuba in Sudan.

63. At our request, both Mr Jacobs and Mr Thomann helpfully made specific reference to the evidence upon which
they relied in their detained final written submissions. We set out that evidence in Appendix 1 as follows: (a) Dame
Rosalind Marsden; (b) Ms Madeline Crowther; (c) Dr Eric Reeves; (d) country background documents; and (e)
Home Office documents. In what follows, we assume that Appendix 1 has been read.

**VIII. THE SUBMISSIONS**

A. The Appellant

64. Mr Jacobs summarises the appellant's case in 11 points in his final written submissions at para [1] and which
are further amplified at paras [185]-[203].

65. Mr Jacobs' submission is that all Nuba (including the appellant) regardless of any political or other profile face a
real risk of persecution and/or serious ill-treatment on return to Sudan on the basis of their ethnicity and political
opinion because of their perceived association with rebel groups, in particular the SPLM-N:

(1) the Nuba are treated the same as non-Arab Darfuris who, following the CG decisions concerning Darfuris, are at
risk on return;

(2) the expert and background evidence establishes a real risk to all Nuba in the Nuba Mountains, in Greater
Khartoum and, on arrival, at the airport due to their ethnicity and perceived political association with rebel groups;

(3) the current situation in Sudan remains fragile despite the recent political developments and it is too soon to say
that Nuba can be safely returned; and

(4) the situation in Greater Khartoum is such that it would be unduly harsh for any Nuba not from there to relocate
there.

66. Mr Jacobs, in particular, places reliance on the evidence of three witnesses (Dame Rosalind Marsden, Ms
Madeline Crowther and Dr Eric Reeves) that the Nuba have been targeted for ill-treatment under the al-Bashir
regime as suspected supporters of rebel groups in particular the SPLM-N (see paras [185]-[186]).


-----

67. Moreover, the present situation, despite the developments in 2018-2019, remains fragile and, again relying in
particular upon Dame Rosalind's most recent evidence, it remains unsafe to return Nuba asylum-seekers to Sudan.
Mr Jacobs summarises what he says is the impact of the current developments in 11 points at para [1] of his written
submissions as follows:

(1) Notwithstanding the positive developments in Sudan since the fall of President Bashir in April 2019, the 'deep
state' remains in place.

(2) Consequently, a majority of officials in Sudan retain entrenched views as to non-Arab Sudanese from
marginalised areas

(3) Those views necessarily impute Nuba with a pollical opinion – namely that or support for SPLM-N, or other
rebel groups.

(4) Arabist policies were racially discriminatory against Nuba – using terms such as Abid (slave). Nuba were
targeted on grounds of race and imputed political opinion. Those Nuba returning from overseas are more likely to
be seen as politically active.

(5) Nuba failed asylum-seekers could still be at risk of ill-treatment in Khartoum today as long as members of the
former regime continue to control NISS and other security organs; the National Security Act has not been amended
to remove NISS's powers of arrest and detention; and the RSF still has a presence in urban areas. ….

(6) General Mohamed Hamdan Dagalo (widely known as Hemeti) has become the most powerful man in Sudan.
He is the leader of the Rapid Support Force (RSF), which comprises the former Janjawid and which has committed
atrocities and perpetrated human rights abuses in Darfur and the Nuba mountains, most recently in relation to a
mining dispute. Those forces retain an 'Arabist' mindset.

(7) The present administration is subject to the same threat that led to the downfall of the Bashir regime – namely
the economic crisis. In the event that the current government is unable to raise international finance to alleviate the
crisis, there is a significant possibility that the military under Hemeti and/or a pro Bashir Islamist faction may take
power, which would result in a restoration of active oppression of marginalized and rebel associated groups, such
as the Nuba.

(8) There is a close parallel between the former regime's perception of non-Arab Darfuris and Nuba because
members of both groups were suspected of being sympathetic to the rebel armed movements in Darfur, the Nuba
Mountains or Blue Nile. In particular, the armed movements from Darfur, the Nuba Mountains and Blue Nile are
closely inter-related and have formed joint alliances…..

(9) In the same way that the Secretary of State concedes that the position has not stabilised sufficiently for the
position relating to returns of Darfuris to change, neither can it logically be said that Nuba (who share a number of
characteristics with Darfuris) can safely be returned.

(10) There is evidence of recent targeting of Nuba in Khartoum. Dame Rosalind Marsden has recently interviewed
a group of professional Nuba men in Khartoum.

(11) The Nuba Mountains are described as a 'war zone' by Dr Catena (a credible source). As matters stand there is
no peace agreement and Nuba continue to face persecution at the hands of RSF in their home areas. It is
unreasonable to expect returning Nuba asylum seekers to settle or resettle in Khartoum/Omdurman in
circumstances where Hemeti's forces continue to persecute Nuba in their tribal areas.

68. In relation to the risk to Nuba in South Kordofan, Mr Jacobs, in addition to Dr Catena's characterisation of the
situation there, relies (at para [73]) upon the evidence of incidents in the Nuba Mountains in October 2019 referred
to in Dame Rosalind's evidence (October 2019):

(i) [On] 4 October, RSF forces recruited from the Hawazma and Salamat (Arab nomadic tribes), attacked the Nuba
village of Tongal in Habila locality, using 25 pick-up trucks with mounted machine guns (paragraph 28)


-----

(ii) On 5 October, Shamseddin Kabbashi, a military member of the Sovereign Council (who is himself a Nuba from
the Gulfan tribe) is reported to have met with Chiefs from both the Gulfan and Dar Naeele and given each of them
SDG 500,000 to unite against the SPLM/N. (paragraph 28)

(iii) On 16 October Abdel Aziz al Hilu's spokesman announced that RSF soldiers in 25 Landcruisers had ambushed
civilians inside SPLM/N-controlled territory near Khor Waral in Habila locality, abducting 13 people, and killing two,
including a local Sheikh who had objected to the local nomads passing through farmland (paragraph 29)

(iv) [O]n 7 October, the RSF mounted an attack on people living near the gold mines at Talodi, using 27 armed
pick-up trucks. They beat and arrested civilians, injuring ten people, and looted their property. Demonstrations by
local residents had been going on for months over the use of mercury and cyanide by gold-mining companies which
they said had caused serious health and environmental problems. Most of these companies are owned by the RSF
and the security apparatus (paragraph 30)

69. Mr Jacobs concludes his submissions (at paras [185]-[203]) with a number of points relating to the country
guidance and disposal of the appellant's appeal as follows:

185. ...The objective evidence … and the evidence from the three experts confirms that Nuba were targeted for ill
treatment under the Bashir regime as suspected members or supporters of rebel groups. They have been singled
out for ill treatment as a consequence of the former regime's Arabisation policies.

186. The expert witnesses have all given reliable evidence and the Tribunal is requested to accept their
conclusions, which have been derived from a wide range of sources. Dame Rosalind Marsden is a credible source
in her own right. Madeleine Crowther has assisted the Tribunal through Waging Peace in previous country
guidance; has provided source material to the Belgian COI and ARC. Dr Reeves is a well-regarded and longstanding country expert.

187. The evidence of Dame Rosalind Marsden is consistent with that of the International Crisis Group, upon which
the Secretary of State's position is based (save for the cursory assessment by the Embassy official, to which it is
submitted, little weight should attach). Both Dame Rosalind and the ICG assert that the current situation in
Khartoum is fragile for a number of reasons.

188. Firstly, the Government is unable to respond to the ongoing economic crisis, a situation which brought down
the Bashir Regime.

189. Secondly, the military are unlikely to relinquish power and have an effective veto in the current administration.

190. Thirdly, the Deep State remains intact outside Khartoum and within Khartoum only the upper layer of
bureaucracy (under secretary level) has been replaced. The pro Islamist and Arabist culture within all government
institutions remains as the mindset of the Bashir regime.

191. Fourthly, NISS retains its wide-ranging powers and immunity pending changes which have not been brought
into effect. NISS retains a desk at Khartoum airport. It is uncontentious that NISS have systematically ill treated
those to whom it has imputed a political opinion. Failed asylum seekers from marginalised rebel areas would
engage that perceived opinion.

192. Fifthly, Hemeti is the most powerful man in Sudan. He is the leader of the Rapid Support Forces, formerly the
Janjawid, which has persecuted Darfuris and Nuba in their home areas. RSF continue to be active in South
Kordofan and the Nuba Mountains and have recently carried out attacks in Nuba areas.

193. Sixthly, there is evidence that RSF targeted Nuba during the June 2019 massacre and in the aftermath of that
incident. Madeleine Crowther has spoken to the Director of HUDO concerning attacks in the Black Belt after 3 June
and Dame Rosalind Marden has interviewed Nuba in Khartoum recently, who have given accounts of recent
harassment on grounds of ethnicity. The Public Order legislation continues to apply in the Nuba areas of the capital
and surrounding areas, thus facilitating continuing harassment of Nuba.


-----

194. Seventhly, the position of Al Hilu and the disengagement of Al Noor are likely to prevent the conclusion of a
peace process, particularly in the Nuba Mountains and South Kordofan. It is likely that Hemeti and the RSF will
seek to bring the rebels to heel or would otherwise which use the impasse to take power back from the current
administration.

195. The above factors all impact on the risk of ill treatment amounting to persecution and Article 3 ill treatment that
Nuba would face in the event of return now as failed asylum seekers. The Refugee Convention is engaged by way
of imputed political opinion and ethnicity.

196. The Appellant has established that he would have been persecuted in the event of return under the Bashir
regime by way of ethnicity and imputed political opinion. Nuba are dark skinned, non-Arab and from rebel areas.
Furthermore, rebel groups associated with Nuba have in recent years posed an existential threat to the Government
of Sudan. These are all factors which Nuba have in common with Darfuris.

197. It is respectfully submitted that the situation in Sudan is still unstable, for the reasons set out by Dame
Rosalind Marsden, Madeleine Crowther and the recent ICG report. In the same way that Darfuris currently face
persecution in their home areas are not able to return to Khartoum, neither can Nuba reasonably be expected to
return. The characteristics of both groups are strikingly similar. It is submitted that the Upper Tribunal should follow
a consistent approach.

198. Notwithstanding the positive changes made in Khartoum, Nuba failed asylum seekers would be at risk of ill
treatment at the hands of NISS/GIS in the event of return. That risk would increase substantially should the current
government fall from power and the Islamist faction of Hemeti takes power. These scenarios are not unlikely for
reasons set out by Dame Rosalind Marsden and Madeleine Crowther.

199. The Tribunal is therefore invited to issue country guidance for Nuba in the same terms as in AAR & AA (NonArab Darfuris – return) Sudan [2019] UKUT 00282 (IAC).

200. It is submitted that the Appellant's appeal against refusal of asylum should be allowed and the decision of FTJ
Sweeney remade on the basis that the Appellant, as a member of the Nuba Tribes, will be at risk of persecution and
Article 3 ill treatment on the basis of his ethnicity and the imputed political opinion (suspected support of SPLM/N)
that would attach to a Nuba who is returned to Khartoum as a failed asylum seeker from the United Kingdom.

201. It is relevant for the purposes of Country Guidance to note that the Secretary of State appears to accept that
certain categories of Nuba cannot be safely returned. These categories are: those who are politically active;
students; and Christians. If, which is denied, the Appellant is not entitled to succeed in this appeal, the Tribunal is
nevertheless requested to confirm that the categories of Nuba as identified above cannot be safely returned to
Khartoum and should succeed in asylum claims.

202. Alternatively, it is established that Nuba are subjected to ethnically and politically motivated attacks in their
home areas and would be refugees in the event of return to those areas. In these circumstances, life in Khartoum
for such Nuba, in displacement areas such as the black belt would be unduly harsh for a returned failed asylum
seeker from the Nuba Mountains and South Kordofan.

203. The level of discrimination in Khartoum and Omdurman, if not persecutory in nature, would be unduly harsh
within the meaning of Januzi. The evidence establishes that there is no access to effective medical services,
education, employment …. Additionally, Nuba are routinely denied citizenship through being required to provide
birth certificates from their areas of origin. This denial impacts on access to essential services.

B. The Respondent

70. In his submissions, Mr Thomann, on behalf of the respondent, rejects any analogy with, and reliance upon, the
CG decisions relating to non-Arabs from Darfur. The respondent contends that there is no risk _per se to an_
individual of Nuba ethnicity on return. Instead, it is said that the risk flows from perceived political profile or activism
and not from the mere fact of being from a Nuba tribe.


-----

71. The respondent contends that there are no specific categories of individuals who cannot safely be returned –
each case must be assessed on a holistic basis and is fact-sensitive by analogy to the approach of the UT in IM
and AI. The issue is whether the individual's profile or political activity presents a sufficiently serious threat to the
Sudanese regime to warrant targeting.

72. Mr Thomann, nevertheless, accepts that a person who has a credible claim to a political profile or activism such
that they will have come to the attention of the Sudanese authorities (or is likely to have done so) is likely to have a
well-founded fear of persecution and/or ill-treatment on return.

73. The respondent contends that a returned asylum-seeker will not, simply on that basis, be at risk on return at the
airport or elsewhere.

74. Further, the respondent accepts that internal relocation to Greater Khartoum will not be reasonable if the
individual has a well-founded fear from the Sudanese state. However, the reasonableness of relocation to Greater
Khartoum for other individuals who cannot return to their home area by reason of a risk of serious harm will depend
upon an assessment of all the circumstances. Finally, the respondent accepts that relocation to the Nuba
Mountains is not a reasonable option.

75. Mr Thomann sets out the respondent's position in paras [4]-[14] of his final written submissions as follows
(footnotes omitted):

4. The population of Nuba in the wider Khartoum Area, the focus of this appeal, is not known precisely, but is likely
to number many hundreds of thousands.  It is not, moreover, possible to speak of a “single Nuba experience”
within that population. Rather, the position, both before and after the changes of 2019, remains that a person from
a tribe which originates from the Nuba Mountains is not, on that account alone, at risk on return to Khartoum and its
environs.

5. As this Tribunal found in _IM and AI (Risks - membership of Beja Tribe, Beja Congress and JEM)_ Sudan CG

_[[2016] UKUT 188 (IAC)…it has at all material times been necessary to build up a comprehensive picture of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K2V-F4K1-F0JY-C39H-00000-00&context=1519360)_
returnee, taking into account all relevant material, in order to establish risk on return. The Secretary of State
accepts that, as part of that composite assessment, a person's Nuba ethnicity is a factor, amongst others, to be
considered when determining whether the individual would be perceived as a sufficiently serious threat to the
regime to warrant targeting, and treatment that amounts to serious harm. Other factors, including the returnee's

a. profession,

b. any political activity,

c. evidence as to whether that activity has come to the adverse attention of the Sudanese authorities,

d. any past history of detention and the circumstances of such detention

will also be relevant to that in the round assessment.

6. The Appellant's suggestion that it is appropriate to depart from the country guidance by drawing an analogy with
the extant country guidance on Non-Arab Darfuris is mistaken for a number of reasons.  Whilst there are analogies,
set out below, there are also significant distinctions pertaining to the communities of Nuba and Non-Arab Darfuris in
the Khartoum Area. In summary the latter community is perceived not merely as larger, but more organised and
politically active. It posed a greater threat to forces seeking to counter reform in 2019. Forensically, there is another
important distinction. The position in this appeal is not that the Secretary of State is inviting this Tribunal to depart
from extant country guidance concerning the position of the Nuba, or Non-Arabs generally in the Khartoum area. It
is rather, one of endorsing the nuanced and, with respect, careful Country guidance promulgated by this Tribunal in
_IM and AI._

7. In so far as concerns the developments in the passage of time between the promulgation of IM and AI and this
Tribunal's determination the changes effected have improved the position in Khartoum and indeed between July


-----

(when the Darfuri case was considered) and now, the process of democratic transition has further progressed and
the position of the interim government has further stabilised.

8. The evidence did not support in 2018, and still less does it now support, the Appellant's core submission that a
Nuba would be at real risk of ill-treatment on return to Khartoum.  The Appellant's general statements to this effect
in his written submissions of 12 November 2019 are not supported by the country evidence.

9. The principal significance of the 2019 developments, and the two transitions of power associated with them, is
as follows. First, these developments shed light on the nature of the popular threat presented to the Sudanese
regime in 2019: a threat which takes political rather than military shape. Secondly, the Bashir regime's response to
the protests in early 2019, and that of the Transitional Military Council later in 2019, further shed light on the extent,
if any, that existential threats to the regime may translate into a heightened risk to the Nuba living in the Khartoum
Area. Thirdly, the change of government, and change of the political climate consequent upon it, bears upon the
assessment of immediate risk, if any, on return to Khartoum International Airport.

10. Beyond this, the Secretary of State does not suggest that the formation of the Interim Government, and the
opening up of democratic and civic space associated with it, represents a permanent democratic settlement. Nor
that the democratic transition is bound to succeed. The Tribunal is not invited to approach this Country Guidance
determination through Panglossian eyes. The institutional changes, and changes of political culture effected by the
Interim Government do, however, properly fall to be taken into account in deciding, according to the relevant legal
principles set out below, on the claims of the present Appellant to international protection, and on the giving of
current country guidance.

11. The Secretary of State has previously accepted that the fact that a person originates from the Nuba Mountains
is a material matter to be brought to bear in assessing how the authorities are likely to react on the strength of the
information known to them about him. She does not resile from that position. However, this factor alone does not
suffice to place a returnee at risk per se.

12. On a careful examination of the evidence, written and oral, it was necessary in 2018 to draw a distinction
between those perceived to have an influence or history of activism considered to be a threat to the regime, and
those that do not.  The evidence before this Tribunal in _IM and AI_ was that targeting by the, then Sudanese
National Intelligence and Security Service (NISS) is not random, but the result of suspicion based upon information
in the authorities' possession. None of the testimonies heard by the Tribunal at the hearing undermine the validity
of that assessment.

13. On the first issue identified for country guidance therefore, the Secretary of State's position is that neither an
Appellant's ethnicity, tribal background nor his activities sur place will, per se, give rise to a real risk of persecution
on return to Omdurman, nor at Khartoum International Airport.

14. The size and diversity of the Nuba population in Greater Khartoum (Omdurman is one of Three Towns that
comprise Greater Khartoum) and their environs renders it difficult to generalise whether relocation to Khartoum
would give rise to unduly harsh circumstances on return. It would be wrong to underestimate the challenge of
accessing housing, services and employment for an internally displaced person or a returnee with no contacts or
roots in Khartoum State. There is, however, no single Nuba experience, and each individual's circumstances would
need to be assessed carefully.

76. The respondent's position on the “general risk” to Nuba is further set out at paras [174]-181] of Mr Thomann's
submissions as follows (footnotes omitted):

174. General Risk: The human rights abuses committed by the Sudanese authorities and in particular the National
Intelligence Security Services (NISS) in recent years are well documented. That country evidence further
suggested that a wide range of persons may be at risk of detention and ill-treatment or serious harm. The last
category may include in particular those returning to conflict areas such as Darfur and South Kordofan (see the
Tribunal's guidance in IM and AI, ….


-----

175. The Secretary of State accepted as part of her 2018 submissions that a person who had a credible claim to a
political profile or activism such that they will have come to the adverse attention of the Sudanese authorities, or is
likely to have done so, was likely to qualify for asylum. The Appellant's Nuba background is, in that context, a factor
material to the assessment in the round. It is not suggested that the country position has changed so significantly
that this concession, which formed part of this Tribunal's Country Guidance in 2016, should be revisited.

176. By contrast, the extant Country Guidance, and the evidence considered as part of this appeal, does not show
that mere membership of a tribe from the Nuba Mountains gives rise to a real risk of persecution or serious harm on
return.  Nor will a failed asylum seeker from a tribe originating from the Nuba Mountains be at risk, by reason only
of this status, of undue hardship on relocation to Khartoum.

177. The threat posed to the regime in 2019 is more broadly based, political, and organised.  At its spearhead are
professionals, and civic activists. This contrasts with the existential military threats posed to the regime in the past,
in conjunction with the Darfuri and South Kordofan insurgencies.  Indeed, as [Rosalind Marsden] accepted, the
military strength of the ethnic communities on the periphery of Sudan was, by 2018, much reduced.

178. Consistently with those developments, the focus of recent evidence of mistreatment and targeting has been,
principally, upon professionals, activists and persons partaking in the 2019 demonstrations.

179. The Appellant's case as to a bright-line risk on ethnic lines is not reconcilable either with by the size of the
population of Nuba in and around Khartoum and the paucity of evidence that Nuba being targeted or mistreated
there.  Rather, a person's ethnic background remains one of the factors to take into account when conducting the
nuanced assessment of risk described by this Tribunal in its 2016 Country Guidance on returns to Sudan generally.

180. There is not, as the Appellant's submission pre-supposes, a single Nuba experience in Khartoum (see, inter
alia, the number of appointments of Nuba to the government and Supervisory Council).  That absence of evidence
is particularly telling in the context of the existential threats posed to successive Sudanese governments in the last
12 months.

181. A Nuba Failed Asylum Seeker likewise will not by reason of that status alone, face a real risk of persecution,
serious harm or treatment contrary to Article 3 of the European Convention on Human Rights on return to Sudan.
Such a claim is not, contrary to Dr Reeves' understanding, a political act which stands to be assessed by the
Sudanese security services as a threat to internal stability.

77. Then at paras [192]-[194], Mr Thomann concludes his submissions as follows:

192. There is no extant country guidance dealing specifically with Nuba.  Instead, the careful guidance of this
Tribunal promulgated in 2016 considered the submission that risk of mistreatment may be derived solely from nonArab ethnicity, and specifically rejected a suggestion that bright line risk distinctions could be made premised upon
ethnic lines.

193. For the avoidance of doubt, and in accordance with that guidance, the Secretary of State does not accept, as
suggested by the Appellant, that “certain categories of Nuba cannot be safely returned”, such as those who are
politically active, students or Christians.

194. Rather, those factors form a relevant, rather than decisive, part of the overall assessment of risk on return
advocated by the Tribunal in _IM and AI._ The evidence is not [that] either Christian Nuba, Nuba students, or
politically engaged Nuba are a group at risk per se. Rather, such aspects are factors which need to weighed up as
part of the decision-maker's overall assessment.  Further, and in addition, the process of strengthening of civic
and democratic forces, the adoption of the constitutional documents, the civic engagement of the professions, and
the concurrent weakening of the Islamist forces since the 2016 country guidance was promulgated has, if anything,
improved the position on return for Nuba who are Christian, educated, or active religiously.

78. Further the respondent contends that a real risk of ill-treatment does not arise simply from being a returned
failed asylum-seeker. The same “nuanced” approach in IM and AI is contended to be applicable. There is no risk


-----

simply being a failed asylum -seeker. In relation to the latter, Mr Thomann contends (at paras [185]-[189]) that
there is no real risk of mistreatment on return at the airport. The evidence, post the 2019 developments, does not
support any real risk of mistreatment at the airport:

185. Risk at the Airport: The Respondent accepts that there was evidence in 2018 that Sudanese authorities,
may be able to identify a person as a failed asylum seeker on return, depending on the circumstances of their
departure from and return to Sudan and question such a returnee closely. That risk materialises when an individual
travels on an emergency travel document, or a passport lacking a valid exit stamp, or is accompanied by escort
staff on return.  It is further likely that such a person would be questioned about activities since leaving Sudan.

186. Beyond this, there remains a lack of evidence that a failed asylum seeker, if detained on arrival in Khartoum,
would become of interest to NISS or experience treatment which would put him at real risk merely by reason of the
fact of claiming asylum.  The fact that there is no formal monitoring of returns to Khartoum International Airport by
human rights groups, and that removals from the UK and other countries take place in low numbers does not
explain such an absence.

187. The testimonies collected by Waging Peace likewise cannot be described as presenting a consistent pattern
of mistreatment such as to support the Appellant's case as to risk on return by mere reason of being a Nuba.

188. The Tribunal has been provided with a 22 October 2019 CPIT Response to Information Request showing
figures for Returns to Sudan compiled with the assistance of Eurostat's published numbers and European Asylum
Support Office responses…. Those figures do not purport to be complete. As will be apparent, the numbers of
voluntary and enforced returns is not large (para 4.2.3, and response to Query 6). It will further be noted that there
is no formal post-return monitoring. It is nonetheless striking that the evidence of a risk of serious mistreatment on
return, as opposed to questioning, by reference to ethnic profile only, is absent. The Appellant's suggestion that
such a risk may exist, in the absence of such evidence, is mistaken.

189. In so far as that position has changed since 2018, the evidence is that the security position at the airport has,
if anything, become less strict. There are no reports of recent mistreatment. RM's supposition that historical
opposition to the Bashir regime would not be viewed negatively in the current climate is astute, and her anecdotal
evidence as to the nature of the remaining security presence reflects this.

79. The respondent accepts internal relocation is not available to an individual who is at risk from the Sudanese
Government (para [183]). However, whilst in principle available to a returnee who cannot return to his home area
by reason of risk of serious harm, relocation to Greater Khartoum will not generally be unreasonable (para [184]):

184. For returnees more generally, not fearing state persecution but unable to return to their home area by reason
of a risk of serious harm, the feasibility of internal relocation has depended upon all the circumstances of the case.
In principle, Khartoum and Omdurman remain areas of viable relocation for those seeking to leave the conflict areas
in South Kordofan. That submission does not overlook the difficulties described by interlocutors for those arriving in
the poorer areas of Khartoum in accessing healthcare, education and employment. The description of societal
factors and discrimination is further noted. However, the sheer size and diversity of the population in Khartoum
from Darfur and the Two Areas renders the submission that relocation will be unreasonable in the generality of
cases unsustainable.  Instead, the question as to whether access to economic activity, basic services and shelter
will be available to a returnee or displaced person requires a fact-specific assessment of the circumstances of the
individual returnee. See, for example, the position of the present Appellant, considered further below.

**IX. THE COUNTRY GUIDANCE ARGUMENT**

80. We set out the existing guidance above because, although (apart from that one reference in IM and AI) it is not
concerned with those of Nuba ethnicity, Mr Jacobs places considerable reliance upon it, contending that Nuba are
treated in a like manner to non-Arab Darfuris as a marginalised group who are likely to be linked through their
ethnicity to political and military conflicts in their areas of origin. In his submission, the CG decisions on non-Arab
Darfuris should be followed and the appellant succeeds. He relies on the fact that before the UT in AAR and AA the


-----

respondent conceded that the situation in Sudan remained volatile and that there was insufficient evidence currently
to show that the guidance in AA and MM should be changed.

81. By contrast, Mr Thomann invites us not to follow or apply AA and MM where the respondent's concession was
merely that there was not “cogent evidence”, given the volatile situation, to justify revising the CG decisions and, in
the cases of the particular appellants before the UT, further delay was not appropriate and their appeals should be
dealt with on the basis of the existing CG cases.

82. Instead, he relies upon IM and AI and invites us to apply its approach (by analogy) in assessing, what if any, is
the risk of persecution to those of Nuba ethnicity returning to Sudan.

83. The argument is as follows: (i) Country Guidance establishes that group A is subject to risks X. (ii) In the
present case evidence shows that the position of group B is the same as that of group A. (iii) Therefore the Country
Guidance applies to group B. Proposition (ii) is a matter for the evidence in the present case; but the derivation of
proposition (iii) from propositions (i) and (ii) is an issue of law. We reject Mr Jacobs' submission that Country
Guidance applies by analogy in the circumstances he seeks to set up.

84. The relevance of the CG decision (in the context with which we are concerned) is that it has a precedential
effect in any case before the FtT or UT where the individual claims to be at risk as a non-Arab Darfuri. That is
made clear by the paragraph 12.2 of the Senior President's Practice Direction (Immigration and Asylum Chambers
_of the First-Tier Tribunal and the Upper Tribunal) (10 February 2010 as amended):_

“12.2. A reported determination of the Tribunal, the AIT or the IAT bearing the letters “CG” shall be treated as an
authoritative finding on the country guidance issue identified in the determination, based upon the evidence before
the members of the Tribunal, the AIT or the IAT that determine the appeal. As a result, unless it has been expressly
superseded or replaced by any later “CG” determination, or is inconsistent with other authority that is binding on the
Tribunal, such a country guidance case is authoritative in any subsequent appeal, so far as that appeal:(a) relates
to the country guidance issue in question; and (b) depends upon the same or similar evidence.”

85. The “authoritative” nature of a CG decision “in respect of a particular matter” as set out in para 12.2 of the
Practice Direction derives its force from s.107(3) of the Nationality, Immigration and Asylum Act 2002 (as
amended).

86. Paragraph 12.4 of the Practice Direction emphasises the importance CG decisions play in treating like cases
alike and that a failure to apply the decision (or properly explain why it is not applicable, in all likelihood because of
new cogent evidence) is likely to be an error of law:

“12.4. Because of the principle that like cases should be treated in like manner, any failure to follow a clear,
apparently applicable country guidance case or to show why it does not apply to the case in question is likely to be
regarded as grounds for appeal on a point of law.”

87. A Country Guidance decision's precedential effect extends, therefore, to any other appeal so far as it “relates to
the country guidance issue in question”. A tribunal hearing an appeal in respect of a non-Arab Dafuri must,
therefore, apply the CG decision in the absence of “very strong grounds supported by cogent evidence” (see SG
(Iraq) v SSHD [2012] EWCA Civ 940 at [47]). The parties in a case covered by Country Guidance are not required,
indeed are relieved of the obligation, to lead the relevant country background evidence: the CG decision will suffice.

88. However, a CG decision dealing with the risk to non-Arab Darfuris returning to Sudan has no precedential
effect in a case not concerned with a non-Arab Darfuri.  That is because it has no collateral precedential effect in
other cases. A CG decision cannot be used as _the evidential tool to overcome (or indeed replace) the need to_
establish by evidence the position of non-Arab Darfuris in this or, indeed, in any other case not involving a non-Arab
Darfuri.

89. If we were concerned in this case with a non-Arab Darfuri appellant, we would know, applying the CG cases,
the correct outcome of the appeal, subject to there not being cogent evidence to justify not applying them. That is


-----

not the same as us knowing what is the actual position of non-Arab Darfuris in the absence of evidence on that
issue. This appeal was not argued on the basis of evidence about non-Arab Darfuris but rather, on this point at
least, that they are at risk (applying the CG decisions) and the Nuba are in the same position (see the expert and
background evidence). We are not in any position to second-guess the UT's position (and the respondent's
concession) in August 2019 in the case of AAR and AA and we do not do so. Despite Mr Jacobs' assertion that the
position of Nuba is the same as that of non-Arab Darfuris, this is not a decision about non-Arab Darfuris and,
subject only to what is said at paragraph 252, nothing in this decision should be taken to comment in any way on
the existing Country Guidance in relation to non-Arab Darfuris.

90. So we reject Mr Jacobs' submission that we should base our decision on the guidance contained in AA and
MM. The risk, if any, to Nuba on return to Sudan must be determined on the relevant evidence before us relating to
the position of Nuba in Sudan.

91. Likewise, of course, IM and AI cannot be 'applied' as country guidance to Nuba as the case did not concern
them. The country guidance issue was different even though, in passing the UT made some reference to their
position at [203]. The UT's view on there being no real risk simply as a failed asylum-seeker might be considered
part of the country guidance but for the fact that it is not identified in the UT's decision as a point on which the
decision gives guidance. We are content to treat it, therefore, as not a country guidance finding and to reach our
own conclusion on the evidence before us.

92. In any event, it seems to us that Mr Thomann was not seeking to ask us to apply IM and AI as a CG decision
but rather contending for a “composite assessment” and “fact-sensitive” approach in determining whether an
individual of Nuba ethnicity would be at risk on return as someone who would be (or would be perceived to be) a
sufficiently serious threat to the Sudanese regime to warrant targeting and, therefore, at real risk of serious harm.
In other words, the general position is that an individual who claims to be at risk will need to establish the risk on the
facts of the individual case, without the benefit of any sweeping assertion derived from a Country Guidance case.
The need to consider any Nuba claim individually was the position which Mr Thomann sought to substantiate on the
basis of the evidence.

**X. DISCUSSION**

93. Having rejected the appellant's argument based on the non-Arab Darfuri CG cases, we turn to consider the
appellant's claim based upon the evidence relating to Nuba in Sudan. In reaching our findings, we consider the risk
to an individual of Nuba ethnicity:

(i) in the Nuba Mountains in South Kordofan;

(ii) in Greater Khartoum; and

(iii) at Khartoum International Airport on return; and

(iv) we conclude by considering whether internal relocation to Greater Khartoum is an option for a person of Nuba
ethnicity at risk in their home area elsewhere.

A. The Nuba Mountains and South Kordofan

94. We consider the position in the Nuba Mountains over two time periods: (a) between 2011 and 2016, covering
the period from the beginning of hostilities and ending with the ceasefire in 2016; and (b) since the 2016 ceasefire
to the present.

95. The conflict in the south of Sudan (2003-2005) which led to the cessation of South Sudan (2011) was followed
by an armed struggle by rebels (2011-2016) based in the Two Areas, i.e. South Kordofan and the Blue Nile, under
the umbrella of the SPLM-N. That armed struggle commenced in June 2011 in the Nuba Mountains and spread to
the Blue Nile in September 2011. The SPLM-N split into two factions in 2017: that in the Blue Nile led by Malik
Agar and in the Nuba Mountains by led by al Hilu. As Dame Rosalind told us in her oral evidence and March 2018
report the al Bashir regime was opposed to the Nuba tribes because many Nuba fought with the SPLM N on the


-----

side of the south Sudanese in the North/South civil war. Her evidence was that in the 1990s the regime declared a
Jihad against the Nuba. The armed conflict in the Nuba Mountains in 2010/2011 led to aerial bombing campaigns,
ground attack, forcible displacement and a humanitarian crisis. The situation is documented in the Asylum
Research Consultancy Report: “South Kordofan and the Blue Nile Country Report” (dated 1 June 2016) covering
the period up to 1 April 2016. We have no reason to doubt that evidence or that of the witnesses we heard about
the period up to the ceasefire in 2016.

96. Dr Reeves described events in the South Kordofan region including ethnic cleansing, the Sudanese
government's blockade of humanitarian assistance to those in the Nuba Mountains and, on the basis of a leaked
Minute of a meeting of senior military officials on 31 August 2014, the use of starvation as a method of war when it
was agreed that the sorghum crop in the Nuba Mountains should be destroyed. He characterised the government's
approach as amounting to genocide. As his evidence was given in June 2018, Dr Reeves' evidence did not take
into account the recent developments in the political situation in Sudan since April 2019.

97. In the Waging Peace Report of March 2018, Ms Crowther referred to attacks on civilians and the indiscriminate
bombing of civilian targets including schools and hospitals. She also referred to the blockade of humanitarian aid to
the region. She also said that the situation on the ground “has largely played itself out away from public attention”
as a result of the expulsion on NGOs in 2009 and the almost “non-existent” press coverage due to the
Government's deliberate obstruction of media freedom.

98. Both Dr Reeves and Ms Crowther spoke of contacts with Dr Tom Catena, who worked – and continues to work
– in the Nuba Mountains as describing the situation as a “war zone”. That said, there has in fact been a continuing
cease-fire by the Sudanese authorities and the rebels since 2016 and, in our view, the developments in 2019
including the peace-talks in Juba between the Government and the rebels, have only made the cessation of
hostilities more stable. Ms Crowther, in her evidence, said that there had been no aerial bombing activity in 2017
because “the government of Sudan has been on its best behaviour” whilst negotiating with, and obtaining a lifting of
sanctions by, the US government in 2017. The same report does, however, record harassment of women students
at University in South Kordofan in January 2018.

_2011-2016_

99. What, then, was the position in the Nuba Mountains up to the cease-fire in 2016? We accept that the situation
at that time created dire humanitarian conditions engineered and maintained by the Sudanese state. We can well
understand why individuals of Nuba ethnicity left the Nuba Mountains area prior to the 2016 cease-fire when faced
with the violence and humanitarian conditions that then pertained there. Based upon the evidence we have been
referred to, it is likely that Government action, including the use of violence and attacks by Government forces,
would have engaged Art 15(c) of the Qualification Directive. Equally, the conditions of deprivation for the Nuba
inhabitations of the region – the “humanitarian crisis” including the blockade of humanitarian assistance and the
deliberate Government tactic of starvation – up to the cease-fire in 2016 may well have, in an individual case,
reached the 'threshold' of “inhumane or degrading treatment” contrary to Art 3 of the ECHR.

_Since 2016_

100. What of the current situation? The appellant's case is that the ongoing violence in South Kordofan creates a
real risk of serious harm and targeting of all Nuba.  By contrast, the Secretary of State, whilst not accepting that
there was previously a real risk to all Nuba prior to the cessation of hostilities in 2016, contends that the current
circumstances since the cease-fire do not give rise to a real risk of serious harm or persecution to an individual
simply due to their Nuba ethnicity.

101. We acknowledge that despite the 2016 cease-fire, violent attacks by government forces, including the RSF
(headed by Hemeti) have taken place in South Kordofan. The “Human Rights Update: April – June 2019” notes
that:

“Although the number of attacks still have not reached the level prior to sharp dehumanisation that began in June
2016, there were more human rights violation incidents perpetrated by the Sudanese government in the Two Areas


-----

during the first six months of 2019, compared to the prior two years. Similarly, as a result, there were more people
injured and killed during the first six months 2019 than during the last six months of 2018.”

102. In that regard, what is said there may reflect the heightened tension during early 2019 as a result of the
protests taking place in Sudan, principally in Greater Khartoum, against the al-Bashir regime.

103. In his written submissions (at para [73]), Mr Jacobs places particular reliance upon four examples of recent
incidents or attacks by government or RSF forces which were referred to by Dame Rosalind in her Addendum
Report of 17 October 2019. The incidents took place in October 2019.

104. First, on 4 October, it is reported that RSF's forces attacked the Nuba village of Tongal using 25 pick-up
trucks mounted with machine guns. Secondly, on 5 October Shamseddin Kabbashi, a military member of the
Sovereign Council (who is himself a Nuba) and General Hemeti have been recruiting from both Arab and Nuba
tribes in government-controlled areas to join the RSF. Thirdly, on 16 October, al Hilu's spokesman announced that
RSF soldiers in 25 land cruisers had ambushed civilians inside SPLM-N controlled territory near Khor Warl
abducting 13 people and killing two others including a local Sheikh who had objected to the local nomads passing
through farm lands. Fourthly, on 7 October the RSF mounted an attack on people living near the goldmines at
Talodi using 27 armed pick-up trucks. They beat and arrested civilians, injuring 10 people, and looted their property.
Dame Rosalind told us that most of these companies are owned by the RSF, including Hemeti and others in the
regime.

105. Whilst we have no reason to doubt the evidence of these violent incidents in the Nuba Mountains, they do not,
in our judgment, demonstrate a real risk to all Nuba living there. In our view, the attacks were targeted in very
particular circumstances against certain individuals and/or organisations and are not representative of widespread
abuses or violence directed against Nuba generally. The incident around the goldmine in Talodi appears to arise as
a result of demonstrations by local residents which had been going on for a number of months over the use of
mercury and cyanide by goldmining companies which they claim have caused serious health and environmental
problems. Ms Crowther also gave the example of recent violence in South Kordofan as the attack on the goldmine
at Talodi. That incident has the feature of a targeted attack as a result of a grievance felt by the forces of the
government or supported by the government. The same can be said of the attack following the 'dispute' with the
nomads passing through farmland.

106. In her oral evidence, Ms Crowther referred to an e-mail dated 19 July 2019 from the South Kordofan/Blue Nile
Coordination Unit (Annex V of her statement dated 27 August 2019) and its reference to cattle raiding incidents by
militia in South Kordofan. In her oral evidence, she agreed these were individual incidents and that there was no
evidence of general round-ups in South Kordofan. Ms Crowther also referred to evidence from an activist (Annex
VII of the same statement) who said that the security and humanitarian situation in South Kordofan had not
changed and the militias were committing many atrocities. In her oral evidence, she agreed that he had not given
any specific examples but that was because he had not been asked but he had given her some in discussions. We
do not know what those examples were and, in reality, his evidence is general without giving any supporting
incidents.

107. Dr Reeves' evidence was, necessarily, restricted to the position prior to the recent developments when he
gave his evidence in May/June 2018. In our judgment, Dr Reeves' opinion that there was in 2018, prior to the 2019
political developments, a real risk to all Nuba in South Kordofan on return is also not borne out by the evidence.

108. Both Ms Crowther and Dr Reeves referred to communications from Dr Catena. Dr Catena, working as a
doctor, is based in the Nuba Mountains. He characterises the Nuba Mountain area as having been, and continuing
to be, a “war zone”. Whilst that may be an entirely fitting historical characterisation of the situation given the history
of conflict and violence in South Kordofan between 2011 and 2016, in our judgment, it is not a fitting description of
the present situation in South Kordofan supported by the evidence of the current circumstances.

109. Whilst attacks against Nuba individuals have taken place, the examples we were referred to are limited. We
were told that there was effectively a media blackout on what was happening in the Nuba Mountains. We can,
however only reach a decision on the evidence before us; not on evidence that could not be produced if that is the


-----

case. The clear position, in any event, is that we saw nothing to suggest that the sources of information from the
Nuba Mountains have simply ceased. On the contrary, we were presented with evidence through the witnesses
(including from Dr Catena) and from Ms Crowther following a visit in December 2018 to camps on the South Sudan
side of the border with Sudan and the South Kordofan region.

110. Mr Thomann conceded that an individual of Nuba ethnicity, if at risk elsewhere in Sudan, could not be
expected reasonably to relocate to the Nuba Mountains. We will consider internal relocation, inter alia to the Nuba
Mountains, later but, for the present, we should not be taken to be endorsing that concession. However, of course,
it is not a concession that there is a real risk of persecution or serious ill-treatment to all Nuba in the Nuba
Mountains. Rather, it is an acceptance by the respondent that a person of Nuba ethnicity, not from the Nuba
Mountains, cannot reasonably be expected to relocate there to live.

111. We accept that there has been some violence and there have been some attacks against Nuba individuals in
South Kordofan in the recent past. The situation in the Nuba Mountains, unlike that in Greater Khartoum, has been
one of real conflict and humanitarian crisis. Nevertheless, the evidence concerning the current position does not
support a finding that the level of conflict rises above that of a few, albeit highly deplorable, violent incidents. The
humanitarian blockade has now been lifted and the Sudanese government is permitting aid to pass into South
Kordofan both from within Sudan and from foreign sources. We will deal below more generally with the events in
Sudan in 2018/2019 and the positive political developments since mid-2019. A ceasefire by both sides has held
since 2016 and has, in our view, only become more secure since the political developments in 2019. A negotiated
peace-process continues between the Sudanese government and the rebel groups, including the SPLM-N. Even
though, briefly in the Autumn of 2019 al-Hilu withdrew, he has now returned to take part in the talks. The events in
2019 have, in our judgment, 'dampened down' the motivation to use military action in the Nuba Mountains and
turned the Government's focus towards a political settlement.

112. The evidence does not establish a widespread or consistent pattern of targeted or random violence or attacks
directed against Nuba by Government forces (or those acting on behalf of the Government) in the Nuba Mountains.
The incidents are limited in number and, as we have said above, arise in specific contexts. The evidence falls well
short of showing that in October 2019 or now there is a risk to Nuba in the Nuba mountains that is universal or
consistent or that arises solely from their ethnicity. Whatever was the position during the conflict between 2011 and
2016, the evidence of the current circumstances does not establish that there is a real risk of persecution or serious
ill-treatment contrary to Art 3 of the ECHR faced by all Nuba in South Kordofan.

113. We were not invited to consider the application of Art 15(c) of the Qualification Directive to the present
situation in the Nuba Mountains. In the light of that we would only say this: nothing in the evidence suggests that a
claim for humanitarian or subsidiary protection, based upon Art 15(c) and establishing a real risk of indiscriminate
violence, would have any prospect of succeeding now.

B. Greater Khartoum

114. The position of Nuba in Greater Khartoum was the subject of a great deal of evidence before us. The
witnesses' evidence had to traverse the emerging situation in Sudan, in particular in Greater Khartoum, following
the protests in late 2018, the fall of the al-Bashir government in April 2019 and the establishment of a new
government and constitution in the summer of 2019. The emerging political situation inevitably created evidential
uncertainties and ambiguity, not least arguments concerning the sustainability of what are accepted by the
appellant to be, positive, democratic developments in Sudan.

115. It was, we have no doubt, a challenge for the witnesses to maintain an up to date assessment of the situation
in Sudan. In that regard, of course, Dr Reeves' evidence did not deal with these developments as it pre-dated
them. Ms Crowther's most recent evidence was informed by her contacts within the relevant communities in the UK
and following a visit to refugee camps in South Sudan in December 2018. Dame Rosalind Marden's evidence was,
at least in part, more directly informed. In October 2019, she made a visit to Greater Khartoum where she met a
number of individuals, including a group of six young Nuba men in Greater Khartoum.

_Prior to the 2018/2019 political developments_


-----

116. The Nuba have historically been discriminated against in Sudan. There was a consistency of evidence before
us that this was the case (see, e.g. the evidence of Dame Rosalind, Madeline Crowther and Dr Reeves). Their
physical appearance, often not being Muslim and being non-Arab, has marked them out as different; particularly
since the policy of 'Arabisation 'and Islamisation of the state which was part of the al-Bashir government's policy.
We accept that the Nuba have often been the subject of discrimination, for example. in their social, economic and
religious lives both in the Nuba Mountains and Greater Khartoum and have been verbally abused being referred to
as “abid” or “zurgha” derogatory terms meaning “slave” and “dirty black” respectively. In Greater Khartoum, Nuba
live predominantly in the shanty towns of the 'Black Belt', where their circumstances are likely to include poverty
and deprivation.

117. Dame Rosalind told us, and we accept, that the al-Bashir regime (and its security apparatus in particular) has
treated Nuba (and those who came from the Nuba Mountains) with suspicion because they were regarded as
possible political opponents and associated with the rebel forces, in particular, the SPLM-N. We accept that this
suspicion might well have led to a risk of arbitrary arrest and detention by the NISS particularly so at times of
heightened political tension, for example during the active conflict in the Nuba Mountains between 2011 and 2016.
The advance by the SPLM-N out of South Kordofan towards Greater Khartoum in April 2013 was, as Dame
Rosalind told us, a major humiliation for the (then) Sudanese government and, she told us, resulted in round ups
and arrests of Nuba. In her last 2018 report she stated:

“As long as there is no comprehensive peace settlement addressed as the root causes of Sudan's internal conflicts,
the Nuba will continue to be regarded with suspicion by the authorities as likely political opponents and will remain
at risk of arbitrary arrest and detention by Sudan's powerful National Intelligence and Security Service (NISS).”

118. In her oral evidence in May/June 2018, Dame Rosalind said that not all Nuba would be suspected of
supporting the SPLM-N but those who had received a higher education were more likely to be targeted (that is to
say, for the most part, not those living in deprived circumstances in the 'Black Belt'). She said that the authorities
could not monitor all Nuba and that the NISS worked in Greater Khartoum, through a network of informers. Her
evidence was that large numbers of Nuba - in the hundreds of thousands or in her later evidence as many as 1.5
million – lived in Greater Khartoum, largely in the 'Black Belt'. Dame Rosalind spoke of the arrest of 200 activist
individuals in January/February 2018 but that all had been released. In that, she disagreed with the evidence of Ms
Crowther that a number of detainees had not been released. Overall, on this point, we prefer Dame Rosalind's
evidence given her exceptional experience of Sudan based upon her diplomatic experience and her recent meeting
with representatives in Nairobi and her recent visit to Sudan. In our judgment, Dame Rosalind's 2018 evidence –
given before the recent developments in Sudan – did not go as far as supporting a finding that there was a real risk
of persecution or serious ill-treatment to all Nuba in Greater Khartoum.

119. In her October 2019 oral evidence, Dame Rosalind said that there was no evidence of Nuba being targeted
prior to the April 2019 fall of the al-Bashir regime. She said that “could well have been taking place” but
emphasised that any targeting was “to do with politics and not ethnicity”.

120. Ms Crowther in her 2018 evidence, postulated a risk to Nuba in Greater Khartoum as a result of their
association with rebel groups. She also said that “at times of political upheaval” this risk is increased because of
the perception of association with all, or at least sympathy for, rebel and opposition activity. She noted the wide
scale protests in early 2018 which were marked by arrest and ill-treatment of hundreds of opposition figures. When
the regime is threatened, Ms Crowther expressed the view that the targeting of the Nuba intensified. That, she
said, involved attacks upon demonstrators and arrests at the beginning of 2018 when widespread protests against
the economic crisis began. Much of Ms Crowther's evidence related to the position of returnees to Sudan which we
will deal with below.

121. Ms Crowther also said that there was systematic discrimination against Nuba in Greater Khartoum as a result
of the government's Arabisation policies. She identified difficulties in access to employment, housing, healthcare
and education. She also, like Dame Rosalind, referred to the difficulties that an individual of Nuba ethnicity might
have in obtaining an ID card, which was crucial to access to a number of services.


-----

122. In our judgment, Ms Crowther's evidence does not establish a consistent picture of a risk of persecution or
serious ill-treatment to Nuba in Greater Khartoum prior to the recent political developments in Sudan. The
difficulties to which she referred are not persecution; and the incidents of ill-treatment are not tied solely to ethnicity.

123. Speaking to the situation in 2018, Dr Reeves' evidence was that all Nuba would face “unacceptably high risks”
if returned to Sudan including Greater Khartoum. We are here only concerned with risk whilst in Greater Khartoum
and not with any risk on return at the airport. Much of his evidence was directed to that latter issue. We accept his
evidence, consistent with the other witnesses and material to which we were referred, that the Nuba are, as an
ethnic group, discriminated against, and that a vast majority undoubtedly live in impoverished circumstances in the
shanty towns in the 'Black Belt' of Greater Khartoum. However, Dr Reeves' evidence of any risk to returning Nuba
was given at a time when, in his view, there was an intensification of government repression as a consequence of
the economic situation and protest beginning in 2018. In his evidence, Dr Reeves was asked to identify recent
examples of Nuba being subject to random targeting. The example given was in the 2015 report by Asylum
Research Consultancy, “Situation in Khartoum and Omdurman” (9 September 2015). That concerned an activist
who had been arrested at a meeting. It does not begin to support Dr Reeves' position that there was a real risk to
all Nuba in Greater Khartoum.

124. Looking at the position in 2018 prior to the 2019 political developments, in our judgment, the evidence of
Dame Rosalind and Ms Crowther does not support a conclusion that all Nuba were at risk simply because of their
ethnicity. The sheer number of Nuba said to live in Greater Khartoum, whether in the hundreds of thousands (or in
even greater numbers) but with only limited examples of ill-treatment, strongly suggests the contrary: that Nuba
were not at risk as such. Looking at the evidence as a whole, we consider that it goes no further than being
consistent with a conclusion that the risk to any individual was based on being perceived to have been a political
threat to the regime. Being Nuba would be a relevant factor as it could create a suspicion of support for rebel
groups such as the SPLM-N (particularly at times of heightened political tension), but would not, in itself, result in
risk of being perceived as a threat and consequent risk of arrest, detention or ill-treatment that could amount to
persecution or serious ill-treatment; a risk of that sort might, however, flow from political activity in Sudan or abroad
which was known to the authorities.

125. In the F-FR 2016 the risk to Darfuri students was highlighted:

“Asked about the profile of groups of persons monitored and targeted by the authorities in Khartoum, the two
lawyers explained that Darfuri activists were the most targeted group compared to activists from the Two Areas,
particularly Darfuri Student activists who took part in demonstrations. According to the sources, Darfuris were more
organised than people from the Two Areas, and this made Darfuris the most targeted group and caused them to be
treated most harshly by the authorities when arrested.”

126. The targeted group was activists, in particular student activists in Darfur but the report also recognised that
student activists from the “Two Areas” may also have been monitored and targeted though, to a lesser extent. The
relevance of being involved in what was, or was perceived to be, “political activity” was also emphasised in the
Landinfo Report, “Sudan, Scope Political activity critical of the regime” (11 November 2013).

127. Likewise, the examples relied upon by Mr Jacobs from the Asylum Research Consultancy report in 2015 do
not support there having been a general targeting of Nuba. One example concerned Nuba attacked and detained
by police following a retaliatory beating by Nuba of a police officer accused of raping a woman of Nuba ethnicity.
Another entailed the arrest and ill-treatment of Nuba by the NISS at the time of the April 2015 elections. The final
passage specifically focused upon ill-treatment focussed on those perceived as political opponents.

128. In the F-FR 2016, at para 3.3 the absence of targeting exclusively due to ethnic background was noted as
follows:

“Four sources observe that all communities from Darfur or the Two Areas in Khartoum could be at risk of
mistreatment by the NISS or indicated that persons from these communities may be targeted by the authorities due
to the ethnicity alone. However, none of the sources provided specific information indicating that persons from


-----

Darfur or the Two Areas were being subject to mistreatment by the authorities exclusively due to their ethnic
background.”

129. The interest, however, that the Sudanese authorities had in students, journalists and activists including
political and human rights activists was noted by two human rights lawyers in the F-FR 2016 at page 67:

“The source added that in addition to Darfuri student activists who were the most targeted group, journalists,
lawyers and other individuals or groups were in opposition to the government were monitored by NISS. It was
added although the political department in the NISS, which was responsible for monitoring the opposition, was a
small department, it was divided into small specialist sections which each was responsible for a certain opposition
group, for example one section for political parties, another section for students, the third section for rebel groups
etc.”

130. Mr Jacobs, in his written submissions, referred to two passages quoting sources in the F-FR Report 2018 at
para 3.4.5 and 3.4.7. The report mainly concerned the position of Darfuris and the risk to returned failed asylum
seekers. One source stated that he thought “Darfuris would be targeted if they took part in demonstrations” (para
3.4.5). Whilst one civil society activist stated that the Nuba people and Darfuris are often associated with rebel
groups, a human rights defender considered that “not all Darfuris are suspected of supporting rebels; just those that
are suspected of opposing the government” (para 3.4.7). The many sources link any round-ups and large scale
arrests of Darfuris in Greater Khartoum (and not all sources were aware of wide-scale round-ups or arrests of
Darfuris) to the war in Darfur (see section 3.3) and now that that conflict intensity has reduced, one source at the
British Embassy said that “there is no need to lock up Darfuris” (para 3.3.2). To the extent relevant to Nuba, in our
judgment, the focus of the accounts of ill-treatment, arrest and detention is on those who are politically active, for
example, those involved in demonstrations and students (see citations at [A224]-[A230]).

131. We note the Australian Government Report (Department of Foreign Affairs and Trade), Country Information
Report: Sudan (27 April 2016) at paras 3.10 – 3.12. At 3.12 states:

“Overall, DFAT assesses that Nuba currently face a high risk of discrimination and violence. Given the actual or
perceived association of Nuba with the armed opposition, Nuba are likely to face a high risk of discrimination and
violence outside the Nuba Mountains, including in Khartoum.”

132. That was said, however, in a report covering a period prior to April 2016 when the cease-fire first took effect in
the Nuba Mountains. It was, therefore, reflecting on a time of considerably heightened political tension given the
on-going conflict with the SPLM-N in South Kordofan. As we have noted, the evidence suggests that there was an
increased risk to individuals such as the Nuba at such times.

133. Overall, therefore, we have concluded that the mantra that there was a risk to all Nuba, because being Nuba
was perceived prior to the 2019 political developments as making an individual a potential political opponent, is not
borne out by the evidence. In our judgment, prior to those recent developments, the evidence does not establish
that a real risk of persecution or serious ill-treatment arose from being Nuba and living in Greater Khartoum. There
was, however, evidence of specific targeting of individuals (with Nuba ethnicity) who had been politically active, for
example a journalist and someone who had spoken on Sudanese political issues at the UK Parliament. There are
examples in the evidence of individuals of Nuba ethnicity being subject to harassment and even detention (e.g.,
those involved in football) but the level of such incidents prior to 2019, was not widespread or sufficient in number to
lead us to conclude that all Nuba were at real risk of being subjected to harm amounting to persecution or serious
ill-treatment.

134. In her oral evidence in May/June 2018, Ms Crowther identified a number of risk factors that would, in her view,
have given rise to specific concerns for Nuba on return: students, those participating in demonstrations, those
engaged in political activities, those educated above primary level, those who have travelled abroad, and those
returning with documents which identified them as failed asylum-seekers.

135. Dame Rosalind in her response to the F-FT 2018 stated that being a Nuba failed asylum seeker created a
significant risk of ill-treatment because of presumed association with the SPLM-N. That view was, in many


-----

respects, backed away from in her oral evidence, in that she accepted that not all Nuba were at risk in Greater
Khartoum and she did not know of any recent examples of targeting of Nuba.  In addition, she referred to a number
of risk factors, albeit again in the context of returnees: actual oppositional activity in Sudan or abroad; membership
of professional classes; profile of being a human rights defender or activist; a blogger/social media activist; young
male of military age; a student. However, she goes on to state that it is difficult to predict who the NISS will target
as the way they operate is “arbitrary”.

136. The evidence, in our view, read as a whole, focused any potential risk upon political activists, journalists,
human rights activists and students who may, as a result, have been perceived by the government to be a threat.
(We will return to whether a failed asylum seeker (whether or not of Nuba ethnicity) would have been at risk on
return to Sudan at the airport.) Given the history of conflicts in Sudan, we also accept that being Nuba and/or being
from the Nuba Mountains was a factor to take into account in assessing whether the individual would fall into the
category which we have identified as potentially being at risk of persecution or serious ill-treatment. Ethnic origins
and geographical origins had the potential to raise suspicions of rebel sympathies for the al-Bashir regime. They
were not, however, in themselves sufficient to put an individual at risk.

137. As we have already commented, the appellant's contention that _all Nuba were (and still are) at risk of_
persecution or serious ill-treatment in Greater Khartoum as perceived supporters of the SPLM-N is difficult to
sustain given the size of the Nuba population in Greater Khartoum (whether in the hundreds of thousands or even
greater) and the incidence of the tensions, arrests and ill-treatment to which the witness and background evidence
spoke. Of course, a conclusion that any particular individual would have been at “real risk” of persecution and/or
serious ill-treatment does not mean that _every Nuba in Greater Khartoum was, in fact, subject to persecution or_
serious ill-treatment. Nevertheless, the disparity or, as Mr Thomann put in his submissions, the disconnect between
the size of the Nuba population in Greater Khartoum and the incidence of targeted mistreatment documented in the
evidence speaks powerfully against the appellant's submission that all Nuba were at real risk.

138. We accept the evidence, for example of Dame Rosalind and in the F-FR 2018 (sections 5.1 and 5.2), that the
Sudanese authorities monitored political activism through informers both in Greater Khartoum and also abroad such
as in the UK. Potentially, therefore, political activism in-country and abroad could have come to the attention of the
NISS. But, as Dame Rosalind told us, the NISS could not, in practice, monitor all the Nuba population in Greater
Khartoum given its size. Knowledge, therefore, of any particular individual's activities, which might have put an
individual at risk, cannot necessarily be inferred simply by the evidence that NISS did monitor groups, such as the
Nuba, in Greater Khartoum.

139.  In our view, a number of factors would be relevant in order to determine whether, prior to the developments in
2019, an individual would be both known to the authorities, and also be perceived as a threat to the regime. Those
factors include the individual's ethnicity, their place of origin (where it is a conflict zone), any actual political activity
in Sudan or abroad, their profession (including whether they are a journalist or human rights activist), any previous
detention or past interest by the Sudanese authorities in the individual and also whether they were a student. As
regards the latter, we heard evidence concerning the student activity both of Darfuris and Nuba. Whilst the
evidence was that the Darfuri students were better organised and, it can perhaps be said, more politically active, we
accept that being a student was a relevant factor when assessing risk regardless of whether the individual was a
Darfuri or Nuba.

140. One other potential risk factor which arose in the evidence was an individual's religion, in particular that some
Nuba were Christians. It was not suggested to us that as such a person would have been at real risk of
persecution. Mr Jacobs did not make much of this factor in his initial written submissions. However, in response to
Mr Thomann's submissions, he relied upon the evidence that, he said, showed that “Christians from the Nuba
Mountains are uniquely targeted” (US Commission on International Religious Freedom, “Annual Report 2019,
Sudan” set out in “CPIT 1” at para 11.2.2 and at [A283]). He relied on evidence that Christian Churches had been
demolished and Christian schools were forced to operate on Sundays. He also relied on Dame Rosalind's
evidence, following her October 2019 visit to Greater Khartoum, that she had been told by one Nuba man of
continuing harassment of Christians, including the Supreme Court's decision in October 2019 to confirm criminal


-----

charges against the executive committee of a Christian church which was predominantly Nuban. He submitted that
Christians suffered systematic discrimination and that “Nuba Christians form a risk category”.

141. We do not accept that the evidence supports such a view. We accept that there are examples of Christians in
Greater Khartoum experiencing harassment and limitations on their ability to follow their faith. The evidence does
not demonstrate, however, this is widespread or, in itself, reached a sufficiently high and sustained level to have
amounted to persecution or serious ill-treatment of Christians. However, religion, in particular if an individual were
Christian, was a risk factor. It was a factor that might potentially have contributed to the overall assessment of risk
to an individual given the Islamic nature of the Sudanese State under al-Bashir. This may, of course, have been
inter-linked with an individual's Nuba ethnicity given that some Nuba are Christian.

_After the 2018/2019 political developments_

142. That being the position prior to the 2018/2019 developments, what, if any, impact have those developments
had upon any assessment of risk to Nuba in Greater Khartoum?

143. The political developments in Sudan between December 2018 and the final hearings in this appeal were
charted in the written and oral evidence of Dame Rosalind and Ms Crowther and a number of up-to-date
documents, in particular the developments are set out in detail in the “CPIT 1” document. We earlier summarised
the main developments (paras 10-13).

144. The essential features of the developments are not in dispute. Mr Jacobs, in his submissions, described what
had occurred in Sudan since the fall of al-Bashir in April 2019 as “positive” developments. Principally, these
consisted of the establishment of the TMC in April 2019 following the overthrow of al-Bashir.

145. Even more significant are the developments that followed in the summer of 2019. Following agreement
reached on 5 July 2019 between the TMC and the FFC, the SC was established consisting of eleven civilian and
military members, which, for the first 21 months, is chaired by a military member (para 6) who is al Burhan. The SC
has a majority (six) of civilian members – five nominated by the FFC and one selected by agreement between the
FCC and TMC (para 5). It will be chaired by a civilian member for the remaining 18 months (para 7). The transition
to civilian control is planned for 2021. During the transitional period, a stated aim is to dismantle the al-Bashir
regime and establish “the state of law and institutions”. The agreement provides for a Legislative Council (paras
14-18) and an independent Investigation Committee to investigate the 3 June 2019 incidents and “related incidents
of human rights violations committed against civilians and militaries” (para 19).

146. A new Constitution, which was appended to Dame Rosalind's report of 27 August 2019, was agreed on 21
August 2019 and provides for democratic institutions and a civil society. The present structure is to remain in effect
for 39 months (the transitional period) when elections will be held.

147. The Constitution enshrines a number of institutions including the SC (Ch 4), the Cabinet and its constitution
(Ch 5), the judiciary including an independent Constitutional Court (Ch 8), and an independent public prosecutor
(Ch 9). The Constitution also enshrines a number of “uniformed agencies” (Ch 11): the armed forces, the police,
the GIS and military courts. The role of the GIS is limited to “gathering and analysing information” and providing it
to the competent authorities (para 36).

148. The Constitution also provides, in some detail, for the “state agencies” seeking to achieve “a just and
comprehensive peace” ending regional conflicts in Sudan (Ch 15).

149. The Constitution contains a “Rights and freedoms Charter” (Ch 14) setting out a number of rights, including
the right to “life and dignity”, to “citizenship and nationality”, to “protection from torture”, to “personal freedom and
security”, for “women”, for “children”, to a “fair trial”, to “freedom of belief and worship” to ”freedom of assembly
and organisation” and to “political participation”.


-----

150. A further “positive” development has been the appointment on 21 August 2019 of a civilian Prime Minister,
Abdalla Hamdok a respected international economist and his cabinet which includes a number of civilian members
and individuals from the Blue Nile and the Nuba Mountains regions.

151. Further, there has been the appointment of a respected female judge to be the Chief Justice together with the
appointment of an independent Attorney General.

152. Since the autumn of 2019 on-going peace talks have been held in Juba, the capital of South Sudan between
the Sudanese Government and rebel movements including both factions of the SPLM-N, albeit at one point al Hilu
temporarily withdrew.

153. We set out earlier a number of events which post-date the hearing in October 2019 (see paras 14-16). Those
events do nothing to deflect from the direction of travel in the political developments and changes in Sudan that
were in place at the date of the October hearing.

154. Mr Jacobs' detailed submissions advance two principal lines of argument; first, the evidence shows that Nuba
are still at risk in Greater Khartoum and continue to be subject to violence etc at the hands of the Sudanese
Government, in particular the GIS; secondly, any changes that have occurred are “fragile” and could collapse with a
return to a military regime more akin to that of al-Bashir. In relation to the period covered by the political
developments, Mr Jacobs relied upon the violent suppression of protestors following the overthrow of al-Bashir in
particular, on 3 June 2019. He also relied upon the continuing enforcement of the Public Order law on the outskirts
of Greater Khartoum directed towards women; the harassment of Christians as evidenced by the Supreme Court's
confirmation of an order of 7 October 2019 of criminal charges against an executive committee of the Sudanese
Church of Christ, accused of refusing to hand over church property; and the targeting of women “tea sellers” in
Greater Khartoum during the protests. Both Dame Rosalind and Ms Crowther gave evidence about these matters.

155. Dame Rosalind, in her reports of 27 August 2019 and 17 October 2019 together with her oral evidence dealt
with the current position in Greater Khartoum.

156. Dame Rosalind was critical of the “CPIT 1” report which appended correspondence from the British Embassy
in which it is said Sudanese contacts expressed

“surprise at the suggestion that Nuba people are subject to systematic discrimination or mistreatment in Khartoum,
with the exception that they might find it more difficult to obtain employment.”

157. She told us that it was not clear whether any Nuba individuals had been consulted (see para 98 above). The
document stated that the view is made “[a]necdotally” and we do not place much weight or reliance upon it.

158. Dame Rosalind told us that Nuba women were continuing to be targeted by the enforcement of the Public
Order law in Greater Khartoum and Christians were harassed as evidenced by the Supreme Court's recent
confirmation of criminal charges against a committee of the Sudanese Church of Christ. She told us of the example
of female tea sellers (who are largely from ethnic groups such as Nuba) being targeted and harassed under the
Public Order law. She also described a meeting with a group of six young Nuba and said they had told her that two
weeks before the meeting two of them had been sitting drinking tea on a pavement at a tea seller's store when they
were taken to a police station but were later released without charge.

159. In our judgment, the evidence relayed by Dame Rosalind from the group of six young Nuba that she met,
does not support a claim that there is a continuing risk to all Nuba in Greater Khartoum. Dame Rosalind's visit was
during the time when hearings in this appeal were taking place and her motive in seeking to meet a group of Nuba
was in order to see for herself the difficulties she had already described to us. The group she met appear to have
been sought out as individuals who perceived themselves as having been targeted. There was only one example
given of personal mistreatment and, at its highest, it concerned arrest and detention for a short period and release,
unharmed, without charge by one or two of the individuals. It comes nowhere near to being supportive of a
conclusion that all Nuba are at risk of serious ill-treatment in Greater Khartoum.


-----

160. Further, the incidents reported to Dame Rosalind of harassment (including arrest and summary conviction and
punishment) of women tea sellers on the outskirts of Greater Khartoum do not support a conclusion that there is a
widespread and real risk of serious ill-treatment to all individuals of Nuba ethnicity even though female tea sellers
largely come from ethnic groups such as the Nuba.

161. Other instances of mistreatment, and even the killing, of tea sellers was given in the evidence. The evidence
was that a number of tea sellers were killed during the 3 June suppression of protestors by the military. The
evidence concerning the suppression of protestors does not support, in our judgment, the targeting of an ethnic
group such as the Nuba by the (then) military Government. Rather, it represents the (then) Government's interest
in those protesting at the time either seeking the removal of al-Bashir or, in the wake of his removal, further reform
away from the TMC. In our view, the female tea sellers (many of whom were providing refreshment to the
protesters) were perceived as associated with those demonstrations and protests. Their mistreatment (or worse)
clearly arises from that perception at the time leading up to, and at the time of, the June protests rather than their
ethnic background, Nuba or otherwise.

162. The recent decision of the Sudanese Supreme Court does not, in our view, support a conclusion that
Christians per se (Nuba or otherwise) are at risk. It must be seen in the context of all the evidence including the
continuing political development in Sudan from 2019, including the adoption of a Constitution which protects
freedom of religion. Most recently, the crime of apostacy has been abolished.

163. In her evidence, Ms Crowther acknowledged that the circumstances in Sudan had dramatically changed since
the May/June 2018 hearing. She referred to the rise of Hemeti, as the leader of the RSF and the involvement of
Hemeti and others in the suppression of the protesters on 3 June 2019. She spoke of attacks in the Black Belt after
3 June 2019 and the incident of a Nuba footballer being targeted. She also referred to the government's failure to
release 25 individuals of Nuba and Darfuri ethnicity who had previously been detained. As we have already noted,
Dame Rosalind's evidence was that all detainees had been released. Even if these latter incidents are accepted,
they do not demonstrate the widespread targeting of the vast number of Nuba.

164. Though Ms Crowther and Dame Rosalind referred to the continued enforcement of the Public Order law
against women, particularly in the 'Black Belt' area of Greater Khartoum, the new government had suspended that
law in central Khartoum but it continued to remain in force in the 'Black Belt' area. (Subsequently, the Public Order
law was repealed.)

165. In our judgment, the evidence of the circumstances in Greater Khartoum since the political developments of
2019 do not establish a real risk to Nuba because of their ethnicity. Whilst we accept that the TMC responded
severely to the protests following the removal of al-Bashir and which culminated in the violent suppression of the
demonstrators and others perceived to be involved in the protests on 3 June, this action was targeted against the
protestors and not Nuba because of their ethnicity. The political developments have clearly made a difference
since the 3 June protests. As we heard, the October 21 protests were not met by a violent response from the new
Government and its forces. Indeed, the attitude of the Government seems to have discouraged the involvement of
Islamist protestors who might have clashed with other protestors. In any event, the demonstrations passed without
the violent intervention that was seen on 3 June. The other evidence of incidents involving action (harassment or
worse) against Nuba do not, as we have already said, establish a level of incident that lead us to conclude Nuba
because of their ethnicity are at risk in Greater Khartoum.

166. Mr Jacobs relied upon the evidence of Dame Rosalind and Ms Crowther as to the “fragile” nature of the
democratic changes that have occurred in 2009 and the continued threat that the military (in particular Hemeti) may
represent if, for example, the economic fortunes of Sudan do not improve. Reliance was also placed upon the
continued threat of the “deep state”, namely the remaining political and governmental posts held by those who
occupied those posts during the al-Bashir regime. The threat, it is said, is that the Islamists, together with the
military, will regain power and any democratic gains in 2019 will be lost.

167. Dame Rosalind was of the view that it was too early to determine whether the progress made towards
democracy and civilian rule was reversible. However, she said that the military threat posed by the rebel groups in
D f d S th K d f h d “d li d i ifi tl ” d th it th t d t th i b th SPLM N


-----

had weakened. She said that the better organisation and widespread nature of the protests in 2019, together with
the availability of social media to document its atrocities, and the interests of external parties in stability, rendered
strong-armed tactics less likely to succeed in 2019. She stated that there had been a falling out between Hemeti
and the Islamist faction. She said that there was no immediate Islamic threat of force and considered that its efforts
might be targeted to preparing politically for an election in three years' time. She accepted that the profile of those
mistreated and arrested in early 2009 appeared to be little focused upon ethnic background. She said that there
had been a degree of opening up of democratic space, a strengthening of the civic forces by the appointment of
independently minded persons, and a commitment by the Prime Minster and his cabinet to “a radical set of reform
measures in dismantling the deep state” as set out in the constitutional declaration. However, she said that the
economic challenges and uncertainty and the risk of the loss of credibility on the part of the civilian government in
the absence of tangible progress rendered the outcome of the transition to democratic and civilian government,
uncertain. Dame Rosalind said that the threat of an Islamic counter-revolutionary coup was real. Nevertheless, she
recognised that there had been a failed coup attempt in July. She said that the Islamic shadow militias still existed.
She said that in a recent demonstration on 21 October, the Islamists had not taken part.

168. As regards the peace process, Dame Rosalind pointed out that there was no peace agreement on the table,
although a preliminary document had been signed. She pointed out that al Hilu's demand for the right to selfdetermination and a secular Sudan was a potential impediment to the peace process. Any change would be very
difficult and would have to be debated in a broader constitutional forum. Dame Rosalind placed great store in the
importance of a comprehensive peace agreement being reached.

169. Ms Crowther's evidence of the impact of the 2019 developments, and changes in the Sudanese Government
and State, was largely to the same effect.

170. The political landscape in Sudan has changed since April 2019 – and particularly since August/September
2019 with the new Constitution, the joint military/civilian SC and new civilian-led Government. There have,
undoubtedly, been positive democratic changes in Sudan in 2019. We were told that the changes are “fragile”. Mr
Thomann accepted that the changes may not be permanent. Whilst we acknowledge that there are risks to the
regime as identified by both Dame Rosalind and Ms Crowther, nevertheless, the progress is all one way and with
the passage of time and the continuing democratisation, the risk that there may be a reversionary regime change in
Sudan, becomes more speculative.

171. A shift to a constitutional democracy is now part of Sudanese law and, without any impediment to which our
attention was drawn, it continues to be the situation in Sudan. Further, recent changes such as abolishing the
Public Order law and the apostacy law point to the reduction of Islamicist influence. The weight of the evidence
was indicative of a real intention by the new Government to see through the reforms and resolve the economic
problems facing Sudan.

172. The threat of a military or Islamic (“deep state”) overthrow of the new order has not eventuated and, indeed,
the military have, if anything, aligned themselves with pro-democracy protestors, for example in their approach to
the demonstrations on 21 October. There is no evidence that the 'deep state' has worked effectively to undermine
the on-going democratic changes. If that has been tried, it appears not to have succeeded. The military have acted
to support the new political order by defeating the GIS revolt in July 2019, and the Islamists failed to take part in the
21 October demonstration, it would seem because the Sudanese government and military made it clear they would
not be allowed to approach government buildings. Hemeti, we were told, has fallen out with the Islamists and there
has been no effective resurgence of the apparatus of the former regime to defeat the new developments. On the
contrary, the principal actors, both military and civilian, are acting in consort to effect the democratic changes in the
new Constitution.

173. At the date of the final written submissions in early December 2019, no evidence was drawn to our attention
by either party that was said to deflect from the 'direction of travel' in Sudan, namely the establishment of a
democratic state post al-Bashir. In addition, despite the inherent complexities and potential impediments to
achieving peace in Sudan, the evidence was that the Sudanese government and the rebel groups (apart from Al
Nour group from Darfur) were actively engaged in peace talks in Juba, even if there had been a temporary


-----

withdrawal by al Hilu. Whilst Ms Crowther spoke of the need for caution given the number of failed earlier attempts
to achieve a peace settlement, those earlier attempts were, of course, during the al-Bashir regime. The political
climate in Sudan has changed.

174. At the time of those submissions, the Sudanese government had already indicated its intention to repeal the
Public Order law. An attempted rebellion by members of the former NISS who objected to the reform of the security
services, was quelled by the military and condemned by Hemeti. We have no doubt that the traditional Sudanese
mindset against non-Arabs, and the resulting casual and sometimes serious discrimination will not have completely
disappeared and may never do so. However, the evidence indicates to us strongly that the manifestation of
ongoing disputes between the new Sudanese government and rebel groups has moved from a military response to
a political one. Dame Rosalind accepted that in her evidence. The search for a comprehensive peace agreement
is enshrined in the new Constitution and the peace process continues in talks in Juba including al Hilu.

175. The direction of travel remains firmly pointing in the way of democratic change and the powers of law and
order and a move to stability and resolving difficulties politically rather than through force or violence.

176. Likewise, the government's response to al-Bashir following his fall is entirely consistent with the rule of law.
He has been sentenced to two years detention (not imprisonment, because of his age) and the Sudanese
Government has indicated its willingness to hand al-Bashir over to the ICC in The Hague to face the charges of
genocide and war crimes which are outstanding against him.

177. The longer the situation remains stable the weaker the arguments based on 'fragility' become: the speculation
inherent in the submissions made to us becomes more distant from the reality. In our judgment, the continuing
stability of the democratic changes does not justify any inference that in the immediate and foreseeable future the
current regime will fall and there will be a return to an Islamic based/military government.

178. What does that mean for an assessment of the risk to Nuba in Greater Khartoum?

179. Mr Thomann accepted that there remains a risk of persecution or serious ill-treatment for those who are
perceived as a sufficiently serious threat to the Sudanese regime to prompt targeting, which may lead to
mistreatment that amounts to serious harm. We agree that the situation has not evolved such that we can be
confident that the risk to those who are, or are perceived to be, a threat to the Sudanese Government, which we
have accepted existed before the political developments in 2019, has now completely evaporated with the fall of the
al-Bashir regime and the installation since August 2019 of a democratic State with a new Constitution and
Government. In time, however, that may well be the proper inference to be drawn from the changes. What is clear,
however, is that the assessment of whether a person is, or is perceived to be, a threat to the Sudanese
Government has to be determined by reference to the change of Government and all that that entails.

180. As Dame Rosalind pointed out in her 27 August 2019 report:

“Civilians in the new transitional government would not regard membership of the UK diaspora or an anti-Bashir
political profile as a negative factor. Indeed, those who supported the revolution and opposed the previous regime
would be welcomed. However, it is not yet clear to what extent the civilians will be able to exercise authority over
GIS and other parts of the military-security apparatus given that security sector reform is to be left in the hands of
the military institutions and the Ministers of Defence and Interior in the Cabinet will be chosen by the TMC.”

181. We acknowledge that the GIS remains active, although its previous head, Salah Ghosh has disappeared and
is no longer its head. The new Constitution limits its role to “gathering and analyzing information” (para 36). But, as
Dame Rosalind stated in her evidence, the existing law (the National Security Act) remains in force until repealed
and that it confers powers of arrest and detention, and grants immunity to GIS officers. The military remain a
central and powerful part of the new Government. Hemeti remains a central part of the new Government with
control of the RFS; but his siding with the democratic protestors against the Islamists in 21 October 2019, offers no
support for the view that he will seek to undermine the political developments in Sudan. As Dame Rosalind told us,
the new Government has moved from a military to a political solution to resolving Sudan's internal problems. Taken


-----

as a whole, the evidence does not lead us to conclude that the Sudanese Government is not at present in control of
its forces, including the RSF and GIS.

182. The central question remains (as it was before 2019) whether the individual's circumstances as known to (or
suspected by) the Sudanese authorities create a perception that the individual is a sufficiently serious threat to the
Sudanese government to warrant targeting and ill-treatment. A fact-sensitive assessment is required taking into
account all the circumstances.

183. We draw on the instances of “risk” categories identified in the evidence of Dame Rosalind and Ms Crowther
as relevant risk _factors in assessing the Sudanese authorities' perception of an individual. These include the_
individual's ethnicity, their place of origin (where it is a conflict zone), any actual political activity in Sudan or abroad,
their profession (including whether they are a journalist or human rights activist), any previous detention or past
interest by the Sudanese authorities in the individual, their religion and also whether they are a student. In making
the distinction between 'categories' and 'factors' we apply our general conclusion that the risk of persecution, if it
exists, will be found in a holistic examination of a claimant's history, profile and identity, not in the simplistic
assignment of a claimant to a category.

184. The 2019 “positive political developments” in Sudan have, in our judgment, substantially lowered the interest
of the Sudanese government in supressing political opposition by violent or military action. The present
Government, after all, owes its existence in part to the political opposition that manifested itself in the streets in
2018/2019. In particular, it will be relevant in assessing whether an individual will be at risk on this basis to take into
account that any “oppositional” political activity against the al-Bashir regime may have a dwindling relevance to the
current Sudanese government, including the army and the GIS.

185. Further, the evidence relating to the Government's response to Nuba in Greater Khartoum since the
democratic changes in the summer of 2019 does not support a conclusion that Sudanese authorities (including the
GIS) consider a person of Nuba ethnicity (without more) as a sufficiently serious threat to the political regime or as a
perceived political opponent as a supporter of the SPLM-N.

C. At Khartoum International Airport

186. Mr Jacobs submitted that the appellant as a failed asylum seeker of Nuba ethnicity would be at risk of
persecution or serious ill-treatment at Khartoum International Airport at the hands of the NISS (or as it is now
rebranded, the GIS). He relied upon the witnesses' evidence and the background evidence to support his
submissions. He submitted that all Nuba, as failed asylum seekers, would be at risk of persecution or serious illtreatment at the hands of the GIS on return.

187. Mr Jacobs relied upon the evidence of Dr Reeves and the individuals whom he had consulted and referred to
his report and oral evidence. Dr Reeves' view was that because of the history of racism towards the Nuba and
(speaking in 2018) the intensification of government repression and the consequence of the budget issues, there
was a risk of ill-treatment amounting to persecution for any returning failed asylum seeker of Nuba ethnicity. Dr
Reeves' view was that returnees were asked for details of their ethnicity at Khartoum airport. He referred to the
killing of a returnee in November 2015 and that, for the NISS, there was no distinction to be made between nonArabs from Darfur and those from the Nuba Mountains. Because there were, he said, fewer Nuba, they were
exposed to a greater risk as a member of a politically active diaspora returning to Sudan. His view was that failed
asylum seekers of Nuba ethnicity, who were returned on ETDs, were likely to be singled out for detention and the
probability of torture was high. He rejected the proposition, put to him in cross-examination, that a 'low level' Nuba
would not be subject to interrogation and ill-treatment on return. They were perceived as opponents of the
government.

188. Mr Thomann submitted that there were difficulties with Dr Reeves' evidence.

189. First, Dr Reeves' report did not mention a number of recent documents referring to the position of returnees to
Sudan, including the F-FR 2016, the investigation of the Office of the Belgian Commissioner for Refugees in
relation to the “Belgian COI Report” and the claimed mistreatment of returnees; and this was despite the fact that Dr


-----

Reeves asserted that he had excluded nothing in preparing his report. He stated in cross-examination that,
although he was aware of some of this material, he had chosen not to refer to them because of their poor quality or
partiality.

190. Secondly, Mr Thomann submitted that Dr Reeves had failed to incorporate into his report what had been said
by one of his expert consultees (Ted Dagne) who had stated that it was necessary in assessing risk to distinguish
between returnees who were activists/leaders and others. In other words, Mr Thomann submitted, that consultee
had not taken the view that Nuba ethnicity in itself gave rise to a risk of harm on return without more.

191. Thirdly, Mr Thomann submitted that, on enquiry, Dr Reeves had been unable to estimate how many Nuba had
been returned to Sudan.

192. Finally, Mr Thomann submitted that Dr Reeves' evidence involved sweeping generalisations including the size
of the Nuba diaspora and there was a “disconnect” between the nature of the risk posited by Dr Reeves and the
portion of the specific examples of mistreatment in the evidence. The specific example he was able to give, based
upon the Asylum Research Consultancy Report for 2015 involved the targeted mistreatment directed at a single
individual who was perceived to have a profile of interest to the NISS. It did not support Dr Reeves' generalisation
that all Nuba returned as failed asylum seekers were at risk.

193. We agree with Mr Thomann's criticisms of Dr Reeves' evidence.  As we have said, Dr Reeves' evidence was
limited to the period before the changes in 2019. Nevertheless, even as regards that period, we have considerable
doubt whether Dr Reeves' assertion of risk to all Nuba on return can be accommodated by the evidence (as a
whole) concerning specific examples of ill-treatment to Nuba on return at the airport (or indeed in Greater
Khartoum). He did not refer to recent evidence such as the F-FR 2016 and failed to incorporate the more nuanced
view of one source that the risk was focused on the politically active. In stating his view of risk to all Nuba
returnees, he was unaware of the number of Nuba returnees to Sudan.  The empirical evidence does not, in our
judgment, provide a sufficient underpinning for the scale and nature of the risk to all Nuba posited by Dr Reeves
prior to 2019, whether within Greater Khartoum or on arrival at Khartoum International Airport. There are instances
of harassment, detention and ill-treatment but they are not, in our view, sufficiently widespread to justify an
inference that all Nuba are at risk. We discuss the documentary evidence about returnees to the airport below. For
the present, we say this: like Ms Crowther, Dr Reeves based his view upon examples of returnees from Belgium
and Italy referred to in the “Belgium COI Report”. In forming his view, however, Dr Reeves fails to have regard to
the report of the Belgian Commissioner for Refugees where it is said that there are very real problems with the
examples, including that many accounts were flawed by the acceptance of the individuals' credibility.

194. Mr Jacobs also relied upon the evidence of Madeleine Crowther and her 2018 report prepared for Waging
Peace. That report, in turn, referred to the “Belgian COI Report” collating evidence derived from the Tahrir Institute,
in the summer of 2017.

195. Ms Crowther concluded, in her 2018 report, that it was likely that individuals (including Nuba) will be detained
and interrogated upon return. There was a two-stage process of detention at the airport. The first stage involved
detention at an immigration office and the second stage at an NISS office, although Ms Crowther stated that the
separation between these stages was not to be looked at as “strict”.  She stated that detainees are released only
on the condition that they do not leave the country and that they gather information on opposition groups in
preparation for a period of further questioning.

196. Ms Crowther told us that she was in regular contact with Nuba groups and she estimated that there were
around 2,000 Nuba in the UK. She told us that Waging Peace had “1,000 active cases” on its books and estimated
that in 90% of the cases the individuals had “experienced torture”. She referred to an interview carried out by
Waging Peace of a detainee who had witnessed a Nuba individual being questioned for hours on arrival in
Khartoum about his political activities and support for the rebels. Her evidence was that claiming asylum abroad
was seen by the NISS as a political act – reflecting a similar view of Dr Reeves. The NISS were not subject to
judicial oversight and enjoyed complete impunity under Sudanese law. Her evidence was that individuals are
routinely questioned about their political activities and connection in the country from which they had travelled. The
i k ti ft l f th i t l i diti l ith f il t d th t f


-----

detention at any time. She noted that the government do not monitor the position of returnees after they have
returned. Waging Peace did not meet individuals at the airport as this would add to the risk by showing
engagement with local human rights defenders or groups.

197. In her evidence, Ms Crowther told us that she had seen the testimonies of those returnees referred to in the
“Belgian COI Report” which had been compiled by the Tahrir Institute. She said that the testimonies confirmed the
accounts of detention and interrogation on arrival and incidences of beatings. She did not accept the criticism of
the Belgian Commissioner that the testimonies of the individuals were not credible.

198. Ms Crowther identified the categories of Nuba who would be at specific risk including, students, those
participating in demonstrations, those engaged in political activities, those educated above primary level, those who
had travelled abroad, and those returning with documents which identify them as failed asylum seekers.

199. Mr Thomann submitted that Ms Crowther's evidence did not support the contention that all Nuba were at risk
on return as failed asylum seekers. First, he submitted that she had not provided any verification of “1,000 cases”
and whether they supported her contention that all Nuba failed asylum seekers were at risk on return. He pointed
out that the majority of the testimonies were anonymous.

200. Secondly, as regards her reliance upon the “Belgian COI Report”, the Belgian Commissioner had called into
question the conclusions on the basis that the accounts given by some of the individuals were not credible. Her
explanation that inconsistencies in their evidence arose from the use of the Arabic language or “fraught period”
experienced by the individuals, was not an adequate explanation not least because Ms Crowther accepted that she
did not speak Sudanese Arabic.

201. Thirdly, Mr Thomann submitted that the two specific examples given by Ms Crowther in her 2018 report were,
on analysis, not supportive of the contention that the mere fact of being a Nuba on return created a real risk of
serious ill-treatment. The first, concerning Ms B, Mr Thomann submitted, was an account of a returnee in March
2014 who had worked as a journalist in Khartoum and who had conducted research in the Nuba Mountains. The
second, Mr C, was an account of a person from the Nuba Mountains but whose studies in the UK had been funded
by a company part-owned by the Sudanese government. However, Mr Thomann pointed out that he had spoken at
a meeting in the UK parliament headed “The Ticking Time-bomb: Preventing a Return to War in Sudan” about the
future of the Two Areas along with the head of the Nuba Mountains Solidarity Abroad organisation. These
examples, Mr Thomann submitted, were targeted against those who were perceived as politically active or
journalists.

202. We accept Mr Thomann's submissions and criticisms of Ms Crowther's evidence. Ms Crowther's view that all
Nuba failed asylum seekers are at risk on return to Khartoum airport is not supported by the evidence upon which
she relies. The “1,000” known cases which she relied upon are unparticularised and provide no verifiable evidence
of ill-treatment to failed asylum-seekers on return. Nor is her position supported by the “COI Belgian Report” and
the specific examples of Ms B and Mr C which she gave. In relying on the former, Ms Crowther failed to take into
account the Belgium Commissioner's view that the accounts of many of the individuals returned from Belgium
lacked credibility. Ms Crowther's contention that the returnees were, in some way misunderstood, because they
spoke Arabic and where hampered by it being a “fraught period” was unsubstantiated in the face of the Belgium
Commissioner's thorough investigation of their cases. The latter instances of Ms B and Mr C, in our judgment, does
provide some support for specific targeting of those who had been politically active including journalists. They do
not support a generalised risk to all returning Nuba failed asylum seekers.

203. In her most recent evidence, Ms Crowther maintained that the position was the same in 2019 despite the
political changes. Ms Crowther's evidence, both in writing and orally, subsequent to the hearings in May/June 2018
focussed more on the political developments in Sudan. We have already indicated, despite his reference to it in his
written submissions, Mr Jacobs disavowed any reliance upon Ms Crowther's response to the Home Office's F-FR
2018. The thrust of her evidence was that the Nuba would continue to be associated with the SPLM-N and
therefore suspected of opposition activism and the political developments did not remove the risk of ill-treatment to
returned Nuba failed asylum seekers. Again, Ms Crowther's assertion of a continued risk to all Nuba failed asylum


-----

seekers is not supported, in our judgment, by the political developments and move to democracy which we have
already identified or the empirical evidence concerning the treatment of Nuba on return.

204. Mr Jacobs also relied upon the evidence from Dame Rosalind. She also gave evidence concerning the
position of returned Nuba failed asylum seekers. In her oral evidence in May 2018, she said that such individuals
would be under “suspicion” on return. She had heard from several sources that they were interviewed and then
monitored over a longer period. She posited that the risk did not necessarily arise immediately as the authorities
could monitor the Nuba, through the network of NISS informers, once living in Sudan.

205. In her 4 January 2019 report, Dame Rosalind again said that a failed asylum seeker of Nuba ethnicity was
likely to be viewed with “increased suspicion” by the Sudanese government on the basis of presumed support for
the SPLM-N in the Nuba Mountains. Dame Rosalind was critical of the F-FR 2018's methodology in assessing the
contrasting views of different sources – some stating that returnees did not face any problems, whilst others
referred to difficulties and ill-treatment for those who were activists or, in some instances, simply because they
claimed asylum abroad. The F-FR 2018 drew only on 20 sources and there was no attempt to resolve contradictory
opinions (paras 26-27). She maintained failed asylum-seekers of Nuba ethnicity were at risk.

206. We accept that the F-FR 2018 sources do not provide consistent accounts of who, prior to the 2019
developments, would be of interest and at risk on return.  The weight of that evidence (set out in summary at

[A240]-[A251]) is, however, not supportive of the appellant's case that all returning failed asylum-seekers of Nuba
ethnicity would have been at risk.

207. In her oral evidence Dame Rosalind was more circumspect about the current situation. She was unable to
give any recent examples of ill-treatment of returning Nuba at Khartoum airport. She said it was a difficult question
to answer whether a person who had claimed asylum overseas and was of Nuba ethnicity would be at risk. This
was because there was no actual evidence relating to treatment of returning failed asylum seekers under the new
regime. However, she repeated that there was still an NISS/GIS desk at the airport but she said that checks
appeared to be more cursory than before. She suspected that there were different procedures on entry for known
failed asylum seekers. She stated that there was a concern that the NISS/GIS mindset was to suspect failed
asylum seekers of Nuba ethnicity of involvement with the SPLM-N and that that had not changed and so there
remained a risk that Nuba failed asylum seekers would be subject to ill-treatment.

208. We consider Dame Rosalind's evidence concerning the present situation to be important. She said that any
investigation in Khartoum airport is likely to be more “cursory” since the fall of the al-Bashir regime. We also note
that she was unable to give any examples of mistreatment of returning failed asylum seekers under the new regime.
We remind ourselves of Dame Rosalind's observation during her evidence that the social media had a part to play
in exposing actions by the Sudanese authorities. We were referred to none that could support specific recent
instances of ill-treatment to arrivals at Khartoum airport.

209. At various points in the case, including the evidence of Ms Crowther, it appeared that the argument being
posited was that the absence of evidence did not show that Nuba were not at risk. We do not accept that
argument. The absence of evidence, in the circumstances we are considering, is not probative evidence that a risk
does exist. The appellant bears the burden of proof and without evidence we cannot infer that what is said happens
(or happened) does, in fact, happen. The absence of external monitoring of the position of returned asylum seekers
cannot probatively assist the appellant where there is otherwise no evidence of those individuals' position in Sudan.

210. Mr Jacobs also placed reliance upon a number of the country background documents.

211. First, he relied upon the F-FR 2016 and, in particular, in relation to the position of failed asylum seekers on
return to Khartoum International airport. At page 15 of the report the following is reported:

“NHRMO considered that those from Darfur or the Two Areas, who had been outside Sudan for a considerable
period, would be questioned extensively about their political activities and risked detention if they were suspected of
activities against the government.”


-----

212. At page 16, the same source referred to a detention of a Nuba person at the airport as follows:

“NHRMO referring to their own human rights monitoring work, considered that it would not be safe for NHRMO staff
to visit Khartoum and referred to a specific case of detention at the airport involving a Nuba person who was
detained for alleged political activity.”

213. Then, finally at page 17 those sources are quoted as reporting the following:

“Western embassy (C) noted that upon arrival at KIA, Darfuris and persons from the Two Areas may be treated
impolitely and probably asked to pay a bribe, but they would not face any difficulties if they already were not
'flagged' by the NISS. NHRMO observed that those from the Two Areas travelling through Khartoum International
Airport (KIA) would be subject to more intensive questioning about their background and political involvement, with
ethnic Nuba most likely to experience harassment.”

214. In our judgment, this evidence, dating from August 2016 and therefore prior to the overthrow of the al-Bashir
government, goes no further than recognising that ethnic Nuba were likely to experience harassment but the
difficulties, in particular detention by the NISS, related to suspicion of actual political activities against the
government and not simply because they are of Nuba ethnicity. It does not support a conclusion that all Nuba are
perceived as potential supporters of rebel groups, such as the SPLM-N or that being a returned asylum-seeker and
having claimed asylum abroad is, in itself, seen as apolitical act which will result in ill-treatment at the airport.  It
also does not support a generalised risk of ill-treatment to _all ethnic Nuba returning as failed asylum seekers or_
being detained and ill-treated as a consequence.

215. Secondly, Mr Jacobs placed reliance upon the “COI Belgian Report” of February 2018. We discussed that
report earlier and also considered Ms Crowther's assessment of it.  We find persuasive the conclusion of the
Belgian Commissioner that these instances of claimed mistreatment by returned asylum seekers are unreliable. He
concluded:

“The CGRS has not been able to obtain absolute certainty or clarity about whether the facts stated in the report of
the Tahrir Institute actually took place. But regarding the three main testimonies from this report, it was found some
important elements were not true, to such an extent that this raises serious doubts about the rest of the testimony.”

216. We are perhaps not concerned with 'absolute certainty or clarity', but we have no reason to disagree with the
general conclusion that the accounts in question are not entitled to be treated as reliable. The “Belgian COI Report”
does not add to the appellant's case.

217. Thirdly, Mr Jacobs placed reliance upon paragraph 4.2 of the Asylum Research Consultancy document dated
13 September 2018 which adopts the F-FR 2016 on the treatment of persons travelling through Khartoum airport
that:

“Persons from the Two Areas will be treated differently because of being perceived to be affiliated with the SPLM-N
and they would be subject to more intensive questioning about their background and political involvement. Ethnic
Nuba persons will be most likely to experience harassment and will be easily identifiable from their name.”

218. This, however, goes no further than recognising that failed asylum seekers, in particular those who are ethnic
Nubas, would have been subject to “more intensive questioning” and would be most likely to experience
harassment. It provides no support for the appellant's contention that all Nuban failed asylum seekers are at real
risk of detention and serious ill-treatment or persecution by the NISS/GIS at Khartoum airport.

219. In relation to any risk, at the airport, Mr Thomann referred us to “CPIT 2” dated 22 October 2019. It includes
figures, inter alia, for enforced returns between 2014 and 2018 prepared from information provided by EASO. A
table in para 2.1.1 shows UK returns to Sudan. The number of forced returns to Sudan were 48 (2014), 34 (2015),
11 (2016), 39 (2017) and 14 (2018). Mr Jacobs accepted that these figures do not assist in showing whether any
Nuba have been returned to Khartoum during this period. The figures at para 4.3.1 show a total for the period of
2014 to June 2019 of 15 enforced returns. The disparity was not satisfactorily explained to us but may relate to


-----

different classification systems being used with the former figures reflecting the year an individual applied for
asylum rather than the year they were returned.

220. At para 4.2.3 there is a table showing figures for forced returns to Sudan between 2014 and 2018 by four EU
states who consented to disclosure of information: Belgium (13), Switzerland (27), Sweden (7) and Slovenia (1).
But, as Mr Jacobs pointed out, Switzerland is the only country which was able to confirm that it returns Nuba to
Sudan (para 4.2.5). Although the information provided did not indicate whether any enforced returns were in fact
Nuba. Mr Jacobs also pointed out that one country, Cyprus, confirmed that it did not return anyone to Sudan who
originated from Darfur or South Kordofan (para 4.2.4). In the result, we have not found “CPIT 2” provided any
significant information to assist us in assessing the risk, if any, to a failed asylum seeker of Nuba ethnicity returned
to Sudan.

221. Mr Thomann contended that the evidence did not establish that a failed asylum seeker of Nuba ethnicity was
for that reason alone at real risk of persecution or serious ill-treatment on return. However, he accepted that the
evidence, as of 2018, was that Sudanese authorities may be able to identify a person as a failed asylum seeker on
return, depending on the circumstances of their departure from and return to Sudan and by questioning such a
returnee closely. He accepted that the risk of identification and close questioning arose when an individual travels
on an emergency travel document, or a passport lacking a valid exit stamp, or if accompanied by escort staff on
return. He accepted that it was likely, as of 2018, that such a person would be questioned about activities since
leaving Sudan. However, he contended that beyond that there was a lack of evidence that a failed asylum seeker,
if detained on return in Khartoum, would become of interest to the NISS or be subject to serious mistreatment which
would put them at real risk merely by reason of the fact of claiming asylum.

222. As to the present position, Mr Thomann submitted that the evidence was that the security position at the
airport had, if anything, become less strict. There were no reports of recent mistreatment and he relied upon Dame
Rosalind's view that opposition to the al-Bashir regime would not now be viewed negatively in the current climate
and her evidence that any investigation in Khartoum airport was now likely to be more “cursory”.

223. We accept the evidence that there has been a two-stage process at the airport – first involving an immigration
desk and then, secondly a NISS/GIS desk.  That arrangement continues today.

224. As regards the situation prior to 2019, we accept the evidence that a failed asylum-seeker of Nuba ethnicity, if
and when identified as a person of Nuba ethnicity or as coming from the Nuba Mountains, was likely to experience
a heightened risk of inquiry about their political activities in Sudan or abroad. That process would have involved the
NISS. The individual's background might well have been readily apparent from his or her appearance and return on
emergency travel documents or a passport lacking an exit stamp was likely to prompt the NISS to question an
individual about their activities. We accept that a person of Nuba ethnicity might face a higher risk of investigation.
However, the evidence does not establish that there would have been any continuing interest in a person, including
a person of Nuba ethnicity, unless they were perceived to be a sufficiently serious threat to the al-Bashir
Government.  The risk was no more, and no less, than the risk we have identified in relation to individuals in
Greater Khartoum. There was no risk per se to a failed asylum seeker. That what was found by this Tribunal in IM
and AI at [225]:

“It is our firm conclusion that a failed asylum seeker, including an individual that has been subject to investigation by
the immigration authorities on return, would not be at risk of further investigation by NISS on that basis alone.”

225. What of the current risk, since the 2019 political developments? Given the establishment of the new
Government and political changes, opposition to the al-Bashir regime would, most likely, no longer be considered to
be oppositional to the current government. The government has changed, and, as we have set out above, there is
a developing move to a democratically based regime. Significant changes have been made along that route
following the overthrow of the al-Bashir regime and its replacement, since August 2019 by the SC and a civilian
government, headed by a well-respected international economist as Prime Minster. There is no evidence that the
GIS (as the NISS' successor) has ill-treated any returned failed asylum seeker since the political developments in
2019. It would be pure speculation to conclude that the 'old ways' (relied upon by the appellant and in any event in
i l ki id ti l t) i th t ti i th b f id


-----

226. In our judgment, the evidence does not establish that there was a real risk to a failed asylum seeker on the
ground that he was of Nuban ethnicity on return at Khartoum airport prior to the 2019 political developments.
Further, the evidence does not establish any such risk since the 2019 political developments.

227. Despite recent changes, we accept that a person of Nuba ethnicity might face a higher risk of investigation but
we are also of the firm conclusion that a failed asylum seeker (whether of Nuba ethnicity or not) is not at risk as
such at Khartoum airport. The examination is, as Dame Rosalind told us, more “cursory” today than it was
previously. The risk, if any, arises in the very same circumstances as it would arise in Greater Khartoum, namely,
applying an holistic and fact-sensitive approach a person would be perceived as a sufficiently serious threat to the
_current regime to warrant targeting and treatment that amounts to serious harm. What we have said earlier_
concerning the risk to individuals in Greater Khartoum following the 2019 political developments applies with equal
force when assessing any risk at the airport as a failed asylum-seeker.

228. The evidence we have discussed deals with returned failed asylum-seekers. There was no evidence that
other Nuba travelling in and out of Khartoum airport were subject to any particular display of interest by the
Sudanese authorities, in particular the NISS/GIS at the airport.  In our view, the absence of any evidence of that
reinforces the conclusions we have reached on the evidence that Nuba as such are not at risk on return.

229. Whether or not that is right, the position on the evidence we did hear is that there is no higher risk of
persecution or serious ill-treatment to those of Nuba ethnicity at Khartoum airport beyond that which we have
already identified in Greater Khartoum.

D. Internal Relocation

230. The parties' written submissions on the issue of internal relocation to Greater Khartoum were brief. It could
have no application to the appellant as he is from Omdurman in Greater Khartoum and the Secretary of State did
not suggest that the appellant could be expected to relocate to the Nuba Mountains (see para [89] of Mr Thomann's
submissions).

231. Not surprisingly, Mr Thomann accepted that if an individual can establish a real risk of persecution by the
Sudanese state in their home area, then internal relocation is not available (see para [182] of Mr Thomann's
submissions). That is accepted by the Home Office in its CPIN: “Sudan, Rejected Asylum Seekers” (August 2017)
at para 2.5.1). Consequently, if an ethnic Nuba from one of the Two Areas was able to establish a real risk of state
persecution in his or her area, the issue of internal relocation to Greater Khartoum does not arise. It is, in general,
the case that a person who has a well-founded fear of persecution by the national state authorities will not be able
to avoid harm by internal relocation.

232. The scope for an internal relocation argument is, therefore, limited, given that we are concerned with the risk
of ill-treatment to the individual by the State in their home area. It could, perhaps, more easily be seen to arise in a
humanitarian protection claim where the risk in the home area falls within Art 15(c) of the Qualification Directive.
That latter risk in, for example, the Nuba Mountains was not, however, an issue pursued or raised before us. We,
nevertheless, address the issue of internal relocation to Greater Khartoum for those cases where it might arise,
albeit not in relation to this appellant.

233. If a real risk of serious harm does otherwise arise in the home area of a person of Nuba ethnicity, the
appellant contends that a level of discrimination (for example in the availability of services, education and
employment) living in the 'Black Belt' in Greater Khartoum would be unduly harsh and unreasonable. The
respondent contends that - assuming the risk is not from the State - that issue would depend upon all the
circumstances of the case, involving a fact-specific assessment for the individual returnee. We agree with the
respondent's submission.

234. We heard, and were referred to, evidence concerning the circumstances of Nuba living in Greater Khartoum
(see, e.g., Dame Rosalind at [A21]-[A22] (oral evidence), [A30]-[A31] (written evidence); Madeline Crowther at

[A100]-[A105] (Waging Peace Report, March 2018), [A124]-[A125] (oral evidence); F-FR 2016 at [A204]-[A214]; FFR 2018 at [A231]-[A234]; Landinfo Response at [A270]). That evidence was directed to the issue of whether the


-----

circumstances were such that it would be unreasonable or unduly harsh for a person of Nuba ethnicity to relocate to
Greater Khartoum, and, in addition, but much less prominently, whether the living and social circumstances in
Greater Khartoum gave rise to a breach of article 3 of the ECHR

235. Mr Jacobs' submissions were briefly made in paras [202]–[203] of his initial written submission, contending
that the level of discrimination in Greater Khartoum, if not persecutory in nature, would make it unduly harsh for a
person of Nuba ethnicity to live there. In his submissions in response to those of Mr Thomann, Mr Jacobs relied, in
effect, on the respondent's position in the CPIN that internal relocation is not available when the risk is from the
State in the individual's home area.

236. He submitted that a person of Nuba ethnicity might well live in the 'Black Belt' and the evidence established
that there is there no access to effective medical services, education and employment. He relied upon the evidence
of Dame Rosalind of the impoverished conditions in the 'Black Belt' where there were no services and merely mud
huts with no fences.  The Public Order law continues in force. There was discrimination in relation to employment
and difficulties for Nuba such as obtaining a national identity card which is required to give them access to basic
services.

237. Mr Thomann accepted that there are difficulties for those in the poorer areas of Greater Khartoum accessing
healthcare, education and employment. He also accepted that discrimination occurs. Nevertheless, he contended
that the sheer size and diversity of the population in Greater Khartoum coming from Darfur and the Two Areas,
made the submission that relocation would be reasonable in the generality of cases sustainable. In his submission,
whether a particular individual would be able to access economic activity, basic services and shelter will require a
fact-specific assessment of the circumstances of that individual.

238. We have no doubt that Mr Thomann's approach is the correct one.

239. In assessing internal relocation, the correct approach is set out in para 339O of the Immigration Rules (HC
395 as amended) and in Januzi v SSHD and AH (Sudan) v SSHD (see above paras 55-60). We bear in mind the
approach to the issue of internal relocation and, in particular, reasonableness or undue harshness set out in
Underhill LJ's judgment in AS (Afghanistan) v SSHD at [61] which we set out above. A fact-sensitive, holistic
assessment of all the circumstances is required.

240. Mr Jacobs relied upon discrimination experienced by Nuba in the 'Black Belt'. Those were the terms used by
both Dame Rosalind and Ms Crowther. We are unsure precisely what they understood discrimination to mean in
this context. It may well have implied that the Sudanese Government deliberately treated those in the 'Black Belt',
in particular the Nuba (and perhaps non-Arab Darfuri), differently from Nuba living elsewhere or other inhabitants of
Greater Khartoum not of Nuba (or non-Arab Darfuri) ethnicity. Consequently, Dame Rosalind was critical of the
British Embassy's report, that “[a]necdotally” sources were surprised at the suggestion that there was _systematic_
discrimination, because it was unclear who had been consulted. The evidence overall, however, does not lead us
to conclude that there is “systematic” discrimination (in the sense of deliberate differential treatment by the State)
against Nuba living in the 'Black Belt' in Greater Khartoum.

241. In our judgment, the crucial issue is an assessment of the actual social and living conditions that Nuba live in
if their internal relocation option is, in reality, to the 'Black Belt'. Do the conditions in the 'Black Belt' make living
there “unreasonable” or “unduly harsh”?

242. Many Nuba have been driven to move to Greater Khartoum because of the conflict in their respected home
areas, and some have, no doubt, moved for economic and social reasons with better access to services and more
job opportunities in Greater Khartoum than in their home area (see F-FR 2018 section 1.1). That may suggest that,
at least for some, they find it a more reasonable prospect than living elsewhere. It is not, we accept, determinative.

243. There is a very large Nuba population (at least hundreds of thousands) living in Greater Khartoum. In reality,
most Nuba live in the 'Black Belt'. There are also very large numbers of non-Arab Darfuris who live there.  While
we accept that those of Nuba ethnicity are likely to live in the 'Black Belt', some, however, may not, where, for
example, they hold professional or other jobs that allow greater economic freedom.


-----

244. Some Nuba do hold high-ranking positions, not least in the SC and traditionally have held posts in the police
force and armed forces. We accept Mr Thomann's submission that the evidence does not establish that education,
whether at a secondary or tertiary level, is not in principle accessible for individuals living in Greater Khartoum from
the Nuba Mountains. There was evidence before us of Nuba attending tertiary education in Greater Khartoum. On
the other hand, the British Embassy has reported that Nuba who obtained employment in Greater Khartoum have
“petty jobs in the informal sector”. There is no doubt that the circumstances in the 'Black Belt', where the majority of
such individuals live in shanty towns, are impoverished. Housing is of a generally poor standard, access to services
is limited, and largely such work that can be obtained by inhabitants is low paid, but not exclusively so. Mr Jacobs
pointed us to general material in the Asylum Research Centre Report, “Sudan Query: The Situation in Khartoum
and Omdurman – an Update” (13, September 2018) concerning access to services and living conditions in Greater
Khartoum (especially at pages 64-67) which cited, and reflected, as he accepted, what was said in the F-FR 2016
and the Waging Peace Report of March 2018. Whilst Dame Rosalind and Ms Crowther said that access to services
is generally poorer for those living in the 'Black Belt', the evidence does not establish that services are generally
unavailable. In our judgment, a fact-specific approach must be adopted to the consideration of access to services,
including education, for any particular individual and its implications for the assessment of 'reasonableness' and
'undue harshness'.

245. We heard evidence concerning the importance of, and access to, ID cards. The evidence before us was that
displaced persons from Darfur and the Two Areas may experience difficulties in reacquiring lost documents
because of the need to obtain witnesses to prove their identity (see F-FR 2016 at para 4.1). That was also the
evidence of Dame Rosalind in her first statement where she said:

“If Nuba have been displaced, they often have difficulty in getting national identity cards because they don't have a
birth certificate and cannot get a certificate from a tribal elder to attest to their identity. If they do not have national
identity cards, they cannot access basic services or sit exams to graduate from secondary school.”

246. Whilst Mr Thomann in para [115] of his submissions drew our attention to evidence demonstrating that an ID
card could be obtained regardless of place of origin or tribal background, there may still be difficulty for some
individuals, particularly from the Two Areas and Darfur, if they cannot establish their identity in the required way.
We also note, the evidence before us, in the F-FR 2016 (at page 77) from a Greater Khartoum based journalist that
people from Darfur and the Two Areas may not be concerned about obtaining an ID card:

“Concerning the possibility of obtaining a national number, the source mentioned that people from Darfur and the
Two Areas also can apply in obtaining national numbers; however, a large number of Darfuris in Khartoum as well
as in Darfur have not applied for the national number yet. According to the source, the main reason for this was
that people did not care about the number and did not see any advantage in having it. They consider the card
merely as a tool for the government to collect information about them in order to monitor and control them.”

247. Consequently, we accept that whether an individual has an ID card and, if not, whether they would be able to
obtain one, may be a relevant factor, specific to their particular circumstances on return to Greater Khartoum when
assessing whether it would be reasonable or unduly harsh for them to live there. On the evidence before us we do
not accept either that an ID card is necessary for reasonable life in Greater Khartoum or that an ID card cannot be
obtained by a migrant Nuba.

248. Overall, we do not accept that, as a general rule, it would be unduly harsh or unreasonable for a person of
Nuba ethnicity returning to Sudan to relocate to Greater Khartoum. Applying the well-established tests of
'reasonableness' and 'unduly harsh', whether internal relocation is open to a particular individual must necessarily
be a fact-sensitive assessment of all the relevant factors.

249. We did not receive detailed submissions on whether the situation in Greater Khartoum breached article 3 of
the ECHR. We do not propose, therefore, to deal with this issue in detail. The claim, for these purposes, is based
upon the circumstances in which a returned failed asylum seeker of Nuba ethnicity would live in Greater Khartoum,
in particular, if that would be to the 'Black Belt'. Establishing a breach of article 3 in these circumstances is likely to
be extremely difficult. The threshold of such a claim is very high (see SSHD v Said at [31] and SSHD v MS
(S li )) O l i ti l ill th t d d f li i d i l diti f th t d


-----

violate article 3 (see Said at [26]). Whilst that must necessarily be a fact-sensitive assessment, we doubt whether,
on the evidence we have seen, that high threshold is likely to be reached in the generality of cases.

250. Finally, the parties' submissions did not explore the issue of whether internal relocation to the Nuba mountains
for a person of Nuba ethnicity at risk in Greater Khartoum was reasonable and not unduly harsh. We noted earlier,
Mr Thomann's position on behalf of the Secretary of State that it was not suggested that the appellant (if at risk in
greater Khartoum) could relocate to the Nuba Mountains. Given that the risk in Khartoum is likely to be a risk from
the State, relocation elsewhere in Sudan is, rightly, accepted not to be an option. If the issue of relocation was to
arise without the risk in Greater Khartoum emanating from the State, we should not be taken to be necessarily
endorsing Mr Thomann's position. All would turn on an assessment of the risk to that individual in the Nuba
Mountains and whether the circumstances they would live in, and experience, there would make it unreasonable or
unduly harsh to do so. It would, as ever, require a fact-sensitive assessment. In the absence of submissions
directed to this issue and given that we consider it unlikely to arise as it would require the risk not to emanate from
the State in Greater Khartoum, we say nothing more specific about relocation to the Nuba Mountains.

E. A Footnote

251. Our decision is solely concerned with the position of individuals of Nuba ethnicity in Sudan. We rejected
earlier an argument based upon a reliance on the CG decisions dealing with non-Arab Darfuris. We have reached
our conclusions based upon the evidence relating to Nuba and not non-Arab Darfuris. But a broader contention
was made before us that the position of the Nuba is the same as non-Arab Darfuris, i.e all Nuba and non-Arab
Darfuris are at risk in Greater Khartoum. We have rejected that contention in relation to those of Nuba ethnicity.
We make no findings in relation to non-Arab Darfuris and, as we indicated above, nothing we said should be
understood to undermine the existing CG decisions in respect of non-Arab Darfuris. We would simply observe that
if the comparison is maintained, on the evidence we saw in relation to Nuba, it might well have implications for the
assessment of the risk to non-Arab Darfuris on return.

**XI. COUNTRY GUIDANCE**

252. We set out the following country guidance in relation to individuals of Nuba ethnicity returning to Sudan:

(a) An individual of Nuba ethnicity is not at real risk of persecution or serious ill-treatment on return to Sudan
(whether in the Nuba Mountains, Greater Khartoum or Khartoum International Airport) simply because of their
ethnicity.

(b) A returning failed asylum-seeker (including of Nuba ethnicity) is not at real risk of persecution or serious illtreatment at the airport simply on account of being a failed asylum-seeker.

(c) Prior to the political developments in 2019, individuals who were at risk on return (whether at the airport or in
Greater Khartoum) were those who were perceived by the Sudanese authorities to be a sufficiently serious threat to
the Sudanese Government to warrant targeting.

(d) The assessment of that risk required an evaluation of what was likely to be known to the authorities and a
holistic assessment of the individual's circumstances including any previous political activity in Sudan or abroad and
any past history of detention in Sudan. Factors include whether the individual was a student, a political activist or a
journalist; their ethnicity; their religion (in particular Christianity); and whether they came from a former conflict area
(such as the Nuba Mountains).

(e) Whilst the question of perception of political opposition underlying (c) above remains the same since the 2019
political developments, when assessing any risk to an individual now, the effects of the 2019 political developments
are relevant and are likely to affect the Sudanese authorities' view of, and attitude towards, those who might be
perceived as political opponents. Further, the 2019 political developments are likely to have greatly reduced the
interest of the Sudanese government in supressing political opposition by violent or military action.


-----

(f) Internal relocation to Greater Khartoum for a person of Nuba ethnicity must depend upon an assessment of all
the individual's circumstances including their living conditions, their ability to access education, healthcare and
employment. Despite the impoverished conditions and discrimination faced by Nuba when living in the so-called
'Black Belt' area of Greater Khartoum, relocating there will not generally be unduly harsh or unreasonable.

**XII. KAM'S APPEAL**

253. Mr Jacobs' submission that the appellant's appeal should be allowed was based upon the contention that all
Nuba, returned as failed asylum seekers, were at risk of persecution or serious ill-treatment because of their
perceived association with rebel opponents to the government, in particular the SPLM-N. We have rejected that
contention. The appellant cannot succeed simply on the basis that he is of Nuba ethnicity and a returning failed
asylum seeker.

254. The preserved findings of the First-tier Tribunal are that the appellant comes from Omdurman (part of Greater
Khartoum) and is of Nuba ethnicity. He has family who live in Omdurman. He has failed to establish any political
activity in Sudan or that he has ever been of interest to the Sudanese authorities, including the NISS. The claim to
have been arrested and ill-treated in Sudan was rejected as not credible by the First-tier Tribunal and that finding
was upheld by this Tribunal.

255. The appellant relied upon sur place activities in the UK, as participating in a television interview criticising the
Sudanese government and as having joined the Nuba Mountains Solidarity Abroad group. The First-tier Tribunal,
having viewed the broadcast clip, concluded that it did not contain any criticism of the Sudanese government. As
regards his activities with the Nuba Mountains Solidarity Abroad group his activities were limited to having attended
one memorial meeting and one social gathering, as well as being a member of the Facebook and WhatsApp
groups. There was no evidence that he had come to the attention of the Sudanese authorities nor that it was likely
that his limited activities would come to the adverse attention of the authorities in Sudan. None of these findings
were set aside by this Tribunal. They stand as part of the assessment of his appeal.

256. Consequently, the appellant has not established any political activity in Sudan and has never been of interest
to the Sudanese authorities, including the NISS. His activity in the UK involved activity critical of the (then) alBashir government. His association with a political group in the UK was limited and was found not to be something
of which the Sudanese government would be aware. All the elements of his claim predated the changes of 2019.
The appellant is a person of Nuba ethnicity from Omdurman with no political activity which could conceivably be
seen as giving rise to a potential threat to the current Government in Sudan. He is not at risk of persecution at the
airport or at home. He will return to his home area where he can safely live with his family. No question of internal
location arises.

257. For these reasons, we re-make the decision and dismiss the appellant's appeal.

Signed

**Andrew Grubb**

Judge of the Upper Tribunal

Date: 25 August 2020

**APPENDIX 1**

A1. CONTENTS

A. Dame Rosalind Marsden DCMG

1. Report, “The Nuba Community in Sudan: why they are at risk” (March 2018) [A3]-[A10]

2. Oral evidence (31 May 2018) [A11]-[A25]

3. “Comments on the Home Office Fact-finding Mission Report” (28 January 2019) [A26]-[A37]


-----

4. “Report on the current political situation in Sudan and the risks involved in returning failed Nuba asylum
seekers to Sudan” (27 August 2019) [A38]-[A49]

5. “Addendum Report on the current political situation in Sudan and the risks involved in returning failed
Nuba asylum seekers to Sudan” (17 October 2019) [A50]-[A62]

6. Oral evidence (24/25 October 2019) [A63]-[A85]

B. Ms Madeline Crowther

1. “Risks to individuals from Nuba Mountains in Sudan” (March 2018) [A87]-[A105]

2. Oral evidence (31 May/1 June 2018) [A106]-[A129]

3. “Comment on Home Office's Nov 2018 Fact-Finding Mission report” (January 2019) [A130]

4. “Report on the risk to Nuba Individuals in Sudan” (27 August 2019) [A131]-[A137]

5. “Addendum report - risk to Nuba Individuals in Sudan” (17 October 2019) [A138]-[A148]

6. Oral evidence (25 October 2019) [A149]-[A166]

C. Dr Eric Reeves

1. “Risk to people from the Nuba Mountains Region on return to Sudan” (January 2018) [A168]-[A174]

2. Oral evidence (21 June 2018) [A175]-[A181]

D. Country Background Evidence

1. Joint Danish Immigration Service and Home Office Fact-finding Missions to Khartoum, Kampala and
Nairobi, “Situation of Persons from Darfur, Southern Kordofan and Blue Nile in Khartoum” (4 August 2016)
(“F-FR 2016”) [A189]-[A215]

2. Home Office, “Report of a Fact-Finding Mission to Khartoum, Sudan” (November 2018) (“the F-FR
2018”) [A216]-[A251]

3. Asylum Research Consultancy, “Situation in Khartoum and Omdurman” (9 September 2015) [A252] –

**[A254]**

4. Research Centre, “Sudan: Query Response” (13 September 2018) [A254]-[A260]

5. COI Focus, “Sudan: Risk upon Return” (2018) [A261]-[A264]

6. Belgium Commissioner General for Refugees, “Respecting the principle of Non-Refoulement when
organising the return of persons to Sudan” (February 2018) [A265]-[A268]

7. Landinfo Response to UK Home Office Query on Sudan (April 2018) [A269]-[A270]

E. The Respondent's Documents

1. Home Office Country Policy Information Team, “Response to an Information Request: Sudan” (23
October 2019) (“CPIT 1”) [A273]-[A283]

2. Home Office Country Policy Information Team, “Response to an Information Request: Sudan, Returns”
(22 October 2019) (“CPIT 2”) [A284]-[A286]

**A. Dame Rosalind Marsden DCMG**

A2. Dame Rosalind Marsden was the first witness to give oral evidence. She served as British
Ambassador to Sudan from 2007 until 2010 and she was the EU Special Representative for Sudan from
October 2010 until October 2013. From 2014 to 2018, she was the Senior Advisor to the Centre for
Humanitarian Dialogue, a US-funded Sudanese programme and she advised the US government on the
Sudanese peace process. She is currently an Associate Fellow at Chatham House where she is a political
analyst advising on Sudan and South Sudan issues. She has first-hand experience of Sudan. In July
2019, she attended a 3-day meeting with 30 Sudanese civil society representatives in Nairobi. Between 28


-----

September and 9 October 2019, she visited Khartoum to help organise and chair a Chatham House
conference during which time she met with a number of local individuals.

_1. Report, “The Nuba Community in Sudan: why they are at risk” (March 2018)_

A3. In her oral evidence in May/June 2018, Dame Rosalind adopted her March 2018 report. In that report,
she described the cultural and religious diversity of the tribes from the Nuba Mountains and the
background to the displacement of “hundreds of thousands” of Nuba to Khartoum in the course of the longstanding conflict in South Kordofan.

A4. In her report, Dame Rosalind stated that ethnicity in Sudan was “highly politicised” and that members
of the Nuba Community were suspected by the authorities of supporting the SPLM-N. That was part of a
wider rebel alliance called the Sudan Revolutionary Front (“SRF”) which also included the armed
movements from Darfur.

A5. Dame Rosalind stated that the al-Bashir regime was opposed to the Nuba tribes. This was because
many Nuba fought with the SPLM on the side of the South Sudanese in the civil war. This led to the
Khartoum regime in the 1990s declaring a jihad against the Nuba and the subsequent policy of using
starvation as a weapon of persecution against Nuba in government control areas. She said that young
men of military age were forcibly recruited and made to fight against their own people. Additionally, large
numbers of Nuba girls and women were raped by government soldiers. She stated that the April 2013
rebel advance towards Khartoum was seen as a major humiliation for the Sudanese government and
resulted in round-ups and arrests of the Nuba.

A6. In her report, Dame Rosalind stated that the declared universal cessation of hostilities in South
Kordofan has yet to lead to a negotiated monitored cessation of hostilities or consent to humanitarian
access to the SPLM-N controlled areas of the Nuba Mountains. She said that:

“As long as there is no comprehensive peace settlement that addresses the root causes of Sudan's internal
conflicts, the Nuba will continue to be regarded with suspicion by the authorities as likely political
opponents and will remain at risk of arbitrary arrest and detention by Sudan's powerful National Intelligence
and Security Service (NISS), particularly at times of heightened political tension.”

A7. She stated that Sudan's National Security Act allowed the NISS to detain people for up to four and a
half months without charge, in violation of international law. There were numerous reports of torture and illtreatment in NISS detention centres.

A8. Foreseeing, in effect, the political developments in 2019, Dame Rosalind added:

“In addition to the risks already facing the Nuba community because of the association with the conflicting
Southern Kordofan in the Blue Nile, Sudan is currently going through a period of heightened political
tension because of widespread protests over the government's austerity measures and a sharp increase in
the price of food and necessities since early January 2018. The government has responded to the protest
by arresting hundreds of opposition politicians, activists and ordinary civilians, including some of the Nuba
community. These protests are expected to continue as there are no signs of any solutions of Sudan's
economic crisis.”

A9. In her report, Dame Rosalind stated that a number of forms of discrimination are suffered by the Nuba
in Sudan including racial, linguistic, cultural, social and economic, and religious discrimination. As regards
the so-called 'Black Belt' in Greater Khartoum where most of the Nuba live in impoverished conditions, she
stated that was

“kept under close surveillance by Sudanese National Security and Intelligence Services (NISS) because
the communities who live there are considered to pose a potential security threat on political grounds”.

A10. In the final paragraph of her report, Dame Rosalind dealt with the forced return of Nuba asylum
seekers. She referred to what was said by a Nuba organisation in the UK. She said this:

“[m]embers of the Nuba Solidarity Committee in the UK say that, if failed Nuba asylum seekers were to be
returned to Sudan, they may not face problems immediately on their return as the Government knows that


-----

their treatment is likely to be monitored. But over time there is a significant risk that they and their families
will be harassed by the security service, including being interrogated by NISS about the diaspora in the UK,
detailed or even targeted in a 'traffic accident'.”

_2. Oral Evidence (31 May 2018)_

A11. In her oral evidence at the first hearing on 31 May/1 June 2018, Dame Rosalind stated that dark-skin
colour could lead to an assumption that a person is Nuba, Darfuri or from the Blue Nile and failing that, an
identity card would record information as to the tribal origin. She said that the Nuba tribes had faced a
history of discrimination and marginalisation. In particular, the Nuba had been involved in the civil war and
also in the conflict in South Kordofan since June 2011. She said that not all Nuba would be suspected of
supporting the SPLM-N but there might be an assumption that an educated Nuba would be sympathetic to
its cause. There would be a greater problem at times of conflict and tension.

A12. Dame Rosalind said that there was a similarity between Darfuris and Nuba in that both groups are
perceived to be sympathisers of armed movements.

A13. Dame Rosalind said that the 2011 attacks in the Nuba areas were triggered by the election and could
be compared to the earlier violence against Darfuris in that they amounted to deliberate attacks on
civilians. The current cessation of hostilities was holding but had not held entirely. Whilst there were no
longer aerial bombardments in Nuba areas, pro-government militia remained active and it was considered
hostilities could be renewed at any time. Indeed, the government had withheld humanitarian aid from the
Nuba Mountains as a means of waging war in the area. She said that the government considered the
advances made on Khartoum in 2013 by the JEM and the SPLM-N as humiliations to the regime and they
had led to a wave of arrests.

A14. Dame Rosalind stated that there was currently (May/June 2018) a state of political tension in Sudan
and the lack of any comprehensive peace agreement had created a background of suspicion. Whilst there
remained no peace agreement, Nuba ethnicity constituted a high-risk factor. Furthermore, the economy
had declined and there had been protests in January 2018.

A15. Dame Rosalind stated that the Nuba in Khartoum live in shanty towns in an area called 'Black Belt'
which she had visited during the elections in 2010. She stated that there were no services in this area
which comprised mud huts and had no fences. She said there was a very serious humanitarian situation
for the Nuba in their home area and there was a continuing flow of Nuba to refugee camps.

A16. Dame Rosalind stated that Nuba as a group might join protests and are kept under surveillance.
Nuba returning from overseas may not face difficulty at the airport but the government are aware of the
potential for monitoring on return. She stated that the security services might let the “dust settle” and
detain individuals once they had passed from the airport into the city.

A17. Dame Rosalind expressed the view that the appellant's risk on return would not be reduced by the
fact that he lived in Omdurman prior to leaving Sudan. He would be seen primarily as Nuba and as a
member of a group which is perceived as hostile to the regime. She stated that the NISS paid close
attention to this group. The NISS are powerful within Sudan and there were numerous reports of abuse.
She said that the NISS was active throughout the country and acted with impunity.

A18. In cross-examination, Dame Rosalind stated that the cease-fire in South Kordofan in 2016 was
agreed with (then) President Obama and that US sanctions were lifted thereafter. She said that the area
bombardment in South Kordofan had stopped but that there remained attacks on civilians. It was a
unilateral cessation of hostilities which was renewed every few months.

A19. Dame Rosalind stated that the lifting of economic sanctions was an incentive to maintain cessation of
hostilities, as was it important to be removed from the US list of state sponsors of terror. However, the
political situation was more precarious than it had been because when sanctions were lifted; the off-and-on
situation in Sudan, in fact, in October 2017 deteriorated with high inflation. The economic situation was
extremely serious. She pointed out that it was unclear whether the Sudanese government would be


-----

prepared to accept any conditions from the international community and that President al-Bashir had asked
the Russian government for protection from the effects of the US sanctions.

A20. Dame Rosalind said that the Nuba population in Greater Khartoum must be in the 100,000s. She
accepted that it would not be feasible for the NISS to monitor the whole of the population.  She accepted
that monitoring would be targeting particular Nuba leaders and that a returned asylum seeker would not,
without more, be on a list of those of interest. She accepted that the focus would be on those with a profile
and that those returned asylum seekers might fall into that category. She noted that the NISS focused
upon those who were more highly educated and activists.

A21. Whilst Dame Rosalind said that Sudanese law prohibited discrimination on grounds of ethnicity, she
also said that the application of the law in practice was different. Educational opportunities were poor and
educational provision was low and privatisation of health provision had made access to health services
more difficult particularly for those living in the 'Black Belt'. She said that in principle an ID card would be
available whatever an individual's ethnic background but stated that the problem was that those from the
peripheral areas did not have a birth certificate and could not obtain the documentation from a tribal area if
they were from conflict areas to obtain an ID card. It was more likely that an individual would not have the
necessary documents if they were displaced.

A22. In relation to South Kordofan, Dame Rosalind said that education in the Nuba Mountains was
extremely poor. The level of education was low. She was unaware of a university in South Kordofan. She
accepted that education was more broadly available in Khartoum. She was unaware whether there were
Nuba students in the university in Khartoum but she was aware of a Nuba students' association but she
could not comment on the number of students. She said that there was no formal bar to Nuba students
going to university.

A23. As regard Christian worship in Khartoum, she said that there had been a decrease since the creation
of South Sudan and many Christians had left. She was unaware of the numbers of Christian schools in
Khartoum.

A24. As regards the perception of Darfuri and Nuba students, Dame Rosalind stated that students as a
group were vulnerable to detention but the Darfuri students seemed to be more subject to arrest and illtreatment. They were more politicised and there was stronger support among Darfuri students in
Khartoum.

A25. As regard recent (i.e. up to May/June 2018) unrest in Khartoum, Dame Rosalind had no specific
knowledge that Nuba were targeted. She was unable to comment on individual incidences of alleged
arrest on return. She was unaware of precisely how many individuals had been detained. Those detained
in January and February – some 200 or so activists and others – had all been released. It had been
reported, she said, that several hundreds of Darfuris were arrested during that period. She observed that
some may not have been detained but may have been required to report to the NISS. The numbers who
were detained were “not huge”. She said that a returning Nuba asylum seeker would come under
“suspicion on return”.

_3. “Comments on the Home Office Fact-finding Mission Report” (28 January 2019)_

A26. Following the publication of the F-FR 2018 in November 2018, Dame Rosalind produced a response
in writing to that report. The report was mainly concerned with the position of non-Arab Darfuris. However,
Dame Rosalind commented in her evidence that the report, in her view, acknowledged the similarity in
perception of the two groups by the authorities, in their respective perceived allegiances with rebel groups.
At para 5 of her response, Dame Rosalind said this:

“Although the FFM report is focused on the circumstances of non-Arab Darfuris and does not specifically
address those of the Nuba, several sources quoted in the report draw attention to the strong read across
between the situation of Sudanese of Nuba and Darfuri ethnicity because both are presumed by the
Government of Sudan to be supporters or sympathisers of the armed movements in their respective
conflict zones – Nuba Mountains/Southern Kordofan and Blue Nile States (also known as the Two Areas)
and Darfur (3 2 6; 3 2 10) In the case of the Nuba they are presumed to be supportive of the Sudan


-----

People's Liberation Movement/North (SPLM/N). As long as the conflict in the Two Areas is not resolved
and the SPLM/N is seen to pose a political and security threat to the regime, this perception is likely to
continue in the minds of the Sudanese authorities.”

A27. In her response, Dame Rosalind commented on the eight-year conflict in South Kordofan and the
progress in peace talks, in particular in the light of the demands of the SPLM-N faction led by al Hilu. At
para 8 she said this:

“There has been no significant progress in the African Union-mediated peace talks between the
Government of Sudan and the SPLM/N to end the conflict. The SPLM/N suffered a leadership split in 2017
and divided into two factions, the larger one led by Abdul Aziz Al Hilu which controls the Nuba Mountains
and the southern part of Blue Nile state and the smaller faction led by Malik Agar which controls the
Ingessena Hills in Blue Nile. Abdel Aziz has adopted a harder negotiating position than Malik Agar and his
demands for self-determination, retention of his army for 20 years and the creation of a secular Sudan with
the abolition of sharia law have proved unacceptable to the Government. Talks over humanitarian access
to the SPLM/N-controlled areas, remain stalled over Abdel Aziz's insistence on cross-border, not just
cross-line, access.”

A28. Dame Rosalind acknowledged that the F-FR 2018 had been written prior to the political development
beginning in December 2018. At paras 10-11, Dame Rosalind said that the protests had begun in midDecember and the government had responded to them with “predictable brutality”:

“10. Though initially sparked by spiralling food prices and fuel shortages, the protests were not “bread
riots” but the culmination of three decades of repression, poverty, unemployment, institutionalised
corruption and atrocity crimes in Darfur, the Nuba Mountains/Southern Kordofan and Blue Nile. They
quickly assumed a strong political dimension with protestors calling for the end of Bashir and his regime.
The protests have been led by a coalition of young people, professionals, civil society and opposition
political parties. All segments of society are involved but young people are the most visible out on the
streets. They feel a sense of hopelessness because of lack of employment opportunities and the erosion
of living standards caused by hyper-inflation. Women, who have also been at the forefront of the protests,
are angry about decades of harassment and humiliation by the public order police. Even sons and
daughters of the ruling party have joined the demonstrations. While no single political organisation
dominates the protests, the Sudanese Professionals Association, and particularly the independent doctors
syndicate, have been prominent in coordinating the protests. Opposition parties and coalitions, which have
a long history of internal divisions, have finally managed to pull together and coordinate with other social
forces. The protests have now entered their second month and are steadily gaining momentum with
increasing numbers and geographical spread. Given the scale and breadth of the protests, which started
in mid-December, these constitute the most sustained popular challenge faced by the Bashir regime since
it came to power in 1989.

11. The Government has responded to the protests with predictable brutality, using beatings, tear-gas,
large-scale arbitrary arrests, torture, extra-judicial killings and the use of live ammunition against unarmed
protestors. Over 50 protestors are reported to have been killed and hundreds injured. A number of victims
have been shot in the head or chest by government snipers or have died from torture in NISS detention.
There has also been a campaign of mass arrests with thousands detained. Journalists, activists and
especially doctors have been targeted. Hundreds of videos and photographs showing the injuries of the
victims and the brutality of government security forces are circulating on social media.”

A29. At paras 13-14, Dame Rosalind commented on the impact of the political turmoil for those of Nuba
ethnicity, including the “increased suspicion by the government” that those of Nuba ethnicity are presumed
supporters of the SPLM-N insurgency in the Nuba Mountains. At paras 13-14 she said this:

“13. All Sudan's opposition groups have come out in support of the protests, including the two SPLM/N
factions led respectively by Abdul Aziz Al Hilu and Malik Agar, who have both publicly encouraged their
supporters to join the protests across Sudan. There have been a number of protests in the poorer
neighbourhoods of Khartoum where Sudanese of both Nuba and Darfuri ethnicity tend to be concentrated.
There have also been solidarity protests in Kauda the SPLM N stronghold in the Nuba Mountains


-----

SPLM/N supporters and activists have also been arrested in the government-controlled area of Nuba
Mountains/Southern Kordofan, including pre-emptive arrests prior to a visit by President Bashir to the area
on 28 January 2019.

14. This means that failed asylum seekers of Nuba ethnicity are likely to be viewed with increased
suspicion by the Government of Sudan not only as presumed supporters of the SPLM/N insurgency in the
Nuba Mountains but also as potential participants in country-wide protests to topple the regime.”

A30. At paras 15-21, Dame Rosalind dealt with the position of Nuba in Greater Khartoum:

“The Nuba living in the shanty towns of Khartoum suffer the same hardships as Darfuris, plus additional
discrimination on religious grounds”.

A31. She continued:

“15. The FFM report mentions the presence of Nuba alongside Darfuris in the shanty towns around the
Khartoum metropolitan area (which includes the three towns of Khartoum, Khartoum North and
Omdurman). The authors of the FFM report conducted all their interviews inside the British Embassy in
Khartoum and did not visit the “Black Belt” areas to see for themselves the conditions in which most
Darfuris and Nuba live. But some of their interviewees noted that the various kinds of social and economic
discrimination suffered by Darfuris living in the so-called “Black Belt”, particularly lack of basic rights,
including access to water, education and health facilities, apply equally to the Nuba. Saleh Mahmoud, the
human rights defender, noted that Darfuris and Nuba living in the shanty towns were often forcibly evicted
(3.5.8). The political scientist observed that government security agencies regarded these areas as
sleeping cells for rebels and that there was a large NISS presence in these areas (3.2.7). Some of the
interviewees thought that the Nuba suffered worse discrimination than the Darfuris. The Second Secretary
Political at the British Embassy said that that “Arabs look down upon the Nuba and people from South
Sudan” (3.2.11). The civil society activist thought that Darfuris did better than the Nuba in terms of socioeconomics. “Nuba IDP families rely on income generated by their children collecting recyclable items to
sell from rubbish dumps” (3.5.5).

16. Unlike Darfuris, who are nearly all Muslims, many Nuba suffer further discrimination as a result of
being Christian. The Government continues to restrict religious freedom and belief by demolishing
churches, interfering in internal Church affairs and making Christian schools open on Sundays. Sudan has
been identified as a “Country of Particular Concern” in the US State Department's latest report to Religious
Freedom.

17. As is the case with Darfuris, there are some Nuba who hold government or military positions in
Khartoum. But the Nuba who occupy these positions are either associated with the National Congress
Party or have been deliberately co-opted by the Government with jobs, privileges and money and are
despised by their own community.”

A32. Dame Rosalind said that, in her view, the F-FR 2018 understated the gravity of the situation in
Sudan. She stated that there was insufficient appreciation of the heavy presence of the NISS at the airport
and the fact

“that failed asylum-seekers, who are returned with escorts, are effectively handed over to NISS, a body
with an extremely poor human rights record”.

A33. She did, however, accept the proposition put forward by one of the respondent's interlocutors in the
report that the human rights environment in Khartoum was more benign than in the past and that people
could talk openly about politics.

A34. At paras 22-25, Dame Rosalind set out what she called the “risk categories” in relation to failed
asylum seekers and Nuba on return and expressed the view that, as of January 2019, a failed asylum
seeker of Nuba ethnicity would be at risk of ill-treatment because of imputed political opinion. She relied, in
part, on what she had been told by others:

“Risk categories


-----

22. I have been told by an eminent Sudanese human rights lawyer to whom I spoke in the context of the
Darfur Country Guidance Case that the fact of being a failed Sudanese asylum seeker in itself creates a
negative profile in the eyes of the Government because seeking asylum is regarded as a hostile political
act. This view was also expressed by several Sudanese interviewees quoted in the FFM report including
Saleh Osman from the Darfur Bar Association and the civil society activist (6.3.4 and 6.3.6). Western
Embassy officials and the IOM representative, on the other hand, generally agreed with the assessment of
risk in the Home Office's Sudan: Country Policy Information Note, Unsuccessful Asylum Seekers, July
2018. The possible reasons for this divergence of opinion is addressed in para 28 below.

23. In my view, it is likely that a failed asylum seeker from the UK would be regarded with greater
suspicion than a returnee from a neighbouring country because the Sudanese diaspora in the UK are
heavily engaged in opposition activity, as evidenced by the large number of anti-government
demonstrations held in cities across the UK in the last five weeks in support of the popular uprising in
Sudan.

24. If a failed asylum seeker is also of Nuba ethnicity, this is sufficient to create a significant risk of illtreatment because of presumed association with the SPLM/N, regardless of whether this is true or not.
Other factors that may add further to the risk include:

- evidence of actual opposition activity either in-country or sur place. NISS officers in the Sudanese
Embassy in the UK go to great lengths to monitor the political activities of the diaspora through a network
of informers;

- membership of the professional classes. Members of the professional classes played a major role in the
1964 and 1985 uprisings and are doing so again in the current uprising

- a profile as a human rights defender of activist

- a profile as a blogger/social media activist. NISS have a special unit which monitors social media closely
for any sign of political dissent. Khartoum has now extended its reach by asking the security services in
neighbouring countries to deport Sudanese activists, who have then been detained on their return to
Sudan.

- a young male of military age

- a student. The “jihadi” student brigades of the ruling National Congress Party target Nuba as well as
Darfuri students in the universities because of presumed affiliation with the opposition and suspicion that
those with an education could become activists and community leaders.

The criteria mentioned above are additional risk factors but the way in which NISS operates is arbitrary and
it is therefore difficult to predict precisely who they will target.

25. Once in detention, detainees with a media or political profile or who come from well-known families are
likely to be treated more favourably than lower profile individuals who are more likely to be abused or
tortured in prison. For example, Saleh Mahmoud, the well-known human rights defender, recounted that
when he was detained in February-April 2018, he was not physically tortured but he was forced to witness
the beating of other young detainees (3.3.1). The civil society activist also noted that, if he was arrested,
he would be probably not be mistreated because he was a high-profile human rights activist and his case
would attract media attention from the international human rights community which was unwanted by the
Sudanese authorities. “But for other Darfuris, when arrested, there is no press release, no one to make a
noise and intervene” (6.3.6). This distinction would also apply to Nuba detainees.”

A35. In relation to the monitoring of failed asylum seekers, she disagreed (at paras 26-27) with the F-FR
2018's view that failed asylum seekers were not likely to face ill-treatment on return in the following terms:

“Monitoring of failed asylum-seekers after their return

26. There is a marked contrast between the views express by the majority of Sudanese civil society
representatives interviewed by the FFM team and those of Western Embassies and the IOM representative
on the other as to whether failed asylum seekers were likely to face ill-treatment on return. Most of the


-----

Sudanese civil society representatives said they had heard about problems for individuals returned to
Sudan, including arrest, detention and ill-treatment or considered it likely that returnees might experience
difficulties (6.3.4-6.3.9). Amjed Farid al Tayeb said that he had personally met returnees who had been illtreated, namely two from Jordan in 2015 and one from Belgium in April 2018. Dr Ahmed Eltoum Salim
drew attention to an article in the New York Times on 22 April 2018 by Patrick Kingsley (6.3.22), who said
he had interviewed seven recently returned asylum seekers, four of whom claimed to have been tortured.
The article documented the case of a Darfuri political dissident returned from France in late 2017, who said
he had been detained by NISS on arrival at Khartoum airport and tortured with beatings and electric
shocks over ten days and had had to be hospitalised. However, Western Embassy officials and the IOM
representative all said that they were not aware of verified cases of ill-treatment of returnees.

27. The methodology adopted by the FFM report is to quote excerpts from the interviews and
correspondence conducted with the 20 sources listed in Annex C of the report. The report relies solely on
these 20 sources and does not draw on any other material. Where the opinions expressed by interviewees
are contradictory, the report does not attempt to explain or reconcile the differences. Nor does it express
any judgment as to which opinions are well-founded or attempt to draw any final conclusions.

28. Nevertheless, it is clear from the interviews that certain caveats should be applied in assessing the
opinions expressed by some interviewees. There appears to be no systematic mechanism in place for
monitoring the treatment of failed asylum seekers after their return. This applies to Western Embassies
and the IOM as well as to Sudanese civil society organisations….”

A36. Dame Rosalind went on in para 28 to state that the UNHCR, IOC and Western Embassies did not
monitor or follow-up returned asylum seekers to Sudan. Further, at para 29, Dame Rosalind said that the
authors of the F-FR 208 had not consulted Amnesty International who had been able to follow up on the
treatment of some failed asylum seekers and:

“have found evidence of ill-treatment in some cases, although they told me that its is a mixed picture and
that it is often difficult to track down failed asylum seekers to monitor their post-deportation experience
because they are so traumatised and paranoid that they do not want to speak to anyone.”

A37. At paras 30-32 of her report, Dame Rosalind set out her conclusions in the light of the F-FR 2018
including her view that the Nuba were likely to be targeted in Khartoum because of their perceived political
affiliation with armed rebel movements and that failed asylum seekers of Nuba ethnicity, on return were
likely to be at risk of ill-treatment because of their ethnicity and, again, their perceived affiliation with armed
rebel movements. The suspicion which fell upon them was, in her view, likely to continue as long as the
internal conflicts in Darfur and in the Two Areas were not resolved. She also identified a “significant
additional risk” as being a “potential participant in country-wide protests at the top of a regime”. At paras
30-32 Dame Rosalind said this:

“Conclusion

30. Although the FFM report is focused on gathering information about the circumstances of non-Arab
Darfuris in Sudan, interviewees quoted in the report draw many parallels with the circumstances of the
Nuba, who have also suffered extreme violence at the hands of government forces and militias in their
home areas and are targeted by the Sudanese authorities in Khartoum because of their perceived political
affiliation with armed rebel movements. Indeed, several interviewees say that discrimination against the
Nuba is worse than that against Darfuris. However, those who researched the report conducted all their
interviews in the British Embassy in Khartoum and did not visit the “Black Belt” to collect first-hand
evidence of the living conditions of many Darfuris and Nuba in Khartoum. The report also downplays the
gravity of the human rights situation in Sudan and particularly the role of NISS in this regard.

31. The other aim of the FFM report was to gather information about the treatment of returnees generally.
It quotes various sources in Western Embassies and IOM who say that they are not aware of information
indicating that failed asylum seekers have been ill-treated after their return but, in the absence of any
systematic monitoring mechanism, this does not necessarily prove that no such incidents take place. Nor


-----

did the authors of the report appear to have interviewed Amnesty whose reports do contain evidence of illtreatment of returnees.

32. Like non-Arab Darfuris, failed Sudanese asylum seekers of Nuba ethnicity are likely to be at risk of illtreatment on the grounds of their ethnicity if they are returned to Sudan because of the associated
presumption in the Government of Sudan's mind of political affiliation to armed rebel movements. This
suspicion is likely to continue as long as Sudan's internal conflicts in Darfur and the Two Areas are not
resolved. If a failed asylum-seeker falls into one or other risk categories, the risk is increased, irrespective
of their tribal origin. However, the way in which NISS operates is arbitrary. There is now a significant
additional risk of being viewed as a potential participant in country-wide protests to topple the regime.
Given the current government crackdown and the prospect of continued political instability, it would not be
appropriate to return failed Sudanese asylum seekers of Nuba ethnicity to Khartoum in a situation of
heightened political tension.”

_4. “Report on the current political situation in Sudan and the risks involved in returning failed Nuba asylum_
_seekers to Sudan” (27 August 2019)_

A38. Dame Rosalind produced two written reports for the October 2019 hearing dated 27 August and 17
October 2019 in which she commented upon the situation in Sudan. These are important as they provide
up-to-date evidence about the situation in Sudan following the fall of al-Bashir and the political
developments that have followed. At para 5 of her report dated 27 August 2019, Dame Rosalind set out
the post-April 2019 situation following the overthrow of the regime of al-Bashir as follows:

“On 11 April 2019 - after four months of nation-wide pro-democracy peaceful protests - Sudan's former
President, Omar al Bashir, was overthrown by a group of senior military and security officers from his own
Security Committee, who formed a Transitional Military Council (TMC). The TMC embarked on
negotiations with Forces for Freedom and Change (FFC), a pro-democracy coalition of opposition political
forces, professionals and other civil society actors, but conducted a brutal crackdown on protesters in
Khartoum on 3 June, followed by other incidents of violence. Nevertheless, under intense external
pressure, the TMC signed a power-sharing agreement with the FFC on 17 August to form a transitional
government with an independent civilian Prime Minister.”

A39. Annexed to her report is the political agreement of 17 July 2019 and the constitutional declaration of
4 August 2019 setting out the arrangements for the transitional government.

A40. At para 6 of her report Dame Rosalind set out the potential dangers for the future noting the “fragility
of the situation” and that it was too early to predict where Sudan was heading and whether it was safe to
return asylum seekers of Nuba ethnic origin. At para 7-9 Dame Rosalind said this about the nature of the
power sharing agreement and new transitional government:

“The power-sharing agreement and the new transitional government

7. Mediated by the African Union and Ethiopia, the deal provides for a transitional period of three years
and three months to prepare for national elections in 2022. During this period, the government will be
composed of three transitional bodies: a joint military/civilian Sovereign Council acting as a collective
Head of State, with six civilian and five military members, to be chaired for the first 21 months by a military
representative and for the last 18 months by a civilian; a civilian Prime Minister and Cabinet largely
composed of technocrats;; and a Legislative Council, responsible for legislation and oversight of the
executive, to be formed within 90 days. The Members of the Sovereign Council and the Cabinet in the
transitional government will not be eligible to stand in the 2022 elections but this bar does not apply to
members of the Legislative Council.

8. The powers and responsibilities of the three bodies are set out in a political agreement (initialled on 17
July) and a constitutional declaration (initialled on 4 August) which were formally signed in Khartoum on 17
August in the presence of international and regional dignitaries. The TMC was dissolved and the
Sovereign Council appointed on 21 August, with General Abdel Fatah Burhan, an army officer and the
former head of the TMC, as chair. Abdallah Hamdok, an experienced and respected economist, who


-----

served until last year as Deputy Executive Secretary of the UN Economic Commission for Africa, has also
been sworn in as Prime Minister and his new Cabinet is expected to be announced on 28 August.

9. The next steps in forming the transitional government will be the appointment of 11 Independent
Commissions (responsible for Peace, Elections, Borders, Constitutional Drafting, Legal Reform. AntiCorruption and Public Funds Recovery, Human Rights, Civil Service Reform, Land, Transitional Justice
and Women and Gender Equality); and the formation of the Legislative Council by mid-November. “

A41. At paras 10-11, Dame Rosalind set out the background to how the agreement was reached between
the TMC and the FFC following the violent crackdown on 3 June 2019:

“How was the agreement reached?

10. The TMC realised the limits of its power when its attempt to halt the revolution by forcibly dismantling
the protest site in Khartoum on 3 June backfired, sparking international outrage (see below). Defiant
protestors turned out in large numbers on 3 June to demonstrate their determination to sustain the
revolution and the FFC's ability to mobilise mass support. Strong international pressure for the rapid
formation of a civilian-led transitional authority, US/UK diplomatic intervention with the TMC's backers,
Saudi Arabia, the UAE and Egypt, and a coup attempt by counter-revolutionary Islamist forces may all
have persuaded the TMC that they had to strike a deal with the pro-democracy movement.

11. In the opposition camp, the FFC concluded that, given the power imbalance between the military and
unarmed civilians, a compromise was needed in order to establish a transitional government, however
imperfect, so that civilians could push their reform agenda from inside government and avoid a political
vacuum, which could leave room for counter-revolutionary coups or escalating violence by Sudan's many
security forces.”

A42. At para 12, Dame Rosalind sets out the “balance” between civil and military on the SC:

“12.  The agreement is a step forward but still leaves considerable power in the hands of the military.
Some opposition forces have criticised the agreement for being too weak, particularly as the military will
chair the Sovereign Council for the first 21 months and will be able to veto its decisions, since, in the
absence of consensus, decisions will require a two thirds majority. They will also be able to nominate the
Ministers of Interior and Defence. On the other hand, FFC negotiators point to gains made during
negotiations on the constitutional declaration such as confirmation that the FFC will have 67 per cent of the
seats in the Legislative Council, the paramilitary Rapid Support Forces (RSF) will come under at least
nominal army control and government officials will not enjoy blanket immunity from prosecution.”

A43. At paras 13-15, Dame Rosalind commented on the challenges facing the FFC and their future impact
on political developments:

**“Divisions within the FFC**

13. But political dynamics will matter more than pieces of paper. The unity of FFC forces has been
strained by the negotiation process, continuing street violence and internal bickering. The Sudanese
Communist Party, which is a member of the FFC, has been particularly critical of the power-sharing
agreement. If civilian authority is to prevail, it will be important for the FFC to maintain a united political
front to ensure that the new government delivers on its reform programme. Most of the civilians in the new
government are likely to be politically inexperienced technocrats. Reports of divisions within the FFC risk
fracturing the protest movement, providing an opportunity for the military to exploit the situation and scuttle
a transition to democracy.

14. While civilian rule and civic rights are the main demands of protestors in urban areas, Sudanese living
in conflict zones attach more importance to achieving peace and ending the marginalisation of Sudan's
peripheries. The armed movements in the Sudan Revolutionary Front (SRF), which fought for years
against Bashir's regime, have stressed that peace and democratisation must go hand in hand if the
revolution is to enable people in the peripheries to become equal citizens and take full part in national
elections – putting an end to long-established forms of governance which favoured a privileged political
elite in Khartoum The TMC and FFC have agreed that achieving a comprehensive peace settlement


-----

should be the priority for the first six months of the transitional period. The constitutional declaration
includes a peace agenda drawn from a roadmap for peace agreed by the SRF and some FFC elements in
Addis Ababa in late July, although the SRF are angry that other key sections of the Addis agreement were
omitted and have complained that the interests of the marginalised areas have been side-lined by the
allegedly Khartoum-centric approach of the FFC negotiators. Nevertheless, the SRF are preparing to start
negotiations as soon as the Peace Commission is formed. It is less clear when the other armed
movements – the SPLM/North faction led by Abdel Aziz al Hilu and the Sudan Liberation Movement led by
Abdel Wahid Nour – will be ready to negotiate.

15. Another challenge will be to ensure proper representation of youth and women in the new governance
structures. These groups were the driving force of the revolution but have been largely excluded from FFC
decision-making bodies. Including these new social forces and other marginalised groups in the new
governance structures will be crucial if Sudan is to transform established patterns of power and privilege
and the new government is to retain the support of the streets.”

A44. At paras 16-27, Dame Rosalind deals with a number of features of the current position relevant to
whether real change has taken place, and will continue, in Sudan dealing with “potential spoilers” and the
challenge of dismantling the Islamic “deep state” and the continuing role of the NISS, now re-named the
GIS:

“Potential spoilers

16. There is concern among some activists that the TMC might be reluctant to hand over the chairmanship
of the Sovereign Council after 21 months and could be tempted to engineer a crisis that would provide a
pretext for claiming that the military need to take over the government in order to prevent chaos.
Alternatively, they might simply “let the government fail” i.e. wait until popular discontent grows because
there is no immediate improvement in basic services and living standards and then use this as an excuse
to take control.

17. Insecurity could also arise from divisions amongst the security forces. While the opposition may
struggle to maintain its unity, the military also face divisions. Among the Sudanese Armed Forces (SAF),
there is reportedly widespread resentment of the RSF as an ill-disciplined militia who are paid far more
generously than their SAF counterparts. There is also resentment among SAF officers that the RSF
commander, General Mohamed Hamdan Dagalo (widely known as Hemeti) enjoys such a senior position
despite never having graduated from the military academy (or indeed even from primary school). Hemeti,
a 45-year-old camel trader turned militia commander, has emerged as the most powerful man in Sudan,
even more than General Burhan, who actually chairs the Sovereign Council.

18. Many in the protest movement are afraid that Hemeti might make a move to take over the country. He
controls tens of thousands of paramilitary forces, who were originally recruited from the Janjaweed
nomadic Arab tribes mobilised by the Bashir regime to put down rebellion in Darfur in 2003-4 and were
subsequently rebranded in 2013 as the Rapid Support Forces. Rights groups say that his forces burned
villages and systematically raped and killed civilians during a series of counter-insurgency campaigns in
Darfur, the Nuba Mountains and Blue Nile over many years. While his forces continue to attack civilians in
Darfur, Hemeti has now brought violence to the streets of the national capital.

19. One of the main reasons for Hemeti's rapid ascendancy is that he has been contracted by Saudi
Arabia and the United Arab Emirates to provide ground troops to fight on their behalf in the Yemen war
against the Houthis and now in Libya in support of General Haftar. With Gulf money, he is reported to be
recruiting heavily from Arab tribes in Chad and Niger as well as other parts of Sudan. Consequently, the
RSF has become a transboundary militia, which could destabilise the wider region as well as bringing
chaos to Sudan. Hemeti can draw on his family's vast gold mining and livestock operations in Darfur, as
well as Gulf money, to buy the support of tribal leaders and local elites. Much will depend on whether it is
possible to control the RSF by reducing its funding from Gulf states and limiting Hemeti's political
ambitions. But many are sceptical about how quickly that could happen, given the strength of Hemeti's
military and economic base and the continued interest of the Gulf states in renting his fighters for Yemen


-----

and Libya. For now, Burhan and Hemeti are tied together by their mutual commercial and political interests
but in the longer run, the SAF's disdain for Hemeti could unpick the alliance.

20. Another risk to the country's stability is that members of the former ruling party (the National Congress
Party) and the Islamic Movement, who still occupy many key posts in state institutions and numerous
businesses, could try to sabotage the economy to undermine the transitional government or mount a
counter-revolutionary coup with support from Islamist elements within the security forces and the Islamist
shadow militias (Popular Defence Forces, Popular Security, Popular Police, student jihadist units) created
by the previous regime. There already appears to have been at least once such coup attempt, which led to
the arrest of several senior army officers, including the Chief of Staff, and some veteran Islamist politicians.

**The extent to which elements of the Bashir regime remain in positions of power**

21. The overthrow of Bashir after 30 years in power was a major turning point in Sudanese politics but
many elements of his repressive regime are still in place. The biggest challenge facing the government will
be dismantling the Islamist “deep state” or “parallel state” created over thirty years by the former regime,
which took control of all security organs, state institutions and key sectors of the economy, including
hundreds of businesses owned by the NCP and the military-security apparatus. Key to dismantling the
deep state will be the implementation of a comprehensive programme of security sector reform aimed at
establishing a professional and inclusive national army, reducing the disproportionately high percentage of
the national budget devoted to the military and security services (estimated to be about 70%) and
restructuring the intelligence service. Because state capture by the Bashir regime was so far-reaching,
dismantling the deep state is expected to take several years.

22. The TMC itself is regarded by many in the protest movement as a mere extension of the Bashir regime
because it was formed from members of Bashir's Security Committee. There is considerable scepticism
that they will be willing to give up their power and financial privileges.

23. A number of Islamist officers from SAF and NISS have been seconded to the RSF in the last couple of
years. Hemeti has claimed that members of Islamist shadow militias also infiltrated the RSF during the
operation to clear the sit-in area on 3 June and were responsible for deliberately escalating the violence,
while trying to put all the blame on him.  These shadow militias appear to have access to army, police and
other uniforms.

24. Bashir and some senior members of the former regime are under arrest and are allegedly being
detained in Kober prison, Khartoum's top security prison. Bashir was brought to trial in Khartoum on 19
August on charges of corruption based on money found in his house when he was arrested (although the
real extent of his corruption is infinitely greater than this). But most Sudanese are more concerned that he
should face justice for the heinous crimes he is alleged to have committed in Darfur, including war crimes,
crimes against humanity and genocide. It is not yet clear whether Bashir will be sent to the Hague but one
of the mandated tasks of the transitional government is to hold accountable all members of the previous
regime for all crimes committed against the Sudanese people since 30 June 1989.

**To what extent does the National Intelligence and Security Service (NISS) still retain power?**

25. An early demand of the protesters was the disbanding of the powerful NISS, which was used to protect
the Bashir regime, among other things by arresting, detaining and often torturing its opponents and by
rigging elections. The Special Operations Department of NISS also has a substantial military capability,
including armoured personnel carriers and attack helicopters as well as an extensive covert business
network.

26. So far there have been two signs of possible reform: General Burhan's decision on 29 July to change
the organisation's name to the General Intelligence Service (GIS); and the stipulation in the Constitutional
Declaration (Article 36) that the duties of GIS should be limited to gathering and analysing information and
providing advice to the relevant authorities. However, the Constitutional Declaration (Article 2a) also
stipulates that all existing laws shall remain in force unless they are repealed or amended. This means that
the National Security Act, which provides for the intelligence service to exercise powers of arrest and
detention and grants immunity to its officers for all acts committed in the course of their duties will remain


-----

in force until such time as it is amended or repealed by the Transitional Legislative Council. As the allpowerful intelligence and security service is at the heart of Sudan's deep state and the military have a veto
in the Sovereign Council, few expect the new government to make many inroads into it anytime soon. One
possible option that has been mooted is for the Special Operations Department of GIS to be transferred to
the Rapid Support Forces. But this would still be problematic if they did not change their modus operandi.

27. GIS is still staffed by the same officers who ran NISS, most of whom are Islamists. They are therefore
likely to operate in much the same way as they did before, particularly while they still enjoy impunity.
Although the former head of NISS, Salah Gosh, is in exile in Egypt, where he is said to be an adviser to
Egyptian intelligence, the most powerful figure in GIS is now thought to be Abdul Ghaffar Sharif, the former
Head of Political Security in NISS, who was notorious for his brutality.”

A45. Subsequently in her report (paras 30-36), Dame Rosalind commented on violence against protestors
in Khartoum in beginning in December 2018 as follows:

“RECENT VIOLENCE AGAINST CIVILIANS

30. When protests started in December 2018, the government's security forces and militias responded in a
heavy-handed way, using whips, tear gas, rubber bullets and often live ammunition against peaceful
protesters. Many injuries were caused by tear gas canisters thrown directly at people's heads. Doctors
were particularly targeted and tear gas was used inside hospitals where the wounded were being treated.
The main perpetrators of the violence were reported to be NISS officers, possibly reinforced by members
of the Islamist shadow militias. According to a Human Rights Watch Report issued two days before Bashir
was overthrown, credible monitors estimated that over 70 protesters had been killed since the protests
started in December.

31. On 6 April, tens of thousands of protesters started a sit-in outside the army HQ in central Khartoum.
When NISS tried to disperse the protesters by force, some junior army officers sought to protect the sit-in
and fraternised with the protesters, even returning fire to repel the NISS attack.  The fact that the
protestors had for the first time managed to reach the army HQ and that some army elements had come
out in their support was a significant development. On 9 August, I was quoted in the Times as saying that
Sudan “can never go back to how things were before. The momentum is growing and growing, things are
moving quickly on the ground“. On 11 April, Bashir was overthrown.

32. After the TMC took over, there was a temporary lull in violence in Khartoum while negotiations started
with the FFC. However, on 13 and 16 May there were two incidents when men wearing RSF uniforms
were reported to have attacked protesters in the sit-in area in Khartoum, using live ammunition, batons and
whips. Four protestors and an army major were reported to have been killed on 13 May. A further fourteen
were injured in Khartoum on 16 May and on the same day, men wearing RSF uniforms were also reported
to have attacked youths with whips and rifle butts in El Gedaref in East Sudan.

33. The turning point was 3 June, the last day of Ramadan, when the TMC launched a large-scale
operation to disperse the protestors from the sit-in area in Khartoum by force using live ammunition. Some
130 people were shot and hundreds injured by the RSF and other security forces. There were also 70
reported cases of rape, including of female medical staff. An attempt was made to conceal some of the
bodies by throwing them into the Nile, weighted down by stones tied to their legs. At least 40 of these
bodies were recovered from the river over the following days. The tents in the sit-in area were all burnt and
the sit-in area, which was seen by the young revolutionaries as a microcosm of the New Sudan of which
they dreamed, was reduced to ashes.  The RSF also attacked the University of Khartoum, which was
within the sit-in area, destroying and looting much of the university property and killing several protesters
within the university campus.

34. Those who survived the attack on the sit-in area on 3 June fled back to their homes and erected
barricades in the streets to try to protect their local neighbourhoods. Over the next few days, the RSF
roamed the streets, attacking anyone who ventured outside.  Some activists and those involved in civil
disobedience were deliberately targeted.


-----

35. If the TMC had hoped to crush the revolution through this brutal crackdown, their tactics badly
backfired.  The June 3 massacre created huge public anger and there is now strong public pressure for
justice and accountability.

36. Since June there have been several further incidents in areas of Central Sudan involving violent
attacks against civilians by people wearing RSF uniforms, including the killing of 6 peaceful protesters,
including 5 school children, at a rally in El Obeid on 29 July to protest bread and fuel shortages. Four more
protesters were killed by government security forces using live ammunition and several wounded in a
protest march in Omdurman on 1 August to show solidarity with the victims in El Obeid.”

A46. In the remainder of her report (paras 38-46), Dame Rosalind dealt with “Nuba – specific issues”
including the threat of the RSF and any evidence of recent targeting of Nuba in Khartoum and the Nuba
Mountains as follows:

“Is the RSF a threat to Nuba? The influence of Arabisation on those in power

38. The RSF were originally drawn from the former Janjaweed, Arab nomadic tribes who were used by the
Bashir regime to conduct a counter-insurgency campaign against the armed movements in Darfur through
a policy of collective punishment and sexual violence against civilians. RSF forces are now also being
recruited from the Rashaida, an Arab tribe in Eastern Sudan, and from Arab nomadic tribes in Chad and
Niger. The RSF have been deployed in the counter-insurgency campaign against the SPLM/North in the
Nuba Mountains and Blue Nile as well as in Darfur.  Hemeti, the RSF commander, comes from the camelherding Abbala branch of the Rizeigat tribe in North Darfur, a large Arab tribe which spans Darfur and
Chad.  He receives advice from a group of Rizeigat politicians, who share an Arab supremacist ideology,
which was initially linked to the Arab Gathering, a pan-Arabist organisation created in Darfur in the 1980s.
Some of them were involved in recruiting Janjaweed and more recently for the RSF. Others have helped in
settling Arab tribesmen on land previously inhabited by non-Arab tribesmen who have been driven off their
lands following conflict with Arab militias or the RSF.

40. Hemeti's original goal was to use the RSF to increase his tribe's political and military power in Darfur
and, if possible, at national level. But after overthrowing Bashir and receiving strong support from Saudi
Arabia and the UAE, his political ambitions grew. Hemeti is not an Islamist but, in May, he accepted
support from a wealthy Darfuri businessman and a veteran Islamist politician, who offered to help him to
bring large numbers of tribal chiefs to Khartoum with the aim of co-opting them and expanding his political
base to weaken the FFC. But this gathering dispersed after three weeks, allegedly because of disputes
over payment. Hemeti then appears to have fallen out with the Islamists whom he accused of infiltrating
his RSF forces, escalating violence at the 3 June break-up of the sit-in and trying to frame him for what
happened. After the massive turn-out by pro-democracy protesters on 30 June, Hemeti seems to have
concluded that he would have to accept a deal with the FFC.

41. For the time being the military and civilian members of the transitional government will have a common
enemy (the Islamists). But if the Islamists are neutralised, it is possible that the military, and Hemeti in
particular, might try to regain control. Given the ethnic composition and track record of the RSF and the
ideology of Hemeti's Rizeigat advisers, this could pose a threat to the Nuba and non-Arab Darfuris.

**Is there recent evidence of targeting of Nuba?**

(a) In Khartoum

42. I have been told by two civil society contacts that Nuba and Darfuris, who had their own tents in the sitin area in Khartoum, were targeted more aggressively during the forcible dispersal of protesters on 3 June.

43. “Tea sellers”, including Nuba women, were amongst those attacked on 3 June both in the sit-in area
and near Comboni College, some distance away from the sit-in area. There are thousands of poor women
who sell tea from street stalls in Khartoum. Most of them come from the marginalised areas of Darfur and
the Nuba Mountains and have always been one of the most vulnerable groups in the city. They are often
harassed and punished by the public order police, even though they only earn two or three dollars a day for
brewing glasses of sweet tea. When the sit-in started outside the army HQ, the tea sellers set up a


-----

volunteer kitchen to prepare tea, coffee and food for thousands of the protesters. On 3 June, many of these
women were beaten and sexually assaulted. At least 6 are reported to have been killed.

44. Two days after the 3 June crackdown, the RSF arrested Yasir Arman, the Deputy Chair of the
SPLM/North (Agar faction) who had returned to Khartoum with a small SPLM/North delegation to support
the revolution and to try to initiate peace talks. A few days later, the RSF also arrested two of his
SPLM/North colleagues – Ismail Jalab and Mubarak Ardol, both of whom are Nuba.  All three were
subsequently deported to Juba. Whereas the SPLM/North delegation was targeted, none of the other FFC
political leaders were arrested.

(b) In the Nuba Mountains

45. Although the level of violence against civilians in the SPLM-North controlled areas of the Nuba
Mountains is substantially lower than it was prior to June 2016 when aerial bombing stopped, attacks on
civilians by government security forces have continued since the TMC took over in April 2019. Human
rights monitors report that there have been a number of cattle-raiding attacks against civilians, particularly
in Dalami, Heiban and Thobo counties, which are said to have been committed by men in SAF uniform.

46. According to the South Kordofan and Blue Nile Coordination Unit, the humanitarian situation in the
Nuba Mountains continues to be serious. Food stocks are reported to be depleted and the food security
outlook uncertain. Essential medicines are in short supply and there is limited access to health clinics.”

A47. At paras 47-55, Dame Rosalind commented on historical parallels between the Nuba and Darfuris
and the current perception of Nuba:

“Historical parallels between Nuba and Darfuris in relation to opposition to the Bashir regime

47. There is a close parallel between the former regime's perception of non-Arab Darfuris and Nuba
because members of both groups were suspected of being sympathetic to the rebel armed movements in
Darfur, the Nuba Mountains or Blue Nile.

48. The armed movements from Darfur, the Nuba Mountains and Blue Nile are closely inter-related and
have formed joint alliances. For example, the Sudan Revolutionary Front, which is a member of the Sudan
Call opposition alliance and the FFC, includes two armed movements from Darfur (the Justice and Equality
Movement and the Sudan Liberation Movement/Minni Minawi and one from the Nuba Mountains and Blue
Nile (the Malik Agar faction of the Sudan People's Liberation Movement/North. The largest armed
movement in the Nuba Mountains and Blue Nile (the Abdel Aziz faction of the Sudan People's Liberation
Movement/North) has also formed an alliance with one of the Darfuri armed movements.

**Has the perception of Darfuris changed?**

49. In the early phase of the revolution, there were signs of a new solidarity with Darfuris. When Bashir
and Salah Gosh initially tried to blame the protests on members of one of the Darfuri armed movements
and NISS arrested over 30 Darfuri students who were falsely accused of being “saboteurs”, the young
protestors on the streets in Central Sudan started to chant “We are all Darfur”. In April, however, some of
the protestors in the sit-in area in Khartoum started to praise Hemeti because they thought the RSF had
initially protected them from attacks by NISS. This attitude, albeit short-lived, was regarded as insensitive
by Darfuris and Nuba because of the widespread and grave human rights violations that the RSF were still
committing against civilians in Darfur and the Nuba Mountains.

**Has the perception of Nuba changed? Are there parallels between current perceptions of Nuba and**
**Darfuris?**

50. Individuals of non-Arab Darfuri or Nuba ethnic origin are both identifiable because of their darker skin
colour and have historically been looked down upon by lighter-skinned Sudanese from tribes in central
Sudan and referred to by insulting terms such as “Abid” (the Arabic term for slave). Civilians in the new
transitional government are likely to try to take a more progressive approach to dealing with ethnic
stereotypes but this racist prejudice is deep-seated in Sudanese society and is unlikely to disappear
overnight.


-----

51. Indeed, many Sudanese living in the marginalised areas feel aggrieved that they are underrepresented in the transitional government. If it had not been for the Sudan Revolutionary Front, which
initiated a meeting with other FFC members in Addis Ababa in late July, there would have been no
substantive chapter in the Constitutional Declaration dealing with the peace agenda and the issues of the
marginalised, IDPs and refugees.  The armed movements have complained that this as a sign that
Sudanese living in central Sudan still want to monopolise power at their expense and complain that their
mindset has not yet changed. It remains to be seen whether the Sovereign Council, and particularly the
military who are responsible for the security sector, will be ready to make concessions in the peace talks
that will give the armed movements and their constituencies appropriate political representation in the
transitional institutions.

**Are Nuba likely to be targeted today on account of ethnicity and perceived involvement with rebel**
**groups?**

52. As one reason for targeting Nuba is their perceived involvement with rebel groups, the situation for
Nuba (and Darfuris) is likely to improve if it is possible to reach a comprehensive agreement with the
armed movements. This is supposed to be a top priority for the transitional government. The Constitutional
Declaration stipulates that a peace agreement should be concluded within six months from the signing of
the agreement (ie by February 2020). The new Prime Minister also vowed to prioritise peace at his
inaugural press conference on 21 August.  However, it is uncertain if the February 2020 target will be met,
given that Abdel Aziz al Hilu, the leader of the largest SPLM/N faction in the Nuba Mountains, is calling for
the right to self-determination and two armies and Abdel Wahid Nour, whose Sudan Liberation Movement
still has a significant military presence in the Jebel Marra area of Darfur, has denounced the power-sharing
deal as a “betrayal of the revolution”.

53. It is too early to say how the security organs such as NISS and the RSF will treat marginalised groups
such as Nuba and Darfuris until we know whether civilians in the transitional government will be able to
exercise effective control over their behaviour and progress can be made in implementing security sector
reform.

**Does the position of Nuba differ from likely targeting of Darfuris? What conclusions can be drawn**
**from the outcome of the recent Darfur Country Guidance case in relation to Nuba?**

54. The outcome of the Darfur Country Guidance Case promulgated on 7 August 2019 is relevant to the
position of the Nuba. The Upper Tribunal (Immigration and Asylum Chamber) concluded that “the situation
in Sudan remains volatile after civil protests started in late 2018 and the future is unpredictable. There is
insufficient evidence currently available to show that the guidance given in AA (non-Arab Darfuris –
relocation) Sudan CG _[(2009) UKAIT 00056 and MM (Darfuris) Sudan CG](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XN3-P8Y0-Y9GT-11NY-00000-00&context=1519360)_ _[(2015) UKUT 00010 (IAC)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F27-STW1-F0JY-C4J7-00000-00&context=1519360)_
requires revision. Those cases should still be followed”.

55. As the position of the Nuba in regard to likely targeting on account of ethnicity and perceived
involvement with rebel groups is the same as that of Darfuris, the same conclusion should be drawn in
relation to Nuba-related asylum cases.”

A48. Dame Rosalind also addressed (paras 56-58) the issue whether a Nuba failed asylum seeker with no
political profile would be at risk on return to Khartoum:

**“Would membership of the UK diaspora place a Nuba failed asylum seeker (with no personal**
**political profile) at risk on return? Would a Nuba failed asylum seeker (with no personal political**
**profile) be at risk of ill treatment in Khartoum in the event of return today? Would a Nuba failed**
**asylum seeker (with no personal political profile) be at risk of ill treatment in the Nuba Mountains in**
**the event of return today?  Would Nuba with a political (anti-Bashir) profile be at risk if returned**
**from the UK?**

56. Civilians in the new transitional government would not regard membership of the UK diaspora or an
anti-Bashir political profile as a negative factor. Indeed, those who supported the revolution and opposed
the previous regime would be welcomed. However, it is not yet clear to what extent the civilians will be
able to exercise authority over GIS and other parts of the military-security apparatus given that security


-----

sector reform is to be left in the hands of the military institutions and the Ministers of Defence and Interior in
the Cabinet will be chosen by the TMC.

57. Nuba failed asylum-seekers could still be at risk of ill-treatment in Khartoum today as long as members
of the former regime continue to control NISS and other security organs; the National Security Act has not
been amended to remove NISS's powers of arrest and detention; and the RSF still has a presence in urban
areas. They would also be at risk in the Nuba Mountains until such time as a peace agreement is in place.

58. There is still the danger of another military take-over or of a counter-revolutionary coup by the
Islamists. Either scenario could create a hostile environment for Nuba failed asylum seekers.”

A49. At paras 59 and 60, Dame Rosalind set out her conclusions identifying that the political situation
remains “volatile” and she identified a number of indicators that would assist to clarify the political situation
for the future:

“CONCLUSION: IS THE CURRENT SITUATION IN SUDAN ONE IN WHICH IT IS SAFE TO RETURN
**NUBA? HOW LONG WILL IT TAKE FOR THE POLITICAL SITUATION TO CLARIFY?**

59. The power-sharing agreement is an important step towards democratic transition. But the political
situation in Sudan remains volatile and it is too soon to predict where Sudan is heading. We are still in
unchartered territory and it is premature to say with confidence that it would be safe to send Nuba back.

60. It is difficult to tell how long it will take for the political situation to clarify but the most relevant indicators
would include:

- signature of a comprehensive peace agreement with the armed movements, particularly with Abdel Aziz
Al Hilu's faction of the SPLM/North, which has the largest presence in the Nuba Mountains (according to
the Constitutional Declaration, a comprehensive peace agreement is supposed to be completed within 6
months - by February 2020)

- evidence that civilians are no longer being attacked by government security forces in the Nuba
Mountains and that humanitarian assistance is being provided to SPLM/North controlled areas

- the start of security sector reform, including amendment of the National Security Act (in accordance with
the Constitutional Declaration) to remove GIS powers of arrest and detention, plus evidence that this is
being implemented in practice

- the withdrawal of the RSF from the streets of Khartoum and other cities and from any law enforcement
activities

- evidence of progress in restoring the rule of law and respect for human rights and establishing an
independent judiciary

- General Burhan hands over the chairmanship of the Sovereign Council to one of its civilian members in
21 months' time (June 2021). This would be a significant milestone.

- holding of free and fair elections in three years and three months (2022)”

_5. Addendum Report “On the current political situation in Sudan and the risks involved in returning failed_
_Nuba asylum seekers to Sudan” (17 October 2019)_

A50. In her final written report, Dame Rosalind dealt with the current situation following a visit by her to
Khartoum between 28 September and 9 October 2019. She identified a number of positive developments
including the appointment of the new prime minister, Abdalla Hamdok (para 3). She noted that those to
whom she had spoken – both Sudanese and international – agreed that the political situation was still very
fragile (para 2). She noted that the government's “biggest immediate challenge is economic” (para 4). At
paras 4-5 Dame Rosalind said this:

“4. But one of the Government's biggest immediate challenges is economic. After 30 years of the Bashir
regime, the country is bankrupt, with no foreign reserves, high inflation, a sharply devalued currency,
pervasive corruption and key sectors of the economy controlled by the deep state. Although the new
t h l b i ffi f i k th i th t it h i d t h ld


-----

prove short-lived if it is not able to deliver early and tangible improvements in people's lives, particularly in
relation to food, fuel, water, electricity and transport. The Government is already being criticised for moving
too slowly. Hamdok has had to do a lot of international travel to New York and Sudan's neighbouring
countries in his first six weeks in office but people are complaining that, when he is away, the Government
is paralysed.

5. International goodwill is yet to be translated into practical economic assistance, apart from some wheat
and fuel that is being supplied by Saudi Arabia and the UAE. Sudan's debt arrears and the US designation
of Sudan as a State Sponsor of Terrorism will have to be addressed before the new Government can
access financial assistance from the IMF and World Bank. The US have indicated that they will not be able
to provide any economic assistance in the short-term are looking to the Europeans and the Gulf states to
help in the meantime. But the Sudanese people are impatient to see immediate improvements in their
lives. The Government is trying to manage expectations and plead for patience. But it will need to
demonstrate that it is doing something to deliver an improvement in basic services and living standards.
Otherwise it could face renewed street protests, which could, in turn, open the door to renewed violence on
the streets by the security forces and the ill-disciplined paramilitary Rapid Support Forces (RSF).”

A51. At para 6, Dame Rosalind said:

“6.  There is very strong public pressure for justice and accountability for the human rights abuses
committed during the December revolution, particularly in the 3 June massacre when the demonstrators in
the sit-in area outside the military headquarters were forcibly dispersed. The Government has set up an
investigation committee but the power-sharing deal between the military and civilians is likely to be a
constraint if, as expected, the finger is pointed at some of the military members of the Sovereign Council.”

A52. At para 7, Dame Rosalind stated that the peace talks may remain tough particularly given that al Hilu
is seeking

“substantial devolution of power to the regions, the need for a secular state and comprehensive security
sector reform.”

A53. At para 9, Dame Rosalind said that the military members of the SC still wield “considerable power”.
She also said that Hemeti “is now regarded as the most powerful man in Sudan”. She went on to state
that:

“He is using his immense wealth from these mercenary activities and from his large and expanding
business empire, including gold mines in Darfur and elsewhere, to build his political constituency among
tribal chiefs and Arab tribes. His RSF officers are reported to have been doing a lot of community work in
provincial areas around Sudan, which is widely interpreted as a sign that Hemeti is already on an unofficial
election campaign trail. He is also trying to polish his image (further tarnished by the RSF's involvement in
the 3 June massacre in Khartoum) by leading the government negotiating delegation in the peace talks in
Juba with the armed movements. But many Sudanese worry it may only be a matter of time before
Hemeti's mask slips.”

A54. At para 10, Dame Rosalind said that the threat to the “transitional government is that of a counterrevolutionary coup by Islamic hard-liners from the Bashir regime”. She said that the concern was that
Islamists may try to “stoke violence” during a demonstration planned for 21 October.

A55. At para 11, Dame Rosalind said that if Hemeti or the hard-line Islamists were to overthrow the current
government this would pose a threat to all Sudanese democratic forces and that Sudanese of Nuba or nonArab Darfuri origin could be particularly at risk.

A56. Nevertheless, at paras 12-13, Dame Rosalind set out a number of positive changes that have taken
place as follows:

“12. For the Sudanese middle class living in central Khartoum and foreign visitors such as myself, there
have been several tangible signs of positive change:

- It is much easier for foreigners from Western countries to get a Sudanese visa


-----

- The atmosphere in the city felt much freer than under the Bashir regime. I was not conscious of being
followed by national security.

- Central Khartoum looks peaceful and seems to have returned to normal after the violence used by
security forces against peaceful protestors from December 2018-June 2019.

- The national security presence at Khartoum airport seems to be much lighter than before

13. The transitional government has started to take some reform measures. For example, it has:

- launched peace talks with the armed movements and released some POWs

- dismissed all the Vice-Chancellors of Sudanese universities

- dismissed most Under-secretaries who were affiliated to the former ruling party and appointed new ones

- dismissed the former Chief Justice and Attorney-General and appointed new ones nominated by the FFC

- dismissed the head of Sudanese state radio and television who defended the RSF's role in the 3 June
massacre

- signed an agreement to allow the UN Office of the High Commissioner for Human Rights to set up a fully
mandated office in Sudan

- promoted women to top posts (Chief Justice, Foreign Minister, Vice Chancellor of Khartoum University)

- announced that journalists will no longer be arrested

- acknowledged the existence of cholera in Sudan, allowing the country to access vaccines from the WHO
(something the previous regime had refused to do).”

A57. At para 14, Dame Rosalind stated that a number of elements of the “old regime” are still in place:

“14. However, the process of change has only just started and many elements of the old regime are still in
place. For example:

- Apart from the removal of Under-Secretaries, the entire civil service is still controlled by the deep state.

- The same applies to the judiciary, apart from the Chief Justice and Attorney General

- The army, police and security apparatus from the old regime are still in place.

- The presence of the RSF in the centre of Khartoum is much smaller and less visible than before but they
are still deployed around strategic and military installations and resentment about their role in the 3 June
massacre continues to simmer. Many Sudanese are worried that they could be reactivated at any time.

- The Islamist shadow militias have not been disbanded.

- The Defence and Interior Ministers are generals who were appointed by the Transitional Military Council.

- The impact of the revolution has not yet been felt at all outside Khartoum. The people running the state
governments are still the senior army officers appointed several months ago by General Burhan.”

A58. In relation to the position of the Nuba living in Khartoum, Dame Rosalind reported on a meeting that
she had with six young Nubian men in Omdurman on 7 October at paras 15-25 as follows:

“Has there been any change for Nuba living in Khartoum?

15. I spoke to a group of six young Nuba men, all of whom were lawyers or teachers, at the office of
Justice Africa (Sudan) in Omdurman on 7 October. I asked them whether the position of Nuba had
changed since the new transitional government took over in early September.

16. They all said that, as far as they were concerned, nothing had changed. “We don't think change has
taken place in Sudan yet”. They described Hamdok as a man from the centre, not a leader of the
revolution, adding that all his advisers were from the centre.


-----

17. They said they had all supported the December revolution and had taken part in the sit-in. At that time,
everyone had mixed in together. But after the political agreement and constitutional declaration were
signed, they felt they had been excluded again by the Forces for Freedom and Change, and the Sudanese
Professionals Association. They regarded these as elitist groups representing the interests of the centre
who did not consult the marginalised groups on an equal footing and wanted to keep the status quo so that
they could continue to run things. Sudan needed radical structural changes and a change in mentality if
there was to be a genuine “New Sudan” built on equal citizenship.

18. They complained that there were very few Nuba in the new Government. The only Nuba in the Cabinet
was the Minister of Agriculture. One of the five military members of the Sovereign Council, Shamseddin
Kabbashi, was also a Nuba but he had been a collaborator with the Bashir regime. “We can't live together
unless everyone accepts diversity”. There was still insecurity in the marginalised areas. “We can't talk
about peace until there is a peace agreement and people can return to their homes. Wars could restart at
any time”.

19. The same policies existed and no one in the new government was speaking up for the interests of the
Nuba and other marginalised people. Most of the Nuba were still living in the slums in the outskirts of
Khartoum and other big towns or in refugee camps in South Sudan, Kenya and Uganda. Some have been
there for a long time. There were no services in the areas where the Nuba lived in Khartoum and
Omdurman. No one in the new government seemed to care about this.

20. The Sudanese media was still biased to Arab culture and was still portraying Sudan as a Muslim state.
Female TV presenters still all had pale skins and wore the hijab. The school curriculum was still biased
towards Arab culture. No one in the new government was talking about changing this to reflect the diverse
cultures of the country. People from the marginalised areas still had limited promotion opportunities in most
sectors and professions. Nor was the Government pursuing the issue of justice for ethnic cleansing in the
Nuba Mountains. Issues of identity, social justice and recognition of diverse cultures had not yet been
addressed by the new government. If not addressed, the Nuba would press for self-determination.

**Are Nuba still being targeted in Khartoum?**

21. I asked the six young Nuba men whether they thought that Nuba were still being targeted in Khartoum
since the new transitional government had taken over or whether their lives had improved. They said that,
since the revolution, the Public Order Law was no longer being enforced in central Khartoum but it was still
being applied in Nuba-majority areas in the outskirts of Khartoum and Omdurman. For example, the Public
Order Police were still harassing tea sellers and food sellers (many of them Nuba women) in Dar es
Salaam, Umbadda, Haj Yousif and El Fatih 1 and 2 (relocation areas for displaced people on the very edge
of Omdurman). They were still being taken to summary courts and lashed or fined. The police, the judge
and the prosecutor would then share out the proceeds of the fines between them. Because these women
were poor, they could not afford lawyers and did not know their rights.

22. Two of the young Nuba men in the group recounted that, two weeks before our meeting, they had
been sitting drinking tea on the pavement at a tea seller's stall in one of the Nuba majority areas of
Omdurman when a police lorry came along, stopped and searched them. They had been taken to a police
station for no apparent reason and subsequently released without charge. They said that this kind of
harassment was still continuing in parts of the capital because police officers from the previous regime
were still in place.

23. One of the young Nuba men in the group raised the treatment of Christians. He said that, although the
new Minister of Guidance and Religious Endowments had affirmed the country's religious diversity and
talked about giving more freedom to non-Muslims, this had not materialised yet. The Ministry was still
entirely controlled by Muslim officials from the old regime and the judiciary was still unreformed. When
Abdel Aziz al Hilu, the leader of the SPLM/N - Al Hilu faction had met Hamdok in Juba, he had told him that
one of his movement's key demands in the peace talks was that Sudan should become a secular state and
that President Nimeiri's decision in 1983 to impose Sharia Law throughout the country should be reversed.
But Hamdok had insisted that this was a national decision that could only be taken in the national
constitutional conference


-----

24. The point made by my Nuba interlocutor about the continuing harassment of Christians is borne out by
a decision taken by the Supreme Court on 7 October to confirm criminal charges against the executive
committee of the Sudanese Church of Christ, a predominantly Nuba denomination, who were accused of
refusing to hand over Church property to an unelected church committee appointed by the Bashir regime.

[24]. I have heard from a different source that Nuba youths in the poor areas in the outskirts of Khartoum
and Omdurman are also being targeted for recruitment into the RSF.  The tribal leaders who have been
paid generously by Himiti to recruit for the RSF are doing so both among people in their home areas in
Southern Kordofan and among their own tribe in Khartoum.

25. The report by the Home Office entitled “Sudan: Political Situation Update” (October 2019) states in
paragraph 31 that the Country Policy and Information Team (CPIT) was not able to identify information of
targeting of Nuba by the state in Khartoum or surrounding cities in the sources consulted, which are listed
in the bibliography. However, none of the sources in the bibliography directly address the situation of Nuba
in Khartoum and the CPIT does not appear to have spoken to any Nuba either in Sudan or in the diaspora
to ask them about their views and their experience in recent months.”

A59. As regards the position of Nuba in the Nuba Mountains, Dame Rosalind dealt with this at paras 26-32
referring to a number of incidents in 2019 involving the RSF:

“Targeting of Nuba in the Nuba Mountains

26. A unilateral ceasefire by both parties to the conflict has been in place in the Nuba Mountains since
2016. Following the formation of the transitional government, Abdel Aziz al Hilu, the leader of the largest
SLM/N faction, signed an agreement with the new government on 11 September 2019 declaring his
readiness to take part in peace talks in Juba starting in mid-October.

27. However, not much has changed on the ground until now. Southern Kordofan is still under a state of
emergency. The military Governor is still in place, the Popular Defence Force (an Islamist militia created by
the National Congress Party) is still operational and the police are still the same.

28. There are still reports of continuing insecurity. For example, on 4 October, RSF forces recruited from
the Hawazma and Salamat (Arab nomadic tribes), attacked the Nuba village of Tongal in Habila locality,
using 25 pick-up trucks with mounted machine guns. General Himiti, the Deputy Chair of the Sovereign
Council and RSF Commander, and Shamseddin Kabbashi, a military member of the Sovereign Council
(who is himself a Nuba from the Gulfan tribe)) have been busy since May recruiting youth from both Arab
tribes and Nuba tribes in government-controlled areas to join the RSF. Kabbashi and Yasir Al Atta, another
military member of the Sovereign Council, have also been trying to encourage the nomadic Arab Dar
Naeele (a branch of the Hawazma tribe) to change their migration path southwards during the dry season
from their traditional route through government-controlled areas to a route through Habila, which is the
territory of the Gulfan, a Nuba tribe, and which is very close to the SPLM/N front line. Kabbashi is also
reported to have tried to bring in SAF soldiers to accompany the Arab pastoralists on their migration route.
SPLM/N sources thought that this looked like a ploy to provoke a conflict and give SAF a pretext to capture
some of their territory ahead of the peace talks starting in Juba. On 5 October, Kabbashi is reported to
have met with Chiefs from both the Gulfan and Dar Naeele and given each of them SDG 500,000 to unite
against the SPLM/N.

29. On 16 October Abdel Aziz al Hilu's spokesman announced that RSF soldiers in 25 Landcruisers had
ambushed civilians inside SPLM/N-controlled territory near Khor Waral in Habila locality, abducting 13
people, and killing two, including a local Sheikh who had objected to the local nomads passing through
farmland. Abdel Aziz accused the government of supporting the Hawazma against other tribes in the
region and violating the ceasefire and announced that he was therefore suspending negotiations until there
was an immediate ceasefire, a full investigation and detainees were released. General Burhan responded
immediately by announcing a ceasefire throughout the country. Mohamed el Taishi, a civilian member of
the Sovereign Council and spokesman for the government's negotiating team in Juba, strongly
condemning the incident, pledging to investigate and hold the perpetrators accountable. This incident
shows that the security situation on the ground is still extremely volatile.


-----

30. In a separate incident on 7 October, the RSF mounted an attack on people living near the gold mines
at Talodi, using 27 armed pick-up trucks. They beat and arrested civilians, injuring ten people, and looted
their property. Demonstrations by local residents had been going on for months over the use of mercury
and cyanide by gold-mining companies which they said had caused serious health and environmental
problems. Most of these companies are owned by the RSF and the security apparatus. Under pressure
from these protests, the Governor of Southern Kordofan had ordered the companies to close their factories
but when they refused to do, angry protestors stormed the gold mining plants and burnt down four of the
factories and the vehicles of the companies operating them. On 4 October, the spokesman of the
Sovereign Council condemned the environmental protestors as “armed groups of saboteurs”. Residents of
Talodi staged a big march on 7 October to denounce the statement by the Sovereign Council on the
grounds that it had not acknowledged the justice of their cause and had falsely accused them of being
armed. The six young Nuba men I interviewed in Omdurman were particularly angry about this statement
because they thought it showed that the Sovereign Council were ignoring the grievances of the Nuba and
defending the vested interests of their own members.

31. Tom Catena, the well-known American doctor who has worked in a hospital in the Nuba Mountains for
the last decade, said in an interview in September 2019 that “the region remains a war zone”. There are
several reports from the HUDO Centre, that, because of the state of emergency in Southern
Kordofan/Nuba Mountains, Sudanese security forces and militias have been carrying out arrests at will
even since the formation of the new government.

32. If the RSF and other security forces are still attacking civilians in the Nuba Mountains, it is difficult to
be confident that they could be relied upon to protect the rights of Nuba failed asylum seekers in
Khartoum.”

A60. At paras 33-35, Dame Rosalind reiterated her view that Nuba were particularly targeted under the alBashir regime like the non-Arab Darfuris. Noting the ongoing peace talks, at para 35 Dame Rosalind
commented on the effect those peace talks might have on social attitudes as follows:

“35. The peace talks between the armed movements and the new government that have just started in
Juba are designed to produce a comprehensive peace agreement with four tracks covering Darfur, the
Two Areas, Eastern Sudan and the North but starting with thematic issues in recognition of the fact that
many of the issues facing the Nuba Mountains are common to all the marginalised areas. It is too soon to
tell how the peace talks will go. But even if the talks succeed, signing a piece of paper is unlikely to change
social attitudes and mindsets overnight. Problems related to ethnic, religious, cultural and social
discrimination may continue for some time and will require further reconciliation efforts.”

A61. At paras 36-37, Dame Rosalind reached her conclusion that the new transitional government is an
important step but the political situation was still “very fragile and volatile”. Based on what she had set out
concerning continued attacks on civilians in South Kordofan and what she was told by the six young
Nubian men about the situation in Khartoum, she concluded that:

“It would be too early to conclude that it is now safe to start returning Sudanese failed asylum-seekers of
Nuba origin to Sudan”.

A62. For Dame Rosalind (para 37), the position of Nuba is the same as that of non-Arab Darfuris as
determined in the UT's CG decisions.

_6. Oral evidence (24/25October 2019)_

A63. In her oral evidence at the October hearing, Dame Rosalind stated that the military retains effective
power of veto in the SC as any decisions could only pass with a majority of two thirds of the members.
She said that two members of the cabinet had been nominated by the military, namely the Minister of
Defence and the Minister of the Interior. She said that Hemeti was the most powerful man in Sudan and
that his RSF forces were active in the Nuba Mountains including the recent incident she had identified in
her report where civilians in a gold mine in South Kordofan, which was owned by Hemeti and by members
of the NISS, were attacked. She said that the powers of the NISS (or GIS) remained under the National


-----

Security Act which had not yet been amended to remove powers of arrest and detention because the
Legislative Council had not been formed.

A64. Dame Rosalind stated that the “deep state” had not been dismantled and that Islamists remained in
control of the main businesses and companies. Dame Rosalind said that the threat of an Islamic counter
revolutionary coup was a real one. She highlighted the failed coup attempt in July 2019 and that the Nuba
could be at risk were a coup to materialise.

A65. In relation to the demonstration on 21 October 2019, she said that the Islamists had not taken part
although there had been reports of incidents of Islamic activity in the days leading up to those protests.
She said that the Islamists and NCP (the previous ruling party) may seek to stand in the next elections in
three years' time and there is concern that the “deep state” machinery might be able to rig those elections.

A66. Dame Rosalind said that the economic future of Sudan posed a “serious threat” to the administration.
If the economic situation was unresolved, in her view, this posed a threat of growing discontent with the
new government and if there was no tangible change there was a risk that the government would fall. If
this were to happen, her view was that the Nuba would be targeted again by those who supported the
policies of al-Bashir and by the RSF. She said that a further threat to stability was the position taken by al
Hilu, the predominant group within the SPLM-N, in making demands for self-determination and a secular
state. She stated that al Hilu had signed a preliminary document in Juba on 21 October which was a road
map for negotiations and a preliminary agreement on how to handle the agenda. It was not, however, a
peace agreement and the talks were to resume on 21 November 2019. She said that the likelihood of a
peace agreement depended on how the transitional government, including the civilians and military, were
willing to compromise for peace.

A67. Dame Rosalind said that the RSF had signed an agreement for the forthcoming peace talks and a
joint cessation of hostilities in the South Kordofan region. This would allow humanitarian access to areas
under their control. The government had agreed that that assistance could come from outside Sudan as
well as internally.

A68. Dame Rosalind commented on a Home Office document, CPIT “Response to an information request”
dated 23 October 2019 (“CPIT 1” below), where the comments of an official of the British Embassy in
Khartoum were reported that contacts had expressed surprise at the suggestion that Nuba people were
subject to systematic discrimination in Khartoum. She noted that the document did not state whether the
Embassy had spoken to any Nuba people.

A69. Dame Rosalind said that the tea sellers, whom it had been reported were harassed, were all Darfuri
or Nuba women displaced from their home areas. She said that the Public Order law was applied with a
wide discretion to detain, for example against women wearing inappropriate clothing. She said that those
Nuba men to whom she had spoken, one of whom was a lawyer and another a teacher, had given
examples of day-to-day harassment in the shanty towns which was a Nuba majority area. She also said
that there was recruitment by the RSF of individuals who were forced to fight against their own
communities.

A70. Dame Rosalind stated that there were “close parallels” between the Nuba and Darfuris. First, both
had been victims of historical marginalisation dating back to British rule which had been continued and
magnified by their treatment by the al-Bashir regime. Secondly, they had suffered at the hands of the
government having been targeted in Khartoum because of perceived association with rebel forces. Thirdly,
they were both exposed to social and economic discrimination in the shanty towns and were often forcibly
evicted by the government who wanted to redevelop land. Both Nuba and Darfuris felt under-represented
in the transitional government. She said that although General Kabbashi was a member of the SC and a
Nuba, he had been a member of the former al-Bashir regime and so did not provide a good example of
how Nuba were represented.

A71. When asked about the return of Nuba now, Dame Rosalind said that it was too soon safely to return
failed asylum seekers of Nuba origin because of the continuing fluidity of the situation and what might


-----

happen over the transitional period. There were a number of threats to the current government and if the
military took over there would be a more hostile environment for the Nuba.

A72. In cross-examination, Dame Rosalind stated that there were no accurate figures of the number of
Nuba in Khartoum but said that it could be as many as 1.5 million. Not all lived in the 'Black Belt'. Those
shanty towns traditionally had particularly intensive security presence and informers to keep an eye on
what was going on.

A73. Dame Rosalind said that the political threat in 2019 was different from previously. She stated that
there had been a change in 2019 and what was crucial was when Hemeti stopped supporting al-Bashir and
arrested him in April. She said that the crackdown in June 2019 was very significant because the military
came to realise that the revolution could not be crushed and that they had to do a deal with the FFC. She
said that the potency of the military intervention in Darfur and South Kordofan had “significantly declined”.
She said that the threat in 2008/2009 was primarily military but the current fear was economic and a
takeover by Hemeti and the Islamists.

A74. With regards to the position of the Nuba in Khartoum, she said that some had managed to go to
university but the majority lived in shanty towns and an underprivileged existence. She stated that a
significant number of Nuba were Christian and that that could affect the risk to them. She said that Darfuri
students were targeted because of their association with rebel groups. She stated that Darfuri students
were seen as politically active. The Nuba, she said, were associated with the SPLM-N. She said that
there was no evidence that in early 2019 the Nuba had been specifically targeted prior to the fall of the alBashir regime. There was also no evidence of Nuba randomly being arrested.

A75. When asked about the position of failed asylum seekers on return, Dame Rosalind said it was not
clear whether there was any systematic procedure in place to monitor failed asylum-seekers on return.
She said that she was unclear what efforts were being made to monitor failed asylum seekers and she
expressed the view that the Sudanese might also want to keep any such monitoring from the authorities.
She said that it might be expected that mistreatment, if it occurred today, would come up on social media.
She said there was no evidence that the British Embassy has checked or monitored any impact on failed
asylum seekers on return. Dame Rosalind also said that there was still a NISS (GIS) desk at the airport
but that checks were more cursory than before.

A76. Dame Rosalind said that at the time of al-Bashir's overthrow in April 2019, the NISS mindset was to
suspect failed asylum seekers of Nuba ethnicity with involvement with SPLM-N. She said that there was a
concern that the remaining NISS members at airports would not have changed their mindset and there
remained a risk that Nuba failed asylum seekers would be subject to ill-treatment.

A77. Turning to the events of early 2019, Dame Rosalind stated that there appeared to be little focus upon
ethnic background. She said that there had been a degree of opening up of democratic space and a
strengthening of civil forces by the appointment of independently-minded persons and a commitment by
the civilian Prime Minister and his cabinet to put in place a radical set of reforms and dismantling of the
'deep state' as set out in the Constitutional Declaration.

A78. Dame Rosalind said that following the 3 June 2019 protests, in which large numbers had been
involved, the authorities had realised that strong armed tactics no longer worked. There were external
pressures, economic and otherwise on the authorities. She referred to the developments by the current
authorities including the announcement of an independent inquiry into the 3 June events. The civilian
Prime Minister had appointed a prominent human rights lawyer with power to prosecute as the head of the
committee. She said that eight senior military officers had been charged with crimes against humanity
following a military inquiry.

A79. Dame Rosalind stated that the civilian Prime Minister had “done a good job” and that there were fine
people in the Cabinet. Dame Rosalind also said there had been the appointment of a new Chief Justice
and Attorney General nominated by the civilian government. She said that the Attorney General and the
Ministry of Justice were discussing more far-reaching legal reforms in Sudan.


-----

A80. Dame Rosalind said that the combination of vested interests of powerful groups (in particular the
military), economic challenges and uncertainty and the risk of a lost credibility on the part of the civilian
government in the absence of future economic stability, made the transition process uncertain.

A81. When asked about the threat from Hemeti and the Islamists, Dame Rosalind said that that the
Islamists posed no immediate threat. It looked, she said, from a political point of view as if their strategy
was to prepare for the elections in three years' time. Dame Rosalind said that the most likely scenario was
that Prime Minister Hamdok would not survive the three-year period until the elections and that the military
may withdraw their co-operation because of their own interests. Nevertheless, she said that the Prime
Minister and civilian cabinet were committed to economic and security reform and to dismantling the 'deep
state'.

A82. Dame Rosalind said that the present government, following a speech in September 2019 in Geneva,
had indicated that a new UNOHCR office would open in Sudan and that this was a quite different view than
previously taken by the Sudanese authorities.

A83. In re-examination, Dame Rosalind was asked whether Nuba ethnicity and the fact that having
claimed asylum overseas would create a risk. She responded that this was a difficult question to answer,
except that the security apparatus was still in place and that returning asylum seekers might be in a
different category. It would depend on how the NISS (GIS) at the airport behaved. They might well be
constrained by the new government which has a different approach. She said that she did not have any
information. She said that under the old regime a returning Nuba might have been at risk as suspected of
being involved with the SPLM-N and might have been detained. She said the same people (the NISS)
were involved today but that she did not have any evidence as to how they were treating failed asylum
seekers.

A84. In relation to very recent events on 21 October 2019, Dame Rosalind said that the reformers were
going to protest and the Islamists too and a clash was feared. However, the Islamists failed to get, as she
put it, “their people out on the street”. A factor may have been that the military made it clear to the
Islamists they would not be able to approach anywhere near military headquarters. They had not sided
with the Islamists on 21 October.

A85. In relation to the Nuba men that she met in Khartoum on her October visit, Dame Rosalind stated
that there were six Nuba men whom, she thought, were activists in the community. Some of these
individuals had spoken of a personal experience of harassment within the two weeks prior to the meeting.

**B. Madeline Crowther**

A86. We also heard, and read, evidence from Madeline Crowther who is an Executive Director and Head
of Communications, Research and Asylum at Waging Peace, an organisation which campaigns against
human rights abuses in Sudan. She gave oral evidence before us at both the 31 May/1 June 2018 and
24/25 October 2019 hearings. She also produced for the initial hearing a document entitled “Risks to
Individuals from Nuba Mountains in Sudan” (March 2018) prepared under the auspices of Waging Peace.
She also produced three additional written reports: dated January 2019 in relation to the F-FR 2018; and
dated 27 August and 17 October 2019 dealing with the developments in Sudan following the fall of the alBashir regime.

1. “Risks to individuals from Nuba Mountains in Sudan” (March 2018)

A87. In her oral evidence Madeline Crowther adopted as her statement the Waging Peace report, “Risks
to Individuals from Nuba Mountains in Sudan (March 2018). She stated that in compiling this report she
had consulted a number of organisations such as Oxfam and Amnesty International and also Dr Tom
Catena who worked in the Nuba Mountains region together with members of the Sudanese diaspora
community. She said that Waging Peace did not pursue a political agenda other than peace in Sudan.

A88. The Waging Peace report is a detailed one. The “Executive Summary” sets out the position
recognising that individuals of Nuba ethnicity are at risk in Sudan as targets of the war efforts in the Nuba
Mountains, the regime's campaign of 'Arabisation' and the association of the Nuba with rebel groups. The


-----

summary also notes the return of a number of individuals as failed asylum seekers who alleged that they
were subsequently detained, interrogated, ill-treated and tortured. The summary is as follows:

“Individuals of Nuba ethnicity are at risk in Sudan, both as targets of a war effort in the region itself, and of
the regime's campaign of 'Arabisation' and association of 'being Nuba' with rebel loyalties, that makes them
ready targets of persecution, ill-treatment, torture, or worse, and particularly so in Khartoum, where
security, military, and police officials are headquartered. This, as well more systemic forms of
discrimination - limiting Nuba individuals' access to equal citizenship, employment, religious freedom,
education, healthcare, and housing - present intolerable obstacles when trying to relocate internally to the
capital.

This risk is increased at times of political upheaval, because of the perception that all Nuba are associated
with, or at least sympathetic to, rebel and opposition activity. Given the wide-scale protests in early 2018,
which were marked by the arrest and ill-treatment of hundreds of opposition figures, this is a particularly
inopportune and dangerous moment to arrange removals, and will likely remain so for the foreseeable
future.

Nuba individuals will also be at high risk due to their profile as rejected asylum-seekers. The recent
normalisation of relations between Sudan and various EU Member States has led to the return of many
individuals that allege they were subsequently detained, interrogated, ill-treated, and tortured, whereas
others have simply disappeared on arrival. This testimony supports the conclusions of our work on the
issue of post-deportation risk over more than six years.”

A89. The report sets out the background to the war in the Nuba Mountains which has its roots in the
Sudanese civil war that ended in 2005 with a Comprehensive Peace Agreement and the cessation of
South Sudan as an independent country in 2011. The report notes that the war resumed in the Nuba
Mountains in June 2011. The report comments on the nature of the conflict as follows:

“…it was noted that the Sudanese government placed even more of an emphasis on disrupting civilian
lives there. Attacks focused particularly on civilians, disrupting farming schedules, and using indiscriminate
and targeted bombing of civilian targets like schools and hospitals. We asked Dr Tom Catena, currently the
only surgeon present in the Nuba Mountains, to comment on the bombing. He responded in an email dated
07.02.18:

'… the areas bombed were not military barracks or even places which had any strategic importance. They
were random market places, schools, hospitals (ours included twice) and farming areas. Many casualties
of the aerial bombardments were civilians who were far from the front lines. We also had many civilians
wounded as a result of indiscriminate artillery shelling.'

The government has also blocked the delivery of humanitarian aid to the region for years, but as this issue
has now been subsumed within wider political negotiations, it remains deadlocked.

The situation on the ground has largely played itself out away from public attention. International NGOs
and humanitarian agencies were already largely absent in the Nuba Mountains, and in 2011 were in any
case still reeling following their 2009 en masse expulsion after the indictment of President Omar Al-Bashir
by the International Criminal Court. Press coverage of events in the Nuba Mountains is almost nonexistent, following the regime's deliberate obstruction of media freedom. Covering the conflict in South
Kordofan has become a 'red line' issue for NISS, who are tasked with keeping the press in check. In its
2013 Freedom on the Net report, Freedom House commented on the prosecution of a number of activists
for their coverage of the conflict areas in Southern Kordofan.

In fact, one of our interviewees for this report whom we spoke to on 16.11.2018 (Ms B, an interview
conducted with her in 2014 is also included in Annex I) was a former journalist in Sudan. She was tasked
with covering South Kordofan, or the Two Areas (this term is used to refer to both South Kordofan and the
Blue Nile). She described intimidation tactics including an unwarranted search of her family home, being
barred from relevant press conferences, or having an invitation revoked at the last minute, and causing
financial hardship. For instance, she was removed from a flight to attend an event, questioned by security
officials and not allowed to board More seriously she was also sometimes dragged to the police station


-----

when interviewing witnesses, and even held overnight on occasion. She says her only course of action was
to self-censor to avoid harassment. The paper for which she worked was also harassed due to the issues it
covered. Its editor had to flee abroad, sending money to his team via couriers on cross-border flights, and
paying a security guard as they were regular victims of 'random' crime like knife attacks.”

A90. The report then turns to consider the current (March 2018) situation and conditions in the Nuba
Mountains:

“The Nuba Mountains intermittently suffer from famine conditions because their farms have been
repeatedly targeted by the regime's campaign of aerial bombardment. The most reliable information about
food security comes in the form of humanitarian updates from the South Kordofan and Blue Nile
Coordination Unit, which are shared privately with agencies and NGO partners. The latest of these,
released in January 2018, stated that although January and February are historically the least lean months
in the year because of harvest times: “Based on key informant interviews performed by the CU

[Coordination Unit], it is likely the current harvest's food stocks will not last beyond April. With the following
early harvest beginning in August, this will create at least a 3 month food gap.” Furthermore, The Famine
Early Warning Systems Network reported that the rate of chronic malnutrition in SPLM-N-controlled areas
in South Kordofan was estimated at 38.3% due to long-term food deprivation and recurrent illness. Dr Tom
Catena commented on 07.02.18:

“Food security in our area is poor again this year. The rains were not very good and we had one major
flood which damaged the sorghum crops of many. There are still many internally displaced people who are
unable to cultivate to any large extent. Insecurity prevents farmers from cultivating in areas with good
farmland as they fear attack by Arab nomads and cattle raiders.”

There has been no aerial bombing activity in 2017 because the government of Sudan has been on its best
behaviour, negotiating a normalisation of relations with the United States, culminating in the partial lifting of
sanctions on the country in October 2017. Although the cessation of offensive military activity should be
celebrated, it is not indicative of a change in approach or policy towards the region by the Sudanese
government, and was driven by political expediency. It remains to be seen how the government will
respond once the next stage of the normalisation of US-Sudan relations, the lifting of Sudan from the State
Sponsors of Terrorism list, is concluded.

The media black-out on events in the region continues. For example in May 2017, the Press and
Publications Court in Khartoum convicted Madiha Abdala, former Editor of Sudanese Communist Party
newspaper Al-Midan, of “dissemination of false information”. She was fined her 10,000 Sudanese pounds
(around $1,497), for publishing an article on the conflict in South Kordofan in 2015. It would be wrong to
conclude that the lack of information coming from the Nuba Mountains suggests there is no news, an
argument sometimes cited in Home Office refusals of which we have had sight.

Meanwhile, a fresh leadership dispute within the Sudan People's Liberation Movement-North (SPLM-N)
since March 2017 has seen the movement split into two rival factions, triggering wider conflict and
displacement, though primarily centred in nearby Blue Nile state. The dispute also places at risk the
political negotiations with Sudan's government, in addition to discussions about humanitarian aid delivery.

Particularly precarious is the fate of mothers in the Nuba Mountains. According to a 2017 Human Rights
Watch report, women and girls living in rebel-held areas of the Nuba Mountains “have little or no access to
contraception, adequate antenatal care, or emergency obstetric care—leaving them unable to control the
number and spacing of their children, and exposing them to serious health complications and sometimes
death.” Moreover, the latest South Kordofan and Blue Nile Coordination Unit report in January 2018
mentioned that: “Pediatric care in particular is substantially lacking throughout the region. As reported in
August of 2017, access to basic pediatric medicines or nutritional commodity was only 22% for the Central
Region and 0% for the Western Jebels. The CU is not aware of any changes to these metrics over the last
6 months and anticipates the child population still faces substantial disadvantages in their access to health
care.”


-----

Students from South Kordofan also suffer routine harassment. For instance, as recently as January 2018,
there were mass arrests of protestors at Aldalang University in the area. Students there were
demonstrating after an officer of the Sudan Armed Forces (SAF) indiscriminately shot and killed two
students on the university campus. Joint security forces (including NISS, Military Intelligence, SAF and
police) raided the university in response, detaining at least 49 students.”

A91. The position of Nuba “as a risk category” is dealt with under a number of headings: political profile;
current political contexts; treatment by NISS of rejected asylum seekers; and recent cases of postdeportation risk.

A92. As regards whether Nuba are at risk because of an actual or perceived political profile, the report
states as follows:

_“Political profile_

It should be clear that Nuba individuals are persecuted in a direct and sustained fashion as part of the
regime's war in South Kordofan. It is of particular relevance that it is this context of conflict that provides the
basis for the persecution of Nuba as an ethnicity in Sudan. Nuba individuals are by their nature assumed to
be either an active part of, or sympathetic to, the SPLM-N, and this then often forms the basis of their
targeting and ill-treatment. It is important to note that actual membership or allegiance to the SPLM-N is not
required for this to be the case. It is sufficient for such qualities to be imputed, although of course an active
political profile would significantly increase an individual's risk profile. And besides, most Nuba individuals
are in some manner connected to the SPLM-N through large family networks.

Moreover, the number of people assumed to have a political profile varies according to how vulnerable the
Sudanese government believes it is at a given moment. Its perception of risk is due to how it assesses
external circumstances, in particular when the threat being posed originates with the SPLM-N. The
testimony of Mr C, sourced from one of our earlier reports and included in full in Annex II (we interviewed
him separately for this report, however), describes his poor treatment at the time of the elections for the
governor of the Nuba Mountains region, saying “tensions were high”. Accordingly, in late 2012 and early
2013 there were many arrests of Nuba due to their supposed, and sometimes actual, involvement in a
coup attempt by Brigadier-General Mohamed Ibrahim Abdel-Galil, better known as 'Wad Ibrahim'. Most
notably, crackdowns followed an April 2013 attack by joint forces including the SPLM-N, named the Sudan
Revolutionary Forces (SRF), in the towns of Um Rawaba in North Kordofan state, and Abu Kershola, in
South Kordofan state. The attack represented the high watermark of the rebel military advance. In
response to their humiliation, the Sudanese government arrested and detained a wide variety of Nuba
individuals accused of supporting this coalition.

We have spoken to several individuals who were targeted during this particularly restive period. One
gentleman was detained for several days and then released, only to be re-detained for sixteen days and
tortured in a manner that included sensory deprivation and solitary confinement, as well as beatings to the
head later requiring stitches. While detained he also saw several other Nuba individuals being tortured. He
eventually collapsed and had to be put on a drip. He still suffers from post-traumatic stress disorder, and a
fear of the dark.

It is therefore clear that at times of political upheaval, when the regime feels its survival is threatened, the
first targets of the security services and other actors are marginalised groups that are assumed to be from
conflict areas, and so sympathetic to the aims of rebel groups. Nuba individuals, identifiable by their skin
tone and other factors, are presumed to be associated either formally or informally with the SPLM-N, and
so often bear the brunt of these attacks.”

A93. Under the heading “Current Political Context” the report turns to the impact, if any, upon Nuba at
times when the regime is threatened:

“There is an established pattern to the crackdowns and arrests following a perceived threat to the regime's
survival. Thus it can be predicted that a Nuba individual returned to Sudan at this juncture would readily be
assumed to have a prior political profile on their arrival. Hence, they would be more likely to suffer arrest,


-----

detention, ill-treatment, torture, or worse. This period of heightened risk will continue for the foreseeable
future.”

A94. The report then returns to the treatment of failed asylum seekers, in particular by the security
services, the NISS:

“Treatment by NISS of rejected asylum-seekers

It is also important to understand how the very act of claiming asylum is viewed as a political act in Sudan.
The government sees Sudanese who have travelled abroad as more easily connected to opposition and
rebel activity, as is evident from the lines of questioning outlined in the testimonies compiled in our reports
on post-deportation risk: 'The Danger of Returning Home' (2012) 'The Long Arm of the Sudanese Regime'
(2014) and 'Recent cases of post-deportation risk' (2017). Individuals are routinely questioned about their
political activities and connections in the country that have travelled from.

During our interviews for this report, this fact was corroborated. One interviewee (Ms A) mentioned a Nuba
individual who was questioned for hours on his arrival into Khartoum about his political activities and
support for the rebels, despite having a French passport. Another interviewee (Mr C) talked about a human
rights activist who returned to Sudan in 2014 with a British passport, but was nonetheless interrogated for
one hour about the activities of the UK community group, NMSA. They believed the security officers limited
themselves to one hour because he owned a British passport. Two of those whom we interviewed, Ms B
and Mr C, had their own stories of harassment on arrival, as included in the Annexes. The testimony of
those who have returned may explain why we were told that even those people with British documentation
are fearful of returning to Sudan because of their treatment on arrival. As a consequence, they may fear
returning to Sudan even to attend the funerals of close family members, including their parents, as recently
described by Mr C. Ms A also said that she was advised by family members never to leave her British
passport at home when travelling around, for fear she would be arrested and detained without paperwork.

This fear is also owing to the fact the NISS continue to enjoy complete discretion as to who it targets and
what techniques it employs, as per the conditions of the 2010 National Security Act – judicial oversight is
not stipulated. This means the NISS makes arbitrary judgments about whom they believe has a sufficient
political profile to warrant their interest – there is no checklist they consult – and that following this
judgment, they can detain someone for up to four and a half months without independent oversight. They
are also granted complete immunity for any actions they take.

This arbitrary targeting, in addition to NISS's immunity, are the sources of the fear felt by Nuba individuals
living in Khartoum. Ms A commented as per our notes:

“Every day we heard of someone kidnapped, detained, disappeared from Nuba. We felt we had to leave,
people we knew were being detained, even killed. Normally because of political values, but government
can always level bogus charges - arrest first, ask later.”

More often, individuals are detained for only a few days if NISS cannot immediately prove wrongdoing. In
these cases, NISS's tactics change; they will release the individual, intending to collect information from
them later, at a given date, or when they re-detain them in a 'cat and mouse' pattern.29 They will usually
force a person to sign a document that releases them on family guarantee or personal security, which
obliges them not to engage in any political activities, or possibly leave the country, and gives the police the
right to detain them at any time. Several of our interviewees mentioned this tactic. Mr C commented, “If you
give information you're fine, but if you resist you face difficulties.”

A95. The report deals with a number of recent cases of claimed ill-treatment of returnees to Sudan from
Belgium, Italy and France. The report begins by identifying the claimed risk of ill-treatment, though not
uniquely to Nuba, as follows:

“The risk faced by returnees into Sudan has become particularly evident recently because of reported
cases of ill-treatment following forcible repatriation over the past couple of years. This risk is not unique to
Nuba individuals, but shared by all rejected asylum-seekers, including those from other marginalised
groups, such as non-Arab Darfuris. Therefore some of the cases outlined below do not strictly fit the profile


-----

under consideration for this report, but they do demonstrate the risks facing those returned. It is clear that
Nuba individuals returned to Sudan face a range of responses by security officials on arrival, routinely
involving arrest, detention, interrogation, and intimidation, but also regularly ill-treatment, torture, and even
death.”

A96. The report goes on to note that they are “unable to advise the returnee be met at the airport, as this
itself could put them at risk, as it would show engagement with local human rights defenders or groups,
and it would in turn put those human rights defenders or groups at increased risk”. The report then turns to
returnees from Belgium as follows:

“Belgium

In December 2017 it was reported that several individuals deported to Sudan from Belgium alleged they
had been tortured. The decision to deport them was made by the Federal Secretary of State responsible
for Asylum and Migration, Theo Francken. This followed Francken inviting Sudanese officials on an
identification mission to assess Sudanese migrants, some of whom had been arrested in a raid on a
makeshift camp in Brussels' Maximillian Park. The delegation was widely believed to have been from
Sudan's NISS, and they were allowed to question Sudanese without Belgian officials present. The episode
eventually threatened the survival of the coalition government in Belgium, as tensions mounted between
Francken, a Flemish nationalist, and Prime Minister Charles Michel from the other Francophone liberal
party, over a charter flight scheduled after the allegations came to light.

In total, the testimonies refer to nine Sudanese who were sent home, including one gentleman from the
Nuba Mountains. We are in touch with the organisation that compiled this evidence, the Tahrir Institute for
Middle East Policy. Hence we have seen the original testimonies, most of which were obtained over the
messaging service WhatsApp. All describe a period of detention on arrival at the airport and interrogation
lasting several days, then being released on family guarantee/personal security. A few describe physical
torture (being beaten with a stick) or emotional torture. One testimony is from a gentleman from the north
of Sudan. He credits the fact that he is not from one of the more marginalised areas (Darfur or the Nuba
Mountains) with his relatively benign treatment.

As it stands, the Belgian Commission which independently handles asylum claims, the Office of the
Commissioner General for Refugees and Stateless Persons (CGRS), reported that it did not find the
testimonies credible. Hence, Sudanese identification missions will continue, though with more oversight by
Belgian officials.”

A97. Then, in relation to Italy the report continues:

**“            Italy**

Italy was one of the first European governments to put in place a formal bilateral agreement on returns and
readmission. It signed a Memorandum of Understanding in August 2016 aimed at increasing police
cooperation in the fight against transnational organised criminality, and especially irregular immigration.
Like the Belgian arrangement, it included provisions for missions of officials from the respective territories
to help investigate details to facilitate returns, as well as of training and equipment for the Sudanese police.

This led to the forcible return of around 40 individuals on a charter flight to Sudan in August 2016. Again,
testimonies received by NGOs confirm accounts of detention and interrogation on arrival, with some
individuals witnessing beatings, as documented by Amnesty International. The human rights monitoring
group Huqooq also provided the testimony of a gentleman nicknamed 'Barakat'. 'Barakat' claims he was
beaten by NISS during the period the group was detained, and he has since gone into hiding. Other
testimonies seen by us also suggest that the deportees now live in fear for their physical security, as well
as that of their families, and that they believe they are being monitored by NISS, including via their mobile
phones.

Just recently, these returnees received permission to appeal their cases before the European Court of
Human Rights for violating the principle of non-refoulement.”

A98 Then in relation to France the report states:


-----

“France

There are rumours that bilateral discussions have been held between the French and Sudanese
governments to arrange for the return and repatriation of Sudanese living in France. Documents produced
by Sudan's Foreign Ministry have come to light that mention Sudanese concerns about a particular
community in a Paris suburb that Sudanese authorities wanted to see returned to Sudan, and a request for
France to share a contact database (this document can be provided on request). This letter indicates
Sudan's clear interest in the behaviour and members of its diaspora, particularly insofar as they may be
loyal or merely sympathetic to rebel and opposition activity.

A French journalist, Tomas Statius, has also recently started documenting cases where it seems
individuals slated for return to Sudan were interviewed by a Sudanese delegation, in a manner that
resembles the approach taken in Belgium. The mission delegates seemed to show particular interest in
those individuals who had been formerly imprisoned in Sudan. Mr Statius suggests this may be because
the security services are able to verify their presence and activity in the country through fingerprint
technology implemented in 2012. Mr Statius has identified four people deported to Sudan following a
Sudanese delegation visit. However, he encountered the same difficulties as we have when trying to
monitor those returnees and report on their well-being post-return.”

A99. The evidence concerning the Belgian returns featured significantly in the evidence before us both in
cross-examination of Ms Crowther and also in relation to the report of the Office of the Commissioner
General for Refugees and Stateless Persons in Belgium (February 2018) which we set out below.

A100. Finally, the report deals with internal relocation to Khartoum. The report first deals with an
individual returning to Khartoum by air and the likelihood of them being detained, interrogated and released
only on condition that they either do not leave the country or that they gather information on rebel and
opposition activities for the government. The report's author states:

“The experiences of those returned to the Sudanese capital via the airport highlight the first difficulty in
relocating internally to Khartoum. It is likely that individuals returned will be detained, and interrogated upon
stepping off the plane, and released only on the condition that they do not leave the country, or worse, that
they gather information on rebel and opposition activities to prepare for a future period of questioning. The
concentration of NISS, police, and other military or security activities in the capital means returnees will
have fewer opportunities to escape the attentions of these bodies. It is highly likely that they will be redetained at a later stage, particularly if they have signed a document on release for family
guarantee/personal security, which enables the police to arrest and detain them at any stage. This type of
process will be considerably easier if plans to digitise citizenship records under the aegis of the EU-Horn of
Africa Migration Route Initiative, in particular the Better Migration Management project run by Germany's
development body, the Deutsche Gesellschaft für Internationale Zusammenarbeit (GIZ), are carried out.”

A101. The report then goes on to identify what it describes as “systematic discrimination” faced by Nuba in
Khartoum:

“By far the biggest obstacle to Nuba individuals relocating to Khartoum are the systemic forms of
discrimination individuals face there. The routine denial of these rights and opportunities, and the
underlying racism of the Arab elite that brings Nuba individuals more readily to the adverse attention of
police and security officials, amounts to a high degree of persecution.”

A102. The report identifies areas of discrimination: citizenship, education, housing, healthcare,
employment and religion. However, before doing so, the report identifies that racial animus, linked to the
regime's stated aim to 'Arabise' the country, affects and impacts upon the Nuba:

“Racial animus/'Arabisation'

That race plays a role is clear from the language used towards Nuba individuals, both in everyday life, and
more specifically when being held by NISS or other military and security bodies. This is also the primary
factor that would easily distinguish an individual as being of Nuban heritage – their 'blackness' is what
would easily differentiate them from others in Khartoum. Mr C mentions this factor in his full testimony,


-----

included in Annex II, saying he was verbally abused because of his heritage, and we regularly hear similar
scenarios in the testimony of other Nuba asylum-seekers we support. The language of slavery is often
employed, with the word 'abid', meaning 'slave', being used. This reflects the Nuba legacy of slavery,
described above.

This residual racism also helps explain why the use of skin whitening creams is so popular among Nuba
women. Having lighter skin, or “trying to look Arab” in the words of Ms A, is seen as a gateway to success.
All our interviewees mentioned this – “everybody's whitening their skin” commented Ms A. What is more,
because these creams only work temporarily, they are a purchase individuals need to repeat in order to
see the benefits, a cost few can bear. There are also a multitude of medical side-effects that will
disproportionately affect those with Nuba heritage.

The context to this is the Sudanese regime's stated aim to 'Arabise' the country. This has historically
involved the suppression of the black, African, and animist (or other religious) expressions of Sudanese
culture, in favour of those that are Arab and Muslim. All of our interviewees mentioned attempts to erase
Nuban culture in the capital, either by omission (there is “nothing non-Arab on TV” said Ms A, or “very rare
to see black faces on TV”, said Mr C, except when the African Union is in town), or by deliberate cultural
destruction. For instance, we hosted an All Sudan Cultural Day in March 2017, and there was a
performance of Nuba dancing. Many non-Nuban Sudanese in attendance approached us afterwards and
said that they had never seen this type of dancing in their own country because of the media black-out.

Additionally, we know some people by certain names. Yet, during our interviews, these individuals
disclosed that these names are not their original or family names. Mr C said that his name, which is Arabicsounding, originated because a school teacher declared that his Nuban name was hard to pronounce. The
teacher announced that the Arabic-sounding name was Mr C's new name. It thereby appears on school
leaving certificates and official documents. Most people we spoke to expressed outrage at this now that
they are safe in the UK. Many are currently in the process of changing their names back to what they
would have been originally, and so reclaiming their Nuban identity.”

A103. As regards discrimination in the context of Sudanese citizenship, the report highlights problems
faced by Nuba as follows:

**“            Citizenship**

Often the suppression of Nuba identity is total. Hence, individuals may find deliberate or practical barriers
to obtaining a national identity card entitling them to state services and entrenching their rights, (for
instance shielding them from undue attention at road check-points). Ms B said that in order to obtain an ID
card, or a 'national number', one needs a birth certificate. Yet, in a May 2013 report on marginalisation in
Khartoum, the organisation International Refugee Rights Initiative (IRRI) found that people may further be
required to provide “a residency certificate; a nationality by birth certificate, ID, or passport; a certificate of
blood type or group and an employment letter. Nuba communities do not customarily own these, and
where they might be acquired by travelling to their home regions, it is to be noted that the costs of travel
may be prohibitive for some. The IRRI report further adds that some individuals are refused even where
they do possess these documents because they possess a 'Southern' name. Ms B said that her parents
were denied citizenship on that basis.

This denial of citizenship is crucial, because an ID card is required for access to most opportunities and
services, such as employment, housing, and education.”

A104. The report then turns to the availability and discrimination directed against the Nuba in the context
of education, housing, healthcare and employment as follows:

“Education

An ID card is required in order to sit the exams to leave secondary school, as was confirmed by Ms B. By
not taking this exam, Nuba students are then also prevented from attending university. This of course
presumes they received primary and secondary-level education. Schooling is not free, so many are unable
to afford it, or if they can, it will only be for one child out of a family of many more children. In addition, there


-----

are often few, or no, schools in the areas in which most Nuba communities live (the so-called 'Black Belt',
discussed below). This effectively bars the Nuba youth from educational opportunities.

Where individuals do get to university, their achievements may be disparaged. For instance, one Nuba
gentleman we support faced severe discrimination while at university: he had to repeat a year, and was
only given a pass grade, despite the fact that his peers, whom he had tutored, received high marks.

The suppression of the Nuban identity is also evident in attempts to eradicate languages other than Arabic
in schooling. Ms A described that during her schooling she would have her hands “beaten raw” for using
her mother tongue, rather than Arabic, in class. She lamented the fact that traditional Nuba languages are
becoming lost, as newer generations speak only Arabic. Nuba individuals are also not represented in
school textbooks or study problems. For instance, exam questions will say 'Mohammed has 5 pieces of
fruit', or so on.

Housing

As mentioned, most of the Nuba live in certain peripheral areas of Khartoum, nicknamed the 'Black Belt'.
Ms A called the conditions “heart-breaking”, describing a situation where individuals were living in slums
without permanent structures, electricity, government service provision, or even food in some cases. She
described how the slums had become 'no go' areas for other Khartoum residents. Slum dwellers are also
demonised by the public and politicians, often in ways that associate them with rebel activity.

Healthcare

There is no access to the admittedly inadequate healthcare accessible to Khartoum's other residents,
because there are no facilities in the 'Black Belt'. Article 46 of Sudan's constitution determines that
emergency and primary healthcare should be free, but, in practice, it is not. Hence the majority of doctors
refuse to work with the Ministry of Health (a figure as high as 70% according to a conversation in February
2018 with someone in the sector). There have been widespread strikes among the medical profession (as
in December 2016) in recognition of the fact that the system was near collapse.

Even were adequate healthcare on offer, Nubans would struggle to access it, because they lack an ID
card, or their ID card identifies them as a Nuba. This means they cannot access the limited health
insurance schemes on offer, and one- off payments can push poor families into 'catastrophic health
expenditure', where the sum paid would seriously disrupt household living standards.

Employment

All our interviewees mentioned the difficulties in gaining employment, even though those who spoke to
were from wealthier backgrounds and had relevant qualifications. For instance, Ms B said she had to recite
verses from the Quran in interviews, and was asked questions such as, “Where are you really from?”
because of the colour of her skin. As a result, she ended up performing outsourcing roles for a computer
company or a teaching association, where she would be paid, but her name or identity would not be
recorded. This adversely affected her ability to prove her employment history and skills to future
employers.

Ms A also described the difficulties her husband faced. From his home in Khartoum, he started an
organisation focused on development, and particularly water security, in the Nuba Mountains. However,
the government effectively barred him from work on local development projects. Mr C also said that
although there is a government-run microfinance scheme for small businesses, aimed at graduates, and
theoretically accessible to individuals from the Nuba Mountains, a successful application requires a
guarantor from the government or ruling NCP, something unlikely for Nuba to receive.

Nuba individuals sometimes limit their horizons as a result. But unfortunately, even some of the lowerskilled work available to Nuba individuals is the target of police action, as it forms part of Sudan's informal
economy. For instance, many Nuba women in the capital work as tea-sellers, while also selling a lightly
alcoholic drink called marissa. Some Nuba families even give it to children before school. There have been
numerous cases of these women being arrested or submitted to degrading punishments as a result, under
the aegis of the Public Order Laws ”


-----

A105. Finally, in relation to religion, and the fact that many Nuba are Christian, the report says this:

“Religion

Another aspect of the 'Arabisation' programme is religious. The Nuba Mountains is a fairly equal and
harmonious mix of Christian, Muslim, and animist believers. However, in Khartoum there is a sustained
assault on the right of worship and belief as a Christian, or simply as a non-Muslim. This is problematic,
because as Mr C noted, Nuba individuals often gather, or build additional infrastructure, around churches
as a place of sanctuary.

Faith-based discrimination has a long history in Sudan, and some of our interviewees described the
process by which young men in the Nuba used to have to pay a dignia, or tax, when they reached a certain
age, as they were presumed to be non-Muslim. Ms B claimed this sometimes happens even today.

The non-profit group, Open Doors, ranked Sudan the fifth-worst country in the world for Christian
persecution in 2017, ranked just above Syria. The US State Department's 2016 International Religious
Freedom report said of Sudan, “The government arrests, detains, and intimidates clergy and church
members. It denies permits for the construction of new churches and is closing or demolishing existing
ones.” The report details egregious violations of freedom of religion or belief in Sudan during 2016 and
comprehensively details a pattern of discrimination, harassment, and persecution of religious minorities in
Sudan that has worsened since the independence of South Sudan in 2011. A letter from the United States
Commission of International Religious Freedom (USCIRF) adds further detail, saying that since 2011, the
government of Sudan has arrested nearly 200 Christians, including 14 religious leaders; prosecuted three
religious leaders on spurious national security charges; demolished or partially demolished 20 churches
and threatened at least 10 others; and refused to issue permits for church construction, arguing that no
new churches are needed due to the secession of South Sudan and the presumed exodus of ethnic
Southerners, who were predominantly Christian. The government has also failed to make necessary
amendments to the 1991 Criminal Code which criminalises and permits death sentences for apostasy and
prison sentences, lashing, or fines for blasphemy.

In Khartoum specifically, there is a battle between the Khartoum State Ministry of Education, and Christian
faith leaders. On 26 July 2017, the Khartoum State Ministry of Education issued a directive requiring
Christian schools to open on a Sunday, taking Friday and Saturday as the weekend break. The Coptic
Church of Sudan was the first denomination to speak out against the order and noted that Christian
schools have been permitted to take Sunday as a holiday for religious observance since the creation of
Sudan. The matter remains unsolved at present.”

_2. Oral Evidence (May/June 2018)_

A106. Madeline Crowther's oral evidence, given at the hearing in May/June 2018, was wide-ranging. She
said that she was in regular contact with Nuba groups and her contact assessed that there were around
2,000 Nuba in the United Kingdom.

A107. She said that the Sudanese government had blocked humanitarian aid to the South Kordofan
region and the Nuba Mountains for many years and that press coverage of events there was non-existent.

A108. She said that students from the Nuba tribes were seen as being anti-government. A further
problem was that Nuba were being perceived as being sympathetic to the SPLM-N. She said that “most
Nuba individuals are in some manner connected to the SPLM-N to large family networks” and that this
gave rise to the individuals being perceived as having a political profile.

A109. She stated that there was continuing discrimination against Nuba. They were readily identifiable
from their skin and were subject to racial slurs such as “slave”, “black”, and the word “abid” was used in a
derogatory way.  The Nuba were identifiable by their dialect and customs and that religion was part of it,
they did not all follow a strict Muslim code. She said that Nuba face discrimination on the same basis as
do non-Arab Darfuris.

A110. Ms Crowther said being Nuba and a returned failed asylum seeker was a combination which put an
i di id l t h i ht d i k f ill t t t t


-----

A111. As regards the passages in the Waging Peace report concerned with returned failed asylum
seekers, Ms Crowther said that she had seen the original testimony the Belgian returnees compiled by the
Tahrir Institute for Middle East Policy. She said that, despite the view of the Belgian Commissioner, she
believed the accounts were credible because she had compared them with other cases and there were
also secret communications through WhatsApp.

A112. In relation to the returnees from Italy, Ms Crowther said that they had been in touch with human
rights groups in Sudan and they were in touch with some of those who had been detained. Forty
individuals had been returned on a charter flight in August 2016 and testimonies had been received by
NGOs confirming accounts of detention, and interrogation on arrival and some beatings. In response to a
question from the Tribunal, when asked why she had said in her report that the returnees from Italy had
been granted permission to appeal to the ECtHR which was not the process of that court, Ms Crowther
said she had obtained that information from an article.

A113. In relation to the returnees from France, Ms Crowther also said a journalist had seen documents in
relation to the returnees from France.

A114. Ms Crowther said that the NISS had complete immunity. She was not aware of any NISS officers
being reprimanded. She was not sure whether NISS had a formal policy on the Nuba. The NISS
headquarters was in Khartoum. They could be seen present at demonstrations and also family events, for
example, funerals. Their presence in Khartoum is heightened.

A115. Ms Crowther said there was a risk of interrogation and detention at the airport of up to one day.
There was a risk of re-detention later. Whether individuals would be ill-treated would depend upon what
the NISS found out. If it was discovered that they had links to the opposition they would be ill-treated but
not if they did not. If re-detained, it was likely would be asking the individual to gather information on the
community and return to them. Less likely to be ill-treated if that was the case. Individuals were likely
never to return once released as not in their interest.

A116. In cross-examination, Ms Crowther said that not all Nuba living in Khartoum were at risk. When
asked whether the incidents were random or targeted, she said that she could not comment. She stated
that many incidents were the targeting of activists referred to in the AIR Report for 2017/18. However, she
also said that she had evidence of random targeting of apolitical Nuba. She was asked about evidence
concerning 200 arrests following the January 2018 protests. She did not agree that most had been
released: she said 292 were left in detention.

A117. Ms Crowther said that Waging Peace had interviewed a detainee who had witnessed a Nuba
individual being questioned for hours on arrival at Khartoum airport about his political activities and support
for the rebels. She said that the act of claiming asylum overseas is seen by the NISS as a political act.
The NISS is not subject to judicial oversight and enjoys complete impunity.  There are no accounts of
disciplinary action having been taken against NISS officers and its headquarters and presence is greatest
in Khartoum and there is a greater likelihood of a Nuba individual being targeted in or around the capital.

A118. Ms Crowther said that the Waging Peace report referred to a journalist in Khartoum who had been
subject to ill-treatment and that she was at heightened risk as she was trying to report on the 'Two Areas'
for her newspaper. She did not agree that the journalist had passed through the airport without any
physical ill-treatment. She said she had been pulled aside and asked difficult questions. A friend had
advocated on her behalf and she had not been detained. She said that the journalist had not been pulled
aside because of her Nuba ethnicity.

A119. In relation to another individual referred to in the report – who was from the Nuba Mountains – Ms
Crowther stated that he had been studying in the United Kingdom and had been funded by the
Government Arab Company. She said that, despite his Nuba ethnicity, he had been able to obtain
government funding to study overseas. She said that his arrest was not random but because he had been
attending meetings in the UK Parliament about his home area. She said that his arrest fitted the pattern of
when the Embassy takes interest in the diaspora in the United Kingdom. She said that these were only


-----

two examples and there were dozens of others referred to in footnotes. She said that if a person was
detained they were likely to be treated more harshly if they were from one of the 'Two Areas'.

A120. Ms Crowther was, again, asked a number of questions about the sections of the report dealing with
the return of failed asylum seekers from Belgium, Italy and France. Specifically, she was asked about the
fact that the Belgian Commissioner had found the testimonies not to be credible. She did not accept that
the testimonies were not credible in relation to the Belgian returnees. She said that the inconsistencies in
the testimonies arose from the Arab language used and/or the “fraught period” experienced by the
speakers. However, in her evidence subsequently, in her answers to questions from the Tribunal, she
accepted that she had never been to Sudan and that she did not speak Sudanese Arabic.

A121. In relation to the Italian returns, she said that one witness had observed a beating at the airport but
had not himself been beaten and the second individual had been treated reasonably. She was asked
whether she agreed that the Nuba background of the individuals had not led to their arrest or ill-treatment.
She replied that one Nuba individual in a cohort considered he had been mistreated because he was Nuba
but she stated that one man stated that he had not been ill-treated because he had said that he was not
Nuba.

A122. When asked why it was that there was no evidence concerning detention after individuals had
passed through the airport, Ms Crowther said that no one was monitoring their immediate post-return
treatment. Individuals were released on an undertaking which could result in them being re-detained.

A123. Ms Crowther said that ethnic background was a gateway or indicator of political activity.

A124. Ms Crowther was also asked about conditions and circumstances in Khartoum for the Nuba as set
out in the report in relation to education, housing, citizenship and religion. She could not say how many
Nuba live in the 'back belt'. She said that individuals of Nuba ethnicity had difficulties in obtaining ID
documents and citizenship. It was harder for them to have the required documents to obtain ID. She
stated that Nuba, particularly from South Kordofan, would be able to access education if they had primary
level education but some would not have that. In relation to housing, she did not accept the proposition
that Nuba could live anywhere in Khartoum.

A125. Ms Crowther said Christians were not able to take Sunday as a holiday and could not attend
Sunday school. She said that she was not aware of any private Christian schools in Khartoum.

A126. In re-examination, Ms Crowther said that given the limited number of forced returns it was difficult to
make an assessment of risk on return as a failed asylum seeker. She said that she was aware of 143
returns to Sudan; 56 in 2007 but there were no figures specifically for returned Nuba.

A127. Ms Crowther said that there was a two-stage process at the airport: (1) with an immigration officer;
and (2) then with the NISS. The separation was not strict and there were conversations between
colleagues. Her understanding was that they worked in concert.

A128. Ms Crowther said that the Nuba were targeted because of their ethnicity. She gave an example of
children detained for organising a football game. Ms Crowther said that a number of factors would give
rise to specific concerns of risk on return for Nuba: students, those participating in demonstrations, those
engaged in political activities, those educated above primary level, those who had travelled abroad, and
those returning with documents which identified them as failed asylum seekers.

A129. Ms Crowther said, in relation to the Belgium returns, that even though the Belgium Commissioner
found the accounts not to be credible, she “would argue” that the instances tallied with dozens of accounts
Waging Peace had collected

_3. Response to the Home Office Fact-Finding Report 2018 (January 2019)._

A130. Ms Crowther produced a document in response to the F-FR 2018 in January 2019. When Ms
Crowther came to give oral evidence before us in October 2019, Mr Jacobs indicated that he did not wish
to rely on her January 2019 report and she was, as a result, not cross-examined upon it. Although, she did
refresh her memory from it. In these circumstances, we do not consider that this document forms part of


-----

the evidence relied upon by the appellant despite Mr Jacobs' reference to it in paras [120]–[123] of his final
written submissions. Given his position at the hearing, and that Mr Thomann was as a result not required
to cross-examine Ms Crowther on her January 2019 response to the F-FR 2018, we need say no more
about it. Ms Crowther's evidence is, in any event, fully detailed in her other evidence, including her more
recent “Report on the risk to Nuba Individuals in Sudan” (27 August 2019) and “Addendum report – risk to
Nuba individuals in Sudan” (17 October 2019).

_4. “Report on the risk to Nuba Individuals in Sudan” (27 August 2019)_

A131. In this report prepared for the October 2019 hearing, Ms Crowther stated that the circumstances in
Sudan have changed “quite dramatically” since the May/June 2018 hearing (para 18).

A132. Mr Jacobs draws attention to seven aspects of her evidence which we can summarise as follows.
First, the rising prominence of Hemeti who, as leader of the RSF, oversaw campaigns of violence in the
Nuba Mountains (para 19). Secondly, Hemeti and other TMC activists were involved in acts of repression
in Khartoum including the violence on 3 June 2019 in which RSF soldiers intent on committing rape and
sexual violence used racist language to women from Darfur and Nuba Mountains. Ms Crowther referred to
an article which set out Hemeti's racist language towards those occupying the sit-in prior to the violence,
referring to them as _zurgha (meaning 'dirty black') (para 21). Thirdly, the killing of tea ladies during the_
violence on June 3 (paras 22 and 23). Fourthly, the targeting of a professional national football player of
Nuba background following his participation during the June protests (para 24). Fifthly, the attacks which
took place in the 'Black Belt' after 3 June 2019 (para 25). Sixthly, the failure of the TMC to release 25
individuals of Nuba and Darfuri ethnicity who were not included in the TMC's release pardon (para 26).
Seventhly, the al-Hilu faction of the SPLM-N boycotted the signing of the agreement between the TMC and
the FFC (para 30).

A133. To her report, Ms Crowther attached a number of written responses from individuals and
organisations: including: (a) unnamed expert A (Annex II); (b) Koert Debeuf, Director of the Tahrir Institute
for Middle East Policy Europe (Annex III); (c) Mohaned Elnour, human rights lawyer (Annex IV); (d) South
Kordofan/Blue Nile Coordination unit (Annex V); (e) Sir Henry Bellingham MP, Chair of the All Party
parliamentary Group on Sudan & South Sudan (Annex VI); (f) Hafiz Mohamed, activist (Annex VII).

A134. In para 31 of her report, Ms Crowther referred to parts of the annexed material as follows:

“Sudan expert A says 'the implications of the recent changes for Nuba specifically are not easy to
measure'; and Koert Debeuf from the Tahrir Institute for Middle East Policy Europe says 'Everything is
messy now. Therefore it is risky to make an assessment that can hold for more than one week.' The AllParty Parliamentary Group, in their submission at Annex V1 said, 'The APPG for Sudan and South Sudan
has heard from senior officials in the British Government who believed that the situation in Sudan had
drastically improved only to give a more cautious opinion within a matter of days after the situation
deteriorated rapidly. Given that the situation is unstable, at this point it is inappropriate to consider South
Kordofan safer under the current regime than it was under the old regime.'”

A135. Ms Crowther said, based upon their responses, that they were “unanimous in cautioning against
hastily optimistic interpretations of the current situation” (at para 31).

A136. As regards the NISS (GIS) activities at the airport, Ms Crowther stated (at para 34):

“I also find it relevant that procedures for exiting and entering the country remain largely unchanged, even
despite the limitation on NISS's role to simply information-gathering - activist [] confirmed to me that
security officials maintain a desk at the airport at which they ask you about your planned activities out of or
in the country. It is too early to say how, and if, this will change in coming months.”

A137. In her concluding paragraph, she said this (at para 35):

“In conclusion, now is not the time to say whether attitudes towards Nuba individuals have improved,
especially considering the very recent fall of the Bashir regime and its replacement by a new transitory
system. The situation is simply too new to draw firm conclusions that would last more than the coming
k th d d t t t f i t id th f lt th t if b tt t t t


-----

were to hold for an initial period, the historically marginalised groups would be among the first to suffer
should there be a wider governmental crisis. There is ample evidence that attitudes among the TMC,
chiefly originating in the RES and its leader Henetti, are anti-Nuba, both on ethnic/racial grounds, and
because individuals are assumed to have existing anti-government opinion. It is therefore my opinion that
someone returned to Sudan as a rejected asylum seeker could foreseeably face difficulty on arrival at the
airport or otherwise, not least as their exposure to diaspora activities would single them out as being of
further interest.”

_5. “Addendum to Report on the risk to Nuba Individuals in Sudan” (17 October 2019)_

A138. This document was prepared following a visit in late November/early December 2018 to South
Sudan, including a refugee settlement near the border with Sudan. Ms Crowther annexed three statements
and emails from organisations: (a) the SPLM-N (Annex 1); (b) Dr Catena (Annex II) and; (c) the Nuba
Solidarity Group Abroad (Annex III).

A139.  Ms Crowther said (at paras 5-6) this about the continued role of Hemeti and the 'deep state' and
Islamists and the treatment of the Nuba:

“5.  Concerns continue to centre on the role taken by the military in the process, and particularly of
individuals implicated in atrocity crimes under the previous administration. Mohamed Hamdan Dagalo, or
'Hemeti' - whose Rapid Support Forces (RSF) are the re-branded Janjaweed responsible for the worst
abuses in Darfur at the height of the genocide there; whose forces have fought in South Kordofan; and who
served on former President Omar Al-Bashir's security committee - maintains his position, as does Abdel
Fattah al-Bourhan, who held a high rank in the Sudanese Armed Forces (SAF) under Bashir.

6.  But more relevant still is the presence of hundreds and thousands of officials who served under Bashir
in the transitional authorities. It remains an open source of tension of what to do with those individuals with
affiliations to Bashir's political party, the National Congress Party (NCP), and who were on the government
payroll. Short of a total purge, this administrative apparatus will be maintained. This apparatus was
employed by Bashir during his rule to conduct a brutal policy of Arabisation, during which black, African,
animist, or other religious expressions of Sudanese culture were suppressed in favour of Arab and Muslim
identities. Many Nuba on the ground and within the diaspora see disparaging and racist ideologies as the
most pernicious and persisting legacies of the Bashir era – it is still common for jokes to be made about an
individual's blackness, using words like 'abid' which means slave. I expanded on this in my March 2018
report and wish to draw your attention to these remarks. It remains the case that an individual will be
readily identified as Nuba because of their skin tone; that they will suffer discrimination in equal citizenship,
employment, religious freedom, education, healthcare, and housing, especially because of inability to
obtain official documentation that entitles them to government services; and that in addition they will be
subject to the unchanged and hostile administrative apparatus of the state.”

A140. At para 7, Ms Crowther stated that a clear example of the “the unchanged nature of the judicial
system and its animus against Nuba Christians” was the confirmation of criminal charges against eight
leaders of the Sudanese Church of Christ which is a primarily Nuban denomination.

A141. At paras 8-9, Ms Crowther stated that:

“no further proposals have been forwarded regarding justice and accountability for historic crimes,
including those of war crimes, crimes against humanity, and genocide in Darfur, and the targeted and
indiscriminate aerial bombardment of South Kordofan. Bashir still has a pending arrest warrant at the
International criminal court, but is avoiding handover and is instead involved in a domestic court case
relating to corruption…”

A142. Ms Crowther said (at para 10) “there was at least initially more hopeful progress on the peace file.”
However, she then referred to the withdrawal of al-Hilu from that process as a result of further attacks in
the Nuba Mountains (para 10). She also referred to the incidents of violence, curfew, arbitrary arrests,
confiscation of goods and checkpoints near Dilling in South Kordofan (para 11). She also referred to
incidents of a person tortured because of a personal dispute with a military official and the killing of two
individuals following a “run-in with the Popular Defence Forces (PFD) involving cattle grazing” (para 11)


-----

She referred to the communication from Dr Catena (Annex II) that he had received patients from
government-controlled areas in recent months (para 11). She also referred to the incidents in September
and October 2019 involving local protests near Talodi over the use of dangerous chemicals in the gold
mines and the raid by the RSF on the goldmines in Talodi to protect the mining operation by Hemeti (para
12). She stated that the response of the SC to these incidents was “muted” while “the cabinet took action
to ban the use of toxic chemicals in the mining process.” (para 12)

A143. Ms Crowther stated that, despite the release of detained prisoners, 25 individuals – whom she
stated were “Nuba political prisoners” - remained detained (at para 13)

A144. Ms Crowther stated that the Public Order law has been suspended in central Khartoum but it
remains in force in the 'Black Belt' where most Nuba live. She said that she had heard reports that the
police have been raiding houses accusing inhabitants of producing local alcohol called 'Merisa' and
confiscating belongings but without initial oversight (see para 14).

A145. Ms Crowther said that “the political situation remains incredibly fragile” (para 15). At para 16, Ms
Crowther referred to the continued existence of the NISS (rebrand the GIS) and that its powers have been
“limited to intelligence-gathering”. But, she said that, as with other developments, the changes may not
bring about change. At para 21, Ms Crowther referred to the (then) planned protest on 21 October to mark
the date of the 1964 October revolution. She said (foreshadowing something that did not in fact occur) that
this:

“has exposed fault lines between Islamists, former regime officials, and the regular demonstrators who all
protest's leadership and merit, and this may lead to an outbreak of further violence.” (para 20)

A146. Ms Crowther referred to violence ”at recent marches” so that “the behaviour of police and other
armed elements towards demonstrators is still of active concern” (para 20).

A147.  Ms Crowther said this in her conclusion (at para 21):

“the recent change in government should not be exaggerated, it is simply too early to tell whether earlier
stated commitments to peace and respect for diversity will be respected, and the initial progress is
discouraging, particularly as the administrative apparatus of the Bashir era remains mostly intact.”

A148.  Ms Crowther went on to state (at para 21) that popular discontent is growing in the Nuba
communities in Sudan and the diaspora with fears that

“the conflict, persecution, discrimination, and Arabisation of the Bashir era will continue whilst its
administrative apparatus and racist ideology remains in force.”

_6. Oral evidence (25 October 2019)_

A149. At the 24/25 October 2019 hearing, Ms Crowther was tendered for cross-examination. She spoke
of her visit to camps in South Sudan. She said that humanitarian aid could only return to the Nuba
Mountains if the SPLM-N and al Hilu forces made an agreement. She said that the incidents of specific
targeting were directed at high profile figures and those who were in and around protests. But, she stated
that incidents were more general. She said that she had spoken to the director of the HUDO Centre who
had told her that there was a crackdown in the 'Black Belt' on the day of the violence on 3 June 2019
followed by which there were days of harassment by the RSF which involved looting, arresting people and
confiscating belongings.

A150. Ms Crowther was asked about the Home Office document CPIT, “Response to an Information
Request” (23 October 2019) which referred at para 3.6 to prisoner releases, but, she said, this did not
relate to the Nuba and Darfuri detainees whom she had said in her evidence continued to be detained.

A151. Ms Crowther said that releases were a confidence building measure in advance of the peace
process. She said that the 25 still detained were Nuba or associated with the SPLM-N.

A152. Ms Crowther was asked about some of the material annexed to her 27 August 2019 report.


-----

A153. First, she was asked about expert A's view in Annex II. She accepted that expert A drew a
distinction between Nuba present in Khartoum who were “pro-SPLM and anti-SPLM” and that expert A said
that “the strong Nuba presence in Khartoum” were “both socially and economically marginalised, but not
necessarily systematically persecuted”.

A154. Secondly, she was asked about the views of Koert Debuf of the Tahrir Institute in Annex III. There
he said, in relation to South Kordofan, that:

“[i]t is very difficult, and even more so than in the past, to get an accurate picture of the situation in Sudan
in general and in South Kordofan in particular. From the information I get, the situation is much better now
as negotiations were concluded in a rather good way.”

A155. In relation to Khartoum, Koert Debuf said:

“Right now, it seems safe for Nuba individuals in Khartoum. However…the situation remains prematurely
stable. Things can collapse quickly. If that happen, Nuba individuals, as well as Darfuri people, might
become the first victims. Therefore, I would advise them to wait with relocations until the consensus
become more stable.”

A156. Ms Crowther said that that was his assessment and that she did not agree with everything he said.

A157. Secondly, Ms Crowther was asked about Mohan Elnour's report (Annex IV) of when, in December
2016, she met a person (a non-Arab Darfuri) deported from Italy who had said that, on arrival, of the 40
deportees the NISS had allowed all but himself and 5 others (two from the Nuba Mountains and three nonArab Darfuris) to leave. He had been detained for 35 days by the NISS and tortured before being released
without charge. He had no idea what had happened to the others. Ms Crowther said that this concerned
2016 and not anything that related to 2019.

A158. Thirdly, in respect of the material from the South Kordofan/Blue Nile Coordination Unit (Annex V),
Ms Crowther agreed that the material described individual incidents of “cattle raids” in Dilling but there was
no evidence of general round-ups in South Kordofan.

A159. Fourthly, in relation to Sir Henry Bellingham MP's communication (Annex VI), Ms Crowther agreed
that he had not given any examples. She said the Sudanese government made it difficult to obtain an
accurate picture.

A160. Fifthly, Ms Crowther was asked about the communication from Hafiz Mohamed (Annex VII). Their
he said that the “security and humanitarian situation” in South Kordofan had not changed and that the
militias were still carrying out atrocities. Ms Crowther agreed that he had not given any specific examples
because he was not asked to do so although he had given her examples in discussion. Ms Crowther was
also asked about Hafiz Mohamed's comments that the procedure at Khartoum airport was “still the same”
involving a second desk where the NISS checked passports and asked questions and that “they might
move you to one of their centres, that also depends on your ethnic background, Darfuri and Nuba treated
very harsh”. Ms Crowther that the assessment by the NISS was intelligence gathering and she agreed that
no specific examples were given. At para 26 of her report, where she said he had stated that Nuba and
Darfuri individuals were treated “much more harshly”, Ms Crowther said this was a reference to the 3 June
events.

A161. Ms Crowther said that there was a lack of widespread abuses or targeting but stated that this lack of
evidence of targeting or rounding up of Nuba in Khartoum “doesn't mean that there isn't evidence”.  She
said that the use of social media, in conjunction with the protests in 2019, had been “definitely helpful”.

A162. Ms Crowther said that the Nuba will continue to be associated with the SPLM-N and suspected of
being opposition activists – even if they are not engaged in active fighting themselves. It was, she said, too
soon to conclude that there would not be a return to general patterns of discrimination and mistreatment.
She said that there was an increasing frustration with the lack of progress made by the interim government.
She was also concerned that early progress with the peace process had stalled but she said that there had
been a number of encouraging developments as regards the new government's progress.


-----

A163. Ms Crowther was critical of the methodology of the F-FR 2018 and that, unlike in the past, the
British Embassy in Khartoum had not consulted widely and she referred to the view of the All Party
Parliamentary Group that the Embassy had not penetrated sufficiently into the lives of everyday Nubas or
Darfuris. She was critical of the failure of the Home Office source to go into the 'Black Belt'.

A164. Ms Crowther said that Salah Gosh, the former head of the NISS, had disappeared. He was, she
said, part of the group who had ousted al-Bashir and it was not known to what extent he was continuing to
be in contact with NISS units and that maybe he was positioning himself for a political career. She said it
was positive that he was no longer head of the NISS/GIS as he was behind the most egregious abuses.
Ms Crowther said that the majority of NISS staff remain in post and that their perceptions of the Nuba
would persist. She said that the Nuba would be the first to suffer if the situation becomes politically
charged again in Sudan. She said that this outcome is likely in light of the demands of the SPLM-N (al Hilu
faction) on cessation and that, given there had already been 22 rounds of peace negotiations which had
failed, any optimism should be cautious. In re-examination, she said that the NISS still constituted a threat
to the Nuba as attitudes would remain and an assumption that they were sympathetic to the cause of the
SPLM-N.

A165. Ms Crowther was asked about her “Addendum Report” and the communication from Dr Catena at
Annex II of that report. She was asked whether incidents of violence etc were now widespread in South
Kordofan. She said that Dr Catena reported that he had started to see casualties from governmentcontrolled areas. She said that the state of emergency seemed to be having a disproportionate effect in
Nuba areas through the RSF and security forces.

A166. In answer to questions from the Tribunal, Ms Crowther said that there were Nuba in the
Government. The minister in charge of immigration and the minister for agriculture were both Nuba. She
also said that there were two members of the SC who were Nuba, one a former military figure, and the
other on the civilian side.

**C. Dr Eric Reeves**

A167. Dr Reeves is a Senior Fellow at Harvard University Centre for Health and Human Rights. He has
not visited Sudan since 2003. He produced a report dated January 2018 and also gave oral evidence via
Skype on 1 June 2018. We are grateful to Mr Jacobs and Mr Thomann for their joint (largely in agreement)
note of Dr Reeves' oral evidence which we have placed some reliance upon in what follows.

1. “Risk to people from the Nuba Mountains Region on return to Sudan” (January 2018)

A168. Dr Reeves set out the sum of his views in the “Executive Summary” of his January 2018 report. In
preparing his report, Dr Reeves consulted a number of individuals, including academics, researchers,
historians and a Sudanese Human Rights lawyer.

“Executive Summary

The evidence availability collectively strongly suggests that there are significant dangers for Nuba people
forcibly repatriated to Sudan, including to the Khartoum urban area. By all expert accounts that I have
solicited in preparing this report, Nuba people would face unacceptable risks, even those returned who
have a very low profile. Indeed, a 'profile' can be created simply by virtue of seeking political asylum in a
European country or re-entering Sudan (and thus inevitably the Khartoum airport) without proper papers or
showing any signs of forced repatriation.

There is a long history of racial attitudes on the part of the ruling regime in Khartoum toward all nonArab/African peoples. This is reflected in the language of denigration…, discrimination in employment
(even if non-Arab/African applicants have superior qualifications and educational attainments), harassment
on the streets, arbitrary arrests, and a lack of access to real political power (they serve sometimes as
figureheads but never with real power to direct the policies of the National Congress Party).

The current economic crisis continues to accelerate dramatically, and there are already signs of
intensifying repression by the government. In the past, non-Arabs/Africans have often been made
t t h th t i t B t b f th i i d f ll ith th t'


-----

promulgation of the 2018 budge[t], which has seen catastrophic price increases for basic commodities
(e.g., 300% for bread, a staple food for most Sudanese), there were clear threats to any forcibly repatriated
Nuba. The recent Belgian forcible repatriation of some 100 Sudanese, selected by representatives of the
National Intelligence and Security Services (NISS), has provided graphic evidence of how badly such
compulsion can be.

The experts I have consulted specifically vis-à-vis the Nuba have all concluded emphatically that forcible
repatriation would present intolerable risks of harassment, discrimination, incarceration, torture, and/or
murder. Forcible repatriation of Nuba people to Sudan is, I believe in the light of these experts views, a
violation of international law.”

A169. Dr Reeves referred to the “continuing imposition of a humanitarian blockade over virtually all areas
of the Nuba Mountains” (p.10). He stated that the SPLM-N in the Nuba mountains “remains the most
serious threat” confronting Khartoum (p.10). He stated that the “continuing use of a humanitarian
embargo” was deployed as a “basic counterinsurgency weapon” (p.10). He referred to “leaked minutes”
from a meeting of senior military and security officials in August 2014 making “explicit the goal of
destroying that year's abundant sorghum crop” (p.10).

A170. Dr Reeves referred (p.11) to a person interviewed who had been a returnee from Belgium in 2017
who claimed to have been questioned by the NISS at Khartoum airport. It is reported that the interviewee
said that the NISS held most of the group returned and he had not heard of the fate of the others.

A171. Dr Reeves stated that, based upon what his respondents had replied, “the chances of arrest,
torture, and/or murder are very significantly increased if the Nuba person repatriated has a 'political
profile'.” (p.12) Such a 'profile' may be created in a number of ways, including applying for asylum in a
Western country (p.12). Dr Reeves states that judging whether a Nuba person is “political” was “entirely at
the discretion of the NISS” which enjoys “total impunity” and he stated that he knows of no case where an
NISS officer has been disciplined for human rights abuses (p.12). Dr Reeves stated (at p.12) that this
“widespread impunity” makes

“the fate of any Nuba person seeking political asylum in the UK entirely uncertain if forcibly repatriated to
Sudan, even if the intention of the asylum seeker is to live 'non-politically' in the Khartoum urban area.”

A172. Dr Reeves referred to the concentration of the security services in Khartoum and stated that the
“opportunities for repression in the still predominantly ethnically Arab capital are especially
numerous.”(p.12) By repression he stated that he meant: “job discrimination, harassment, street beatings,
incarceration, torture and murder” (p.12). But, he went on to state that the “NISS is pervasive in Sudan”
and that there are “no safe havens in the country for forcibly repatriated non-Arab/African peoples”. (p.12)
Dr Reeves stated that as a result of the generalised hostility to non-Arab/African peoples from regions with
continuing rebellions or strenuous political opposition:

“mistreatment of forcibly repatriated Sudanese fitting this ethnic/political profile are at acute danger.” (p.12)

A173. Foreshadowing (then) future events, Dr Reeves stated that the economy was in “an irreversible
decline and that civil unrest will grow far beyond what we have seen to date” (p.13). Dr Reeves stated that
it was “quite likely” that “the historical scapegoating tendency” will be directed against non-Arab Sudanese
including these from the Nuba Mountains and Blue Nile (p.13).  He stated that, for many, there would no
escaping from the “violence that will be unleashed by a regime in its death throes” (p.13).

A174. Under the heading “Conclusion”, Dr Reeves stated (p.14):

“the risk of being persecuted soley on the basis of being a non-Arab Nuba person in Sudan, particularly in
the Khartoum area, is unacceptably high.

Nuba people cannot internally relocate to Khartoum to escape or avoid persecution; although those with a
political profile are most likely to suffer persecution – including harassment, discrimination, illegal
incarceration, torture, and even murder – all are at potential risk”.

_2. Oral Evidence (1 June 2018)_


-----

A175. Dr Reeves stated in his oral evidence that he was in regular contact with Dr Catena in the Nuba
Mountains and, relying on an email dated 18 May 2018 from Dr Catena, Dr Reeves stated that
notwithstanding the cease-fire there had been skirmishes in the region and there were rumours that militia
would attack the goldmines in the area. Dr Reeves referred to the Sudanese bombing attacks on civilian
targets up to July 2016 and the continuing humanitarian blockade imposed by the government in the Nuba
Mountains. Dr Reeves referred to a leaked minute of a meeting of senior military and security officials in
Khartoum on 31 August 2014 in which it was agreed that the Sorghum crop in the Nuba Mountains should
be destroyed to use starvation as a method of war.

A176. Dr Reeves said that the Nuba were subject to severe discrimination and that they were viewed as
African, ill-educated and inferior. He said that there was no feasible prospect of a Nuba living in Khartoum
accessing education. Dr Reeves stated that the Sudanese government's view of non-Arab or African
Sudanese is inherently racist. Their dark-skinned colour is referred to with offensive language “abid”
meaning 'slave'. In his view, the Nuba were subject to greater discrimination than Darfuris. Whilst Darfur
provided soldiers for the North in the civil war, the Nuba sided with the SPLA rebel army. There was
residual anger against Nuba in respect of this.

A177. Dr Reeves said that there had been a media blackout in the Nuba Mountains and that no journalist
had been permitted to report from the area since June 2011 when the fighting began. He said that the
actions of the government towards the Nubas in the Nuba Mountains had amounted to genocide. In
particular, in June 2011 in Kadougli there had been house to house killings and civilians were hunted down
by helicopter gunships. Dr Reeves stated that the humanitarian blockade of the region was still in place.

A178. Dr Reeves stated that, although the government had ceased military bombardment in the Nuba
Mountains, the situation could easily change and that there was a likelihood that hostilities would resume.
This was because the government was not able to tolerate large parts of the country that it could not
control. Much of Darfur had been subdued by government forces but the same was not true in the Nuba
Mountains. He said that the present risk was starvation, lack of education, availability of vaccinations and
medicines.

A179. As regards returnees, Dr Reeves stated that he considered that Nuba failed asylum seekers who
returned on emergency travel documents were almost certain to be singled out for detention and the
probability of torture was high. Dr Reeves said that the mere fact that a Nuba had travelled abroad would
mark him out as suspicious on return and give rise to a real risk of mistreatment. The ability to have left
the country showed resourcefulness and the fact of having applied for asylum overseas would lead to
imputed political opinion. As fewer Nuba are returned than Darfuris, the Nuba returnees would, in his view,
be more likely to be singled out.

A180. In cross-examination, Dr Reeves was asked about the number of Nuba in Khartoum. He was
uncertain of the number but finally stated that there were about 100,000 to 200,000 but that was a
'guesstimate'. When he was asked whether he agreed with Waging Peace's estimation of 2,000 Nuba in
the UK, Dr Reeves said that he could not comment on the accuracy of that figure.

A181. Dr Reeves stated, when asked about there being no evidence of Nuba students being targeted in
Khartoum, that it was much less likely (compared to Darfuris) that they would be sufficiently educated to go
to University.

A182. Dr Reeves accepted that the basis of his report was his sources. He was asked about its reliance
upon a 2003 Amnesty International Report as the one example of there being a general risk to Nuba and
that no reference was made to the F-FR 2016. Dr Reeves said that 2003 report it showed the history. He
was aware of the F-FR 2016 but it was flawed in so many ways and was not as valuable as his sources.
He was asked about a response by Ted Dagne which was not included in his report. Dr Reeves said this
was his mistake. Dr Reeves was asked about Ted Dagne's email which said that if an individual was not a
known political activist, he would not be of significant interest. Dr Reeves said that his English was not
good – he is Ethiopian – and there was no distinction between activists and others.


-----

A183. Dr Reeves did not accept the proposition that a 'low level' Nuba would not be subject to
interrogation and ill-treatment upon return. He stated that in Sudan to be Nuba is to be both ethnically and
politically identified and the Nuba are seen by the government as part of the opposition. Dr Reeves said he
saw forced removal as an aggravating factor which would make it more difficult to avoid ill-treatment at the
hands of the Sudanese authorities on return. He relied on the instances reported in the Belgian COI Focus
report. In response to questions from the Tribunal, Dr Reeves said that he only knew of one returning
Nuba who was detained. The number of returned was relatively small. Returnees were arrested at the
airport because of political profile; it was relevant that they were being forcibly repatriated and had claimed
political asylum.

A184. Dr Reeves disagreed with Peter Verney's view expressed in evidence in AI and IM that black
Africans are not at risk on that basis alone. Ethnicity was extremely important. Dr Reeves stated that it
may be that a Nuba returnee would not be arrested but it increases the risk which is unacceptably high.

A185. Dr Reeves said that returnees to Khartoum airport would be asked details of their ethnicity.  He
referred to a killing of a returnee in November and he stated that the NISS and other security services saw
no distinction between non-Arabs from Darfur and those from the Nuba Mountains. The fact that fewer
Nuba will return would lead to a greater risk attaching to a return-Nuba as a member of a politically active
diaspora and a returned Darfuri.

A186. Dr Reeves stated that the return to the NISS of Salah Gosh was a sign by the regime that it wished
to adopt a more extreme line. Dr Reeves referred to the speech of al-Bashir in December 2016 in which
he threatened protestors with “what we did before”. Dr Reeves stated that this indicated a return to a shoot
to kill policy.

A187. In re-examination, Dr Reeves said a returning failed asylum seeker would be identified if forcibly
repatriated; that gave you a profile and the NISS has extensive surveillance presence in Europe especially
in the UK. A returnee would be seen as part of the diaspora. The NISS would distinguish an ordinary
Sudanese returnee – whom they would not care about – and a Nuba returnee. They would be subject to
intense interrogation, almost certain detention and may, or may not, be tortured and tasked with reporting
on release. Activists and those perceived as activists would be treated the same.

**D. Country Background Evidence**

A188. The parties, over the course of the hearings before us, supplied us with some eight volumes of
background material running into thousands of pages. Both Mr Jacobs and Mr Thomann, at our request,
drew our attention in their written submissions specifically to the background material upon which they
placed reliance. We have focussed on that material as relevant to our decision.

_1. Joint Danish Immigration Service and Home Office Fact-finding Missions (4 August 2016) (“F-FR 2016”)_

A189. Both parties referred us to a Joint Report of the Danish Immigration Service and the Home Office in
relation to fact-finding missions to Khartoum, Kampala and Nairobi (“Situation of Persons from Darfur,
Southern Kordofan and Blue Nile in Khartoum” (August 2016)). The F-FR 2016 relates to visits conducted
between February and March 2016.

A190. At para 1.1, the F-FR 2016 estimates the size of population from Darfur and the Two Areas living in
Khartoum as “ranging from hundreds of thousands and up to a million or greater”. The report states that
the highest figure estimated was 5 million and that two sources refer to the size of these communities as
60-70% of the total population of Khartoum. At para 1.2 the F-FR 2016 states that the two principal drivers
why individuals have moved to Khartoum is the security situation in their home areas and socioeconomic
factors.

A191. Section 2 of the F-FR 2016 deals with the treatment on arrival at Khartoum airport of persons from
Darfur and the Two Areas. Paragraph 2.1 sets out the security arrangements at the airport amounting to
two types of control: an immigration desk where travel and residence documents would be checked and
NISS security desk. The report continues:


-----

“2.1. Western Embassy (A) noted that NISS officers checked passports against a database, which
principally listed persons with links to international terrorist groups; Western embassy (C) confirmed the
existence of a NISS security database.

Information provided by some sources indicated that the level of questioning by NISS officers at the
security desk could vary. For example, whilst Western embassy (A) observed that this security check was
usually undertaken without conversation, the two human rights lawyers from Khartoum advised that the
purpose of security checks at the airport was to gather information about those arriving and so various
questions would be asked such as where the returnee was coming from, what they had done abroad and
why there were coming to Sudan.”

A192. In para 2.2, the F-FR 2016 deals with returning failed asylum seekers and what evidence, if any,
there was that returnees who were from Darfur or the Two Areas experienced difficulties:

“2.2. A number of sources stated that they had no information to indicate that failed asylum seekers /
returnees from Darfur or the Two Areas would generally experience difficulties on return to Khartoum
International Airport (KIA), or they did not consider that claiming asylum overseas would put such a person
at risk per se. Western Embassy (C) noted that they had monitored the forced return of two persons from
Europe in 2015 and had no reason to believe that they experienced any difficulties or mistreatment,
although the source acknowledged that they were not present throughout the arrival procedure. The
diplomatic source mentioned that they had experience of a very few rejected asylum seekers being
deported from Switzerland and Norway. According to the source it was unclear whether these returnees
could get support upon return to Sudan. However, the source added that those sent back from Norway had
not faced any problems upon return.

Some sources noted:

-  a lack of coordination in the return operations from deporting countries to inform those concerned when
precisely returnees would arrive at KIA

-  a general absence of independent organisations at KIA, including UNHCR, when forcibly returned
persons arrived in Sudan, although IOM was present for voluntary returns

- a limited number of enforced returns from Europe

EAC advised that at the security desk, officers asked a range of questions of failed asylum seekers
returning to Sudan (for instance about how long they had stayed abroad; why they did not have a passport;
or political affiliations and acquaintances abroad). ACPJS remarked that persons returning without travel
documents or under escort would be subject to questioning.

Several sources noted that Israel and Jordan had deported a number of Sudanese nationals, including
persons who had claimed asylum. Sources mentioned that the most recent incident was in December 2015
and involved the large-scale deportation of Sudanese nationals from Jordan, with some sources indicating
the number of persons deported was over 1,000 persons.

Some sources noted that deportees from Israel and some of the deportees from Jordan were arrested on
arrival and detained, some may have experienced prolonged detention or physical mistreatment and/or
were placed on reporting arrangements or travel restrictions. Other sources noted that returnees from
Jordan had been processed smoothly. There is however, lack of detailed, accurate information regarding
these events, including information on whether these deportees have been de facto refugees.

UNHCR was not able to verify whether any of the returnees had been detained. However, the source
stated that if a person had a high political profile, one could not rule out the possibility that he could face
difficulties with the authorities. Information from some other sources about the deportation of Sudanese
nationals from Jordan and Israel also indicated that those returnees who were held in prolonged detention
may have been detained because of their political profile.

Some sources highlighted that those returning from Israel were more at risk of being subjected to thorough
questioning and/or arrested upon return than those returned from other countries.”


-----

A193. At paragraph 2.4 the F-FR 2016 deals with the impact of a “long-term stay abroad” stating that in
itself it is not a risk factor but that those from Darfur or the Two Areas would be subject to extensive
questioning about their political activities:

“2.4 A number of sources confirmed that in their view long-term residence abroad would not in itself be a
risk factor. Some sources additionally observed that there were established Sudanese diaspora
communities living overseas.

NHRMO considered that those from Darfur or the Two Areas, who had been outside Sudan for a
considerable period, would be questioned extensively about their political activities and risked detention if
they were suspected of activities against the government.”

A194. At paragraph 2.5, the F-FR 2016 notes that several sources said that travelling on emergency travel
documents would not in itself be a risk factor.

A195. At paragraph 2.6, the F-FR 2016 deals with the “Impact of Political Profiling” as a relevant factor in
whether a returnee would be subject to questioning and/or arrest at the airport:

“2.6. Several sources noted that those returnees who had a political profile may be thoroughly questioned
and/or arrested at KIA.

For example, ACPJS was aware of cases in which political activists had been detained both when
attempting to leave and on return to Sudan, mentioning the example of a lawyer and a political activist who
were detained on return; DBA (Kampala)considered that activists from Darfur and the Two Areas would be
at the greatest risk at Khartoum airport (KIA); the two human rights lawyers from Khartoum cited examples
in which political activists had been detained at the airport and explained that treatment on arrival
depended on a person's political opposition activities and their affiliation with rebel groups; NHRMO
referring to their own human rights monitoring work, considered that it would not be safe for NHRMO staff
to visit Khartoum and referred to a specific case of detention at the airport involving a Nuba person who
was detained for alleged political activity.

Two sources in Kampala noted that security protocols were often adopted when activists travelled into and
out of Sudan, to avoid their country of departure being detected by the NISS (see 2.8 Impact of country of
departure).

Some sources indicated that persons, who had a political profile from Darfur and the Two Areas, may be
prevented from obtaining an exit stamp and leaving Sudan or replacing their passport from overseas
missions.

Two sources observed that persons from Darfur and the Two Areas who held a political profile may not
always be detained or targeted on arrival. Ahmed Eltoum Salim (EAC), referring both to his own
experiences and other persons he knew, noted that high profile persons, including political activists who
had been granted asylum abroad, had returned to Sudan and were now working with the government. The
Khartoum based human rights organisation also noted that the authorities did not arrest returnees who had
a political profile to the same extent as was the case before 2005 when signing of the Comprehensive
Peace Agreement led to the return of many Sudanese opposition groups.

Referring to the detention of political persons at Khartoum International Airport (KIA), Ahmed Eltoum Salim
(EAC), the Khartoum based human rights organisation and the two human rights lawyers from Khartoum
indicated that the behaviour of the NISS at the airport was slightly improved and that the detention of
political persons on arrival was less common now.

The two human rights lawyers from Khartoum noted that it was less likely now for persons to be arrested at
the airport for political reasons, although sometimes this happened. The source explained that at the
security desk it is now more common to obtain information about a person and for them to be picked up
later if they are deemed of interest.”

A196. Paragraph 2.7 deals with the “Impact of Ethnic Affiliation” noting that several sources did not
consider that a person's ethnicity generally affected their treatment but also noting that some sources said


-----

that there would be more extensive questioning, for example, of ethnic Nuba who were “most likely to
experience harassment”:

“2.7. Several sources indicated that a person's ethnicity did not generally affect their treatment on arrival at
Khartoum International Airport (KIA), or otherwise had no information to the contrary to contradict this
assessment.

Western embassy (C) noted that upon arrival at KIA, Darfuris and persons from the Two Areas may be
treated impolitely and probably asked to pay a bribe, but they would not face any difficulties if they already
were not 'flagged' by the NISS. NHRMO observed that those from the Two Areas travelling through
Khartoum International Airport (KIA) would be subject to more intensive questioning about their
background and political involvement, with ethnic Nuba most likely to experience harassment.

EAC pointed out that there were officers from Darfur and the Two Areas working at the airport, for example
Lieutenant General Awad El Dahiya, Head of Passports and Civil Registrations at the Ministry of Interior
was from Southern Kordofan.

EHAHRDP considered that all asylum seekers from Darfur and the Two Areas would be at risk on return.”

A197. At para 2.8 the F-FR 2016 states that those sources did not consider that in general travelling from
overseas countries would result in persons being targeted or detained on arrival.

A198. Section 3 of the F-FR 2016 deals with the “treatment of persons from Darfur and the Two Areas by
the authorities”. At para 3.1, the report states that the role of the NISS and the National Security Act in
dealing with the monitoring arrests and detention of politically active persons including persons from Darfur
and the Two Areas in Khartoum. The F-FR 2016 says this:

“3.1. Several sources cited cases in which the NISS were responsible for acts of harassment and
intimidation as well as more serious human rights violations, including acts of torture. Cases of arbitrary
arrest and use of in-communicado detention were also reported. Freedom House cited a report from the
African Centre for Peace and Justice Studies (ACPJS), recording 169 unlawful killings during civil unrest in
September 2013. According to the source, the report referred to NISS agents fraudulently changing postmortem documentation to cover up the number of persons killed by the NISS. According to Freedom
House only one security officer was ever convicted following the government's investigation into the
incident.

Several sources referred to the National Security Act 2010 as providing a broad remit for the NISS to
operate with impunity. In particular sources highlighted that the 2010 Act permitted extended powers of
detention and prevented NISS officers from facing prosecution for offenses committed in the course of their
duties.

Several sources referred to the NISS conducting surveillance of persons in Khartoum and having a
network of informants, including within the Darfuri and Two Area communities44, for example DBA
(Khartoum) noted that the NISS had informants in the Darfuri student population who had informed the
NISS about who was active in demonstrations. One source referred to the NISS' use of electronic
surveillance, for example tapping phone calls or monitoring online social media.

However, Freedom House commented that the NISS was poorly organised and lacked up to date
intelligence and that this could result in the NISS arbitrarily targeting a person. Western Embassy (A)
noted that it was difficult to understand the reasons why the authorities targeted some individuals and
provided an example in which a former member of an armed opposition group whose father had been
interrogated even though the individual was no longer active in the group. Western Embassy (C) referred
to a case in which a Sudanese national who worked at a school was harassed by the NISS for unknown
reasons. He subsequently left the country and claimed asylum in a western country.”

A199. At para 3.2, the F-FR 2016 deals with “Profile of Persons Targeted” emphasising, in particular,
targeting of those with political profiles such as students activists, including from Darfur and the Two Areas,
along with others such as persons affiliated with rebel groups, journalists, human rights activists and the
like:


-----

“3.2. A majority of sources observed that those from Darfur or the Two Areas who were critical of the
government and/or had apolitical profile may be monitored and targeted by the NISS in Khartoum. This
could include many different forms of activism.

Several sources identified student activists from Darfur and the Two Areas as being at risk of being
targeted. Different sources provided examples demonstrating extra-judicial killings, mistreatment in
detention as well as cases of harassment and intimidation by the NISS and their affiliated militias. Sources
noted that one of the main reasons why the student population was targeted was because they were the
most active politically and intent in voicing their criticism of the government. Such a trend had become
more prevalent in recent years.

A number of sources noted that other groups targeted by the NISS included: persons affiliated with rebel
groups; lawyers and journalists; civil society leaders; human rights activists, including women activists.
From these groups, three sources highlighted those with an affiliation to rebel groups as being particularly
at risk.

Political profile was also identified as a factor when considering risk on arrival at Khartoum International
Airport (KIA).”

A200. Section 3.2.1 deals with “Trends and Changes in Treatment” noting that several sources observe
that security operations including arrests and detentions (including by the NISS) “was not constant, but
changed over time”.  The report states that the reporting of

“discriminatory practices suffered by Darfuris and persons from the Two Areas were systematic, but not
constant, and that there were many periods where discriminatory practices were more intensely pursued
and conversely times when discriminatory practices were less pronounced”.

A201. The F-FR 2016 goes on to state:

“The SDFG advised that it was difficult to say what was happening in Khartoum today or the extent to
which persons from Darfur or the Two Areas were targeted by the NISS now. According to the source, it
was predominantly politically active persons who were targeted by the NISS.”

A202. Section 3.3 deals with the “Impact of Ethnic and Tribal Affiliation” stating that a number of sources
observed that those from Darfur or the Two Areas could be at risk of mistreatment by the NISS in
Khartoum and that they might be targeted by the authorities due to their ethnicity alone. The report states
that no specific information examples were given. The greater suspicion and risk of worse treatment in
detention are for those from Darfur and the Two Areas “and in particular those of African ethnicity”. The FFR 2016 says this:

“3.3. Four sources observed that all communities from Darfur or the Two Areas in Khartoum could be at
risk of mistreatment by the NISS or indicated that persons from these communities may be targeted by the
authorities due to their ethnicity alone. However, none of the sources provided specific information
indicating that persons from Darfur or the Two Areas were being subjected to mistreatment by the
authorities exclusively due to their ethnic background.

Faisal Elbagir (JHR) noted that whilst there was no official report on ordinary civilians (that is persons who
were not involved in political activities) from Darfur or the Two Areas being targeted by the authorities
merely due to their ethnic affiliation, such cases could be found on social media. However, the source
could not give examples of such cases which had been verified. Elbagir also remarked that due to media
restrictions in Sudan, it was often difficult to obtain accurate news reports about cases of detention.

Khartoum based journalist (1) noted that it was the type and level of political activity rather than one's
ethnic background which was the determining factor behind who was monitored and targeted by the NISS.
ACPJS explained that ethnicity was complicated and that ethnic disputes were often exploited by the
government to pursue political goals. ACPJS highlighted that in general anyone who was suspected of
political opposition against the government could be targeted, including persons from Arab tribes.


-----

Some sources advised with regard to the arrest of Darfuris in Khartoum that there had been no largescale
arbitrary arrest of Darfuris in Khartoum in recent years compared to that of 2008, following the JEM assault
on Omdurman55. Sources noted that at that time widespread security operations in Khartoum took place,
which were often based on the skin colour and ethnicity of a person.

A number of sources, however, noted that those from Darfur and the Two Areas, and in particular those of
African ethnicity, were more likely to be viewed with greater suspicion and treated worse in detention than
other tribes from Darfur and the Two Areas if they did come to the attention of the NISS due to their
political activity. Some sources also mentioned Ingessana from the Two Areas among the tribes being
suspected by the authorities for political activity. Several sources noted that the Darfuri and the Two Area
communities were perceived by the NISS to be 'rebel sympathisers' and consequently these communities
would be more closely monitored by the NISS, for example through the use of informants. Khartoum
based journalist (3) held the view that it was only those communities arriving in Khartoum post 2003 who
would be monitored.

DBA (Kampala) and ACPJS observed that those from other Darfuri tribes (i.e. not the Fur, Masalit and
Zaghawa), would not generally be perceived as opposed to the regime or commonly associated with rebel
groups and hence not being monitoring by the NISS. However, DBA (Khartoum) noted, in the context of
how persons from Darfur and the Two Areas were treated on arrest, that other African Darfuri tribes,
including the Tunjur, Meidob, Tama, Mima, Gimir and Dago tribes, were treated more harshly than Araborigin tribes because the authorities assumed that these groups supported armed rebel groups. DBA
(Kampala) also observed that activists of Arab origin may experience harsh treated for advocating in favour
of the rights of non-Arab tribes.

EHAHRDP commented that it was difficult to be prescriptive about which tribes would be at greater risk,
although considered those from Arab Baggara tribes as less likely to experience mistreatment because
these tribes were commonly associated with the pro-government Janjaweed militia.

UNHCR noted, however, that it was difficult in practice to treat persons differently on the basis of their tribal
affiliation. The source explained that it was difficult to say which group would be targeted and which would
not due to the sheer number of different tribes in Darfur (over 400), and the fact that mixed parentage
occurred.”

A203. Section 3.4 deals with “Treatment upon Arrest” and the risk of ill-treatment, torture and extra-judicial
killing, including by the NISS, of those in detention.

A204. Section 4 of the F-FR 2016 deals with the “living conditions in Khartoum for persons from Darfur
and the Two Areas”.

A205. Section 4.1 deals with “Access to Documentation” and cites a number of sources as indicating that
persons from Darfur and the Two Areas

“would, in general, have access to civil documentation, including a National ID number… required to
access services and to obtain other types of documents such as passport etc”.

A206. Several sources are quoted, however, as indicating that persons from Darfur or the Two Areas may
experience difficulty in reacquiring lost civil documentation “because of the need to obtain witnesses to
prove their identity”.  One source, however “noted that Sudanese from conflict areas living in Khartoum
lacked access to basic services, and faced economic, social and political exclusion”.

A207. Section 4.2 deals with “Access to Housing/Accommodation” referring to sources stating that there
was “no systematic discrimination” against persons from Darfur and the Two Areas with regards to where
they could live in Khartoum but that the “only real difficulty regarding access to housing” for persons from
Darfur or the Two Areas was “whether a person had sufficient income or financial resources to live in a
particular place”.

A208. The report then refers, to what has been called before us the 'Black Belt' where persons from Darfur
and the Two Areas usually lived as follows:


-----

“… Sources noted that usually persons from Darfur and the Two Areas had limited financial means and so
were forced to live in the poorer slum communities on the outskirts of the city, where housing was generally
of a poor standard. The districts of Mayo and Omdurman were mentioned as having sizeable populations
from Darfur and the Two Areas. Several sources also noted numerous other areas in Khartoum where
such communities lived.

The Commissioner for Refugees, Ministry of Interior, noted that there were no areas in Khartoum
exclusively inhabited by people from Darfur and the Two Areas. Both EAC and the Commissioner for
Refugees remarked that persons from Darfur and the Two Areas often stayed with relatives in Khartoum,
at least initially. Forced evictions occurred in these slum communities. Usually this resulted in communities
being forced to live further outside Khartoum, where access to services was very limited.

The international consultant observed that Darfuris tended to live in large enclaves in new conurbations in
Khartoum with water, electricity etc., but observed that 'people had to pay for it'. Some sources pointed out
that there were economically better-off Darfuris and people from the Two Areas who lived in better parts of
Khartoum including the centre of the city.”

A209. Section 4.3 deals with “Access to Healthcare” referring to statements by sources that access to
healthcare in some areas was “generally poor” and that there were fewer public hospitals in Khartoum.
The report refers to sources stating that there was “no systematic discrimination” against persons from
Darfur and the Two Areas in accessing healthcare in Khartoum “providing they could pay for it”. It then
reports a source recording that Sudanese from the conflict areas living in Khartoum “lacked access to basic
services, although mentioned that general access to healthcare in Khartoum was better than in Darfur and
the Two Areas”.

A210. Section 4.4 deals with “Access to Education”. Again, stating that it was “generally limited and the
quality of education was poor” in the slum areas but that there is “no systematic discrimination against
persons” from those Two Areas in accessing education “providing they could pay for it”. EHAHRD
commented that those from the conflict areas living in Khartoum

“lacked access to basic services, although mentioned the general access to education in Khartoum was
better than in Darfur and the Two Areas”.

A211. Section 4.6 deals with “Access to Employment”. It says that forces highlighted that:

“improved economic conditions, including access to employment, as one of the pull factors driving
migration from Darfur and the Two Areas to Khartoum”.

A212. The F-FR 2016 then goes on to deal with employment in the “informal sector”, there being “some
degree of discrimination” limiting access to certain types of jobs or sectors in the labour market for those
from Darfur or the Two Areas. The report says this:

“4.6. …. Several sources indicated that persons from Darfur or the Two Areas experienced some degree of
discrimination which was reflected in their limited access to certain types of jobs/sectors in the labour
market in Khartoum. For instance, such persons would likely find it difficult to secure skilled employment;
enter into certain qualified professions or sectors especially within the public sector. Several sources also
pointed at the adverse economic conditions and the general shortage of jobs in Sudan as an additional
factor, which made it difficult for Darfuris and persons from the Two Areas to access employment in the
formal sector.91As a result those with an academic background tended to leave Sudan to work overseas,
for example in the Gulf states or Europe.

The international consultant noted that those from Darfur or the Two Areas were broadly divided into two
groups –those who were educated and who were professionally employed, e.g. as teachers or selfemployed, and those who lacked a formal education and worked in the informal sector, such as agriculture
or construction.

The Khartoum based human rights organisation noted that Darfuri African tribes, such as the Masalit, Fur
and Tunjur or (African) tribes from the Nuba Mountains were more likely to experience employment
discrimination Western embassy (C) likened employment discrimination against African (non-Arabs) from


-----

Darfur and the Two Areas as similar to the difficulties faced by migrants/ refugees seeking employment in
Europe.

Some sources indicated that loyalty to the regime/NCP would influence the likelihood of employment in
some sectors.

Other sources identified that Darfuris and persons from the Two Areas could be found employed in the
armed forces, including the police. However, based on his experience, the international consultant
considered it unlikely that the provisions in the Doha Document for Peace in Darfur (DDPD), aimed at
improving representation of Darfuris in government positions and the armed forces had been met.”

A213. Section 5 deals with social circumstances in Khartoum and racial discrimination:

“A number of sources observed that persons from Darfur and the Two Areas, and in particular those of
African descent, experienced some level of discrimination or societal harassment. To illustrate this, five
sources referred to the use of derogatory phrases such as 'slave', especially from those belonging to
Riverine Arab tribes.

Crisis Group noted that despite 'systematic' discrimination restricting those from Darfur and the Two Areas
in conducting political activities, such communities were able to live 'day to day' in Khartoum. The source
also considered that the level of discrimination an individual may experience was linked to how politically
involved a person was and how long they had lived in the city; according to the source those with
established links over a longer period would likely experience less discrimination in Khartoum. Western
embassy (A) remarked that there was no visible societal discrimination against the Darfuri and persons
from the Two Areas, except within the student community.

DBA(Kampala)noted that discrimination tended to be from the authorities, rather than the civilian populace.
The source referred to cases of discrimination involving the POP who targeted illegal tea sellers; in cases
of recruitment into the civil service or in the over-taxation of Darfuri businesses. Three sources considered
day to day discrimination from officials working in the Sudanese authorities to be reflective of a wider 'racist
narrative' or supremacist ideology, which placed emphasis on a person's skin colour and was prejudicial
towards those of African/non-Arab descent.

Two sources considered societal discrimination and racism against persons from Darfur and the Two
Areas as a major problem in Sudan.”

A214. There is one final section of the F-FR 2016 with which we should deal which concerns the “Public
Order laws”. Section 4.7 refers to the wide deployment of the public order police (POP) in Khartoum who
enforce the public order law. The report then goes on to record sources reporting the use of that law
against women from Darfur and the Two Areas selling tea illegally and to enforce Islamic standards of
dress against women. The report says this:

“4.7. A number of sources noted that women from Darfur and the Two Areas selling tea illegally (i.e.
without required licence) or selling alcohol were at risk of being targeted by the POP for violating Public
Order laws. ACPJS observed that the POP was more prevalent in the slum areas where persons from
Darfur and the Two Areas more commonly lived. Freedom House advised that any person undertaking
such activities could be targeted, not just those from Darfur or the Two Areas, but explained that the
marginalisation of communities from Darfur and the Two Areas limited employment opportunities and so
they were commonly found in such roles. Sources advised that there were reports of bribery, extortion and
harassment committed by the POP.

….

Some sources noted that public order offences could also include matters such as not conforming to
standards of Islamic dress (e.g. wearing trousers or not wearing a headscarf). Western embassy (B)
explained that POP would harass Christian Nuba women if they did not observe Islamic dress, explaining
that such a person would be treated differently, for example compared to Western women or Coptic
Christian women who did not observe Islamic dress. When the FFM delegation advised Freedom House
that they had seen a large number of women without a headscarf in the streets during their stay in


-----

Khartoum, Freedom House commented that such an indiscretion would be less problematic for those from
wealthy families who were well connected, but it may give rise to difficulties for those from marginalised
communities such as Darfur or the Two Areas. However, Freedom House also noted that small acts of
political opposition, such as not wearing a headscarf, were increasingly tolerated and explained that Sudan
was relatively more progressive in the implementation of such laws, then for example, countries like Iran.”

A215. The fact-finding missions, which provided the material for the report, as we noted, were conducted
between February and March 2016. During the course of the hearing, a Home Office fact-finding mission
to Khartoum took place between 10 and 17 August 2018 and resulted in a report in November 2018.

_2. Report of a Fact-Finding Mission to Khartoum, Sudan (November 2018) (“the F-FR 2018”)_

A216. The F-FR 2018 published in November 2018 is a detailed one and mainly deals with the treatment
of non-Arab Darfuris. The parties, however, placed reliance upon some passages in the report which, in
particular, referred to individuals from South Kordofan or the Nuba Mountains. We have already referred to
this document as it was raised in the additional written reports of the experts, and in the oral evidence we
heard, at 24/25 October 2019 hearing.

A217. In section 1 of the F-FR 2018, reference is made to the large population of Darfuris and also those
from the Nuba Mountains in Greater Khartoum.  Reference is made to the migration of different groups to
Khartoum including Darfuris and that they, together with people from the Nuba Mountains, live in “shanty
towns surrounding Khartoum” (see para 1.1.3). That is a reference to the 'Black Belt'. At para 1.3.6, an
activist is noted as saying that:

“[t]here are no IDP camps for Darfuris or those from South Kordofan in Khartoum but many live in shanty
towns”.

A218. It is also reported (para 1.3.4) by one source from the British Embassy that it is:

“[mu]ch harder to get a sense of the [Darfuri] population in other groups because they are so well
integrated… Nuba, Christian or South Sudanese who live in 'ghettos', and [are] poorer, are easy to identify,
but cannot say this of Darfuris as they are so spread across society.”

A219. At para 1.3.13, a source is recorded as stating that in the shanty towns “Darfuris share the area with
Nuba, but the majority are Darfuri.”

A220. One issue, raised in other evidence that we heard, concerns the ability to identify the Nuba in
society. This is dealt with in paras 1.7.3–1.7.13. Again, in particular, in relation to identifying non-Arab
Darfuris. Their particular physical features are relied upon by sources as a means to make them “easily
identifiable”. At para 1.7.11 the source says: “the features of NADs, Nuba and Arab Darfuris are different”
(NAD = Non-Arab Darfuri). That source goes on to say:

“It is also possible to identify a Darfuri by the way they speak – anyone who speaks a local language most
likely speak Arabic with an accent. This is the same for other groups too, such as Nuba.”

A221. The F-FR 2018 goes on to deal with the treatment of non-Arab Darfuri by the government but also
refers to the position of individuals from the Nuba Mountains. At para 3.2.6, a university professor is
reported as saying that:

“… the three groups that government has most suspicions are the Zaghawi, Massalit and Fur – most
security sensitive as linked with rebel groups. People from South Kordofan face similar problem, as do
peoples from Blue Nile and East Sudan.”

A222. Another source (Siddig Yousef) is reported as stating (para 3.2.10):

“… the Nuba are treated badly, but face less social discrimination than the Darfuris … society generally
does not treat the Darfuris and the people from South Kordofan differently from other groups. But the
government and NISS treat them badly, considering them supporters of the armed groups.”

A223. At section 3.3 under the heading “Arrest and Detention – general” it is reported by an official at the
British Embassy that the roundup of Darfuris was linked to the war in Darfur and now that that conflict has


-----

reduced in intensity, “there is no need to lock up Darfuris”. The individual is recorded as stating, however,
that Darfuris do face issues with “poverty, marginalisation but they are not affected anymore than other
groups”.

A224. A further source is recorded as saying that he is “not aware of wide-scale arrests of Darfuris”. At
para 3.3.16, a number of sources are recorded as referring to protests in Khartoum during January 2018
during which

“a range of groups, including Darfuris, demonstrated against the deteriorating of the economic situation,
fuel shortages and rises in prices. There were a large number of arrests, one source estimated 500
arrested, including some members of civil society interviewed by the FFT.”

A225. In section 3.4 under the heading “Profiles and specific groups” at paras 3.4.5–3.4.8 the F-FR 2018
refers to the targeting of Darfuris who took part in demonstrations and also, from one source, the
association of the Nuba people like Darfuris, with rebel groups:

“3.4.5 Siddig Yousef thought that 'Darfuris would be targeted if they took part in demonstrations'. He also
observed, when asked who the state may have an interest: 'Whole areas of South Kordofan are not under
government control whereas all of Darfur is under government control. Nuba are ill-treated by the
government [in South Kordofan], also in Khartoum... the government is facing opposition from everyone –
because of the lack of fuel, increase in prices. There is a state of emergency in 9 out of 18 states /
provinces, including 5 in Darfur, 3 in South Kordofan and one in Kassala... the public order laws are
against women. If a woman is not covering her head, may be oppressed, arrested and lashed – only in
Khartoum state... many women are affected every day – 1000s –all women of different groups.'

3.4.6 The official of Western Embassy A considered '... that any high-level opposition members would be at
risk. However, reasons would be required to arrest someone with a high profile as it would be reported in
the media. For someone with a low profile, no reasons would be required as there would be less interest [in
the media].' Similarly, the IOM official observed that while '[t]he nature of NISS' likely priorities are not
known... it is assumed to be in those who are suspected of being a threat to state security, but qualified this
by noting that 'IOM works closely with immigration, not NISS'

3.4.7 The civil society activist observed '[t]he Nuba people and Darfuris are often associated with the
SPLM-N, SLM-AW and JEM – they are seen as rebels. Most cases that the organisation deals with [are]
Darfuris and Nuba, to whom it provides legal aid. The organisation has a lot of contact with Darfuris in
Khartoum, as well as those in Gezira, White Nile and Kordofan.' However, the human rights defender
considered that '... not all Darfuris are suspected of supporting rebels; just those that are suspected of
opposing the government, it is a well-known fact that there are many Darfuris who are members of the
ruling party and some assume high ranks within the party and the government.

3.4.8 In regard to state treatment/targeting, the activist thought it not possible to generalise and 'could not
say every Darfuri has a problem. If he is a politician, an activist... each case should be considered/dealt
with on its merits.' When asked what profiles of person would be of interest to the government the source
'thought it would be any opposition, anyone not affiliated to the NCP... human rights defenders, politicians.
They don't want people to help the South Sudanese in IDP/refugee camps.”

A226. Then, at 3.4.9 the F-FR 2018 states that there are difficulties faced by non-Arab Darfuri students
including arrest and detention:

“Sources generally agreed that non-Arab Darfuri students faced difficulties from the state, including arrest
and detention, because of their perceived opposition to the government and (suspected) links to rebel
groups. However, there was not consensus amongst sources on the nature and type of risks faced, and
whether all students were at risk or only those who participated in activities that were, or were perceived, to
oppose or criticise the government.”

A227. At para 3.4.10, the F-FR 2018 goes on to deal with the size of student population in Khartoum
noting, from some sources,


-----

'a strong presence of' and 'many' Darfuri students in Khartoum. The Second Secretary Political considered
that Darfuri students 'came to Khartoum/Omdurman for better quality education. Students are of mixed
backgrounds, predominately Fur, then Massalit, Zaghawa, Berti.”

A228. At para 3.4.15 the F-FR 2018 refers to a report concerning problems faced by Darfuri students from
the Sudanese state and reports incidents in 2012 when 70 students were arrested and only 66 released
with 4 disappearances whose dead bodies were thrown into an irrigation canal. The report records a
source as saying that “13 Darfuri students” were killed by government affiliated bodies between 2003 and
2016. The report continues:

“There are NISS agents (informants) and NISS offices on campus. When something happens, NISS arrest
everyone… This happens to all students, including non-Darfuris, especially if they are political activists.
There are problems for students who join different student organisations... many Darfuri students are
involved in activist groups due to the continuous conflict in Darfur, which makes them more politically
aware. Also there are problems faced Darfuris who join other (i.e. not rebel) opposition groups. They are
being more targeted by the security forces than others in the same opposition parties.”

A229. At para 3.4.19 a university professor from Darfur is reported as stating that:

“'All Sudanese opposition parties have their student activists, but the Darfuri students tend to be more
agitative.”

A230. At para 3.4.21 a civil society activist is reported as stating that students are:

“… labelled as trouble due to their perceived rebel support. There is a lot of violence, including people
being shot dead, on campus at the Universities. The targets are mainly the Darfuri and the Nuba.”

A231. The F-FR 2018 goes on to consider the economic and social circumstances, mainly for non-Arab
Darfuris. However, some reference is made to the Nuba. At para 3.5.5 a civil society activist is quoted as
saying: “Darfuris do better than the Nuba in terms of socio economics”. He continues:

“'In general Darfuris are better off than the Nuba people. Nuba IDP families rely on income generated by
their children collecting re-cyclable items to sell from rubbish dumps.”

A232. At para 3.5.9 under the heading “Employment”, one source is recorded as saying:

“Other marginalised groups, for example the Nuba, are also denied high-ranking places.”

A233. At section 3.6, the F-FR 2018 deals with “Access to ID numbers and cards”. The report refers to
the views of differing sources on whether Darfuris would be able to readily access an ID number which, a
British Embassy source states, is needed by all Sudanese “to get a driving licence, a job, to go to
university, etc.” (para 3.6.2). The difficulty of obtaining a national ID number is noted at paras 3.6.3 –
3.6.14. At para 3.6.3 one source notes:

“The government makes it impossible to get a National ID number as verification from a male relative is
required (and in many cases women do not have a surviving male relative) [however [the source] also
noted that many Darfuris are at school and university which he acknowledged was likely to require having
an ID number and card].”

A234. The same source then goes on to say:

“Other people, for example from the East, Blue Nile and the Nuba Mountains, are also discriminated
against on these grounds (particularly in the respect of women that are not able to obtain verification as
they do not have male relatives).”

A235. In section 5 under the heading “Government monitoring” it is stated that:

“Most sources who commented thought there was government monitoring of the Sudanese population,
some suggesting there was a particular focus on non-Arab Darfuris because of their possible links with
rebel groups. Sources expressed different views on the effectiveness of state monitoring.”

A236. An official at the British Embassy is reported as saying (para 5.1.5):


-----

“There is general monitoring of all Sudanese by the government...[but] thought that it was not interested in
Darfuris unless they were in some way politically active or having ties to rebel groups. The government
does not like demonstrators. The government does not monitor Darfuris in particular ... did not consider
that Darfuris were targeted for monitoring more so than other groups.”

A237. The F-FR 2018, nevertheless, goes on to refer to sources stating that informers and other means of
monitoring are used by the NISS.

A238. In section 5.2 under the heading “Overseas – monitoring the diaspora”, an official at the British
Embassy reported (at para 5.2.1):

“NISS do monitor the diaspora for rebel activities, many people in the UK report to the Sudanese. Sudan
has a big monitoring/reporting culture – the regime is paranoid. However, as rebel influence diminishes, the
government's interest in them declines.”

A239. The monitoring of activists in Europe is also reported by another source (see para 5.2.2).

A240. Section 6 deals with “Returns” to Sudan. This section is focused upon the return of non-Arab
Darfuris. At para 6.1.1 the report states as follows:

“Officials from 4 of the western Embassies interviewed (Norway, Switzerland, and Western Embassies A
and B) confirmed that since 2017 these countries have returned voluntarily and by force a number of
Sudanese nationals, including unsuccessful asylum seekers, to Sudan… the Home Office, as the UK
government department responsible for managing migration and asylum cases, at the time of writing
(November 2018) continues to remove Sudanese who have no right to remain in the UK voluntarily and, if
necessary, by force on a case-by-case basis.”

A241. At para 6.2 the ethnic profile or place of origin of a returnee is discussed but only in the context of
whether they were from Darfur. The evidence from the Western Embassies was mixed: some were not
aware whether any returnees were from Darfur and others that some of the returnees were likely to be
from Darfur. No reference is made to any of the returns relating to the Nuba; nor was that issue directly
raised with the Western Embassy.

A242. Section 6.3 deals with the “Treatment of returnees”. At para 6.3.1 the Sudanese head of
immigration is quoted as saying that returnees were supported and most were economic migrants and that:

“Unless there is a criminal case pending against a returnee they do not face any problems on return…. [he]
was not aware of any arrests. Returnees are interviewed to establish nationality.”

A243. He goes on to say that “claiming asylum abroad is not seen a crime.”

A244. However, other sources stated that (para 6.3.2):

“They had heard about problems for individuals returning to Sudan, including arrest, detention and illtreatment, or considered it likely that returnees may experience difficulties.”

A245. Another source, although he had no direct knowledge of returnees' experiences, stated that he:

“had heard mixed accounts from his research assistant who had interviewed people who had returned.”

A246. The source goes on to say that some had not had their passports stamped, maybe some returning
from Israel had been detained and then released whilst: “some others had been detained from the airport
and kept longer.”

A247. Another source from the Darfur Bar Association is quoted as saying (para 6.3.4):

“Returnees will be treated severely simply by the fact of having claimed asylum. They will be treated as
opponents of the government and accused of being rebels. Most people arrested at the airport are accused
of being rebel sympathisers. There have been 100s of arrests of returnees from Jordan and Israel.”

A248. However, it is also reported (para 6.3.5) that when this source was asked to give examples he was:


-----

unable to provide specific detail and had not investigated any cases of returns being arrested/detained on
arrival. He knew of such arrests from relatives of returnees arrested.”

A249. Another source (Siddig Yousef) is quoted at para 6.3.7 as saying

“... any activist outside of Sudan, regardless of tribe, may face problems”.

A250. When he was asked whether a Darfuri, who had made an asylum claim which had been rejected
and had then been returned to Sudan, would be of interest, this source said that he had no idea (para
6.3.7).

A251. At para 6.3.21, the report states that a number of sources, including the King of the Berti were not
aware of specific problems of returnees including unsuccessful asylum seekers.

3. Asylum Research Consultancy, “Situation in Khartoum and Omdurman” (9 September 2015)

A252. Mr Jacobs referred us to three passages in this report. At para 1.1.2 under the heading “Violence
against members of specific groups” and the sub-heading “Nuba”:

“The African Centre for Justice and Peace Studies (ACJPS) reports that “On the night of 22 June [2014]
police in the Almolazmeen area of Khartoum's twin city Omdurman arrested 40 individuals of Nuba
ethnicity, beating those arrested and using racist and discriminatory language against them. According to
eye-witness accounts, at least 40 police were deployed to the area and targeted people based on their
Nuba ethnicity in apparent retaliation for the beating of a police officer accused of raping a woman of Nuba
ethnicity along with two other police officers earlier that night. The 40 detainees, including at least 14
children and the woman who was reportedly gang-raped by police officers prior to her arrest, were taken to
Omdurman central police station”.

A253. In the same paragraph 1.1.2, the document continues:

“In the days building up to the April 2015 elections ACJPS reported that “Members of the Nuba ethnic
group also appear to have been targeted, possibly on the grounds of their presumed political affiliations to
armed movements. Four members of the Nuba ethnic group in Khartoum were arrested by the NISS and
held for three days on suspicion of being members of the SPLM-N. They were released onto a street in
Khartoum blindfolded. All four individuals reported being subjected to torture and ill-treatment, including
being beaten with water pipes, whilst in NISS custody.”

A254. Finally, at para 1.3.2 under the heading “Prison conditions” and the sub-heading “Nuba”, the
document says this:

“The African Centre for Justice and Peace Studies (ACJPS) further notes in a June 2015 report that “The
use of torture across Sudan is endemic. Sudanese authorities use torture and other forms of ill treatment to
intimidate and silence perceived political opposition to the policies of the ruling National Congress Party
(NCP). Human rights defenders, political and other social activists, internally displaced persons (IDPs) and
students are particularly vulnerable to torture and ill-treatment”.113 It further notes that “Members of ethnic
minority groups, including Darfuris and people hailing from Sudan's Blue Nile and South Kordofan states,
are particularly vulnerable to torture and ill-treatment. ACJPS has documented threats of sexual violence
against male and female detainees, as well as cases of rape against female detainees in state custody.
Detainees have also reported the use of racist verbal abuse”.”

4. Asylum Research Consultancy, “Sudan: Query Response” (13 September 2018)

A255. This is a detailed document and Mr Jacobs placed reliance upon it as confirming the position as set
out in the F-FR 2016. We confine ourselves to referring to the passages he relied on. The report draws
heavily on the F-FR 2016 and other reports (and news items) such as the Waging Peace Report of March
2018. We did not understand Mr Jacobs to suggest that there was anything uniquely supportive of his
case in this document.

A256. Mr Jacobs referred us to para 4.2 concerning the position of those from the Two Areas travelling
through Khartoum International Airport:


-----

“…persons from the Two Areas will be treated differently because of being perceived to be affiliated with
the SPLM-N [Sudanese Peoples Liberation Movement- North] and they will be subject to more intensive
questioning about their background and political involvement. Ethnic Nuba persons will be most likely to
experience harassment and will be easily identifiable from the name.”

A257. At para 1.1.1, the ARC document cites the F-FR 2016:

“a person from Darfur or the Two Areas could also be targeted even if they were not politically active.”

A258. At para 1.1.3, the ARC document again quotes the F-FR 2016 that sources indicated that there was
a risk of mistreatment by the NISS of communities from Darfur or the Two Areas in Khartoum and that

“persons from these communities may be targeted by the authorities due to their ethnicity alone. However,
none of the sources provided specific information indicating that persons from Darfur or the Two Areas
were being subject to mistreatment by the authorities exclusively due to their ethnic background”.

A259. At para 1.1.2 the ARC document refers to the F-FR 2016 report of targeted harassment of women
including Darfuri and Nuba women and including tea-selling Nuba women in Khartoum.

A260. Mr Jacobs also referred us to sections in the ARC document dealing with “discrimination”, “access
to documentation”, “living conditions in Khartoum”, “access to employment”, “access to housing”, “access
to healthcare” and “access to education” at pages 61-67 of the report. He did so without specific reference
to the detail. It is unnecessary for us to set it out as the document largely relies upon, and reflects, the FFR 2016 which we have set out in detail earlier.

5. “COI Focus, Sudan: Risk upon Return” (2018)

A261. We were referred to a number of passages in the report “COI Focus, Sudan: Risk upon Return” (6
February 2018) produced by the Belgium Office of the Commissioner General for Refugees and Stateless
Persons, which, Mr Jacobs submitted, confirmed the risk to Nuba upon return owing to reputed political
opinion. The first passage at para 2.1.1 dealt with the treatment of returned Sudanese national and the
procedure on arrival at Khartoum International airport:

“2.1.1. Immigration procedures and security check

According to a range of sources, there are two controls upon arrival at Khartoum International Airport (KIA):
first by the immigration service and then by the National Intelligence and Security Service (NISS). Sources
contacted by the CGRS indicated that travel and residence documents are checked first at the immigration
desk and that this is followed by a security check at the NISS desk. This information confirms what the
2016 British-Danish was told by its sources (several western embassies, Sudanese human rights lawyers,
regional NGOs, IOM)

According to the British embassy in Khartoum, there is a standard immigration procedure for every person
identified as a rejected asylum applicant: their documents are temporarily withheld and they are detained
for a maximum period of 24 hours for interrogation. If this interrogation does not yield any results, the
returnee is released. If the investigation reveals criminal activity or other nefarious reasons for the original
departure from Sudan, the returnee is blacklisted from leaving Sudan. If the crime is outstanding, the
returnee will be arrested.

The IOM explained to the British-Danish fact-finding mission that there are two categories of voluntary
returnees: those with an ordinary travel document (passport) and those with an emergency travel
document (ETD), such as a laissez-passer, issued by a Sudanese embassy. Returnees with a passport do
not encounter any problems. The IOM and some other sources (a western embassy; two NGOs in
Khartoum) are of the opinion that a return with an ETD does not in itself entail a risk for the returnee.
However, a returnee with an ETD can expect a more detailed interrogation by the intelligence service,
according to some sources (IOM; Sudanese NGOs in Khartoum and Kampala). The IOM added that
returnees with an ETD are questioned about the reasons for their earlier departure from Sudan at the
immigration desk. This takes about fifteen to twenty minutes, and the person is then free to go. Not only


-----

rejected asylum seekers undergo such interrogations, but all persons who have lost their passport,
according to the IOM.

According to some sources contacted by the CGRS (Waging Peace; ICG; Sudanese human rights activist
in Khartoum (A); Baldo S.; DRDC) returnees with an ETD run a greater risk of being targeted by the
authorities. According to Maddy Crowther of Waging Peace, this is because they are identified as rejected
asylum applicants, which gives them a political profile.92The Sudanese journalist and analyst Tajeldin
Adam stated that returnees with an ETD are usually taken away by the NISS for further verification, during
which they may be subjected to discrimination or persecution, especially political opponents or members of
vulnerable groups.93DWAG stated that even when they have a valid passport, returnees face a high risk of
detention, torture or even death. Waging Peace knows of several cases where a holder of a British
passport faced problems.95Suliman Baldo referred to the recent arrest of a British journalist and an
American activist of Sudanese origin.

Regarding verifications carried out by the NISS, the Australian Department of Foreign Affairs and Trade
(DFAT) stated that the NISS is strongly present at the airport and checks all documents of departing and
arriving passengers. The British embassy in Khartoum pointed out that the intelligence service only
intervenes when the immigration procedure is completed and that returnees are not systematically
subjected to further investigation. This only takes place when the NISS views a returnee as “a potential
person of interest”, for instance when their name appears on a travel watch list, or because they had
contacts with the Sudanese opposition or were active in opposition groups abroad.

Two western embassies told the British-Danish fact-finding mission that the NISS checks passport
numbers in their database. Two Sudanese human rights activists stated that the intelligence service also
uses this security check to collect information about incoming passengers and to ask questions about their
origin, their activities abroad and the reasons for their visit to Sudan. Rejected asylum applicants are
moreover asked questions about the duration of their stay abroad, the lack of a passport and their political
affiliations, according to the European and African Centre for Research, Training and Development (EAC),
an NGO working in Khartoum on legal migration.

The British embassy stated that it is not entirely clear how the immigration service identifies a returnee as a
rejected asylum applicant but that indicators such as the use of an ETD (e.g. a laissez-passer), the
absence of a valid exit visa or the presence of an escort may draw the attention of the immigration service.
Waging Peace also pointed out that an incoming passenger escorted by British immigration agents to
Khartoum airport can be identified as a rejected asylum applicant. Mukhtar Alqabir (KACE Sudan)
explained in an e-mail to the CGRS that repatriated Sudanese are usually intercepted by the NISS on
board or near the plane and taken by a separate route to the NISS office.

A Sudanese human rights lawyer stated in his e-mail to the CGRS that the authorities, when they have
doubts about a person's nationality, ask the person to have a relative come to the airport. Niemat Ahmadi
(DWAG) added that detainees often refuse to give the names of their relatives so as not to put them at risk.

A Sudanese human rights activist (C) in Khartoum told the CGRS in her e-mail that she travelled to
Khartoum in February 2017 with an ETD because she had lost her passport in London. She was taken by
the NISS to a separate office, where she was asked to fill in a “forced deportation form” with questions
about her journey, her family and her ethnic origin. As she refused to answer this last question, she was
taken to another building and was only released when the NISS was told her ethnic origin by a family
member. The Sudanese activist wondered what would happen with an incoming passenger belonging to
an ethnic group which the government views with hostility.”

A262. Under the heading “Ethnic Profiles” the report (para 2.3.2), dealing largely with non-Arab-Darfuris
but also those from the Nuba Mountains, states that the risk to them was “not assessed by all sources in
the same way”:

“The risk for persons from conflict areas, such as Darfur and South Kordofan (Nuba Mountains) and Blue
Nile States, especially for non-Arab Darfuris, is not assessed by all sources in the same way.


-----

The British Upper Tribunal considered in a decision of 2015 that the term “Darfuri” is to be understood as
an ethnic term relating to origins, not as a geographical term. Accordingly, the risk is the same for all nonArab Darfuris, whether they were born and lived in Darfur or not.

In their latest decisions regarding Darfuris, the Upper Tribunal and the ECtHR have ruled against
repatriation of non-Arab Darfuri.

The Upper Tribunal quoted the UK Border Agency (UKBA) Operational Guidance Note on Sudan of 2
November 2009: “All non-Arab Darfuris, regardless of their political or other affiliations, are at real risk of
persecution”. In 2015, the ECtHR concluded again that the Sudanese government is extremely suspicious
of Darfuris who travelled or lived abroad.

Both jurisdictions refer to a UNHCR report of 28 November 2008 stating that Darfuris in the Khartoum area
are at heightened risk of being subjected to arbitrary arrests and that Darfuris travelling abroad may be
viewed with suspicion by the security forces.

The British Sudan researcher Peter Verney considers that non-Arab Darfuris may also be arrested and
detained for racist motives, as part of the “genocidal” and “ethnocidal” destruction of their societies, and not
because of actual evidence of links with rebel groups. The Sudanese authorities attribute a political colour
on the basis of ethnicity, and not on the basis of a real political profile. According to Verney, hundreds of
low profile non-Arab Darfuris are being arrested.

In a document released in October 2017, Waging Peace stated that non-Arab Darfuris still are at risk in
Sudan, also when they are sent back to Khartoum. According to Waging Peace, ethnic Darfuris (or persons
supposed to belong to this ethnic group) face more systematic forms of discrimination and persecution in
the capital, which prevents their relocation.

In 2013, the British embassy in Khartoum was told by human rights organizations that returnees from
Darfur and the Nuba Mountains run a higher risk of arrest upon arrival than other Sudanese returnees.

Amnesty International considered that Sudanese from conflict-affected areas such as Darfur and South
Kordofan and Blue Nile States should not be sent back to Sudan, where they would be at real risk of
serious human rights violations. A number of sources contacted by the CGRS (Amnesty International;
Sudan expert for an international organization; Sudanese journalist; DWAG; Tajeldin Adam; ACJPS;
DRDC; KACE Sudan) hold the same view. Suliman Baldo declared that the Sudanese security services
are more prone to subject detainees from conflict areas to racist insults and ill-treatment, including torture,
compared with detainees from north or central Sudan. Most youths leaving the country come from conflict
areas, according to Baldo. Some sources (DWAG; DBA; human rights lawyer in Khartoum; ACJPS;
DRDC) stated that the Fur, Massalit and Zaghawa are the ethnic groups which are most often targeted in
Sudan.181A Sudanese professor of human rights law stated that not every returnee faces problems at KIA
but perceived a risk for persons who combine a specific ethnic background with political activities, for
instance a Darfuri suspected of involvement with a rebel group.

A number of sources contacted by the CGRS (Eric Reeves; Waging Peace; Sudanese human rights
activist (A); Sudanese human rights activist in Khartoum (D)) were of the view that Darfuris are particularly
under suspicion, all the more so, according to Tubiana, when they have requested asylum in the West or in
Israel. Most sources also mentioned other Sub-Saharan ethnic groups such as the Nuba. Darfuris with
“political profiles” (sometimes based on distant family ties with rebel groups or involvement in some form of
political activity, according to Reeves) run a high risk of arrest, detention and torture. Waging Peace noted
that many activities have a political side and that this could also be the case for the activities of journalists,
teachers, human rights activists, humanitarian aid workers etc. Applying for asylum will also draw attention
from the authorities, according to Waging Peace.

Abdelrahman Elgasim (DBA) stated that passports of Darfuris are usually confiscated and their holders are
interrogated about every aspect of their life (place of birth, ethnic origin, parents, brothers and sisters,
partners, political affiliation, occupation) and have to sign a written commitment not to leave the country.
They are then blacklisted from leaving the country. Elgasim is aware that a number of Darfuris occupy


-----

senior government functions but most of them are members of the Islamic Movement, and are tied through
their religion to the Islamic government.

Other sources stated that an ethnic profile entails in itself insufficient risk upon return and pleaded for a
more individualized approach which would take into account the returnee's political profile.

Several sources (IOM; UNHCR; western embassies; Sudanese NGO) told the British-Danish fact-finding
mission in early 2016 that a person's ethnicity did not generally affect their treatment on arrival at KIA.
UNHCR explained that, due to ethnic diversity, especially in Darfur, and to mixed parentage, it is difficult in
practice to treat persons differently on the basis of their tribal affiliation. A western embassy noted that
upon arrival at KIA, Darfuris and persons from the Two Areas may be treated rudely and will probably be
asked to pay a bribe, and according to a Kampala-based Sudanese NGO, the National Human Rights
Monitors Organization (NHRMO), they would be subjected to more intensive questioning and if they are
suspected of anti-government activities, they could face detention.

In May 2013, the Swiss Federal Administrative Court (FAC) considered that, although still unstable, the
situation in Darfur was improving and that attacks against non-Arab Darfuris had decreased. The FAC
concluded that Darfuris had to adduce additional distinguishing features, such as political or other
affiliations, to substantiate their fear of persecution.

The British embassy in Khartoum stated in 2016 that its contacts with Darfuri within civil society and
political parties, with UN agencies and other embassies do not suggest ethnic persecution of non-Arab
Darfuris settled in regions outside Darfur.187The British embassy added that many Darfuris, including nonArab Darfuris, are represented at senior levels in government, the security forces, and the media.

In August 2017, the British Home Office considered that non-Arab Darfuris are not generally at risk of
persecution or serious harm in Khartoum solely on the grounds of their ethnicity. This view departs from
the British Upper Tribunal's jurisprudence holding that non-Arab Darfuris are eligible for international
protection and have no internal relocation alternative,189and from its own policy guideline of 2016, which
followed the Upper Tribunal's jurisprudence.190The Home Office is of the view that a person's non-Arab
Darfuri ethnicity is likely to be a factor which may bring them to the attention of the state and, depending on
other aspects of their profile and activities, may lead to a risk of serious harm or persecution. The Home
Office added that Darfuris in Khartoum face discrimination in accessing public services, education and
employment, experience forced eviction, societal harassment from other Sudanese, and do not have
access to humanitarian assistance. However in general such treatment is not so severe that it is likely to
amount to persecution. Each case has to be considered on its individual facts. The Home Office further
noted that all returns are to Khartoum and considers this a reasonable option, including for persons not
previously resident in Khartoum. If the person is able to demonstrate a risk of persecution or serious harm
in Khartoum, internal relocation to another part of Sudan will not be reasonable.

The ACJPS told the CGRS it did not have any evidence suggesting that persons are targeted because of
their ethnic background and stated that ethnicity is a complicated matter and that ethnic disputes are used
by the government to achieve political goals.”

A263. Under the heading “Political Profiles” the report (para 2.3.2) deals with the sources on the issue of
what risk, if any, faced by those viewed as political opponents of the Sudanese government:

“All sources agree that Sudanese political opponents face a risk of persecution upon return if they have
been politically active abroad, where the diaspora is kept under close surveillance by the Sudanese secret
service.

Several sources of the British-Danish mission (UNHCR; western embassies; Sudanese lawyers and
activists in Khartoum and Kampala; Sudanese journalist) emphasized that returnees with a political profile
or with rebel connections may be thoroughly questioned and/or arrested at KIA.

A range of sources contacted by the CGRS (Sudan expert of an international human rights organization;
ACJPS; human rights activist (C) in Khartoum; DBA; a journalist in Khartoum; Sudanese professor; KACE
Sudan) share the view that activists, vocal critics of the regime and members of the opposition all run a risk


-----

upon return. Activists known to be communist, secularist or political opponents run a heightened risk of illtreatment, according to Muqhtar Alqabir (KACE Sudan). The ACJPS stated that arrests sometimes do not
last long and are rather a form of intimidation, but that returnees who are viewed as a real threat may be
detained for a longer time. The ACJPS is primarily thinking of lawyers, journalists and students. Arrests
may even take place during social visits, according to the Sudanese human rights activist. A member of the
Sudanese Congress Party was arrested at his mother's funeral. This is an arbitrary process depending on
the perception of NISS agents and immigration staff.

According to Geir Skogseth of Landinfo, the Sudanese authorities, especially the NISS, keep a close watch
on political activities, broadly defined. This also extends to political activities in the diaspora. Individuals
with political activities abroad may experience problems with the NISS upon their return, whether voluntary
or forced. A collaborator of an international organization stated that the way a person is treated upon
return strongly depends on the person's individual profile. It is very dangerous for someone who is publicly
active in the diaspora to be sent back, but persons who left Sudan merely to find a better life will only face
interrogation.

The DBA considered that activists from Darfur and the Two Areas would be at greatest risk at KIA. The
NHRMO told the British-Danish fact-finding mission that persons from these areas would be questioned
extensively about their political activities and risked detention if they were suspected of activities against
the government. The NHRMO declared that it is not safe for their collaborators to go to Khartoum. Two
human rights lawyers from Khartoum mentioned that political activists are sometimes detained at the
airport but that this is not very common. It is now more common for the authorities to obtain information
about a returnee, and to arrest him later if he is deemed of interest. The EAC, who is active in Khartoum,
noted that arrests of persons with a political profile have become less common since the conclusion of the
2005 Comprehensive Peace Agreement197and the return to Sudan of a number of opposition groups.

A Sudan researcher at HRW pointed out in July 2017 to the Austrian Centre for Country of Origin & Asylum
Research and Documentation (ACCORD) that a Darfuri returning to KIA would probably not be targeted
merely because of his ethnic background. Possible discrimination of a Darfuri returnee at KIA would rather
depend on the profile of the person, on his ethnic background and political activities, which might arouse
suspicion of rebel sympathies. The HRW researcher added that membership of the Hizb al-Umma
(National Umma Party, NUP) and some other opposition parties would not necessarily be considered an
aggravating factor as this party is part of the “acceptable opposition” with a handful of other parties.

On the other hand, Jérôme Tubiana stated in his e-mail to ACCORD of July 2017 that Darfuris are likely to
be interrogated by security, and possibly beaten or tortured, detained, and even killed. He added that Hizb
al-Umma or other opposition affiliation is an aggravating factor.

Amnesty International considers that Sudanese coming from areas other than Darfur and the Two Areas
must not be sent back to Sudan when they are accused of opposition activities.

The British Upper Tribunal estimated in April 2016 that not all political opponents suffer persecution and
that for this to happen, their level of political engagement has to be fairly high. The Upper Tribunal added
that sur place activities may entail a risk, for instance when the activities are public and known to the
intelligence service. It does not take much for the NISS to create a file on an opponent but this does not
necessarily mean that the file will be used later on. However, the British Sudan expert Peter Verney told
the Upper Tribunal that little more than suspicion is sometimes enough to detain someone.

Relying on the Upper Tribunal's jurisprudence, the British Home Office noted that there is a risk of
persecution or serious harm for those who oppose the government, including members of the political
opposition or civil society, student activists and journalists, who may be subjected to arbitrary arrest and
detention, forced disappearance and ill-treatment. The Home Office added that not every person belonging
to a category at risk will be persecuted and assessed the risk as follows:

“The risk a person faces will depend on their profile and activities, and whether they are likely to be
perceived as a threat to, and attract the attention of, the authorities in such a way that amounts to more


-----

than a routine, commonplace risk of detention and questioning but meets the threshold of a real risk of
persecution or serious harm.”

In an e-mail to the CGRS, Waging Peace deplored that the Upper Tribunal and the Home Office are
minimizing the risk of widespread arrests and detention, so as not to reach the threshold of “risk of serious
harm”. The NGO considers this an “unwarranted reformulation of the Refugee Convention”. Moreover,
according to Waging Peace, it's up to the asylum applicant to prove that he or she is a person of interest,
whereas repression in Sudan is of an arbitrary nature and claiming refugee status is in itself a political act.

A number of sources contacted by the CGRS (Waging Peace; human rights activist (C) and journalist in
Khartoum; human rights lawyer in Khartoum; Sudanese professor) have knowledge of a blacklist of
persons wanted by the authorities. The NISS relies on a detailed and sophisticated database, according to
Reeves207, and creates files on individuals, according to a Sudanese human rights activist and a
collaborator of an international organization. The latter does not believe that files are created on individuals
who are not viewed as a threat.

A number of testimonies included in Waging Peace's report of 2014 show that Sudanese activists and
opposition members returned several times to Sudan without problems, possibly because of their status,
but that this privilege can be revoked when tensions are high. The moment of the return to Sudan can
therefore also be a risk factor. Waging Peace refers to the detention of Mariam El Mahdi, vice-president of
the Hizb al-Umma, and to the testimony of Dr Sidgi Awad Kaballo, member of the Sudanese Communist
Party.”

A264. At section 4.3 under the heading “Surveillance of the Diaspora”, setting out the passage in full and
upon which Mr Jacobs relied in part, the report says this:

“The British embassy in Khartoum reported that under the Sudanese 2014 Asylum Act, the Commissioner
for Refugees has an “obligation to monitor the situation of Sudanese refugees abroad and to expressly
encourage them to return to Sudan”. The Office of the Commissioner for Refugees comes under the
Ministry of Interior, but maintains close relations with the NISS.

The British embassy also wrote that it has no independent evidence of overseas surveillance of asylum
seekers by the Sudanese government, but that in October 2012 a Sudanese diplomat was expelled from
Norway following allegations of spying on Sudanese refugees.346In 2013, a Sudanese asylum applicant
was found guilty in Norway of spying on the diaspora, according to Landinfo.

The ECtHR noted that there is no systematic surveillance by the NISS, which does not have the means to
spy on every member of the diaspora. The NISS surveys specific persons, for instance those who have a
political past in Sudan, are engaged in public political activities abroad or have family or personal ties with
the opposition in exile.

In 2013 and 2014, The Telegraph, relying on statements from Sudanese activists, wrote that the Sudanese
intelligence service was infiltrating opposition circles and that the Sudanese government coordinated a
network of spies in cities across the UK where the Sudanese opposition is strongly present. According to
the activists, spies also work at the Sudanese embassy, where they collect information on the diaspora.

The British Home Office wrote in 2016 that Sudanese intelligence conducts surveillance on politically active
members of the diaspora within the UK and is likely to focus attention on those who (or are perceived to)
pose most risk to the regime.

In 2012 and 2014, Waging Peace collected testimonies among Sudanese from the diaspora and Sudanese
who had been interrogated upon their return to Sudan about their activities in the UK. From their
testimonies, Waging Peace concluded that Sudanese intelligence spies on the diaspora and closely
monitors political meetings and demonstrations abroad. Information collected by the NISS may be used
against returnees to Sudan. Waging Peace is also of the view that the NISS does not have the means to
monitor all activists who are less actively engaged.”

5. Respecting the Principle of Non-Refoulement when Organising the Return of Person to Sudan (February
_2018)_


-----

A265. In the “COI Focus” report, the Belgian authorities considered reports of documented repatriations to
Sudan from a number of European countries, including Belgium, Italy, France, Germany, The Netherlands
and Norway and from a number of non-European countries, including Jordan and Israel (see section 1 at
pages 10 – 15; and section 2.4 at pages 31 – 38).

A266. These formed the basis of an investigation by the Office of the Belgian Commissioner General for
Refugees and Stateless Persons resulting in a report entitled “Respecting the Principle of non-Refoulment
when Organising the Return of Persons to Sudan (8 February 2018). These returns, largely resulting from
an investigation by the Tahrir Institute were relied upon by Madeline Crowther in her evidence as
demonstrating a risk to returned asylum seekers (including Nuba). The Belgian Commissioner General
found that “some important elements” of the individual's counts “were not true, to such an extent that this
raises serious doubts about the rest of the testimony”. The Commissioner General's assessment leading
to that conclusion is set out at pages 7–10 of the report as follows:

“An assessment

Main findings:

- Efforts were made to obtain more specific information about the facts of the treatment or ill-treatment
encountered upon arrival in Khartoum. The descriptions were very summary.

o   The conversations with Mr Koert Debeuf and the person identified as “a Sudanese refugee”, who
seemed to have played an important part in the investigation by the Tahrir Institute, did not yield more
information than the information mentioned in the note of the Tahrir Institute. An analysis of the
conversations on WhatsApp with some persons who were returned to Sudan (made available by Mr Koert
Debeuf), did not yield any additional information either. For some aspects, a (slight) difference was found
between the declarations made and their transcription in the note.

o   The conversation the CGRS had on WhatsApp with one of the persons who had been removed to
Sudan did not yield any additional information either. This person did not seem to be disposed to give
additional information.

o   Several embassies of EU member states let us know that no incidents or cases of ill-treatment of
persons who were recently removed to Sudan had come to their attention. Neither did the UNHCR and
IOM possess such information. The UNHCR informed us that they do not as a rule monitor rejected
asylum seekers or persons who did not apply for asylum after their return.

- The CGRS has not been able to obtain absolute certainty or clarity about the question whether the facts
mentioned in the report of the Tahrir Institute have actually taken place. There is no hard evidence that the
facts actually took place. Neither could it be established with certainty that the facts mentioned did not take
place. However, some findings of the CGRS give rise to serious doubts, at least regarding some of the
testimonies.

A distinction must be made between the person who returned voluntarily under the IOM REAB program,
and the nine persons who were removed. For the voluntary returnee, it has been alleged that he had in fact
been forced to return. This claim does not appear to be well-founded. Regarding the first testimony
reproduced in the note of the Tahrir Institute, the following was stated: “MR. ... was going through a
process organized by the IOM and didn't leave Belgium voluntarily. ... They forced me to sign the papers to
go to Sudan. They told me we will do you a business investment, they will forcibly deport me, so they
intimidated me so I signed the papers. ... They told me I will get 1.700 euros. ... They cheated me, they
didn't do anything for me. They didn't even give me one euro until today.” But on the other hand it appears
that on the day after his detention (on 5 September 2017), the person involved announced that he wanted
to return voluntarily and that on 3 October 2017, he benefited from special counselling by the IOM and
reiterated on that occasion his wish to return voluntarily. The visit of the identification mission took place
after the person concerned announced that he wanted to return voluntarily. It also appears that the IOM did
all the necessary to support the business plan of the person concerned: on 16 October 2017 (four days
after his arrival), the person concerned visited the IOM for the first time. He then came back several times
to put his business plan in order Financial aid was due to be paid on 16 November but because the person


-----

concerned did not present himself in person, the payment could not be executed. The project was
eventually concluded in January 2018: “Mr. ... has been fully assisted -on Monday 22nd of January 2018
business of play station center will be established in his area of origin Rabak –White Nile state”. Regarding
this person, the report of the Tahrir Institute also stated: “I am from Darfur and our lives are difficult in
Darfur. ... My life is difficult and dangerous in Darfur”. According to his statement (included in his file at the
Immigration Office), he was born in Rabak, capital of the State of White Nile. This is also mentioned on the
laissez-passer. And IOM confirmed that he is to start his integration project in “his area of origin Rabak –
White Nile state”. Many elements in the testimony appear not to be true. One therefore wonders if the other
elements mentioned in the testimony are true. This concerns the person mentioned first in the report of the
Tahrir Institute, whose testimony is the most extensive.

For one person (the second testimony in the report of the Tahrir Institute), it appears that he made his first
visit to the IOM office on the day of his arrival in Khartoum. He appears to have visited this office for the
first time on 22 October 2017 and to have arrived in Khartoum shortly after midnight on the same day or
shortly before midnight. IOM confirmed the following: “MR ... approached our office for the first time on 22
October 2017. He received his in-kind entitlements on 28 January for purchasing mobile phones for
release. We did not come across any harsh treatment complaint from Mr. ..., neither has he shown any
traces of possible harsh treatment.” On the other hand, it appears that according to the report of the Tahrir
Institute he claimed the following: “Upon arrival in Khartoum, he was detained at the airport for two days
and interrogated on political charges: questioned on where he was from in Darfur and accused of working
with the Darfur opposition. He denied it and was tortured physically (beaten with a stick) and
psychologically for three hours. ... “. Contrary to the statement as reported, it appears from the analysis of
the WhatsApp conversation that the person concerned declared to have been detained for one day. On 26
January 2018, the CGRS had a brief conversation with this person on WhatsApp. During this conversation,
he repeated that he had been detained for one day, from the afternoon until the next morning. He did not
give any more information about possible ill-treatment. After some time, he seemed no longer willing to
continue the conversation. His testimony seems incompatible with the fact that he visited the IOM office on
the day of his arrival. The same can be said regarding his statement that he cannot leave his room and
look for work.

The CGRS found that three of the persons mentioned in the report of the Tahrir Institute have contacted
IOM to start an integration project in Sudan. This concerns the first three persons mentioned in the note of
the Tahrir Institute, i.e. the three persons who gave a direct testimony. Two of them had the most
outspoken complaints about ill-treatment after their arrival in Khartoum. The third person has not
mentioned ill-treatment upon arrival. For all three persons, IOM confirmed that they visited their office at
least once to obtain financial help to start an integration project in Khartoum or Rabak. For all three
persons, IOM also confirmed that while visiting the IOM office, they did not say anything about any
incidents upon their arrival. The fact that those three persons are not “persecuted” at the moment can be
considered as an indication of the fact that they do not belong to special categories at risk.

Because the CGRS has not been able to thoroughly assess the situation of the persons concerned, it is
impossible to formulate a clear conclusion regarding their profile and the risk in case of return. Most of the
persons who returned or were removed may very well belong to profiles that are not at risk of being
persecuted, tortured or treated in an inhuman way; for some of them, questions can be raised about the
credibility of their claims or their profile, for others there are no concrete indications.

A special situation concerns the last, indirect testimony mentioned in the  updated version of the report of
the Tahrir Institute. Regarding this person, the report of the Tahrir Institute states: “He said he was from
Darfur and was recruited for the armed struggle. He claimed he was a minor (16 years old) but a medical
examination (bone scan) carried out by the Belgian authorities determined he is 20 years old +/-2 years. ...
Once in Khartoum he was questioned and beaten for a fully day, then released. He went home to his
family. A week later, a group of men (probably form intelligence) came to violently take him away from his
home, and this was witnessed by the relatives present. Since then, he has disappeared. One of his uncles
–a deportee from Israel –was recently killed for having attempted to migrate.” The information mentioned in
the report about an attempted removal via Istanbul, from where the person concerned was allegedly sent


-----

back to Belgium with an escort by the Turkish authorities, is clearly not true: the planned removal via
Istanbul was cancelled before the departure to Istanbul. This raises doubts about the accuracy of the rest
of the testimony. It is likely that the testimony is not based on the own words of the person concerned or of
a family member who has met the person concerned. In order to find out more about this aspect, the
CGRS had a conversation with two Sudanese nationals who were said to have more information or to be in
touch with the person concerned or his relatives. The first person, who was contacted on the advice of Mr
Koert Debeuf, informed us that he did not know that much and had go this information from another
person. This person (still detained in a removal centre, heard on 7 February 2018) in turn let us know that
he had not had any direct contact. However, he claimed to have been present during a conversation of a
fellow inmate (who left for Italy in the meantime) with a person living in France, at the end of December.
This person in turn was allegedly in touch with relatives of the “missing” person. Until now the CGRS has
not been able to obtain more information. Therefore, it is difficult to assess the profile of the person
concerned and the claims made, especially the fact that the person has disappeared. But in this case also,
some elements of the so-called testimony are clearly not true, which raises doubts about the truthfulness of
the rest of the testimony. Moreover, it was found that various persons gave the impression that they had
been in touch with the person concerned, whereas this appeared to be untrue.”

A267. In its conclusions, the report states (page 15) that:

“The CGRS has not been able to obtain absolute certainty or clarity regarding the question whether the
facts mentioned in the note of the Tahrir Institute have actually taken place. But for the three most
important testimonies from the report of the Tahrir Institute, some important parts of the testimony have
been found to be untrue, to the extent that this casts serious doubt on the rest of the testimony. To obtain
more certainty in this matter, additional research would be necessary.”

A268. The report concludes (page 16) that:

“…the removal or return of persons to Sudan can be resumed providing the protection need of each of the
persons concerned has been assessed 'on its merit' beforehand (including a protection need regarding
article 3 ECHR).”

_6. Landinfo Response to UK Home Office Query on Sudan (April 2018)._

A269. We were referred to short passages in the Landinfo (Norway) response to an enquiry via EASO, by
the Home Office (dated 9 April 2018).  In section 2 of the response, the document deals with the interest of
the NISS in individuals coming from the conflict areas as follows:

“In meetings with Landinfo in Sudan, our sources have generally stated that NISS definitely has a special
focus on the populations coming from the conflict areas. According to one source, NISS has a special
“tribal branch” dedicated to monitoring political activity among populations with origins in the periphery.
Activists with origins in South Kordofan have pointed out that NISS in particular monitors four groups
among Nubans: people belonging to armed groups, activists, those with higher education, and recent
arrivals.

     -   People belonging to armed groups will face arrest if identified by NISS. This applies especially to
persons who have taken up arms and people who provide practical support, but also to political supporters.

     -  Activists are in focus as they are seen as people who actively influence others to support organisations
that are critical towards the regime's politics regarding the “Two Areas”. The definition of activist is wide
and not limited to members of political parties or the political wings of armed groups. (Activists from conflict
areas belonging to civil society organisations or political parties are fairly often suspected and/or accused
by NISS of supporting armed groups.)

     -   People with higher education (high school or more) are followed more closely than others, as they are
“potential activists” and people with influence over others within the community.

     -   Recent arrivals from zones with ongoing armed conflict are followed closely to keep them from sharing
information about recent developments, the humanitarian situation and human rights violations committed
b S d d f th i i t ti i t ti th h i ht it ti


-----

What is difficult to tell, is whether NISS operatives outside the “Two Areas” fine tune their monitoring to
mainly include people who are known to belong to ethnic groups or other social communities that are
perceived as being “in opposition”, or if they focus on people with Nuba origin in general.”

A270. In relation to the issue of discrimination, the response says this:

“There is no institutional, explicit discrimination based on ethnicity regarding access to state services and
the like. On the other hand, the regime does very little to level out the deep rooted social and economic
differences in Sudanese society, whether these differences follow ethnic (or regional, or religious) divides
or not. Therefore, access to public services and resources is generally easier for the urban middle class,
which is dominated by Nile River Arabs, than for other segments – especially those with origins in the
periphery.”

**E. The Respondent's Documents**

A271. Mr Thomann placed before us a number of recent Home Office documents prepared by the Country
Policy and Information Team (CPIT) relating to the current situation in Sudan. The main document is a
“Response to an Information Request: Sudan” (23 October 2019) (“CPIT 1”). In addition, in relation to a
specific issue of return there was a “Response to an Information Request: Sudan” (22 October 2019)
(“CPIT 2”). We were further referred to a document produced by the International Crisis Group,
“Safeguarding Sudan's Revolution” (21 October 2019) (“the ICG report”). That document is extensively
referred to and cited in CPIT 1 and we refer to its detail in the citation from that Home Office document.

A272. With one exception, Mr Jacobs in his written submission accepted that the Home Office documents
were “broadly uncontentious”. The one exception concerned an email from the British Embassy in
Khartoum at Annex A of CPIT 1, the content of which was in dispute and dealt with by Dame Rosalind in
her evidence.

_1. Response to an Information Request: Sudan (23 October 2019) (“CPIT 1”)_

A273. The political situation is summarised in paras 2.1.1 – 2.1.2 of CPIT 1, relying heavily on the ICG
report, as follows:

“2. Political situation: summary

2.1.1. International Crisis Group (ICG) in a report dated 21 October 2019, based on interviews with
informed individuals and publicly available sources, summarised events leading to the formation of the
transitional government, the main political actors and dynamics, and key challenges facing the country:

'Sudan has swung between hope and despair since 11 April [2019], when the most sustained civilian
protest movement in the country's modern history swept Omar al-Bashir from power. Many Sudanese
celebrated Bashir's ouster, seeing him as responsible for economic ruin and severe rights abuses. But the
generals who sought to placate the demonstrators by deposing Bashir have shown reluctance to cede
power. The security forces' brutal 3 June attack on protesters in Khartoum repulsed the world and
galvanised support for mediation that yielded a power-sharing agreement on 17 August. Still, more outside
support is needed to keep the transition on track. The African Union (AU) should appoint an envoy to help
bridge the gap of mistrust between parties. For their part, Western powers should signal willingness to
open the taps of badly needed financial support, encourage Khartoum to make peace with rebel factions
on Sudan's periphery, and sustain pressure on the generals' Gulf allies to ensure that all sides abide by the
deal Sudan needs to move ahead after Bashir's rule.

There have been encouraging steps since the military leadership and civilian opposition signed a
constitutional declaration sealing the power-sharing agreement at a ceremony by the Nile in Khartoum.
The parties named representatives to an eleven-member sovereign council that is to steer the country to
free elections over the 39 months following 17 August. A widely respected economist, Abdalla Hamdock,
became prime minister four days after the ceremony, and a new cabinet took office on 8 September. But
the generals continue to wield enormous influence, and they have shown few signs that they intend to
respect the Sudanese people's demand for a civilian-led administration. In Sudan's lopsided, patronaged i th t b h l i t t i li i t liti l


-----

That is just one challenge among many. In addition to being a potential spoiler, the security establishment
is fragmented, unaccountable and subject to dangerous internecine rivalries. The once-dominant army has
lost its primacy to the Rapid Support Forces, a paramilitary group formed from the remnants of the
Janjaweed militia of Darfur infamy and run by Muhammad Hamdan Dagalo “Hemedti”, who may be the
most powerful man in Sudan. The country's primary military and paramilitary orgnaisations should be
unified under one command, but that project will require patience and encouragement from outside powers
like Saudi Arabia and the United Arab Emirates (UAE). Forcing the issue could result in confrontation at a
time when the last thing Sudan needs is more conflict.

Then there is the challenge of maintaining the unity of the extraordinarily broad civilian coalition – named
the Forces for Freedom and Change – that has been at the vanguard of the uprising. Comprising
professional associations, civil society groups, unions, political parties and armed groups, the coalition has
had its own internal struggles. It will need to deftly manage them lest the security establishment use
fissures in its unity to peel off constituents and weaken it politically.

There are also wars on the country's periphery – in the Blue Nile, Kordofan and Darfur regions – that tear
at national cohesion. The transitional government should focus on ending these conflicts.

Yet for all the challenges standing in Sudan's transitional path, there are reasons for hope. For one thing,
the protest movement's strength and increasing sophistication set it apart from anything in the country's
recent history. The generals have already seen that strong-arm tactics of the sort used to quell prior
movements – for example in 2013 – are not likely to work here. For another thing, a botched transition
could stymie prospects for a surge of desperately needed international support and investment in Sudan's
flailing economy. That is an outcome for which the security forces will almost certainly not wish to be
blamed.'

2.1.2. The ICG report also observed:

'There is also much to do on the economic front. Rescuing Sudan's anaemic economy will require broad
international support through a major multilateral donor initiative. Hamdok has estimated that the country
needs a [US] $10 billion infusion over the next two years. Donors, including the US, the EU and its
member states, and Gulf countries, should begin taking steps to support this request. The US should also
move expeditiously to rescind Sudan's designation as a state sponsor of terrorism, which forbids
international financial institutions from issuing loans and impedes other foreign investment, thereby
hobbling Sudan's private sector. Lifting the designation would help the newly appointed, civilian-led
cabinet by giving it an early win and would be an important step toward Sudan's qualifying for debt relief.
External partners should couple these supportive measures with stern warnings that spoilers in Khartoum
who impede the economic and political reforms necessary for Sudan's successful transition will be subject
to targeted sanctions on part of the AU, EU and US.

Sudan is one of Africa's most important countries, sandwiched between two major powers, Ethiopia and
Egypt, abutting the Red Sea and located in a region scarred by instability. The benefits of a successful
transition are potentially enormous, and the cost of state failure would be vast. Until recently, it was hard to
imagine a moment of opportunity like the country now faces. It would be a mistake to squander it.' “

A274. Section 3 of CPIT 1 deals with the peace talk between the new government and the rebel forces.
The section draws again upon the ICG report but also a number of other sources, some less formal than
others, to describe the recent developments in Sudan:

“3.  Peace talks with armed opposition

3.1.  Armed groups.

3.1.1. Radio Dabanga reported on 15 October 2019 that the Sudan Revolutionary

Front (SRF) is an:

'… alliance [that] consists of the Sudan People's Liberation Movement-North faction led by Malik Agar
(SPLM-N Agar) in Blue Nile state, and the Darfuri Justice and Equality Movement, the Sudan Liberation


-----

Movement faction under the leadership of Minni Minawi (SLM-MM), and the SLM-Transitional Council
faction headed by El Hadi Idris.

In March 2017, Abdelaziz El Hilu resigned from his position as SPLM-N deputy chairman, blaming the
movement's peace talks delegation of neglecting the right to self-determination in the conflict regions. The
Nuba Mountains Liberation Council publicly supported the resignation and replaced leader Agar with his
deputy El Hilu, which paved the way for a split in the SPLM-N.

The mainstream Sudan Liberation Movement under the leadership of Abdelwahid El Nur withdrew from the
SRF when the alliance opted for a peaceful solution instead of continuing the armed struggle. El Nur says
he will only join peace negotiations after Khartoum has restored stability and security in Darfur.'

3.1.2. The ICG report observed that:

'The [SRF]… has since splintered, however, limiting its relevance as an armed force. Among its constituent
parts, the Sudan People's Liberation Movement-North faction under Malik Agar, of Blue Nile, and Yasir
Arman, of northern Sudan, lost most of its fighters following a bitter split in 2017. Darfuri rebel leader Minni
Minnawi's Sudan Liberation Army faction is now based in Libya as mercenaries fighting on behalf of
General Haftar. The fighting force of the Justice and Equality Movement under Jibril Ibrahim is thought to
have dwindled below a few hundred operating in South Sudan and Libya. These groups' political strength
among Sudanese is difficult to gauge but is likely eroding, even in war-affected regions.

Though vocal in its efforts to get a seat at the table during transitional agreement talks, the Front is in
reality overshadowed by larger, more powerful armed groups that sit outside it. One is the Sudan People's
Liberation Movement-North faction led by Hilu, who took most of the rebel fighters with him in the 2017
split. Hilu has a secure stronghold in the Nuba Mountains of South Kordofan and commands the largest
rebel faction in Blue Nile. Another is the Sudan Liberation Movement faction of Abdul-Wahid al-Nur, which
is the only remaining significant rebel force in Darfur. Nur's faction has declined in power in its Jebel Marra
stronghold during his long self-imposed exile in France, as has the strength of his personal command. Both
leaders disengaged from peace talks in Bashir's final years – especially Nur, who earned notoriety among
diplomats for his consistent refusal to enter negotiations.'

3.2.  Peace Process – Juba Declaration of Principles

3.2.1. The ICG report of 21 October 2019 noted

'The new transitional government must reckon with the legacy of decades of efforts by elites in the
wealthier riverine centre to subdue rebellions across the country by force. This legacy encompasses
several regions devastated by conflict, huge displaced populations and an array of rebel movements, some
scattered outside Sudan's borders. Bringing peace to warring areas should be a priority during the
transitional period and will require careful consideration of the accommodations that the rebels are seeking.
These include steps to reverse the imposition of Islamic law on religious minorities, separate religion and
state, and provide for a fairer distribution of power and resources to areas in the periphery, including by
allowing them to elect governors rather than imposing these from distant Khartoum.'

3.2.2. Radio Dabanga observed that “In the Juba Declaration of Principles, signed by the Sudanese
government and the rebel movements on September 11 [2019], it was agreed to begin negotiations midOctober [2019] for a period of thirty days, a comprehensive ceasefire by the two sides, the abolition of
death sentences facing leaders of armed movements, and the release of prisoners of war.” The same
source also reported that on Monday 14 October 2019 “Sudanese peace talks began in Juba, at the
invitation of South Sudanese President Salva Kiir. During the inaugural session, the chairman of the
Sudanese Sovereign Council, Lt Gen Abdelfattah El Burhan, stressed Khartoum's commitment to
achieving a comprehensive peace in the country”.

3.2.3. However, the Sudan Tribune reported that the Sudan Liberation Movement – Abel Wahid al-Nur
(SLM-N) “… refuses to take part in the Juba peace process and called to hold a referendum on the
legitimacy of the transitional authority before to join the peace process.”

3 3 Peace agreement


-----

3.3.1. Radio Dabanga went on to note that “The current chairman of the Sudan Revolutionary Front (SRF,
an alliance of Sudanese armed movements), El Hadi Idris, emphasised the SRF's commitment to reach a
comprehensive peace agreement, stating that the change in Sudan which happened with support of the
rebel movements has created a new reality open for peace.”

3.3.2. The Sudan Tribune reported on 20 October that:

'[The] Transitional government and the Sudanese Revolutionary Front have reached a political agreement
paving the way for the launch of talks for peace in Darfur region and the Two Areas.

According to the draft political agreement seen by Sudan Tribune, the parties will sign also an agreement
renewing the cessation of hostilities for humanitarian purposes.

Also, “the government will deliver humanitarian assistance from inside and outside Sudan to conflictaffected areas”.

The former regime had failed to sign such agreement in the past as the government wanted to control the
humanitarian aid and demanded that all the assistance be delivered through the government-controlled
areas…. Under the would-be signed agreement, the parties also agree to negotiate all issues related to the
Sudanese crisis, including areas of armed conflict, national issues and specific issues.

The deal provides to review previous decisions on dams and the territory of the northern state, referring to
the dispute on Kajabar dam.'

3.3.3. Radio Dabanga similarly reported on 21 October 2019 that '[t]he Sudan Revolutionary Front (SRF,
an alliance of Sudanese armed movements) and the Sudanese transitional government, today signed an
agreement in the South Sudan capital of Juba, paving the way for the launch of talks for peace in Darfur
and the Two Areas'. The article went on to note that:

'The political agreement also includes an agreement renewing the cessation of hostilities for humanitarian
purposes. The government will also deliver humanitarian assistance from inside and outside Sudan to
conflict-affected areas.

The parties agreed to negotiate all issues related to the crisis in Sudan, including areas of armed conflict,
national issues, and specific issues.'

3.3.4. On the peace agreement with the rebel groups, DW reported on 21 October 2019 that:

'Sudan's government has signed a political declaration with rebels, calling it a major step toward ending
years of civil war. A nationwide cease-fire was also extended as part of efforts to create a lasting peace.

Sudan's new government and major rebel groups have signed a declaration opening the door for further
political talks while also renewing a cease-fire for three months, all part of efforts to end the country's years
long civil wars.

"The political declaration will pave the way for political negotiations and is a step toward a just,
comprehensive and final peace in Sudan," said General Mohamed Hamdan Daglo on Monday. Daglo is a
key figure in the transitional government that is tasked with transitioning to civilian rule after the ouster of
President Omar al-Bashir in April.

The Khartoum administration also agreed to let aid into war-torn areas including Darfur, the Nuba
Mountains and Blue Nile regions, which were cut off from humanitarian groups during al-Bashir's rule.'

Peace agreement – SPLM-N (El Hilu)

3.3.5. The Sudan Tribune observed that 'The government is holding a separate process with the SPLM-N
led by Abdel Aziz al-Hilu [from discussions with the SRF] The rebel group which is not part of the SRF
umbrella demands the right of self-determination if the government fail to repeal Islamic legislations and
ensure fair representation to the Sudanese minorities in the state institutions.'

3.3.6. However, on 16 October 2019, Radio Dabanga reported that the SPLM-N (El Hilu):


-----

**'… has suspended negotiations with Sudan's transitional government on Wednesday accusing government**
forces of violating the agreed ceasefire.

A statement issued by Ammar Daldoum, head of the movement's delegation to the negotiations in Juba …
said that [on 15 October 2019,] elements of the Rapid Support Forces (RSF) government militia driving
Land Cruisers reportedly ambushed civilians on the road which connects the western and eastern regions,
near Khor Waral in Habila locality, which is part of the “liberated areas”. The RSF detained 16 people. They
released three of them later, but still hold 13 people including their goods and belongings.'

3.3.7. In response, the “Chairman of Sudan's Transitional Sovereign Council (TSC), Lt Gen Abdelfattah El
Burhan, on Wednesday issued a constitutional decree declaring a cease-fire "on al fronts throughout
Sudan". He asserted that "this decree affirms the sincerity of the leadership to move forward for achieving
peace, halting the bloodshed and meeting the demands of the Sudanese people and leading the country to
the ranks of developed countries".

3.3.8. On 18 October 2019, after resuming discussions, “the Sudan People's Liberation Movement-North
faction under the leadership of Abdelaziz El Hilu (SPLM-N El Hilu) and the Sudanese government reached
an agreement on a roadmap for peace negotiations concerning South Kordofan.” The agreement

'… defines three negotiating items concerning political, security, and humanitarian arrangements.

The spokesman for the SPLM-N El Hilu negotiation team, El Jak Mahmoud, reported in a press
conference… that the two negotiating parties expressed the necessity to agree on a Declaration of
Principles as a roadmap for the regulation of the peace talks process. Also, the two parties agreed to
present their perceptions on the political agenda.

'The agreement was signed by Lt Gen Shamseldin Kabashi on behalf of the Sudanese government, Amar
Daldoum, chairman of the SPLM-N El Hilu negotiation team, and Tut Galwak, the chairman of the South
Sudanese mediation committee.'

3.3.9. The Sudan Tribune reporting on 21 October 2019 observed:

'Deputy leader of the Sudan People's Liberation Movement-North (SPLM-N) led by Malik Agar Yasir
Arman, predicted that the humanitarian situation in the war-affected areas will improve after the Sudanese
Transitional Authority agreed to introduce relief from inside and outside the country.

The transitional government and the Sudanese Revolutionary Front (SRF) signed a political agreement
and a cessation of hostilities agreement providing to open humanitarian access to the rebel areas.

“The government will deliver humanitarian assistance from inside and outside Sudan to conflict-affected
areas" read the agreement signed in Juba on Monday [21 October 2019].

'It is the first time since the long-time Operation Lifeline Sudan (OLS) that the government accepts the
delivery of humanitarian assistance from outside the country and the armed groups accepts food delivery
by government agencies… According to the signed deal, the parties will seek a mandate from the Peace
and Security Council of the African Union.

Further, besides the national issues such as development and national wealth distribution, the tracks will
discuss the armed conflicts in Darfur and the Two Areas, and the issues of eastern and northern Sudan.'

A275. At para 3.4 CIPT 1 records the announcement of a permanent ceasefire in the three conflict zones,
including South Kordofan as follows:

“3.4. Ceasefire

3.4.1. As part of the peace agreement (and during the negotiations), the government announced a
permanent ceasefire in the 3 conflict zones (Darfur, Blue Nile and South Kordofan). Aljazeera reported
that there had been unofficial ceasefire in place since the former President Omar al-Bashir had been
overthrown in April 2019.”

A276. In section 4, CIPT 1 sets out the new government's constitution including the two ministers from the
E t S d i d Bl Nil St t th i t t f Chi f J ti hi hl t d


-----

Supreme Court Judge and the first woman to hold that position along with the appointment of a new
Attorney General.

A277. Section 5 of CPIT 1 deals with the security situation, again drawing heaving on the ICG report, as
follows:

“5. Security sector power and reform

5.1.1. The ICG report of 21 October 2019 observed:

'In practice, however, and though the civilian-led cabinet has wide popular support, the security
establishment continues to hold most instruments of raw power in the country. It has control of the streets,
a grip on Sudan's illicit economy, and political and financial backing from foreign capitals, principally Riyadh
and Abu Dhabi.

This establishment is far from being a cohesive body. At its core, it comprises the Sudanese Armed
Forces, Hemedti's RSF, the intelligence services and allied militias. It is vulnerable to internecine rivalries.
Its constituent parts have their own loyalties and political backgrounds. Against this backdrop, the security
sector represents a dual threat to the peace process. It is, first and foremost, a spoiler that may try to block
civilian oversight of the transitional government in order to preserve the extensive prerogatives it enjoyed
under Bashir and has not yet been forced to yield. Additionally, its internal divisions could spur instability if
they blow up into armed clashes.'

5.1.2. The ICG report goes on to discuss the strengths and weakness of the key security actors – the LtGeneral Burham and the Sudanese Armed Forces; General 'Heme Dagalo (known as 'Hemedti') and the
Rapid Support Forces; Salah Gosh and National Intelligence and Security Services (NISS; now renamed
the General Intelligence Services) – and its recommendations for managing these competing interests
within the government.”

A278. Section 6 deals with “Political Opposition” and the context of the FFC and its future role in
sustaining democratic change. Again, the document draws heavily on the ICG report:

“6. Political opposition

6.1. Diversity and cohesion

6.1.1. The ICG considered that:

'The Forces for Freedom and Change is a fragile coalition of parties, political personalities, unions and civil
activist groups often with competing interests, divergent constituencies and opposing ideologies. Some
veteran opposition party leaders within its ranks are part of the same old guard that many Sudanese view
as sharing responsibility for the country's woes. Its younger leadership cohort, however, particularly the
professionals and civil society figures who organised the protest movement, enjoy great credibility with the
public, as demonstrated by their capacity repeatedly to summon tens of thousands of Sudanese into the
streets.

Throughout, the opposition has shown not only determination but also a mastery of optics. The sit-in
outside the army's Khartoum headquarters was redolent with symbolism – and made for great television. In
naming Ahmed al-Rabia, a schoolteacher who drives a taxi at night to supplement his income, as a chief
spokesman in April, the opposition drew a sharp contrast between its support base – ordinary Sudanese
seeking change – and the generals who got rich during Bashir's long rule.'

6.1.2. The ICG report cautioned 'The Forces for Freedom and Change coalition is expected to form the
bedrock of support for efforts to institute full civilian rule at the end of the pivotal 39-month transition, but it
is a work in progress. For all the FFC's accomplishments, it is not yet clear whether its many component
organisations will maintain the unity required to check the security sector.'

6.1.3. The ICG report goes on to discuss the opposition groups and their internal dynamics

6.1.4. Radio Dabanga reported on 13 October 2019 that:


-----

'El Sadig El Mahdi, head of Sudan's opposition National Umma Party (NUP), has warned that “the current
transitional regime is deadlocked because of manoeuvres on peace, conspiracies by former regime
members, opportunistic foreign interventions, as well as economic conditions”… He called for what he
called “digging out the manoeuvres of the peace project”. He said he considers peace as part of the
permanent constitution, adding that among the challenges facing the transitional system will be imbalances
within the Forces for Freedom and Change (FFC).

He described the transitional emergency programme submitted by a committee of the FFC as “weak”,
stressing the support of the NUP for the transitional government until the end of the transition period.'

A279. Section 6.2 of CPIT 1 deals with demonstrations and marches in Khartoum during October and
citing the Middle East Monitor, para 6.2.7:

“6.2.7. The MEM also observed that:

'A statement by the police stressed that “the constitutional document and the law guarantee the right of
peaceful expression and demonstration.” It also called on all parties to “provide the requirements for the
holding and conduction of rallies and marches, and to stick to routes and timings, to secure and protect
those gatherings.” … To date, no violent clashes between security authorities and demonstrators have
been reported.'”

A280. In section 6.3, CPIT 1, again with citation from the ICG report, deals with “Islamic discontent”:

“6.3. Islamic discontent

6.3.1. The ICG report of 21 October noted:

'The coup against Bashir and the generals' consolidation of power with Gulf backing has put Sudan's
Islamist political machinery, embodied in recent years primarily by the ruling National Congress Party, out
of order. Its incapacity may be temporary, however, since it still controls layers of the state bureaucracy
and military. A failed counter-coup attempt on 24 July, reportedly involving Islamist-allied military
personnel, suggests that at least some of Bashir's old guard may see themselves as his legitimate heirs.

Sudan's version of the so-called deep state has its roots in the country's Islamist movement, which Bashir
co-opted first to mount his own coup in 1989 and later to extend his rule. This movement, the National
Islamic Front, was led by the prominent preacher Hassan al-Turabi for almost ten years. It was a major
component of Sudan's ruling party and controlled much of the government bureaucracy….

By standing apart from the transition, and in fact defining themselves in opposition to both the civilian
coalition and the generals, parties associated with Islamism could well profit from the inevitable challenges
that the transitional government will face. Because they are outside of it, they stand to gain public support
should the transitional government be unable to deliver on key promises, especially with respect to reviving
the economy. Further, they may be able to call upon eager patrons in Qatar and Turkey, which are both
looking for opportunities to regain their foothold in Khartoum.

That said, both Abu Dhabi and Riyadh are keen to keep parties with strong links to Islamists in political
exile. These two monarchies calculate that Sudan's security forces are their most dependable ally in that
regard. The civil society component of the opposition coalition has also consistently rejected any
accommodation with Muslim Brotherhood-style political Islam, identifying it as a legacy of Bashir that must
be swept away.'

6.3.2. The Sudan Tribune reported on 20 October:

'The Sudanese army called on political forces planning to demonstrate on Monday to stay away from the
headquarters of the armed forces in Khartoum and the various positions of its forces in the country.

The warning comes after calls by Islamist groups to demonstrate on the 55th anniversary of the 21 October
Revolution to demand the army seize power and remove Forces for Freedom and Change from power.


-----

The anti-revolutionary calls triggered other calls by the Sudanese Professionals Association, the
spearhead of protests that brought down the al-Bashir regime to demonstrate and hold public rallies on
Monday to defend the revolution and demanding the dissolution of the National Congress Party.

On the same vein, the Sudanese Communist Party called for a protest to demand the transitional authority
to realize the goals of the revolution.

In a statement issued on Sunday evening, Sudanese army spokesman Brigadier General Amer Mohamed
al-Hassan renewed the support of the Sudan Armed Forces for the December Revolution and recalled that
peace will not be achieved without political stability in the country.

Al-Hassan also stressed that the armed forces will remain a "faithful guardian of the country", but will not
interfere in political practices.'”

A281. Section 7 deals with the economic crisis and the fall of the al-Bashir regime. At para 7.1.3, the
report states that the aim of the government is to remove blocks on accessing international finance by
achieving Sudan's removal from the US list of state sponsors of terrorism.

A282. Section 8 of CPIT 1 deals with changes to the law and the intention to give prosecution powers to
an independent investigation committee into the brutal attacks on the pro-democracy protesters in June
2019 and to a commitment to abolish the Public Order law:

“8. Prosecution for past crimes, impunity and legal reform

8.1.1 The Sudan Tribune reported on 17 October 2019:

'[The] Minister of Justice, Nasr al-Din Abdel Bari and Attorney General Taj al-Sir al-Hebir on Thursday
discussed the drafting of laws allowing to dismantle the former regime based on the constitutional
document.

The two officials further agreed to give prosecution powers to the independent investigation committee on
the brutal attack on the pro-democracy protesters.

The meeting discussed the amendment of the Public Prosecution Law, the National Investigation
Committee formed under the Transitional Constitutional Document, the Joint Committees and the files
before the Ministry of Justice related to some major corruption affairs, said a statement released by the
office of the Attorney General… According to the statement, the Attorney General agreed to grant
prosecution powers to the Independent National Investigation Committee, to draft amendments to the
Public Prosecution Law, and other laws restricting freedoms.'

8.1.2. The Sudan Tribune also reported on 19 October 2019:

'[The]… Justice Minister Nasr al-Din Abdel Bari on Saturday [19 October] reiterated the transitional
government's commitment to abolish the Public Order Law and to amend the Criminal Code articles that
violate women basic rights.

The minister made his remarks after receiving a memorandum on women rights from women groups at the
inauguration of the Violence Against Women Database project launched by Darfur Lawyers Association
and the Ma'an (Together) Cultural Centre… Under Sudan's public order, Sudanese women face arrest and
punishment of up to 40 lashes if they violate Article 152 of the Criminal Act of 1991, which broadly prohibits
"indecent and immoral acts."

Most of the offences prohibited under this law relate to gender interactions, dance, choice of dress,
smoking, and other behaviours that the authorities consider as violating moral Islamic standards.

In a report on the Public Order Law in 2010; Human Rights Watch, citing police sources, said that in
2008the police brought 43,000 public order charges against women in Khartoum state alone.'

8.1.3. The Sudan Tribune reported that:

'[The]… transitional government has announced a three-month extension of the state of emergency.


-----

“"The Presidential Decree No. (8) extending the state of emergency in all regions of the country for three
months will take effect on Friday, 11 October 2019," said Mohamed al-Faki, member of the Sovereign
Council in a statement issued on Thursday.

Al-Faki stressed that during the state of emergency, the Council of Ministers may take any measures that
do not restrict, partially repeal or limit the effects of the Constitutional Document.

The ruling Forces for Freedom and Change (FFC) this week announced the extension of the state of
emergency allow the detention of the leaders of the former regime who are not yet investigated or facing
justice.

However, the Islamist Popular Congress Party which was part of al-Bashir's government condemned the
extension saying it is "contrary to the revolution of the Sudanese people."”

A283. In section 11, CPIT 1 considers the position of the Nuba first as an overview, then in Khartoum and
finally outside Khartoum:

“11. Nuba: human rights violations

11.1. Overview

11.1.1. There is limited information in sources consulted in this note about the treatment of Nuba generally
or in Khartoum in particular prior to and following the formation of the transitional government in August
2019.

11.1.2. Radio Dabanga, which “produces independent news to make sure that everyone, wherever they
are in Sudan is aware of vital information, including outbreaks of disease, gender-based violence, and
human rights abuses. It is the belief of Radio Dabanga the representation of these issues in the media can
help to foster information exchange, understanding, and eventually peace in Sudan” does report on
incidents involving suspected SPLM-N sympathisers in South Kordofan, for example (see below)

11.2. Khartoum

11.2.1. An official at the British Embassy in Khartoum in an emailed response to the country policy and
information team dated 16 October 2019 observed:

'… I don't think we will be able to provide information more detailed or evidently useful than what you have
already produced [reference to 1 October 2019 draft of COI response 10/19-068, final version dated 4
October 2019].

Anecdotally, Sudanese contacts have expressed surprise at the suggestion that Nuba people are subject
to systematic discrimination or mistreatment in Khartoum, with the exception that they might find it more
difficult to obtain employment. However, this was placed in the context of high unemployment and broader
cultural discrimination whereby employers in Sudan favour people from their own tribes. General Shams
al-Din Kabbashi, who is a member of Sudan's newly formed Sovereign Council… is Nuba and a significant
number of Nuba are studying at university in Khartoum. Conversely but also anecdotally, DFID colleagues
have advised of a small number of violent incidents in open areas in Khartoum in which people were killed.
These are not known to have specifically targeted Nuba but more generally “southerners”.

On the current situation, we are still monitoring for evidence of meaningful change in how the security
apparatus and police are operating. Your political situation update [COI response 10/19-068, as above]
correctly notes that RSF Commander Hemeti sits on the Sovereign Council. The new Minister of Interior
who has responsibility for the police is also one of two ministers (along with Defence) who were not civilian
appointees and this might mean that there will be little change in how they operate.'

11.2.2. The US Commission on Religious Freedom (USCIRF) reporting on events up to April 2019, but
mainly focussing on events in 2018 and therefore prior to the formation of the transitional government,
stated:

'Christians from the Nuba Mountains are uniquely targeted, highlighting the convergence of discrimination
against religious and ethnic minorities by the government. For example, security and land authorities


-----

particularly target members and evangelical church leaders of the Sudanese Presbyterian Evangelical
Church (SPEC) and Sudanese Church of Christ (SCOC). During USCIRF's meetings in 2018, evangelical
leaders said that the Ministry of Guidance and Endowments has directly interfered in their church affairs
since 2012. SCOC and SPEC interlocutors reported officials confiscating their papers documenting
property rights. In 2016, Sudanese authorities placed 27 churches on a list to be destroyed, claiming
issues with zoning and illegal construction, but reportedly rescinded the order in 2017. Nevertheless, in
February 2018, authorities bulldozed a SPEC church in the Hajj Yousif neighbourhood in Khartoum.
Church members told USCIRF that police gave no notice and demolished the building in spite of a pending
decision on the church's property rights. Police confiscated belongings from within the church, including all
of the church's books, and reportedly gave them to another individual claiming ownership of the land.
Sudanese officials told USCIRF that churches were not uniquely targeted, and claimed that mosques had
also been demolished for similar issues with zoning regulations… In August 2018, authorities dismissed
the cases of and released eight SCOC leaders who were arrested in 2017. Minority religious leaders and
their lawyers have been monitored, harassed, and frequently arrested for various reasons such as
proselytization or speaking out against the government, accused of criminal activity, detained, forced to
defend themselves in court, fined, and released, on a repeated basis. One Muslim human rights lawyer,
who advocated for non-Muslims' rights and was repeatedly arrested and harassed, was forced to f lee
Sudan in 2018. Some of these arrests have been due to religious leaders' protest over authorities'
interference in church affairs and leadership decisions.'

11.2.3. The USCIRF also observed problems faced by women, although specifically stating if Christian, or
Christian Nuba women, were directly affected:

'In 2018, authorities continued to target women with arrest, harassment, and detention by applying existing
religious laws. In particular, the enforcement of Sudan's public order laws under the 1991 Criminal Act and
other state and local laws continued to uniquely impact women through criminalization of indecent dress
and other offenses based on state interpretations of Islamic principles. Penalties for these offenses
regularly include imprisonment, fines, and lashings, and research by Sudanese nongovernmental
organizations (NGOs) has shown that women have been more likely to receive harsher penalties for some
infractions than men. Determinations for arrests are at the discretion of public order police. Public order
cases are common; according to Sudanese civil society actors, more than 40,000 public order cases are
processed annually in Khartoum State alone.'

11.3. Outside Khartoum

11.3.1. Radio Dabanga reported on 10 October 2019:

'Security forces in rural South Kordofan reportedly continue to violate the rights and freedoms of residents
and confiscate their property in the name of the emergency security measures applicable in the state.

According to neighbourhood committees in Hajeri Djawad south of Delling, the violations include curfews,
arbitrary arrests, and the confiscation of consumer goods in rural areas of the Nuba Mountains through
checkpoints stationed at Abujebel Bridge and Hajeri Djawad.

The committees confirmed complaints filed by residents about arbitrary confiscation of their property.

Hasan Kitan, a member of the Sudanese Professionals Association (SPA) in Delling, told Radio Dabanga
that indiscriminate arrests are ongoing, the latest being the arrest of Jabir El Basha, the Headmaster of
Hajeri Djawad Secondary School two days ago because of a statement on the conflict between herders
and farmers in the area.

The neighbourhood committees demanded the emergency measures be lifted immediately and an
acceleration the peace process.

Kitan said after a conference organised by the neighbourhood committees of Hajeri Djawad on Tuesday
that despite the changes that took place in the country after the revolution, the people living in Delling
locality do not feel that change while the emergency measures continue.'

11 3 2 Radio Dabanga reported on 21 October 2019 that:


-----

'Military Intelligence agents briefly held a group of people, who they said they suspected of being Sudan
People's Liberation Movement-North (SPLM-N) supporters, in El Abbasiya in South Kordofan on Thursday

[17 October 2019]. They still hold one of them.

One of the victims told Radio Dabanga said that members of Military Intelligence halted a passenger
vehicle returning shoppers from the Grand Market of El Abbasiya market to their villages west of the town
on Thursday.

They accused us of supporting the Sudan People's Liberation Movement-North (SPLM-N) in the area and
that, they needed to inspect the vehicle and our purchases,” he reported, “but they just stole most of our
belongings.”

When passenger El Taj Yousef protested the inspection, they took him to the garrison of El Abbasiya.

The source said that the people living in El Abbasiya strongly reject the continual detentions and
confiscations “despite the changes that took place in the country and statements of the governor speaking
about freedom of movement in the region”.'”

_2. Response for an Information Request: Sudan, Returns (22 October 2019) (“CPIT 2”)_

A284. The final document relied upon (CPIT 2), relates to returns to Sudan and is dated 22 October 2019.
It is a response to an information request concerning the figures for returns to Sudan which were compiled
with the assistance of Eurostat's published numbers and the European Asylum Support Office. The figures
do not purport to be comprehensive. The numbers cover the period January 2014 to October 2019.

A285. The total numbers in each of the countries recorded for forced return is relatively low ranging
between 0 (Slovenia) and 27 (Switzerland). Belgium retuned 13 and Sweden 7. The UK returned 15.  Of
the countries considered, only Switzerland confirmed that it returned Nuba to Sudan (see para 4.2.5). The
figures for Switzerland do not, however, disclose if any of the forced returns were, in fact, Nuba. Three
countries – Belgium, Switzerland and the United Kingdom – accepted that applicants for asylum included
those belonging to Nuba groups (para 4.2.4). Slovenia indicated that, whilst it returned rejected applicants
for asylum, their returnees did not include Nuba (or non-Arab Darfuri). Cyprus, likewise, did not return
Nuba (or indeed non-Arab Darfuris) but it did not return any rejected asylum applicants and had no
applications from Nuba.

A286. At para 1.2.1, the document notes that the UK government does not monitor returned asylum
seekers.

**APPENDIX 2**

**Upper Tribunal**

**(Immigration and Asylum Chamber) Appeal Number: PA/00006/2016**

**THE IMMIGRATION ACTS**

**Heard at Newport (Columbus House)** **Decision & Reasons**
**Promulgated**

**On 14 February 2017**

…………………………………

**Before**

**UPPER TRIBUNAL JUDGE GRUBB**


-----

**DEPUTY UPPER TRIBUNAL JUDGE CHALKLEY**

**Between**

**k m**

**(ANONYMITY DIRECTION made)**

Appellant

**and**

**THE SECRETARY OF STATE FOR THE HOME DEPARTMENT**

Respondent

**Representation:**

For the Appellant: Mr A Sinfield of Albany Solicitors

For the Respondent: Mr S Kotas, Home Office Presenting Officer

**DECISION AND REASONS**

**Background**

1. The appellant is a citizen of Sudan who was born on 31 May 1987. He is a member of the Nuba tribe.

2. The appellant left Sudan on 21 November 2014 and, having travelled through a number of countries,
arrived in the United Kingdom on 31 August 2015 and claimed asylum.

3. On 18 December 2015, the Secretary of State refused the appellant's claim for asylum, humanitarian
protection and under Article 8 of the ECHR.

4. The basis of the appellant's claim is set out in the decision letter at paras 2 and 9. The claim was as
follows. First, the appellant claimed to be at risk from the Sudanese government because he belonged to
the Nuba Tribe. Secondly, he claimed that he had been arrested and detained by the government and
accused of being a member of the opposition party, the Sudan People's Liberation Movement (SPLM).
Thirdly, he claimed to fear the SPLM whom he had refused to join. Finally, the appellant relied upon sur
_place activities._

**The Appeal**

5. Following the refusal of his claim, the appellant appealed to the First-tier Tribunal. His appeal was
heard by Judge Sweeny on 3 August 2016. Judge Sweeny dismissed the appellant's appeal on all
grounds. Judge Sweeny accepted that the appellant was a Sudanese citizen and a member of the Nuba
Tribe. However, the judge rejected the appellant's account that he had been arrested and detained by the
Sudanese government. The judge concluded that the appellant would not be at risk from the SPLM not
least because they had shown no adverse interest in him since 2011/12. Finally, the judge rejected the
appellant's claim to be at risk because of his sur place activities.

6. The appellant then sought permission to appeal to the Upper Tribunal. In his grounds, the appellant did
not challenge the judge's adverse credibility finding nor his finding that the appellant had failed to establish
he would be at risk because of his sur place activities or from the SPLM. However, the grounds argue that
the judge failed to consider the risk to the appellant because of his Nuba ethnicity. The grounds argue that
the background evidence submitted to the judge demonstrated that a person of Nuba ethnicity was at risk
simply due to their ethnicity. They were, in effect, a non-Arab tribe similar to non-Arab Darfuris who were
[recognised to be at risk following MM (Darfuris) Sudan CG [2015] UKUT 10 (IAC).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F27-STW1-F0JY-C4J7-00000-00&context=1519360)


-----

7. On 27 September 2016, the First-tier Tribunal (Judge M J Gillespie) granted the appellant permission to
appeal on that ground.

8. On 10 October 2016, the Secretary of State filed a rule 24 response seeking to uphold the judge's
decision, inter alia, on the basis that the appellant had not claimed to be at risk as a result of belonging to
the Nuba Tribe.

**The Submissions**

9. We heard oral submissions from Mr Sinfield on behalf of the appellant and Mr Kotas who represented
the Secretary of State.

10. Mr Sinfield submitted that the appellant had directly raised his fear of persecution due to his ethnicity in
his witness statement dated 25 July 2016 (at A1-A6 of the bundle), in particular at para 10. Mr Sinfield
submitted that the background evidence and the expert report of Dr Bekalo also raised the risk to those of
Nuba ethnicity and equated their position to those of non-Arab ethnicity from Darfur. He accepted that, on
reading the judge's determination, the appellant's (then) Counsel may not have pressed this basis of the
appellant's claim. However, it was properly raised and, in particular, was referred to in Counsel's skeleton
argument before the judge at paras 14-15.

11. Mr Kotas submitted that the judge had not failed to consider a relevant basis upon which the appellant
put his claim. He drew our attention to para 29 of the determination where the judge pointed out that
Counsel had said that the “widespread violence against the Nuba Tribe …[was] … a red herring”. Mr
Kotas submitted that in paras 14 and 15 of the skeleton argument Counsel was not seeking to put the
appellant's case based upon a simple risk because of his ethnicity but rather to support his claim (and
credibility) based on the fact that he had been arrested and detained by the Sudanese authorities. Mr
Kotas submitted that the expert report of Dr Bekalo dated 3 May 2016 (at B3-B15) was based upon the
appellant's claim to have been arrested and detained which the judge considered at paras 98-100 but had
properly given little weight to as he had rejected the appellant's account to have been arrested and
detained. Mr Kotas submitted that the judge's decision should stand.

**Discussion**

12. At the conclusion of the submissions, and following a short adjournment, we informed the
representatives of our decision that we had concluded that the judge had erred in law in failing to consider
the risk to the appellant based upon his Nuba ethnicity. Our reasons for reaching that decision are as
follows.

13. First, we accept that the appellant's (then) Counsel does not appear to have focused to any great
extent, or at all, upon the appellant's claim to be at risk because of his Nuba ethnicity. That is supported by
what Counsel is reported to have said at para 29 of the determination which we set out above. The focus
of the case was, undoubtedly, the risk to the appellant having been arrested and detained by the Sudanese
authorities and any risk due to his sur place activities.

14. Secondly, however, the appellant undeniably raised before the judge in his evidence a fear based
upon his ethnicity. At para 10 of his witness statement he states the follows:

“It is well documented that there is war in the Nuba Mountains (paragraphs 37-28RFRL). The government
is bombing and killing us in the Nuba Mountains and persecuting and discriminating against us everywhere
else in Sudan. The Sudanese government is trying to ethnically cleanse my people in the same way that
they are trying to ethnically cleanse the Africans in Darfur.”

15. That the appellant was relying, as one basis for his claim to asylum, upon his ethnicity could not be
clearer.

16. Thirdly, whilst the matter is not entirely free from doubt, we do not accept Mr Kotas' submission that
paras 14 and 15 of Counsel's skeleton argument did not raise a claim based on the appellant's ethnicity.
Those paras are as follows and appear under the heading “Nuba Tribe”:


-----

“14.  The objective evidence supports the assertion that those who reside in the Nuba Mountains in South
Kordofan and Blue Nile have been subject to numerous indiscriminate attacks and armed conflict **[C73**
**Amnesty 2015/2016]. The Appellant's account as to indiscriminate arrest by security forces in the South**
Kordofan is also consistent with the objective evidence [C166].

15.  The Respondent's position that the Appellant would not be at risk on return to Omdurman is
misconceived. The Tribunal is invited to note the treatment of Nubans generally in Omdurman [C253] and
the treatment of perceived political Nubans [C254].”

17. Whilst those paragraphs can, in part, be seen as adding substance to the preceding two paragraphs
which identify a claimed risk to the appellant due to his arrest and detention, we are not persuaded that
they do not also raise, particularly when read with the appellant's evidence, a claim based upon his
ethnicity.

18. Fourthly, there is also at least some supporting evidence in Dr Bekalo's expert report relevant to a
claim that the appellant was at risk as a non-Arab from the Nuba Tribe. So, at para 3.1 (at B10) it is stated
that:

“It is well documented that human rights violations of persecution continue unabated in Sudan. There is a
political–economy monopolisation and marginalisation, by the so-called Arab tribe groups over non-Arab
tribes, which fuel the widely reported conflict in Nuba/Kordofan and Darfur regions and elsewhere across
Sudan. There is on-going mistreatment and persecution by the GoS against individuals and groups, who
object marginalisation and those believed or perceived to be supporters of rebel groups.”

19. The report then goes on to refer to the atrocities and genocide in the Darfur region.

20. Again, the contrast between Arab tribes and non-Arab tribe – the appellant belonging to the latter – is
referred to on a number of occasions in the report reflecting on the adverse treatment of the latter. At B5 of
the report, Dr Bekalo refers to “conflicts” which are “raging” in Darfur and Nuba/Kordofan.

21. Fifthly, although we were not specifically taken to the background evidence, attacks upon, and illtreatment of, those of Nuba ethnicity can be readily identified in the material, for example, Human Rights
Watch Report, “Sudan: Cluster bombs used in Nuba Mountains” (15 April 2015) (at C93-C96) and Asylum
Research Consultancy, “Situation in Khartoum and Omdurman” (9 September 2015) (at C261-C311)
especially at para 1.2.2. We do not say that these documents establish the appellant's claim but they are
undoubtedly relevant to any claim to be at risk because of Nuba ethnicity.

22. In short, therefore, we are satisfied that the issue of whether the appellant was at risk because of his
Nuba ethnicity was a matter properly raised on the material before the judge. We are unable to conclude
that any such claim was bound to fail and that, therefore, the judge's failure to deal with this aspect of the
claim was a material error of law.

**Decision**

23. For the above reasons, the decision of the First-tier Tribunal to dismiss the appellant's appeal involved
the making of an error of law.

24. We indicated at the end of the hearing that the appeal would be retained in the Upper Tribunal in order
to remake the decision. The sole issue will be the appellant's claim to be at risk on return to Sudan
because of his Nuba ethnicity.

25. The judge's adverse credibility finding and his findings on the other aspects of the appellant's claim
stand and are preserved.

Signed

A Grubb

Judge of the Upper Tribunal

Date


-----

**APPENDIX 3**

**DOCUMENTARY EVIDENCE BEFORE THE UPPER TRIBUNAL**

|Item|Document|Date|
|---|---|---|
|1.|Overseas Development Institute: “Where to Now? Agency Expulsions in Sudan: Consequences and Next Steps”|March 2009|
|2.|Hansard Online: Africa: Post-Conflict Stabilisation|08/07/2010|
|3.|Overseas Development Institute: “City limits: Urbanisation and Vulnerability in Sudan Khartoum Case Study, Sara Pántuliano et al”|January 2011|
|4.|Hansard Online: Sudan|07/02/2011|
|5.|Hansard Online: Migrant Domestic Workers|08/06/2011|
|6.|Hansard Online: South Sudan|26/03/2012|
|7.|Hansard Online: Queen's Speech|17/05/2012|
|8.|Home Office: “Sudan OGN v 17.0”|August 2012|
|9.|Waging Peace: “The Danger of Returning Home”|September 2012|
|10.|Hansard Online: Sudan and South Sudan: EUC Report|17/10/2012|
|11.|Enough Project: Crime against Humanity: Sudan Burns 26 Nuban Villages across 54 Square Miles|06/12/2012|
|12.|Enough Project: Sudan Caucus Brief: Crisis in the Nuba Mountains|11/12/2012|
|13.|British Embassy Letter|08/04/2013|
|14.|Enough Project: Life in the Nuba Mountains – Humanitarian Needs Assessment in Sudan's South Kordofan State|October 2013|
|15.|Enough Project: Sudan Minister Speaks on Resilience as Dire Need in Nuba Mountains Made Public|10/10/2013|
|16.|Hansard Online: Sudan|28/10/2013|
|17.|Small Arms Survey, Andrew McCutchen: “The Sudan Revolutionary Front: Its Formation and Development”|2014|
|18.|Hansard Online: South Sudan|24/03/2014|
|19.|Enough Project: School in Nuba Mountains Bombed for Second Time|27/03/2014|
|20.|Asylum Research Consultancy (ARC): “Sudan COI Query Response”|11/04/2014|
|21.|Enough Project: Human Security Alert: Massive Mobilization of Sudan Armed Forces (SAF) in the Nuba Mountains|15/04/2014|
|22.|Hansard Online: Republic of Sudan: Human Rights|14/07/2014|
|23.|Sudanreeves.org: Minutes of the Military and Security Meeting Held in the National Defence College [Khartoum]|31/08/2014|
|24.|Article 1, Waging Peace: “The Long Arm of the Sudanese Regime”|September 2014|
|25.|Enough Project: Extermination by Design – The Case for Crimes against Humanity in Sudan's Nuba Mountains|November 2014|
|26.|Enough Project: Mass-Scaled Human Suffering in Nuba Mountains, Sudan|20/11/2014|
|27.|Hansard Online: Modern Slavery Bill|08/12/2014|
|28.|British Embassy Letter|19/02/2015|
|29.|International Refugee Rights Initiative: “We just want a rest from war.” Civilian perspectives on the conflict in Sudan's Southern Kordofan State|April 2015|
|30.|Nuba Mountains Peoples Foundation: “Alternative Report to the Committee on the Elimination of Racial Discrimination (CERD)”|April 2015|
|31.|HRW.org: “Sudan: Cluster bombs used in Nuba Mountains”|15/04/2015|
|32.|The Conversation: “The World's Unexplained Silence over Human Tragedy in the Nuba Mountains of Sudan”|20/05/2015|
|33.|Amnesty International: “Don't we matter? Four years of unrelenting attacks against civilians in Sudan's South Kordofan”|July 2015|


-----

|Col1|KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)|Page 125 of 130|
|---|---|---|
|34.|Asylum Research Consultancy (ARC): “Situation in Khartoum and Omdurman”|09/09/2015|
|35.|Enough Project: Life as a Surgeon in Sudan's Nuba Mountains: Atavist Feature|26/10/2015|
|36.|Amnesty International: “Hotspot Italy – How EU's Flagship Approach Leads to Violations of Refugee and Migrant Rights”|2016|
|37.|Nuba Reports.org|2016|
|38.|Humanitarian Aid Relief Trust: “Report on Sudan and South Sudan”|January 2016|
|39.|Joint Report of the UK Home Office and the Danish Immigration Service: Situation of Persons from Darfur, Southern Kordofan and Blue Nile in Khartoum|February to March 2016|
|40.|UN General Assembly Report Summarising Stakeholder Submissions: Compilation prepared by the Office of the United Nations High Commissioner for Human Rights in accordance with paragraph 15(b) of annex to Human Rights Council resolution 5/1 and paragraph 5 of the annex to Council resolution 16/21 - Sudan|19/02/2016|
|41.|Australian Government Department of Foreign Affairs and Trade: “Country Information Report – Sudan”|April 2016|
|42.|Sudantribune.com: “SPLM-N accuses Sudanese army of indiscriminate bombardments in S. Kordofan”|11/04/2016|
|43.|Home Office: “Country Information and Guidance Sudan: Persons involved in 'sur place' activities in the UK”|May 2016|
|44.|Foreignpolicy.com: “The Shrapnel Finds Us Wherever We Hide”|19/05/2016|
|45.|South Kordofan June 2016 Situation Report|June 2016|
|46.|Asylum Research Consultancy: “South Kordofan and Blue Nile Country Report”|01/06/2016|
|47.|VOA news.com: “Sudanese still feeling South Kordofan 5 years into war”|03/06/2016|
|48.|Wikipedia: “Sudanese Conflict in South Kordofan and Blue Nile”|11/07/2016|
|49.|Joint Report of the UK Home Office and the Danish Immigration Service: Situation of Persons from Darfur, Southern Kordofan and Blue Nile in Khartoum|August 2016|
|50.|British Embassy Letter|29/09/2016|
|51.|Refworld: Sudan and Chemical Weapons – a Serial Offender?|10/10/2016|
|52.|Refworld: Amnesty International Report|2017-2018|
|53.|Refworld: World Report 2017 - Sudan|12/01/2017|
|54.|Amnesty International Report 2016/2017: “The State of the World's Human Rights”|22/02/2017|
|55.|US State Department: “Country Report on Human Rights Practices for 2016, Sudan”|March 2017|
|56.|Hansard Online: International Women's Day|09/03/2017|
|57.|SKBN Coordination Unit: Humanitarian Update|April 2017|
|58.|The Conversation: “Tragedy in the Nuba Mountains – Hunger and Starvation are Constants”|17/07/2017|
|59.|Home Office: “Sudan: Country Policy and Information Note; Opposition to the government, including sur place activity”|07/08/2017|
|60.|Home Office: “Sudan: Country Policy and Information Note; Rejected asylum seekers”|10/08/2017|
|61.|US State Department “Sudan 2016 International Religious Freedom Report”|15/08/2017|
|62.|Austrian Centre for Country of Origin & Asylum Research and Documentation (ACCORD): “Sudan, second quarter 2017: Update on incidents according to the Armed Conflict Location & Event Data Project (ACLED)”|14/09/2017|
|63.|National Human Rights Monitors Organisation: “The US lifts sanctions against Sudanese despite opposition from Sudanese in the Nuba Mountains”|October 2017|
|64.|Hansard Online: Sri Lanka|12/10/2017|
|65.|Human Rights Watch: “World Report 2018, Sudan”|January 2018|


-----

|Col1|KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)|Page 126 of 130|
|---|---|---|
|66.|Refworld: World Report 2018 - Sudan|18/01/2018|
|67.|Belgian Government, Office of the Commissioner General for Refugees and Stateless Persons (CGRS): “COI Focus, Sudan: Risk upon return”|06/02/2018|
|68.|Belgian Government (CGRS): “Report on Sudan”|08/02/2018|
|69.|Human Rights and Development Organization (HUDO Centre): “Report on Human Rights Situation in South Kordufan, Blue Nile States/Sudan, January-December 2017”|11/02/2018|
|70.|Amnesty International: “Annual Report 2017/18”|22/02/2018|
|71.|UN Office for the Coordination of Humanitarian Affairs: “Humanitarian Response Plan, January – December 2018”|13/03/2018|
|72.|Waging Peace: “Risk to Individuals from Nuba Mountains in Sudan”|19/03/2018|
|73.|DG ECHO Daily Map: “European Union, Sudan, Refugees, IDPs and Malnutrition”|28/03/2018|
|74.|US State Department: “Country Report on Human Rights Practices for 2017, Sudan”|April 2018|
|75.|Landinfo: “Response to an information request from the UK Home Office”|April 2018|
|76.|African Centre for Justice and Peace Studies: “Human rights violations in South Kordofan”|11/04/2018|
|77.|EASO COI Query Response: “Sudan: People from Nuba Mountains; State and Societal Treatment of the Nuba in Khartoum and Elsewhere; Freedom of Movement from South Kordofan to Khartoum”|18/04/2018|
|78.|US State Department: Sudan 2017 Human Rights Report|20/04/2018|
|79.|US Commission on International Religious Freedom: “Sudan”|25/04/2018|
|80.|Amnesty International Letter|24/05/2018|
|81.|National Human Rights Monitors Organisation: “Human Rights Update: September 2017 – February 2018”|25/05/2018|
|82.|Home Office: “Report of a Fact-finding Mission to Khartoum, Sudan (2018)”|26/11/2018|
|83.|All Party Parliamentary Group (APPG) for Sudan and South Sudan: “Report from Visit to Sudan in September 2018”|10/12/2018|
|84.|SKBN Coordination Unit: “Humanitarian Update”|January 2019|
|85.|Human Rights Watch: “Sudan: Security Forces Killing, Detaining Protesters”|07/01/2019|
|86.|African Centre for Justice and Peace Studies (ACJPS): “Sudan Update: Deaths in Custody, Continued Arbitrary and Incommunicado Detention of Peaceful Protesters and Obstruction of Media Coverage of Protests”|09/01/2019|
|87.|Reporters Sans Frontieres: “Sudan's NISS Steps Up Harassment of Media Again”|15/01/2019|
|88.|African Centre for Justice and Peace Studies (ACJPS): “Sudan: Activists Targeted with Arbitrary Arrest and Incommunicado Detention whilst the Media Remains Restricted amidst Crackdown on December 2018 Peaceful Protest”|17/01/2019|
|89.|European Parliament Resolution of 17 January 2019 on Sudan (2019/2512(RSP))|17/01/2019|
|90.|Human Rights Watch: “World Report 2019 – Sudan”|17/01/2019|
|91.|Office of the United Nations High Commissioner for Human Rights (UNHCR): “Reports of Excessive Force against Sudan Protests Deeply Worrying – Bachelet”|17/01/2019|
|92.|Amnesty International: “Sudan: Security Forces Continue Deadly Onslaught on Protesters and Medical Personnel”|18/01/2019|
|93.|US State Department: “US Concern Over Sudanese Government Response to Protests”|23/01/2019|


-----

|Col1|KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)|Page 127 of 130|
|---|---|---|
|94.|The Arab Weekly: “Al-Bashir Cannot Pin Sudan's Crisis on Foreign Plots”|27/01/2019|
|95.|Human Rights Watch: “Sudan: Video Footage Shows Extreme Violence, Abuse”|10/02/2019|
|96.|Reporters Sans Frontieres: “At Least 79 Journalists Arrested in Two Months of Protests in Sudan”|14/02/2019|
|97.|Reuters: “Sudan's economic decline provides fuel for anger against Bashir”|20/02/2019|
|98.|International Federation for Human Rights (FIDH): “Sudan: 30 Women Detained in Inhumane Conditions Following Involvement in Protests”|21/02/2019|
|99.|Office of the United Nations High Commissioner for Human Rights (UNHCR): “Report of the Special Rapporteur on the Situation of Human Rights Defenders: Observations on Communications Transmitted to Governments and Replies Received (February 2019) [Sudan excerpt]”|22/02/2019|
|100.|Amnesty International: “Sudan: State of Emergency Intensifies Brutal Government Crackdown on Protests”|25/02/2019|
|101.|United Nations News Centre: “Darfur Peace Process at a 'Standstill' as Demonstrations against Sudanese Government Continue”|25/02/2019|
|102.|International Crisis Group: “Bashir Moves Sudan to Dangerous New Ground”|26/02/2019|
|103.|SKBN Coordination Unit: “Flash Update “|March 2019|
|104.|US State Department: “2018 County Reports on Human Rights Practices – Sudan”|13/03/2019|
|105.|African Centre for Justice and Peace Studies (ACJPS): “Sudan Protests: Deep Concern for the Safety and Wellbeing of Eight Activists Detained Incommunicado”|15/03/2019|
|106.|Radio Dabanga: “Massacre in Ardamata, West Darfur Widely Condemned”|17/03/2019|
|107.|Radio Dabanga: “Sudan Uprising – Fourth Month of Mass Demos, Vigils”|20/03/2019|
|108.|US Commission on International Religious Freedom, Annual Report 2019, Sudan|April 2019|
|109.|African Centre for Justice and Peace Studies (ACJPS): “Sudan Protests: NISS Introduces a New Tactic Targeting Chief-Editors after Lifting Censorship against Four Newspapers”|04/04/2019|
|110.|Global Observatory: “How Peaceful Protests in Sudan, Violently Suppressed, Could Yield Political Change”|05/04/2019|
|111.|CNN: “As Sudan Brutalizes its People”|09/04/2019|
|112.|The Times: “Army Splits to Shield Protesters from 'Butcher of Darfur'”|09/04/2019|
|113.|The Times: “Middle-class, Professional Women Become Symbol of Sudan's Revolt”|10/04/2019|
|114.|BBC-Monitoring: Media Guide – Sudan|10/07/2019|
|115.|US Congressional Research Service: “Sudan's uncertain transition”|17/07/2019|
|116.|BBC Monitoring: “Explainer: What next for Sudan after power-sharing deal?”|18/07/2019|
|117.|BBC: “Sudan to charge eight military officers over deadly crackdown”|27/07/2019|
|118.|De Waal, Alex: “Sudan: a political marketplace framework analysis”|Circa August 2019|
|119.|Nubsud Human Rights Monitors Organisation: “Human Rights Update: April – June 2019”|04/08/2019|
|120.|Radio Dabanga: “Sudan uprising: Timeline of tumultuous change”|12/08/2019|
|121.|Waikwa Wanyoike: “'Sudan's Constitutional Charter is a Ray of Hope but Tough Times Lie Ahead' Int'l J. Const. L. Blog”|13/08/2019|


-----

|Col1|KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)|Page 128 of 130|
|---|---|---|
|122.|BBC: “Sudan crisis: What you need to know”|16/08/209|
|123.|International Crisis Group: “Nurturing Sudan's Fledgling Power-sharing Accord”|20/08/209|
|124.|Sudan Tribune: “Al-Burham forms Sudan's Sovereign Council”|20/08/2019|
|125.|US Congressional Research Service: “Sudan: In focus”|21/08/2019|
|126.|Human Rights Watch: “Sudan: Prioritize Justice, Accountability”|23/08/2019|
|127.|BBC: “Sudan's revolutionaries pin hopes on PM Abdalla Hamdok”|28/08/2019|
|128.|Radio Dabanga: “Port Sudan conflict abates”|28/08/2019|
|129.|The New Humanitarian: “Briefing: Sudan comes in from the cold as it transitions to civilian rule”|29/08/2019|
|130.|International Crisis Group: “Crisis Watch – Sudan”|September 2019|
|131.|Radio Dabanga: “Prime Minister Hamdouk presents new Sudanese government”|06/09/2019|
|132.|Aljazeera: “African Union lifts suspension of Sudan”|07/09/2019|
|133.|Aljazeera: “Sudan's first cabinet since Omar al-Bashir's removal sworn in”|08/09/2019|
|134.|Radio Dabanga: “Sudan PM, South Sudan President Kiir discuss peace, open borders for free trade”|12/09/2019|
|135.|Radio Dabanga: “Sudan armed movements: Juba Declaration is a major step forward”|13/09/2019|
|136.|Sudan Tribune: “Expelled aid groups can return to Sudan: official”|15/09/2019|
|137.|Middle East Eye: “Sudan's Hamdok government fails first democracy test”|16/09/2019|
|138.|Sudan Tribune: “Sudan releases 17 POWs says SPLM-N Agar”|16/09/2019|
|139.|Radio Dabanga: “Tens of thousands demonstrate in Sudan for justice”|20/09/2019|
|140.|Middle East Eye: “Sudan's new PM Hamdok orders investigation into killing of protestors”|22/09/2019|
|141.|Human Rights Watch: “Sudan's New Investigation Committee Raises Concerns”|23/09/2019|
|142.|The New Arab: “Sudan requests $2 billion from World Bank to fund economic rescue plan”|23/09/2019|
|143.|Radio Dabanga: “Minister of Finance: sanctions against Sudan will not be lifted within a year”|24/09/2019|
|144.|UN Web TV: “Nasr Al Deen Abdel Bary (Sudan) – 31st Meeting, 42nd Regular Session Human Rights Council”|24/09/2019|
|145.|Janes: “Sentinel Country Risk Assessments, Sudan, Internal Conflict, updated 25 September 2019”|25/09/2019|
|146.|UN Office for the High Commissioner for Human Rights: “Bachelet signs “milestone agreement” to open UN Human Rights Office in Sudan”|25/09/2019|
|147.|Radio Dabanga: “Sudan rebels to send delegation to Khartoum after successful Cairo talks”|26/09/2019|
|148.|Radio Dabanga: “Sudan signs international undertaking for media freedom”|26/09/2019|


149. Sudan Tribune: “SRF to hold public debates on peace in Khartoum before
negotiations”


26/09/2019


-----

|Col1|KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)|Page 129 of 130|
|---|---|---|
|150.|Sudan Tribune: “Sudan agrees to open UN Human Rights office in Khartoum”|26/09/2019|
|151.|Radio Dabanga: “Sudan's National Human Rights Commission: junta played no role in June 3 massacre”|27/09/2019|
|152.|UN News: “At UN, Sudanese Prime Minister says 'great revolution has succeeded', country will rebuild, restore values”|27/09/2019|
|153.|Sudan Tribune: “Al-Nur renews rejection to join Sudan's peace process after meeting Hamdok”|30/09/2019|
|154.|Washington Post: “Seize this moment in Sudan”|30/09/2019|
|155.|BBC: “Sudan PM meets Darfur rebel chief in France”|01/10/2019|
|156.|Just Security: “Bringing the Rule of Law to Sudan”|01/10/2019|
|157.|Sudan Tribune: “Sudan Call accepts al-Mahdi's resignation”|01/10/2019|
|158.|Al-Intibaha (accessed via BBC Monitoring): “Deal reached on Sudan's chief justice and prosecutor nominees”|02/10/2019|
|159.|Baj News (accessed via BBC Monitoring): “Sudan to name chief judge and prosecutor within 24 hours”|02/10/2019|
|160.|Radio Dabanga: “Sudan Minister of Finance: France will support debt relief”|02/10/2019|
|161.|Sudan Tribune: “Sudan's removal from terror list “is a process, not an event”: U.S. diplomat”|02/10/2019|
|162.|Radio Dabanga: “Rebel forum calls for unity, cohesion, and an end to racism in Sudan”|03/10/2019|
|163.|Radio Dabanga: “US Assistant Secretary of State: 'Sudan now is a partner we can cooperate with'”|04/10/2019|
|164.|Sudan Tribune: “Sudan has long road ahead before foreign debt relief: World Bank”|04/10/2019|
|165.|Radio Dabanga: “Security forces abusing emergency measures in Sudan's Nuba mountains”|10/10/2019|
|166.|Radio Dabanga: “Sudan appoints its first woman Chief Justice”|10/10/2019|
|167.|Sudan Tribune: “Sudan's [sic] extends state of emergency for three months”|10/10/2019|
|168.|Radio Dabanga: “Marches for peace and missing demonstrators all over Sudan”|11/10/2019|
|169.|Radio Dabanga: “NUP leader El Mahdi: Sudan's transitional government 'deadlocked'”|13/10/2019|
|170.|Radio Dabanga: “Sudanese peace negotiations launched in Juba”|15/10/2019|
|171.|Radio Dabanga: “University of Khartoum to resume studies this month”|15/10/2019|
|172.|British Embassy, Khartoum: email|16/10/2019|
|173.|Radio Dabanga: “Attorney General: 'Rule of law to prevail in Sudan'”|16/10/2019|
|174.|Radio Dabanga: “Sudanese rebels suspend Juba peace talks after militia ambush in South Kordofan”|16/10/2019|
|175. S|Sudan Culture Minister: “No censorship” at 15th Khartoum International Book Fair|16/10/2019|
|176.|Sudan Tribune: “IMF maintains negative growth forecast for Sudan in 2019 & 2010”|16/10/2019|
|177.|Sudan Tribune: “Sudan transitional government appoints two new ministers”|16/10/2019|
|178.|Aljazeera: “Sudan peace talks resume after deadlock”|18/10/2019|
|179.|Radio Dabanga: “SPLM-N El Hilu, Sudan Government agree on peace talks roadmap”|18/10/2019|
|180.|Sudan Tribune: “Sudan's Justice Minister, Attorney General discuss reforms to dismantle former regime”|18/10/2019|
|181.|Sudan Tribune: “Sudan releases new batch of POWs from armed groups”|19/10/2019|
|182.|Baj News (accessed via BBC Monitoring): “Sudan parties to boycott 21 October protest marches”|20/10/2019|


-----

|Col1|KAM (Nuba – return) Sudan CG [2020] UKUT 269 (IAC)|Page 130 of 130|
|---|---|---|
|183.|Sudan Tribune: “Government, SRF to sign political agreement on peace in Sudan”|20/10/2019|
|184.|Sudan Tribune: “Sudan Justice Minister pledges to end discrimination against women”|20/10/2019|
|185.|DW: “Sudan renews ceasefire pact with reels, lets in aid”|21/10/2019|
|186.|International Crisis Group: “Safeguarding Sudan's Revolution|21/10/2019|
|187.|Radio Dabanga: “SRF rebels, Sudan government sign agreement in Juba”|21/10/2019|
|188.|Radio Dabanga: “Student factions clash in Khartoum”|21/10/2019|
|189.|Sudan Tribune: “Sudanese army calls to stay away from its sites ahead of protests by pro and anti-revolutionary forces”|21/10/2019|
|190.|Home Office: Response to an Information Request - Sudan|22/10/2019|
|191.|Middle East Monitor: “Launch of 'Million-People March to Accomplish Revolution' in Sudan”|22/10/2019|
|192.|Radio Dabanga: “Friends of Sudan supports planned economic reforms”|22/10/2019|
|193.|Sudan Tribune: “Juba Political Agreement will improve humanitarian situation in Sudan: Arman”|22/10/2019|
|194.|Sudan Tribune: “Sudanese demonstrate calling to swiftly dismantle the former regime”|22/10/2019|
|195.|Home Office: Response to an Information Request - Sudan|23/10/2019|
|196.|African Centre for Justice and Peace Studies: “Sudan Human Rights Monitor Report December 2014 – January 2015”|Undated|
|197.|Amnesty International: “Sudan 2015/2016 Report”|Undated|
|198.|CHR, Michelsen Institute: “Sudan Working Paper, 2016, Civilians' Survival Strategies amid Institutionalized Insecurity and Violence in the Nuba Mountains, Sudan”|Undated|
|199.|Darfurwomendaction.org: “Niemat's Story”|Undated|
|200.|Radio Dabanga: “About Us”|Undated|
|201.|Reporters Sans Frontier: “Sudan country page”|Undated|
|202.|Reporters Sans Frontier: “Violations of press freedom barometer”|Undated|
|203.|Soas.ac.uk: “Ahmed H Adam – Overview”|Undated|
|204.|UN Human Rights Council: Report of Independent Expert on the Situation of Human Rights in Sudan|Undated|
|205.|Warmfoundation.org: “Jérôme Tubiana”|Undated|
|206.|Wikipedia – Nuba Mountains|Undated|
|207.|Wikipedia – Omer Ismail|Undated|


**End of Document**


-----

