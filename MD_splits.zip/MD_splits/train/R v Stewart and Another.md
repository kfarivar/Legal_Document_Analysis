# R v Stewart and Another [2021] EWCA Crim 1948

Court of Appeal, Criminal Division

Stuart-Smith LJ, Lewis LJ, HHJ Marson QC

2 December 2021Judgment

MR B SINGH appeared on behalf of the Appellant Stewart

MR R BUTCHER appeared on behalf of the Appellant Allen

_________

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

1. LORD JUSTICE STUART-SMITH: On 24 September 2020 in the Crown Court at Birmingham before
Her Honour Judge Buckingham, Mr Stewart pleaded guilty to one count of possession of a firearm with
[intent to cause fear of violence, contrary to section 16A of the Firearms Act 1968. On 30 September 2020](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CN10-TWPY-Y0VN-00000-00&context=1519360)
at the same court before His Honour Judge Kershaw, Mr Allen pleaded guilty to one count of possession of
a firearm with intent to cause fear of violence, contrary to the same section.

2. On 12 March 2021 they were sentenced by His Honour Judge Hurst as follows. Mr Stewart was
sentenced to an extended sentence of detention of nine years and eight months, made up of a custodial
term of five years eight months with an extension period of four years. Mr Allen was sentenced to an
extended sentence of detention in a young offender institution of nine years and eight months, made up of
a custodial term of five years and eight months with an extension period of four years.

3. About a month later on 16 April 2021 in the Crown Court sitting at Bristol, Mr Allen pleaded guilty to two
counts of possession of class A drugs (cocaine and heroin) with intent to supply. On 20 April 2021 he was
sentenced by Mr Recorder Millard concurrently on each count to 30 months' detention in a young offender
institution. That sentence was ordered to run consecutively to the extended determinate sentence of nine
years eight months which had been imposed for the firearms offence.

4. Each appellant now appeals with leave against the sentences to which we have just referred.

5. Although Mr Allen was sentenced for the drug offences after being sentenced for the firearms offence,
the drug offences occurred first.


-----

6. On 3 September 2018 police officers, acting on intelligence, attended Flat 3 St. Stephen's Court, Old
Market Street in Bristol. Mr Allen, who was 16 years of age, was present together with another man.
Following a search, the police recovered a number of clear bags, a black hunting knife, drugs
paraphernalia and drugs including crack cocaine with a value of between £2,910 and £2,980 (enough for
30 street deals) and heroin with a value of £1,995 to £2,145 (enough for 67 street deals). Mr Allen and the
other man had travelled down from Birmingham to deal in drugs and the address where they were found
and arrested was the home of a user. Mr Allen was charged with two offences of possession of class A
drugs with intent to supply, one relating to the crack cocaine and the other relating to the heroin. So was
that other man, to whom we do not need to refer again.

7. The firearms offences were committed on 20 April 2020. By this time Mr Stewart and Mr Allen were
members of a street gang called B19 or 9boyz which was based in the Newtown area of Birmingham.
They travelled from there to challenge a rival gang that was based in Handsworth.

8. Shortly before 6.00 pm a group of five young men who were members of the rival gang had arrived at
DFC Chicken in Rookery Road, Birmingham. The group stopped briefly outside DFC Chicken before
leaving on foot to an unknown location. They returned a few moments later. As they were doing so a
Peugeot containing the appellants and two other persons who have not been identified drove past. One of
the members of the rival group entered DFC Chicken to make a purchase, while the others remained
outside. Within a minute or so the appellants' Peugeot reappeared. It stopped abruptly in the middle of a

nearby road junction some 40‑50 yards away. Three young men got out. Mr Stewart was in the lead,

closely followed by Mr Allen and a third man. All were wearing dark clothes with hoodies covering their
heads. The driver remained in the vehicle. Mr Stewart ran towards the rival group. Both he and Mr Allen

produced firearms. Mr Stewart had a silver‑barrelled handgun while Mr Allen had a handgun wrapped in a

sock. The third male was in possession of a black‑handled article in his waistband but he was not seen to

draw it and it is not clear what the article was.

9. Mr Stewart pointed his handgun at the victim rival group as he was running towards them. He cocked
the weapon and attempted to fire it but it did not discharge. He then cleared a round from the gun's
chamber and continued to run into DFC. He ran into the doorway, pointed the pistol at a fleeing rival but
did not fire as the rival had escaped over the counter. While that was going on, Mr Allen, who was
standing close to Mr Stewart, fired a round into DFC Chicken. This shot was directed at the rival group as
they fled, but there were also members of staff present in the shop when he fired. The bullet struck a
CCTV monitor near to the fleeing rival group.

10. Mr Stewart managed to clear his weapon chamber. He then left the doorway of DFC and fired a shot
down a nearby alleyway containing members of the fleeing rival group. Fortunately, no one was hit. The
defendants and the third man then left the scene in the Peugeot. The incident had lasted about 40
seconds from when they got out of the Peugeot until when they left. It had taken place in broad daylight in
the presence of members of the public, including those going about their lawful business while at work. It
was captured on good quality CCTV images which graphically convey the terrifying approach of the three
men and the drawing and use of the firearms by two of them, causing mayhem on the streets of
Handsworth. A number of 999 calls were made and armed police attended in the aftermath.

11. Mr Stewart was born on 9 October 2002. He was therefore 17 on 20 April 2020, almost 18 when he
pleaded guilty on 24 September 2020 and just short of eighteen and a half when sentenced on 12 March

2021. He fell to be sentenced as a 17‑year‑old. By the time he came to be sentenced he had six

convictions for nine offences, including two convictions for possession of long knives and convictions for
robbery and attempted robbery. He had already spent periods in detention, the longest sentence being an
eight month detention and training order for possession of a knife in a public place imposed on 25 March
2019.

12. Mr Allen was born on 5 September 2001. He was therefore 16 and two days short of his 17th birthday
on 3 September 2018 when the drug offences were committed. He was 18 when the firearms offence was
committed on 20 April 2020 and 19 when he pleaded guilty on 30 September 2020 and when he came to


-----

be sentenced on 12 March 2021. On the date he was sentenced for the firearms offence he had
accumulated 13 appearances before the courts for 31 offences. The judge regarded his record as worse
than Mr Stewart's, including as it did a robbery in 2015 when Mr Allen had been armed with a Stanley knife,
together with subsequent offences of robbery, criminal damage, theft, possession of heroin and cocaine in

August 2017 with intent to supply and a further conviction for possessing a 23‑inch knife. The CPS did not

authorise charging the drug offences until August 2020 and he was not arraigned until 16 April 2021, by
which time he was 19.

13. When sentencing the appellants for the firearms offences the judge had the benefit of pre‑sentence

reports. The report on Mr Stewart assessed him as posing a very high risk of serious harm based upon his
previous convictions including offences of assault, his history of possessing knives and the facts of the
firearms offence. Realistically recognising the likelihood of a custodial sentence, the report urged on the
court that Mr Stewart had been 17 at the time of offending and the impact of a complicated childhood. The
report on Mr Allen assessed him as posing a high risk of serious harm to the public based upon his past
violent offending and the facts of the firearm offence.

14. The court sentencing for the firearm offences also had letters from the mothers of each appellant. We
have read those letters in full and with care. It is evident that the sentencing judge did so too.

15. Mr Stewart's mother spoke with a heavy heart of someone she described as a lovely, kind and
intelligent young man, identifying his association with others as the root of his deteriorating behaviour and
stresses in their family. While not condoning his behaviour, she expressed the hope that the sentence to
be imposed would not demoralise and institutionalise him and that he would find the strength to turn away
from those associates who she blamed for his descent into crime.

16. Mr Allen's mother pointed to the absence of supporting male influences at home and to signs that he
had taken steps to change his ways, including by converting to Islam.

17. We deal first with the firearms sentences. The appellants were sentenced separately with Mr Stewart
being sentenced first. While recognising that each had acted differently, the judge took the view, as he
was entitled and right to do, that there was no real distinction between them in the terms of the way that
they had behaved.

18. Having reviewed Mr Stewart's previous convictions, which we have summarised above, the judge
placed the offending in Category 2A which gave a range of sentences for an adult of four to eight years
with a starting point of six years. In doing so, he rejected a submission on Mr Stewart's behalf that the
proper category would be Category 3. He rejected it because in the terms of the guideline there was a
high risk of death or severe physical or psychological harm and also a high risk of serious disorder. In our
judgment the judge was right to place the offending in Category 2A for the reasons he gave.

19. The judge identified as aggravating features Mr Stewart's previous convictions which he refused to
treat as "comparatively modest", the fact that his firearm was a prohibited weapon and subject to minimum
sentence provisions (which for Mr Stewart would be three years), the fact that it was part of a group or
gang attack with an organised crime group and the fact that the firearm had been concealed after use. He
mistakenly said that Mr Stewart's firearm had been disguised (which should have been a reference to Mr
Allen's).

20. Asking himself the questions posed in R v Avis (1998) 1 Cr.App.R 420 led to affirmative answers. It
was a prohibited weapon that was discharged in public in the vicinity of and towards members of the rival
gang. It was carried with the intention of causing fear. All other members of the group were exposed to
danger, as were members of the public, but fortunately very little damage was done.

21. Turning to mitigation, the judge recognised that the National Referral Mechanism had reached the
conclusion that he had been trafficked into the behaviour he had been exhibiting over the past number of
years. He rejected the submission that not having the gun when he was arrested demonstrated that Mr
Stewart had been used. The judge's view was that this was all part of a gang's determination to protect
their firearms by secreting them somewhere safe. He decided that a reduction for plea in the region of 19


-----

per cent would be appropriate because Mr Stewart had initially run a defence of alibi and what he
described as Mr Stewart's "direct plea of not guilty to the more serious offence" by which we understand
him to have meant that Mr Stewart did not formally offer to plead guilty to the lesser offence when pleading
not guilty to the more serious one. He accepted that the finding of the NRM reduced Mr Stewart's
culpability "to a certain extent" and he expressly took into account the letter from Mr Stewart's mother.

22. He said that he had a clear public duty to protect the public and that there must be an element of
deterrence in any sentence imposed in such circumstances. He explained the custodial element of the
sentence as follows:

"I bear in mind that this is an offence which would attract a minimum term but I am afraid we are well above
that. It seems to me that the starting point of six years can quite properly be increased to eight years to
reflect the circumstances of this crime and the aggravating features that I have identified. I then reduce that
to seven years to reflect your age then and now, and the finding of the national referral mechanism, and I
reduce that, not by 19 per cent, but by a figure in the order of 20 per cent to five years and eight months,
which comes out at 19 per cent."

23. The judge then addressed the question of dangerousness. He correctly identified that he was dealing
with the provisions applicable to offenders under the age of 18 at the time of conviction and he imposed an
extended licence period of four years. He explained his decision as follows:

"I have to consider whether or not you pose, in the future a significant risk of occasioning serious harm to
others by the commission of further specified offences. In my judgment, you clearly do. The facts of this

case, and your previous convictions, your associates, and the finding in the pre‑sentence report which is

that you pose a very high risk to other people. The choice is entirely in your hands. If you go back to the
gang, you pose that risk. If you leave the gang, you don't. It's clearly not a case for a sentence for life
detention or life imprisonment, and the sentence I have already indicated of course is in excess of four
years."

24. The judge adopted much the same approach when sentencing Mr Allen. Having pleaded guilty at the
PTPH Mr Allen was entitled to 25 per cent credit. The judge referred to his antecedents which we have
summarised above. The judge then reiterated that the offence was within Category 2A for the same
reasons as he had previously given. The aggravating features were the same, though obviously Mr Allen's
antecedents were different and worse. The judge then explained how he reached the custodial element of
the sentence and how it came out at the same figure as Mr Stewart's as follows:

" The starting point is six years, I take that up to eight years for the facts of the offence and the aggravating
features, and then I reduce it by a full 25 per cent for your plea of guilty entered when it was, plus a little bit
more to reflect your comparatively young age, which means that you both end up with the same sentence,
five years and eight months, which I am sure that you will consider is a fair disposal, that you should have
the same for doing the same sort of thing, but he has done slightly better by being younger and having his
national referral mechanism finding, and therefore that largely counters the lesser credit that he gets."

25. Turning to the question of dangerousness, he concluded that Mr Allen was dangerous for exactly the
same reasons as Mr Stewart:

"You have been convicted of a specified offence, obviously I am applying the legislation that applies to
those who are 18 and above. You do pose a significant risk of causing serious harm to others, by the
commission in the future of specified offences. I reach that conclusion based on the facts of this case, your

antecedent history and the conclusion of the author of the pre‑sentence report, who is entirely realistic

about the danger that you pose."

26. As with Mr Stewart he imposed a four‑year period of extended licence.

27. We turn now to the drugs sentence imposed on Mr Allen. The Recorder referred to Mr Allen's
antecedents with specific mention of his six previous drug offences and he said that he allowed a reduction
of 25 per cent for the plea of guilty being entered at the PTPH. He correctly categorised the case as one of


-----

Category 3 street dealing, with a starting point for an adult of four‑and‑a‑half years and a range of three

and a half to seven years. He identified Mr Allen's previous convictions as the aggravating feature that he
took into account. In mitigation he took into account the two year delay between arrest and sentence, the
impact of the pandemic on prison conditions and Mr Allen's "relatively young age". Balancing the
aggravating and mitigating features, he took as his starting point four and a half years which when reduced
by 25 per cent brought the notional sentence down to 40 months.

28. Referring to the existence of the firearms offence, he made a further reduction of 10 months on each
count on grounds of totality. On this basis he imposed a sentence of 30 months' imprisonment on each
count, concurrent with each other but consecutive to the firearms sentence.

29. Mr Stewart is represented before us, as he was before the Crown Court, by Mr Balbir Singh. He
submits that the sentence imposed on Mr Stewart was far too severe and that it was wrong in principle to
make a finding of dangerousness. There are a number of strands to the submission advanced by Mr Singh
in support of the appeal. In doing so he now accepts that the offence was properly placed by the judge
within Category 2A. We agree for the reasons given by the judge. However, he submits that leaving all his

other arguments on one side, the judge was wrong to go up from the six‑year starting point to a notional

sentence of eight years for an adult to reflect the circumstances of the crime and the aggravating features
that he had identified.

30. We are unable to accept this submission. Turning first to the circumstances of the crime, although it
lasted less than a minute, this was a brazen, shocking and terrifying incident which put both the rival gang
and the public at substantial risk of severe injury or death. We endorse the judge's identification of
aggravating features and consider that he was right to regard them as exerting significant upward pressure
on the notional sentence that should be passed. In doing so we expressly endorse the judge's view that
the fact that Mr Stewart did not have the firearm with him when arrested is not a mitigating feature but
reflects the entrenchment of the attackers in an organisation that was sufficiently well developed to take
care to conceal the weapon after use. The successful concealment of the weapon is therefore better seen
as an aggravating feature not a mitigating one.

31. Where we consider that Mr Singh is on firmer ground is in his reliance on Mr Stewart's age. He also
seeks to rely upon the fact that Mr Stewart has in his favour the decision by the NRM that there are
conclusive grounds to accept that Mr Stewart is a victim of modern slavery. The basis for and extent of
this finding are not disclosed. All that we have is the fact of the decision. It is therefore not clear whether it
adds anything to the fact that he is involved with a serious gang at a young age with all that implies about
control and compulsion. In reaching our decision we take full account of Mr Singh's submission that Mr
Stewart's culpability is reduced because of his age, but we do not consider that the bare fact of an NRM
finding adds materially to what is already known about him.

32. Turning to Mr Stewart's age, we consider there is force in the submission that the judge did not give it
sufficient weight. As we have set out above, he reduced the notional sentence from eight years to seven to
reflect Mr Stewart's age. That is a reduction of 12.5 per cent. We are conscious of the recommendation in
paragraph 6.46 of the Sentencing Council Guideline on Sentencing Children and Young People that "the

court may feel it appropriate to apply a sentence broadly within the region of half to two‑thirds of the adult

sentence for those aged 15 to 17." We are also conscious of the authorities which emphasise that there
should be no question of "falling off a cliff" on a person's 18th birthday.

33. Other points made by Mr Singh appear to us to be less compelling. However, we recognise that the
sentencing hearing was delayed for reasons not attributable to Mr Stewart and that during that time he was
remanded a long way from home. Separately, we are not satisfied that the judge made an error of
principle in affording just under a 20 per cent reduction for Mr Stewart's plea. There is no indication that Mr
Stewart gave a formal indication at an early stage that he would plead to the lesser offence: see R v
[Stickells [2020] EWCA Crim 1212.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60VP-Y463-GXFD-84NW-00000-00&context=1519360)

34. We can deal with the issue of dangerousness shortly. We are in no doubt at all that the judge was not
merely entitled but clearly right to make a finding of dangerous for the reasons he gave supported as he


-----

was in his views of the risks posed by Mr Stewart by the assessment in the PSR. Neither the existence of
the NRM decision nor the presence of tiny shoots of hope in Mr Stewart's relationship with his mother can
undermine the judge's finding. He was also justified in imposing a maximum period of extended licence of
four years. That ground of appeal fails.

35. However, the ultimate question for us is whether the custodial element of the sentence, namely five
years eight months, was manifestly excessive. We have come to the conclusion that the sentence passed
by the judge did not give sufficient weight to Mr Stewart's age. While we would not accept that the judge
was obliged to make an adjustment of 50 per cent on account of Mr Stewart's age, we consider that an

adjustment in the region of one‑third would have been justified. Applying that to a notional sentence of

eight years, making some relatively modest allowance in respect of the other matters relied upon by Mr
Singh as mitigation and then applying a reduction for plea in the region of 20 per cent, suggests that an
appropriate custodial element of the sentence in Mr Stewart's case would have been one of four years.

36. The process of sentencing is not however a purely mathematical exercise. We have therefore
considered in the round whether an extended sentence with a custodial element of four years and an
extended licence period of a further four years is an appropriate sentence on the facts of this case taking
into account all of the matters that have been urged upon us. In our judgment it is. Mr Stewart's appeal is
therefore allowed. In place of the custodial element of five years and eight months we substitute a
custodial term of four years. The extended licence period of four years is maintained.

37. Mr Allen is represented before us, as he was in the courts below, by Mr Butcher. There is essentially
one point to be made, namely that by imposing the sentence for the drug offences that he did and making
that sentence of 30 months consecutive to the firearms sentence, the Recorder created an aggregate
sentence that was manifestly excessive having regard to the principle of totality. Although Mr Butcher
expresses reservations about the firearms sentence because of Mr Allen's age, he accepts the findings of
dangerousness and directs his submissions principally to the aggregating effect of the consecutive
sentence for the drugs offences.

38. In relation to the drugs offences viewed on their own, Mr Butcher submits that they are in any event
excessive having regard to the fact that Mr Allen was only 16 at the time and the inordinate delay of almost
two years before the CPS authorised the bringing of charges which had the baleful effect that the drugs
offences were not dealt with at the same time as the firearms offence and Mr Allen was not arraigned until
he was 19.

39. In our judgment there is force in these submissions. Although the Recorder referred to the two‑year

delay and to Mr Allen's "relatively young age" as mitigating features, he treated these features merely as

counter‑balances that cancelled out the aggravating effect of Mr Allen's previous convictions. It does not

appear that he regarded the fact that Mr Allen was 16 at the time of the drugs offences as exercising a
material downward shift from a starting point of four and a half years that would have been appropriate as
the starting point for someone who was in all senses an adult. Furthermore, although we would not
criticise the principle of the Recorder's decision to impose sentences that were consecutive to the firearms
sentence, we consider that the reduction of only 10 months for totality was inadequate. If the drugs
offences had been sentenced at the same time as the hefty sentence imposed for Mr Allen's later
commission of the firearms offence, we consider that the drugs offences should not have increased the
aggregate length of the sentence by more than 18 months.

40. We therefore allow the appeal against the sentence of 30 months imposed for the drugs offence, by
maintaining it as a sentence consecutive to the firearms offence but reducing its length to 18 months. To
that extent Mr Allen's appeal is allowed.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS


-----

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

