# R v Cubi [2022] EWCA Crim 835

Court of Appeal, Criminal Division

Stuart-Smith LJ, Baker J, HHJ Andrew Lees

10 June 2022Judgment

**Mr D Henderson appeared on behalf of the Applicant**

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

Friday 10th June 2022

**LORD JUSTICE STUART-SMITH:**

1. On 4th December 2021, having pleaded guilty before the Cambridgeshire Magistrates' Court to three offences,
the applicant was committed to the Crown Court for sentence, pursuant to section 14 of the Sentencing Act 2020.

2. On 8th April 2022, in the Crown Court at Cambridge before His Honour Judge Lowe, he was sentenced as
follows: for production of a Class B drug (cannabis), contrary to section 4(1) of the Misuse of Drugs Act 1971
(offence 1), to 24 months' imprisonment; for possession of criminal property (cash), contrary to sections 329(1) and
334 of the Proceeds of Crime Act 2002 (offence 2), to a concurrent term of three months' imprisonment; and for
assault by beating, contrary to section 39 of the Criminal Justice Act 1988 (offence 3), to a consecutive term of one
month's imprisonment. The total sentence was, therefore, 25 months' imprisonment. Ancillary orders and the
statutory victim surcharge were all made.

3. He now renews his application for leave to appeal against sentence following refusal on the papers by the single
judge.

4. The facts may be relatively shortly stated. On 1st December 2021, police officers attended an address in
Peterborough in order to execute a drugs warrant. On entering the property, officers saw the applicant and a Mr
Batusha attempting to flee through an upstairs window. Police Constable Frisby took Batusha to the ground. The
applicant ran over and aimed punches and kicks towards Police Constable Frisby. Although he was wearing a
helmet, he was struck on the head. The applicant then fled the scene but was detained in a nearby street and
arrested. He was found to have injuries to his feet, which were suspected to have been sustained when jumping
and running from the house. He was therefore taken to hospital to have the injuries tended.


-----

5. A search of the property revealed a cannabis production unit. Six rooms were being used either to harvest, grow
or store cannabis or cannabis paraphernalia. The electricity meter in the property had been bypassed. 94
cannabis plants were seized, along with two bags of loose cannabis buds, a total of just under nine kilograms of
cannabis. The plants could have been expected to generate between £26,000 and £78,000. The harvested
cannabis had a wholesale value of between £46,000 and £132,000. Its street value was estimated to be between
£115,000 and £167,000. The applicant was found to be in possession of £3,000 in cash.

6. In police interview, the applicant said that he had only been in the UK for a week and that he had been helping
Batusha with shearing cannabis. The applicant said that he had been sleeping on a mattress in a room where
cannabis was being grown. He denied having any meaningful role within the setup and said that the £3,000 was
his, for the purposes of rent. He said that he did not know that PC Frisby was a police officer when he attacked
him.

7. A pre-sentence report was provided to the court. In his account to the author of the pre-sentence report, the
applicant said that he had been in the United Kingdom for around seven months, not one week as he had told the
police. He said that he owed a gang £25,000 for his passage to the United Kingdom. He now said that he had
initially been working on a construction site and had moved to work where the cannabis was being grown some five
days before. He said that he was not expecting to receive money, but instead to repay the £25,000 debt to the
criminal gang. No further explanation for his possession of the £3,000 was given.

8. In sentencing the applicant for the offence of production of cannabis, the judge had regard to the relevant
guideline. He rightly held that this was a category 2 case and, given the quantities involved, said that it did not just
"tiptoe" into that category.  He said:

"The fact that this is a serious type of category 2 pushes it up within the relevant range."

Turning to the applicant's role, the judge said:

"In terms of role, there are factors here indicating both significant and lesser role. This is not a case where
either defendant suggests they were coerced or bullied into doing what they were doing. They were
seeking to pay off debts that they had voluntarily incurred and chose this way to discharge those debts.
That having been said, there is no suggestion here that they had influence on those above them in the
chain and whilst, in my judgment, what they were doing cannot be characterised as a limited function, what
they were doing they were doing under direction from others. Looking after this quantity of cannabis and
the number of plants and the value that attaches to both, without any direct supervision, cannot properly be
characterised as a limited function, in my judgment.

In my assessment, both of them had not simply some awareness but complete awareness and
understanding of the scale of the operation. The operation I am sentencing them for is limited to what was
found in that house. I am satisfied that they would have been fully aware of the amount of harvested
cannabis and the number of plants. It was their job to look after both.

I also find that both of them entered [into] or involved themselves in this operation with the expectation of
significant financial gain – the key word there, perhaps, being 'expectation'. Both of them had significant
debts, they say, running to many thousands of pounds, that they hoped to discharge through their
involvement in this criminality. In his interview with the police Mr Batusha said he was to receive 25 per
cent of the value of the harvested cannabis and [the applicant] of course was found with £3,000 in cash,
which was at least in part generated by his involvement in this criminality.

On balance, mindful of those competing factors, this case, in my judgment, falls into significant role but
very much towards the lower end and in fact, when I take into account their personal circumstances and
the lack of previous convictions, I find my starting point in the region of the upper end of lesser role,
category 2."

9. The starting points and ranges to which the judge was referring were (a) category 2 and "significant role", with a
starting point of four years' custody and a range from two years six months to five years; and (b) category 2 and
"lesser role" with a starting point of one year's custody and a range from 26 weeks to three years


-----

10. The judge said that he was mindful of Manning. He then imposed the sentences on the applicant to which we
have referred. The sentence of 24 months' imprisonment for the drugs offence reflected a sentence of three years'
custody, before giving a reduction of one-third for the applicant's early plea of guilty.

11. Mr Henderson appeared for the applicant in the court below and appears pro bono before us. We are grateful
to him for his assistance, both in writing and orally. His submissions have been clear and concise; no more could
have been said on behalf of the applicant. Two points are taken. Under ground 1, it is submitted that the judge
erred in placing the applicant in the "significant role" category and should instead have placed him in the "lesser
role" category.

12. We do not agree. The judge was entitled to take the view that the applicant was motivated by financial
advantage. He hoped and expected to reduce the debt that he had incurred to the criminal gang he had engaged
to bring him illegally into the United Kingdom. The judge was also entitled to take the view that the applicant was
aware of the scale of the operation being carried on in the house. His conclusion that the applicant fell into
significant role "but very much towards the lower end" was unimpeachable. It must be borne in mind that while the
applicant's culpability was very much towards the lower end of the range, the judge had already and correctly
identified that in terms of harm, the quantities involved exerted an upward pressure on what would otherwise have
been the starting point. This was not a case where it could or should be said that, because the applicant's
culpability was at the lower end of the "significant role", an appropriate sentence would also be at the lower end of
the range for category 2. An appropriate sentence should reflect both the relatively high level of category 2 harm
and the relatively low level of "significant role" culpability.  Had the judge said that the combined effect of these
opposing pressures led him to a notional sentence in the middle of the range, or near the initial category starting
point of four years, he could not reasonably have been criticised.

13. We find little assistance in the various cases to which we have been referred, where different sentences, based
on different facts, have been upheld as not being manifestly excessive. Had the applicant's role been more
managerial or substantial, there would have been no reason to describe his culpability as being at the lower end of
"significant role". As it is, we see no basis for the criticism advanced under ground 1.

14. Under ground 2, it is asserted that even if he correctly categorised the offending, as he did, the starting point
taken by the judge was too high and the sentence was manifestly excessive.

15. We do not agree. The appellant had no real personal mitigation. He was working to pay off a debt that he had
incurred to enable him to enter the United Kingdom illegally. It was not suggested that he was a victim of modern
**_slavery, or that he had acted under coercion or duress. The fact that he had no previous convictions in this country_**
is to be set against the combined facts that (a) he had not been here long, and (b) on the information provided to
the author of the pre-sentence report, he had been involved in similar drug criminality in Albania before coming
here.  Mr Henderson submitted that this all demonstrated a degree of naivety. We are unable to accept that
submission.

16. Nor do we accept that the judge's approach involved any double counting of the impact of the quantities
involved. The quantities had a double relevance in determining that the case falls within category 2 and as leading
to the inference that the applicant knew the scale of the operation. That does not involve double counting. It
merely means that the quantities properly and separately informed the assessment of both harm and culpability.

17. Whilst some modest reduction could have been made on the basis of Manning, there was little else to be said
on the applicant's behalf, apart from his early plea of guilty. A notional sentence of three years, before reduction for
his guilty plea, is well below the notional starting point for category 2 "significant role" and, as the judge noted, was
at the upper end of the range for category 2 "lesser role".

18. For these reasons, which are essentially the same as those of the single judge when refusing leave on the
papers, this renewed application is refused.

________________________________


-----

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

