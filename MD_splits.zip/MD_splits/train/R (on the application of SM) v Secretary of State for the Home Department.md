# R (on the application of SM) v Secretary of State for the Home Department

 [2024] EWHC 1683 (Admin)

King's Bench Division, Administrative Court (London)

Sarah Clarke Kc (Sitting As A Deputy Judge Of The High Court)

1 July 2024Judgment

**Mr Taimour Lay (instructed by BHT Sussex) for the Claimant**

**Mr Michael Biggs (instructed by Government Legal Department) for the Defendant**

Hearing date: 21 May 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

.............................

**Sarah Clarke KC sitting as a Deputy Judge of the High Court:**

1. This is an application for Judicial Review on behalf of the Claimant (“the Claimant”) against a decision
made by the Single Competent Authority (“SCA”), acting on behalf of the Defendant – the Secretary of
State for the Home Department (“the Secretary of State” of “the Defendant”) - on 21 April 2023 (“SCA's
Decision”) in which the SCA decided that there were not reasonable grounds to believe that the Claimant
was the victim of trafficking / modern slavery. Permission was granted by Mr David Pievsky KC sitting as
a Deputy Judge of the High Court on 5 December 2023. For the reasons set out below, this challenge
succeeds and the SCA's Decision will be quashed.

**Background to the SCA's Decision**

2. Specific public authorities (“First Responders”) are required to notify the Defendant of any potential
victims of modern slavery / trafficking that they encounter in England and Wales by referring them into the
National Referral Mechanism (“NRM”). The NRM is the framework for the identification of Victims of
Trafficking (“VoT”) operated by the SCA. The NRM is regulated by Policy Guidance provided under
section 49 of the **_Modern Slavery Act 2015 (the “MSA”). This guidance is entitled:_** **_Modern Slavery:_**
Statutory Guidance for England and Wales (under s.49 of the **_Modern Slavery Act 2015) and Non-_**
Statutory Guidance for Scotland and Northern Ireland), and by Part 5 of the Nationality and Borders Act
2022 (“the Guidance”). Version 2.11 of the Guidance applied at the time of the SCA's Decision.

3. Chapter 2 of the Guidance provides the following definition of human trafficking (based on the Europe
Convention on Action against Trafficking in Human Beings 2005 (“ECAT”).

_“2.3. The essence of human trafficking is that the victim is coerced or deceived into a situation where they_
_are exploited. Article 4(a) of the Council of Europe Convention on Action against Trafficking in Human_
_Beings (the Convention) defines 'human trafficking' as:_

_“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of_
_force or other forms of coercion of abduction of fraud of deception of the abuse of power or of a position_


-----

_of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person_
_having control over another person, for the purpose of exploitation. Exploitation shall include, at a_
_minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or_
_services, slavery or practices similar to slavery, servitude or the removal of organs.”_

4. Consistent with this definition, paragraph 2.4 of the Guidance explains: “Human trafficking consists of 3
_basic components: action, means and purpose of exploitation”._ These are described in paragraph 2.5
(emphasis added):

a. _Action: recruitment, transportation, transfer, harbouring or receipt, which includes an element of_
_movement whether national or cross-border;_

_which is achieved by a…_

b. Means: threat or use of force, coercion, abduction, fraud, deception, abuse of power or vulnerability;

_for the purpose of…_

c. _Exploitation: for example, sexual exploitation, forced labour or domestic servitude, slavery, financial_
_exploitation, removal of organs._

5. In a child trafficking case such as this, the “means” component is not required as a child is not able to
give informed consent to engage in criminal or other exploitative activity, nor can they give consent to be
abused or trafficked (see paragraphs 2.6 and 2.11 of the Guidance). Nor does a child need to consent to
enter the NRM although every effort should be made to ensure that the child understands what is
happening (paragraph 5.47).

6. Following the initial referral, there is then a two-stage decision making process undertaken by the SCA
on behalf of the Defendant. The first stage is for the SCA to decide whether there are reasonable grounds
to believe that the person was a victim of trafficking (known as a “Reasonable Grounds Decision”). If a
positive decision is made, then the second stage is that after further consideration and investigation, the
SCA determines whether, on the balance of probabilities, there were sufficient grounds to decide that the
individual was a victim of trafficking (known as a “Conclusive Grounds Decision.”). In the Claimant's case,
the SCA's first stage Reasonable Grounds Decision was reconsidered at the request of his legal
representative and it is the reconsidered decision (SCA's Decision) that is the subject of this Judicial
Review.

7. A first stage decision made by the SCA as to whether there are reasonable grounds to believe that a
person is a VoT has significant potential consequences for the person concerned, particularly in terms of
entitlement to protection and support and potential to further remain in the United Kingdom (“UK”) if the
person is subject to immigration control. A negative first stage Reasonable Grounds Decision means that
there is no need for the Defendant to proceed to making a second stage Conclusive Grounds Decision as
to whether a person has been a VoT. This is amply demonstrated in the Claimant's case in that the SCA's
Decision (a negative first stage Reasonable Grounds Decision) has negated any need for subsequent
consideration of whether there are Conclusive Grounds to believe that he is a VoT and it has (indirectly)
informed the Home Office's ongoing refusal of his asylum claim.

8. It is also important to recognise that it is equally the case that there is a strong public interest in
ensuring that the NRM process is not subject to abuse by applicants who claim to be a VoT but are not.
The implications for both sides emphasises the importance of the SCA's decision making process at both
the first and second stage, and the need for care in the way in which decisions are taken.

**Background facts**

9. I have been provided with a helpful agreed chronology of events and the background facts which give
rise to this claim are not in dispute.

10. The Claimant is an Albanian national who was born on 8 March 2004 and is now aged 24 yrs. On 25
November 2021, the Claimant obtained a false passport which he used to travel on 5 December 2021 to
the UK via Germany arriving at London Gatwick Airport on 17 December 2021 where he was detained by


-----

the immigration services. He was interviewed and a “Welfare Form: Unaccompanied Children” was
completed. During that interview, SM stated, “I am stressed because I am in debt to come here and if they
_know I am here it will be a problem.” He also stated, “I just want to be safe. I want to be relaxed.”_

11. On 21 December 2021, the Defendant referred the Claimant into the National Referral Mechanism
(“NRM”) for a decision to be made as to whether he was a victim of trafficking. The NRM Referral Form is
dated 18 December 2021. This form includes:

_“Pax stated he had been trafficked to get to the UK. Pax stated he had asked someone for help to get him_
_here and that they knew who he was but he did not know them. He stated he was in debt for coming here_
_and that if they found him, it would be a 'problem', Pax travelled alone from Berlin to the UK using a_
_counterfeit document._

_Pax did not claim he had been exploited but stated he had been trafficked.”_

12. On 30 December 2021, the SCA issued a negative first stage Reasonable Grounds Decision (“the
Initial Reasonable Grounds Decision”). This concluded that:

i) The Claimant had been “broadly consistent in their account and there are not considered to be any
_significant credibility concerns with their account.” (referring to the matters contained in the Welfare Form_
and NRM Referral form as set out at paragraphs 10-11 above.)

ii) The Claimant's account was accepted applying the standard of proof “I suspect but cannot prove”. The
SCA accepted that the “Action” criteria was met, and the “Means” criteria was not required given that SM
was a child. The SCA however concluded that the “Purpose” condition was not met because the events
were not deemed to constitute modern slavery. The Initial Reasonable Grounds Decision stated:

_“The PV stated that he came to the UK for a better life and to work and take care of himself. The PV asked_
_people to bring him to the UK. The PV stated that is indebted to the people who brought him to the UK and_
_that if they know he is here it would be a problem for him. No further information has been provided to_
_explain what debt the PV has incurred, or how the PV planned to pay this back. (Q1-3 WF)._

_The referral form itself lacked detail around this incident and despite contacting the First Responder, no_
_further details could be provided in relation to this claim._

_Again when contacting the Social Worker, no further information was provided in relation to the claim of_
_trafficking._

_The information provided does not lead the SCA to suspect that the PV is a victim of modern slavery. The_
_information provided is dissimilar to that of any form of exploitation as the PV travelled under his own_
_volition and there is nothing noted that is indicative of any form of exploitation in the PV's account._

_It is, therefore, considered that the PV was not subjected to forced labour/forced criminality/domestic_
_servitude/sexual exploitation/organ harvesting/other, nor was there an intention to subject him to this.”_

13. On 19 June 2022, the Claimant made a witness statement in support of his asylum claim. The
relevant parts stated in summary:

i) In early October 2021 he went to Tirana with his friend. A man approached them in a park and told them
that there were more opportunities in the UK but you could not “get there on an Albanian passport. He told
_them that he had connections and could get fake identity documents and passports. He suggested_
_arranging passports for them and said it would cost £15,000 for a passport. He wanted to be paid in_
_pounds.”_

ii) The Claimant thought it was a good idea, “because I wanted to do something different with my life. I did
_not really think about the consequences. After we discussed the price, he said if I did not pay there would_
_be consequences.”_

iii) The Claimant does not know why the man did not take the money up front but stated that perhaps this
was because he had told the man he had the money and would pay him letter. He stated, “I don't know
_why he let me do that.”_


-----

iv) The man took the Claimant's full name and home address. He also took his Albanian identity card and
copied down the information including the reference number. He also took the Claimant's photograph.

v) The Claimant agreed to meet the man again in a month. On the agreed date he met the man in the
same park. The man gave him a false Czech passport containing his photograph. The man said, “if you
_don't pay us back your life will be at risk.”_

vi) The Claimant told the man that he would be able to pay him for the passport in the next two days. The
man took the Claimant's telephone number. He threatened the Claimant, “saying that I must pay him. He
_said that he knew everything about me because he had my name, address and photograph. He said if I did_
_not pay him, he would find me, kidnap me and kill me. He also threatened my family saying he'd kill them.”_

vii) The Claimant stated, “Even though he frightened me, and I knew that I could not pay him, I thought if I
_left the country, he could not find me. I did not think he'd ever hurt my family. I went home and the next day_
_changed my phone number so he could not call me.”_

viii) The Claimant stated that he did not have enough money to pay the man and had no way of raising the
money, therefore he decided to leave Albania quickly. He travelled to Berlin by bus and then flew to
Gatwick Airport on 17 December 2021 where he was detained at Immigration.

ix) A few days later he spoke to his parents by telephone. “They had been worried sick and thought I had
_been abducted by the man I owed money too [sic]. They were very unhappy with what I have done. My_
_mother was crying and she told me off. She told me I had made a serious mistake. She said I should not_
_return to Albania. I told them I regretted my actions and that I am too frightened of the man I owe money to_
_return.”_

x) His mother told him that on or around 21 or 22 April 2022, someone had called his father from an
unknown number. “They said that they knew I was in the UK, and that I owe them money. If I did not pay
_them back, we will 'pay' for it. They threatened my father. My father went to the police, but they said that_
_they could not help.” He is worried that his parents have received more threats since then that they are not_
talking about.

xi) He states, “I cannot return to Albania because I am afraid of the man I owe money to. He cannot be
_working alone and must be part of a bigger group because one man cannot make a passport and then_
_locate and threaten my family. I cannot repay the debt and now they want the money and me as well. If I_
_return, I will be found and either killed or sent back abroad to work and pay off the debt.”_

14. On 8 February 2023, the Claimant attended a “Minor Asylum Interview”. In essence, he gave the
same account as in his witness statement. He was asked what he feared the people who he owed money
to would do to him to which he said, “They can kill me or take me to work for them, I don't know.” He was
asked why he thought the man would risk losing £15,000 to which he replied, “Because he took my ID card
_detail, number, I told him my address, I told him everything.” He said the man did not ever say that he_
worked for a gang. He was asked, “Did he tell you about any work or to meet anybody when you got to the
_UK?” He replied, “We just simply talked about passport, he said I will give you one and you give me_
_money.” He said that he was scared to return to Albania because his life is in danger and that he thinks_
the man must have connections because he managed to do the false passport.

15. On 9 March 2023 the Claimant's solicitor sent an email to the Defendant applying for a reconsideration
of the Initial Reasonable Grounds Decision. The email attached the Witness Statement and Asylum
Interview Record summarised above. The email asserted that based on these documents, “it is plausible
_that my client was transported for the purpose of exploitation.”_

16. The key points made in the email were:

i) The solicitor had discussed the Claimant's case with Christine Beddoe (a respected specialist advisor on
human trafficking and child exploitation), “who agrees it is plausible that by selling him the passport he was
_being prepared for exploitation. She agrees that the modus operandi of the traffickers is one that is known_
_about - ie creating a debt with a follow up of exploitation to pay that back. She states that she is aware of_
_situations like this where “fake passports were offered and then after travelling on the passport the victim_


-----

_gets threats by trafficker that they will be exposed to police for traveling as illegal on fake passport. All part_
_of the mechanism to keep control over the victim and stop families from going to police.”_

ii) The email quotes from the US Department of State – Trafficking in Person Report, “Albanian migrants
_who seek employment in Western Europe are vulnerable to exploitation in forced labor and forced_
_criminality, particularly in the UK”._

iii) The email further states:

_“As all documents on the trafficking from and within Albania find, including the latest HO CPIN and FFR on_
_Human Trafficking, such networks are prevalent, target vulnerable families and offer them what they need_
_most, whether promises of work, money or living relationships. In this case, they sold him the passport to_
_create a situation of debt bondage. This also indicates that such networks are operating at street level, they_
_can reach every town or village via their associates. Such networks have elaborated branches across the_
_country and internationally where they ultimately force their victims into exploitation. Trafficking and_
_exploitation starts from home and it takes place within Albania or abroad. A study on the 'Typology of child_
_trafficking in Albania' published in July 2020 by the Organisation for Security and Cooperation in Europe_
_(OSCE) concludes that 'trafficking for the purpose of exploitation for criminal activities is the primary risk in_
_trafficking of boys'.”_

**The SCA's Decision**

17. On 21 April 2023, the SCA reconsidered its Initial Reasonable Grounds decision on the Claimant's
human trafficking claim and issued its reconsidered Decision (SCA's Decision) that is the subject of this
Judicial Review claim.

18. The SCA's Decision states, “we considered the following available information” followed by a list which
includes the NRM Referral and Welfare Form, the Claimant's witness statement and asylum and interview
record, and the Claimant's solicitor's email dated 8 March 2023.

19. The SCA's Decision then contains a summary of the information contained in the Claimant's Witness
Statement. The summary does not however include the statement at paragraph 13(xi) above. The
summary also does not contain any summary of the contents of the Claimant's Asylum Interview Record
and nor does it set out the matters contained in the email from the Claimant's solicitor dated 8 March 2023.

20. The SCA's Decision then quotes, “evidence taken from the United States of America Department of
_State Trafficking in Persons Report for 2022 has been considered regarding_ **_modern slavery in Albania_**
_and the United Kingdom.”_ This includes references to, “human traffickers exploit domestic and foreign
_victims in Albania, and traffickers exploit victims from Albania abroad….The UK, Albania, and Vietnam are_
_the leading nationalities of potential victims referred into the NRM. Thirty-one percent of potential victims_
_assert their exploitation occurred entirely outside of the UK. Labor trafficking, including forced criminality, is_
_the most common form of exploitation among adults and children. The evidence above confirms that_
**_modern slavery occurs in Albania and the United Kingdom and they are countries where individuals are_**
_subject to exploitation.”_

21. The SCA's Decision then sets out the standard of proof applied in making the decision:

“The Reasonable Grounds decision applies the standard of proof 'I suspect but cannot prove'. This means
_that to accept your account, it needs to be suspected that your version of events occurred as claimed and_
_that these events constitute_ **_modern slavery (human trafficking and or slavery, servitude and forced /_**
_compulsory labour)._

22. It then states:

_“Careful consideration has been given to the assessment of the available information in your case. Looking_
_at the available sources of information [as listed earlier in the decision], it is recognised that you have been_
_broadly consistent in your account and there are not considered to be any significant credibility concerns_
_with your account._


-----

_Whilst your account is accepted applying the standard of proof 'I suspect but cannot prove', the_
_consideration below explains why the events are not deemed to constitute_ **_modern slavery (human_**
_trafficking and or slavery, servitude and forced / compulsory labour).”_

23. The SCA's Decision then applied the three stage definition of human trafficking and concluded that the
criteria of “Action” was satisfied in that the Claimant had been subjected to an act of transportation. It then
set out that the “Means” criteria did not apply because the Claimant was a child when the events occurred.

24. The SCA's Decision then addressed the final criteria – “Purpose”:

_“Purpose - part 'c'_

_In applying part 'c' consideration must be given to whether you were_

_recruited/transported/transferred/harboured/received for the purpose of exploitation._

_The description of smuggling is contained in the decision annex attached to this letter. You said that you_
_met a man in the park in Albania who told you that there are opportunities in the United Kingdom and_
_offered to get you a forged passport so that you can travel to the UK. The man asked you to pay him_
_£15000 for that service and you agreed. Once you got the passport and, as you knew you did not have that_
_amount of money, you decided to flee your home country. You booked a bus ticket to Germany traveling_
_through several European countries. Once in Germany you stayed in the airport for 2 to 3 weeks as you did_
_not have any money to pay for a hotel accommodation. You then booked a flight to the UK and landed at_
_Gatwick airport on 17/12/2021. You entered the UK using the forged passport you were provided with._

_From the information you have provided within your account it is considered that you were not forced to_
_carry out any work against your will or under any menace of penalty. Your relationship with the man was_
_limited to him providing you with the passport and you paying him the £15000 agreed to assist your journey_
_to the UK. The threats to you before and after you received the forged passport as well as the threats to_
_your family after you arrived in the UK are related to the fact that you have not paid the man as agreed._

_This is dissimilar to the definition of Human Trafficking/Modern Slavery and is indicative of a smuggling_
_arrangement where the objective of the man was to facilitate your entry to the UK as you were seeking_
_opportunities for a better life._

_It is, therefore, considered that you were not subjected to forced labour/forced criminality/domestic_
_servitude/sexual exploitation/organ harvesting/other, nor was there an intention to subject you to this._

25. The SCA's Decision concluded that, “Taken cumulatively, there are not considered to be reasonable
_grounds to believe that you were trafficked from Albania to the United Kingdom and that you are a victim of_
**_modern slavery (human trafficking and or slavery, servitude or forced/compulsory labour)”._**

26. The Annex to the SCA's Decision states, that it, “provides more detailed information about the
_information sources and definitions underpinning the decision.” The Annex lists its sources as the Council_
of Europe Convention on Action Against Trafficking in Human Beings (the Convention) and the **_Modern_**
**_Slavery: Statutory Guidance for England and Wales (under s49 of the_** **_Modern Slavery Act 2015) and_**
Non-Statutory Guidance for Scotland and Northern Ireland. The Annex provides definitions of **_Modern_**
**_Slavery, Human Trafficking and Exploitation types. The Annex also states:_**

“Smuggling

_Human trafficking must not be confused with human smuggling._

_“Human smuggling occurs when an individual seeks the help of a facilitator to enter a country illegally, and_
_the relationship between both parties ends once the transaction ends. Many of those who enter the UK_
_illegally do so by this route. Human smuggling is not a form of modern slavery._

_The purpose of human smuggling is to move a person across a border illegally, and it is regarded as a_
_violation of state sovereignty. The purpose of_ **_modern slavery is to exploit the victim for gain or other_**
_benefit and is regarded as a violation of that person's freedom and integrity”.”_


-----

**Pre-action correspondence**

27. On 5 May 2023, the Claimant's solicitor sent a pre-action letter to the Defendant. The Defendant
responded by letter dated 2 June 2023. In summary this letter asserted that the correct threshold test had
been applied, that the SCA's Decision was lawful and refuted that the facts gave rise to a credible
suspicion of trafficking. It further states, “The decision considered your client's witness statement and
_asylum interview record. Furthermore, the decision dated 21/04/2023 refers to the country evidence in_
_Albania. With regards to the opinion of Dr Christine Beddoe, it is for the NRM to decide whether there are_
_reasonable grounds to suspect human trafficking.” The letter stated that the SCA's Decision considered all_
the relevant materials in the Claimant's case and maintained its negative decision.

**Legal Principles**

28. Both sides agree that the SCA's Decision is challengeable by way of Judicial Review, but it is not the
role of this Court to conduct a merits review of the SCA's Decision. Responsibility for making the SCA's
Decision lies with the SCA, acting as the Secretary of State's delegated decision maker. This Court's role
therefore is limited to conducting a review of the legality of the SCA's Decision by deciding whether the
decision-maker properly addressed the right legal issue, and reached a decision on the basis of a rational
application of the Defendant's policy Guidance as to how the decision should be approached (see R (on
_the application of H) v The Secretary of State for the Home Department [2015] EWHC 1725 (“H”) at [2] and_

[65]:

_Findings of fact are for the decision-maker: the role of the Court is only to determine whether the decision-_
_maker has not properly understood the nature of the decision which he was called upon to make; or if the_
_findings made have been tainted by an improper approach to the fact-finding process; or if the findings are_
_such as to be irrational – either in the sense of being perverse, or because a relevant consideration has not_
_been properly taken into account or something irrelevant has been taken into account._

29. That said, both sides agree that a decision that a person is not the victim of trafficking requires the
Administrative Court to adopt a heightened or more rigorous level of scrutiny (also described as “anxious
scrutiny”) (see R(HAM) v SSHD _[2015] EWHC 1725 (Admin) ("HAM") at [2] to [5]; R(FM) v SSHD_ _[2015]_
_EWHC 844 (Admin) at [24]; R(TVN) v. SSHD [2021] EWHC 3019 (Admin) (“TVN”) at [4] to [5] and R(MN) v_
_Home Secretary (CA)_ [2021] 1WLR 1956(“MN”) at [240] to [246]; _H_ at [2] to [5]). The general principles
are:

i) The starting point is that a high quality of reasoning is required in an Reasonable Grounds Decision
(such as the SCA's Decision), which engages fully with the case advanced by the person concerned due to
the importance of the decision as a potential gateway to important rights including the right to a Conclusive
Grounds Decision.

ii) A Reasonable Grounds Decision needs to demonstrate a careful and conscientious analysis of all
relevant factors and that every factor that might tell in favour of the person concerned has been properly
taken into account.

iii) The requirement for a high standard of reasoning is all the more important given that a Reasonable
Grounds Decision is a largely paper exercise, albeit conducted by a trained and qualified SCA decision
maker.

iv) The provision of proper reasons is an essential part of a lawful decision and thus a Reasonable
Grounds Decision which contains insufficient or inadequate reasons will be unlawful and will generally be
quashed, (subject to the “highly likely” test in section 31 of the Senior Courts Act 1981).

v) The Guidance must be carefully applied, weighing the strength of the indicators or evidence presented
and a comprehensive written assessment must be prepared, based on the circumstances of each case.
“The Guidance requires decision-makers to include in their decision letters a full and detailed consideration
_explaining the reason for the decision in every case.” (MN at [243])._

30. However, the Court must not lose sight of the fact that its task is one of review for error of law, not
t F th i ti i d ith b t t ti “ h t _tt_ _i_


-----

_the substance of the analysis, reasoning and conclusions, rather than matters of wording or form” (MN at_

_[245]), anxious scrutiny “does not mean that the court should strive by tortuous mental gymnastics to find_
_error in the decision when in truth there has been none. The concern of the court ought to be substance_
_not semantics” (HAM at [5],_ applying _FM at [32], quoting_ _R(Sarkisian) v IAT_ _[[2001] EWHC Admin 486 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_

[18]).

31. Lastly, “…particular care is necessary to ensure that the criticism is as to the fundamental approach of
_the [decision-maker], and does not merely reflect a feeling on the part of the appellate tribunal that it might_
_itself have taken a different view of the matter from that that appealed to the [decision-maker]” (MN at [245]_
applying Mibanga v Secretary of State for the Home Department [2005] INLR 377, Buxton LJ at [29]).

**_The status of the Guidance_**

32. The Guidance is Statutory Guidance published by the Secretary of State and provides extensive
material to assist SCA Decision-Makers to identify who is, and is not, a victim of trafficking. (See TVN at

[10]):

_A public law decision maker will act unlawfully if the decision maker either misunderstands statutory_
_guidance or fails to act in accordance with it, save for a case where the decision maker has consciously_
_departed from the guidance for a good reason. The position was summarised by the Court of Appeal in MN_
_at §84 where the Court of Appeal said:_

_“The NRM as embodied in the Guidance is for practical purposes the primary source of the obligation to_
_support victims of trafficking. The Guidance does not itself have the status of law, but it represents a formal_
_statement of Government policy and practice, and failures to comply with it may on ordinary principles be_
_the subject of challenge by way of judicial review: see para 20 of the judgment of Baroness Hale in MS_
_(Pakistan) [2020] 1 WLR 1373”_

33. The NRM provides the definition of human trafficking and the 3 basic components (see paragraphs 2324 above). As is clear from the summary at paragraphs 24-26 above, the SCA's Decision was concerned
with the component of “for the purpose of exploitation” and the basis of the SCA's Decision was that this
component was not satisfied.

34. The issue of how to assess the “for the purpose of exploitation” component was considered in MN at

[340] – [343] albeit in a different context (the taking away of a child for the purpose of female genital
mutilation allegedly for the purpose of forced marriage and the degree of nexus required between the two
events for the “for the purpose of exploitation” test to be satisfied). At [342] the Court observed, “The
_concept of purpose must be applied as a matter of ordinary language and common sense, having regard to_
_what may reasonably be supposed to be the intended scope of ECAT.”_

35. Paragraphs 2.22-2.23 of the Guidance provide:

**_Exploitation_**

_2.22. To be a victim, someone must have been trafficked for the purpose of_

_'exploitation' which may take the form of either:_

_• sexual exploitation_

_• forced labour or services_

_• slavery or practices similar to slavery_

_• servitude_

_• forced criminality_

_• removal of organs (also known as organ harvesting)_


-----

**_Trafficked for the 'purpose of exploitation' – what if someone hasn't_**

**_yet been exploited?_**

_2.23. Under the Convention on action Against Trafficking in Human Being (ECAT), a person is a 'victim'_
_even if they haven't been exploited yet, for example because a police raid takes place before the_
_exploitation happens._

_2.24. This is because, under the definition of trafficking, trafficking occurs once certain acts are carried out_
_for the purpose of exploitation. So, it is the purpose which is key, rather than whether or not exploitation_
_has actually occurred. Even if the UK authorities intervene and prevent exploitation taking place in the UK,_
_victims may have experienced serious trauma in their home country or on the way to the UK and may still_
_be in need of support._

36. In VCL v United Kingdom (2021) 73 EHRR 9 at [99], the European Court of Human Rights (“ECtHR”)
approved the International Labour Organisation Convention 1930 (“ILO”) indicators of forced labour,
describing these as, “a valuable benchmark in the identification of forced labour.” These are:

     - Threats or actual physical harm to the worker.

     - Restriction of movement and confinement to the work place or to a limited area.

     - Debt bondage: where the worker works to pay off a debt or loan, and is not paid for his or her services.
_The employer may provide food and accommodation at such inflated prices that the worker cannot escape_
_the debt._

    - Withholding of wages or excessive wage reductions, that violate previously made agreements.

     - Retention of passports and identity documents, so that the worker cannot leave, or prove his/her identity
_and status._

     - Threat of denunciation to the authorities, where the worker is in an irregular immigration status.

37. The Guidance, at paragraphs 2.55-2.62 highlights the need not to confuse **_modern slavery with_**
people smuggling, and provides general guidance in respect of cases where it is unclear as to whether
smuggling or trafficking has taken place:

**_Human smuggling is not human trafficking_**

_2.55 The competent authorities must not confuse human trafficking with human smuggling. Human_
_smuggling is also called people smuggling._

_2.56 Human smuggling occurs when an individual seeks the help of a facilitator to enter a country illegally,_
_and the relationship between both parties ends once the transaction ends. Many of those who enter the UK_
_illegally do so by this route. Human smuggling is not a form of modern slavery._

_2.57 The purpose of human smuggling is to move a person across a border illegally, and it is regarded as a_
_violation of state sovereignty. The purpose of_ **_modern slavery is to exploit the victim for gain or other_**
_benefit and is regarded as a violation of that person's freedom and integrity._

_2.58. There are several factors which help distinguish smuggling and modern slavery (trafficking):_

     - with trafficking, a victim's entry into a state can be legal or illegal but smuggling is characterised by illegal
_entry_

     - trafficking can take place both within and across national borders but international travel is required for
_smuggling_

     - in the case of adults, trafficking is carried out with the use of force and/or deception – smuggling is not,
_which indicates it is a voluntary act on the part of those being smuggled_

     - trafficking involves the intended exploitation of people on arrival while the services of smugglers usually
_end when people reach their destination and the transaction ends._


-----

**_Unclear cases_**

2.59. Trafficking victims may indeed start out believing that they are being smuggled, will have control over
_how their debt is repaid and will be free to go about their business once the agreed fee has been settled._
_Some may well end up in a potentially exploitative situation, where they are debt bonded and forced to_
_work to pay off their 'debts', which in many cases are increased by their trafficker over time to retain control_
_over them._

2.60. _As noted in 'Smuggled or Trafficked?' by Jacqueline Bhabha and Monette Zard' staff in the_
_competent authorities must appreciate that in some cases the distinction of smuggling and trafficking can_
_be blurred. There are certainly 'pure' cases of trafficking and smuggling. For example, there may be_
_trafficking cases where children are kidnapped without their parents' consent, or in which migrant workers_
_are defrauded and forced from the outset._

2.61. _At the other end of the spectrum, there are completely transparent cross-border transportation_
_agreements where a fee is mutually agreed and the relationship between transporter and transported ends_
_upon arrival. However, at the point of departure and at multiple stages of the journey, it may well be_
_unclear which category – trafficking or smuggling – is at issue._

2.62. _In less clear cases, the Competent Authority must consider the information in this section of the_
_guidance and use their judgement in order to reach a decision._

38. This section of the Guidance was addressed in TVN at [13]:

_13 The key part of [the] Guidance for present purposes is that smuggling is a "voluntary act on the part of_
_those being smuggled" and that "the services of smugglers usually end when people reach their_
_destination and the transaction ends". There are a variety of potential scenarios. A person who pays to be_
_"smuggled" into the UK as an economic migrant and his relationship with those who transported him ends_
_when he arrives in the UK. He is not a victim of trafficking. Further, a person who has "voluntarily" gone into_
_an arrangement under which he is smuggled into the UK and agrees to work for a period without pay to_
_repay back those who transported him may well also not be a victim of trafficking, despite the fact that this_
_person is in debt bondage to his minders for a defined period. However, a combination of debt bondage_
_plus force, coercion or menaces is highly likely to result in the individual being a victim of trafficking._

39. The distinction between smuggling and trafficking by reference to the concept of “purpose” was dealt
with in _R(Y) v Secretary of State for the Home Department [2012] EWHC 1075 (“R(Y)_ at _[34]-[37]._ In
summary, the key points to be derived from that case are:

i) Whether the transportation is “for the purpose of exploitation” or for the purpose of people smuggling
(with, in the context of R(Y) - exploitation occurring on an opportunistic basis incidental to that) is a “very
_fact sensitive decision” [31]._

ii) A decision maker must explain the reasons for the decision and be seen to address the issues. If it
does not do so, then it is open to challenge [35].

iii) In R(Y), the Court held that within a month of Y's arrival in the UK, it must have been clear that Y had
lied when she said that her father would pay her traffickers on her arrival, yet she was harboured for a
further six months during which she was forced to submit to sex and to work in the house without pay. “The
_smuggling process had by then ended and the only reasonable conclusion is that the Snakeheads decided_
_to use her by way of punishment or payment in kind. That means that she was being kept for the purpose_
_of exploitation, and that is trafficking” [36]. The Court therefore concluded that the decision that the_
Claimant was not subject to trafficking at any time was irrational [37].

40. Paragraph 14.28-14.33 of the Guidance deals with the weight to be given by decision makers to expert
reports. These include:

14.29  The _experience and qualifications of the individual providing the supporting evidence and the_
_sources used will be relevant in considering what weight to attach to an expert report and every case must_
_be considered on its merits._


-----

14.30  Expert evidence is not determinative of whether the Reasonable or Conclusive Ground test is met
_but should be taken into account when reaching a conclusion on whether there are reasons why the_
_Reasonable or Conclusive Grounds test is or is not met. There is no requirement to accept an assessment_
_of an expert that a person is or is not a victim. Any expert assessment must be considered in the round_
_with all other evidence._

14.31  The individual writing the report may not have access to the full range of information available to
_the relevant competent authority and all relevant evidence, including any documentary evidence, must be_
_considered when making a Reasonable or Conclusive Grounds decision._

14.32 _Where an expert report is considered when assessing a claim under the NRM, and other_
_information is available, all the information and relevant reports should be considered. If there are several_
_expert reports all must be taken into account. A decision should not rely on an expert report alone without_
_considering all relevant information._

14.33 _A decision should not rely on an expert report alone where there is other relevant information_
_available. A decision should not rely on an expert report without the relevant competent authority making_
_other independent enquiries into the potential victim's circumstances and credibility, and an expert report_
_should be considered and weighted appropriately alongside other evidence._

41. It is agreed between the parties that the test to be applied by a Decision Maker on a Reasonable
Grounds Decision, is correctly set out in paragraphs 14.49 – 14.53 of the Guidance:

**_Standard of proof for Reasonable Grounds decision_**

_14.49. When a competent authority receives a referral, they must decide_

_whether on the information available it is reasonable to believe that a_

_person is a victim of human trafficking or slavery, servitude and forced or_

_compulsory labour._

_14.50. The test that competent authority staff must apply is whether the_

_statement:_

_'I suspect but cannot prove' the person is a victim of modern slavery_

_(human trafficking or slavery, servitude, or forced or compulsory_

_labour)'_

_• is true; or_

_• whether a reasonable person having regard to the information in the_

_mind of the decision maker, would think there are Reasonable Grounds_

_to believe the individual is a victim of modern slavery (human trafficking_

_or slavery, servitude or forced or compulsory labour)_

_14.51. It may not be initially clear to competent authority staff whether a_

_potential victim has been subject to human trafficking or slavery, servitude,_

_and forced or compulsory labour. To reach a positive Reasonable Grounds_


-----

_decision the relevant competent authority just needs to determine that, on_

_the information available, it is reasonable to believe that a person is a_

_victim of modern slavery; the competent authorities do not need to_

_distinguish at the Reasonable Grounds stage which form of modern slavery_

_they have experienced._

_14.52. Reasonable suspicion would not normally be met on the basis of an_

_unsubstantiated claim alone, without reliable, credible, precise and up to_

_date:_

_• intelligence or information_

_• evidence of some specific behaviour by the person concerned_

_14.53. Where reliable, credible, precise and up to date intelligence, information or evidence is present, it_
_must be considered in reaching a Reasonable Grounds decision._

**_Evidence gathering at the Reasonable Grounds stage_**

_14.54. The Reasonable Grounds decision has significant consequences for_

_the potential victim in terms of protection and support (and potential further_

_stay in the UK if they are subject to immigration control). It is important that_

_the competent authority decision is of the highest possible standard and_

_takes all available evidence into account when reaching the decision,_

_including the expert views of those surrounding the individual._

_14.55. Reasonable suspicion would not normally be met on the basis of an_

_unsubstantiated claim alone, without reliable, credible, precise and up-to date_

_reference to some or all of the below:_

_• reference to the indicators of modern slavery in the referral_

_• intelligence or information from law enforcement agencies, including objective country of origin evidence_

_• information from First Responders, support organisations, social services_

_and persons involved in assisting the victim_

_• evidence of some specific behaviour by the person concerned_

_14.56. This is a non-exhaustive list and there may be additional information_

_that is relevant. Where reliable, credible, precise and up-to-date_

_intelligence, information or evidence is present and relevant, it must be_

_considered in reaching a Reasonable Grounds decision._

42. In _TDT (Vietnam)) v Secretary of State for the Home Department (Equality and Human Rights_
_Commission intervening) [2018] 1 WLR 4922(“TDT”) at [47], the Court addressed the issue of “generic or_
_specific evidence”, stating:_

“….In truth I do not believe that this is an issue on which useful generalisation is possible. In principle the
_ultimate question in any given case must be whether there are reasonable grounds for suspecting that the_


-----

_particular individual in question is a victim of trafficking. However, one of those grounds may be indeed is_
_very likely to be that he or she falls into a class known to be peculiarly vulnerable to being trafficked. The_
_weight to be given to generic evidence of that kind in any particular case will depend both on the strength_
_of the association alleged and the reliability of the evidence supporting it. If there were clear statistical_
_evidence that 95% of all young Ruritanians entering the UK illegally were victims of trafficking, I cannot see_
_why that by itself would not justify (at least) a credible suspicion that any particular young Ruritanian illegal_
_entrant had been trafficked. Conversely, if there was indeed a known phenomenon of young Ruritanians_
_being trafficked but they were only a small proportion of the numbers of young Ruritanians entering the_
_country such a suspicion would not be justified without other circumstances being present. But in the real_
_world most cases will fall between those two extremes: the relevant evidence will be a mixture of generic_
_and specific, and the question will be what its overall effect is when viewed as a whole.”_

43. In, _HAM at [67] to [74], the Court provided guidance on, “the question for the decision-maker at the_
_reasonable grounds stage. The key points are:_

i) The actual question to be answered by the decision-maker is, _“does the Competent Authority have_
_reasonable grounds to believe that the person in question is a victim of trafficking?” [67]. (I note that this_
test is interchangeably referred to in the Guidance and case law as “reasonable grounds to suspect”.)

ii) This is an objective question to which the low threshold of suspicion but not proof should be applied. It
is not the task of the decision-maker to form a subjective view of what the putative victim has been able to
prove to the decision-maker's satisfaction [68] and [71].

iii) In answering the objective question, the decision-maker should bear in mind the non-exhaustive list in
the Guidance of possible reasons for absence of detail or inconsistency [68]. (To this I would add that the
decision-maker should also consider any other relevant parts of the Guidance applicable to the particular
case under consideration.)

iv) _“At this preliminary stage of the enquiry, there could be both reasonable grounds upon which a_
_reasonable person could believe that a person could be a victim of trafficking and reasonable grounds for_
_believe that they might not be. (That may particularly be so in circumstances where there are_
_inconsistencies or gaps in the evidence, but also features of the account which suggest possibly plausible_
_psychological or other reasons to explain those lacunae.) In such circumstances, the question of whether_
_there are "reasonable grounds" for suspecting that a person is a victim of trafficking must be answered in_
_the affirmative. Provided there are reasonable grounds for belief, then the question of whether there are_
_also reasonable grounds for disbelief is irrelevant. The further question of whether the grounds for disbelief_
_outweigh the grounds for belief is not one for determination at that stage: it is a matter which will fall for_
_determination by a decision-maker making a Conclusive Grounds decision at a later date (after the_
_reflection/recovery period and if necessary after extra enquiries).” [70]_

v) The decision must be taken in the light of all the evidence, which includes evidence from the
complainant and other sources, including evidence from specialist organisations which suggests that
assertions made by the putative victim's account appear consistent with known trafficking patterns [72].

vi) It is important that the decision-maker takes a “rigorous approach to the question which the decision_maker must ask”, given the short timescale within which, and the purpose for which, a reasonable grounds_
decision is to be made [73].

vii) At [74], the Court referred to, “the importance of context”:

_74 The "reasonable grounds" decision is intended to be made within five days of referral to the decision-_
_maker. It is intended to do no more than to act as an initial filter to a fuller more conclusive decision. If,_
_based on the information before the decision-maker, there is simply no basis on which a reasonable_
_person could be of the opinion that there were reasonable grounds to believe that the individual concerned_
_had been trafficked, they should be filtered out of the process at that stage to avoid diversion of resources_
_into further enquiry. But if, based on that information, some reasonable grounds are established (which_
_may or may not stand up to more detailed scrutiny, or prove well founded on a more detailed analysis) then_
_a positive reasonable grounds decision should be made to allow enough time and support for a proper_


-----

_conclusive grounds decision to be made. The initial filter should not be elevated to a detailed summary_
_determination of the ultimate credibility of the case advanced._

**Grounds for judicial review**

44. Permission was granted in respect of two overlapping Grounds:

i) Ground 1: There has been irrational consideration of the legal definition of a child victim of trafficking.

ii) Ground 2: The Defendant's decision has not applied the correct threshold in considering whether there
are “reasonable grounds” to suspect the Claimant is a victim of trafficking.

45. In oral argument it became clear that the Claimant's case really amounted to one central Ground –
that the SCA's Decision that there were not Reasonable Grounds to suspect that the Claimant is a VoT
was irrational in that it failed to take into account all relevant considerations and failed to follow and
rationally apply the Defendant's own Guidance in terms of relevant factors to be considered. This was the
central issue that was addressed and argued by both sides during this hearing.

46. That being so, I do not consider that the summary/headline formulation of either Ground encapsulate
the central issue as it emerged during the hearing, and I therefore consider that this Judicial Review should
be determined on the basis of the Ground identified at paragraph 45 above.

**The arguments**

47. It should be stated that the Claimant's essential case and the submissions made as summarised
below, had been set out in the Claimant's pleadings and skeleton argument and that Defence counsel had
addressed those arguments in his skeleton argument. Therefore, despite my reformulation of the essential
Ground of challenge as set out at paragraphs 45-46 above, both sides were on notice of the points that
were in issue.

48. Mr Lay, on behalf of the Claimant submitted that:

i) The SCA's Decision that there were not reasonable grounds to suspect that the Claimant is a VoT is
irrational because it did not consider all relevant facts and evidence, allied to the legal framework and
Guidance.

ii) The SCA decision-maker accepted the Claimant's account as being broadly consistent and not having
any significant credibility concerns. That being so, the decision-maker accepted that a child had been
approached by a man in Albania and embroiled in a scheme by which the Claimant agreed to pay £15,000
for a forged passport for the purposes of unlawful travel to the UK (money which the Claimant did not
possess and had no means of obtaining). The Claimant was threatened at the point of handover of the
forged passport that if he did not pay for it, his life would be at risk, he would be found and kidnapped and
that if he returned to Albania he would be found and killed or sent back abroad to work and pay off the
debt.

iii) This scenario means that logically there are reasonable grounds to suspect that the arrangement
generated a £15,000 debt obligation, payable either in Albania or at a future point in time post-arrival in the
UK and that the purpose of the provider of the passport was to subject the Claimant to forced labour to
obtain payment of the debt. The SCA's Decision did not consider this plainly relevant matter.

iv) The SCA's Decision did not address Dr Beddoe's view on the modus operandi of criminal gangs using
the “sale” of false passports to create a situation of debt bondage in which the only credible way that the
Claimant could repay the money would be by working under threat either in Albania or in the UK, a point he
made to the Defendant in his asylum interview.  In fact, the reasons for the SCA's Decision do not refer to
Dr Beddoe's view at all. The first direct reference to Dr Beddoe by the Defendant only came in the preaction protocol letter, and the Court should be wary of belated attempts to pad out, or backfill, the SCA's
Decision. The reality is that the SCA decision maker did not consider Dr Beddoe's evidence at all.

v) The SCA's Decision stated that evidence from _the United States of America Department of State_
_Trafficking in Persons Report for 2022 had been considered but the reasons for the decision do not in fact_


-----

refer to the findings of that Report or the obvious relevance of it as background supportive of reasonable
grounds to believe “for the purpose of trafficking” in the Claimant's case. The evidence from this report and
from Dr Beddoe demonstrate that the Claimant's circumstances are consistent with a recognised pattern of
trafficking from Albania to the UK. The SCA's Decision did not consider these plainly relevant factors.

vi) Nor did the SCA's Decision consider or apply paragraphs 2.23-2.24 of the Guidance (see paragraph 35
above) which deals directly with a situation (such as this), where the person has not yet been exploited.
The SCA's Decision therefore did not focus sufficiently (or at all) on the “purpose” and instead focussed on
the fact that no exploitation had actually occurred. Given that the Claimant was apprehended at UK
immigration, the opportunity for exploitation was prevented, and therefore focus needed to be on the
“purpose” rather than on the fact that no exploitation had actually taken place.

vii) Nor did the SCA's Decision consider or apply the Guidance on “unclear cases” (see paragraphs 2.59 –
2.62 of the Guidance at paragraph 47(vii) above) where trafficking and smuggling may be intimately
connected, particularly in the case of a child who cannot give informed consent to engage in criminal or
other exploitative activity, and they cannot give consent to be abused or trafficked (see Guidance
paragraph 2.6 at paragraph 5 above). The SCA's Decision did not consider whether this case was a
scenario in which smuggling overlaps with, or develops into, trafficking particularly in circumstances of debt
bondage where there is a failure to pay the debt (R(Y) at [36], paragraph 39(iii) above; see also TVN at [13]
at paragraph 38 above, “a combination of debt bondage plus force, coercion or menaces is highly likely to
_result in the individual being a victim of trafficking”. In oral submissions, Mr Lay pithily summarized the_
Claimant's situation as, “there is no such thing as something for nothing”.

viii) Mr Lay submitted that the Defendant failed to properly consider and address these matters in its
decision and that had it done so this would have led to a different conclusion – namely that there were
reasonable grounds to believe that the Claimant was trafficked for the purposes of exploitation. The
Defendant's position that no reasonable grounds exist is irrational. The Defendant has in effect focussed
only on the matters that support its decision.

ix) Mr Lay submitted that applying _HAM at [70] (see paragraph 43(iv) above), the decision-maker was_
required to ask himself whether notwithstanding a reasonable decision-maker could conclude there were
no Reasonable Grounds, was this a set of circumstances about which a(nother) rational decision-maker
was nonetheless capable of identifying Reasonable Grounds/credible suspicion? Applying this reasoning, it
is submitted that this means that it has to be the Defendant's position that no rational decision-maker could
ever be persuaded of “credible suspicion” on this Claimant's facts, even having regard to his being a child
at the time of the transaction.

49. On behalf of the Defendant, Mr Biggs submitted that:

i) The SCA's Decision that there were no reasonable grounds to believe that the defendant was
transferred for the purpose of exploitation was properly open to the Defendant. The Claimant's
submissions amount simply to disagreement with the Defendant's evaluative judgement and primary
findings of fact – matters which are matters which are within the province of the decision maker subject to
“anxious scrutiny”.

ii) Mr Biggs accepted that the decision-maker's evaluative judgement must take account of all relevant
factors, apply relevant Guidance and the correct test and that the reasons for the decision would have to
show expressly or by implication that all these have been taken into account. Interpretation of the
reasoning for the decision must be fair and contextual. If it can be inferred that a matter was (in fact)
properly taken into account, then it does not matter that the decision maker has not set out every aspect of
their reasoning.

iii) Mr Biggs submitted that this is a clear case that there were no reasonable grounds to believe that the
Claimant was transported for the purpose of exploitation.

iv) The SCA's Decision clearly recorded that the Claimant's witness statement, asylum interview record
and his solicitor's email of 8 March 2023 were considered. The SCA's Decision also set out the relevant
parts of the United States of America Department of State Trafficking in Persons Report for 2022 He


-----

submitted that the SCA's Decision gave an accurate summary of the Claimant's account. The reasons for
the SCA's Decision accurately set out the three stages and set out and applied the correct legal test and
threshold. The evaluative decision on “purpose” was expressed in a compressed way, but all that
paragraph 2.24 of the Guidance says is that the decision-maker needs to consider “purpose” - - whether or
not exploitation has actually occurred. The SCA's Decision did consider “purpose” and concluded that the
purpose was indicative of a smuggling arrangement rather than exploitation.

v) As to the evidence relied on by the Claimant, Mr Biggs submitted that Dr Beddoe's view amounts to little
more than speculation, and is inconsistent with the facts, because there have been no, “threats by
_traffickers that they [the claimant] will be exposed to police for travelling as illegal on a fake passport”._
Similarly, the Claimant's evidence in his witness statement as to what will happen to him if he returns to
Albania, including his opinion that he will be, “sent back abroad to work and pay off the debt” (see
paragraph 13(xi) above), is also speculation. Mr Biggs stated that it is notable that even now, nothing has
occurred that indicates that the purpose of the Claimant being transported to the UK was for the purpose of
forced labour. Any threats of violence that he and his family have received are in connection with the
enforcement of payment, rather than threats of enforcement through forced labour or servitude and
therefore consistent with a smuggling arrangement. The Claimant has never suggested that he has been
subjected to “debt bondage”.

vi) Mr Biggs submitted that at most, the Claimant's evidence amounts to an unsupported and speculative
possibility that he might be trafficked in the future to pay off the debt. This is insufficient to constitute
reasonable grounds to believe that the Claimant was transported for the purpose of exploitation. Whilst in
_R(Y) at [36], and TVN at [13] (see paragraph 38 and 39(iii) above), the Court recognised that smuggling_
may become exploitation if there is a combination of debt bondage and coercion, the basis for suggesting
that that line has been crossed in this case is entirely speculative.

vii) The evidence of exploitation is therefore speculative, not supported by the facts and at best contingent
and therefore applying ordinary language and common sense (see _MN at [342], paragraph 34 above) is_
insufficient to amount to “reasonable grounds to believe”.

viii) The Defendant was entitled to conclude that this is a case of “smuggling” as explained in the
Guidance and the SCA's Decision and does not satisfy the requirements of modern slavery.

ix) The Claimant's suggestion that the SCA decision-maker is required to ask whether, notwithstanding
that a reasonable decision maker could conclude there were no Reasonable Grounds, was this a set of
circumstances about which a(nother) rational decision-maker was nonetheless capable of identifying
Reasonable Grounds inverts the Wednesbury standard and is incoherent and wrong. All that a decisionmaker is required to do is apply the Reasonable Grounds to believe standard applying all relevant factors
and reach a Wednesbury reasonable decision. Nothing in _HAM at [70] (see paragraph 43(iv) above)_
supports the approach for which the Claimant contends.

**Discussion**

50. Dealing firstly with the Claimant's submission that the decision-maker was required to ask itself
whether notwithstanding a reasonable decision-maker could conclude there were no Reasonable Grounds,
was this a set of circumstances about which a(nother) rational decision-maker was nonetheless capable of
identifying Reasonable Grounds/credible suspicion? - I agree with the Defendant that this analysis is
wrong. All that the SCA decision-maker is required to do is to apply the Reasonable Grounds to believe
standard applying all relevant factors. _HAM at [70], when read in the context of [67] – [74] makes this_
clear. _HAM at [70] likewise confirms this,_ _“Provided there are reasonable grounds for belief, then the_
_question of whether there are also reasonable grounds for disbelief is irrelevant.”_

51. The role of this Court is to apply a heightened, more rigorous level of scrutiny (“anxious scrutiny”) to
whether or not the SCA decision-maker took into account all relevant considerations and followed and
rationally applied the Guidance in terms of the relevant factors to be considered. What matters is the
substance of the analysis, reasoning and conclusions, rather than matters of wording or form. Further,
there will be cases in which reasonable decision makers on the same facts may disagree on the question


-----

of whether there are Reasonable Grounds. It is no part of the role of the Court to interfere with such
decisions.

**_Facts, evidence and context_**

52. The SCA's Decision lists the NRM Referral and Welfare Form, the Claimant's witness statement and
asylum and interview record, and the Claimant's solicitor's email dated 8 March 2023 as being information
that was considered.

53. However, the only summary of this information contained in the SCA's Decision is a summary of the
contents of the Claimant's witness statement. As stated at paragraph 13(xi) above, this summary excludes
reference to the Claimant's evidence that:

_“I cannot return to Albania because I am afraid of the man I owe money to. He cannot be working alone_
_and must be part of a bigger group because one man cannot make a passport and then locate and_
_threaten my family. I cannot repay the debt and now they want the money and me as well. If I return, I will_
_be found and either killed or sent back abroad to work and pay off the debt.”_

54. The summary also does not contain any summary of the contents of the Claimant's asylum interview
record and therefore does not record his evidence given in that interview that, “They can kill me or take me
_to work for them, I don't know.” (see paragraph 14 above)._

55. The SCA's Decision quotes evidence taken from the United States of America Department of State
Trafficking in Persons Report for 2022 and states that this “has been considered regarding **_modern_**
**_slavery in Albania and the United Kingdom.” This evidence provides important context in that it_**
demonstrates that Albania is one of three leading nationalities of modern slavery victims and that labour
trafficking including forced criminality is the most common form of exploitation among adults and children.

56. The SCA's Decision then correctly sets out the standard of proof to be applied in making the SCA's
Decision.

57. Importantly, the Decision then states that “careful consideration has been given to the assessment of
_the available information in your case” – referring to the “available sources of information [as listed earlier_
_in the decision].”_ Mr Biggs for the Defendant submitted that the SCA's Decision gave an accurate
summary of the Claimant's account, however I do not agree. As explained above, the summary of the
information in the SCA's Decision excludes important matters which are directly relevant to the Reasonable
Grounds decision to be taken, and which are supportive of the Claimant's case. The summary of the
contents of his witness statement excludes his fear of being exploited, there is no summary of his interview
(and therefore no reference to his statement that “they can kill me or put me to work for them”), and no
summary at all, or reference to the content of the 8 March 2024 email.

58. Equally important is the finding in the SCA's Decision that, “it is recognised that you have been broadly
_consistent in your account and there are not considered to be any significant credibility concerns with your_
_account….your account is accepted applying the standard of proof 'I suspect but cannot prove”. Based on_
this finding, the Defendant thereby confirms that it accepts the Claimant's evidence, which means that the
Defendant must be taken to accept that the Claimant had a genuine fear of exploitation for the reasons
expressed by him in his witness statement and interview. In addition, the SCA decision-maker must have
accepted that a 17 year old Albanian child entered into an arrangement which created a £15,000 debt
obligation which he had no means to pay – a fact which must have been obvious to the provider of the
passport. These circumstances therefore required the SCA decision-maker to consider whether this
created a situation of debt bondage and how that debt would ever be repaid other than by some form of
**_modern slavery._**

59. The SCA's Decision then correctly sets out the three stage definition of human trafficking and correctly
concludes that the first step is satisfied, and the second step does not apply because the Claimant was a
child at the relevant time.

60. The crux of the SCA's Decision is then set out and the explanation for that decision is provided under
th h di “P _t ' '”_ Th fi t t tl t t th t id ti hi h i


-----

whether the Claimant was “recruited/transported/transferred/harboured/received for the purpose of
_exploitation.” The remaining four paragraphs set out the evidential basis (reasons) for the decision. These_
focus on evidence which is supportive of the conclusion of smuggling. It is notable however that the
reasons for the SCA's Decision do not contain any reference to the Claimant's genuinely held fear of
exploitation, nor to the information contained in the 8 March 2024 email (in particular the opinion of Dr
Beddoe and the references to contextual reports and research), nor does it contain any reference to the
contextual evidence from the United States of America Department of State Trafficking in Persons Report
for 2022. The SCA's Decision does not analyse the context or the relevance of that context to the
Reasonable Grounds Decision to be taken.

61. The SCA's Decision did not address Dr Beddoe's opinion on the _modus operandi_ of criminal gangs
using the sale of false passports to create a situation of debt bondage with a follow up of exploitation to
repay the debt. In fact, as I have said, the reasons for the SCA's Decision do not refer to Dr Beddoe's view
at all. The first direct reference to Dr Beddoe by the Defendant only came in the pre-action protocol letter,
and the Court should be wary of belated attempts to pad out or backfill the decision.

62. These factors are all contextual background which are capable of showing a recognised pattern of
trafficking from Albania to the UK which are consistent with the circumstances as described by the
Claimant.

63. All these factors are plainly relevant to the assessment of whether there were Reasonable Grounds to
believe that the Claimant was transported for the purposes of exploitation and it was incumbent on the
SCA decision-maker to consider these and explain why these factors nevertheless did not amount to
Reasonable Grounds. This in my view is what is meant by the requirement that a high quality of reasoning
is required in a Reasonable Grounds Decision which engages fully with the case advanced by the person
concerned due to the importance of the decision as a potential gateway to important rights including the
right to a Conclusive Grounds Decision (see paragraph 29(i) above).

64. In fact, the SCA's Decision set out and explained the points considered in support of the negative
decision, but do not do the same with the points in favour of the Claimant.

65. I have considered whether the SCA's Decision when taken as a whole, and applying a fair and
contextual approach, shows expressly or by implication that these relevant factors in favour of the Claimant
have been taken into account. I do not think it does, for the reasons I have given. The relevant factors are
not referred to in the SCA's Decision (with the exception of the United States of America Department of
State Trafficking in Persons Report for 2022), and none of them are dealt with in the reasons for the SCA's
Decision at all. As the Court stated in TDT at [47] (see paragraph X above), “the relevant evidence will be
_a mixture of generic and specific, and the question will be what its overall effect is when viewed as a_
_whole.” This plainly requires the full extent of the relevant generic and specific evidence to be identified and_
evaluated, not just the parts of the evidence that support the conclusion of the SCA decision-maker.

66. This also does not meet the requirements of high quality of reasoning which engages fully with the
case advanced by the person concerned (see paragraph 29(i) above), nor is it a careful and conscientious
analysis of all relevant factors in which every factor that might tell in favour of the person concerned has
been properly taken into account (see paragraph 29(ii) above).  The SCA's Decision in fact is consistent
with the conclusion that it did not take into account these plainly relevant considerations.

**Legal framework and Guidance**

67. The Guidance must be carefully applied and decision letters must include a full and detailed
consideration explaining the reasons for the decision (see paragraph 29(v) above). The correct legal
framework must be applied.

68. In this case, the SCA's Decision identified (correctly) that the focus of the decision was on the question
of whether there were reasonable grounds to believe that the Claimant was transported “for the purpose of
_exploitation” – applying ordinary language and common sense. Given that the Claimant was apprehended_
at the point of entry to the UK, this was clearly a case under the “what if someone hasn't yet been


-----

_exploited” section of the Guidance (paragraphs 2.23-2.24 (see paragraph 35 above). These sections make_
clear that a person can be a victim of trafficking even if they have not yet been exploited and that it is the
“purpose that is key rather than whether or not the exploitation has actually occurred”. That being so, it is
surprising that there is no reference in the SCA's Decision (whether express or implied) to this section of
the Guidance. There is force in the Claimant's submission that instead of focusing on the “purpose”, the
focus of the SCA's Decision was on the fact that no exploitation had actually occurred. The SCA's
Decision states, “From the information you have provided within your account it is considered that you
_were not forced to carry out any work against your will or under any menace of penalty.” This finding plainly_
influenced the conclusion that this was a smuggling arrangement, but the SCA's Decision, as I have
explained, does not consider the evidence of “purpose” which are supportive of the Claimant's case. Mr
Biggs for the Defendant dismissed these as speculation however it is notable that his rationale for this is
that nothing has in fact occurred that indicates that the purpose of the Claimant being transported to the
UK was for the purpose of exploitation. In so doing, Mr Biggs focuses on the result rather than the purpose
and moves away from the time at which the Decision was made – which was within a few days of the
Claimant's arrival in the UK. Mr Biggs further asserted that the threats of violence received by the Claimant
and his family are in connection with the enforcement of payment rather than exploitation, however this
does not absolve the SCA decision-maker of considering the evidence against this hypothesis.

69. The SCA's Decision demonstrates that the SCA decision-maker did not stand back and put the
decision in its full context. The supplier of the false passport must have known that the Claimant would use
it and leave Albania, and the supplier must have expected that he would be able to enforce the debt in
some manner.  The SCA decision maker did not consider what other way a 17 year old Albanian child
would be able to pay off a debt of £15,000 other than by way of debt bondage / exploitation. These factors
needed to be considered, particularly when set in context of the Claimant's evidence of his genuine (as the
Defendant found) fear of exploitation and the contextual evidence provided by the various reports cited and
Dr Beddoe's opinion.

70. The SCA decision-maker needed to consider all relevant factors and circumstances. A failure to do
so, leaves the SCA's Decision open to challenge on irrationality grounds. It would be obvious to the seller
of the passport that the Claimant had lied about being able to pay the debt. That being so, it begs the
question – how else would the debt be enforced other than by exploitation?

71. The Guidance deals at paragraphs 14.28 – 14.33 with the weight to be given by decision makers to
expert reports (see paragraph 40 above). Although Dr Beddoe had not made a formal report (which I was
told is not unusual at this early stage of the NRM process), her opinion as a well regarded expert should
have been expressly considered and taken into account when reaching a conclusion on whether the
Reasonable Grounds test is or is not, met. Although her opinion is not determinative, it should have been
considered in the round with all the other evidence. If, as the Defendant contends, her opinion was
dismissed by the SCA decision-maker as speculation, then in my view it was incumbent on the decision
maker to address this head on in the SCA Decision and explain why. This manifestly did not happen, and I
infer from this that in fact the opinion of Dr Beddoe was not considered at all, and that the Defendant's
subsequent attempts to suggest to the contrary are ex post facto. This was a failure to consider a
manifestly relevant matter in the substance of the SCA's Decision. In making this finding, I have in mind
that it is important not to adopt an overly strict approach to this SCA Decision, but it does need to have
considered the central matters in issue (as the Guidance and the relevant case law makes clear).

72. It is also notable that the Annex to the SCA's Decision refers only to paragraphs 2.56-2.57 of the
Guidance (see paragraph 37 above) which provide a description of human smuggling, but does not refer to
paragraphs 12.59 – 12.62 of the Guidance which deal with “Unclear cases” and which makes a number of
points of relevance to the Claimant's case including:

i) Trafficking victims may start out believing they are being smuggled but may end up in a potentially
exploitative situation where they are debt bonded.

ii) In some cases, the distinction between smuggling and trafficking can be blurred and it may be unclear
which category – trafficking or smuggling is at issue. The Claimant submitted (and I accept) that this may


-----

be particularly relevant in the case of a child who cannot give informed consent to be trafficked. I also
observe that a child is particularly vulnerable to exploitation and also vulnerable to not appreciating the risk
of entering into an arrangement in which a significant debt is accrued which he has no means to pay, the
purpose of the which is to later enforce the debt by means of exploitation. The Defendant's response is
that the evidence of exploitative purpose in this case is speculative, at best contingent and therefore
insufficient to amount to “reasonable grounds”. The difficulty with this submission is that nowhere in the
SCA's Decision does it engage with this issue, nor with this aspect of the Guidance at all. Instead, the
Annex quotes only the parts that describe smuggling (and are therefore supportive of the SCA's Decision)
but ignores the follow on paragraphs which demonstrate that the line between smuggling and trafficking is
far from clear cut and requires a thorough consideration of all relevant points. I conclude that the SCA
Decision did not deal with these matters because the SCA decision maker failed to take into account these
relevant considerations and failed to follow and rationally apply the relevant sections of the Guidance.

**Conclusion**

73. Ultimately, the Defendant's case is that the SCA's Decision was open to it in all the circumstances.
The difficulty with this as I have said, is that the SCA's Decision does not consider the relevant factors and
Guidance which assist the Claimant in establishing reasonable grounds which as the Court said in _HAM_

[74], “may or may not stand up to more detailed scrutiny, or prove well founded on a more detailed
_analysis) then a positive reasonable grounds decision should be made, to allow enough time and support_
_for a proper conclusive grounds decision to be made. The initial filter should not be elevated to a detailed_
_summary determination of the ultimate credibility of the case advanced.”_

74. The SCA's Decision is therefore irrational in that it failed to take into account all relevant
considerations and failed to follow and rationally apply the Defendant's own Guidance in terms of relevant
factors to be considered.

**Relief**

75. For these reasons, I find that the SCA's Decision in this case was unlawful.

76. The relief sought is that the SCA's Decision be quashed and remitted for reconsideration. The
Defendant has not advanced any discretionary grounds for refusing that relief. Accordingly, I will grant the
relief sought.

77. I add that nothing in this judgement should be taken as expressing any view one way or the other on
the range of lawful outcomes of any process of reconsideration of the Reasonable Grounds Decision
according to law in which all relevant matters and Guidance are taken into account. The role of this Court is
confined only to consideration on Judicial Review grounds of the SCA's Decision as framed. The
Defendant, on reconsideration of the Reasonable Grounds Decision, applying all relevant factors and the
Guidance, may nevertheless come to the same decision as before, but that is not a matter for this Court.

78. The parties are invited to prepare a draft order reflecting this judgment and addressing any
consequential issues including costs.

**End of Document**


-----

