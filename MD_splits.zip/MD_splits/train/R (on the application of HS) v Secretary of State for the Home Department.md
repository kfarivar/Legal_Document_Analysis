# R (on the application of HS) v Secretary of State for the Home Department

 [2019] EWHC 2070 (Admin)

Queen's Bench Division, Administrative Court (London)

Walker J

29 July 2019Judgment

Mr Tim Buley QC (instructed by Bhatt Murphy Ltd) for the claimant

Mr Neil Sheldon QC (instructed by the Government Legal Department) for the defendant

Hearing dates: 8 and 9 May 2019

- - - - - - - - - - - - - - - - - - - - 
Approved JUDGMENT

**The Hon Mr Justice Walker:**

A. Introduction and immigration bail legislation 5

A1 Introduction: anonymity, detention & refusal to renew bail 5

A1.1 Anonymity, and October 2018 material as to torture 5

A1.2 HS arrives, commits a crime, and stays without permission 5

A1.3 The September 2016 detention decision 5

A1.4 Period 1: no bail 6

A1.5 Periods 2 and 3: HS is on bail 6

A1.6 Period 4 and refusal to renew bail 6

A1.7 The February 2017 FTT bail decision 6

A1.8 The March 2017 re-detention decision 7

A1.9 Grounds, evidence and legal representation 7

A1.10 Structure of this judgment, and EIG 8

A1.11 The outcome 9

A2 Immigration detention and bail legislation 9

A2.1 The Court of Appeal decision in Lucas 9

A2.2 Conditional bail, comprising FTT bail and CIO bail 11

A3 Conditional bail and a “person detained” 12

A3.1 Konan: Bail availability no bar to judicial review of detention 12

A3 2 A basic principle: bail only for those lawfully detained 12


-----

A3.3 The 2016 Act confers retrospective powers of bail 14

B. History of events 15

B1 Events up to 13 February 2017 15

B1.1 Spouse application, sexual offence arrest, permission expiry 15

B1.2 Criminal proceedings 15 August 2012 to 14 January 2016 15

B1.3 Sentencing 14 January 2016 and prison to 12 September 2016 15

B1.4 Prison sentence conditional release, 12 September 2016 16

B1.5 Immigration detention & OASys, 12 Sep & 21 Dec 2016 16

B1.6 Bail application to the FTT: the Halesowen address 17

B1.7 The FTT hearing and decision on bail, 8 February 2017 17

B1.8 The FTT bail: primary and secondary conditions 17

B1.9 Grant of CIO bail from 13 February 2017 onwards 18

B2 Events from 14 February to 5 March 2017 18

B2.1 Concerns about the Halesowen address 18

B2.2 The re-detention minute of 3 March 2017 19

B3 Re-detention and documents: 6 March 2017 21

B3.1 Re-detention on 6 March 2017 21

B3.2 The 6 March asylum refusal, including certification 21

B3.3 The 6 March detention reasons 22

B4 Events from 7 March to 27 April 2017 22

B4.1 Medical examinations at Morton Hall IRC, 7 March 2017 22

B4.2 Colnbrook IRC 14-16 March: ETD & mirtazapine 30 mg 23

B4.3 JR challenge to certification, lodged 29 March 2017 23

B4.4 Mental health review, 3 April 2017 24

B4.5 First progress report, and detention review, 1 & 3 April 2017 24

B4.6 First Rule 35 report by Dr Dighe, 8 April 2017 31

B4.7 Second mental health review, 13 April 2017 31

B4.8 First Rule 35 response, 15 April 2017: Level 2 assessment 32

B4.9 De-certification, 21 April request for release, 27 April appeal 33

B4.10 Second progress report, 26 April 2017 34

B5 Events from 28 April to 25 May 2017 34

B5.1 Second detention review, 28 April 2017 34

B5.2 Third progress report, 4 May 2017 36

B5.3 Reply 4 May 2017 to 21 April release request 36

B5.4 Fourth progress report, 23 May 2017 37

B5.5 Home Secretary/FTT exchange as to “correct decision letter” 37


-----

B5.6 HS applies for section 4 support, 24 May 2017 37

B5.7 Release address: Dicksons/PC Baker 10 to 24 May 2017 37

B6 Events from 26 May to 23 July 2017 39

B6.1 Third detention review, 26 May 2017 39

B6.2 HS proposes the first Cobridge address, 1 June 2017 39

B6.3 Fifth progress report 5 June 2017 40

B6.4 Sixth progress report 20 June 2017 40

B6.5 Report on the first Cobridge address, 21 June 2017 40

B6.6 Fourth detention review, 23 June 2017 40

B6.7 Mirtazapine increased to 45mg daily, 28 June 2017 41

B6.8 Home Office default causes appeal adjournment, 11 July 2017 41

B6.9 Steps taken in relation to s 4 support, July 2017 41

B6.10 Release address: developments 11 to 23 July 2017 41

B7 Events from 24 July to 24 August 2017 42

B7.1 Fifth detention review & seventh progress report, 24 July 2017 42

B7.2 The 28 July asylum/ deportation letter 43

B7.3 Pre-action correspondence, 2 to 17 August 2017 43

B7.4 Sixth detention review & 8th progress report, 21 August 2017 43

B7.5 Release address: developments 24 July to 25 August 2017 45

B8 Events from 25 August to 19 September 2017 45

B8.1 Lodging of claim, & order of Nicola Davies J, 25 August 2017 45

B8.2 Order of May J, 1 September 2017 46

B8.3 Second Rule 35 report, 2 September 2017 46

B8.4 Response to second rule 35 report, 7 September 2017 46

B8.5 London Road release address rejected, 12 September 2017 47

B8.6 Seventh detention review, 13 September 2017 47

B8.7 Order of Ms Leigh-Ann Mulcahy QC, 19 September 2017 50

C. JR ground 1: abuse of power 51

C1 JR ground 1: background 51

C1.1 HS's stance in the original ground 1 51

C1.2 Court of Appeal decision in Lucas 51

C2 Current ground 1: an extended obligation 51

C2.1 The extended honour obligation 51

C2.2 Ground 1: what is not in dispute 52

C2.3 Nature of the extended honour obligation 52

C2.4 The court's jailor control role: A (Somalia) 53


-----

C3 Supreme Court decision in Evans v Attorney General 57

C3.1 Evans: HS's reliance on Lord Neuberger's principles 57

C3.2 Evans: the executive reviewability principle 59

C3.3 Evans: the binding judicial decisions principle 59

C3.4 Evans: my conclusion on Lord Neuberger's principles 60

C4 High Court decision in S 61

C4.1 R (S) v SSHD [2006] EWHC 228 (Admin): the decision 61

C4.2 S: arguably unlawful re-detention on 27 Jan 2006 62

C4.3 S: lawfulness of the 4 February 2006 notice 62

C4.4 S: submissions and analysis 63

C5 Court of Appeal decision in AR (Pakistan) 64

C6 High Court decision in Lupepe 66

C7 High Court decision in Gafurov 69

C8 Conclusion on JR ground 1 70

C8.1 Three different contexts 70

C8.2 Disobeying or interfering with the tribunal's order 71

C8.3 Powers to override or vary the tribunal's order 71

C8.4 Calling into question the FTT's reasoning 72

D. JR ground 2: legal principles governing detention 75

D1 JR ground 2: relevant legal principles 75

D2 Relevant Lumba principles in the present case 77

D3 Lumba principle (2): length of detention 77

D4 Lumba principle (4): diligence and expedition 78

D5 Conclusion on JR ground 2 79

E. JR ground 3: the AR policy 79

E1 JR ground 3: relevant aspects of the AR policy 79

E2 Analysis of alleged breaches of the AR policy 84

E3 Conclusion on JR ground 3 86

F. JR ground 4: reasons for detention 86

F1 JR ground 4: the true reason principle 86

F2 The true reason: concerns about the Halesowen address 87

F2.1 The new information, what it made imperative, & for how long 87

F2.2 Was the true reason communicated to HS on 6 March 2017? 88

F2.3 Request not to share the new information with HS 89

F3 Other breaches of the true reason principle 89

F4 Conclusion on JR ground 4 90


-----

G. Overall conclusion 90

A. Introduction and immigration bail legislation

A1 Introduction: anonymity, detention & refusal to renew bail

A1.1 Anonymity, and October 2018 material as to torture

1. By orders of Mrs Justice Nicola Davies dated 25 August 2017 and Mrs Justice May dated 1 September
2017 the claimant in these proceedings is to be known as “HS”. I stress that this means that no report of
these proceedings may identify him. The reason for that order is that HS seeks asylum, and in that regard
makes an assertion that he has been tortured by state agents in Pakistan. In November 2017 that
assertion was rejected by the First-tier Tribunal (“FTT”). However in October 2018 new immigration
solicitors for HS wrote a letter to the defendant Home Secretary enclosing a report by Dr Jillian Creasy of
the Medical Foundation for the Care of Victims of Torture. The letter was described as a fresh application
for asylum on account of fresh information and grounds. The letter also asked for consideration of HS's
human rights in respect of the information and grounds. At the time of the hearing before me on 8 and 9
May 2019 there had not been any substantive response by the Home Secretary to that letter.

A1.2 HS arrives, commits a crime, and stays without permission

1. In February 2011 HS, who is a national of Pakistan and was then aged 22, arrived in this country with
entry clearance for a limited period. His entitlement to be here was extended for some months when he
made an application to stay here as a spouse. He remained here without permission when the spouse
application was withdrawn.

2. In reality, even if (which he did not) HS had wanted to leave the UK, HS had little option but to stay
here. During the period when he had permission to be here he was charged with rape. Bail conditions,
imposed initially by the police and later by the court, continued after the date when he ceased to have
permission to be here. Compliance with those conditions required him to remain here. Eventually the
charge of rape was not pursued when he pleaded guilty to sexual activity with a girl under 16, leading to a
sentence of 16 months' imprisonment. While in prison he was served with a deportation order, and
responded by claiming asylum.

A1.3 The September 2016 detention decision

3. A detention decision by the Home Secretary (“the September 2016 detention decision”), made under
immigration detention powers, took effect from 12 September 2016 onwards. Detention began on that date
because it was the date when the custodial part of HS's sentence was complete. From that time, so far as
his prison sentence was concerned, HS was on licence until his sentence expiry date of 13 May 2017.

A1.4 Period 1: no bail

4. As explained below, a person detained under immigration detention powers can be granted bail. For
ease of exposition I have identified four material periods of time from 12 September 2016 onwards. During
the period 12 September 2016 to 7 February 2017 (“period 1”) HS was detained and was not granted bail.

A1.5 Periods 2 and 3: HS is on bail

5. At a contested hearing on 8 February 2017, by a decision which I say more about in sections A1.7 and
B1.7 below, the First-tier Tribunal (“FTT”) granted bail to HS. This grant of bail expired 5 days later, on 13
February 2017, when under the FTT's order HS was required to “appear before” (i.e. to surrender to) an
immigration officer. HS duly did this on 13 February 2017. I shall refer to the period from HS's conditional
release on 8 February to his surrender on 13 February as “period 2”.

6. On 13 February 2017 when HS surrendered the Home Office gave him bail, specifying a further date on
which he was to appear before an immigration officer. From then until 6 March 2017, Home Office officials


-----

gave HS further grants of bail. Each such grant of bail required HS to surrender on a specified date, the
last of which was 6 March 2017. I shall refer to the period from 13 February until 6 March as “period 3”.

7. I explain below why it seems to me that there are two possible legal analyses of periods 2 and 3. The
differences between these two analyses do not matter for present purposes.

A1.6 Period 4 and refusal to renew bail

8. HS surrendered, as required by his most recent grant of bail by the Home Office, on 6 March 2017.
When he did so he was informed that he was detained under immigration detention powers. He was
eventually released on 21 September 2017 in accordance with a High Court order made on 19 September
2017.

9. Period 4 is the period between 6 March and 21 September 2017. It is a period when HS was not on bail.
In sections A1.8, B2 and B3 below I say more about the decision to detain HS on 6 March 2017. For
reasons explained below, implicit in that decision was a decision not to renew HS's bail that day.

A1.7 The February 2017 FTT bail decision

10. As noted above, after being detained under immigration powers from 12 September 2016 onwards,
HS was released on conditional bail by a decision of the FTT made at a hearing on 8 February 2017. This
decision was embodied in a formal order dated 8 February 2017. I shall refer to it as “the February 2017
FTT bail decision”.

11. The February 2017 FTT bail decision is embodied in a written order signed by FTT Judge Mathews,
who made the order. It was also signed by HS and by two sureties. As was then commonly the practice for
grants of bail by the FTT, the February 2017 FTT bail decision did not give reasons for concluding that bail
was appropriate, nor did it give reasons for concluding that the conditions it specified were appropriate.

A1.8 The March 2017 re-detention decision

12. As also noted above, in March 2017 a decision was taken to re-detain HS under immigration powers. I
shall refer to it as “the March 2017 re-detention decision”. No written record of the final stage authorising
that decision has been produced to the court. However, as described in section B2 below:

(1) the March 2017 re-detention decision was preceded by a minute (“the re-detention minute”) comprising
a proposal by a Home Office official along with comments, signed on 3 March 2017, by a “quality assured
officer”;

(2) it is apparent from the re-detention minute that:

(a) the decision was to be taken by a process under which one or more “gate keepers” authorised redetention as proposed in the re-detention minute;

(b) the Home Office had been told of reservations about HS's bail address giving rise to a risk of harm to
the public; and

(c) the proposing official identified what was described as an “imperative”: namely that HS be “re-detained
until such a time that he can provide an appropriate address to be released to”;

(3) when re-detained on 6 March 2017 HS was given a document which purported to give the reasons for
his re-detention;

(4) it is clear that the “imperative” identified by the proposing official necessarily involved a further decision
that HS's bail by the Home Office would not be renewed and that no further grant of bail by the Home
Office would be made until an appropriate bail address had been provided;

(5) there is no reason to doubt that action in accordance with the re-detention minute, including the
“imperative” that it described, was duly authorised.

A1.9 Grounds, evidence and legal representation


-----

13. Mrs Justice May's order dated 1 September 2017 was made at a time when period 4 was still
continuing. Her order gave HS permission to rely on three grounds for judicial review. In their current form
they can be summarised as asserting that:

(1) the March 2017 re-detention decision was an abuse of power, or otherwise unlawful, because it was
incompatible with the February 2017 FTT bail decision;

(2) detention during period 4 was unlawful because it breached principles which require that detention
should not exceed a reasonable period and that the Home Secretary should act with reasonable expedition
to bring about that removal;

(3) detention during period 4 was unlawful because it involved public law errors in the application of the
Home Secretary's published “Adults at Risk” policy on detention (“the AR policy”).

14. A proposed fourth ground was notified by HS to the Home Secretary in March 2019. The Home
Secretary has no objection to it being advanced. I accordingly grant HS permission to rely on it. In
summary, it is:

(4) detention during period 4 was unlawful because the Home Secretary failed to give true or adequate
reasons for returning HS to detention.

15. In support of his claim HS has filed his own signed witness statements dated 13 September 2017
(“Statement HS1”), 15 September 2017 (“Statement HS2”) and 14 September 2018 (“Statement HS3”). In
answer to those statements the Home Secretary filed a statement (“Lartey 1”) made by an immigration
officer, Mr Emmanuel Lartey, dated 11 October 2018.

16. On 8 May 2019 HS sought permission to rely on a fourth witness statement. I declined permission as
the assertions in the proposed statement were not relevant to the issues which I had to decide.

17. At the hearing before me Mr Tim Buley QC, instructed by Bhatt Murphy Ltd, appeared for HS. Mr Neil
Sheldon QC, instructed by the Government Legal Department, appeared for the Home Secretary. I am
grateful for the assistance provided by the legal teams on both sides.

A1.10 Structure of this judgment, and EIG

18. In sections A2 and A3 below I give an account of relevant legislation and legal analyses of the effect of
that legislation in certain respects. Section B describes the history of events up to and including an order
made in the Administrative Court on 19 September 2017 for the conditional release of HS. In sections C, D,
E and F I discuss the four grounds for judicial review. Section G summarises my conclusions. Unless the
context indicates otherwise, square brackets in quotations below indicate an abbreviation that I have used
or explanatory material which I have inserted. On the same basis numbers or letters in square brackets
have been added by me for ease of reference.

19. It is convenient to mention here that a manual for immigration officers, known as Enforcement
Instructions and Guidance (“EIG”), sets out policies of the Home Secretary on various aspects of
enforcement.

A1.11 The outcome

20. In summary I hold as follows:

(1) the March 2017 re-detention decision involved no abuse of power, because:

(a) the February 2017 FTT bail decision was consistent with, and indeed supported, a conclusion that HS
should be a “detained person”;

(b) insofar as HS's true target was the decision not to renew CIO bail on 6 March 2017, the allegation of
abuse fails for the reasons given at (c) and (d) below;

(c) the non-renewal of bail was within the bounds of reasonableness, which in the circumstances was all
that the law required; and


-----

(d) if the law required a decision by the court that a material change since the February 2017 FTT bail
decision warranted the non-renewal of HS's bail, then the new information about HS's bail accommodation
did indeed objectively warrant this;

(2) detention during period 4 did not breach principles which require that detention should not exceed a
reasonable period and that the Home Secretary should act with reasonable expedition to bring about that
removal;

(3) detention during period 4 did not involve public law errors in the application of the AR policy; but

(4) detention at the start of period 4 was unlawful because the Home Secretary failed to give true or
adequate reasons for the March 2017 re-detention decision.

A2 Immigration detention and bail legislation

A2.1 The Court of Appeal decision in Lucas

21. The judgment of Hickinbottom LJ in _R (Lucas) v Home Secretary_ _[2018] EWCA Civ 2541 at_
paragraphs 8 to 12 gave an account of statutory provisions concerning immigration detention and bail. For
ease of reference I repeat here the substance of relevant parts of that account, adapted to the
circumstances of the present case. I return to the substance of the Lucas decision in section C1.2 below.

22. References in the present judgment to "Schedule 2" and "Schedule 3" are to Schedule 2 and Schedule
3 to the 1971 Act respectively, as they stood at all times material to the present case, i.e. before 15
[January 2018, when they were extensively amended by Schedule 10(2) to the Immigration Act 2016 (“the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
2016 Act”).

23. Paragraph 2 of Schedule 3 provided for "Detention or control pending deportation". At all material
times, sub-paragraph 2(3) read as follows:

(3) Where a deportation order is in force against any person, he may be detained under the authority of the
Secretary of State pending his removal or departure from the United Kingdom.

24. Sub-paragraph 2(4A) provided (so far as material) that:

(4A) Paragraphs 22 to 25 of Schedule 2 to this Act apply in relation to a person detained under subparagraph (3) as they apply in relation to a person detained under paragraph 16 of that Schedule.

25. These paragraphs thus extended the provisions of paragraphs 22 to 25 of Schedule 2 (which
otherwise only concerned detention of persons falling into categories set out in paragraph 16, none of them
applicable in the present case) to those detained under paragraph 2(3) of Schedule 3 (which is applicable
to HS).

26. Paragraphs 22 and 24 of Schedule 2 (at the material time, so far as material to the present case and,
in the light of paragraph 2(4A) of Schedule 3, replacing references to "paragraph 16" with "paragraph 2(3)
of Schedule 3"), stated as follows:

22. (1) The following namely … a person detained under [paragraph 2(3) of Schedule 3] may be released
on bail in accordance with this paragraph.

(1A) An immigration officer not below the rank of chief immigration officer or the [FTT] may release a
person so detained on his entering into a recognizance … conditioned for his appearance before an
immigration officer at a time and place named in the recognizance … or at such other time and place as
may in the meantime be notified to him in writing by an immigration officer.

(1B) …

(2) The conditions of a recognizance … taken under this paragraph may include conditions appearing to
the immigration officer or the [FTT] to be likely to result in the appearance of the person bailed at the
required time and place; and any recognizance shall be with or without sureties as the officer or the [FTT]
may determine."


-----

…

24. (1) An immigration officer or constable may arrest without warrant a person who has been released by
virtue of paragraph 22 above–

(a) if he has reasonable grounds for believing that that person is likely to break the condition of his
recognizance that he will appear at the time and place required or to break any other condition of it, or has
reasonable ground to suspect that that person is breaking or has broken any such other condition; …

(b) …

(2) A person arrested under this paragraph–

(a) if not required by a condition on which he was released to appear before an immigration officer within
twenty-four hours after the time of his arrest, shall as soon as practicable be brought before the [FTT] or, if
that is not practicable within those twenty-four hours, before … a justice of the peace; and

(b) if required by such a condition to appear within those twenty-four hours before an immigration officer,
shall be brought before that officer.

(3) Where a person is brought before the [FTT or] a justice of the peace … by virtue of sub-paragraph
(2)(a), the Tribunal [or] justice of the peace–

(a) if of the opinion that that person has broken or is likely to break any condition on which he was
released, may either–

(i) direct that he be detained under the authority of the person by whom he was arrested; or

(ii) release him, on his original recognizance or on a new recognizance, with or without sureties …; and

(b) if not of that opinion, shall release him on his original recognizance ….

A2.2 Conditional bail, comprising FTT bail and CIO bail

27. For convenience I shall refer to release under paragraph 22(1A) of schedule 2 as the grant of
“conditional bail”. Where granted by the FTT I shall refer to it as “FTT bail”. Where granted by an
immigration officer not below the rank of chief immigration officer I shall refer to it as “CIO bail”.

A3 Conditional bail and a “person detained”

A3.1 Konan: Bail availability no bar to judicial review of detention

28. Judicial review may be refused where the claimant has an effective alternative remedy. In R (Konan) v
_SSHD_ _[[2004] EWHC 22 (Admin) the Home Secretary advanced a submission that judicial review of Ms](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JT61-DYBP-N4FV-00000-00&context=1519360)_
Konan's detention was inappropriate since bail was an alternative remedy. This submission was robustly
rejected by Collins J, who pointed out at paragraph 30 that a tribunal considering a bail application:

is not determining ... the lawfulness of the detention. The grant of bail presupposes the power to detain
since a breach of a bail condition can lead to reintroduction of the detention.

A3.2 A basic principle: bail only for those lawfully detained

29. Subject to statutory intervention to the contrary, if it is demonstrated that a person has been unlawfully
detained, then in the absence of a new and lawful detention decision that person must be released
unconditionally. This was established by the decision of the Supreme Court in _R (B (Algeria)) v Special_
_Immigration Appeals Commission [2018] UKSC 5, [2018] AC 418, which I shall refer to as B (Algeria)._

30. The Supreme Court's judgment was delivered by Lord Lloyd Jones, with whom Baroness Hale PSC,
Lord Mance DPSC, Lord Hughes and Lord Hodge JJSC agreed. At paragraph 41 Lord Lloyd Jones noted
that it was unlikely that an applicant for bail would seek to challenge the tribunal's jurisdiction to grant bail.
He added, however, in this respect differing from an observation by Collins J in _Konan,_ that as it was a
matter of jurisdiction there may be cases in which the tribunal should properly take the point of its own


-----

motion. After examining arguments including contentions by the Home Secretary as to practical
implications, Lord Lloyd Jones's conclusion in paragraph 45 was clear, and was in outcome identical to that
of Collins J in Konan:

45. … I have no doubt that the statutory provisions with which we are concerned [provisions materially
identical to paragraph 22 of Schedule 2] require a lawful power to detain as a pre-condition to a grant of
bail. In any event, if administrative inconvenience is a consequence the remedy lies with Parliament.

31. It is here that it seems to me that two possible legal analyses might arise in relation to periods 2 and 3.
Both analyses are, however, subject to a potentially important qualification described in section A3.3
below.

32. The first analysis, which seems to me implicit in the wording of Schedule 2, is that the term “detained
person” refers not only to a person who has been wholly deprived of liberty but also to a person who,
following a decision to detain (“the index decision”), is given conditional release under an order granting
bail. The order granting bail would, for a defined period, partially restrict the extent to which that person
was deprived of liberty. On this analysis:

(1) a person granted conditional bail would continue to be a “detained person” pursuant to the index
decision;

(2) expiry of bail would simply mean that such a person by reason of the index decision remained a
detained person and no longer had the benefit of conditional release;

(3) immediately upon expiry of bail the Home Secretary could wholly deprive the person of liberty, the
reason being that the index decision had never lapsed but had only been modified during a period which
had now come to an end;

(4) accordingly if the Home Secretary proposed not to renew existing bail, then on expiry of the existing
bail it would not be necessary (although it might be desirable) to make a new decision to detain;

(5) the index decision would continue to have effect, however, only so long as detention pursuant to that
decision remained lawful;

(6) if detention pursuant to the index decision became unlawful at a time when the person had no bail then
the person would be entitled to immediate release, and in accordance with _B (Algeria)_ that entitlement
could not, in the absence of power to make a lawful fresh decision to detain, be frustrated by a purported
bail decision; and

(7) if detention pursuant to the index decision became unlawful at a time when a “detained person” was on
bail then the person would be entitled to immediate unconditional release, and in accordance with _B_
_(Algeria) that entitlement could not, in the absence of power to make a lawful fresh decision to detain, be_
frustrated by the existing bail decision or a new purported bail decision.

33. Thus on the first analysis there was no need for the March 2017 re-detention decision. When HS
surrendered in the normal way that day the September 2016 detention decision continued to have effect. In
order to achieve the “imperative” identified in the re-detention minute, all that was needed was simply to
refuse to renew CIO bail. However, although the March 2017 re-detention decision was not necessary,
once it was taken it replaced the September 2016 detention decision.

34. The second analysis says that once a detained person is released on bail that person would cease to
be a “detained person” unless and until a power of detention was newly and lawfully exercised. On this
analysis the March 2017 re-detention decision was an essential step if the “imperative” identified in the redetention minute were to be achieved. As to this analysis:

(1) it can be said in support that it gives the words “detained person” their ordinary meaning: a person who
has been released, even if the release is subject to conditions, would not ordinarily be regarded as
“detained”;

(2) on this basis the September 2016 detention decision would be superseded by the grant of FTT bail;


-----

(3) however on expiry of the FTT bail, and of each subsequent grant of CIO bail, there would, on this
analysis, need to be a new detention decision so that the formerly bailed person can become a “detained
person” who can then be released on CIO bail;

(4) it is not clear to me that there was any such new detention decision on expiry of the FTT bail, and of
each subsequent grant of CIO bail;

(5) if there were any such new detention decision on expiry of the FTT bail, and of each subsequent grant
of CIO bail, it is not clear to me that associated requirements, such as the giving of reasons for the new
detention, were complied with.

35. On this second analysis the March 2017 re-detention decision was a necessary step to enable the
Home Secretary, on expiry of HS's most recent CIO bail, to take HS into custody.

36. For present purposes, however, it does not matter which analysis is correct: on either view HS's
detention from 6 March 2017 onwards was pursuant to the March 2017 re-detention decision.

A3.3 The 2016 Act confers retrospective powers of bail

37. It might be that both analyses in section A3.2 above could need reconsideration in the light of Section
61 of the 2016 Act. Section 61 provides in material part:

…

(3) A person may be released and remain on bail under paragraph 22 or 29 of Schedule 2 to the
Immigration Act 1971 even if the person can no longer be detained under a provision of the Immigration
Acts to which that paragraph applies, if the person is liable to detention under such a provision.

(4) The reference in subsection (3) to paragraph 22 or 29 of Schedule 2 to the Immigration Act 1971
includes that paragraph as applied by any other provision of the Immigration Acts.

(5) Subsections (3) and (4) are to be treated as always having had effect.

38. Section 61 was not yet enacted when the Supreme Court gave the Home Secretary permission to
appeal in _B (Algeria)._ At the hearing of that appeal no reliance was placed by the Home Secretary on
section 61.

39. Neither side in the present case drew attention to, or relied upon, section 61. I have not attempted to
analyse whether section 61 actually has an effect on the analyses of periods 2 and 3 set out in section
A3.2 above. I proceed on the basis that it does not have any material effect on the arguments which arise
in the present case in relation to period 4.

B. History of events

B1 Events up to 13 February 2017

B1.1 Spouse application, sexual offence arrest, permission expiry

40. After arriving as a student in February 2011 HS entered into an arranged marriage in April 2012 with a
woman resident here. The following month an application (“the spouse application”) was made for him to
have further permission to remain as a spouse. Before that application was processed, however, on 15
August 2012 he was arrested on suspicion of sexual offending.

41. The spouse application was withdrawn on 27 July 2013. HS says that this was done without his
knowledge. In the meantime HS's student visa had expired on 27 September 2012. On and from 28 July
2013, at latest, HS was in the United Kingdom without permission to be here.

B1.2 Criminal proceedings 15 August 2012 to 14 January 2016

42. HS was eventually charged with rape. That charge, however, was withdrawn on 5 October 2015 when
HS pleaded guilty to a single charge of sexual activity with a female under the age of 16.


-----

43. When HS was arrested by the police on 15 August 2012, the police gave him unconditional bail. His
first appearance in court was on 20 August 2013. From that date until his sentencing hearing on 14
January 2016 he was subject to bail conditions imposed by the court. He complied with all those
conditions.

B1.3 Sentencing 14 January 2016 and prison to 12 September 2016

44. On 14 January 2016 HS was sentenced to 16 months in prison and placed on the sex offenders
register for a period of 10 years. The sentencing remarks record that HS's offending involved HS having a
thirteen-year-old female child, “A”, perform oral sex on him, after which he engaged in full sexual
intercourse with her vaginally. While he may not have been aware of her exact age, there was no doubt
that he must have known that she was under 16. This child and another girl, “C”, had run away from a
residential facility in which they had been placed because they were children at risk of sexual exploitation.
A and C were thus both vulnerable children. HS and another adult male known as “Raza” met the two
children at night time outside a pub as a result of a plan made by Raza and C. The sexual activity between
HS and A took place in the back of a car. An aggravating feature was that this occurred in the presence of
Raza and C. What happened took place with the consent of A. However, as the sentencing remarks
pointed out, the legislation was designed to protect young girls from themselves, as well as from adults
who willingly exploit them.

45. HS, in statement HS1, says that he accepted and continues to accept full responsibility for what he did
and is truly sorry for it. He notes that at the sentencing hearing the judge described references showing
clearly that HS made himself available to make his own community a better place and had done that
selflessly over the years. HS adds that while serving his prison sentence he was a healthcare and
substance misuse mentor, was designated a “red-band” (a status given to the most trusted prisoners), and
was regarded as a model prisoner.

46. On 20 May 2016 HS was served with a deportation decision and order under Section 32 of the UK
Borders Act 2007. He claimed asylum in July 2016, giving details of his claim at a screening interview on
29 July and a full asylum interview on 12 August 2016.

B1.4 Prison sentence conditional release, 12 September 2016

47. The sentence of 16 months in prison had the consequence that HS became eligible for, and was
granted, conditional release on 12 September 2016. On that day HS became subject to licence conditions
imposed by the prison service. These conditions were applicable until 13 May 2017, when the full sentence
of sixteen months was complete. The conditions included:

Not to reside (not even to stay for one night) in the same household as any child under the age of 18
without the prior approval of your supervising officer.

Not to have unsupervised contact with children under the age of 18 without the approval of your
supervising officer….

B1.5 Immigration detention & OASys, 12 Sep & 21 Dec 2016

48.  However HS did not leave the prison on 12 September 2016. The reason was that he had been
detained by the Home Secretary under immigration powers, and the prison became his place of detention
under those powers.

49. On 21 December 2016 the Probation Service conducted an OASys assessment of HS. The
assessment identified four categories of risk to others:

**Low risk of serious harm – current evidence does not indicate likelihood of serious harm.**

**Medium risk of serious harm – there are identifiable indicators of risk of serious harm. The offender has**
the potential to cause serious harm but is unlikely to do so unless there is a change in circumstances, for
example, failure to take medication, loss of accommodation, relationship breakdown, drug or alcohol
misuse.


-----

**High risk of serious harm – there are identifiable indicators of risk of serious harm. The potential event**
could happen at any time and the impact would be serious.

**Very High risk of serious harm – there is an imminent risk of serious harm. The potential event is more**
likely than not to happen imminently and the impact would be serious.

50. The OASys assessment on 21 December 2016 was that if HS were in the community he would pose a
medium risk to children and to the public.

B1.6 Bail application to the FTT: the Halesowen address

51. As regards his immigration detention HS applied to the FTT for bail in December 2016. For this
purpose he proposed a release address in Halesowen, Birmingham (“the Halesowen address”). The
address was visited by a probation officer on 13 December 2016. An email from the probation service to Mr
Lartey on 3 February 2017 stated that the Halesowen address “was assessed as suitable”.

B1.7 The FTT hearing and decision on bail, 8 February 2017

52. The FTT bail hearing took place on 8 February 2017. The Home Secretary opposed bail. In the light of
the 3 February 2017 email, however, no objection was taken by the Home Secretary to the suitability of the
Halesowen address if bail were to be granted.

53. It can confidently be assumed that when making the February 2017 FTT bail decision the FTT judge
found that such risk of harm, reoffending or absconding as existed could be acceptably managed by
conditions, along with recognisances given by two sureties each in the sum of £1000. In the absence of
such a conclusion the FTT judge would have been bound to refuse bail.

54. The formal FTT order, however, does not expressly record that conclusion. No written document gives
the FTT judge's reasons for that conclusion. Nor is there evidence of anything said orally by the FTT judge
in that regard.

B1.8 The FTT bail: primary and secondary conditions

55. The FTT bail conditions comprised a primary condition, along with secondary conditions. The primary
condition was to surrender bail to an immigration officer on 13 February 2017. It was expressed in these
terms:

The applicant is to appear before an immigration officer at West Midlands, Sandford House, 41 Homer
Road, Solihull, B9 3QJ between 09:00 and 17:00 on 13th February 2017 (or any other place and on any
other date and time that may be required by the Home Office or an immigration officer), at which time First
Tier Tribunal Immigration bail will end, and the Chief Immigration Officer will make any further bail decision.

56. The secondary conditions included compliance with electronic monitoring by means of a tag between
2300 and 0530 each night, compliance with the terms of the licence imposed by the prison service, and a
prohibition on entering employment, paid or unpaid, or engaging in any business or profession. In addition
HS was to report to the probation service in Dudley on Monday 13 February, and was required to live and
sleep at the Halesowen address.

B1.9 Grant of CIO bail from 13 February 2017 onwards

57. On 13 February 2017, as required by the FTT bail primary condition, HS surrendered bail to an
immigration officer. He was then given CIO bail. From that date until 6 March 2017 HS continued, in effect,
to be at liberty subject to conditions.

B2 Events from 14 February to 5 March 2017

B2.1 Concerns about the Halesowen address

58. It is not disputed that during the period from 14 February to 6 March 2017 HS was living at the
Halesowen address in compliance with the terms of his CIO bail. Paragraph 7 of Lartey 1 deals with a


-----

telephone call which Mr Lartey received on 15 February 2017 from a person he describes as “the Offender
Manager”. The person described this way was in fact the probation officer who had advised on the
suitability of the Halesowen address on 3 February 2017: see section B1.6 above.

59. Later on 15 February 2017 the probation officer sent an email to PC Jo Baker of West Midlands Police,
copied to Mr Lartey. It stated:

Following our telephone contact please find below details of the intelligence which indicates that the

[Halesowen] address … is not suitable.

Identifiable persons linked to the property have convictions for sexual offences. It is of concern that [HS] is
networking with persons that hold a similar nature of offending to himself.

This would also create opportunities for [HS] to offend and not be effective in managing his risk in the
community.

I apologise that you have not been informed of this intelligence at an earlier date.

There is also information to suggest other criminal behaviour perpetrated by [HS's] associates in the local
area.

This information is not to be shared with [HS] at this stage as it may instigate him to abscond.

I would be grateful of you could advise if we could re-detain [HS] based on his risk of harm to the public.

60. In paragraph 8 of Lartey 1 Mr Lartey confirmed that 15 February 2017 was the first occasion when the
Home Office became aware of concerns about the suitability of the Halesowen address. In paragraph 11
Mr Lartey noted that he had requested the police to provide him with information which was declined. In
that regard he referred to an exchange of emails with PC Baker. PC Baker is described in those emails as
“Dudley Sex Offender Manager”. On 16 February 2017 he emailed PC Baker seeking “the Intel report
relating to the address” and also asking whether the report was “disclosable to the Court (especially the
Immigration Judge who granted [HS] bail)”. PC Baker's response, in an email on 17 February 2017, was
that her statement would have to be:

… sent direct to the Judge in the case at the court they work from.

61. In disclosure provided by the Home Secretary an account is given of a further email from PC Baker at
about this time. So far as material, the email stated:

… To cut a long story short the address that he is at is not suitable as a bail address and he will be asked
by his probation officer to find other suitable accommodation.

They will give him a 2-week period to do so.

His probation officer… or her colleagues will be speaking with him by the end of the week to instruct him to
find an alternative address. …

B2.2 The re-detention minute of 3 March 2017

62. On 3 March 2017 Mr Lartey prepared on Form ICD.3079 a document entitled “Minute of a decision to
detain a person under immigration powers” (“the re-detention minute”). It identified a single outstanding
barrier to deportation. This was that an emergency travel document (“ETD”) needed to be obtained from
the Pakistani authorities. This was followed by a series of numbered paragraphs dealing with HS's
immigration history, a brief description of the offence leading to deportation being pursued, offending
history, deportation casework status, medical conditions (described as “none raised”) and current barriers
to removal (stating that an ETD was expected within one to three months).

63. Paragraph 7 of the re-detention minute dealt with risk of absconding, stating:

High – [HS] has no valid leave to remain in the UK. He knows our intention to deport him. Therefore, the
risk of absconding is always there.

64 In paragraph 8 Mr Lartey made an assessment of the risk of reoffending in these terms:


-----

Medium- [HS] has no previous convictions. However, he was made the subject of a signed deportation
order and has no lawful right to be in the UK and no right to employment or recourse to public funds, the
risk of re-offending for financial gain is always present.

65. Paragraph 9 was concerned with assessment of risk of harm to the public. Here Mr Lartey noted that
HS had been convicted of sexual activity with a female child under the age of 16 and commented:

… therefore the risk to the public is very high, especially to [females] under the age of 16.

66. Paragraphs 10 and 11 of the re-detention minute need not be set out here.

67. Paragraph 12 of the re-detention minute set out Mr Lartey's recommendations. It was in these terms:

[1] HS has shown that he has little regard for the UK criminal and immigration laws. He overstayed in the
UK and committed a very serious crime.

[2] On 8 February 2017, [HS] was released on bail as a result of his Offender Manager verifying his bail
address as being suitable to be released to. Shortly after his release his Offender Manager communicated
to the Home Office reservations about the address not being suitable. Due to [HS's] criminal offence for
which he has been placed on the Sexual Offenders' Register for 10 years, it is imperative for him to be redetained until such a time as he can provide an appropriate address to be released to.

[3] On the other hand, [HS's] asylum application has been concluded. [HS's claim to] asylum has been
certified as clearly unfounded and he has been afforded an out-of-country Right of Appeal. Once he has
been re-detained, he will be served with the necessary paper work to allow us to proceed with ETD
application.

[4] I have considered the presumption of release and liberty in favour of temporary admission or release as
set out under Chapter 55 [EIG] and have weighed this against the imperative to protect the public from the
risk of harm and re-offending.

[5] I therefore propose that [HS] should be re-detained based on his risk of harm to the public. Once
detained, arrangements will be made for a Face-to-Face interview with the Pakistani Authorities to enable
us to proceed with his removal from the UK.

68. Form ICD.3079 concludes with a section headed, “Quality assured officer's comments …”. In the redetention minute this section was completed by a Higher Executive Officer, Ms Diane Luff. Below I set out
relevant parts of her comments, with paragraph numbers added in square brackets for ease of reference:

[1] ICD.3079 has been quality assured and is now forwarded on to the gate keepers for them to authorise
detention.

[2] On 8 February 2017, [HS] was released on bail as a result of his [probation officer] verifying his bail
address as being suitable to be released to. Shortly after his release his [probation officer] communicated
to the Home Office her reservations about the address not being suitable …

[3] Both the Police and NOMs have provided information on [HS's] current address not being suitable and
his risk of harm to the public.

[4] He is due to report on 6 March 2017. We would appreciate it if he is re-detained on this date. This will
allow us time to serve him with the necessary paperwork for his deportation and RL will arrange for an F to
F interview [a face to face interview with the Pakistani High Commission] around the 13/3/17, however his
ETD will be not available for the up-coming charter.

[5] There is a valid expired Pakistani passport in our possession … to allow the Home Office [to] submit to
the Pakistani Authorities an ETD application.

[6] [HS's] asylum application has been concluded. His asylum has been certified as clearly unfounded and
he has been afforded an out-of-Country Right of Appeal. Once he is re-detained, he will … be served with
the necessary paper work.

[7] Note


-----

[8] [HS] is being retained for a F to F interview in order to obtain [an] ETD.

B3 Re-detention and documents: 6 March 2017

B3.1 Re-detention on 6 March 2017

69. On 6 March 2017 HS reported in accordance with his then current CIO bail conditions, under which he
had accepted a requirement to report that day. When he did so he was detained by an officer on behalf of
the Home Secretary. He was given two documents.

B3.2 The 6 March asylum refusal, including certification

70. As to the two documents given to HS on 6 March 2017, one was a notice of decision on form ICD.
4996. This document was a letter dated 6 March 2017 giving notice of a decision to refuse HS's protection
(i.e. asylum) and human rights claim. The letter also certified that HS's asylum and human rights claims
were clearly unfounded, with the consequence under section 94(1) of the Nationality, Immigration and
Asylum Act 2002 that HS could not appeal while in the United Kingdom. I shall refer to it as “the 6 March
asylum refusal”.

B3.3 The 6 March detention reasons

71. The other document given to HS on 6 March 2017 was a notice on form IS. 91R, also dated 6 March
2017, and which I shall refer to as “the 6 March detention reasons”. It was headed:

NOTICE TO DETAINEE

REASONS FOR DETENTION AND BAIL RIGHTS

72. The body of the 6 March detention reasons began with two numbered paragraphs stating that
detention of HS had been ordered under powers in the 1971 and 2002 Acts, and that detention was only
used when no reasonable alternative was available. Five tick boxes were then set out. Those relevant for
present purposes are a, c, and e. Box a, saying “You are likely to abscond if given temporary admission or
release”, was not selected. Box c, saying “Your removal from the United Kingdom is imminent”, was
selected. So was box e, saying “Your release is not considered conducive to the public good”.

73. The next part of the form required the signatory to state that the decision to detain had been reached
on the basis of one or more of a number of factors. Those selected in the 6 March detention reasons were:

…

6. You have not produced satisfactory evidence of your identity, nationality, or lawful basis to be in the UK.

7. You have previously failed or refused to leave the UK when required to do so.

….

10 You are excluded from the UK at the personal direction of the secretary of state.

…

12 Your unacceptable character, or conduct or associations.

B4 Events from 7 March to 27 April 2017

B4.1 Medical examinations at Morton Hall IRC, 7 March 2017

74. For the purposes of his detention HS was taken to Morton Hall IRC. Shortly after arrival he was seen
by a nurse, Mr Craig McKitterick, who conducted a reception health assessment. Mr McKitterick's notes,
made at 01.39 on 7 March 2017 include the following:

Saw this chap in reception, he states he has no long-term health problems and no recent injuries. He
states he suffers with PTSD from his torture in Pakistan and that this makes him extremely anxious. He


-----

currently has a tag on his leg which reminds him of when he was shackled and it causes him great
distress. He is currently taking mirtazapine 15mg …

Denies any thoughts of DSH or suicide

No other issues raised and nil concerns.

…

Reason for referral … - States he has been suffering with depression for a long time which is related to his
torture at home in Pakistan. He feels very low in mood and has expressed thoughts of self-harm in the
past. No current thoughts.

75. Later on 7 March HS was seen at the health centre by Dr Satyajit Datta. Notes made by him at 10:41
that day record HS telling him that mirtazapine had been prescribed for anxiety and depression, and
helped HS in this regard. Dr Datta's notes show that he prescribed mirtazapine for HS at a dosage of 15
mg daily.

76. Dr Datta also noted that HS was asking for a “Rule 35” [a torture assessment].

B4.2 Colnbrook IRC 14-16 March: ETD & mirtazapine 30 mg

77. HS was transferred to Colnbrook IRC on 14 March, returning to Morton Hall IRC on 16 March 2017.

78. On 15 March 2017 HS participated in an interview with the Pakistani High Commission. The purpose
of the interview was so that the High Commission could consider whether to agree to a request by the UK
government for the issue of an ETD (see section B2.2 above) enabling HS to be returned to Pakistan.

79. Morton Hall IRC medical records indicate that during HS's stay at Colnbrook IRC his daily dose of
mirtazapine was increased to 30 mg.

B4.3 JR challenge to certification, lodged 29 March 2017

80. On 29 March 2017 Dicksons Solicitors Ltd (“Dicksons”), acting for HS, lodged a claim for judicial
review in the Upper Tribunal seeking to challenge the part of the 6 March asylum refusal which certified
HS's asylum claim as clearly unfounded.

B4.4 Mental health review, 3 April 2017

81. On 3 April 2017 Mr Stephen Wyatt, a nurse at Morton Hall IRC, met HS and conducted a mental
health review. Mr Wyatt made notes which included the following:

… [HS] said that he was concerned over the Home Office leaking information to the Pakistani authorities
because he recently had an interview with the Pakistani High Commission. … We did some problemsolving work on how to only concentrate on those things he could influence, in effect I coached him on
unproductive and productive worry. He found benefit from this but he does not require any further formal
contact due to the level of need being quite low. Ad hoc pastoral support will suffice for his needs at
present, he has no thoughts of self-harming or suicide. Generally mood is euthymic and his work is
keeping him occupied and socially engaged.

B4.5 First progress report, and detention review, 1 & 3 April 2017

82. On 1 April 2017 Mr Lartey signed a document addressed to HS and headed, “MONTHLY PROGRESS
REPORT TO DETAINEES”. This was a document which used a standard format. As will be seen, despite
the heading, in HS's case it was prepared more frequently than monthly. I shall refer to it simply as a
“progress report”.

83. The standard format for progress reports involved what I shall refer to as a number of sections. Those
sections, and what was said in them in the first progress report of 1 April 2017, were:

(1) What I shall call section [1] was headed, “Reason for detention:”. What I shall call paragraph [1.1]
explained that HS was detained under schedule 3 as a subject of a deportation order pending his removal


-----

or departure from the United Kingdom. What I shall call paragraph [1.2] said that the current position of
HS's case was set out in the following parts of the document.

(2) What I shall call section [2] was headed, “Reasons for deportation”. What I shall call paragraph [2.1]
then recorded that HS was convicted on 5 October 2015 of sexual activity with a female child under 16,
that he was sentenced to 16 months imprisonment on 14 January 2016, and that he was also “made the
subject of Sexual Offenders Register [i.e. subject to the notification requirements of the _[Sexual Offences](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)_
_[Act 2003] for 10 years”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)_

(3) What I shall call section [3] was headed, “Brief immigration history.” This set out what I shall call
paragraphs [3.1] to [3.7]:

[3.1] You arrived in the United Kingdom (UK) on 11 February 2011 in possession of an entry clearance as
a student valid until 27 September 2012.

[3.2] On 17 May 2012, you applied for Further Leave to Remain as a spouse of a person settled in the UK
but withdrew your application on 27 July 2013.

[3.3] On 23 March 2016, you were served with a notice of a decision to deport – Stage 1 (ICD.4936) letter.

[3.4] On 20 May 2016, you were served with a deportation decision (ICD.4934) and deportation ordered
since you failed to respond to our Stage 1 letter.

[3.5] On 11 July 2016, you submitted an asylum claim stating that you had been involved in political
agitation and you fear for your life should you be returned to Pakistan.

[3.6] On 29 July 2016, your screening interview was completed.

[3.7] On 12 August 2016, your full asylum interview was completed.

(4) What I shall call section [4] was headed, “Current barrier to removal”. Under this heading what I shall
call paragraph [4.1] appeared, making reference to HS's “ETD”, as to which more information appeared
later in the document, and to HS's “JR” as to which no further information appeared in the document:

[4.1] Your ETD and JR

(5) What I shall call section [5] was headed, “Progress since last review”. Under this heading what I shall
call paragraphs [5.1] to [5.3] were set out:

[5.1] Your asylum application has been refused.

[5.2] We are continuing to make arrangements to obtain a travel document for your removal from the
United Kingdom. However this is taking longer than we would like because you have refused to be
interviewed by the Pakistani Authorities. If you wish to assist us in progressing your case, and potentially
reducing the time you spend in detention prior to removal, please speak to one of the officers in your prison
establishment.

[5.3] You are advised that your continued failure to co-operate with the Emergency Travel Documentation
process is a factor in the decision to maintain detention. You should also be aware that continued failure to
co-operate will remain a factor in deciding whether to maintain detention or grant bail in future. While
decisions will be considered on the basis of all known, relevant factors, you should also note that non-cooperation may result in a prolonged period of detention. In addition, there is a onus on you to leave the
country once your appeal rights have been exhausted.

(6) What I shall call section [6] was headed, “Facilitated Return Scheme (FRS)”. This section contained
information about the Facilitated Return Scheme (“FRS”), a voluntary scheme designed to assist those
wishing to return to and settle in their home countries.

(7) What I shall call section [7] began with two opening sentences as set out below, followed by what I
shall call paragraphs [7.1] and [7.2]:

[7] Your case has been reviewed. It has been decided that you will remain in detention to effect your
removal from the UK because


-----

[7.1] You are likely to abscond if given temporary admission or release.

[7.2] Your release carries a high risk of public harm.

(8) What I shall call section [8] consisted of an opening sentence as set out below, along with what I shall
call paragraphs [8.1] to [8.7]:

[8] This decision has been reached on the basis of the following factors

[8.1] However, you are seeking to deliberately delay your removal by refusing to comply with your ETD
interviews.

[8.2] You have obstructed the removal process by failing to cop-operate with the application process to
obtain an Emergency Travel Document. On 19 May 2016 and 26 May 2016 you refused to comply with
ETD interviews.

[8.3] You do not have enough close ties (e.g. family or friends) to make it likely that you will stay in one
place. You have not provided any evidence of family which will allow you to stay in once place.

[8.4] You have shown a lack of respect for United Kingdom law as evidenced by your conviction for a
serious crime, namely Sex Offences against Children not listed Elsewhere, Rape.

[8.5] You have been assessed as posing a serious risk of harm to the public because you have committed
the following offence Sex Offences against Children not listed Elsewhere, Rape.

[8.6] You have committed an offence and there is a significant risk that you will re-offend.

[8.7] Your unacceptable character, conduct or associations.

(9) What I shall call section [9] was as follows:

[9] Consideration has been given to the factors in favour of release, but due to the seriousness of the
offence these must be particularly compelling to outweigh the above, therefore it is considered that
detention for the purposes of deportation is reasonable.

(10) What I shall call section [10] stated:

[10] Your detention will continue to be reviewed on a regular basis and any significant material changes to
your case will be considered against this decision.

(11) What I shall call section [11] was headed, “Bail Rights”. The information set out under this heading
included what I shall call paragraphs [11.1] to [11.2]:

[11.1] This explains certain rights that you have as a detainee to apply to be released on bail.

[11.2] If you have been served with a deportation order and you are detained pending your removal or
voluntary departure, you may apply at any time, pending the giving of removal directions, to a Judge of the
First Tier Tribunal or the Secretary of State to be released on bail.

84. On 3 April an authorising officer, on this occasion Senior Executive Officer L. Todd, commented on a
first detention review prepared by Mr Lartey.

85. This, too, was a document with a standard format. Most of the document comprised a review set out in
14 numbered sections. Those sections are identified below, along with information about what was set out
in relevant sections of the first detention review dated 3 April 2017 for HS:

(1) Section 1 was headed, “Immigration History”. What I shall call paragraphs [1.1] to [1.4] were in broadly
similar terms to paragraphs [3.1] to [3.4] of the first progress report dated 1 April 2017. What I shall call
paragraph [1.5] was in broadly similar terms to paragraphs [3.5 and [3.6] of that report, and what I shall call
paragraph [1.6] was broadly similar to paragraph [3.7]. An additional paragraph which I shall call
paragraphs 1.7. stated:

[1.7] On 6 March 2017, [HS] was re-detained by the Home Office. He was served with asylum decision. His
asylum was refused with an Out-of-Country right of appeal.


-----

(2) Section 2 had a heading, “Brief description of the offence(s) committed which have led to deportation
being pursued and any relevant judge's sentencing remarks”. Under this heading what I shall call
paragraph [2.1] was in broadly similar terms to paragraph [2.1] of the first progress report dated 1 April
2017.

[2.1] On 5 October 2015, [HS] was convicted at Stoke on Trent Crown Court of sexual activity with a
female child U.16 – offender 18 or over – penetration of anus/ vagina/ mouth by penis/ part of body and
sentenced to 16 months imprisonment on 14 January 2016. He was also made subject of Sexual
Offenders Register for 10 years.

(3) Section 3 was headed “Offending History”. Under this heading appeared what I shall call paragraph

[3.1]:

[3.1] This is his only offence in the UK.

(4) Section 4 was headed “Deportation casework status”. Under this heading appeared what I shall call
paragraph [4.1]:

[4.1] On 20 May 2016, [HS] was served with a signed Deportation Order. He was served with an asylum
decision on 6 March 2017.

(5) Section 5 was headed, “Known or claimed medical conditions (including mental health and/or self-harm
issues, PTSD, Risks of suicide)”. Under this heading appeared what I shall call paragraph [5.1]:

[5.1] None known or claimed. No R35 application has been submitted by [HS].

(6) Section 6 was headed “Current barriers to removal (including documentation and compliance)”. Under
this heading what I shall call paragraph [6.1] appeared, followed by an indication that a travel document
was expected to be issued within 3 to 6 months. Paragraph [6.1] stated:

[6.1] Compliance – Yes, - [HS] was seen on 15th March 2017 at Colnbrook IRC by the Pakistan High
Commission. We are waiting for the outcome of the interview.

(7) Section 7 was headed “Assessment of risk of absconding”. Under this heading appeared what I shall
call paragraph [7.1]:

[7.1] High – [HS] has no valid leave to remain in the UK; he knows our intention is to deport him, therefore,
the risk of absconding is always there.

(8) Section 8 was headed, “Assessment of re-offending”. Under this heading appeared what I shall call
paragraph [8.1]:

[8.1] Medium – [HS] has no previous convictions. However, he was made the subject of a signed
deportation order and has no lawful right to remain in the UK and no right to employment or recourse to
public funds, therefore the risk of re-offending for financial gain is always present.

(9) Section 9 was headed, “Assessment of risk of harm to the public”. Under this heading appeared what I
shall call paragraph [9.1]:

[9.1] [HS] was convicted of sexual activity with female child U.16 - offender 18 or over – penetration of
anus/vagina/mouth by penis/part of body. Therefore, the risk to the public is very high, especially to
females under the age of 16.

(10) Section 10 was headed, “Risk indicators and risk level, according to the Adults at Risk policy (where
relevant)”. Under this heading appeared what I call paragraph [10.1]:

[10.1] There is currently no indicator which will classify him as an adult at risk.

(11) Section 11 was headed “Previous applications for bail or temporary release”. Under this heading
appeared what I shall call paragraphs [11.1] to [11.4]:


-----

[11.1] For the attention of the Section 4 Team in the event of a S4 bail application accommodation level 3
is considered appropriate. For proposed level 2 and level 3 cases further details to follow upon receipt of
pro-forma from the Section 4 Team.

[11.2] He withdrew his bail application on 20 October 2016.

[11.3] His bail application dated 16 December 2016 was refused on 23 December 2016.

[11.4] He was granted bail on 8 February 2017, but was re-detained on 6 March 2017.

(12) Section 12 was headed, “Action taken to progress since last review (in bullet point format only)”.
Under this heading appeared what I shall call paragraph [12.1]:

[12.1] Re-detained [HS].

(13) Section 13 was headed, “Action planned for next review period (in bullet point form only)”. Under this
heading appeared what I shall call paragraph [13.1]:

[13.1] Liaise with RL on [HS's] ETD.

86. The part of the document comprising the review ended with section 14. That section was headed:

14. Recommendation (whether to maintain detention or release, supported by reasons). Including any
other compassionate circumstances (including children issues and ties to the UK).

87. In the first detention review authorised on 3 April 2017 Mr Lartey's recommendation was in what I shall
call paragraphs [14.1] to [14.5]:

[14.1] [HS] has shown that he has little regard for the UK criminal and immigration laws. He overstayed
leave to remain in the UK and has committed a very serious sexual offence on a minor.

[14.2] Should [HS] be released into the community, the nature of his crime indicates he continues to pose a
serious risk of harm to the public.

[14.3] Furthermore in view of [HS's] serious crime and disregard for the UK laws and the fact that he now
knows that our intention [is] to remove him, he will have no incentive to remain in touch with the Home
Office.

[14.4] I have considered the presumption in favour of temporary release/liberty as set out under chapter 55
of the EIG and Vulnerable Adults at Risk Policy. Consideration has also been given to all relevant factors in
favour of release, however, he poses a risk of harm to the public which is considered to outweigh the
presumption in favour of release.

[14.5] I propose that [HS] should be detained until we procure an ETD to remove him from the UK.

88. The authorising officer's comments stated in what I shall call paragraphs [AOC.1] and [AOC.2]:

[AOC.1] [HS] has been convicted of a serious sexual assault and he continues to pose a risk of harm,
particularly to females under 16 years of age. His deportation is therefore both proportionate and justified.
We are currently attempting to document [HS] and I note we are awaiting the outcome of an interview with
the Pakistani authorities.

[AOC.2] Having reviewed evidence before me, and having given due weight to [HS's] offence, I consider
the presumption to liberty is outweighed by the risks of re-offending, harm, and absconding. I hereby
authorise [HS's] continued detention for a further 28 days.

B4.6 First Rule 35 report by Dr Dighe, 8 April 2017

89. Dr Dighe examined HS on 8 April 2017 in order to prepare a Rule 35 report. That report (“the first Rule
35 report”) described HS's account of torture (“AOT”) in Pakistan. Section 6 of the report was headed
“Assessment”. As to the consistency of his findings with HS's allegations, and whether there might be other
plausible causes for those findings, Dr Dighe stated:


-----

[1] Scars shown to me on his Lt wrist of 0.5cms & Rt arm cigarette burns seem consistent with his AOT in
Pakistan between 2007-2010.

[2] No other plausible causes.

90. As to the impact that detention was having on HS, Dr Dighe stated:

[3] Here in detention he gets flash backs and feels anxious about being sent back and brutally killed if he is
asked to return to Pakistan. He said he walks up & down the corridors lost in thought and memories of
these past events.

B4.7 Second mental health review, 13 April 2017

91. On 13 April 2017 there was a second mental health review. It was conducted by the same nurse who
conducted the review on 3 April 2017, Mr Stephen Wyatt (see section B4.4 above). Mr Wyatt's notes of this
second mental health review included:

I reflected to him that his level of need was now much reduced and his self-care had improved
substantially, he agreed that he could now employ the techniques of stop and think and opposite action
when he remembers them. He said it is still hit and miss at times but it is getting better and he finds he can
socialise much more effectively now than in previous weeks. He said that perhaps in the first few days here
that he might have been over anxious but he has simply got used to living here and this has reduced his
symptoms.

B4.8 First Rule 35 response, 15 April 2017: Level 2 assessment

92. The Home Secretary's response to the Rule 35 report (“the first Rule 35 response”) was prepared on
15 April 2017 in a document addressed to HS. It stated, after recording what had been said by Dr Dighe:

[10] … your account of ill-treatment does meet the … definition of torture. Accordingly, it is accepted that
the evidence provided meets Level 2 and as such, you are regarded as an Adult at Risk under the [AR
policy].

93. It is convenient here to set out “Level 2” as described in the AR policy:

[Level 2:] where there is professional and/or official documentary evidence indicating that an individual is
an adult at risk but no indication that detention is likely to lead to a significant risk of harm to the individual if
detained for the period identified as necessary to effect removal.

94. The first Rule 35 response then set out HS's immigration history, including that on 11 April 2017 the
Pakistani High Commission had agreed to issue an ETD. It also set out details of HS's conviction and
sentence. The first Rule 35 response then continued:

Balancing risk factors against immigration control factors

[18] Consideration has been given to balance your wellbeing whilst in detention, against the risks of harm
to the public and the need to maintain effective immigration control.

[19] Although you entered the UK with valid leave, it is noted that after you withdrew your application for
leave to remain as the spouse of a person settled in the UK, you remained in the UK illegally. Given that
you were not complying with the condition of your leave to enter, there is nothing to demonstrate that, if
you were released from detention, you would comply with any restrictions placed on you.

[20] It is also considered, in view of your history of offending which involved sexual activity with a female
child under 16 that you present a risk to the public and that your detention is therefore justified.

[21] No issues in regard to your physical or mental health were indicated prior to your Rule 35 report, which
was received after you were made subject of a deportation order and after your asylum claim was refused.
Although you are an adult at risk, the Doctor has not indicated that a period of detention is likely to worsen
your symptoms.


-----

[22] The only barrier to removal is your application for judicial review and if permission is refused, it is
considered that your removal can be effected within a three month timescale.

95. Under the heading “Conclusion” the first Rule 35 response stated:

[23] It is acknowledged that you are an adult at risk but it is considered that your removal can be enforced
within a reasonable time scale.

[24] Therefore when balancing the indicators of vulnerability against the negative immigration factors
highlighted above and the timescale for your removal, it is considered that the negative factors outweigh
the risks in your particular circumstances. Therefore a decision has been made to maintain your detention.

B4.9 De-certification, 21 April request for release, 27 April appeal

96. Meanwhile on 13 April 2017 the Home Secretary filed an acknowledgment of service in the Upper
Tribunal judicial review claim. This document indicated that certification had been withdrawn, with the result
that HS would have an in-country right of appeal against the decision to refuse his asylum claim.

97. On 21 April 2017 Dicksons wrote to Home Office officials, submitting that it was unreasonable to
detain HS any further given the time it was likely to take for his asylum appeal to be determined. It was
added that detention had worsened HS's symptoms, requiring an increase in the dosage of his mirtazapine
tablets, and that continuing detention was likely “to have an enormous impact on HS's mental health”.

98. As had been noted in the letter of 21 April, withdrawal of certification by the Home Secretary now
enabled HS to lodge an appeal against the 6 March asylum refusal. In the absence of a response to the 21
April letter, Dicksons duly did so on 27 April 2017.

B4.10 Second progress report, 26 April 2017

99. Mr Lartey signed a second progress report on 26 April 2017. Section [1] and section [2], dealing with
reason for detention and reasons for deportation, were unchanged from the first progress report of 1 April
2017. In section [3], dealing with immigration history, paragraphs [3.1] to [3.7] were unchanged. A new
paragraph [3.8] was added:

[3.8] Your Rule 35 application [response] was served on you on 15 April 2017. You have been assessed as
meeting Level 2 of the Adults at Risk Policy on the basis of evidence provided. Your detention has been
reviewed and the report considered when determining your suitability for detention under the 'Adult at Risk'
policy. It has been decided to maintain your detention.

100. Changes were also made in sections [4] and [5]. In section [4], dealing with the current barrier to
removal, the previous paragraph [4.1] was replaced with the words, “Your accepted in-country right of
appeal”. In section [5], dealing with progress since the last review, what was said in the previous paragraph

[5.1] was replaced by a new paragraph [5.1]:

[5.1] Your JR has been progressed and it has been accepted that you will be afforded an in-country right of
appeal.

101. Paragraphs [5.2] and [5.3] were unchanged. So were sections [6], dealing with the FRS, and [7],
identifying likelihood of absconding and high risk of public harm as reasons why HS should remain in
detention to effect his removal from the UK. Section [8], identifying factors on the basis of which the
decision had been reached, also remained unchanged. So did section [9], stating that consideration had
been given to factors in favour of release. Similarly there was no change to sections [10], stating that
detention would continue to be reviewed, and [11], dealing with bail rights.

B5 Events from 28 April to 25 May 2017

B5.1 Second detention review, 28 April 2017

102. On 28 April 2017 Assistant Director D. Hervey, a Grade 7 official, acted as authorising officer and
signed HS's second detention review. The review had again been prepared by Mr Lartey. In section 1,


-----

dealing with immigration history, paragraphs [1.1] to [1.7] were unchanged. A new paragraph [1.8] noted
that on 12 April 2017 the Home Office had agreed that HS's case should be reviewed and he should be
afforded an in-country right of appeal.

103. There were no changes to sections 2, 3 and 4, dealing with the offence committed, offending history,
and deportation casework status. In section 5, dealing with medical conditions, the previous paragraph

[5.1] was replaced by a new paragraph [5.1]:

[5.1] [HS] submitted a Rule 35 application on 10 April 2017. His Rule 35 application [response] was faxed
to be served on him on 15 April 2017.

104. In section 6 the question as to when a travel document was expected to be issued was indicated not
to be applicable, presumably for the reason given in a replacement paragraph [6.1]:

[6.1] Compliance – Yes, [HS's] ETD has been agreed by the Pakistani Authorities.

105. There were no changes to sections 7, 8 and 9, dealing with assessment of risks of absconding,
reoffending and harm to the public. In section 10, dealing with the AR policy, the previous paragraph [10.1]
was replaced new paragraphs [10.1] and [10.2]:

[10.1] Risk Level: 2 – In relation to his claim of ill-treatment, his account of ill-treatment does meet the
above definition of torture. Accordingly, it is accepted that the evidence provided meets Level 2 and as
such, he is regarded as an Adult at Risk under the policy. His detention was reviewed and the report
considered when determining his suitability for detention under the 'Adult at Risk' policy.

[10.2] It [was] decided to maintain his detention.

106. Paragraph 11, dealing with previous applications for bail, was unchanged. Paragraph 12, concerning
action taken since the last review, comprised two paragraphs. In the material before the court, the first of
these paragraphs was redacted. I shall call it [12.1]. The second paragraph, which I shall call paragraph

[12.2], noted that there had been liaison for HS's ETD to be issued. Section 13, the action plan for the next
review period, also comprised two paragraphs. In the material before the court the second of these
paragraphs was redacted. I shall call it [13.2]. As to the first, which I shall call paragraph [13.1], it stated:

[13.1] Address issues raised by [HS] regarding Temporary Admission

107. Paragraphs [14.1] to [14.4] of Mr Lartey's recommendation repeated the same paragraphs in his first
review recommendation (see section B4.5 above). The last paragraph of that recommendation, however,
was replaced by a new paragraph which, in the material before the court, contained a redacted passage
followed by a reference to a process for Detained Immigration Appeals (“DIA”):

[14.5] An ETD has been procured for [HS] as a result of his re-detention. [redacted passage] [HS's] appeal
can then be dealt with under the DIA process. I therefore propose that his detention should be maintained.

108. Assistant Director Hervey's comments were:

We need to serve the fresh decision asap if that is what the court agrees and then ask for the appeal to be
expedited. An ETD has been agreed so if the appeal, assuming one is lodged, goes in our favour then
removal could take place within a reasonable period of time. In the light of this and the risks highlighted
above I agree with the assessment and proposal. The presumption to liberty is outweighed by the risk of
absconding, re-offending and harm and detention should therefore be maintained for a further 28 days.

B5.2 Third progress report, 4 May 2017

109. Mr Lartey signed a third progress report on 4 May 2017. Sections [1] to [4] were unchanged from the
second progress report. In section [5], dealing with progress since the last review, paragraphs [5.1],
dealing with the judicial review and the acceptance that HS would be afforded an in-country right of appeal
was unchanged. The previous paragraphs [5.2] and [5.3], which complained of failure to cooperate with the
ETD process, were omitted. Paragraph [6] dealing with the FRS was unchanged. So was paragraph [7],
identifying likelihood of absconding and high risk of public harm as the reasons why HS would remain in
detention to affect his removal from the UK Paragraph [8] identifying factors on the basis of which the


-----

decision had been reached, was altered so that the previous paragraphs [8.1] and [8.2], complaining of
HS's conduct in relation to the ETD, were omitted. The remaining paragraphs in section [8], formerly [8.3]
to [8.7], now paragraphs [8.1] to [8.5], were unchanged. Paragraphs [9] to [11], dealing with factors in
favour of release, continued review of detention, and bail rights, were unchanged.

B5.3 Reply 4 May 2017 to 21 April release request

110. Also on 4 May 2017 Mr Lartey wrote to Dicksons in reply to the letter of 21 April 2017. Mr Lartey's
letter began by stating that the request in the letter of 21 April 2017 had been treated as a request for a
Temporary Release (“TR”). Among other reasons for rejecting that request, the letter of 4 May 2017 stated
at paragraphs 7 and 8:

7. It must be noted that your client has not provided a release address. Your client is under licence to
report to an Offender Manager and any address provided will have to be verified by Probation and the
Police as suitable.

8. Your client should note that the Home Office will not be accepting the address to which he was
previously granted bail. For his future TR or bail application, consideration [will] be given to any address he
submits.

111. In paragraph 9 of the letter dated 4 May 2017 Mr Lartey made an observation about HS's in-country
appeal. Apparently unaware of the filing of the appeal on 27 April 2017, Mr Lartey advised that the appeal
should not be submitted for the time being, apparently because HS had not received “the right appeal
documents”:

9. The Home Office accepts responsibility for your client's in-country right of appeal. We will endeavour to
forward you with the appropriate appeal documents in due course. We would advise that you do not submit
an appeal until you receive the right appeal documents.

112. In a further paragraph, Mr Lartey added:

[10] You are obliged to apply to the [FTT] Immigration and Asylum Chamber for bail where your client's
release will be considered by an immigration judge.

B5.4 Fourth progress report, 23 May 2017

113. On 23 May 2017 Mr Lartey signed a fourth progress report. This document appears to be identical to
the second progress report (see section B4.10 above). Thus it reinstated complaints about HS's conduct in
relation to the ETD which had been omitted in the third progress report (see section B5.2 above). The
reason for doing this is unclear. It may have been a mistake.

B5.5 Home Secretary/FTT exchange as to “correct decision letter”

114. After realising that HS's appeal had already been lodged the Home Office emailed the FTT asking it
to reject or strike out the appeal. The reason for this request was apparently because the Home Office
wished to serve HS with a “correct decision letter” and appeal documents. Although the email did not say
this, it seems likely that officials were planning to issue the “fresh decision” referred to by Assistant Director
Hervey on 28 April: see section B5.1 above. It also seems likely that the “fresh decision” was intended to
form part of the “appropriate appeal documents” referred to by Mr Lartey in paragraph 9 of the letter of 4
May 2017: see section B5.3 above.

115.  In directions given on 23 May 2017 the FTT said that if the Home Secretary wished to serve a new
decision then one possible course would be to withdraw the decision of 6 March 2017.

B5.6 HS applies for section 4 support, 24 May 2017

116. On 24 May 2017 HS made an application for support (“section 4 support”), including accommodation,
under section 4 of the Immigration and Asylum Act 1999 (“the 1999 Act”).

B5.7 Release address: Dicksons/PC Baker 10 to 24 May 2017


-----

117. Dicksons sent an email to PC Baker on 12 May 2017 asking why the Halesowen address was now
deemed unsuitable given that it had previously been approved. The email asserted that PC Baker had
visited HS when he resided there and that no concerns were raised.

118. PC Baker replied the same day stating, among other things:

The address was agreed by probation, however they were not in possession of all of the
information/intelligence around the address and your client.

After my home visit these issues were highlighted with probation and immigration and the address was
deemed unsuitable for bail.

Due to the sensitivity of this information I am unable to advise you in any more detail, however a statement
can be produced to the Judge that is allocated to the bail case if necessary.

Please let me know if there are any other addresses that your client can put forward.

119. On 15 May 2017 Dicksons emailed PC Baker with details of a proposed address in Erdington (“the
first Erdington address”). On 24 May PC Baker emailed Dicksons saying she was unable to approve the
first Erdington address. She added:

It is not specifically the address, however in connection with the current occupants

120. In response to a request for further information PC Baker sent a reply email later on 24 May 2017.
The reply email included the following:

Sorry I cannot disclose the history of the current occupants to you for obvious reasons, however address
checks have to include current occupants to both safeguard them and your client.

Although I cannot give specifics, general reasons for an address being turned down may be others with
similar convictions/allegations against them, persons that have been victim to sexual assaults, vulnerable
adults residing there or children being at the location.

Obviously not all of these apply to [the first Erdington address] and I cannot specifically state which one
does apply.

B6 Events from 26 May to 23 July 2017

B6.1 Third detention review, 26 May 2017

121. On 26 May 2017 Ms Luff (see section B2.2 above), acting as authorising officer, signed HS's third
detention review. Again, the review had been prepared by Mr Lartey. Sections 1 to 11 were unchanged
from the second detention review: see section B5.1. In section 12, dealing with action taken since the last
review, paragraph [12.1] continued to be a redacted paragraph. Paragraph [12.2] was unchanged from the
second detention review. New paragraphs [12.3] to [12.5] stated:

[12.3] TA application responded to.

[12.4] Liaising with Workflow Manager for [HS's] in-country decision to be considered in-house.

[12.5] Liaising with Appeals Section for [HS's] appeal to be struck out since [HS] has not submitted the
correct appeal form.

122. Section 13 consisted only of paragraph [13.1], which was a redacted paragraph.

123.  In the recommendation section of the review paragraphs [14.1] to [14.4], as before, repeated what
had been said in those paragraphs in the first detention review. Paragraph [14.5], subject to any change in
the redacted passage, repeated what had been said in that paragraph in the second detention review.
Thus Mr Lartey's recommendation seems to have contained nothing new. Ms Luff, as authorising officer,
set out comments (including a redacted passage) as follows:

[AOC.1] [redacted passage] [HS's] appeal can then be dealt with under the DIA process. An ETD has been
procured for [HS] as a result of his re-detention.


-----

[AOC.2] [HS] has been assessed as Level 2 as set out in the [AR] policy.

[AOC.3] Having reviewed the evidence before me, and having given due weight to [HS's] offence, I
consider the presumption to liberty is outweighed by the risks of reoffending, harm and absconding. I
hereby authorise [HS's] continued detention for a further 28 days.

B6.2 HS proposes the first Cobridge address, 1 June 2017

124. Dicksons wrote to Mr Lartey on 1 June 2017 in connection with a potential release address. Details
were given of an address in Cobridge Stoke-on-Trent (“the first Cobridge address”) along with information
about the landlord and about two tenants, a husband and wife whom I shall refer to as H and W.

B6.3 Fifth progress report 5 June 2017

125. Mr Lartey signed a fifth progress report on 5 June 2017. It appears in all material respects to be
identical to the third progress report (see section B5.2 above).

B6.4 Sixth progress report 20 June 2017

126. Mr Lartey signed a sixth progress report on 20 June 2017. It appears in all material respects to be
identical to the fifth progress report: see section B6.3 above.

B6.5 Report on the first Cobridge address, 21 June 2017

127. On 21 June 2017 PC Baker (see section B2.1 above) forwarded to Mr Lartey information that had
become available when PC Debra Marshall and a colleague from Staffordshire Police visited the first
Cobridge address (see section B6.2 above). It appeared that H was currently detained at Morton Hall IRC
with HS, and that W, who was living at the first Cobridge address, stated that she was not willing for HS to
stay for more than a few nights.

B6.6 Fourth detention review, 23 June 2017

128. A fourth detention review was signed by a Senior Executive Officer, Alex Lloyd, as authoring officer
on 23 June 2017. The review was again prepared by Mr Lartey. Sections 1 to 11 were unchanged from
the third detention review on 26 May 2017: see section B6.1 above. In section 12, action since the last
review, what had previously appeared was replaced by paragraphs [12.1] and [12.2] as follows:

[12.1] Liaising with Police to have his bail accommodation assessed for its suitability.

[12.2] Liaising with [HS's] representatives to provide a suitable bail address.

129. Section 13 of the fourth detention review again contained a single redacted paragraph [13.1]. The
recommendation section comprised paragraphs [14.1] to [14.5]. Subject to what may have been in the
redacted part of paragraph [14.5], these paragraphs were in identical terms to those in the
recommendation sections of the second and third detention reviews. The authorising officer's comments
were as follows:

[AOC.1] I agree with my colleague's recommendation that [HS] poses a serious risk of harm to the public
should he be released. Furthermore due to his immigration history it is also agreed that the risks of
absconding are of an unacceptable level. Therefore it is considered that the risks outweigh the
presumption of liberty in this case.

[AOC.2] It is considered that removal is achievable and there are clear steps to take to progress the case.
Given that any appeal can be expedited by DIA it is considered that the detention period is reasonable.
Therefore detention is authorised or a further 28 days.

[AOC.3] Actions: the asylum decision should be served ASAP.

B6.7 Mirtazapine increased to 45mg daily, 28 June 2017


-----

130. On 28 June 2017 HS saw Dr Sarah Fletcher at the Health Centre. Dr Fletcher increased HS's
mirtazapine dosage to 45 mg daily. In this regard Moreton Hall IRC electronic medical records describe
HS's presentation as:

Really struggling with low mood and anxiety … still having flashbacks, feeling down, not concentrating and
short-term memory loss. Has fleeting thoughts of self-harm but nothing planned

131. The reason for this increase is described further in a second Rule 35 report on 2 September 2017:
see section B8.4 below.

B6.8 Home Office default causes appeal adjournment, 11 July 2017

132.  On 11 July 2017 the FTT adjourned the hearing of HS's appeal, which had been fixed for 4 August
2017. In place of the scheduled hearing the FTT required the Home Secretary to attend on 4 August 2017
and explain the failure on part of the Home Secretary to serve the respondent's bundle for the hearing.

B6.9 Steps taken in relation to s 4 support, July 2017

133. Also on 11 July Mr Lartey was advised by other Home Office officials of HS's request, nearly seven
weeks earlier, for accommodation and other support under section 4 of the 1999 Act. Mr Lartey supplied
relevant information to those officials on 20 July 2017.

B6.10 Release address: developments 11 to 23 July 2017

134. In a further development on 11 July 2017, West Midlands Police emailed Dicksons and Mr Lartey
advising that HS had telephoned proposing a second Erdington address. In the absence of PC Baker on
annual leave the matter was dealt with by a colleague, who stated:

The address put forward was [next door to the first Erdington address]. [HS] previously had checks
completed on [the first Erdington address] and PC Baker was unable to approve it. Unfortunately the
reasons for its unsuitability remain at the neighbouring property and I have therefore had to advise [HS]
that the police are unable to agree to a move there. I have tried to give [HS] some guidance over the phone
on choosing suitable addresses and I am happy to check alternatives whilst PC Baker is on leave.

135. On 18 July 2017 Dicksons emailed PC Marshall of Staffordshire Police advising a second Cobridge
address proposed by HS.

B7 Events from 24 July to 24 August 2017

B7.1 Fifth detention review & seventh progress report, 24 July 2017

136.  HS's fifth detention review was signed by a Higher Executive Officer, Kailash Bhatt, as authorising
officer on 24 July 2017. Again the review was prepared by Mr Lartey. Sections 1 to 11 were unchanged
from the fourth detention review signed on 23 June 2017: see section B6.6 above. In section 12, dealing
with actions since the last review, paragraph [12.1], concerning liaison with the police for assessment of
bail accommodation suitability, was unchanged. In place of the former paragraph [12.2], new paragraphs

[12.2] and [12.3] appeared:

[12.2] Liaising with the section 4 team.

[12.3] Liaising with mental health team at Morton Hall IRC.

137. Section 13 again comprised a single paragraph. However in the fifth detention review it was not
redacted. As appearing in the fifth detention review, it stated:

[13.1] Liaising with the mental health team to allow for completion of the stage 3 decision.

138. The recommendation section comprised paragraphs [14.1] to [14.5]. Subject to what may have been
in the redacted part of paragraphs [14.5] these paragraphs were in identical terms to those in the
recommendation sections of the fourth detention review.

139 The authorising officer stated:


-----

[AOC.1] [HS] has committed a serious offence and sentenced to 16 months imprisonment. He was made
the subject of a DO and his appeal scheduled to be heard on 4 August 2017, an ETD has been agreed.
The only barrier to his removal is an outstanding appeal.

[AOC.2] [HS] has been assessed as level 2 as set out in the Adults at Risk policy.

[AOC.3] Having reviewed the evidence before me, and having given due weight to [HS's] offence, I
consider the presumption to liberty is outweighed by the risks of re-offending, harm, and absconding. I
hereby authorise [HS's] continued detention for a further 28 days.

140. Also on 24 July 2017 Mr Lartey signed a seventh progress report. It was in identical terms to the sixth
progress report dated 20 June 2017: see section B6.4 above.

B7.2 The 28 July asylum/ deportation letter

141.  On 28 July 2017 Mr Lartey sent HS a letter on form ICD.4996 (“the 28 July asylum/ deportation
letter”) on behalf of the Home Secretary. It withdrew the 6 March 2017 refusal of asylum, replacing it with a
new refusal set out in the letter. It also included a decision not to revoke his deportation order. The letter
advised that HS had an in-country right appeal.

B7.3 Pre-action correspondence, 2 to 17 August 2017

142.  On 2 August 2017 Bhatt Murphy sent the Home Secretary a pre-action protocol letter alleging three
grounds for judicial review. The first was breach of the AR policy, the second was breach of public law
principles, and the third was “a litany of public law errors” in the reasons given for detention. The public law
principles relied on for the second breach were said to concern detention when removal cannot be affected
within a reasonable time, when a reasonable period for detention had been exceeded, and when there had
been a lack of diligence by the Home Secretary. The letter required the Home Secretary to provide
accommodation and support under section 4 of the 1999 Act and to release HS on bail.

143. Mr Lartey sent a pre-action reply to Bhatt Murphy on 15 August 2017. The reply included 25 subparagraphs rejecting assertions in Bhatt Murphy's 2 August letter. Among other things the reply stressed
that if there was information about the unsuitability of the address HS provided for bail release it was the
duty of the Home Office to re-detain him due to risk of harm to the public.

144. Bhatt Murphy sent Mr Lartey a letter dated 17 August 2017 rejecting the pre-action reply. Among
other things, the letter of 17 August 2017 asserted that following the February 2017 FTT bail decision HS
could only be detained if there were reasonable grounds to believe that he was likely to break, or had
broken, any condition of bail.

B7.4 Sixth detention review & 8th progress report, 21 August 2017

145. On 21 August a sixth detention review was signed by a Higher Executive Officer, J Turner, acting as
authorising officer. Again the review was prepared by Mr Lartey. In section 1, dealing with immigration
history, paragraphs [1.1] to [1.8] were unchanged from the fifth detention review of 24 July 2017: see
section B7.1 above. However a new paragraph [1.9] was added. Part of this new paragraph was redacted.
The part that was not redacted made reference to the 28 July asylum/ deportation letter:

[1.9] on 28 July 2017, [HS] was served with a deportation decision ICD.4996 …

146. Sections 2 and 3 were unchanged. Section 4, dealing with deportation casework status, included an
additional sentence. Part of the sentence was redacted in the material before the court. The part that was
not redacted noted that the decision of 6 March 2017 was withdrawn and a new decision was served on
HS on 28 July 2017. Section 5, dealing with medical conditions and section 6, dealing with current barriers
to removal were unchanged. So were sections 7 to 11. The action since the last review, set out in bullet
points in section 12, no longer listed liaising with the mental health team at Morton Hall IRC. In its place,
reference was made to having addressed the pre-action protocol letter of 2 August 2017, and to having
served HS with a deportation decision. In section 13 paragraph [13.1] was changed to read as follows:

[13 1] M it hi i t h i hi h i h d l d f 7 S t b 2017


-----

147.  Mr Lartey's recommendation at paragraphs [14.1] to [14.4] was in identical terms to what was said in
those paragraphs in all previous detention reviews. Paragraphs [14.5] and [14.6] stated:

[14.5] An ETD has been procured for [HS] as a result of his re-detention. [HS] has been served with a new
decision affording him an in-country right of appeal. His case management hearing has been scheduled for
7 September 2017.

[14.6] I therefore propose that his detention should be maintained.

148. The authorising officer's comments were:

[AOC.1] [HS] has committed the offence of sexual activity with a female child under 16. He has been
served with a deportation decision and signed deportation order. His case management review is due to be
heard on 7 September 2017. Should his appeal be dismissed and he becomes appeal rights exhausted
then we have an approved ETD to be able to set removal directions within a reasonable timescale.

[AOC.2] Having reviewed the above evidence and the seriousness of [HS's] offence I consider the
presumption to liberty to is outweighed by the risks of re-offending, harm and absconding. I therefore
authorise [HS's] continued detention for a further 28 days.

149. Also on 21 August 2017 Mr Lartey signed an eighth progress report. Sections [1] and [2] were
unchanged from the seventh progress report dated 24 July 2017: see section B7.1 above. In section [3],
dealing with immigration history, new paragraphs were added noting the 28 July asylum/deportation letter
and the 2 August pre-action protocol letter. Section [4], as to current barrier to removal, was unchanged.
Section [5], dealing with progress since last review, made reference to the pre-action protocol response
letter of 15 August 2017. Sections [6] to [11] were unchanged.

B7.5 Release address: developments 24 July to 25 August 2017

150. PC Marshall sent an email to Dickinsons on 24 July concerning the second Cobridge address (see
section B6.10 above). The email included the following:

I have been out and visited [the second Cobridge address] and have spoken to the occupant … [He] lives
at the address alone and the property itself would be suitable for [HS] to live at and does not raise any
safeguarding concerns itself. However, I do have concerns regarding the location of the property and the
suitability of [HS] residing there. [The second Cobridge address] is located opposite Cobrdige park which is
a location that is frequented by children, in particular teenagers who are often there unsupervised. I have
considered the specifics of [HS's] sexual conviction and therefore I would not support [HS] residing at that
address.

151. Two further release addresses were then proposed, one in Tunstall, Stoke-on-Trent and the other in
Surrey. As regards the Tunstall address PC Marshall emailed Dicksons on 6 August 2017:

I have been out to visit [the Tunstall address] earlier today and have spoken to two of the three occupants.
There is no spare room for [HS] to stay in, however there is a suggestion that someone may be moving out
soon. The property is a business premises with flats above. I do have concerns regarding the location of
the property as its directly opposite Tunstall children's centre. I would not be able to approve this property
as a suitable location for [HS] to move to given that he is someone who is considered to pose a risk to
children.

152. As regards the Surrey address, PC Baker emailed Dicksons on 10 August 2017, advising that Surrey
Police had been informed that the room there was no longer available.

153. On 21 August 2017, an address in London Road, Stoke-on-Trent was proposed.

B8 Events from 25 August to 19 September 2017

B8.1 Lodging of claim, & order of Nicola Davies J, 25 August 2017

154. HS's claim form was lodged on 25 August 2017. It was accompanied by an application for urgent
consideration This application was dealt with by Mrs Justice Nicola Davies on the papers In her order


-----

dated 25 August 2017 she dealt not only with anonymity (see section A1 above), but also gave directions
for the Home Secretary to provide a written response by 31 August 2017 and for the papers to put before a
judge no later than 1 September 2017.

155. In a letter to the court dated 31 August 2017 the Home Secretary stated that HS's detention would be
reviewed, as a matter of urgency, by a detention review panel. In the meantime a copy of the sixth
detention review dated 21 August 2017 was supplied.

B8.2 Order of May J, 1 September 2017

156. On 1 September 2017 Mrs Justice May made the order referred to in section A1 above after
consideration of the matter on the papers. In addition to confirming anonymity, the order granted HS
permission to proceed, and directed an expedited hearing on 19 September 2017.

B8.3 Second Rule 35 report, 2 September 2017

157. On 2 September 2017 HS was seen again by Dr Fletcher, on this occasion for the purposes of a
second rule 35 report. As noted in section B6.7 above, the second Rule 35 report included further
information concerning the 28 June 2017 decision to increase HS's daily dose of mirtazapine to 45mg.
Section 5 of the second Rule 35 report stated:

I can confirm his mirtazapine was increased to 45mg on 28th June 2018 because of ongoing anxiety, low
mood, insomnia, short term memory loss, poor concertation and flashbacks. He had also been
experiencing fleeting thoughts of self-harm. He had limited response to 30mg despite taking it daily.

158. The second Rule 35 report did not attempt to revisit the first Rule 35 report. It was confined to the
provision of additional information. Other additional information provided in the second Rule 35 report was
in section 6, as to the impact of detention on HS:

[HS] reports that detention is exacerbating all of his mental health symptoms … particularly the anxiety,
memory loss and feelings of vulnerability. He also becomes extremely stressed and anxious when he sees
any uniformed staff as this brings back memories and flashbacks of the torture he sustained.

B8.4 Response to second rule 35 report, 7 September 2017

159. On 7 September 2017 a letter from a Home Office official was sent to HS. It said the second Rule 35
report had been considered. Among other things, it recorded what had been said in the second Rule 35
report and accepted that this met Level 2. As regards HS's suitability for detention under the AR policy, the
letter adopted a similar structure to that in the Home Secretary's response to the first Rule 35 report (see
section B4.8 above). When dealing with HS's immigration history, the second response in what I shall call
paragraph [17] repeated something which had been said in the first response:

[17] On 29 March 2017, you lodged an application for a judicial review. We have been advised that this is
being expedited, and a decision is expected in the near future. If the application is refused, there will be no
barriers to your removal.

160. In the section headed “Balancing risk factors against immigration control factors” the second
response at paragraphs [20] to [22] repeated what had been said in paragraphs [18] to [20] in the first
response. Paragraph [23] of the second response similarly repeated what had been said in paragraph [21]
of the first response, replacing the words “the Doctor” with “the doctors”. Paragraph 24 of the second
response stated:

[24] The only barrier to your removal is your outstanding appeal against the decision to deport you.

161. Under the heading “Conclusion” the second response stated in paragraph [25]:

[25] It is acknowledged that you are an Adult at Risk but it is considered that your removal can be enforced
within a 3-5 month period.

162. This was then followed by a paragraph [26] in identical terms to paragraph [24] of the first response.


-----

B8.5 London Road release address rejected, 12 September 2017

163. On 12 September 2017 PC Baker sent an email to HS and Dicksons saying that the London Road
address (see section B7.5 above) had been visited the previous day by Staffordshire Police. Her email
continued:

They have turned down the address as it is next to a massage parlour which may increase the risk you
pose and the risk posed to you.

Please forward any other addresses that you need to be looked at.

B8.6 Seventh detention review, 13 September 2017

164. On 13 September a seventh detention review was signed by an Acting Assistant Director, A Cockell,
acting as authorising officer. Again the review was prepared by Mr Lartey. Section 1 repeated what had
appeared in section 1 of the sixth detention review, adding paragraphs dealing with the FTT bail, the
intelligence received on 15 February 2017, the 25 August 2017 papers, and in relation to HS's appeal
proceedings, a decision on 7 September 2017 that the matter should proceed to a full hearing that was yet
to be listed.

165. Sections 2, 3 and 4, as set out in the material presented to the court, do not appear to have
contained any material change. Section 5, dealing with medical conditions, referred to the second Rule 35
report and the second Rule 35 response.

166. In section 7 the previous assessment of risk of absconding as high was replaced by an assessment
of medium risk as follows:

[7.1] Medium – [HS] has no valid leave to remain in the UK; he knows our intention is to deport him,
therefore, the risk of absconding is always there. Whilst it is accepted that [HS] conformed to bail
conditions when granted FTT bail on 8 February 2017, however, it must be noted that he failed to
regularise his stay in the UK when his leave to remain in the UK expired on 27 September 2012. It is
considered likely [HS] would not have bought himself to the attention of the Home Office if not for the crime
for which he was convicted on 5 October 2015.

167. In section 8 the assessment of risk of reoffending remained at “medium”. The previous reasons for
that assessment, however, were replaced by the following:

[8.1] Medium – Whilst [HS] has not been convicted of a crime of overstaying his leave to remain in the UK
and subsequent offending by working in breach of not having a permit to do, he has flouted the laws of the
UK. [HS] was convicted of a serious offence of _sexual activity with a female child U.16 – offender 18 or_
_over – penetration of anus/ vagina/ mouth by penis/ part of body. He was also made the subject of the Sex_
Offender's register for 10 years. He was assessed by Probation Service to be a category 1, level 1
offender. To prevent him [HS] from further committing such an offence the immigration judge stated as
follows; you will go onto the Sex Offender's register and your case will be considered and dealt with by the
_barring board in the usual way ... Your name will go onto the Sex Offender's register for a period of ten_
_years …”_

[8.2] [HS's] OASys report (paragraph 11.6) identifies him as presenting an on-going risk of harm to
children.

168. In section 9 the assessment of risk of harm to the public, previously described as “very high” was
replaced with the following:

[9.1] High – [HS] was convicted of sexual activity with a female child U.16 – offender 18 or over –
penetration of anus/ vagina/ mouth by penis/ part of body. Therefore, the risk to the public is very high,
especially to females under the age of 16. He was ordered to be on the _Sex Offender's Register for a_
_period of ten years …”. The reason why a judge places an offender on the sex register is to protect the_
public from harm.


-----

[9.2] [HS] has been assessed such that he is subject to the minimum level of Multi-Agency Public
Protection Arrangements (MAPPA level 1), the purpose of which is the protection of the public. The fact
that he is appropriate to be monitored under risk management strategies is an indication that he is
considered to pose a continuing risk to the public with the requirement to abide by certain other restrictions.

[9.3] In addition, his OASys (para 10.4) shows that lack of responsibility and lack of motivation to address
underlying issues relating to offending may increase the level risk. Furthermore, paragraph 10.5 of his
OASys report states that targeted intervention including participation on the sex offender treatment
programme as factors, action and events, may reduce or contain the level of his risk. However, [HS] has
not provided any evidence to show that he has been rehabilitated. The mere fact that he has served his
custodial sentence is not evidence that he has rehabilitated himself.

169. Section 10, concerned with the AR policy, supplemented what had been said previously by referring
to the second Rule 35 response, and to the definition of “torture” adopted by the Home Secretary. Section
11, dealing with previous applications for bail or temporary release repeated what had been said before,
adding a reference to the urgent relief sought on 25 August 2017. Section 12, concerned with action taken
since the previous review, consisted of a single paragraph which was redacted in the material before the
court. Section 13, listing action to be taken, included a proposal to request “to expedite the appeal date
once listed”.

170. Mr Lartey's recommendation at paragraphs [14.1] to [14.4] was in identical terms to what was said in
those paragraphs in all previous detention reviews. In the remaining two paragraphs, Mr Lartey stated:

[14.5] An ETD has been procured for [HS] as a result of his re-detention. [HS] has been served with a new
decision affording him an in-country right of appeal. His case management review was heard on 7
September 2017. His appeal is yet to be listed and a hearing date expected within a month. In the absence
of a hearing date it is not possible to give a timeframe on when the appeal will be concluded.

[14.6] I therefore propose that that his detention should be maintained pending a hearing date.

171. The authorising officer's comments comprised three paragraphs. Paragraph [AOC.1] was redacted in
the material before the court. Paragraphs [AOC.2 and [AOC.3] stated:

[AOC.2] So, attending to the matter of on-going detention – I did not make that decision, but having
reviewed the facts, I consider that detention was, at that time, appropriate and continues to be so. [HS] had
been released by an immigration judge who was well aware of [HS's] offending. At the time of the bail
hearing the address by [HS] was considered to be suitable for his release and management on Criminal
Justice Licence. However, we subsequently learned that the police had information indicating that the
address in question was frequented by other, convicted paedophiles and they so advised the Home Office.
The judge who released on bail may well have had an opinion themselves as to this information and its
effect on continuing bail. Certainly, the information indicates a substantial change in circumstances over
and above the point where bail was granted and does, in my view, indicate an enhanced risk to the public
should [HS] continue to reside there. In any event, it is now considered that the original bail granted by the
judge had ended on [HS] answering to an IO when he first reported or certainly when he was subsequently
detained by the S of S, which was for the purposes of being interviewed to advance our documentation
prospects (he has now been documented for removal) and due to the enhanced risk that had become
apparent since bail had been given. Although we are as yet some way off removal, due to the pending
appeal, I consider that he will be removed promptly once the appeal is determined as he is documented for
removal (subject, of course, to the appeal outcome).

[AOC.3] I also consider that given the serious nature of his sexual offending and his offender manager's
assessment that he remains a risk of harm to underage women, that there is great weight in favour of
detention pending his remove to protect a specified section of the public. I note also that his licence has
expired and thus that risk mitigation factor is no longer available to the community. As to the risk that he
would abscond, I consider that risk remains; his solicitors have written to GLD indicating his intention to
comply with conditions including tagging but that does not outweigh the fact that he has shown himself
willing to remain here without leave, to offend whilst here without leave and has made it perfectly clear that


-----

he does not wish to return home. That creates considerable doubt in my mind that he would comply with
any form of immigration restrictions and a real risk that he would, if released, feign compliance until it suits
his purposes to avoid removal, at which point he would likely abscond. I authorise detention for a further
period in order to prevent further offending and to ensure he remains in contact in order to realise his
removal post appeal. I consider that the presumption to release is outweighed and that there is a realistic
prospect for removal within a period that will be reasonable in all the circumstances.

B8.7 Order of Ms Leigh-Ann Mulcahy QC, 19 September 2017

172. The hearing directed by Mrs Justice May took place on 19 September 2017 before Ms Leigh-Ann
Mulcahy QC, sitting as a deputy High Court judge. Her order that day directed, among other things, that HS
be released from immigration detention no later than 2pm on 21 September 2017 (paragraph 7).
Paragraph 8 set out terms which included that HS was to live and sleep at a specified address. This
address had been put forward by HS and agreed by the Home Secretary at the hearing on 19 September
2017.

C. JR ground 1: abuse of power

C1 JR ground 1: background

C1.1 HS's stance in the original ground 1

173. Ground 1 was reformulated in an amended statement of facts and grounds on 7 December 2018.
HS's stance in the original ground 1 was that throughout the period from 13 February to 6 March 2017 he
was still subject to the bail terms ordered by the FTT, with the consequence that the Home Secretary could
[not vary those terms. This stance accorded with the view taken by Collins J in R (Lucas) v SSHD [2016]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KB5-3NW1-F0JY-C09P-00000-00&context=1519360)
_[EWHC 1960 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KB5-3NW1-F0JY-C09P-00000-00&context=1519360)_

C1.2 Court of Appeal decision in Lucas

174. On 16 November 2018 Collins J's decision in _Lucas_ was reversed by the Court of Appeal in the
decision cited in section A2 above. It is now common ground, in accordance with the Court of Appeal's
judgment, that the bail granted by the FTT on 8 February 2017 ceased to have effect when HS
surrendered bail on 13 February 2017. It is also common ground that at the time of that surrender HS was
a person detained under paragraph 2(3) of Schedule 3. Accordingly, paragraph 22 of Schedule 2 gave
power for the grant of FTT bail and CIO bail: see section A2 above. It is similarly common ground that, in
accordance with the Court of Appeal's decision, the conditional bail applying to HS during the period 13
February to 6 March 2017 was CIO bail.

175. It is in this context that the current ground 1 falls to be considered.

C2 Current ground 1: an extended obligation

C2.1 The extended honour obligation

176. HS's current ground 1 relies on a proposition of law which I shall call “the extended honour
obligation”. This proposition of law can be set out by quoting paragraph 58 of the amended statement of
facts and grounds, inserting a word which I have placed in italics, and omitting words which I have placed
in square brackets:

58. It is an abuse of power for the Defendant to re-detain a person who has been granted bail without there
being _objectively [(and without the Defendant identifying)] some clear and significant change of_
circumstance which justifies this. It is implicit in the statutory scheme of immigration detention, and in any
case a necessary implication in a scheme which permits deprivation of liberty, that the Secretary of State
cannot take a decision to re-detain in a way which does not honour the decision of the FTT (or another
court or tribunal) to grant bail.


-----

177. I have inserted the word “objectively” because HS contends that on judicial review of a CIO bail
refusal it is for the court, not the Home Secretary, to decide whether there has been a clear and significant
change of circumstances justifying detention.

178. I have placed the words “(and without the Defendant identifying)” in square brackets because they
add to the extended honour obligation. They would only call for consideration if the extended honour
obligation is a sound proposition of law.

C2.2 Ground 1: what is not in dispute

179. There is no dispute that the Home Secretary must, unless there is a stay pending appeal, honour an
FTT grant of bail by complying with its terms. Nor is it disputed that, subject to any discretionary or
statutory bar, a later decision to detain can be successfully challenged by judicial review if it goes beyond
the bounds of reasonableness in all the circumstances including the FTT decision.

C2.3 Nature of the extended honour obligation

180. I have referred to ground 1 as involving an “extended” honour obligation because it would not merely
require the Home Secretary to do what the FTT has ordered. It asserts that after the FTT order has
expired, when later exercising statutory powers of detention, an extended obligation arises in the sense
that the Home Secretary will have no power in law to detain unless there is a clear and significant change
of circumstance which objectively justifies this.

181. Submissions for the Home Secretary emphatically disputed the existence of any extended obligation
of the kind which ground 1 asserts. They nevertheless accepted that departure from the FTT decision
would have to be justified and could be susceptible to judicial review: see section C2.2 above.

182. In argument the parties cited a number of judgments in previous cases. Sections C3 to C7 below set
out or summarise passages from judgments whose meaning or implications were in contest, along with
relevant submissions and my observations on them. My overall analysis of the arguments, and their
consequences in the present case, is set out in section C8 below. Before turning to those sections,
however, I set out in section C2.4 below passages from judgments in a decision which was said by HS to
have general significance as to the importance of the court making objective findings in cases concerning
the liberty of the individual.

C2.4 The court's jailor control role: A (Somalia)

183. R (A) v Secretary of State for the Home Department [2007] EWCA Civ 804 involved an examination
by the Court of Appeal (Toulson, Longmore and Keene LJJ) of principles of substantive law applicable to
immigration detention. I shall refer to it as A (Somalia).

184. In the decision under appeal A sought judicial review of detention under paragraph 2(3) of Schedule
3 which began in September 2003 and was continuing throughout 2006. Calvert-Smith J applied a wellestablished principle that the power of detention in paragraph 2(3) of Schedule 3 may be exercised only
during such period as is reasonably necessary for that purpose. It is one of the principles invoked by HS in
the present case: see section D below. Applying that principle Calvert-Smith J held that a period of 15
months' detention, from 3 September 2003 to 3 December 2004, was lawful because it was reasonably
necessary to detain A while attempts were made to obtain travel documentation to enable him to be
returned to Somalia. A second period from 4 December 2004 to 20 July 2006 (“the middle period”) was
held to be unlawful because there was no carrier willing to take “enforced returns” to Somalia. From 21 July
onwards, however, detention was held to be lawful again once an agreement with a carrier had been made
for such returns.

185. On appeal by the Home Secretary Calvert-Smith J's decision was reversed. Put shortly, the Court of
Appeal concluded that risks of absconding and offending were so great that A's detention in the middle
period was reasonably necessary for the purposes of the deportation order. That being so it was not
necessary to deal with an argument for the Home Secretary that, rather than the court deciding what was
reasonably necessary, the court was limited to reviewing the reasonableness of the Home Secretary's


-----

decision to exercise the power of detention during the period in question. Nonetheless important
observations were made concerning that argument. One of the judgments referred to in those observations
was the advice of the Privy Council in Tan Te Lam v Superintendent of Tai A Chau Detention Centre [1997]
AC 97(“Tan Te Lam”).

186. Toulson LJ, with whom Longmore LJ agreed, said at paragraph 62 of his judgment:

… Where the court is concerned with the legality of administrative detention, I do not consider that the
scope of its responsibility should be determined by or involve subtle distinctions. It must be for the court to
determine the legal boundaries of administrative detention. There may be incidental questions of fact which
the court may recognise that the Home Secretary is better placed to decide than itself, and the court will no
doubt take such account of the Home Secretary's views as may seem proper. Ultimately, however, it must
be for the court to decide what is the scope of the power of detention and whether it was lawfully exercised,
those two questions being often inextricably interlinked. In my judgment, that is the responsibility of the
court at common law and does not depend on the Human Rights Act (although Human Rights Act
jurisprudence would tend in the same direction).

187. Keene LJ said at paragraphs 70 to 75:

70. … the principal issue … concerns the exercise of the power [of detention during the middle period] and
in particular whether the detention was for a reasonable period of time. There is also another issue,
logically arising at an earlier stage, as to whether it is for the court or for the Secretary of State to
determine whether the detention was for a reasonable period and therefore lawful. It has been submitted
on behalf of the Secretary of State that the role of the court is simply to review his exercise of power on the
usual principles applicable in judicial review, albeit that the court's scrutiny would be more intensive than
usual. Mr Giffin Q.C. has contended that the court should not itself determine whether the period of
detention exceeded that which was reasonable in the circumstances, but rather should ask whether it was
open to the Secretary of State to regard detention as appropriate in the circumstances. It is accepted that
Article 5 of the European Convention on Human Rights is engaged in such a case, but it is said that Article
5(1)(f) allows for the lawful detention of a person against whom action is being taken with a view to
deportation, and that that particular provision does not involve considerations of proportionality.

71. It is to my mind a remarkable proposition that the courts should have only a limited role where the
liberty of the individual is being curtailed by administrative detention. Classically the courts of this country
have intervened by means of habeas corpus and other remedies to ensure that the detention of a person is
lawful, and where such detention is only lawful when it endures for a reasonable period, it must be for the
court itself to determine whether such a reasonable period has been exceeded. That has been the
approach adopted in practice in the domestic cases to which we have been referred …

72. The Privy Council seems to have adopted a similar approach in _Tan Te Lam, finding that the facts_
which had to be found for the power to detain to exist were jurisdictional facts and hence for the court to
determine. Mr Giffin has pointed out that the decision went to the existence of the power rather than to its
exercise, which is true, but the reasoning in that decision seems to be of broader significance. As was said
by Lord Browne-Wilkinson, giving the judgment, at page 114 B–C:

“If a jailor could justify the detention of his prisoner by saying 'in my view, the facts necessary to justify the
detention exist' the fundamental protection afforded by a _habeas corpus would be severely limited. The_
court should be astute to ensure that the protection afforded to human liberty by habeas corpus should not
be eroded save by the clearest words.”

If the Secretary of State were to be entitled to determine what weight should be attached to, say, the risk of
the detainee absconding if released, as compared to the weight to be attached to other factors, and so to
decide whether the length of detention was reasonable, with the court only intervening if his decision was
not one properly open to him, the erosion of the protection of human liberty referred to by Lord BrowneWilkinson would be very substantial indeed.

73. The Privy Council in _Tan Te Lam was expressing itself in terms of jurisdictional fact, one of the_
accepted bases for a court having the power in public law cases to determine facts in pre-Human Rights


-----

Act days. But the situation has changed with the coming into force of that statute. A court of law is a “public
authority” within the meaning of s 6 of the Human Rights Act, 1998, as s (3)(a) expressly states. It is
therefore unlawful for it to act

“in a way which is incompatible with a Convention right.” Section 6(1)

74. It was this provision which led the _House of Lords in Huang v. Secretary of State for the Home_
_Department [2007] UKHL 11; [2007] 2 WLR 581to conclude that on a statutory appeal to the appellate_
immigration authorities the task of those authorities was to make its own decision as to whether a refusal of
leave to enter or remain in this country was compatible or not with a Convention right and thus lawful or
unlawful. Its task was not that of secondary review of another's decision. In the present case we are not, it
is true, concerned with a statutory appeal. Nonetheless, this court is still required by s 6(1) to decide
whether or not the detention of this individual is compatible or not with his rights under Article 5, because
only by so doing can the court ensure that it is acting lawfully. It cannot do that merely by asking whether it
was open to the Home Secretary to decide that the length of detention was reasonable, as opposed to
whether it was actually reasonable in the eyes of the court. The Strasbourg jurisprudence indicates that it is
not enough that detention is lawful under domestic law, though that is a requirement for compliance with
Article 5. To comply with Article 5 it must also be proportionate. As Lord Hope of Craighead put it in R v.
_Governor of Brockhill Prison, ex parte Evans (No.2) [2001] 2 AC 19 at 38E:_

“The third question is whether, again assuming that the detention is lawful under domestic law, it is
nevertheless open to criticism on the ground that it is arbitrary because, for example, it was resorted to in
bad faith or was not proportionate: _Engel v The Netherlands (No 1) (1976) 1 EHRR 647, para 58 and_
_Tsirlis and Kouloumpas v Greece (1997) 25 EHRR 198, para 56.”_

75. That principle applies to Article 5(1)(f) as it does to the other provisions of that Article. If the detention
is not proportionate, it is in breach of Article 5, and it must be for the court to decide whether or not there is
such a breach, as s 6(1) requires. Of course, the court will in most cases attach considerable weight to any
assessment emanating from a government department about the progress of negotiations with foreign
governments or with airlines about securing the return of deportees. But the ultimate decision is, in my
judgment, for the court. I therefore would reject the Secretary of State's submission as to the limited role of
the court in cases such as this.

188. Submissions for HS stressed what was said by Keene LJ about Lord Browne-Wilkinson's
observations in Tan Te Lam. If the court is to be able to control the jailor it must have power, in public law
cases, to determine facts. Such a power arose at common law where jurisdictional questions were in issue,
and when deciding questions of proportionality under the Human Rights Act. In cases where public law
powers are used to detain an individual there would, HS submitted, be nothing surprising about the court
having a responsibility of objectively assessing the circumstances.

189. The court's jailor control role has a central place in the common law. An important part of that role is
exercised in claims for judicial review. If there is no other convenient and effective remedy (a point to which
I shall return in section C8.4 below) then on ordinary public law principles a decision to detain, or a refusal
of CIO bail can be challenged by judicial review under one or more of three heads: for failure to comply
with the substantive law as determined by the court, for going beyond the bounds of reasonableness, and
for failure to comply with procedural law as determined by the court. In immigration detention cases, for the
reasons given by Toulson and Keene LJ, the Home Secretary, as part of the substantive law, must show
objectively that detention complies with four principles identified in section D below. The question on
judicial review ground 1 is whether, as regards a decision to detain, or refusal of CIO bail after FTT bail has
expired, substantive or procedural law requires the court to decide objectively whether there has been a
change of circumstances sufficient to warrant taking a different course from that taken by the FTT. HS
submits that such a requirement is vital to fulfil the court's jailor control role and to ensure the rule of law.
The Home Secretary responds that a decision to detain, or CIO bail refusal can be challenged if it goes
beyond the bounds of reasonableness in the circumstances, including the earlier FTT grant of bail. That
being the case, the Home Secretary submits that immigration bail is not of such a nature as calls for


-----

objective inquiry by the court as to what has happened between an FTT grant of bail and a decision to
detain, or a CIO refusal of bail once the FTT bail has expired.

C3 Supreme Court decision in Evans v Attorney General

C3.1 Evans: HS's reliance on Lord Neuberger's principles

190. HS asserted that the extended honour obligation followed from two constitutional principles set out in
_R (Evans) v AG [2015] UKSC 21, [2015] AC 1787, by Lord Neuberger PSC in paragraph 52 of his_
judgment:

52 First, subject to being overruled by a higher court or (given Parliamentary supremacy) a statute, it is a
basic principle that a decision of a court is binding as between the parties, and cannot be ignored or set
aside by anyone, including (indeed it may fairly be said, least of all) the executive. Secondly, it is also
fundamental to the rule of law that decisions and actions of the executive are, subject to necessary well
established exceptions (such as declarations of war), and jealously scrutinised statutory exceptions,
reviewable by the court at the suit of an interested citizen. …

191. I shall refer to these constitutional principles as “the binding judicial decisions principle” and “the
executive reviewability principle”. They are at the heart of the rule of law. The Home Secretary does not
dispute them. Nor does the Home Secretary dispute their importance.

192. Before discussing these two principles it is necessary to say more about Evans. The background can
conveniently be set out by quoting paragraphs 1 to 3 of Lord Dyson MR's judgment in the Court of Appeal

_[2014] EWCA Civ 254, [2014] QB 855:_

[1 Mr Evans is a journalist employed by The Guardian newspaper. He sought disclosure under the Freedom](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4H0-TWPY-Y1K2-00000-00&context=1519360)
_[of Information Act 2000 (“FOIA”) and the Environmental Information Regulations (“EIR”) of a number of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4H0-TWPY-Y1K2-00000-00&context=1519360)_
written communications which passed between The Prince of Wales and various Government Departments
during the period between 1 September 2004 and 1 April 2005. The Departments refused disclosure and
their decisions were upheld by the Information Commissioner (“the Commissioner”). Mr Evans appealed to
the First-Tier Tribunal against the ruling of the Commissioner. The appeals were transferred to the Upper
Tribunal (“UT”) with the agreement of the parties pursuant to regulation 19 of the Tribunal Procedure (FirstTier Tribunal) (General Regulatory Chamber) Rules 2009.

2 By a decision dated 18 September 2012, after a hearing at which factual and expert evidence was
considered, and after examining the communications themselves in closed session, the UT (Walker J,
Upper Tribunal Judge Angel and Ms Suzanne Cosgrave) ruled that the communications should be
disclosed to the extent that they fell into a category which the UT defined as “advocacy correspondence”.

3 The Departments did not seek permission to appeal against this decision. Instead, on 16 October 2012
the Attorney General (as an “accountable person” within the meaning of section 53(8) of the FOIA) issued
a certificate pursuant to section 53(2) which purported to override the decision of the UT and render it
ineffective on the basis that, in his opinion, there was no failure on the part of the Government
Departments to comply with section 1(1)(b) of the FOIA and regulation 5(1) of the EIR.

193. Mr Evans's claim for judicial review of the Attorney General's certificate failed in the Divisional Court.
The certificate was quashed, however, in the Court of Appeal on the grounds that an accountable person
could not issue a s.53(2) certificate merely because that person disagreed with the tribunal's decision.
Something more was required, such as a material change of circumstances.

194. The Supreme Court by a majority upheld the outcome in the Court of Appeal. The minority, Lords
Wilson and Hughes JJSC, considered that section 53 enabled the Attorney General to disagree as to the
weight to be attached to competing public interests found by the tribunal, and that the certificate had done
this by properly explained and solid reasons.

195. Lord Neuberger PSC, with whom Lords Kerr and Reed JJSC agreed, approached the matter in the
light of the two principles set out above. He held that if section 53 were to entitle a member of the executive
to overrule a decision of the judiciary simply because on consideration of the same facts and arguments


-----

the member of the executive does not like it, that meaning would have to be crystal clear from the wording
of the Act. Section 53, however, fell short of being crystal clear, and could fairly be given a narrow range of
potential application, such as where there is a material change of circumstances since the judicial decision.
Given the detailed investigative processes by which a judicial decision is reached, the accountable
person's grounds would not be “reasonable” within the meaning of section 53 where, as here, those
grounds simply involved disagreeing with the conclusions of a court or judicial tribunal on the same
material as was before the court or tribunal.

196. Lord Mance JSC, with whom Baroness Hale DPSC agreed, accepted that section 53 enabled the
Attorney General to disagree as to the weight to be attached to competing public interests found by the
tribunal. However he considered that under section 53 disagreement with findings of fact or rulings of law
in a fully reasoned decision would require the clearest possible justification. That being so, the appeal fell
to be dismissed because the Attorney General's certificate had not engaged with or given any real answer
to the closely reasoned decision of the Upper Tribunal but proceeded on the basis of findings which
differed radically from those made by the tribunal without any adequate explanation.

197. Returning to Lord Neuberger's judgment, it included paragraphs 53 and 59:

53 In _M v Home Office [1994] 1 AC 377, 395, Lord Templeman in characteristically colourful language_
criticised “the proposition that the executive obey the law as a matter of grace and not as a matter of
necessity [as] a proposition which would reverse the result of the Civil War”. The proposition that a member
of the executive can actually overrule a decision of the judiciary because he does not agree with that
decision is equally remarkable, even if one allows for the fact that the executive's overruling can be
judicially reviewed. Indeed, the notion of judicial review in such circumstances is a little quaint, as it can be
said with some force that the rule of law would require a judge, almost as a matter of course, to quash the
executive decision.

…

59 All this militates very strongly in favour of the view that where, as here, a court has conducted a full
open hearing into the question of whether, in the light of certain facts and competing arguments, the public
interest favours disclosure of certain information and has concluded for reasons given in a judgment that it
does, section 53 cannot be invoked effectively to overrule that judgment merely because a member of the
executive, considering the same facts and arguments, takes a different view.

C3.2 Evans: the executive reviewability principle

198.  I can deal at once with the executive reviewability principle. I noted in section C2.4 above that on
ordinary public law principles a decision to detain, or a refusal of CIO bail, including a decision after an FTT
grant of bail has expired, can be challenged by judicial review. Nothing in the present case puts that in
issue. In particular, if a decision to detain, or a CIO bail refusal is contrary to substantive law, then this will
be a ground for judicial review. The argument over the extended honour obligation is not about
reviewability. It is about what substantive or procedural law requires.

C3.3 Evans: the binding judicial decisions principle

199. The binding judicial decisions principle has the consequence that the February 2017 FTT bail
decision, having not been overruled by a higher court, binds both HS and the Home Secretary, and cannot
be ignored or set aside by anyone. However in the present case the Home Secretary did precisely what the
February 2017 FTT bail decision bound the Home Secretary to do. HS was released on 8 February 2017
as required by the February 2017 FTT bail decision. HS's release on 8 February 2017 was on the bail
terms set out in that decision: see section B1.8 above. In accordance with the express words of that
decision, once HS appeared before an immigration officer on 13 February 2017 a chief immigration officer
made a further bail decision.

200. Nothing done by the Home Secretary involves setting aside the February 2017 FTT bail decision. As
to ignoring it, the February 2017 FTT bail decision said nothing about what anyone should do once it had
expired


-----

201. If the Home Secretary had proceeded on the basis that the February 2017 FTT bail decision had
never been taken, or on the basis that it did not bind the Home Secretary as to what it decided, then it
could be said that the Home Secretary had ignored the February 2017 FTT bail decision. In such
circumstances there would be a breach of the binding judicial decisions principle. But no such
circumstances arise in the present case.

202. HS referred me in this regard to paragraph 53 of Lord Neuberger's judgment. There Lord Neuberger
postulated a proposition that the executive could overrule a judicial decision because the executive did not
agree with that decision. He likened such a proposition to a suggestion in a previous case that “the
executive obey the law as a matter of grace and not necessity” – something which would reverse the result
of the Civil War. Again this does not advance HS's arguments in support of the extended honour obligation.
Nothing done by the Home Secretary involved overruling the February 2017 FTT bail decision.

203. I add that the present case does not fall within Lord Neuberger's paragraph 59, quoted in section
C3.1 above. The present is not a case where the tribunal's decision is one for which “reasons have been
given in a judgment”.

204. There are of course important principles of estoppel in private law proceedings under which a
decision on an issue between two civil parties, or a failure on an earlier occasion to raise an issue, may bar
a party from raising a point later. But HS does not invoke those private law principles. Nor could he: the
issues which arise in the present case are issues of public law.

C3.4 Evans: my conclusion on Lord Neuberger's principles

205. Thus my conclusion on Lord Neuberger's principles is that they are not called into question in the
present case. I add that:

(1) the circumstances of the Evans case are nothing like the circumstances of the present case: the Upper
Tribunal judgment in _Evans_ that was overruled by the Attorney General ran to 251 paragraphs and, in
order to decide whether disclosure of confidential documents would be in the public interest, gave
reasoned rulings on specific issues: see _Evans v Information Commissioner_ [2015] UKUT 313 (AAC),

[2015] AACR 38;

(2) the judgments in the Supreme Court in Evans reached differing conclusions as to the impact of Lord
Neuberger's principles in the circumstances of the Evans case: nothing in what I have said above involves
any analysis of those differing conclusions or their legal consequences. Brief observations in that regard
are, however, made in section C8 below.

C4 High Court decision in S

C4.1 R (S) v SSHD [2006] EWHC 228 (Admin): the decision

206. In R (S) v SSHD [2006] EWHC 228 (Admin), which I shall refer to as “S”, Mr Justice Underhill was
concerned with a claimant (“S”) who, like HS, had been in detention under paragraph 2(3) of Schedule 3.
As explained in section A2 above, such detention engages the bail powers in paragraph 22 of Schedule 2.
At that time relevant bail powers now conferred on the FTT were conferred on the Asylum and Immigration
Tribunal (“the AIT”). For convenience I set out below para 22(1A) as it read at the material time, italicising
words which Mr Justice Underhill described as central to the issues in that case:

(1A) An immigration officer not below the rank of chief immigration officer or the [AIT] may release a person
so detained on his entering into a recognizance … conditioned for his appearance before an immigration
officer at a time and place named in the recognizance … _or at such other time and place as may in the_
_meantime be notified to him in writing by an immigration officer._

207. On 19 January 2006 an AIT adjudicator made an order releasing S on bail. At that time a problem
about travel documents had not been resolved and there was no predictable end to S's detention. The
order required S to appear before an immigration officer on 16 February 2016. Thus the period of bail
specified in the order was a period from 19 January to 16 February 2006.


-----

208. What then happened was that travel documents became available later on 19 January 2006. On 1
February 2006 removal directions were given, specifying a flight on 14 February. Two important events
followed the giving of removal directions on 1 February 2006:

(1) on 27 January 2006 S was re-detained by an immigration officer; and

(2) on 4 February 2006 S was served with a written notice “pursuant to paragraph 22(1A) of Schedule 2”
stating that the conditions of S's bail were varied and S was “required to appear before an immigration
officer at Harmondsworth IRC on 4 February 2006”.

209. At a hearing on 13 February 2006 Mr Justice Underhill refused to grant an order of habeas corpus. In
his judgment on 22 February 2006 he founded his refusal of habeas corpus on a conclusion that the 4
February notice had been an effective variation of the “appearance date” specified in the AIT order. He
nevertheless considered it arguable that the re-detention on 27 January 2006 had been unlawful.
Accordingly he granted permission to apply for judicial review “substantially concerned with damages”, but
only in relation to the detention between 27 January and 4 February 2006.

C4.2 S: arguably unlawful re-detention on 27 Jan 2006

210. In paragraph 9 of his judgment Mr Justice Underhill noted an argument advanced by the Home
Secretary that re-detention on 27 January 2006 fell within a power to detain conferred by paragraph 16 of
Schedule 2:

9. … [The Home Secretary] submitted that on its face the situation plainly fell within the power of an
immigration officer to detain a person under para. 16 of Schedule 2 : the Claimant was, as at 27th January,
a person in whose case there were reasonable grounds for suspecting that removal directions would be
made (as they were a few days later), and accordingly the case fell within the terms of sub-para. (2). [The
Home Secretary] did not accept that that power was rendered unexercisable by the fact that the Tribunal
had earlier exercised its powers under para. 22(1A) to grant a temporary release. [The Home Secretary]
accepted that it would be unlawful for an immigration officer to exercise his powers under para 16 when
doing so would be contrary to the basis on which the Tribunal had proceeded. But that would not be so
where there had been a material change of circumstances affecting the basis on which the Tribunal had
acted, In the present case the Tribunal had made its order at a time when it was unknown when removal
might occur, and on the basis that it was wrong to detain the Claimant for a further undefined period: the
obtaining of his travel documents completely changed that picture.

211. However in paragraph 11 of his judgment Mr Justice Underhill doubted that the power in paragraph
16 of Schedule 2 was engaged at all. He then added a more general observation which I shall return to
below. The concluding sentence of paragraph 11 stated:

I need not however express a concluded opinion on the point, since the only question for present purposes
is whether it is arguable that that the re-detention of the Claimant on 27th January was unlawful; and in my
view it is.

212. The consequence of this analysis was that S was given permission to apply for judicial review in
relation to his re-detention on 27 January: see paragraph 18 of the judgment.

C4.3 S: lawfulness of the 4 February 2006 notice

213. Mr Justice Underhill then turned to the position once the written notice had been served on 4
February 2006. He held that from that date onwards S had been lawfully detained. The reason was
explained in paragraph 12 of the judgment: the notice had been an effective variation of the “appearance
date” specified in the AIT order. It was effective because it was permitted under paragraph 22(1A) by the
words italicised above.

214. On this aspect it is relevant to set out paragraph 13 of the judgment:

13. … Miss Harrison [counsel for S] submitted that any such construction would have the effect of allowing
a purely administrative act to over-ride the decision of the Tribunal. But the difficulty for her is that the


-----

statute unquestionably provides for an immigration officer to specify a time (and place) for appearance
other than that provided for by the Tribunal: it thus authorises precisely what she says is objectionable. I
accept that there must be limits on the exercise of that power. Specifically, I do not believe that it can be
used where the effect is to undermine the basis on which the Tribunal reached its decision. In such a case
it would not be beyond judicial control. The person affected by it could in principle re-apply to the Tribunal,
since he would be (again) a 'person detained' within the meaning of para. 2(4A) of Schedule 3; or, if more
appropriate, he could apply for judicial review. But this is not such a case, for essentially the reasons given
by Mr. Sheldon [counsel for the Home Secretary] in relation to his broader submissions (see para. 9
above). The notice of 4th February reflected a material change in circumstances, namely that removal
directions had now been given and the removal date was imminent. It is perfectly plain that the Tribunal did
not intend the Claimant to be entitled to remain at liberty beyond the date at which he could lawfully be
deported, or to obstruct lawful re-detention aimed at facilitating such deportation: its decision to release the
Claimant until 16th February simply reflects the fact that at the date of its decision it did not anticipate
deportation becoming possible before that date.

C4.4 S: submissions and analysis

215. In support of the extended honour obligation HS relied on the general observation mentioned in
section C4.2 above. It was in these terms:

… more generally, I doubt if it is right that the Secretary of State can simply rely on reassertion of the
underlying power under which a person has been detained — whether that is to be found in para. 16 or
anywhere else — to re-detain that person after he has been released by the Tribunal under para. 22.

216. To my mind this observation must be read in context. The AIT had conditionally released S on AIT
bail until 16 February 2006. Mr Justice Underhill, at this stage, was considering a contention by the Home
Secretary that, without there being any variation of the AIT's order, it was lawful to detain S prior to the
expiry of the period of AIT bail. In that context I share Mr Justice Underhill's doubt. The re-detention on 27
January 2006 occurred only a week or so into the period of AIT bail, and denied S the full benefit of what
the AIT had ordered – conditional bail for nearly three more weeks, until 16 February 2016.

217. There is an obvious and strong argument that the 27 January detention plainly sought to override the
AIT order and to ignore the binding nature of that order. But this gives no support for HS's proposed
extended honour obligation. The analysis above does not involve extending the Home Secretary's duty
beyond honouring the terms of the AIT order: it is that very order which was not being honoured by the 27
January re-detention.

218. HS also relied upon what was said in paragraph 13 of Mr Justice Underhill's judgment: see section
C4.3 above. Here, too, it is necessary to set what was said in context. The Home Secretary was relying on
an express statutory power to vary the AIT's order. I agree with Mr Justice Underhill that such a power
cannot be untrammelled, and that it may not be used where the effect is to undermine the basis on which
the AIT reached its decision. The reason for this is, in my view, so obvious as to go without saying: the
power to vary is ancillary to the AIT's power to grant conditional bail, with the consequence that while it
may alter the time and place of reporting it may not do so in such a way as would run counter to the AIT's
purpose in granting conditional bail.

219. Here, too, it seems to me that this gives no support for HS's proposed extended honour obligation.
The analysis above does not involve extending the Home Secretary's duty beyond honouring the terms of
the AIT order: it is that very order which would not be honoured by a variation which undermines the basis
on which the AIT reached its decision.

C5 Court of Appeal decision in AR (Pakistan)

220. The next case relied upon by HS in support of the extended honour obligation was R (AR (Pakistan))
_v SSHD [2016] EWCA Civ 807, [2017] 1 WLR 255, which I shall refer to as AR (Pakistan). AR was granted_
FTT bail by an order dated 7 October 2014. The primary condition required AR to appear before a chief
immigration officer on 15 October 2014. Secondary conditions required AR to live and sleep at a specified


-----

address and to cooperate with arrangements for electronic monitoring (“tagging”) as set out in section 36 of
the Asylum and Immigration (Treatment of Claimants, etc) Act 2004. It seemed that an immigration officer
imposed a condition as to curfew which may or may not have been properly authorised. It was not clear
whether AR was informed of the curfew when he first reported on 15 October 2014. However he was
undoubtedly notified of it prior to February 2015, when the FTT refused an application by him to vary his
bail conditions so that he could attend prayers in the evening. That application was refused on 16 February
2015, and a further application was refused by the FTT on 14 July 2015. On 7 August 2015 AR filed a
judicial review claim which was due to be heard by the Upper Tribunal on 12 October 2015.

221. However on 9 October the Home Secretary notified AR that “the conditions of your bail are hereby
varied to cease immediately”. The parties came to the hearing on 12 October 2015 with a proposed
consent order that AR had permission to withdraw his claim for judicial review. The Upper Tribunal
considered that it would nevertheless determine issues raised in the claim owing to their “unusual and
important nature” and the likelihood of the authority of the Home Secretary to relax bail conditions arising in
future cases. It heard argument and gave judgment holding that this was a case where the FTT bail was “of
non-finite duration”, with the consequence that it was not open to the Home Secretary vary the conditions
of bail imposed by the FTT.

222. AR applied to the Court of Appeal for permission to appeal from the Upper Tribunal decision. That
application was supported by the Home Secretary. Both sides contended that the Home Secretary did
have power to relax or discharge the conditions applicable to AR's bail. At a permission hearing the Court
of Appeal directed the appointment of an amicus curiae for the purpose of supporting the Upper Tribunal
judgment which would, otherwise, have had nobody to defend it. At the full hearing on 26 July 2016 Mr
Sarabjit Singh of counsel fulfilled that role.

223. The Court of Appeal judgment, delivered on 29 July 2016, reversed the ruling of the Upper Tribunal.
It held that the FTT bail conditions ceased when AR appeared before an immigration officer in accordance
with the FTT order. In paragraph 26 of his judgment Longmore LJ, with whom Jackson and Voss LJJ
agreed, quoted from the words used in paragraph 22 (1A) of schedule 2, referring to a detained person
“entering into a recognisance … conditioned for his appearance before an immigration officer at a time and
place named in the recognisance …”, and said:

This a time-honoured form of words to express the idea of surrendering to bail. Once a bailed person
surrenders to his bail (whether to magistrates or the Crown Court in a criminal case or to an immigration
officer in an immigration case) it is then for the person to whom he surrenders to re-fix bail, if he or she
considers it appropriate to do so and determine any appropriate conditions.

224.  In support of the Upper Tribunal decision, Mr Singh had submitted that if the view taken by the Court
of Appeal were right, there would be no need for the FTT to impose secondary conditions, and that a
question arose as to why the relevant procedure rules made it clear that adversarial argument about
conditions was to be conducted in the FTT rather than at the time of surrender. As to these submissions,
Longmore LJ said in paragraph 28 of his judgment:

The answer is that secondary conditions (such as residence and submission to electronic tagging) are
required because there is inevitably a lapse of time between release from detention and the date of
surrender. During that lapse of time, conditions such as that imposed by the FTT in this case will, in any
event, be necessary. Any conditions imposed by the FTT will also be important guidance to an immigration
officer to whom a bailed person surrenders. He is likely to continue the terms; any departure from them to
the prejudice of the bailed person would have to be justified and could be amenable to judicial review.

225.  HS placed reliance on what was said by Longmore LJ in the last sentence quoted above. This, HS
submitted, was a clear statement that, while the FTT conditions came to an end when a detained person
appeared before an immigration officer as required by the FTT order, nevertheless CIO bail would be likely
to continue those terms, and any departure from them to the prejudice of the bailed person would have to
be justified and could be amenable to judicial review. I agree.


-----

226. However this passage, to my mind, says nothing to support the extended honour obligation. There is
no reason to doubt that imposing an additional burden on the bailed person could be amenable to judicial
review, in the absence of some more convenient and effective remedy. At a judicial review the additional
onerous condition would have to be justified as lawful. On ordinary principles it would be lawful if, as set
out in section C2.4 above, the decision maker has complied with substantive and procedural law, and does
not go beyond the bounds of reasonableness. Longmore LJ's observation does not expressly or implicitly
support the proposition that an FTT decision granting bail is of a character which requires substantive law
to introduce additional objective tests that must be satisfied by those considering detention and bail at a
later stage.

C6 High Court decision in Lupepe

227. In R (Lupepe) v SSHD _[2017] EWHC 2690 (Admin), which I shall refer to as Lupepe, a judicial review_
claim before Mr Justice Lewis gave rise to a number of questions concerning immigration detention, bail,
and the imposition of a curfew. Relevant for present purposes is that the claimant was granted bail after a
hearing before the FTT on 27 January 2014. The primary condition of bail required him to appear before a
chief immigration officer at a specified address on 3 March 2014. The secondary conditions required,
among other things, that he cooperate with arrangements for electronic monitoring. Mr Justice Lewis held,
at paragraph 19 of his judgment, that the FTT was not requested to consider, and did not specifically
consider, whether bail should be subject to a condition of curfew. When the claimant was released on 27
January 2014, however, immigration officials served him with a notice of restrictions pursuant to paragraph
2(5) of schedule 3. These restrictions included a curfew. It was subsequently appreciated that paragraph
2(5) of schedule 3 did not in law enable the imposition of a curfew. The only way in which a curfew could
be imposed was as a condition of bail. By letter dated 23 August 2016 the claimant was notified that the
curfew in the restrictions imposed on 27 January 2014 was lifted. However the claimant was not regarded
as presenting an acceptable risk of release without a curfew. When the claimant attended a reporting
centre on 8 November 2016 he was re-detained. At that point he was given a document indicating that he
had been granted bail under paragraph 22 of schedule 2. This document contained conditions of bail which
included a curfew.

228. The first issue identified by Mr Justice Lewis in his judgment was whether the CIO bail of 8 November
2016 could impose a curfew condition where no such condition had been imposed by the FTT. At
paragraph 47 of his judgment Mr Justice Lewis described the contention for the claimant in this way:

… it is submitted that the defendant could not [after the FTT decision] seek to impose different and more
onerous bail conditions than those determined as appropriate by the [FTT] unless there had been a
material change of circumstance.

229. Mr Justice Lewis then made reference to cases cited to him:

(1) in _R v Secretary of State for the Home Department ex p. Danaei_ [1998] INLR 124 the claimant's
asylum appeal had been dismissed by an immigration adjudicator. The adjudicator found as a fact that the
claimant had had an adulterous relationship in Iran with a married woman. On a subsequent application for
permission to remain, the Home Secretary refused to accept that finding of fact and decided that the
claimant's account in that regard was untrue. The issue was the extent to which the Home Secretary was
bound by the finding of fact made by the adjudicator. The Court of Appeal held that it was unreasonable, in
the public law sense, for the Home Secretary in this context to disagree with a factual conclusion of an
adjudicator who had heard the evidence unless the adjudicator's conclusion was itself unlawful as a matter
of public law or unless fresh material had become available since the hearing.

(2) Lewis J described the decision of the Court of Appeal in _R v Warwickshire County Council ex p._
_Powergen (1996) 97 L.G.R. 617 as being to “similar effect”. There the Court of Appeal held that a highway_
authority could not depart from the decision of a planning inspector on a planning appeal that a particular
development did not give rise to highway safety issues.


-----

(3) referring to paragraphs 11 and 13 of the judgment in S (see section C4 above), Mr Justice Lewis noted
that they indicated that the Home Secretary could not re-detain a person released on bail, or vary
conditions of bail, where to do so would undermine the basis on which a tribunal had reached its decision.

(4) Mr Justice Lewis noted what Lord Neuberger had said in paragraph 59 of his judgment in Evans: see
section C3.1 above.

(5) turning to _AR (Pakistan), Mr Justice Lewis noted that the Court of Appeal had recognised that the_
Home Secretary may impose conditions not imposed by the FTT if that were justifiable (see section C5
above).

(6) in paragraph 51 of his judgment Mr Justice Lewis distinguished the facts in Lupepe from those in other
cases: the FTT had not been asked to consider a curfew condition, and had not made any findings of fact
or reached any conclusion on the necessity for a curfew condition in relation to Mr Lupepe. He added in
paragraph 53 that the Home Secretary's decision to grant bail subject to such a curfew would not,
therefore, directly contradict or run counter to any finding or decision made by the FTT.

230. It had been contended for Mr Lupepe that it was matter of choice for the Home Secretary to seek, or
not to seek, a curfew condition, and if the Home Secretary for any reason did not seek such a condition,
the Home Secretary could not thereafter, in effect, circumvent the process and impose such a condition. In
paragraph 53 of his judgment Mr Justice Lewis rejected that characterisation. It was not, he concluded,
appropriate in circumstances where the reasons why a curfew condition had not been sought arose from a
view of the law which had been thought to be correct until a decision of the Court of Appeal otherwise.

231. Mr Justice Lewis added at paragraphs 54 and 55:

54. In this situation, therefore, the decision of the defendant to impose a curfew condition would not, of
itself, involve any action which amounted to an abuse of power or involve any departure from the decision
of the First-tier Tribunal in a way which was unlawful or unreasonable as a matter of public law.

55. Similarly, in my judgment, the decision to detain the claimant in order to release him on bail but subject
to a curfew condition would not, on the facts of this case, involve an unlawful departure from the decision of
the First-tier Tribunal. The defendant was not seeking to contradict the decision of the First-tier Tribunal
that the claimant could be released, on appropriate conditions, from detention. The difficulty was that the
conditions considered necessary to ensure that release from detention was appropriate were not fully
canvassed in the First-tier Tribunal for the reasons explained above. The defendant considered that the
appropriate conditions included a curfew. Once the Court of Appeal decided that a curfew could only be
imposed as a condition of bail, the only means by which the defendant could impose such a condition
would be to detain the claimant and then release him on bail with the appropriate condition attached. The
situation was unusual and resulted from a misunderstanding of the powers of the defendant in relation to
bail. The steps adopted by the defendant were intended to rectify the situation and lead to a situation
where the claimant was released but on conditions considered by the defendant to be appropriate. That did
not, in my judgment, involve a situation where the defendant was seeking to question or depart from the
decision of the First-tier Tribunal on the matters which it specifically addressed and would not, on this
ground, give rise to any public law illegality.

232. HS relies upon _Lupepe as supporting the extended honour obligation. In that regard, however, HS_
acknowledges that Mr Justice Lewis had held that CIO bail could supplement bail conditions imposed by
the FTT where the FTT had not itself addressed the condition in issue. As to this, HS said that the present
case was concerned with overturning bail altogether, which was much more serious than merely
supplementing the bail conditions. In any event, HS added that it was implicit in Mr Justice Lewis's
reasoning that the binding judicial decisions principle was applicable.

233. I cannot accept that these submissions assist HS. I agree that Mr Justice Lewis adopted an approach
which assumed that the principles discussed in the cases cited to him were applicable as principles, albeit
that when applied to the facts of _Lupepe_ they did not assist Mr Lupepe. It seems to me clear, however,
from Mr Justice Lewis's judgment that he was not asked to consider the argument advanced for the Home
Secretary before me that immigration bail is not of such a nature as calls for objective inquiry by the court


-----

as to what has happened between an FTT grant of bail and a CIO refusal of bail once the FTT bail has
expired. In any event I find no support in Lupepe for the central feature of the extended honour obligation,
under which it would be for the court to determine whether at the time of the new decision there had been a
clear and significant change of circumstance which justified that decision. On the contrary, Mr Justice
Lewis seems to me to have regarded the approach taken in Warwickshire County Council, in S, and in AR
_(Pakistan),_ as akin to the approach in _Danaei, where the test was unreasonableness “in the public law_
sense”. Certainly in _Lupepe Mr Justice Lewis did not consider that there was any need for the court_
objectively to assess whether a curfew condition was required: however the relevant legal tests were
expressed, Mr Justice Lewis regarded them as satisfied in circumstances where arguments relied upon to
justify the new course of action had not been advanced before the FTT and did not circumvent the tribunal
process.

C7 High Court decision in Gafurov

234. In R (Gafurov) v SSHD _[[2018] EWHC 3656 (Admin), a judicial review claim which I shall refer to as](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TSJ-WPX2-8T41-D1RY-00000-00&context=1519360)_
“Gafurov”, Mr Phillip Mott QC, sitting as deputy judge of the High Court, was concerned with a period of
immigration detention which began on 29 June 2018. This had the consequence that, as noted in section
A2 above, the statutory regime applicable to the present case was no longer in force: on 15 January 2018
schedule 10 to the 2016 Act came into force, resulting in extensive amendments.

235. The factual basis to the case was that on 14 May 2018 the FTT, knowing that the claimant was
scheduled to be removed on 14 July 2018, granted bail which made no provision for his re-detention prior
to the date of removal. In that regard, however, there was an express statutory provision, in para 1(6) of
Schedule 10 to the 2016 Act, that a grant of immigration bail did not prevent subsequent detention under,
among other things, a provision for detention pending deportation.

236. On 29 June 2018 the claimant was re-detained. The approach taken by the deputy judge was to
consider, first, whether the re-detention was “reasonable in all the circumstances”. The deputy judge noted
at paragraph 25 of his judgment that the reasons relied upon for re-detention were “really the same” as the
matters that had been relied upon when opposing bail at the hearing before the FTT on 14 May 2018.
Unsurprisingly, in those circumstances he concluded that detention had not been reasonable in all the
circumstances. At paragraph 26 he said this:

26. It seems to me that in order for a decision to re-detain to be rational there must be some change
between the position as it was when the First-tier Tribunal judge granted bail and the time when the
claimant is detained again. What amounts to a change sufficient to found a rational decision to re-detain
will vary from case to case. It is very much fact specific. There may be cases where the simple elapsing of
time will be enough.

237. At the conclusion of his judgment the deputy judge referred to an additional submission that had been
made on behalf of the claimant. This was that the relevant statutory provision permitting detention “must be
read as subject to an implied limitation allowing re-detention only where there has been a material change
of circumstances”. It was not necessary for the deputy judge to decide whether that submission was
correct. He expressed a provisional view in these terms:

31. … My provisional view is that it is very difficult, where Parliament has expressly given a power in
unlimited terms, to imply or import a limitation. To a very large extent, if not entirely, the limitation
proposed, which is that re-detention should only be lawful where there is a material change of
circumstances, is putting in another way that the power should only be exercised rationally. That follows
without it being expressed in the statute, and it is this court which is very quick to act if there is a breach of
that

238. HS acknowledged that the deputy judge, by referring to a test of whether the decision to re-detain
was “rational”, was using the language of a public law unreasonableness challenge. Despite this, HS
submitted that the deputy judge's discussion had not taken the approach that could be expected in such a
challenge. I disagree. The deputy judge's reference to “a change sufficient to found a rational decision to
re-detain” seems to me to connote a standard public law requirement that there must be something which


-----

could enable a reasonable decision maker to conclude that a new approach should be taken which differed
from the FTT's decision.

C8 Conclusion on JR ground 1

C8.1 Three different contexts

239. To my mind the matters discussed in the cases cited to me involve three different contexts, each of
which calls for separate consideration. The first, dealt with in section C8.2 below, is administrative action
which disobeys, or interferes with, an order made by a tribunal. The second, dealt with in section C8.3
below, concerns the proper interpretation of powers enabling the executive to override or vary an order
made by a tribunal. The third, dealt with in section C8.4 below, concerns circumstances where the
executive, after a tribunal order has taken effect and fulfilled its purpose, acts in a manner that calls into
question the tribunal's reasoning when making the order.

C8.2 Disobeying or interfering with the tribunal's order

240. The Home Secretary is party to an FTT bail decision. Indeed the only reason for the matter coming
before the FTT is that the Home Secretary has refused bail. If the FTT grants bail then the binding judicial
decisions principle requires the Home Secretary to ensure that detention of the detained person ceases for
the period specified in the FTT's order. This is subject only to such legal power as the Home Secretary may
have to override or vary the provisions in the FTT's order: see section C8.3 below.

241. A decision falling within this context was the Home Secretary's re-detention of S on 27 January 2006:
see section C4.1 above. It was the context for Mr Justice Underhill's general observation relied on by HS:
see section C4.4 above. Re-detention at a time when S had been given conditional liberty, and had not
breached any condition of that liberty, was in defiance of the tribunal's grant of bail.

242. Re-detention may have occurred because the Home Secretary considered that paragraph 2(3) of
Schedule 2 enabled a fresh detention decision to be made even though FTT bail had not yet expired. On
the application of relevant principles of interpretation, however, I explain in section C8.3 why it is difficult to
see how any such reading of paragraph 2(3) of Schedule 3 could be justified.

C8.3 Powers to override or vary the tribunal's order

243. Paragraph 22(1A) of Schedule 2 requires the tribunal, if it grants bail, to include in the order for bail a
power enabling an immigration officer to vary the time and place for surrender. In _S_ it was held that this
power was lawfully exercised on 4 February 2006. For the reasons given in section C4.4 above I agree
with Underhill J that there is a mechanism of court control. It is this: the power is ancillary to the tribunal's
decision, and it is accordingly implicit that it cannot be used where the effect is to undermine the basis on
which the tribunal reached its decision. The implication is needed because variation may deprive an
individual of liberty granted by the FTT order. This is such a serious consequence that in my view the
power must be interpreted as only permitting variation if the Home Secretary can objectively demonstrate
that the variation will not operate to undermine the basis of the FTT order.

244. I noted in section C8.2 above that in S the Home Secretary may have considered that paragraph 2(3)
of Schedule 2 enabled a fresh detention decision to be made even though FTT bail had not yet expired.
This interpretation would be so drastic in its effect as to amount to an overriding of the tribunal's decision.
In Evans, as it seems to me, all members of the Supreme Court approached the matter on the basis that a
drastic effect of this kind can only come about if the language used in the statute is crystal clear. Unlike
section 53 of the Freedom of Information Act, nothing in paragraph 2(3) of Schedule 3 expressly
contemplates that a decision to detain might override an extant grant of FTT bail. That being so, it seems
to me that there can be no room for such an interpretation.

245. This can be contrasted with paragraph 1(6) of Schedule 10 to the 2016 Act: in Gafurov all agreed that
this was a clear provision that immigration bail would not prevent detention under the provisions mentioned
in that paragraph.


-----

246. In a different context the Supreme Court in _Evans_ was split on how section 53 could be read. A
majority concluded that it could not be read as narrowly as Lord Neuberger proposed. However two of that
majority concluded that it could and should be read as requiring a more stringent review by the court than
would normally be adopted on a reasonableness challenge. It was because the certificate did not survive
more stringent review that the appeal failed.

247. It can be seen from _Evans_ that there may nevertheless be a statutory power to override a tribunal
decision. If there is then it may, as a matter of statutory interpretation, be held to be exercisable subject
only to reasonableness review, subject to a more stringent review, or subject to an objective requirement
of, among other things, material change of circumstances. In the present case, however, I am not
concerned with any of this, for there is no question in the present case of there being any relevant statutory
power of override.

C8.4 Calling into question the FTT's reasoning

248. Having concluded that the present case does falls neither within the first nor the second contexts
discussed above, I come to the context that it does fall within: the third context. I preface my discussion
with a note of caution: my discussion concerns a bail regime which is now out of date. The 2016 Act
changes to bail are numerous, and I do not attempt to analyse them here.

249. As explained above, in the present case HS asserts that an FTT bail decision should restrict future
action by the Home Secretary even though the FTT decision has been given full effect and has expired.
The action which HS identified as being restricted was HS's re-detention.

250. I do not think that that precise identification can possibly be right. The February 2017 FTT decision
was a decision on bail. If it is to have a continuing effect, that continuing effect will be on future decisions
as to bail, not as to detention. Detention will ordinarily be the precursor to bail, and the circumstances in
which it can be challenged are well established: see section D below.

251. Moreover, as it seems to me, the February 2017 FTT bail decision was consistent with a conclusion
that HS should be a “detained person”. What the February 2017 FTT bail decision implicitly finds is that
such risks as are posed by HS can adequately be managed by a combination of bail conditions and the
giving of sureties. Such a finding gives no support to a conclusion that relevant risks can be discounted if
HS is given complete liberty. Indeed it seems to me that the February 2017 FTT bail decision runs counter
to any such conclusion. The FTT ought not, in principle and subject to any relevant legislative provision, to
impose conditions which are unnecessary. By imposing the conditions in the February 2017 FTT bail
decision, the FTT was concluding that bail conditions were needed to protect against relevant risks. The
logical conclusion is that detention of HS, so as to make him a “detained person” who could be made
subject to bail conditions, was an appropriate course.

252. Thus, as it seems to me, the appropriate target for HS's abuse of process claim is not the March
2017 re-detention decision as such, but rather the decision implicit in it that HS would not be granted bail
until such time as he had an appropriate release address. Once this is recognised there are two immediate
potential hurdles for HS to surmount. The first, noted in a broader context by the Home Secretary, is that
the February 2017 FTT bail decision was not concerned with what would or would not be an appropriate
address. The present case thus becomes akin to _Lupepe,_ where the claimant failed because the Home
Secretary's decision did not seek to question or depart from the FTT decision on the matters which it
specifically addressed.

253. The second hurdle is that the court will not normally grant judicial review to a claimant who has an
effective alternative remedy. As regards the decision not to grant bail, HS throughout period 4 had the
option of seeking bail from the FTT. The availability of that remedy was stressed in argument by the Home
Secretary. It is a speedy and highly effective remedy. There was a special reason in Konan for concluding
that the effective alternative remedy principle did not apply, for there the true challenge was to the decision
to detain. Where the challenge is in truth to a refusal of bail, it may well be that the challenge should be
stopped at the permission stage on the basis that the appropriate place for it to be determined is in the


-----

FTT. However no submission was made to that effect in the present case, perhaps because of what was
said in Konan, and I say no more about it.

254. There was, rightly, no suggestion by HS that private law principles of issue estoppel would operate to
bar a refusal of CIO bail.

255. In the present case I turn to Longmore LJ's observation in AR (see section C5 above) that if CIO bail
is more onerous than prior FTT bail this would have to be justified and could be amenable to judicial
review. For the reasons given in section C5 above this does not, however, indicate that an FTT bail
decision is of a character which requires substantive law to introduce additional objective tests that must be
satisfied by those considering detention and bail at a later stage. Nor, for reasons given in sections C6 and
C7 above, do Lupepe or Gafurov offer support for such a contention. What is demonstrated by Gafurov is
that, on a reasonableness review, refusal of CIO bail may be unlawful if the reasons are essentially the
same as those which were rejected by the FTT, and the circumstances have not changed. I note that there
was no suggestion in that case that the FTT's decision had been reached on the basis of a
misunderstanding of the law, or was in any way legally flawed.

256. In the present case the FTT bail decision involved no distinct analysis of any particular issue of law or
fact. It amounted to no more than a conclusion that such evidence as had been put before the FTT
warranted a conclusion that risks associated with release could be adequately managed by requiring
sureties and by setting appropriate conditions.

257. In these circumstances I consider that it would be undesirable to impose an additional objective test.
The following considerations appear to me to have the consequence that the court's role of jailor control
does not call for such a course:

(1) In the ordinary course a finding by the FTT at a particular bail hearing should not be regarded as
setting that finding in stone. Deciding whether a person should be granted bail on any particular occasion
should not become a process under which findings at previous bail hearings are finely analysed.

(2) The ability to seek FTT bail is a speedy and effective remedy for immigration detainees who consider
that on any particular occasion they have been wrongly detained when they should have been given CIO
bail. The statutory purposes of granting that remedy are unlikely to be advanced by arguing about what the
FTT held, and why, on a previous occasion. Those statutory purposes will, rather, be advanced by
promptly applying to the FTT for it to make its own factual and evaluative assessments on matters as they
currently stand.

(3) HS protested at the notion that it might be open to the Home Secretary to say that the FTT had taken a
wrong view of the facts, or of the law, at a previous hearing. It was submitted that this would be allowing a
jailor to say, “in my view, the facts necessary to justify detention exist”, and thereby do exactly what Lord
Browne-Wilkinson had said the court should not permit. In the present context, however, that criticism is
not apt. The Home Secretary accepts that an earlier decision of the FTT can only be called into question if
it is within the bounds of reasonableness to do so. Those bounds will normally limit the Home Secretary in
the way described in _Gafurov,_ preventing the Home Secretary from doing no more than run arguments
which failed before on the same facts. The bounds of reasonableness are likely to require that before
asserting that the earlier FTT decision was flawed in law the Home Secretary will have to show a strong
case that something went badly wrong. In essence, where a contention of inconsistency with an earlier
FTT bail decision is made, a limitation imposed by the bounds of reasonableness gives the court more
flexibility, in the interests of justice, than can be achieved by imposing an objective test.

(4) If there is a strong case, sufficient to surmount a reasonableness challenge, then it may be in the
interests of justice for the Home Secretary to be allowed a degree of leeway to take a different course from
an earlier FTT decision. Under the pre-2016 Act régime there is no mechanism for the Home Secretary to
bring the matter back to the FTT. But under that régime it will always be open to the detained person to
ensure, by applying to the FTT for bail, that it is a judicial assessment of the facts and law which
determines what the position on bail should be in the particular circumstances of the case.


-----

258. For the reasons given above I conclude that in the present case there is no extended honour
obligation of the kind advanced on behalf of HS. There is, as the Home Secretary accepts, an obligation to
take proper account of any relevant assessment by the FTT. The test of whether proper account has been
taken is the ordinary public law test of reasonableness. In the present case the earlier FTT decision
granting bail, for the reasons described above, is not of a character which requires the introduction of
additional objective tests that must be satisfied by those considering detention and bail at a later stage.

259. I add that in the circumstances of the present case it would not matter whether the test was
reasonableness or an additional objective test of change in material circumstances. In this regard I put on
one side complaints about the reasons given to HS for his re-detention, and complaints that HS should
have had prior notice of relevant concerns to enable him to answer them. As explained in the remainder of
this judgment, the reason for HS's re-detention and non-renewal of bail lay in new information that persons
linked to the Halesowen address had convictions for sexual offences and that other criminal behaviour was
perpetrated by HS's associates in the area. This was a material change of circumstances which objectively
warranted prompt action to re-detain HS. I do not accept that the new information was “thin”: it identified
two specific areas of concern, and why they were of concern. Objectively, as it seems to me, prompt
protection of the public militated in favour of taking those concerns at face value rather than risk delay by
pressing the police for the underlying intelligence material.

D. JR ground 2: legal principles governing detention

D1 JR ground 2: relevant legal principles

260. In this section I describe, based on an account given by HS, “core principles” for the purposes of JR
ground 2. The Home Secretary did not take issue with this account.

261. As a matter of general principle, it is for a detaining authority to satisfy the court as to the legality of
detention: R (Lumba) v SSHD [2012] AC 245at §65, albeit the concept of “burden of proof” is inapt when
considering matters such as reasonableness: R (Saleh) v SSHD [2013] EWCA Civ 1378 at §§42-46.

262. Legal requirements as to the use of immigration powers of detention were examined by Woolf J in R
_v Governor of Durham Prison ex p Hardial Singh [1984] 1 WLR 704. In R (I) v SSHD [2003] INLR 196 what_
was said by Woolf J was discussed by Dyson LJ by reference to four propositions. In Lumba at paragraph
22 the four propositions were repeated by the same judge, now Lord Dyson JSC. All members of the
Supreme Court sitting on that occasion, with the exception of Lord Phillips of Worth Matravers PSC,
agreed with these four propositions. I shall refer to them as “the Lumba principles”:

_Lumba principle (1): The Secretary of State must intend to deport the person and can only use the power_
to detain for that purpose;

_Lumba_ principle (2): The deportee may only be detained for a period that is reasonable in all the
circumstances;

_Lumba principle (3): If, before the expiry of the reasonable period, it becomes apparent that the Secretary_
of State will not be able to effect deportation within that reasonable period, he should not seek to exercise
the power of detention;

_Lumba_ principle (4): The Secretary of State should act with the reasonable diligence and expedition to
effect removal.

263. The prospects of removal may be relevant to the reasonable period. Richards LJ in R (MH) v SSHD

_[2010] EWCA Civ 1112 said at paragraph 65:_

65. I do not read the judgment of Mitting J in _R (A and Others) v Secretary of State for the Home_
_Department_ [2008] EWHC 142 (Admin) as laying down a legal requirement that in order to maintain
detention the Secretary of State must be able to identify a finite time by which, or period within which,
removal can reasonably be expected to be effected. That would be to add an unwarranted gloss to the
established principles. In my view Mitting J was not purporting to do that but was simply asking himself the
questions “by when?” and “on what basis?” for the purposes of his own consideration of the case before


-----

him. Of course, if a finite time can be identified, it is likely to have an important effect on the balancing
exercise: a soundly based expectation that removal can be effected within, say, two weeks will weigh
heavily in favour of continued detention pending such removal, whereas an expectation that removal will
not occur for, say, a further two years will weigh heavily against continued detention. There can, however,
be a realistic prospect of removal without it being possible to specify or predict the date by which, or period
within which, removal can reasonably be expected to occur and without any certainty that removal will
occur at all. Again, the extent of certainty or uncertainty as to whether and when removal can be effected
will affect the balancing exercise. ...

66. ... Of course, A (Somalia) [a reference to R (A) v Secretary of State for the Home Department [2007]
_EWCA Civ 804] shows that the court needs to go on to consider the degree of certainty or uncertainty_
affecting the prospect of removal and to ask itself whether the prospect is sufficient to warrant detention in
all the circumstances of the case.

68. … the judge's assessment … was comprehensive and sustainable. In particular:

(v) … As the period of detention gets longer, the greater the degree of certainty and proximity of removal I
would expect to be required in order to justify continued detention.

264. Thus, on the one hand, there is no hard and fast rule that the Home Secretary must be able to point
to a specific point in time by which the Home Secretary expects removal to be possible. On the other hand,
a relatively greater level of uncertainty as to when removal may occur will tend to make continued
detention harder to justify by reference to other factors, when considered in the overall balancing exercise.

265. I stress that when deciding whether detention complies with the Lumba principles, save as regards
incidental questions of fact in certain circumstances, it is for the court to assess the position objectively:
see the citations from A (Somalia) in section C2.4 above.

D2 Relevant Lumba principles in the present case

266. HS's judicial review ground 2 alleged breaches of _Lumba_ principles (2) and (4). I consider the
arguments in relation to those principles in sections D3 and D4 respectively.

267. In the course of argument on JR ground 2 HS criticised the Home Secretary's assessment of HS's
status under the AR policy, and criticised the Home Secretary for not giving advance warning of concerns
about the suitability of the Halesowen address. I deal with those matters in sections E and F respectively.

D3 Lumba principle (2): length of detention

268. HS invoked Lumba principle (2) when criticising the March 2017 re-detention decision. HS submitted
that approaching the matter objectively, it was plain on 6 March 2017 that if HS were detained then more
than a reasonable time would elapse before he could be returned to Pakistan. HS advanced a contention
that when making that objective assessment it was highly relevant that the February FTT bail decision
“judged that [HS] posed a low risk” of absconding or reoffending.

269. I readily accept that risks of absconding and re-offending may be relevant. However HS's contention
seems to me to be fundamentally misconceived, for several reasons:

(1) There may be cases where a person liable to detention is of such low risk of absconding or reoffending
that detention is unnecessary. That is not this case.

(2) There is no record of any finding by the FTT that in HS's case the risk of absconding or reoffending
was low: see section B1.7 above. The OASys assessment was that the risk of harm to children and to the
public was medium: see section B1.5 above.

(3) What can be said is that the February 2017 FTT decision necessarily involved a finding that the risk of
absconding or reoffending could be satisfactorily managed by the taking of sureties and imposing
appropriate bail conditions.

(4) Satisfactory risk management by this method can only be put in place if HS has been detained.


-----

(5) Moreover, looking at the matter objectively, it seems to me to be important that if HS were to reoffend,
then repetition of his earlier offending would involve a very serious sexual offence on vulnerable children.

270. Next in this regard HS noted that it had not been until November 2017 that the hearing of HS's appeal
took place. While HS acknowledged that there was no fixed date for this hearing, HS said that a delay until
November 2017 before the hearing could take place was “entirely predictable”. In a context where reoffending, should it take place, will involve a very serious sexual offence on a vulnerable child, and the
most recent OASys report identified a medium risk to children, I do not consider that a predicted period of 8
months in detention is unreasonable in length.

271. HS noted that the March 2017 re-detention decision had originally been justified on the basis that
certification of his asylum claim prevented an in-country appeal. That, however, was not something which
the Home Secretary could rely on in circumstances where, once challenged, the certification was
withdrawn. So far as Lumba principle (2) is concerned, it seems to me that this is neither here nor there. As
indicated above, it does not seem to me that the period necessary to allow for an in-country appeal was
such as to make detention unreasonable.

272. Of overriding importance, as it seems to me, was the new information from the police and probation
service expressing serious concern about HS's release address. It is common ground that there is no
mechanism by which the Home Secretary could return to the FTT and ask it to review HS's bail. In those
circumstances, objectively, it was in my view plainly reasonable to re-detain HS on the footing that, subject
to any grant of bail, the period of detention involved was likely to be in the region of 8 months.

D4 Lumba principle (4): diligence and expedition

273. HS said that the Home Secretary had failed in three respects to act with reasonable diligence and
expedition to effect removal. The first respect was that the decision to certify HS's claim necessarily caused
delay since an in-country appeal could not be lodged until the certificate was withdrawn. The second was
that the Home Secretary had failed to file a bundle with the FTT which led to adjournment of the hearing
which had been fixed for 4 August 2017. Third, it was said that by reason of that adjournment or a
subsequent default a further case management review had to be fixed for early September. It seems to
me, however, that none of these defaults made any appreciable difference to the date on which the appeal
could be heard. The reason is that the Home Secretary, during the period from late April to late July 2017
was concerned that the 6 March asylum refusal was unsatisfactory and needed to be reconsidered. That
reconsideration resulted in the highly detailed 28 July asylum/deportation letter. Thus, as it seems to me,
even if there had been no certification, and no failing in relation to the lodging of a bundle in time for a 4
August hearing, such a hearing would have been impractical. It seems likely that replacement of the 6
March asylum refusal with the 28 July asylum/deportation letter is what resulted in the need for a case
management review in September. However there was no analysis in argument before me identifying
reasons why the 28 July asylum/deportation letter could and should have been prepared earlier than in fact
was the case.

D5 Conclusion on JR ground 2

274. For the reasons given above, I conclude that objectively there was no breach by the Home Secretary
of the Lumba principles.

E. JR ground 3: the AR policy

E1 JR ground 3: relevant aspects of the AR policy

275. In this section I describe, based on an account given by HS, relevant aspects of the AR policy. The
Home Secretary did not take issue with this account.

276. The AR policy replaced para 55.10 of EIG, which was previously the basis on which the Secretary of
State assessed the suitability for detention of persons with conditions or circumstances which made them
particularly vulnerable or made detention unsuitable. The general policy in Chapter 55 EIG, applicable to all
detainees includes for example a presumption in favour of release in all cases The AR policy adds to


-----

this and affords a greater level of protection to those recognised to be particularly vulnerable to harm in
detention.

277. The AR policy is primarily to be found in statutory guidance, laid before Parliament, namely the
[“Immigration Act 2016: Guidance on adults at risk in immigration detention”, August 2016 (“the AR](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
Statutory Guidance”). The Secretary of State has also published guidance for caseworkers, but that is
necessarily subsidiary to the AR Statutory Guidance which has Parliament's approval.

278. The AR Statutory Guidance requires the assessment of factors which I shall call “vulnerability risk
factors”. These are factors which are relevant to the vulnerability of detainees, and their suitability for
detention. The AR Statutory Guidance then requires the weighing of identified vulnerability risk factors
against what it calls “immigration factors”. Key passages from the AR Statutory Guidance are as follows,
first from an introductory section entitled “Purpose and background”:

1. This guidance specifies the matters to be taken into account in accordance with Section 59 of the
Immigration Act 2016 when determining the detention of vulnerable persons. ...

2. This guidance allows for a case-by-case evidence-based assessment of the appropriateness of the
detention of an individual considered to be at particular risk of harm in the terms of this guidance.

3. The clear presumption is that detention will not be appropriate if a person is considered to be “at risk”.
However, it will not mean that no one at risk will ever be detained. Instead, detention will only become
appropriate at the point at which immigration control considerations outweigh this presumption. Within this
context it will remain appropriate to detain individuals at risk if it is necessary in order to remove them. This
builds on the existing guidance and sits alongside the general presumption of liberty.

…

5. The processes set out in this guidance apply to all cases [except in certain modern slavery cases] in
which consideration is being given to detaining a potentially vulnerable individual in order to remove them.
They also apply to cases of individuals who are already in detention, though there are some differences in
the way in which these cases are managed.

279. The next section is headed “Principles” and comprises paragraph 6, which includes:

6. The main principles underpinning this guidance are:

￿ the intention is that fewer people with a confirmed vulnerability will be detained in fewer instances and
that, where detention becomes necessary, it will be for the shortest period necessary

￿ in each case, the evidence of [vulnerability] risk to the individual will be considered against any
immigration factors to establish whether these factors outweigh the [vulnerability] risk

￿ the greater the weight of evidence in support of the contention that the individual is at [vulnerability] risk,
the weightier the immigration factors need to be in order to justify detention

280. The AR Statutory Guidance then continues:

Who is an adult at risk?

7. For the purposes of this guidance, an individual will be regarded as being an adult at risk if:

￿ they declare that they are suffering from a condition, or have experienced a traumatic event (such as
trafficking, torture or sexual violence), that would be likely to render them particularly vulnerable to harm if
they are placed in detention or remain in detention;

￿ those considering or reviewing detention are aware of medical or other professional evidence, or
observational evidence, which indicates that an individual is suffering from a condition, or has experienced
a traumatic event (such as trafficking, torture or sexual violence), that would be likely to render them
particularly vulnerable to harm if they are placed in detention or remain in detention – whether or not the
individual has highlighted this themselves


-----

…

281. The next section of the AR Statutory Guidance is headed “Assessment of whether an individual
identified as being at [vulnerability] risk should be detained”. In this section para 9 of the AR Statutory
Guidance identifies three “levels” of evidence and the weight that should be afforded to it:

9. Once an individual has been identified as being at [vulnerability] risk, consideration should be given to
the level of evidence available in support and the weight that should be afforded to the evidence in order to
assess the likely risk of harm to the individual if detained for the period identified as necessary to effect
their removal:

￿ a self-declaration of being an adult at risk - should be afforded limited weight, even if the issues raised
cannot be readily confirmed. Individuals in these circumstances will be regarded as being at evidence level
1

￿ professional evidence (e.g. from a social worker, medical practitioner or NGO), or official documentary
evidence, which indicates that the individual is an adult at risk - should be afforded greater weight.
Individuals in these circumstances will be regarded as being at evidence level 2

￿ professional evidence (e.g. from a social worker, medical practitioner or NGO) stating that the individual
is at risk and that a period of detention would be likely to cause harm – for example, increase the severity
of the symptoms or condition that have led to the individual being regarded as an adult at risk - should be
afforded significant weight. Individuals in these circumstances will be regarded as being at evidence level
3.

282. Also in this section is paragraph 10:

10. Determinations from courts or tribunals about the credibility of a person's account or claims, or about
professional evidence, or credibility concerns arising from other sources, may be taken into account in
deciding the weight that should be afforded to evidence and could result in a reconsideration of the
evidence level into which the individual falls.

283. The next section, headed “Indicators of [vulnerability] risk”, comprises paras 11 and 12 of the AR
Statutory Guidance. Paragraph 11 gives a list of conditions or experiences which will indicate that a person
may be particularly vulnerable to harm in detention. This list includes (a) those suffering from a mental
health condition or impairment and (b) having been a victim of torture.

284. Paragraph 12 adds, among other things:

12. The above list is not intended to be exhaustive. … In addition, the nature and severity of a condition, as
well as the available evidence of a condition or traumatic event, can change over time.

285. In the next section, headed “Assessment of immigration factors”, para 13 of the AR Statutory
Guidance explains that, where vulnerability risk is identified, it will be necessary to balance that risk against
“immigration factors”. Paras 14 and 15 add:

14. The immigration factors that will be taken into account are:

￿ Length of time in detention – there must be a realistic prospect of removal within a reasonable period.
What is a “reasonable period” will vary according to the type of case but, in all cases, every effort should be
made to ensure that the length of time for which an individual is detained is as short as possible. In any
given case it should be possible to estimate the likely duration of detention required to effect removal. This
will assist in determining the risk of harm to the individual. Because of their normally inherently short
turnaround time, individuals who arrive at the border with no right to enter the UK are likely to be detainable
notwithstanding the other elements of this guidance

￿ Public protection issues – consideration will be given to whether the individual raises public protection
concerns by virtue of, for example, criminal history, security risk, decision to deport for the public good

￿ Compliance issues - an assessment will be made of the individual's risk of abscond, based on the
previous compliance record.


-----

15. An individual should be detained only if the immigration factors outweigh the [vulnerability] risk factors
such as to displace the presumption that individuals at risk should not be detained. This will be a highly
case specific consideration.

286. I add that the guidance for caseworkers included a section concerned with vulnerability risk factors
emerging after the point of detention. So far as material for present purposes, it included the following, with
paragraph numbers added by me in square brackets:

Factors emerging after the point of detention

Ongoing assessment

[1] Following the detention of any individual (including those regarded as being at risk) there should be an
ongoing assessment of [vulnerability] risk made by the caseworker throughout the period of detention
which will facilitate the identification of any emerging [vulnerability] risk, or changes to known [vulnerability]
risk factors.

[2] If any [vulnerability] risk factors emerge, or any existing [vulnerability] risk factors change, there should
be a formal review of the case, with a fresh consideration of the balance of [vulnerability] risk factors
against the immigration factors, as set out above.

[3] The emerging [vulnerability] risk factors may shift the balance to the extent that the [vulnerability] risk
factors outweigh the immigration factors. In these circumstances, the individual should be released from
detention on appropriate release conditions and their compliance monitored. Equally, a failure to remove
within the expected timescale might also tip the balance to the extent that release becomes appropriate,
though this is less likely if the individual's non-compliance has caused the failure to effect removal.

[4] As part of the induction process into immigration removal centres (IRCs) all detainees should have a
medical screening within 2 hours of their arrival and must be given an appointment with a GP within 24
hours of admission to an IRC. They will also have access to health care services throughout their stay in
detention.

[5] …

[6] Home Office staff may, however, be made aware if an individual's medical condition (or claimed medical
condition) through (in asylum claims) the asylum screening process in detention or (in both asylum and
non-asylum cases) a detainee directly informing a member of Home Office or detention facility staff of it. In
these cases, the information should be recorded as level 1 evidence, the appropriateness of detention
should be reviewed in the light of the new information, and healthcare staff in the detention facility
informed. Where appropriate, the individual should be advised to seek a medical opinion from the health
services available in the detention facility in which they are housed.

[7] If, once detained, new information comes to light which suggests that the individual presents an
indicator of [vulnerability] risk which is not necessarily medically-related (and which is therefore not brought
to the attention of the Home Office by the medical services in the detention setting), such as having been a
victim of sexual or gender-based violence, human trafficking or **_modern slavery, having a physical_**
disability, or being transsexual, detention should be reviewed in the light of the new information. If
supporting evidence is available, consideration should be given to the weight that should be afforded to
that evidence. Individuals self-declaring should be advised that they may provide supporting information if it
is available.

287. The guidance for caseworkers also noted that the purpose of Rule 35 of the Detention Centre Rules
is to ensure that particularly vulnerable detainees are brought to the attention of those with direct
responsibility for authorising, maintaining, and reviewing detention. The guidance summarised Rule 35 in
this way:

Rule 35 of the Detention Centre Rules 2001 sets out the requirement for doctors working in immigration
removal centres to report on any detained person:

- whose health is likely to be injuriously affected by continued detention or any conditions of detention


-----

     - who is suspected of having suicidal intentions

    - for whom there are concerns they may have been a victim of torture …

E2 Analysis of alleged breaches of the AR policy

288. The breaches of the AR policy relied on by HS are grouped under three broad headings. The first
concerns failure to apply the AR policy prior to the Rule 35 report. HS points out that as part of his asylum
claim he had given account of torture in Pakistan. This had the consequence that he fell within Level 1 for
the purposes of the AR policy. Nothing in the material before the court suggests that this was identified,
and taken account of, when reaching the March 2017 re-detention decision and in the period prior to
receipt of the first Rule 35 report on 8 April 2017.

289. I accept that HS's account of torture was a vulnerability factor with the consequence that HS fell
within level 1, and that this was overlooked. I do not, however, accept that overlooking HS's Level 1 status
had any causative effect. HS's asylum claim did not include professional evidence stating that a period of
detention would be likely to cause harm. In those circumstances, even if the 3 March detention minute had
specifically addressed HS's account of torture in his asylum claim, I have no doubt that the factors requiring
detention, in particular the concerns about the release address, would have been regarded as outweighing
this vulnerability factor.

290. Second, HS submits that the first Rule 35 response was seriously inadequate and contained
numerous legal errors, any one of which was sufficient to make it fundamentally flawed. One such “legal
error” was said to be that the response treated HS as Level 2, whereas “this was a Level 3 risk where the

[doctor] had indicated that detention was detrimental” to HS. This assertion was emphatically denied by the
Home Secretary.

291. No elaboration was given in opening oral submissions for HS. In reply submissions, however,
reliance was placed on a passage in the judgment of Mr Justice Burnett in R. (EO) v Secretary of State for
_the Home Department [2013] EWHC 1236 (Admin) at paragraph 59:_

Those who have suffered torture in the past are disproportionately adversely affected by detention. That is
why the Secretary of State will normally detain those in respect of whom there is independent evidence of
torture only in very exceptional circumstances.

292. This citation does not assist HS. It will not necessarily be the case that a past experience of torture
will have the consequence that a period of detention would be likely to cause harm. It is no doubt for that
reason that under the AR Statutory Guidance Level 3 is achieved only where there is professional
evidence to this effect.

293. I have set out material parts of the first Rule 35 report in section B4.6 above. Nowhere in that report
is there any statement that detention was having, or would be likely to have, a detrimental effect on HS's
mental health. In these circumstances the first Rule 35 response rightly categorised HS as Level 2.

294. The remaining criticisms of the first Rule 35 response have more force. The Home Secretary accepts
that the first Rule 35 response proceeded on a mistaken premise that the “only barrier” to HS's removal
was the outstanding judicial review concerning certification of HS's asylum claim – when two days earlier
the Home Secretary's acknowledgment of service stated that certification would be withdrawn. The first
Rule 35 response said that there was nothing to demonstrate that HS would comply with any restrictions
placed on him, whereas HS had fully complied with restrictions prior to his trial and with the FTT bail
conditions. The first Rule 35 response assumed, plainly unjustifiably, that past offending in and of itself
showed a future risk. There was no reference to the enhanced presumption, arising from Level 2 status,
that detention was inappropriate.

295. These flaws in the first Rule 35 response are lamentable. As with the first breach of the AR policy,
however, it does not seem to me that they are material. The concerns arising in relation to the release
address were so serious that there can, in my view, be no doubt that it was right to ensure that HS was
subject to a regime under which he was detained subject to any future grant of bail, and it was right to
l d th t b il ld t b t d til th ti f t l dd


-----

296. The third breach relied on by HS was an allegation that applicability of the AR policy to HS was not
kept under review. I am not persuaded that there was a failure by the Home Secretary in this regard. I note
that on 28 June 2017 Dr Fletcher increased HS's mirtazapine dosage to 45mg daily. There is nothing to
suggest that the Home Secretary was informed of this at the time, or that there was any notification of
anything else prior to the second Rule 35 report, to indicate that detention was harming HS's mental health.

297. In oral reply submissions for HS it was said that HS's vulnerability status ought to have been
reconsidered at each detention review. I would agree if at the time of any such review there was reason to
think that there had been or might be a change in HS's vulnerability factors or the weight to be given to
those factors. This leads to the question whether, at the time of the detention reviews on 28 April, 26 May,
23 June, 24 July and 21 August, Home Office officials had reason to think that there had been or might be
a change in HS's vulnerability factors or the weight to be given to those factors? On the material before the
court, the answer to that question is, “No”.

E3 Conclusion on JR ground 3

298. For the reasons given above judicial review ground 3 is unsuccessful.

F. JR ground 4: reasons for detention

F1 JR ground 4: the true reason principle

299. In this section I deal with HS's complaint that his detention was unlawful because incorrect reasons
were given for that detention. In oral submissions HS sought to add a further contention that he ought to
have been warned of those reasons in advance so that he could respond and thereby show that detention
would not be necessary. For reasons given in section F4 below I need not consider whether HS should be
given permission to rely upon this new contention.

300. Judicial review ground 4 involves the application of principles as to the giving of reasons for arrest. It
is not disputed that these principles apply to detention under paragraph 2(3) of Schedule 3.

301. At common law, subject to qualifications which do not arise in the present case, a person arresting
another must inform that other in substance of the true reason for arrest. I shall refer to this as “the true
reason principle”. The great importance of this principle was stressed in Christie v Leachinsky [1947] AC
573by Viscount Simon, with whom Lords Thankerton, Macmillan, Simmonds and du Parcq agreed.

302. Viscount Simon's speech added at p. 587 an additional proposition: the arresting person is not
entitled to give a reason which is not the true reason.

303. Lord Simmonds, with whom Lords Thankerton and Macmillan agreed, said at p. 591:

Putting first things first, I would say that it is the right of every citizen to be free from arrest unless there is in
some other citizen, whether a constable or not, the right to arrest him. And I would say next that it is the
corollary of the right of every citizen to be thus free from arrest that he should be entitled to resist arrest
unless that arrest is lawful. How can these rights be reconciled with the proposition that he may be arrested
without knowing why he is arrested? … Is citizen A. bound to submit unresistingly to arrest by citizen B. in
ignorance of the charge made against him? I think, my Lords, that cannot be the law of England. Blind,
unquestioning obedience is the law of tyrants and of slaves: it does not yet flourish on English soil.

304. HS says that the same obligations arise under article 5(2) of the European Convention on Human
Rights. He adds that they also arise because the Home Secretary's own policy in EIG 55.6 provided for the
giving of written reasons at the time of detention and at regular intervals during detention. It is not
necessary to examine these separate legal bases for judicial review ground 4. The reason is that on
aspects relevant for present purposes neither side suggests that they involve additional obligations to
those identified above.

305. I consider that there is a single question which it is appropriate for me to decide. This is whether HS's
re-detention on 6 March was unlawful because it was in breach of the principle identified above. If it did not
breach the true reason principle, then HS has no claim to damages under this head. If it did breach that


-----

principle then, unless they can be agreed, there must be an assessment of damages. At that assessment
factual questions, and associated legal questions, may arise. Such questions may include whether and if
so when HS was informed as to the true reason for detention. They may also include whether and if so
when, in the absence of information from the Home Secretary, HS independently became aware of the true
reasons, and whether in those circumstances his detention ceased to be unlawful. Similarly such questions
may include whether there may be a defence if it be the case that provision of the true reason would have
made no difference to HS, and, if in law there is such a defence, whether this was such a case. Such legal
questions as may arise in these respects are in my view best determined in the context of facts found by
the court as part of the assessment process.

F2 The true reason: concerns about the Halesowen address

F2.1 The new information, what it made imperative, & for how long

306. To my mind it is as plain as a pikestaff that the true reason for re-detention was new information that
persons linked to the Halesowen address had convictions for sexual offences and that other criminal
behaviour was perpetrated by HS's associates in the area. It was that new information that led the police
and the probation officer to advise that the Halesowen address was not suitable as a bail address for HS:
see section B2.1 above.

307. This new information gave cause for grave concern. It would have been astonishing if it had not
prompted swift action by the Home Office. Lartey 1 give Mr Lartey's account of receipt of the new
information, and continues:

10. I reviewed the matter taking into account the new information received from [the probation officer].
Upon my review, I considered it necessary to re-detain [HS] based on the risk of harm to the public. …

308. Lartey 1 identifies one reason only for concern about risk to the public at this stage: the new
information. In the re-detention minute, when making his recommendations in paragraph 12, Mr Lartey put
this at the forefront. As set out in section B2.2 above, paragraph 12[2] noted that the Home Office had
been advised of “reservations about the address not being suitable”. This was clearly a reference to the
new information.

309. Thus the new information was crucial to the justification for recommending detention. Indeed Mr Larty
made plain not only that the new information made it “imperative” for HS to be re-detained, but also that
detention would only be required during such period as concerns about HS's bail address persisted. In this
regard the final sentence of paragraph 12[2] stated:

… it is imperative for him to be re-detained until such a time as he can provide an appropriate address to
be released to.

310. The quality assured officer's comments by Ms Luff (also recorded in section B2.2 above) similarly put
the new information at the forefront: see paragraphs [2] and [3] of those comments as set out in section
B2.2 above.

311. There was no other reason which caused Mr Lartey to recommend re-detention. Section 7 of the redetention minute referred to a high risk of absconding. However it is clear from paragraph 12[2] that if the
Halesowen address had been, as previously thought, an appropriate bail address then the risk of
absconding would not have resulted in re-detention. Paragraph 12[3] of the re-detention minute noted that
HS's asylum application had been concluded and certified. It did not suggest that the resulting imminence
of HS's removal was such as to warrant detention. Paragraphs 12[3] and [5] made reference to further
steps to be taken to proceed with the ETD application. There was, however, no suggestion by Mr Lartey
that re-detention was desirable for that purpose. Paragraph 12[4] expressly stated that what outweighed
the presumption of liberty was “the imperative to protect the public from the risk of harm and re-offending”.
This was clearly a reference back to paragraph 12[2].

F2.2 Was the true reason communicated to HS on 6 March 2017?


-----

312. The Home Secretary's skeleton argument conceded that HS was not initially told about the new
information. However it was submitted that the substance of the new information was sufficiently
communicated to HS by checking box e and box 12 on form IS.91R, which was given to HS on 6 March
2017.

313. As set out in section 3.3 above, checking box e on form IS.91R informed HS that his release was not
considered conducive to the public good. This was true, so far as it went, but it did not go very far.
Checking box 12 told HS that a factor in reaching this decision was his “character, conduct or
associations”. This was far too broad a range of options to give HS much useful information.

314. There is a stark contrast between the detention minute and the completed form IS.91R. As I have
noted above, it is clear from the detention minute that the true reason for re-detention was new information
that persons linked to the Halesowen address had convictions for sexual offences and that other criminal
behaviour was perpetrated by HS's associates in the area. Form IS.91R gave no space to say this. It may
be speculated that, faced with the limitations of the form, whoever was filling it in may have felt that
checking box 12 was the best that could be done. In my view Form IS.91R, if it is still in the format used in
March 2017, needs to be reconsidered: in order to comply with the true reason principle it may be
necessary to do more than check boxes. At the very least in the present case what was needed was to add
something along the lines of “Your current bail address is at a location where you are associating with
sexual and other criminal offenders.”

F2.3 Request not to share the new information with HS

315. The probation officer asked the police and the Home Office not to share the new information with HS.
As set out in section B2.1 above, the probation officer's email of 15 February 2017 put the request in this
way:

This information is not to be shared with [HS] at this stage as it may instigate him to abscond.

316. The Home Secretary advanced a submission that this could be a relevant factor justifying the
omission in form IS.91R to set out the new information. However I do not need to consider whether in law a
request to keep intelligence confidential might give rise to a qualification to the true reason principle. In my
view the submission necessarily fails on the facts. The request was only not to share the new information
“at this stage”. The concern was that on realising that the police were aware of these matters HS might
abscond. Once HS had been detained, however, there was no longer a risk of absconding, and nothing in
that concern would warrant the failure to tell HS the true reason for his detention.

F3 Other breaches of the true reason principle

317. The Home Secretary accepts that checked boxes 7 (previous failure/refusal to leave the UK when
required) and 10 (personal direction of the Secretary of State) were incorrect. It was submitted that
checking box 6 (no satisfactory evidence of identity, nationality or lawful basis to be in the UK) was justified
because HS had previously not co-operated with the ETD process. I doubt whether any such noncooperation falls within the wording of box 6. It was presumably considered by the Home Secretary, once
the asylum claim had been rejected, that HS had not produced evidence of a lawful basis to be in the UK.
There is no evidence that this played any material part in deciding to re-detain HS. In any event, for the
reasons given in section F2.1 above, difficulties with the ETD process did not form any part of Mr Lartey's
reasons for recommending detention, and there is no evidence of anyone else concluding that they
warranted detention. The same is true of the assertion, by checking box c, that HS had been detained
because his removal was imminent.

318. The giving of each of these untrue reasons was a breach of the true reasons principle: see Viscount
Simon's additional proposition cited in section F1 above. Any issue as to whether these breaches give rise
to additional claims for damages must be decided as part of the assessment process.

F4 Conclusion on JR ground 4


-----

319. For the reasons given above judicial review ground 4 succeeds. HS's re-detention on 6 March 2017
was in breach of the true reasons principle, and for that reason was unlawful. It is accordingly unnecessary
for me to consider whether I should allow HS to argue that his re-detention was additionally unlawful
because he was not given advance warning of the concerns which led to his re-detention.

G. Overall conclusion

320. While HS's first three grounds for seeking judicial review fail, his fourth ground succeeds. I ask
counsel to seek to agree consequential orders. Unless there is good reason to the contrary, those orders
should include a transfer to the Central London County Court for that court to give directions for the
assessment of damages.

**End of Document**


-----

