# *R v Ginar [2023] All ER (D) 23 (Oct)

[2023] EWCA Crim 1121

Court of Appeal, Criminal Division

EnglandandWales

Vice-President Of The Court Of Appeal, Criminal Division, Lord Justice Holroyde, Mr Justice Jeremy Baker, Mrs
Justice Lambert DBE

26 September 2023

**SENTENCE – ATTEMPTING TO ARRIVE IN UK WITHOUT VALID ENTRY CLEARANCE – GUIDANCE**
Abstract

_The Court of Appeal, Criminal Division, gave guidance on the sentencing of adult defendants for attempting to_
_arrive in the UK without valid entry clearance, contrary to_ _[s 24(D1) of the Immigration Act 1971 (IA 1971) (the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)_
_[offence). The offence had recently been created by amendments to IA 1971, and there was no previous judgment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_by the present court concerning it. The defendant, who was Turkish, and over 50 other foreign nationals, had been_
_passengers on a rigid inflatable boat which had been intercepted by a UK Border Force vessel as it had sailed from_
_France into UK territorial waters. The defendant had pleaded guilty (in the magistrates' court) to the offence_
_contrary to_ _[IA 1971 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_ _[s 1 of the Criminal Attempts Act 1981, and he had been sentenced to 8 months'](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y129-00000-00&context=1519360)_
_imprisonment. Among other things, the court ruled that: (i) the seriousness of the offence was such that the custody_
_threshold would generally be crossed and an appropriate sentence, before considering any additional culpability or_
_harm features, any aggravating and mitigating factors and any credit for a guilty plea, would be of the order of 12_
_months' imprisonment; (ii) a key feature of culpability inherent in the offence, save in very exceptional_
_circumstances, was that the defendant would have known that he had been trying to arrive in the UK in an unlawful_
_manner; (iii) culpability would be increased if the defendant had played some part in the provision or operation of_
_the means by which he had sought to arrive in the UK, for example by piloting a vessel, rather than being a mere_
_passenger or if he had involved others in the offence, particularly children, or if he had been seeking to enter in_
_order to engage in criminal activity (for example by joining a group engaged in modern slavery or trafficking); (iv)_
_culpability would be reduced if the defendant had genuinely intended to apply for asylum on grounds which were_
_arguable; and (v) the offence would be mitigated by an absence of recent or relevant convictions, good character,_
_young age or lack of maturity, mental disorder or learning disability, or the fact that the defendant had become_
_involved in the offence due to coercion or pressure. The court rejected the submission that the recorder had erred in_
_treating the defendant's immigration history as an aggravating factor, in circumstances where his repeated efforts to_
_enter and remain in the UK had made it significantly more serious that he had again attempted to arrive in the UK_
_on the present occasion. Accordingly, the court held that the resultant sentence of 12 months' imprisonment,_
_reduced to 8 months' imprisonment after giving credit for the guilty plea, was not manifestly excessive; and the_
_defendant was refused leave to appeal against sentence._
Digest

The judgment is available at: [2023] EWCA Crim 1121

**Background**


-----

In 2005, the defendant, who was Turkish, travelled to the UK. He was refused leave to enter. Subsequently, his
asylum application was refused and an appeal against the refusal was dismissed. However, the defendant
remained in the UK.

In 2013, the defendant's application for leave to remain was refused, with no right of appeal. His application for
permission to apply for judicial review was dismissed.

In 2015, the defendant left the UK, and in 2017, he made an unsuccessful application for entry clearance.

In June 2023, the defendant and more than 50 other foreign nationals were passengers on a rigid inflatable boat
which was intercepted by a UK Border Force vessel as it sailed from France into UK territorial waters.

The defendant was detained. He made no comment when interviewed under caution. Subsequently, he pleaded
guilty, before a magistrates' court, to attempting to arrive in the UK without valid entry clearance (the offence),
[contrary to s 1 of the Criminal Attempts Act 1981 (CAA 1981) and s 24(D1) of the Immigration Act 1971 (IA 1971).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y129-00000-00&context=1519360)

[The offence was of recent origin, having been created by amendments to IA 1971, introduced by the Nationality and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
_[Borders Act 2022 (NBA 2022), which had come into effect in June 2022.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_

_[IA 1971 s 24, as amended, created a number of offences of illegal entry into the UK. Section 24(D1) provided that:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)_
'A person who (a) requires entry clearance under the immigration rules, and (b) knowingly arrives in the United
Kingdom without a valid entry clearance, commits an offence.'

The defendant was committed to the Crown Court for sentence, where he was sentenced to eight months'
imprisonment.

The Registrar of Criminal Appeals referred the defendant's application for leave to appeal against sentence to the
present court.

**Issues and decisions**

(1) The court gave guidance on the sentencing of adult defendants for attempting to arrive in the UK without valid
[entry clearance, contrary to IA 1971 s 24(D1).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)

The defendant submitted that: (i) the recorder had erred in principle in treating the defendant's history of previous
immigration and asylum applications, which had not involved any criminal offence, as an aggravating factor. He
argued that the previous history had arisen at a time when it had not been a criminal offence to arrive at a
designated port without valid entry clearance. Accordingly, his prior experience of the asylum and immigration
system could not properly have been treated as an aggravating feature of the offence, even if, in principle, such a
history might have had relevance in other circumstances.

It was appropriate to give guidance, in general terms, as to the sentencing of adult defendants for the present type
of offence. Sentencers would need to follow the Sentencing Council's General Guideline; the Imposition Guideline,
particularly if considering suspension of a prison sentence; and where appropriate, the guideline in relation to
reduction in sentence for a guilty plea (see [15] of the judgment).

[Applying that approach to an offence contrary to IA 1971 s 24(D1), the following considerations were relevant. First,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)
the statutory maximum sentence for the new offence was four years' imprisonment. So too was the maximum
sentence for an offence under s 24(B1) of knowingly entering the UK without leave. Before the amendments to
which the court had referred, the maximum penalty for the predecessor of that offence had been six months'
imprisonment. It was apparent that Parliament had regarded that previous level of sentence as insufficient, both for
the existing offence of entering without leave and for the new offence of arriving without a valid entry clearance. The
four-year maximum was also longer than some other offences which might be committed in an immigration and
asylum context (see [17] of the judgment).


-----

However, it was significantly shorter than the maximum sentence of 10 years' imprisonment for an offence of
possessing a false identity document with intent, contrary to _[s 4 of the Identity Documents Act 2010 (IDA 2010).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:51SF-9SP1-DYCN-C29V-00000-00&context=1519360)_
Use of a false identity document would not ordinarily cease at the border, but would facilitate life in the UK
thereafter. It would also tend to undermine the passport system generally. Therefore, the present offence was
inherently less serious than an identity document offence of the kind for which the present court in R v Kolawole

_[[2004] All ER (D) 439 (Nov) had indicated as attracting a sentence in the range of 12-18 months, even on a guilty](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TXB-5HC0-Y96Y-H3T0-00000-00&context=1519360)_
plea and even for a person of previous good character (see [18] of the judgment).

Second, there were no previous judgment of the present court concerned with the present type of offence. Third,
there was no offence-specific guideline for an offence which was so closely analogous as to be helpful (see [18],

[19] of the judgment).

Fourth, the predominant purpose of sentencing in cases of the present nature would generally be the protection of
the public. Deterrence could carry only limited weight as a distinct aim in the sentencing of those who had travelled
as passengers in a crossing, such as that on which the defendant had embarked. The circumstances of those who
committed offences of that kind, as opposed to those who organised them, would usually be such that they were
unlikely to be deterred by the prospect of a custodial sentence if caught. The present court knew of no evidence or
research which indicated the contrary (see [20] of the judgment).

The following considerations were relevant as to culpability and harm. There was legitimate public concern about
breaches or attempted breaches of border control, and the present type of offence, which was prevalent, would
usually result in significant profit to organised criminals engaged in people smuggling. A key feature of culpability
inherent in the offence, save in very exceptional circumstances, was that the defendant would know that he was
trying to arrive in the UK in an unlawful manner: if it were otherwise, he would take the cheaper and safer
alternative route which would be available to him. The harm inherent in the present type of offence was not simply
the undermining of border control, but also, and importantly, the risk of death or serious injury to the defendant
himself and to others involved in the attempted arrival, the risk and cost to those who intercept or rescue them, and
the potential for disruption of legitimate travel in a busy shipping lane (see [22] of the judgment).

Those considerations led to the conclusion that the seriousness of the present type of offence was such that the
custody threshold would generally be crossed and that an appropriate sentence, taking into account the inherent
features which the present court had mentioned, but before considering any additional culpability or harm features,
any aggravating and mitigating factors and any credit for a guilty plea, would be of the order of 12 months'
imprisonment (see [23] of the judgment).

Culpability would be increased if the defendant had played some part in the provision or operation of the means by
which he sought to arrive in the UK, for example by piloting a vessel, rather than being a mere passenger; or if he
had involved others in the offence, particularly children; or if he had been seeking to enter in order to engage in
criminal activity (for example by joining a group engaged in **_modern slavery or trafficking). Culpability would be_**
reduced if the defendant had genuinely intended to apply for asylum on grounds which were arguable (see [24] of
the judgment).

Consideration of aggravating and mitigating factors had to be a case-specific matter, but the following might
commonly arise and would call for either an upwards or downwards adjustment of the provisional sentence. The
offence would be aggravated by relevant previous convictions, by a high level of planning going beyond that which
was inherent in the attempt to arrive in the UK from another country, and by a history of unsuccessful applications
for leave to enter or remain or for asylum. Even if the previous attempts had not involved any criminal offence, the
history of previous failure made it more serious that the defendant had resorted to an attempt to arrive without valid
entry clearance. The weight to be given to that factor would depend on the circumstances of the case (see [25] of
the judgment).

The offence would be mitigated by an absence of recent or relevant convictions, good character, young age or lack
of maturity, mental disorder or learning disability, or the fact that the defendant had become involved in the offence
due to coercion or pressure (see [26] of the judgment).


-----

Cases of the present nature would often have powerful features of personal mitigation, to which appropriate weight
had to be given on a fact-specific basis. The circumstances which were relied on as arguable grounds for claiming
asylum, such as the defendant seeking to escape from persecution and serious danger, were likely also to mitigate
the offence of arriving in the UK without a valid entry clearance. Some defendants might have been misled as to
what would await them in the UK if they paid large sums of money to the criminals who offered to arrange their
transport. Some might have suffered injury or come close to drowning in crossing in a dangerously overcrowded
vessel. It would be for the sentencer to evaluate what weight to give to circumstances of that nature in a particular
case (see [27] of the judgment).

_R v Kolawole_ _[[2004] EWCA Crim 3047, [2004] All ER (D) 439 (Nov) distinguished](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P55M-00000-00&context=1519360)_

(2) Whether the sentence was manifestly excessive in all the circumstances of the case.

It was implicit in the recorder's sentencing remarks that she had taken a provisional sentence after trial of 12
months, and had then treated the aggravating and mitigating factors as, in effect, balancing one another out. There
was no arguable ground for challenging either her approach or her decision. The provisional sentence had been in
accordance with the view which the present court had expressed. The submission that the recorder had made an
error of principle in treating the defendant's immigration history as an aggravating factor was rejected. His repeated
efforts over a period of years to enter and remain in the UK country made it significantly more serious that he had
again attempted to arrive in the UK on the present occasion. There were cogent points made on his behalf in
mitigation, but the recorder had been entitled to reach the conclusion she had as to the balancing of factors. The
resultant sentence of 12 months' imprisonment, reduced to 8 months' imprisonment after giving credit for the guilty
plea, could not be said to be manifestly excessive (see [28] of the judgment).

For those reasons, the application failed and would be refused (see [29] of the judgment).

Andreas O'Shea for the defendant.

A Johnson and B Wild for the Crown.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

