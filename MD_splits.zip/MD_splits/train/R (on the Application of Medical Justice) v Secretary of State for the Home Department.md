# R (on the Application of Medical Justice) v Secretary of State for the Home
 Department [2024] EWHC 38 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Linden

12 January 2024Judgment

**Shu Shin Luh and Laura Profumo (instructed by Wilson Solicitors LLP) for the Claimant**

**Julie Anderson (instructed by the Government Legal Department) for the Defendant**

Hearing dates: 29 and 30 November 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 12[th] January 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

THE HONOURABLE MR JUSTICE LINDEN

**MR JUSTICE LINDEN:**

**INTRODUCTION**

1. Section 59 of the Immigration Act 2016 requires the Defendant to issue guidance specifying the matters
to be taken into account when deciding whether a person would be “particularly vulnerable to harm” if they
were to be detained for immigration purposes, and “whether [such a person] should be detained or remain
_in detention”. The guidance is required to be laid before Parliament in draft and is subject to approval by_
negative resolution. Version 1 of that guidance – _[“Immigration Act 2016: Guidance on adults at risk in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
_immigration detention” (“the Statutory Guidance”) was laid before Parliament in August 2016 and came into_
effect on 12 September 2016. The current version is dated May 2021.

2. The Statutory Guidance is concerned with the detention of an individual for the purposes of their
removal from this country. It states that “the clear presumption is that detention will not be appropriate if a
_person is considered to be “at risk”. A person will fall into the “at risk” category if they declare that they are_
suffering from a condition or have experienced a traumatic event (such as trafficking, torture or sexual
violence) which would be likely to render them particularly vulnerable to harm if they were detained; or if
those who are considering or reviewing their detention are aware of evidence that this is the case.

3. But, under the Guidance, the weight which will be afforded to the evidence that the person is an adult at
risk – the level of risk - will depend on whether there is “professional evidence (e.g. evidence from a social
_worker, medical practitioner or NGO)” that they are an adult at risk. Professional evidence which is_
provided by a person who is not acting on behalf of the Home Office has been called a medico-legal report
(“MLR”) in these proceedings but is also referred to in the documents as an _“external medical report”._
S bject to compliance ith certain q alit standards hich are set o t in non stat tor g idance _“Ad lts_


-----

_at risk in immigration detention” (“the Caseworker Guidance”) - the effect of the Statutory Guidance is that_
an external medical report which shows that the person under consideration is an adult at risk will place
them at risk level 2. An external report which shows that they are an adult at risk and that a period of
detention would be likely to cause harm to them will place them at Level 3. The strength of the presumption
against detention increases with these classifications and the Caseworker Guidance specifies the
circumstances in which that presumption may be rebutted. These are significantly more limited for Level 3
cases and less so for Level 1 cases.

4. This Claim arises because, in 2022, the Defendant issued a document called _“Interim Guidance:_
_Requesting a second opinion for an external medical report/Medico-Legal Report” (“the Second Opinion_
Policy”). With certain exceptions, and subject to certain conditions as to timescales, this requires Home
Office caseworkers to seek a second opinion from a Home Office contracted professional on an external
medical report or MLR which is submitted in relation to a person who is in immigration detention. The effect
of this is that there will be a delay in the determination of the person's risk level and, all things being equal,
any decision to release them. Moreover, a case which, for example, would have been designated Level 3
under the Statutory Guidance in the light of their MLR, may well not be if the second opinion disputes what
is said in the external report. A person who would have been released under the Statutory Guidance on the
basis of their MLR therefore will not necessarily be.

5. The Claimant is a charity which, through a network of doctors, facilitates the provision of medical
assessments, advice and assistance to people who are detained in immigration removal centres. It also
conducts research into issues which affect vulnerable people and victims of torture who are in immigration
detention, and it seeks to influence policy on these issues through dialogue with relevant state bodies
including the Home Office and, occasionally, through litigation.

6. In broad terms, the Claimant's case is that the Second Opinion Policy contradicts the Statutory
Guidance, which was approved by Parliament, and undermines the statutory purpose of section 59 of the
2016 Act. It is therefore an impermissible watering down of the Statutory Guidance which will result in
people who ought to be released from immigration detention in the light of an MLR being released
significantly later than required by that Guidance, or not released at all. The Claimant also contends that
the Defendant was under a common law duty to consult it about the introduction of the Second Opinion
Policy but did not do so.

7. The Defendant denies that the Second Opinion Policy is unlawful. His case is that this Policy is
consistent with the Statutory Guidance and does not contradict it or undermine the purpose of section 59.
The argument that it will result in delays to the release of detainees and/or that detainees who would have
been released under the Statutory Guidance will now not be released is a prediction of a statistical
outcome rather than based on the terms of the Second Opinion Policy. It is therefore precluded by the
decision of the Supreme Court in _R(A) v Secretary of State for the Home Department_ _[2021] UKSC 37,_

[2021] 1 WLR 3931. The Defendant accepts that there was no consultation with the Claimant about the
introduction of the Second Opinion Policy but he denies that he was under any duty to do so.

**THE ISSUES**

8. The Claimant's renewed application for permission was granted by Mrs Justice Heather Williams by
Order dated 25 July 2023. She also held that the Claimant has standing to bring this Claim.

9. Williams J gave permission in respect of the following Grounds of challenge which, in the interests of
clarity, I will quote given that the Claimant's case in relation to Grounds 1 and 2 underwent alteration
between the Statement of Facts and Grounds and the permission hearing and, indeed, in the course of the
hearing before me. At [2023] EWHC 2848 (Admin) [4] Williams J said that the Grounds were:

i) _“that the second opinion policy is unlawful as it is contrary to and frustrates the statutory purposes of_
_s.59 of the 2016 Act;_

ii) _the policy is unlawful as it contradicts the [Statutory Guidance] and undermines statutory protections_
_concerning the detention of adults at risk which were approved by Parliament;_


-----

iii) there was an unlawful breach of the duty to consult with the claimant before the policy was finalised and
_published. The duty to consult, which is disputed, is said to arise from an established practice of_
_consultation and/or because a failure to consult would lead to conspicuous unfairness.”_

10. As one would expect, this accurately reflects the Claimant's case as set out in Ms Luh's skeleton
argument for the permission hearing dated 17 July 2023 (see for example [3], [11] and [13]-[30] of that
document). An Agreed List of Issues was also helpfully prepared for the hearing before me which said that
the issues in relation to Grounds 1 and 2 were:

i) “Do the terms of the Defendant's Second Opinion Policy contradict the terms of the [Statutory Guidance]
_so as to render it unlawful? (Ground 2)_

[ii) Do the terms of the Second Opinion Policy undermine the statutory purpose of section 59 Immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C41M-00000-00&context=1519360)
_Act 2016 as to render it unlawful? (Ground 1)”_

11. Ms Luh's skeleton argument, dated 7 November 2023, also presented the case on the basis that these
were the issues in relation to Grounds 1 and 2. Moreover, as I understood Ms Anderson's position, she
accepted that if either of these questions was answered in the Claimant's favour, the Claim would succeed
on the relevant Ground. Her concern was that the case should not be decided on a wider or different basis
for reasons of fairness and because of potentially wider implications if it was. I return to this concern
below.

12. At [12]-[13] of her judgment, Williams J also noted criticisms of the Claimant's witness statements
which had been made by Mrs Justice Lang when refusing permission on the papers on 23 March 2023.
Whilst these statements covered “perfectly proper subjects, including the standing of Medical Justice and
_the alleged established practice of consultation”, they also include comment and opinion which Lang J said_
would not be admissible as expert opinion evidence. Williams J added that she did not find the Claimant's
witnesses' comments on the merits of the Second Opinion Policy to be of assistance. She understood their
wish to provide an element of context but she stressed that the proceedings were not a forum for debating
the merits of the Policy.

13. I respectfully agree that the issues for determination do not call for the Court to adjudicate the merits or
demerits of the Statutory Guidance or the Second Opinion Policy. Both parties agreed on this point and
they presented the case accordingly. Grounds 1 and 2 require consideration of the text of the Statutory
Guidance and the Second Opinion Policy with a view to deciding whether they are consistent with each
other and with the purpose of section 59 of the 2016 Act. Ground 3 requires consideration of whether, on
the evidence, there was a duty to consult the Claimant in relation to the Second Opinion Policy. I am not
called upon to decide whether there is a problem with the quality of medical opinions and/or care provided
to people in immigration detention by professionals engaged by the Home Office. Nor is it relevant for me
to ask whether there is an overreliance by immigration detainees on external medical reports provided by
professionals who may be sympathetic to their position. Nor do I need to consider whether the Defendant
was right or wrong to introduce a policy of seeking a second opinion prepared by doctors approved by the
Home Office and, if so, whether the approach under that Policy is sensible or flawed. I will therefore
express no opinion on these matters.

**RELEVANT HISTORIC CONTEXT**

14. Mr Justice Ouseley provided a very helpful account of the background to section 59 of the 2016 Act
and the Statutory Guidance in _R (Medical Justice) v Secretary of State for the Home Department_ _[2017]_
_EWHC 2461 (Admin) (“the Medical Justice case”) at [21]-[24]. Ms Idel Hanley - Policy, Research and_
Parliamentary Manager at the Claimant - also gave evidence on this subject in her witness statement,
dated 7 December 2022, in support of the Claim.

15. In short, in February 2015 the Home Office under the then Home Secretary, Ms Theresa May MP,
commissioned Mr Stephen Shaw CBE to review the appropriateness of its polices and practices in relation
to the welfare of people in immigration detention. This followed criticisms in court judgments and
inspectorate reports, particularly in relation to the detention of people with mental illness. In his report,


-----

which was published in January 2016, Mr Shaw developed the concept of “particular vulnerability” to harm
in detention i.e. susceptibility to physical or emotional harm, damage or injury. He recommended that the
existing categories of people who would be presumed unsuitable for detention should be expanded, and
that some of the qualifications to that unsuitability should be removed. There should also be recognition of
the dynamic nature of vulnerability in detention so that people who fell outside the specific categories might
nevertheless be identified as sufficiently vulnerable for their continued detention to be injurious to their
welfare.

16. As Ouseley J recorded at [23] of his judgment, a ministerial statement on 16 January 2016 accepted
Mr Shaw's recommendation to adopt a wider definition of people _“at risk” and said that the Government_
would:

_“introduce a new 'adult at risk' concept into decision-making on immigration detention with a clear_
_presumption that people who are at risk should not be detained, building on the existing legal framework._
_This will strengthen the approach to those whose care and support needs make it particularly likely that_
_they would suffer disproportionate detriment from being detained, and will therefore be considered_
_generally unsuitable for immigration detention unless there is compelling evidence that other factors which_
_relate to immigration abuse and the integrity of the immigration system, such as matters of criminality,_
_compliance history and the imminence of removal, are of such significance as to outweigh the vulnerability_
_factors.”_

17. These policy objectives were achieved by the enactment of section 59 of the Immigration Act 2016,
which required the publication of what became the Statutory Guidance, and by the promulgation of further
non-statutory guidance on these issues.

**GROUNDS 1 and 2**

**Section 59**

18. Section 59 of the Immigration Act 2016 provides as follows:

_“59 Guidance on detention of vulnerable persons_

_(1) The Secretary of State must issue guidance specifying matters to be taken into account by a person to_
_whom the guidance is addressed in determining—_

_(a) whether a person (“P”) would be particularly vulnerable to harm if P were to be detained or to remain in_
_detention, and_

_(b) if P is identified as being particularly vulnerable to harm in those circumstances, whether P should be_
_detained or remain in detention._

_(2) In subsection (1) “detained” means detained under—_

_[(a) the Immigration Act 1971,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

_[(b) section 62 of the Nationality, Immigration and Asylum Act 2002, or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-73D4-00000-00&context=1519360)_

_[(c) section 36 of the UK Borders Act 2007,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y01T-00000-00&context=1519360)_

_and “detention” is to be construed accordingly._

_(3) A person to whom guidance under this section is addressed must take the guidance into account._

_(4) Before issuing guidance under this section the Secretary of State must lay a draft of the guidance_
_before Parliament._

_(5) Guidance under this section comes into force in accordance with regulations made by the Secretary of_
_State._

_(6) The Secretary of State may from time to time review guidance under this section and may revise and_
_re-issue it._


-----

_(7) References in this section to guidance under this section include revised guidance.”_

**The Statutory Guidance**

19. The Statutory Guidance is somewhat repetitively drafted and, in any event, it is only necessary to refer
to the passages which matter for the purposes of the issues between the parties as to its interpretation.
The core issue in this regard was whether, as Ms Luh contended, the Statutory Guidance required the
Defendant to make a decision about the detention or continued detention of a person _“on the available_
_evidence” or whether, as Ms Anderson submitted, it permitted a decision on a person's risk level to be_
postponed pending further inquiries, including the seeking of a second opinion.

20. Under the introductory heading “Purpose and background” the Statutory Guidance explains, in a
passage on which Ms Luh relied, that:

_“1. This guidance specifies the matters to be taken into account in accordance with_ _[section 59 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C41M-00000-00&context=1519360)_
_Immigration Act 2016… This approach emerges from the Government's response (in a Written Ministerial_
_Statement of 14 January 2016) to the report by Stephen Shaw… The intention is that the guidance will, in_
_conjunction with other reforms referred to in the Government's response, lead to a reduction in the number_
_of vulnerable people detained and a reduction in the duration of detention before removal. It aims to_
_introduce a more holistic approach to the consideration of individual circumstances, ensuring that genuine_
_cases of vulnerability are consistently identified, in order to ensure that vulnerable people are not detained_
_inappropriately. The guidance aims to strike the right balance between protecting the vulnerable and_
_ensuring the maintenance of legitimate immigration control.” (emphasis added)_

21. The passage highlighted above is also reiterated in [6] as one of the “main principles underpinning the
_Statutory Guidance”:_

_“The intention is that fewer people with a confirmed vulnerability will be detained in fewer instances and_
_that, where detention becomes necessary, it will be for the shortest period”._

22. The key features of the Statutory Guidance are, in summary, as follows.

23. First, the Guidance applies to decisions about whether to detain a person for the purposes of their
removal and about whether the detention of a person should continue: [5].

24. Second, [2] states that:

_“This guidance allows for a case-by-case evidence-based assessment of the appropriateness of the_
_detention of an individual considered to be at particular risk of harm in the terms of this guidance”._

25. Third, [3] states that:

_“The clear presumption is that detention will not be appropriate if a person is considered to be “at risk”…_
_detention will only become appropriate at the point at which immigration control considerations outweigh_
_this presumption…[and detention]..is necessary in order to remove them”_

26. This is another _“main principle” of the Guidance: see, [6] 5[th] bullet point, and see [13] and [15] in_
particular.

27. Fourth, the concept of “an adult at risk” is defined at [7]. As noted above, in broad terms a person “will
_be regarded” as such if they declare that they are suffering from a condition or have experienced a_
traumatic event (such as trafficking, torture or sexual violence) which would be likely to render them
particularly vulnerable to harm if they were detained; or where those considering or reviewing the detention
of the person are aware of medical or other professional evidence, or observational evidence, which
indicates that they are particularly vulnerable to harm.

28. Fifth, [6] states, that another of the main principles underpinning the Guidance is that:

_“assessment of risk is based on the evidence available, ranging from a self -declaration of risk to_
_authoritative professional opinion. The level of evidence available dictates the level of evidence-based risk_
_into which any given individual will fall” (emphasis added)_


-----

29. In similar vein, [8] provides, so far as material:

_“8. On the basis of the available evidence, the Home Office will reach a view on whether a particular_
_individual should be regarded as being “at risk” in the terms of this guidance. If, on this basis, the individual_
_is considered to be an adult at risk, the presumption will be that the individual will not be detained.”_
(emphasis added)

30. Sixth, [9] of the Guidance then provides that:

_“9._ _Once an individual has been identified as being at riskconsideration should be given to the level of_
_evidence available in support and the weight that should be afforded to the evidence in order to assess the_
_likely risk of harm to the individual if detained for the period identified as necessary to effect their removal:”_
(emphasis added)

31. Three levels of risk or weight are then specified as follows:

_“• a self-declaration of being an adult at risk - should be afforded limited weight, even if the issues raised_
_cannot be readily confirmed. Individuals in these circumstances will be regarded as being at evidence level_
_1_

_• professional evidence (e.g. from a social worker, medical practitioner or NGO), or official documentary_
_evidence, which indicates that the individual is an adult at risk - should be afforded greater weight._
_Individuals in these circumstances will be regarded as being at evidence level 2_

_• professional evidence (e.g. from a social worker, medical practitioner or NGO) stating that the individual is_
_at risk and that a period of detention would be likely to cause harm – for example, increase the severity of_
_the symptoms or condition that have led to the individual being regarded as an adult at risk - should be_
_afforded significant weight. Individuals in these circumstances will be regarded as being at evidence level_
_3”_

32. Seventh, as to when external professional evidence might not be taken at face value or given full
weight, [10] says:

_“10. Determinations from courts or tribunals about the credibility of a person's account or claims, or about_
_professional evidence, or credibility concerns arising from other sources, may be taken into account in_
_deciding the weight that should be afforded to evidence and could result in a reconsideration of the_
_evidence level into which the individual falls.”_

33. Eight, at [11], there is then a list of conditions or experiences – for example, a mental health condition
or impairment, or being a victim of human trafficking or sexual or gender based violence - which will
indicate that a person may be particularly vulnerable. In the case of pregnancy it is specified that the
person will be regarded as at Level 3 risk if they fall into the relevant category. In relation to victims of
torture, the Statutory Guidance states that _“individuals with a completed Medico Legal Report from_
_reputable providers will be regarded as meeting level 3 evidence, provided the report meets the required_
_standards” (emphasis added). Consistently with Mr Shaw's recommendation, [12] states that this list is not_
exhaustive and the caseworker is reminded that the nature and severity of a condition, _“as well as the_
_available evidence of a condition or traumatic event, can change over time” (emphasis added)._

34. Ninth, [13] of the Guidance then says that, with a view to deciding whether the presumption against
detention has been rebutted:

_“any risk factors identified and evidence in support, will then need to be balanced against any immigration_
_control factors in deciding whether they should be detained”_

35. Tenth, under 3 headings, [14] then deals with the immigration control factors which are to be taken into
account in the balancing exercise. These are, in summary: the likelihood of removal within a reasonable
period; whether the individual's history gives rise to public protection issues; and the risk of them
absconding. There is also a requirement to consider whether there are alternatives to detention which will
address the immigration factors, and whether the individual would be willing to leave voluntarily as an
alternative to detention.


-----

**The Caseworker Guidance**

36. As Ms Anderson points out, the Statutory Guidance is not prescriptive as to outcome for any given
prospective or actual detainee. It contains a set of principles which are to be applied in making decisions
about detentions. For the purposes of applying those principles it defines an adult at risk, it defines 3 levels
of risk, it identifies the relevant potential countervailing factors in relation to the presumption against
detention and it then leaves the caseworker to make a judgement. The Statutory Guidance also says little
which is specific about the circumstances in which a MLR might be rejected, or given less weight.
However, these subjects are dealt with further and more prescriptively in the Caseworker Guidance. The
first version of this document, which sets out the three risk levels and their consequences in similar terms
to the current one, was published on 9 September 2016, very shortly after the first version of the Statutory
Guidance.

37. It is not necessary to recite the terms of the Caseworker Guidance in detail but I note that the effect of
being placed at a given level of risk is important. For example, it is said that “as a guide”:

i) In relation to Level 2 cases, the person should be considered for detention “only” if the date of removal is
fixed, or can be fixed quickly, is within a reasonable timescale and the individual has failed to comply with
reasonable voluntary return opportunities; or if the individual is being detained at the border pending
removal having been refused entry to the UK; or if they present a level of public protection concerns that
[would justify detention: for example, they are a “foreign criminal” as defined in the Immigration Act 2014; or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
if there is a relevant national security or other public protection concern; or if the evidence shows that they
are highly likely not to be removable unless detained.

ii) In relation to Level 3 cases, the person should be considered for detention “only” if removal has been
set for a date in the immediate future, there are no barriers to removal, escorts and any other appropriate
arrangements are (or will be) in place to ensure the safe management of their return and they have not
complied with voluntary or ensured return; or if they present a significant public protection concern, or they
have been subject to a 4 year plus custodial sentence, or there is a serious relevant national security issue
or they present a current public protection concern. “It is very unlikely that compliance issues, on their own,
_would warrant detention of individuals falling into this category.”_ (page 24 of 29 in version 9 of the
Caseworker Guidance).

38. There are also 4 pages of guidance on the subject of weighing the evidence and, in particular, the
evidence set out in any external medical report. In summary, this provides that there is a _“baseline_
_requirement” that the external medical report is by a qualified healthcare professional who is registered_
with the relevant healthcare regulator in the United Kingdom e.g. the General Medical Council or the Health
and Care Professions Council. The report must also list the healthcare professional's registration number,
qualifications and experience in the relevant field. If the baseline requirement is not satisfied, the report
should be rejected.

39. But if the baseline requirement is satisfied there is then a series of considerations or standards which
must be applied by the caseworker. Failure to meet any of them may contribute to the report being given
_“limited weight”. They include, for example:_

i) An explanation of the healthcare professional's understanding of what they are being asked to do, and
consideration of whether they have been led to reach specific conclusions by the adviser or firm who
commissioned the report.

ii) A list of the medical records and other documents which the healthcare professional has considered so
that the caseworker can see whether the assessment is well informed.

iii) The circumstances in which any medical examination took place and whether, for example, it was face
to face or by video-link. The Caseworker Guidance provides that, other than in exceptional circumstances,
_“the report must be based on a face to face consultation”._

iv) Whether there was any language barrier between the healthcare professional and the detained person
and, if so, whether an interpreter was used.


-----

v) Whether the report is specific to the circumstances of the individual, as opposed to being based on
generic statements about the impact of detention, whether based on research or otherwise.

vi) Whether the healthcare professional has referred any concerns about the health of the detainee to the
onsite healthcare team, has taken into account treatment received or available in the detention centre and
has engaged with the question whether the person could be adequately cared for in detention.

**The “Detention: General Instructions”**

40. Ms Luh referred me to further detailed guidance in the form of _“Detention: General Instructions”_
(Version 3, dated 28 September 2023) and, in particular, passages in this document which deal with
reviews of detention. The General Instructions specify who may authorise the initial detention of a person
and they require reviews of the detention of an individual at specified intervals _“as a minimum”. The_
detainee is also entitled to be provided with written reasons for their detention following the initial decision
and each subsequent review of detention. The Instructions also contemplate that there may be ad hoc
reviews and require that a review is conducted if _“there is a significant and/or material change in_
_circumstances in between reviews”._

**The Second Opinion Policy**

41. Again, the drafting of the Second Opinion Policy is repetitive. But the key features of this document for
present purposes are as follows.

42. The Policy makes clear that, with specified exceptions, it applies to _”All external medical reports_
_requiring consideration under the Adults as Risk in Detention (AAR) policy” which are received whilst a_
person is detained under immigration powers (i.e. it does not apply to the initial decision about whether to
detain). The exceptions are where there has already been a decision to release the person from detention,
or removal is due within 10 working days or where the MLR falls to be rejected in any event because it
does not satisfy the baseline standard in the Caseworker Guidance.

43. The document adds:

_“This guidance should be used in conjunction with the AAR policy when an external medical report has_
_been received and an assessment of the detained individual's vulnerability is required under that policy.”_
(emphasis added)

44. I note that the Policy therefore bites in circumstances where, as the Policy itself recognises,
consideration of an external report ([42], above) and an assessment are “required” by the regime in place
before the Policy was introduced, including the Statutory Guidance. It also bites regardless of whether the
quality standards in the Caseworker Guidance, other than the baseline standard, are or are not met by the
external medical report.

45. The purpose of the Policy is stated to be as follows:

_“This guidance outlines the process for referring external medical reports for a second clinical opinion for_
_those detained under immigration powers, and how this should be used in line with the Adults at Risk in_
_Immigration Detention (AAR) policy”._

_The AAR policy guidance contains a set of quality standards with which to evaluate external medical_
_reports as evidence of vulnerability. This guidance is designed to work in conjunction with the standards_
_and introduce an additional, clinical input to assist decision making for those who may be vulnerable in_
_immigration detention.” (emphasis added)_

46. Where an external medical report is received, and the Policy applies, the caseworker:

_“must request that the external medical report be referred for a second opinion.” (emphasis added)_

47. There is then guidance as to how this is to be done, with deadlines for the completion of the various
stages as follows:


-----

i) Within one working day of receipt of the external medical report, the caseworker must send it to the
Detained Medical Reports team (“DMRT”) by email with a request for a second opinion.

ii) The DMRT then sets the date for an assessment to be carried out by a Home Office contracted doctor.
The appointment with the doctor must take place within 7 working days of the referral to the DMRT or, in
the case of a detainee who requires to be transferred to an immigration removal centre from a short term
holding facility so that the assessment can be carried out, 7 working days of transfer. If this is not possible,
the DMRT must explain this to the casework team and the assessment of the level of risk of the detainee
must be undertaken without the use of a second opinion.

iii) Assuming that the 7 day deadline is met, the second opinion report is required to be completed by the
Home Office contracted doctor within 5 working days of the assessment appointment and sent to the
DMRT which, in turn, must forward it to the casework team.

48. The maximum number of external reports which can be referred for a second opinion pursuant to the
Policy is 10 per week. If this limit has been reached the DMRT will notify the caseworker immediately and
consideration of the external medical report will proceed without a second opinion.

49. There is also a requirement for the detainee to be notified of the decision to refer the matter for a
second opinion and to invite them to the appointment with the Home Office doctor, with deadlines for the
stages in this process so as to allow the detainee 2 working days to respond before the date of the
assessment. Again, failure to meet these deadlines will mean that the caseworker is required to determine
the risk level without a second opinion on the case. If the detainee fails to respond, or declines to attend,
the assessment for the second opinion will be based on the available evidence including the external
medical report.

50. The Policy also deals with the position in the event that the assessment for the purposes of the second
opinion is delayed or cancelled. The consequences depend on the reason for the delay or cancellation. If it
is because the detainee is unable to attend or fails to cooperate with the process, the second opinion will
be based on the documentary evidence. If the Home Office cancels because it is unable to facilitate the
appointment, the appointment may be re-booked to take place within the next 5 working days. But if this is
not possible the DMRT must instruct the caseworker to assess the case without a second opinion. If the
appointment is cancelled for reasons which are beyond the control of the Home Office and it cannot be rebooked within the 5 working day period, a second opinion will be provided on the basis of the documentary
evidence.

51. As to the position whilst the second opinion is being obtained, the Policy states that:

_“Statutory detained casework actions must continue as normal whilst the second opinion report is_
_outstanding, but there will be no requirement to change the AAR level based on the external medical_
_report at this point, since the vulnerability evidence level continues to be under consideration.” (emphasis_
added)

52. Ms Anderson points out that the Second Opinion Policy also reminds caseworkers that, under the
Caseworker Guidance, they are required to send the external medical report to the healthcare team at the
immigration removal centre or the prison so that they can undertake any action required for the care or
management of the detainee. The Policy also states that:

_“Ongoing consideration of the vulnerability evidence level must not impede appropriate medical care or_
_treatment for the individual. Onsite healthcare teams should make decisions or referrals in relation to the_
_individual's care as appropriate on the basis of the information that they have available to them (including_
_the external medical report where appropriate)._

_It is also important that consideration is given to the individual's potential vulnerability whilst the second_
_opinion report is pending and particularly when preparing scheduled detention decisions in the interim (if_
_any). Should a decision subsequently be made to release the person from detention….before the second_
_opinion has been concluded, the…caseworker must inform DMRT immediately…”_


-----

53. The Policy then deals with what happens when the second opinion is received. It requires a decision to
be taken as to the appropriateness of the person's continued detention “in line with the Adults at Risk in
_Immigration Detention (AAR) policy” (emphasis added). It also reminds the caseworker that the standards_
applicable to external medical reports are set out in the Caseworker Guidance, and that reports which do
not comply with the baseline standard will not require a second opinion. And it goes on to say:

_“Consideration must then be given to the remaining standards, in order to determine the vulnerability level_
_under the AAR policy. Content from the second opinion report should be used to help determine the overall_
_weight attributable to the external medical report. The second opinion report acts as an additional factor in_
_arriving at the vulnerability evidence level: …1, ..2 or …3. For instance, in cases where the second opinion_
_expresses concerns regarding the evidence or methodology presented, this may mean downgrading the_
_evidence level which might have (on face value) otherwise resulted from the content of the external_
_medical report. Similarly, in cases where the second opinion echoes the concerns in the external medical_
_report regarding the vulnerability of the person and potential impact of detention upon them, this serves to_
_strengthen the evidence of the vulnerability._

_In each case, the clinical expertise presented in the second opinion report assists the responsible_
_casework/barrier team in reaching a balanced and justifiable assessment of the vulnerability of the person_
_in question within the scope of the AAR policy.” (emphasis added)_

54. There is then guidance as to how to balance the evidence, the first part of which deals with the relative
weight to be attached to in person, virtual and paper based assessments. Under the heading “Conflicting
_evidence” there is the following passage which I set out in full given Ms Luh's proposed interpretation of it_
as a ”lowest common denominator approach”:

_“When evaluating the 2 sources, and particularly where the Home Office contracted doctor disagrees with_
_the findings made in the external medical report, care must be taken not to dismiss the clinical opinions_
_expressed in the external medical report. The assumption must be that they have been made in good faith,_
_on the basis of the evidence presented. The responsible casework team member is not qualified to make a_
_clinical judgement regarding either piece of evidence. However, where a difference of clinical opinion is_
_noted between the 2 reports, there will be less justification for applying full weight to either._

_Accordingly, the vulnerability evidence level should be determined based on those elements which the_
_sources agree on. If both agree to the presence of a mental health condition, for instance, then the AAR_
_level will be level 2. If both agree that detention may result in harm, then the evidence should be_
_considered as satisfying .. level 3. However, as an example, should there be a disagreement over the_
_likelihood of harm caused by detention, and if the second opinion advances strong reasons to disagree_
_with the external medical report, then the most appropriate AAR level is likely to be AAR2. In this way,_
_neither report is being dismissed, but neither is full weight being given to the point which is in dispute._
_However, as with all cases, it remains vitally important that full consideration is given to the individual_
_circumstances of the case.“_

**The arguments of the parties**

The Claimant's arguments

55. Ms Luh's argument was that the Second Opinion Policy contradicts the Statutory Guidance in three
key respects:

i) First, it directs the caseworker not to deal with the external medical report submitted on behalf of the
detained person in its own right, and not to accept it as Level 3 evidence that the person is likely to be
harmed by continued detention, even when the report meets the standards required by the Caseworker
Guidance.

ii) Second, it directs the prolongation of a person's detention pending the obtaining of a second opinion
report. Even if the deadlines set in the Policy are adhered to, it may delay the decision about whether they
should be released for up to 18 working days and significantly more calendar days. There is also no


-----

deadline by which a caseworker is required to review the person's detention on receipt of the second
opinion report.

iii) Third, the Second Opinion Policy directs the caseworker to confine the assessment of the level of
weight to be afforded to an external medical opinion or MLR to those matters that are agreed as between
the authors of the reports, and expressly directs caseworkers not to give the MLR full weight where there is
a difference of opinion.

56. In her oral submissions, Ms Luh referred to Ground 2 as a “sort of” _Padfield point. Her skeleton_
argument stated that it is well established that where policy seeks to address the terms of a statutory
provision, it must promote and not frustrate the provision's statutory object and she relied on _Padfield v_
_Minister of Agriculture Fisheries & Food_ [1968] AC 997 at 1030B-D per Lord Reid. She argued that this
clearly applies to executive policy where the scope of such policy is controlled by, and must be applied as
part of, a _“consistent and coherent whole” with the Statutory Guidance issued under section 59(1) and_
approved by Parliament under s. 59(4). In this connection, she relied on [129]-[148] of the judgment of
Ouseley J in the Medical Justice case.

57. Ms Luh also argued that the Second Opinion Policy is unlawful because it undermines and frustrates
the purpose of section 59(1) in that:

i) First, it results in people “being detained for longer and not for immigration control factors, even where
_the MLR submitted contains evidence they are likely to be harmed if they remain detained” ([56] of the_
Claimant's skeleton argument).

ii) Second, _“people who have presented evidence that they are likely to be harmed if they remain in_
_detention may not be afforded the strongest protection against continued detention and may face further_
_harm in detention” ([57] of her skeleton). This is because, pending the second opinion, the MLR is not_
considered as part of a review of the detention and therefore not accepted as evidence for the purpose of
determining the level of risk. The weight which the MLR would otherwise have been given may also be
downgraded in the light of the second opinion.

iii) Third, even if there is a concern about a specific MLR, that is no basis for delaying consideration of
release of an adult at risk. If an MLR does not meet the required standards, the Statutory Guidance and the
Caseworker Guidance already provide a reasoned basis for downgrading the evidence without requiring
the consideration of release of the adult at risk to be delayed.

58. In her oral submissions, Ms Luh reiterated these points and added that the effect of applying the
Second Opinion Policy was that a caseworker would breach section 59(3) of the 2016 Act because they
would not then have taken into account the Statutory Guidance. She referred me to R (London Borough of
_Islington (ex parte Rixon) CO/1002/95 15 Marach 1996 which was produced over the short adjournment on_
the first day of the hearing. This argument and ex parte Rixon had not formed part of her pleaded case and
were not referred to in her skeleton argument. There was no application to amend and the argument was
not developed on either side. I therefore do not propose to address it further than to say that it does not
appear to have merit given that, as will already be apparent from my summary of the Second Opinion
Policy, it is required to be applied for the purposes of making an assessment of risk under the Statutory
Guidance. The problem therefore is not that a caseworker will fail to take that Guidance into account in
applying the Policy albeit – as I will come on to explain - the application of the latter, in my view, involves a
departure from the former.

59. When asked about Ms Anderson's arguments based on the decision of the Supreme Court in R(A) v
_Secretary of State for the Home Department (supra) Ms Luh said that her case could be brought within the_
_Gillick test but that it was not necessary for her to frame her case by reference to this test._

60. Although section 59(4) was referred to by Ms Luh she did not appear to be pursuing an argument,
which was referred to in the original Statement of Facts and Grounds, that there was an obligation under
section 59(4) to seek the approval of Parliament for the Second Opinion Policy and that the Policy was
therefore ultra vires because this had not been done. When I asked about this, Ms Anderson pointed out
that permission had been refused on this point by Lang J and the Claimant's renewed application for


-----

permission had not challenged this refusal. As a result, nor had Williams J given permission to argue it
and, consequently, it did not feature in the Agreed List of Issues or the skeleton arguments. I agreed with
Ms Anderson that it would therefore be unfair for this specific argument to be raised at this stage. It
engaged different considerations and had wider implications, in terms of the effect of section 59 on the
promulgation of guidance, given that it raised the question when, more generally, this section requires
guidance to be laid before Parliament and when it is not necessary to do so.

61. In Ms Luh's reply she appeared to reformulate her main case when she said that any policy which is
_“different or adds to or tells caseworkers to do something different or additional [to the Statutory Guidance]_
_would be unlawful”. However, on further probing, it appeared that in substance her case remained as per_
the Agreed List of Issues.

The Defendant's arguments

62. Ms Anderson denied that the Second Opinion Policy was contrary to the requirements of the Statutory
Guidance. Her first point was that in interpreting the relevant documents it was important to bear in mind
their nature. The Statutory Guidance is not statute. It is framed in general terms and is not legally
prescriptive as to processes and outcomes. The Second Opinion Policy is no more than advice to
caseworkers when they are making decisions about the detention of a person who is said to be vulnerable.
The nature of the decision as to the continuation of detention is that it requires consideration of a number
of factors. Neither document seeks to dictate the outcome of a given case or mandates the ignoring of
evidence or anything other than a balanced approach to the available evidence, and neither displaces the
myriad of other measures and public law requirements that continue to apply in this area. Importantly, nor
does the Statutory Guidance prevent the caseworker from seeking further information _“in fulfilment of_
_Tameside principles”_ where it is considered necessary and appropriate to do so in order to make an
informed decision.

63. Second, whilst the Court must consider the natural meaning of any policy, that does not render the
Secretary of State's understanding and intentions concerning his own policy irrelevant. The Second
Opinion Policy indicates that it is intended to be read in line with the Statutory Guidance, but it does not
purport to dictate the outcome of the decision to be made. Even where an outcome is indicated by Policy, it
is trite law that caseworkers may depart from any guidance where justified by the individual facts.

64. Third, the Court cannot be asked to rule on the contents of a policy to find them unlawful, save where
the terms unequivocally require a public decision maker to act unlawfully on _Gillick principles. In this_
connection, Ms Anderson relied on the decision of the Supreme Court in R(A) v Secretary of State for the
_Home Department (supra)._

65. Fourth, Ms Anderson highlighted various features of the Second Opinion Policy, including that it was to
be read and applied “in line with” the Statutory Guidance and was designed to introduce additional clinical
input to assist with decision making. It also contains various provisions which require that delays are to be
kept to a minimum and that consideration is given to the potential vulnerability of the detainee whilst the
second opinion is awaited, so that there might be a decision to release even though the second opinion
had not yet been received. She also emphasised that the approach to assessment of the case in the light
of the second opinion was more nuanced than Ms Luh suggested.

66. Ms Anderson's submission was that, fairly considered, the Second Opinion Policy does not preclude,
or 'excuse', a caseworker from considering an external medical report, or reviewing detention where that is
required, simply because a second opinion is requested. If the circumstances are that the medical report
includes material that requires an urgent review, or otherwise a review is appropriate, then that review
should take place regardless of a request for a second opinion. The Claimant's “tick box” approach was
contrary to the evaluative assessment which was required by the Statutory Guidance. Nor is it the case
that the Second Opinion Policy entails harm to detainees. If it is the case that a detainee is likely to suffer
harm as a result of detention then there is a duty on the Home Office clinicians to provide information
directly in relation to that. An MLR is not the only source of relevant information. The risk of harm is likely to
be picked up and dealt with appropriately.


-----

67. Ms Anderson submitted that Ground 2 – frustration of statutory purpose - should be rejected for
essentially the same reasons given that it relied on what she described as a flawed interpretation of the
Second Opinion Policy. Ground 2 relied on speculation as to the effect of the Policy which could not be
said necessarily to flow from its terms. The Claimant's approach was akin to the approach which, in A, the
Supreme Court said was impermissible i.e. an approach of comparing a normative statement in the
Statutory Guidance with a prediction of what might happen if the Policy were applied in the abstract. She
submitted, correctly, that the proper application of the _Gillick principle involves comparing the underlying_
legal position and the direction in the policy guidance to see if the latter contradicts the former. It does not
involve comparing a normative statement with a prediction of what might happen if the persons to whom
the guidance is directed are given no further information. There is no obligation to promulgate a policy
which removes the risk of possible misapplication of the law on the part of those who are subject to a legal
duty: see R (MA & HT) v Secretary of State for the Home Department _[[2022] EWCA Civ 1663 at [47].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67BD-T9V3-CGX8-0257-00000-00&context=1519360)_

68. Second, obtaining information to inform a decision, applying Tameside principles, is a legitimate part of
the decision-making process. The statutory purpose is not undermined by adherence to such legal norms.
On the contrary, it would undermine the statutory purpose to apply a 'tick box' rather than an 'evaluative
and informed' approach to such decisions, especially where they concern opinion evidence of this type. In
reality it was likely that the individual circumstances of a case would inform the decision rather than the
outcome being solely dictated by any interpretation of the Second Opinion Policy or the “downgrading” of
an opinion.

**The interpretation of the Statutory Guidance and the Second Opinion Policy**

69. Despite indications in Ms Anderson's skeleton argument, and Mr Ledwitch-Madsen's witness
statement on behalf of the Defendant, that she would argue that the subjective views of the Defendant are
relevant to the interpretation of a written policy, at the hearing both parties appeared to agree that I should
interpret the documents which are at issue in this case and, in doing so, should adopt the approach to
interpretation which was confirmed by the Court of Appeal in _R (JB)(Ghana) v Secretary of State for the_
_Home Department_ _[2022] EWCA Civ 1392 at [67]-[68]. As Bean LJ said:_

_“67. It is well established that in construing a policy document a court should not subject the wording to the_
_kind of fine analysis which might be applied to a statute or a contract… But the document must still be_
_interpreted objectively. As Lord Steyn said in Re McFarland [2004] 1 WLR 1289 at [24], although such_
_documents need not be construed as though they were legislation, and it "seems sensible that a broad and_
_wholly untechnical approach should prevail", nevertheless:-_

_"…what is involved is still an interpretative process conducted by a court, which must necessarily be_
_approached objectively and without speculation about what a particular minister may have had in mind."_

_68. The principle……is that documents of this kind should mean what they say, and should be interpreted_
_as they would be read by a reasonable claimant or support worker or advisor….._

70. The starting point is that it is for the State to justify the detention of the individual: _R (Lumba) v_
_Secretary of State for the Home Department (JUSTICE intervening)_ _[2011] UKSC 12; [2012] 1 AC 245e.g._
at [65], which formed part of the legal context in which the Statutory Guidance was promulgated. All other
things being equal, greater justification will be required when the circumstances of the individual mean that
they are vulnerable whilst in detention. Consistently with this, the Statutory Guidance creates a
presumption that adults at risk will not be detained, and a principle that a decision to detain such a person
must be justified on the evidence and must continue to be justified for as long as the detention lasts. It
follows from this that a change in circumstances or further evidence of vulnerability, such as an external
medical report, may mean that a detention which was otherwise justified ceases to be.

71. As I read the Statutory Guidance, and as I consider the reasonable caseworker would read it, the
Guidance recognises these points and therefore requires decisions about whether the presumption against
detention has been rebutted to be made _“on the basis of the available evidence” (see e.g. [8] of the_
Guidance). Unless detention is justified on the available evidence, the presumption of liberty will prevail
and the person will not be detained or will be released. This is one of the main principles underpinning the


-----

Guidance: see [3] and the passages referred to [26] above. If a person is an adult at risk, the caseworker is
therefore required to consider _“the level of evidence available in support and the weight that should be_
_accorded to the evidence in order to assess the likely risk of harm to the individual if detained…” and to_
determine the person's risk level under [9] of the Guidance. This requirement continues during the person's
detention as [5] and [12] of the Statutory Guidance and the requirements for regular reviews, under the
_“Detention: General Instructions”, reflect, and Ms Anderson did not dispute._

72. It would not be consistent with this approach for there to be material delays in acting on the available
evidence. The available evidence approach means that, under the Statutory Guidance, a person cannot be
held in detention when the evidence available to the Defendant shows that this is not justified. It would
therefore be contrary to the Guidance to postpone consideration of the evidence or a decision about
detention for more than a de minimis period of time after receipt of material new evidence. An external
medical report which is submitted on behalf of a detainee must therefore be considered when it is received,
the level of risk assessed and a decision taken as to whether the continued detention of that person is
justified. If detention is not justified, the person must be released.

73. Given the presumption against detention, this also seems to me to be a reasonable interpretation of
the Statutory Guidance. It does not mean that an external medical report has to be accepted or given full
weight by a caseworker: there were and are bases on which it might be rejected or given limited weight on
the available evidence. Nor does it mean that no further inquiries at all may be made, or other information
taken into account: as Ms Anderson submitted and Ms Luh accepted, if it was known that the detainee had
an appointment the next day to see a Home Office doctor it might be permissible to await the doctor's
views depending on the circumstances. But there is a difference between waiting for a short period of time
for the outcome of an existing medical appointment and postponing a decision on the available evidence in
order to organise an assessment to see whether further evidence might become available to contradict or
undermine the available evidence.

74. If one then considers the meaning of the Second Opinion Policy, contrary to the arguments of Ms
Anderson and Mr Ledwitch-Madsen, there cannot be any real doubt that it directs caseworkers
systematically to postpone a decision in the cases to which the requirement to seek a second opinion
applies, rather than make a decision on the evidence which is now available in the form of the external
medical report. As noted at [51] above, whatever the available evidence as a result of receipt of external
medical report which satisfies the baseline standard, the Policy provides that the caseworker is not
required to change the detainee's risk level under the Statutory Guidance before the second opinion is
received and, of course, under the Policy a risk level which might have been changed under the Guidance
may not now be. The characterisation, in the Policy, of the position as being that the risk level is
undergoing consideration whilst the second opinion is awaited should not distract attention from the
substance, and the consequent effect of the Policy on the position of the detainee who is an adult at risk.
Moreover, the postponement of a decision is likely to be for a significant – certainly for more than a de
minimis - period of time. Even in cases where the second opinion then concurs with the external medical
report and the individual is released, that seems to me to be plainly contrary to the Statutory Guidance.

75. It is no answer for the Defendant to say that there may be cases where a decision to release a person
is taken whilst the second opinion report is pending. This may be, for example, because the detainee is
obviously suffering, or at risk of, serious harm and/or the matter is urgent - but the general requirement of
the Second Opinion Policy is that a decision is deferred until the second opinion has been received. Nor is
it an answer to submit that the Policy requires decisions to be taken “in line” with AAR policy including the
Statutory Guidance. It is clear that this means no more than that, having received the second opinion, this
then forms part of the available evidence for the purposes of making the assessment of risk under that
Guidance, albeit adopting the approach to the evaluation of the evidence stated in the Policy. Nor is the
Claimant's objection to the Second Opinion Policy merely a statistical prediction of likely outcomes based
on guidance which is said not to be sufficiently prescriptive (see A): the objection is based on a comparison
of what the caseworker is specifically required by the text of each document to do. Nor does the fact that,
according to Mr Ledwitch-Madsen, 80% of referrals for second opinions in the first 9 months of the Policy


-----

did not result in a second opinion because the requisite deadlines were not met, detract from the point that
the Policy materially departs from the position under the Statutory Guidance.

76. The other respects in which Ms Luh said that the Second Opinion Policy was contrary to the Statutory
Guidance did not appear to add much to the central point that, under the Policy, caseworkers are directed
to delay acting on the available evidence, to commission further evidence and to take that evidence into
account in coming to a decision. It is true that the Second Opinion Policy is likely to delay or prevent the
release of detainees who would otherwise have been released under the Statutory Guidance on the basis
of their external medical report. But this illustrates the consequences of the difference of approach in the
two documents rather than, of itself, proving that there is a contradiction between them.

77. Although Ms Luh is right that the effect of the Second Opinion Policy is that the external medical report
may carry less weight than it would have done under the Statutory Guidance alone, I also agree with Ms
Anderson that the approach to assessing the evidence in the light of the second opinion report is more
nuanced than Ms Luh suggested. This is quite apparent from the text which I have set out at [54] above.
However, this is not a central issue given that the key contradiction of the Statutory Guidance is the one
which I have identified. If it were permissible, under that Guidance, to postpone a decision pending a
second opinion, the fact that the second opinion was then taken into account, the way in which it was taken
into account, and the fact that people who would have been released under the Guidance might not be
released, would not necessarily be contradictions of the Statutory Guidance even if other complaints about
the approach to these matters might be made.

**Was the Second Opinion Policy unlawful?**

78. If one then considers whether it would be unlawful for the Defendant to promulgate a policy which
contradicts the Statutory Guidance, I did not understand Ms Anderson to argue otherwise. Perhaps the
simplest way of expressing the point is that the Statutory Guidance was required by section 59 of the
Immigration Act 2016 to be approved by Parliament, albeit by negative resolution procedure, and was
approved by Parliament. It therefore was not open to the Defendant to contradict or undermine it without
the approval of Parliament.

79. Although Ms Luh did not rely on _R(A) v Secretary of State for the Home Department (supra) or the_
_Gillick test, her approach was said by Ms Anderson to be contrary to these authorities. But in my view this_
is a case in which the Defendant has undermined the rule of law in a direct and unjustified way by issuing a
policy which positively authorises or approves unlawful conduct by caseworkers in that the terms of the
Second Opinion Policy require or encourage them to act contrary to the Statutory Guidance approved by
Parliament (see [38] of A). The fact that, in a given case, there might be circumstances which lead a case
worker to decide not to defer a decision does not affect this point. So it seems to me that the present case
falls squarely within A and that the Defendant has failed the Gillick test.

80. I agree that the decision of Ouseley J in the Medical Justice case is, at least, consistent with Ms Luh's
argument in that he regarded the Statutory Guidance as the controlling policy document in relation to the
issue before him given that it had been approved by Parliament. However, in that case the problem was
that the definition of “torture” in the Statutory Guidance was materially different to, and unlawfully narrower
than, the definition in the Caseworker Guidance and elsewhere. At [129] Ouseley J observed that the
various documents were “drafted to be a consistent and coherent whole”, as Ms Luh noted; and at [141] he
said that the Caseworker Guidance has to be read subject to the Statutory Guidance and cannot contradict
it. But he was addressing (and rejecting) a rather different argument, namely that a broader approach to
who was vulnerable in the Caseworker Guidance could remedy deficiencies in the narrower approach
under the Statutory Guidance.

81. I am doubtful about Ms Luh's argument based on Padfield (supra), at least as it was put. The passage
on which she relied is well known. At 1030B-D Lord Reid said:

_“Parliament must have conferred the discretion with the intention that it should be used to promote the_
_policy and objects of the Act; the policy and objects of the Act must be determined by construing the Act as_
_C a whole and construction is always a matter of law for the court. In a matter of this kind it is not possible_


-----

_to draw a hard and fast line, but if the Minister, by reason of his having misconstrued the Act or for any_
_other reason, so uses his discretion as to thwart or run counter to the policy and objects of the Act, then_
_our law would be very defective if persons aggrieved were not entitled to the protection of the court.”_

82. Here, of course, the Defendant was not purporting to exercise his powers under section 59 of the
Immigration Act 2016 in publishing the Second Opinion Policy, hence Ms Luh's reference to a “sort of”
_Padfield point. Insofar as Ms Luh was arguing for a wider principle - that a public body must not, through_
the exercise of powers under one statutory provision, undermine the purposes of another - the scope and
application of this principle in the present case was not explored in argument by either Counsel.

83. Despite the framing of the agreed issue, which focussed on the purpose of section 59, in her skeleton
argument (at [54]) Ms Luh's modified _Padfield argument alleged undermining of the purpose of the_
Statutory Guidance and section 59, combined, which she said was “to identify those who are unsuitable for
_detention because they are particularly vulnerable to harm in detention….. Thus the fact that the Second_
_[Opinion Policy itself has not been issued under s. 59 IA 2016 does not mean that its terms can operate to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C41M-00000-00&context=1519360)_
_frustrate and undermine the purpose of_ _[s. 59 IA 2016.”. At [56], however, she identified the purpose of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C41M-00000-00&context=1519360)_
section 59 and the Guidance as being _“to reduce numbers of vulnerable people being detained, and_
_reduce the length of their detention to the shortest possible time, subject to sufficiently weighty and cogent_
_countervailing immigration factors”. Her oral submissions emphasised this purpose and she placed_
particular reliance on the introduction to the Statutory Guidance and the passage at [6] which I have set out
at [20] and [21] above which, she said, should be taken into account in identifying the purpose of section
59.

84. Insofar as Ms Luh was arguing that section 59 meant that, having published the Statutory Guidance
and obtained the approval of Parliament, the Defendant could not then cut down that Guidance without the
approval of Parliament, I agree, as I have said. But, for the avoidance of doubt, this is because the purpose
of section 59 was to provide that guidance on the specified matters would be approved by Parliament and
promulgated. In addition to requiring a degree of Parliamentary scrutiny, the aim was for there to be
transparency and decision-making which was consistent with what Parliament had approved. This was in
line with what Lord Dyson JSC had said about transparency and the rule of law in R (Lumba) v Secretary
_of State for the Home Department (JUSTICE intervening) (supra) at [34]–[36], albeit in the context of_
different issues as to policy making by the executive. Contrary to Ms Luh's argument, subject to the Policy
being laid before Parliament etc, it would not have frustrated the purpose of section 59 to make provision
for the obtaining of a second opinion on any external report submitted on behalf of a detainee.

85. I agree with Ms Anderson that there is no principle of statutory construction that would allow the
purpose of an enabling provision to be determined on the basis of secondary legislation or statutory
guidance issued pursuant to that provision as Ms Luh argued. Nor did Ms Luh point to any. Typically, the
question arises the other way round: the court is asked to interpret the secondary legislation or the
statutory guidance in the light of the enabling provision, for example with a view to deciding whether it is
authorised by, or consistent with, that provision. I therefore do not agree that the purpose of section 59 can
be derived from the Statutory Guidance, that the section itself has the wider purposes contended for by Ms
Luh or that the Second Opinion Policy was contrary to those purposes, at least in the way that she
appeared to argue that it was.

86. Of course, the passages from Statutory Guidance relied on by Ms Luh were admissible to explain its
purpose. But I agree with Ms Anderson that the statement in [1] of the Guidance (cited at [20] above) about
the reduction in the number of vulnerable people in detention and the length of their detention articulated
an intention to address the problems which had been identified by Mr Shaw and others. September 2016
was intended to be a watershed moment, and it was intended that various reforms which were being
introduced would mean that there would be less time spent in detention by vulnerable people than was the
case before the reforms. But the passages relied on by Ms Luh do not establish that any decision or policy
thereafter which resulted in an increase in the number of vulnerable people in immigration detention or
prolonged the length of their detention would inevitably be inconsistent with the Statutory Guidance, and
therefore unlawful.


-----

87. In any event, [1] of the Guidance referred to _“genuine cases of vulnerability” and the statement of_
principle in [6] (cited above at [21]) referred to _“fewer people with a confirmed vulnerability” (emphasis_
added). Arguably the Second Opinion Policy is part of the process of confirming whether the person has a
vulnerability, and identifying genuine cases, and therefore consistent with this purpose of the Guidance.
Moreover, Ms Luh's argument to some extent assumes what needed to be proved. The fact that a second
opinion is sought may mean that the release of some detainees who ought to have been released will be
delayed, but the “available evidence” approach may mean that detainees are released when further
evidence would have established that they were not in fact vulnerable or, at least, not sufficiently
vulnerable for their detention to cease to be justified.

**Conclusion on Grounds 1 and 2**

88. For these reasons I uphold what I understand to be the core complaint by the Claimant under Grounds
1 and 2, albeit not on precisely the same basis as Ms Luh advocated.

**GROUND 3**

**Overview**

89. The Claimant's case was that the duty to consult arose at common law in three ways. First, there was
an established practice of consultation in respect of policies concerning adults at risk; second, it would be
conspicuously unfair not to consult the Claimant given the gravity of the consequences of the Second
Opinion Policy; and, third, the Defendant had in any event embarked on voluntary consultation with two
psychiatrists and, accordingly, it was unfair not to consult with the Claimant as well: see [3] of the Agreed
List of Issues. Each of these bases for the alleged duty was contested by the Defendant but it was not
contended that, if there was a duty to consult, it had been complied with.

**Legal framework**

Overview

90. Most of the legal principles which apply to this Ground were not in dispute before me and are helpfully
summarised in the well-known passage from the judgment of the Divisional Court, given by Hallet LJ, in R
_(Plantagenet Alliance Ltd) v Secretary of State for Justice & Others_ _[2014] EWHC 1662 (Admin) at [97]-_

[98](11). Having noted, at [95], that the duty to consult is an incident of the common law principle of
fairness, at [98(2)] she said:

_“There are four main circumstances where a duty to consult may arise. First, where there is a statutory_
_duty to consult. Second, where there has been a promise to consult. Third, where there has been an_
_established practice of consultation. Fourth, where, in exceptional circumstances, a failure to consult would_
_lead to conspicuous unfairness. Absent these factors, there will be no obligation on a public body to consult_
_…”_

91. At [98(10)] she said:

_“(10) A legitimate expectation may be created by an express representation that there will be_
_consultation…, or a practice of the requisite clarity, unequivocality and unconditionality… (emphasis_
added)

92. Where there is a duty to consult, the purposes served by requiring the consultation to be fair were said
by Lord Wilson, in R (Moseley) v Haringey London Brough Council [2014] UKSC 56, [2014] 1 WLR 3947,
at [24], to be:

_“First, the requirement 'is liable to result in better decisions, by ensuring that the decision-maker receives_
_all relevant information and that it is properly tested'…... Second, it avoids 'the sense of injustice which the_
_person who is the subject of the decision will otherwise feel'…. Such are two valuable practical_
_consequences of fair consultation. But underlying it is also a third purpose, reflective of the democratic_
_principle at the heart of our society.”_

E t bli h d ti f lt ti


-----

93. The authorities emphasise that the bar for the claimant is a high one where the duty to consult is
alleged to be based on an established practice of consultation. The practice must be sufficiently clear and
well established to be tantamount to a promise or assurance that there will be consultation in the
circumstances which have arisen: see Lord Diplock in _Council of Civil Service Unions v Minister for the_
_Civil Service [1985] AC 374 at 408G-H. In R v Devon County Council, ex parte Baker [1995] All ER 73 at_
88-89 Simon Brown LJ (as he then was) said:

_“(4) The final category of legitimate expectation encompasses those cases in which it is held that a_
_particular procedure, not otherwise required by law in the protection of an interest, must be followed_
_consequent upon some specific promise or practice. Fairness requires that the public authority be held to_
_it. The authority is bound by its assurance, whether expressly given by way of a promise or implied by way_
_of established practice.” (emphasis added)_

94. Having reviewed the authorities, in _R (MP) v Secretary of State for Health and Social Care_ _[2020]_
_EWCA Civ 1634, [2021] PTSR 1122Newey LJ summarised the law on this issue as follows:_

_“(i) an express promise, representation or assurance needs to be “clear, unambiguous and devoid of_
_relevant qualification” to give rise to any legitimate expectation, whether substantive or procedural; (ii) a_
_practice must be tantamount to such a promise if it is to found any legitimate expectation. It may be, as_
_Sedley LJ said in BAPIO, that a practice does not have to be entirely unbroken, but it does have to be so_
_consistent as to imply clearly, unambiguously and without relevant qualification that it will be followed in the_
_future.”_

Conspicuous unfairness

95. As far as the Claimant's argument based on conspicuous unfairness is concerned in R (Bhatt Murphy)
_v Independent Assessor_ _[2008] EWCA Civ 755 at [50] Laws LJ said by way of a summary:_

_“A change of policy which would otherwise be legally unexceptionable may be held unfair by reason of_
_prior action, or inaction, by the authority. If it has distinctly promised to consult those affected or potentially_
_affected, then ordinarily it must consult (the paradigm case of procedural expectation)…..If, without any_
_promise, it has established a policy distinctly and substantially affecting a specific person or group who in_
_the circumstances was in reason entitled to rely on its continuance and did so, then ordinarily it must_
_consult before effecting any change (the secondary case of procedural expectation). To do otherwise, in_
_any of these instances, would be to act so unfairly as to perpetrate an abuse of power.”_

96. In R (Article 39) v Secretary of State for Education [2020] EWCA Civ 1577, [2021] PTSR 696, at [31],
Baker LJ said that the “paradigm case” and “secondary case” described by Laws LJ in this passage are in
effect, respectively, the third and fourth of the categories referred to by Hallett LJ at [98(2)] of her judgment
in the Plantagenet Alliance case. It is worth noting that in Bhatt Murphy Laws LJ had said, at [42], that in
the secondary case of procedural expectation, whilst the categories of unfairness are not closed and the
question of unfairness is fact sensitive, something no less concrete was required than in the paradigm
case. At [49] he said this:

_“49. I apprehend that the secondary case of legitimate expectation will not often be established. Where_
_there has been no assurance either of consultation (the paradigm case of procedural expectation) or as to_
_the continuance of the policy (substantive expectation), there will generally be nothing in the case save a_
_decision by the authority in question to effect a change in its approach to one or more of its functions. And_
_generally, there can be no objection to that, for it involves no abuse of power. Here is Lord Woolf again in_
_Ex p Coughlan (paragraph 66):_

_“In the ordinary case there is no space for intervention on grounds of abuse of power once a rational_
_decision directed to a proper purpose has been reached by lawful process.”_

_Accordingly for this secondary case of procedural expectation to run, the impact of the authority's past_
_conduct on potentially affected persons must, again, be pressing and focussed. One would expect at least_
_to find an individual or group who in reason have substantial grounds to expect that the substance of the_
_relevant policy will continue to enure for their particular benefit: not necessarily for ever, but at least for a_


-----

_reasonable period, to provide a cushion against the change. In such a case the change cannot lawfully be_
_made, certainly not made abruptly, unless the authority notify and consult.”_

Voluntary consultation

97. For the purposes of the third basis on which Ms Luh submitted that a duty to consult arose – voluntary
consultation - she relied on the principle, stated in _R v North and East Devon Health Authority, ex parte_
_Coughlan [2001] QB 213 at [108], that whether or not there is a legal requirement to consult, if it is_
embarked upon it must be carried out “properly”. Lord Woolf MR explained that this meant in accordance
with the criteria established in R v Brent LBC ex parte Gunning (1985) 84 LGR 168. Ms Anderson pointed
out that in R (Eveleigh & Others) v Secretary of State for Work and Pensions _[2023] EWCA Civ 810, [2023]_
1 WLR 3599 at [91], [97] and [98] the Court of Appeal, whilst acknowledging that [108] of _Coughlan has_
often been cited in the authorities, left open the question whether it is binding and/or correct.

98. This issue was not fully argued before me and I do not need to decide it given that, in my view, it does
not arise. The relevant passages in the _Coughlan and the_ _Eveleigh cases were concerned with the_
question whether and in what circumstances the Gunning criteria have to be complied with if there is no
pre-existing duty to consult. In _Coughlan Lord Woolf was addressing the position where voluntary_
consultation is undertaken and in Eveleigh the Court of Appeal decided that the UK Disability Survey was
not a process which was required to meet the Gunning criteria: in effect, it did not even amount to voluntary
consultation. As is very well known, the Gunning criteria are qualitative features of a fair consultation: they
require that consultation must be undertaken at a time when proposals are still at a formative stage; that it
must include sufficient reasons for particular proposals to allow those consulted to give intelligent
consideration and an intelligent response; that adequate time must be given for this purpose; and that the
product of consultation must be conscientiously taken into account when the ultimate decision is taken.

[108] of Coughlan and Eveleigh were not concerned with the question whether it was fair or rational for a
public body to leave a given party out of a consultation process which it had conducted.

99. However, Ms Luh also relied on R (Article 39) v Secretary of State for Education (supra). This case
concerned the introduction of the Adoption and Children (Coronavirus) (Amendment) Regulations 2020,
which amended a series of regulatory protections in respect of children's social care services in order to
deal with the impact of the Covid-19 pandemic on the social care system for children. At [79] Baker LJ
described these changes as “unquestionably substantial and wide ranging…[with] the potential to have a
_significant impact on children in care. The regulations which were under consideration for amendment are_
_an integral part of the whole statutory scheme governing children's social care.”_ The Secretary of State
consulted with providers of care services, including local authorities, service providers and Ofsted by way
of “a rapid informal consultation, substantially by email” [85].

100. The claimant in the Article 39 case was a children's rights charity which complained that there had
been a failure to consult those who were advancing children's rights, whether the claimant, other nongovernmental organisations, the Children's Commissioner for England or children themselves. The duty to
consult was said to arise under section 22(9) of the Care Standards Act 2000 in respect of some of the
provisions in question and otherwise to arise at common law on the basis that there was an established
practice of consultation in that area. The claimant also contended that the failure to consult the Children's
Commissioner and organisations concerned with children's rights was irrational and unfair.

101. The Court of Appeal accepted that a duty to consult the Children's Commissioner and other bodies
which represented children's rights had arisen, and that there had been a breach of this duty. The duty
arose in these three ways:

i)  First, given the statutory duty to consult in respect of certain of the amendments, albeit “any persons

_[the Secretary of State] considers appropriate”, given the scope of the amendments under consideration_
and given the fact of informal consultation with certain bodies in relation to those amendments, having
decided to carry out a consultation it was irrational to conduct it on an entirely one sided basis which
excluded those most directly affected by the changes, whose input would have led to a better informed
decision [83];


-----

ii) Second, there was an established practice of consulting with the Children's Commissioner and other
representative bodies when considering regulatory changes of the sort in question: there had been
consultation before the introduction of at least some of the original regulations which had been amended

[84]; and

iii) Third, given the impact of the proposed changes on the very vulnerable children in the care system it
was conspicuously unfair not to include bodies which represented their rights and interests within the
consultation which the Secretary of State had chosen to carry out. There was no good reason not to
include such bodies and there were very good reasons to include them. In this connection, Baker LJ
emphasised the statutory responsibility of the Children's Commissioner to promote and protect the rights of
children which meant that once there had been a decision to consult it was irrational and unfair not to
include the Commissioner in that consultation. And he emphasised the expertise of the Commissioner and
other bodies expressly set up to represent the interests of children and the fact that they were plainly better
equipped to do so than the bodies which had been consulted. Their input would have meant that the
Secretary of State was better equipped to make judgments about how the regulations should be amended
([85(1)-(5)]).

102. At [33] (and [78]) of his judgement in the Article 39 case, [108] of the judgment in Coughlan was cited
by Baker LJ as authority for the proposition that if a decision to consult is taken the consultation must be
carried out “properly and fairly” i.e. in accordance with the Gunning criteria. At [34] Baker LJ went on to
cite Lord Wilson in _R (Moseley) v Haringey London Brough Council_ (supra) at [23] where he said that,
irrespective of how the duty to consult has been generated, the common law duty of procedural fairness
will inform the manner in which the consultation will be conducted. Baker LJ then said:

_“35 Once a duty to consult has been found to arise, it is for the decision-maker to determine who should be_
_consulted. His determination is open to challenge, however, on grounds of irrationality: R (Liverpool City_
_Council) v Secretary of State for Health [2017] PTSR 1564.”_

103. The claimant in the Article 39 case had argued on the basis of Coughlan that, whether or not there
was a legal requirement to consult, if it was considered appropriate to consult anyone at all, a rational a
decision maker would also have consulted those who would be directly affected by the proposed changes:
see [48]. I am doubtful that Baker LJ was intending to identify irrationality as the only basis on which there
may be a challenge to a failure to include a party in a consultation process at common law, and the
_Liverpool City Council case to which he referred does not appear to establish that this is the position. The_
proposition that, at common law, it is for the decision maker alone to decide whom to consult was rejected
in R (Milton Keynes Council) v Secretary of State for Communities and Local Government _[2011] EWCA_
_Civ 1575, [2012] JPL 728 at [32]. Pill LJ said:_

_“A fair consultation requires fairness in deciding whom to consult as well as fairness in deciding the subject_
_matter of the consultation and its timing.”_

104. However, this point was not argued before me and nor was the Milton Keynes case cited. In practice,
it will not often be the case that the test of fairness and the test of rationality make a material difference to
the outcome where the issue is as to the exclusion of a party from a consultation process given that, where
the challenge is to the fairness of such a process, “The test is whether the process was so unfair as to be
_unlawful” (per Burnett J (as he then was) in R (London Criminal Courts Solicitors Association v The Lord_
_Chancellor_ _[[2014] EWHC 3020 (Admin), [2015] 1 Costs LR 7 at [36]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FF4-N1G1-F152-J31H-00000-00&context=1519360)_

**The competing cases under Ground 3**

The Claimant's case

_Evidence_

105. The Claimant's case is principally set out in the witness statement of Ms Hanley which was served
with, and expressly incorporated into, the Statement of Facts and Grounds. Ms Luh also referred me to
certain paragraphs from the witness statement of Ms Tara Wolfe dated 8 December 2022. She is the Head


-----

of the Medico-Legal Report Service at Freedom from Torture and her evidence and the evidence of other
witnesses in support of the Claimant's case was said to corroborate Ms Hanley's evidence.

106. Ms Hanley attends meetings of the National Asylum Stakeholder Forum (NASF) Detention SubGroup (DSG), of which the Claimant is a member, the terms of reference for which include the following
passage:

_“Purpose_

_• Facilitate discussion between the Home Office and Non-Government Organisations (NGOs) on matters_
_related to Immigration Detention._

_• Facilitate the development of policy and operational ideas between Home Office officials and NGOs._

_• Provide a forum for consultation, challenge, recognition, and horizon scanning._

_In being a member of the group all parties agree to:_

_• engage honestly, collaboratively, and with respect for this being a consultative forum that encourages all_
_members to challenge from within, therefore sustaining our mutual trust and respect; and_

_• knowingly not raise issues subject to live litigation._

**_And by, agreeing to the above_** _they can involve themselves in discussions_
_about proposed policy and operational changes pertaining to immigration detention.” (emphasis in the_
original)

107. Ms Hanley says that the Claimant has consistently been invited by the Home Office to participate in
stakeholder forums of this sort over the years. Later in her statement she says that for over 15 years the
Claimant has engaged with the Home Office in discussions about the relevant detention rules and policies:

_“17…..We have been consistently invited to respond to consultations on a range of Home Office policies_
_concerning immigration detention, arrangements of healthcare, management of risks to and safeguarding_
_of detained persons.”_

108. She says that, notwithstanding some concerns about the way in which the Home Office has
approached consultation:

_“19….…the Home Office does routinely and consistently consult with and seek views from stakeholders,_
_including Medical Justice, on significant new policies or policy changes relating the detention of vulnerable_
_people. This has particularly been the case since the introduction and implementation of the Adults at Risk_
_policy framework under the_ _[Immigration Act 2016 in September 2016. Often the consultation is done](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
_through the NASF detention sub-group given its terms of reference specifically include stakeholder review_
_of and participation in policy development. But sometimes it is done through email with a select group of_
_NGO stakeholders with common interests in detained persons' welfare. Although sometimes the Home_
_Office describes its invitation for stakeholder feedback as “engagement” with stakeholders, or an_
_opportunity to provide “comments”, rather than “consultation”, it is our experience that this is a distinction_
_without difference, as the purpose of the invitation has consistently been to elicit our views on policy, either_
_at the development stage or where substantive changes are contemplated._

_20. In preparing this witness statement, I and my colleagues have gone through the policies published by_
_the Home Office concerning the detention of adults at risk from 2016 onwards, and reviewed our_
_organisational records, including communications with the Home Office. In this process, we have not been_
_able to identify a key policy development or change in policy affecting adults at risk on which the Home_
_Office did not seek our views and the views of other similar NGO stakeholders at a stage when the policy_
_was only in a draft form. The absence of any consultation on the Second Opinion MLR Policy under_
_challenge in this claim is a departure from normal practice.” (emphasis added)_

109. Ms Hanley then goes on to give a detailed account of various issues concerning adults at risk about
which the Home Office has consulted the Claimant and others since 2015. She also summarises the
consultation which took place in relation to each issue. For reasons which will become apparent, it is not


-----

necessary for me to rehearse a great deal of the detail but she gives accounts of the following
consultations.

110. She says that in 2015 there was a consultation on Rule 35 of the Detention Centre Rules 2001 and
Rule 32 of the Short-term Holding Facility Rules which concerned the standards required for the
preparation of medical reports and consideration of such reports by Home Office caseworkers. This
followed criticisms of how Rule 35 operated in the context of the Detained Fast Track which had been
made in R (EO and Ors) v Secretary of State for the Home Department _[2013] EWHC 1236 (Admin) and R_
_(Detention Action) v Secretary of State for the Home Department [2014] EWHC 2245 (Admin), as well as_
wider concerns raised by the All Party Parliamentary Group of Refugees in a report which it published in
March 2015.

111. Ms Hanley says that the Home Office responded by holding a series of consultative meetings with
stakeholders, albeit these meetings ceased when the Detained Fast Track was suspended. Draft templates
for Rule 35 reports and Home Office responses to accompany the Detention Services Order (“DSO”) and
Rule 35 process policy were provided to the Claimant and other stakeholders through the predecessor of
the NASF DSG. Later that year, the Home Office also provided a draft amended DSO 09/2016 on Rule 35,
which would accompany the proposed template forms when implemented. Training materials on the new
Rule 35 templates were also circulated for discussion. Events were then overtaken by the Shaw review
and report. Stakeholders were not asked to provide further comment in the light of Mr Shaw's report but, on
15 September 2016, the Claimant, as a consultee, was notified of the publication of the DSO and template
Rule 35 forms as well as the Caseworker Guidance. These were to be implemented on 19 September
2016.

112. Ms Hanley also says that in 2016 the Claimant was also consulted on the draft Statutory Guidance.
On 27 May 2016 the Claimant was informed by Mr Cheeseman, the then policy lead at the Home Office,
that the first draft had been published the day before. The Claimant submitted comments and met with Mr
Cheeseman and his supervisor to discuss the draft, and the Claimant and other stakeholders followed up
in writing. The second draft was then published on 21 July 2016 and the Claimant and other stakeholders
were alerted to this by email from Mr Cheeseman on the same day. They continued to engage with the
Home Office in the period up to when the Guidance came into force on 12 September 2016, and he with
them.

113. Ms Hanley says that in late 2016 to 2017 the Claimant was consulted on DSO 08/2016 on the
Management of Adults at Risk in Immigration Detention, which was published on 27 February 2017. Along
with other stakeholders the Claimant received a draft of this DSO for consultation some months before the
planned publication date and it responded on 1 November 2016, it appears in writing. The Claimant
provided comments with clinical and casework evidence, and made recommendations that the policy
changes should be withdrawn and reviewed and that there should be multi-agency input into the drafting of
personalised care plans and health and wellbeing risk assessments.

114. Between 2016 and 2017 there was consultation with the Claimant and other stakeholders about DSO
02/2017 on removal from association and temporary confinement. This DSO provided guidance on rules
on the removal of a detained person in the interests of security or safety and the power to segregate
detained person owning to their behaviour. It was circulated for consultation in 2016. The Claimant
responded with comments and recommendations in July 2016 which included welcoming the introduction
of mandatory medical assessments. There was no new DSO published at this stage but, in 2017, there
was further consultation on an amended draft of the same DSO which provided more detail than the 2016
version, including additions which reflected the Claimant's comments as to levels of staffing in
segregation units. The Claimant provided a detailed response to this consultation in April 2017. The DSO
was published on 18 July 2017 and it included provisions which reflected the submissions made by the
Claimant. Ms Hanley notes that there were minor amendments to the DSO on 3 February 2020 of which
the Claimant was informed by email from the Home Office lead for DSOs.

115. There was also consultation in 2017 about DSO 03/2017 on the care and management of detained
individuals refusing food and/or fluid. Ms Hanley says that the Claimant raised concerns about the care of


-----

detainees who refused food and water, through the NASF DSG. On 6 January 2017, the Home Office
circulated a draft of a new DSO together with templates. The Claimant provided comments in February
2017, amendments were made which reflected some of the Claimant's concerns and the DSO was
published in October 2017. Ms Hanley notes that amendments were made to the DSO in 2019, of which
the Claimant was notified, but says that these were minor and did not affect the substance of the DSO. She
says that the Claimant was also notified of an updating of the DSO to clarify the extent to which it applies to
people who refuse food and/or fluids for reasons other than protest. At the time of writing, however, the
updated DSO had not been published on the Home Office website.

116. In 2018, there was further consultation about the Statutory Guidance, the DSO on Rule 35 and the
Caseworker Guidance following the ruling by Ouseley J in the _Medical Justice case. He had ordered a_
review and reissuing of the Statutory Guidance within a reasonable period of time. On 16 January 2018, Mr
Cheeseman wrote to the Claimant and other stakeholders confirming that the Home Office was keen to
take their view on the proposed amendments through a series of meetings. On 5 February 2018, Mr
Cheeseman then circulated embargoed copies of amendments to the Caseworker Guidance and to Rule
35 of the Detention Centre Rules which proposed a new formulation for the definition of torture. He also
proposed meetings with stakeholders to receive their feedback. Ms Hanley says that the consultation
period was short and that only a select number of stakeholders had been approached. Mr Cheeseman was
therefore pressed, in correspondence and at a consultation meeting on 20 February 2018, to allow a
longer period and to include other consultees. The Claimant and certain other NGOs provided a joint
written response on 21 February 2018. The consultative process continued and there were further
exchanges on the matter in March to May 2018, culminating in the revised documents coming into force on
2 July 2018.

117. Concerns about the Home Office's response to Ouseley J's ruling in the _Medical Justice_ case
persisted and the Claimant issued further proceedings in 2018 (CO/2382/2018). In February 2019, that
claim was settled on terms which included an agreement by the Home Office to hold a wider consultation
on the operation of Rule 35 of the Detention Centre Rules 2001. Pursuant to this agreement, on 26 March
2019 the Home Office invited the Claimant and other organisations to contribute to a _“targeted_
_consultation” on new 'Removal Centre Rules'. Regarding Rule 35, the Home Office stated that they would_
_“particularly welcome your suggestions on any further amendments that could be made to rule 35”. This_
consultation included the Claimant and others being invited to meetings with Dr Alan Mitchell, then an
Immigration Removal Centre GP and currently President of the European Committee for the Prevention of
Torture and Inhuman or Degrading Treatment or Punishment, whom the Home Office had commissioned
to review the role of evidence levels in relation to adults at risk policy and to make recommendations.

118. The Claimant submitted a 28-page written response to the consultation on 4 June 2019 and followed
up on 7 August 2019. A response from the Home Office, dated 9 September 2019, stated that there was
an intention to convene a meeting with NGOs to discuss the matter further. However, this meeting did not
take place and the new 'Removal Centre Rules' were not implemented. In late January 2020, however, Mr
Cheeseman emailed stakeholders including the Claimant with related proposed reforms. These are dealt
with below.

119. There was then a consultation in relation to DSO 04/2020 on Mental vulnerability and immigration
detention: non-clinical guidance. This followed the ruling of the Court of Appeal in _R (VC) v Secretary of_
_State for the Home Department_ _[2018] EWCA Civ 57 in February 2018, inter alia, that the procedures_
under which mentally ill detainees could make representations on matters related to their detention were
[contrary to the Equality Act 2010. In September 2019 Mr Cheeseman circulated a draft of this DSO to a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
small number of stakeholders including the Claimant for consultation, with a deadline for responses of 3
weeks. At the request of the stakeholders, on 8 October 2019 a meeting was held at which the Claimant
stated concerns about the absence of any proposal for independent advocacy for those with mental
incapacity and disability in Immigration Removal Centres. On 11 October 2019 the Claimant then followed
up with its written consultation response which included other concerns such as the processes for
identifying serious mental illness. In late January 2020 the Home Office circulated a further draft of the
DSO which had taken some of the Claimant's concerns on board. This draft was discussed further at the


-----

NASF DSG meeting in February 2020 and it was published on 23 July 2020, with stakeholders being
notified of this on the following day via the mailbox DSOConsultation@homeoffice.gov.uk. Ms Hanley says
that further amendments had been made which reflected some of the points which the Claimant had made.

120. Ms Hanley says that, from June 2020, there was consultation in relation to three proposed areas of
reform in relation to adults at risk. The Claimant and other stakeholders were invited to meet the Home
Office to discuss a document - “draft governing standards for external medical reports” – which had been
circulated in advance. These meetings took place on 8 and 23 June 2020 and the stakeholders followed up
with a joint letter on 3 July 2020 which set out their concerns.

121. Following this letter, on 5 August 2020 there was a further invitation for consultation from Mr
Cheeseman enclosing a document entitled _“Vulnerable individuals in Immigration Detention – Policy_
_Developments”. This highlighted three areas for reform namely: the introduction of quality standards for_
external medical reports; changes to the framework on detention of potential victims of trafficking; and
reforms to adults at risk safeguards, including a change to the approach to assessing immigration factors
concerning risk Levels 2 and 3, and expanding the range of health professionals who may be authorised to
carry out Rule 35 assessments.

122. The Claimant then attended a stakeholders meeting with the Home Office on 10 August 2020 to
discuss the proposals and, in a follow up letter, requested a widening of the group of consultees. On 9
October 2020, the Home Office indicated that it was willing to consider doing so.

123. In the event, only two of the proposed reforms were taken forward; quality standards in relation to
external medical reports and changes to the framework on detention of potential victims of trafficking. In
relation to the former, the Home Office circulated an updated draft of the proposals on 25 November 2020
and stakeholders including the Claimant were invited to a feedback meeting which took place on 4
December 2020. They were then invited to submit written evidence of their concerns, which the Claimant
and others did on 16 December 2020. Ms Hanley says that these concerns were raised _“during the_
_consultative process, which ran for an extended period from June 2020 to May 2021” when the revised_
Caseworker Guidance was published, although she does not detail what exchanges, if any, there were in
the first half of 2021. However, she says that some of the responses from stakeholders were taken on
board and gives examples.

124. Ms Hanley says that since May 2021 the Claimant and others have set out their concerns about the
revised quality standards including in writing on 23 July 2021. She raised the matter at the NASF DSG on 2
December 2021 and Ms Bethany Farr, who had become the relevant policy lead for the Home Office, said
that she would provide a response to these concerns. She did so on 8 February 2022 and agreed to make
some changes. There was further correspondence on this matter in March, May and September 2022.

125. Meanwhile, in August 2021, the Claimant was invited to comment on an amended DSO on the
Management of Adults at Risk in Immigration Detention. After requesting an extension of the deadline for
a response, it submitted comments and made recommendations such as introduction of Vulnerable Adult
Care Plan (VACP) which replaced the care plan in the previous iteration of the policy. When the updated
DSO was published on 5 August of 2022, it included some amendments which reflected submissions by
the Claimant. The Claimant was notified of its publication via DSOConsultation@homeoffice.gov.uk. on 10
August 2022 .

126. As to the second of the proposed areas for reform notified by the Home Office on 5 August 2020,
referred to above at [120], the detention of victims of **_modern slavery, this was also discussed on 10_**
August 2020. The Home Office stated that they were not planning to undertake a public consultation, only
to consult via NASF DSG stakeholders. Stakeholders were invited to provide written comments within two
weeks and the Claimant did so on 24 August 2020. There was a further meeting organised by the Home
Office on 26 November 2020 at which the Claimant gave feedback on the proposals and, on 25 February
[2021, the Immigration (Guidance on Detention of Vulnerable Persons) Regulations 2021 (SI 2021/184)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:6239-BFG3-GXFD-8274-00000-00&context=1519360)
were laid before Parliament.


-----

127. On 14 March 2022, the Home Office circulated a draft DSO entitled “Operational guidance: Detention
_Services Order XX/2022 Detention of Potential or Confirmed Victims of_ **_Modern Slavery” for comment._**
Stakeholders were originally asked to respond by 11 April 2022 but this deadline was extended in
response to a joint letter requesting a longer period of consultation, and that the circle of consultees
include the Immigration Law Practitioners' Association (“ILPA”) and anti-trafficking organisations. The
Claimant and the Helen Bamber Foundation submitted a joint response on 10 May 2022. An updated
DSO was then published online on 05 August 2022. The document included some small changes that
reflected the Claimant's comments, albeit the vast majority were not taken on board. When this was
raised at the NASF DSG meeting in September 2022, the Home Office responded that, given the volume
of comments received from stakeholders in respect of this DSO, it was not possible to enter into a detailed
dialogue about each point raised, but attendees were assured that all such concerns are considered.

128. There was also a consultation in relation to what became DSO 01/2022 on assessment care in
detention and teamwork. This is used by the Home Office to manage people in detention who have been
identified as being at risk of self- harm or suicide. A draft DSO was circulated to stakeholders on 13
December 2021, which was intended to replace existing DSOs on the subject – 06/2008 and 04/2006. The
original email stated that the consultation would run until 3 January 2022 but this was extended to 4
February 2022 after a joint request from certain stakeholders. The Claimant and others worked with the
Royal College of Psychiatrists to provide a response which was formally the response of the College
“supported by” the Claimant. The updated version of the guidance was published in June 2022 and it
reflected some suggestions contained in the College's response. The DSO was updated on 17 October
2022 but the changes were not material. These changes were notified via
DSOConsultation@homeoffice.gov.uk.

129. Against this background, understandably Ms Hanley expresses surprise and disappointment at the
approach of the Home Office to the Second Opinion Policy, which she contrasts with “normal practice” as I
have noted. Although the first version of this Policy was apparently published on 20 June 2022 and emails
were sent to ILPA members on 27 June 2022, the Claimant was not made aware of the new Policy until
after an updated version was published on the gov.uk website on 24 September 2022. There had been no
prior indication that the Home Office was considering the introduction of a policy of this nature, not even at
the NASF DSG meeting on 9 June 2022, 11 days before the Policy was first introduced. This was despite
the fact that an update on work in progress in relation to various DSOs was provided in advance of that
meeting. Ms Hanley also says that since March 2022 there had been a standing action point for this subgroup on the related subject of quality standards for external medical reports and this topic was the subject
of ongoing correspondence with the Home Office, as I have noted. She says, and I agree, that it is
surprising that no reference to the proposed Policy was made in this context either.

130. When concerns were raised about the lack of notification or consultation at the NASF DSG meeting
on 29 September 2022, Ms Farr said that there had not been any consultation on the Policy because it had
evolved from the work on quality standards for consideration of external medical reports. As part of the
work on standards, the Home Office had sought input from two (unnamed) consultant psychiatrists.
However, it was recognised that it could also be valuable to have clinical input into decision making and
this is what the Policy does. The two psychiatrists had been invited to provide input on the Policy.

_Arguments_

131. In her submissions, Ms Luh emphasised that she was not contending for a duty to consult in relation
to all changes in policy relating to immigration detention. Her case was that there was an established
practice of consultation with the Claimant and other relevant stakeholders on material developments in
policy in relation to adults at risk and the operation of the statutory framework in relation to them. I should
accept Ms Hanley's evidence about this which had not been specifically contradicted or undermined by the
Defendant.

132. In relation to the question of conspicuous unfairness, Ms Luh made comparisons with the facts of the
_Article 39 case and, in particular, emphasised the importance of the changes introduced by the Policy_
given their impact on the detention and/or the length of detention of individuals The Claimant and other


-----

relevant stakeholders were, in effect, the voice of adults at risk in the context of decisions about detention
and yet they had not been consulted about the Policy. The unfairness was compounded by what she said
was the consultation of two unnamed psychiatrists, with the result that there was a one sided consultation
in which those who represent the detainees and potential detainees were not heard.

133. Ms Luh submitted that Ground 3 could not be met with a claim that, ex post facto, the views of the
Claimant have been taken into account. Even if they have been, consultation is required before a decision
is taken. The Defendant acted unlawfully in introducing the Policy without prior consultation.

The Defendant's case

_Evidence and pleadings_

134. In its pre action protocol response dated 28 November 2022, the Defendant denied that there was a
duty to consult. However, it did so on the basis that the Second Opinion Policy did not materially alter the
policy position on consideration of evidence contained in external medical reports, so that it was not unfair
to fail to consult in relation to it. The letter also said that although the views of two psychiatrists were taken
into account before publishing the guidance:

_“this was not by way of consultation. These were two consultant forensic psychiatrists who have been_
_engaged by the Home Office to provide second opinion reports and their input was sought in relation to_
_points of process and about what they did and did not have the capacity to deliver within the second_
_opinion process. One of these psychiatrists was also asked to comment in advance on the principles of the_
_process, with which he agreed. Consequently, this step did not have a bearing on the question whether the_
_Home Office had a duty to consult….”_

135. The letter went on to reiterate a written apology for the failure to inform _“partners”, including the_
Claimant, of the introduction of the guidance when it was implemented. This apology had been provided to
members of the NASF DSG on 25 November 2022.

136. Notably the Defendant's pre action protocol response did not address, still less deny, the clear and
specific contention, made by the Claimant's solicitors in their pre action letter dated 7 November 2022, that
there was a duty to consult at common law given that “There has been an established practice of
_consultation on policies concerning the Adults at Risk statutory framework”._

137. The Detailed Grounds of Defence, dated 27 September 2023, say very little about the facts in relation
to Ground 3, which is addressed at [28]-[33]. [30] states that the Defendant:

_“.. categorically denies that there is an established practice of consultation…_

_31. Whilst MJ and other organisations have been invited to contribute to consultations in the past on a_
_variety of matters, it is not the position that any and all interim operational guidance that may be relevant to_
_detention (including detention of vulnerable individuals) has been put out for consultation prior to initial_
_implementation. Even MJ's own account of the instances of consultation relate to 'amendment' of existing_
_policies rather than a set process of all policies (including operational guidance) following a development_
_process where they are put out to consultation prior to development and introduction.  Such an approach_
_would be unworkable in practice and unnecessarily restrictive where a swift response may be required in_
_relation to operational developments. ”_

138. This plea appears to seek to avoid confronting the fact that the Claimant was not alleging a practice
of consulting on “any and all” interim operation guidance relating to detention. The clear allegation, at e.g.

[91] of the Statement of Facts and Grounds, was that the consistent practice of the Defendant was to
consult the Claimant and other relevant stakeholders on _“material policy developments and changes_
_concerning adults at risk”._

139. Similarly, the Detailed Grounds of Defence do not address the plea, at [94] of the Statement of Facts
and Grounds, that the Defendant had embarked on a voluntary consultation with the two psychiatrists and
that this was effectively admitted in its pre action response of 28 November 2022. The approach in the
Defendant's pleading is not to contradict Ms Hanley's evidence but to argue that it does not establish the


-----

Claimant's case and/or that relief should be refused because the views of the Claimant have now been
taken into account in any event.

140. Similarly, in his witness statement dated 28 September 2023, Mr Ledwitch-Madsen does not engage
with the evidence of Ms Hanley. He says that he is a Civil Servant who works in detention policy and that
his duties include responsibility for the Second Opinion Policy. But his statement does not explain whether
he knows about what consultation there may have been in the past and it does not appear that he is a
member of the NASF DSG group. No explanation is given for why Ms Farr, for example, did not provide a
statement dealing with Ground 3.

141. Mr Ledwitch- Madsen says that his statement focusses on the interpretation and effects of the
Second Opinion Policy:

_“Whilst I have been provided with the documents filed in support of the judicial review by the Claimant, I_
_understand that the various witness statements containing comment, opinion and anecdotal materials were_
_indicated not to be helpful by the Court at that hearing and I have not considered those materials in detail._
_Also, whilst the contents of the materials filed in support of the claim are not accepted by the SSHD, it is_
_not appropriate for me to comment further on them in circumstances where I understand they have be_
_deemed not to be (sic) relevant or helpful in determining the legal issues for decision”._

142. Bluntly, this appears at best misconceived in the light of what Williams J actually said. As noted
above, at [13] of her judgment giving permission Williams J said that the Claimant's witness statements
covered “perfectly proper subjects, including….the alleged established practice of consultation”. She said
that other parts of the witness statements, which sought to debate the merits of the Policy, were not helpful
but there is no doubt that the evidence of an established practice of consultation was “in play” for the
purposes of the Claim.

143. Mr Ledwitch-Madsen then deals with Ground 3 at [16]-[19] of his statement. His evidence in relation
to whether there was an established practice of consultation is at [17], where he says this:

_“Whilst this is a matter for the Court to determine, I confirm on behalf of the Home Office that it is not_
_accepted that there is an established practice of consultation on all operational policies of this nature prior_
_to their initial implementation. Certainly, there have been instances where particular policies or_
_amendments to policies have been subject to consultation in some part, or at some stage of their use or_
_development. Consultations are engaged in on an ad hoc basis, according a host of variable factors_
_including the subject-matter and time available. Consultation is not undertaken as part of any written or_
_unwritten set process and it do (sic) not follow an identical form in every instance.” (emphasis added)_

144. This does not appear to amount to a “categorical [denial]” and, from what he himself said and failed
to say in his statement, it is not clear that Mr Ledwitch-Madsen was in a position to make such a denial or,
indeed, to give reliable evidence on this issue. His reference to _“operational policies of this nature”_
apparently refers to the Second Opinion Policy but he does explain or define the category of operational
policy to which he is referring. He does not give any specific evidence or example to support the assertion
that the consultations which he apparently admits have taken place were “engaged in on an ad hoc basis”,
nor as to the application of the “host of variable factors” approach to a particular policy or policy change.
No example of an _“operational policy of this nature” which has been formed or amended without_
consultation is given by him.

145. Mr Ledwitch-Madsen goes on to argue that it would be difficult to devise a workable approach to
consulting on “these types of operational policies and guidance”:

_“The Home Office recognises the importance that constructive engagement with stakeholders can have_
_when designing and developing some policies but it does not follow that all policies could be, or should be,_
_subject to a set process of prior consultation or that this would universally be beneficial so as to justify the_
_delay incurred.”_


-----

146. Again, this observation appears to be directed at an argument which is not being made by the
Claimant. It is not contended that all policies should be the subject to consultation, nor that they must all be
subject to a set process which would not permit of any adaptation according to the circumstances.

147. Mr Ledwitch-Madsen then states, in somewhat vague terms, that there were discussions with
external stakeholders “relevant to the development of the standards in the AAR policy”. He says that one of
the benefits of the Second Opinion Policy was that it may act as a reminder to focus minds when providing
all reports, including MLRs, to ensure that all the relevant requirements were adhered to. _“Views were_
_expressed that there were no issues with the provision of reports to address….The views adverse to any_
_steps in this area were taken into account when the deciding at the strategic level to introduce the interim_
_second opinion policy, subject to review after 12 months”. This appears to be a reference to views_
expressed by external stakeholders in the context of the discussions about the quality standards in the
Caseworker Guidance to which Ms Hanley refers in her witness statement. Mr Ledwitch-Madsen does not
appear to be suggesting that the possibility of a second opinion process was discussed, and nor did Ms
Anderson. He adds that the initial review period and a further review period of 6 months allowed the
practical effects of the application of the Second Opinion Policy to be taken into account. He does not
appear to say that the views of stakeholders in relation to the Second Opinion Policy, since it was
introduced, have been taken into account.

148. Mr Ledwitch-Madsen did not provide evidence about the involvement of the two psychiatrists referred
to by Ms Farr in the NASF DSG meeting on 29 September 2022 and in the Defendant's pre-action
response. Nor did he provide any specific explanation for the failure to notify the Claimant and other
stakeholders of the proposal to introduce or, indeed, the introduction of, the Second Opinion Policy. He did
not suggest any reason, such as urgency, as to why there could not have been any consultation about this
Policy through the NASF DSG or otherwise.

_Arguments_

149. Ms Anderson's opening submission on Ground 3 was a surprising one. In her skeleton argument she
had referred to the criticisms of the Claimant's witness statements made by Lang and Williams JJ. She said
that the Defendant had prepared its evidence in response to the Claim on the basis of its understanding
that the materials relied on by the Claimants were not admissible for certain purposes including, _“as_
_evidence of facts whose resolution was required for determination of” the Claim. The Defendant had_
adopted an approach which was consistent with the overriding objective and had taken account of
resources and costs. She said, surprisingly, that it was “now understood that the Claimant continues to rely
_on the materials as evidence legally material to the determination of the Claim” (emphasis added) but the_
extent to which they could be relied on as evidence of primary fact was unclear. The parts of the evidence
relied on by the Claimant in relation to Ground 3 were “a mixture of discursive history from [the Claimant's]
_perspective….with some references to engagement with the Home Office”. The Defendant was content for_
the Court to consider these materials de bene esse with a view to assessing whether they could sustain
this part of the Claim. However, it might be necessary for the status of the materials to be considered
further in oral submissions.

150. Ms Anderson then began her oral arguments on Ground 3 with a submission that I should exclude
the evidence of Ms Hanley and other witnesses on behalf of the Claimant as to an established practice of
consultation. As I understood her argument it was that Ms Hanley's evidence was extensive and detailed
and based on consideration of voluminous documentation, not all of which was necessarily in the
possession or control of the Defendant. Researching or analysing the history of consultation related by Ms
Hanley would be costly and disproportionate to the issue to which it was relevant. To admit it in evidence
would be equally disproportionate and would be unfair to the Defendant. I should therefore decline to do
so. In answer to a question from the Court, Ms Anderson confirmed that the Defendant had not requested
copies of any of the documents relied on or referred to by Ms Hanley which were not exhibited by her
and/or were not within his possession or control.

151. Ms Anderson went on to argue that in any event the evidence relied on by the Claimant did not
establish a duty to consult it on any of the bases contended for Even on the Claimant's own case it had not


-----

been shown that there was an established practice of consultation which had the requisite clarity,
unequivocality and unconditionality. What Ms Hanley and others had described was intermittent or ad hoc
positive engagement by the Home Office with various entities to provide a forum for discussion, rather than
an established set practice of formal public consultations on new measures, with any defined group of
consultees, prior to their adoption. That engagement had been with various persons and groups at various
times and in relation to a variety of matters including matters arising from litigation. Neither party had
considered that they were acting pursuant to legal rights or obligations or a fixed expectation.

152. There was no statutory obligation to consult and no express assurance of consultation, nor any
written machinery or procedure for consultation which defined who was to be consulted about what and the
process which was required to take place. These matters, and therefore the content of the duty alleged by
the Claimant, were unclear. This is important given rule of law principles, which require a party to be able
to understand, in advance, the legal obligations to which they are subject: see Sales J (as he then was) in
_R (MH) v Secretary of State for the Home Department_ _[2009] EWHC 2506 (Admin) at [105], albeit in a very_
different context. Although the Claimant had pointed to the existence and terms of reference of the NASF
DSG there was no magic in the word _“consultation” (see_ _Eveleigh (supra) at [81]) and in any event Ms_
Hanley's evidence was not to the effect that consultation invariably took place through this forum.

153. Ms Anderson also submitted that reliance on “conspicuous unfairness” was contrary to “rule of law
_values”. The phrase did not have the quality of a legal test or principle. She relied on R (TN, Afghanistan) v_
_Secretary of State for the Home Department_ _[2015] UKSC 40, [2015] 1 WLR 3083 at [71] where, she_
pointed out, the Supreme Court rejected an approach based on conspicuous unfairness which had been
adopted in R (Rashid) v Secretary of State for the Home Department [2005] Imm AR 608 CA, albeit again
in the context of very different issues.

154. As far as voluntary consultation is concerned, in addition to pointing out that the question whether

[108] of the judgment in Coughlan is binding or correct was left open in Eveleigh, Ms Anderson submitted
that _“ taking advice from two medical experts in relation to medico-legal reports” did not come close to_
meeting the requirements for judicial intervention. In her oral submissions she said that the two had given
advice about the feasibility of the proposal rather than being asked, as stakeholders, whether they thought
it was a good idea. This did not amount to engaging in public consultation, and unfairness would only have
arisen if the Home Office had consulted with one interest group but not another. The facts of the Article 39
case were, she submitted, very different.

155. Ms Anderson also made the point that the Second Opinion Policy is described as _“Interim”. It was_
introduced for a period of 12 months and was then subject to a review. She went on to argue that since the
Claimant had now provided its views and these had been taken into account relief should be refused. The
matter was now academic and/or relief would serve no useful purpose.

**Discussion and conclusion on Ground 3**

156. I reject Ms Anderson's submission that I should exclude the evidence of Ms Hanley and other
witnesses for the Claimant which was relevant to Ground 3. As Williams J said in granting permission, that
evidence was perfectly properly before the Court. Ms Anderson did not point me to any authority which
would permit me to exclude the whole of the evidence relied on by a party, on a given issue,
notwithstanding that it is highly relevant, on the grounds that an opposing party considered that it was
disproportionate or onerous to prepare evidence in response. The Defendant was clearly in a position to
carry out the necessary research and/or proof the relevant witnesses in the months since proceedings
were issued, if he chose to do so. He cannot rely on his decision not to take these steps as a basis for
contending that, in effect, the court should not entertain Ground 3.

157. In any event, it would not have been unduly onerous for the Defendant to take the necessary steps.
This is particularly so given that he could have chosen to give examples rather than cover the whole
history, as Ms Hanley purported to. The bar in terms of establishing a legitimate expectation based on an
established practice is a high one, as I have noted. He could have given evidence of examples of ad hoc


-----

consultation, or of where the dialogue relied on by the Claimant did not amount to consultation, or where
there was no consultation on an issue relating to adults at risk at all.

158. It therefore would not be in accordance with the overriding objective for me to exclude the evidence
relied on by the Claimant in relation to Ground 3. I also accept that the evidence of Ms Hanley is an
essentially accurate account of the primary facts. I am mindful that where there is a conflict of evidence in
the context of judicial review, the court should normally accept the evidence of a witness for the Defendant
unless there is good reason to do otherwise (see, e.g. _R. (on the application of Soltany) v Secretary of_
_State for the Home Department_ _[[2020] EWHC 2291 (Admin) at [87]). But Mr Ledwitch-Madsen did not go](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60NM-YP93-CGXG-04D6-00000-00&context=1519360)_
further than to say that he did not accept that there was an established practice, which is a conclusion
based on the evidence, and which he acknowledged is an issue for me to determine. He did not actually
contradict Ms Hanley's account in any material respect, including her frequent references to “consultation”
between the Claimant and relevant stakeholders and the Home Office. He did say that the consultations
were “ad hoc” but did not give any specific evidence in support of this assertion. Given that he began his
witness statement by saying that he had not considered the Claimant's evidence in detail and that it was
not appropriate for him to comment further, and given that he does not claim to have personal knowledge
of the history related by Ms Hanley, what he says on this point is no more than assertion and can be given
little weight.

159. The more difficult question is whether Ms Hanley's evidence does establish a practice of consultation
which was “so consistent as to imply clearly, unambiguously and without relevant qualification that it will be
_followed in the future”. With some hesitation, I have concluded that it does. The main reasons for my_
hesitation were the fact that the bar is a high one and the fact that the consultation described by Ms Hanley
does not follow a uniform or standard pattern. The existence and terms of reference of the NASF DSG do
appear to me to be significant but Ms Hanley did not go further than to say that consultation was “often”
through this group. She also makes clear, in the passage from [19] of her witness statement which I have
cited at [107] above, that sometimes the consultation is with a select group of stakeholders. And she gives
examples in her evidence, some of which I have noted, where the Claimant and other stakeholders argued
for a wider group of consultees than had initially been approached by the Home Office and/or requested a
longer period of consultation. She accepts that the engagement with stakeholders is not always referred to
as “consultation” and the engagements which she describes do appear, in a number of instances, to have
an informal quality and to have taken place over extended periods of time, with a number of lulls. I was
also uneasy about the fact that Ms Hanley did not exhibit the underlying documents to which she referred
in her account of the consultation which had taken place.

160. However, Ms Hanley's statement that for over 15 years the Claimant has “consistently” been invited
to respond to consultations on Home Office policies concerning immigration detention, healthcare
arrangements and management of risks to and safeguarding of detained persons, is effectively
uncontradicted by evidence from the Defendant. So is her evidence that this is _“routinely” the practice,_
particularly since 2016. And so is her statement that, having reviewed the Claimant's records going back to
2016 “we have not been able to identify a key policy development or change in policy affecting adults at
_risk on which the Home Office did not seek our views and the views of other similar NGO stakeholders at a_
_stage when the policy was only in a draft form”. Nor has her description of the lack of consultation about_
the Second Opinion Policy as _“a departure from normal practice” been specifically contradicted. The_
account which Ms Hanley then gives of the consultations which have taken place, which was
uncontradicted by evidence as opposed to assertion, provided ample support for her summary of the
position.

161. In relation to my concern about the lack of uniformity of approach in terms of the use of the NASF
DSG and the number of consultees, Ms Luh pointed out that the requests by the Claimants and other
stakeholders for additional consultees were where it was considered that bodies which were not members
of the NASF DSG had valuable expertise in relation to the particular subject matter of the consultation. The
underlying approach of the Home Office was to consult with the members of the NASF DSG or sub groups
of its members according to the subject matter of the relevant policy and the area of expertise of the
particular members. Moreover, the key point for present purposes was that policy matters relating to adults


-----

at risk in detention were within the expertise of the Claimant and, on the evidence, the Claimant was
consistently consulted in relation to material issues arising in this area, regardless of who else was.

162. As for Ms Anderson's arguments based on there not being a set machinery or procedure for
consultation, the parties agreed that the question is one of substance rather than form. To my mind the key
point is that the evidence establishes a clear pattern of seeking the views of the Claimant in relation to
policy proposals and changes in the area of adults at risk, the Claimant providing those views, the views
being taken into account by the Defendant and a decision being taken i.e. in broad terms, compliance with
the _Gunning criteria. Effectively, there was a continuing dialogue with the Claimant about relevant policy_
changes. In my view it is not necessary for the Claimant to establish an invariable procedure or timetable
which has been followed in every case, provided it is clear that the Home Office has consulted with the
Claimant with sufficient consistency to imply, and thereby generate a legitimate expectation, that it will
continue to do so absent sufficient reasons to do otherwise.

163. As to my uneasiness about simply relying on Ms Hanley's account of the consultation which has
taken place without, myself, seeing the underlying documentation, her evidence was not specifically
contradicted, as I have said. Nor did the Defendant take this point or seek to have the documentation or
any of it put before the court. Ultimately I therefore did not see any reason why I should not take Ms
Hanley's account at face value. Consistently with this approach, having asked Ms Luh a number of
questions which sought to clarify aspects of Ms Hanley's evidence I indicated that, on reflection, I would not
take her answers into account insofar as they materially added to the evidence already before the Court. If
she wished to rely on additional points, an application to adduce further evidence would have to be made.
Otherwise, I would go off the evidence in the witness statements as drafted. No such application was
made.

164. Nor do I attach significant weight to Ms Anderson's assertion that in the minds of the relevant civil
servants or, indeed, the stakeholders it was not considered that there was any legal obligation to consult: in
effect, that the consultation was considered by the parties to be voluntary. Even if this were supported by
specific and/or reliable evidence, which it is not, the question whether a duty to consult arose is an
objective one for the court rather than depending on the subjective views of the parties.

165. I therefore uphold Ground 3 on the basis that the Claimant had a legitimate expectation of
consultation about the Second Opinion Policy, no real attempt to explain or justify the failure to consult
having been put forward by the Defendant in the context of the Claim. Had I not found that there was a
legitimate expectation of consultation, I am doubtful that I would have held that there was a duty to consult
on the alternative bases advanced by Ms Luh:

i) There is some uncertainty as to the precise role of “conspicuous unfairness” in this area of the law: as to
whether Hallett LJ's fourth category was intended to create a free standing public law principle over and
above existing principles of fairness, legitimate expectation and rationality and, if so, as to the scope of that
principle (in addition to the _TN case relied on by Ms Anderson, see_ _R (Gallagher) v Competition and_
_Markets Authority_ _[2018] UKSC 25, [2019] AC 96 at [40]-[41] on which I was not addressed). Moreover,_
although I accept that the consequences of the Second Opinion Policy were important, that it would have
been useful to consult the Claimant and other bodies which represent the interests of adults at risk in
detention, and that the approach of the Defendant was surprising and discourteous, the present case does
not appear to me to be comparable to the sort of case envisaged by Laws LJ in his judgment in _Bhatt_
_Murphy, for example at [49]. However, these issues were not fully argued before me and I therefore do not_
express any final view on them.

ii) As for Ms Luh's arguments based on the Article 39 case, whether the issue was considered to be one of
rationality, fairness or conspicuous unfairness, the key foundation for the decision of the Court of Appeal
was the fact that, on any view, there had been a consultation process from which the Children's
Commissioner and other bodies which represented the rights and interests of children had been excluded.
The complaint was about their exclusion from this process and considerations such as the importance of
the changes which were proposed and the fact that the views of bodies with different interests were being
taken into account then provided a basis for concluding that public law principles had been breached by


-----

this exclusion. Although the way in which the Defendant has failed to address the evidence about the
involvement of the two psychiatrists in the present case is highly unsatisfactory, on the information
available I am prepared to accept Ms Anderson's characterisation of what happened as taking advice
rather than public consultation. At all events, what happened does not appear to be comparable with the
consultation process in the _Article 39 case. In the present case there does not appear to have been a_
consultation process from which the Claimant was unfairly (or irrationally, though this was not alleged)
excluded and/or failure to involve the Claimant in the way that the two psychiatrists were involved did not
breach these public law principles.

**RELIEF**

166. As far as relief is concerned, I would propose to quash the Second Opinion Policy pursuant to
Grounds 1 and 2. Ms Anderson's argument in relation to relief in relation to Ground 3 is therefore
somewhat academic but, for the avoidance of doubt I reject it. She did not rely on section 31(2A) of the
Senior Courts Act 1981. Her argument, as I understood it, was that Ground 3 is academic given that the
views of the Claimant have been taken into account. I am not clear that there is evidence that this is so, as
I have noted. Certainly, the evidence does not establish that conscientious consideration has been given to
the concerns which the Claimant would have raised had there been consultation about the Policy when it
was in draft or, indeed, the concerns which have been expressed since it was introduced. In any event, I
agree with Ms Luh that the court should be slow to refuse relief on the basis of self-serving assertions of
the sort relied on by the Defendant given that the point of the duty to consult is that the consultation takes
place in advance of the decision being made.

**End of Document**


-----

