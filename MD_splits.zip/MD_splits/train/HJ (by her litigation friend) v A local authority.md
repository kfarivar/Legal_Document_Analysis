# HJ (by her litigation friend) v A local authority [2021] EWHC 66 (Admin)

Queen's Bench Division, Administrative Court (London)

Hugh Mercer QC (sitting as a deputy judge of the High Court)

18 January 2021Judgment

**Marisa Cohen (instructed by [a firm]) for the Claimant H. Harrop-Griffiths (instructed by [a firm]) for the**
**Defendant**

Hearing date: 18 November 2020

--------------------
**Approved Judgment**

Covid-19 Protocol: This judgment was handed down remotely by circulation to the parties' representatives by email,
release to BAILII and publication on the Courts and Tribunals Judiciary website.

The date and time for hand-down is deemed to be 10:00 am 18 January 2021.

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

**Hugh Mercer QC sitting as a Deputy Judge of the High Court:**

Background Facts

1. The Claimant, HJ, is a young woman from Vietnam. She says that she left Vietnam in October 2019 as
an unaccompanied child and arrived in the United Kingdom on 24 November 2019.

2. HJ was discovered on 15 January 2020 by the police at an address in Greenwich where they were
attending for an unconnected purpose. The room in which she slept had a padlock on the outside of the
door and the only person in the residential unit was a single male in his twenties whom she knew as
Cuong. She described working on two occasions in a nail bar some distance from where she was found
and receiving no payment.

3. The notes of her interview on 15 January with two social workers of the Interested Party (RBG) record
that she believes her sole surviving family member, her mother (who had been forced to flee Vietnam due
to her adherence to the Hoa Hao religion), to be in the United Kingdom. Until the age of 8 years, she lived
with a grandmother but on the grandmother's death she lived on the streets and found work dishwashing
whilst also attending school in the mornings. She said her father died in an accident when she was 1 or 2
years old.

4. HJ described travelling by air via China to Russia and from there travelling by lorry. In Russia all
luggage and papers were taken from HJ and those she was travelling with. She described passing
between various Vietnamese men and women, in particular when she got out of the lorry in England she
had a lift from a Vietnamese woman to London and then meeting a Vietnamese man on a train which led
her to the address where she was found.


-----

5. As regards her age, she had told the police that she was [an age] years old with a date of birth of [a
date]. The police expressed the view in their report that she did not look 15 years old but rather late
teens/early 20s. She was recorded by the police as “very upset by the police presence”. The police
contacted social services and the police note envisages that at least part of the social services' role was to
“assess her real age”. I have seen manuscript notes of the interview and an undated typed note of
interview with HJ ('the typed interview record').

6. The Defendant's Summary Grounds assert that the Claimant must have understood that the social
workers were assessing her age. However, it would appear that the interview was a preliminary interview
conducted at the police station when much information was missing. The Person Case Notes record for
example that neither the methods of transportation to which HJ had been subjected nor the experiences of
HJ were known and she was described as not providing much information. The witness statement of her
solicitor, Yen Ly, records that a Vietnamese interpreter confirmed that there are no social services in
Vietnam and that the term translates as “government employed people who help”. HJ's evidence is that the
two social services persons who attended the police station did not explain the purpose of the interview.
The purpose of the interview is recorded in the Person Case Notes as to establish identity, ensure she is
provided with appropriate services and to ensure that she is not unlawfully detained. Reference is also
made to the police impression that she is older than 15 years and “following a visit by

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

_Assessment team it has been established that the YP is over 18 years and therefore is an adult”. There is_
no suggestion that HJ was told that her age was being assessed or indeed that adverse material was put
to her. On the evidence I cannot proceed on the basis that HJ must have understood that her age was
being assessed by social workers.

7. The first striking feature of the social services interview is that HJ was frank about the fact that she had
lied to the police about her age saying that she was born on 17 January 2004 when she told social services
that the true date was 17 January 2003. The notes refer to her saying that she was 17 years of age when a
birth date of 17/01/03 would make her 16 years on 15 January 2020 but it is not clear that she was aware
of the precise date of the interview. The reason she gave for telling the police that she was 15 years old
was that if she said she was younger the police would not hit her.

8. The second striking feature of the social services interview is the absence of reference to the possibility
that HJ might have been trafficked. The practice guidance _Safeguarding children who may have been_
_trafficked (2011) provides at §5.9 a list of possible indicators that a child may have been trafficked which_
include having a history with missing links and unexplained moves; rarely leaving the place of residence;
being permanently deprived of a large part of their earnings by another person; being excessively afraid of
being deported. §5.10 goes on to caution that the list is not definitive and that other unusual factors may
indicate that the person has been trafficked.

9. I refer to the Defendant's referral under the National Referral Mechanism dated 14

April 2020 which relied on factors including exploitation, excessive house chores, regular patterns of
leaving and returning to residence indicating working, limited freedom of movement, movement into, within
or out of the UK, unable or reluctant to give accommodation or personal details and “psychological –
_indications of trauma or numbing”. A point which Mr Harrop-Griffiths makes for the Defendant is that the_
Interested Party could have made this referral under the NRM on 15 January 2020. That seems a fair point
to make though this judgment does not seek to apportion responsibility as between RBG and Croydon but
[to assess the legality of the refusal of the Defendant to assess HJ on 21 January 2020 under its Children](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
_[Act 1989 obligations.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_

10. That said, when a young Vietnamese person is found living in a room with a padlock on the outside of
the door, describes working for no payment in a nail bar, gives a vague account of apparently chance
encounters with a series of Vietnamese persons as part of her journey and provides no suggestion as to
how she might have paid for her passage from Vietnam, it is difficult to see how such an account did not


-----

provide to the RBG social workers possible indicators of HJ being the victim of trafficking. In that context
however, I do note that the first reasonable grounds decision of 1 May 2020 found that there were not
reasonable grounds to conclude that HJ was a victim of modern slavery (“due to the lack of information
_provided”, the Defendant not having responded to a request for information) albeit that a reassessment on_
16 October 2020 found that there were reasonable grounds so to conclude. A further decision on whether
there are Conclusive Grounds is awaited.

11. The reference by the Defendant's NRM referral to indications of trauma or numbing is potentially
significant. She is recorded by the RBG social workers on 15 January 2020 as having avoided eye contact
for much of the interview and consistently looking down.

I note an entry in one of the manuscript notes of that interview which reads “Let sleep

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

_2/3m” which I understand to be recording that the interviewers allowed HJ to sleep for 2-3 minutes during_
the latter part of the interview. I also note in this context Article 13 of the Council of Europe Convention on
Action against Trafficking in Human Beings (2005) according to which, if there are reasonable grounds to
believe that a person is a victim of trafficking, they should be provided with a “recovery and reflection
_period” of at least 30 days. I refer later to the trafficking context but I simply note at this stage that 15_
January 2020 was without doubt a long and tiring day for HJ after what is admitted to be unknown methods
of travel and experiences during travel and that this is a factor which would need properly to be taken into
account when assessing HJ's conduct and/or credibility on 15 January.

12. At all events, the conclusion of RBG social services the typed interview record apparently written up
some time after 15 January 2020 was that HJ “looks older than the age she claimed to be, we would
_estimate her to be in her early 20s”. The basis of this is expressly her physical appearance but it is followed_
by reference first to the state of her fingertips which “do appear to have been tampered with appearing
_flaky either because of excessive detergent use or being filed away”. Given that, on the social workers' own_
notes, HJ's account was that she supported herself from the time of her grandmother's death by earning
money washing up, it would be strange if this were a conclusion that there had in fact been tampering with
finger tips. The second aspect relied upon is a reference to HJ's lie as to her age and date of birth but
without reference to the fact of her frankness in admitting this to the social workers and without apparently
taking into account her evident distress in front of police officers as noted in the police report. The third
aspect relied on is alleged inconsistencies in HJ's account and “parts that did not seem credible”. It is
difficult at this distance to evaluate those alleged inconsistencies but it is not suggested that any of them
were put to HJ at the time. Also Ms Cohen drew my attention to the first reasonable grounds decision on
the trafficking issue of 1 May 2020 where it is stated that “Looking at the available sources of information

_[as listed earlier in the decision], it is recognised that you have been broadly consistent in your account and_
_there are not considered to be any significant credibility concerns with your account”._

13. As already quoted, the conclusion on the day in the Person Case Notes had been that HJ was over 18
years and therefore an adult. It is not stated that HJ was informed of this conclusion or that she was given
any paperwork to communicate that conclusion. It would appear to be the conclusion in the Person Case
Notes which was adopted by the Home Office.

14. After the interview with the RBG social workers, HJ recalls being put back in her cell and later being
interviewed by an immigration officer from the Home Office who told HJ that her age was not accepted. On
15 January 2020, the Home Office granted immigration bail with a requirement on HJ to appear at Lunar
House in Croydon on 22

January 2020. Her date of birth was recorded as [a year] and an “alias” date of birth of [a year]. The
relevance of that reference to an alias appears to be a reference to her own account of her date of birth.
The Home Office appears (though we have no specific information on this) to have adopted the RBG social
services conclusion that HJ was over 18 years by inserting a date of birth making HJ [an age] years on [a
date].


-----

15. What appears to follow next is that HJ came into contact with the Refugee Council, I was informed
through having contacted immigration solicitors in Wimbledon. With their assistance, HJ was referred by
the Refugee Council to the Defendant on 17 January

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

2020 but the Defendant refused to assess her and advised her to approach the Home Office. Lunar House
being closed, HJ went to the police station. It is not clear whether HJ's presence in Croydon was the result
of the instruction in her grant of immigration bail to attend at Lunar House on 22 January 2020 combined
with her desire to avoid returning to the address where she had been found in Greenwich or the result of
solicitors' advice or her coming into contact with the Refugee Council.

16. On 20 January 2020, HJ returned to the Defendant in person which again refused to assess her on the
basis that responsibility lay with Greenwich. HJ's solicitor responded that the Refugee Council had
concerns about the nature of the relationship between the Claimant and the man at the property in
Greenwich such that it would not be desirable for her to return there. In fact she did return to the address in
Greenwich for each night between 15 January and 20 January inclusive.

17. On 21 January the Claimant returned to the offices of the Refugee Council in Croydon. There was
further email correspondence with the Defendant and HJ was taken to the offices of the Defendant. The
Defendant maintained that the Claimant should present to RBG according to the terms of the Pan London
Protocol for Unaccompanied Asylum-Seeking Children (“the Protocol”). On the hearing of an application for
interim relief on the evening of 21 January, HJ's counsel expressed the view that RBG would be the
responsible borough under the Protocol and that it would be obliged to accept a referral but that the
Protocol is an agreement which does not override the Defendant's statutory obligations.

18. Mrs Justice Steyn granted interim relief to HJ ordering that the Defendant forthwith secure that suitable
age appropriate accommodation be made available for the Claimant. The interim relief has since been
continued and the result is that, pursuant to arrangements put in place by the Defendant, HJ has been
living with a foster carer who accompanied HJ to court on the hearing of this application for judicial review.

19. The Defendant's summary grounds disclose that the Defendant became aware – from contact with the
Home Office - of an age assessment by RBG on 22 January. The

Defendant obtained a copy from RBG who call it a “preliminary assessment”. It follows that, when refusing
to assess HJ as a child in need under the _[Children Act 1989 on 17, 20 and 21 January 2020, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
Defendant was not aware that there had been a preliminary assessment of HJ's age by RBG.

20. The target of this application for judicial review is the last of the three decisions and we know that the
Defendant knew that RBG was involved in some way because of the reason given for not assessing HJ on
20 January 2020 which was that RBG was responsible. Such knowledge could of course have come from
HJ and not necessarily from any contact by the Defendant with RBG.

21. The last event of January was that HJ's solicitor sent pre-action correspondence to RBG explaining
why the age assessment was unlawful to which RBG responded that proceedings had been properly
brought against the Defendant in whose area HJ was present at the time. David Lock QC in a judgment of
11 February 2020 refused to join

RBG as a Defendant but ordered that RBG be joined as an interested party. RBG's response to the letter
before claim crystallises the on-going dispute between RBG and the Defendant who each believe that the
other authority is responsible for HJ. The problem for both authorities, in terms of sorting out the
responsibility for any support

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

provided to HJ, is that this is not a case where one authority is judicially reviewing another authority but
[rather a decision on the legality of the Defendant's refusal to assess HJ under the Children Act 1989.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)


-----

The statutory context

22. By section 17(1) Children Act 1989, it is the general duty of every local authority:

“(a) to safeguard and promote the welfare of children within their area who are in need;

…

by providing a range and level of services appropriate to those children's needs.”

23. Section 27 CA 1989 entitled “Co-operation between authorities” provides:

“(1) Where it appears to a local authority that any authority [...] mentioned in subsection (3) could, by taking
any specified action, help in the exercise of any of their functions under this Part, they may request the
help of that other authority [...], specifying the action in question.

(2) An authority whose help is so requested shall comply with the request if it is compatible with their own
statutory or other duties and obligations and does not unduly prejudice the discharge of any of their
functions. …”

24. Section 51 of the Modern Slavery Act 2015 provides:

“Presumption about age

(1) This section applies where—

(a) a public authority with functions under relevant arrangements has reasonable grounds to believe that a
person may be a victim of human trafficking, and

(b) the authority is not certain of the person's age but has reasonable grounds to believe that the person
may be under 18.

(2) Until an assessment of the person's age is carried out by a local authority or the person's age is
otherwise determined, the public authority must assume for the purposes of its functions under relevant
arrangements that the person is under 18.

…”

Discussion

25. Ms Cohen for HJ submitted that the Defendant was not entitled to refuse a child a needs assessment
as it did on 17, 20 and 21 January 2020. She took as her starting point Lord Nicholls' judgment in R(G) v.
_Barnet LBC_ _[2003] UKHL 57 at §32 where he said:_

“The first step towards safeguarding and promoting the welfare of a child in need by providing services for
him and his family is to identify the child's need for those services. It is implicit in section 17(1) that a local
authority will take reasonable

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

steps to assess, for the purposes of the Act, the needs of any child in its area who appears to be in need.
Failure to carry out this duty may attract a mandatory order in an appropriate case …”

26. On the issue of “within their area” in section 17, Ms Cohen cited R(G) v. Southwark LBC [2009] 1 WLR
1299in which Lady Hale had to consider whether a child in need within its area requiring accommodation
within the meaning of _section 20(1) could be referred by the local children's services authority to the_
housing authority. Lady Hale first recalled Rix LJ's dissenting observation in the Court of Appeal with
regard to whether it was open to children's services to arrange for the child to be accommodated under the
homelessness provisions: “because a child, even one on the verge of adulthood, is considered and treated
_by Parliament as a vulnerable person to whom the state, in the form of the relevant local authority, owes a_
_duty which goes wider than the mere provision of accommodation”. Lady Hale continued at [28(3)]:_


-----

“Is he within the local authority's area? This again is not contentious. But it may be worth remembering that
it was an important innovation in the forerunner provision in the Children Act 1948. Local authorities have
to look after children in their area irrespective of where they are habitually resident. They may then pass a
child on to the area where he is ordinarily resident under section 20(2) or recoup the cost of providing for
him under section 29(7). But there should be no more passing the child from pillar to post while the
authorities argue about where he come from.”

27. It seems to me that those words do assist HJ here. Lady Hale was concerned with a

“sofa surfing” young person sleeping in cars or on friends' sofas. As noted in the quotation, whether the
young person was within Southwark's area was not in issue in that case and so strictly that passage might
be regarded as obiter on the issue of “within their area”. However, it is a much cited passage and it is an
authority on the need to postpone argument as to which of two bodies are in fact responsible for applying
_sections 17 and/or 20 Children Act. Local children's services are to apply the Act and may not arrange for a_
child be accommodated under homelessness provisions. This supports an approach whereby local
children's services may not pass on their responsibility to some other authority.

28. The Claimant moves next to the judgment of Mr Justice Cobb in R(AM) v. Havering LBC [2015] EWHC
_1004 (Admin) where he determined at [33(xii)] that the duty to assess the needs of children falls primarily_
on the children's services authority for the area in which the children are physically present, even if living
there only temporarily. He read section 17 with Schedule 2, Part 1 and the reference in para. 4(2) to “a
_child who is at any time within their area”. He noted a case relied on by the Defendant in this case, the_
decision of Bean J in R(HA) v. Hillingdon [2012] EWHC 291, and Bean

J's comment that something other than a “simple geographical test” is necessary to avoid “dumping” cases.
Mr Justice Cobb commented that no alternative to a geographical test was proposed by Mr Justice Bean.

29. The Defendant's Skeleton Argument does not dispute the physical presence test but the Defendant's
counsel did take me to Mr Justice Bean's judgment. In that case, Hillingdon had assessed HA to be an
adult and as a consequence he had been placed in National Asylum Support Service accommodation in
Birmingham's area. HA challenged Hillingdon's assessment and Hillingdon said that Birmingham should

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

provide interim relief because Hillingdon had discharged its duty. The Defendant relies on [14] in Bean J's
judgment where he observed that Parliament cannot have intended a simple geographical test for section
_20 as otherwise a claimant dissatisfied with an age assessment could just travel to another local authority_
and request to be reassessed. Such a test would also in Bean J's judgment encourage dumping of
applicants by one authority on another. In the event, Bean J accepted that concurrent duties may be owed
by one or more authorities but he focused (at [22]) on the precise nature of the challenge which was a
challenge to Hillingdon's termination of services following their age assessment which was argued to be
unlawful.

30. R(HA) v. Hillingdon would be directly in point had the interim relief in this case been granted against
RBG which then wanted to terminate its services on the basis of its preliminary age assessment of 15
January 2020 but that is not how this case comes before me. I am concerned with the refusal of the
Defendant to assess HJ at a time when they and HJ were unaware that RBG had carried out a preliminary
assessment of

HJ's age.

31. To return to Cobb J's judgment in _R(AM) v. Havering LBC, he cited the judgment of Mr Justice_
Beatson in R(Stewart) v. Wandsworth LBC _[[2001] EWHC Admin 209 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-615M-00000-00&context=1519360)_

[30] (children attending school in LB Wandsworth and residing in LB Lambeth both had a section 17 duty)
as authority for the proposition that more than one local authority can owe a duty to assess under section
_17 to the same child in need who may be physically present in their area. This authority was relied on by_
the Claimant here who points out that both RBG and the Defendant owe a section 17 duty in this case


-----

Bean J also referred to Beatson J's views in that case whilst noting that there was no dispute about age in
the R(Stewart) case.

32. Bean J found more apposite however, at least to determine R(HA) v. Hillingdon LBC, the decision of
the Court of Appeal in _R(Liverpool CC) v. Hillingdon LBC_ _[2009] EWCA Civ 43. That was a case where_
Liverpool had assessed a claimant's, AK's, age and determined that he was an adult whereupon he was
placed in Hillingdon's area. On the basis of new evidence, AK sought a re-assessment of his age which
Hillingdon refused to undertake. The claimant expressed a preference to live in Liverpool and so Hillingdon
removed him to Liverpool and contended that they could not owe him any section 20 duty. In contrast to
this case, that case was directly concerned with whether

Liverpool or Hillingdon was responsible for assessing AK's age because Liverpool had issued judicial
review proceedings claiming that Hillingdon had a statutory duty to conduct an age assessment and to
provide AK with section 20 accommodation.

33. Dyson LJ at [35] found that Hillingdon had failed to give any consideration to AK's welfare needs, to
assess those needs or the requisite accommodation to fulfil those needs. Hillingdon also did not take
account of his age as they did not know what it was. He continued at [38]:

“But in my view there was no performance of the section 20 duty at all in his case. Hillingdon did not even
carry out a reassessment of AK's age to see whether the Children Act applied. They regarded this as the
responsibility of Liverpool. They showed both by their words and their actions that they were not accepting
that they were under a section 20 duty.”

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

34. It was on that basis that Dyson LJ determined in Liverpool's favour that Hillingdon did not discharge its
duty under section 20. Rix LJ concurred but added separate reasoning on the concurrent duties issue.
Hillingdon's counsel in that case had conceded that, if

Hillingdon had failed to discharge its section 20(1) duty, then it was liable, to the exclusion of Liverpool, for
properly assessing AK's age. Rix LJ was prepared to accept that, if Hillingdon had not discharged its
section 20 duty, then, _as between Hillingdon and Liverpool, Hillingdon's responsibility was complete. He_
added at [44]:

“… I would prefer for myself to be cautious about whether it might not after all be possible for two local
authorities to have a concurrent duty to a child: on the ground that the child was a child in need in the area
of each successively in circumstances where the first local authority had not discharged its duty before the
second authority had acquired its duty on the child moving or being moved into its area. After all, the
statute is concerned with the interests of the child before that of adjusting the responsibilities of separate
local authorities.”

35. He added that settling up between authorities is a separate issue which might be resolved by
reference to statute or, for cases outside relevant provisions, adjustments might need to be arranged
without statutory sanction.

36. Before Bean J, it was argued that Liverpool v. Hillingdon had been to some extent overtaken by R(A)
_v. Croydon LBC as Liverpool would be unable to discharge their duty by an age assessment which turned_
out on appeal to be incorrect. The Defendant relies in similar reasoning here. Furthermore, it was argued
before Bean J that Liverpool v. Hillingdon illustrated a further point which is that an unlawful act (such as

Hillingdon's termination of services following an age assessment which was under appeal in _R(HA) v._
_Hillingdon or Hillingdon's refusal to perform its s. 20 duty in the_

Liverpool case) does not discharge any duty owed by the local authority. Whilst that is a fair point to make,
I do not see that it takes matters forward in this case. As Bean J recognised, concurrent duties may be
owed. But the issue for this case is not whether RBG and Croydon both owed duties to HJ. Rather the
question is whether the


-----

Defendant's refusal on 21 January was unlawful or not.

37. The relevance of Liverpool v. Hillingdon to this case appears in my judgment to be that Croydon sits in
the shoes of Hillingdon and RBG is in the shoes of Liverpool. Thus, even though Hillingdon was the second
local authority the case is authority for the proposition that the second authority in whose area a putative
child is found can owe a duty under section 20 and it is not clear to me that Dyson LJ would have modified
his criticism of Hillingdon for not assessing AK's age had R(A) v. Croydon already been decided. The tenor
of Dyson LJ's judgment is that a local authority cannot simply decline to engage as Hillingdon had done in
that case – and Croydon in this case. Though there is much to be said for the proposition that RBG has not
discharged its duty by a preliminary assessment of age, it does not follow that the Defendant had no duty
to HJ.

38. The Defendant's submission is the more limited one that HJ had an alternative remedy to seeking
judicial review of the Defendant's refusal to assess her as a child which was to appeal the determination of
age by RBG. Clearly, as noted by Cobb J in R(AM) v. Havering LBC at [33(xiv)] (citing Stewart at [28] and
_R(M) v. LB Barking & Dagenham [2002] EWHC 2663 (Admin) at [17]), it is essential that two councils_
involved in assessing a child in need should cooperate with each other and share the burdens.

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

Though I can see that the statutory framework for cooperation and reimbursement of the costs involved
does not appear to be complete, for London the situation seems to have been the subject of some
upgrading by the Protocol referred to earlier.

39. But there is no indication in the statute that a lack of cooperation and/or an absence of a mechanism
for reimbursement absolves a local authority from its obligation to assess a child in need who is physically
in its area. Dealing specifically with the age assessment and the submission that the Defendant must defer
to RBG against whose decision HJ must appeal, for the reasons which follow I cannot accept that
submission.

40. I agree that, albeit in a preliminary way, RBG has assessed HJ's age and that the Home Office
appears to have based its records on RBG's preliminary assessment. Also, I can see the undesirability of a
young person moving to area 2 and seeking an assessment of his or her age because he or she has
received an adverse age determination in area 1.

41. Against that, first the Act is designed to provide protection for a vulnerable class of persons, namely
children, even those near adulthood. Second, as Cobb J put it at

[33(xvi)], “needs should be met first and redistribution of resources should if necessary take place
_afterwards”. Third, in so far as it is a separate factor, there is no warrant in the statutory language for_
subordinating the assessment of a child's needs to cooperation between authorities. It is likely to be the
case that, if two authorities in the position of RBG and the Defendant cooperate, such cooperation will lead
to a more efficient result but my reading of the authorities is that, if the local authorities concerned do not in
fact cooperate, the child or putative child is not to suffer the consequences through delay or otherwise.

42. This is not therefore a straightforward alternative remedy case where a claimant seeks judicial review
of the decision of authority X when a statutory appeal procedure is available for decisions of this kind. It
was not suggested that there is any statutory appeal procedure against the decisions of local children's
services not to carry out a child in need assessment. Rather the argument is that RBG assessed HJ to be
an adult and, until such time as HJ successfully appeals that decision, no duty under the Children Act
arises for the Defendant. I mention first the issue of timing as neither party to these proceedings knew of
RBG's assessment of age on the three occasions HJ presented to the Defendant. Effectively the
submission appears to be that even if the Defendant did have a duty to assess a child in need, it was
absolved from that duty by the later knowledge that another authority had made a preliminary assessment
that the putative child was an adult. It would seem difficult to reconcile such an approach with what I
understand to be the swift action required from authorities so that, for example in this case, a putative child
is not reduced to returning for several nights to a room where the police found her with a padlock on the


-----

outside of the door. Furthermore if, as appeared to be common ground before me, authorities can owe
concurrent duties, it cannot be an answer to a claim based on the duty of the Defendant that, dependent on
the ultimate finding in respect of HJ's age, RBG may have failed to discharge its duty. That would be a
particularly surprising result in particular in a case where the Defendant's submission is that RBG's age
assessment “is not necessarily (or even obviously) unlawful”, referring to the evident shortcomings of
RBG's age determination and it has not been argued that it is _Merton-compliant to use the term in the_
Defendant's Skeleton and to which I return below.

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

43. On the point that to reject the Defendant's submission would create a perverse incentive for authorities
like RBG to carry out a preliminary age assessment in the hope that a putative child will turn to a different
authority, it is far from clear to me that RBG's tactic, if that is what it is, will result in their not being liable to
the Defendant. The Defendant also argued against a different perverse incentive for claimants to try to
have their age assessed by multiple authorities until they were assessed to be a child but I am not deciding
the case where a _Merton-compliant age assessment assessing the claimant to be an adult has been_
carried out by authority A and the claimant turns to authority B for an assessment of a child's needs.

44. The Defendant relied on a passage in the ADCS Age Assessment Guidance at p. 64 under the
heading “Disputes between local authorities”:

“Disputes have arisen between local authorities about who is responsible for assessing the age of a child
when he or she has been moved between two or more local authority areas. In the case of R (Liverpool
CC) v. Hillingdon LBC, the Court of Appeal held that after the young person had been released from
Harmondsworth Immigration Removal Centre, the London Borough of Hillingdon should have conducted
an age assessment and also a full assessment of his needs for the purposes of section 20 of the Children
Act 2004 [sic], even though the young person had previously been assessed by Liverpool.

However in R (A) v. Leicester CC and Hillingdon LBC, a case in which the claimant child had moved from
one authority's area to the other and there was no dispute about her age, HHJ Farmer QC held that
concurrent duties were owed. The possibility that this could be the case in age assessment cases was
raised but not resolved in R(Liverpool CC) and also in the later case of R (HA) v. Hillingdon LBC and
SSHD. Therefore, a local authority should conduct an age assessment for any child who comes to their
attention where there is significant reason to doubt the age claimed even if the child has moved from
another local authority area before an age assessment is conducted.”

45. The Defendant relies in particular on the closing words of that quotation. I do not read those words as
necessarily excluding a duty on the second authority to assess the needs of a child even if a preliminary
age assessment has been carried out by the first authority finding the claimant to be an adult but, even if
they are so read, I do not consider them to be consistent with Dyson LJ's judgment in _R(Liverpool) v._
_Hillingdon at [38] where he clearly considered Hillingdon to have an obligation to reassess AK's age_
despite Liverpool having assessed AK to be an adult. I acknowledge that the context was one in which
Dyson LJ at [20] had found Liverpool to have discharged their duty which does not appear consistent with
the House of Lords decision in R(A) v. Croydon LBC, but, as already found, that would not in my judgment
necessarily have changed Dyson

LJ's view of the responsibilities of Hillingdon.

46. The Defendant also referred me to the joint ADCS and Home Office Age Assessment Joint Working
_Guidance (April 2015) at pp. 9-10 (the “Age Assessment Guidance”)._

Under the heading “Existing potentially unlawful age assessment”, the guidance states:

“If it becomes clear that there is not enough evidence to show that an age assessment was completed in
line with case law the Home Office must ask the LA for this information. If the LA cannot provide this, an
age assessment which is in


-----

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

line with case law must be carried out. The LAs must collaborate and promptly agree which LA must take
responsibility for conducting the age assessment.”

47. The wording of this guidance is unclear as to what is meant by “show that an age assessment was
_completed in line with case law”. The words indicate that there will be adequate and inadequate age_
assessments but the reference to “in line with case law” requires closer analysis.

48. Mr Harrop-Griffiths submitted to me on the basis of the judgment of Mrs Justice Thornton in R(AB) v.
_Kent CC at [44] that an abbreviated assessment can be lawful and_ _Merton_ compliant. The basis for
Thornton J's acceptance of abbreviated age assessments was both Sir Stanley Burnton's judgment in R(B)
_v. Merton LBC [2003] EWHC 1689 at [27] (where he acknowledged that there may be obvious cases_
where prolonged enquiry is unnecessary) and the Court of Appeal's reconsideration of this aspect in _BF_
_(Eritrea) v. Secretary of State for the Home Department_ _[2019] EWCA Civ 872 at [55]-[57]. R(AB) v. Kent_
was a case in which the conclusion on an abbreviated age assessment was that AB presented as 20-25
years and Mrs Justice Thornton ruled that this was too close to the cut off of 18 years for the Council not to
give AB the benefit of the doubt so that the abbreviated assessment failed adequately to acknowledge the
potential margin for error to give AB the benefit of the doubt.

49. It follows that, according to the Age Assessment Guidance, if the Home Office had the documentary
material which is before me, it (and by extension the Defendant when it saw the information from RBG
which is before me, if and to the extent that the Defendant considered that an age assessment was
necessary) must have been in doubt as to whether there was sufficient evidence to show that the age
assessment was completed in line with case law for the following reasons:

i) The Assessment team's conclusion on 15 January 2020 is recorded in the Person Case Notes as
establishing that HJ “is over 18 years and therefore is an adult” and in the note written up later by RBG
(“the Note of Interview”) as “in her early 20s” but there is no recognition of the margin for error in such an
assessment and the need to give HJ the benefit of the doubt in what RBG describes as a “preliminary
_assessment”;_

ii) It is not recorded that RBG explained to HJ that it was carrying out an age assessment and the Person
Case Notes indicate various other purposes for the interview which took place on 15 January 2020;

iii) No appropriate adult is recorded as being present;

iv) There is no suggestion in the Note of Interview that RBG put adverse matters to HJ;

v) There is no record of a reasoned decision as to why it was rejecting HJ's account of her age.

50. To those points can be added the circumstances of the interview due to a combination of HJ's evident
fear of the police, her tiredness, the unknown method of travel and experiences, the potential indications of
trafficking with the possible trauma that entails. Though I acknowledge that the typed interview record
evidences consideration going

**Judgment Approved by the court for handing down.           HJ v London Borough of Croydon**
CO/225/2020

beyond merely physical appearance/demeanour, the absence of reference to aspects of basic fairness in
the interview notes should have troubled any authority reviewing the assessment in this case. Even though
the Home Office did tell HJ on 15 January that her age was not accepted, there is no suggestion that she
was told that her age had in fact been assessed or that she was entitled to challenge that assessment. In
addition, a finding in a “preliminary assessment” which is stated as “over 18 years” in one place and “early
20s” in another place and which it seems led to the Home Office inserting a date of birth of 2001 must give
rise to an obvious question as to the margin for error in an abbreviated assessment if the case law were
being applied.


-----

51. In those circumstances, an age assessment in line with case law was required to be carried out. The
Defendant and RBG were instructed by the Age Assessment Guidance to “collaborate and promptly agree”
which local authority is to take responsibility for conducting the age assessment. If there had been such
collaboration or cooperation between the Defendant and RBG, one would expect to find it in the evidence
before the Court but no such evidence is before me. In the circumstances of this case, I cannot accept that
the Defendant was entitled to refuse to assess the needs of HJ on the basis of the preliminary assessment
of age by RBG.

[52. Finally, I should deal briefly with the submissions in argument based on the Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
In oral submissions, the Defendant's initial submission was that the trafficking context is irrelevant to this
case albeit in the later part of the submissions, Mr Harrop-Griffiths seemed to prefer a finding based on
trafficking than one based on the Children Act which has potentially wide ramifications. I note first that the
claim form in this case contains no complaint of failure to recognise HJ as a potential victim of trafficking.
This is not a mere technicality as it defines the way in which the evidence has been prepared. Thus, for
example, the 1 May 2020 decision finding that there are no reasonable grounds to conclude that HJ is a
victim of **_modern slavery refers to the description of the exploitation being “contained in the decision_**
_annex attached to this letter” but I find no such annex in the papers. Thus, although I can see that section_
_51(2)_ of the Act may well have potential for assisting a claimant in a case such as this where only a
preliminary assessment of age has been carried out, it seems to me that I am not procedurally in a position
to base my decision on the trafficking context. I also note an exchange of pre-action correspondence
between solicitors acting for the Claimant and the Home Office in July 2020 in relation to the negative
reasonable grounds decision but it would appear not to have proceeded after the positive reasonable
grounds decision on 16 October 2020. To be clear, I am not rejecting or expressing a view on the evidence
on trafficking in this case. Indeed paragraph 10 above highlights what look to me to be red flags in this
context which, even though they did not result in a positive reasonable grounds decision on 1 May 2020,
should in my judgment have been taken into account as a factor by the Home Office, RBG and the
Defendant in assessing the preliminary age assessment by RBG.

**End of Document**


-----

