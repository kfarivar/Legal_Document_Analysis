# Pasian v Secretary of State for the Home Department 2022 Scot (D) 29/2

[2022] CSOH 21

Outer House, Court of Session

Lord Brailsford

24 February 2022

**Scotland – Immigration – Asylum – Alleged victim of human trafficking**
Abstract

_Scotland – Immigration – Asylum – Alleged victim of human trafficking. Court of Session: Granting the prayer of a_
_judicial review petition by a Filipino asylum seeker who claimed to be a victim of human trafficking in the form of_
_domestic servitude and who sought reduction of a 'conclusive grounds' decision by the Home Secretary that she_
_was not a victim of trafficking, the court held that the respondent had not reached perverse conclusions or had_
_regard to irrelevant matters, and she did not leave out of account the majority of the matters it was alleged that she_
_did, however there was merit in the petitioner's allegation of error in relation to the reasons why the police_
_completed their enquiries into the family for whom she had worked regarding her allegations of trafficking: that was_
_not mentioned in the decision under review and it was clearly relevant to the petitioner's claim to be a victim of_
_trafficking; the respondent had left out of account a matter which was relevant and which might have told in the_
_petitioner's favour, and it followed that she had failed to apply anxious scrutiny and that the decision was irrational._
Digest

The petitioner was an asylum seeker and claimed to be a victim of human trafficking in the form of domestic
servitude. She sought reduction of a 'conclusive grounds' decision by the competent authority that she was not a
victim of trafficking. On 17 December 2008 the United Kingdom ratified the Council of Europe Convention on Action
against Trafficking in Human Beings ('ECAT'). By virtue of art 4(a) of the Convention, and the 2000 Palermo
Protocol, ratified by the UK on 9 February 2006, 'human trafficking' was defined as: 'the recruitment, transportation,
transfer, harbouring or receipt of persons, by means of the threat or use of force or other forms of coercion, of
abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving
of payments or benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of
sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs.' Against that background, the National Referral Mechanism ('NRM') operated via a three stage process.
First, it was open to the police, in their capacity as 'first responder' to refer a case of suspected human trafficking to
a competent authority, and request that it assess whether there were reasonable grounds to suspect that a person
had been a victim of human trafficking. The respondent, the Secretary of State for the Home Department, was such
a competent authority. Second, the competent authority conducted a reasonable grounds test, designed to act as a
filter to identify potential victims. The relevant standard of proof at that stage was 'I suspect but cannot prove' that
the person was a victim of human trafficking. If, at that second stage, a positive decision was made, certain
obligations arose on the part of the UK towards that person, with a corresponding degree of protection, by virtue of
ECAT. Third, in the event that the competent authority concluded that there were reasonable grounds to suspect
that a person was a victim of human trafficking, then a substantive conclusive grounds decision, as to whether the
person was in fact a victim, was taken. The respondent reached a conclusive grounds decision on the balance of
probabilities ie had to be satisfied that it was 'more likely than not' that the person was a victim of human trafficking


-----

An adverse conclusive grounds decision was not subject to appeal. Nor could it be made subject of an indirect
[challenge in an appeal, in terms of s 82(1) of the Nationality, Immigration and Asylum Act 2002, against a removal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
direction, other than in limited circumstances. Thus, the only method of challenging a conclusive grounds decision
was by way of judicial review. The petitioner was a 52-year-old Filipino national. She entered into an arranged
marriage when aged 17 with a man ten years her senior and suffered domestic abuse throughout the marriage. In
1991 she travelled to the Middle East to work as a domestic servant. Between 1991 and 2011 she worked for four
different families. The family for whom she worked from 2008 relocated to Glasgow in February 2011 and the
petitioner joined them at their request. She was granted a domestic worker visa on 29 January 2011 and
subsequently entered the UK. She briefly left the UK for the Philippines in May 2011 and returned in August of the
same year. She had remained in the UK since her return. The petitioner claimed that she was exploited by the
family from August 2011. She did not claim that she was exploited at any time in the Middle East, nor during the
time she worked for them in the UK prior to August 2011. The substance of the petitioner's trafficking claim was that
(a) she worked from 6am until midnight, six days per week; (b) she was paid an extremely low wage; (c) she was
locked inside the family home for significant periods and unable to leave unaccompanied; (d) her passport was
retained when she left the family home unaccompanied; and (e) the family demonstrated their control over her by
locking her out of the home on one occasion. She had been residing with her partner in the UK since December
2011. The period that the claimed exploitation related to was therefore August to December 2011. The petitioner
was encountered and arrested (on suspicion of overstaying her visa) whilst at a flat in Glasgow on 16 June 2017.
She claimed asylum on 23 June. A referral was made to the NRM on 18 September 2017 for the competent
authority to consider whether the petitioner was a victim of human trafficking. The competent authority issued a
positive reasonable grounds decision on 21 September. The competent authority first issued a negative conclusive
grounds decision on 22 February 2019. Judicial review proceedings were raised in relation to that decision, which
the respondent conceded and undertook to reconsider. Two further negative conclusive grounds decisions followed
on 25 October 2019 and 30 March 2020, both of which also resulted in petitions for judicial review, a concession by
the respondent and an undertaking to issue a reconsidered decision. The most recent decision, which gave rise to
the petition, was undated but was served on the petitioner on 22 December 2020. The respondent rejected the
petitioner's claim on two bases. First, it was rejected on credibility grounds. The family's retention of the petitioner's
passport when leaving the house unaccompanied was not ipso facto proof of exploitation. It was not reasonable
that the petitioner would only have started being exploited from August 2011 when she had worked for the same
family since 2008 and, on her own account, had not been exploited previously. She had not sought assistance from
the police or other authorities despite having the opportunity to do so. She had indicated in her asylum interview
that she intended to find new employment in the Middle East on completion of her contract with the family, which
suggested that she was not being forced to work for or remain with them. She did not come forward to the police
until 2017 when she was arrested. She had been inconsistent regarding the date she commenced employment,
although the respondent accepted that she might have difficulty recalling certain facts and that matter did not go to
the core of the claim. The psychological evidence only spoke to the claimed exploitation being one of the factors
which might have impacted her mental health; there were other life events the psychologist referred to. The
petitioner's credibility issues outweighed the external country information supporting her claim. Secondly, even if the
petitioner was credible, the events she describes did not amount to domestic servitude. Having regard to the three
elements of trafficking, viz action, means and purpose, the petitioner travelled to the UK, left and returned
voluntarily. She was not a victim of 'harbouring' and was lawfully resident while working for the family. She was not
psychologically or physically forced to remain in the UK. That was supported by the fact that she was permitted
access to a mobile phone and to meet friends unaccompanied. The respondent did not accept the hours the
petitioner claimed to have worked. It was reasonable for her to care for a child in the evening given she did not have
to during the day. She had considerable freedom and could have sought assistance from the police. Her claimed
vulnerability was not a legitimate reason for not having done so. Exploitation was not to be confused with working
for low wages or in poor working conditions. She remained with the family for her own economic benefit and was
not overworked or humiliated. It was unclear to what extent she was limited access to food. Even if the wages were
low, she was paid and chose to remain with the employer. There was no force or coercion and she could have
chosen not to work. Many of the conditions that might indicate that a situation of domestic servitude existed were
not present in her case. The petitioner challenged both bases of the respondent's decision.

The petition would be granted.


-----

In relation to the respondent's credibility findings the petitioner argued that she either left out of account relevant
matters, had regard to irrelevant matters or reached certain perverse conclusions. However, there was no merit in
the submission that the respondent reached perverse conclusions. The submission was bound to fail standing the
findings in fact the respondent made which the petitioner did not challenge. The respondent did not accept how
onerous the work was. Her conclusions did not come close to perversity and were reasonably open to her on the
evidence. The respondent did not treat the inconsistencies in the petitioner's account regarding the date she
commenced employment with the family as material. That was clear from the terms of the decision. She also
acknowledged the difficulties the petitioner might face in recalling that information. The respondent was entitled to
give the weight to the psychological evidence that she did. The weight to be given to that evidence was ultimately a
matter for her and she was not bound to find the petitioner's claims of trafficking were corroborated by it. The
respondent did not require that the petitioner showed she had been working in 'unbearable conditions' to be
considered a victim of trafficking. She merely referred to her policy which noted that that would often, but not
always, be found in situations of domestic servitude. An overall reading of the respondent's decision confirmed that
she did not leave out of account the majority of the matters it was alleged that she did, namely the connection
between the petitioner's role, her vulnerability and her exploitation; various matters when assessing the petitioner's
'stated intention'; the psychological evidence and the extent to which that could corroborate her account; the
coercive behaviour the family employed; the incident when the petitioner was locked outside the family home; the
circumstances in which victims of trafficking might consent to exploitation; and the links between police and
immigration authorities and how that might have affected the petitioner's 'choice'. As to the suggestion that the
respondent left out of account that there was no evidence the petitioner remained with the family for her own
economic benefit, that was the inevitable conclusion for the respondent standing the other conclusions regarding
the petitioner's credibility. Notwithstanding that none of those matters amounted to an error of law, there was merit
in one of the petitioner's allegations of error, which related to the reasons why the police completed their enquiries
into the family regarding her allegations of trafficking. It was not in dispute that that was not mentioned in the
decision under review. Indeed, the fact that the police had even completed their enquiries was not mentioned. The
reasons for that were unclear. In these judicial review proceedings the respondent had averred that the petitioner
had not explained the relevance of the police's reasons for completing their enquiries into her case. There was
nothing to suggest that the decision-maker was of that view or whether she simply overlooked the matter. In any
event, the respondent's submission ran into three difficulties. First, the competent authority had deemed the police's
completion of their enquiries sufficiently relevant for inclusion in previous decisions. Whilst the respondent might
argue that the contents of past decisions, which had been reduced, were irrelevant, they had been lodged in
process. Whilst not subject to review in these proceedings, it would be illogical to ignore their contents entirely,
particularly where the petitioner averred that the respondent had failed to have regard to relevant matters and
where the respondent appeared to have altered her view as to the matters which were relevant without providing
any explanation for doing so. Second, the petitioner provided sufficient notice to the respondent that the police's
reasons were relevant. The court acknowledged that the decision referred to correspondence the respondent had
sent to the petitioner requesting further information prior to the decision, in relation to which it was noted no
response was received. Nonetheless, there was sufficient notice in the petitioner's second petition for judicial review
in the following terms: '16 . . . The Secretary of State does not disclose whether that was simply because the
petitioner's exploiters had left the UK. The Secretary of State has failed to provide adequate reasons for her
decision.' The petitioner had subsequently called on the respondent to ascertain the police's reasons and disclose
those to her. To date, the respondent had failed to do so. It was unclear what information the respondent already
had available (see, for example, section 11.20 of the respondent's guidance 'Modern Slavery: Statutory Guidance
[for England and Wales (under s 49 of the Modern Slavery Act 2015) and Non-Statutory Guidance for Scotland and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Northern Ireland' which referred to frequent information sharing between the police and the competent authority. At
a minimum one could assume that the information would have been readily available to the respondent had she
wished to access it. Third, and in any event, the relevance of that matter was self-evident. It was established that
anxious scrutiny required that decisions show by their reasoning that every factor which might tell in favour of an
applicant had been properly taken into account. Thus, the petitioner need not show that the police's reasons would
definitely or even probably tell in her favour. It was a matter which could either tell in her favour or support the
respondent's conclusion. For example, if the family left the UK shortly after learning of the police's investigations of
them, one could see how that was clearly relevant to the credibility of the petitioner's claim. It might enable an
inference to be drawn as to the reason why the family left. On the other hand, if the police were not satisfied that the


-----

family had exploited the petitioner, that would support the respondent's conclusion that she was not a victim of
trafficking. Given those possibilities, it was clearly a matter which was relevant to the petitioner's claim to be a victim
of trafficking. The difficulty was that there was no information either way. That amounted to leaving out of account a
matter which was both relevant and potentially material to the petitioner's claim and which might have told in her
favour. Having found that the respondent had left a relevant matter out of account, it followed that the court was
satisfied that she had failed to apply anxious scrutiny and the decision was irrational.

[R (on the application of LH) v Secretary of State for the Home Dept [2019] EWHC 3457 (Admin), [2020] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y32-R543-CGXG-055R-00000-00&context=1519360)
_[113 (Jan) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y32-R543-CGXG-055R-00000-00&context=1519360)_

**End of Document**


-----

