# JR Petitioner against ADVOCATE GENERAL FOR SCOTLAND Respondent
 2024 Scot (D) 18/6

[2024] CSOH 64

Court of Session (Outer House)

Lady Poole

Petitioner: Shabbir; Drummond Miller LLP (as agents for AJ Bradley and Co Solicitors)

Respondent: Cowan; Office of the Advocate General for Scotland

20 June 2024

**OPINION OF LADY POOLE**

20 June 2024
**Background**

[1]     The petitioner is a national of Albania. He claimed asylum in the UK on 13 February 2023. His application
was refused on 8 January 2024. He seeks judicial review of a decision of the Home Office to certify his protection
and human rights claims as clearly unfounded under _[section 94 of the Nationality, Immigration and Asylum Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-748W-00000-00&context=1519360)_
2002. Certification in this way had the effect that the petitioner was not entitled to appeal the decision on his claims
to the First-tier Tribunal under section 82 of the 2002 Act. The claim was certified because the decision maker
considered the application was so wholly lacking in substance that it was bound to fail before the tribunal.

[2]     The parties were in agreement that there are established principles governing the approach the courts take
to judicial review of certification decisions of this nature (the “certification review principles”). The court has to ask
itself the same question as the person who made the certification decision (Tsiklauri v _Secretary of State for the_
_[Home Department 2020 SC 495 at paras [11] and [14], Fathabadi v Advocate General [2020] CSOH 83 para [7]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61GF-08J3-GXFD-8043-00000-00&context=1519360)_
The court cuts through the underlying layers of decision making, and simply asks the question of whether a
protection claim and/or human rights claim is so clearly unfounded that it is bound to fail in an appeal before the
First-tier Tribunal. This is because “the question of whether or not a claim is clearly unfounded is susceptible to only
one rational answer” (ZT (Kosovo) v _Secretary of State for the Home Department [2009] UKHL 6 para [23]). It_
follows that a number of grounds frequently seen in other types of applications for judicial review, such as whether a
decision letter contains sufficient mention of relevant circumstances bearing on a human rights claim, are not strictly
to the point (Tsiklauri, para [11]).

[3]     The issues before the court for determination were: (i) whether the application for judicial review should be
transferred from the Court of Session to the Upper Tribunal for determination, and if so at what stage; and (ii)
whether to grant permission.
**Transfer to the Upper Tribunal Governing law**

[4]     Rule 58.3 of the Rules of the Court of Session provides that a petition for judicial review is made in Form
58.3. Form 58.3 contains a section headed “Transfers to the Upper Tribunal”. A petitioner is required to specify
whether the petition is subject to mandatory transfer to the Upper Tribunal, discretionary transfer to the Upper


-----

Tribunal, or neither. If there are answers to the petition, they too will address the issue of transfer to the Upper
Tribunal.

[5]     The statutory provisions regulating transfers of applications for judicial review to the Upper Tribunal are in
_[section 20 of the Tribunals, Courts and Enforcement Act 2007 (the “2007 Act”). This provides:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61W0-TWPY-Y0TB-00000-00&context=1519360)_

“(1) Where an application is made to the supervisory jurisdiction of the Court of Session, the Court–

(a)   must, if Conditions 1 and 2 are met, and

(b)   may, if Conditions 1 and 3 are met, but Condition 2 is not,

by order transfer the application to the Upper Tribunal.

(2)   Condition 1 is that the application does not seek anything other than an exercise of the supervisory
jurisdiction of the Court of Session.

(3)   Condition 2 is that the application falls within a class specified for the purposes of this subsection by
Act of Sederunt made with the consent of the Lord Chancellor.

(4)   Condition 3 is that the subject matter of the application is not a devolved Scottish matter.

[...]

(6)   There may not be specified under subsection (3) any class of application which includes an
application the subject matter of which is a devolved Scottish matter.

(7)   For the purposes of this section, the subject matter of an application is a devolved Scottish matter if
it–

(a)   concerns the exercise of functions in or as regards Scotland, and

[(b)   does not relate to a reserved matter within the meaning of the Scotland Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0K7-00000-00&context=1519360)

(8)   In subsection (2), the reference to the exercise of the supervisory jurisdiction of the Court of Session
includes a reference to the making of any order in connection with or in consequence of the exercise of
that jurisdiction”.

[6]     The procedural rules in the Court of Session regulating transfers to the Upper Tribunal are in rule 58.5 of
the Rules of the Court of Session. Rule 58.5 provides:

“(1) If the conditions in section 20(1)(a) of the 2007 Act are met, instead of determining permission under rule 58.7,
the Lord Ordinary must make an order transferring the application to the Upper Tribunal.

(2)   If paragraph (3) applies, the Lord Ordinary may make an order transferring the application to the
Upper Tribunal—

(a)   instead of determining permission under rule 58.7;

(b)   after determining permission; or

(c)   at any subsequent hearing.

(3)   This paragraph applies if—

(a)   the conditions in section 20(1)(b) of the 2007 Act are met, and

(b)   the Lord Ordinary is satisfied that it is in all the circumstances appropriate to transfer the application.

(4)   The Lord Ordinary may make an order under paragraph (2) whether or not such an order was sought
in the petition or was sought by motion by any party to the proceedings, but if no such order was sought,
the parties must be heard before making an order.


-----

(5)   Where the Lord Ordinary makes an order transferring the application to the Upper Tribunal under
paragraph (1) or (2), an order may be made in respect of any expenses incurred by the parties up to that
point”.

[7]     If a petition is transferred to the Upper Tribunal, section 21 of the 2007 Act provides that the Upper Tribunal
has the same powers of review as the Court of Session, and must apply the principles that the Court of Session
would apply in deciding an application to its supervisory jurisdiction. Any steps or orders made by the Court of
Session before transfer are to be treated as made by the Upper Tribunal. Rule 27 of the Tribunal Procedure (Upper
Tribunal) Rules 2008 sets out the procedure in the Upper Tribunal when it receives a case that has been
transferred. The Upper Tribunal will notify each party in writing that the proceedings have been transferred to it, and
must give directions as to the future conduct of the proceedings. The Upper Tribunal is entitled to regulate its
procedure as it thinks fit (rule 5 of the Tribunal Procedure (Upper Tribunal) Rules 2008).

[8]     Very few petitions for judicial review in Scotland will be subject to mandatory transfer. The only class of
application currently specified for these purposes under the Act of Sederunt (Transfer of Judicial Review
Applications from the Court of Session) 2008 (SSI 2008/357) is

“an application which challenges a procedural decision or a procedural ruling of the First-tier Tribunal, established
[under section 3(1) of the Tribunals, Courts and Enforcement Act 2007”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y14J-00000-00&context=1519360)

[9]     A higher number of petitions are subject to discretionary transfer. However, in practice it has been rare for
the Court of Session to transfer cases to the Upper Tribunal. There are historical reasons in immigration cases why
transfers were not made, because they were initially prohibited under section 20(5) of the 2007 Act. This was
because the immigration and asylum tribunal was not initially in the tribunal structure under the 2007 Act, until its
functions were transferred into that structure by the Transfer of Functions of the Asylum and Immigration Tribunal
[Order 2010 (SI 2010/21). Section 20(5) of the 2007 Act was repealed with effect from 1 November 2013, some time](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7XJ3-V5P0-YC34-71H7-00000-00&context=1519360)
ago. Despite that change in the law, it appears that little consideration tends to be given to the transfer provisions
after the making of the initial averments in the petition and answers.

[10]     In considering whether a discretionary transfer should be ordered, the first stage will be to decide if the
conditions in section 20(1)(b) of the 2007 Act are met. After that, under rule 58.5(3) of the Rules of the Court of
Session, the court has to consider all the circumstances and decide if it is satisfied it is appropriate to transfer the
application. Two Scottish cases suggest some circumstances the courts might consider. These are the novelty and
importance of the issues raised, the views of the parties, the expense of proceeding in the Court of Session, and
[expedition (L v Angus Council [2011] CSOH 196 para [54], A, Petitioner [2014] CSOH 27 paras [7]-[8]). Conversely,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TJD-VFN2-D6MY-P25S-00000-00&context=1519360)
in A, Petitioner at para [10], the loss of the ability to reclaim to the Inner House without permission was found not to
be a good reason to refuse a transfer (permission being required to appeal a decision of the Upper Tribunal to the
Inner House of the Court of Session under section 13 of the 2007 Act and rule 44 of the Tribunal Procedure (Upper
Tribunal) Rules 2008, but not to reclaim an interlocutor of the Outer House of the Court of Session). Other relevant
factors might be delay if a hearing date already fixed would be lost, or if there are difficult questions of procedure
that might arise in the Upper Tribunal if cases are transferred, but not in the referring court (R (on the application of
_Hankinson) v Revenue and Customs Commissioners [2009] EWHC 1774 (Admin), a case decided under transfer_
provisions applicable in England and Wales under section 19 of the 2007 Act).
**_Application of governing law_**

[11]     An oral hearing was ordered on both the issue of transfer and permission (rule 58.5(4)). It had already
been accepted in the pleadings that the petition was subject to discretionary transfer under section 20(1) of the
2007 Act. The petitioner expressed neutrality on the issue of whether it should be transferred. It was said that there
was force in the matter being remitted to a specialist tribunal to whom Parliament has given the power to the court
to transfer responsibility in appropriate cases. However, reasons why the court might not do so were that it had the
requisite experience and knowledge to determine the case itself, the right to appeal further without permission
would be lost, and the case was different from the one reported example of a transfer the petitioner had been able
to find. The respondent invited the court not to exercise its discretion to transfer the case. It was suggested the
court was better suited to carry out the review function. On exploration in oral argument, underlying that view was


-----

the fact that cases are not usually transferred in Scotland, with the result that such cases might be relatively
unfamiliar in the Upper Tribunal.

[12]     Applying the conditions for discretionary transfer in section 20 of the 2007 Act, condition 1 is met because
this petition does not seek anything other than the supervisory jurisdiction of the Court of Session. Condition 2 is not
met, because the subject matter of the petition is not in a class specified in an Act of Sederunt for mandatory
transfer. Condition 3 is met because the subject matter of the petition is not a devolved Scottish matter, since
[immigration, including asylum, is a reserved matter in the Scotland Act 1998 (Schedule 5 Part II reservation B6). As](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0K7-00000-00&context=1519360)
a consequence, the court “may” transfer the petition to the Upper Tribunal under section 20(1)(b). The next stage is
to decide if the court is satisfied in all the circumstances that it is appropriate to transfer the application, applying
rule 58.5(3)(b) of the Rules of the Court of Session.

[13]     In order to decide whether it is appropriate to exercise discretion to transfer a qualifying application for
judicial review to the Upper Tribunal, regard must be had to the circumstances of the particular application before
the court. The circumstances of the present case of most relevance were as follows.

1.   The nature of the issue to be determined. The petition did not raise any point of general public
importance, and was not the first in a number of similar cases which might benefit from being determined in
the Court of Session. The test which must be applied in this particular type of judicial review, a challenge to
a decision to certify a claim as clearly unfounded, is streamlined and well established (para [2] above).
There is no particular benefit in the case continuing in the Court of Session in these circumstances. The
Upper Tribunal has wide experience of appeals from the First-tier Tribunal in asylum cases, including those
raising human rights or humanitarian protection issues. It is in a particularly favourable position to
determine whether human rights and protection claims in a particular case would be bound to fail before
the First-tier Tribunal. (The respondent informed the court that in England and Wales it was a procedural
requirement that this particular type of judicial review must be commenced in the Upper Tribunal rather
than the courts).

2.   Cost, including to the public purse. The petitioner submitted that cost was a neutral factor for the
petitioner. Because he was in receipt of legal aid, he was exempt from court fees under the Court of
Session etc Fees Order 2022. The respondent was unable to provide submissions on a comparison of the
overall level of expenses likely to be incurred, because of the limited number of applications for judicial
review dealt with by the Upper Tribunal in Scotland. The court was not in a position to reach a concluded
view about relative cost on the basis of the information before it. It can nevertheless be observed that fees
for hearing first instance petitions in the Court of Session may be significant. Under the Court of Session
etc Fees Order 2022, a fee of £225 is payable by each party for every 30 minutes or part thereof from 1
April 2024 for a substantive hearing, unless exempt. The fees are per party, and the respondent did not
suggest it was exempt. Many petitions in the area of immigration are listed for a day's substantive hearing,
which might result in significant court fees, if payable, being incurred. Even though the petitioner might
personally be exempt from court fees, there is still a cost to the public purse of proceeding in the Court of
Session. Publicly available information suggested that after permission is granted there is a fixed fee for
the substantive hearing in the Upper Tribunal, currently £847, unless exempt (Apply for a judicial review in
an immigration or asylum case - GOV.UK (www.gov.uk)). It is possible there might be a cost saving to
public funds if the petition is determined in the Upper Tribunal.

3.   Delay. There is no substantive hearing date fixed in the Court of Session which will be lost if the case
is transferred. Parties were unable to assist the court with relative timescales for determination in the Court
of Session or Upper Tribunal in Scotland, because of the paucity of transferred applications for judicial
review. Information was provided about timescales in England and Wales, suggesting 12-16 weeks for
listing of a hearing of an application for judicial review after permission was granted in the Upper Tribunal,
but it did not follow that the same position would exist in the Upper Tribunal operating in Scotland. As a
matter of law, under section 21 of the 2007 Act, in any transferred case the Upper Tribunal must apply the
principles that the Court of Session would apply in deciding an application to its supervisory jurisdiction. A
well-established principle is that judicial review is designed to provide a speedy and effective remedy to
[challenge decisions of public bodies (Lauchlan and O'Neill v Scottish Ministers 2022 SC 125 para [18])](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66K9-65N3-CGX8-01VW-00000-00&context=1519360)


-----

The Upper Tribunal has wide case management powers (rule 5 of the Tribunal Procedure (Upper Tribunal)
Rules 2008). If it chooses, in its directions as to the future conduct of the proceedings under rule 27(1)(b)
of its procedure rules, it can adopt a procedure similar to that adopted in the Court of Session - of issuing
an order fixing dates for a procedural and substantive hearing to ensure the case is dealt with speedily,
and setting a timetable leading up to those dates for procedural steps such as the lodging of marked up
documents and authorities, any affidavits, statements of issues, and notes of argument. There was
nothing before the court suggesting the case would take any longer if transferred to the Upper Tribunal.

4.   Procedural difficulties. There are rules in both the Court of Session and the Upper Tribunal, set out in
para [6] and [7] of this opinion, which regulate procedure on a transfer. The respondent drew the court's
attention to one possible procedural issue, which concerned an appeal lodged by the petitioner in the Firsttier Tribunal as well as bringing the petition. The appeal had been taken on the basis that there had been
no certification of the human rights claim. The decision on permission below includes refusal of permission
on grounds predicated on there being no certification of the human rights claim. It is clear from the terms of
the decision letter of 8 January 2024 that the human rights claim was certified, with the result that these
grounds have no real prospects of success. In those circumstances, it may be that the First-tier Tribunal
proceedings will be brought to an end. If not, it is possible there are advantages to both this case and the
existing appeal being dealt with within the tribunal system. There a no procedural difficulties of such a
nature to preclude transfer of the petition.

5.   The views of the parties. Views of parties are a relevant factor. Given the terms of rule 58.5(4) of the
Rules of the Court of Session, they are not decisive. On exploration, the views of the respondent that the
case should not be transferred stemmed from it being unusual to transfer a petition to the Upper Tribunal in
Scotland. That did not appear to the court to be a weighty reason, because the provisions in the 2007 Act
and Rules of Court which govern transfers exist to be applied in appropriate cases. Both the Upper
Tribunal and the Court of Session have relevant expertise in immigration and asylum matters, and are able
to apply the well-established certification review principles. The petitioner also referred to the additional
requirement of permission to appeal against an Upper Tribunal decision if either party wished to appeal
further, but as noted above the court has already rejected this as an adequate reason to refuse a transfer
[(A, Petitioner [2014] CSOH 27).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TJD-VFN2-D6MY-P25S-00000-00&context=1519360)

[14]     In the circumstances of this particular case, it is on balance appropriate to transfer this petition to the
Upper Tribunal. The most significant factor for the court was the nature of the issues for determination in this
application for judicial review. As discussed above, the Upper Tribunal may be in a particularly favourable position
to determine applications for judicial review involving application of the certification review principles. Although the
court had regard to parties' views, they did not provide any strong reason against transfer in this particular case.
The petitioner was in essence neutral. The respondent's views were based on what was usually done in
applications for judicial review in Scotland. But if taken to its logical conclusion, this approach would render the
discretionary transfer provisions in the 2007 Act and Rules of the Court of Session otiose, which cannot have been
the intention. There was no evidence before the court that transfer would result in increased cost, delay, or
insurmountable procedural difficulties, and so those were not factors which weighed against transfer. In all the
circumstances, discretionary transfer is appropriate.

[15]     The next question is the stage at which that transfer should be made. The petitioner submitted that the
court should determine permission first if deciding to transfer the case. The respondent submitted that if there were
to be a transfer, it should occur before permission was determined. One reading of section 20A(2) of the 2007 Act
might be that it is for the Upper Tribunal to determine time bar and permission in transferred cases. However, under
section 21(5) of the 2007 Act, steps or orders already taken or made by the Court of Session in a transferred case
are to be treated as taken or made by the Upper Tribunal. Further, under rule 58.5(2) of the Rules of the Court of
Session, a discretionary transfer may be made instead of determining permission, after determining permission, or
at any subsequent hearing. Reading all of these provisions together, section 20A(2) of the 2007 Act requires to be
interpreted so that the powers of the Upper Tribunal to determine time limits and permission arise in a discretionary
transfer case where those matters have not already been determined by the Court of Session. That leaves intact
the Court of Session's powers to determine time limits and permission before transferring, if it wishes to do so. The


-----

test for permission for judicial review in Scotland is the same whether determined by the Court of Session or by the
Upper Tribunal (section 20A(2)(b) and (3) of the 2007 Act). Given that the court had written submissions before it
and had heard argument on permission, considerations of delay and expense suggested the court should
determine the issue of permission prior to transfer.
**Permission**

[16]     The petition may only proceed if permission is granted. The statutory tests that must be applied are found
[in section 27B of the Court of Session Act 1988. The applicant must demonstrate a sufficient interest in the subject](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5S2R-9F71-DYCN-C0TP-00000-00&context=1519360)
matter of the application, and the application must have a real prospect of success. Permission is not to be
interpreted as an insurmountable barrier preventing what may appear to be a weak case from being fully argued in
due course (Wightman v Secretary of State [2018] CSIH 18 at para [9]).

[17]     It has been accepted by the authorities that the petitioner was the victim of **_modern slavery. He was_**
trafficked to work in a cannabis farm in the UK. The petitioner says he was trafficked by men to whom the
petitioner's father owed money. Despite the arguments of the respondent to the contrary, the grounds in the petition
focussed between paragraphs 51 and 55 pass the test for permission. The grounds in paragraphs 49 and 50 also
pass the test, to the extent that the matters in them are relevant to the question of whether the human rights claim
would be bound to fail before the First-tier Tribunal (as opposed to challenging the process before the initial
decision maker). In determining these grounds, the Upper Tribunal will apply the principles that the Court of Session
would apply in deciding an application to its supervisory jurisdiction (section 21 of the 2007 Act), including the
certification review principles. Given that those grounds will be fully argued in due course, to avoid any issue of
prejudgement, the less said about them at this stage the better.

[18]     Permission is refused on the grounds between paragraphs 44 and 49 of the petition. The grounds in
paragraphs 45 and 46, predicated on the petitioner's human rights claim not having been certified, have no
prospects of success. The decision letter of 8 January 2024 must be read as a whole. On page 1 it states in terms

“You do not have a right of appeal against this decision because your protection and human rights claims have
[been certified as clearly unfounded under section 94 of the Nationality, Immigration and Asylum Act 2002”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-748W-00000-00&context=1519360)

Paragraph 75 of the decision letter sets out the test applied, and paragraph 77 records a decision “to refuse your
claim and certify it as clearly unfounded”. Again on page 14 it is said

“You do not have a right of appeal against this decision because your protection and human rights claims have
[been certified as clearly unfounded under section 94 of the Nationality, Immigration and Asylum Act 2002”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-748W-00000-00&context=1519360)

While it is accepted that certification decisions are distinct from decisions on the merits of a human rights or
protection claim (Tsiklauri para [12]), it is crystal clear that in this particular decision the human rights claim as well
as the protection claim was certified as clearly unfounded.

[19]     To the extent that the challenge is one of a failure to give adequate reasons for the certification of the
human rights claim (paragraph 47), that is not a relevant challenge in this particular type of judicial review. The
same can be said for the challenge in paragraph 48 of the petition based on an alleged application of the wrong
rules by the initial decision maker. Under the certification review principles, the same question has to be asked as
the person who made the certification decision, of whether the human rights and protection claims are clearly
unfounded. Whether or not the initial decision maker applied the correct passages in the Immigration Rules or gave
detailed enough reasons are matters which are, as put in Tsiklauri, not strictly to the point (para [11)). The grounds
in paragraphs 47 and 48 also have no real prospects of success.
**Conclusion**

[20]     Permission is therefore granted on the grounds in paragraphs 49 to 55 of the petition, and refused on the
grounds in paragraphs 44 to 48 of the petition. The question of any expenses up to this point is reserved. Thereafter
the application for judicial review is transferred to the Upper Tribunal for determination of the grounds upon which
permission has been granted.


-----

**End of Document**


-----

