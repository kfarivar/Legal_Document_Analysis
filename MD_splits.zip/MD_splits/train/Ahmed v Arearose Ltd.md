# Ahmed v Arearose Ltd UKEAT/0314/15

EMPLOYMENT APPEAL TRIBUNAL

JUDGE SHANKS (sitting alone)

5 FEBRUARY 2016

5 FEBRUARY 2016

M Uddin for the Appellant

No appearance or representation by or on behalf of the Respondent

_SUMMARY_

_PRACTICE AND PROCEDURE - Right to be heard_

_PRACTICE AND PROCEDURE_

The Appellant's claim form was rejected for non-compliance with the early conciliation provisions. He applied for a
reconsideration under r 13 of the Employment Tribunal Rules of Procedure, but the application was rejected by the
Employment Judge without him being given a hearing as required by r 13(3). It seemed to the Employment Appeal
Tribunal that there may be issues as to whether the proceedings were exempt from the early conciliation provisions
under reg 3 of _[SI2014/254, whether a certificate the Appellant had obtained was valid for the purposes of those](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5BJ3-P7V1-F16W-C4VV-00000-00&context=1519360)_
provisions and whether a subsequently obtained certificate could rectify a defect in a claim form arising from it not
containing an early conciliation number. The application should be remitted to be reconsidered by another
Employment Judge at a hearing at which both parties could attend.

**JUDGE SHANKS:**

(reading the judgment of the Tribunal)

_INTRODUCTION_

**[1] This appeal concerns the provisions relating to early conciliation that were introduced by an amendment to the**
_[Employment Tribunals Act 1996 (“ETA”), which took effect on 6 April 2014. The representation today has been not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0HW-00000-00&context=1519360)_
entirely satisfactory.

**[2] Speaking on behalf of the Claimant, Mr Ahmed, is Mohammed Zashin Uddin. He says he is a McKenzie friend,**
but it is clear that what is in fact happening is he is representing Mr Ahmed by speaking for him in court, albeit he
has also told me that he is not being paid in any way for so representing him and is doing it out of friendship. I
should say a little bit more about this in case it becomes relevant at a later date. Mr Uddin is in fact a practising
solicitor, though not in the area of employment law, and he is an associate, as I understand it, with a firm called
Syed Shaheen Solicitors. That firm is mentioned in the Appellant's EAT form as representing him, and that firm
wrote by email to the EAT on 1 February 2016, saying that they were not instructed by the Claimant to represent
him at the hearing today and that their instructed counsel, Mr Akram Rana of Clapham Chambers, would not


-----

appear before the Tribunal but that a McKenzie friend would represent him. That letter was apparently drafted and
written by Mr Uddin, although it is signed “Syed Shaheem Solicitors”.

**[3] On the Respondent's side, there is no appearance today, though I am asked to, and do, take account of the**
Respondent's Answer, which was received at the EAT on 4 December 2015.

_LEGAL FRAMEWORK_

**[4] Before I set out the factual background, it would be helpful if I deal with the legal context. Section 18A of the**
_ETA 1996 provides as follows:_

_“(1) Before a person (“the prospective claimant”) presents an application to institute relevant proceedings_
_relating to any matter, the prospective claimant must provide to ACAS prescribed information, in the prescribed_
_manner, about that matter._

_…_

_(2) On receiving the prescribed information in the prescribed manner, ACAS shall send a copy of it to a_
_conciliation officer._

_(3) The conciliation officer shall, during the prescribed period, endeavour to promote a settlement between the_
_persons who would be parties to the proceedings._

_(4) If -_

_(a) during the prescribed period the conciliation officer concludes a settlement is not possible, or_

_(b) the prescribed period expires without a settlement having been reached,_

_the conciliation officer shall issue a certificate to that effect, in the prescribed manner, to the prospective_
_claimant._

_…_

_(8) A person who is subject to the requirement in sub-s (1) may not present an application to institute relevant_
_proceedings without a certificate under sub-s (4).”_

“Relevant proceedings” are defined in s 18 of the _ETA 1996, and they cover a large number of claims under_
different legislation, although, at the moment, I cannot see any reference to the Race Relations Act (“RRA”), though
it may well be that such a reference comes in through another route. In particular, there may be something in the
_[Equality Act 2010 (“EqA”) that brings in the RRA to that list of provisions. It does include a claim for holiday pay.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_

**[5] Those are the relevant provisions in the ETA. There is then secondary legislation in the form of the Employment**
_Tribunals (Early Conciliation: Exemptions and Rules of Procedure) Regulations 2014. These provide in reg 3 for_
exemptions from early conciliation, and one of the possible exemptions is provided by reg 3(1)(b), which says:

_“(1) A person (“A”) may institute relevant proceedings without complying with the requirement for early_
_conciliation where -_

_…_

_(b) A institutes those relevant proceedings on the same claim form as proceedings which are not relevant_
_proceedings;_

_…”_


-----

There is then a Schedule to the Regulations that deals with the Early Conciliation Rules of Procedure. It lays down
what the prospective Claimant must tell ACAS, it lays down the period of early conciliation, which is one calendar
month, and it lays down provisions in relation to early conciliation certificates. Rule 7 says this:

_“(1) If at any point during the period for early conciliation, or during any extension of that period, the conciliation_
_officer concludes that a settlement of a dispute, or part of it, is not possible, ACAS must issue an early_
_conciliation certificate._

_(2) If the period for early conciliation, including any extension of that period, expires without a settlement having_
_been reached, ACAS must issue an early conciliation certificate.”_

Then, r 8 says:

_“An early conciliation certificate must contain -_

_(a) the name and address of the prospective claimant;_

_(b) the name and address of the prospective respondent;_

_(c) the date of receipt by ACAS of the early conciliation form presented in accordance with r 2 or the date that_
_the prospective claimant telephoned ACAS in accordance with r 3;_

_(d) the unique reference number given by ACAS to the early conciliation certificate; and_

_(e) the date of issue of the certificate, which will be the date that the certificate is sent by ACAS, and a_
_statement indicating the method by which the certificate is to be sent.”_

**[6] Finally, there are relevant Rules of Procedure in the** _Employment Tribunals (Constitution and Rules of_
_Procedure) Regulations 2013. Under the heading “Starting a claim”, r 10, there is a provision to this effect:_

_“(1) The tribunal shall reject a claim if -_

_…_

_(c) it does not contain all of the following information -_

_(i) an early conciliation number;_

_(ii) confirmation that the claim does not institute any relevant proceedings; or_

_(iii) confirmation that one of the early conciliation exemptions applies.”_

If that is the case, the form is returned to the Claimant with a notice of rejection explaining why it has been rejected,
and that is clearly an administrative act. Rule 12 is headed “Rejection: substantive defects” and says this:

_“(1) The staff of the tribunal office shall refer a claim form to an Employment Judge if they consider that the_
_claim, or part of it, may be -_

_…_

_(d) one which institutes relevant proceedings, is made on claim form which contains confirmation that one of_
_the early conciliation exemptions applies, and an early conciliation exemption does not apply;_

_…”_

Then, at sub-r (2), it says:


-----

_“(2) The claim, or part of it, shall be rejected if the Judge considers that the claim, or part of it, is of a kind_
_described in sub-paragraphs … (d) of para (1).”_

There is then a provision for reconsideration of rejection at r 13:

_“(1) A claimant whose claim has been rejected (in whole or in part) under r 10 or 12 may apply for a_
_reconsideration on the basis that either -_

_(a) the decision to reject was wrong; or_

_(b) the notified defect can be rectified._

_(2) The application shall be in writing and presented to the Tribunal within 14 days of the date that the notice of_
_rejection was sent. It shall explain why the decision is said to have been wrong or rectify the defect and if the_
_claimant wishes to request a hearing this shall be requested in the application._

_(3) If the claimant does not request a hearing, or an Employment Judge decides, on considering the_
_application, that the claim shall be accepted in full, the Judge shall determine the application without a hearing._
_Otherwise the application shall be considered at a hearing attended only by the claimant._

_(4) If the Judge decides that the original rejection was correct but that the defect has been rectified, the claim_
_shall be treated as presented on the date that the defect was rectified.”_

_FACTS_

**[7] I turn now to the facts. The Claimant works for the Respondent, Arearose Ltd, which is the franchisee of a**
Burger King restaurant at King's Cross, and he has worked for them since 2003. On 24 June 2015 he put in a claim
form to the Employment Tribunal against the Respondent. He was represented by a Mr Ariful Mazid of PGA
Solicitors LLP in Whitechapel Road.

**[8] The Particulars of Claim appear to be claiming unpaid holiday going back for many years and discrimination**
and harassment under the RRA and the EqA so far as it relates to race. At the moment, I am not able to see any
[other claims made in that ET1, although Mr Uddin briefly suggested that there may be a claim under the Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
**_[Slavery Act 2015, a submission which I think he has withdrawn. Under para 2.3 in the claim form there is a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
question, “Do you have an Acas early conciliation certificate number?” and there is a tick in the “No” box. Then,
there is another heading, “If No, why don't you have this number?” and the box that is ticked is, “Acas doesn't have
the power to conciliate on some or all of my claim”.

**[9] I am told today, although I have not confirmed it, that on 1 July 2015 Regulations were to come into force that**
would have meant that a claim for unpaid holiday pay could not go back further than two years. As I have
mentioned, the claim in this case went back many years more than two. That appears to be the explanation for PGA
Solicitors starting the claim on 24 June 2015 and also apparently the reason that they did not seek to notify ACAS
before issuing the proceedings, notwithstanding the fact that they had ticked the box that says, “Acas doesn't have
the power to conciliate on some or all of my claim”. In spite of that, on 25 June 2015 it seems that they did contact
ACAS. Page 61 in the bundle is a confirmation of early conciliation notification. It gives a case reference number
R062777/15, and it says that it was submitted to ACAS at 1.44pm on 25 June 2015. On that same day, at 3.11pm,
PGA emailed the Employment Tribunal to say this:

_“Please note that Claimant has applied to (ACAS [and it gives the reference]). As the claim was going back to_
_2003, Claimant time to issue the claim was running out due to new regulation coming into effect on 1st July_
_2015 we had to issue the claim before the date line. Therefore, we would be grateful if you hold if you would be_
_hold the claim rather the rejecting it for 3-4 weeks.” [sic]_

**[10] The very next day, on 26 June 2015, ACAS issued a document that is headed “Early Conciliation Certificate”.**
It gives the same reference number, except that after “15” there is a stroke and the number “44” so it is now
R062777/15/44 It gives the name of the prospective Claimant the name of the prospective Respondent the date


-----

of receipt of the notification (25 June 2015) and the date of issue by ACAS of this certificate (26 June 2015),
method of issue (email), and it says:

_[“This Certificate is to confirm that the prospective claimant has complied with the requirement under ETA 1996](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:58T2-WBY1-DYCN-C0MS-00000-00&context=1519360)_
_[s18A to contact Acas before instituting proceedings in the Employment Tribunal.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:58T2-WBY1-DYCN-C0MS-00000-00&context=1519360)_

It is then signed “Early Conciliation Support Officer”. I have a number of comments on that certificate. First of all, it
was in fact wrong, because these proceedings had been instituted two days before, but the ACAS representative
clearly was not to know that. Secondly, it does not actually certify what is laid down by s 18A(4) ETA, which is that
the conciliation officer had concluded a settlement was not possible or that the prescribed period had expired
without a settlement having been reached. It does, however, comply with r 8, in that it contains the matters that are
specified there, and it does in general certify that the prospective Claimant has satisfied the requirement to contact
ACAS before instituting proceedings but not the other matters that I have just mentioned in s 18A(4). It is, however,
headed “Early Conciliation Certificate”, and it does have a reference number. I assume, although it is perhaps a
little surprising, that the conciliation officer had been in touch with the Respondent between 25 and 26 June and
had received a negative answer from them in relation to the chances of settlement, but I have no evidence that that
is the case.

**[11] In any event, armed with that certificate, PGA Solicitors emailed the Employment Tribunal as follows:**

_“Please note that we have received the ACAS certificate. The Acas EC Reference Number is R062777/15/44._

_We enclosed the certificate. Please add the reference number to the main claim form._

_Should you have any query please contact with us.” [sic]_

It seems therefore that PGA were inviting an amendment to para 2.3 of the claim form or were seeking to remedy a
deficiency in the claim form.

**[12] Notwithstanding that, on 2 July 2015 the Tribunal wrote to PGA Solicitors as follows:**

_“Dear Sir_

_REJECTION OF CLAIM_

_…_

_I am returning your claim form because you have not complied with the requirement at r 10(1)(c) of the [ET]_
_Rules, because it does not contain one of the following:_

_(i) an early conciliation number,_

_(ii) confirmation that the claim does not institute any relevant proceedings, or_

_(iii) confirmation that one of the early conciliation exemptions applies._

_Employment Judge Wade to whom your claim has been referred to has therefore decided that your claim must_
_be rejected._

_I am therefore returning your claim form to you.”_

Although it is not very clear from that letter, it appears that in terms of the Rules the rejection was under r 12(2) of
the _ET Rules of Procedure, having been referred to Employment Judge Wade, who presumably looked at it and_
took the view, which is probably right, that ACAS did have power to conciliate on all of the claim, contrary to the tick
at para 2.3 of the claim form as originally submitted.


-----

**[13] The response to that from PGA Solicitors was dated 7 July 2015, and is at p 40 in my bundle. They enclosed**
for further consideration the rejected claim form and the ACAS early conciliation certificate. They made various
points, including the fact that they received instructions to issue proceedings at the last moment before the
introduction of the new law on 1 July 2015, and they recorded that on 24 June the claim was issued and on 26 June
2015 they received the early conciliation certificate and forwarded it to the Tribunal on the same day. They made
the point that if permission was not granted the Claimant would have to issue a fresh claim and that would mean
that they would suffer because of the new law introduced on 1 July 2015, they made the point that the early
conciliation certificate was sent in on 26 June before the notice of rejection, and they said, perhaps unfortunately,
that the early conciliation is merely technical and neither party is obliged to go through the full procedure. They then
said, in the final paragraph:

_“In the above circumstances it is our humble request to the Tribunal to grant permission to issue the claim._
_However, if the Tribunal decided not to grant permission the claimant requested to decide the claim at a_
_hearing in which case claimant would like to submit further arguments.” [sic]_

I have quoted accurately what the letter says, as I have all previous quotations. It is not expressed very clearly, but
Mr Recorder Luba QC on the sift took the view and I agree that it is arguable that it included a request for a hearing
before a decision was made on the reconsideration under r 13(3) and (4).

**[14] What in fact happened was that the Tribunal again wrote to PGA on 17 July and said this:**

_“I refer to your application dated 7 July 2015 for a reconsideration of the decision to reject your claim which has_
_been considered by Employment Judge Wade._

_As you did not request a hearing, the Employment Judge has determined your application on the basis of your_
_written representations only. The Judge has decided to dismiss your application for the following reasons:_

_You have not provided an early Conciliation Certificate which is only supplied by ACAS at the end of the_
_conciliation period or alternatively please explain why you say that ACAS does not have the power to conciliate_
_all or part of your claim.”_

It then indicates the right of appeal to the Employment Appeal Tribunal. Again, I have quoted that accurately. It
seems rather odd to ask for an explanation whilst rejecting the application for reconsideration; furthermore, there
was no hearing, and Judge Wade was wrong to conclude that one could not be requested.

**[15] The appeal in this case was lodged on 13 August 2015, but while it has been on foot there have been further**
communications between PGA and the Employment Tribunal. I was shown two letters from the Employment
Tribunal, one dated 8 September and one dated 4 December 2015, relating to these. Again, they are very confusing
as to what exactly was being asked for and what was being given, but the Employment Judge appears to have
taken the view that because the claim form was put in before the certificate and s 18A(8) ETA says in terms that a
person may not present an application without a certificate this was not a matter that could be rectified under r 13 of
the ET Rules of Procedure.

_CONCLUSION_

**[16] It seems to me this case is in something of a muddle. There should have been a hearing attended at least by**
the Claimant before Judge Wade made any decisions. There may be further facts that need to be investigated, and
it seems to me there are potential arguments on three points: (1) whether a certificate was in fact required for the
proceedings that the Claimant was bringing; (2) whether the certificate produced is in fact valid; and (3) whether
providing the certificate and the number in particular after the proceedings have been issued is possible (in other
words, whether those proceedings could have been rectified or whether new proceedings have to be started). It
seems to me, in those circumstances, I should allow the appeal against the rejection of 17 July 2015, remit the
whole matter to the Employment Tribunal, I think not to Judge Wade, and a hearing can then be held at which the
facts can be further considered if necessary and at which a full decision can be given that if necessary can be the
subject of a further appeal.


-----

Judgment accordingly.

**End of Document**


-----

