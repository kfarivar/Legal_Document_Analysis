# R v Brecani

## [2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)

 Court: Court of Appeal, Criminal Division Judgment Date: 19/05/2021

# Catchwords & Digest

## EVIDENCE - ADMISSIBILITY – ADMISSIBILITY, AT CRIMINAL TRIAL, OF SINGLE COMPETENT AUTHORITY'S DECISION THAT DEFENDANT VICTIM OF MODERN SLAVERY

 Case workers in the Single Competent Authority established by the Home Office were not experts in human trafficking or modern slavery (whether generally or in respect of specified countries) and, for that fundamental reason, they could not give opinion evidence in a trial on the question whether an individual was trafficked or exploited. Accordingly, the Court of Appeal, Criminal Division, in dismissing the defendant's appeal against his conviction for conspiracy to supply cocaine, held that a judge had been right to exclude: (i) a conclusive grounds decision which the Single Competent Authority had made, for administrative purposes and on the balance of probabilities, and which had concluded that the defendant was a victim of modern slavery attached to it. Further, the court held that the judge had also been right to exclude evidence from an expert witness who the defendant had commissioned, concerning his defence of modern slavery under Slavery Act 2015. The court held that the defendant's conviction was safe. Further, it refused leave to appeal based on the ground that defendant's case should have been severed from the trial of his co-defendants, holding that it was desirable for co-defendants in a broad alleged conspiracy to be tried together, and that the judge's decision could not be criticised.

# Cases referring to this case

Koceku v Republic of Albania

_[[2024] EWHC 1028 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C0J-S2P3-RX1P-60WD-00000-00&context=1519360)_
Applied

R v BRP

_[[2023] EWCA Crim 40](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67DB-27J3-RRJW-500Y-00000-00&context=1519360)_


10/05/2024

AdminCt

25/01/2023

CACrimD


-----

Considered
R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

R v BWM

_[[2022] EWCA Crim 924, [2022] 4 WLR 116](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65VM-CXY3-GXF6-84FW-00000-00&context=1519360)_
Considered

R v AGM

_[[2022] EWCA Crim 920, [2022] All ER (D) 23 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65W9-2RG3-GXF6-827R-00000-00&context=1519360)_
Considered

R v Miller-Cross

_[[2022] EWCA Crim 346](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:651C-B223-GXF6-8308-00000-00&context=1519360)_
Considered

# Cases considered by this case

VCL and another v United Kingdom

_[[2021] ECHR 77587/12, [2021] All ER (D) 87 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:622N-S9J3-GXFD-841G-00000-00&context=1519360)_
Considered

Director of Public Prosecutions v M

_[[2020] EWHC 3422 (Admin), [2021] 1 WLR 1669](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61HR-GVX3-GXFD-8184-00000-00&context=1519360)_
Not Followed

R v DS

_[[2020] EWCA Crim 285, [2021] 1 All ER 1233, [2021] 1 WLR 303](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627S-BFT3-GXFD-80RS-00000-00&context=1519360)_
Considered

R v GS

_[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2019] 1 Cr App Rep 84, [2018] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
_[(D) 90 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
Considered

R v MK (also known as D); R v Gega (also known as Maione)

_[[2018] EWCA Crim 667, [2019] QB 86, [2018] 3 All ER 566, [2018] 3 WLR 895, [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_
[2 Cr App Rep 210, [2018] All ER (D) 10 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5S2J-3TH1-DYBP-N4PT-00000-00&context=1519360)
Applied

R (on the application of M) v Hammersmith Magistrates' Court and Another (2017)

_[[2017] EWHC 1359 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NTV-JXY1-F0JY-C125-00000-00&context=1519360)_
Considered

R v Joseph

_[[2017] EWCA Crim 36, [2017] 1 WLR 3153, [2017] 1 Cr App Rep 486, [2017] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_
_[(D) 100 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_
Considered

Rogers v Hoyle

_[[2014] EWCA Civ 257, [2015] QB 265, [2014] 3 All ER 550, [2014] 3 WLR 148, [2014]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CT8-HCV1-DYBP-M557-00000-00&context=1519360)_
_[All ER (D) 131 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BSR-4MR1-DYBP-N3M6-00000-00&context=1519360)_
Considered


20/01/2023

CACrimD

05/07/2022

CACrimD

05/07/2022

CACrimD

04/03/2022

CACrimD

16/02/2021

EctHR

15/12/2020

AdminCt

28/02/2020

CACrimD

31/07/2018

CACrimD

28/03/2018

CACrimD

05/05/2017

DC

09/02/2017

CACrimD

13/03/2014

CACivD


-----

R v N; R v E

_[2012] EWCA Crim 189, [2013] QB 379, [2012] 3 WLR 1159, [2012] 1 Cr App Rep 471,_
[(2012) Times, 10 April, [2012] All ER (D) 128 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5513-TB01-DYBP-N1F7-00000-00&context=1519360)
Considered

R (on the application of B) v Merton London Borough Council

_[[2003] EWHC 1689 (Admin), [2003] 4 All ER 280, [2003] 2 FLR 888, [2005] 3 FCR 69,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)_
[(2003) Times, 18 July, [2003] All ER (D) 227 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWK1-DYBP-N3M0-00000-00&context=1519360)
Considered

R v Turner

[[1975] QB 834, [1975] 1 All ER 70, [1975] 2 WLR 56](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KN0-TWP1-60PG-00000-00&context=1519360)
Applied

**End of Document**


20/02/2012

CACrimD

14/07/2003

AdminCt

17/10/1974

CACrimD


-----

