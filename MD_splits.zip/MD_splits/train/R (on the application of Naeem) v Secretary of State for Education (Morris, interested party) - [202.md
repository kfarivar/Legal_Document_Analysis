648

# R (on the application of Naeem) v Secretary of State for Education (Morris,
 interested party) [2022] 3 All ER 648

[2022] EWHC 15 (Admin)

QUEEN'S BENCH DIVISION (ADMINISTRATIVE COURT)

FOSTER J

18 NOVEMBER 2021, 6 JANUARY 2022

**Education — Higher education — Student loans — Immigration status — Applicants for student finance**
**required to be settled in United Kingdom on first day of first academic year of course — Government**
**withdrawing priority visa application process on short notice citing COVID-19 pandemic — Applicants**
**unable to acquire settled status within time — Whether requirement discriminatory — Whether requirement**
**justified — Human Rights Act 1998, Sch 1, Pt I, art 14, Pt II, art 2 — Education (Student Support)**
**Regulations 2011, SI 2011/1986, Sch 1, Pt 2, para 2(1)(a).**

[The claimant brought judicial review proceedings challenging the Education (Student Support) Regulations 2011, SI](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:53K6-0XP1-F16W-C4X2-00000-00&context=1519360)
_[2011/1986, which contained the eligibility requirements for provision of student finance to would-be higher](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:53K6-0XP1-F16W-C4X2-00000-00&context=1519360)_
education students. By para 2(1)(a)[a] of Sch 1 to the 2011 Regulations an applicant was required to be 'settled in the
United Kingdom' in immigration terms on the first day of the first academic year of their course to be eligible for
receipt of student finance. The claimant made an application for settled status in May 2020. In previous applications
he had used the Home Office 'Super Priority' visa application process, which granted visas within 24 hours on
payment of a fee. A similar priority service granted visas on payment of a smaller fee within five working days. If no
fees were paid, the turnaround offered by the Home Office for disposal of an Indefinite Leave to Remain ('ILR') visa
application was six months. On 31 March 2020, however, following the incidence of the COVID-19 pandemic, the
priority channels were withdrawn by the Home Office with only a few days' notice, unknown to the claimant until he
sought to submit his application on 17 May 2020. He then had no alternative but to make his application by the
slower route. The Secretary of State refused the claimant's application for finance on the basis that he had not
satisfied the requirement to be settled on 1 September 2020. He was in fact subsequently granted ILR and acquired
settled status on 23 November 2020. The claimant argued that in the context of the COVID-19 pandemic the
application of the requirement to be settled in the UK on 1 September 2020 discriminated unlawfully against him
contrary to art 14[b] of the European Convention for the Protection of Human Rights and Fundamental Freedoms
1950 (as set out in Sch 1 to the Human Rights Act 1998) read with art 2[c] of the

1

a Paragraph 2, so far as material, is set out at [11], below.

b Article 14 provides: 'The enjoyment of the rights and freedoms set forth in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion, national or social origin,
association with a national minority, property, birth or other status.'

c Article 2, so far as material, provides: 'No person shall be denied the right to education.'

**[*649]**


-----

648

First Protocol to the Convention ('A2P1'). The claimant submitted that he had met the requirements for ILR but had
been prevented from satisfying the criteria by the summary suspension of the priority service and was therefore a
person having 'other status' under art 14. The interested party was in substantially the same position as the
claimant, having been caught by the withdrawal of the priority schemes at a time when it was too late to acquire ILR
through the only remaining six-month route. The central areas of dispute between the parties were as to whether it
was possible to discern 'other status' into which the claimant and the interested party fell, and if so whether
differential treatment could be justified.

**Held – When seeking to discover whether the construct of culpable art 14 differential treatment had taken place, the**
court had to look to the whole circumstances of the case. 'Status' now had an uncomplicated and broad reach.
Status could be acquired and limited in time and might refer to the specific circumstances of a claimant. The value
to the UK of the applicants in the present case was indistinguishable from the value of those whose ILR applications
had been processed in time. The scheme appeared to exclude people who met the criteria which the Regulations
were designed to include. The application of the cut-off date to this particular cohort did not reflect the objectives of
the Regulation. In essence the claimant and interested party were complaining about the fact that, although equally
entitled, they were being treated differently from those who had not been impeded from acquiring ILR as they had
been, and that was the ground on which the difference in treatment was based. The present case had the hallmarks
of a legitimate expectation that had been disappointed. What had arisen might also be expressed as a manifest
unfairness but its remedy could be expressed within what was now recognised as the flexible context of art 14. The
public law wrong of disabling a clearly identifiable cohort of students from acquiring student finance by not adapting
the Regulations so as to cater for the exigencies of the pandemic-driven withdrawal of access, could amount to
discrimination as claimed, and also plainly met the justice of the case. The claimant was within the class of persons
sufficiently connected with this country to justify receipt of student finance under the Regulations. Thus the absence
of a solution to the issue which arose, namely withdrawal of the ability to achieve student finance for the required
course, did not serve the legislative purpose, but rather cut right across it. A cohort of people would be disentitled
from pursuing their academic careers, probably, or at least possibly for a considerable time, with no guarantee of
being able to recommence their studies. At the date of withdrawal of the priority services a closed class of would-be
students had become disentitled from acquiring student finance for their university courses. Properly analysed,
there had been unlawful discrimination. Further, the discrimination against the claimant and the interested party
could not be justified and was not proportionate. To exclude the candidates on the present facts cut across the
purpose of the Regulations and defeated its aims. Whilst the importance of a bright line rule concerning qualification
for the scheme was accepted, a remedy in the present case did not impugn that, nor would the Secretary of State
necessarily be required to exercise a discretion, compassionate or otherwise, in the circumstances of this case: the
relevant factors for inclusion were all ascertainable. In all the circumstances, the Secretary of State had unlawfully
discriminated against the claimant and the interested party by treating them less favourably than those who had not
been caught out by the
**[*650]**

sudden withdrawal of the priority scheme. The Secretary of State had not mitigated the severe effect of withdrawal
of the priority services in the limited way required to protect that group, who were, as had subsequently been
shown, as entitled to student finance as the comparator group, unaffected by the COVID priority scheme. It was
contrary to the objectives of the Regulations for there to be no mitigation of the delay in process that had been
forced upon the applicants in this case. The claim would therefore be allowed and a declaration granted accordingly
(see [50], [76]–[82], [86], [89], [90], [91], [96]–[100], [111]–[114], below); R (on the application of Tigere) v Secretary
_[of State for Business, Innovation and Skills [2016] 1 All ER 191, R (on the application of Stott) v Secretary for State](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
_[for Justice [2019] 2 All ER 351, R (on the application of DA) v Secretary of State for Work and Pensions, R (on the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_
_[application of DS) v Secretary of State for Work and Pensions [2020] 1 All ER 573 and R (on the application of SC)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_
_[v Secretary of State for Work and Pensions [2022] 3 All ER 95 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S8-S3R3-GXF6-84Y2-00000-00&context=1519360)_
**Notes**

For the provision of financial support for students and the eligibility of students for financial awards, see Halsbury's
_Laws EDUCATION vol 35 (2020) paras 873, 885._


-----

648

For the prohibition of discrimination: social categorisations and 'other status', and for the right to education
generally, see Halsbury's Laws RIGHTS AND FREEDOMS vol 88A (2018) paras 586, 610.

[For the Human Rights Act 1998, Sch 1, Pt I, art 14, Pt II, art 2, see Halsbury's Statutes vol 7(1) (2022 reissue) 893,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0GT-00000-00&context=1519360)
907.

For the Education (Student Support) Regulations 2011, _[SI 2011/1986, Sch 1, Pt 2, para 2(1)(a),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:53K6-0XR1-F16W-C00W-00000-00&context=1519360)_ see _Halsbury's_
_Statutory Instruments vol 6(2) (2019 issue) 770._
**Cases referred to**

_[Artico v Italy (App no 6694/74) (1980) 3 EHRR 1, [1980] ECHR 6694/74, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1KB-00000-00&context=1519360)_

_[Bah v UK (App no 56328/07) (2011) 31 BHRC 609, (2011) 54 EHRR 773, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2W4-00000-00&context=1519360)_

_[Bank Mellat v HM Treasury (No 2) [2013] UKSC 39, [2013] 4 All ER 533, [2014] AC 700, [2013] 3 WLR 179.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_

_[Clift v UK (App no 7205/07) [2010] ECHR 7205/07, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1CR-00000-00&context=1519360)_

_[Cudak v Lithuania (App no 15869/02) (2010) 30 BHRC 157, (2010) 51 EHRR 418, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W183-00000-00&context=1519360)_

_Huang v Secretary of State for the Home Dept, Kashmiri v Secretary of State for the Home Dept [2007] UKHL 11,_

_[[2007] 4 All ER 15, [2007] 2 AC 167, [2007] 5 LRC 320, [2007] 2 WLR 581.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PRJ-3D10-TWP1-61N4-00000-00&context=1519360)_

_[Mathieson v Secretary of State for Work and Pensions [2015] UKSC 47, [2016] 1 All ER 779, [2015] 1 WLR 3250,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5P-0TS1-DYBP-M47G-00000-00&context=1519360)_
[(2015) 146 BMLR 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HG8-F3D1-DYJ0-B2GX-00000-00&context=1519360)

_Minter v UK (App no 62964/14) (2017) 65 EHRR SE51, ECtHR._

_[R v Docherty [2016] UKSC 62, [2017] 4 All ER 263, [2017] 1 WLR 181.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)_

_[R (on the application of A) v Criminal Injuries Compensation Authority [2021] UKSC 27, [2022] 1 All ER 577, [2021]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64RX-C0V3-GXF6-80JN-00000-00&context=1519360)_
[1 WLR 3746, [2021] All ER (D) 33 (Jul).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:633N-TVF3-GXFD-82VF-00000-00&context=1519360)

_R (on the application of Aguilar Quila) v Secretary of State for the Home Dept, R (on the application of Bibi) v same_

_[[2011] UKSC 45, [2012] 1 All ER 1011, [2012] 1 AC 621, [2011] 3 WLR 836, [2012] 1 FLR 788.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M209-00000-00&context=1519360)_

_R (on the application of Clift) v Secretary of State for the Home Dept, R (on the application of Hindawi) v Secretary_
_of State for the Home Dept [2006] UKHL 54,_
**[*651]**

_[[2007] 2 All ER 1, [2007] 1 AC 484, (2006) 21 BHRC 704, [2007] 2 WLR 24.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NBY-MTM0-TWP1-60SN-00000-00&context=1519360)_

_R (on the application of DA) v Secretary of State for Work and Pensions, R (on the application of DS) v Secretary of_
_[State for Work and Pensions [2019] UKSC 21, [2020] 1 All ER 573, [2019] PTSR 1072, [2019] 1 WLR 3289.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_

_[R (on the application of Haney) v Secretary of State for Justice [2014] UKSC 66, [2015] 2 All ER 822, [2015] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G0G-M5W1-DYBP-M2GS-00000-00&context=1519360)_
[1344, (2014) 38 BHRC 313, [2015] 2 WLR 76.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3B7-00000-00&context=1519360)

_R (on the application of Kebede) v Secretary of State for Business Innovation and Skills [2013] EWHC 2396_
_(Admin), [2014] PTSR 92, [2013] EqLR 961._

_[R (on the application of RJM) v Secretary of State for Work and Pensions [2008] UKHL 63, [2009] 2 All ER 556,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W6K-CMW0-Y96Y-G0D2-00000-00&context=1519360)_

[[2009] AC 311, (2008) 26 BHRC 587, [2008] 3 WLR 1023.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0FC-00000-00&context=1519360)


-----

648

_[R (on the application of SC) v Secretary of State for Work and Pensions [2021] UKSC 26, [2022] 3 All ER 95, [2021]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S8-S3R3-GXF6-84Y2-00000-00&context=1519360)_
3 WLR 428.

_R (on the application of SM) v Lord Chancellor (Bail for Immigration Detainees intervening) [2021] EWHC 418_
_[(Admin), [2021] 1 WLR 3815, [2021] All ER (D) 117 (Feb).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6239-W103-GXFD-82RJ-00000-00&context=1519360)_

_[R (on the application of Stott) v Secretary for State for Justice [2018] UKSC 59, [2019] 2 All ER 351, [2020] AC 51,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_

[2018] 3 WLR 1831.

_[R (on the application of Tigere) v Secretary of State for Business, Innovation and Skills [2015] UKSC 57, [2016] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
_[All ER 191, [2015] 1 WLR 3820, (2015) 40 BHRC 19.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_

_[Stec v UK (App nos 65731/01 and 65900/01) (2006) 20 BHRC 348, (2006) 43 EHRR 1017, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W399-00000-00&context=1519360)_

_Stevenson v Secretary of State for Work Pensions_ _[[2017] EWCA Civ 2123.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R60-TG01-F0JY-C3KT-00000-00&context=1519360)_

_[Thlimmenos v Greece (App no 34369/97) (2000) 9 BHRC 12, (2000) 31 EHRR 411, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3V5-00000-00&context=1519360)_
**Judicial review**

The claimant, Jawad Naeem, sought judicial review of the decision of the Secretary of State for Education refusing
his application for student finance under the Education (Student Support) Regulations 2011, _[SI 2011/1986. Kyra](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:53K6-0XP1-F16W-C4X2-00000-00&context=1519360)_
Morris appeared as interested party.

_Amanda Weston QC and Gráinne Mellon (instructed by Watkins Solicitors) for the claimant and interested party._

_Leon Glenister (instructed by the Government Legal Department) for the Secretary of State._

_Judgment was reserved._

6 January 2022. The following judgment was delivered.

**FOSTER J.**
**Introduction and the Issue**

**[1] This application brings a challenge to the Education (Student Support) Regulations 2011,** _[SI 2011/1986 (as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:53K6-0XP1-F16W-C4X2-00000-00&context=1519360)_
amended) ('the Regulations'). The Regulations are made by the Defendant Secretary of State for Education and
contain the eligibility requirements for provision of student finance to would-be higher education students.
**[*652]**

**[2] By para 2(1)(a) of Sch 1 to the Regulations the Claimant was required to be 'settled in the United Kingdom' in**
immigration terms, on the first day of the first academic year of his course, that is to say by 1 September 2020 to be
eligible for receipt of student finance.

**[3] The Claimant challenges the Defendant's refusal of his application for finance under the Regulations on the**
grounds he did not satisfy the requirement to be 'settled' on 1 September 2020. His case is that applying this
requirement to him was discriminatory contrary to art 14 of the European Convention on Human Rights ('ECHR')
read with art 2 of the First Protocol to the Convention ('A2P1').

**[4] A further argument in respect of art 1 of the First Protocol to the Convention was also raised but, although not**
conceded, not pursued in this case since the Defendant accepts the application of art 14 read with A2P1 to the
issues but denies any infringement of rights.

**[5] The Claimant made an application for settled status in May 2020. He had in previous applications used the**
Home Office Super Priority visa application service which grants visas within 24 hours on payment of a fee. A
similar Priority Service granted visas on payment of a smaller fee within five working days. If no fees are paid, the


-----

648

turnaround offered by the Home Office for disposal of an Indefinite Leave to Remain ('ILR') Visa application is six
months. With only a few days' notice, the Priority channels were withdrawn by the Home Office on 31 March 2020,
unknown to the Claimant until he sought to submit his application on 17 May 2020. He had no alternative but to
make his application by the slower route. The Claimant achieved his place at university and made his application for
student finance on 24 August 2020. His evidence is that he fully expected to be granted settled status, as he was
aware he fulfilled the immigration criteria, accordingly in his application he stated that he was entitled to settled
status.

**[6] In the event, the Claimant chased the Home Office on several occasions, but was only offered an extension to**
[his limited leave to remain pursuant to s 3C of the Immigration Act 1971, and so the Claimant started his course on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y02Y-00000-00&context=1519360)
25 September 2020 without finance but incurring fees. On 23 November 2020 he was granted Indefinite Leave To
Remain and acquired settled status. By letter of 18 December 2020 he was informed that he was ineligible for
student finance because he had not met the 1 September 2020 deadline. The same day the Claimant began the
statutory two-stage appeals process against the decision. That process was exhausted, unsuccessfully, on 24
February 2021 whereupon he referred his case to an Independent Assessor and thereafter entered into pre-action
correspondence.

**[7] The Claimant argues that in the context of the COVID-19 Pandemic the application of the requirement to be**
settled in the United Kingdom on 1 September 2020 the first day of the academic year of his course, as provided by
para 2(1)(a) of Sch 1 to the Regulations, discriminated unlawfully against him contrary to art 14 of the ECHR.

**[8] The Interested Party is a citizen of South Africa and in substantially the same position as the Claimant, having**
been caught by the withdrawal of the priority schemes at a time when it was too late to acquire ILR through the only
remaining six-month route.
**[*653] The Framework**

**[[9] The power of the Secretary of State for Education to make Regulations derives from s 22 of the Teaching and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYC0-TWPY-Y1JS-00000-00&context=1519360)**
Higher Education Act 1998 as amended ('the 1998 Act') which provides relevantly:

'(1) Regulations shall make provision authorising or requiring the Secretary of State to make grants or loans,
for any prescribed purposes, to eligible students in connection with their undertaking—

(a) higher education courses, or

(b) further education courses,

which are designed for the purposes of this section by or under the regulations.

(2) Regulations under this section may, in particular, make provision—

(a) for determining whether a person is an eligible student in relation to any grant or loan available under this
section …'

**[10] The relevant requirement of eligibility appears as follows in reg 4 of the Regulations:**

'(1) An eligible student qualifies for support in connection with a designated course subject to and in
accordance with these Regulations.

(2) Subject to paragraph (3), a person is an eligible student in connection with a designated course if in
assessing that person's application for support the Secretary of State determines that the person falls within
one of the categories set out in Part 2 of Schedule 1.' (Emphasis added.)

**[11] The relevant eligibility category in FN's case is set out at para 2 of Sch 1 to the Regulations and is entitled**
'Persons who are settled in the United Kingdom'. It provides relevantly:


-----

648

'(1) A person who on the first day of the first academic year of the course—

(a) is settled in the United Kingdom other than by reason of having acquired the right of permanent residence;

(b) is ordinarily resident in England;

(c) has been ordinarily resident in the United Kingdom and Islands throughout the three-year period preceding
the first day of the first academic year of the course; and

(d) subject to sub-paragraph (2), whose residence in the United Kingdom and Islands has not during any part
of the period referred to in paragraph (c) been wholly or mainly for the purpose of receiving full-time education.

(2) Paragraph (d) of sub-paragraph (1) does not apply to a person who is treated as being ordinarily resident in
the United Kingdom and Islands in accordance with paragraph 1(4).'

**[12] 'Settled' in para 2(1)(a) above is defined in para 1(1) of Sch 1 to the Regulations having 'the meaning given by**
_[section 33(2A) of the Immigration Act 1971'. It provides that:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFF0-TWPY-Y19V-00000-00&context=1519360)_

'… references to a person being settled in the United Kingdom are references to his being ordinarily resident
there without being subject under the immigration laws to any restriction on the period for which he may
remain.'

**[13] Regulation 2 defines 'academic year' as—**
**[*654]**

'the period of twelve months beginning on 1st January, 1st April, 1st July or 1st September of the calendar year
in which the academic year of the course in question begins according to whether that academic year begins
on or after 1st January and before 1st April, on or after 1st April and before 1st July, on or after 1st July and
before 1st August or on or after 1st August and on or before 31st December, respectively …'

**[14] The effect of the scheme for both Claimant and Interested Party is that a failure to achieve the criteria for the**
receipt of student finance on the first day of the first term of the first year of the course, means no finance is payable
for the whole of the academic course. The effect of this is that debts incurred to date are payable, yet because
eligibility to student finance support is established at the beginning of a student's course, a student remains
ineligible for support for the duration of the course if the 1 September 2020 date is missed. As each of the appeal
decisions acknowledged, and the Independent Assessor, there is no relevant compassionate or other discretion to
disapply the requirements of the Regulations.
**Factual Background**

**[15] The Claimant Mr Jawad Naeem is a citizen of Pakistan who was born on 27 November 1987. He is a currently**
a second-year student at Nottingham Trent University where he is studying for a BSc degree in Computer Science
(Cyber Security). His current position is tenuous because of his inability, without a loan from student finance, to fund
his place.

**[16] Jawad Naeem entered the UK on 14 April 2015 as the spouse of a person settled here. On 13 December 2017**
he was granted a visa extension with limited leave for two-and-a-half years. Accordingly, his visa was due to expire
on 18 May 2020. On 14 April 2020 he became eligible to apply for Indefinite Leave to Remain ('ILR') as a partner on
what is known colloquially as the '5-year route', outlined in Appendix FM to the Immigration Rules. He was only
entitled to apply for such an extension during the window of his last 28 days' currency of his limited visa.

**[17] The Claimant had applied for a place at Nottingham Trent University to study for the degree. He was accepted**
for the course commencing in September 2020 and explains that he gave up his employment in order to attend the
university and better his and his family's prospects. He had been made aware that he was entitled to ILR and
lodged his application for settled status. He had utilised the fast track before and has deposed he intended to on
this occasion


-----

648

**[18] Under the Super-Priority Service utilised previously, the 24-hour service cost £800 whilst the Priority Service**
five-day turnaround would be guaranteed on payment of £500. When he spoke to his solicitor, they discovered that
both services had been withdrawn by the Home Office citing the effects of the Pandemic. The compulsory online
application process had no provision for urgency. The Home Office had also closed all UK Visa and Citizenship
Application Centres and Service and Support Centres. The Claimant was unable to communicate the urgency of his
application.

**[19] Kyra Morris, the Interested Party, is a citizen of South Africa born on 11 February 1999, moving to the UK 10**
August 2015 as a child dependent upon the Ancestral visa held by her father. Kyra Morris completed her A-levels in
the UK in 2017, following which she intended to read Physics and Astrophysics at the University of Bristol. She was
unable to afford the international fees and so required to be qualified as a Home Student.
**[*655]**

**[20] Accordingly, on 2 July 2020, she made an application for ILR intending to use the Super Priority Route. She**
was unaware until some weeks after that she required funding to be in place by 1 September 2020 for starting in
the Autumn Term.

**[21] Given the COVID-19 delays and the loss of the Super Priority Route, she contacted her local MP to help,**
following which her application was dealt with speedily, but she achieved ILR only on 4 September 2020. The
University of Bristol agreed to classify her as a Home Student nonetheless, but she was informed on 18 November
2020 that because ILR was not in place on 1 September, she had been refused student funding.

**[22] Ms Morris began her Physics and Astrophysics course on 5 October 2020 but has been warned unless she**
can pay her first year's fees she may be unable to continue to the second year. She is without the means to do so
and so far owes a debt of £9,250 which will remain outstanding even if she is unable to continue her course.
Because of the effect of the failure on 1 September 2020 under the student finance scheme, she is ineligible for
funding for the whole of the rest of the course.

**[23] The evidence before the court as to the Home Office website was not complete but suggested that on 23**
March 2020 a warning was posted to the visa application website stating that the priority and super-priority services
would be withdrawn on 30 March 2020. The effect of this is that given that the general service indication for ILR
visas is a six-month turnaround, the warning of 23 March 2020 came too late for any person whose visa application
was made, (by my calculation, and allowing no margin for error) after Friday, 28 February 2020. That date was the
last working day when a six-month turnaround would have been expected to have produced a decision before 1
September 2020 for Autumn commencement. Applicants, who needed to rely upon the Priority Services, would be
unable to acquire ILR in time to comply with the Regulations.

**[24] The Claimant accepted a place at university to study for a BSc Honours degree in Computer Systems (Cyber**
Security). On 24 August 2020 (still not having heard in response to the visa application) he made an application for
student finance to the Defendant, filling in the appropriate forms. In those forms he was asked about his settled
status and he put 'ILR' and gave the application reference number. Whilst the Secretary of State did not contend
this was actually dishonest, he observed that 'at a minimum Mr Naeem should have known he was not entitled to
ILR'. (In the event, a visa was granted on 23 November 2020, in the usual course, without query.)

**[25] On 28 August 2020 the Claimant emailed the Home Office at their contact address for coronavirus issues,**
requesting a letter to provide to the University to confirm his ILR status/eligibility. However, instead, on 1 September
[2020 his limited leave to remain was extended pursuant to s 3C of the Immigration Act 1971 – which did not entitle](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y02Y-00000-00&context=1519360)
him to student finance.

**[26] The Claimant nonetheless continued to chase and started the course on 25 September 2020 hoping matters**
would be resolved.

**[27] Student Finance England who administer student finance asked him for settled status information on 9 October**
2020 – but by this date no reply had been received. He emailed the Home Office again on 20 November 2020


-----

648

telling them of the request. On 23 November the Claimant was informed that a Biometric Residence Permit was
being sent and an attached information sheet confirmed his application for ILR had been approved with
confirmation by way of the Biometric Residence Permit. It appears that on or about
**[*656]**

21 September 2020 the Home Office told Student Finance that Mr Naeem had applied in time, but the outcome was
still outstanding. He was deemed ineligible for student finance on 18 December 2020 in the following terms:

'As Mr Naeem's ILR was not granted prior to 1 September 2020, he cannot be seen as entitled within the UK
for the purpose of student finance on the first day of the academic year.'

By this date, the Claimant had of course received his ILR status, but it was not extant prior to 1 September 2020.

**[28] The Claimant submitted a Stage 1 appeal against the decision on 18 December 2020 explaining his position**
and intention to use the Super Priority Service, indicating that the application of the Regulations meant he would be
personally liable for the fees incurred and that he could not afford to drop out and defer his course for a year. On 1
February 2021, being without response to the appeal, he made a complaint. The response was communicated the
following day indicating the framework required that status as at the 1 September 2020 had to be considered. A
Stage 2 appeal was issued by the Claimant on 4 February 2021 in similar terms to the Stage 1 appeal. The appeal
body responded on 24 February 2021 that the jurisdiction was limited to considering the proper application of the
Regulations. Student Finance England confirmed to him this was the effect of the decision.

**[29] An Independent Assessor considered a request by him for consideration and on 19 May she accepted the facts**
advanced by the Claimant, namely that he intended to use the Super Priority Service and concluded it was 'through
no fault of his own' that he did not have ILR by 1 September 2020. She concluded the Claimant was unlikely to be
able to complete his course without a student loan but was compelled to conclude that the Claimant did not meet
the requirements of the Regulations because of the limits of her jurisdiction. The Interested Party also exhausted
the appeal route, unsuccessfully, but with similar comments as to the unfairness of her position. Although to an
extent challenged by the Defendant, I see no reason not to accept the underlying facts as they were found by these
Tribunals.

**[30] The Claimant and Interested Party rely also upon the publication of a policy entitled 'Government support**
_package for higher education providers and students' for an illustration of what they regard as the unfairness of the_
position compared with the allowances made for foreign students coming to study here. They note it said:

'The government is clear that we do not want to see students miss out on the opportunity to benefit from our
excellent HE system as a result of Covid 19.'

**[31] This position was echoed during Parliamentary Questions and Answers on 22 June 2020. Gillian Keegan,**
Minister for Apprenticeships and Skills at the Department for Education said:

'In May we announced a package of measures to support our universities and safeguard the interests of
students. This means that every student who wants to go to university and gets the grades can achieve their
ambitions.'

The support package referred to a—

'discretion to ensure that international students are not negatively impacted if they find themselves in a position
where they cannot comply with certain Visa rules as a result of the Covid 19 outbreak …'

**[*657]**

**[32] There were specific changes introduced through new guidance or amended guidance. The applicants draw**
attention to the following:


-----

648

(i)   'Guidance for students from England Wales and Northern Ireland' published on 27 August 2020,
indicating that eligibility for student finance would be extended to individuals unable to meet UK residency
requirements due to COVID-19: this was a policy statement by the Student Loans Company.

(ii)   'Covid 19: Guidance for Student sponsors, migrants and Short-term students', under which
international students were permitted to begin their courses before their Visa applications had been
decided.

(iii)   'Coronavirus (Covid-19) fact sheet: Visa holders and short-term residents in the UK' 9 April 2020
giving permission for Tier 4 students to comply with Visa requirements through distance learning.

**[33] Reliance is placed upon the contrast between these concessions to the effects of the pandemic for others, and**
the suspension of the Priority and Super Priority Services at the end of March 2020 to show that in some areas
accommodation was made for the effects of the Pandemic on applications. Indeed eligibility was extended to those
who could not meet residency requirements. The Defendant indicated they related principally to travel issues.

**[34] In the course of the Claimant's pre-action correspondence with the Defendant he invited the Defendant to**
review the application of the Regulations during the currency of the COVID-19 Pandemic to individuals who had an
outstanding application on the first day of the first year of their academic course and who meet the requirements for
ILR such that they would have been 'settled' but for the suspension of the Home Office priority service. The
Defendant was invited to amend the Regulations with retrospective effect to provide student funding for individuals
within that class. He agreed to a review but declined to make any changes.

**[35] The Super Priority Service appears to have been restored in respect of all ILR applications in the early months**
of 2021. Apparently there has been some but not extensive restoration of the Priority Service.
**The Defendant's Position**

**[36] The Secretary of State and Minister of State for Universities were provided for the purposes of the review with**
a Ministerial Submission recommending rejection. The Ministers adopted the reasoning in the Submission and
refused to accommodate the claim of the Claimant and Interested Party under the Regulations or otherwise.

**[37] The Secretary of State relies in these proceedings on the reasoning of the Submission.**

**[38] The Ministers declined to make any changes—**

'given the operational importance of maintaining clear rules on eligibility, and the serious difficulties in
introducing a retrospective change that would apply only to students affected by the Home Office action.'

This was explained in the following way:

(i)   Both claimants were aware when they made their application for ILR that the priority service was not
available and that the turnaround for their application would be up to six months. Further, they both began
their courses knowing that they did not meet the requirement to be settled at the relevant date (or if they
did not know, they should have known).

**[*658]**

(ii)   If the Claimant and Interested Party had begun an academic course starting after January 2021 (thus
delaying the start of their courses by only a few months, or by one year for the same course in September
2021) they would meet the requirement to be settled on the first day of the first academic year of the
course so it was not the case they were denied access to Higher Education rather, they may need to defer
for no more than one year.

(iii)   High-level case law (R (on the application of Tigere) v Secretary of State for Business, Innovation
_[and Skills [2015] UKSC 57, [2016] 1 All ER 191, [2015] 1 WLR 3820) supported the legality and rationality](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
of having clear bright line rules on eligibility for student finance, and the lack of an 'exceptional
circumstances' discretion was lawful, an individualised system would have very powerful disadvantages.


-----

**[*659]**


648

(iv)   It was justifiable to maintain the requirement in the Pandemic even given the withdrawal of the Home
Office priority services because, applying the requirement to be settled on the first day of the first academic
year of the course always meant that some students have fallen on the wrong side of the relevant date by
a few days, and sometimes for reasons beyond their control eg where the HO has not met its own service
standards, or because key documents have been lost by a third party. 'It is not obvious that such persons
would be any less “deserving” than the current claimants.' This requires a general power of exceptions and
that would be a very difficult system to operate fairly. The SoS would have to make judgments on decisions
made by other Ministers.

(v)   Second, any scheme would have to be of general application as it would be very difficult to provide
an exception which applied only to the claimants. Such a scheme would require evidence of whether, had it
not been for the withdrawal of that service the student would have use the priority system, whether there
was an outstanding application on the first day of the course and whether that application was
subsequently granted. It would be necessary to discover whether the delays were as a direct result of the
withdrawal of the super priority service; and that would be impossible.

(vi)   It would allow students who never intended to use the service to claim student finance earlier than
entitled under the Regulations. Accordingly it would have to cover all who applied for ILR between 30
March 2020 and 31 March 2021. Statistics show there were 95,120 decisions on applications for
settlement in the UK from non-EEA nationals in the year ending March 2020. Even if the Regulations could
be amended retrospectively it would have to be applied as a blanket policy ie if a person can show they
applied for ILR between these dates and were subsequently granted it, they could have the requirement to
be settled on the first day of the first academic year waived and would be eligible for funding for the entirety
of their course. This opens up the scope for funding considerably and would inevitably bring into scope a
significant number of students who did not meet the settlement year rule solely as a result of their own
actions.

(vii)   A significant number of students may have refrained from application knowing they were not eligible,
they may have self-funded, others may have deferred their studies until they became eligible. It would not
be fair on them to have a scheme that made exceptions that benefited these applicants.

(viii)   Fourth, they should have known of the requirements and when they applied would have been
aware the priority service was not operating and they would be considered under the standard Home Office
timeframe, and when they made their application for student finance they should have known they were not
eligible.



**[39] The Minister concluded that a scheme to allow the Claimant and Interested Party to obtain finance now was**
not a proportionate response to the 'slight delay in obtaining settled status', and therefore, student funding.

**[40] The Secretary of State represented by Mr Leon Glenister did not take issue with the framework within which**
the application for judicial review took place. He disputed, however, the basis upon which status was asserted. The
first basis for 'other status' was derived from the Statement of Facts and Grounds in terms that the Claimant was 'a
person who meets the requirements of ILR under the Immigration Rules but he was prevented from meeting the
eligibility of the Regulations by suspension of the Home Office priority service'. This is later described in the
skeleton argument, he observes, as 'students who owing to the suspension of the Home Office Priority
Service/Super Priority Service between 30 March 2020 and 31 March 2021 were granted ILR after the first day of
the first academic year of their course, where they would have been granted ILR before the first day of the first
academic year of their course had the priority service remained in operation'. This status cannot be relevant he
argues because the Claimant asserts he was treated differently from 1 September 2020 because it is at that date
that he suffered the detriment of not meeting the requirement.

**[41] Mr Glenister says this means his 'other status', by reason of which he was discriminated against, must be that**
he had limited leave to remain with an outstanding application for ILR – in his skeleton argument the Secretary of
State says the Claimant had not expressed his claim in this way so must fail He also raises a further point: the


-----

648

effect of what the Claimant says amounts to asserting a status which seeks to go behind his formal immigration
status which is equivalent to prejudging the application to be determined by the Home Office, and it cannot form the
basis of a claim to differential treatment – of course the treatment is different, because the status is different.

**[42] This case is different from the situation in Tigere, he argues, where what was compared was an immigration**
status, namely discretionary leave to remain, that shared similar characteristics to the ILR in terms of its connection
to the UK but did not carry with it the student finance consequences of ILR. Further and in any event, the asserted
status is merely a 'description of the difference in treatment' as opposed to the 'ground of the difference in
[treatment' which R (on the application of SC) v Secretary of State for Work and Pensions [2021] UKSC 26, [2022] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S8-S3R3-GXF6-84Y2-00000-00&context=1519360)
_[All ER 95, [2021] 3 WLR 428describes. The status asserted contains the phrase he was 'prevented from meeting](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S8-S3R3-GXF6-84Y2-00000-00&context=1519360)_
the eligibility criteria by suspension of the Home Office priority service', but that is, he said 'open to significant
interpretation'. In any event, the fact he was 'prevented' from obtaining ILR is not a part of the ground of difference
in treatment. The reason he was treated differently, was that he had limited leave to remain.

**[[43] Mr Glenister relies upon the case of R v Docherty [2016] UKSC 62, [2017] 4 All ER 263, [2017] 1 WLR 181(at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)**
para [63]). In that case, the Claimant said he was discriminated against by being treated less favourably than a
prisoner who had been convicted on a different date. By that different date, the law had
**[*660]**

changed and the nature of the sentence available for that other person had changed, it was more lenient than that
to which the Claimant was exposed.

**[44] Lord Hughes giving the judgment of the court stated:**

'[63] … even if it be assumed in the appellant's favour that the mere date of conviction can amount to a
sufficient status, which is doubtful, the differential in treatment is clearly justified. All changes in sentencing law
have to start somewhere. It will inevitably be possible in every case of such a change to find a difference in
treatment as between a defendant sentenced on the day before the change is effective and a defendant
sentenced on the day after it. The difference of treatment is inherent in the change in the law. If it were to be
objectionable discrimination it would be impossible to change the law.'

**[45] Mr Glenister submitted there was in truth no 'other status' than the difference in immigration position. The**
Claimant was treated in the same way as any other individual who, for example could not afford the priority service,
or had a delay in considering their application. He was justifiably treated differently to somebody who had already
been granted ILR and this application requires the Defendant to second-guess an application for ILR.

**[46] Mr Glenister defends the bright-line rule of 1 September cut-off date as a practical part of its operation which**
inevitably means some students might miss the deadline for reasons beyond their control. Such students are as
'deserving' as the Claimant; the detriment to the student was not great because they needed only to delay the start
of their course for a few months or at worst a year.

**[47] He further argued that the Claimant was aware or should have been aware of the requirement of 1 September**
2020 and in stating that he had been granted ILR and was 'settled' was wrong – that was why he was in the position
he was now in. The same could be said, as I understand his submission, for the Interested Party who began the
course knowing she did not meet the criteria for student finance. I understood this to be his argument against any
suggested detriment to the students on the basis that they had incurred fees and would be left high and dry, with
debts but no course to continue were their applications to fail.

**[48] A central tenet of the Secretary of State's refusal to accede to the claims, and of Mr Glenister's defence of the**
claim was what were described as the unfairness to others who might be in similar positions, but who would not
obtain relief. Emphasis was laid on the further ramifications if any exception were to be made in respect of this
claimant and Interested Party.
**Consideration**


-----

648

**[49] Ms Amanda Weston QC and Ms Grainne Mellon on behalf of the Claimant argue that this case involves a**
straightforward application of art 14. The Claimant says:

(i)   The regulation of student finance fell within the ambit of A2P1.

(ii)   The Claimant at the material time, namely by 1 September 2020, met the requirements for ILR but
was prevented from satisfying the criteria in the Regulation by the summary suspension of the Priority
Service and was therefore a person having 'other status' as one of the group of 'students who achieved ILR
only after the first day of the first academic year of their course due to the summary suspension of the
priority service/super

**[*661]**

priority service between 30 March 2020 and 31 March 2021 and who would have been granted ILR before
the relevant date, but for the suspension of the service'. The difference does not relate to substantive
satisfaction of the Regulation, but to withdrawal of the fast-track policy.

(iii)   Alternatively, he was treated in the same way as those who did not meet the criteria for ILR, despite
being in a materially different situation was not treated differently from them. In other words a Thlimmenos
_[v Greece (App no 34369/97) (2000) 9 BHRC 12, (2000) 31 EHRR 411 analysis. This could be expressed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3V5-00000-00&context=1519360)_
alternatively as he ought to have been treated the same as those who had received ILR by the 1
September 2020 because he was in a relevantly analogous situation and the consequential prejudice is
considerable since he is deemed ineligible for finance for the whole degree course, not just the year.

(iv) There is no objective and reasonable justification for such detriment/discriminatory
treatment/difference in treatment. Further, the cohort of those affected is small and may be addressed
easily by amendment to the relevant Regulations.

**[50] It was not in issue that, as Baroness Hale set out in R (on the application of DA) v Secretary of State for Work**
_[and Pensions, R (on the application of DS) v Secretary of State for Work and Pensions [2019] UKSC 21, [2020] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_
_[All ER 573, [2019] PTSR 1072, there are four questions to be asked namely:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_

'(i) Does the subject matter of the complaint fall within the ambit of one of the substantive Convention rights?

(ii) Does the ground upon which the complainants have been treated differently from others constitute a status?

(iii) Have they been treated differently from other people not sharing that status who are similarly situated or,
alternatively, have they been treated in the same way as other people not sharing that status whose situation is
relevantly different from theirs?

(iv) Does that difference or similarity in treatment have an objective and reasonable justification, in other words,
does it pursue a legitimate aim and do the means employed bear a reasonable relationship of proportionality to
[the aims sought to be realised (see Stec v UK (App nos 65731/01 and 65900/01) (2006) 20 BHRC 348, (2006)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W399-00000-00&context=1519360)
43 EHRR 1017 (para 51))?'

**[51] I turn to these questions now. It is convenient to consider (ii) and (iii) together.**
_Ambit. (i) Does the subject matter of the complaint fall within the ambit of one of the substantive Convention rights?_

**[52] On question (i) as both parties agree, a generous approach is taken by the court to the notion of falling within**
the ambit of a substantive Convention right. As long as the impugned measure has more than a tenuous connection
with one of the core values protected by an ECHR right, the court will recognise the subject matter as coming within
the ambit of that right. Article 2 Protocol 1 has been extended to the regulation of financial support for education. As
was said in R (on the application of Kebede) v Secretary of State for Business Innovation and Skills [2013] EWHC
_2396 (Admin), [2014] PTSR 92, [2013] EqLR 961:_

'Nobody can have access to university education unless funding is found to discharge the fees. State support
for the discharge of fees by way of


-----

648

**[*662]**

loans will be, for a very large number of people, the only practical way of paying them. It is therefore an
important feature in providing practical and effective access to university education. For this reason I do not
accept that the current arrangements relating to funding are too remote from the right guaranteed by A2P1 to
fall outside its ambit and therefore to be considered by reference to article 14.'

**[53] The central areas of dispute between the parties were as to whether it was possible to discern 'other status'**
into which the Claimant and Interested Party fell, and if so whether differential treatment could be justified.
_Status (ii) Does the ground upon which the complainants have been treated differently from others constitute a_
_status? And_
_Differential treatment (iii) Have they been treated differently from other people not sharing that status who are_
_similarly situated or, alternatively, have they been treated in the same way as other people not sharing that status_
_whose situation is relevantly different from theirs?_

**[54] The Claimant argues that a broad, non-mechanistic approach is necessary when deciding whether the**
treatment complained of could be described as on grounds of 'other status'. It seems to me that must now be
correct by reference to the recent developments in understanding of how art 14 operates to right public law wrongs,
as set out in more detail below.

**[55] The Claimant submits that the legislative context includes the clear public interest in ensuring that people in the**
position of the Claimant and Interested Party achieve their educational goals, became taxpayers and earners, and
made a positive contribution to society. The general context for the application was the awareness on the behalf of
the Secretary of State for Education that the Pandemic was impacting upon studying and on applications in respect
of education both from abroad and at home. This is a fair representation of the context of the case in my judgment,
and I would add to the factual context of the application as follows. As a matter of common sense, decisions as to
university courses and study are frequently once-in-a-lifetime matters, and have significant consequences bringing
with them attendant expenses and life-style and other changes. Further, a particular selected course may not be
available to a student in a different year from that in which it is first offered. The loss of a particular course at a
particular time is a matter of real significance.

**[56] Ms Weston QC submitted that the Secretary of State treats ILR as a proxy for being 'settled' ie sufficiently**
connected to the UK for the purposes of accessing student finance, but that the notion of a sufficient connection
with the United Kingdom was not necessarily reflected in the possession of ILR/settled status under the Immigration
Rules. Thus, being sufficiently settled in the UK for the purposes of accessing student finance was not always
coterminous with the possession of ILR. In other words, colloquially, one could be sufficiently connected for the
purposes of the intention behind the Regulations without the actual visa in one's hand.

**[57] In support of these contentions Ms Weston QC referred to a number of recent cases of high authority.**
Tigere

**[58] The starting point for this consideration is the case of R (on the application of Tigere) v Secretary of State for**
_Business, Innovation and Skills_
**[*663]**

_[[2015] UKSC 57, [2016] 1 All ER 191, [2015] 1 WLR 3820in which the court considered the statutory purpose of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
restriction of student finance to those who were legally 'settled' in the UK and had three years' lawful ordinary
residence. The applicant had only discretionary leave to remain, and she was 'settled here for many years in the
factual sense but not so settled in the legal sense' (per Baroness Hale at para [1]), that is, she did not have the ILR
required by the first day of the first academic year of the course and so was excluded from receiving a student loan.

**[59] The Court held that immigration status could be an 'other status' within the meaning of art 14 (following Bah v**
_[UK (App no 56328/07) (2011) 31 BHRC 609, (2011) 54 EHRR 773), and the exclusion of those who did not have](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2W4-00000-00&context=1519360)_
ILR in the United Kingdom would be discriminatory under art 14 unless justifiable and proportionate to its objective,


-----

648

and it _could be justifiable and proportionate on the basis it was legitimate to target resources on those who are_
properly part of the community and likely to remain here, and contribute. However, by a majority, the appeal was
allowed (the court intervening because there was no evidence the Secretary of State had addressed his mind to the
relevant issue), and deciding that the Claimant, had, on the facts of her case, the same reasonable prospect of
benefiting society from a contribution after a university education and repaying loans as did those who met the full
ILR requirement.

**[60] At para [55] Baroness Hale said:**

'It is readily understandable why the Secretary of State for Business, Innovation and Skills should have looked
to the immigration rules for a convenient definition of those who are sufficiently connected with this country to
justify receipt of the subsidy. But if he is to take that course, he needs to consider whether those rules do in fact
adequately identify those who are sufficiently connected when it comes to University funding, and exclude
those who are not. The purposes served by the immigration rules are not identical to the purposes of the
regulations governing eligibility for student loans.'

**[61] On this basis, Ms Weston QC said, it was appropriate to regard the Claimant in the present action as within the**
class of persons intended to benefit from the student finance provisions. I agree. As she expressed it orally, at the
point at which eligibility had to be shown under the Regulations the Claimant and the Interested Party had the
attributes of status.
R (Stott)

**[62] The flexibility of 'other status', recognising that an acquired or temporary status may suffice, is found in R (on**
_[the application of Stott) v Secretary for State for Justice [2018] UKSC 59, [2019] 2 All ER 351, [2020] AC 51. In that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_
case the Supreme Court was considering the rule that an offender serving an extended determinate sentence was
only eligible for release on parole after serving two thirds of the appropriate custodial term whereas other prisoners
serving determinate sentences became eligible after the halfway point. The majority held that this difference in
treatment was a difference on the grounds of 'other status' within art 14.

**[63] In Stott the Supreme Court decided (by a majority of four to one) to depart from the previous decision of R (on**
_the application of Clift) v Secretary of State for the Home Dept, R (on the application of Hindawi) v Secretary of_
_[State for the Home Dept [2006] UKHL 54, [2007] 2 All ER 1, [2007] 1 AC 484and follow the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NBY-MTM0-TWP1-60SN-00000-00&context=1519360)_
**[*664]**

[decision of the European Court in Clift v UK (App no 7205/07) [2010] ECHR 7205/07 (13 July 2010) in holding that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1CR-00000-00&context=1519360)
being a prisoner serving a determinate sentence of imprisonment of more than 15 years amounts to a status.

**[64]** _Stott was a case in which the developing concept of 'other status' was explored and the question whether there_
was a requirement for status to be defined by more than merely the difference in treatment complained of. Lady
Black JSC at para [56] gave the following overview of the development of the position through the case law starting
with the older cases:

'Reviewing these decisions, together with R (Clift), I think it can be said (although acknowledging the danger of
oversimplification) that prior to the decision in _Clift v UK_ … the House of Lords had adopted the following
position on “other status”.

(i) The possible grounds for discrimination under art 14 were not unlimited but a generous meaning ought to be
given to “other status”;

(ii) The _Kjeldsen test of looking for a “personal characteristic” by which persons or groups of persons were_
distinguishable from each other was to be applied;

(iii) Personal characteristics need not be innate, and the fact that a characteristic was a matter of personal
choice did not rule it out as a possible “other status”;


-----

648

(iv) There was support for the view that the personal characteristic could not be defined by the differential
treatment of which the person complained;

(v) There was a hint of a requirement that to qualify the characteristic needed to be “analogous” to those listed
in art 14, but it was not consistent (see, for example, Lord Neuburger's comment in para [43] of R (RJM)) and it
was not really borne out by the substance of the decisions;

(vi) There was some support for the idea that if the real reason for differential treatment was what someone
had done, rather than who or what he was, that would not be a personal characteristic, but it was not universal;

(vii) The more personal the characteristic in question, the more closely connected with the individual's
personality, the more difficult it would be to justify discrimination, with justification becoming increasingly less
difficult as the characteristic became more peripheral.'

**[65] Lady Black returned to the development of the law at [63] of Stott:**

'Returning to the list of propositions derived from the House of Lords' decisions which is to be found at para

[56] above, it seems to me that the subsequent authorities in the Supreme Court could be said to have
continued to proceed upon the basis of propositions (i) to (iii), which have also continued to be reflected in the
jurisprudence of the ECtHR. Proposition (iv) lives on, in _R v Docherty, but perhaps needs to be considered_
further, in the light of its rejection in Clift v UK (see further, below) … That court's answer to the argument was,
it will be recalled, to give quite wide-ranging examples of situations in which a violation of art 14 had been
found. With the continued expansion of the range of cases in which “other status” has been found, in domestic
and Strasbourg decisions, the search for analogy with the grounds expressly set out in art 14 might be thought
to be becoming both more difficult and less profitable. However, that should not, of course, undermine the
assistance

**[*665]**

that can be gained from reference to the listed grounds, taken with examples of “other status” derived from the
case law. It may not be helpful to pursue proposition (vi) abstract; whether it assists will depend upon the facts
of a particular case. Proposition (vii) comes into play when considering whether differential treatment is
justified, rather than in considering the “other status” question, and need not be further considered at this
stage.'

**[66] Lord Mance said at para [231]:**

'There is no reason why a person may not be identified as having a particular status when the or an aim is to
discriminate against him in some respect on the ground of that status.'

And at para [75] Lady Black perhaps summed up the approach; she was—

'cautious about spending too much time on an analysis of whether the proposed status has an independent
existence, as opposed to considering the situation as a whole, as encouraged by the ECtHR in Clift v UK.'

R (A)

**[67] The effect on the law of the decision in Clift v UK and the requirement, if any, for the independent existence**
condition with regard to status was considered further in two recent cases in the Supreme Court _R (on the_
_[application of A) v Criminal Injuries Compensation Authority [2021] UKSC 27, [2022] 1 All ER 577, [2021] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64RX-C0V3-GXF6-80JN-00000-00&context=1519360)_
[3746and R (on the application of SC) v Secretary of State for Work and Pensions [2021] UKSC 26, [2022] 3 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S8-S3R3-GXF6-84Y2-00000-00&context=1519360)
_[95, [2021] 3 WLR 428, both handed down on the same day. In R (A) the claimants were victims of modern slavery](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S8-S3R3-GXF6-84Y2-00000-00&context=1519360)_
and trafficking but their applications for compensation under a government scheme were refused on the grounds
that they did not qualify since they had unspent convictions.

**[68] Lord Lloyd-Jones, with whom the rest of the court agreed, set out the relevant passage from** _Clift v UK as_
follows:


-----

648

'60. … The question whether there is a difference of treatment based on a personal or identifiable characteristic
in any given case is a matter to be assessed taking into consideration all of the circumstances of the case and
bearing in mind that the aim of the Convention is to guarantee not rights that are theoretical or illusory but
rights that are practical and effective (see Artico v Italy _[[1980] ECHR 6694/74, para 33; and Cudak v Lithuania](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1KB-00000-00&context=1519360)_

_[[2010] ECHR 15869/02, para 36, 23 March 2010). It should be recalled in this regards that the general purpose](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X3HY-00000-00&context=1519360)_
of art 14 is to ensure that where a state provides for rights falling within the ambit of the Convention which go
beyond the minimum guarantees set out therein, those supplementary rights are applied fairly and consistently
to all those within its jurisdiction unless a difference of treatment is objectively justified.'

which, he described as giving:

'[42] … a broad meaning to “any other status” in art 14. In particular, it rejected (at para 56) earlier notions that
“any other status” must relate to innate or inherent characteristics …

[A]t the very least, suggest[ing] disapproval of an over technical approach.'

**[*666]**

**[69] Lord Lloyd-Jones reflected the conflicting approaches at Supreme Court level, including the observations of**
Lord Mance and Lord Hughes JJSC in R (on the application of Haney) v Secretary of State for Justice [2014] UKSC
_[66, [2015] 2 All ER 822, [2015] AC 1344to the effect that Clift, read literally, might eliminate altogether consideration](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G0G-M5W1-DYBP-M2GS-00000-00&context=1519360)_
of status.

**[[70] He also considered Mathieson v Secretary of State for Work and Pensions [2015] UKSC 47, [2016] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5P-0TS1-DYBP-M47G-00000-00&context=1519360)**
_[779, [2015] 1 WLR 3250. In](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5P-0TS1-DYBP-M47G-00000-00&context=1519360)_ _Mathieson treatment which was held to violate art 14 was suspending disability_
allowance to a child on the ground that he had been an in-patient in an NHS hospital for more than 84 days. There
was no suggestion that the 84-day criterion had any significance apart from the fact that it was the ground for the
difference in treatment complained of (between the entitlement of a disabled person in the claimant's situation and
that of a disabled person in an NHS hospital for 84 days or less). Even where the status is contrived the court
concluded the claimant had status falling within the grounds of discrimination prohibited by art 14.

**[71] At para [22] of Mathieson Lord Wilson reflected the ECtHR position saying:**

'It is clear that, if the alleged discrimination falls within the scope of a Convention right, the ECtHR is reluctant
to conclude that nevertheless the applicant has no relevant status, with the result that the inquiry into
discrimination cannot proceed.'

**[72] Lord Lloyd-Jones, having reviewed the case law, concluded at para [46] of SC:**

'In the light of this more generous approach to status, I have no doubt that being a victim of trafficking does
constitute a status for this purpose. Although it is an acquired characteristic resulting from something done as
opposed to being inherent or innate, it is plainly a personal identifiable characteristic to which many important
legal consequences attach.'

**[73] This has resonance for the applicants in the present case where the relevant characteristic is acquired,**
resulting from the withdrawal of the Priority Schemes.

**[74] Lord Lloyd-Jones dealt with the proposition that there was a requirement for 'individual existence' that is to say**
the question whether the status contended for exists solely by reference to the terms of the legislation or policy
which is under challenge and has no independent character; the argument being that a personal characteristic
cannot be defined by the differential treatment of which a person complains: the basis of the discrimination of which
complaint is made has to have an existence independent of the measure that is under attack. Lord Lloyd-Jones
agreed with Lord Reid in SC that art 14 draws a distinction between relevant status and difference in treatment and
the former could not be defined solely by the latter. Status must be something more than a mere description of the
difference in the treatment.
R (SC)


-----

648

**[75] Particular reliance was placed by Ms Weston QC upon SC, inviting the court to find that following this case,**
'status' now has an 'uncomplicated and
**[*667]**

broad reach'. The need to establish status as a separate requirement had, (see the authority of _Stevenson v_
_Secretary of State for Work Pensions_ _[[2017] EWCA Civ 2123 at para [41]) 'diminished almost to vanishing point'.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R60-TG01-F0JY-C3KT-00000-00&context=1519360)_

**[76] I accept as she submits, that the Court must look to the whole circumstances of the case when seeking to**
discover whether the construct of culpable art 14 differential treatment has taken place. The case of SC settles the
position and indicates Ms Weston QC is, in my judgment, correct in her submissions.

**[77] In** _SC Lord Reed gave the judgment of the court and referred, on the question of status to the reasoning of_
Leggatt LJ below, who held that the words in art 14 prohibiting discrimination 'on any ground such as sex, race,
colour, language, religion, political or other opinion, national or social origin, association with a national minority,
property, birth or other status' were:

'[69] … intended to add something to the requirement of discrimination. It followed that status could not be
defined solely by the difference in treatment complained of: it must be possible to identify a ground for the
difference in treatment in terms of a characteristic which was not merely a description of the difference in
treatment itself. On the other hand, he also observed that there seemed to be no reason to impose a
requirement that the status should exist independently, in the sense of having social or legal importance for
other purposes or in other contexts than the difference in treatment complained of.'

**[78] Lord Reed continued:**

'[71] … I would add that the issue of “status” is one which rarely troubles the European court. In the context of
article 14, “status” merely refers to the ground of the difference in treatment between one person and another
… as explained below, it refers specifically in its judgments to certain grounds, such as sex, nationality and
ethnic origin, which lead to its applying a strict standard of review. But in cases which are not concerned with
so-called “suspect” grounds, it often makes no reference to status, but proceeds directly to a consideration of
whether the persons in question are in relevantly similar situations, and whether the difference in treatment is
justified. As it stated in _Clift v United Kingdom, para 60, “the general purpose of article 14 is to ensure that_
where a state provides for rights falling within the ambit of the Convention which go beyond the minimum
guarantees set out therein, those supplementary rights are applied fairly and consistently to all those within its
jurisdiction unless a difference of treatment is objectively justified”. Consistently with that purpose, it added at
para 61 that “while … there may be circumstances in which it is not appropriate to categorise an impugned
difference of treatment as one made between groups of people, any exception to the protection offered by
article 14 of the Convention should be narrowly construed”. Accordingly, cases where the court has found the
“status” requirement not to be satisfied are few and far between.'

**[79] Status can therefore be acquired and limited in time (see Stott, a type of sentence of imprisonment), and may**
refer to the specific circumstances of a claimant, see the recent case of _R (on the application of SM) v Lord_
_Chancellor (Bail for Immigration Detainees intervening) [2021] EWHC 418 (Admin),_
**[*668]**

[[2021] 1 WLR 3815, [2021] All ER (D) 117 (Feb) where the distinction drawn was between immigration detainees in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6239-W103-GXFD-82RJ-00000-00&context=1519360)
prison compared with immigration detainees in removal centres.

**[80] The Claimant here postulates the two groups in analogous situations for comparison as:**

(i)   those who applied in time and achieved ILR by 1 September 2020; and on the other hand

(ii)   those who applied in time and were as at 1 September 2020 just as entitled to ILR but were
prevented by the withdrawal of the Priority Services from achieving it by then.


-----

648

**[81] Ms Weston QC suggested that the Claimant here could be compared to Ms Tigere who was described in that**
case:

'The reality is that even though she does not yet have ILR her established private life here means that … she
will almost inevitably secure ILR in due course. She is just as closely connected with and integrated into UK
society as her settled peers.'

The evidence in that case showed that it was unlikely that the overwhelming majority of people in her position would
emigrate, removing all the net benefit to the UK so her value to the UK was the same as if she was in the settled
class.

**[82] I accept this analysis and I agree, the value to the UK in these terms of the applicants in this case is**
indistinguishable from the value of those whose ILR applications were processed in time. The difference in
treatment appears to be unjustified, subject to arguments on a bright line rule or other reasons against. It appears to
exclude people who meet the criteria which the Regulations are designed to include. The application of the cut-off
date to this particular cohort does not reflect the objectives of the Regulation.

**[83] Importantly, the difference in treatment in Tigere was found to be inconsistent with the objectives behind the**
[Regulations which were expressed by Lord Hughes at para [53] of Tigere thus ([2016] 1 All ER 191, [2015] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)
3820):

'… the plain objectives of the government in promulgating the eligibility rules under consideration are: (a)
principally, to target the not inconsiderable subsidy represented by the student loan scheme (about 45% of £9
billion per annum) on those who are properly part of the community (in this case of England, for there are
separate and different rules for the other parts of the United Kingdom); (b) thereby to target the subsidy on
those who are likely to remain in England (or at least the United Kingdom) indefinitely, so that the general
public benefits of their tertiary education will enure to the country's advantage; (c) thereby to increase the
likelihood that, because the recipients of the loans will probably remain here, the public will receive repayment;
and (d) to provide a rule which is easy to understand and apply, and inexpensive to operate, so that the
minimum part of the available funds are taken up in administration costs.'

**[84] In Tigere the Court decided that the decision to exclude a person like Ms Tigere (by imposing the settlement**
rule that she could not fulfil), did not serve the objectives of the Regulations. The conclusion was expressed in this
way:

'[58] It follows that in respect of this cohort of people, the settlement rule, whilst no doubt intended to serve the
first three objectives set out in

**[*669]**

para [53], above, does not in fact do so. It goes further than is needed to serve those objectives. In
consequence, it excludes people who meet the criteria which those objectives are designed to include. It fails
to strike a fair balance between the state's interests and those of the cohort concerned. There is little sign in
the evidence lodged by the Department that this cohort was expressly considered. The adoption of the rule in
relation to this cohort creates discrimination which is outside the legitimate range of administrative decisions
available to the Secretary of State, and whether the test is correctly characterised as a decision “manifestly
without reasonable foundation” or as some less stringent criterion.'

**[85] I acknowledge Mr Glenister's observation about the claim of discrimination being apparently capable of**
articulation only as from 1 September 2020. This highlights the temporal aspects of this case: necessarily, given the
facts, the position is only seen clearly retrospectively. These are not features which defeat the Claimant's
arguments but in my judgment, rather, illustrate the nature of the claim. These aspects may be relevant to remedy,
but do not of themselves defeat the fact that it is possible to articulate with clarity the nature of the status in play.
The establishment of a status and the comparator group against whom detrimental treatment is claimed, can be
elusive, and it may be expressed in more than one way, as was recognised in Stott. However, that is also a feature


-----

648

of the series of cases set out above. Analysing the case by reference to the approach in Tigere reveals that in my
judgment the facts clearly fall within the art 14 framework.

**[86] In essence the Claimant and Interested Party are complaining about the fact that, although equally entitled,**
they are being treated differently from those who were not impeded from acquiring ILR as they were, and that is the
ground on which this difference in treatment is based. I accept that the analysis under art 14 is not straight forward.
This case has the hallmarks of a legitimate expectation that has been disappointed. What has arisen here may also
be expressed as a manifest unfairness but its remedy may in my judgment be expressed within what is now
recognised as the flexible context of art 14. The public law wrong of disabling a clearly identifiable cohort of
students from acquiring student finance by not adapting the Regulations so as to cater for the exigencies of the
Pandemic-driven withdrawal of access, may amount in my judgment to discrimination as claimed, and also plainly
meets the justice of the case.

**[87] It seems to me that Ms Weston's QC reference in oral submissions to the case of Thlimmenos v Greece (App**
[no 34369/97) (2000) 9 BHRC 12, (2000) 31 EHRR 411 provides an apt analogy here. In that case an inflexible rule](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3V5-00000-00&context=1519360)
existed such that a person convicted of a serious crime would be refused admission to the profession of chartered
accountant. The applicant had previously been convicted of failing to wear a military uniform. In this case, the crime
was committed because he was a conscientious objector, he refused for religious reasons to wear a uniform. The
applicant's crime did not imply a failure of integrity or morality rendering him unsuitable for the profession,
accordingly the court held that there existed no objective and reasonable justification for not treating the applicant
differently from other persons convicted of a felony seeking to enter the profession.
**[*670]**

**[88] By analogy here Ms Weston argues that there is no objective and reasonable justification for not treating the**
cohort of applicants caught by the sudden withdrawal of the Priority application process as complying with the
Regulations.

**[89] I accept that the Claimant is, by reference to Lord Hughes' description in Tigere (see citation from paras [54]**
and [58] above) within the class of persons sufficiently connected with this country to justify receipt of student
finance under the Regulations. Thus the absence of a solution to the issue which arose, namely withdrawal of the
ability to achieve student finance for the required course, does not serve the legislative purpose, but rather cuts
right across it.

**[90] In my judgment, even though the cases are not the same, the** _Tigere analysis may be applied here. In the_
present case a cohort of people will (if not remediated) be disentitled from pursuing their academic careers,
probably, or at least possibly for a considerable time, with no guarantee of being able to recommence their studies.
I do not accept, as was argued, that there is here no infringement of rights. At the date of withdrawal of the Super
Priority and Priority Services a closed class of would-be students became, on that withdrawal, disentitled from
acquiring student finance for their university courses.

**[91] I acknowledge, as submitted by Mr Glenister, that there is an element of retrospectivity to this conclusion. This**
is inherent in a case where the discrimination involves meeting a requirement described by reference to a set date
and is described retrospectively. However, this does not detract from the fact that properly analysed, there is here
unlawful discrimination. The question, therefore, is whether it can be justified as pursuing a legitimate aim and
satisfy the proportionality requirements, to which I turn.
_(iv) Does that difference or similarity in treatment have an objective and reasonable justification, in other words,_
_does it pursue a legitimate aim and do the means employed bear a reasonable relationship of proportionality to the_
_aims sought to be realised?_

**[92] In the context of education in the Supreme Court in Tigere Baroness Hale (with whom Lord Kerr agreed) said**
the following of the courts approach:

'[32] … As the appellant points out, education (unlike other social welfare benefits) is given special protection
by A2P1 and is a right constitutive of a democratic society Nevertheless we are concerned with the


-----

648

distribution of finite resources at some cost to the taxpayer, and the court must treat the judgments of the
Secretary of State, as primary decision-maker, with appropriate respect.'

**[93] She continued:**

'[33] … It is now well established in a series of cases at this level, beginning with Huang v Secretary of State
_for the Home Dept, Kashmiri v Secretary of State for the Home Dept_ _[2007] UKHL 11,_ _[[2007] 4 All ER 15,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PRJ-3D10-TWP1-61N4-00000-00&context=1519360)_

[2007] 2 AC 167, and continuing with R (on the application of Aguilar Quila) v Secretary of State for the Home
_[Dept, R (on the application of Bibi) v Secretary of State for the Home Dept [2011] UKSC 45, [2012] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M209-00000-00&context=1519360)_
_[1011, [2012] 1 AC 621, and Bank Mellat v HM Treasury (No 2)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M209-00000-00&context=1519360)_ _[[2013] UKSC 39, [2013] 4 All ER 533, [2014]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_
AC 700, that the test for justification is fourfold: (i) does the measure have a legitimate aim sufficient to justify
the limitation of a fundamental right; (ii) is the measure rationally connected to that aim; (iii)

**[*671]**

could a less intrusive measure have been used; and (iv) bearing in mind the severity of the consequences, the
importance of the aim and the extent to which the measure will contribute to that aim, has a fair balance been
struck between the rights of the individual and the interests of the community?'

**[94] I do not accept the submissions made in respect of the facts on behalf of the Secretary of State. True it is that**
the applicants knew there was an issue with their funding when they began their courses. They were, however,
between a rock and a hard place. They were entitled in my view to look to the statements elsewhere that the
Secretary of State did not intend that delays in immigration issues should affect students' academic positions. It is
true, these were statements directed at different cohorts of students, in different circumstances, and did not assure
the Claimant and Interested Party directly. Nonetheless, absent the sudden withdrawal of the Priority Services at
the Home Office, these individuals were entitled to have had confidence that, when their opportunity to apply for ILR
(and thus student funding) arose, they could swiftly receive the appropriate paperwork from the Home Office. It was
not unreasonable to hope and expect that the effects of the delay beyond their control would be mitigated in their
cases too, so they might continue and not lose their university places. But I do not base my assessment of
prejudice on these aspects of the facts.

**[95] I do not regard their starting their courses, hoping, and not unreasonably expecting, that some mitigation of**
their position would be available, to be culpable or relevant to the issues here. Nor do I regard the loss of a
particular course and the requirement to start another at another time as not engaging their A2P1 rights. The
evidence here shows that there is no guarantee these applicants would be able to carry on to another course at
another time given their personal circumstances. In any event, one course is not necessarily so easily
interchangeable with another as suggested by the Secretary of State in seeking to diminish the prejudice to these
applicants.

**[96] Mr Glenister submitted and I accept that certainty is a legitimate aim in this context. That proposition is well**
supported by the dicta of the Supreme Court. The fallacy of the argument here, however, is the suggestion that the
solution to the issue would lead to uncertainty. The class of those affected by a remedy is tightly confined and the
criteria for protection capable of being precisely drawn. In any event, given the passage of time, the class is now
closed. Mr Glenister also described the Defendant's stance as an area of 'policy' which the Court must be very wary
of entering. I disagree that the risk of so doing presents itself in this case. I am mindful of the warning from Lord
Reed in para [162] of SC where he said:

'In practice, challenges to legislation on the ground of discrimination have become increasingly common in the
United Kingdom. They are usually brought by campaigning organisations which lobbied unsuccessfully against
the measure when it was being considered in Parliament, and then act as solicitors for persons affected by the
legislation, or otherwise support legal challenges brought in their names, as a means of continuing their
campaign. The favoured ground of challenge is usually art 14, because it is so easy to establish differential
treatment of some category of persons, especially if the concept of indirect discrimination is

**[*672]**


-----

648

given a wide scope. Since the principle of proportionality confers on the courts a very broad discretionary
power, such cases present a risk of undue interference by the courts in the sphere of political choices.'

**[97] That is clearly not this case. The risk of treading inappropriately into an area of legislative discretion is not**
manifested by requiring the Defendant to mitigate the effects of the discriminatory treatment under the secondary
legislation of the Regulations.

**[98] Mr Glenister argued that the nature of any remedy allowing the Claimant and Interested Party to benefit under**
the Regulations would be quite disproportionate to the problem. He postulated a general remedy that would have
far-reaching effect on a huge cohort of students. I do not believe that to be a corollary of a remedy in this case.

**[99] Ms Weston QC told the Court that the researches of those instructing her suggested that these two parties**
were the only people within the particular factual matrix of this case. That aside, I reject the suggestion that there
would be so wide a scope of any operative amendment to the Regulations that it would be disproportionate to
remedy the wrong in these cases.

**[100] The evidence in this case is that the Priority Schemes were withdrawn with only six days' notice which means**
there is an identifiable cohort of people for whom it was immediately impossible to obtain student finance for the
September 2020 year if the Defendant insisted upon evidence of settled status by 1 September 2020.

**[101] This can be notionally tested. The term beginning 1 September 2020 could, with the availability of the Priority**
and Super Priority Schemes, have accommodated funded students who achieved their ILR the day before each
course was due to start. Accordingly, it was feasible on payment of a fee, to achieve ILR in a window that closed at
the end of August. The last date on which an application under the Super Priority 24-hour Scheme could have been
made was probably Friday, 28 August, to ensure turnaround by Monday, 31 August, achieving ILR by 1 September
2020. So (merely by way of example), a scheme that involved changing the relevant date on which evidence of ILR
status would be acceptable, together perhaps with an indication that those who commenced their courses ran the
risk of having to foot their student fees' bill if they failed in their ILR applications, could in my judgment easily have
been developed. Payment of the relevant fee could even have been part of that scheme if thought appropriate. The
fact that some evidence would have been required is not of itself evidence of disproportion. Proof of status is
required in any event under the Regulations and payment of a fee, is (even to a different branch of government) not
problematic. To the extent that such a scheme might perhaps include those who would not otherwise have used the
Priority system, that in my judgment is neither here nor there: such scheme will not attract those without a course
or, perhaps, prepared to pay the fee, or able to run the risk of not achieving ILR in due course. The development of
the scheme is not this court's function, but it is not theoretically impossible nor, as argued, would such scheme
prove disproportionate.

**[102] In any event, the issue here is whether the discrimination against the Claimant and the Interested Party can**
be justified and is proportionate. In my view it cannot and is not. To exclude these candidates on these facts cuts
across the purpose of the Regulations and defeats the aims recognised in Tigere.

**[103] The essence of the Claimant's claim is that the Defendant did not mitigate the severe effect of withdrawal of**
the Priority Services in the limited
**[*673]**

way required to protect this group, affected by COVID strictures, who were, as has subsequently been shown, as
entitled to student finance as the comparator group, unaffected by the Covid Priority Scheme changes. The loss of
finance for the whole of the degree course if the 1 September date were missed is in my judgment of very
significant weight.

**[104] In terms of proportionality or other justification, it is not relevant (or accurate) to describe these applicants as**
'no less deserving' as another, unparticularised cohort postulated on behalf of the Defendant who may have
decided to cut their losses and not apply that year. There is no inherent unfairness: these particular applicants
applied to the Court, on their own facts and are entitled to a remedy, if the court so finds.


-----

648

**[105] As indicated above, Mr Glenister's concentration on the time at which the discrimination is argued to begin is**
understandable and highlights the character of the problem: what has happened is now in the past. What is
required at this stage is a retrospective remedy. That does not in my judgment mean there is no case of
discrimination here, nor that a failure to accommodate the 'lost cohort', probably only these two people, cannot be
remedied. This is not equivalent to the case of Docherty _[[2017] 4 All ER 263, [2017] 1 WLR 181or Minter v UK (App](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)_
no 62964/14) (2017) 65 EHRR SE51 which were cases involving failed applications under art 14 on the basis of a
change in sentencing legislation. The differential treatment on which the applicants there relied flowed exclusively
from changes in the legislative sentencing regime, which were prospective. It is well-established that differential
treatment caused purely by the commencement of a new legislative regime does not constitute discrimination.
Here, there is a distinct ground of discrimination.

**[106] I disagree with the Secretary of State that this impediment to the applicants amounts merely to 'slight delay in**
obtaining settled status'. It is plain from the facts deposed to by the Claimant and the Interested Party, that it is far
from clear that either of these people could afford to continue without student finance, nor that their places would
have been open to them either, as appears to be suggested, one term late, or one year late. I accept, as Mr
Glenister submits, both knew that they were technically not entitled to student finance at the time of the courses
started, but in the circumstances of this case, that is not determinative.

**[107] However, importantly the Court is asked only to give relief to these claimants and in my judgment there is no**
unfairness in affording relief to those who have claimed, even if, only those non-claimants strictly within the same
description, are then afforded relief. The Secretary of State, somewhat in terrorem, argued it would be necessary to
ascertain in each individual case, on the assumption that there were many more, evidence as to whether, had it not
been for the withdrawal of the service, the student would have used the Priority System, and evidence whether the
delays were caused by the withdrawal of the priority services. I disagree. This is not borne out by the evidence or
the logic of the case.

**[108] At the end of the ministerial submission this was said:**

'We have considered whether we can mitigate against this happening again in the future without the need to
make any changes in the Regulations. Should the super priority service be withdrawn again, we intend to
clearly signpost students to the Gov.uk website to manage their expectations and allow them plenty of time to
apply for their ILR. We have

**[*674]**

also asked whether the HMO could consider expediting applications for settlement from individuals who can
show they have outstanding student finance application [sic] and the grant of ILR is key to their eligibility.'

**[109] This reflects the Defendant's understandable concern about the integrity of the bright line ILR requirement in**
the Regulations. Mr Glenister in his submissions emphasised the difficulty with any importation of a discretion
requiring the Secretary of State to decide between cases and on competing evidence. He drew the court's attention
to those passages in the authorities which reflect the desirability of a bright line rule, indeed Lord Hughes said as
[much in the present context in the Tigere case ([2016] 1 All ER 191, [2015] 1 WLR 3820). I accept the importance](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)
of a bright line rule concerning qualification for the scheme. A remedy in this case does not impugn that, nor will the
Defendant necessarily be required to exercise a discretion, compassionate or otherwise, in the circumstances of
this case: the relevant factors for inclusion are all ascertainable. The vice in the present case is the disqualification
by the date contained in the Regulations. It is now not in issue that, but for the date, both Claimants here qualify. It
is not difficult to construct a scheme which catches those who made an application which, under the usual course of
the suspended scheme, would have acquired ILR. Those persons can, now in retrospect, be shown to have done
so successfully.

**[110] I do not however purport to draft or influence the required working out of the remedy which the parties may**
wish to have considered at a short consequentials hearing in the New Year.
**Summary of Conclusion**


-----

648

**[111] The Claimants have succeeded in their Claim.**

**[112] The Defendant unlawfully discriminated against the Claimant and the Interested Party by treating them less**
favourably than those who were not caught out by the sudden withdrawal of the Super Priority Scheme.

**[113] The Defendant did not mitigate the severe effect of withdrawal of the Priority Services in the limited way**
required to protect this group, who were, as has subsequently been shown, as entitled to student finance as the
comparator group, unaffected by the Covid Priority Scheme. It is contrary to the objectives of the Regulations for
there to be no mitigation of the delay in process that was forced upon the applicants in this case.

**[114] In these circumstances the Court will remedy the unlawful discrimination and grant a declaration and a**
quashing Order as asked by the Claimant and Interested Party.

Claim allowed.

Wendy Herring Barrister.

**End of Document**


-----

