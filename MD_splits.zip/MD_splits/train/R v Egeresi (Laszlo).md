# R v Egeresi (Laszlo) [2019] EWCA Crim 675

CA, CRIMINAL DIVISION

201801471

Hamblen LJ, Edis J, HHJ Leonard

Friday, 29 March 2019

29/03/2019

(Draft approved)

LORD JUSTICE HAMBLEN:

Introduction

1. On 9 March 2018, in the Crown Court at Kingston before His Honour Judge Greenwood, the appellants, Laszlo
Egeresi and Gabor Olah, were convicted on counts of arranging or facilitating the travel of another for exploitation,
contrary to section 2(1) of the Modern Slavery Act 2015 (“MSA”).

2. Both appellants were convicted on count 2 by a 10 to 1 majority and count 4 unanimously. Egeresi was also
convicted on count 3 by a 10 to 1 majority but a not guilty verdict was returned on count 1, which charged Egeresi
with a similar offence under earlier legislation.

3. Egeresi was sentenced to seven‑and‑a‑half years' imprisonment concurrent on counts 2 and 4 and 4 years

concurrent on count 3. Olah was sentenced to 6 years' imprisonment concurrent on counts 2 and 4.

4. They appeal against conviction and sentence with leave of the single judge.

The Outline Facts

5. The prosecution case was that the appellant Egeresi, subsequently assisted by Olah, were engaged in bringing
a number of fellow Hungarian countrymen into the UK, or moving them within the UK, with a view to exploiting
them.  The counts on the indictment spanned the period 31 July 2015 to 24 June 2017. It was alleged that they
deceived Arnold Egeresi ("AE") (count 2) and Tibor Szelezsan ("TS") (count 4) into travelling to this country on the

promise of well‑paid work and a better standard of living. Upon arrival they were given employment but most of

their wages were taken from them and they were forced to live on next to nothing in dirty, overcrowded conditions.
They were also forced to take out a loan or an overdraft and told that the debt was increasing due to interest. If they
complained or no payments were made, they were threatened or assaulted.

6. In the case of Daniel Varga ("DV") (count 3), Egeresi deceived him by taking out a loan in his name. Egeresi was
the organiser and Olah played his part by assisting him as part of a joint enterprise.

7. The defence case for each appellant was that there was no intended or actual exploitation of anyone and that
they were not in business together. In the case of Egeresi, it was said that it was AE's idea to take out the loan in
the name of DV.  The appellant did not want to become involved but he was persuaded to do so by AE.


-----

8. The issue for the jury was whether the appellants had acted together in bringing people to this country in order to
exploit them.

The Evidence at Trial

9. For the prosecution, evidence was given by AE, who said that he came to the UK in about March 2015. He was

given Egeresi's name as someone who could help him find employment. They are not related ‑ it is a coincidence

that they share they same surname. Egeresi organised a national insurance number for him. AE began working at
the Castle Public House and earned about £350 per week, £300 of which he gave to Egeresi. In the summer of
2015 he went back to Hungary and Egeresi asked if he was returning and told him that he owed him money. On his
return AE moved to Telford and Egeresi threatened him and said he knew people in that area and would drive there
with him if he did not clear his debt (count 2). On one occasion he was beaten up by Egeresi and Olah; it was
because he did not want to help them to find other people. Olah punched him so hard that he sustained a broken
nose. He last left the UK in June 2017, a few days after Egeresi was arrested.

10. DV gave evidence that he came to this country in 2016. He was given the name of Egeresi who helped him
with travel arrangements, accommodation and finding a job. He paid his rent upfront. He treated him properly, not
as a slave. He also helped him to open a bank account. At one point AE took a photo of his bank card as he said
Egeresi wanted to check whether there was any trouble with it. DV, who spoke very little English, then discovered
that he had been deceived into obtaining £5,000 from Amigo Loans. He spoke to Egeresi, who always
accompanied him to bank, who told him not to worry as they would pay it back (count 3). He remembered an
incident in about May 2017 when there was a fight in the kitchen between Egeresi, Olah and AE as a result of which
AE received an injury to his nose.

11. TS said that he was brought into the United Kingdom by Tomasz Begla. He knew Olah in Hungary and looked
on him as a friend or brother. He only met Egeresi when he arrived in this country. Egeresi and Olah promised to
arrange all the necessary paperwork. Olah was living in the same house as TS and his role was to collect money
from everyone. TS was given employment as a kitchen porter at the Bear Public House. When he had his first day
off he found out about Egeresi's existence and that he was the boss. The two of them kept him under terror
although almost everything was organised by Olah. They helped him to open a bank account. They had his card
and PIN number. He had to give them 90% of his wages every week plus his overdraft (£1,500) which they
recorded in a book. They used demeaning and threatening language and Olah was the more intimidating of the two
(count 4). Two people were living in each room and everyone was paying £250 ahead and a new person would
arrive every two weeks. He was then moved to a property in Hersham where he shared a room with DV. He
worked from 10.00 am until midnight. He was fed up and eventually decided to leave without notice. He asked a
manager to help with accommodation and then moved to Aylesbury. The manager subsequently, with TS's
agreement, contacted the police. He had never applied for a loan from Amigo but may have acted as a guarantor.
His greatest fear was having to go back to Hungary. It was put to him that that was because there were warrants
out for his arrest in Hungary and he had convictions for dishonesty and he said he did not think that was relevant or
meant that he was lying.

12. Bradley Marchant said that he was the general manager of the Bear Public House. He knew TS, the kitchen
porter. He was brilliant at his job and very cheerful. He met Olah and Egeresi several times to ensure TS's
paperwork was in order. On one occasion TS appeared upset and was very agitated. He spoke about his
accommodation and the amount of money he had to pay. Marchant told him that matters would only be resolved if
he went to the police. He then helped him to find employment elsewhere. He spoke to Egeresi or Olah who asked
where TS had gone and he said he had no idea. They said he had stolen money and a laptop and wanted to know
where he was.

13. In addition, the prosecution relied upon the evidence of Lucia Szuroka, the partner of AE, Krisztina Toth, the
partner of DV and a handwriting expert.

14. The appellants were arrested on 23 June 2017. A letter from Amigo Loans addressed to DV was found in
Olah's bedroom. They made "no comment" in interview and each of them handed over a prepared statement.


-----

15. For the defence, Egeresi gave evidence. He said that he came to the UK alone in May 2011. Olah was never
his business partner. Both Olah and AE are distant cousins. He himself ran a business which brought people into
the UK but it was only for family, friends and friends of friends. He made minimal profit. Occasionally he would
charge a fee which would be agreed and that would be approximately £2,000. However, there would be no charge
at all for members of his family. In total he helped 15 people to come to the UK but did not threaten or exploit
anyone.

16. He was willing to help AE as they are related. He offered to support him financially. However, he was a
gambler and rarely made repayments. He continued to help AE because it was all about trust and family ties. He
had nothing to do with TS coming to the UK. He did lend him £1,400 because he knew he wanted money to send it
to his mother. He charged no interest and did not take any of his wages. DV was a friend. He did not persuade
him to have an overdraft or deliberately saddle him with liability for the Amigo loan. It was AE's idea. He admitted
that he pretended to Amigo to be DV, a decision which he later regretted. Subsequently he helped with the
repayments on the loan as DV had shown him gratitude.

17. Olah gave evidence. He said he had arrived in this country in 2014. Egeresi helped him with everything. When
he had been here for some time, and his English had improved, he asked AE and TS to help them. It was a friendly
favour and he did not exploit or threaten anyone. He also helped other Hungarians but was not in business with
anyone.

The appeal against conviction

18. The sole ground of appeal is that undue pressure was put on the jury to return verdicts by the end of Friday 9
March 2018.  The allegation of undue pressure arises against the following factual background.

19. On 5 February 2018, shortly after the jury had been empanelled, two jurors informed the judge that they could

not sit beyond 9 March 2018 as they had each pre‑booked one week holidays thereafter. At that stage it was not

considered to be an issue.

20. On 12 February 2018, the judge discharged one of the jurors who had indicated that he would not be able to
judge the case on the evidence and had conducted independent research on one aspect of the case.

21. On 26 February 2018, one of the jurors sent a note stating that she was feeling emotionally and financially

anxious about missing her flight for her pre‑booked holiday. Having discussed the matter with counsel, the judge

said that he would tell her she would catch that flight even if the case had not been concluded. He informed the jury
to that effect stating as follows:

"Members of the jury, one of your number mentioned right at the very outset of this case that she had a holiday
booked on the 10th, and that that juror is understandably anxious about, in particular, what would happen if this
case did run beyond the 9th.  The answer is very straightforward, and I want to emphasise that you can and should
stop worrying about it, because I have the power to discharge a juror literally at any stage, and I undertake to
discharge you if that happened, so you will be on this trip, you can stop worrying about it.

[JUROR]: Thank you, your Honour.

[JUDGE]: All right. It may be I will now receive other notes from other worried people, but I am determined to deal
with it one at a time. You have expressed understandable anxiety about it. Please do not worry. You are a juror:
you must not do this difficult task whilst worrying. You will be discharged. You will be on that trip whatever
happens."

22. This resulted in a second note from a second juror about an hour later who sought a similar reassurance.  The
judge gave the second juror the same promise stating as follows:

"I just want to deal with the other note that I received. One of your number wrote me a note to the effect that he is
in exactly the same position as the juror to whom I gave the assurances that she will be discharged if we are still


-----

here on the 9th or at the end of the 9th. He points out he is in exactly the same position and therefore ought to be
treated the same. Well, I agree. You will be treated in precisely the same way; you are in the same position. It is
possible. We do not expect these difficulties to arise, and we are hoping that they will never arise, however it is
possible for jury members to reduce; as you have seen we are continuing with 11 now. It is possible to go down to
10. It is possible to go lower to that nine as well, if one has to. I do not want anyone to continue working with that
kind of anxiety. If there is that kind of difficulty and necessity arises, you will be discharged."

23. On 27 February 2018, the judge received various jury notes including one which asked:

"Roughly how long will we need to deliberate?"

24. The judge also had a note from one of the jurors saying that he had a course booked on Monday 12 March.
The note said:

"I'm registered at a conference in Oxford for work costing £500 which I've paid for and needs to be reimbursed.
Also have two nights booked at a hotel. The conference starts on the 12th of March and ends on the 15th. No
significant personal hardship to myself, but I feel that I have an obligation to my employer to let them know, at least
an indication of percentage change, I will not be able to attend so they can make efforts to get a refund or a
replacement for my seat/room. I've not raised this to date as it was my understanding that the trial was not
predicted to last beyond the 2nd of March, but I would require a percentage chance absence if possible."

25. After discussion with counsel the judge addressed the jury as follows in relation to these notes:

"'Roughly how long will we need to deliberate?'

Well, that is a no go area for me because there must, as I told you earlier in the trial, there must never be any
pressure on jurors to speed up deliberations. Deliberations are entirely in the hands of the jury and they take as
long as they take and these days, they separate overnight. In the old days, there used to be here until late in the
night sometimes if they could not agree on a verdict. That does not happen any more. We have the normal court
day, you separate, you carry on the following day and it takes as long as the jury take. It is entirely in their hands.
That is one that I cannot answer at all, so I will leave that with just the one point that I did make to you is that there
must be no pressure of time. There must never be any pressure of time in respect of deliberations.

Then, one of your number, I think I know who it is because I was told by the usher, who has a, some sort of course,
a conference booked for Monday the 12th. That is an awkward date because I know the 12th is the Monday
following the Friday when other jurors go on holiday. They go on holiday on Saturday and the Sunday and this is
the Monday following and your question is whether you have to warn your employers that you may not be able to
attend. My only opinion is you do have to warn them because I do not know how long you will be deliberating, so
you will have to warn them if deliberations take long, you will not be able to go on this conference. Do you want to
do that right away because I will give you that opportunity."

26. The judge then continued:

"Well, I will keep repeating as I must, sitting where I do, that there must be no pressure of time when you are
deliberating and I have repeated that often enough for you to see that this is my job. I must tell you that; no
pressure of time. You have to consider your verdicts conscientiously and time must not be a factor. For that
reason, I think you ought to warn your employers because if the trial goes beyond Friday and I have said already,
we can go down to nine jurors in that event and will have to. We cannot go lower than nine and so, there is that
possibility you will still be out deliberating and you will not be able to attend the conference. That is as much as I
can say. I am sorry if it is disappointing time and again, but I am only the messenger."

27. It is apparent from those passages, as is common ground, that pressure of time had been a recurring theme
and the judge had stated that there was no pressure on a number of occasions.

28. The trial then continued and the jury retired with 11 jurors. The jury started their deliberations at 10.25am on 8
March 2018 Just after the jury retired there was the following exchange with counsel:


-----

"... I know Your Honour had already said to the jury... Your Honour did not saying this morning, but had already said
in the course of the trial a number of times that when it comes to this stage there's no pressure of time on them at
all.

[JUDGE]: I have said it before.

[COUNSEL]: You have said it before, and I am sure they have very much in mind, because it has been repeated on
a number of occasions when they themselves have asked 'How long might we be in retirement?', and Your Honour
has emphasised, as long as it takes them to reach verdicts.

[JUDGE]: Yes, I might have mentioned it again. To be frank, I was anxious to get them started, because we had a
delay, but I did make very, very clear, and, what is more, I have already said to them that in relation to the jurors
who have to leave at the weekend if they are still in retirement those jurors will be discharged and they will continue
thereafter with nine, so they are well aware of this situation."

29. The jury were sent home at 4.40pm that day. They restarted their deliberations the next day at 09.43am. At
2.30 pm they returned unanimous verdicts of guilty on both appellants in respect of count 4. They were then given
the majority verdict direction. At 3.15 pm the jury returned majority verdicts of not guilty on count 1, guilty on count
2 (10 to 1) for both appellants and guilty on count 3 (10 to 1).

30. It is against that factual background that it is submitted on behalf of the appellants that the convictions on all
counts are unsafe. It is said that it can be inferred from the notes reflecting the anxiety of the two jurors of the trial
continuing beyond Friday 9 March 2018, that undue pressure was applied on the jury to return verdicts by then. It is
contended that the two jurors, and the other nine jurors for that matter, would have felt under pressure to return all

verdicts by that date. The jurors had invested some four‑and‑a‑half weeks in the trial and there would have been an

understandable expectation that all 11 of them would be involved in returning all verdicts.

31. In those circumstances, it is submitted that there was a real danger that the jury rushed their verdicts or, at the
very least, of a perception that this was the case, in order to ensure that all verdicts were returned while all 11 of
them were still members of the jury.

32. It is accepted that the judge had given directions that the jury should have felt under no pressure on a number
of occasions, but it is pointed out that the last such direction was given on 27 February 2018 and it had not been

repeated at the time of the summing‑up or when the jury were being sent out to consider their verdicts.

33. It is submitted that further directions should have been given at that stage. Further or alternatively, it is
submitted that the judge should have adjourned all or part of the jury deliberations by 1 week, by which time the two
jurors would have returned from their respective holidays. This had been suggested during discussions in court on
26 February 2018 and would have avoided any undue pressure of time.

34. In all the circumstances it is submitted that the convictions are therefore unsafe.

35. It is clear from the citations from the transcript, set out above, that the jury were told, on a number of occasions
by the judge, that they were under no pressure of time. It may have been preferable if the judge had repeated that
before the jury retired to consider their verdicts, but this had been an issue raised during the course of the trial and
the judge had repeatedly made the position clear. In particular, he made this point very plainly in responding to the
juror's questions on 27 February 2018.

36. In any event, it is apparent that the jury were not in fact under any pressure of time. The judge had made it
clear to the jury that if their deliberations were not concluded by the close of business on 9 March 2018, the law
permitted the trial to continue with nine jurors, and that that is what would happen. There was therefore no need for
the two jurors who were to go on holiday to feel under pressure. As they knew, if verdicts were not reached by
close of business on 9 March 2018, deliberations would go on without them. Equally, there was no need for the
remaining jurors to feel under pressure as they also knew that they could continue their deliberations, if it transpired
that the two jurors had to be discharged


-----

37. In those circumstances there can have been no expectation that all 11 of them would necessarily be involved in
the deliberations. The judge had made the position quite clear as to what would happen in relation to the two jurors
should deliberations not be completed by close of business on 9 March 2018.

38. In the event, the first verdicts were returned at a time when there were over 2 hours left in the standard court
day. The jury had clearly considered the matters carefully and did not simply rush to convict but reached mixed
verdicts, convicting on some counts but not on others. The verdicts are explicable on evidential grounds and this
reflects a jury considering the evidence and reaching verdicts accordingly.

39. In our judgment, where proper regard is had to the history of the proceedings and the various interchanges
between the judge and jurors, and the various warnings, statements and directions he had given during the course
of the trial, there is no substance in the suggestion that these were anything other than properly returned verdicts
reached by a jury who were under no undue pressure.

40. The appeal against conviction must accordingly be dismissed.

The appeal against sentence

41. Egeresi is now aged 38, having been born in December 1980. He is of previous good character. Olah is aged
26, having been born in March 1992. He has no convictions in the UK but has convictions in Hungary for low value
theft, public order offences and a false document offence.

42. In his sentencing remarks the judge said that the appellants were each engaged in an enterprise which was
designed to exploit people coming to the UK from Hungary. They systematically exploited vulnerable individuals
who spoke little English and once in this country they were effectively trapped. The victims suffered psychological
harm and were threatened over a prolonged period.

43. The judge found that it was very much a joint enterprise. Both playing a leading role, although Egeresi was
senior of two and the overall boss. It was carried out for financial greed and resulted in some £240,000 being paid
into Egeresi's account.

44. The judge observed that these offences now carried a maximum sentence of life imprisonment. He said he
was greatly assisted by the authority of R v Zielinski [2017] EWCA Crim 758, which gave some guidance as to the
level of sentences which should be imposed, but he would not embark on a detailed comparison between the
features of the two cases. The judgment in that case made it clear what the range of sentencing had to be in a
case such as this. He would impose a higher sentence on Egeresi to reflect the difference in seniority in terms of

the more leading role he played.  The sentence was seven‑and‑a‑half years in respect of Egeresi and 6 years in

respect of Olah. Since there had been no indication of remorse whatsoever there could be no discount. In addition
there would be slavery and trafficking prevention orders.

45. The grounds of appeal are that the sentences imposed are wrong in principle and manifestly excessive and
that they are based on a misreading of the decision in Zielinski. In particular it is submitted that:

(i) All parties were agreed that the case was very similar to Zielinski where the appellant's sentences for two

offences contrary to section 2(1) MSA were increased from 12 months to two‑and‑a‑half years' imprisonment. For

an offence contrary to section 1 MSA, the sentence was increased from 4 years to 7 years' imprisonment.

(ii) The judge erred in using the sentences in Zielinski to justify the sentences imposed in the instant case.  The
Court of Appeal made it clear in that case that the sentence of 7 years was for the offence contrary to section 1
MSA and the concurrent terms were for the offences contrary to section 2 MSA.

(iii) The Court of Appeal made a distinction between the two types of offences. The judge in the instant case failed
to make such a distinction and therefore imposed a sentence which was wrong in principle.


-----

(iv) Whilst there are aspects of the instant case which are more serious than the factual scenario in Zielinski, such
as exposure to financial liability through the arrangements of overdrafts and loans, there are aspects of Zielinski
which are more serious than this case, including the greater frequency of physical violence and retention of bank
and ID cards.

(v) The appellant in Zielinski benefited financially to the same extents as the leading offender, whereas in this case
Egeresi benefited financially to a far greater extent than Olah.

(vi) Even if the culpability of the appellant in Zielinski is considered equivalent to that the appellants, a sentence of

two‑and‑a‑half years would have been appropriate.

46. In Zielinski the defendant was convicted of two counts of arranging or facilitating the travel of another for
exploitation, contrary to section 2(1) MSA (counts 1 and 2) and a count of conspiring with others to require another
to perform forced or compulsory labour, contrary to section MSA (count 4). He was sentenced by the trial judge to
concurrent terms of 12 months' imprisonment on each of counts 1 and 2 and to 4 years' imprisonment on count 4,
again to run concurrently.

47. The matter was referred to the Court of Appeal by the Attorney General on the grounds the sentences were
unduly lenient.  The court gave the following overview of the facts at paragraphs 4 to 5:

"4. In overview, the offender and members of his family had conspired together over a period of nine months to trick

Polish nationals to travel to the United Kingdom on the promise of well‑paid work. The evidence indicated that those

Polish nationals were, in effect, desperate, unemployed, and badly needed money. They also did not speak
English.

5. Once in this country, they were put to work in what might be described as regular employment, but most of their
wages were then taken away from them by the offender and members of his family. They were forced to live in
appalling conditions and they were threatened and on occasion actually assaulted in order to force them to comply
with the demands of the conspirators."

48. There were six complainants.

49. In considering the Reference the court observed, at paragraph 18, that there is growing concern of offending of
this kind and there is a need for deterrence. The court cited the following passage from the judgment of Lord Judge

LCJ in at Attorney‑General's Reference Nos 2, 3, 4 and 5 of 2013 (R v Williams Connors and Ors) [2013] EWCA

_Crim 324; [2013] 2 Cr App R(S) 71, a case decided under the predecessor legislation to MSA, but comments which_
the court said remained relevant for the purposes of the modern legislation:

"10. Sentences in this class of case must make clear, not merely that the statutory minimum wage should not be
undermined, but much more important, that every vulnerable victim of exploitation will be protected by the criminal
law, and they must also emphasise that there is no victim, so vulnerable to exploitation, that he or she somehow
becomes invisible or unknown to or somehow beyond the protection of the law. Exploitation of fellow human beings
in any of the ways criminalised by the legislation represents deliberate degrading of a fellow human being or human
beings. It is far from straight forward for them even to complain about the way they are being treated, let alone to
report their plight to the authorities so that the offenders might be brought to justice. Therefore when they are,
substantial sentences are required, reflective, of course, of the distinctions between enslavement, serfdom, and
forced labour, but realistically addressing the criminality of the defendants."

50. The following factors were identified as being of particular relevance to the gravity of the offending in Zielinski:

(i) The level of organisation and planning behind the scheme

(ii) The deception involved from outset of persuading victim to travel to the UK.

(iii) The relatively large number of victims involved


-----

(iv) The duration of assistance of the conspiracy.

(v) The poor standard of accommodation provided.

(vi) The methods used to control the victims.

(vii) The level of vulnerability of the victims.

(viii) The level of harm caused by the offending and the lasting effect on those victims from whom the court had
heard and

(ix) The offending was for financial gain.

51. The following mitigating factors were identified:

(i) The fact that the defendant was effectively of good character.

(ii) He was relatively young and

(iii) He was not the leader of the conspiracy by "an able and willing lieutenant."

52. Having observed that all these cases depend on their own particular facts the court's conclusion was as
follows:

"27... We are in no doubt that a sentence of four years' imprisonment after a trial for the totality of this offending
was much too low and should be significantly increased to reflect the gravity of all that occurred, which we have
already recounted.

28. In our view, the very least sentence appropriate to this case, given its facts and circumstances, is one totalling
seven years' imprisonment. In our view, that is to be achieved by increasing the sentence on counts 1 and 2 to
sentences of two and a half years' imprisonment, and the sentence on count 4 to one of seven years' imprisonment,
all sentences to run concurrently."

53. It is to be noted that the court decided what the appropriate sentence was for the totality of the offending and,
having decided that was 7 years' imprisonment, achieved that by passing a 7 year sentence on count 4, with

concurrent sentences of two‑and‑a‑half years on counts 1 and 2. It did not distinguish between the seriousness of

the offending in relation to individual counts, but passed an overall sentence that reflected totality of offending and
chose to do that by passing a longer sentence on count 7.

54. In those circumstances, we did not consider that any particular guidance is to be derived from the length of the
concurrent sentences imposed on counts 1 and 2, for both of which the maximum sentence is life imprisonment.
On the other hand, it is to be noted that the court regarded the section 1 count as being the most serious offence
and that the court's view of the gravity of the overall offending reflected this additional count involving, as it does,
forced labour.

55. As in Zielinski, the question for the court in this case is whether the sentences imposed were manifestly
excessive having regard to the seriousness of the totality of the offending.

56. Having regard to the factors considered of most relevance in Zielinski, the position in the present case is as
follows:

(i) The level of organisation and planning behind the scheme - There was a significant degree of planning as
evidenced by the use of adverts, the arrangement of transport and accommodation of national insurance interviews
and bank accounts and the finding of work.

(ii) The deception involved - In this case, there was the false promise of work on favourable terms to victims before
travel and false information given to victims about the fees which would be charged


-----

(iii) The number of victims involved - There were three specific victims: AE under count 1; DV under count 3
(involving Egeresi only) and TS under count 3.

(iv) The duration and persistence of the conspiracy. The conspiracy spanned around 15 months.

(v) The standard of accommodation provided - There were victims' complaints about poor accommodation.

(vi) The methods used to control victims - Bank accounts were established by the offenders in the victims' names
and money withdrawn from those accounts. A large proportion of wages earned by the victim was taken from each
week or month. The taking of the wages was enforced by threats of violence and, on occasion, actual violence.

Debts were built up through demands for rent and third‑party loans were used to increase the economic pressure

on the victims.

(vii) The level of vulnerability of the victims. The victims were economically vulnerable, spoke little English and, as
the judge observed, once in the UK they were effectively trapped. They were financially exposed to third parties.

(viii) The level of harm caused by the offending and the lasting effect on those victims from whom the court had
heard - AE was physically injured. All the victims are likely to have suffered psychological harm. The judge found
that TS was bullied and threatened over a prolonged period.

(ix) Whether the offending was for financial gain. The offending was carried out for gain and the judge found that
the exploitation produced very large profits and referred to £240,000 found in Egeresi's account.

57. In the present case it may be said that the economic exploitation went further than Zielinski. Here, in addition
to the confiscation of the victims' wages, victims were left with liability to third parties for overdrafts and loans which
had benefited the appellants. Both Egeresi and Olah left TS with a liability for a significant overdraft. Similarly DV
was left with a burden of a loan taken out in his name.

58. In Zielinski, the defendant, was not a leader of the offending, but was a willing lieutenant. In this case the judge
found that both Egeresi and Olah had a leading role and Egeresi was the more senior of the two.

59. On the other hand, it is right to point out that there was considerably more physical exploitation in Zielinski and
there are aspects of Zielinski which are more serious, such as the greater frequency of physical violence and the
retention of bank and ID cards. In addition there are the important points that there were many more victims and
that the offending included a section 1 offence.

60. Standing back and viewing the seriousness of the totality of the offending, whilst all cases depend on their own
facts, and whilst the judge was entitled to consider that the Zielinski case provided guidance, in our judgment, he
should have recognised that the totality of the offending was more serious in that case and that the appropriate
level of sentence was somewhat lower in this case. In this connection we note that at trial the prosecution
suggested a starting point of 4 years on the bases of Zielinski. We consider that to be realistic in the circumstances
of this case. Based on a starting point of around 4 years, we consider that the sentences imposed in this case were
manifestly excessive.

61. As the judge recognised, the sentence for Egeresi should be higher than that for Olah, to reflect the fact that he
had a more senior role, of his financial gain from the offending and the additional count on which he was convicted.

62. In our judgment, the appropriate sentences in this case are 5 years' imprisonment for Egeresi and 4 years'
imprisonment for Olah. To that extent this appeal against sentence is allowed. We accordingly quash the sentence

of seven‑and‑a‑half years on Egeresi and 6 years' imprisonment on Olah and on counts 2 and 4 substitute

sentences of 5 years and 4 years respectively.

63. MR McLOUGHLIN: My Lord, can I just enquire. Plainly the longer sentences in respects of counts 2 and 4;
count 3, Egeresi only, he was given a sentence of 4 years?


-----

64. LORD JUSTICE HAMBLEN: That can remain as is.  The sentences on counts 2 and 4 have been changed.

65. MR McLOUGHLIN: I am grateful.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

