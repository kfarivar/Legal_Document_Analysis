# R v Capitao [2022] EWCA Crim 893

Court of Appeal, Criminal Division

Andrews LJ, Cutts J, and  HHJ Bate

21 June 2022Judgment

MR A FRYMANN appeared on behalf of the Applicant Basky Capitao

MR P SPREADBOROUGH appeared on behalf of the Applicant Jemy Capitao

MISS S MEEK appeared on behalf of the Applicant Langrish

_________

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

1. MRS JUSTICE CUTTS: This is a renewed application for leave to appeal sentence brought by all three
applicants following refusal by the single judge.

2. The three applicants were jointly charged with two offences of conspiracy to supply class A drugs. One
concerned the supply of cocaine and the other the supply of heroin, contrary to section 1(1) of the Criminal
Law Act 1977 (counts 1 and 2 on the indictment) and with one offence of arranging or facilitating the travel
[of another with a view to exploitation, contrary to section 2(1) of the Modern Slavery Act 2015 (count 3).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

3. On 22 June 2021 at the Crown Court at Kingston upon Thames, the applicant Basky Capitao was
convicted of all three offences after trial. On 30 July 2021 he was sentenced to a total of 11 years'
imprisonment made up in the following way: eight years' imprisonment concurrent on each of counts 1 and
2 and three years' imprisonment on count 3 to run consecutively to that term.

4. On 14 April 2021 the applicant Jemy Capitao pleaded guilty to counts 1 and 2 and an additional offence
of possessing criminal property, contrary to section 329(1)(c) of the Proceeds of Crime Act 2002 (count 4).
On 28 May 2021, after the trial had begun, he changed his plea to one of guilty on count 3. On 30 July

2021 he was sentenced to a total of 12 years' imprisonment made up in the following way: nine‑and‑a‑half

years' imprisonment concurrent for each of counts 1 and 2 and two‑and‑a‑half years' imprisonment on

count 3 to run consecutively to that term. No separate penalty was imposed for count 4.


-----

5. On 30 October at his PTPH at the same court the applicant Langrish pleaded guilty to an offence of
possessing a controlled drug with intent, contrary to section 5(3) of the Misuse of Drugs Act 1971 (count 6).
On 18 May 2021, the day of his trial, he pleaded guilty to counts 1, 2 and 3. On 5 January 2022 he was
sentenced to a total of eight years and six months' imprisonment made up in the following way: 52 months'
imprisonment concurrent for each of counts 1 and 2, 25 months' imprisonment consecutive for count 3 and
25 months' imprisonment again consecutive for count 6.

6. Ancillary orders were made in the case of each applicant.

7. Other conspirators pleaded guilty to counts 1 and 2 and were subsequently sentenced. It is
unnecessary for the purposes of these applications to set out the detail of their involvement and the
sentences they received.

8. The applicants were all involved in the county lines drug supply of cocaine and heroin between London
and South Wales. It involved the exploitation of a [an age] boy whom we shall refer to as SA. He was
used as a runner and to sell drugs on the street. The conspiracies ran between January and October
2020. The total quantity of class A drugs was in excess of 1 kilogram. Two lines were used in the
conspiracies known as Gino 1 and Gino 2.

9. The offending came to light when SA was reported missing from London. On 25 September 2020
police officers attended a flat in Swansea having received information that SA was there. He was not, but
they recovered a Nokia telephone from the flat. Subsequent analysis revealed that it housed the Gino 2
line. Later that day SA was located at a different address in Swansea. On 1 October another phone was
seized from SA's home address in London. Among messages found on the phone relating to heroin and
cocaine were messages from the Gino 1 line.

10. Jemy and Basky Capitao were arrested on 1 October and Langrish on 6 October 2020

The applicants' roles

11. Jemy Capitao was resident in Swansea. He set up and ran Gino 1. When that ceased being used he
set up Gino 2 the very next day. When arrested he was found to be in possession of nearly £3,000 in cash
(the subject of count 4). At one stage he went on holiday to Dubai during a period of the conspiracy and
handed the drugs line over to others in London. He did not recruit SA but did assist with his travel. When
SA asked for Gino 2 to be set up, this applicant did so.

12. He pleaded guilty on a written basis of plea which was accepted by the prosecution in which he stated

that he ran Gino 1 sporadically between January and mid‑August 2020. Although it was a commercial

enterprise he only made enough money to pay off old drug debts. He handed over the drug line to others
from London to operate before he went on holiday and did not expect to have any further involvement in it
beyond being a local consultant. He was not involved in the recruitment of SA into drug supply but was
encouraged by others to use him. In order to repay debts and at the request of SA he set up Gino 2 when
those in London ceased Gino 1.

13. Basky Capitao is Jemy's younger brother. He was actively involved in the Gino 1 line from 18 August

when Jemy went on holiday. He supervised two other co‑accused, Kimpton and Elaouzi and had a close

association with Langrish. He facilitated SA's travel to South Wales and met him on 10 September
knowing that he was going to be used as a runner.

14. Langrish was a driver and acted as a courier of the drugs from London to South Wales, a journey he
made on five or six occasions. He had never held the Gino 1 or 2 lines, although he was in close proximity
to them on occasion. On one occasion he picked up SA and drove him to Swindon where he was met by
another conspirator. Langrish had been Basky Capitao's legitimate driver but once Jemy handed the drugs
line to Basky, Langrish became a driver and courier of the drugs. When arrested Langrish was found in
possession of over 100 wraps of cocaine ready for street deals.

15. He pleaded guilty on a written basis of plea which was accepted by the prosecution in which he said
that he performed a limited role in the conspiracy as a driver. His first involvement was on 14 August 2020.


-----

He suffers from a medical condition called diverticulitis which causes him constant pain and discomfort. He
became a heavy cannabis user to alleviate the pain. He sourced the cannabis from South Wales. He
became involved in the conspiracy solely at the instigation of Basky Capitao for whom he had legitimately
worked as a driver. He did not know exactly what he was driving to South Wales but accepted that it must
have been class A drugs. He would be paid £100 per trip. In relation to count 3, he drove SA to Swindon
at the request of Basky Capitao.

Antecedents

16. Jemy Capitao, now aged 29 years, has seven convictions for 11 offences between 2007 and 2017.
These include a conviction in 2017 for two offences of being concerned in the supply of class A drugs and
an offence of perverting the course of justice for which he was sentenced to a total of 32 months'
imprisonment.

17. Basky Capitao, now aged 28 years, has four convictions for eight offences, none of which are for like
offences. He has a conviction for wounding with intent in 2014. His most recent conviction is for battery
also in that year.

18. Langrish, now aged 37 years, has six convictions for 13 offences, none of which relate to drug
offending. His last conviction was in 2015 for a driving offence. The judge had before him a medical report
on the applicant which confirmed his diagnosis. This had led on occasion to hospital admission and it was

likely that he would suffer such flare‑ups again.

Sentence

19. The judge in his sentencing remarks observed that this was a county lines organised crime operation.
He did not accept defence submissions that this was routine drug dealing. It was an operation to supply
class A drugs, both cocaine and heroin, from London into the Swansea area of South Wales. The judge
observed that drugs are a major scourge of every town and city in the United Kingdom. They ruin lives and
communities. Those who become involved in this sort of conspiracy at any level may expect, he said,
appropriate sentences.

20. The judge noted that there were no sentencing guidelines for conspiracy offences but found that the
guideline in relation to supplying or offering to supply a controlled drug was of assistance. He placed the
conspiracies in counts 1 and 2 within Category 2 harm by reason of the quantity of drugs concerned.
Street dealing undoubtedly happened, but in his view that did not reflect the harm caused by the
conspirators in this case such that it should fall within Category 3.

21. Dealing with each applicant in turn, the judge said that he would sentence Jemy Capitao upon his
basis of plea but he did not consider that what he said about SA afforded him any mitigation. He observed
that this applicant was aged 27 and SA 15 at the time of the offending. The applicant exploited his
vulnerability, even if he did not recruit him into the world of drugs. The judge noted that Jemy Capitao was
the originator of both lines. Even if he operated the line occasionally he did so for financial reasons and it
was organised crime. In the judge's view this applicant's role did not fit easily within leading or significant
role within the guidelines. In the event he afforded him a significant role observing that every factor placing
an offender within this category applied in this applicant's case. These multiple characteristics justified
upward adjustment within the category which has a starting point of eight years and a range of

six‑and‑a‑half to 10 years' imprisonment. The judge found aggravating features in the applicant's previous

drugs conviction and that he had used or admitted a person under 18 to deliver a controlled drug. He
thereby reached a notional sentence after trial of 12 years' imprisonment on counts 1 and 2, which he
reduced by 20 per cent for credit for plea to 114 months. He reached a notional sentence after trial on
count 3 of 36 months' imprisonment, which he reduced by 10 per cent for credit for plea, thereby coming to
30 months' imprisonment. This was to be consecutive to the term imposed for counts 1 and 2, resulting in
a total sentence of 12 years' imprisonment.

22. In sentencing Basky Capitao the judge found that he had been leading a double life. On the one hand
he was a family man with a good business; on the other involved in the two conspiracies, actively involved


-----

in supervising two other conspirators from 18 August 2020 when his brother went on holiday. In exploiting
SA the judge found that he knew when he facilitated his travel to South Wales that he was going to be a
runner there. The judge expressly limited this applicant's involvement to the weeks from 18 August to 1
October, but found that he featured in each of the characteristics justifying a significant role, that is
operational and management function within a chain, involving others in the operation, expectation of
financial or other advantage and some awareness of the scale of the operation. The judge found his role
was a significant one, although not as significant as his brother's. This afforded the same starting point
and sentencing range that we have already identified.

23. The judge found aggravating factors in that this applicant was supervising Gino 1 and SA started work
in September. His previous convictions did not aggravate the sentence. The judge stated that he had
borne the principle of totality in mind and thereby came to a total sentence of 11 years made up in the way
we have already set out.

24. As we have indicated, Langrish was sentenced on a later occasion. The judge observed that he was a
father and a man capable of earning an honest living. He took into account his medical difficulties. The
judge was satisfied that this applicant was a key player in the conspiracies, acting as a courier from the
drugs headquarters to South Wales to keep the drugs line supplied with heroin and cocaine. He concluded
that most of the five or six trips he made to South Wales in the relevant time period were for that purpose.
He proposed to sentence this applicant on the basis that he drove SA to Swindon as a favour to others.
Nonetheless, he observed that the applicant was aware that his travel was with a view to SA being
exploited.

25. The judge found this applicant to have features of significant and lesser role within the guidelines. He
had some understanding of the scale of the operation but also had a limited function under direction and
expected only limited financial advantage. There was no suggestion of an enhanced lifestyle by reason of
his involvement. The judge found no aggravating factors. In the event the judge found no evidence that
this applicant had used or permitted SA to deliver drugs. That said, the applicant had been part of a team
involved willingly in the movement of a child knowing that he would do the bidding of other conspirators.
He found mitigation in a lack of relevant convictions and in an element of remorse. He also recognised that
this applicant had a stringent doorstop curfew whilst on bail.

26. The judge adopted a notional sentence after trial of 36 months for count 3. On count 6 (possession of
cocaine with intent to supply) the judge placed the offence within Category 3, lower end of significant role
or top end of lesser role. He afforded 10 per cent for the applicant's guilty pleas at trial for counts 1, 2 and
3 and 25 per cent for his guilty plea to count 6. With an eye to totality the judge adopted a starting point on
counts 1 and 2 of five years' imprisonment. Affording 10 per cent credit for plea resulted in a reduction to
52 months' imprisonment on each count concurrent. This was reduced by 116 days to reflect his qualifying
curfew whilst on bail. Again, taking totality into account the judge adopted a notional sentence after trial of
30 months' imprisonment on count 3 and reduced that further to 25 months by affording a little over 10 per
cent credit for plea. On count 6 the judge reduced the notional sentence after trial to 36 months'
imprisonment, rather than 48 months identified in the guideline. Affording 25 per cent credit for plea this
was further reduced to 25 months' imprisonment. The judge ordered all sentences to run consecutively
thereby coming to a total sentence of eight years and six months' imprisonment.

Grounds of appeal

27. Each applicant submits that the sentence imposed upon him was manifestly excessive. Dealing with
each in turn:

28. Mr Spreadborough on behalf of the applicant Jemy Capitao submits first that the role attributed to him
by the judge did not accurately reflect his basis of plea and the judge thereby erroneously came to a
sentence near the starting point for high end leading role when it should have been high end lesser or
lower end significant role within the guidelines. He further submits that by treating the exploitation of SA as
an aggravating factor for counts 1 and 2 and also imposing a consecutive sentence for count 3, the judge

fell into error and double‑counted this offending in coming to the overall sentence. Further, he submits that


-----

the judge did not allow for the limited role this applicant played in his dealings with SA. He was not as
involved as those who recruited, transported and controlled SA whilst he was in South Wales. The judge
fell further into error, he submits, when he refused to accept the nature of SA and the fact that he was
already involved in drug dealing as mitigation. Finally, he submits the judge further failed to take sufficient
account of totality and the prison conditions during the pandemic.

29. Mr Frymann on behalf of Basky Capitao submits that the judge adopted too high a starting point on
counts 1 and 2 which did not properly reflect his brief involvement in the conspiracy which was some three
to four weeks within the operational period of 10 months. He submits that in his case the offending was
more accurately described as street dealing, albeit aggravated over time to lower end Category 2 harm

within the guideline. This applicant takes the same point on double‑counting and the involvement of SA.

He submits that the judge double‑counted his supervision of others in the conspiracy by treating it as a

factor falling within significant role and additionally as an aggravating factor. Finally he submits that the
judge failed to pay sufficient regard to totality, as well as to his personal mitigation and the prison
conditions within the pandemic.

30. Miss Meek on behalf of the applicant Langrish submits that the judge failed to have adequate regard to
his basis of plea and his limited role within the conspiracy and with SA. She submits that he should have
been placed within Category 3 of the sentencing guidelines and the judge therefore adopted too high a
notional sentence after trial. She points out that by the time the applicant Langrish was sentenced, the
sentencing guidelines in relation to **_Modern Slavery were in force. In error, neither she nor the judge_**
made reference to them during the course of the sentencing hearing. She submits that on those guidelines
this applicant would fall within Category 3C of the guideline which has a starting point of two years'
imprisonment and a range of one to four years' custody. She submits that the judge adopted too high a
starting point for this offence by reference to that guideline. Second, she submits that the judge failed to
have sufficient regard to totality on the overall sentence and finally that the judge failed to properly take into
account this applicant's ongoing medical condition, his remorse, his curfew and his lack of previous
convictions.

Discussion

31. We have reflected upon these submissions. In our view the judge's sentencing remarks in relation to
each of these applicants were comprehensive, thorough and fair. He was conducting an intricate
sentencing exercise involving a number of people for their involvement in organised crime. He had the

considerable advantage of presiding over the applicant Basky Capitao's trial and was well‑placed to assess

the role of each of the applicants and the conspirators.

[32. As this court observed in R v Khan [2013] EWCA Crim 800, the fact of involvement in a conspiracy is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58GH-J8S1-F0JY-C26C-00000-00&context=1519360)
an aggravating feature in offending of this type as each conspirator playing his part gives comfort and
assistance to others knowing that he is doing so and the greater his awareness of the scale of the
enterprise in which he is assisting the greater his culpability. We consider the judge entirely right to have
placed the offending in counts 1 and 2 in relation to each of these applicants into Category 2 of the
guideline. The quantity of drugs supplied justified such an approach, including for the applicant Basky
Capitao, albeit he was involved in the conspiracy for a lesser period of time.

33. We also consider the judge correct to have passed consecutive sentences on count 3. We consider
this to be the proper approach to such offences provided of course proper consideration is given to totality.

34. Taking each of these applicants in turn, we are unpersuaded that in sentencing him on counts 1 and 2
the judge failed to properly reflect the applicant Jemy Capitao's basis of plea. This applicant set up both
lines, the second only a day after the first ceased. We agree with the judge that every factor of significant
role applied in this applicant's case. The judge was right in those circumstances to reach a notional
sentence after trial towards the top of the category range for Category 2 significant role. We note that
there was no separate penalty for the offence in count 4, that is possession of approximately £3,000, which
must also have been taken into account in coming to the appropriate overall term. A significant


-----

aggravating factor in this applicant's case was his previous conviction for class A drug dealing. It could be
no mitigation that he was using the proceeds of his drug dealing to pay off a drug debt.

35. On count 3 we cannot accept this applicant's contention that he should have received a lesser
sentence by reason of the fact that SA had already been exploited by others and was a drug dealer who
persuaded him to open the Gino 2 line. SA was a [an age] boy. It is no mitigation to say that he was
already corrupted before he was exploited by the applicant. We find no force in the submissions that the
judge failed to pay sufficient regard to totality or take sufficient account of prison conditions which have
limited application to sentences of this length.

36. We are however persuaded that in one respect the judge fell into error and that is in effectively

double‑counting the exploitation of SA in reaching the overall sentence. As we have said, in our view the

judge was right to have imposed a consecutive sentence for count 3 and we find nothing wrong in its
length. However, by also using the exploitation of SA to be an aggravating factor in the drugs offences the
judge double-counted this feature. This was in our view wrong in principle. We give effect to that
conclusion by granting leave to appeal against sentence and quashing the sentence of nine years and six
months on each of counts 1 and 2 and substituting sentences of nine years in their place. These are to run
concurrently to each other and consecutive to the sentence on count 3, leading to a total sentence of 11
years and six months' imprisonment.

37. We turn to Basky Capitao. We recognise, as did the judge, that this applicant was involved in a
conspiracy for a lesser period of time than his brother. We nonetheless consider the judge right on counts
1 and 2 to have ascribed him a significant role in Category 2 within the guideline for the reasons he gave.
We consider the length of sentence on count 3 to be beyond criticism. We are unpersuaded that the judge
failed to take sufficient account of this applicant's mitigation or prison conditions or that he failed to have
proper regard to totality. However, we are persuaded that for the same reason as in the case of the

applicant Jemy Capitao, the judge fell into error in double‑counting the exploitation of SA. We also accept

that the judge further double‑counted the fact that this applicant was supervising others during the

conspiracy, stating it to be a reason for placing him in significant role and also treating it as an aggravating
factor. This we consider was wrong in principle.

38. We give effect to that conclusion by granting leave to appeal sentence. We quash the sentence of
eight years on each of counts 1 and 2 and substitute sentences of seven years and three months in their
place. These are to run concurrently with each other and consecutively to the sentence on count 3,
leading to a total sentence of 10 years and three months' imprisonment.

39. We turn finally to the applicant Langrish. We are unpersuaded that the judge failed to have adequate
regard to the lesser role that this applicant played in the conspiracy. The judge expressly found him to
have a lesser role and in reaching a notional sentence after trial of five years on counts 1 and 2 passed a
significantly lower sentence than those imposed on the other applicants. The judge also expressly took
into account this applicant's medical condition, remorse and lack of relevant previous convictions. He
deducted days from the final sentence to reflect the days on curfew.

40. We are further unpersuaded that the judge had insufficient regard to totality. He expressly and
significantly reduced each sentence to take that into account. For reasons we have already identified, the
judge in our view adopted an entirely correct course in making the sentence on count 3 consecutive to that
on counts 1 and 2. He was also entitled in our view to direct the sentence on count 6 to run consecutively
to the other sentences imposed. This was entirely different offending.

41. We consider it unfortunate that no reference was made in the court below to the sentencing guidelines
then in force in relation to count 3. We note however that even if this applicant was placed within Category
3C the sentence imposed upon him for count 3 was well within the range and we do not accept that the
term imposed was manifestly excessive. In our view the total sentence imposed on this applicant was not
arguably manifestly excessive. Accordingly we refuse leave to appeal against sentence and dismiss the
application.


-----

LADY JUSTICE ANDREWS: Mr Frymann, in light of the fact that the court has granted permission and
indeed allowed the appeal, we take it you would like a representation order?

MR FRYMANN: Yes, thank you very much, it saves my blushes. I was just thinking that I might have to
mention that, so thank you and yes please.

LADY JUSTICE ANDREWS: You may have one, thank you very much.

MR SPREADBOROUIGH: May I make a similar application, my Lady? I think when receiving the
summary it was incorrectly recorded that Jemy Capitao had arranged for private representation. I have
actually been appearing pro bono up today so I make a similar application.

LADY JUSTICE ANDREWS: In which case the same applies, Mr Spreadborough. Our note suggests he
is privately funded but if you are acting pro bono then you should have a representation order.

MR SPREADBOROUIGH: I have been throughout. Thank you, my Lady.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

