# R (on the application of Dragoi) v Secretary of State for Justice [2024] EWHC
 60 (Admin)

King's Bench Division, Administrative Court (London)

Michael Ford KC (sitting as a deputy judge of the High Court)

18 January 2024Judgment

**Mr Turner (instructed by Briton Solicitors) for the Claimant**

**Mr Skinner (instructed by Government Legal Department) for the Defendant**

Hearing date: 15 November 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30 am on 18 January 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Michael Ford KC, sitting as a Deputy High Court Judge:**

**Introduction**

1. This is an application for judicial review brought by the Claimant, Mr Vasile Dragoi, against a decision of
the Secretary of State for Justice, made on his behalf by Ms Amy Rees, the Chief Executive of His
Majesty's Prison and Probation Service, on 26 May 2023 and summarised in a letter to the Claimant dated
26 May 2023. The decision was to refuse to exercise the discretion to remove the Claimant to Romania
under the early release scheme (“ERS”) provided for by s.260 of the Criminal Justice Act 2003 (“CJA”).

2. There were three grounds of challenge in the Statement of Facts and Grounds (“SFG”): that the
Defendant failed to take into account relevant considerations (Ground (1)); irrationality (Ground (2)); and,
Ground (3), that the Claimant's detention was and is unlawful. Permission to apply for judicial review was
granted by Lang J in an order of 14 July 2023.

3. There was a helpful agreed list of issues and an agreed chronology. The list of issues set out the
relevant factors which, the Claimant submitted, the Defendant failed to take into account for the purpose of
ground (1). Ground (3) included sub-issues of whether the Claimant was unlawfully detained in breach of
Article 5 of the European Convention on Human Rights (“ECHR”) and whether the unlawful detention claim
was an abuse of process.

4. The hearing was beset by procedural problems to do with filing hearing bundles and authorities, none of
which was attributable to the Defendant. I am grateful to the Defendant's legal team for assisting the Court
and providing me with a core bundle of documents and an agreed authorities bundle.

5. Before me, the Claimant was represented by Mr Turner and the Defendant by Mr Skinner. Their
submissions were of much help to me in addressing the issues before the Court.


-----

**Relevant Facts**

6. The background facts are short, were not in dispute and were mostly set out in the agreed chronology.

7. The Claimant is a Romanian national, born on 3 March 1960. He has various serious health problems,
which I refer to below.

8. Between January and October 2017 the Claimant committed various criminal offences of what is usually
referred to as “human trafficking”. Economically vulnerable residents from his home town, Valcea in
Romania, were sent to work in England in order to work in the construction industry. The victims were
barely paid any of their wages, which instead went direct to the traffickers; they were told that their living
expenses would be paid, whereas they were in fact in debt to the traffickers; they were accommodated in
dangerous and horrific living conditions; and some suffered physical injury while others were threatened
with violence, as were their families in Romania.

9. Following a Crown Court trial, at which several[1] victims gave evidence (others were too scared to do
so), on 1 December 2021 the Claimant was convicted by a jury of two offences: (i) conspiring to arrange or
facilitate travel of another with a view to exploitation, contrary to s.2 of the **_Modern Slavery Act 2015_**
[(“MSA 2015") and (ii) conspiring to convert criminal property. On 14 May 2022 he was sentenced to six](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
years' imprisonment for the human trafficking offence and 18 months for the second offence, to run
concurrently. According to the evidence before me, the comments of the sentencing judge referred to the
Claimant playing a leading role in the exploitation of victims.

10. The Claimant was notified on 24 May 2022 that he was liable to be deported as a foreign criminal. He
was and is currently held at HMP Wandsworth.

11. On 3 February 2023 the Crown Court made a slavery and trafficking prevention order against the
Claimant under s.14 of the MSA 2015, prohibiting him from communicating with certain named persons
who were victims of his offences and engaging in other acts related to modern slavery for a period of five
years.

12. The Claimant's sons, Ion Bogdan Dragoi and Florinel Dragoi, who were part of the same enterprise,
were sentenced to terms of imprisonment of five years and seven months and five years and three months
respectively. Both were removed to Romania under the ERS: Florinel Dragoi on 16 September 2022 and
Ion Dargoi on 26 January 2023.

13. According to the evidence before me, the police were not aware that the Claimant's sons had been
removed under the ERS until they were contacted by a Romanian Victim Care NGO, saying that victims
had seen the Claimant's sons back in their local communities. The police then discovered that the sons
had been removed to Romania and it was too late to appeal against those decisions.

14. It was common ground that the power to remove the Claimant under s.260 of the CJA arose on 19
February 2023. Shortly before this, and as a result of the information the police had received about the
removal of the Claimant's sons, in an email dated 10 February 2023 a member of the Metropolitan Police's
**_Modern Slavery and Child Exploitation Team raised concerns about early removal of the Claimant with_**
HM Prison and Probation Service (“HMPPS”). The e-mail explained that the Claimant had property in
Valcea, where he was from and would no doubt return, a small town where 11 victims who gave evidence
against him resided. It said the victims were fearful of reprisals, could easily be traced by the defendants
and were still vulnerable. It added that the removal of the Claimant had the potential to undermine trust and
confidence of the victims in the criminal justice system and risked discouraging future victims coming
forward.

15. On 8 March 2023 the Defendant first considered the Claimant's potential removal under ERS and
decided he was not eligible for removal because the Claimant had an unsatisfied confiscation order against
him. It is not in dispute that this was an error because the Claimant had paid the sum due by 21 January
2023 and the Defendant had been notified of this.

16. On 28 March 2023 the Secretary of State for the Home Department made a deportation order in
respect of the Claimant


-----

17. The Claimant brought a first judicial review, CO/1599/2023, issued on 3 May 2023, challenging the
decision of 8 March 2023 on the basis that it was infected by a material error of fact - the Claimant had in
fact paid the confiscation order - and contending that he had been unlawfully detained from 19 February
2023 (his ERS eligibility date). In pre-action protocol correspondence, dated 13 April 2023, the Claimant's
solicitors provided information about his health problems.

18. Following orders for expedition, at a hearing on 5 May 2023 the Defendant undertook to withdraw the
decision of 8 March 2023 and to reconsider the matter. As a result, the claim was dismissed save for the
issue as to damages for unlawful detention, as to which the Court made directions that the Claimant was to
file and serve his submissions on unlawful detention no later than 14 days after the Defendant
reconsidered his claim under the ERS.

19. On 18 May 2023 a fresh decision was taken by the Governor of HMP Wandsworth, again refusing the
Claimant's removal under ERS on the grounds of public safety and that his early release would undermine
public confidence in the criminal justice system. However, following objections from the Claimant that the
matter should have been referred to the Chief Executive of HMPPS in accordance with the guidance in PSI
04/2013 (the “PSI”), entitled “The Early Removal Scheme and Release of Foreign National Prisoners”, the
Defendant agreed that the decision would be retaken by the Chief Executive.

20. As a result the matter was referred to Ms Rees, the Chief Executive of HMPPS. It is her decision,
taken on 26 May 2023, which is the subject of the challenge in this, second, judicial review. Ms Rees lists
the documents provided to her for purpose of decision at §14 of her witness statement. The documents
comprised the following:

(1) An email dated 22 May 2023 from the Ministry of Justice (“MoJ”) Policy Team, explaining how that the
police had contacted the HMPPS Modern Slavery Team about this case; summarising the police concerns
relating to fears about the 11 victims from the Claimant's home town who gave evidence against him and
who were said to be vulnerable, fearful and easily traceable; referring to the police view that removal of the
Claimant would undermine trust in the criminal justice process and/or stop others giving evidence in future;
and saying that sometimes in extreme cases prison governors did refuse ERS.

(2) An email dated 15 May 2023 from the police, attached to the above email from the MoJ, and which
repeated the same points as the police had made in their earlier email dated 10 February 2023, to which I
have referred above (see §14 above).

(3) An email of 26 May 2023 from the MoJ Early Release Team, and a chain of associated emails, one of
which explained that Ion Dragoi and Florinel Dragoi had been removed under ERS without the knowledge
of the police. As well as the relevant removal form, attached to that email were the following:

i. A detailed submission from MoJ Release Policy Team, dated 25 May 2023, explaining that an urgent
decision was required in relation to ERS. It set out the background to the conviction and sentencing of the
Claimant and his co-defendants; gave the information about the victims which I have summarised at §8
above; stated that the police were not aware that the Claimant's co-defendants had been removed to
Romania until they were contacted by a Romanian NGO; and summarised the concerns of the police about
the impact on the Claimant's victims, who remained in fear of reprisals, and the risk that future victims
might not be prepared to come forward. The document gave general advice about the ERS policy, saying
at §20 that:

“...there is a general presumption in favour of authorising early removal unless the prisoner meets one of
the reasons to refuse or whose early removal would seriously undermine public confidence in the scheme
and the administration of justice.”

After referring to the typical reasons for refusal, such as ongoing criminal matters and others listed in the
PSI, it stated at §23.

“Unlike other removal cases however, Mr Dragoi would be returning to the country where the victims of his
crime are living and will be expecting to again live in the small village where they reside. The offence
involved the exploitation of very vulnerable people, who gave evidence against Mr Dragoi in his criminal


-----

trial, and who are still attempting to piece their lives back together following the trial and their return to their
home country”.

The document also stated that it did not anticipate any Parliamentary “handling” arising from the
submission, nor any media interest in the matter.

ii. An email chain between HMPPS and the MPS **_Modern Slavery and Child Exploitation unit, which_**
included the email of 10 February 2023 referred to above at §14.

iii. An email of 22 May 2023 from the from Governor of HMP Wandsworth Governor, explaining why he
had refused removal under ERS on 18 May 2023, based on impact on the victims and the potential to
undermine trust and confidence in the criminal justice system.

21. The decision of Ms Rees was summarised in a letter dated 26 May 2023. The letter stated as follows:

“This note summarises my decision in relation to Mr Vasile Dragoi (Senior)'s application for removal from
the UK under the Early Removal Scheme (ERS).

Early removal under the ERS is discretionary and not a right. It is for me as Chief Executive of HMPPS to
make the final decision on whether or not, taking the individual circumstances of the case into
consideration, early removal is appropriate.

I have considered the facts of the case carefully. My decision is to refuse Mr Dragoi's application for
removal under ERS on the grounds, under section 2 of PSI 04/2013, that to grant his application would
undermine both public safety and public confidence in the Criminal Justice System.

Mr Dragoi's offence involved the exploitation of very vulnerable people. Several gave evidence against him
during his criminal trial. I understand that those 11 victims live in Valcea, Romania – the same small town
that Mr Dragoi is from and where he owns property. Were he to return early, the victims would be easily
traceable by the defendants who recruited them and there would be a real risk to their safety.

Granting early release to Mr Dragoi has the potential to undermine the trust and confidence not only of
those victims but of the wider public, who would not think it reasonable to allow an offender of this type to
return early to the area where their vulnerable victims reside. There is a real risk that future victims of
exploitation may not have the confidence to come forward and give evidence if they take the view that
offenders will serve reduced amounts of time in prison before being released back into their home country.”

22. After receiving that letter, the Claimant's solicitors sent a pre-action protocol letter dated 30 May 2023,
challenging the decisions of 8 March 2023, 18 May 2023 and 26 May 2023. In reply, the Defendant said
the challenge to the March decision was academic but maintained the lawfulness of the decision taken by
Ms Rees on 26 May.

23. The claim form in this challenge is dated 2 June 2023. The Claimant also made an application for
expedition. Permission was granted by Lang J on 14 July 2023 who also ordered expedition of the claim, to
be heard as soon as possible after 12 September 2023. Because that order was not served on the
Defendant, the hearing originally listed for 24 October was vacated, so that the hearing eventually came
before me on 15 November.

**Legal Framework**

24. The _[CJA 2003 introduced an ordinary statutory rule that a prisoner sentenced to a fixed term of 12](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
months or more was to be released at the half-way mark and would then be on licence for the second half
of the term: see s.244(1), found in Chapter 6 of Part 12 under the heading “Release, licences, supervision
and recall”. In addition, the Act provides for various grounds upon which the Secretary of State may, in his
or her discretion, release a fixed-term prisoner early. For example, s.248 provides that the Secretary of
State “may at any time” release a fixed-term prisoner on licence if he is satisfied there exist exceptional
circumstances which justify release on “compassionate grounds”. The Explanatory Notes at §579 give the
example of where a prisoner is suffering from terminal illness.


-----

25. Central to this appeal is s.260, providing for removal under the ERS. It applies to fixed-term prisoners
who are “liable to removal from the United Kingdom”, defined in s.259 to include persons who are liable to
deportation, are illegal entrants or are liable to removal under s.10 of the Immigration and Asylum Act
1999. So far as is relevant, section 260 states as follows:

“(1) Where a fixed-term prisoner is liable to removal from the United Kingdom, the Secretary of State may
remove the prisoner from prison under this section at any time after the prisoner has served the minimum
pre-removal custodial period (whether or not the Board has directed the prisoner's release under this
Chapter).

(2) The minimum pre-removal custodial period is the longer of—

(a) one half of the requisite custodial period, and

(b) the requisite custodial period less one year.

(2C) Subsection (1) does not apply in relation to a prisoner to whom section 247A applies.

(4) A prisoner removed from prison under this section—

(a) is so removed only for the purpose of enabling the Secretary of State to remove him from the United
Kingdom under powers conferred by—

[(i) Schedule 2 or 3 to the Immigration Act 1971,or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

[(ii) section 10 of the Immigration and Asylum Act 1999 (c. 33), and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)

(b) so long as remaining in the United Kingdom, and in the event of a return to the United Kingdom after
removal, is liable to be detained in pursuance of his sentence.”

26. It is clear from the language of s.260 that it confers a discretion on the Secretary of State and there is
no duty to remove on the relevant date: see **_R v Round_** [2010] Cr Ap R (S) per Hughes LJ at §11.
Prisoners “removed” from prison under s.260 are “liable” to be detained so long as they remain in the UK
or return to the UK after removal: see s.260(4)(b). They are not, in other words, “released” from prison
(compare and contrast s.248).

27. Mr Skinner submitted (and Mr Turner agreed) that the overarching purpose of s.260 was to remove
foreign offenders from the UK, in accordance with the statement in s.117C(1) of the Nationality,
Immigration and Asylum Act 2002 that the “deportation of foreign criminals is in the public interest”. That
purpose is supported by s.260(4)(b) CJA, giving an incentive for a prisoner not to return to the UK. It is
further expressed and reflected in the PSI, under which the normal, default position is removal under the
ERS (see below). The public interest in deportation is not the only public interest engaged, however, and
there are competing public interests to be weighed against early removal: hence, for example, the
exclusion under s.260(2C) of prisoners convicted of certain terrorism offences specified in s.247A; and
hence, too, the relevant grounds for refusal of early release in the PSI. But the competing public interests,
to be balanced against the overarching policy of removal, do not include the protection of prisoner welfare
or protecting vulnerable prisoners (contrast s.248 CJA, providing for early release on compassionate
grounds).

28. The Defendant's policy on ERS is set out in the PSI, providing guidance on the ERS. After setting out
the rules on eligibility for early removal under ERS, it explains that prisoners who are subject to outstanding
criminal court proceedings, a confiscation order or outstanding proceedings in respect of such an order
should not be removed under ERS: see §§2.9, 2.12. The key paragraph for present purposes is §2.13,
which states under the heading “Other Reasons to Refuse ERS”:

“Where HOIE [Home Office Immigration Enforcement] confirm that a FNP [Foreign National Prisoner] can
be removed, and the prisoner is not subject to further custodial requirements, outstanding criminal matters,
or confiscation order proceedings, Governors must normally approve removal under the ERS. However,
there may be some exceptional cases in which ERS should be refused, particularly where there are
serious concerns about public safety. These are:


-----

     - clear evidence that the prisoner is planning further crime, including plans to evade

immigration control and return to the UK unlawfully;

     - evidence of violence or threats of violence, in prison, on a number of occasions;

     - dealing in class A drugs in custody;

     - serving a sentence for a terrorism or terrorism-connected offence.

     - other matters of similar gravity relating to public safety.

     - where early removal under the ERS would undermine public confidence in the criminal justice system.”

There is a form to be used, setting out the reasons for the refusal. By §2.20, where it is thought by a
Governor that removal may undermine public confidence in the scheme or in the criminal justice system,
the Chief Executive takes the final decision on whether early removal is appropriate, taking all matters into
consideration. The PSI anticipates that such cases will be exceptional: see §2.21.

**The Grounds of Challenge**

29. It is against that background that I consider the grounds of challenge. There is one matter to deal with
at the outset, however. In his submissions to me Mr Turner sought to argue that the term “public safety” in
§2.13 of PSI could only mean, as a matter of law, the safety of the public in the UK. His argument was, as I
understood it, that the Ms Rees had misinterpreted the term in PSI because she had focussed on the risk
to the safety of citizens in Romania - the victims in Valcea.

30. There was no ground of challenge based on the correct meaning of “public safety” in PSI, nor any
challenge to the effect that Ms Rees had misinterpreted that term in PSI. Nor was this point raised in the
Claimant's skeleton argument. Nor was there any application to amend the grounds to bring a challenge
based on the proper meaning of PSI. Further, to address the point it might be necessary to examine the
background to the legislation or PSI. In those circumstances, I do not consider it is a point which can or
should fall within the grounds of challenge to be considered by me. I have restricted my analysis to the
existing grounds in the claim form.

**Ground (1): Failure to Consider Material Facts**

31. Under Ground (1), the Claimant contended that the Defendant irrationally failed to consider the
following factors: (i) the Claimant's sons had been removed under ERS, and there was no reason for his
different treatment; (ii) the Claimant's serious health problems; (iii) the Claimant had signed a slavery and
trafficking prevention order which, among other matters, prevented his contacting the victims. In addition,
under this ground, it was contended (iv) that the Defendant failed to conduct an assessment of whether the
Claimant was at risk of offending, so that it had no rational basis to consider he would or might do so; and
(v) no consideration was given to how the threat would be different if the Claimant were released at the end
of his sentence rather than removed under ERS.

32. There is no lexicon of factors which must or may be taken into account when exercising the discretion
under s.260. It was common ground that, as a result, the question of what factors are relevant is a matter
for the Defendant, subject only to review on Wednesbury grounds: see R (Khatun) v Newham London
**_Borough Council [2005] QB 37, per Laws LJ at §§34-5._**

33. Laws LJ derived this principle from the Lord Scarman's speech from In Re Findlay [1985] AC 318 at
333-4 who in turn had approved as correct two passages from the judgment of Cooke J in CREEDNS Inc v
**_Governor General [1981] 1 NZLR 172 at 183. The first was that it was not enough that a consideration “is_**
one that may properly be taken into account, nor even that it is one which many people, including the court
itself, would have taken into account if they had to make the decision”. Cooke J's second statement was
that, even where a statute is silent “there will be some matters so obviously material to a decision...that
anything short of direct consideration of them by the ministers....would not be in accordance with the
intention of the Act”. These passages underline the high threshold to be crossed in a challenge of the


-----

present sort, which takes place in the context of legislation giving no real clue as to scope of the discretion
to refuse ERS,

34. It is in light of those principles that I consider the five matters raised under this ground. It was not
disputed by Mr Turner that public safety or undermining public confidence in the criminal justice system,
both of which are listed in §2.13 of the PSI, are potentially good and lawful public interest reasons for
refusing early removal under ERS.

35. Factor (i). This factor involves three distinct challenges. The first is that it is said that the Defendant
failed in fact to consider that the Claimant's sons had been removed to the same town in Romania as the
one to which he was expected to return. This is wrong factually: as Ms Rees explained in her witness
statement, this information was communicated to her via the e-mail of 22 May 2023 and the presence of
the Claimant's sons added to her wider concerns, meaning she did consider this matter.

36. The other ways that this challenge is put are as follows:

(1) It is said in the Statement of Facts and Grounds (“SFG”) at §24.1 that the Defendant did not provide
reasons why Claimant was treated differently. But there is no reasons challenge and, in any event, Ms
Rees explains in her evidence why the Claimant was treated differently from his sons. In the case of the
sons, it seems no consideration was given to the risks caused by their return to Valcea under ERS; but, if
those cases had been referred to her, she said it was “unlikely” she would have given them early release.
In summary: the difference in treatment arose because the Claimant's sons were removed under ERS
without the police being alerted to this, with the result that the potential risks to victims or public confidence
in the criminal justice system were not considered at the time, whereas the police were alerted to the
potential removal of the Claimant. That is, I consider, a rational ground for the difference in treatment.

(2) In the skeleton argument for the Claimant, the matter was put in a third way. On the (correct) factual
assumption that the Defendant did consider the sons' early removal to Valcea, it is contended that the
Defendant acted irrationally because the victims' concerns have not materialised, even though the sons
have been released. But, as Ms Rees explained in her statement, the presence of the Claimant's sons in
Valcea added to her wider concerns about the release of the Claimant. This is supported by the information
set out in the document of 25 May, according to which the Romanian NGO reported to the UK police that
victims had seen the sons back in their local community. The obvious inference was that the victims were
concerned about the presence of the Claimant's sons. In light of those concerns, the serious offences of
which the Claimant and his sons were convicted, the vulnerability of the victims, and the likelihood that the
Claimant, who was the leader in the offences, would in all likelihood be returned to the same town as the
victims if he were removed under ERS, I consider it was sufficient for the Defendant to consider the risk to
the safety of victims, even in the absence of clear evidence that in fact the Claimant's sons had harmed or
threatened victims. Put another way, I do not consider that the absence of evidence of actual harm to
victims was a factor so obviously material that no reasonable decision-maker could fail to have regard to it.

37. **Factor (ii). The second relevant factor upon which reliance is placed is the Claimant's health. The**
Claimant's health problems are not in dispute, are listed in §15 of the SFG, and had been drawn to the
attention of the Defendant in the earlier PAP letter from the Claimant's solicitors of 13 April, supported by
medical evidence. They include type 1 diabetes, requiring insulin treatment since 2017; hypertension since
2005; coronary bypass surgery in 2009; chronic kidney disease requiring haemodialysis three times a
week since 2021; heart failure in 2021; interstitial lung disease; and severe sleep apnoea.

38. Mr Turner rightly accepted that health is not a matter to which the Defendant was required to have
regard in and of itself when it came to deciding if early removal should be granted or refused under the
ERS. But he submitted that the Claimant's health was relevant here to the two specific reasons, of public
safety and public confidence in the criminal justice system, on which Ms Rees relied when refusing his
removal. It was relevant to public safety because it made it less likely he would commit offences or had any
motive to contact victims; and his health was relevant to confidence in the criminal justice system because
public confidence would be less undermined by removal of someone under ERS who was seriously ill. In
considering these twin factors, Mr Turner submitted that no reasonable decision-maker could exclude
taking account of the Claimant's serious health problems


-----

39. It was not in dispute that Ms Rees in fact failed to consider the Claimant's health because no
information about them was drawn to her attention. Nor, for the Defendant, did Mr Skinner dispute that the
Claimant's health was a potentially relevant factor, to which Ms Rees could properly have had regard. The
legal dispute, therefore, turns on the narrow issue of whether Ms Rees, assuming she knew of the
Claimant's serious health problems, could only act lawfully if she took them into account when considering
refusal of removal of the Claimant under ERS.

40. In relation to the public safety factor relied on by Ms Rees, I bear in mind that the purpose of s.260
CJA is not to protect vulnerable prisoners and neither the language nor intention of s.260 provides any
clear pointer as to what matters are obviously material when it comes to refusal of early removal. The
relevant circumstances included that the victims were vulnerable, the Claimant had been found to be the
leader of the offences and, as Ms Rees explained in her decision letter, the victims would be in the same
small town and would be easily traceable by the defendants in the criminal trial - meaning him _and his_
sons, because they had already been removed to Romania. Despite his health problems, the Claimant had
both a motive and a means, through combination with his sons, to target the victims if he were returned to
Valcea. It is of note, too, that offences in 2017 took place when the Claimant already had some significant
health problems, although not as serious as those he had by 2023.

41. In the particular circumstances, in my judgement the Claimant's serious health problems were not so
obviously material to the conclusion that his return posed a real risk to the victims' safety that any rational
decision maker considering the refusal of early removal under the ERS was required to take them into
account. No doubt it would have been preferable if the health problems had been drawn to the attention of
Ms Rees and if she had expressly addressed them in her decision. I accept, too, that the Claimant's health
problems were potentially relevant to her decision based on the victims' safety, and were matters that
many decision-makers no doubt would take into account. However, the threshold for a challenge is a high
one in light of Khatun and there is a danger in a court assuming that because it would have taken account
of a matter, it was irrational not to do so - a danger which the principles endorsed in In Re Findlay warn
against. Decisions about risks to public safety in this context are inevitably somewhat speculative and on
balance I do not consider the failure to take account of the Claimant's health problems crosses the
threshold of a rationality challenge or would not be in accordance with the intention of the legislation.

42. I reach the same view in relation to the second matter on which Ms Rees relied in refusing early
removal. Of course, trust and confidence in the criminal justice system might not be undermined if the
victims or public had knowledge that the Claimant had only been removed owing to his serious health
problems. But the diffusion of information to the victims and the wider public is imperfect and partial: they
might only understand that the Claimant had been released early. Partly as a result, any assessment of the
effect of the Claimant's removal on public confidence in the criminal justice system is bound to be
somewhat impressionist and speculative, meaning it is not a decision with which a court will readily
interfere. The Explanatory Notes to the _[MSA 2015 recognise that victims are often unwilling to come](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
forward to law enforcement agencies (§4), supporting a heightened concern in this area that future victims
are not dissuaded. In the circumstances, I consider at best the Claimant's health problems were something
Ms Rees might have considered as potentially relevant to whether public confidence in the criminal justice
system would be undermined by his early removal. But I consider it is a step too far to hold that they were
so obviously material to answering that question that any reasonable decision-maker was required to take
them into account.

43. Factor (iii). The third factor which it is said the Defendant irrationally failed to take into account is the
slavery and trafficking order, made under s.14 of the MSA 2015, to which the Claimant and his sons are
subject.

44. It is correct that the order imposed on the Claimant prevents him contacting named victims and is not
restricted to acts in the UK (an order may extend outside the UK: see s.17(3) MSA 2015). It is correct, too,
that a breach of a slavery and trafficking prevention order is a criminal offence: see s.30. But the practical
effect of an order on a defendant who is outside the UK is quite another matter: the authorities in the UK
are unlikely to know if the order has been breached and, even if they discover it has, the steps required to
bring a defendant back to the UK for sentencing are unlikely to be straightforward


-----

45. Mr Turner described this argument as being at the “outer orbit” of his submissions. I consider he was
right to be restrained in pressing this submission because it elevates legal form over practical effect. Ms
Rees could rationally conclude that the removal of the Claimant posed a risk to public safety regardless of
the existence of the s.14 order. The practical difficulties of enforcing it in Romania is a sufficient reason for
concluding it was not so obviously material that she was bound to consider it in reaching her decision.

46. **Factor (iv). Fourthly, under this ground it is submitted that the Defendant failed to conduct any**
assessment of the risk of the Claimant reoffending (which I take to mean taking action against the victims
who reside in Valcea), including assessing that risk in light of his health problems.

47. Serious concerns about public safety is a potentially good reason for refusing removal under ERS.
Neither the PSI nor the Act requires any risk assessment to be undertaken. The Claimant had already
been convicted of offences of **_modern slavery, in which the victims had been subjected to extremely_**
serious criminal acts and in which he had played a leading role. In addition, Ms Rees had information from
the police that victims were in fear of reprisals. I have already concluded that it was open to her to
conclude that the Claimant's removal to Romania could contribute to the potential risk to victims despite his
health problems. I do not consider that the statutory scheme requires a formal assessment of the risk
posed by the Claimant (whatever that is taken to mean). The Claimant's past conduct towards the victims,
together with Ms Rees' assessment that they would be “easily traceable” by the Claimant and his sons in
Valcea, provided a sufficient rational basis for her view that his removal posed a real risk to their safety,
even in the absence of a formal risk assessment.

48. Factor (v). Fifthly, the Claimant submits that the Defendant did not consider that the threat would be
no different if the Claimant were released now than if he were released at the end of his sentence. I
consider Mr Turner was right not to press this point in oral argument. An offender must be released at the
end of his sentence even if he or she poses a risk to public safety. That requirement does not begin to
undermine a conclusion that early removal may be refused under ERS because of a risk to public safety
until a prisoner is released. Whether the threat level would be greater or lesser on eventual release is not
relevant to the decision in respect of ERS.

**Ground (2): Irrationality**

49. In support of this argument, the Claimant relies on two matters.

50. The first is the failure to consider the five factors above. If the submission is that the Defendant failed
to consider each factor, it adds nothing to the arguments made in respect of ground (1) and succeeds or
falls with it. Alternatively, it could be said that the cumulative effect of all the relevant factors listed above
meant that no reasonable decision maker could conclude that public safety or trust and confidence in the
criminal justice system would be undermined by the Claimant's early release under ERS.

51. The combined effect of those factors is not, in my judgement, sufficient to cross the threshold of a
rationality challenge. It was not in dispute that risks to public safety or undermining public confidence in the
criminal justice system were each legitimate public interest factors which could justify refusing early
removal under ERS. The weighing of those public interests against the competing public interest in early
removal of foreign prisoners is, just as Mr Skinner submits, a multifactoral exercise involving balancing
incommensurable public interests and where a court will be slow to interfere with the assessment of the
decision-maker. Even having regard to the Claimant's serious health problems, and the absence of
evidence of actual harm caused to victims following the release of his sons, I consider it was open to the
Defendant to conclude, acting rationally, that the removal of the Claimant would pose a real risk to their
safety. Yet more clearly, it was open to Ms Rees to conclude, in what was necessarily a rather speculative
assessment, that the early release of the Claimant had the potential to erode the trust and confidence of
both victims and the wider public in the criminal justice system, and to exacerbate the existing, recognised
problem that victims of **_modern slavery are often reluctant to come forward and give evidence against_**
their abusers.

52. The second argument is that the inconsistency of treatment between the Claimant and his sons makes
the decision irrational in the sense that it is arbitrary. This submission has been dealt with above: there was


-----

a good and sufficient reason for the difference in treatment between the Claimant and his sons because
the police were only alerted to his potential early release under ERS in time to stop it.

**Ground (3): Unlawful Detention**

53. The Claimant argues that the consequence of his succeeding on grounds (1) and (2) above is that he
was unlawfully detained from 19 February 2023. This challenge is now academic in light of my conclusions
on grounds (1) and (2) but, as I was addressed on it, I briefly record my reasons on the point. It may also
be relevant to the outstanding claim for damages for unlawful detention addressed in the order of
Chamberlain J of 9 May 2023 (as to which I understand the Claimant has not filed any submissions setting
out the basis of his claim within the 14-day limit provided for in §2 of that Order).

54. Mr Turner contended that (i) the Defendant's exercise of the discretion in s.260 CJA was unlawful; (ii) if
the discretion had been exercised properly, the Claimant would have been released; with the
consequences that (iii) the Claimant was unlawfully detained from that date and/or (iv) his detention was in
breach of Article 5 ECHR. The date from which detention was unlawful is given as 19 February 2023 or
“such date as the Court considers appropriate”.

55. However, I did not understand the Mr Turner to contest the analysis by Mr Skinner of the principles in
relation to unlawful detention, which are summarised below.

56. First, a prisoner who is sentenced to imprisonment is lawfully held in prison pursuant to s.12(1) of the
Prison Act 1952, and is deemed to be in the legal custody of the Governor of the prison: see s.13 of the
1952 Act.

57. Second, in relation to prisoners held in detention following a sentence of a court, a breach of public law
duties does not confer on individuals a right to damages for unlawful detention. The position was analysed
by the House of Lords in considering the position where the Secretary of State “failed deplorably” to afford
prisoners given indeterminate sentences for public protection a reasonable opportunity to demonstrate they
should be released: see R (James) v Secretary of State for Justice [2010] AC 553, per Lord Hope at §3.
Such a prisoner remains lawfully detained by statute until there is a direction for his release. As Lord Hope
put it:

“5. It is plain that the remedies which the claimants seek are not available to them at common law. The
Secretary of State's breach of his public law duty to have a system in place which provided prisoners with a
reasonable opportunity to demonstrate that they are no longer dangerous does not confer on individuals
who are affected by this breach a right to damages. Mr Owen QC for Mr Lee and Mr Wells submitted that
they were entitled to writs of habeas corpus. But he accepted that he was unable to challenge the legality
of the warrant which authorised their continued detention. As Simon Brown LJ said in R v Oldham Justices,
_Ex p Cawley_ [1997] QB 1, 13-14, where there has been a criminal conviction the courts have firmly
excluded collateral attack by habeas corpus, holding that the only proper remedy lies by way of appeal.
Sentences of imprisonment for public protection are sentences for an indefinite period, subject to the
provisions of Chapter II of Part II of the 1997 Act as to the release of prisoners and duration of licences:
2003 Act, section 225(4). There is no entitlement to release until release has been directed by the Parole
Board, and a direction to that effect cannot be given until the Board is satisfied that detention is no longer
necessary for the protection of the public. Mandatory orders may be obtained to ensure that the system
works properly. But it is not open to the courts to set that system aside by directing release contrary to the
provisions of the statute.

[6. For this reason I cannot agree with Laws LJ's finding in the Divisional Court [2008] 1 All ER 138, 154F](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RJK-M3N0-TWP1-60FD-00000-00&context=1519360)
that, to the extent that the prisoner remains incarcerated after tariff expiry without any current and
executive assessment of the danger that he does or does not pose to the public, detention is unlawful. In
terms of the statute, his detention is lawful until the Parole Board gives a direction for his release. The
default position, as Mr Pushpinder Saini QC put it in his helpful intervention for the Parole Board, is that
until the direction is given protection of the public requires that the prisoner should be confined.”

See similarly Lord Brown at §§36-37.


-----

58. Third, while a claim for damages may be brought under s.8 of the Human Rights Act 1998 where a
detention is in breach of Article 5 ECHR, Mr Skinner referred me to the decision of the Divisional Court in R
**_(Khan) v Secretary of State for Justice_** [2020] 1 WLR 3932, in which Fulford LJ and Garnham J
summarised the principles from the authorities at §121. In particular, (i) Article 5 does not guarantee a
prisoner's right to early release; (ii) the lawfulness of a prisoner's detention is decided, for the duration of
his sentence, by the court which sentenced him; and (iii) the “fact that a prisoner may expect to be
released on licence before the end of the sentence dos not affect the analysis that the original sentence
provides legal authority for detention throughout the term”. However, it is clear that Article 5 requires that
an individual is protected against “arbitrary” detention, the principles on which are summarised in James v
**_United Kingdom (2013) E.H.R.R. 12 at §§192-195._**

59. In the SFG, the Claimant appeared to contend that any public law error in the decision to refuse him
early removal automatically entailed that his detention was unlawful and in breach of Article 5. The
skeleton argument for the Claimant and the oral submissions of Mr Turner were more restrained because it
was contended that claim would only succeed if, had the Defendant acted lawfully, the Claimant would
have been removed under ERS at the material time (though in his reply Mr Turner appeared to accept that
not every public law error had the effect of making a detention unlawful). But, however the submissions
were put, I consider they do not begin to explain how the obstacle of James is to be overcome in relation
to a claim for unlawful detention under domestic law, nor do they provide any sufficient basis for a
conclusion that the Claimant's detention was arbitrary for the purpose of the case-law on Article 5 ECHR.
Nor does the limited evidence from the Claimant do so.

60. In the circumstances, even if I found in favour of the Claimant on grounds (1) or (2), I am not
persuaded he has made out any sufficient case why his detention was unlawful or in breach of Article 5
ECHR.

61. Finally, I should record that the Defendant raised a further argument that it was an abuse of process
for the Claimant to bring a claim for unlawful detention when Chamberlain J had made directions in May
2023 for submissions to be made setting out that claim within 14 days of the reconsidered decision (in the
event, 14 days of 26 May 2023) when none had been provided. I do not consider it necessary to decide
that point, given my conclusions on grounds (1) and (2); but the absence of any such submissions means
there is nothing additional to undermine my view that the Claimant has not made out any sufficient case to
show he has a good claim of unlawful detention or breach of Article 5.

**Conclusion**

62.  For the above reasons, the claim for judicial review is dismissed.

**End of Document**


-----

