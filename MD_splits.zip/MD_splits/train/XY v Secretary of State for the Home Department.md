# XY v Secretary of State for the Home Department [2024] EWHC 81 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Lane

23 January 2024Judgment

**Mr C Buttler KC, Ms Z McCallum (instructed by Asylum Aid) for the Claimant**

**Ms C McGahey KC, Mr W Irwin (instructed by Government Legal Department) for the Defendant**

Hearing dates: 29 and 30 November 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 23 January 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Mr Justice Lane:**

1. As a matter of public law, what is a Secretary of State able to do, faced with a judicial declaration on the
interpretation of his or her published policy, if he or she does not agree with that interpretation? That
important question lies at the heart of the claimant's challenge. The present case also raises issues
involving the duty of candour in judicial review and the approach to claims of privilege or irrelevance as
reasons for withholding material from the other party.

2. The policy in question concerns article 14 of the Council of Europe Convention on Action against
Trafficking in Human Beings 2005 (“ECAT”). Article 14(1)(a) of ECAT states that each party to the
Convention “shall issue a renewable residence permit to victims … (a) the competent authority considers
that their stay is necessary owing to their personal situation”.

3. As is now well known, ECAT has not been incorporated into domestic law. Whether and, if so, how to
comply with article 14(1)(a) is, accordingly, a matter for the defendant. The defendant has a published
policy, “Discretionary Leave Considerations for Victims of Modern Slavery,” which directs the defendant's
officials to make decisions regarding leave to remain in the United Kingdom as a victim of modern slavery
in accordance with article 14(1)(a) of ECAT. The version with which we are concerned is 4.0, published on
8 December 2020. This provides that discretionary leave may be considered under the policy where the
Competent Authority has made a positive conclusive grounds decision that an individual is a victim of
**_modern slavery and they satisfy one of a number of criteria, which for our purposes is that leave is_**
necessary owing to the victim's personal circumstances. After setting out a non-exhaustive list of what
might constitute such personal circumstances, the policy provides that, additionally, “a person may provide
evidence from a healthcare professional that they need medical treatment. In these cases, consideration
should be given to whether it is necessary for the treatment to be provided in the UK”.


-----

**_R (KTT) v SECRETARY OF STATE FOR THE HOME DEPARTMENT [2021] EWHC 2722_**
**_(ADMIN)_**

4. In R ( KTT) v the Secretary of State for the Home Department [2021] EWHC 2722 (Admin), Linden J
held that the defendant's policy “overwhelmingly demonstrates a commitment to take decisions as to
discretionary leave in accordance with ECAT...” (paragraph 79). Linden J held that the relevant question
under article 14(1)(a) was whether the victim's “stay” was necessary owing to their personal situation, not
whether the grant of the residence permit itself was necessary. At paragraph 92, Linden J accepted the
claimant's submission that the fact that a victim is pursuing an asylum/protection claim based on fear of retrafficking may be an aspect of the victim's personal situation for the relevant purposes, given that this
interpretation would be in accordance with the aims of ECAT. This was so, notwithstanding that section 77
of the Nationality, Immigration and Asylum Act 2002 prevents a person from being removed from the
United Kingdom while their claim for asylum is pending.

5. Following the handing down of his judgment in KTT, Linden J made an order on 25 October 2021
(sealed on 2 November 2021). The order included a declaration in the following terms:
“1. On their true construction, versions 2, 3 and 4 of the Defendant's policy “Discretionary Leave for Victims
of Modern Slavery” (“the MSL policy”) require the defendant's decisions on the grant of leave to remain to
be made in accordance with Article 14(1)(a) ECAT, which requires the grant of a residence permit to a
confirmed victim of modern slavery if their stay in the UK is necessary owing to their personal situation.

2. The statutorily-protected stay in the United Kingdom of a confirmed victim of trafficking pending the
resolution of an asylum claim made by them which is based on a fear of being re-trafficked is capable of
constituting a stay which is necessary owing to their personal situation within the meaning of Article
14(1)(a) ECAT.”

6. The order also contained a provision whereby the defendant's decision to refuse the claimant leave to
remain under the MSL policy was quashed and the defendant required to make a fresh decision on the
claimant's application for leave to remain under the MSL policy within 28 days of the order.

7. The central issue in the present case concerns the defendant's response to the judgment and order in
KTT. The claimant contends that the defendant's public stance was that the policy contained in the
published document Version 4.0 remained in force, with the consequence that the defendant's officials
would be assumed to make decisions in accordance with the policy, as interpreted by Linden J and set out
in his declaration. Instead, the claimant contends that the defendant operated what he describes as a
secret policy, whereby the defendant's officials were instructed to make decisions in cases where
confirmed victims of modern slavery were seeking asylum on the grounds of a fear of re-trafficking, but
were told not to serve those decisions. This, the claimant asserts, is contrary to the rule of law.

8. The defendant's position, in essence, is that the defendant merely paused decision-making in respect of
those affected by the judgment in KTT, until there was no longer any prospect of the defendant challenging
Linden J's order. That prospect disappeared when permission to appeal to the Supreme Court was refused
by that Court, in respect of the judgment of the Court of Appeal which had upheld Linden J's order. The
defendant contends that this was a lawful approach.

9. If, however, the approach was unlawful, the claimant asserts that he suffered a breach of his Article 8
ECHR rights, both substantively and procedurally. He further asserts that the defendant's actions violated
Article 14 ECHR.

10. It is now necessary to examine the claimant's case in more detail.

**_THE CLAIMANT_**

11. The claimant is a national of Albania, born in September 2001. His modern slavery account was that,
at the age of 16, he was enslaved in Albania by a gang who kidnapped him and forced him to sell drugs.
The resultant trauma has caused the claimant to suffer anxiety and depressive disorder, as well as to
exhibit symptoms of post-traumatic stress disorder. The claimant takes antidepressant medication and
l i t bl t d i i i t f h l i l th


-----

12. The claimant arrived in the United Kingdom in 2018 and claimed asylum. He had been enabled to flee
Albania with the assistance of his uncle. Following his asylum claim, the claimant was placed into foster
care, followed by shared accommodation.

13. The claimant began a long course of therapy in February 2020. In November 2020, he was diagnosed
with post-traumatic stress disorder. The claimant continued with his therapy until May 2021, when the
service was terminated because of a lack of funding.

14. On 21 July 2021, the Single Competent Authority promulgated a positive conclusive grounds decision,
accepting that the claimant had been subjected to **_modern slavery. In April 2022, the claimant_**
recommenced psychological therapy. On 21 June 2022, his counsellor reported that the claimant was a
very vulnerable young man who had been struggling to manage his mental health over a number of years.
The counsellor concluded that it was unlikely that there would be any improvement in the claimant's mental
well-being until such time as the claimant felt safe and stable in the United Kingdom.

**_THE JUDICIAL REVIEW_**

15. In July 2022, the claimant's solicitors sent a pre-action protocol letter to the defendant, challenging the
defendant's delay in determining the claimant's asylum claim.

16. On 1 December 2022, the claimant commenced the present judicial review proceedings. These sought
to challenge what was then the “ongoing refusal since 21 July 2021 (the date of the claimant's conclusive
grounds decision) to make a decision on whether the claimant is entitled to leave to remain as a victim of
**_modern slavery…”. It was said that there was evidence that the ongoing threat of removal of the claimant_**
was impeding his psychological recovery and aggravating his mental ill health. At the time, the claimant's
appeal against the refusal of his asylum claim was pending before the First-tier Tribunal.

17. Paragraph 3 of the statement of facts and grounds asserts that the defendant appeared to be
operating an unpublished, blanket policy. She would not make a decision on a confirmed victim's
entitlement to ECAT leave until the defendant had considered the implications of the judgment in KTT.
Paragraph 5 asserted that there was some 600 confirmed victims of trafficking in the United Kingdom who
had claimed asylum and who would in principle be entitled to ECAT leave in consequence of the judgment
in KTT. Amongst other matters, a declaration was sought by the claimant that the defendant's unpublished
policy was unlawful.

18. On 23 December 2022, the defendant filed an acknowledgement of service. This contained the
statement the defendant had agreed to grant the claimant discretionary leave for a period of 12 months. On
that basis, the claimant was invited to withdraw his judicial review. The claimant did not do so. On 18
January 2023, the defendant granted the claimant 12 months' “ECAT leave”, on the express basis that it
was accepted, in the light of the information supplied by the claimant, that he had a continuing need for
counselling.

19. On 8 March 2023, Lang J granted permission and made an anonymity order in respect of the claimant.
On 6 April 2023, the claimant wrote to the defendant, _inter alia, seeking disclosure of “details of the_
unpublished policy of suspending or deferring ECAT leave decisions of confirmed victims of trafficking in
light of KTT”…”. It was stated that the claimant intended to make a CPR Part 18 request if the information
was not provided. That included the number of confirmed victims whose decisions had been placed on
hold.

20. As amended, ground 1 challenges the defendant's refusal from 21 July 2021 to 18 January 2023 to
consider the claimant's entitlement to ECAT leave as being unlawful, contrary to the claimant's ECAT leave
policy and _Wednesbury unreasonable. Ground 2 asserts that the defendant's refusal from 21 July 2021_
until 18 January 2023 to consider the claimant's entitlement to ECAT leave breached his rights under
Article 4 and/or Article 8 of the ECHR. I note here that the Article 4 ECHR challenge is not pursued.
Ground 3 asserts that the defendant's decision to defer consideration of the claimant's entitlement to ECAT
leave breached his rights under Article 14 ECHR, read with Articles 4 and/or 8 and/or Article 1 Protocol 1.

**_THE DEFENDANT'S RESPONSE TO KTT_**


-----

21. I turn to the evidence concerning the defendant's decision making in the wake of the judgment and
order in KTT. At this stage, I am concerned only to set out the evidence in an essentially chronological
manner. The latter part of this judgment will examine when and how some of this evidence came to light in
the context of the defendant's duty of candour and the related issue of redactions of documents by the
defendant on the asserted grounds of lack of relevance and legal professional privilege.

22. On 29 November 2021, the defendant informed the claimant's solicitors, Asylum Aid, that a provisional
decision had been made in the case of the claimant. This decision regarding leave to remain under ECAT
was said to be going through internal checks. The deadline for the checking process was 8 December
2021. The defendant refused to disclose the decision letter of 29 November but did so during the course of
the hearing (see below).

23. On 9 December 2021, Asylum Aid pointed out that the deadline for internal checks had passed. They
asked to know the position regarding the decision on modern slavery leave. There was no response from
the defendant.

24. On 23 December 2021, the Court of Appeal refused the defendant's application for a stay on that part
of the order of Linden J which required the defendant to make a fresh decision on the application for leave
made by KTT. The fact that the defendant was not seeking a stay on the declaration made by Linden J,
which plainly had relevance to others in the same position as KTT, was noted by Underhill LJ in his
reasons for refusing the stay. Also on 23 December 2021, the defendant granted KTT **_modern slavery_**
leave.

25. On 19 January 2022, the defendant's Assistant Director to the Trafficking Litigation Lead at the
**_Modern Slavery Unit sought ministerial agreement to a proposed operational handling of discretionary_**
leave decisions, following the judgment in KTT. Attached to the Assistant Director's e-mail was a
submission entitled “Operational handling of Discretionary Leave decisions post judgment in KTT v SSHD.”
This noted the refusal by the Court of Appeal of a stay on the mandatory order of Linden J. The submission
sought ministerial agreement “for how we proceed in making decisions in similar cases, until such time as
our appeal against the judgment reaches conclusion”. Express reference was made to the “KTT cohort that is - cases where an individual has received a positive conclusive grounds decision but is still awaiting
the outcome of their asylum claim.” The effect of the judgment in KTT was that this cohort was “in scope of
a consideration of a grant of leave... where the asylum claim was based on a fear of re-trafficking”.
Hitherto, decisions on whether to grant **_modern slavery leave had been deferred, where the person_**
concerned had made an asylum claim. In the light of KTT, such decisions should, the document noted, no
longer be deferred and a person within the KTT cohort should be granted a period of temporary leave, from
the date of the conclusive grounds decision to when their asylum claim case had concluded. It was said
that data as of mid-January 2022 demonstrated that there were about 800 cases involving individuals
awaiting a discretionary leave decision who also had an outstanding asylum claim. To further refine how
many of these cases fell within the scope of the KTT judgment would require further work. The memo
noted that where a decision was made to grant leave, “the individual will have access to mainstream
benefits.”

26. The memo referred to “four options for taking decisions set out at paragraph 7”. As originally disclosed,
the whole of paragraph 7 was redacted. The memo stated that Options A, C and D were not recommended
and that the recommendation was to pursue Option B.

27. A further Part 18 request by the claimant resulted in the defendant providing information on Options AD, in the GLD's letter of 26 September 2023. The options were:
Option A - decision making functions continuing as usual, not factoring in the findings of KTT.

Option B - decision making functions continuing as usual but for any victim of **_modern slavery with an_**
outstanding asylum claim, the modern slavery discretionary leave decision was to be “held.”

Option C - placing a hold on decisions with outstanding asylum/protection.

Option D - granting discretionary leave in accordance with KTT.


-----

28. The letter of 26 September 2023 explained that the difference between Options B and C was that all
individuals with an outstanding asylum/protection claim would have their decision “held” under Option C;
whereas Option B would still allow decision making to take place where an individual could be granted
discretionary leave under the existing policy.

29.  On 19 January 2022, an email to the defendant's Private Secretary said that “a decision is required to
reduce legal risk and inconsistency in practice.” On 26 January 2022, the Assistant Private Secretary to the
Minister for Safeguarding raised questions about the litigation risks associated with the options for
decision. On 28 January 2022, in an e-mail to “SCA Blue Command - all staff”, the defendant appears to
have instructed staff to pause all modern slavery leave decisions on the KTT basis for confirmed victims
of trafficking who had claimed asylum. The instruction was redacted on the grounds of asserted litigation
and legal advice privilege. When faced with the claimant's Part 18 request, the defendant explained that
the instruction concerned only the service of what, ignoring the right to KTT leave, would have been
refusals of modern slavery leave. It was these cases that were placed on hold pending the defendant's
final position following the KTT judgment. Individuals who were entitled to discretionary leave on some
other basis, in accordance with the discretionary leave policy, continued to have decisions made.
Decisions were not halted for those who were eligible for a grant of discretionary leave on a non- KTT
basis or for those who did not have a pending asylum decision.

30. It is clear from the letter of 26 September 2023 that the instruction was to put the case on hold,
irrespective of whether the re-trafficking risk on return was at issue in the asylum claim. Accordingly, the
KTT cohort comprised a wider category than that contained in Linden J's declaration.

31. In paragraph 42 of the amended detailed grounds of defence, the defendant accepts that during “this
period of pause” the defendant did, in fact, address the position of individuals “who brought or threatened
judicial review challenges... The Defendant contends that this was an entirely reasonable approach; since
the time limits for bringing and responding to judicial review challenges are short, the Defendant had no
choice but to respond to such challenges or potential challenges within fairly brief time periods, and she did
so”. This is said, however, not to affect the defendant's entitlement, at a more general level, to take time to
consider the implications of KTT, both at first instance and on appeal, and to pause, insofar as was
possible, the taking of decisions during that period.

32. On 31 January 2022, the defendant's National Referral Mechanism (“NRM”) technical specialist emailed the defendant's NRM's team with an instruction “to mitigate further legal challenges”. Decision
makers should not serve any Option 1 letter unless advised to do so. If unsure, they should attend a “DL
Drop-In or seek advice from the Chief Caseworking Unit”. The GLD's letter of 20 September 2023 to
Asylum Aid explains that Option 1 was a decision to refuse discretionary leave to an individual who had an
extant asylum claim but who did not meet the criteria for discretionary leave because they were not
assisting the police/authorities with the investigation; were not pursuing a claim for compensation; and their
personal circumstances did not require a grant of discretionary leave. I observe that this last condition
ignores the effect of KTT.

33. The message of 31 January 2022 asked for Option 1 decisions to go before what the GLD letter
describes as a “second pair of eyes” process for refusal decisions; but with a reminder that these decisions
“cannot be served until further notice”.

34. From all this, the claimant contends it is tolerably clear that the defendant's plan was “deliberately not
to serve decisions that should have been served under the published policy, so that those who were
affected were unable to bring effective legal challenges.”

35. On 3 February 2022, the defendant confirmed her agreement to Option B; namely that “decision
making functions [continued] as usual but for any victim of **_modern slavery with an outstanding asylum_**
claim the **_modern slavery discretionary leave decision to be “held””. On 10 March 2022, the defendant_**
responded to Asylum Aid to apologise for the delay in making the claimant's discretionary leave decision.
The defendant said that there were certain types of discretionary leave decision that the defendant was
“currently unable to serve, causing delays to the process.” The letter enclosed a blank personal


-----

circumstances questionnaire form, thereby (according to the claimant) generating the impression that the
decision was still being progressed.

36. On 17 March 2022, the Court of Appeal upheld the judgment of Linden J: R (EOG and KTT) the
Secretary of State for the Home Department [2023] QB 351.

37. On 13 March 2022, Asylum Aid replied to the defendant, re-appending the questionnaire for a third
time and requesting that a decision be made urgently. On 14 April 2022, according to the GLD's letter of 20
September 2023, the claimant's case was assessed and an Option 1 letter drafted. The letter was checked
by the second pair of eyes on 31 May 2022 and placed on hold. The defendant refused to disclose a copy
of the decision letter of 14 April 2022 but did so during the course of the hearing (see below).

38. On 18 April 2022, Asylum Aid sent a pre-action letter in respect of the delay and on 26 April 2022 the
defendant responded, committing to determine the asylum claim within three months.

[39. On 27 April 2022, the Nationality and Borders Act 2022 received Royal Assent. The effect of section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)
65(2)(a) is for leave to remain to be granted in accordance with the construction of article 14(1)(a) of ECAT
which the defendant had unsuccessfully sought to advance in the KTT litigation. Section 65 was not at that
stage brought into force.

40. On 8 July 2022, the Deputy Chief Caseworker at the Single Competent Authority sent an e-mail to
staff, stating that all discretionary leave decisions affected by KTT remained on hold. On 11 July 2022, the
Deputy Chief Caseworker e-mailed staff again, recording the advice that Option 1 letters where there was
an open asylum claim should be put on hold. The e-mail said that this guidance “is for internal use only and
should not be disclosed to external stakeholders”. If anyone was contacted regarding the KTT judgment or
a decision that was on hold, the matter was to be forwarded to the “Tech Spec inbox for the team to
respond.” If the case was to be put on hold, “do not draft an Option 1 or full refusal letter”.

41. The defendant has confirmed to the claimant that the reference in the 11 July 2022 e-mail to previous
advice was a reference to the instruction not to serve Option 1 letters. The only substantive change to the
approach taken since January 2022 was, according to the defendant, to include individuals who had
“outstanding further submissions” and not just “first time asylum claims” within the cohort of those whose
decisions were being paused.

42. I have already made reference to the pre-action correspondence in connection with the present
proceedings. When Asylum Aid served a further pre-action letter on 27 October 2022, it enclosed the letter
of 25 October 2022, confirming that the claimant's therapy remained ongoing and that the claimant's ill
health was connected with his fear of removal. A letter from a social worker was also enclosed, explaining
that the claimant's inability to work was impeding his psychological recovery.

43. On 28 October 2022, the Supreme Court refused the defendant permission to appeal against the
judgment of the Court of Appeal in R (EOG and KTT).

44. On 11 January 2023, a further submission was made to Ministers. The defendant's Policy Lead for
Victim Support sought approval for a proposal to address the judgment of the Court of Appeal. The
proposal was that, from 30 January 2023, there should be a change in policy for permission to stay for
victims of human trafficking or slavery, in order to give effect to ECAT 14.1(b) only. “This would mean that
the express policy intent was that compliance with article 14(1)(a) is at most an aspiration with expressly
no intention to comply in full or at all at present”. A second submission, appended to the e-mail but heavily
redacted on the asserted grounds of litigation and legal advice privilege, indicated that the change in
direction was materially motivated by the litigation risks associated with failing to implement the judgment
in KTT. This submission noted that the defendant was receiving challenges from individuals who claimed
they were eligible for leave to remain, following KTT. It said that generally “we have delayed granting leave
to remain to eligible individuals under the KTT judgment until a policy has been published... We are
granting discretionary leave with recourse to public funds... Without a published policy we risk inefficient
and inconsistent decision making…”. It was said that further advice would be provided in due course on the
approach to be taken to the approximately 1500 individuals who were currently eligible for a consideration


-----

of leave to remain as result of KTT. Options were “being worked through with a view to mitigating the
operational impact whilst reducing policy and legal risks.”

45. The submission explained that there might be adverse political consequences as a result of not
complying with article 14(1)(a) of ECAT but that nonetheless this option was preferable to the alternative
option of implementing the KTT judgment. The reputational impact of changing policy was said to have
been carefully considered, including “how this will be viewed by both stakeholders and senior
parliamentarians, specifically Rt Hon Sir Iain Duncan Smith and Rt Hon Mrs Theresa May.” It was
[explained that during the passage of the Bill for the Nationality and Borders Act 2022,“we did not expressly](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)
state that Section 65 intended to fulfil a maximalist approach to ECAT compliance, however we did say that
it was in line with our international obligations... and clarified the policy set out in the **_Modern Slavery_**
Discretionary Leave Guidance. This may lead to further criticism....” The alternative option of implementing
the KTT judgment and maintaining a commitment to give full effect to article 14 of ECAT would have
“significant operational implications” and would be likely to impact “our ability to clear the asylum legacy
backlog by the end of December 2023 and achieve increased removals to Albania due to the resource
required to casework these cases”.

46. On 17 January 2023, it was confirmed that the defendant had agreed to the recommendation. On 27
January 2023, a further submission was made to Ministers. This sought agreement to “allow for leave to
remain to be granted to individuals with a positive conclusive grounds decision and outstanding asylum
claim (or further submissions) on the basis of a risk of re-trafficking as of 30 January 2023 as a result of the
KTT judgment”. It was said that there were approximately 1500 cases “stayed behind the KTT judgment
which need a short-term solution”. The recommendation was to grant members of this cohort 12 months
leave where the asylum claims or further submissions were based on fear of re-trafficking. This was
estimated to be 80% of the cohort of 1500 victims but the data was currently being reviewed. The
alternative, which was to determine the entitlement of this cohort in accordance with the process that would
be authorised by section 65 of the 2022 Act, was not recommended, on the basis that there would likely be
“reputational impact... because we have not processed these cases in a timely manner, and that delay has
disadvantaged the cohort, which may be presented negatively externally given the cohort's status as
vulnerable due to their confirmed status as victims of modern slavery”.

47. On 30 January 2023, section 65 of the 2022 Act was brought into force. Also on that day, the
defendant rescinded the published MSL policy, replacing it with guidance on “Temporary permission to
stay considerations for victims of trafficking or slavery,” in which the defendant “elected… to no longer give
effect to Article 14(1)(a) of ECAT…”. On 31 January 2023, decision making under the new guidance
commenced.

48. On 14 February 2023, an official responded to a question about the submission of 27 January, which
had been raised by the defendant's Private Office. The question was whether “doing nothing” was an
option. The response was that it was not an option that could be recommended. The official noted that
judicial reviews continued to be lodged on grounds linked to the delay in implementing the KTT judgment.
Locally held data indicated a total of 63 such judicial reviews being launched to date. The official had also
seen 96 KTT-related pre-action protocols; a number which was said to have risen incrementally.

49. On 16 March 2023, the defendant published updated guidance on Discretionary Leave (Version 10.0).
Under the heading “Modern slavery cases (including human trafficking)” it was said that individuals who
before 30 January 2023 had both a positive conclusive grounds decision and had made an asylum claim or
further submissions, based in a material part on a claim to a well-founded fear of re-trafficking/real risk of
serious harm due to re trafficking, which had not been finally determined, were potentially entitled to
discretionary leave, had their applications for leave been determined under the Home Office policies prior
to 30 January 2023. Such persons were not to have their applications for discretionary leave determined
under the new policy (described above). Instead, where a competent authority had made a positive
conclusive grounds decision prior to 30 January 2023 and the individual had prior to that date articulated
an asylum claim or further submissions which were trafficking-related and the individual's asylum claim or
submission “have at the present date not yet been finally determined (this means that they are still awaiting
a decision or still have in country appeal rights to exercise)” then “you must consider granting DL DL


-----

would normally be granted in these circumstances”. I record here that the claimant could not benefit from
this policy as he had by then already been granted **_modern slavery leave in response to these_**
proceedings.

**_DID THE DEFENDANT ACT UNLAWFULLY?_**

50. For the claimant, Mr Buttler KC relied upon the judgments of the Supreme Court in R (Lumba) v
Secretary of State for the Home Department [2012] 1 AC 245. At paragraph 20, Lord Dyson held that a
policy “if unpublished, …must not be inconsistent with any published policy”. At paragraph 26, Lord Dyson
recorded the defendant's acceptance that a decision-maker must follow his published policy and not some
different unpublished policy “unless there are good reasons for not doing so”. Lord Dyson noted that in R
(Nadarajah) v Secretary of State for the Home Department [2004] INLR 139, Lord Phillips MR had said “the
Secretary of State could not rely on an aspect of his unpublished policy to render lawful that which was at
odds with his published policy”.

51. At paragraph 34, Lord Dyson held that the “rule of law calls for a transparent statement by the
executive of the circumstances in which the broad statutory criteria will be exercised”.

52. Mr Buttler also relied upon R(Anufrijeva) v Secretary of State for the Home Department and another

[2004] 1 AC 604. There, the House of Lords identified a constitutional principle which requires an
administrative decision which is adverse to an individual to be communicated to that individual before the
decision can have the character of a determination with legal effect, thereby enabling the individual to
challenge the decision in the courts if they so wish. At paragraph 28 of the judgments, Lord Steyn
described this principle as “the antithesis of such a state [as] was described by Kafka, a state where the
rights of individuals are overwritten by hole in the corner decisions or knocks on doors in the early hours.
That is not our system …” At paragraph 31, Lord Steyn held that it was of importance to an individual to be
informed of the decision “so that he or she can decide what to do. Moreover neither cost nor administrative
convenience can in such a case conceivably justify a different approach”.

53. The starting point for this aspect of the claimant's case ought to be obvious; but in view of the
defendant's actions it nevertheless requires to be clearly and emphatically stated. The declaration
contained in the order made by Linden J in KTT represented the law. Unless and until disturbed on appeal,
it was an authoritative statement of what the defendant's published policy meant. It meant that in the
passage of Discretionary Leave Considerations for Victims of **_Modern Slavery Version 4.0 which stated_**
“Discretionary leave may be considered under the specific policy where the SCA has made a positive
conclusive grounds decision that an individual is a victim of modern slavery **and they satisfy one of the**
following criteria: leave is necessary owing to personal circumstances...”, the reference to leave being
“necessary” was not to be read at face value. Rather, as the declaration made plain, what needed to be
“necessary” was the individual's “stay” in the United Kingdom, as that expression was understood in article
14 (1)(a) of ECAT. This was the way in which certain individuals could obtain leave to remain because their
stay was necessary to pursue an asylum claim based upon a fear of re-trafficking.

54. So long as the wording set out above formed part of the defendant's published policy, the defendant
had to interpret it in accordance with the declaration of Linden J, unless and until that declaration was
disturbed on appeal. At no time did the defendant secure a stay on the operation of that declaration. As I
have explained, the Court of Appeal was not even asked to impose such a stay.

55. The defendant was, of course, at liberty to amend the relevant policy. It had been the defendant's
decision to create a policy which gave effect to article 14 of ECAT. The defendant could, therefore, have
decided that the policy should be abrogated or amended if she did not wish to accept the judgment in KTT.
Not only did the defendant not do that, however, a new iteration of the policy (Version 5.0) was published
on 10 December 2021, almost two months after Linden J gave judgment. In Version 5.0, the passage set
out above was reproduced in identical terms to that in Version 4.0.

56. For the defendant, Ms McGahey KC emphasised that the defendant was entitled to seek to overturn
the decision in KTT, both in the Court of Appeal and in the Supreme Court. Ms McGahey submitted that
until the ultimate fate of the declaration was known, the defendant was entitled to pause decision making in


-----

respect of the KTT cohort. It would not, she said, have been appropriate to make decisions during this time
on the basis that Linden J was correct in his interpretation of the defendant's policy, only to find that a
higher court concluded otherwise.

57. This is undoubtedly correct. As in the case of any other disappointed litigant, the defendant has the
right to pursue all available avenues of appeal, as well as procedural mitigations, such as the imposition of
a stay. The problem, however, which was of the defendant's own making, was that, in the meantime, the
defendant was saying to the world, through the published policy (as interpreted by the declaration) that
individuals falling within the ambit of the declaration could be granted discretionary leave to remain in the
United Kingdom when, in reality, the defendant's officials had been instructed not to issue decisions to
those who had sought such leave (and, indeed, others who had claimed asylum on grounds other than a
fear of re-trafficking).

58. It is here that the claimant 's complaint about a “secret policy” comes into sharp focus. In the light of
what I have said about the defendant's ability to revoke or amend the ECAT policy, it would have been
perfectly possible for the defendant to have published an amendment, explaining that until the ultimate
stage of the KTT litigation was known, the defendant would, as a general matter, not be making decisions
in respect of those covered by the declaration or, indeed, in respect of a wider group just described. I
accept that there might have been a political price to pay if, in the light of Linden J's judgment, the
defendant had at that point decided (without the protective covering of section 65 of the 2022 Act) to take
the more extreme step of amending the policy so as to exclude the KTT group or some larger category. I
also accept that there may even have been political ramifications if the defendant had merely amended the
policy in order to pause decision making, in the way I have described. Political considerations of this kind
cannot, however, be allowed to dilute the important “rule of law” principles articulated in Lumba and
Anufrijeva. They may explain the defendant's actions but they can in no way excuse breaking the law.

59. As Mr Buttler pointed out in reply, there is, in fact, a striking precedent, in the very context with which
we are concerned, of the defendant amending the discretionary leave policy for victims of modern slavery
in order to pause decision making in the light of the judgment of a court: namely, that of the Court of
Appeal in R (PK) (Ghana) v the Secretary of State the Home Department _[2018] EWCA Civ 98. In that_
case, the Court of Appeal held that the defendant's policy, as then in force, failed properly to reflect article
14(1)(a) of ECAT because it imposed a requirement to show “compelling personal circumstances”, which
was a higher threshold that the concept of necessity articulated in article 14(1)(a).

60. In the wake of PK (Ghana), the defendant published, on 21 February 2018, “Interim operational
guidance: Discretionary leave for victims of modern slavery” (Version 1.0). In this, the defendant's officials
were told as follows:
“you must **pause decision-making where you are not minded to grant discretionary leave to remain for**
any confirmed victim of **_modern slavery. A confirmed victim of_** **_modern slavery is an individual with a_**
positive conclusive grounds decision. All refusal decisions must be placed on hold.

The only exception is where the confirmed victim has been granted refugee leave. In these cases, you can
issue a refusal of discretionary leave as normal.

In cases where you are issuing a positive conclusive grounds decision and you are not minded to grant
discretionary leave you should issue the grant letter template.” (Original emphasis)

61. A similar approach could have been taken in the present case. Instead, the defendant adopted a policy
or practice in the light of KTT, which was not given effect by amending or supplementing the published
policy in Version 4.0 or Version 5.0, with the result that affected individuals and those advising them had no
proper means of knowing what the true position was. The position is, I find, directly analogous to that in
Lumba.

62. Ms McGahey submitted that this crucial aspect of the claimant's challenge, as articulated by Mr Buttler
at the hearing, was not to be found in the pleaded grounds. That is, with respect, wrong. In paragraph 3 of
the claimant's amended Statement of Facts and Grounds (for which permission to amend was granted by
consent on 18 July 2023) it is asserted that the defendant “appeared to be operating an unpublished


-----

blanket policy that she will not make a decision on a confirmed victim's entitlement to ECAT leave until she
has considered the implications of that judgment” i.e. KTT. Paragraph 5 of the grounds “places at issue a
blanket and unpublished policy”, as to which “the Court will need to consider its legality. [The claimant] also
seeks a declaration that the unpublished policy is unlawful.”

63. The defendant cannot, on the state of the evidence, deny that what the defendant's officials were
being told to do (or not to do) falls to be treated as a policy. The instructions were of a generalised nature,
bearing upon a particular class of person. However the defendant might wish to categorise them, the
instructions were a material departure from the published policy, as it had to be interpreted in the light of
the declaration of Linden J. It was a variation or modification of that policy and, thus, itself a policy.

64. For the purpose of establishing Lumba illegality, it matters not whether, as a general matter, decisions
were still being made in respect of individuals, but not being served on them, which is what the claimant
contends, or whether, as the defendant argues, decision making was being paused for reasons that were
withheld from public gaze. That said, I find that, in the case of the claimant, decisions in the proper sense
of the word, refusing leave to remain by reference to his medical needs, were, in fact, made and then
placed on file, rather than being communicated to him. I refer particularly to the evidence wherein the
claimant was in effect given to understand that his decision was being examined by the second pair of
eyes; and the evidence concerning the invitation to complete yet another questionnaire. At the very least,
the claimant was being given every reason to think that his case was being progressed when, in reality, it
was not. I shall have more to say about this issue later.

65. The only way in which the defendant could avoid the consequences of operating a secret Lumba-style
policy would be to seek to characterise the instructions as, in effect, exceptions to the defendant's
published policy. As is well known, the owner of a policy may depart from it, where there are good reasons
to do so. The problem here, however, is that the person concerned is entitled to be informed that the
decision maker has departed from the policy in their case. As can be seen from the materials, that simply
did not happen.

66. The defendant contends that, in the circumstances of the present case, the principle that a person who
is subject to an adverse decision is entitled to be informed of it does not apply because those in the
position of the claimant could bring a judicial review on the basis that the defendant's delay in dealing with
their case was unlawful. That, after all, was what the claimant eventually did. So too did others similarly
affected.

67. I emphatically reject that submission. Where, in contrast to a decision-maker's publicly articulated
stance, she has instructed officials not to make decisions, or to make them and withhold them, it is no
answer at all to expect the individuals concerned to suffer the trouble and expense of having to bring legal
proceedings in order to discover why the decisions are not being made or communicated.

68. As can be seen from the preceding account, however, at this point the defendant's position becomes
even more problematic. When judicial reviews were brought, the defendant's response was not to explain
that decisions were being held back or not made whilst the defendant attempted to challenge the decision
in KTT. That would have been possible, albeit that, at this stage, it would not have resolved the defendant's
Lumba problem. Instead, the defendant's reaction, upon being faced with such a judicial review, was to
grant discretionary leave to the person who had brought the proceedings.

69. The defendant contends that this response, when faced with judicial reviews, was appropriate. As Ms
McGahey said, a judicial review “needs to be answered” and there are tight time limits within which this
needs to be done. To adopt Ms McGahey's metaphor, it was, accordingly, reasonable to move the cases of
those who brought judicial review to the top of the queue of those affected by the judgment in KTT.

70. I regret that I find this purported justification entirely inadequate. It would have been possible and,
indeed, compatible with the (albeit unpublished) policy of pausing/withholding decisions in the light of KTT
for the defendant to have said that was what she was doing, when faced with a judicial review. Instead, as
the materials reveal, the response was to offer discretionary leave to remain. Not only did that rob the
policy of coherence, it strongly supports the claimant's contention that leave to remain was offered in these


-----

circumstances precisely in order to keep the policy secret. And so it would have remained, but for the work
of Alison Pickup and her colleagues at Asylum Aid who (as her statement and exhibits show) diligently
assembled information from others acting for victims of **_modern slavery, which led to the claimant_**
pursuing this claim, notwithstanding that he had been granted leave, and thus bringing the evidence set out
above into the light of day.

71. There is a further point to make. The defendant's instructions to officials meant that an individual would
receive a discretionary grant of leave, notwithstanding KTT, if this was considered to be necessary
because of the individual's need for medical treatment. The claimant, however, was originally found by the
defendant not to be entitled to leave in that regard. This emerges from the materials I described above. It
was only when the defendant was supplied with further evidence at the pre-action stage of the present
proceedings that the defendant apparently concluded that the claimant was entitled to leave on this
ground.

72. Mr Buttler submitted that the effect of the secret policy was, in the claimant's case, to deny him
knowledge of the earlier negative decision on that ground and, thus, the opportunity of challenging that
decision at the stage when it would (but for the secret policy) have been communicated to him. I agree that
this was the effect of the policy on the claimant. I will return to what this means when examining the issue
concerning Article 8 ECHR.

73.  The defendant argues that all of the above is, in effect, immaterial because the claimant and others in
his position were not going to be removed from the United Kingdom in any event. They had an extant claim
to asylum with the result that, pursuant to section 77 of the 2002 Act, they could not be removed.

74. I shall return to this issue in the context of Article 8, so far as concerns the claimant's individual
circumstances. As a general proposition, however, the submission can in no sense save the day for the
defendant on the primary issue of unlawfulness. In KTT, Linden J concluded that the fact that the 2002 Act
prevented the person from being removed while their claim for asylum (or appeal) was pending did not
mean they were unable to put forward a case for leave on the basis of article 14(1)(a) of ECAT. As he
pointed out in paragraph 91 of the judgment, if the position were otherwise, then **_modern slavery leave_**
would rarely if ever be conferred in respect of a person seeking asylum because such leave would not be
necessary to facilitate their stay. As Linden J had earlier noted (paragraph 10), the effect of refusing to
grant **_modern slavery leave was that the person concerned remained “subject to the so-called hostile_**
[immigration environment underpinned by the Immigration Act 2014”. In normal circumstances, the grant of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
discretionary leave of this kind carries with it an ability to work, study and claim “mainstream” benefits. It
therefore cannot be said that, as a general matter, the defendant's instructions to officials made no
difference to the persons within the KTT cohort.

75. The claimant accordingly succeeds on this primary matter. It is therefore necessary to turn to the issue
of Article 8 ECHR.

**_ARTICLE 8 ECHR_**

**_(a) Substantive breach_**

76. In the light of the judgment of the Court of Appeal in Malcolm v Secretary of State for Justice [2011]
_EWCA Civ 1538, it is common ground between the parties that if Article 8(1) can be shown by the claimant_
to be engaged, then the challenged decision will not be “in accordance with the law” for the purposes of
Article 8(2), in the event that I find for the claimant on the primary issue (as I have). This means that the
claimant will have suffered an actionable interference with his Article 8 ECHR right to respect for his private
and family life and it will be unnecessary to determine whether, in circumstances, that interference was
proportionate. This flows from paragraph 32 of Malcolm, where the court held (albeit _obiter) that the_
principles of public law are part of the relevant domestic law, when deciding whether the “in accordance
with the law” principle is satisfied.

77. In Mendizabal v France (Application no. 514314/99), the European Court of Human Rights found that
there had been a violation of Article 8 in the case of a Spanish national, lawfully resident in France, who


-----

from 1979 to 1989 had been issued with temporary residence permits, each valid for one year. From 1989,
she was given a series of grants of leave to remain for three months; a practice which continued until 2003,
when she was issued with a ten year residence permit. The applicant complained that the refusal over a 14
year period to issue her with a long term residence permit constituted an interference with her private and
family life.

78. It appears from paragraph 71 of the judgment that the Court concluded that Article 8 was engaged, at
least in part because of the uncontradicted fact that “the precariousness of her situation and the uncertainty
as to her fate had a significant moral and financial impact on her (casual and unskilled jobs, social and
financial difficulties, impossibility, as a result of not having a residence permit, of renting premises and
carrying on professional activity which she had undertaken in training)”. At paragraph 72, the Court found
that, even though the claimant had already been lawfully resident in France for over 14 years, she had
suffered “an undeniable interference with her private and family life”.

79. Mr Buttler submitted that, in the present case, the claimant had a right in domestic law to be granted
**_modern slavery leave from either 21 July 2021 or 29 November 2021 to 18 January 2023, which he was_**
unlawfully denied. The consequences were that the claimant could not work or get mainstream benefits.
Nor could he do other things such as become a tenant of property, hold a bank account or obtain a driving
licence. The fact that the claimant was not, in the circumstances, destitute was, according to Mr Buttler,
immaterial for this purpose. Although Ms Mendizabal had been resident in France for far longer than the
claimant had been resident in the United Kingdom, unlike him she had been able to work, albeit not in
positions for which she had been trained.

80. Mr Buttler also relied upon R (Balajigari) v Secretary of State for the Home Department [2019] 1 WLR
4647. In that case, a number of claimants contended that decisions to refuse them leave to remain in the
United Kingdom under paragraph 322(5) of the Immigration Rules, on the basis that they had dishonestly
misrepresented their earnings, engaged their rights under Article 8 ECHR. If Article 8 were engaged, then
the claimants would have been able to challenge (by way of appeal) any refusal of their human rights
claims. Mr Buttler drew particular attention to what was recorded at paragraph 81 of the judgment of
Underhill LJ, where the Balajigari claimants pointed to the legal consequences of remaining in the United
Kingdom without leave; namely, those stemming from the so-called “hostile environment”, which included
severe restrictions on the right to work, rent accommodation, have a bank account and hold a driving
licence.

81. Although, at paragraph 91, Underhill LJ did not reach a conclusion on whether those consequences
were such as to engage Article 8, he nevertheless observed that it was “not difficult to see that in some
cases some of the legal consequences of being present in the UK without leave - for example, the
inhibitions on renting accommodation - may engage Article 8; but their impact will vary from case to
case...”.

82. Ms McGahey submitted that, in the present case, there is no engagement of Article 8(1). The
claimant's anxiety centred on his fear of being returned to Albania. The grant of a temporary period of
discretionary leave pursuant to the ECAT policy would not have given the claimant reassurance in that
regard. The effect of the discretionary leave would have been merely to have permitted the claimant to
remain in the United Kingdom until his asylum claim was resolved. That, however, would have been the
position in any event, as a result of section 77 and section 78 (which prohibits removal while an appeal is
pending). Although the defendant accepted that being granted discretionary leave would have given the
claimant access to mainstream benefits and an entitlement to work, on the facts of his particular case
these were not the claimant's concern. The claimant's health was such that he was unable to work.
Although the amount of benefits would have been higher, this fact was not such as to reach the minimum
level of severity necessary to engage Article 8 ECHR. The claimant was, at the time, being supported by
his foster family. He had access to a college course. He could also have lessened any harm by bringing his
judicial review at an earlier point in time.

83. I do not accept the defendant's submissions on this issue. Beginning with the last of these, for the
reasons I have given when dealing with the primary issue, the defendant cannot be heard to say that the


-----

claimant ought to have accelerated the process of obtaining discretionary leave by bringing the judicial
review at an earlier stage.

84. As for the other submissions, before looking at the claimant's own case, it is necessary to examine the
general background, including the rationale in article 14 of ECAT for the grant of residence permit (which,
in our jurisdiction, is leave under the 1971 Act). In this regard, I agree with Mr Buttler that it is helpful to
note what Murray J recorded at paragraph 81 of his judgment in R (JP) v Secretary of State for the Home
Department and another [2020] 1 WLR 918. There, Murray J cited the evidence of Professor Katona, a
psychiatrist with undoubted experience in the immigration field, whose evidence was that a delay in
granting ECAT leave or some other form of leave to remain to a victim of trafficking makes it much more
difficult for the victim to engage fully in, and thereby benefit from, trauma-focused work. The Professor also
considered that a prolonged indefinite uncertainty of waiting for a decision was clinically distressing and
destabilising; and that an inability to work or study can increase a sense of social isolation, which is further
aggravated by difficult financial circumstances.

85. I fully accept that one cannot simply translate those findings and apply them, without more, to the
particular facts of another case. The important point being made by the claimant, however, is that the
harmful effects of having been a modern slave and the fear of becoming one again, are generally likely to
be adversely affecting the victim and, as a consequence, are likely to play a part in deciding whether a
grant of leave is necessary, if the defendant is to comply with what (at the time) was her publicly-stated
policy of giving effect to article 14 of ECAT.

86. With these general observations in mind, I turn to the claimant's witness statement of 25 November
2022. The claimant said that he would like to be granted discretionary leave as a victim of trafficking whilst
his asylum appeal was being determined “as at least this could give me some stability in the short term. I
do not know how long it will take for my asylum appeal to be finally determined, a hearing date has not yet
been set. But discretionary leave to remain would make me feel more secure.” The claimant explained that
the reason he wanted to be granted leave was “so I can feel safe, and know that I'm not going to be forced
to leave the UK and return to Albania. At the moment I feel like I am living on a cliff edge and the support I
have around me in the UK might all be taken away.” If the claimant's mental health improved, he said he
would try to return to college so he could get a qualification, with the aim of being an electrician. If he
received additional benefits, as a result of being given discretionary leave, the claimant felt he would be
able to buy healthier and better quality food, travel around London and take part in social activities “that
would help with my recovery and ongoing emotional difficulties.”

87. Ms McGahey submitted that all this is self-serving. In this regard, she drew particular attention to the
letter of 27 October 2022 from Asylum Aid to the defendant. This pre-action protocol letter referred in detail
to the opinions of those who had counselled the claimant in respect of his mental health. This medical
evidence showed that the claimant was unable to work and, moreover, that his anxiety was primarily
generated by the uncertainty caused by having to wait for an appeal in respect of his asylum claim.

88. Even if this is right, I do not find that it materially diminishes the weight to be placed upon the
claimant's witness statement. It is understandable that an individual's main focus may often be on their
asylum claim, not least if it involves an appeal to the First-tier Tribunal or the Upper Tribunal. This does
not, however, mean that the person should be taken to be indifferent towards the possibility of being
granted leave to remain by reason of being a victim of **_modern slavery. Nor does the fact that the_**
significance of having such leave may need to be explained to the person concerned mean that it falls to
be written off, in considering whether the denial of modern slavery leave constitutes a matter that bears
upon the engagement of Article 8(1).

89. I therefore find that Article 8(1) is engaged in the claimant's case. I must, accordingly, consider the
period of time that the defendant's unlawful interference with the claimant's Article 8 rights lasted.

90. The claimant submits that the period should run from 21 July 2021 to 18 January 2023. The first of
those dates was when the positive conclusive grounds decision was made by the single competent
authority in respect of the claimant. The second date was when the defendant issued a decision granting
the claimant modern slavery leave Alternatively the claimant submits that the period should run from 29


-----

November 2021. That was when the defendant confirmed to Asylum Aid that a provisional decision had
been made “subject to checks.” The defendant intimated that those checks would be completed by 8
December 2021 and thereafter the decision would be served.

91. I do not consider that 21 July 2021 represents the correct starting point for the Article 8 breach.
Assuming a lawful decision-making process on the part of the defendant, it would clearly take time for the
conclusive grounds decision to translate into the grant of discretionary leave to remain. Nor do I consider
that the 29 November 2021 is the correct starting point. The communication on that date referred to a
“provisional decision”, which was said to be “subject to checks.” The defendant was plainly entitled to carry
out such checks. I find that the correct starting point is, accordingly, 8 December 2021. That was the date
when the officials said that the checks would be completed. In the circumstances, there is no reason to
assume that - absent the illegality identified in respect of the primary issue - those checks would have had
an adverse consequence for the claimant.

92. In so concluding, I have had close regard to the witness statement of 30 November 2023 of Mr Scott
Evans of the Government Legal Department, together with exhibits. Two of these are draft letters from the
defendant to Kate Macpherson of Asylum Aid, in each case refusing the claimant leave under the Modern
**_Slavery Discretionary Leave Policy, on the basis that the claimant's medical situation did not make the_**
grant of leave necessary. They are dated 29 November 2021 and 14 April 2022. They are the letters
mentioned in paragraphs 22 and 37 above. The later letter would be relevant for present purposes only if
no significance could be attached to the letter of 29 November. The reason there are two letters is because
Asylum Aid was continuing to press the defendant for a modern slavery leave decision. These documents
had previously been withheld by the defendant in these proceedings. Their belated production is an
instance of the procedural shortcomings on the part of the defendant which I address later in this judgment.

93. Mr Evans categorises the letters as “truly draft decisions that never reached final form and are
therefore irrelevant”. I do not accept this categorisation. Unlike the letter of 14 April 2022, which has
marginal comments from the second pair of eyes, there is nothing on the face of the letter of 29 November
to indicate it was scrutinised by the second pair of eyes. What matters, however, is that the defendant
expected checks to be completed by 8 December 2021 and, as I have indicated, there is nothing to
suggest that these would have resulted in a negative decision if the defendant had applied the published
policy as it fell to be construed in the light of Linden J's declaration. The fact that this letter never reached
“final form” is immaterial if the only reason it did not do so was because of the operation of the defendant's
unlawful policy. I find there is no other discernible reason.

94. I therefore conclude that there was a substantive breach of Article 8 ECHR from 8 December 2021 to
18 January 2023.

**_(b) Procedural breach_**

95. I turn to the question of whether there was a breach of Article 8 ECHR in its procedural context. Since
it adds nothing in terms of remedy, I shall deal with this aspect somewhat briefly.

96. In R (Gudanaviciene) v the Director of Legal Aid Casework) [2015] 1 WLR 2247, the Court of Appeal
held at paragraph 69 that there was no reason why the procedural requirements inherent in Article 8 ECHR
should not apply in immigration cases. Accordingly, the question to be determined is whether the person
affected has been involved in the decision making process, viewed as a whole, to a degree sufficient to
provide them with the requisite protection of their interests (paragraph 70). The focus of the procedural
aspect of Article 8 is to ensure the effective protection of an individual's Article 8 rights.

97. Ms McGahey accepted that the success of this aspect of the claim depended upon the court's
conclusions on the primary issue. For the reasons I have given above, I find that the effect of the
defendant's policy was materially to impair the claimant's ability to use judicial review to challenge that
policy and obtain **_modern slavery leave to remain. Accordingly, this aspect of the claimant's challenge_**
also succeeds.

**_ARTICLE 14 ECHR_**


-----

98. I turn to Article 14 ECHR. Here, the claimant places reliance on JP. In that case, Murray J held that
**_modern slavery claims fell within the ambit of the rights guaranteed by Articles 4 and 8 of, and Article 1 of_**
the First Protocol to, the ECHR. In the present case, the defendant rightly takes the view that the “ambit”
requirement is satisfied by reason of Article 8 ECHR. The question, accordingly, becomes whether the
defendant has discharged the burden of proving a proportionate justification for any difference in treatment
between two persons in an analogous situation.

99. In JP, Murray J found that there had been a breach of Article 14 ECHR in that the defendant's practice
of deferring a decision on whether to grant **_modern slavery leave until after an asylum claim had been_**
finally determined, disadvantaged those who are seeking modern slavery leave and also claiming asylum.
In the present case, in addition to there being no issue regarding the ambit of Article 14 ECHR, there can
be no doubt that, just as with JP, the claimant has a relevant status within the meaning of that Article. He
has the status as an asylum-seeking victim of **_modern slavery, which is “a personal or an identifiable_**
characteristic assessed in the light of all the circumstances of the case”: Stevenson v Secretary of State for
[Work and Pensions [2017] EWCA Civ 213, paragraph 41 (Henderson LJ).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5ND3-H9N1-F0JY-C02W-00000-00&context=1519360)

100. The third requirement is for the claimant to be in an analogous situation to individuals who are treated
differently. Here, I accept the claimant's submission that victims of **_modern slavery who claim asylum_**
have the same need for modern slavery leave, pending the determination of their asylum claim, as does a
victim of **_modern slavery who does not claim asylum. To hold otherwise would be inconsistent with the_**
basic rationale of KTT.

101. Ms McGahey sought to contest the claimant's case in respect of this third matter (difference in
treatment/analogous situation), by means of the following argument. She said the claimant's case in this
respect was that the defendant ought to have issued a refusal decision in respect of the application for
**_modern slavery leave, based on medical grounds; and that the defendant did not do so because the_**
claimant was an asylum seeker. The inference was that, if the claimant had received a negative decision
on medical grounds, he would have challenged that decision. However, since bringing a judicial review
requires the claimant to bring at the same time all challenges to the alleged acts or omissions of the
defendant, the claimant would in practice have challenged the decision by reference to both the medical
issue and the refusal to make a decision on the KTT ground.

102. I do not consider that Ms McGahey's submission can be accepted. A victim of **_modern slavery_**
_simpliciter who applied for discretionary leave on medical grounds and was refused received a decision. A_
victim who made an application on medical grounds but who also had an outstanding asylum claim did not
receive a decision. That was a difference in treatment in respect of persons in an analogous situation;
namely, those who sought **_modern slavery leave on medical grounds. The opportunity to challenge the_**
negative decision accordingly arose only in the case of those who had not made an asylum claim. An
individual who, as an asylum seeker, did not get a negative decision in respect of their medical grounds
case was accordingly treated differently for no reason other than that they had made an asylum claim and
were therefore (unbeknown to them) affected by the defendant's unlawful policy. Such a person would not
know that they had been the subject of a negative medical grounds decision and would have to bring a
judicial review only by reference to what was considered by them to be an unlawful delay in the defendant's
reaching a decision in their case. The fact that such a person - if they decided to bring such a judicial
review - would likely be “rewarded” with a grant of leave cannot justify the difference in treatment.

103. Accordingly, I move to the final question under Article 14, which is whether the difference in treatment
is justified. Plainly, it was not. For the reasons I have given, the difference in treatment arose directly from
the operation of the unlawful policy.

104. The Article 14 challenge accordingly succeeds.

**_DUTY OF CANDOUR, PRIVILEGE AND IRRELEVANCE_**

105. I turn, finally, to the procedural matters foreshadowed in paragraphs 1 and 21 above. The claimant
contends that in the defendant's pre-action response letter of 22 November 2022 the defendant breached
the duty of candour in failing to disclose the existence of the unpublished policy and the fact that, pursuant


-----

to it, the defendant had taken two decisions regarding the claimant's entitlement to modern slavery leave
but not served those decisions on the claimant. Instead, the defendant incorrectly asserted that the
documents and information were possibly owned by third parties rather than the defendant and that the
claimant should file a data subject access request in order to obtain disclosure. I consider that there is
force in this criticism. The defendant has not advanced any justification for the assertion.

106. On 6 April 2023, Asylum Aid wrote to the defendant, explaining the relevance of the alleged secret
policy to the claimant's argument in the judicial review that the decision was “not in accordance with the
law” for the purposes of Article 8 ECHR. The defendant's detailed grounds of defence, filed on 26 April
2023, contained a limited admission that the defendant had paused the implementation of the published
policy. The grounds failed, however, to provide any further details and denied that the defendant was
operating an unlawful unpublished policy. The defendant also failed to engage with the claim that the
defendant's decision making was “not in accordance with the law” for the purposes of Article 8.

107. On 26 April 2023, the defendant filed no evidence and gave no disclosure alongside the detailed
grounds of defence. The claimant contends that this was a breach of the duty of candour and, as a result,
the claimant still did not know whether all confirmed victims or only a subset thereof were affected by the
unpublished policy. Nor did the claimant know when that policy came into force and whether it admitted of
any exceptions. It was at this point that Ms Pickup of Asylum Aid began contacting other legal firms and
organisations in order to obtain relevant information.

108. On 24 May 2023, the claimant filed his reply evidence, including witness statements of Ms Pickup
and Frances Lipman of Deighton Pierce Glynn Solicitors. Ms Lipman supplied details of modern slavery
cases of which she was aware in which, following the initiation of judicial review, the defendant granted, or
offered to grant, the person concerned leave to remain. Ms Pickup's witness statement explained that it
appeared the defendant was operating a practice of granting periods of leave only in response to a legal
challenge or on medical grounds, independently of the individual's right to leave on the basis of the
judgment in KTT.

109. I find myself in agreement with the claimant that, if the defendant had earlier complied with the duty of
candour and disclosed details of the unpublished policy, it would not have been necessary for the claimant
to have gone to the considerable effort of obtaining and analysing the evidence in the witness statements
of Ms Pickup and Ms Lipman. It was in the light of this information that the claimant amended his pleadings
in order to include a claim for breach of Article 14 ECHR which, as I have found, succeeds.

110. On 26 May 2023, the claimant made the first of his requests for information under Part 18 of the
CPR. The request sought, amongst other things, all records relating to the defendant's decision, policy or
practice of suspending or deferring decisions on modern slavery leave in the light of the judgment in KTT.
On 30 June 2023, the defendant wrote to commit to filing amended detailed grounds of defence within 28
days and providing a “full response” to the Part 18 request. On 3 July 2023, the claimant consented to the
28 day extension.

111. On 28 July 2023, the defendant filed and served amended detailed grounds of defence, along with
certain disclosure. The defendant admitted for the first time that an exception had been made for victims
who issued legal proceedings. Paragraph 42 of these grounds contended that it was “entirely reasonable”
for the defendant to do so and that “the defendant had no choice but to respond to such a challenges or
potential challenges within fairly brief periods, and she did so”. This did not, however, affect what was said
to be the defendant's entitlement at a more general level to take time to consider the implications of KTT
“and to pause, insofar as was possible, the taking of decisions during that period.” As I have earlier held,
that contention of the defendant was wholly unjustified. If the intention was to pause decision making, that
could and should have been explained in response to any judicial review brought on the ground that there
had been unlawful delay in reaching a decision in respect of a particular individual. To grant discretionary
leave to individuals who were in a position to bring such judicial reviews undermined the coherence of the
defendant's policy and supports the claimant's contention that granting leave in these circumstances can
only have been to minimise the risk of the policy becoming public knowledge.


-----

112. The defendant's response to the Part 18 request at this point was to serve partial disclosure, limited
to e-mails to the defendant's caseworkers containing the instructions in January and July 2022. These
were heavily redacted but no explanation was provided for the redactions. The covering letter from the
defendant asserted that the remaining disclosure required ministerial sign-off and requested an extension
until 2 August 2023. The claimant agreed to this.

113. On 1 August 2023, the defendant disclosed three submissions for ministerial approval. These were
the submissions of 19 January 2022 and 11 and 27 January 2023. The claimant contends that the
disclosure was so heavily redacted as to be largely unintelligible. No explanation was offered for the
redactions.

114. In response to a letter from the claimant of 18 August 2023, the defendant replied on 1 September
2023, asserting that the redactions were made to protect “legal professional privilege” and to “remove email addresses or other information not for entry into the public domain”. The defendant stated that no
further response to the first Part 18 request would be made. This was said to be on the basis that the
amendments made to the defendant's detailed grounds of defence were sufficient. However, as the
claimant points out, those amended grounds failed to state the date on which the unpublished policy began
or ended; to identify the cohort to whom the policy had applied; and to confirm whether the defendant had
applied it to the claimant. Furthermore, the defendant had still not pleaded to the claimant's “not in
accordance with the law” argument.

115. On 6 September 2023, the claimant made a second Part 18 request which, amongst other matters,
pointed out that much of the disclosure was unintelligible owing to redactions and that the defendant had
not adequately explained the basis for them. An explanation was also sought of the four options for
implementing the KTT judgment, which were the subject of the first ministerial submission seeking
approval for the unpublished policy but which had been completely redacted.

116. On 20 September 2023, the defendant said that decision making for the cohort affected by the
“pause” restarted on 26 April 2023. The response then purported to provide a “summary” of the four
redacted options. The claimant regarded the summary as unintelligible.

117. On 21 September 2023, the claimant served a third Part 18 request. This was done in order to try to
make sense of the unintelligible disclosure. The claimant explained that it was impossible for him fully to
assess the relevance of the defendant's disclosure and whether the duty of candour had been discharged.
On 26 September 2023, re-amended grounds of defence were filed and served by the defendant. These
now pleaded to the “not in accordance with the law” argument. On 26 September 2023, the defendant
responded to the third Part 18 request. This purported to correct the earlier summary of Options A-D, and
offered an explanation for the differences between them. The defendant stated the date when the
unpublished policy was first applied; described the cohorts affected; admitted that the unpublished policy
had been applied to the claimant; and gave disclosure of an incomplete e-mail chain relating to one of the
two unserved decisions in respect of the claimant. On 28th September 2023, the defendant wrote to the
claimant to say that the defendant was “satisfied that the redactions are privileged and that she is not
obliged to/neither will she go through the procedure that led her to the redactions”.

118. On 4 October 2023, the claimant filed a fourth Part 18 request. So far as the redactions were
concerned, the claimant pointed out that the defendant maintained the earlier refusal to identify the
categories of privilege on which the defendant was relying and refused to confirm whether lawyers subject
to professional duties to the court were involved in the process of redacting the documents.

119. The letter continued as follows:
“It is a matter of particular concern that, when pressed for a summary of redacted Options A-D presented
to the Defendant for interim implementation in consequence of the judgment in KTT, the Defendant
changed her description of redacted Option B. In her Part 18 response dated 20 September, she
summarised (redacted) Option B as “for decisions which may be impacted by an appeal of KTT v SSHD to
_be “held””. However, when pressed for the distinction between this and redacted Option C (“placing a hold_
on decisions with an outstanding asylum/protection claim”) in her Part 18 response dated 26 September,


-----

she redefined the summary of Option B… as “decision making functions continuing as usual but for any
_victim of modern slavery with an outstanding asylum claim the [MSL] decision to be “held”._

There is a big difference between “holding” decision-making and for “decision making functions to continue
_as usual”. It appears that the Defendant has glossed the description of the options and, at the same time,_
deprived the Claimant of the opportunity to check the accuracy of the description. Again, we reserve the
right to draw the Court's attention to this conduct.”

120. On 12 October 2023, the defendant responded to the fourth Part 18 request. The defendant filed and
served corrected re-amended detailed grounds of defence and explained that the defendant refused to
provide disclosure of the two unserved decisions on the grounds that they were “draft decisions never
relied on or served by my client.” By a separate letter, the defendant confirmed that reliance was placed on
both legal advice privilege and litigation privilege in respect of the redactions and confirmed that they “were
reviewed by both the GLD and counsel prior to disclosure and were properly made.”

121. On 16 October 2023, Asylum Aid wrote to explain in detail the relevance of the two unserved
decisions to the claims under Article 8 and Article 14 ECHR and gave the defendant a further opportunity
to disclose the two unserved decisions. On 24 October 2023, the defendant replied, refusing to disclose
the two unserved decisions. The defendant dismissed the claimant's letter of 16 October as “simply
conjecture about why you believe the documents are relevant and how your client would have sought to
challenge any decision if it were served”. It was said that the decisions were not relevant to the claim.

122. I have earlier referred to the witness statement of Mr Evans, so far as it addresses the decision
letters of 29 November 2021 and 14 April 2022. Mr Evans also deals with the duty of candour and the
rationale for the redactions. In this regard, he first addresses the e-mail of 28 January 2022. This was the
e-mail in which officials in the Single Competent Authority were reminded of the judgment in KTT and that
the defendant had been successful in seeking permission to appeal against it. The litigation in KTT
accordingly remained live. There was then a redacted passage, before the sentence “Decision Makers will
be informed of the outcome of the KTT appeal.” A final sentence in that paragraph was also redacted.

123. Mr Evans states that during the course of the reconsideration which followed the claimant's
application of 24 November 2023 for (amongst other things) a further explanation of, and justification for,
redactions in the light of the judgment of Swift J in IAB and others v Secretary of State for the Home
Department and Secretary of State for Levelling up, Housing and Communities _[2023] EWHC 2930_
_(Admin), Mr Evans undertook a reconsideration of the documents disclosed by the defendant in the_
present proceedings. In the course of that reconsideration, he determined that the redactions just
described were made in error. Accordingly, Mr Evans has exhibited the e-mail in a form which “un-redacts”
the passages in question. They read as follows:
“To mitigate further legal challenges, Decision Makers should **not serve any** **option 1 letters unless**
advised to do so by the Chief Caseworking Unit. If Decision Makers are unsure what to do with the case,
they should attend a DL Drop In or seek advice from the Chief Caseworking Unit.

…

Until that appeal is concluded, the above will remain in place.” (Original emphasis)

124. The fact that officials were being told not to serve Option 1 letters in order to “mitigate further legal
challenges” was, in fact, known to the claimant before receipt of the witness statement of Mr Evans. As I
have earlier recorded, the defendant had previously disclosed an e-mail of 31 January 2022, from an
official in the Single Competent Authority to other officials there, in which it was said “as per Beccy's e-mail
dated 28/01/2022, to mitigate further legal challenges this option 1 decision should **not be served until**
further notice”. (Original emphasis)

125. At the hearing, Ms McGahey was adamant that she should take responsibility for the error in
redacting the passages in the e-mail of 28 January 2022. She also pointed out the passage in the e-mail of
31 January 2022, to which I have just referred. Mr Buttler submitted that Ms McGahey's taking of
responsibility did not absolve the defendant from blame; and that it was pure happenstance that the


-----

claimant already knew, from the e-mail of 31 January 2022, what the motivation had been for not serving
the Option 1 letters. Mr Buttler submitted that the breach of the duty of candour was, as a result, serious.

126. Mr Evans' statement then deals with Options A, B, C & D in the ministerial submission of 19 January
2022. Mr Evans says that the options set out in paragraph 7 of the submission (which was redacted in its
entirety) were “set out in the context of, and by reference to, legal advice. For that reason, the whole of
paragraph 7 was redacted”. Mr Evans says that, in his response of 26 September 2023 to the claimant, he
stated that the options were:
“Option A - decision making functions continuing as usual not factoring in the findings of KTT v SSHD.

Option B - decision-making functions continuing as usual but for any victim of **_modern slavery with an_**
outstanding asylum claim the MSDL decision to be “held”.

Option C - placing a hold on decisions with an outstanding asylum/protection claim.

Option D - grant discretionary leave in accordance with KTT v SSHD.”

127. Mr Evans says that the wording he used in his letter of 26 September 2023 was “not my own
interpretation of the options but a close representation of the options as set out in the submission of 19
January 2022”. For what he describes as “the utmost clarity,” Mr Evans reproduces in his witness
statement the “exact words used in the submission” as follows:
“Option A - decision making functions should continue as normal, as set out in paragraph 4, but not factor
in the findings of KTT v SSHD.

Option B -decision making functions should continue as normal as set out in paragraph 4 but, for any victim
of **_modern slavery with an outstanding asylum claim, the MSDL decision should be “held” “pending the_**
conclusion of the KTT appeal or asylum claim (including appeal, whichever is first)

Option C -all decisions on **_Modern Slavery Discretionary Leave, where there is an outstanding_**
asylum/protection claim should be automatically placed on hold pending the KTT appeal.

Option D - Grant a period of Discretionary Leave in accordance with the KTT judgment - that is, until the
conclusion of the individual's asylum claim.”

128. Exhibited to the witness statement of Mr Evans is a copy of the submission of 19 January 2020. In
paragraph 7, for the first time, the wording of each of the Options A to D is now unredacted, together with
text stating that Option A, Option C and Option D are “not recommended” that that Option B “is
recommended”.

129. Mr Evans then turns to the judgment of Swift J in IAB. Mr Evans says he understands that the
documents in IAB were very different from those being considered in the present case. In IAB, Swift J
observed that the reasons for redactions were not obvious from the context of the redactions within specific
documents. In the present case, by contrast, the documents in question were, Mr Evans says, all
generated by the defendant as she grappled with the adverse decisions in KTT, the implications of those
decisions and the options arising from them. It was, accordingly, obvious that documents created in this
context would contain significant quantities of information in respect of which legal professional privilege
could properly be claimed. There was even express reference in the submission of 19 January 2022 to the
fact that counsel's advice had been incorporated in the body of the submission. Nevertheless, Mr Evans
confirms that, apart from the exceptions described in his statement, the redactions were properly made
under either or both litigation privilege and legal advice privilege.

130. The witness statement then addresses the issue of the names of civil servants. Mr Evans confirms
that no names of civil servants had been redacted. The relevant redactions instead removed e-mail
addresses, telephone numbers and other contact details. This was explained by the defendant to the
claimant on 1 September 2023. A single redaction to an e-mail of 8 July 2022 concerned General Data
Protection Regulation matters.


-----

131. It is necessary for me to address the candour and redaction matters raised in the statement of Mr
Evans. The first concerns the error in redacting passages from the e-mail 28 January 2022. There can be
no doubt that this involves a breach of the duty of candour. Its effect on the litigation is, however,
ameliorated by the fact that the relevant information (i.e. mitigating the risk of legal challenge) has been
disclosed to the claimant, albeit that Mr Buttler attributes this merely to good fortune.

132. Ms McGahey sought to take sole responsibility for the error. The court's concern to ensure
compliance by parties with the duty of candour is not, however, to be equated with a desire to seek out and
name any individual, whether they be an official, solicitor or counsel, and lay the blame at their door. The
duty is one owed by the parties themselves. In the present case, the most important breach of the duty of
candour occurred far earlier. As the above chronology shows, all the information which the claimant has
had laboriously to drag out of the defendant should have been disclosed by, at latest, the stage when the
defendant first filed detailed grounds of defence. I consider that the honest mistake which occurred in
respect of the e-mail of 28 January 2022 (for such it plainly was) is attributable to what, at least on the facts
of the present case, appears to be an approach by the defendant to the duty of candour which I regret to
say is misconceived. It is an approach which, at almost every stage, involved revealing as little as possible,
and only then in response to specific requests from the other party. The defendant's approach in the
present case is about as far from the requirement of “laying one's cards face up on the table” as could be
imagined. It is an approach which risks committing the sort of error seen with respect to the email of 28
January 2022.

133. A graphic instance of this apparent mindset can be seen in the defendant's stance to the disclosing of
information regarding the exact nature of Options A-D. Instead of taking a proper approach to what
constitutes legal professional privilege, whereby only that which is truly privileged can be withheld, vast
amounts of the ministerial submission of 19 January 2022 were redacted, including the whole of paragraph
7, seemingly on the basis that the whole of any passage that had a privileged element within it should be
redacted in its entirety. If the correct course had been taken at the outset, with the passages containing the
actual text of the options being unredacted (as they finally have been only in the course of the hearing), a
considerable amount of effort and expense on the part of the claimant would have been avoided.

134. The present case also discloses a serious misunderstanding on the part of the defendant as to what
might qualify for redaction on the ground of irrelevance. In the context of the duty of candour, particular
care needs to be taken before material is withheld on this ground. Unless disclosure would be positively
harmful (e.g. to a third party) or would involve a wholly disproportionate amount of disclosure, material
should not, in general, be withheld on the claimed ground of irrelevance. Otherwise, there is a risk that the
duty of candour will be breached or, at the very least, that the other party may be led to assume something
untoward lies behind the refusal to disclose.

135. Again, a notable instance of these dangers can be seen in relation to the draft decisions made in
respect of the claimant. Mr Evans is, with respect, wrong to contend that because the draft decisions never
reached “final form” they must be “therefore irrelevant.” They were, on any view, documents that
specifically concerned decision-making in respect of the claimant. It seems that the defendant's thinking on
this issue is that because in the defendant's view the claimant would not be able to succeed in persuading
the court that the “draft decisions” had a material bearing on his case, the claimant and his legal team were
not entitled to see them. That, however, was a matter for submission to the court. It was emphatically not a
reason to prevent the claimant from seeing the documents.

136. I also do not understand how Mr Evans can say that the claimant's wish to see the decisions in
question went substantially beyond the claimant's pleaded case. The documents were, on the contrary,
relevant to the pleaded contention that the defendant was operating a secret policy of making, but not
serving, decisions; and that the effect of this in the claimant's case was to breach his Article 8 ECHR rights.
Even if there might be room for argument on this matter (which there is not), it lies ill with the defendant to
take such a belated point, given the procedural failures on his part.

137. I need now to turn to the judgment of Swift J in IAB. The judge held that the defendant was not
entitled, as a matter of course, to redact the names of junior civil servants from documentation disclosed in


-----

judicial review proceedings. I understand that this aspect of the judgment is under appeal. Towards the end
of his judgment, however, Swift J had this to say on the issue of procedure (which I am told is not the
subject of appeal):
“41. The parties made submissions on the procedure to be adopted by a party who wishes to disclose
redacted documents in judicial review proceedings. The principal point in issue is whether there is any
obligation on the disclosing party to explain a redaction at the point of disclosure or, whether redacted
documents may be disclosed without explanation, so that the onus is on the receiving party to make an
application for specific disclosure to see the part redacted, and the disclosing party's obligation to explain
the redaction would only arise if and when an application for specific disclosure is made.”

42. Both parties submitted that any guidance given ought to favour a process that is as simple and efficient
as possible. I entirely agree.”

43. A party disclosing a redacted document ought to explain the reason for the redaction at the point of
disclosure. The explanation need not be elaborate; the simpler and shorter it can be the better. The
explanation ought to be such that it affords the receiving party a sensible opportunity to decide whether to
apply for disclosure of the document, unredacted. The approach taken by the Secretaries of State in this
case, the provision of single word explanations, "relevance", "privilege" and so on, will rarely be sufficient.
All will depend on context. I do not consider the approach I suggest will be unduly onerous for the
disclosing party. Before deciding to provide a disclosable document in redacted form at all, the disclosing
party will have given careful thought to the reason for redaction. It is neither unreasonable nor onerous to
expect the disclosing party to reduce that reason, succinctly, to writing. A requirement to explain at the
point when the documents are served reflects in part the provision made in CPR 79.24. That Rule has no
application either to these proceedings or to the general run of judicial review claims, but is certainly a
model for an efficient and pragmatic approach.

44. When redacted documents are exhibited to a witness statement it may be appropriate for the reason
for redaction to be given in that statement. All will depend on the reason for the redaction and the identity
of the person making the witness statement. If the redaction is made on LPP grounds it will usually be
better for the explanation to be given in a witness statement made by the solicitor with conduct of the case.
If the redaction is made for some other reason, it will be for the disclosing party to decide who is best
placed to provide the explanation. Whoever provides the explanation should do so in a witness statement.
Experience shows that the process of reducing an explanation into a signed statement produces decisions
that are better considered. A party receiving a redacted document can decide, taking account of the
explanation provided, whether to apply for disclosure of an unredacted version of the document.

45. I consider that the steps sketched above will ensure matters are addressed fairly and proportionately.”

138. I have set out above what Mr Evans says about the redactions in the present case based on legal
professional privilege. I accept what he says on this issue, albeit that I do not accept the existence of
privileged passages entitled the defendant to redact to the extent he did.

139. Ms McGahey took issue with the sentence in paragraph 44 of IAB, where Swift J said that experience
shows that the process of reducing an explanation into a signed statement produces decisions that are
better considered. Ms McGahey said that neither she nor her junior, Mr Irwin, had ever come across a case
where a witness statement had been said to be necessary in order to explain redactions on the ground of
legal advice privilege. Mr Buttler concurred.

140. I do not consider that Swift J was, in fact, suggesting that there has hitherto been a practice of using
a witness statement to explain redactions on the ground of legal advice privilege or litigation privilege. His
point is that a witness statement is likely to focus minds on the extent, if any, to which privilege exists and
so prevent or at least minimise instances of “knee-jerk” or otherwise ill-considered invocations of privilege.
As the present proceedings graphically demonstrate, whatever may or may not have happened hitherto,
explaining the reasons for redactions by means of a witness statement is likely to avoid many of the
problems that have arisen in this case. What Mr Evans says at paragraphs 12 to 18 of his statement about
legal professional privilege could and (with hindsight) should have been articulated earlier, in the form of a


-----

witness statement. The fact that a matter of privilege might be “obvious” to a party does not mean it will
necessarily be obvious to the other party and the court. The same is true of redactions made on the ground
of relevance. In the present case, a timely witness statement explaining the defendant's thinking about the
“draft decisions” would plainly have been beneficial.

141. The point made by Swift J in the penultimate sentence of paragraph 44 of IAB, that reducing an
explanation into a signed statement produces decisions that are better considered, must, therefore, with
respect, be right, regardless of whether this has routinely happened hitherto in the contexts with which we
are concerned. Producing a witness statement, with its statement of truth, is an important action. The
person making it will be concerned to get it right. That is, of course, particularly so where the maker of the
statement is someone with legal professional duties. Had the redactions originally made by the defendant
in the present case been subjected to the discipline of a witness statement, it is likely that, amongst other
things, the error in the redaction of the e-mail of 28 January 2022 would not have been made.

**_DECISION_**

142. The judicial review succeeds, to the extent set out above. I invite the parties to agree, if possible, an
order that gives effect to my judgment and any consequential matters.

**End of Document**


-----

