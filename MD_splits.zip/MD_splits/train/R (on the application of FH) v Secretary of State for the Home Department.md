# R (on the application of FH) v Secretary of State for the Home Department

 [2024] EWHC 1327 (Admin)

King's Bench Division, Administrative Court (Bristol)

Farbey J

4 June 2024Judgment

**Nicola Braganza KC and Miranda Butler (instructed by DPG Law) for the Claimant**

**Edward Morgan KC** and Colin Thomann (instructed by **Government Legal Department) for the**
**Defendant**

Hearing dates: 23 and 24 January 2024; 7 and 8 March 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 4 June 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

**MRS JUSTICE FARBEY :**

**Introduction**

1. The claimant is a Kenyan national born in 1992. She has in the past lived in Oman and Qatar. Having
previously worked in the United Kingdom for three months as an overseas domestic worker in a private
household, she returned to the United Kingdom as a domestic worker on 28 June 2019.

2. The claimant states that in early August 2019, she was threatened and forced out of her employer's
house when asking for her salary. She called the police. On 4 August 2019, the police referred her to the
National Referral Mechanism (“NRM”) which is the process operated by the defendant for identifying
[victims of trafficking and modern slavery under the Modern Slavery Act 2015 (“the 2015 Act”). There are](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
two “competent authorities” within the Home Office. The Single Competent Authority (“SCA”) has been in
existence since 2019. The Immigration Enforcement Competent Authority (“IECA”) was established in
2021. The claimant was referred to the SCA where she was subject to the two-stage procedure for
identifying victims of modern slavery: the “reasonable grounds” stage and the “conclusive grounds” stage.

3. By letter dated 19 August 2019, the claimant received a positive reasonable grounds decision. By letter
dated 4 April 2023 – after launching the present proceedings – she received a positive conclusive grounds
decision.

4. The claimant applies for judicial review in relation to the defendant's delay in making the conclusive
grounds decision. Ms Nicola Braganza KC appeared with Ms Miranda Butler for the claimant. Mr Edward
Morgan KC appeared with Mr Colin Thomann for the defendant.

5. The claim has evolved over time. There are essentially three overarching grounds of challenge before
me, which I shall number for convenience as follows:


-----

i. **Ground 1: The delay in reaching a decision on the claimant's individual case was unreasonable,**
discriminatory and in breach of the claimant's rights under various articles of the European Convention on
Human Rights (“ECHR”).

ii. Ground 2: There is unlawful systemic delay in the conclusive grounds decision-making process within
the SCA as a whole.

iii. Ground 3: The failure to publish the criteria for prioritising cases for allocation to SCA decision-makers
who take conclusive grounds decisions was unlawful.

6. In support of her arguments relating to all three grounds, the claimant relies on the evidence that cases
requiring a conclusive grounds determination are allocated to decision-makers in accordance with various
criteria for prioritisation. Those criteria were written down on 9 February 2023 (that is, more than two
months after these judicial review proceedings were commenced). The February 2023 document contains
a list of categories of case in the order in which the category should be prioritised in the weekly allocation
of cases to decision-makers. For ease of reference, I shall refer to the February 2023 document as the
Prioritisation List or the List. One category in the List is cases in which a judicial review claim has been
brought or in which a pre-action protocol letter has been sent. This category is called “SCA Litigation
Cases.”  By way of amendment to the grounds of challenge after the List was disclosed to the claimant,
she contends that it was unlawful that she did not receive a conclusive grounds decision until compelled to
commence this litigation whereupon her case was prioritised in accordance with what she submits was a
secret and unlawful prioritisation policy.

7. The defendant submits that the claimant's arguments on Ground 1 should be dismissed on the basis
that they have become academic: the claimant has received a positive conclusive grounds decision. It is
not said by either party that Grounds 2 or 3 are academic or that they should not be determined on their
merits.

8. By way of relief, the claimant seeks (among other things) a declaration that the delays within the NRM,
both systemically and in her own case, were unlawful; a declaration that the failure to publish the List was
unlawful; a declaration that the List was unlawful and an order quashing it; a mandatory order that any
future Prioritisation List be published; and damages (including an amount in aggravated and exemplary
damages) for breach of her rights under articles 4 and 8 ECHR, read both with and without article 14
ECHR.

9. There are for present purposes no distinctions to be made between victims of trafficking and victims of
**_modern slavery; I use the terms interchangeably in this judgment._**

**Background to the claim**

_The history of the proceedings_

10. Having received a positive reasonable grounds decision, the claimant applied for political asylum on
11 January 2020. In a statement dated 20 May 2020, made in support of her asylum claim, she expressed
a fear for her life if returned to Kenya on the grounds that her former husband would kill or harm her. By
letter to the defendant dated 11 June 2021 the claimant's immigration solicitors (who are not the solicitors
instructed in the present claim) chased the defendant for a conclusive grounds decision. On 21 August
2021, the claimant's son was born.

11. By email to the defendant dated 17 December 2021, the immigration solicitors chased again for a
conclusive grounds decision. The email informed the defendant that the claimant was “very vulnerable and
struggling to cope with her mental stress due to the uncertainty of her immigration status.” The defendant
was asked to expedite the decision and to provide the likely timescale within which a decision would be
reached.

12. Considerable time passed with – regrettably – no response to the email. On 18 October 2022, the
claimant's present solicitors sent a letter before claim.  The defendant was asked to make a conclusive
grounds decision within 14 days; pay damages to the claimant for the unlawful delay; and confirm that the


-----

systemic delays in the NRM process would be addressed. The claimant's solicitors requested that relevant
material be disclosed in the response to the letter as part of the duty of candour.

13. On 4 November 2022, the defendant responded. The response stated that no decision would be
taken prior to the claimant's asylum interview because the asylum interview record was “a vital piece of
information which forms part of the NRM's decision making.” The defendant aimed to make the conclusive
grounds decision within eight months of the interview taking place, absent special circumstances.
However, the defendant's letter made no mention of when such an interview would take place.

14. On 20 December 2022, the claimant applied for judicial review. The claim documents included a
witness statement from the claimant setting out her claim to be a victim of trafficking and describing her
experiences (good and bad) of the support and assistance she had received as a potential victim. The
statement shows that she undertook counselling for about four months and then (after a change of
accommodation) for another two months, which helped her to come to terms with her experiences as a
victim of trafficking. In these latter two months, she did not attend counselling appointments regularly as
she was pregnant and attending English classes at a local college. She was unable to continue
counselling after giving birth to her son as she had no childcare and did not want to take her son to the
counselling sessions where he would witness her distress. She was at the time of the statement waiting to
hear whether she could enrol for further English language classes (for which childcare would be available).
The wait for her conclusive grounds decision made her feel worried and anxious all the time.

15. I have also considered the claimant's earlier witness statement lodged in other judicial review
proceedings challenging the defendant's failure to provide her with suitable accommodation under section
95 of the Immigration and Asylum Act 1999. The statement (dated 2 December 2021) refers to her
suffering flashbacks to her experiences of exploitation and her wish to undertake counselling. She does
not refer in this statement to any other mental health problems.

16. On 13 January 2023, the defendant filed an acknowledgement of service and summary grounds of
defence. On 19 January 2023, the claimant filed a reply to the summary grounds of defence.

17. At around that time, the claimant asked the defendant to issue a conclusive grounds decision based
on the witness statements already provided in the judicial review bundle. The defendant agreed to her
request and indicated that a conclusive grounds decision would be taken by 11 June 2023, absent special
circumstances.

18. By email to the claimant's solicitors dated 8 February 2023, the defendant's solicitors confirmed that
the timescale for a decision had been shortened and that a decision would be taken by 10 May 2023,
absent special circumstances. The timescale would permit the SCA to review the evidence from the
claimant. The new timescale took account of the fact that the claimant's asylum interview was due to take
place on 9 February 2023.

19. By order dated 23 February 2023, permission to apply for judicial review was refused on the papers by
HHJ Lambert sitting as a judge of the High Court. As I have mentioned, on 4 April 2023, the claimant
received a positive conclusive grounds decision.

20. On 14 April 2023, Russell Bramley – a Policy Manager in the Home Office **_Modern Slavery Unit –_**
signed a witness statement that contained the following passage:

“11. The guidance **does not provide for specific prioritisation of a case in circumstances where a**
**challenge is issued on the alleged delay of a [conclusive grounds] decision. All cases are**
progressed and decided as soon as it is possible to do so…However, the [competent authorities] maintain
operational flexibility to prioritise certain cases where practicable to do so, and this may include cases in
which ongoing legal challenges are a factor” (emphasis added).

I shall refer to this passage as the “paragraph 11 statement.”

21. On 9 June 2023, following a renewed application at an oral hearing, Eyre J granted permission to
apply for judicial review on the grounds concerning delays within the NRM. A different ground, which


-----

contended that trafficking support failed to assist victims' recovery needs, was stayed pending judgment in
_R (PM) v Secretary of State for the Home Department_ _[[2023] EWHC 1551 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68HW-W0W3-RRMB-313B-00000-00&context=1519360)_

22. I was provided with a transcript of Eyre J's ruling on the permission application in which he makes
plain that he would have refused permission save that it appeared that there was evidence that the making
of a claim to this court triggers a conclusive grounds decision. In considering whether to grant permission,
Eyre J had before him the paragraph 11 statement. In granting permission, Eyre J observed:

“6. The evidence of the Claimant is to the effect that it is the common experience of those dealing with
cases such as this that it is the making of a claim to this court which triggers a conclusive grounds
decision. In effect, those who bring proceedings are moved up the queue... **[I]t is apparent that**
**there is not a formal policy of doing that (namely moving those who make claims up the queue).**
**This is not a case of the application of an unpublished policy of the kind which the court has**
**considered in a number of cases. Rather the position is that it is at least reasonably arguable that**
the system is being operated in such a way that those who would otherwise have to delay for a period of
time can jump the queue by bringing proceedings.

7. It is playing with words to argue whether that is a matter of policy or of practice. If, in practice, the way
the system is operated is that those who would otherwise face a delay are able, by starting proceedings, to
reduce the time taken to address their application then that is arguably not a rational way of operating
the system. The guidance addressing criminal cases does not assist one way or the other on this. If the
position is that under the cover of operational flexibility case workers are conducting the system such as to
bump up the queue those who have brought proceedings then that is, at the very lowest, arguably
irrational.

8. I am not going to limit the basis on which I give permission on ground one, but I trust that those
comments make it clear the reasoning behind my grant of permission” (emphasis added).

23. On 11 July 2023, the claimant was granted refugee status. By letter dated 24 July 2023, the claimant's
solicitors made a request to the defendant for further information under CPR Part 18. The request is
convoluted and I do not set it out fully here. Among other things, the solicitors cited the paragraph 11
statement and sought disclosure of internal guidance relating to the prioritisation of cases in ongoing legal
proceedings, together with any other internal guidance relating to conclusive grounds decision-making.
They sought detailed disclosure of the defendant's records relating to the claimant, including notes that
recorded:

“a) where, when and how the decision maker in the Claimant's case took the view that the conclusive
grounds decision needed to be made post the Claimant's asylum interview;

b)  where, when and how the decision maker in the Claimant's case subsequently took the view that the
conclusive grounds decision did not need to be made post the Claimant's asylum interview…

c) the reasons and timing, and evidence of the same, of the decision maker's decision(s)…that more
evidence/information was required from the Claimant before a Conclusive Grounds decision could be
made.”

24. The Part 18 request continued:

“With reference to each of the projected dates stated for a Conclusive decision to be made, please provide
the evidence explaining the assessment of the timeframes provided...”

25. On 4 September 2023, the defendant filed detailed grounds of defence. On the same day, the
Government Legal Department (“GLD”) sent an email to the court and to the claimant's solicitors to inform
them that some of the documents served under Part 18 had not been checked for legal professional
privilege (“LPP”):

“Further to my previous e-mail… Counsel for the Defendant Colin Thomann has requested that I contact
the court and the claimant's solicitors to request that the documents emailed to the court/claimant solicitors


-----

at 16:01 today be disregarded as they have not yet undergone a legal professional privilege check. These
are documents A1-A10, B1, and C1-C6 listed under 'Request 5' in the Part 18 request response.

This was an error on my part for which I apologise and I confirm that I shall re-serve the documents upon
the court and the claimant's solicitors after they have undergone a legal professional privilege check and
appropriate redactions have been duly made.”

26. By email dated 5 September 2023, GLD informed the claimant's solicitors that they were in the
process of considering further documents recently provided by the defendant. By email dated 8
September 2023, the defendant filed and served amended detailed grounds of defence together with
further evidence in the form of a further witness statement from Mr Bramley and exhibits. GLD also sent
redacted versions of the documents which they had mistakenly served a few days earlier.

27. Among the September documents was the Prioritisation List.

28. On 20 September 2023, the claimant's solicitors sent a letter to GLD in what I regard as unduly
aggressive terms. The letter made the following accusations:

i. The redactions in the 8 September documents gave rise to concerns about inadequate disclosure.

ii. The redactions had not been explained so that GLD had breached best practice as set out in The
Administrative Court Judicial Review Guide 2023.

iii. The redactions comprised data that was relevant to issues in the claim and that did not attract LPP.

iv. The late disclosure of the List demonstrated that the defendant was guilty of non-disclosure and
misrepresentation in relation to issues in the claim. The late disclosure was a clear breach of the
defendant's duty of candour.  In particular, Eyre J had been “positively” misled at the permission hearing.

v. Mr Bramley was guilty of “personal serious breach” and was required “to promptly provide a full and
direct explanation via a sworn witness statement”. The claimant was concerned about the “truth and
reliability of his previous witness statements.”

29. The solicitors' letter asserted:

“For the avoidance of doubt, we consider that the above clearly demonstrates a **flagrant breach of the**
**Defendant's Duty of Candour involving deliberate misleading of the court and we intend to bring**
**the above to the court's attention and consider it appropriate for sanctions to be imposed for such**
**conduct, including by way of damages and costs” (emphasis added).**

30. By letter dated 26 October 2023, GLD responded. In relation to the LPP documents, the letter stated:

“We ask that you urgently confirm that you have deleted the emails they were sent with, and any record
you have of the underlying documents, by no later than 12pm on 27 October 2023. In the event that you
have passed the documents to anyone else (which may include any counsel or your client), that they also
delete the emails and any underlying documents.

Having conducted this review we are content that the redactions have been undertaken in accordance with
the Administrative Court Guide and our client's disclosure obligations.”

31. As regards the allegations of breach of the duty of candour, the letter included the defendant's apology
and the background in the following terms:

“The Home Office unreservedly apologises for the failure to disclose the document you have referred to as
the Priority List before 8 September 2023. I enclose a witness statement of Russell Bramley setting out the
circumstances giving rise to and the reasons for that failure.”

32. The letter explained that neither Counsel nor GLD had been aware of the List:

“On 26 January 2023, GLD was provided with the enclosed (and already disclosed) 19 January 2023
ministerial submission, which refers to 'a Ministerial Arrangement on 21 December to enable direct
discrimination on the grounds of nationality to allow prioritisation of Albanian cases' in the NRM and


-----

recommends that the SCA devote as much caseworker resource as possible to Albanian cases whilst
continuing to serve the priority [criminal justice] and age change cases.

However, without any waiver of privilege…we can confirm that the Home Office did not provide GLD or
counsel with a copy of the Priority List, or make GLD or counsel aware of its existence until 25 August
2023.”

33. The letter confirmed that Counsel and GLD were unaware of the Prioritisation List when Counsel made
submissions at the renewal hearing as to whether there was an unpublished policy. GLD stated that,
having received the Prioritisation List, they immediately initiated the steps necessary to ensure full
engagement with, and proper discharge of, the duty of candour. Having completed that exercise, the
Prioritisation List had been disclosed.

34. Contrary to GLD's request, the claimant's lawyers did not delete the LPP documents. The case was
listed for a short directions hearing on 14 November 2023 for the court to consider (among other things)
the allegation that the defendant was in breach of the duty of candour and the question of the status of the
LPP documents. In their written submissions for that hearing, Counsel for the claimants contended that the
LPP documents should not be deleted and that the claimant should be permitted to rely on that material to
demonstrate serious breaches of the duty of candour. They submitted that, at the renewal hearing, the
defendant had “invited the Court to reject the claim on a basis that she knew to be false” which amounted
to “an egregious and deliberate attempt to mislead the court.”

35. By letter to the court dated 13 November 2023, GLD rejected the assertion that there had been any
deliberate pattern of conduct in breach of the duty of candour. GLD noted that the claimant's written
submissions failed to deal with Mr Bramley's explanation for the late disclosure as set out in his witness
statement. The letter stated:

“We renew our request to the Claimant to delete the email correspondence attachments served in error on
4 September 2023. We received a prompt response from the Court, confirming that the attachments that
had been deleted from the court file and we are grateful for the court's co-operation. Those acting for the
Claimant do not appear to challenge the fact that the previous disclosure was made in error not by the
client. This is particularly important where, as here, there is a recognition that an error has arisen. If the
Claimants solicitors have accessed these emails, they will have noted that the attachments include
numerous duplications of the same emails.

I have taken updated instructions from my client today and can confirm that we have no objections to
unredacted copies of the emails being provided to Mr Justice Eyre to assist with the consideration of our
application dated 26 October 2023, should the Judge wish to read this material de bene esse.

We also reaffirm that the disclosure exercise is subject to on-going review. As explained by my counsel Mr
Thomann, in written submissions on behalf of the Defendant dated 10 November 2023, as this is a
challenge to a continuing policy, the Defendant will continue to review the need to update the Court and the
Claimant with any further developments.”

36. By the date of the directions hearing, the parties had reached terms of agreement that were reflected
in a consent order approved by Eyre J at the hearing. The contentious questions of duty of candour and
the LPP documents were essentially adjourned.

37. On 17 November 2023, the claimant filed and served an amended Statement of Facts and Grounds.
The ground of challenge relating to the inadequacy of trafficking support was withdrawn. A new Ground
(which I have labelled Ground 3 above) took account of the disclosure of the Prioritisation List and
contended that the defendant operates a prioritisation policy that is unlawful on the basis that it is (i)
unpublished; (ii) directly discriminatory; and (iii) unreasonable.  Read in more detail and expanded orally,
this new Ground covered indirect discrimination, article 14 ECHR and the public sector equality duty.

38. On 28 November 2023, the defendant filed and served re-amended detailed grounds of defence. A
directions hearing listed on 13 December 2023 was vacated by consent following the parties' agreement in
relation to the LPP documents. In essence, the defendant consented to the inclusion of LPP material in


-----

the claim bundle without any collateral waiver of privilege. I have been told that the defendant made this
concession in the interests of transparency and proportionality with a view to assisting the court in the
resolution of the core issues before it. I have therefore seen the LPP documents.

39. Further correspondence between the parties followed in which the claimant sought and chased further
disclosure. The net result was that the defendant provided a number of documents on 9 January 2024, a
matter of days before the hearing before me.

40. The substantive hearing of the claim was listed for two days. In an endeavour to use the second day
efficiently, I invited both parties to consider a number of issues overnight. On the second morning, soon
after Ms Braganza had re-commenced her submissions, Mr Morgan sought an adjournment. It transpired
that, during the course of taking instructions on some of the issues that I had raised, he and Mr Thomann
had been provided with information that called for additional detail and clarification. Mr Morgan and Mr
Thomann were concerned that, without an adjournment, they would not be able to ensure that the relevant
and accurate material was provided to the court. They could not be confident that the defendant's duty of
disclosure to the court had been discharged.

41. The claimant was in the unfortunate position of being unable to oppose the adjournment application as
it was plainly important that the court be provided with accurate information and that the defendant comply
with the duty of candour. The claim was therefore adjourned – with case management directions – to the
first convenient date. Before adjourning the hearing, I granted permission to apply for judicial review on
Ground 3 (which had been formulated and drafted after the renewed permission hearing).

42. During the adjournment, the defendant provided a witness statement from Charlotte Tovey (the Head
of Operations within the IECA) and a Supplementary Witness Statement from Matthew Moss (a Grade 7
Operational Leader within the SCA). In a regrettable further twist, Mr Moss came to realise that his
Supplementary Witness Statement itself contained errors. He was forced to file a further Supplementary
Witness Statement in order to correct his errors.

43. On 16 February 2024, the defendant filed and served re-re-amended detailed grounds of defence.
Given (i) the volume of pleadings; (ii) my concern to conserve public funds; and (iii) the fact that the
defendant's conduct triggered the adjournment, my case management directions for the adjourned hearing
did not require any formal amendment to the claimant's grounds of challenge. The parties exchanged
supplementary skeleton arguments for the adjourned hearing in which the claimant dealt with the various
developments.

_The LPP documents_

44. The LPP documents are plainly privileged on grounds of either LPP or litigation privilege. I was
provided with no realistic argument to the contrary. The parties' agreement that I should consider
documents revealing the defendant's legal advice and litigation strategy placed me in an invidious position.
The public interest in the courts' upholding both LPP and litigation privilege is strong. Each of those
privileges serves the interests of justice. As I mentioned during discussion with Counsel, I was tempted to
put the documents out of my mind on the basis that the resolution of the issues before me turns on the
evidence and the parties' legal submissions to me.

45. However, as it happens, the LPP documents reveal how the conclusive grounds decision came to be
taken in the present case. On around 10 January 2023, GLD advised the defendant to provide a shorter
timeframe for the decision. On around 11 January 2023, the defendant reviewed the case and agreed to
aim to take a decision by 11 August 2023 – even if there was no asylum interview beforehand – provided
that the claimant supplied a witness statement about her experiences of modern slavery. By 19 January
2023, it was clear that the claimant was not willing to provide a witness statement on the grounds that she
had already done so. In light of her refusal, the defendant brought forward the timeframe so that a decision
would be made by 11 June 2023. A shorter timeframe was not viable for resource reasons.


-----

46. Mr Thomann had been instructed by GLD and had given advice by 27 February 2023. On that date,
the GLD lawyer with conduct of the case sent an email to a number of officials which included the following
information:

“I have not received any notification of renewal but I am sure this is coming soon. Please note that when I
**discussed this case with Counsel (including the permission refusal and the high likelihood that [the**
**claimant] will renew to an [oral permission hearing], he mentioned that it would be very helpful if**
**the conclusive grounds decision can be issued by the time the [hearing] is listed. I am not sure if this**
would be possible at all, but I thought I would mention it” (emphasis added).

47. A subsequent email to a number of officials was sent with GLD's advice that the conclusive grounds
decision “is to be issued by the first week of April” and informing them that Mr Thomann would be kept
updated. In accordance with that legal advice, the conclusive grounds decision was issued in the first
week of April.

48. The LPP documents therefore demonstrate that the claimant's conclusive grounds decision was
expedited as a result of input from the defendant's lawyers. The defendant initially agreed to provide a
decision by August 2023 on legal advice from GLD. That timeframe was again brought forward to June
after the claimant refused to provide a witness statement. The claimant received a decision in April 2023
because Counsel had given advice.

**The Issues**

49. The three grounds of challenge each have a number of different elements which are reflected in the
following agreed List of Issues:

“1. Whether the Defendant has breached his duty of candour and cooperation in these proceedings. If so,
what the nature and extent of that breach is and what consequences should flow from it, including as to
relief and /or costs.

2. Whether the Claimant should be permitted to rely upon the witness statement of Professor Katona and
expert report of Dr Galappathie.

3. Whether the delays in (i) making a Conclusive Grounds decision in the Claimant's case and (ii) generally
within the NRM are unlawful and / or unreasonable.

4. Whether the Defendant has breached the Claimant's rights under Article 4 ECHR, and/or Article 8 and/or
Article 4 or Article 8 taken with Article 14.

5. Whether the Defendant's process of allocation / Prioritisation Policy / List prioritising Conclusive Grounds
decisions is unlawful, including on the following grounds:

a. Whether the Defendant / the Single Competent Authority unlawfully failed to publish a policy on
prioritisation in this respect when he was required to do so.

b. Whether the Defendant's allocation processes / Prioritisation Policy involved unlawful discrimination.

c. Whether, in devising and implementing the prioritisation of Albanian nationals' Conclusive Grounds
decisions, the Defendant had due regard to the PSED.

d. Whether Defendant's allocation process / Prioritisation Policy for Conclusive Grounds decisions is
otherwise unlawful and / or unreasonable.

6. What relief, if any, should flow from the matters above.”

50. The parties filed the following bundles:

i. A Core Bundle running to 1,736 pages;

ii. A Supplementary Bundle running to 209 pages;

iii. An Additional Bundle running to 84 pages;


-----

iv. A Defendant's Bundle running to 501 pages;

v. A Further Supplementary Bundle running to 73 pages;

vi. A Joint Authorities Bundle running to 777 pages.

vii. A Bundle of Updated Documents for Substantive Hearing on 7/8 March 2024 running to 84 pages.

51. I have found it consistently difficult to navigate the bundles. No one appears to have taken
responsibility for ensuring that the documents were presented in a logical, focused way. The volume of
documents is excessive. The basis for including large sections of the bundles is opaque. Judicial
resources have been deployed in doing what the parties ought to have done: sorting out the documents.

52. As the claim concerns the delay in the United Kingdom's processes for identifying victims of trafficking,
I shall turn next to that topic.

**The identification of victims of trafficking**

_Convention against Trafficking_

53. The Council of Europe Convention on Action against Trafficking in Human Beings (“ECAT”) was
adopted on 16 May 2005 and ratified by the United Kingdom in December 2008 with effect, as a matter of
international law, from 1 April 2009. The purpose of ECAT is (among other things) to protect the human
rights of victims of trafficking and to design a comprehensive framework for the protection and assistance
of victims (article 1(1)(b)). There is a definitional connection between trafficking and exploitation. The
latter concept includes forced labour or services, slavery or practices similar to slavery, and servitude
(article 4a). The United Kingdom's duties under ECAT apply, therefore, both to victims of trafficking and to
victims of modern slavery as the term is used in domestic law.

54. Article 10 of ECAT makes provision for the identification of victims:

“1. Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims …

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in
Article 12, paragraphs 1 and 2.”

55. Article 10 thus provides for an interim period between a reasonable grounds decision and a final
decision that a person is a victim (see the analysis in _R (EOG) v Secretary of State for the Home_
_Department_ _[2022] EWCA Civ 307, [2023] QB 351, paras 5-7)._

56. The United Kingdom has a duty to provide support to victims of trafficking in order to aid their recovery
from exploitation and abuse at the hands of their traffickers. Article 12(1) of ECAT stipulates that each
party to the Convention “shall adopt such legislative and other measures as may be necessary to assist
victims in their physical, psychological and social recovery.” The nature and extent of the required
assistance is expressly set out in article 12. It includes appropriate and secure accommodation,
psychological and material assistance, access to emergency medical treatment, translation and
interpretation services, counselling, and information about legal rights.

57. Article 13 deals with the recovery period that must be afforded to potential victims of trafficking (i.e.
those who have received a positive reasonable grounds decision):


-----

“1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in their territory.

…

3. The Parties are not bound to observe this period if grounds of public order prevent it or if it is found that
victim status is being claimed improperly.”

_Domestic law and guidance_

58. The obligations under ECAT to identify and support victims of modern slavery in the United Kingdom
have (in broad terms) been implemented by the NRM and by the promulgation of guidance. By virtue of
section 49 of the 2015 Act:

“(1) The Secretary of State must issue guidance to such public authorities and other persons as the
Secretary of State considers appropriate about—

(a) the sorts of things which indicate that a person may be a victim of slavery or human trafficking;

(b) arrangements for providing assistance and support to persons who there are reasonable grounds to
believe are victims of slavery or human trafficking or who are such victims;

(c) arrangements for determining whether there are reasonable grounds to believe that a person is a victim
of slavery or human trafficking;

(d) arrangements for determining whether a person is a victim of slavery or human trafficking.

(1A) Guidance issued under subsection (1) must, in particular, provide that the determination mentioned in
paragraph (d) is to be made on the balance of probabilities.

(2) The Secretary of State may, from time to time, revise the guidance issued under subsection (1).

(3) The Secretary of State must arrange for any guidance issued or revised under this section to be
published in a way the Secretary of State considers appropriate.

(4) If the Secretary of State makes regulations under section 50, the references in subsection (1) to
“arrangements” include arrangements under the regulations.”

59. I was provided with a copy of statutory guidance published pursuant to this section (“the Guidance”)
dated January 2024. Although this version of the Guidance was not in force at the time of the decisions
taken about the claimant, it was common ground that I should consider it. The Guidance recognises that
victims of trafficking are a vulnerable group who have been “forced, threatened or deceived into situations
of subjugation, degradation and control which undermines their personal identity and sense of self.” The
identification, protection, care and support for victims is “at the heart” of the Guidance which emphasises
the physical and psychological effects of cruelty inflicted on victims and describes how they may have
diagnosable psychiatric conditions such as post-traumatic stress disorder.

60. The Guidance says that the reasonable grounds decision “acts as a filter for potential victims referred
to the NRM based on the information available at that time.” The Guidance recognises that not only
decision-makers but also those working with victims “need to understand how decisions are made.” In
order to aid transparency, the Guidance makes clear that the reasonable grounds decision “should be
made, where possible, within 5 working days of referral to the NRM.”  A person who has received a
positive reasonable grounds decision will generally be entitled to a recovery period of at least 30 days or
until a conclusive grounds decision is made, whichever is the later. A person will not be removed from the
United Kingdom during the recovery period.


-----

61. As regards the duties to support potential victims pursuant to article 12 of ECAT, the beneficiary of a
positive reasonable grounds decision may receive support including (among other things) secure and
appropriate accommodation; financial support; and medical treatment, assistance and counselling. In the
present case, the claimant was referred to Unseen UK (“Unseen”), which is a charity providing support to
potential victims of trafficking. A caseworker at Unseen has confirmed that during the recovery period the
claimant received help in relation to:

i. Understanding her NRM and ECAT entitlements;

ii. Physical health;

iii. Mental health and counselling;

iv. Education;

v. Housing;

vi. Maternity services;

vii. Personal safety;

viii. Finance: the claimant received a regular subsistence payment from Unseen.

62. The Guidance says that the reasonable grounds decision is followed by a “substantive Conclusive
Grounds decision on whether someone is formally recognised as a victim, with a higher threshold.” The
reference to a “higher threshold” reflects that, in deciding whether a person is a victim of modern slavery
at the conclusive grounds stage, the standard to be applied by decision-makers is the balance of
probabilities (R (MN) v Secretary of State for the Home Department _[2020] EWCA Civ 1746, [2021] 1 WLR_
1956which was given statutory effect by the insertion of section 49(1A) of the 2015 Act).

63. The Guidance states that a conclusive grounds decision will be taken “at least 30 calendar days after
the reasonable grounds decision.” This means that all potential victims of modern slavery have access to
support and to the reassurance that they will not be removed from the United Kingdom for at least 30 days.

64. There is no specific target timeframe for taking conclusive grounds decisions. Key to the present
challenge is the broad provision in the Guidance that:

“7.9…The Conclusive Grounds decision should **generally be taken as soon as possible” (emphasis**
added).

65. The Guidance continues:

“However, a decision can only be made when sufficient information about the case has been shared or
made available by interested parties to the relevant competent authority…Whilst the competent
**authorities may make a decision after 30 calendar days from the positive Reasonable Grounds**
**decision, in many cases it will take significantly longer for all relevant information to be available to**
**inform the decision” (emphasis added).**

66. The absence of a target timescale for conclusive grounds decisions is reiterated in a different part of
the Guidance:

“14.124. There is no target to make a Conclusive Grounds decision within a specific timeframe. A decision
can only be made fairly and reasonably once sufficient information has been made available to the
competent authority for it to complete the decision. When the relevant competent authority has received
sufficient information for it to complete a decision it should seek to do so as soon as possible but only once
a minimum of 30 calendar days of the Recovery Period have passed, unless the relevant competent
authority has received a Request to delay the decision. The 30-day period begins when the relevant
competent authority makes a positive Reasonable Grounds decision.”

67. Although there is no general target timescale for conclusive grounds decisions, the Guidance indicates
that some cases fall to be prioritised. In the criminal context, the Guidance seeks to assist the Crown
Prosecution Service (“CPS”) to take informed decisions about whether to proceed with a prosecution


-----

against a potential victim of trafficking by emphasising the need for expeditious progress of criminal cases
within the NRM. The Guidance rightly recognises the important public interest in custody time limits. On
behalf of the defendant, Mr Bramley confirms in a witness statement that conclusive grounds decisions in
criminal cases may be expedited where possible so that a decision is made ahead of court hearings.

68. There are special provisions under the Guidance for child victims. As in cases involving an adult, a
conclusive grounds decision should be made as soon as possible after 30 days but, in addition, the
decision should, where possible, be made before the child reaches the age of 18. It follows that these
cases become urgent if a child is 17 years old (so-called “age change” cases). As in cases involving an
adult, a child's case should be considered urgently if the child is subject to criminal proceedings.

69. The Guidance makes plain that decision-makers need to assess whether a potential victim's account
of **_modern slavery is credible. Credibility is assessed both at the reasonable grounds and at the_**
conclusive grounds stage. Decision-makers are entitled to obtain further information before making a
decision.

70. The Guidance states that a positive conclusive grounds decision does not result in an automatic grant
of leave to remain. However, victims of **_modern slavery will automatically be considered for a grant of_**
leave to remain under the applicable Immigration Rules.

**Judicial consideration of delay**

71. In _R (O & H) v Secretary of State for the Home Department_ _[2019] EWHC 148 (Admin), this court_
(Garnham J) considered whether the claimants had suffered unlawful delay in their own cases and whether
the NRM arrangements as a whole were legally flawed. The defendant's evidence was that “exponential
increases in the number of referrals to the NRM” had led to “regrettable delays in some cases.” Garnham
J took into consideration that the NRM had been the subject of criticism by Jeremy Oppenheim (a Senior
Civil Servant within the Home Office) in a 2014 report. Among other things, the Oppenheim report noted
that:

i. Governance of the NRM lacked an overall performance framework,

ii. There was insufficient accountability for the outcomes of the process or the appropriate management of
the process.

iii. The reduction of delay needed tight performance management with agreed outcomes.

Garnham J referred to further criticism of NRM delays in a report that had been published by the National
Audit Office in December 2017.

72. As regards the law, Garnham J held (at paras 65-66) that the absence of an express time limit for the
making of a conclusive grounds decision (whether in European or domestic instruments) did not give the
defendant an unrestrained timescale. The restraint on the timescale is described in para 67 of his
judgment:

“decisions must be taken in a reasonable time. What is reasonable, however, will turn on the nature of the
power being exercised, the effect of exercising, and failing to exercise, the power, and all the
circumstances of the case. ”

An obligation to deal with an application in a reasonable time says little but is:

“…a flexible concept, allowing scope for variation depending not only on the volume of applications and
available resources to deal with them, but also on differences in the circumstances and needs of different
groups of asylum seekers. But…in resolving such competing demands fairness and consistency are also
vital considerations” (O & H, para 72, citing S v Secretary of State for the Home Department [2007] EWCA
_Civ 546, para 51, per Carnwath LJ as he then was)._

73. In summarising the various applicable principles, Garnham J held (at para 89) that a failure merely to
reach the best standards is not unlawful: there must be an action or inaction which can be regarded as
irrational. The court will not generally involve itself in questions concerning the internal management of a


-----

government department. The provision of inadequate resources by Government may be relevant to a
charge of systemically unlawful delay but the courts will be wary of deciding questions that turn on the
allocation of scarce resources.

74. In the event, Garnham J dismissed the claim, both in relation to individual and in relation to systemic
delay:

“98. There is, however, nothing to suggest that the delay in reacting to the long-emerging problem or the
delay in applying appropriate resources to the problem is the result of some irrational decision or some
irrational failure to act. Delays are a function of the very substantial growth in the NRM's caseload and the
Home Office's tardiness in responding. But in my judgment, it cannot be said that substantial delay is
_inherent in the arrangements. There is nothing to which my attention has been drawn, for example, which_
suggests there is some design fault in the system or some flaw in the arrangements which make delay
inevitable. Certainly, I do not have the materials on which I can draw safe conclusions about the internal
management of the relevant departments of the Home Office. It may well be that the Home Office failed in
its management of the NRM to reach the highest standards of administration; it may well be that it would
now be possible to devise a better system but neither of those facts means their conduct of the NRM to
date has been unlawful…”

75. The situation was improving and was being addressed:

“99. Furthermore, it appears from the evidence and the agreed statistics that the position is now
improving. The problems appear to have been identified and resources are being devoted to improving the
speed at which cases are determined.”

100. In my judgment the simple fact of significant delays in the processing of Conclusive Grounds
decisions does not, on these facts, establish unlawfulness…

115. [T]here is no legal time limit for resolving the Claimants' cases and the delay has not been so
egregious as to be unlawful when looked at in isolation. The explanation for the delays in these two cases
is the same as applies more generally; there has been a rapid increase in the NRM's caseload and the
Secretary of State has been somewhat slow to address the resulting problem. But his response has not
been irrational, and the problem has now been, or is being, addressed.”

76. The challenge in O & H therefore failed on its facts. The court in EOG considered other issues but the
defendant's delay in reaching conclusive grounds decisions was the subject of criticism by Underhill LJ
(with whom Dingemans LJ and Sir Geoffrey Vos MR agreed):

“91. The background to both these cases is the extraordinary length of time which it now takes for the
Secretary of State to reach both conclusive grounds decisions in the case of victims of trafficking and
decisions in asylum claims. If the conclusive grounds decision in EOG's case or the decision on KTT's
asylum claim had been reached in a reasonable time it is unlikely that either claim would have been
brought…Mr Tam [Counsel for the Secretary of State] in his oral submissions frankly acknowledged these
delays and made no attempt to suggest that they were acceptable…

92…I am sure that the Secretary of State is aware that solving the problem of those delays would clearly
be in the interests of potential and confirmed victims of trafficking, asylum seekers, the Home Office and
the courts.”

**Developments since O & H**

_The Ministerial Arrangement_

77. On 3 January 2023, the Equality (Albanian Nationals) Arrangement 2023 (“the Ministerial
Arrangement”) came into operation. Section 29(6) of the Equality Act 2010 provides so far as material: “A
person must not, in the exercise of a public function…do anything that constitutes discrimination”. Section
29 is contained in Part 3 of the Act. By virtue of paragraph 1(1)(d) and (2) of Schedule 23 to the Act, an act
authorised by the executive is excepted from the anti-discrimination provisions of Part 3 as follows:

“1 Acts authorised by statute or the executive


-----

(1) This paragraph applies to anything done—

…

(d) in pursuance of arrangements made (whether before or after the passing of this Act) by or with the
approval of, or for the time being approved by, a Minister of the Crown;

…

(2) A person does not contravene Part 3, 4, 5 or 6 by doing anything to which this paragraph applies which
discriminates against another because of the other's nationality.”

The Ministerial Arrangement was made under these provisions.

78. The text of the Ministerial Arrangement refers to the objectives of the UK-Albanian Joint Communique
of 13 December 2022 which included “increasing returns to Albania of Albanian cases as part of supporting
the aim of reducing illegal migration and fighting **_modern slavery.”  The Ministerial Arrangement_**
authorised discrimination on the grounds of nationality where it arose from prioritising **_modern slavery_**
cases where the potential victim was an Albanian national. It was supported by an Equality Impact
Assessment (“EIA”) from the Albanian Irregular Migration Co-ordination Unit.

79. On 19 January 2023, Mr Bramley made a written Ministerial Submission to the Home Secretary and
Home Office Ministers in which he set out two options for putting into operation the Ministerial
Arrangement. The policy objective was to “help meet the ambition of 100 removals a week for Albanian
nationals and provide for decisions on cases otherwise prioritised to meet criminal justice and safeguarding
aims.”

80. The two options presented to Ministers were:

“Option 1 – Devoting 100% of SCA resources to Albanian cases, deprioritising existing priority groups.

…

Option 2 – Devote majority of resources to Albanian cases, also progressing Criminal Justice System/Age
Change cases, and deprioritise all other cases for [conclusive grounds] decision.”

81. The Submission informed Ministers that, under either Option, cases that formed part of “work in
progress” – a term that I do not completely understand – and that did not fall into prioritised categories
would not be progressed. The Submission stated:

“We do not believe it necessary to include mention of the Albanian case prioritisation in Statutory Guidance
for competent authorities to operationalise.”

82. Ministers were aware from the Submission that the public sector equality duty (“PSED”) had been
considered by Home Office Legal Advisers who had provided “clearance”.  In line with Mr Bramley's
recommendation, Ministers selected Option 2.

83. As regards the overall picture after January 2023, there are documents disclosed by the defendant
showing that on 1 February 2023, there were 27,849 cases classed as “work in progress” of which 6,585
concerned Albanian nationals. By 1 December 2023, those figures had dropped to 25,580 and 3,190
respectively. It is hard to know what to make of this evidence as I am not able to distinguish between what
is meant by “work in progress” and the SCA's total caseload.

84. I have been provided with nearly 500 pages of tables showing the allocation of cases to SCA case
workers for conclusive grounds determination by “case label”, which seems to refer to case type or the
basis for selecting cases for allocation, such as age change or the receipt of a pre-action protocol letter.
The tables also show the nationality of the potential victim, the target date for decision, and the “date
received”. The tables show each case that was allocated between 5 December 2022 and 2 January 2024.

85.  Ms Braganza selected a few of the entries on the tables for highlight in her oral submissions, but they
do not appear to add to the other statistical material in any readily comprehensible fashion. The tables are
plainly administrative data of the sort that is to be expected in a large government department but their


-----

forensic utility is limited by the lack of any real analysis by the parties. I would adopt the observation of
Garnham J that the court is not in a position to conduct an audit (O & H, para 104).

86. I have also considered a Ministerial Submission dated 24 July 2023 – and associated documents –
which recommends that the Minister combine various Ministerial Arrangements and Authorisations in
relation to discrimination in the treatment of Albanian nationals in the immigration, asylum and NRM
systems. The impact of the arrangements on other nationalities was said to be mitigated by how there
would be no impact on their access to support while their claims were outstanding. These documents were
not the subject of detailed submissions before me.

_The Prioritisation List_

87. On 9 February 2023, the List came into operation. The document in which it is contained states that,
in addition to Albanian, criminal justice and age change cases, there was resource for additional cases to
be prioritised. The author of the List recommended the following “priority ladder” (emphasis added;
acronyms and typographical errors retained):

“1. Albanian cases (Any case marked ready from that nationality)

2. Criminal Justice System cases (CPS cases/Cases with a known CTL or Court Date)

3. Age Change Cases (Cases where a minor is over 17 and yet to turn 18)

4. SCA Litigation cases (JR's and PAP's)

5. Safeguarding cases (all levels) (NOTE: Safeguarding team working on new means of prioritising cases)

6. Priority cases (cases to support SCA teams such as CLT and to support other Home Office departments
who may have PAP/JR requirements such as FNORC)

7. Reconsiderations

8. Ad hoc cases to support DM development needs (specific case types to support performance
management or to help a DM achieve sign off)”.

88. The author of the List made clear that “the approach would remain flexible” in order to ensure that
ministerial objectives were honoured.

89. When the List was disclosed to the claimant, in order to correct the paragraph 11 statement, Mr
Bramley made a witness statement on 8 September 2023 in which he explained:

“A list of priorities was first created on 09 February 2023 and has been operated to date. Prior to this,
criminal justice cases and child cases were prioritised as per the statutory guidance. Any prioritisation of
cases outside of these key areas was done on a case by case basis by exception. Alongside the key
priorities set out the in the statutory guidance, the Single Competent Authority would prioritise a range of
different cases on a case-by case-basis, examples of which are set out in the notes section of the February
document. In general cases have always been prioritised in relation to whether they are high harm (such
as safeguarding risks to the potential victim), high risk (such as causing delays in the criminal justice
system), or high cost (such as litigation cases). Prior to the ministerial arrangement and resulting focus on
allocation, the Single Competent Authority also had the flexibility at times to target the oldest cases in the
system.”

90. Mr Bramley went on to explain that the Prioritisation List had not to date been published because it
concerned operational decision-making based on published policies and operational judgement. The List
was “an internal guide” and was “flexible enough to respond to the needs of day.” It was “subject to
change if operational demands require it.” He said that officials were content to consider publishing the
List but this was a decision for Ministers.

91. Mr Bramley described the way in which the category of SCA Litigation Cases was dealt with:

“14. One of the case types prioritised by the SCA are those with linked litigation. The SCA responds to
requests for decision timescales from Home Office litigation colleagues in relation to litigation challenging


-----

delay on a case by case basis. We respond to all requests from litigation colleagues for a timescale in
relation to PAPs/JRs [i.e. pre-action protocol letters or claims for judicial review] where a [conclusive
grounds] reconsideration has been agreed as a result of litigation. All PAP/JRs challenging delay to the

[conclusive grounds] decision and which have resulted in an agreement to reconsider a [conclusive
grounds decision] are deemed to be of significance to the Chief Casework team.

15. The timescale provided will depend on the status of the case, for example whether further information
gathering is required before a decision can be made. Setting a decision deadline by means of a PAP
response or Consent Order amounts to prioritisation of the case.

16. Additionally, the SCA may receive a request from litigation colleagues to provide a timescale for a

[conclusive grounds] decision in order to support other Home Office units with PAP or JR requirements.

92. Returning to the chronology, Mr Bramley made a second Ministerial Submission on 27 July 2023 (over
four months after the claimant had received the decision in her case). The Submission noted that the
prioritisation of Albanian cases had enabled the NRM to reduce the number of Albanian cases in the
system from around 7,000 to 5,700 in around five months. The Submission recommended that NRM
decision-makers should revert to a more flexible approach so that wider Home Office and Government
priorities could be addressed, including cases involving foreign national offenders and the clearance of socalled “legacy” cases. Two options were presented to Ministers. Under Option 1, Albanian cases would
continue to be prioritised to the extent that around 75% of NRM resources would be devoted to them.
Under Option 2, a more flexible approach would permit the SCA to take operational decisions on resource
allocation in accordance with wider policy priorities. Mr Bramley recommended Option 2 but Ministers
made the decision to follow Option 1.

93. On 6 October 2023, there was a further Ministerial Submission. The Submission noted that speeding
up some cases inevitably meant that other cases would be slower to resolve or not addressed at all,
causing “equalities issues, leading to significant litigation, and causing uncertainty for those waiting”. Nonprioritised cases made up the bulk of the backlog. These non-prioritised cases were at that point “very
unlikely to get a decision”. The impact of prioritisation was that “certain case types, particularly women”
were having to wait far longer for a decision.”

94. The Submission refers to a strain on resources and the need to recruit more decision-makers:

“Competent Authorities are undergoing a significant recruitment campaign…with permission to take on
another 200 decision makers across the two competent authorities. There are currently 211 decision
makers in the SCA and 145 in the IECA. As part of the additional 200, 114 offers have now been made,
and a third round of recruitment is under way.”

95. Two options were proposed by officials. Under Option 1, the prioritisation of Albanian cases would
continue with 75% of both IECA and SCA resources devoted to that cohort. Under Option 2, detained
foreign national offenders would be prioritised followed by Albanian cases, criminal justice cases and agechange cases. Ministers selected Option 2.

96. In his September 2023 statement, Mr Bramley explains why the Prioritisation List had not been
published. The List had been an “operational decision on allocation, based on published policies and
operational judgement.” It was used as “an internal guide to help operational decisions on allocation.” It
was flexible enough to respond to changing needs and subject to change if operational demands required
it. Publication was a matter for Ministers not officials.

97. On 25 October 2023, a new list of categories for prioritised allocation was circulated via an internal
email from the author of the original List.  In summary, the new list was:

i. Foreign national offender cases;

ii. Two different groups of Albanian cases;

iii. Criminal justice cases;

iv. Age change cases;


-----

v. Litigation cases;

vi. Safeguarding cases;

vii. Priority or expedited cases;

viii. Cases falling for reconsideration;

ix. Ad hoc cases to support staff development.

98. The author circulated another email with another new list on 9 November 2023 that can be
summarised as follows:

i. Foreign national offender cases;

ii. Two different groups of Albanian cases;

iii. Other asylum legacy cases, criminal justice cases, litigation cases and age change cases (all being
considered of equal priority);

iv. Safeguarding cases;

v. Priority or expedited cases;

vi. Cases falling for reconsideration;

vii. Ad hoc cases to support staff development.

99. It makes no material difference to these proceedings whether these two lists are regarded as new lists
or as modifications to the original List. I shall for convenience continue to use the terms “the Prioritisation
List” or “the List” as a compendious term for all three lists.

100. In a development during the adjournment, on 22 February 2024, the defendant amended the
Guidance to include a section on the “Prioritisation of Conclusive Grounds cases.”  The section contains a
list of groups whose cases will be prioritised for conclusive grounds decisions. It states that the current
[approach to prioritisation can “change periodically in line with Ministerial arrangements under the Equality](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
_[Act 2010” and that changes to the prioritisation criteria will be reflected in the Guidance.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_

101. Against this lengthy background, I turn to consider the issues in dispute.

**Issue 1: Defendant's duty of candour**

102. Mr Bramley provided a witness statement (dated 25 October 2023) in order to explain why the
Prioritisation List was not disclosed earlier. He said that, as an official involved in policy and not
operational matters, he was not aware of the List until late August 2023 when he learned about it in an
email from the SCA.  He confirmed that, from a policy perspective, the priorities remained criminal justice
cases, age change cases and Albanian cases. The former two categories were the ones outlined in the
Guidance and the latter was the subject of ministerial announcements.

103. Mr Bramley said that the operational arm of the SCA was free to take operational decisions about
case allocation provided that the overarching policy priorities were respected. Operational decisions could
include dealing with cases that involve litigation. It was expected that operational teams could make these
more “granular” decisions without recourse to approval from those in charge of policy decisions. The
competent authorities were afforded the flexibility to manage their own flow of cases, provided that policy
priorities were respected.

104. Adam Hundt, a solicitor who had conduct of the claimant's case on a temporary basis, sets out in a
witness statement the prejudice arising from the late disclosure of the Prioritisation List. He says that the
claimant would at an early stage have made submissions on the lawfulness and impact of the List if it had
been disclosed in a timely way. Other than highlighting this point, the various aspects of his statement are
more in the nature of a submission than a witness statement.

_The parties' submissions_


-----

105. Ms Braganza submitted that the defendant's failure to disclose the Prioritisation List amounted to a
serious breach of the duty of candour.  The defendant and his lawyers were aware that this material was
relevant to the claim. It could be implied that they made a deliberate choice to withhold the List until a late
stage in the proceedings. The defendant knowingly advanced a false case to HHJ Lambert which had led
to the refusal of permission on a false basis. Eyre J too had been deliberately misled. If not deliberate, the
defendant's failure to disclose the List until far too late was a breach of the duty of candour. The defendant
had continued to disclose other important documents in a piecemeal way and very late. No steps had
been taken to avoid future breaches of duty, such as by way of staff training.

106. Mr Morgan submitted that the contention that the Prioritisation List was deliberately withheld was
mistaken. There had been no disregard for the duty of candour or wilful breach. Where issues of
disclosure or the accuracy of information had been raised, a proportionate and swift response had been
provided. He confirmed on behalf of the defendant that a programme of supplemental training was being
developed to provide additional guidance to operational personnel (where the failures of disclosure had
occurred) in order that they should in future have a full appreciation of the court's expectations.

_Discussion_

107. In failing to disclose the List, Mr Bramley made a mistake. There is no evidence that any civil servant
or Government lawyer intended to mislead the court. Any pleaded document or correspondence in which
the claimants' lawyers suggest otherwise lacks any proper or realistic foundation. When the defendant's
lawyers appreciated the error, they took speedy steps to rectify it and to comply with the duty of candour.
The defendant has unreservedly apologised to the claimant and to the court.

108. The defendant's mistake was regrettable but it did not prevent the claimant from (i) being granted
permission to apply for judicial review by Eyre J and then by me; (ii) receiving a copy of the Prioritisation
List which Ms Braganza deployed at length and to full effect at the substantive hearing; and (iii) receiving
associated disclosure of documents showing how the List has been applied in practice and changed. The
defendant has agreed to pay the costs of the hearings and applications resulting from late disclosure.  The
issue of whether indemnity costs should be awarded was included in the List of Issues, but I heard no
argument on the application of the principles for such an award and so do not deal with that question in this
judgment. In my judgment, the effect of any unfairness or procedural impropriety arising from late service
of documents has been dissipated. As for the future, Mr Morgan has confirmed that training for operational
personnel is being developed.

109. The claimant sought mandatory orders in relation to breaches of the duty of candour. Among other
things, the claimant's skeleton argument asked the court to require those involved in the breaches to (i)
apologise formally to the court and the claimant; and (ii) confirm their understanding of the importance and
nature of the duty of candour by filing witness statements which should demonstrate “the steps to be taken
to minimise the risk of a repeat of such breaches in future litigation.” I asked both parties to let me know of
any authority for the proposition that the court has power to grant substantive final relief – which would
here be in the nature of orders made against civil servants – simply in relation to breaches of the duty of
candour as opposed to some reviewable error of law. Mr Morgan confirmed that his research did not
uncover any such authority. Ms Braganza abandoned the claim for relief in relation to candour which, in
the various mandatory orders sought, had in any event taken an unusual form.

110. Irrespective of the history of the matter, I am not now asked to exercise any public law power or
procedural discretion in relation to the duty of candour. I agree with Mr Morgan that questions of candour
should not be allowed to deflect the court from its primary duty of determining the issues in the claim.  It is
neither necessary nor proportionate to lengthen this judgment with further analysis of disclosure issues
which could not advance the claimant's claim for relief.

**Issue 2: Expert Evidence**

111. The claimant applies to rely on expert evidence in the form of a psychiatric report from Dr Nuwan
Galappathie and a witness statement from Professor Cornelius Katona. The application is resisted.


-----

_Dr Galappathie_

112. On 13 August 2023, the claimant was examined by Dr Nuwan Galappathie, a consultant forensic
psychiatrist. On 20 October 2023, he produced a psychiatric report. In his opinion, the claimant was at
that time suffering from a severe episode of depression, generalised anxiety disorder and post-traumatic
stress disorder. The claimant sought to rely on this report to support her claim that her rights under articles
4 and 8 ECHR had been breached because of the impact of the defendant's delay on her mental health.
The report would also be relevant to the quantification of damages, although the List of Issues does not
include damages as an issue to be resolved at this stage.

113. Ms Braganza submitted that the court could not assess the impact of delay on the claimant without Dr
Galappathie's evidence.  She submitted that the report had been served in a timely manner, more than
two months before the hearing. It was not proportionate to obtain psychiatric evidence until after the grant
of permission to apply for judicial review. It had then taken considerable time to find an available
psychiatrist. Ms Braganza submitted that the defendant had not suffered, and does not claim to have
suffered, any prejudice from the service of this report.

114. Mr Morgan submitted that reliance on expert evidence was raised for the first time in the claimant's
amended grounds. It was not foreshadowed in any way: no prior notice was given. My attention was
drawn to the Upper Tribunal's criticisms of Dr Galappathie's objectivity and expertise in CE (Cameroon) v
_Secretary of State for the Home Department, PA/01112/2020, 14 August 2023, paras 205-207._

115. I have a great deal of sympathy with the defendant's position. The effect of delay on the claimant's
mental health was first raised by the claimant's previous solicitors as long ago as 11 June 2021 and then
again by email to the defendant on 17 December 2021: it cannot have taken the claimant's present
solicitors by surprise. The assertion that it would have been disproportionate to have served the evidence
earlier is unpersuasive when the evidence is said in the claimant's skeleton argument to address “central”
and “essential” matters in the claim.

116. Given the tardy production of the report, there was in practice no realistic way for the defendant to
obtain his own report without jeopardising the hearing date. Nevertheless, there was no suggestion before
me that the defendant would have wished to obtain his own report. In the absence of any specific or
concrete details of prejudice to the defendant, the just course in a claim raising the claimant's human rights
is to admit the report. The claimant's application is allowed. I shall return to the substance and effect of the
report in due course.

_Professor Katona_

117. Professor Katona is the Honorary Medical and Research Director at the Helen Bamber Foundation.
In a witness statement dated 15 November 2023, he seeks to “comment on the effect of the current delays
in decision making in the…NRM…on individuals, specifically on how delay affects mental health, treatment
of mental health conditions and prognosis.” Contrary to CPR 35.10(3), he does not set out his instructions
save to say that he has been “asked to comment with reference to the current delays in NRM decision
making” which he understands “are much longer than they were in 2018” when he drafted a witness
statement in O & H that is exhibited to his current statement.

118. Professor Katona is a critic of certain immigration legislation as creating a “perceived hostility”
towards victims of trafficking. He disagrees with “the defendant's practice of expediting the decision
making of those who are able to access legal advice” and would like a system for more expeditious
decisions in the NRM based on victims' needs.

119. Professor Katona expresses his opinion on the effect of delay as follows:

“The increased time [waiting for a conclusive grounds decision] is associated with uncertainty and fear
including specific fear of refusal and subsequent removal. This in turn leads to greater isolation and makes
it difficult if not impossible to integrate into society.

In my clinical experience and that of my colleagues at HBF, the cumulative effect of these liminal
d iti d l ff t t l h lth I ti l it k it diffi lt f l t i


-----

talking treatments even if they are able to access them which is often difficult. In addition it often increases
their distress and prevents their anxiety and trauma symptoms from resolving, resulting in further mental
deterioration.”

120. The report provides two case studies dating back to 2021. In one case study, the period between a
reasonable grounds and a conclusive grounds decision was 837 days; in the other case, it was 987 days.
In each case, the subject of the case study continued to experience serious mental health problems even
after a conclusive grounds decision, which Professor Katona relates to the delay in receiving the decision.

121. Ms Braganza submitted that Professor Katona is an acclaimed expert whose evidence was accepted
in O & H. His evidence addresses central matters in this claim – namely the psychiatric impact of delays
on potential victims which is not addressed in the rest of the evidence. The same arguments were made
about the timing of his report and the lack of prejudice to the defendant as were made in relation to Dr
Galappathie's report.

122. Mr Morgan made similar submissions in relation to Professor Katona as he had made in relation to Dr
Galappathie. He added that Professor Katona's evidence did not meet the test in CPR 35.1 and did not
relate to any live issues in the proceedings.

123. In my judgment, as Professor Katona is a psychiatrist, his view of immigration legislation and his view
of the defendant's practice in relation to prioritising cases for decision within the NRM are (i) outside his
expertise and (ii) not reasonably required to resolve these proceedings (CPR 35.1). This aspect of his
evidence is inadmissible.

124. As for the remainder of his statement, I accept in general terms that one serious adverse effect of the
defendant's delay in taking conclusive grounds decisions is that the recovery of victims from the trauma of
being trafficked may be inhibited and that the path to integration may be delayed. I shall admit Professor
Katona's report but I conclude that little emerges from it beyond this general and essentially undisputed
proposition.

**Issue 3: Delays in making conclusive grounds decisions**

_The parties' submissions_

125. Ms Braganza submitted that any delay in reaching a conclusive grounds decision must be reasonable
in the circumstances.  Dealing with the claimant's individual case, she submitted that the defendant had
failed to explain or justify the decision to await an asylum interview record and to demand a further
statement from the claimant. Such requirements were irrational and had lengthened the overall decisionmaking process in an unreasonable way. Neither the asylum interview record nor any further statement
was ever likely to constitute a vital piece of evidence. The defendant's later change of approach – which
abandoned each of these requirements – demonstrated the lack of any need to impose them in the first
place. In particular, the insistence on waiting for the asylum interview record had caused a long delay but
the record had played no part in the conclusive grounds decision: the written minute of the conclusive
grounds determination made no reference to it.

126. Ms Braganza submitted that the defendant's ability and willingness to bring forward the decision –
more than once – by a considerable time demonstrated the arbitrary nature of the successive timeframes
that had been allocated to the claimant's case.  The overall delay was on any analysis extremely lengthy
and protracted. In these circumstances, the delay in the claimant's individual case was unreasonable.

127. As regards the NRM as a whole, Ms Braganza submitted that the system for progressing conclusive
grounds determinations was irrational and unlawful in light of the cumulative impact of the following factors:
(i) the particular vulnerability of the cohort of potential victims within the NRM; (ii) the recognised harm
which their “limbo” status within the NRM causes to their recovery from their trafficking experiences; (iii)
the extreme and rising delays in decision-making; (iv) the defendant's awareness over many years that this
was an issue which needed to be addressed; (v) the defendant's reliance upon the unlawful List as a
means to manage delays; (vi) the duty on the defendant to act promptly and with reasonable expedition;
and (vii) the duty on the defendant to identify victims and facilitate their recovery There had been no


-----

progress since the judgment in _O & H.  The defendant had in that case persuaded the court that_
improvements were in hand but no improvement to waiting times had materialised. On the contrary,
waiting times had increased as the claimant's case exemplified.

128. Mr Morgan submitted that, in order to be actionable in this court, the claimant would need to
demonstrate some form of irrationality in the defendant's decision-making process (O & H, para 89). That
was a high hurdle. There was nothing irrational either in the processes applied to the claimant's individual
case or in those applied within the SCA as a whole. It was rational and within the defendant's powers to
decide initially to await the asylum interview record: the later decision to proceed without it did not render
the initial approach irrational. Nor was it irrational to seek a further witness statement. The defendant's
subsequent willingness to forego a fresh statement did not demonstrate any form of irrationality.

129. As to the system as a whole, Mr Morgan submitted that the decision as to whether or not a person is
conclusively a victim of trafficking is fact-sensitive and involves the exercise of judgment rather than the
application of a formula. The NRM operates with finite resources and with no control over how many
people are referred to it. Decision-makers may need to obtain information from applicants and from third
party agencies. It was plainly stated in the Guidance that “all relevant information must be shared and
made available to the relevant competent authority to inform the decision, which can often take interested
parties significant time to provide.” The question of whether a reasonable period for taking a decision has
been exceeded must be answered in this overall context.

130. Mr Morgan submitted that the Prioritisation List did not deprive operational decision-makers of their
discretion to respond to cases of higher vulnerability or need. It was rational and consistent with the
Guidance for decision-makers to target or prioritise different cases with particular characteristics from time
to time in light of finite resources, but the system at all times remained sufficiently flexible to deal properly
and speedily with urgent cases.

131. Mr Morgan emphasised that the growing volume of applications had strained resources. It was
rational in the circumstances to prioritise resources in order to reach reasonable grounds decisions quickly,
thereby enabling potential victims of trafficking to receive protection through the support available during
the recovery period. Such a policy leads to longer waiting times for conclusive grounds decisions but those
awaiting conclusive decisions are in the meantime safe and may begin the recovery process free from the
risk of expulsion; whereas a person has no entitlement to any support before a reasonable grounds
decision is made.

132. Mr Morgan submitted that, in any event, the individual delay-based challenge was academic
because the claimant had received a decision. No purpose would be served by the grant of declaratory
relief sought in her individual claim.

**Analysis and conclusions**

_Developments since O & H_

133. The judgment in _O & H was handed down at the beginning of 2019. I have been provided with_
various sets of statistics showing the workload of the NRM since then. They are summarised in the
defendant's skeleton argument:

“66. As the number of referrals to the NRM had increased, exponentially, in the decade to 2022, the
backlog initially increased substantially, as RB [i.e. Mr Bramley] explains, in the years to 2022. By 2022,
when above 16,938 potential victims of modern slavery were referred to the Home Office (33% increase
compared even to the preceding year), the median time taken from referral to conclusive grounds
decisions made across the competent authorities that year rose from 437 days in the 4th quarter of 2021 to
642 days in the 4[th] quarter of 2022. The mean time rose from 588 to 761 [days]...

…

69…The statistics for Q3 [i.e. the third quarter] 2023 became available on 2 November 2023. Those record
4,138 referrals (an increase of 4% from Q2), 2,390 [conclusive grounds] decisions were issued in Q3 (a


-----

15% increase from Q2). The time between [reasonable grounds] and [conclusive grounds] decisions in Q3
was 530 days median (an increase of 18% from Q2) and 640 mean (an increase of 11% from Q2). The last
two statistics again cover only the decisions taken in the requisite quarter, rather than overall delay times.

70…[T]he SCA issued some 2,728 [reasonable grounds] decisions and the IECA issued 1,017 in the index
period. From July to September 2023, 2,390 [conclusive grounds] decisions were issued (compared to
2,069 from April to June 2023). As an indication of capacity building achieved, the equivalent figures for the
same periods in 2022 are 1,508 and 1,202 respectively.

71. The number of [conclusive grounds] decisions being taken continued to exceed positive [reasonable
grounds] decisions entering the NRM process (1,958), resulting in a continuing reduction in the overall
backlog of [conclusive grounds] cases to be determined.”

134. As Mr Bramley accepts, the time taken to reach conclusive grounds decisions needs to be improved.
He states:

“It should be noted that the key factor in the timescales for making [conclusive grounds decisions] is the
significant increase in referrals into the NRM in recent years. Between 2014 and 2022 referrals into the
NRM increased by 625%, with close to 17,000 referred last year. At various times, other factors that have
had a bearing on timescales to make [conclusive grounds decisions] have included an increase in criminal
justice system cases (which are prioritised) and prioritizing [reasonable grounds decisions] so that entry to
the system is not unduly inhibited and the time taken to train and upskill new decision makers in line with
the large recruitment exercises required to expand the resource available.”

135. In broad terms, the view that the system is far too slow is understandable. As Ms Braganza forcefully
pointed out, the claimant was subject to a delay of three years and eight months between her reasonable
grounds and conclusive grounds decisions.

136. The court must nevertheless make proper sense of the overall numbers and avoid pitfalls that those
versed in analysing statistics would point out. To take one example: the time taken to process a conclusive
grounds decision is only included in the published statistics once the decision is made.  It follows (as Mr
Moss emphasises in his evidence) that the clearance of old cases will cause the statistics relating to
processing times to show an increase in the average waiting time. This does not mean that the waiting list
or waiting times are not being reduced – a factor that the claimant's evidence and her submissions about
the statistics do not acknowledge.

137. The claimant's assertion that there is no concrete evidence of action taken or results achieved since
the judgment in O & H is not supported by the evidence. I shall deal with both action and results in turn.

138. In terms of action, Ministers have (as I have indicated) been alerted to the need to recruit additional
decision-makers. In his statements served during the adjournment, Mr Moss describes the defendant's
efforts to recruit new staff.  It appears that recruitment campaigns have not resulted in an increase in
permanent staff devoted to conclusive grounds decisions but rather a decrease of 69 decision-makers.
This lack of success stands in contrast to the recruitment campaigns for reasonable grounds decisionmakers in the SCA and (according to Ms Tovey's witness statement) in the IECA as a whole.

139. There is nothing to suggest that the failure to augment conclusive grounds decision-makers in the
SCA was the defendant's fault (as opposed to representing labour market forces or some other factor). It
is not decisive in demonstrating that the defendant has taken little or no action to speed up decisionmaking since the judgment in O & H.

140. The evidence shows that the defendant has deployed its resources in a variety of other ways with the
aim of improving productivity. The levers include:

i. The establishment of the IECA which appears to have removed a significant proportion of the SCA's
casework (23% of referrals went to the IECA in 2022).


-----

ii. Policy changes to the effect that certain individuals may be disqualified from receiving the protections
and support of the NRM on grounds of public order or if the claim to be a victim of trafficking is made in bad
faith.

iii. Clarification to decision-makers that, although an asylum interview may provide useful evidence for the
conclusive grounds determination, there is no requirement in the Guidance to await the interview.

iv. Staff working overtime;

v. The use of agency staff on a temporary basis;

vi. The use of the List to achieve a more focused and targeted allocation of cases;

vii. Management oversight in the form of the granular selection of cases each week as fully set out in the
weekly emails disclosed by the defendant;

viii. Enhanced training for decision-makers, referred to as “decision making upskill” in the documents
before me; and

ix. Practical training “on the job” (represented by Group 8 on the List).

141. Ms Braganza properly accepted that the defendant was not under a legal duty to deploy as many
resources as needed to clear the backlog of cases. Resources are not and never will be infinite. It is the
responsibility of the defendant and not the court to decide how to allocate them. The multi-faceted
approach adopted by the defendant was not irrational and is not open to challenge.

142. Dealing specifically with the SCA, Mr Moss states that, in the whole of 2022, the SCA served 5734
conclusive grounds decisions. In the first six months of 2023, it served 4153 such decisions. Of those,
only 1429 were Albanian cases: the vast majority were not Albanian so that the Ministerial Arrangement did
not produce a standstill on other decisions. The number of cases awaiting a decision in the SCA has
decreased by over 1000 since April 2023. In 2022, the median time for a conclusive grounds decision in
the SCA was 583 days whereas in the second quarter of 2023, it was 470 days. The claimant put forward
an analysis of the statistics in a Note which was dependent on the defendant's evidence. I have not been
provided with persuasive statistical analysis to contradict the defendant's position that these numbers
represent some concrete progress. I reject the submission that nothing has changed since the judgment in
_O & H._

_The principle of prioritisation_

143. The words “as soon as possible” in the Guidance cannot mean that the defendant is bound to decide
all cases in the order in which they arrive for decision. Such an interpretation would leave the defendant
fettered to a rigid policy that left no room for flexibility and no room for dealing with urgent cases urgently.
That cannot have been the defendant's intention when setting the Guidance.

144. The Guidance does not need to be – and in the interests of operational effectiveness should not be –
construed with the same rigour as a statute. The words “as soon as possible” must be read and
interpreted as meaning as soon as reasonably possible within the practical and legal constraints that
operate within the NRM and within the demands of open-textured decision-making in relation to an overall
vulnerable group. Any reasonable reader of the Guidance would assume such constraints which are no
more than common sense. Part of those constraints is that some cases need to be prioritised. It is not
irrational to have a Prioritisation List. Ms Braganza accepted as much.

_The rankings on the Prioritisation List_

145. The defendant's Official Statistics demonstrate that in 2022 the most common nationality referred to
the NRM was Albanian which accounted for 27% (4,613) of all cases (compared to 20% in the previous
year) and the highest annual volume for this nationality since the NRM began. As I have set out above, the
objective of the Ministerial Arrangement was to increase expulsions of Albanian migrants with the twin aim
of reducing illegal migration and fighting modern slavery.


-----

146. In the present context, the List was an operational reaction to the Ministerial Arrangement which itself
flowed from the Communique. If the objectives of the Communique are met, the number of Albanians
within the immigration and NRM systems will reduce. I accept Mr Morgan's submission that reducing the
queue of Albanian cases would be likely to cause the NRM queue to fall, bringing associated benefits for
processing times generally. That approach is not irrational. It tackles a problem in a way that the claimant
does not want it to be tackled but it does not sound in relief.

147. It is important to be clear about the limitations of the List. It does not oblige decision-makers to work
on one priority category at the expense of all other cases. As Mr Bramley explains in his evidence:

“It is not the case that we allocate all of Priority 1 first then move onto Priority 2, it's much more flexible than
that so there will be a mixture of the priorities allocated each week with heavier weighting towards the
top…”

148. As regards non-Albanian cases, it is plain from the evidence that prioritisation within the NRM is a
multi-factorial process that engages various different policy objectives with which the court cannot – save
on error of law grounds – interfere. Criminal justice cases form a prime example. Unlike the claimant,
victims of modern slavery facing proceedings in the Crown Court may be remanded in custody: the delay
in dealing with their cases within the NRM affects and engages the liberty of the individual. I would reject
any suggestion that custody cases should not be prioritised. Even in non-custody cases, I would reject the
suggestion that the NRM should not make a contribution to ensuring that the Crown Court's heavy case
load proceeds expeditiously. There is, moreover, a strong public interest in ensuring that people are not
sentenced to prison on the basis of a flawed view of whether or not they are victims of trafficking.

149. Ms Braganza submitted that it was irrational to prioritise ad hoc cases to support staff training and
development (the eighth category on the List). She submitted that it was unreasonable to prioritise ad hoc
cases above those suffering from particular vulnerability (such as psychiatric problems).

150. I have some sympathy with this submission but – like other elements of the claim – it must be
considered in context. It is rational to select some cases that will assist decision-makers to learn “on the
job” with a view to increasing overall productivity, thereby maximising the longer-term volume of cases that
may be processed and reducing the queue. Having a particular pipeline of work for less experienced
decision-makers is not irrational.

151. Ms Braganza submitted that it should not have been necessary for the claimant to lodge judicial
review proceedings in order to speed up the decision in her case. That is doubtless true as a general
proposition but it is not irrational or otherwise unlawful for the defendant to respond to litigation or the threat
of litigation. It was the defendant's duty to respond to the claimant's letter before claim. It was thereafter
the defendant's duty to comply with CPR Part 54 (which governs judicial review claims) and with the
directions of the court. The defendant also – as part of the duty to further the overriding objective – has a
duty to consider ways of resolving disputes by alternative means and settling cases. Expediting a
conclusive grounds determination on the advice of Counsel to avoid lengthy and costly judicial review
proceedings cannot be regarded as unreasonable.

152. Adhering to court procedures is part of the rule of law. Civil servants must ensure that this is done. If
civil servants choose to emphasise the need for compliance with court procedures by using the language
of prioritisation of the NRM's workload, they are doing nothing unlawful. They are complying with the law.

153. I expressed concern at the hearing that a system which ceased to process cases that were not
considered priority cases under the List would breach the Guidance. I was concerned that a complete
cessation of decision-making in relation to non-prioritised cases would be incompatible with the Guidance:
it would be difficult to say that taking non-prioritised cases out of the queue entirely was compatible with
processing them “as soon as possible.” It would leave no space for processing cases that had already
been the subject of considerable delay or for accelerated decision-making based on some physical or
psychiatric vulnerability of the potential victim of trafficking that would warrant prioritisation outside the List.

154. Mr Morgan responded to my query by taking me in granular detail to the weekly emails sent by SCA
managers to those officials tasked with allocating particular cases to decision-makers These allocation


-----

emails demonstrate that the List (and even the Ministerial Arrangement) was applied with a degree of
flexibility. In relation to older cases:

i. The allocation email on 16 March 2023 said (among other things): “We have a few older cases going out
this week, 17 in total from 2018 and 2019 so good to see that we are still able to continue clearing some of
the oldest cases whilst delivering against the Albanian prioritisation work and other priority case deadlines”.

ii. On 29 June 2023, eleven per cent of cases allocated in that week met the “older target case profile of
2018 or older (a proportion of these also meeting other priority criteria outside of older case criteria…We
are going to try to keep adding in a small per centage of target older cases each week where we can with
the aim of clearing the cases from 2018 or older.”

iii. On 13 July 2023, a total of 117 cases were allocated of which 29 were target older cases allocated as
part of a backlog clearance strategy.

iv. Of 105 allocations on 21 July 2023, 27 were Albanians but a further 15 were older cases.

v. Of 76 allocations on 24 August 2023, 17 were Albanians representing only 22% of the allocation.

155. Ms Braganza emphasised that, by the beginning of September 2023, SCA managers were under
pressure to allocate Albanian cases at the expense of other cases. There was at that time (for example) a
drive to allocate and clear 500 Albanian asylum seekers through the conclusive grounds stage. Of these
500 cases, 334 had been allocated by mid-October 2023 with some other priority cases being allocated
each week. Nevertheless, by the end of October 2023, decision-makers were permitted to work only on
foreign national offender and Albanian cases unless there were “none left” in the weekly allocation in which
case they could revert to other case categories on the List.

156. On 25 October 2023, decision-makers were instructed to work only on foreign national offender and
Albanian cases followed by criminal justice and age change cases. If all such cases were properly
progressed, managers were allowed to allocate other categories on the List. However, there was an
instruction that:

“Nobody should be working on any other case types at the moment. If any [decision-makers] are working
on any other case types (without a valid reason) then they should be placed on hold…”

157. Another internal email dated 25 October 2023 stated:

“If a [decision-maker] is currently working on a case that isn't a [foreign national offender] case and isn't an
Albanian priority case then they should only continue working on it if they are over 50% of the way through
that decision….

Once all [foreign national offender] and Albanian cases are cleared then we can look at switching back to
dealing with other cases.”

158. This stringent instruction was in force until 9 November 2023 from which time other categories on the
List were again allocated. The evidence before me runs out after 21 December 2023.

159. It follows that the documents before me demonstrate a mixed picture. On the one hand, in the eight
or so months following the Ministerial Arrangement, officials strived to maintain a mix of cases for as long
as possible. Even after the List was created, officials did not take the List to mean that all cases in Priority
Group 1 should be determined before cases in Group 2 should be considered. Rather, in broad terms,
officials allocated more cases from groups higher up the List. However, there came a time when foreign
national offenders and Albanian cases were prioritised in a more stringent manner. In my judgment, the
differing priorities at different times reflects the ebb and flow of the delivery of a public service.

160. Ms Braganza criticised Mr Morgan for describing the allocation process as allowing for the flexibility
to deal urgently with vulnerable individuals. Were the defendant to have applied a policy that the SCA
would only process foreign national offender and Albanian conclusive grounds decisions, then there may
have been scope to hold that such a policy was inconsistent with the Guidance which (at the time) did not
imply any such prioritisation. It may also have given rise to concerns under articles 4, 8 and 14 ECHR; an


-----

obvious example would be a refusal to expedite a case when presented with credible evidence of an
urgent threat that without a conclusive grounds decision, a victim may be re-trafficked.

161. Yet even at the height of the prioritisation of Albanians and foreign national offenders, the defendant's
allocation processes were never that strict. The allocation emails show that the defendant deployed
“standby teams” to deal with urgent cases, and on other occasions urgent cases were allocated across
other teams. In summary, the breakdown of cases in the weekly allocation emails supports the defendant's
submission that neither the Ministerial Arrangement nor the List was rigidly applied.

162. In addition, the SCA continued to allocate “Safeguarding” cases even at the height of prioritising
Albanian and foreign national offender cases. For example, on 25 October 2023, staff were directed in the
following terms:

“If there is an imminent or immediate risk to any individual then the case should be dealt with **as our**
**highest priority” (emphasis added).**

163. A similar message (albeit with the words “as a higher priority” rather than as the highest priority) was
sent on 9 November 2023 and again each week until 21 December 2023 when the evidence before me
runs out. Mr Bramley's evidence confirms that safeguarding cases are prioritised on a case by case basis
based on the potential victim's “vulnerabilities and needs”.

164. Ms Braganza criticised the Safeguarding category – which seems to comprise those who pose a
grave risk of harm to themselves or others – as drawn too narrowly to cover many victims who are
vulnerable to harm from delay. She submitted that, even if only cases of particularly high vulnerability were
treated as part of the Safeguarding category, they would fall some way down the List and beneath the SCA
Litigation category which could cover a range of cases including those which did not raise any serious
vulnerabilities or other particular forms of urgency. It was irrational to place the most vulnerable potential
victims beneath those who happened to have the resources and practical access to legal advice that would
enable them to bring litigation.

165. In support of this submission, the claimant relied on a number of witnesses from those who work with
victims of trafficking and modern slavery. Her solicitor, Ugo Hayter, comments on the defendant's NRM
statistics and provides some other statistics based on evidence from colleagues in the firm. The solicitor
gives evidence on “the impact of delays on clients” and “challenging the defendant's delay in NRM
decision-making.” She exhibits her witness statement provided to the court in O & H. She exhibits a 2019
report by Kalayaan (an NGO specialising in supporting and campaigning for the rights of migrant domestic
workers), together with a letter from Kalayaan stating that its service users experience ever-worsening
experiences in the NRM. She exhibits a witness from Rachael Despicht of Birnberg Peirce Solicitors, a
letter from a caseworker at Migrant Legal Project and a witness statement from the same caseworker that
was filed in relation to O & H in 2018.

166. I have no doubt that these various statements and letters represent genuinely-held and strong views
formed as a result of the authors' work on behalf of victims. None of the authors are presented as experts,
whether in statistics, psychiatry, public policy or any other field. They do not deal with the competing
considerations which inevitably underlie both policy and operational decisions that confront officials in this
area. They provide a partial view of the policy landscape founded (unsurprisingly) on their particular
perspective.

167. The defendant does not dispute that victims of **_modern slavery suffer uncertainty and may suffer_**
mental health difficulties as a consequence. Professor Katona's evidence demonstrates that delay may
cause serious mental health problems for victims. Nonetheless, the claimant's submissions that vulnerable
individuals are not properly prioritised fail to recognise the public interest in speedy decisions for those who
may be wrongly prosecuted or who may soon reach the age of 18 or who fall within the other public interest
reasons for including a particular category on the List. These competing interests form the nub of a difficult
problem. However, the resolution of difficult problems that arise in the course of delivering public services
is the responsibility of the executive branch of government.  In this overall context, I do not regard the
scope of the Safeguarding category as irrational or unreasonably narrow.


-----

168. Consideration of the various categories on the Prioritisation List demonstrates that the overall
allocation of resources within the NRM engages competing public interests. As I have indicated, it is the
responsibility of the Government to grapple with the full complexity of those competing interests. That
complexity, and the constant need to balance competing public interests, was not reflected in any real way
in any of the witness statements filed on behalf of the claimant or fully acknowledged in her written or oral
submissions.

169. Upon proper analysis, the claimant's arguments amount to a strongly-held disagreement with the
substance of the Prioritisation List. The claimant may want different cases to be prioritised or she may
want different elements of the List to feature in a different order. That is not enough for the grant of relief.

170. For these reasons, the adoption of the List and its rankings was not irrational. The adoption of
priorities or the ranking of cases for the purpose of allocation to case workers was not inconsistent with
public Guidance that decisions should generally be taken as soon as possible. I am not persuaded that the
rankings were in any event rigidly applied in a way that would have contradicted the Guidance. I am not
persuaded of any irrationality in the system as a whole. The systemic challenge fails.

_The decision in the claimant's case_

171. As I have mentioned, the claimant's conclusive grounds decision was taken in April 2023, after the
commencement of the present proceedings. The Ministerial Arrangement did not have effect until 3
January 2023. The List, which was dated 9 February 2023, was a reaction to the Ministerial Arrangement.
Therefore, the vast bulk of the delay experienced by the claimant predated both developments. There is
no evidence before me that the decision-making process in the claimant's case took longer to complete
prior to January 2023 because she was removed from the “queue” to make way for Albanian cases.

172. As I have previously set out in my review of the LPP documents, the defendant was already taking
steps to bring forward the claimant's conclusive grounds determination from around 11 January 2023 in
response to the issuing of these proceedings, which was before the List was drafted. The defendant has
confirmed that (i) at the time of the pre-action protocol letter, the claimant was already in a cohort of older
cases awaiting decision; and (ii) neither the Ministerial Arrangement nor the List had the consequence of
impairing or impeding her conclusive grounds decision which was in fact brought forward after the
intimation of litigation. The upshot of this is that the Prioritisation List had no material effect on her case.
Her conclusive grounds decision followed the commencement of the judicial review proceedings at a pace
which reflected the advice of GLD and of Mr Thomann. She suffered no material prejudice from the List.

173. The sheer length of the delay in the claimant's case gives cause for concern in the context of a
procedure that was intended to identify whether she had fallen prey to exploitation and abuse. However,
Mr Morgan is in my judgment correct to say that the operation of the NRM inevitably involves and requires
the allocation of finite resources in a manner that must be fair as between individual cases while at the
same time having sufficient flexibility to respond to urgency arising from the particular vulnerability of a
potential victim of trafficking in any given case. I do not accept that the length of delay in this case fell
outside these usual constraints on decision-makers.

174. More specifically, it cannot be said with any degree of persuasive force that the decision to postpone
a conclusive grounds determination until after the claimant's asylum interview was unreasonable: it was
open to the defendant to determine that the probing and testing involved in an interview could assist the
NRM process in the present case. Other requests made of the claimant – with a view to obtaining further
information – were also reasonable. The claimant's disagreement with the decision to await the asylum
interview and then to require a fresh witness statement is nothing to the point in the absence of public law
error. The defendant's initial approach was not rendered unreasonable by the doubtless pragmatic
approach at a later stage to defer to the claimant's preference that the defendant draw upon the witness
statements filed in these proceedings and her asylum statement.  The long delay in this case was highly
regrettable but, in context, it was not unreasonable or unlawful.


-----

175. Further, the claimant received a conclusive grounds decision in April 2023 so that the challenge to
delay in her own case is academic.  The grant of relief, in the form of a declaration, would serve no
practical purpose. For this reason too, this ground of challenge fails.

**Issue 4: The claimant's human rights**

**Article 4 ECHR**

_The parties' submissions_

176. Ms Braganza submitted that the time taken to make decisions must not frustrate the legislative
purpose (R v Tower Hamlets LBC, ex p Khalique (1994) 26 HLR 517, 522). The conclusive grounds
decision-making process constitutes part of the defendant's discharge of the United Kingdom's obligations
under article 4 ECHR. The investigative duty imposed on States by article 4 must be discharged with
promptness and reasonable expedition. The NRM decision-making process (underpinned by the
framework of the 2015 Act and article 4 ECHR) is intended to identify and protect victims of trafficking as
well as facilitating their recovery from exploitation. Instead, it unreasonably frustrates that purpose, by
leaving victims in limbo, at risk of further exploitation, and unable to obtain the stability which is essential
for recovery.

177. Mr Morgan submitted that the claimant's human rights were not breached. Following the positive
reasonable grounds decision, she had benefitted from the allocation of a specific support worker in
accordance with the applicable provision for victims. She had received financial support to meet her
essential needs and to assist her recovery; accommodation at public expense including utilities; access to
health services; and legal assistance at public expense.  Mr Morgan pointed out that the claimant had
expressly withdrawn her ground for judicial review alleging the inadequacy of such assistance under article
12 of ECAT.

_Legal framework_

178. Article 4 ECHR provides in so far as material:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

It is not in dispute that human trafficking, as defined by (among other things) article 4(a) of ECAT, falls
within the scope of article 4 ECHR.

179. Article 4 enshrines one of the “basic values of the democratic societies making up the Council of
Europe” and gives rise to an absolute right (Rantsev v Cyprus and Russia (2010) 51 EHRR 1, para 283).
As observed in R (TDT (Vietnam)) v Secretary of State for the Home Department _[2018] EWCA Civ 1395,_

[2018] 1 WLR 4922, para 17, it imposes positive obligations on the State which may be classified under
three headings:

“(a) a general duty to implement measures to combat trafficking – 'the systems duty';

(b) a duty to take steps to protect individual victims of trafficking – 'the protection duty' (sometimes called
'the operational duty');

(c) a duty to investigate situations of potential trafficking – 'the investigation duty' (sometimes called 'the
procedural duty')” (emphasis added).

180. I heard no argument on the systems duty, which does not appear relevant to the issues before me.

_Investigation duty_

181. The investigation duty is a procedural obligation to investigate situations of potential trafficking by
means of actions capable of leading to the “identification and punishment of individuals responsible” for
trafficking (Rantsev, para 288). The investigation must in all cases be prompt and reasonably expeditious


-----

but where the possibility of removing the individual from the harmful situation arises, the investigation must
be undertaken as a matter of urgency (Rantsev, para 288).

182. Ms Braganza argued that the duty of promptness and reasonable expedition applies to the conclusive
grounds decision-making process. However, I was left uncertain as to why the claimant had been subject
to an investigative failing in the Rantsev sense. Her case was not argued before me on the basis that the
investigation and punishment of her trafficker had been deficient.

183. Even if that were the case, the application of the Guidance is not the mechanism by which the United
Kingdom satisfies the investigation duty under article 4 (TDT, para 30). An investigative deficiency would
be the responsibility of the police and CPS rather than the defendant (MS (Pakistan) v Secretary of State
_for the Home Department_ _[2020] UKSC 9, [2020] 1 WLR 1373, para 35). I am therefore unpersuaded by_
Ms Braganza's contention that, in establishing and operating the NRM, the defendant seeks to discharge
the investigation duty.

_Protection duty_

184. The claimant submits that the excessive delay in reaching a conclusive grounds decision amounted
to a failure to facilitate her recovery which was in turn a breach of the article 4 protection duty. The scope
of the protection duty is not entirely clear from the case law.

185. In _Rantsev, the substance of the duty is described as being a duty on State authorities to take_
appropriate measures within the scope of their powers to remove an individual from the risk of trafficking
(see para 286). To that end, States must “endeavour to provide for the physical safety of victims of
trafficking…and to establish comprehensive policies and programmes to prevent and combat trafficking”
(Rantsev, para 287). The protection duty is therefore said to be a duty to (i) remove victims from a
trafficking situation and (ii) prevent re-trafficking. The core of the duty is to ensure (or endeavour to
ensure) individual safety.

186. In Chowdury v Greece (App No 21884/15), 30 March 2017, para 110, the European Court of Human
Rights (“ECtHR”) added that protection measures include:

“facilitating the identification of victims by qualified persons and **assisting victims in their physical,**
**psychological and social recovery” (emphasis added).**

The ECtHR used same wording in VCL v United Kingdom (2021) 73 EHRR 9, para 153, which adds that
the two principal aims of the protection duty are “to protect the victim of trafficking from further harm and to
**facilitate his or her recovery” (emphasis added).**

187. I was referred to an agreed unofficial translation of the ECtHR's judgment in LE v Greece (App No
71545/12), 21 April 2016, in which the ECtHR held (at para 78) that the delay of nine months in recognising
the applicant as a victim of trafficking breached article 4 ECHR because it represented a substantial failure
in terms of the operational measures that the Greek authorities could take to protect her. The case does
not appear to add to the principles set down in Chowdury and VCL.

188. In TDT, Underhill LJ held at para 41 that the protection duty arises in the face of a real and immediate
future risk to victims. He was not deterred from that view by anything in Chowdury, which was cited to him.
However, the issues in _TDT were different and Underhill LJ expressly stated (at para 42) that the_
consideration of support and treatment for victims fell outside the scope of the issues raised. The case did
not need to decide whether or to what extent the protection duty involves a duty to support victims of
trafficking and provide treatment for the consequences of past ill-treatment. An attempt to “assimilate the
duty to provide assistance under article 12 of ECAT to the protection duty” failed in MN (see para 47).

189. In MS, Baroness Hale of Richmond described the protection duty (by reference to Rantsev, para 286)
as arising when the authorities “were aware, or ought to have been aware, of circumstances giving rise to a
credible suspicion that an identified individual had been, or was at real and immediate risk of being,
trafficked and exploited” (para 34). The appellant's appeal in _MS failed in relation to the protection duty_
because, once he had come to the attention of the police, he was effectively removed from the risk of


-----

further exploitation. The appeal was allowed on the alternative basis that there had not yet been an
effective investigation by the police. The issues in MS were different to the present case.

190. Both TDT and MS considered Chowdury. The ECtHR's judgment in VCL post-dated TDT and MS but
not _MN. The approach in_ _VCL cements the approach in_ _Chowdury. The importance of the approach is_
perhaps reflected by the decision to cite VCL in the ECtHR's Guide on Article 4 of the ECHR (see para 61
of the Guide as updated on 31 August 2022).

191. On the basis of the existing case law, I would not rule out that a failure to provide support for a
potential victim of trafficking may breach the protection duty of article 4 ECHR. In this case, however, there
was in my judgment no breach of the duty. The emphasis before me related to psychiatric and (to a lesser
degree) social recovery. Dr Galappathie was asked to give his opinion on “the impact of the delay in the
decision making in Ms FH's trafficking claim on her mental health” to which he responded:

“In my opinion, the delay in making a decision on Ms FH's trafficking claim, led to her suffering from a
deterioration in her mental health and prevented her from recovering from her trafficking experiences. In
my opinion, she required the external and practical security of such leave to remain in order to engage in
treatment. In my opinion, she had not been able to properly engage and benefit from the trauma work that
she requires given her unstable circumstances. Ms FH is currently suffering from severe depression,
generalised anxiety disorder, and PTSD and these conditions have worsened and had an adverse impact
on her treatment resistance, given the long period of time she had to wait for a decision in her trafficking
claim.

In my opinion, this deterioration in her mental health is likely to have occurred due to the delays in her
trafficking claim as she was already living in fear of being returned to Kenya. In my opinion, the
deterioration in her mental health will immediately worsen if she is informed that she is being returned to
Kenya at the end of her period of leave to remain. It is notable that there was a long delay from when she
received her Reasonable Grounds decision on 19 August 2019 to when she received her Conclusive
Grounds decision dated 4 April 2023, a period of 3 years and 7 months. In my opinion, it is likely that her
condition has worsened from a moderate episode of depression, generalised anxiety disorder and PTSD to
a severe episode of depression, generalised anxiety disorder and PTSD, during this period that her
trafficking decision was delayed. In my opinion, according to the Judicial College guidelines her condition
has worsened from around the lowest point of B) Moderately Severe on the Psychiatric Damage Generally
scale to the highest point of B) Moderately Severe on this scale.”

Dr Galappathie took the view that, as at the time of his assessment, the claimant had not recovered from
the impact on her mental health of being trafficked.

192. Dr Galappathie's report was served nearly a year after the present claim was lodged and so his views
cannot have had any effect on the rationality of how the defendant progressed the claimant's **_modern_**
**_slavery claim. His reasoning in relation to causation – that the claimant's worsening mental health was_**
attributable to delay – is in any event thin and does not reflect either the evidence from the claimant's
support worker at Unseen (which paints a more optimistic picture of the claimant's situation) or the
impoverished account of mental health problems in her own written evidence.

193. These other sources of evidence show that the claimant benefitted from psychological counselling.
She found it difficult to attend appointments regularly not because she was denied access or encountered
some failure by the State to make adequate provision. Rather, she suffered from bouts of being unwell
while she was pregnant and then had childcare responsibilities and also attended college, giving rise to
difficulties in attending counselling that others who are not awaiting a conclusive grounds decision may
face. Her support worker sourced some childcare for a few hours each week so that she could attend
college, thereby aiding her social recovery. In these circumstances, I do not accept that there was a
breach of the duty to assist or facilitate her “physical, psychological or social recovery” (VCL, above).

194. Further and as Mr Morgan emphasised, the claimant withdrew her challenge under article 12 of
ECAT. It would be unjust if she were able to re-introduce a complaint about the effect of delay by


-----

reference to any failure of the State to assist her recovery through the prism of a challenge under article 4
ECHR.  For these reasons, this element of the claim fails.

**Article 8 ECHR**

195. Ms Braganza submitted in the alternative that the excessive delay in reaching a conclusive grounds
decision breached article 8 ECHR: it gave rise to a disproportionate interference with the claimant's private
and family life, which includes psychological integrity (Botta v Italy (1998) 26 EHRR 241, para 32). She
submitted that the delay in NRM decision-making directly affected much of the claimant's private life, her
ability to care for her son and her psychological recovery from exploitation. The witness and expert
evidence demonstrated a serious and disproportionate interference with those rights for which there was
no justification. Mr Morgan submitted that the article 8 claim added nothing to the article 4 claim.

196. I agree with Mr Morgan that the article 8 challenge overlaps significantly with the article 4 challenge
and I would repeat what I have already said about Dr Galappathie's report and the support that the
claimant received. I would, however, add that, after giving birth to her son, the claimant attended
mother/baby groups and was supported with items from the “baby bank” such as clothing and nappies.
She was for a time housed in accommodation that was not suitable for a baby but was moved. In all the
circumstances, it is hard to discern how the defendant has done anything to interfere adversely with her
private or family life.

197. The claimant's ability to care for her son and her psychological recovery from exploitation fell within
the purview of article 12 of ECAT, about which she no longer makes any complaint. It is perhaps
conceptually difficult to discern how the United Kingdom's unchallenged compliance with the duty to
support potential victims of trafficking under ECAT can give rise to an interference with a person's right to
respect for private or family life. That aside, any interference with the claimant's article 8 rights would be
justified on the grounds that – in the absence of any viable challenge to delay – the defendant was entitled
to deploy greater resources to the reasonable grounds stage in order that others too could benefit from
article 12 assistance. The article 8 claim fails.

**Article 14 ECHR**

198. Ms Braganza submitted in the further alternative that the defendant's delay breached the antidiscrimination provisions of article 14 ECHR read with articles 4 and 8. She invited me to apply the fourstage test in _Re McLaughlin_ _[2018] UKSC 48, 1 WLR 4250, para 15, submitting that (i) this case plainly_
falls within the ambit of articles 4 and 8; (ii) the claimant (and those like her) were treated differently from
Albanian and male victims of trafficking, who were in an analogous situation; (iii) the basis for the
difference in treatment was attributable to sex and national origin; and (iv) there was no objective
justification for the difference in treatment.

199. Mr Morgan submitted that neither the prioritisation arrangements in the Ministerial Arrangement nor
the existence and operation of the Prioritisation List rendered the measures adopted by the defendant
under the NRM ineffective or of no practical effect, and so the rights enjoyed by virtue of article 14 were not
infringed. As evidenced by the contemporaneous allocation emails, the SCA continued at all times to
respond flexibly to demands upon its resources and available decision-making capacity on a week-byweek basis.

200. Article 14 of the Convention prohibits discrimination in the following terms:

“The enjoyment of the rights and freedoms set forth in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion,
national or social origin, association with a national minority, property, birth or other status.”

201. Ms Braganza focused on the Ministerial Arrangement and the List. As I have set out above, the
timing of the claimant's conclusive grounds decision was not affected by the Arrangement or by the List.
Any unlawful discrimination that may be generated by the Arrangement or the List did not have an effect on
her.


-----

202. At a systemic level, the discrimination would be justified by reference to high level social and
economic policy in the spheres of immigration control and foreign relations represented by the
Communique and its implementation through policy initiatives including the Ministerial Arrangement. As a
by-product of the Ministerial Arrangement, the List is also justified by reference to the same policy
objectives. Such high-level objectives are not conventionally the province of the judiciary which will
generally respect the judgment of the executive unless it is “manifestly without reasonable foundation” (see
e.g. R (SC) v Secretary of State for Work and Pensions _[2021] UKSC 26, [2022] AC 223, paras 158-161)._
That high threshold is not met in this case.

203. When considering the issue of justification, the ECtHR adopts a stricter approach to some grounds of
differential treatment than others and refers in its judgments to certain “suspect grounds,” such as sex,
nationality and ethnic origin, which lead to its applying a strict standard of review (SC, para 71). In cases
raising suspect grounds, “very weighty reasons” will usually have to be shown in order for the relevant
measure to be justified (SC, para 158). However, other factors can sometimes lower the intensity of review
even when a suspect ground is in issue (SC, para 158).

204. The Ministerial Arrangement was made in the context of the Government's policy towards those
arriving in the United Kingdom on small boats. The EIA stated (grammatical errors retained):

“A new policy approach to tackle all forms of illegal migration, including small boat crossings, was
announced by Prime Minister Rishi Sunak on 13 December 2022…

In 2022 so far, nearly a third of people who arrived in the UK via small boat were Albanian…

…Albanian cases will be prioritised in the NRM and asylum systems, as well as for returns action and
detention capacity, to allow increased flow of Albanians for removal…

The aims of [focusing on Albanian cases] in our immigration and modern slavery processes is to tackle
and deter illegal migration, of which Albania was the highest cohort in recent months, which puts life at risk
during Channel crossings and encourages organised crime.”

205. These matters concern social and economic strategy selected by the executive at the highest level.
To reject them as factors justifying discrimination would represent undue interference by a court in the
sphere of political choices even in a “suspect grounds” case (SC, para 162). In my judgment, the
defendant has justified the discrimination such that the article 14 claim fails.

**Issue 5a: Was there an unlawful failure to publish the Prioritisation List?**

_The parties' submissions_

206. Ms Braganza submitted that the defendant's failure to publish the List until part-way through the
hearing of the present claim was unlawful because the List contained guidance which should have been in
the public domain (R (Lumba) v Secretary of State for the Home Department _[2011] UKSC 12, [2012] 1 AC_
245, paras 34-38; R (Lupepe v Secretary of State for the Home Department _[2017] EWHC 2609 (Admin),_
para 64; _R (MXK) v Secretary of State for the Home Department_ _[2023] EWHC 1272 (Admin), para 63)._
She submitted that the List contained guidance as to how the defendant would exercise his discretionary
powers to expedite decision-making and set out factors in relation to which potential victims of trafficking
would plainly wish to make representations (including, for instance, as to their vulnerability). Without such
guidance, potential victims and those advising them were shooting at an invisible target, without knowledge
of the matters which the defendant was likely to treat as grounds for particular prioritisation.

207. Ms Braganza submitted that the Prioritisation List was at the heart of the NRM process, affecting
individual rights in relation to the protection and investigation duties under article 4 ECHR. It affected the
entire cohort of potential victims of trafficking and had an adverse impact on non-priority cases. The List
was in these circumstances the exercise of public power amounting to a policy rather than internal
administrative guidance.

208. Mr Morgan submitted that the Prioritisation List was internal administrative guidance for civil servants
that was not directed to the public. It had no bearing upon and could not change the character of the


-----

decision as to whether or not a person was a victim of trafficking. It did not compel any particular outcome
for any particular victim of trafficking. It was inherently flexible in order to respond to changing demands on
resources. It was and remained a point of reference for decision-makers as to the factors to which they
might have regard when formulating their own decisions.

_Legal framework_

209. Although a number of authorities were cited to me, the leading case remains _Lumba which_
established that a policy must be published if it will inform discretionary decisions in respect of which “the
potential object of those decisions has a right to make representations” (para 20). Lord Dyson MR
explained why policies must be published, in the following familiar terms:

“34. The rule of law calls for a transparent statement by the executive of the circumstances in which the
broad statutory criteria will be exercised…

35. The individual has a basic public law right to have his or her case considered under whatever policy
the executive sees fit to adopt provided that the adopted policy is a lawful exercise of the discretion
conferred by the statute: see In re Findlay [1985] AC 318, 338e. There is a correlative right to know what
that currently existing policy is, so that the individual can make relevant representations in relation to it. In
_R (Anufrijeva) v Secretary of State for the Home Department [2004] 1 AC 604, para 26 Lord Steyn said:_

'Notice of a decision is required before it can have the character of a determination with legal effect
because the individual concerned must be in a position to challenge the decision in the courts if he or she
wishes to do so. This is not a technical rule. It is simply an application of the right of access to justice.'

…

38….What must, however, be published is that which a person who is affected by the operation of the
policy needs to know in order to make informed and meaningful representations to the decision-maker
before a decision is made.”

210. In _XY v Secretary of State for the Home Department_ _[2024] EWHC 81 (Admin), [2024] 1 W.L.R._
2272, para 63, Lane J confirmed that the principles in Lumba apply equally to changes of existing policy:

“The defendant cannot, on the state of the evidence, deny that what the defendant's officials were being
told to do (or not to do) falls to be treated as a policy. The instructions were of a generalised nature,
bearing upon a particular class of person. However the defendant might wish to categorise them, the
instructions were a material departure from the published policy…It was a variation or modification of
**that policy and, thus, itself a policy” (emphasis added).**

211. Not all documents produced by officials within government departments are policies in the sense
outlined in Lumba.  In R (Good Law Project Ltd) v Prime Minister _[2022] EWCA Civ 1580, [2023] 1 W.L.R._
785, the Court of Appeal held in relation to the eight policies under challenge:

“59. We do not find that there is a duty to comply with the eight policies. As noted at para 10 above, we
agree broadly with the reasons given by the Divisional Court. These are policies to 'govern the internal
administration of Government departments and do not involve the exercise of public power', and are not
about individual cases or the rights of an individual. They are directed to ministers and civil servants, and
not to the public. Indeed, one of the policies warns that individuals might be subject to disciplinary action in
the event of a failure to follow it, which is a different kind of enforcement based on a contract of
employment.

…

64. There is, in our view, a real risk that, if policies such as the policies in issue in this appeal were
regarded as legally enforceable, public authorities would be deterred from adopting them, notwithstanding
the benefits that they can help to bring in terms of consistency, absence of arbitrariness and equal
treatment…


-----

65. In our view, the types of policy that are likely to attract a duty to comply are those that are the epitome
of Government policy, as appears from Friends of the Earth [2021] PTSR 190, paras 105–107. As noted
above, some of the policies were expressed to be 'guidance' and others might reasonably have been
described as 'arrangements'…This strongly suggests that the eight policies, taken on their own or as a
whole, are not the sort of policies which are or should be subject to a duty to comply enforceable by way of
a claim for judicial review.”

212. It was not in dispute before me that, if the Prioritisation List was not a policy, there was no duty under
_Lumba to publish it. The issue was whether the List was a policy or merely an administrative arrangement_
or internal guidance.

_Discussion_

213. In relation to the claimant's individual situation, this Issue is academic because she was not caught
by the Prioritisation List in unpublished form or at all. In relation to the systemic challenge to the NRM, the
Issue has become academic (albeit mid-way through the claim) because the Guidance has been amended
to include a section on the prioritisation of conclusive grounds decisions. Irrespective of the defendant's
willingness to agree that I should reach a conclusion, I doubt that it serves the interests of justice to
undertake what can only be a retrospective and outdated analysis of whether there was a duty to publish
the List before the Guidance was amended.

214. It is one thing for the court to agree that the academic nature of the claim in relation to the claimant's
own case should not prohibit some wider, systemic challenge on the basis that judicial consideration may
lead to some more general public good. It is quite another thing for the court to permit its resources to be
used after the defendant has done what the claimant's representatives wanted him to do and after the
public good that propelled the claim has come about.

215. The claimant placed at the heart of her submissions the proposition that advisers were unable to
make representations about the place of their clients in the queue because the List had not been
published. I confess to some concern that claims for judicial review could be launched about whether a
particular case has been allocated to a decision-maker within the SCA in accordance with any extant list of
categories used by civil servants as an aid to queuing work. The courts should not be asked to micromanage the workload of SCA decision-makers.

216. The defendant would on the claimant's analysis be compelled to treat case allocation as the exercise
of public power (Good Law Project, para 59, above) and to act accordingly. The prospect of resources
being diverted from substantive decisions to invidious procedural decisions in order to deal with those
asserting that their own case should be allocated at some particular point would be inexpedient. It would
give rights to potential victims of trafficking that are not replicated in numerous other points of interaction
between the individual and the State where claims for a public benefit enter a “queue”. I have doubts
about whether the ability of potential victims, and those advising them, to shoot at a moving target (to
reflect Ms Braganza's language) would carry any public interest.

217. Setting aside these various concerns, the claimant's submissions fail on their merits. The
Prioritisation List has none of the hallmarks of a policy directed to the public. It was plainly a form of
internal administrative guidance intended to inform the defendant's approach to allocating cases and to the
sequence in which cases were to be addressed. It was directed to civil servants and to the deployment of
resources. It was not directed to the public. It was temporary in nature: having been introduced in
February 2023, it was changed in October 2023 and again in November 2023.  The changes were
contained in internal emails as part of the day-to-day working arrangements of decision-makers. They had
no particular life span: it would not have been unlawful for further emails to contain further changes. There
would seem little or no concrete scope for a potential victim of trafficking to make representations in
reliance on a changing List.

218. The claimant submitted that the amendment of the Guidance during the course of these proceedings
amounted to a concession by the defendant that the List ought all along to have been published as a
policy. That submission cedes too much power to the executive. It is for judges to determine the legal


-----

status of government documents in accordance with established principles of law. If the mere publication
of a document were regarded as giving rise to legal consequences, there would be a risk that public
authorities would be deterred from publication with damage to the more general public interest in
transparent and open government.

219. Nor is the Prioritisation List inconsistent with the published Guidance. As I have held, there is no
inconsistency between a duty under the Guidance to make conclusive grounds decisions “as soon as
possible” and the prioritisation of some types of case over others. The List did not mark a change of any
policy, so that this is not a case in which Lane J's observation in XY applies.

220. In these circumstances, there was no duty to publish the List and there is no reason why article 4
ECHR should be engaged. The claimant seeks a mandatory order that the defendant publish any revised
prioritisation policy. As I have indicated, the Guidance as amended confirms that any changes to
prioritisation will be published in the Guidance. I see no practical purpose in making an order to compel a
course of action that the defendant has said that he will take. I dismiss this ground of challenge and refuse
the request for a mandatory order.

**Issue 5b: Whether the defendant's allocation processes involved unlawful discrimination contrary**
**[to the Equality Act 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)**

221. Ms Braganza submitted that the claimant and others in the NRM have suffered discrimination under
[the Equality Act 2010 contrary to the prohibition on discrimination in the exercise of a public function under](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
section 29 of the Act. The Prioritisation List was directly discriminatory within the meaning of section 13 of
the Act on grounds of nationality: it discriminated against all non-Albanians. The List was also indirectly
discriminatory, under section 19, on grounds of sex and disability.

222. Ms Braganza relied on evidence that men make up 84% of Albanian referrals. According to the
defendant's statistics for 2021, 77% (9,790) of those referred to the NRM were male; 23% (2,293) were
female; 50% (6,411) were adults and 43% (5,468) were children. She submitted that there is no specific
provision within the List for disabled individuals such as those who suffer from psychiatric problems.

223. As regards direct discrimination because of nationality, I have already set out that paragraph 1(1)(d)
and (2) of Schedule 23 to the 2010 Act authorises the executive to introduce measures that are excepted
from the anti-discrimination provisions of Part 3 which includes section 29. Given the terms of this
provision, I agree with Mr Morgan that a claim of unlawful direct discrimination cannot succeed: direct
discrimination was lawful by virtue of the Ministerial Arrangement made under the statutory excepting
provision.

224. Turning to indirect discrimination, the parties were agreed that the key question is whether the
defendant can show that any indirect sex or disability discrimination was “a proportionate means of
achieving a legitimate aim” (section 19(2)(d) of the 2010 Act). Each party relied on the same or similar
factors as underpinned their respective submissions on the question of justification under article 14 ECHR.
In these circumstances, I mean no disrespect to the parties by not elongating this judgment with further
analysis of the rationale and objectives of the Ministerial Arrangement and the List. In my judgment, any
indirect discrimination was justified and proportionate. This aspect of the claim fails.

**Issue 5c: Whether the prioritisation of Albanian cases had due regard to the PSED**

225. The PSED is contained in section 149 of the Equality Act 2010 which provides in so far as material:

“(1) A public authority must, in the exercise of its functions, have due regard to the need to—

(a) eliminate discrimination, harassment, victimisation and any other conduct that is prohibited by or under
this Act;

(b) advance equality of opportunity between persons who share a relevant protected characteristic and
persons who do not share it;

…..


-----

(3) Having due regard to the need to advance equality of opportunity between persons who share a
relevant protected characteristic and persons who do not share it involves having due regard, in particular,
to the need to—

(a)  remove or minimise disadvantages suffered by persons who share a relevant protected characteristic
that are connected to that characteristic;

(b)  take steps to meet the needs of persons who share a relevant protected characteristic that are
different from the needs of persons who do not share it;

(c) encourage persons who share a relevant protected characteristic to participate in public life or in any
other activity in which participation by such persons is disproportionately low.”

226. “Protected characteristics” are defined in section 149(7) and include sex and disability on which the
claimant relies in this case.

227. The approach to be taken by the courts in considering the PSED has been recently re-stated by
Lewis LJ (with whom Arnold LJ and Asplin LJ agreed) in _Webb-Harnden v Waltham Forest London_
_Borough Council [2023] EWCA Civ 992, [2023] HLR 45:_

“13. The general approach to whether the duty has been complied with is well established. The duty
applies in the exercise of an authority's functions. In broad terms, the duty under section 149 is a duty to
have due regard to the specified matters not a duty to achieve a specific result. The duty is one of
substance, not form, and the real issue is whether the relevant public authority has, in substance, had due
regard to the relevant matters, taking into account the nature of the decision and the public authority's
reasoning (see, e.g, _Baker v Secretary of State for Communities and Local Government (Equality and_
_Human Rights Commission intervening) [2009] P.T.S.R. 809 at paragraphs 36-37, and_ _Bracking v_
_Secretary of State for Work and Pensions_ _[2013] EWCA Civ 1345; [2014] Eq. L.R. 60, at paragraph 26). As_
Lord Neuberger of Abbotsbury PSC observed at para 74 of his judgment in _Hotak v Southwark LBC_
_(Equality and Human Rights Commission intervening) [2015] P.T.S.R. 1189 'the weight and extent of the_
duty are highly fact-sensitive and dependant on individual judgment'. Relevant principles are set out at
paragraph 26 of the judgment of McCombe LJ in _Bracking. As the Court of Appeal has subsequently_
observed, that decision has to be read in context and the application of the duty will differ from case to
case depending upon the function being exercised and the facts of the case. Furthermore, courts should
be careful not to read the judgment in Bracking as though it were a statute: see Powell v Dacorum Borough
_Council_ _[2019] EWCA Civ 23; [2019] H.L.R. 21 at para 51 and see R. (Kays) v Secretary of State for Work_
_and Pensions_ _[2022] EWCA Civ 1593 at paragraphs 41 to 42.”_

228. Ms Braganza submitted that the defendant could not show compliance with the PSED in relation to
the Prioritisation List which discriminated against non-Albanians and against women (most Albanians in the
NRM being men) and against people with disabilities. As expressed in the claimant's skeleton argument,
the underlying purpose of the List was to discriminate against all non-Albanians and against women.
There was no EIA in relation to the List. The defendant had failed to consider the extent of the impact of
discrimination and any lesser measures to be applied.

229. Ms Braganza submitted that the most obvious lesser measure which should have been implemented
immediately was to inform those affected that they were about to be the victims of discrimination so that
“stakeholders could respond and advisers could advise”. The operation of a secret system (unknown to
those affected by it) amounted to State-operated and approved discrimination which was abhorrent.

230. I do not agree with these submissions. The thrust of the argument is not that the claimant or anyone
else has suffered from any lack of regard for the PSED in achieving a positive conclusive grounds decision.
The challenge relates to decisions about the order in which conclusive grounds decisions are taken.  The
prioritisation of Albanian cases was authorised under the Ministerial Arrangement which has a statutory
footing and which was preceded by a detailed EIA. I was provided with a further EIA dated 25 July 2023
and a draft EIA dated 26 May 2023. Ms Braganza criticised the EIAs as failing to meet standards of
equality law but in truth no realistic or cogent challenge was mounted to the scope or depth of these
documents The claimant's submissions in any event failed to recognise that NRM decision-making is


-----

governed by the Guidance. I was directed to no part of the extensive provisions of the Guidance that
would suggest any breach of the PSED.

231. Upon analysis, the challenge amounts in effect to an attempt to achieve a specific result in the form
of a merits-based challenge to the List; and the submission that stakeholders and others ought to have
been informed of the List amounts to a merits-based challenge to its non-publication. As Webb-Harnden
has put beyond doubt, such an approach is not permitted. This part of the claim fails.

**Issue 5d: Whether the defendant's allocation processes or the List were otherwise unlawful or**
**unreasonable**

232. The claimant's residual submissions do not seem to me to provide concrete particulars of any other
ground of challenge. It is not for the court to search or amplify Counsel's submissions in order to discover
some further basis for relief. The “sweep-up” formulation of Issue 5d renders it otiose.

**Issue 6: Relief**

233. For the reasons given in relation to the various different Issues, each of the grounds of challenge fails
and there are no grounds for relief.

**Conclusion**

234. The claim is dismissed.

**Postscript**

235. This judgement should come as limited comfort to the defendant. That he has surmounted the legal
challenge does not mean that the situation is satisfactory. I would gratefully adopt and reiterate Underhill
LJ's observation in EOG, para 92 (cited above): solving the problem of this sort of delay would aid victims
of trafficking, the Home Office and the courts.

**End of Document**


-----

# R (on the application of FH) v Secretary of State for the Home Department

## [2024] EWHC 1327 (Admin)

 Court: Queen's Bench Division (Administrative Court) Judgment Date: 04/06/2024

# Catchwords & Digest

## IMMIGRATION - CONCLUSIVE GROUNDS DECISION – DELAY IN MAKING DECISION

      The Administrative Court dismissed the claimant’s application for judicial review regarding the defendant’s delay in making a conclusive grounds decision. The claimant had been referred to the process operated by the defendant for identifying victims of trafficking and modern slavery under the Modern Slavery Act 2015. A delay of three years and eight months occurred between the reasonable grounds and conclusive grounds decisions. Among the grounds of review was the contention that the delay in reaching a decision on the claimant’s individual case was unreasonable, discriminatory and in breach of the claimant’s rights under the European Convention on Human Rights (“ECHR”). The court held, among other things, that the statutory guidance published pursuant to the Act stated that a conclusive grounds decision would be taken at least 30 calendar days after the reasonable grounds decision. The guidance provided for the conclusive grounds decision to generally be taken as soon as possible with some cases to be prioritised. The prioritisation of cases for the purpose of allocation to case workers was not inconsistent with the guidance that decisions should generally be taken as soon as possible. In the absence of irrationality, the systemic challenge failed. As the claimant had since received a conclusive grounds decision, the challenge to delay in her own case was academic. Finally, there was no breach of her human rights. Each of the grounds of challenge having failed, there was no basis for granting relief.

# Cases considered by this case


XY v Secretary of State for the Home Department

_[[2024] EWHC 81 (Admin), [2024] 1 WLR 2272, [2024] All ER (D) 01 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6B7G-1CS3-RT19-B2M9-00000-00&context=1519360)_
Considered

Webb-Harnden v London Borough of Waltham Forest

_[[2023] EWCA Civ 992, [2023] All ER (D) 91 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:690Y-CV53-RRT6-X4FM-00000-00&context=1519360)_
Considered


23/01/2024

AdminCt

22/08/2023

CACivD


R (on the application of PM) v Secretary of State for the Home Department 23/06/2023

AdminCt


-----

_[[2023] EWHC 1551 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68HW-W0W3-RRMB-313B-00000-00&context=1519360)_
Considered
R (on the Application of MXK and others) v Secretary of State for the Home
Department

_[[2023] EWHC 1272 (Admin), [2023] All ER (D) 98 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68K0-PB73-RWXY-F4W4-00000-00&context=1519360)_
Considered

R (on the application of the Good Law Project Ltd) v Prime Minister and others

_[[2022] EWCA Civ 1580, [2023] 3 All ER 760, [2023] 1 WLR 785, [2022] All ER (D) 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68XB-JD03-RRNF-50NG-00000-00&context=1519360)_
_[(Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:671X-DMG3-CGX8-02K7-00000-00&context=1519360)_
Considered

EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v
Secretary of State for the Home Department

_[[2022] EWCA Civ 307, [2023] QB 351, [2022] 3 WLR 353, [2022] INLR 213, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
_[ER (D) 70 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
Considered

MN v Secretary of State for the Home Department; IXU v Secretary of State for the
Home Department (AIRE Centre and another intervening)

_[[2020] EWCA Civ 1746, [2021] 1 WLR 1956, [2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
Considered

MS (Pakistan) v Secretary of State for the Home Department

_[[2020] UKSC 9, [2020] 3 All ER 733, [2020] INLR 460, [2020] All ER (D) 111 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60J0-VFB3-GXFD-805F-00000-00&context=1519360)_
Explained

R (on the application of O and another) v Secretary of State for the Home Department

_[[2019] EWHC 148 (Admin), [2019] All ER (D) 164 (Jan)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V0C-18T2-8T41-D0RB-00000-00&context=1519360)_
Explained

Re McLaughlin's Application for Judicial Review (Northern Ireland)

_[[2018] UKSC 48, [2019] NI 66, [2019] 1 All ER 471, [2018] 1 WLR 4250, [2018] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W6F-T212-D6MY-P0CH-00000-00&context=1519360)_
_[(D) 144 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T52-6V31-DYBP-N06D-00000-00&context=1519360)_
Considered

R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State
for the Home Department (Equality and Human Rights Commission intervening)

_[[2018] EWCA Civ 1395, [2018] 1 WLR 4922, [2018] All ER (D) 38 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
Explained

R (on the application of Lumba) v Secretary of State for the Home Department; R (on
the application of Mighty) v same

_[[2011] UKSC 12, [2012] 1 AC 245, [2011] 4 All ER 1, [2011] 2 WLR 671, (2011) Times,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_
24 March, [2011] All ER (D) 262 (Mar)
Applied

Rantsev v Cyprus and Russia (Application 25965/04)

_[[2010] ECHR 25965/04](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_
Considered

**End of Document**


26/05/2023

KBD

01/12/2022

CACivD

17/03/2022

CACivD

21/12/2020

CACivD

18/03/2020

SC

31/01/2019

AdminCt

30/08/2018

SC

19/06/2018

CACivD

23/03/2011

SC

07/01/2010

EctHR


-----

