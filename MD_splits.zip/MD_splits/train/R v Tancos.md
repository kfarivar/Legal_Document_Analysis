# R v Tancos [2023] EWCA Crim 153

Court of Appeal, Criminal Division

Coulson LJ, Cutts J, HHJ Munro KC

31 January 2023Judgment

MR N MOHINDRU KC appeared on behalf of the Appellant

MISS L WILDING appeared on behalf of the Crown

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. MRS JUSTICE CUTTS: On 4 April 2022 following a lengthy trial at the Crown Court at Bristol, this
appellant was convicted of 10 trafficking offences. Count 1 was an offence of the trafficking of another
person into the United Kingdom for labour exploitation, contrary to section 4(1)(a) of the Asylum and
Immigration (Treatment of Claimants) Act 2004. Counts 2, 3 and 4 were all conspiracies to traffic people
into the United Kingdom, contrary to section 1(1) of the Criminal Law Act 1977. Count 2 related to offences
under section 4(1) and subsection (5) of the Asylum and Immigration (Treatment of Claimants) Act 2004,
[as amended by the UK Borders Act 2007. Count 3 related to offences under the same provisions of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y0HC-00000-00&context=1519360)
same Act but as amended by the _[Protection of Freedoms Act 2012. Count 4 related to offences under](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JD-N4J1-DYCN-C16J-00000-00&context=1519360)_
section 2(1) and subsection (5) of the Modern Slavery Act 2012. Counts 5, 6 and 7 involved conspiracies
to traffic people within the United Kingdom. Count 5 was a like offence to count 2, count 6 a like offence to
count 3 and count 7 a like offence to count 4. Counts 8 and 9 represented conspiracies of forced labour.
Count 8 related to offences under section 71 of the Coroners and Justice Act 1977 and count 9 to offences
under section 1(1)(b) of the **_Modern Slavery Act 2015. Count 10 was a conspiracy to acquire criminal_**
property.

2. On 22 June 2022 the appellant was sentenced to 16 years' imprisonment on each of counts 4, 7 and 9
concurrent. No separate penalty was imposed on all other counts. A total therefore of 16 years'
imprisonment. Ancillary orders were made. The appellant appeals this sentence with leave of the single
judge.

The facts


-----

3. Between 1 June 2007 and 18 July 2017 the appellant and his co‑accused, with the assistance of others,

trafficked people into the United Kingdom in order to subject them to forced labour under the threat of fear
or punishment. The victims were Slovakian or Hungarian and came from impoverished backgrounds.
Many were raised in orphanages and were destitute with nowhere to go once they reached adulthood. The
appellant knew of the orphanages as he lived close by. He had previously run a construction company in
the Czech Republic and was well known. He promised victims free transport to the United Kingdom,
somewhere to live, food, work and the ability to keep 50 per cent of their wages. Some victims were
recruited directly and others through word of mouth by others associated with the appellant.

4. The reality was entirely different. Once in the United Kingdom the victims were put into forced labour,
had their identities and wages stolen and their bank accounts (which the appellant had helped to set up)
and bank cards were used without their consent. Documents were only returned to them to allow victims to
make applications for National Insurance numbers that would enable them to gain employment and open
bank accounts into which their wages would be paid. The front door to the houses where the victims
stayed were locked.

5. Their travel would be arranged for them. Upon arrival in the United Kingdom the victims would be met

by the appellant and driven to an address at 72 Brentry Lane in Bristol. This was a three‑bedroomed

property. Victims were crammed in two bedrooms and onto filthy mattresses there and in the loft. They
spoke limited English and had no knowledge of the local area. Three addresses in total were used to
house victims.

6. The appellant would accompany victims ostensibly to act as an interpreter when they opened bank

accounts. The appellant and his co‑accused would keep the bank cards and PIN number letters from

which they would withdraw the victims' wages. The victims had no access to the money paid into their
bank accounts.

7. Initially victims were sent to work at a car wash owned by the appellant. Later they would be taken to
recruitment agencies and registered to work in local factories and companies, usually in low paid manual
roles. On occasion they were told to work in someone else's name.

8. The appellant and his co‑accused would drain the victims' bank accounts at the end of each week.

They lived off the victims' earnings. Between 2010 and 2017 nearly £300,000 was transferred by the

appellant and his co‑accused via Western Union. Cash withdrawals were used to fund gambling in

casinos, the purchasing of motor vehicles and living expenses.

9. This pattern of abuse was repeated with multiple victims. Some stayed for short periods; others

remained for years. The offending came to a halt when the appellant and his co‑accused were arrested at

Brentry Lane on 18 July 2017. The police found five Slovakian men at the address who were taken by
officers for their own safety. A total of 29 victims of human trafficking were identified.

10. Two mobile telephones found by the police evidenced that the appellant and his co‑accused were the

victims' point of contact for registration with employment companies and with banks and for loans. These
phones contained 120 identical stored contacts which included 14 recruitment agencies and employers, as
well as images of bank cards, PIN numbers, employment records, identity documents, air flight details,
travel documentation and online bank statements.

11. The appellant made no comment in his police interview.

12. Fourteen victims gave evidence at trial. Each was treated in the way we have set out and it is
unnecessary for the purposes of this appeal to set out in detail the circumstances of the offending against
each, save to observe that the appellant used physical violence to control some, including Peter Onody,
who on one occasion tried to commit suicide. He was not permitted to seek medical attention when he was
hit by a car at the car wash and still suffers from kidney problems as a result. Martin Drabcak suffered
from a heart defect and had breathing difficulties. The appellant refused to take him to hospital. He also


-----

bullied him because he was gay. Peter Pecha was slapped by the appellant when he did not do as he was
told. He was injured at work in a factory in 2016 and unable to work there for eight months in
consequence. The appellant nonetheless made him work at the car wash. Witnesses also spoke of not
having enough food to eat and the houses in which they slept being always cold.

Impact statements

13. Eleven of the 14 victims who gave evidence provided impact statements. It is plain that all were
affected by their treatment by the appellant. We pick out some as examples of the impact upon them but
make clear that we have read them all.

14. Peter Onody spoke of his suicide attempt after the appellant refused to lend him 30 euros to fund
medical treatment for his nephew in Slovakian. He said:

"What he was doing with us it was catastrophic. I would not wish for even a dog to experience what we
had to go through."

15. He described mentally hitting rock bottom. He described being happy as he was free and not suffering
any more.

16. Martin Drabcak talked of the appellant destroying half his life in the eight years he was in the United
Kingdom and that it was hard to move on. Every day he said he was stressed and had depression. He
described the appellant as permanently marking him.

17. Alexander Pumpa described Brentry Lane as a gate to hell. He described being a slave there and
thought there was no way out. He described his gratitude to those who had rescued him.

18. Katarina Timkova spoke of the grim conditions in the house with not enough to eat. She had a baby

whilst there who was malnourished and suffered ill‑health as a result and was suffering ongoing difficulties

in life. Others spoke of their fear and distress in the United Kingdom. Some were unwilling or unable to
discuss the impact on them, one for fear he would cry. Some were unable to sleep and remained in fear.

Sentence

19. The appellant had no previous convictions in the United Kingdom. He had a previous conviction in the
Czech Republic for disorderly conduct and extortion and in the Slovak Republic for burglary. He was
subject to a suspended sentence imposed abroad at the time of some of the instant offending.

20. In his sentencing remarks the judge described the vulnerability of the victims targeted by the appellant

and his co‑accused who, once in the United Kingdom, were trapped and forced into labour, sometimes for

years, solely for the financial benefit of the appellant and his co‑accused. They were made to work for

nothing and do so in a way that utterly failed to respect their lives as workers, let alone the respect to which
they were entitled as human beings. In the view of the judge the appellant treated his victims as property,

robbing them of their confidence and self‑respect. They represented a cash value to him in the same way

cattle do to a farmer.

21. The judge said that he had read the impact statements which he said were made by "desperate and
damaged people" and were consistent with what he saw of witnesses during the course of the trial. He

observed that the circumstances surrounding the three‑month trial had been subject to the most detailed

scrutiny which had provided him with substantial insight into the nature of the crimes, as well as the
character of the criminals who perpetrated them. In his view the appellant had expressed no remorse or
regret.

22. The judge had some regard to the fact that the appellant had been on remand during the height of the
pandemic which could not have been easy. He also had regard to his health issues.

23. The judge approached sentence by imposing the lead sentence on counts 4, 7 and 9, as these carried
the highest maximum terms of imprisonment. The sentences however would be reflected in all the


-----

offences of which the appellant had been convicted, each of which would in themselves have merited
substantial periods of custody.

24. The judge placed the appellant's offending within culpability Category A of the relevant sentencing
guideline by reason of the fact he played a leading role, there was an expectation of substantial financial
advantage and there was a high degree of planning or premeditation.

25. So far as harm was concerned, the judge accepted the contention of the prosecution that it fell within
Category 2. Having seen and heard the victims and taken account of their impact statements, he said that
he was quite sure that the level of psychological harm was serious and would have a substantial long term
effect. The judge was also sure that the victims will suffer long term impacts on their daily lives. This, he
said, of course varied between victims but he had to make an overall assessment.

26. The judge then stated that as a result of his categorisation of the offending within the sentencing
guideline, the starting point was one of 12 years and the range 9 to 14. In so saying he fell into error.
Those are the figures for offending falling within Category 1B. The correct starting point for a Category 2A
offence is 10 years' imprisonment with a range of 8 to 12 years.

27. The judge did not accept the prosecution contention that the number of victims, the impact upon them
and the period over which the offending took place elevated any offence to Category 1A. He was
unpersuaded that any individual count fell within that category. Instead he said those factors identified by
the prosecution would properly merit a sentence outside of the category range.

28. The judge was careful to avoid double counting matters that operated so as to set the level of
culpability and harm. He found aggravating factors in the homophobic bullying of Mr Drabcak and the
appellant's previous convictions. There was little mitigation, he said, beyond his health issues. The judge
stated that in the appellant's case some significant movement upwards from the starting point was
required, even to the extent of taking the sentence outside of the category range. Even having regard to
the mitigation such as it was, a total sentence of 16 years' imprisonment in his view was commensurate
with the seriousness of the offending.

The appeal

29. Mr Mohindru KC, who appears on behalf of the appellant as below, appeals this sentence on three
principal grounds. First, he submits that the judge erred in adopting the starting point and category range
of Category 1B within the relevant guideline, despite having clearly placed the offending into Category A2.
This raised the starting point and range from that within A2. Mr Mohindru submits that this amounts to a
structural defect of the sentence and a factor rendering it manifestly excessive. He submits it is at least
two years' imprisonment in excess of what it ought to have been.

30. Second, that the judge erred in his categorisation of harm within the guidelines in that he overstated
the impact on the victims as set out in their personal statements and failed to take sufficient, if any, account
of the Category 3 factors that were present. Mr Mohindru submits that there were a greater number of
Category 3 than Category 2 harm factors. In particular he points to the impact statements of some of the
victims to the effect that they are now doing much better. Their descriptions of feeling sad, helpless, fearful
and angry at the time are in his submission better characterised as some psychological harm, rather than
serious psychological harm. Mr Mohindru concedes that Mr Onody and Mr Drabcak described serious
psychological harm with a long term impact, but submits that the judge had to look at the picture overall
which was not as serious as he found it to be. Whilst this alone did not render the Category 2 classification
incorrect, it is a matter which should in his submission have been reflected in a downward movement from
the starting point for Category 2.

31. Third, and Mr Mohindru accepts that this is really part of ground 2, that the judge erred in passing a
sentence outside of the range in the relevant category of the guidelines. In this regard Mr Mohindru
concedes that an uplift of some significant level from the starting point was justified on the basis of the
number of counts, number of victims and time span of the offending. However, he submits that the
downward adjustment he contends for in ground 2 ought to have been such as to render a sentence
outside of the guidelines not in the interests of justice


-----

Discussion

32. It is plain from the sentencing remarks that the judge having placed the offending into Category 2A fell
into error in setting out the starting point and range for Category 1B which was two years higher, both in
starting point and range.

33. We have considered carefully whether that error led the judge into passing a sentence for the totality
of the appellant's offending which was excessive and manifestly so. We have come to the conclusion that

it did not. The judge had presided over a three‑month trial. As he himself said, this afforded him the

opportunity to consider the nature of the appellant's offending in detail. He saw 14 victims give evidence
and was in the best possible position to assess the impact of the appellant's offending upon them, both
from the evidence they gave and from the impact statements they provided. It is unsurprising in our view
that some victims were affected more than others. But we agree with the respondent that the judge had
abundant evidence of serious psychological harm being caused in this case.

34. We are unpersuaded that the judge fell into error in finding that taken in the round those victims had

suffered a substantial and long term adverse impact on their day‑to‑day life since the offending ceased.

This was a case in our view that fell squarely into Category 2 harm and no downward adjustment was
warranted on the basis of the victim impact. It is to be remembered that the starting point and range in the
sentencing guidelines are for a single offence.

35. As Mr Mohindru concedes, the scale of this appellant's offending justified an overall sentence outside
of the category range for a single offence. The question is whether a sentence of four years outside the
category range for a 2A offence renders the sentence imposed manifestly excessive. We are again of the
view that it does not. The judge was sentencing on counts 4, 7 and 9 as the lead offences. The total
sentence had to reflect the appellant's offending on those and seven further counts, each of which, as the
judge said, alone merited a substantial term of imprisonment.

36. A total sentence of 16 years' imprisonment was in our view just and proportionate taking into account
the number of offences, the time over which the offending took place and the circumstances of that
offending, for all the reasons the judge carefully set out in his sentencing remarks. This appeal is
accordingly dismissed.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

