(TC)

# TC09126: ELPHYSIC LTD; PHYARREIDON LTD; ROSSCANA LTD;
 ZRAYTUMBIAX LTD [2024] UKFTT 291 (TC)

DECISION NUMBER: TC09126

FIRST-TIER TRIBUNAL (TAX CHAMBER)

LOCATION: TAYLOR HOUSE, LONDON

CASE REFERENCE NUMBERS: TC/2022/12879; TC/2022/12880; TC/2022/00735; TC/2022/01302;
TC/2022/12881

TRIBUNAL CHAIRMAN: JOHN BROOKS

TRIBUNAL MEMBER: HUNTER

DATE: 8–12, 15–19, 22–25 MARCH 2024, DECISION DATE 27 MARCH 2024Release Date: 27 MARCH 2024

APPELLANT: ELPHYSIC LTDPHYARREIDON LTDROSSCANA LTDZRAYTUMBIAX LTD

RESPONDENTS: COMMISSIONERS FOR HIS MAJESTY'S REVENUE AND CUSTOMS

**VAT/NIC — Mini-umbrella companies (MUCs) — Whether HMRC have power to de-register MUCs on basis**
**that their VAT numbers are/will be used for fraudulent/abusive purposes pursuant to decision in Valsts**
**ieņēmumu dienests v Ablessio SIA Case C-527/11 — Whether MUC business model/scheme an organised**
**and contrived structure for purpose of defrauding HMRC — Whether fraud properly pleaded — Whether**
**removal of entitlement to use VAT Flat Rate Scheme and consequent issue of assessments reasonable —**
**Entitlement to claim Employment Allowance — Appeals allowed in part**

APPELLANT: ELPHYSIC LTDPHYARREIDON LTDROSSCANA LTDZRAYTUMBIAX LTD

RESPONDENTS: COMMISSIONERS FOR HIS MAJESTY'S REVENUE AND CUSTOMS

FOR THE APPELLANT: DANIEL MARGOLIN KC AND IAIN MACWHANNELL OF, AND DAVID BEDENHAM OF
COUNSEL INSTRUCTED BY, JOSEPH HAGE AARONSON LLP.

FOR THE RESPONDENTS: JAMES PUZEY AND JOSEPH MILLINGTON, BOTH OF COUNSEL, INSTRUCTED
BY THE GENERAL COUNSEL AND SOLICITOR TO HM REVENUE AND CUSTOMS.
**DECISIONINTRODUCTION**
1.

The use of mini-umbrella companies (“MUCs”) or specialist contracting intermediaries (“SCIs”), another name by
which MUCs are known, has arisen because of the significant growth in the temporary labour market in the UK and
the use of recruitment agencies, at the request of the end user such of such labour (eg a factory or warehouse) to
administer the payroll of those temporary workers, something many recruitment agencies outsource.
2.

Different “models” exist for processing payroll which are dependent on the particular industry and the circumstances
of the temporary workers, eg in the construction industry there is the CIS Scheme. Under one payroll model,
employment intermediaries act as an “umbrella employer”. Such an umbrella employer is responsible for deducting


-----

(TC)

and making payment to HM Revenue and Customs (“HMRC”) of any applicable National Insurance Contributions
(“NIC”) and income tax under Pay As You Earn (“PAYE”) before paying the net salary to the worker.
3.

It had been relatively common, in relation to certain temporary workers, for intermediaries when calculating pay and
deductions to make claims for the workers' travel and subsistence expenses. However, their ability to do so was,
save in a limited number of circumstances, restricted from 6 April 2016 by _[s 14 of the Finance Act 2016. From](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5KTJ-NH11-DYCN-C539-00000-00&context=1519360)_
around March/April 2016, a significant number of recruitment agencies (including a number of the larger recruitment
agencies) and intermediaries started to use what has been called the mini umbrella model (the “MUC model”) to
employ significant numbers of people. The MUC model continues to be used and, to date, some hundreds of
thousands of workers have been employed through it.
4.

Under the MUC model, a MUC:

(1)   employs temporary workers and deals with HMRC in relation to any tax liabilities arising from that
employment including making use of the Employment Allowance (“EA”);

(2)   supplies its employees' labour to employment intermediary companies, which, in turn, supply that
labour to recruitment agencies for onward supply to end-users;

(3)   charges VAT to the intermediary companies at the standard rate; and (4) utilises the VAT Flat Rate
Scheme (the “FRS”) as explained below. 5. Each of the Appellants in this case is a MUC.

6.

Daniel Margolin KC, Iain MacWhannell and David Bedenham appeared for the Appellants. HMRC were represented
by James Puzey and Joseph Millington.
7.

We were very much assisted by the clear submissions, both written and oral, on behalf of the parties but, although
carefully considered, we have not found it necessary to refer to each and every argument advanced, all of the
authorities cited or all of the evidence before us in reaching our conclusions.
_LEAD CASE PROCEDURE_
8.

Under Rule 18 of the Tribunal Procedure (First-tier Tribunal) (Tax Chamber) Rules 2009, where two or more cases
give rise to common or related issues of fact or law, the Tribunal may make a direction specifying one or more
cases as “Lead Cases” and staying the other related cases.
9.

On 21 October 2022 the Tribunal (Judge Sinfield) made such a direction (the “October 2022 Directions”) specifying
the appeals of Jazztify Limited (“Jazztify”), Elphysic Limited (“Elphysic”), Phyarreidon Limited (“Phyarreidon”),
Rosscana Limited (“Rosscana”) and Zraytumbiax Limited (“Zraytumbiax”), as Lead Cases under Rule 18. Judge
Sinfield also directed that the many thousands of related cases be stayed until 60 days after the release of the
Tribunal's decision in the Lead Cases.
10.

On 3 January 2024 Jazztify withdrew its appeals and it was directed that the appeals of Elphysic, Phyarreidon,
Rosscana and Zraytumbiax (together the “Lead Appellants”) remain as the Lead Cases with the directions that had
previously made in relation to the related cases continuing to apply.
11.

The following “common or related issues of fact and law” arise in the Lead Cases, as set out in Schedule 2 to the
October 2022 Directions:


-----

(TC)

(1)   Whether HMRC have power to de-register for VAT taxable persons on the basis that HMRC have
concluded that person is using its VAT registration for fraudulent, or abusive purposes, or will do so in the
future.

(2)   Whether there is an organised and contrived structure with the purpose of defrauding the Revenue
by claiming tax benefits which the Lead Appellants were not entitled to including registration for VAT, the
use of the “FRS”, and the use of the EA.

(3)   Whether the Lead Appellants “used their VAT registrations for fraudulent or abusive purposes or
allowed them to be so used or were likely to do so in the future and therefore whether the Appellants were
liable to be de-registered for VAT, pursuant to the decision of the Court of Justice of the European Union
(“CJEU”) in Valsts ieņēmumu dienests v Ablessio SIA Case C-527/11 (“Ablessio”).

(4)   Whether the Lead Appellants were entitled to use the FRS or whether, as HMRC allege, they failed
to meet the requirements of Regulations 55A and L of the Value Added Tax Act Regulations 1995 (the
“1995 Regulations”) and were liable to have their authorisation terminated under Regulation 55P of the
1995 Regulations.

(5)   Whether the Lead Appellants “misused the FRS by registering for that scheme in false trade classes
to benefit from a more advantageous FRS rate.”

(6)   Whether the Lead Appellants are liable to HMRC for the assessed VAT. (7) Whether or not the Lead
Appellants were entitled to claim EA.

_EVIDENCE_
12.

In addition to an electronic hearing bundle comprising 7,294 pages, a supplementary bundle comprising 127 pages
and over 120 detailed spreadsheets, we heard from HMRC Officers Christopher Harker, Neil Copeland, Stuart
Knowles, Adam Edmondson, James Sheilds, Julie Barnes, Martin Bowe, Gavin Emms, Kevin Wright and Brian
Price.
13.

Officer Chritopher Harker, a Senior Officer for HMRC (previously HM Customs and Excise) has been continuously
employed in a VAT related role since 1989. He was the “decision maker” for the VAT elements of the decisions
under appeal. From 2011 he has worked in a Labour Market team and more recently has specialised in traders who
use the MUC model. He referred to the MUC “scheme” as being:

“… a contrived structure designed to defraud by claiming HMRC reliefs to which they are not entitled”

In addition to saying that the Lead Appellants were part of that “contrived structure”, Officer Harker agreed, when it
was put to him in cross examination, that he had not alleged any particular individual or entity was dishonest or
fraudulent although he maintained, when re examined, that as far as he was concerned:

“… it's the model that is fraudulent. The model is, you know, using these reliefs to which in my mind they're not
entitled and therefore it is the model that is fraudulent.”

Although on occasions he was slightly evasive when answering questions, on the whole we found Officer Harker to
be a fair minded, straightforward and generally helpful witness.
14.

Officer Neil Copeland, a Senior HMRC Officer, was appointed to the Inland Revenue, a predecessor department to
HMRC, in 2000 and has been continuously employed in the PAYE arena. He is a “Technical” Lead for both PAYE
and NIC. He also undertakes company reviews and enquiries within the temporary labour sector and associated
supply companies. Although the decision letters to the Lead Appellants were signed by Officer Harker, Officer
Copeland who has worked within HMRC's “Labour Market Team” since 2016, specialising in businesses operating
within the MUC model since 2020, was the “decision maker” in relation to the EA aspects of the decisions under


-----

(TC)

appeal. Although not as helpful a witness as Officer Harker, we nevertheless found the evidence of Officer
Copeland, who accepted that a business model could be non-compliant, in the sense of not satisfying the
applicable legislative requirements, without it being fraudulent, to be credible.
15.

Officer Stuart Knowles, a Senior HMRC Officer who, since 2016, has been a member of HMRC's Fraud
Investigation Service (“FIS”). He and Officer Alexander Howard visited premises which were registered addresses
for MUCs. Officer Knowles, at times, seemed to want to argue HMRC's case rather than answer questions put to
him especially in regard to the supply chain of the MUCs, a matter which he had researched and reviewed.
16.

Officer Adam Edmondson, a Compliance Officer who has been employed by HMRC from December 2019 and has
been in his present role from July 2022. Together with Officer Majid he visited various commercial and residential
premises. He also researched and reviewed the supply chain of the MUCs.
17.

Officer James Shields is an HMRC Compliance Caseworker. He was an Administration Officer in HMRC's Debt
Management and Banking department from September 2016 to July 2019 when he became a Compliance Case
worker at the grade of Officer in HMRC's FIS department until taking up his current position in January 2022. With
HMRC Officer Navlyn Chima he conducted visits to 12 commercial and residential premises at which MUCs had
their registered offices.
18.

Officer Julie Barnes has been a Senior HMRC Officer since January 2022 having joined the department in 1980.
She became a member of HMRC's Labour Market Team in December 2014 as an Officer dealing with debt
management. Since 2016 she has been undertaking investigations involving the use of MUCs as an investigator
and from January 2022 as a Case Director. She contacted the UK-based nominee directors of Rosscana, and
Elphysic. Officer Barnes also produced financial documentation, including due diligence documents from Contis
Financial, relating to the Lead Appellants.
19.

Officer Martin Bowe has been a Tax Specialist at HMRC since 2014. His role is to undertake cross tax
investigations into a variety of entities. It was Officer Bowe who opened a COP8 investigation following the sale of
shares in ABP Ventures Limited to Compass Star Limited (“Compass Star”).
20.

Officer Gavin Emms is an Investigating Officer employed by HMRC and its predecessor since 1997. He has been a
civil investigator with HMRC's FIS since 11 March 2019. Before that he was a visiting VAT officer working within
Individuals and Small Business Compliance. With Officer Kevin Scott he visited two premises at which MUCs were
registered including that of Amanda O'Doherty, the director of Phyarreidon.
21.

Officer Kevin Wright, an HMRC Officer who has worked for HMRC for 22 years and, from 2015, has been a
technical lead for the cybercrime team. As part of HMRC's investigations into the use of MUCs his evidence
concerned web portal data for certain Government Gateway accounts relating to the Lead Appellants. He provided
a summary of the registration process for the Government Gateway and the use of 'cookies' to identify users. He
was responsible for providing web portal data retrieved from HMRC's internal systems to Officer Price for analysis.
His evidence was not challenged.
22.

Officer Brian Price, a Principal Data Analyst for HMRC whose role involves using data science tools and techniques
to analyse bulk data. Since 2019 he has been tracking MUCs and, while completing a piece of work on non-resident
directors, identified a large number of Filipino directors with companies at the same UK Registered Offices. He
offered his assistance to his FIS colleagues in identifying these MUCs and from June 2019 produced a monthly set


-----

(TC)

of outputs to identify MUCs and the links between them. In his evidence he described the process he undertook in
relation to the February 2023 outputs taking the “Live Company Snapshot” and “Persons with Significant Control”
data directly from the Companies House website. His evidence was not challenged and he was, like Officer Kevin
Wright, accepted by the Lead Appellants as being a straightforward witness.
23.

In addition to this 'live' evidence, the unchallenged witness statements from the following were admitted into
evidence:

(1)   Alexander Howard, an HMRC Officer who, with Officer Knowles, visited premises which were
registered addresses for MUCs;

(2)   Adnan Majeed, an HMRC Officer who, with Officer Edmonson, visited premises used by MUCs as
their registered offices;

(3)   Claire Bennett, an HMRC Officer who conducted a visit to a 'virtual office address and spoke to a
Daniel Conway who had agreed to perform 'virtual office' tasks for Corpserv (see below) for 98 companies;

(4)   David Maughan, a Compliance officer for HMRC who conducted calls to individuals listed as being
employed by MUCs;

(5)   Georgina Prichard, a Compliance Officer of HMRC who undertook calls to individuals identified as
being employed by MUCs and who spoke to a Katie Porter;

(6)   Kevin Scott, a Senior Officer of HMRC who with Officer Emms visited two premises at which MUCs
were registered;

(7)   Lauren McKinnon, an Administration Officer with HMRC's telephone 'Employers Helpline'. Her
evidence described the frequency of calls to register MUCs for PAYE and the call to register Phyarreidon;

(8)   Lisa Rosenthal, an HMRC Senior Investigating Officer who obtained information from the Euro
Pacific Bank;

(9)   Melanie Lish, an HMRC Fraud Investigator who contacted individuals identified as employed by
MUCs and who spoke to a Marcus Price;

(10)   Navlyn Chima, an Investigator with HMRC who, with Officer Shields, visited 12 commercial and
residential premises at which MUCs had their registered addresses;

(11)   Rebecca Willis, a chartered accountant employed by HMRC who works with HMRC's Fraud
Investigation Service who reviewed the bank accounts of the Lead Appellants;

(12)   Sandra Mackay, a Customer Services Adviser in HMRC's EHL. Her evidence concerned the bulk
registration for PAYE of MUCs and the telephone call to register Zraytumbiax for PAYE;

(13)   Thomas Wright, an HMRC Compliance Officer who spoke to individuals identified as employed by
MUCs;

(14)   Tracy Shaw, a 'virtual office' assistant for Corpserv;

(15)   Shona Priddey, an individual who leased commercial premises to Lee Pemberton; and

(16)   Elizabeth Davies, an individual recruited via Facebook to provide 'virtual office' services for
Corpserv.

24.

Annabel McLaughlin, Edgar Jon Dela Cruz Funtanilla, Beverly Gonzalo, Lea Velasco, Janylin Daca and Mardie
Flores gave evidence for the Lead Appellants.
25.


-----

(TC)

Ms Annabel McLaughlin, a Business Consultant, gave evidence in relation to the role of her “own companies”,
AMBR Solutions Limited (“AMBR UK”), Kedros Formations Limited (“Kedros”) and AMBR Business Process
Outsourcing Inc (“AMBR PH”). AMBR UK was a back-office service provider specialising in supporting small
companies operating in labour supply (ie MUCs). Kedros was a company formations agent and AMBR PH, which is
now known as Verity BPO Inc (“Verity”), is a back-office service provider established in the Philippines. Ms
McLaughlin was described by Mr Margolin as a “forthright and open witness”. While we agree she was indeed
forthright, somewhat argumentative and wanted to ensure she had the last word, we did not find her a particularly
helpful witness. She was often evasive saying she was unable to recall when dealing with “difficult” questions and
her explanation of the existence of clauses in agreements which were contrary to her evidence being “poor
wording” in the document was simply not credible.
26.

Mr Jon Funtanilla, a Filipino national who is the sole director and shareholder of Compass Star and the sole director
and shareholder of Supplierland LLC (“Supplierland”), gave evidence regarding the MUC “business model”, its
application and the role of Compass Star and Supplierland in it. Although somewhat evasive in several of his
answers in cross examination Mr Funtanilla did, on the whole, seek to assist the Tribunal and to that extent was a
helpful witness.
27.

Ms Beverly Gonzalo of Phyarreidon, Ms Janylin Daca of Zraytumbiax, Ms Lea Velasco of Rosscana and Ms Mardie
Flores of Elphysic, the Filipino directors and shareholders of the Lead Appellants, were all helpful witnesses who
gave credible accounts of their roles and involvement with their respective companies.
28.

Although considered, as it has not been possible in this decision for us to refer to every piece of evidence, we have
adopted the approach set out in the decision of the Upper Tribunal (Judges Raghavan and Brannan) in Adelekun v
_HMRC_ _[[2020] UKUT 244 (TCC) which, at [29], observed that:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60JM-7053-CGXG-043J-00000-00&context=1519360)_

“… It cannot be assumed that just because a document appears in a hearing bundle that the tribunal panel will
take account of it; if a party wants the tribunal to consider a document then the party should specifically refer
the tribunal to it in the course of the hearing (see Swift & others v Fred Olsen Cruise Lines _[2016] EWCA Civ_
_785 at [15]). This is not least to give the tribunal adequate opportunity to consider and evaluate the document_
in the light of the reliance a party seeks to place on it, but also to give the other party the opportunity to make
their representations on the document. That is particularly so where, as here, there were several hearing
bundles before the FTT relating to the various previous proceedings and the one containing the relevant
additional documents was voluminous comprising 434 pages.”

29.

That said, we did read all of the witness statements (which were “taken as read” as the evidence in chief of that
witness) and considered those documents exhibited to the statements to which we were referred in submissions or
which had been put to the witnesses.
30.

We would also remind the parties that, as Lewison LJ (with whom Males and Snowden LJJ agreed), observed at

[2(iii)], when considering an appeal against a “pure question of fact” in Volpi & another v Volpi _[2022] EWCA Civ_
_464, the:_

“… mere fact that a judge does not mention a specific piece of evidence does not mean that he overlooked it.”

Also, as Lewison LJ noted, at [2(vi)] in Volpi, although reasons for judgment “will always be capable of having been
better expressed” (which is no doubt true of the present case) a judgment should not be subjected to a “narrow
textual analysis” or “picked over or construed as though it was a piece of legislation or a contract.”
_FACTSStatement of Agreed Facts_
31


-----

(TC)

The parties produced the following Statement of Agreed Facts which, save for some immaterial (primarily personal)
details, we set out in full:
**Elphysic**

(1)   On 12 March 2021, Elphysic was incorporated in England and Wales.

(2)   Laura Wickers was the sole director at the date of incorporation.

(3)   Elphysic's registered address on incorporation was [in] … Leigh-on-Sea … England. That was the
personal address of Laura Wickers. Laura Wickers was appointed as director of a total of 24 companies.
Each company was registered to her personal address.

(4)   The address changed to … [a] Business Centre, [in] Stourport-on-Severn … on 1 April 2021.

(5)   The standard industrial classification (“SIC”) of Elphysic on incorporation was “other building
completion and finishing (SIC 43390)”. This was changed to “other manufacturing not elsewhere classified
(SIC 32990)” on 23 April 2021.

(6)   On 30 March 2021, Laura Wickers' directorship of Elphysic was terminated. (7) On 30 March 2021,
Mardie Flores was appointed as the director of Elphysic. (8) On 30 March 2021, Mardie Flores became the
shareholder of Elphysic.

(9)   On 12 April 2021, an application was submitted on behalf of Elphysic to register for VAT. The
application was submitted using the name Laura Wickers. The principal place of business on that
application was shown as her personal address [in] … Leigh on-Sea.

(10)   On 14 April 2021, Elphysic was registered for VAT … with effect from 30 March 2021.

(11)   Elphysic accounted for and paid to HMRC VAT as follows:

(a)   On 30 July 2021 (for the period 30 to 31 March 2021), £0.00 was declared;

(b)   On 30 July 2021 (for the period 1 April to 30 June 2021), £371.74 was declared, which was paid
on 28 July 2021;

(c)   On 28 October 2021 (for the period 1 July to 30 September 2021), £1,174.41 was declared,
which was paid on 3 November 2021;

(d)   On 26 January 2022 (for the period 1 October to 31 December 2021), £869.19 was declared,
which was paid on 25 January 2022; and

(e)   On 9 May 2022 (for the period 1 to 31 January 2022), £1,171.63 was declared, which remains
due.

(12)   By a letter dated 31 January 2022, Elphysic was de-registered for VAT, informed it was not
permitted to account for VAT under the FRS, informed it was not entitled to the EA and assessed to VAT in
the sum of £1,485.85.

(13)   On 2 March 2022, Elphysic appealed to the Tribunal.

**Phyarreidon**

(14)   On 25 May 2021, Phyarreidon was incorporated in England and Wales. (15) Amanda O'Doherty
was the sole director at the date of incorporation.

(16)   Phyarreidon's registered address on incorporation was [in] … Newcastle upon Tyne …. That was
the personal address of Amanda O'Doherty.

(17)   The address changed to … Wildmoor Mill, …, Bromsgrove … on 19 June 2021 and to … Derby
Road, Long Eaton, Nottingham … on 21 July 2021.


-----

(TC)

(18)   The SIC of Phyarreidon on incorporation was “freight transport by road (SIC 49410)”. This was
changed to “packaging activities (SIC 82920)” on 12 July 2021.

(19)   On 10 June 2021, Amanda O'Doherty's directorship of Phyarreidon was terminated.

(20)   On 10 June 2021, Beverly Gonzalo was appointed as the director of Phyarreidon.

(21)   On 14 June 2021, an application was submitted on behalf of Phyarreidon to register for VAT. The
application was submitted using the name Amanda O'Doherty. The principal place of business on that
application was shown as her personal address [in] … Newcastle upon Tyne ….

(22)   On 15 June 2021, Phyarreidon was registered for VAT … with effect from 10 June 2021.

(23)   Phyarreidon accounted for and paid to HMRC VAT as follows:

(a)   On 3 November 2021 (for the period 1 July to 30 September 2021), £2,405.26 was paid;

(b)   On 7 February 2022 (for the period 1 October to 31 December 2021), £2,164.98 was declared,
which was paid on 3 February 2022; and

(c)   On 18 May 2022 (for the period 1 to 31 January 2021), £1,249.65 was declared, which was paid
on 20 May 2022.

(24)   On 31 January 2022, Phyarreidon was de-registered for VAT, informed it was not permitted to
account for VAT under the FRS, informed it was not entitled to the Employment Allowance and assessed
to VAT in the sum of £2,605.74.

(25)   On 2 March 2022, Phyarreidon appealed to the Tribunal.

**Rosscana**

(26)   On 22 May 2019, Rosscana was incorporated in England and Wales. (27) Shannyce Shawcroft was
the sole director at the date of incorporation.

(28)   Rosscana's registered address on incorporation was [at] … Close, Nottingham. That was the
personal address of Shannyce Shawcroft. Shannyce Shawcroft was appointed as director of a total of 24
companies. Each company was registered to her personal address.

(29)   The address changed to … [one in] Bexleyheath, Kent on 29 May 2019 and to [an address] … in,
Kinmel Bay on 7 January 2020.

(30)   The SIC of Rosscana on incorporation was “freight transport by road (SIC 49410)”. This was
changed to “packaging activities (SIC 82920)” on 27 May 2019.

(31)   On 26 May 2019, Lea Velasco was appointed as the director of Rosscana.

(32)   On 27 May 2019, Lea Velasco became the shareholder of Rosscana.

(33)   On 27 May 2019, Shannyce Shawcroft's directorship of Rosscana was terminated.

(34)   On 2 July 2019, an application was submitted on behalf of Rosscana to register for VAT. The
application was submitted using the name Shannyce Shawcroft. The principal place of business on that
application was shown as her personal address …, [in] Nottingham.

(35)   On 8 July 2019, Rosscana was registered for VAT … with effect from 5 June 2019.

(36)   On 8 July 2019, Rosscana was notified by HMRC that it had been authorised to account for VAT
using the FRS with effect from 5 June 2019.

(37)   Rosscana accounted for and paid to HMRC VAT as follows:

(a)   On 30 October 2019 (for the period ending 30 September 2019), £1,832.38 was paid;


-----

(TC)

(b)   On 4 February 2020 (for the period 1 October to 31 December 2019), £1,719.06 was paid;

(c)   On 5 May 2020 (for the period 1 January to 31 March 2020), £819.94 was declared, which was
paid on 2 March 2021;

(d)   On 28 July 2020 (for the period 1 April to 30 June 2020), £1,072.83 was declared, which was
paid on 4 August 2020;

(e)   On 5 November 2020 (for the period 1 July to 30 September 2020), £812.31 was declared, which
was paid on 6 November 2020;

(f)   On 8 February 2021 (for the period 1 October to 31 December 2020), £0.00 was declared;

(g)   On 4 May 2021 (for the period 1 January to 31 March 2021), £1,758.60 was declared and paid;
and

(h)   On 27 July 2021 (for the period 1 April to 30 April 2021), £1,901.72 was declared and paid.

(38)   On 30 April 2021, Rosscana was de-registered for VAT, informed it was not permitted to account for
VAT under the FRS, informed it was not entitled to the EA and assessed to VAT in the sum of £5,108.17.

(39)   HMRC issued review conclusion letters to Rosscana:

(a)   On 23 December 2021, regarding HMRC's decision regarding de registration for VAT and use of
the FRS; and

(b)   On 27 January 2022, regarding HMRC's decision that it was not entitled to claim the EA.

(40)   Rosscana appealed to the Tribunal on:

(a)   20 January 2022, against HMRC's decision regarding de-registration for VAT and use of the
FRS; and

(b)   17 February 2022, against HMRC's decision that it was not entitled to claim the EA.

**Zraytumbiax**

(41)   On 28 April 2021, Zraytumbiax was incorporated in England and Wales. (42) Paige Chick was the
sole director at the date of incorporation.

(43)   Zraytumbiax's registered address on incorporation was … Grove, Cardiff … . That was the personal
address of Paige Chick. Paige Chick was appointed as director of a total of 24 companies. Each company
was registered to her personal address.

(44)   The address was changed to Office 3 and 4 … House, … Street, Wolverhampton on 12 May 2021
and to Unit 40, … Works, … Road, Sheffield on 20 July 2021.

(45)   The SIC of Zraytumbiax on incorporation was “freight transport by road (SIC 49410)”. This was
changed to “other retail sale not in stores, stalls or markets (SIC 47990)” on 9 July 2021.

(46)   On 13 May 2021, Paige Chick's directorship of Zraytumbiax was terminated. (47) On 13 May 2021,
Janylin Daca was appointed as the director of Zraytumbiax.

(48)   On 21 May 2021, an application was submitted on behalf of Zraytumbiax to register for VAT. The
application was submitted using the name Paige Chick. The principal place of business on that application
was shown as her personal address at … Grove, Cardiff.

(49)   On 25 May 2021, Zraytumbiax was registered for VAT … with effect from 13 May 2021.

(50)   Zraytumbiax accounted for and paid to HMRC VAT as follows:


-----

(TC)

(a)   On 24 August 2021 (for the period 13 May to 30 June 2021), £0.00 was declared;

(b)   On 11 October 2021 (for the period 1 July to 30 September 2021), £2,292.39 was declared,
which was paid on 19 October 2021;

(c)   On 2 February 2022 (for the period 1 October to 31 December 2021), £2,690.24 was declared,
which was paid on 3 February 2022; and

(d)   On 3 May 2022 (for the period 1 to 31 January 2022), £1,070.98 was declared and paid.

(51)   On 31 January 2022, Zraytumbiax was de-registered for VAT, informed it was not permitted to
account for VAT under the FRS, informed it was not entitled to the EA and assessed to VAT in the sum of
£3,585.78.

(52)   On 2 March 2022, Zraytumbiax appealed to the Tribunal.

_FURTHER FINDINGS OF FACT_
32.

Before turning to the creation and development of what the Lead Appellants describe as the “MUC business model”
and HMRC as the “MUC scheme”, it is convenient to set out further findings of fact, beyond those agreed by the
parties, in relation to these appeals first in relation to the Lead Appellants and then more generally.
Lead Appellants (and Jazztify)Elphysic
33.

In addition to Elphysic, Ms Wickers was appointed director of 23 companies for a short period (a matter of weeks at
most) and on her resignation was replaced as director, in each case by a Filipino national. As with all of the
applications to register for VAT (on form VAT1) for the companies of which Ms Wickers had been a director, the
VAT1 for Elphysic included her details even though it was received by HMRC after the date of Ms Wickers'
resignation as director. Also, none of the VAT1s for the companies of which Ms Wickers was a director declared
that that company's business was that of a labour supplier. Additionally, the FRS applied for was not always the
rate at which VAT was accounted by the company concerned.
34.

The address at the Business Centre in Stourport-on-Severn which became Elphysic's registered address from 1
April 2021 was also the registered address of 214 MUCs.
35.

In a telephone conversation with Officer Barnes on 5 December 2022 Ms Wickers explained that although she had
become a director of the 24 MUCs for Corpserv all she had done was to receive post to her address, take
photographs of the letters and upload these to the Corpserv App. When asked how she had become involved Ms
Wickers said that it had been a “massive thing” on Facebook and that she had been referred by a “lady on there
named Donna”. She said that she had spoken to “loads” of people about it some of whom had been “doing it for
years”.
36.

Ms Wickers described having been referred to Corpserv. She had been instructed to contact it by email and that,
following her appointments, she had been paid £100 a month into her bank through PayPal and that this was for
receiving and opening post sent to the company concerned and uploading the photographs of it on the Corpserv
App. She explained how she had become director of the 24 companies describing how she received four letters for
each company and was paid £10 per letter for the first three letters and £20 for the fourth and received an extra £30
if all four were signed making a total payment per company of £80.
37.

Although she was aware that she had become the director of 24 companies Ms Wickers told Officer Barnes that
she was only a director “momentarily” and was not aware of any duties or responsibility that went with being a
company director. She said that once the documents had “gone back” the company was sold.


-----

(TC)

38.

She confirmed that she had not registered Elphysic or any of the companies at Companies House. Neither had she
made any application to register it for VAT even though its VAT1 contained her name and her address and other
details which she confirmed were correct. However, she did not recognise the telephone numbers (the same
number was given for the business and director's mobile telephone) stated to be hers on the VAT1.
39.

Perhaps this is not surprising as, other than in the case of Rosscana, the telephone numbers have nothing to do
with the director of the Lead Appellants but, as is apparent from the table below, were purchased in sequential
blocks and allocated to the next MUC in line.

_Allocation of telephone numbers_

**MUC Name** **Telephone Number (Business)** **Telephone Number (Director)**

Alchemille Ltd 01902237281 01902237281

Poseelish Ltd 01902237282 01902237282

**Zraytumbiax Ltd** 01902237283 01902237283

Lihosmear Ltd 01902237284 01902237284

Mevisen Ltd 01902237285 01902237285

Pigmently Ltd* 01172420265 01172420265

Meltingwolf Ltd 01172420266 01172420266

**Jazztify Ltd** 01172420267 01172420267

Fancysealion Ltd 01172420268 01172420268

Mysteriousmute Ltd* 01172420269 01172420269

Cehumear Ltd 01299554233 01299554233

Philiontron Ltd 01299554234 01299554234

**Elphysic Ltd** 01299554235 01299554235

Heviser Ltd* 01299554236 01299554236

Sphies Ltd 01299554237 01299554237

Rymedates Ltd* 01527387430 01527387430

Phomerooly Ltd 01527387431 01527387431

**Phyarreidon Ltd** 01527387432 01527387432

Qeudaenon Ltd 01527387433 01527387433

Meixetheus Ltd* 01527387434 01527387434

_* not appellants but MUCs that operate within same business model/scheme as appellants_
40.

Ms Wickers, when asked if she had registered Elphysic or any other company for PAYE, told Officer Barnes that
she had not and asked her what PAYE was!
41.

An analysis of Elphysic's bank statements for the period from 19 April 2021 to 1 March 2023, by Rebecca Willis for
HMRC, showed that its assumed receipts from customers over this period was £41,995. Its expenditure relating to
employees (which included wages, payment of payroll taxes to HMRC, pension contributions, job retention
scheme), £36,451.
42.

|MUC Name|Telephone Number (Business)|Telephone Number (Director)|
|---|---|---|
|Alchemille Ltd|01902237281|01902237281|
|Poseelish Ltd|01902237282|01902237282|
|Zraytumbiax Ltd|01902237283|01902237283|
|Lihosmear Ltd|01902237284|01902237284|
|Mevisen Ltd|01902237285|01902237285|
||||
|Pigmently Ltd*|01172420265|01172420265|
|Meltingwolf Ltd|01172420266|01172420266|
|Jazztify Ltd|01172420267|01172420267|
|Fancysealion Ltd|01172420268|01172420268|
|Mysteriousmute Ltd*|01172420269|01172420269|
||||
|Cehumear Ltd|01299554233|01299554233|
|Philiontron Ltd|01299554234|01299554234|
|Elphysic Ltd|01299554235|01299554235|
|Heviser Ltd*|01299554236|01299554236|
|Sphies Ltd|01299554237|01299554237|
||||
|Rymedates Ltd*|01527387430|01527387430|
|Phomerooly Ltd|01527387431|01527387431|
|Phyarreidon Ltd|01527387432|01527387432|
|Qeudaenon Ltd|01527387433|01527387433|
|Meixetheus Ltd*|01527387434|01527387434|


-----

(TC)

Other payments included £1,000 and £600 to software providers Xelarus Consulting Philippines Inc (“Xelarus”) and
Tyche Software Limited (“Tyche”) respectively for training disks. Payments of £379 and £350 were made to
Angstrom BPO Inc (“Angstrom”) a back-office business process outsourcing (“BPO”) service provider and WRZ
Consulting Inc (“WRZ”) (see below) respectively. There were also monthly charges from Contis totalling £396 for
using its bank account. The bank reconciliation showed a closing balance of £1.
43.

Elphysic's accounts for the year ended 11 March 2022 show an £826 loss and net current assets of £1.
**Phyarreidon**
44.

The initial director of Phyarreidon, Ms O'Doherty, was also the director of 23 other companies. In each case this
was for a short period of time, the longest period being no more than a month. On her resignation as director of
each of these companies, a new director, always a Filipino national, was appointed to take her place.
45.

Although the VAT1 forms applying for VAT registration were submitted to HMRC after Ms O'Doherty had resigned,
each contained her details, address, date of birth etc and there was no declaration made of any associated
businesses. Neither was there any declaration on the VAT1 that the MUCs were labour suppliers. Additionally, the
FRS rate applied for was not always the rate that was actually used.
46.

Although the original registered office of Phyarreidon was that of Ms O'Doherty's home, the registered address
changed, from 19 June 2021, to one in Bromsgrove and, from 21 July 2021 to an address in Long Eaton. 215
MUCs have had their registered offices at the Bromsgrove address and 585 MUCs have been registered at the
Long Eaton address.
47.

HMRC was unable to obtain bank statements for Phyarreidon.
**Rosscana**
48.

The initial sole director of Rosscana, Shannyce Shawcross, was also the director of 23 other companies, all
registered to her home address. She resigned as a director of all companies a matter of weeks after her
appointment. Every time she resigned as a director she was replaced by a Filipino national.
49.

19 of the 24 VAT registration applications were made after she had resigned as director although all were made
using her name and details. Again “labour supply” was not included as a business activity, no associated
businesses were declared on the VAT1 and the FRS rate on the application was not always that used.
50.

On 17 October 2022, having received letters from HMRC's FIS, Ms Shawcross sent the following email to HMRC:

“Hi, I have received a letter from the Fraud Investigation Service regarding directorships? Years ago I took part
in signing contracts online, I didn't really understand what I was doing, but I got paid for it. I always asked if it
would affect my benefits as I'd need to let universal credit know but was always told no. Please could you let
me know where we go from here as I'm panicking.

Thank you,

Shannyce shawcroft”

51.


-----

(TC)

Officer Barnes contacted Ms Shawcross by telephone on 19 October 2022 in response to this email and the letters
that had been sent by HMRC. Ms Shawcross explained that she did not realise that she had been a director of UK
companies until she had received HMRC's letters. However, having checked with Companies House she found out
that she had been a director of 24 companies but had resigned from them all. She did not know she had been
replaced by a Filipino national as director.
52.

She told Officer Barnes when asked what she knew about the companies and being a director that she had “to sign
stuff and send it off” but did not know what she was doing or what she was signing and had played no part in the
registration of those companies at Companies House. Ms Shawcross described to Officer Barnes how, between
2019 and 2020, she had signed and dated “stuff”, taken photographs and “send it off” although did not know what
she was doing and had not read any of the documents or realised she was agreeing to become a director of a
company and had “got into this” via a “girl on my Facebook group” who suggested she “have a look” at it.
53.

Ms Shawcross told Officer Barnes that the administrator for the group was a Donna Eckford who was the person
who had allayed her concerns about any adverse effect it might have on her State Benefits. She described how she
provided her information, including identification, national insurance number and date of birth via the Facebook
group and had later received six contracts through the post to sign and was told that that this, signing six contracts,
could be done four times. She said that she was required to sign a letter, take a photograph and upload it to the
WRS Formations (“WRS”) website. Although Ms Shawcross could not remember exactly what she was paid she did
recall receiving £257 on one occasion and £70 on another.
54.

When asked about the application by Rosscana for registration for VAT, Ms Shawcross confirmed that, although it
contained her details, she had not submitted the VAT1 and that she had “no idea” who was responsible or how her
details had been used on the form. She also confirmed that neither Rosscana nor any other company had traded
from her home.
55.

On 23 January 2023 Officer Knowles contacted an Alex Bowen who resided at the address in Kinmel Bay, the
second registered address of Rosscana from 7 January 2020 after it had been changed from Ms Shawcross's
address. In addition to Rosscana hundreds of other MUCs had their registered address at the property in Kinmel
Bay.
56.

Mr Bowen explained that he was self-employed and provided virtual office services for approximately 200
companies for Corpserv and that companies were being added and removed all the time, although this was not
something he controlled. All he did was to receive post for limited companies, open the envelope and take a picture
of what was inside and email it to Corpserv. He told Officer Knowles that he had been providing virtual office
services for Corpserv for a couple of years for which he was paid £250 a month. However, he said that he had
nothing to do with the companies which used his address other than to provide a virtual office for them. Mr Bowen
said that he became involved with Corpserv through a friend who was also providing a virtual office for it and had
advertised for others to get involved.
57.

An analysis of Rosscana's bank statements for the period from 20 September 2019 to 1 March 2023 by Rebecca
Willis for HMRC showed that its assumed receipts from customers over this period was £96,445. Its expenditure
relating to employees was £84,286. Other payments included £2,900 to Tyche. Payments of £1,322 were made to
Verity with £188 being paid to WRZ. It also paid £1,775 to Wedo Business Services Limited. There were also
monthly charges from Contis totalling £681 for using its bank account. The bank reconciliation showed a closing
balance of £2.
**Zraytumbiax**


-----

(TC)

58.

The initial director of Zraytumbiax, Paige Chick, was also the director of 23 other companies albeit for a short time
only. Following her resignation as director of all of the companies she was replaced by a director who was a Filipino
national.
59.

Notwithstanding Mr Chick's resignation as director from all companies prior to their application for VAT registration,
her name and details were included on all VAT1 forms, none of which declared the business of the company
concerned to be the provision of labour despite that being the case. Also, notwithstanding Ms Chick's other
directorships, no associated businesses were declared on the VAT1 either. Also, in many cases, following the
commencement of trade by the company concerned, there was a difference in the FRS rate actually declared from
that which had been identified in the application.
60.

As noted in the Statement of Agreed facts, there were changes of address for Zraytumbiax. The first, on 12 May
2021, was from Ms Chick's personal address in Cardiff to an address in Wolverhampton at which some 260 MUCs
had been registered. The registered address of Zraytumbiax was then changed again on 20 July 2021 to an
address in Sheffield. 260 MUCs had been registered at that address.
61.

An analysis of Zraytumbiax's bank statements for the period from 28 April 2021 to 24 February 2023, by Rebecca
Willis for HMRC,showed that its assumed receipts from customers over this period was £93,351. Its expenditure
relating to employees was £78,870. Other payments included £3,300 to Xelarus and £600 to About Business
Software LLC. Payments of £2,230 and £714 were also made to Angstrom, which like Verity provided back office
business services, and Veritek Consulting Philippines Inc (“Veritek”), a company owned and operated by Mr
Funtanilla, . There were also monthly charges from Contis totalling £360 for using its bank account. The bank
reconciliation showed a closing balance of £0.
**Jazztify**
62.

Having withdrawn its appeal on 2 January 2024 Jazztify is no longer an appellant. However, we have referred to it
as we heard evidence in relation to its formation and operation which, as Mr Puzey submitted, goes to the existence
or otherwise of what HMRC describe as the “scheme in action.”
63.

Jazztify was incorporated in England and Wales on 8 July 2019. Its sole director as at that date was Nicola Wright
and its registered office was her personal address in Grimsby. Ms Wright was also the director of six companies
each of which was registered to her personal address. On 8 August 2019 Jazztify's registered address changed
from that of Ms Wright to an address in Bristol which was not only the home address of a Donna Eckford but also
the registered office address of some 220 MUCs.
64.

Jazztify's SIC on incorporation was “freight transport by road (SIC 49410)”. This changed to “operation of
warehousing and storage facilities for land transport activities” (SIC 52103) on 30 December 2019.
65.

On 21 August 2019, Nicola Wright resigned as a director of Jazztify and on the same day Chilin Pangilinan, a
Filipino national, was appointed as the director and became the shareholder of Jazztify.
66.

An application to register for VAT was submitted on behalf of Jazztify on 23 August 2019. That application on Form
VAT1 was made using the name Nicola Wright with the principal place of business shown on that application being
her personal address in Grimsby. In addition, the VAT1 registration application form also states Ms Wright's date of


-----

(TC)

birth and National Insurance number and that the form was submitted by her in her capacity as director
notwithstanding that she had resigned two days earlier. “Freight transport by road” was inserted in Box 6 on the
VAT1 which was headed 'Business Activities'. Also, despite Ms Wright being a director of six companies no other
business involvement was declared on the VAT1.
67.

Jazztify was registered for VAT with effect from 28 August 2019 and on 2 September 2019 was notified by HMRC
that it had been authorised to account for VAT using the FRS with effect from 22 July 2019. It subsequently
accounted for and paid VAT to HMRC.
68.

By letter dated 30 April 2021, HMRC de-registered Jazztify for VAT and notified that it was not permitted to account
for VAT under the FRS, that it was not entitled to the EA and assessed it to VAT in the sum of £6,910.50. Although
Jazztify appealed to the Tribunal against these decisions by HMRC, on 4 January 2024 it withdrew its appeals.
69.

An analysis of Jazztify's bank statements for the period from 8 July 2019 to 24 February 2023 by Rebecca Willis for
HMRC showed that its assumed receipts from customers over this period were £147,730. Its expenditure relating to
employees was £125,821. Other payments included £3,600 to About Business Software Limited. Payments of
£2,902 were made to Verity with £897 being paid to WRZ. There were also monthly payments of charges from
Contis totalling £618 for using its bank account. The bank reconciliation showed a minus £1 closing balance.
70.

Jazztify's unaudited accounts for the year ended 5 April 2020 show a profit of £3 with net current assets of £4.
71.

Ms Eckford, a nominee director herself, whose address was the second registered address of Jazztify, recruited
other nominee directors. On her Facebook page she posted the following:

“Are you over 18 with photo ID a passport driving licence provisional/full licence or a citizens card and want to
make £450 completely FREE you can do this up to 4 times so that's a total of £1800 to be made.

No selling

Won't effect income, tax or benefits

There's a Facebook group with now over 2k members who are doing this

£75 for every person you refer can refer as many people as you like there is no limit

No bank details needed. all payments through PayPal so you cannot be scammed

It won't cost you anything apart from a few seconds in time

100% legit I have referred over 500 plus to this opportunity and I've been part of it since 2017

Christmas is round the corner & extra cash always comes in handy for additional little treats

Who would like more info? Pm me or comment below” ”

72.

This is consistent with a 17 March 2019 Facebook advertisement from WRS Money which stated:

“Thanks to everyone who submitted there post to us, payments on the way anyone who knows anyone who'd
like to benefit from the nominee campaign please steer them to us.


-----

(TC)


£150 for initial sign up of 6 companies

£600 total

Scan post for extra money

Refer friends for more cash”

73.

Ms Eckford was interviewed by HMRC's FIS on 23 March 2023. Although this was in relation to her income in
general she was asked specific questions in relation to her income generated through MUCs. Because of there
being a suspicion of fraud this was conducted under HMRC's Code of Practice (“COP”) 8.
74.

Ms Eckford explained that she provided virtual office services to Corpserv which she saw advertised on Facebook.
This entails her receiving post for the MUCs, mail opening and taking pictures of it which are forwarded on to
Corpserv via email. For doing this she received £250 per month. In addition, she received commission for referring
new people to sign up to provide virtual office services to Corpserv. Although she was not aware of exactly how
many people provided such services for Corpserv she said there were over 100. Ms Eckford described how she
had to complete an application form and had a contract with Corpserv. However, as all her dealings with the
company were via email she did not know where Corpserv was based and did not have any named UK contact for
Corpserv. She did not know who had been responsible for setting up the Corpserv Facebook group.
75.

When asked about the first nine companies on a list of those of which she had been a director before resigning and
being replaced as a director by a Filipino national, Ms Eckford explained that she was asked to be the nominee
director of these nine companies for a company called Kedros and had she received a fee of £450 for doing so. Ms
Eckford said that she had signed incorporation and numerous other documents for the companies and then
uploaded them to a portal. However, she not aware that, at the time of the interview she was still listed at
Companies House as the person of significant control for eight of these. She was also not aware that she was listed
as the person who had registered six of these companies for VAT.
Genesis of the Business Model/Scheme
76.

Sometime around the middle of 2015 Mr Funtanilla received a telephone call from Ms McLaughlin who he had
known since they had both worked at Zeva, a company which operated in the temporary labour market. In that call
Ms McLaughlin described a business model that had been developed by an unconnected company under which a
UK company would outsource its labour requirements to a smaller UK company that had directors who were
residents of India or Pakistan. However, she explained, there were some doubts as to whether these directors
controlled the companies and this was causing some issues with the UK tax authorities.
77.

After discussing whether it was lawful for a foreign national to be a director of a UK company, Ms McLaughlin told
Mr Funtanilla that although all directors had to be responsible for their own companies, they could seek assistance
from third parties such as accountants and business advisors to ensure that compliance obligations were being
met.
78.

Mr Funtanilla saw such a business model as an opportunity to do things for himself and other Filipinos by using
technology and systems to make things work more efficiently and meet all compliance requirements. Part of his
research identified that the UK had a framework in place to support small companies by way of tax benefits to
encourage people to incorporate and operate small businesses. Mr Funtanilla recalled being envious of the system
as no such assistance is provided in the Philippines. He had researched this aspect of the business at the time as


-----

(TC)

he was “surprised” by it. He also understood that this was the issue that was being debated in the Anderson Group
case – specifically, eligibility to claim these reliefs when there was no control over the company by its director.
79.

One of the discussions he had with Ms McLaughlin was about how most people in the UK would not see it as
financially worthwhile being a director of a small company. However, this was not the case in the Philippines where
the local cost base meant smaller margins could provide attractive additional income to Filipinos. Although he
explained that, to him, this was a secondary consideration it was nevertheless an important one when it came to
incorporating and running a business that could make money. As a result, he concluded that it might be possible to
work on the opportunity.
80.

In 2016 Mr Funtanilla decided that to use Compass Star, an 'off-the-shelf' company incorporated in the British Virgin
Islands in 2011, and operated remotely from the Philippines in the implementation of the business plan he had
designed. He opened a bank account for Compass Star to enable it to trade with UK businesses. Mr Funtanilla, who
understood that the recruitment sector had changed since he had developed systems for Zeva:

“… wanted to ensure that everything that was done was completely lawful”

He therefore contacted the Aspire Business Partnership (“Aspire”) to which he had been introduced by Ms
McLaughlin and a Gary Butterworth both of whom had previously used Aspire for consultancy services.
81.

Around March/April 2016, Compass Star made its first introductions of Filipino directors to MUCs, initially as part of
a live testing of the system for Vela Contractors Limited (“Vela”).
82.

Also, around this time, Mr Funtanilla invited Alan Nolan and his colleague Jack Thomas, both from Aspire, to visit
the Philippines to “present” to him on the UK recruitment sector and how it worked. He also intended to get a group
of would-be directors together for Aspire to explain to them how the recruitment supply chain operated as this would
allow him to better understand the opportunity and to ensure that the group would show genuine interest. The
presentation was a success and Mr Funtanilla asked Aspire for a copy of it as he intended to use it as the basis for
his training programmes.
83.

Mr Funtanilla explained that Aspire's presentation gave him the basis to improve his knowledge and awareness of
the recruitment sector and how it worked. He also took the opportunity to explore other general compliance aspects
with Aspire. He told Mr Nolan and Mr Thomas that he needed them to tell him what was and was not compliant and
was advised to seek Counsel's Opinion on the operating model.
84.

Initially he asked Ms McLaughlin and Mr Butterworth how to go about obtaining an opinion from counsel and was
told by Mr Butterworth that it would be expensive. Mr Funtanilla he did not want to spend what could have been
PHP 1,500,000 (Philippine Pesos) on obtaining an opinion but was told by Mr Butterworth that he, Mr Butterworth,
had attended a conference in chambers with Giles Goodfellow QC and that Mr Goodfellow had provided an opinion,
dated 21 June 2016, on the model which Vela was operating with Compass Star that had concluded:

“…, there is a reasonably good case that if the factual premises set out in the Instructions and this Opinion are
established and the proposed structure is properly implemented in practice, the SCIs [MUCs] will be able to
show that they are unconnected with each other and/or other persons within the proposed structure and
consequently the EA and the FRVAT [FRS] scheme will be properly available.”

85.


-----

(TC)

Mr Goodfellow had also advised that the directors of the MUCs should not only purchase the shares in their
company at a price that reflected the anticipated return but that they should participate in the profits whether by way
of director's fees or dividends or a mixture of two. He added:

“What is also important is that whichever form or mixture of forms is chosen, it should be decided by the
director/shareholder and not simply rolled out according to some formula imposed from above.”

86.

Mr Butterworth shared Mr Goodfellow's Opinion with Mr Funtanilla who, as result, understood the MUC model to be
lawful and did not consider it necessary to seek his own Opinion from counsel. This was despite the Opinion having
been provided “solely for the benefit” of Leading Counsel's “Instructing Companies [ie Vela] and the current
directors of such companies” and, at paragraph 2 of stated that:

“… If this Opinion is shown or otherwise disclosed to any third party, it should be made clear to the third party
that they should take their own independent legal advice in relation to the matters contained in this Opinion and
that I do not assume any duty of care or otherwise to them.”

87.

Ms McLaughlin was also shown a copy of that Opinion in 2016 at Zeva's office (Zeva is the trading name for Vela
and associated companies) when she attended a meeting with Gary Butterworth.
88.

Ms McLaughlin also saw the undated advice of tax counsel Setu Kamal in relation to the MUC business model on
28 August 2018 when she attended a meeting in Essex with the director of Strategic Pay Limited, Dipen Patel.
However, this Opinion is not in relation to any of the Lead Appellants and Ms McLaughlin did not elaborate or
explain how she derived any comfort from it.
89.

She also read the written “Advice (Final)”, dated 24 November 2020, David Southern QC had given to regarding
Akin Resources Limited (“Akin”) in relation to the MUC model on 18 December 2020 when she attended a meeting
with the director of Akin, Sarah Kinrade, at their offices in Bury. This was the sixth iteration of Mr Southern's advice
which had been amended several times following email exchanges with Mr Alan Nolan who had suggested that the
amendments be incorporated in the final version.
90.

In that Advice, having set out the business model and referred to the FRS and EA, Mr Southern observed:

“The arrangements have to work commercially without direct regard to tax considerations. Margins appear to
be very low, and depend upon a large number of largely automated transactions. That is the reality of the
temporary employment market which has developed in response to economic change and as a reaction to
legislative changes which are concerned with employee rights rather than taxation. However, if the SCIs

[MUCs] can only make a profit if the EA and FRS are available, that undermines their commercial credibility. “

91.

In answer to one of the “detailed questions”, raised in the “revised instructions” in relation to the reference in the
draft opinion “to economic and financial dependence … where one company is tied hand and foot to another” where
it was “hoped” that point was clarified by the revised instructions, Mr Southern responded

“The question is always, how do arrangements operate in practice? What is essential, it seems to me, is that
each SCI [MUC], apart from its separate existence in law as a legal entity, should have a 'real' element of
commercial independence, be it very limited.”

92.


-----

(TC)

Ms McLaughlin explained that she had read the Opinions of Mr Goodfellow, Mr Kamal and Mr Southern because,
although she was not working for an intermediary, she was “interested” in the advice the intermediaries were taking
and that they “reflected the arrangement” and how it operated.
93.

Further advice was sought by Mr Funtanilla from Aspire, which he had retained, regarding a forthcoming change in
the VAT legislation to implement the low-cost regime. He was advised that an approach be made to Mr Goodfellow
to seek his view on the new legislation. Mr Funtanilla therefore engaged Aspire, on behalf Compass Star, to
prepare instructions and a conference with counsel was arranged for 20 January 2017. However, because of
difficulties obtaining a visa, Mr Funtanilla was unable to travel to the UK and he asked Gary Butterworth to attend
the conference in Mr Goodfellow's chambers on his behalf together with a representative from Aspire as Mr
Funtanilla's instructing agents.
94.

Following that conference the written Opinion of Mr Goodfellow was received by Mr Funtanilla in early March 2017.
95.

Mr Funtanilla visited the UK later in 2017. Although the primary purpose of his visit was to meet with Compass Star
customers, he asked Aspire to arrange another conference with Mr Goodfellow while he was in the UK. At that
conference, on 16 May 2017, there was a general discussion of the MUC business model and Mr Funtanilla was
satisfied that Mr Goodfellow had not changed his view of its effectiveness as expressed in the Vela Opinion. In
addition to that conference Mr Funtanilla met with Compass Star clients in London, Birmingham, Liverpool, and
Manchester before returning to the Philippines on 24 May 2017.
Implementation & Operation of the Business Model/SchemeCompany formation
96.

Incorporation of the MUCs in the UK was initially carried out for Compass Star by Kedros, a company formation
agent that had been established by Ms McLaughlin. Kedros sold “off the shelf” companies to Compass Star, its only
customer. The companies that Kedros incorporated were setup so that they could trade immediately. In addition to
incorporating companies, Kedros also registered them for VAT and applied for FRS on their behalf. Kedros had
around six members of staff, who were responsible for company formations, registering companies for taxes,
engagement with nominee directors and engagement with Compass Star and the Filipino directors/shareholders.
97.

Following Ms McLaughlin's resignation as director of Kedros (although she remained a shareholder) its day-to-day
business was carried on by Joseph Butterworth (who is the son of Gary Butterworth). Compass Star stopped using
Kedros in 2017 after it, Kedros, was hacked and received a lot of negative publicity.
98.

Prior to the formation of Supplierland (see below), Compass Star found directors for MUCs and would introduce an
intermediary to a MUC as and when intermediaries approached Compass Star seeking to trade with a MUC.
Around April 2017, Mr Funtanilla purchased the trading style of Kedros which included a database of companies
that were going to be incorporated. This included details such as the company names, their registration status, and
the registered addresses of those companies.
99.

WRZ, a Philippines company formed by Mr Funtanilla around November 2017, was granted a certificate of
incorporation on 23 February 2018. Mr Funtanilla explained that WRZ was a company operating in the Philippines
which traded as WRS. Its purpose was to enable Compass Star to pay the appropriate Filipino taxes. Staff were
recruited in the Philippines and Dubai to incorporate companies and prepare them for referral to Filipino directors
and WRZ began to incorporate the UK companies that would become the MUCs from around June 2018.
100.


-----

(TC)

In September 2020 WRZ began winding down its operations. This was because it banked with Bank of the
Philippine Islands (“BPI”) which treated UK pounds sterling (£) as a third-party currency (in contrast with US dollars
and PHP). Mr Funtanilla explained that this made it difficult and expensive to trade. As result the operations that
had been undertaken by WRZ were transferred to Veritek which was granted its certificate of incorporation on 24
March 2021.
101.

By early 2017 Mr Funtanilla had stopped using Compass Star's bank accounts at Euro Pacific Bank (“EPB”). EPB
was initially based in St Vincent and the Grenadines before transferring its domicile to Puerto Rico. Mr Funtanilla
explained that Compass Star had used EPB because it had been recommended to him in around 2016 as banking
between Britain and the Philippines would have been difficult and expensive. However, some of EPB's clients
started to be investigated for suspected tax evasion and money laundering. Although Mr Funtanilla could not
remember precisely when and how he found out about this he was alarmed and considered that if Compass Star
had continued to bank with EPB it could have tainted its reputation. Therefore, rather than operate through
Compass Star Limited, Mr Funtanilla started to use the name “Compass Star” as a brand.
102.

Shortly after EPB stopped trading, around 30 June 2022, Compass Star received a formal request from the
International Tax Authority in the British Virgin Islands to disclose information following an application that had been
made by HMRC in the UK. Having obtained legal advice Mr Funtanilla brought an application for judicial review
challenging that request which was ultimately unsuccessful. However, before the outcome of the judicial review
proceedings were known Mr Funtanilla changed the domicile of Compass Star (the company Compass Star
Limited) to Nevis. He explained that he did this as he was concerned that there could be an adverse reaction to
being unsuccessful in the judicial review and saw moving the company to another jurisdiction as “sensible.”
103.

WRZ, trading as WRS, incorporated MUC at Companies House. In the absence of a Companies House SIC code
for a labour supplier Mr Funtanilla looked for the types of customers and types of sectors in which the MUCs
operated narrowing it down to a few options such as warehousing, transport etc. As and when a MUC found a
customer, WRS would, if necessary, contact Companies House to change the SIC code.
104.

WRS contacted a selection of the reliable nominees that Kedros had used and asked if they wanted to continue to
be nominees and/or whether they were able to refer other people that might want to be nominees. A commission
was paid by Compass Star for a successful referral of a new nominee. Once a nominee was accepted WRS would
enter into Nominee Service Agreements (“NSAs”) with him or her.
105.

A typical example of an NSA is that entered into on 21 March 2019 between WRS and Shannyce Shawcroft
referred to in the NSA as “the Customer” and “the Nominee” respectively. The material parts of that NSA provide:

“Background

A. The customer is a Company Formation Agent and provides Company Formation Services ("the Services")
to businesses (“the Clients”) who wish to incorporate a limited company in the UK (“The Company”)

B. The Client wishes to use a Nominee to incorporate the Company and register for HM Revenue and
Customs (“HMRC”) Taxes prior to the Company trading

C. The Nominee will be used for the incorporation of up to four companies at any one time

**1. Nominee's Responsibilities**

1.1. The Nominee will agree:


-----

(TC)

1.1.1. To provide accurate personal details in a timely manner on request of the Customer, in order for the
Customer to form and register the Company with HMRC;

1.1.2. To use their personal address as a registered office whilst the company is being incorporated and the
application for HMRC Taxes is being made; …”

106.

Initially, Mr Funtanilla did not understand the process for registering UK companies for VAT and applying for the
FRS. He therefore sought advice from Mr Butterworth, Ms McLaughlin and Aspire and, based on his discussions
with them, put in place a system for a VAT registration application to be made in the name of the nominee director.
107.

Although it was possible to incorporate companies and apply for VAT with a Filipino director in place it was found to
be a slow process. Mr Funtanilla said that had this process been quicker VAT registrations would “most certainly”
have been made using the Filipino directors. He said that the method of application used, ie with nominee directors
details being provided, was for speed and efficiency and not for reasons of secrecy or concealment and that
incorporating and then applying for VAT registration while the nominee directors were still in the role expedited the
process and this was why provision was made in the NSA for this.
**Nominee Directors**
108.

In addition to Ms Wickers, the original director of Elphysic, Ms Shawcross, the original director of Rosscana and Ms
Eckford, to whose home address Jazztify was registered, HMRC contacted an Amy Lowes who was a nominee
director of some 58 companies. Ms Lowes was interviewed by HMRC's FIS (Officers Knowles and Paula Elliott) on
4 June 2018, a month after the submission, on 4 May 2018, of a VAT1 for Campbrite Limited (“Campbrite”).
109.

Companies House records show that Ms Lowes had been appointed as director of Campbrite on 28 April 2018 and
had resigned from that role on 22 September 2018, the date on which Jonnalyn Abuque, a Filipino national, was
appointed as its director. Although the 4 May 2018 application for VAT registration was initially rejected by HMRC it
was successfully re-submitted on 10 June 2018 again with Ms Lowes' details on it despite her having told HMRC
that she had not completed the VAT1 form even though she confirmed that the details shown it, her date of birth,
national insurance number and address were correct.
110.

Ms Lowes also said that she was not aware that she had been registered as the director of Campbrite, a company
which she said she had “never heard of” and had to ask Officer Knowles what it was? She also asked him to
explain, as she did not know anything about it, what VAT was?
111.

The interview note records that, having heard Officer Knowles's explanation, Ms Lowes said that she was worried.
She explained that she had filled out a survey for Kedros on Facebook about two and half years previously and had
been paid £75 for doing so. At the time she had provided a photograph of her provisional driving licence and a
photograph of letter as proof of her address. She advised she had started to receive post and e-mails but could not
get in touch with Kedros as they removed the link from Facebook. She had not done anything with the post and had
thrown it away as it was not addressed to her and there was not a person's name on it.
112.

Officer Knowles told her that these letters were addressed to the companies which had been established in her
name and the company was the person that these were sent to. Ms Lowes said that the Facebook link had been
taken down quite quickly and when she did an internet search she was able to see all of the Facebook posts about
everybody being set up as directors and receiving post. She said that everybody she knew had completed the
survey, her parents, sisters, friends, the “whole estate”, it “was all over Facebook”.
113


-----

(TC)

Ms Lowes also showed the HMRC Officers unopened letters she had received. One of these was addressed to
Yscane Limited, three addressed to Anesomen Limited and two to Sinewto Limited.
114.

On 7 June 2018 Ms Lowes sent Officer Knowles a screenshot of the following Facebook message:

“Don't worry not selling any products but have got an opportunity to earn a one off sum of £75 for kedros
formations or if you don't want to stop there you can start working for them and refer people like I do. You earn
£25 for each referee :) this is easy and would be ideal for single mummies or anyone that wants to stay at
home and work from your phone. If you want more info post how? :)”

115.

In June 2018 Officer Knowles interviewed a Joanna McKillop who was the director of 53 MUCs . Ms McKillop said
that she had signed up to Kedros to be a “nominee” director and that she had also signed up her husband, Neil, to
be the “nominee” director of 58 MUCs. Mr McKillop however he was unaware of this as Ms McKillop had not told
him she had “signed him up”. Ms McKillop confirmed that she had received £75 to be the “nominee” director of the
MUCs for both herself and her husband. She provided a copy of the contract she signed with Kedros together with
other documents and screenshots of the Kedros portal and confirmed that she signed documents to be the director
of the companies. However, she did not know that the MUCs of which she was the director had been registered for
VAT or that the applications for VAT registration had been submitted in her name.
**Registered Offices**
116.

The registered office addresses used by WRS when incorporating companies were those of the UK nominees.
Once the companies were ready and passed to a BPO the address was changed to a “virtual office” address
sourced through Corpserv, a company in which Mr Funtanilla had no interest and to which he was introduced by Ms
McLaughlin.
**Corpserv**
117.

Corpserv was registered in the United Arab Emirates (“UAE”) on 16 December 2018 to provide “virtual office” backoffice services. According to its website these include, for a “standard package” at £5 per month the provision of:

“a registered office address, mail forwarding via email once per week and no long contract.”

The “premium package”, at £10 per month, provided in addition to the services under the standard package and
post being forwarded via Royal Mail at cost price:

“director service address, mail forwarding via email twice per week, free.co.uk domain”.

These services were provided either by recruiting people to sign up to be “virtual office assistants” or through
Corpserv taking commercial tenancies to which post would be delivered and subsequently collected.
118.

A virtual office assistant would, as described above in relation to the Kinmel Bay second address of Rosscana,
agree for Corpserv to register its client's companies at the assistant's home address. All of that company's post
would then be sent to the address and the assistant would be required to open and scan it, and send the scan to
Corpserv using the Corpserv Virtual Office app on a weekly basis. For doing this the assistant would be paid a
monthly fee.
119.

Elizabeth Davies was, between January 2020 and March 2022, a virtual office assistant for Corpserv. She saw an
advertisement on Facebook advertising the opportunity to earn some money working from home and was
recommended to Corpserv by her friend, Tracy Shaw, who on 31 October 2019 forwarded to her an email, of 3


-----

(TC)

October 2019, from Donna Eckford which itself forwarded an email from Corpserv, also dated 3 October 2019,
which stated:

“Dear Corpserv Virtual Office Nominee,

I am pleased to announce we are accepting Corpserv Virtual Office applications again for a limited number of
people.

If you have any reliable friends or family whom you feel may be interested in signing up to become a Corpserv
Virtual Office Provider and earn some extra money please forward on the attached forms and ask them to
return the Application Form along with photo ID and a proof of address to info@corpservvo.com. We will pay
£75 for each successful referral made!

Please take note of the following points:

  - We are no longer offering the 200 company package for £200 Per Month to new CSVO providers. Instead,
we are now only offering the 100 companies for £100 Per Month package.

  - All applications must be signed (typing a name into the signature box using word is not acceptable) and all
three pages of the application forms must be returned.

  - All completed application forms must be supported with a copy of a photo ID and a Proof of Address (Utility
bill, bank statement, Council tax bill etc.)

   - We are not currently accepting applications from council housing tenants.

  - Applications will be processed on a first come first served basis. Any applications received after we have
filled our current vacancies will be added to a waiting list.

   - Payments will be withheld if post is not returned on a regular basis.

Please see attached a copy of the Application Form and also some information about the Corpserv Virtual
Office responsibility to pass on to any interested parties.”

120.

Ms Davies completed the application form which she e-mailed to Corpserv on 8 January 2020 together with a
picture of her passport, as proof of identification, and a copy of her Council Tax Statement, as proof of her address.
121.

Under the agreement she entered into with Corpserv, Ms Davies was required to provide a virtual office address for
either 100 or 200 companies, open company mail received at the virtual office address, use the 'Corpserv Virtual
Office App' to take pictures of the mail received at least once per week and reply to any e-mail communications
from Corpserv within 72 hours. If she was on holiday or unable to upload any images of the post received for more
than seven days she was required to inform the Corpserv Virtual Office team giving at least one week's notice.
Having been accepted by Corpserv Ms Davies began to receive post for 100 companies and was paid £100 a
month.
122.

Ms Shaw, the friend who had recommended Ms Davies to Corpserv, also confirmed that she had answered a “work
from home” advertisement on Facebook and had become a virtual office assistant for Corpserv between June 2019
and November 2022. She explained that payment for providing this service to Corpserv was based on the number
of companies registered at her home address. She said that she was initially paid £200 a month but that this was
increased to £250 at some point during the time she was working for Corpserv with payment being made by bank
transfer on or around the first of each month.
123.


-----

(TC)

In addition to taking photographs of letters to upload and send to Corpserv, Ms Shaw explained that the virtual
office assistants were also asked to send certain types of letters to a postal address for which they were to be paid
extra. This required a copy of the postage receipt to be sent to Corpserv by email which would reimburse the
assistants the next time they were paid along with the extra money that they were promised for posting these
letters. However, Corpserv did not pay the correct amount as promised, stating that a number of letters had not
been received even though the other letters which had been sent in the same envelope had been. Ms Shaw
continued to receive post and take images and uploaded to Corpserv until her contract was terminated. She said
that, at the time of her statement (17 February 2023) she was still receiving letters for the companies which she has
returned to sender unopened and with not known at this address written on the envelope.
124.

On 26 July 2021 during a visit to an address, identified as a virtual office in Middlesborough at which 98 MUCs were
registered, Officer Bennett, a debt collection officer, spoke to a Mr Conway who was housesitting for his son, Daniel
Conway. On her return to the property, on 31 August 2021, Daniel Conway told her that he had nothing to do with
the MUCs about which she was enquiring. He said that he had been approached by someone at university around
three years earlier who had asked him if he would like to make some money by using his address as a virtual office,
scan post onto a portal and send it to a company called Corpserv. He showed Officer Bennett a list of the
companies registered at his address. He also confirmed that he had received an email from Corpserv advising him
if HMRC came to the door not to worry as this is just a postal address and he would not be liable for anything.
125.

Before Corpserv had been registered in the UAE, WJ Nelson Limited (“WJ Nelson”), a company incorporated on 19
March 2018 with a Lee Pemberton as its director, had rented commercial properties to provide virtual offices for
MUCs. WJ Nelson was dissolved on 13 October 2020.
126.

Mr Pemberton, who was also the director of Go-To Outsourcing Limited (“Go-To”), was interviewed by HMRC
(Officers Knowles and Barnes) on 15 June 2022. The notes of that interview (which refer to Mr Pemberton as “LP”)
record that Go-To:

“… provides process outsourcing on behalf of other companies. His [Mr Pemberton's] company started to trade
about 4 years ago and was rebranded about a year ago. He now also does support work for recruitment
agencies by assisting them to sift through job applications provided and recommending candidates for job
roles. LP also provides a customer support role, payroll onboarding and administration for a company called
Azure.

…

LP advised he has a couple of staff in the UAE, who predominantly do due diligence work. His staff in the
Philippines carry out admin tasks, such as checking new starter ID and putting details on the system. LP
confirmed these overseas staff work for Go-To Outsourcing Ltd.

…

LP explained that when he was at a networking event in Germany, he made various contacts from all over the
world, including the Philippines and he stayed in touch with them. LP advised he was contacted by one of
these contacts to do some testing on software, databases, and ERP systems. LP advised that his customer
was very good at building the software but not so good at testing it. That's where LP got involved with testing
the software.”

127.

Although pressed to do so by Officer Knowles, Mr Pemberton said that he could not reveal the name of the software
concerned. Mr Pemberton also told Officer Knowles that before it had been dissolved WJ Nelson had provided


-----

(TC)

registered office services. With regard to Go To, he told Officer Knowles it had three “workstreams”, the first for
WRZ, the second for UK clients such as WK1 an intermediary (see below) and the third for recruitment agencies.
128.

The note of his interview continued:

“LP went on to explain that WRZ who are based in the Philippines had approached him to carry out work on
testing software and business process testing.

SK asked LP to explain what the terms “Business Process Outsourcing and Penetration Testing” meant. As
this was the wording for his services on the invoices for WRZ.

LP explained that Business Process Outsourcing is UI/UX testing of software, checking orders and operational
testing. LP explained that he helps to make software user friendly. Penetration Testing was looking at and
testing software. LP explained that he provides test reports and makes recommendations on improvements. LP
advised that this work is carried out by himself and his 16 staff members, of which 7 are doing this work full
time. LP explained that his staff in UAE (Dubai) do the due diligence work and customer service work.

SK asked who LP's contact with WRZ was.

LP advised John Funtonella (sic) is the contact with WRZ.

SK asked LP if he had met him in person to discuss the business requirements. LP confirmed he has met him.

SK asked LP what work was undertaken on behalf of WK1 Ltd and Outsourced Contracting Ltd.

LP advised that both companies were referred to him by John Funtonella. LP explained that WK1 Ltd were
struggling to complete due diligence checks. LP stated that WK1 Ltd had employed someone directly to deal with
this, they paid them £40k pa, however the work they undertook was not of a high standard, so they had let them go.
LP stated that the company now do these due diligence checks on behalf of these companies.
129.

In the interview Mr Pemberton also referred to Supplierland. He said that he used Supplierland to communicate with
the suppliers (MUCs) that had been provided by WK1 when evidence had been requested to show that their
accounts were paid up to date.
130.

After discussing the due diligence work undertaken by Go-To, Officer Knowles asked Mr Pemberton about the use
of a van that had been noted in the company's purchase invoices. Mr Pemberton explained that the van was hired
and had been used to move company records during the coronavirus lockdowns in 2020 and 2021. He said that the
van was only to help support employees working remotely by moving equipment and records to them and, as Go To
has staff based throughout the UK, it was also used extensively to make deliveries to remote workers. In addition,
the van was used to take workers to end clients to undertake software testing. Mr Pemberton told the officers, the
company no longer hired a van as it had recently purchased a car, a red MG.
131.

He also told the officers that Go-to had also acquired, on 24 December 2021, a letter opening machine together
with an annual maintenance contract for it at a cost of (net of VAT) of £2,943. Mr Pemberton said that the machine
was used for opening a “small” amount of post received at the office but bought as an investment for the business
because it held a “good” re-sale value.
132.

On 17 January 2023 Officer Knowles made a telephone call to a Terry Gormley, the landlord of commercial
premises in Stourbridge. The property had been visited by HMRC officers on 9 January 2023 as it was the
registered address of hundreds of MUCs. Officer Knowles explained that the purpose of the call was to obtain


-----

(TC)

further information. Mr Gormley told Officer Knowles that his tenant for the last two to four years was Mr Pemberton
and that he paid a monthly rent of approximately £250.
133.

Mr Gormley said that he was not aware that that the address was being used by MUCs. He told Officer Knowles
that he had been at the property on 17 January 2023 as a neighbour had reported a drip/leak. Whilst there he had
noticed a “mountain of post” that had been delivered to the premises, which was collected weekly by someone, not
always Mr Pemberton, in a van. Mr Gormley said that he was told by the driver of the van that there were several
addresses in addition to this premises in Stourbridge from which post was collected.
134.

Later that day, 17 January 2023, Mr Gormley telephoned Officer Knowles to let him know that he had located a
copy of the lease which he had agreed with Mr Pemberton and that it had commenced on 15 October 2018. He
recalled that the original lease was with Mr Pemberton. Mr Gormley recalled that in early 2022 Mr Pemberton had
asked him for a copy of the lease requesting it be in the name of Justena John from Corpserv FZE, which had an
address in Dubai. Although Mr Gormley was concerned, he was advised by Mr Pemberton that this was fine as it
was a bona fide company. Later that day Mr Gormley called Officer Knowles again to let him know that Mr
Pemberton had not returned a signed copy of the lease to him.
135.

On a third call to Officer Knowles, on 18 January 2023, Mr Gormley told him that he had spoken to another tenant
of his who ran a bike shop. When he had asked Mr Gormley for requested extra space to temporarily store stock Mr
Gormely had allowed him to use the office used by Mr Pemberton. The bike shop proprietor had asked why there
was so much post at the premises and had taken a photograph of the vehicle, a red car, which came to collect the
post.
136.

Shona Priddey, from 14 April 2019, also leased a ground floor front room of a property in Bromsgrove to Mr
Pemberton. She invoiced WJ Nelson for the rent. However, in October 2019 Mr Pemberton had asked her, in an
email, if invoices for the rent could be issued to Corpserv in the UAE as he was dissolving WJ Nelson in November
2019. He explained that he would still be the primary point of contact. Mrs Priddey acceded to his request and
entered into a new lease and subsequently invoiced Corpserv for the rent which, she said, was “always” paid on
time. Mrs Priddey said that, although Mr Pemberton never worked at the property, within weeks of becoming a
tenant “copious” amounts of mail from Companies House and HMRC was received for the ground floor front room.
She explained that the letters “arrived in their hundreds” which annoyed her other tenants as some mornings the
hallway was “covered” by these letters.
137.

Officers Shields and Chima visited this premises, at which 34 MUCs had their registered offices, on 1 December
2022 but despite knocking twice on the front door and ringing the doorbell there was no answer. The officers also
visited other premises on 1 December 2022 including an address in Kidderminster at which 393 companies had
been registered and at Warwick Racecourse where 260 companies had been registered.
138.

The Kidderminster address was that of a company called True Love Tattoos. The Officers entered the property and
went upstairs to find the 'rear office' on the first floor where the MUCs were registered. The buzzer for the first floor
indicated that in addition to the tattoo business, a first-floor office was used by a business called “We Construct”.
The officers spoke to someone from the tattoo business who told them that the other office was never used but that
they were becoming increasingly annoyed by the amount of post coming to the property which was collected by
someone driving a red MG car.
139.

At Warwick Racecourse Officers Shields and Chima spoke to the general manager who explained that many
businesses use the office address and that “everything is done through Corpserv” and is all cloud based The


-----

(TC)

manger stated that Corpserv is their client and had been for approximately nine to 12 months. He said that he was
not aware of the actual businesses registered there or their details and confirmed that there was no contract in
place. He told the officers that Corpserv send people to collect the unopened post every week for which it paid £300
per month.
**Recruitment and Training of Filipino Directors**
140.

Having identified a need for the directors of the MUCs to be able to communicate with their customers the
intermediaries, Mr Funtanilla created the Compass Star Communications Portal which allowed documents to be
uploaded, downloaded, and stored centrally. He also created the Compass Star app (the “CSL app”).
141.

Although Mr Funtanilla said that Compass Star did not use social media for the recruitment of Filipino Directors,
advertisements, such as the following, which was posted on 4 January 2019, did appear on Facebook:

“1.) What is Compass Star Limited?

Compass Star Limited is company that provides Director Referrals to Limited Companies in the UK Contacting
Market. Compass Star Limited is registered in the British Virgin Islands.

Compass Star does not operate in the Philippines but it outsources its operations to Million Philippines
Corporation, a Philippine company registered in the SEC.

2.) What are the responsibilities of a Director?

Directors are ultimately responsible for the Limited companies they are registered to. Directors will have to
review and sign business documents created by their company's accountancy firm through the use of the
Compass Star portal.

So long as you meet the following requirements:

Must be between 18-65 years of age

Must have a personal cell phone number

Must be able to access the internet

Must have a valid, personal email address

Must be able to personally carry out the Director tasks from the Compass Star Web Portal

Must be able to submit the required documents (proof of legality)

Then you are qualified to partake of this opportunity.

Payments:

Please note as well that your remuneration of PHP 10,000 per year follows the following payment schedule:

50% or P5,000 paid immediately upon successfully being assigned to a UK Limited company

25% or P2,500 at the end of the 3rd quarter of the year

25% or P2,500 at the end of the 4th quarter of the year

Through Cebuanna Lhuillier


-----

(TC)

Apart from your annual remuneration, you may also become a REFERRER and EARN UNLIMITED INCOME
for every SUCCESSFUL REFERRAL!!

If you have your 2 Valid Id's and 1 Valid Clearance already, MESSAGE your Real or FULL NAME for

FULL DETAILS and FREE ONLINE REGISTRATION/APPLICATION!!”

142.

A Facebook post, on 25 April 2019 explained:

“ComPASS (SIC) STAR is a homebased part time job; it means work is not everyday...

What will be our work in Compass Star? . Our work is to be the secretary of the company in Uk and Europe
which is to authorize the documents like company schedule, company purchases, receipt and so on..

Work is that simple..”

143.

Another advertisement that appeared on Facebook on 19 August 2019 stated:

“WE'RE HIRING!!

PART TIME HOME BASED JOBS

COMPASS STAR LTD

100% LEGIT!!

DEFINITELY

NO MONEY OUT

NO SELLING

NO PRODUCTS

NOT SCAM

INCOME 10K YEARLY, 1ST PAYMENT - P5,000

2ND PAYMENT - P2,500, 3RD PAYMENT - P2,500

AND EARN UNLIMITED INCOME FOR EACH

SUCCESSFUL REFERRAL

JUST LIKE/SHARE THIS POST, LIKE OUR PAGE, TAG 5 FRIENDS and MESSAGE

YOUR FULL NAME FOR FREE ONLINE APPLICATION AND FULL DETAILS!”

The requirements to be MUC director, as stated in that advertisement, were two valid identifications, valid
clearance, active personal cell phone number, active Gmail account and internet access. It would appear that
payments to those appointed as MUC directors were made by Veritek via GCash, a mobile telephone application.
144.

A PowerPoint presentation, exhibited by Mr Funtanilla, contained a “walkthrough” of the steps required for a Filipino
national seeking to take up the advertised opportunity to apply to become a director of a UK company and, if


-----

(TC)

successful, in choosing their package on the Business Support Club (“BSC”) and finding their customer on
Supplierland (see below in relation to Supplierland and the BSC) following their appointment.
145.

The first step required the potential director to download the CSL app through the Apple Application Store or
Google Play Store to be able to continue. Initially, the potential director would have accessed the necessary
materials via a weblink to the Compass Star website/portal. This would take him or her to a “home” screen. On that
screen there is a short video which the potential director must watch. It explains the importance of data protection
and the data privacy policy that the director was asked to accept. It also stated:

“Thank you for your interest in becoming a director for a UK Limited company. Before we continue, please note
that the entire process is legitimate and is subject to compliance reviews from the UK government. As such, it
is extremely important that the information you provide is completely accurate and infallible. You must certify
that all the information you have provided is true and correct. You must be able to be contacted through your
personal email account and through your personal mobile number. Someone from CSL will receive your call
and validate all your personal details.”

146.

Having entered the account details and authentication details (eg a last three characters of a mobile telephone or
passport number) the potential director must click on either “yes” or “no” to confirm that he or she has:

“…NEVER served as a Director or Company Secretary, and have NEVER been a shareholder of any UK
company.”

147.

The potential director is then invited to provide their personal details and click “continue”. Having done so they are
taken to the next step which requires them to upload their identification documents. At this stage they received the
following message:

“Done!

Thank you for completing your application. An account has been created for you.

What happens next?

You will be informed once CSL is ready to allocate your directorship to an appropriate UK Company. IDs
submitted will be validated per queuing basis as we receive many requests. If you are successful, you will
receive an email confirmation that all your IDs has been accepted and be ready to wait of our call for the
orientation and interview so keep your lines open and always reachable.

Company offers and contracts will be sent to your email and should be read and signed within 24 hours. Please
review and sign the documents requested and accept. CSL will have a final review of all the documents and
confirm your acceptance once contracts and documents are completed. You will be notified once your
registration completes, your first renumeration will be sent within 30 days after signing your Incoming Payments
notice.

Good luck!”

148.

Mr Funtanilla described the vetting process undertaken by Compass Star. This would involve the potential director
being contacted by a Compass Star employee who would ask the candidate questions relating to their identification
to establish a feel for the candidate and monitor the authenticity of the referral. All such conversations would be
carried out in English. Although interviews were originally in-person at Compass Star's premises Mr Funtanilla
explained that during the pandemic Compass Star was not permitted to invite candidates to the office and
interviews were conducted over the telephone Following the interview a notification would be sent by email


-----

(TC)

instructing the applicant to log into the Compass Star portal where there would be a message stating whether they
were successful or not. If unsuccessful, the candidate could not use the Compass Star portal any further. A
successful applicant received a notification from Compass Star telling them to log into the portal. On the portal was
a message telling them they were successful and could become a director of a company.
149.

Having verified their email address and mobile telephone number on the CSL app the newly accepted director is
instructed to Navigate to the “Company Details” section within the director's account where:

“the director will have the opportunity to select the specific company they wish to become a part of.”

The system would then provide a list of relevant companies from which the director is able to choose.
150.

Although the PowerPoint slide refers to lists of relevant companies being based on the interests of the newly
accepted director or from other fields outside of their professional interest, it would appear that all that is shown on
the screen is a list of companies, their registration number and trade sector within which they operate eg “transport”.
There is a tile on which the newly accepted director is required to click, stating “Get Company”.
151.

Ms Flores, the director of Elphysic, having completed and returned her application form explained that after about a
month she was contacted on the telephone by a female employee of Compass Star. After confirming she had made
an application to be a director she asked Ms Flores if she was ready to perform the role of a director and if she had
the time to do so. Ms Flores agreed. She explained that she had previously worked in administrative roles in
companies which she considered made her suitable for the role. The Compass Star employee confirmed that Ms
Flores was going to be offered a position as a director and explained that a contract would be sent to her home
which should be signed and returned. Following this telephone conversation Ms Flores received a notification via
the portal to log in and choose her company. The company she chose from the many available was Elphysic. She
explained that this was because liked the name and thought it was unique.
152.

Ms Gonzalo, the director of Phyarreidon, explained how she was contacted by telephone by a male member of
Compass Star staff a few days after she had submitted her application to become a director. He asked her
questions about her understanding of the role, her prior experience, qualifications and background and was told at
the end of the call that she had passed the interview and should log into the CSL app after a few hours to choose a
company to operate. She said that on completing her login to the CSL app there were several companies to choose
from, but she liked the name Phyarreidon and chose it.
153.

Ms Velasco, Rosscana's director, saw being a director of a UK company as:

“… a new opportunity and trying something new, being a Filipino director . So when I was told about this
opportunity I got interested, so being – like having some experience in the virtual world. So I think it's kind of
like a new experience for me.”

Having received a telephone call from a Compass Star employee who had told her that the opportunity related to
the UK labour market, something about which she knew little and had no experience of, Ms Velasco was invited to
choose a company on the Compass Star portal. Of the list of companies there she chose Rosscana. She said that
she chose it because:

“Rosscana is the most simplest one and very easy to pronounce.”

Although it was listed as transport company Ms Velasco said that it was supplying labour relating to packaging but
that when she chose the company it did not matter what sector it was in.
154


-----

(TC)

Ms Daca, the director of Zraytumbiax, said that she was notified via the CSL app around an hour after she had
been interviewed that she been successful. She was then directed by the CSL app to choose her company.
However, the only company available for selection was Zraytumbiax. Although there were other companies shown
on the list these were “greyed out” and not available to choose. The business of Zraytumbiax was, she said, freight
transport by road an industry about which she said she knew nothing. She was unable to explain what the
company's employees actually did:

“… because intermediary is the one who is delivering these workers into their own assignments.”

155.

Having clicked on the name Zraytumbiax to select the company, Ms Daca was taken to a gov.uk page where she
saw that the company was registered and had a director, Paige Chick, someone who she did not know and had
never met. She subsequently discovered that Paige Chick was a nominee director who had resigned the same day
as Ms Daca's appointment. Ms Daca confirmed that the change of the registered address of Zraytumbiax following
Ms Chick's resignation as director had been chosen by her “back office”.
_BSC_
156.

After the company has been chosen, the director is directed to the BSC website, a platform/online market place,
which provides details of various recommended services aimed at assisting the company in its operations. The
BSC, which was already supplying some services to the labour supply industry, was used to support the MUCs as
they required associated services to operate. It was aimed at new businesses and matched new businesses to
suppliers of goods and services and has a tool that enables suppliers to be recommended to customers. The BSC
was paid a commission by the suppliers who sold their services/products and were contracted to the customers via
its website.
157.

Having selected Elphysic as “her” company Ms Flores was directed to the BSC website where she purchased the
package of services recommended by Compass Star. These included training disks, banking services, insurance,
the services of Angstrom a BPO (although she actually signed a contract with Verity – see below) and access to
Supplierland. Although she said that she could have altered the package of services she did not do so. Also
included as part of the BSC process were options, in tick boxes, to state whether or not she wanted to apply for
registration for VAT for the company. Ms Flores said, having been told by Compass Star that was what the
customers wanted, that she did select to be VAT registered.
158.

Ms Gonzalo, director of Phyarreidon, said that she was directed to the BSC where, having looked at the services in
the “basket (as recommended by Compass Sar) she had decided to purchase that package which included: a BPO
(Angstrom), banking, insurance, training discs, and access to Supplierland.
159.

Having been re-directed to the BSC once she had selected Rosscana, Ms Velasco “chose” the package
recommended by Compass Star which included Verity as BPO. She explained that this was because she “trusted”
Compass Star despite having only known of its existence for one day.
160.

Ms Daca of Zraytumbiax explained that she had been recommended by Compass Star to a package from the BSC,
a package consisting of five services, all of which were in a pre populated shopping basket on the BSC website.
The items in the basket were the services of a back-office provider, Angstrom, employer's liability insurance, a bank
account, access to Supplierland, and 11 training videos (see below). Although Ms Daca said that she could have
altered (or added to) what was in the basket, she did not do so. She did not consider other options or make
enquiries as to whether the services could be obtained elsewhere for less either. She explained that this was
because she trusted Compass Star “because they are experts with this matter” even though she had known
Compass Star for “just one day” and had watched a video explaining what it Compass Star will “do for you”


-----

(TC)

161.

The BSC, Ms Daca also explained, contained boxes which she ticked stating that the company wanted to apply to
be registered for VAT and to join the FRS. She did so after the benefit of registration had been explained to her
when interviewed by Compass Star and because:

“… it's much better if the business is VAT registered to look more professional.”

Ms Daca said that her BPO had explained to her that if the turnover was below the threshold (then £85,000) it was
not necessary to be VAT registered to trade but had nevertheless recommended that the company did register for
VAT even though under the contract with its customer it did not expect the turnover to exceed £50,000.
_Verity_
162.

One of Compass Star's recommendations in the pre-populated BSC basket was the “Verity BPO Package”. BPO
services had originally been provided to the MUCs by AMBR UK, a company established by Ms McLaughlin in 2014
(around the same time she had established Kedros) and began trading from around 2016. It was a back-office
provider specialising in supporting small companies operating in labour supply (ie MUCs) providing payroll services,
clerical services, call centre services and bookkeeping for them. It had around 12 members of staff who were
responsible for payroll processing, employee pension management, PAYE filings, auditing, providing call centre
services via a worker helpline, book-keeping, reconciliation, credit control, debt management, company accounts
filings, and clerical services only to companies setup by Kedros.
163.

From October 2017 Ms McLaughlin began to wind down the operation of AMBR UK for personal/family reasons and
decided that it would be a better way of operating if the back office services were be provided from the Philippines
where labour was cheaper and where they were used to providing back-office support for UK businesses. It would
also enable Ms McLaughlin to take “more of a back seat”. However, as she realised that the back-office company
would very likely need some UK support she established a personal services company through which she provided
consultancy services.
164.

AMBR Business Process Outsourcing Inc (“AMBR PH”), which Ms Mclaughlin had incorporated in the Philippines in
November 2016, commenced trading providing back-office services from l December 2017. It rented serviced
offices and initially had six members of staff who performed business processing services. All of AMBR PH's
customers were MUCs. Ms McLaughlin was a 99% shareholder of AMBR PH with the remaining share held by four
nominee directors and shareholders.
165.

Around 2018, Ms McLaughlin was introduced to Mary Joy Figueroa who took over AMBR PH in January 2019. Ms
McLaughlin explained that she wanted a consultancy role and had grown the business to a point where she
considered that to be possible. Also, Ms Figueroa had a background in managing people and was keen to be
involved on the ground and operate the business. In exchange for Ms Figueroa agreeing that the company would
use Ms McLaughlin's consultancy services, based on the existing trade of the business and its client base, it was
agreed that she could acquire Ms McLaughlin's shares and is now the 99% shareholder with the remaining 1% held
by the same four nominees.
166.

Shortly after Ms Figueroa becoming the majority shareholder, AMBR PH changed its name to Verity. This was to
avoid any potential confusion with AMBR UK. Verity continued to provide support services to the MUCs and has
expanded from its original operation. It has 65 employees and operates from serviced offices in the Philippines. Ms
McLauglin continues to provide consultancy services to Verity.
167.


-----

(TC)

We were provided with an example of Verity's terms and conditions set out in “a Service Agreement” between
Verity (defined in the agreement as the “Service provider”) and Adeem Limited (“Adeem”) (“defined in the
agreement as the “Client”) which, although not one of the Lead Appellants, was a MUC with a Filipino national as its
director and a registered office in the UK. Clause 10.4 of that agreement provides:

“As the authority dealing with the company administration, the Service Provider will, subject to appropriate
resolution, initiate proceedings to remove the Client from his company office in event that he fails to meet the
obligations required of him in his role as Director.”

168.

Schedule 1 to the agreement sets out the services provided by Verity:

“Specification of Services

1. The Service Provider will register the Client's limited company for PAYE

2. The Service Provider will provide ongoing payroll services including;

2.1 Payroll administration

2.1.1 Processing payroll as required, including;

2.1.1.1 Calculating and paying PAYE, National Insurance and Student Loan

2.1.1.2 Calculating and paying Pension Contributions

2.1.1.3 Calculating and paying Attachment of Earnings

2.1.1.4 Paying your employees via Faster Payment

2.1.1.5 Issuing Contracts to workers

2.1.1.6 Issuing P45's

2.1.1.7 Passing any HR issues to the Client

2.1.2 RTI filing [ie under HMRC's Real Time Information (“RTI”) system]

2.2 Year-end reporting

2.2.1 Issue and file P14s, P60s and P35 with HMRC

2.2.2 Issue and file P11Ds

2.2.3 Calculate and advise re Class 1A NIC payments

2.3 The payroll administration will take place on a weekly basis, between Monday and Friday.

3. The Service Provider will provide registered office services for the business.

4. The Service Provider will sign an Insurance authority to make payments to your insurer on your behalf.

5. Access to a specialist Software platform to provide the Client with payroll information.

6. Review management accounts produced by the Client and assist with year end filling process to ensure
compliance with UK Accounting and Tax legislation (including, Annual Accounts and Corporation Tax returns).

7 Ad hoc accounting advice as and when required by the Client ”


-----

(TC)

169.

Schedule 2 makes the following provision for fees and payments:

“Our professional fees to your company for the support services listed above will be £3.00 per worker
processed per week plus VAT.

These will be invoiced at the end of the month with a breakdown of our fees

Any additional fees over and above the amounts detailed above will be notified to you in advance for approval.”

170.

The newly appointed MUC directors confirmed their agreement to these terms and conditions, as well as those for
Supplierland, Trilogy and Veritek, by ticking the relevant box for each as requested by the BSC to which they were
also required to provide personal information.
171.

It is common ground that the each of Lead Appellants entered into an agreement with either Verity or Angstrom on
identical terms, including clause 10.4, to the above agreement between Verity and Adeem.
172.

For completeness, having previously referred to it, we should explain that Angstrom, a Philippines registered
company was established in 2020 and began trading in 2021 delivering identical BPO services to those provided by
Verity. It employed the same employees as Verity and shared the same offices and facilities in the Philippines. Ms
McLaughlin, who was not involved in its establishment, explained that Angstrom gave customers the “choice”
between two BPOs.
173.

Although Mardie Flores, the director of Elphysic, said that Angstrom provided Elphysic with BPO services, she had
signed a contract with Verity on 30 March 2021 for the provision of such services. This was not “corrected” until a
new agreement between Elphysic and Angstrom was signed by Ms Flores. Although it was stated on that new
contract as being entered into on 31 March 2021, it was not until 20 July 2023 (shortly before signing her witness
statement) that this new agreement was signed. Ms Flores sought to explain this saying:

“… because I become a director on March 31 2021, so the service agreement must be done on that date. So
that's what I have said, the agreement that I have done between Verity and me is an honest mistake and that I
just found out when I had already agreed. And then – so I signed a new contract with Angstrom because from
the very beginning my service provider is really Angstrom, and that's a human error and that is an honest
mistake on my part.”

174.

Ms Flores said that she authorised everything that she had been asked to authorise by Angstrom but said that she
would have checked it first as she always did. However, despite saying she checked the service agreement with
Verity she could not explain why she had not noticed that it was the wrong service provider other than to repeat that
it was an:

“… honest mistake, it really was an honest mistake.”

175.

As with the pre-populated BSC “basket”, although a MUC director could decline to approve a document sent by its
BPO for approval in practice this never happened and the document, be it a VAT return or anything else, was
always authorised. Ms Daca of Zraytunbiax explained that this was because:

“… it's accurate that's why I authorise it”.

_Supplierland_


-----

(TC)

176.

Having agreed to the terms and conditions on the CSL app the director would be taken to a new page where, in
addition to information regarding a training disk subscription (see below) there is an invitation from Supplierland to:

“Come check out hundreds of Suppliers in our Marketplace!”,

This is a continuation of the automated process leading to the next step which is to login to the Supplierland
account.
177.

Mr Funtanilla explained that Supplierland was incorporated on 15 April 2018 to enable the introduction process and
due diligence process for the MUCs to be, as far as possible, automated. He said that that he recognised that the
business would never be successful if shortcuts were taken, and automation facilitated the proper functioning of the
business. He also recognised that lots of intermediaries essentially traded in the same way and wanted the same
thing. Supplierland therefore invited intermediaries to sign up and enabled them, once they had paid a subscription,
to post opportunities that could be met by a MUC.
178.

Intermediaries accessed Supplierland by setting up an account. Once they agreed to the online terms (including
paying a subscription of £12,000 per annum) Supplierland invoiced the intermediaries. Once it received the
information regarding the intermediary and their invoice was paid, they were added to the Supplierland system and
had the ability to advertise the contracts to be fulfilled by suppliers. The MUCs did not need to pay a fee to register
as labour suppliers on the site but were charged a monthly fee by Supplierland. Invoices were sent once the MUC
had been granted access to the portal and they had agreed to the online terms.
179.

The material parts of these online terms provided:

“Supplierland Marketplace Agreement – SME

This Supplierland Marketplace Agreement (the “Agreement”) governs your access to and use of the
Supplierland products and services described below, and constitutes a binding legal agreement between
Supplierland and you.

…

**Supplierland Marketplace**

Supplierland offers a platform (the “Marketplace”) for those businesses involved in the supply of labour services
and associated products through which those seeking services (“Clients”) can be matched with those who are
able to supply the services (“Suppliers”).

Clients may specify one or more uniquely defined contracts (the “Contract”) upon which the Suppliers will be
able to advertise the price at which they are able to deliver the services (“the Bid”). The Marketplace provides
Clients with the opportunity to advertise the Contract and for Suppliers to make the Bid.

For each Contract opportunity, the Marketplace enables the Client to compare Suppliers by reference to price,
experience and compliance with regulatory requirements through an auction mechanism. The auction
mechanism takes into consideration bid-price, customer feedback and experience of delivering the Services.

…

**Payments by Clients**


-----

(TC)

As a client you will pay Supplierland an annual fee which will be charged upon registration [ie the £12,00
referred to above].

**Payments by Suppliers**

As a supplier you will pay Supplierland a monthly fee which will be due on registration

180.

Mr Funtanilla knew that Aspire engaged with the users of Supplierland to utilise a due diligence framework that they
had developed. He also knew that this framework was purchased by the intermediaries direct from Aspire and a
training course was available to help with the management of risk. He therefore approached Aspire with a view to
licensing the materials for incorporation into the Supplierland platform so that the users could communicate with
each other more easily. Aspire told Mr Funtanilla that it had been in dialogue with HMRC's FIS (Officer Harker) and
that the due diligence framework had been sanctioned as one which would reduce supply chain risk.
181.

However, Officer Harker in evidence said that he had no recollection of ever reviewing Aspire's due diligence
documents saying that he:

“… certainly shouldn't be sanctioning anybody's due diligence.”

182.

Nonetheless Mr Funtanilla was comforted by what he was told and the knowledge that intermediaries and MUCs
were embarking on what he described as an “authorised process”. It was therefore agreed that Supplierland would
license the due diligence process from Aspire with effect from July 2020 (the “Licensed Materials”) and that Aspire,
under this agreement, would update these as appropriate. The first version of the licensed materials was provided
by Aspire on 4 September 4 2020 comprising:

(1)   Due Diligence Policy;

(2)   Appendix A: Due Diligence Questionnaire;

(3)   Appendix B: Due Diligence Questionnaire Guidance;

(4)   Appendix C: OMR Questionnaire; and

(5)   Appendix D: OMR Questionnaire Guidance.

183.

Suppliers would complete an initial questionnaire which was made available to intermediaries on the portal by
Supplierland. Intermediaries which were looking to engage the services of a supplier (MUC) could access these and
consider the questionnaire responses before engaging a supplier. The cost of this was covered by the subscription
that the intermediaries had paid. The questions asked on that due diligence questionnaire ranged from the
straightforward, such as the provision of the company name, its trading name if different, its registered and
correspondence addresses, names of directors with copies of their identification documents to other matters such
as:

(1)   Is the company registered as a contractor under the Construction Industry Scheme (CIS)?

(2)   Is the company registered as a subcontractor under the Construction Industry Scheme (CIS)?

(3)   Does the company hold gross or net status?

(4)   Are there any offshore companies in the labour supply chain?

(5)   Do you have [a] Criminal Finances Act policy?

(6)   Do you have a Modern Slavery policy?


-----

(TC)

(7)   Do you operate in a sector regulated by the Gangmasters Labour Abuse Authority (GLAA)'s licensing
standards?

184.

There is no indication that this document was completed by the MUCs' directors and, if it was completed at all, this
must have been on behalf of the MUCs directors.
**Customers**
185.

Having agreed the terms and conditions and gone through the login process to access Supplierland, the director
would be provided with a list of potential clients and choose its customer from that list.
186.

Ms Flores, director of Elphysic, said that she had found its customer, Pico Business Solutions Limited (“Pico”), on
Supplierland. However, other than explaining that Pico was “my intermediary” and that “it helps for the agency
supply chain” Ms Flores was unable to provide anything further in relation to Pico, its trade, business or field of
operations.
187.

Ms Gonzalo explained that, having purchased the package on the BSC she followed the link on to Supplierland on
the Compass Star portal where she clicked on a “Let's find customers” button. She said that the only customer that
appeared to be available was an intermediary company called “E-Payslip Now Limited” (“E-Payslip”). Although
there were other customers listed their names were greyed out and as she could not click on them she chose EPayslip.
188.

Similarly, Supplierland was also how Ms Velasco found Minden, which operated in packaging, as Rosscana's
customer.
189.

Ms Daca (director of Zraytumbiax) explained that after she had made her purchases at the BSC she was redirected back to the Compass Star portal and clicked on a green button that stated, “Find a customer”. Having done
so she was re-directed to the Supplierland website where she found a customer that wanted to purchase labour,
Keytemps Limited (“Keytemps”) although that she did not know what its real business was.
**Directors Duties & Payments**
190.

On becoming a director of a MUC a communication would be received from Compass Star setting out the
responsibilities of a director and explaining what could be earned.
191.

Ms Gonzalo, the director of Phyarreidon, received the following from Compass Star:

“The role of company director is vital to the operation of the business. Ultimately, you will be responsible for the
decision making required in running the business and so, it is important that you understand what the role
entails, what is expected of you and what you can expect in return.

192.

It continues setting out the “General Responsibilities of UK Directors” including that as a director:

“You must not allow your powers as a director to be controlled by others - you may accept advice but must
exercise your own independent judgement to make final decisions.

…


-----

(TC)

**Duties you will be required to perform in return for earnings from your UK Limited Company**

  - Your company will need to bid for contracts to supply services to UK intermediary companies

  - Approve VAT Returns every three months

  - Approve PAYE Returns every month

  - Approve Management Accounts

  - Respond in a timely manner to emails from Customers

  - Respond in a timely manner to emails from your Accountant

  - Approve Year End Accounts

  - Approve Tax Returns and Annual Returns

  - Review and sign Contracts

  - Make business decisions

**What will you earn from your role as director of a UK Limited Company?**

  - You will be paid PHP 10000 split over 12 months in 4 equal instalments months provided that you continue

to fulfil your obligations as a director

  - Your company will operate in a competitive marketplace – it will be up to you to decide the level of margin

that you want to retain from receipts for the services that you supply

   - You will need to ensure that the margin that you retain is sufficient for your company to cover all operating

costs and make a profit

  - The remaining profit will be available to you to take as a company dividend, subject to future investment

requirements”

193.

Ms Gonzalo, like the directors of all Lead Appellants, did not receive a dividend from “her” company. Neither did
she, or the other directors of the Lead Appellants, receive director's fees or a salary from their respective MUCs.
Instead, each director received a payment of PHP10,000 from Compass Star irrespective of the performance of
their companies. That figure of PHP10,000 and how and when this was paid to the directors, ie the timing and
amount of each instalment was something, Ms Gonzalo said, that was decided by Compass Star and not her.
_Director's Nights_
194.

To recruit directors and enable existing directors of the MUCs to meet with potential customers and at the same
time create what Mr Funtanilla described as a “social community”, Compass Star held evening events/parties at
different locations throughout the Philippines. Not only would the directors be given market updates and provided
with food and drink, but they would also have an opportunity to meet with the UK business advisers who were also
invited. The UK representatives would often address the attendees to provide an insight into their businesses and
service delivery expectations and any recent changes in UK legislation.


-----

(TC)

195.

There would also be games, raffles, and prizes (such as a mobile phone, a tablet, a laptop etc) which Mr Funtanilla
saw as a way of enhancing the capabilities of those attending of operating a successful business. We were
provided with photographs of one such social event, a “Director's Night” at the Baylea Cavite, held on 24 April 2017
at which Mr Funtanilla and Alan Nolan of Aspire were present and spoke. We were also shown a video recording of
another such event at which Mr Nolan told those present that he represented Aspire:

“… and we are the accountants to the directors – so we look after everything to do with your companies.”

**Training Materials**
196.

Because of difficulties with internet bandwidth in the Philippines it was decided to create a suite of training videos
and to deliver such training via CD-ROMs which would be available for the MUCs to purchase. Such an approach
also satisfied the “limited cost trader” requirements on which Compass Star had taken the advice of Mr Goodfellow
QC.
197.

Mr Funtanilla had spoken to Andrew Lumbre from Aspire Outsourcing Services, a training and communications
business established in the Philippines, regarding their training material as he had known Mr Lumbre for many
years. Mr Lumbre confirmed that he would arrange for the development of a suite of training films which he could
license for use by the MUCs through the BSC and make available to other clients as training material. Mr Funtanilla
had created a company called About Business Software LLC (a United Arab Emirates company based in Dubai)
which licensed the training films from Aspire Outsourcing Services through the BSC.
198.

The following 11 CD-ROMs containing training materials were produced:

(1)   Agency Worker Regulations;

(2)   Company Formation;

(3)   Director Responsibilities;

(4)   GDPR;

(5)   Holiday Pay Obligations;

(6)   HR Essentials;

(7)   Making Tax Digital;

(8)   Modern Slavery;

(9)   Pensions & Protection;

(10)   Sales and Marketing; and

(11)   Taxation, PAYE, National Insurance Contributions and Income Tax.

199.

Ms Flores, the director of Elphysic, explained that the training disks were purchased at a cost of £200 to £600 each
through the BSC package from Xelarus and Tyche at a total cost of £1,600. She said that these were “very useful”
and although she could have carried out her own research a little or no cost said:

“Well, the training disk is very important, so the amount does not matter because the importance that it helps
me is more than the amount that I am going to pay.”

200.


-----

(TC)

Ms Gonzalo of Phyarreidon confirmed that she had received the training disks which had been delivered one at a
time approximately every two months. She said that in addition to watching them she did her own research and also
looked at the gov.uk website.
201.

Rosscana also purchased training disks paying a total of £2,900 to Tyche. Ms Velasco explained that although the
disks were relatively short (each was approximately ten minutes in length ) she considered them to be good value
as she could:

“…gain more knowledge in these training videos and knowledge cannot be paid for [at ]any price.”

However, as Ms Velasco acknowledged, it would have been possible to have carried out the research herself for
nothing.
202.

Ms Daca, the director of Zraytumbiax which had purchased the disks from Xelarus for £3,300 and About Business
Software LLC for £600, claimed in evidence that each disk took about around 45 minutes to an hour to view.
However, the longest disk, that for marketing, was 20 minutes in length with the others lasting approximately ten
minutes each. Ms Daca said that although she considered these disks to be expensive she thought that she could
learn more with them.
**Employees**
203.

It is apparent from the interview of Brian Taylor and Bruno Dunington of Less Stress Payroll Solutions Limited
(“LSPS”) by HMRC Officers Knowles and Sophie Fletcher, which took place on 6 December 2022, that workers
were allocated to, rather than chosen by, the MUCs that employed them. When asked by Officer Knowles how
workers are put into different MUCs Mr Taylor said that they were allocated based on the business area they
worked in and costs and savings. The employees were also moved between the MUCs and did not always know
which MUC employed them, believing that their employer was the agency at the head of the chain.
204.

This is apparent from the following email sent on 1 June 2020 by Toni Aubrey, a MUC employee, to Gail Corrigan of
Venus Outsourcing (which was copied to Alex Westworth of Now Education and her Member of Parliament) under
the subject matter “Furlough” in relation non-payment under the Coronavirus Job Retention Scheme:

“I am confused, perhaps you can clear up my confusion?

I signed up with Now Education and as far as I was concerned they were my employer . However, due to the
situation we are now in it appears they are not. So I was then led to believe that Venus was my employer?
Then it becomes apparent that no, Venus is an outsourcing company and I'm employed by some construction
company in Scotland that I have never even heard of?

So my confusion, how is it that I'm employed by a company I've never heard of?

How is it that Now Education, who apparently are NOT my employer, can move me, freely without my
knowledge, from one employer to another without any consultation with me, but they're not my employer?

How is it that as this fiasco of a situation has progressed everyone seems to want to 'pass the book'. Now
Education have suggested I get in touch with you because they aren't my employer, you are now saying I get in
touch with some construction company from Dumfries and Galloway as they are my employer?

Why would a construction company in Scotland employ a Teaching Assistant in Wolverhampton??? Why do I
need to contact them when I HAVE NEVER HEARD OF THEM????

Please can somebody contact me today with some answers.”


-----

(TC)

205.

Ms Corrigan responded on 1 June 2020:

“Thank you for your e-mail and I am very sorry for the confusion which I will try to clear up for you.

Firstly, I can confirm that your employment is with Camellia Ltd [a MUC], which is a specialist labour supplier to
Venus Outsourcing.

We have expressed your concerns to the director of Chelonia Ltd who has provided us with an explanation
concerning non-receipt of payments under the furlough scheme.

According to the director, Leanne, an application was made in accordance with the Coronavirus Job Retention
Scheme (CJRS) and, it was explained to you that any payment due under this scheme would be paid after the
supplier had received funds from the Government.

Despite Leanne's best endeavours, Chelonia Ltd has experienced lengthy delays before receiving payments
from HMRC for which they are yet to receive an explanation. Whilst these funds have not been received by our
supplier, we have today received an assurance that the furlough payment due to you will be issued without any
further delay.

Please accept my sincere apologies that you have had to write to me in order to resolve this matter. I hope my
response clarifies this matter for you.”

206.

Another example of a “confused” MUC employee can be seen from the note of a telephone interview of Marcus
Love by Officer Thomas Wright on 14 February 2023. Having explained that he was not looking into Mr Love's
individual tax affairs but at the employment arrangements of the companies that had paid him, Officer Thomas
Wright asked Mr Love whether he had heard of Couragerecords Limited, Firespittingceltic Limited, Berollo Limited
and Miemanum Limited, all of which had submitted payroll for Mr Love between 18 February 2020 and 2 March
2021, 2 March 2021 and 22 June 2021, 22 June 2021 and 30 July 2021 and 2 August 2021 and 29 October 2021
respectively.
207.

Mr Love confirmed that he recognised these names which he thought all belonged to the same employer, namely
Quest Employment agency (“Quest”), on behalf of Amazon which he considered to be his employer. He explained
that he was paid through a payroll company which completed the weekly payments by BACS. Payment was never
made by Quest and different company names were shown on his bank statement as having made the payments. In
the event of any pay query he would contact Quest which would always refer back to the payroll company but did
not identify it. He said that he had been required to enter into a contract before he received any payslips which he
received online through a link on the Quest Employment website. The contracts he signed were with the companies
such as Couragerecords Limited, Firespittingceltic Limited etc and the payroll companies frequently changed. Every
time there was a change in the payroll company Mr Love was asked to sign a new contract with the new company
before he was paid.
208.

When Officer Maughan contacted workers who appeared to have been employed by MUCs some of those he
contacted had heard of the MUCs that employed them although many had not. However, all those he contacted
considered themselves to be employed by the recruitment agency and not the MUC that actually employed them.
For example, when Officer Maughan made a telephone call to an Andrew Wilson on 16 February 2023 and
explained to him that HMRC records showed that he had been employed by five companies, one of which was
Rosscana, Mr Wilson told Officer Maughan that although he was aware of the names of these companies, which he
believed were payroll companies used by the agency, he had worked for Parcelforce via an agency, Capital
Recruitment, which changed payroll companies every six to nine months.


-----

(TC)

209.

Officer Prichard had a similar experience when she asked a taxpayer if she had heard of Androsaed Limited, a
MUC that HMRC records showed had employed her. Officer Prichard was told that the taxpayer had not heard of
the company and although she did not know she thought that it might have been connected to the period when she
worked at Aldi as agency staff. However, she could not remember the exact dates of that employment or details of
the recruitment through which it had been obtained.
210.

The employment history of all of the individuals employed by the Lead Appellants and Jazztify was reviewed by
Officer Copeland.
211.

He found that Elphysic had a total of nine workers, eight of whom became employees after working for another
MUC. Around October 2021, Elphysic's workforce had fallen to one. Six employees had become employed by
businesses other than MUCs, one had retired and the other had no further employment. The sole remaining worker
continued to be employed by Elphysic until joining another MUC in in April 2022. Elphysic claimed a total of
£2,459.50 in EA for the 2021-22 tax year and then ceased to remit PAYE RTI returns.
212.

Officer Copeland's review identified that Phyarreidon had a total of 20 individuals engaged during the period it
operated. Nine of these were employed by Phyarreidon immediately after having been employed by a MUC and six
were employed by another MUC immediately after leaving their engagement with Phyarreidon. In 2021-22, the only
tax year in which it traded, Phyarreidon claimed the full amount available for EA, £4,000. It had a total Secondary
Class 1 National Insurance liability of £4,424.33 and, as a result, paid HMRC £424.33 relating to Secondary Class 1
liabilities in the final months of the 2021-22 tax year. The amounts paid fell from £359.73 for the period ended 5
March 2022, to £63.60 for the period ended 5 April 2022 which followed five of the six remaining employees leaving
in March 2022, all of whom were subsequently engaged by another MUC.
213.

In relation to Rosscana, Officer Copeland's review found that, during the period in which it operated, Rosscana had
employed 56 individuals. 19 of these had previously been employed by a MUC and 17 went on to be engaged by
another MUC, three of whom had been employed by MUCs both before and after a period of employment with
Rosscana. The decrease and increase in the number of employees corresponded with the reducing EA available
with an increase in the number of workers engaged at the start of the tax year when EA is reset. Rosscana
submitted RTI reports for the periods ended 5 August 2019 to 5 July 2021 inclusive, claiming a total EA for each tax
year of £2,664.31 for the tax year ended 5 April 2020, £2,625.51 for 2020-21 and £491.78 for 2021-22.
214.

For 2021-22 Rosscana submitted RTI reports for the periods ended 5 May 2021 and 5 June 2021 only claiming a
total of £491.78 EA in May (as above) before paying a reduced amount of liability in June. The total PAYE charge
due in June was £1,420.19 with £932.92 being paid to HMRC. The difference, £487.27, equated to the exact
amount of EA it would have claimed had its eligibility to do so not been removed by HMRC.
215.

The review also ascertained that Zraytumbiax had employed a total of 20 individuals, of which nine were engaged
immediately after an engagement with another MUC. Five employees were immediately employed by another MUC
on leaving Zraytumbiax. Three individuals were employed both before and after leaving employment with
Zraytumbiax. There are also instances where the number of individuals being engaged by Zraytumbiax falls closer
to the EA threshold before being increased on the commencement of the following tax year on the resetting of the
EA.
216.


-----

(TC)

Ms Daca, Zraytumbiax's director, thought that after its customer, Keytemps, transferred the workers to Zraytumbiax,
to be registered, it was for Keytemps to distribute the workers to their own assignments and she did not know what
these would be. In evidence Ms Daca was unsure how much the workers would be paid other than to say:

“… it is about the national minimum wage in the UK”

She did not know that this could depend on the age of the worker concerned and explained that this was something
that her BPO would deal with, saying:

“…it's my back-office work.”

217.

Jazztify began to employ individuals from 30 December 2019 and had a total of 34 workers, 16 of whom
commenced after previous employment with another MUC. Nine workers who left Jazztify commenced immediately
with another MUC. Eight of these employees have had three consecutive engagements with MUCs with the other
workers having left to take up several different sources of employment, full-time, recruitment agency or retired.
218.

Jazztify Ltd claimed £3,000.00, £4,000.00 and £416.10 EA in relation to the tax years 2019-20, 2020-21 and 202122 respectively. For 2019-20 Jazztify paid £658.27, for 2020-21 £95.19 and for 2021-22 it submitted RTI reports for
the periods ending 5 May 2022 and 5 June 2022 only. In May 2022 it claimed EA due of £416.10 and paid the
amount HMRC had calculated as becoming due. In June 2022 its eligibility to claim EA had been removed so
HMRC raised the full liability amount of £1,152.04. However, Jazztify paid £708.79 leaving £443.25 – the exact
amount of Secondary Class 1 National Insurance due for the same period.
219.

Between the period of 31 December 2019 and 20 February 2020 Jazztify engaged a total of 22 individuals. There
were no further engagements between then and 5 April 2020, the end of the tax year to which this relates. Of the 22
individuals, 11 had left prior to 5 April 2020, six within the tax period ended 5 February 2020, three within the tax
period ended 5 March 2020 and two within the tax period ended 5 April 2020. Many of these former employees had
previously been employed by MUCs, leaving them for employment by other MUCs before joining Jazztify on 30
December 2019 and were subsequently employed by different MUCs on leaving Jazztify's employment.
**PAYE Registration**
220.

Officer Copeland explained that a valid National Insurance number is required to enable a business to register for
PAYE online. As the directors of the MUCs were all Filipino nationals who did not have a UK National Insurance
number they were unable to apply online and it was necessary to apply for PAYE registration by telephone through
the HMRC's “Employers Helpline” (“EHL”). Because the MUCs register, through their respective BPOs, for PAYE by
telephone there is no requirement to submit any documents. As a result, there is no digital footprint for their
interactions with HMRC. However, Officer Copeland was advised by several EHL call handlers that there was a
distinct pattern to calls seeking PAYE registration for MUCs with the same individuals appearing to be calling day in
day out to register several companies at a time. The EHL call handlers identified the same people by accent, their
telephone manner and the same background noise. This was the case with all the Lead Appellants except
Rosscana where the person making the call had a northern English accent.
221.

Officer McKinnon explained that the EHL in HMRC's East Kilbride office, where she works, is contained within one
wing with all staff on the same floor. At 24 April 2023, when Officer McKinnon made her witness statement the
office was made up of 11 teams with each having about 10 advisors and one team leader. There is another EHL
office in Newcastle with similar if not higher numbers of advisors than at East Kilbride. Officer McKinnon said that
the EHL deals with processing Online Tax Registration Service forms. These include the online forms for PAYE
scheme registration, and “CIS Deduction suffered repayment claims”. It handles around 2,000-3,000 calls a day.
222


-----

(TC)

On 20 July 2021, Officer McKinnon answered a telephone call on the EHL which lasted for about 15 minutes. It was
a request to register four limited companies for a PAYE scheme. Although the caller was not identified Officer
McKinnon recalled the voice sounded “very similar” to other callers she had spoken to previously for similar
registration calls. At the time, as she had only worked on the helpline for a few months and did not have much
experience and the lines were busy, Officer McKinnon agreed to register two schemes rather than the four
requested. The first PAYE scheme was for Destruction Limited and the second was for Phyarreidon. The telephone
call in which Phyarreidon was registered for a PAYE scheme followed the following pattern, something of which the
EHL were aware in relation to all MUC registrations:

(1)   The caller would wish to register multiple companies, generally about five companies per call;

(2)   None of the company's directors would have a UK a National Insurance number;

(3)   The majority of the callers had a female sounding voice, similar sounding accents and the same tone
of voice and a similar way of speaking and there were frequently similar background noises;

(4)   When giving names of companies and directors they would give the names and immediately say
“allow me to spell it”.

(5)   If asked, in the majority of calls, the caller would say that they were the internal bookkeeper for all of
the companies that they were registering, even when the companies had different trading addresses;

(6)   If questioned, as to whether the caller was an internal as opposed to external bookkeeper they would
end the call; and

(7)   The call would also be ended by the caller if they were questioned about the information they
provided for companies.

223.

Due to the volume of such calls Officer McKinnon began to recognise voices, although if asked whether they had
called previously the caller would give a different name. Occasionally, due to the familiarity of the caller's voice,
Officer McKinnon would ask the caller if they had spoken to her before only to be told that they had not. Officer
McKinnon also noticed that the numbers the calls were coming from always began 033 which are UK numbers that
do require a specific location (a similar system is used by HMRC which has a number for one helpline although
advisors taking the calls may be based in different locations within the UK). In addition, Officer McKinnon described
how she would hear the same background noises. She said that if she took several of this type of call in a day, she
would hear exactly the same background noises such as dogs barking, what sounded like chickens (as though the
animal making the noise was nearby) or children playing at a time when children in the UK would be expected to be
in school. This led her to believe that the same people were calling more than once during the day.
224.

On 10 June 2021 Officer Mackay took a call on the EHL from an “internal bookkeeper” who wished to register three
companies for PAYE. As the caller had not indicated at the start of the call that the registrations were for nonresident limited company directors, Officer Mackay advised her to register via the online portal at Gov.uk. It was
only at this point that the caller indicated that all three company directors were non-residents and confirmed that
she was an employee of all three companies. Office Mackay recorded the details of these companies.

(1)   The first of the companies, Questions Limited, had a Filipino resident director and had its registered
office in Wolverhampton at an address which Officer Mackay recognised as having been used previously
to register other non-resident director companies;

(2)   The second company was Zraytumbiax, a Lead Appellant. The nature of its business was stated as
“Transport” with the first pay date of 7 June 2021. The director's name was given as Janylin Daca, again a
resident in the Philippines; and

(3)   The third company to be registered for PAYE was Lochich Limited. The nature of the business was
confirmed as “Construction” with no subcontractors being paid, only employees, with the first pay date


-----

(TC)

being 7 June 2021. As with the other companies the director was a Filipino national, Ms Daca the director
of Zraytumbiax.

**Promoters**
225.

Officer Copeland, who conducted investigations into five UK registered promoter companies, explained that these
act as a conduit between the recruitment agency and the MUCs offering the recruitment agency favourable terms
for outsourcing their workforce. This had the effect of increasing the amount of relief that could be claimed by the
MUCs as more workers outsourced resulted in more reliefs being claimed. Officer Copeland observed that
subsequent to its involvement with the MUC model there was not only a rapid increase in turnover by each of the
five companies but that there was also a relatively small difference between their inputs and outputs. Additionally,
he noticed that the due diligence provided to each of the companies was always in an identical format irrespective
of the MUC that it traded with.
226.

The five companies investigated by Officer Copeland were: Horizon Contracts Limited (“Horizon”), WK1 Limited
(“WK1”), Propaye Outsourcing Limited (“Propaye”), Hirepaye Limited (“Hirepaye”) and Orwell Solution Services
Limited (“Orwell”).
_Horizon_
227.

Horizon was incorporated on 4 September 2018. Its declared nature of activities at Companies House was “other
activities of employment placement agencies (SIC code 78109)”. The directors of Horizon, from incorporation, are
Gail Jayne Corrigan and Mark Donald Grierson. Horizon was the successor company of Impact Contracting
Solutions Limited (“Impact”), of which Ms Corrigan was also a director. It used approximately 80% of the MUCs
previously used by Impact. On 16 September 2019 HMRC issued Impact with a “Kittel” decision, amended on 23
December 2019, denying its right to deduct input tax on the basis that it knew or should have known that it
participated in transactions connected to the fraudulent evasion of VAT. Impact has appealed against that decision.
228.

Officer Copeland stated that Horizon did not appear to start trading until its 05/10 VAT period when it reported a
quarterly turnover of over £3 million. This increased to some £15 million for its 08/10 VAT period.
_WK1_
229.

WK1 was incorporated on 28 June 2017 as Essex IT Consulting Ltd with a declared nature of business at
Companies House as “other activities of employment placement agencies (SIC code 78109)”. On incorporation its
sole director and shareholder was Lee Sargeant. On 4 April 2019 the company changed its name to WK1 Ltd and a
few days later, on 9 April 2019 Chris Gilbert was appointed as a director alongside Lee Sargeant. Shortly after Mr
Gilbert's appointment as a director of WK1 it started to trade with MUCs in relation to the supply of labour.
230.

Its turnover for its 06/18 VAT period was £31,000, it fell to £18,000 in its 09/18 VAT period and to £20,000 in the
next, 12/18, VAT period. However, there were increases to £2.3 million, £6.6 million, £9.2 million and £11.6 million
in the VAT periods 03/19, 06/19, 09/19 and 12/19 respectively.
_Propaye_
231.

Propaye was incorporated on 24 November 2017. Its declared nature of business at Companies House was “other
business support service activities not elsewhere specified (SIC code 82990)”. Kenneth Alan Hastings was its sole
director and shareholder on incorporation. However, Mr Hastings ceased being a shareholder on 13 September
2018 and was replaced by Ten66 Holdings Limited (“Ten66”) the same day. Ten66 was incorporated on 8 August
2018 with a declared nature of business at Companies House being “activities of other holding companies not


-----

(TC)

elsewhere specified (SIC code 64209)”. Mr Hastings, who has attended “Director's Nights” in the Philippines, was
appointed as director of Ten66 and was the sole shareholder on its incorporation.
232.

Turnover in Propaye's first VAT accounting period, 02/18, was £4 million. Its turnover in the next period, 05/18,
increased to £10 million and increased again in its 08/18 VAT period to £12.5 million. The 11/18 VAT period saw a
further increase in turnover to £15 million.
_Hirepaye_
233.

Hirepaye was incorporated 30 January 2019. Its declared nature of business was “management consultancy
activities other than financial management (SIC code 70229)”. Its joint directors and shareholders from
incorporation were Jeremy Weaver and Steven Gerard Zahabm both of whom had previous employment
experience within companies familiar with supply chains and/or utilising MUCs.
234.

Hirepaye's first VAT return, for its accounting period 04/19, showed minimal trading. However, this increased each
subsequent accounting period. For 07/19 was £1.5 million, £4 million in 10/19 and over £9 million in 01/20.
_Orwell_
235.

Orwell was incorporated on 30 August 2019 as Orwell Bookkeeping Limited and changed its name to Orwell
Solution Services Limited on 6 May 2020. Its declared nature of business at Companies House is “other business
support service activities not elsewhere specified (SIC code 82990)”. Alistair Porter was the initial sole director and
shareholder on incorporation. Mr Porter resigned as director on 31 March 2020 and ceased to be a shareholder on
24 March 2020. Jessica Saunders was appointed as a director on 31 October 2019 and became a shareholder from
1 November 2019.
236.

HMRC received a VAT1 application from Orwell on 6 May 2020. It was registered for VAT with an effective date of
registration of 5 May 2020. Although the company does not appear to have traded during the period before its
change of name from Orwell Bookkeeping Limited or when Mr Porter was a director, following its VAT registration
its turnover was regularly over £1 million for each accounting period and there was very little difference between its
input and output tax. This was a pattern that Officer Copeland said he had seen “very often within the MUC model”.
Orwell ceased trading and an insolvency practitioner was appointed on 5 October 2021.
237.

A questionnaire completed by Orwell for HMRC on 20 April 2023 on behalf of Ms Saunders, after she had ceased
to be its director, included the following answers (a third column on the questionnaire “HMRC Comment” was blank
and has therefore not been reproduced below):

|HMRC questions|Client Comment|
|---|---|
|General Enquiries||
|1. …||
|2. In relation to Ms Saunders' role, can you advise me of the day-to-day functions Ms Saunders undertook?|Ms Saunders regularly checked the bank & profit & loss reports. She ensured all PAYE & VAT deadlines were met by corresponding with the bookkeepers BJC Financial Services Ltd. She completed due diligence checks on supplier companies via use of the Supplierland platform and associated communication portal.|
|…||
|4. You have advised that Ms Saunders heard that Supplierland was an excellent way of making new business connections,|Following a virtual meeting with Gail Corrigan of Central Outsource she was contacted by Sarah Kinrade. Ms|


-----

|(TC)|Col2|
|---|---|
|who did Ms Saunders hear about Supplierland from?|Saunders originally believed that Sarah Kinrade worked for Supplierland but now she thinks she works at Cora Management Limited. Sarah arranged for a training session via Zoom regarding use of the Supplierland platform for performing due diligence checks.|
|…||


**Other BusinessesCentral Outsource**
238.

Central Outsource, of which Gail Corrigan is the sole proprietor, supplies what are described as “outsourcing
services”. The application for VAT registration, which was made by Ms Corrigan, was received by HMRC on 5
February 2021. The VAT1 declared under “Other Business Involvement” that Ms Corrigan was involved with
Impacting (sic) Solutions Limited (of which she is a director) but did not declare that she was also a director of
Horizon.
239.

It would appear from the general email she sent on 28 April 2022 to interested parties, under the subject heading
“Seminar on industry updates & Cocktails” that Ms Corrigan had a co-ordinating role in relation to intermediaries.
The email states:

“Dear All,

I would like to invite you to a seminar that will be held by Central Outsource on behalf of all of the
intermediaries I am engaged with. The purpose of the seminar is to reiterate all pay models in the sector, how
to ensure that your supply chain is compliant and working in line with HMRC's guidelines.

HMRC are causing lots of disruption at the moment, and I think it would be a good idea for us discuss in an
open, informal session where you can all ask as many questions as you like. Depending on the interest, I may
invite industry contacts/experts that you may find useful for advice.

Since I am based in Manchester, and have agency clients spread all over the UK (as far down as Southampton
and as high up as Scotland) I would like to host this in Birmingham. Until I receive confirmation of any possible
interest from you, I can't confirm where this will be or the agenda but of course this would be offered nearer the
time.

…

I can confirm that nibbles and cocktails will follow for those that wish to stay afterwards …. ”

240.

On 11 November 2022, in response to a letter to her former accountants sent by Officer Copeland in relation to a
VAT enquiry, Alan Nolan of Aspire wrote to HMRC (Officer Copeland) stating that Aspire was acting for Ms
Corrigan. The letter explained that:

“Central Outsource is an independent professional services provider, acting as an intermediary between
temporary work agencies, umbrella type companies and other third parties.

The service provided by Central Outsource is designed to help clients manage or improve a specific area of
their business by referring and recommending suitable suppliers. Turnover is primarily derived by agreeing a
service rate which is calculated by reference to the size of the business and worker population. Referrals and
recommendations for professional services include.

  - Sales and marketing.

In oice Finance


-----

(TC)



  - Contract management.

  - Human Resources (including the promotion of well-being).

  - Commercial Risk Management.

  - Customer Relationship Management.”

241.

The letter continued:

“We are concerned that your enquiry could be mis-guided on the basis that you have an open VAT enquiry into
a company in which Ms Corrigan is a former director and one which has appointed a liquidator.

This company operated in in the temporary work sector supplying labour services. For the avoidance of doubt,
Central Outsource is not a labour services provider and, therefore, it remains unclear as to the reason behind
your enquiry. We very much doubt, given the circumstances, that this enquiry can be described as 'random'.

In this regard, it seems likely that your enquiry has been “led” by Ms Corrigan's former association(s). It would
be helpful, therefore, if you could explain the reason for your enquiry into a business which is in its infancy and
one which charges VAT at the standard rate and has minimal claims for input tax credits – as its turnover is
derived from referrals and recommendations.

Once we understand HMRC's rationale, we will be able to respond to your letter dated 15[th ]August 2022.

At this point, we wish to make it clear that we consider your request for the information to be unreasonable in
the circumstances and we will be proposing a small sample of invoices which should be sufficient to check the
taxpayers tax position.”

_ICM Outsourcing Limited_
242.

On 23 June 2022 Officers Knowles, Emms and Thomas Wright held a meeting, using Microsoft Teams, with
Jennifer Strzala the director of ICM Outsourcing Limited (“ICM”), a promoter company. The meeting, which was in
relation to MUC fraud, was also attended by Rhian Smith of Aspire, ICM's agent. Both Ms Strzala and Ms Smith
confirmed that they were aware of the MUC fraud model.
243.

Ms Strzala told the officers that ICM outsourced payroll to agencies and end users. She advised that a recruitment
agency would be approached by an end client seeking temporary staff. The recruitment agency then outsourced the
payroll through ICM and would contact ICM with hours worked for staff. ICM would then engage with their suppliers,
the MUCs, who in turn would pay the workers. In response to a question from Officer Knowles, who had seen the
companies' bank statements, Ms Strzala said the ICM banked with Trilogy and held no other bank accounts. She
said that Trilogy was used for convenience. In addition to sourcing their suppliers through Supplierland, ICM also
used Supplierland for due diligence and contact with the MUCs that provided it with a supply of labour. Due
diligence checks, which were updated “every couple of months” were through a checklist on Supplierland which
included identification checks. Ms Strzala was unable to recall who had recommended Supplierland to ICM or if a
fee was paid for its services or how much any such fee might have been.
244.

When asked by Office Knowles how was it decided which workers to place with a supplier (MUC), Ms Strzala said
that ICM tries to place relevant workers with relevant suppliers. She also said that it is the supplier, the MUC and
not ICM, that employs the workers.
_Synergy Choice Limited_
245.


-----

(TC)

Synergy Choice Limited (“Synergy”) is another promoter company. Its director Jennifer Pemberton was interviewed,
via Microsoft Teams, by Officers Knowles, Scott and Rebecca Snowdon on 7 June 2022. Hannah Sandford of
Aspire was also in attendance.
246.

Ms Pemberton explained that Synergy provides workers for agencies and that she carried out due diligence checks
on suppliers. She told the officers that she had trained as an engineer before teaching science for ten years.
However, after her second child was born, she decided not to return to teaching and became involved in the
business as she wanted to stay at home to fit in with childcare needs. Therefore, the company had been
established for her to be its director.
247.

Ms Pemberton undertook checks on the suppliers who provide the workers for agencies. She explained that
Synergy's customers are the recruitment agencies and its suppliers are MUCs. She said that the agencies do not
contact her directly and it was Gail Corrigan, who was introduced to her by a mutual contact, who contacted her. It
is, Ms Pemberton said, Ms Corrigan that introduces customers to Synergy. She advised that Supplierland is used to
find the contracts and once found she then carries out the due diligence checks and generally spent Tuesdays and
Fridays carrying out the checks and approximately one hour a day on the rest of the weekdays amounting to about
15/16 hours a week. Supplierland was also used as a means of contact with Synergy's suppliers and Ms
Pemberton said that she did not have any contact details of the directors of the MUCs. Ms Pemberton could not
remember how she became aware of Supplierland but assumed that it was through Gail Corrigan. She was also not
sure if Synergy paid Supplierland or if it had entered into a contract for its services and did not know where
Supplierland was based.
248.

When asked by Officer Scott about her involvement in negotiating contracts Ms Pemberton said that this was
something always done by Gail Corrigan, even in relation to a contract that had been signed by Ms Pemberton on
20 January 2022. She said that there was little contact with customers as Synergy had a contract with a call centre,
Cora Management, to deal with any customer queries and manage contact with the customers and that it was Gail
Corrigan who “set the company up and engages new customers”.
249.

In response to questions asked by Officer Scott about the FRS Ms Pemberton said she did not know what the FRS
was but that she was nevertheless confident in the advice she received when she was “approached” to start the
company. Ms Pemberton was unable to assist the officers in relation to expenses incurred by Synergy but
confirmed that she did not decide which workers were allocated to which agency.
250.

Having confirmed that a Bradley Carr was the accountant for Synergy, Ms Pemberton explained that she was no
longer personally involved with Synergy, although correspondence was still being sent to the registered business
address. She was of the view that the business was being closed down and was not aware that its turnover in the
last two years had been £61 million.
_LSPS_
251.

As we have previously noted, on 6 December 2022, Brian Taylor and Bruno Dunington of LSPS met with Officers
Knowles and Fletcher as part of HMRC's investigation into MUC fraud. LSPS also used Supplierland and the
officers were told that it had no choice as to the MUCs with which it engaged. This was, they explained, a decision
of Supplierland as all communication took place through that portal.
252.

Having confirmed that LSPS's suppliers provided labour, Officer Knowles asked why a minimum payment was
included in contracts between LSPS and its suppliers. Mr Dunington explained that this was due to the FRS and the
need for there to be an income amount to override the threshold to ensure profit Mr Taylor and Mr Dunington


-----

(TC)

confirmed that Supplierland had been introduced to them by a Stephen Lawrence of another company that used
MUCs. He had told them that Supplierland supplied MUCs in a compliant way.
253.

Other contacts of theirs linked to Supplierland included Jack Thomas and Alan Nolan. Mr Dunington confirmed that
LSPS paid Supplierland a licensing fee. He explained that Alan Nolan and Jack Thomas provided a model brief and
that LSPS had sought its own legal advice around this business model. Mr Dunington, who confirmed that it was a
commercial arrangement, said that it was cheaper for LSPS to use hundreds of MUCs rather than one supplier as:

“… it's a cheaper way for LSPS and their clients to make margins −−it saves money and reduces
administration.”

254.

Mr Dunington also stated that he does not “do due diligence checks” until trade has commenced with a supplier. He
also confirmed that Supplierland completes the due diligence checks on behalf of LSPS.
_Charon Solutions Limited_
255.

Charon Solutions Limited (“Charon”) also completed a questionnaire (similar to that completed by Orwell) on behalf
of its director, Lucy Booth. The material questions and answers are set out below (as with the Orwell questionnaire
the third column “HMRC Comment” was blank and has therefore not been reproduced below):

**HMRC questions** **Client Comment**

**Company Set Up & Director**
1. Describe the main business activity of Charon Solutions Ltd? Charon Solutions Ltd (“Charon”) is a contracting
intermediary company

a) What is the process by which labour is provided to your Agency clients will refer individual workers to Charon
clients? when they have identified a work opportunity for them

but do not want to engage the worker directly
themselves. Charon will outsource the engagement of
the worker to a further tier of intermediary supplier by
using the Supplierland platform. The chosen supplier
will engage the services of the individual worker and
provide [them] under terms of business to Charon
which, in turn, provides the under terms of business to
their agency client

b) … …

2. What is Lucy Booth's role within the business? Director and shareholder

a) What experience do they have within the recruitment sector? Previously worked at other companies involved in the
supply or procurement of temporary labour (FS
Commercial Limited, Impact Contracting Limited, Crown
Oil Limited).

b) How did you get involved in this business? I was presented with the opportunity to become director
of Charon by Gail Corrigan of Central Outsource Limited

c) … …

d) Does the director have any other employments/self- Charon ceased to trade in March 2022. Mrs Booth is
employment? currently employed as a student nurse

… …

h) Who is responsible for:
i. Sourcing customers Central Outsource

ii. Sourcing suppliers Via Supplierland portal

iii. Due diligence Director

iv. Who prepares and submits the VAT returns? Bookkeeper – BJC Financial Limited (“BJC”)

v. If not the director who?
vi Preparing and issuing invoices Outsourced to Grafit Solutions Limited

|HMRC questions|Client Comment|
|---|---|
|Company Set Up & Director||
|1. Describe the main business activity of Charon Solutions Ltd?|Charon Solutions Ltd (“Charon”) is a contracting intermediary company|
|a) What is the process by which labour is provided to your clients?|Agency clients will refer individual workers to Charon when they have identified a work opportunity for them but do not want to engage the worker directly themselves. Charon will outsource the engagement of the worker to a further tier of intermediary supplier by using the Supplierland platform. The chosen supplier will engage the services of the individual worker and provide [them] under terms of business to Charon which, in turn, provides the under terms of business to their agency client|
|b) …|…|
|2. What is Lucy Booth's role within the business?|Director and shareholder|
|a) What experience do they have within the recruitment sector?|Previously worked at other companies involved in the supply or procurement of temporary labour (FS Commercial Limited, Impact Contracting Limited, Crown Oil Limited).|
|b) How did you get involved in this business?|I was presented with the opportunity to become director of Charon by Gail Corrigan of Central Outsource Limited|
|c) …|…|
|d) Does the director have any other employments/self- employment?|Charon ceased to trade in March 2022. Mrs Booth is currently employed as a student nurse|
|…|…|
|h) Who is responsible for:||
|i. Sourcing customers|Central Outsource|
|ii. Sourcing suppliers|Via Supplierland portal|
|iii. Due diligence|Director|
|iv. Who prepares and submits the VAT returns?|Bookkeeper – BJC Financial Limited (“BJC”)|
|v. If not the director who?||


-----

|(TC)|Col2|
|---|---|
|vii. Controlling the bank account ie making payments etc.|BJC make payments from bank account on behalf of Charon and perform bank reconciliations as part of their remit as bookkeeper|
|…|…|
|6. You have sent in the bank statements for a Trilogy account.||
|a) …|…|
|b) Who are the authorised signatories on all bank accounts used in the business?|BJC has access to the account as part of the provision of its services. Mrs Booth is the signatory but has never accessed the bank account|
|…|…|
|General Due Diligence||
|31. Regarding your due diligence process:||
|a) Please provide an overview of your due diligence process.|New suppliers are subjected to an initial due diligence check which requires the supplier director to complete a questionnaire and provide prescribed documentation. Following engagement, supplier companies are subjected to a due diligence check up to 4 times per year. 10% of companies eligible for check will be selected at random. They will be required to complete a questionnaire and provide supporting documentation|
|b) What advice have you been provided regarding due diligence?|Mrs Booth attended a supply chain risk management training session run by Aspire Business Pship Limited. She had a Teams meeting with Sarah Kinrade at Ask HR Limited who provided information on how to conduct the due diligence checks|
|…|…|
|33. Please advise:||
|a) …||
|b) Do you complete a due diligence check after you have engaged a suppler?|The length of time taken to complete a due diligence check meant that it would usually not be completed until after a supply had commenced|
|…|…|


_Akin_
256.

Akin, a promoter company, made monthly VAT returns commencing in its 08/18 accounting period. During this time
it had a monthly turnover of approximately £5 million.
257.

An unannounced visit to Akin was made by Officers Knowles and Elliott on 21 June 2018. However, as its director,
Sarah Kinrade, was not available the officers met its bookkeeper, Bradley Carr, who was then working for a
different company, Cavalera. Ms Kinrade was, in addition to being director of Akin, an employee of Cavalera. Mr
Carr told the officers that Akin's business records were not available and notwithstanding correspondence between
HMRC and Aspire, Akin's representatives, these records were never produced to HMRC.
258.

On 21 March 2023 HMRC issued a decision denying Akin recovery of input tax on a Kittel basis, ie Akin knew or
should have known that its transactions were connected to the fraudulent evasion of tax. A VAT assessment was
[also issued in the total sum of £15,233,542.00. A penalty under s 69C of the Value Added Tax Act 1994 (“VATA”)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5R2C-H3J1-DYCN-C1HK-00000-00&context=1519360)
was also issued to the company by HMRC.
HMRC Investigation
259.


-----

(TC)

HMRC's investigation into the MUC scheme, “Operation Bakewell”, commenced in December 2020 and remains
ongoing. It was under the auspices of Operation Bakewell that HMRC conducted the interviews with nominee
directors and made visits to the virtual offices we have described above.
260.

In the absence of any information being provided to HMRC in relation to the business model/scheme, Officer Price
began tracking MUCs in 2019. Whilst completing a piece of work on non-resident directors he identified large
numbers of Filipino directors of companies with the same UK Registered Offices. His FIS colleagues advised that
these directors/companies were of interest in relation to their enquiries into what appeared to be abuses of the EA
and FRS. Officer Price therefore offered his assistance in identifying these companies and has been doing so,
passing on the information he has obtained to his colleagues since June 2019, on a monthly basis.
261.

MUCs that were of interest to the FIS enquiries shared common attributes such as their location, postcodes,
naming pattern and ownership. The companies concerned tended to move their registered office after incorporation
and are frequently located at addresses in groups of 30 or more companies. There are also similarities in the
company names, which Officer Price considered showed evidence of a naming strategy. The names chosen could
be UK placenames (eg Abergwili Ltd, Badshot Lea Ltd), fixed patterns (same number of name parts differing by the
change of a single part and pseudo-names (company names mimicking people's names eg AL Benson Ltd, AW
Christie Ltd). Also, the directors and persons with significant control for these companies, as identified by
Companies House, had originally been UK nationals and residents who subsequently resigned and were replaced
as directors and shareholders by individual Filipino nationals resident in the Philippines.
262.

Applying such criteria to the Companies House data, Officer Price produced a list of 42,678 companies which he
matched against HMRC's RTI system to find the PAYE references and identify the software used to submit the RTI
returns. Officer Price also matched them to HMRC's Corporation Tax (“COTAX”) System to identify the first
registered office on incorporation to compare against the current registered office and used this information to
create a list which showed that the 42,678 companies were located at 203 different addresses.
263.

The data gathered by Officer Price was passed to Officer Copeland on a monthly basis to progress HMRC's
investigation. Officer Copeland reviewed each of the postcodes and examined the data to ascertain whether the
MUCs had any other common traits such as the use of the same software, whether they were incorporated using
the same SIC codes and whether they were based at the same address. Any companies within the same postcode
but which did not match the other criteria would be removed from Officer Copeland's enquiries leaving him with a
list of 64 companies which he believed to be MUCs involved within the scheme.
264.

Officer Copeland explained that his main focus was on the company's registered office address, its status (whether
it was active/dissolved/liquidated), the current VAT number, the current VAT address, the current FRS indicator, the
current FRS registration date, the VAT outputs to date, the VAT Output tax to date, the de-registration date, the
PAYE reference and the amount of EA claimed on an annual basis for the period from 2015 to 2022 (inclusive). No
further action would be taken if the company was liquidated or dissolved or had no active registrations in relation to
VAT and PAYE.
265.

Using the VAT data provided, Officer Copeland drew conclusions based on the registration and use of the FRS. If
the companies were not shown as being authorised for the FRS Officer Copeland undertook a calculation based on
the company's VAT Outputs and VAT Output Tax to ascertain the percentage of VAT being declared to HMRC. If
this was in line with the FRS percentage rate the company would remain in HMRC's active list but would be
eliminated as not being a MUC. This exercise resulted in two lists, the first where the FRS was used with


-----

(TC)

authorisation and the second where FRS had been used even though the company had not been authorised to do
so.
266.

Officer Copeland also undertook further checks based on the PAYE history of the companies. Those that had been
registered for PAYE and claimed the maximum amount of EA for four consecutive years would be eliminated from
the investigation. This was because, at that time, HMRC did not consider that MUCs would have traded for more
than two to three tax years and would not have been expected to reach the maximum EA for each year of trade.
267.

Having analysed the data in relation to the MUCs, Officer Copeland concluded that, without the EA and VAT FRS
reliefs, all these companies would be trading at a loss, and even with those reliefs they make very little profit. The
money gained by reason of the reliefs appears to benefit other associated companies in fees etc. This is apparent
from the bank accounts which show payments being made to, amongst others, Verity, Dragon Perks, Angstrom,
Veritek, and Xelarus.
268.

The work of Officer Copeland was confirmed by Officer Wright who explained how the data obtained was used. He
also explained the workings of HMRC's Web Portal and how, when a taxpayer wants to register with HMRC for
online access to a tax service or services, he or she is required to set up a Government Gateway account as part of
the registration process. In this process an applicant is allocated a Government Gateway ID number and chooses a
password. At this stage the user has to input a name and e-mail address which is used by Government Gateway.
As part of this process HMRC asks several questions to check the identity of the user. When a user creates an
account on the HMRC web portal they are identified by a unique alphanumeric string that is referred to as their
Government Gateway ID. Within HMRC systems each Government Gateway account is also assigned a unique
number which is also used to represent the customer's account. This is known as the UserID. Tax identifiers such
as a PAYE Reference or an Agent Code can be associated to a UserID.
269.

There are three types of account: Individual, Organisation and Agent accounts.
270.

Individual and Organisation accounts can only be enrolled for a single tax number for each of the services.
Additional security in the form of 2-step verification was added to the online accounts relating to individuals and
businesses by HMRC in 2017. Access to HMRC's online services via these accounts is recorded as a series of
events by HMRC systems. These events include metadata about the interaction along with what the taxpayer
viewed or changed. Each event will contain the customer's Internet Protocol (“IP”) address. IP addresses are
numerical labels assigned to devices connected to a network using the Internet Protocol. All computers directly
connected to the internet will have a unique IP address so that any data sent or received by that address can be
routed to it. The IP(V4) address takes the form of four sets of numbers, with each number ranging from 000 to 255,
for example, 213.205.227.90.
271.

The taxpayer's IP address recorded by HMRC is often referred to as the external IP address, as opposed to an
internal IP address such as exists in a private home, with several computers, mobile phones and many other
devices connected to the internet via a modem or router that is itself connected to the internet and acting as a
gateway for all those devices which are allocated special internal IP addresses (which are not available or usable
as external IP addresses on the internet).
272.

When any data is sent to or from the internet the gateway handles the translation of the addresses between the
internal network and the internet, known as Network Address Translation (NAT). Business networks, university
networks and mobile phone networks also use the same NAT on a larger scale, again using gateways.
273


-----

(TC)

IP addresses can be static or dynamic. Static IP addresses remain unchanged over time providing the customer
maintains an account with the ISP. Businesses often utilise static IP addresses to make it easier to offer facilities
like remote login. Dynamic IP addresses change over time, the rate of change is highly dependent on the ISP
issuing the IP address. Using publicly available data it is possible to identify the ISP responsible for a particular IP
address.
274.

Officer Wright also referred to HTTP cookies (which are also known as web cookies, browser cookies and
commonly just cookies), which are part of the standards by which web servers and web browsers work. 'These are
a small piece of information that a web server asks a user or client to store on their computer, either temporarily or
permanently, to enable the webserver to identify a device and link events together. He explained that there are
several types of cookie, of which “session” and “persistent” cookies are used on the HMRC web site.
275.

A session is the term used to record all of the events from the point a user logs into the HMRC website to the point
they leave. The session cookie is a token used to link these events together and to the user. It is a unique token
generated by the HMRC servers and issued to the device used to login. The token, ie the “cookie”, is stored on the
device's memory and is sent and stored as part of every subsequent event (ie access by a taxpayer to his or her
account). However, the session cookie is removed from the device once the user logs out or after a period of
inactivity. On the next login a new session cookie is issued. Using this session cookie, it is therefore possible to link
together all the events connected to someone's session even if their IP address changes.
276.

Persistent cookies are similar in function to session cookies but are stored permanently on a user's device. The first
time a device is used to login to the HMRC website a persistent cookie is generated by the HMRC servers and
stored by the web browser on the device. Each time that device and browser are subsequently used to login to the
HMRC website each event is tagged with this cookie value. It is therefore possible for HMRC to attribute different
sessions to a device and browser even if different HMRC accounts are being accessed and the IP address
changes. As these persistent cookies are stored on a user's device it is possible to recover them during a forensic
examination. However, it is possible for users to delete persistent cookies from their device from within the browser,
or to prevent them being stored using private browsing modes.
277.

Officer Wright has had access to a number of HMRC systems that store data in relation to taxpayers' interactions
with HMRC online services which, from 1 January 2018, he was able to search and download the relevant data
from, from which he created and produced 32 spreadsheets analysing the data identifying online contact between
HMRC, the Lead Appellants and other MUCs.
278.

He identified the successful web-based accesses recorded on the HMRC system by the Lead Appellants and
considered these in relation to their applications for VAT registration, PAYE and other submissions in relation to
VAT. He also identified additional registrations using the same name and national insurance number as used by the
Lead Appellants and, using the cookies, identified additional registrations applied for using the same device finding
that there were 17 persistent cookies used in the registration of 28,493 companies. Officer Wright passed the
spreadsheets he had created and information he had found to Officer Price for analysis.
279.

Having analysed the material gathered, on 30 April 2021 HMRC issued some 22,000 letters to MUCs (including
Jazztify and Rosscana) to de-register them from VAT, remove them from the FRS and EA and issue assessments
for under-declared output tax (the difference between VAT paid at the claimed FRS rate and standard rate, ie 20%).
Thousands of similar letters (de-registration from VAT, removal from FRS and EA and assessments) were issued
by HMRC (including to Elphysic, Phyarreidon and paid Zraytumbiax) on 31 January 2022.
280.


-----

(TC)

Officer Harker explained that he not attempted to contact the directors of the MUCs, including those of the Lead
Appellants. His experience when seeking to contact directors of MUCs in other cases on which he had been
working had been unsuccessful. He explained:

“Well, unfortunately, you know, as I say, we opened up 20 enquiries and failed to get a single response.”

281.

HMRC's letters had been signed by Officer Harker as the “decision maker”. He explained that although the
decisions to remove the EA had been made by Officer Copeland he was, “the decision maker” insofar as his name
went on the decision letter. This was, he agreed, because it had been decided that one letter signed by a single
officer (Officer Harker) should be sent for everything rather than separate letters sent regarding de-registration,
removal of FRS and EA and assessments.
_LAWVAT Deregistration_
282.

Section 3(1) VATA provides that a person:

“… is a taxable person for the purposes of this Act while he is, or is required to be, registered under this Act.”

283.

Section 4(2) VATA defines a taxable supply as a supply of goods or services made in the UK other than an exempt
supply.
284.

Paragraph 1 of schedule 1 to VATA provides that a person whose taxable supplies exceed the VAT threshold
becomes liable to be registered for VAT. Under paragraph 9 of that schedule where a person requests to be
registered for VAT and satisfies HMRC that he makes or intends to make taxable supplies in “the course or
furtherance” of a business, HMRC “shall if he so requests” register him with effect from the date on which the
request was made or such earlier date as he may agree with HMRC.
285.

Provision for the cancellation of VAT registration is contained in paragraph 13 of schedule 1 to VATA, the material
parts of which provide:

(1)…

(2) Subject to sub-paragraph (5) below, where the Commissioners are satisfied that a registered person has
ceased to be registerable, they may cancel his registration with effect from the day on which he so ceased or
from such later date as may be agreed between them and him.

…

(5) The Commissioners shall not under sub-paragraph (2) above cancel a person's registration with effect from
any time unless they are satisfied that it is not a time when that person would be subject to a requirement, or
entitled, to be registered under this Act.

286.

In Ablessio the CJEU stated:

“28. … Member States have a legitimate interest in taking appropriate steps to protect their financial interests,
and the prevention of evasion, avoidance and abuse is an objective recognised and encouraged by Directive
2006/112 [sc. the Principal VAT Directive] (see, in particular, Case C-255/02 _Halifax and Others [2006] ECR I-_
1609, paragraph 71; Case C-285/09R. [2010] ECR I-12605, paragraph 36; and Case C-525/11 _Mednis [2012]_
ECR, paragraph 31.”

287.


-----

(TC)

At [30] the Court in Ablessio recognised that Member States can “legitimately take measures that are necessary to
prevent misuse of [VAT] identification numbers” provided that the measures “must not go beyond what is necessary
for the correct collection of the tax and the prevention of evasion, and they must not systematically undermine the
right to deduct VAT, and hence the neutrality of that tax”. It continued:

“34. … sound evidence giving objective grounds for considering that it is probable that the VAT identification
number assigned to that taxable person will be used fraudulently. Such a decision must be based on an overall
assessment of all the circumstances of the case and of the evidence gathered when checking the information
provided by the undertaking concerned …

…

38. It is for the referring court to examine whether, having regard to all the circumstances of the case, the tax
authority has established to the requisite legal standard the existence of sound evidence from which it may be
concluded that the application for registration in the register of taxable persons subject to VAT by Ablessio
might result in the misuse of the identification number or other VAT fraud.

39 … where the tax authority concerned has not established, on the basis of objective factors, that there is
sound evidence leading to the suspicion that the VAT identification number assigned will be used fraudulently.
It is for the referring court to assess whether that tax authority provided sound evidence of the existence of a
risk of tax evasion in the case in the main proceedings.”

288.

In _Proxemor Trade SRL v_ _Direcţia_ _Generală a_ _Finanţelor Publice Cluj –_ _Administra￿ia_ _Jude￿eană a_ _Finanţelor_
_Publice Bihor Case C-358/20 EU:C:2021:936, the CJEU referred to Ablessio, at [41], stating:_

“… although Member States have a certain discretion when they adopt measures to ensure the identification of
taxable persons for the purposes of VAT, that discretion cannot be unrestricted, so that a Member State cannot
refuse to assign an individual number to a taxable person without legitimate grounds (see, to that effect,
judgment of 14 March 2013, _Ablessio,_ _C-527/11, EU:C:2013:168, paragraphs 22 and 23). In particular,_
although Member States have a legitimate interest in taking appropriate steps to protect their financial interests
and that the prevention of tax evasion, avoidance and abuse, and although they can legitimately take
measures, in accordance with the first paragraph of Article 273 of the VAT Directive, that are necessary to
prevent the misuse of identification numbers, in particular by undertakings whose activity, and consequently
their status as taxable persons, is purely fictitious, those measures must not go beyond what is necessary for
the correct collection of the tax and the prevention of evasion, and they must not systematically undermine the
right to deduct VAT, and hence the neutrality of that tax (see, to that effect, judgment of 14 March 2013,
_Ablessio, C 527/11,EU:C:2013:168, paragraphs 28 and 30).”_

289.

The principles enunciated by the CJEU in _Ablessio_ were also considered by the Upper Tribunal in _Impact_
_Contracting Solutions Limited v HMRC [2023] UKUT 99215 (“Impact UT”), albeit in relation to a denial of input tax,_
_Kittel, decision by HMRC. The Court of Appeal has granted Impact permission to appeal against the Upper_
Tribunal's decision on the basis that it erred in holding that the _Ablessio_ principle permits the deregistration of a
taxable person who has not himself fraudulently evaded VAT nor had the intention to do so (but who knew or
should have known that he was facilitating the VAT fraud of another). The Court of Appeal is due to hear Impact's
appeal by 27 January 2025.
290.

It is common ground that the Tribunal has a full appellate jurisdiction in relation to VAT deregistration (see
_Manhattan Systems Ltd v HMRC_ _[[2017] UKFTT 862 (TC) at [45]) and that it is for HMRC to establish, to the civil](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R55-G9J1-F102-045Y-00000-00&context=1519360)_
standard of proof, that the VAT numbers concerned were being, or would be used as part of a VAT fraud.
VAT Flat Rate Scheme (FRS)
291


-----

(TC)

The FRS, a VAT scheme for small undertakings, is authorised under Article 281 of the Principal VAT Directive
(“PVD”) which provides:

**Simplified procedures for charging and collection Article 281**

Member States which might encounter difficulties in applying the normal VAT arrangements to small
enterprises, by reason of the activities or structure of such enterprises, may, subject to such conditions and
limits as they may set, and after consulting the VAT Committee, apply simplified procedures, such as flat-rate
schemes, for charging and collecting VAT provided that they do not lead to a reduction thereof.

292.

Article 281 PVD was brought into effect in the UK by s 26B VATA.
293.

Under the FRS, rather than record the output VAT on sales and input VAT on purchases to determine the VAT due
to HMRC, a taxable (ie a VAT registered) person may, if (and only if) authorised to do so by HMRC under regulation
55B of the 1995 Regulations, elect to calculate their VAT liability by applying an “appropriate percentage”
(dependent upon the trade sector of the business) to their “relevant turnover”.
294.

A person's “relevant turnover” is defined by s 26B(2)(c) VATA, as the total of the value of their taxable and exempt
supplies “together with the VAT chargeable on them”, ie their gross turnover.
295.

The “appropriate percentage” is determined by reference to the category of business carried on as stated in the
table of categories of businesses and appropriate percentages contained in Regulation 55K of the 1995
Regulations.
296.

Regulation 55KA makes provision for “limited cost traders”.
297.

Regulation 55JB makes provision for a reduced flat rate percentage rate in the taxable person's first year of
operation.
298.

Regulation 55L(1) of the 1995 Regulations provides:

A taxable person shall be eligible to be authorised to account for VAT in accordance with the scheme at any
time if—

(a) there are reasonable grounds for believing that—

(i) the value of taxable supplies to be made by him in the period of one year then beginning will not exceed
£150,000

(b) he—

(i) is not a tour operator,

(ii) is not required to carry out adjustments in relation to a capital item under Part XV, or

(iii) does not intend to opt to account for the VAT chargeable on a supply made by him by reference to the
profit margin on the supply, in accordance with the provisions of any Order made under section 50A of the Act,

(c) he has not, in the period of one year preceding that time—


-----

(TC)

(i) been convicted of any offence in connection with VAT,

(ii) made any payment to compound proceedings in respect of VAT under _[section 152 of the Customs and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y087-00000-00&context=1519360)_
Excise Management Act 1979,

(iii) been assessed to a penalty under section 60 of the Act, or

(iv) ceased to operate the scheme, and

(d) he is not, and has not been within the past 24 months—

(i) eligible to be registered for VAT in the name of a group under section 43A of the Act,

(ii) registered for VAT in the name of a division under section 46(1) of the Act, or

(iii) associated with another person.

299.

Under Regulation 55M(1)(f) of the 1995 Regulations a flat-rate trader ceases to be eligible if he is “associated with
another person”.
300.

Regulation 55Q(1)(b) provides that a flat-rate trader ceases to be authorised to account for VAT under the FRS at
the date he became associated with another person.
301.

Regulation 55A(2) of the 1995 Regulations provide that a person is “associated with another person” at any time if:

… that other person makes supplies in the course or furtherance of a business carried on by him, and—

(a) the business of one is under the dominant influence of the other, or

(b) the persons are closely bound to one another by financial, economic and organisational links.

302.

HMRC may refuse to authorise a person to use the FRS, under Regulation 55B(3):

… if they consider it is necessary for the protection of the revenue that he is not so authorised.

303.

HMRC may also terminate the authorisation of a person's use of the FRS under Regulation 55P of the 1995
Regulations if they consider it “necessary for the protection of the revenue” or if “a false statement” was made by
that person or on his behalf in relation to his application for authorisation.
304.

Section 73 VATA provides HMRC with a power to assess a taxable person to VAT where it appears that the
person's VAT returns are inaccurate.
305.

The right of appeal against a withdrawal of FRS authorisation is provided by s 83(1)(fza) VATA. By s 84(4ZA) VATA
such an appeal (and an appeal against any VAT assessments consequent upon it) shall be allowed if the Tribunal
considers that HMRC could not reasonably have been satisfied that there were grounds for the decision.
306.


-----

(TC)

It would appear to be common ground that the Tribunal's jurisdiction in an FRS authorisation appeal is materially
similar to the _Gora_ approach applied in excise approval appeals (see _Gora v C&E Commissioners_ _[[2003] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N13H-00000-00&context=1519360)_
_[Civ 525; [2004] QB 93; Corbelli (t/a Corbelli Wines) v HMRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N13H-00000-00&context=1519360)_ _[[2017] UKFTT 615 (TC) at [310]-[312]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PCC-HH11-F102-00R1-00000-00&context=1519360)_
307.

Such an approach requires the Tribunal to determine what facts existed at the date of the decision (ie facts and
matters that have arisen since the decision are not relevant at this stage of the enquiry, save to the extent that they
might explain facts and matters that did exist), and then to determine whether, in light of those facts, HMRC's
decision was one that could or could not reasonably have been reached. If, applying this approach, the decision
was not reasonably arrived at the appeal should be allowed unless the Tribunal is satisfied that, despite the errors,
the same result is inevitable (see John Dee Ltd v C&E Commissioners _[[1995] STC 941 and Corbelli at [313]-[319]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4D2W-3NY0-TWP1-S1KC-00000-00&context=1519360)_
308.

It is for an appellant to establish that the decision to remove him or her from the FRS and that any assessment
consequent upon it was unreasonable in the _Wednesbury_ sense, ie taking into account irrelevant considerations,
failing to take into account relevant considerations, otherwise reaching a decision which no reasonable body of
commissioners could have reached, or making an error of law.
Employment Allowance (EA)
309.

[Provision for the EA is made by s 1 of the National Insurance Contributions Act 2014 (“NICA”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5BS9-9K21-DYCN-C401-00000-00&context=1519360)
310.

Section 4 NICA provides for an employer that qualifies for the EA to receive it by making a deduction from NIC
payments that it would otherwise be liable to pay. Accordingly, the effect of the EA is a reduction in a qualifying
employer's NIC liability up to the maximum yearly amount.
311.

Section 2 NICA provides, so far as relevant for present purposes:

…

(10) A person cannot qualify for an employment allowance for a tax year if, apart from this subsection, the
person would qualify in consequence of avoidance arrangements.

(11) …

(12) In subsections (10) and (11) “avoidance arrangements” means arrangements the main purpose, or one of
the main purposes, of which is to secure that a person benefits, or benefits further, from the application of the
employment allowance provisions.

(13) In subsection (12) “arrangements” includes any agreement, understanding, scheme, transaction or series
of transactions (whether or not legally enforceable).

312.

It is common ground that the burden is on HMRC to establish that the person qualified for the EA in consequence of
an avoidance arrangement.
313.

_[Section 11 of the Social Security Contributions (Transfer of Functions, etc.) Act 1999 the “Transfer Act”) provides a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y08F-00000-00&context=1519360)_
right of appeal against “any decision of an officer of the Board under section 8”.
314.


-----

(TC)

Section 8 of the Transfer Act includes “whether a person is or was entitled to make a deduction under section 4 of

[NICA]” (see section 8(1)(ea)). Section 12 of the Transfer Act provides that regulations may be made with respect to
appeals to the Tribunal made under section 11 of the Transfer Act.
315.

Regulation 10 of the Social Security Contributions (Decisions and Appeals) Regulations 1999 provides:

If, on an appeal under Part II of the Transfer Act or Part III of the Transfer Order that is notified to the tribunal, it
appears to the tribunal that the decision should be varied in a particular manner, the decision shall be varied in
that manner, but otherwise shall stand good.

_DISCUSSION_
316.

HMRC contend that the Lead Appellants were part of “an organised and contrived structure with the purpose of
defrauding the Revenue by claiming tax benefits (the FRS and EA) to which they were not entitled” and, as the
Lead Appellants' VAT numbers were being used as part of that VAT fraud, were properly de-registered for VAT
under Ablessio. HMRC also contend that the removal from the FRS of the Lead Appellants for the protection of the
revenue was a decision that was reasonably reached and that the assessments were correctly made on the Lead
Appellants as a result of the removal from the FRS. Additionally it is contended that the removal of the entitlement
to the EA was as a result of avoidance arrangements in that the main purpose, or one of the main purposes, of the
MUC scheme was to secure a benefit to the MUCs from the EA provisions.
317.

The Lead Appellants accept that the MUC business model does indeed involve a degree of organisation as
between the various participants for which, in the interests of speed and efficiency, there was a substantial degree
of automation. However, Mr Margolin submits that, as HMRC have neither pleaded the allegations of fraud with
sufficient particularity nor established that the VAT numbers of the Lead Appellants were being used for fraud, the
_Ablessio test is not satisfied. He also submits that the decisions to remove the Lead Appellants from the FRS and_
the backdating of that removal to the dates when they commenced trading were decisions that were unreasonable.
He says that in reaching those decisions HMRC took into account irrelevant factors and ignored relevant factors.
Against that background he submits the VAT assessments issued on the basis of those flawed decisions cannot
stand. Mr Margolin also contends that HMRC have not established that the entitlement to EA was in consequence
of avoidance arrangements.
318.

It is common ground that the burden of proof is on HMRC in relation to the VAT de registration issue. In relation to
the FRS and VAT assessments the burden is on the Lead Appellants to show that the decision to remove them
from the FRS was unreasonable. However, the burden is on HMRC to establish that the Lead Appellants qualified
for the EA in consequence of an avoidance arrangement. It is also common ground that no allegation of fraud or
dishonesty is made against the directors of the Lead Appellants of whom, it is accepted, that they neither knew nor
should have known of any alleged fraud.
319.

Although, in the absence of agreement, the parties produced separate lists of issues, we consider that the following
issues arise:

(1)   Whether HMRC's allegations of fraud have been properly pleaded;

(2)   The Ablessio Issue:

(a)   whether the VAT registrations of the Lead Appellants were used or likely to be used for
fraudulent purposes; and if so


-----

(TC)

(b)   whether, for them to liable to be de-registered for VAT pursuant to the CJEU decision in
_Ablessio, the directors knew or should have known of the existence of any fraud;_

(3)   Whether HMRC's decision to remove the Lead Appellants from the FRS was reasonable and if so
whether the Lead Appellants are liable to HMRC for the assessed VAT.

(4)   Whether HMRC established that the Lead Appellants qualified for EA in consequence of an
“avoidance arrangement”.

Pleading
320.

It is not disputed, that, as Saville LJ (as he then was) observed in British Airways Pension Trustees Limited v Sir
_[Robert McAlpine & Sons Limited (1994) 45 Con LR 1 at 4:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57VD-2P41-DYBP-T4NK-00000-00&context=1519360)_

“The basic purpose of pleadings is to enable the opposing party to know what case is being made in sufficient
detail to enable that party properly to prepare to answer it.”

321.

The following relevant principles governing pleading dishonesty were summarised by Arnold LJ (with whom David
Richards and Patten LJJ agreed) at [23] in Sofer v Swissindependent Trustees SA _[2020] EWCA Civ 699:_

“… There was little dispute as to these before either the Judge or us. They were summarised, in my judgment
accurately, by counsel for the Claimant as follows:

i) Fraud or dishonesty must be specifically alleged and sufficiently particularised, and will not be sufficiently
particularised if the facts alleged are consistent with innocence: Three Rivers District Council v Governor _and_
_Company of the Bank of England (No.3) [2003] 2 AC 1._

ii) Dishonesty can be inferred from primary facts, provided that those primary facts are themselves pleaded.
There must be some fact which tilts the balance and justifies an inference of dishonesty, and this fact must be
pleaded: Three Rivers at [186] (Lord Millett).

iii) The claimant does not have to plead primary facts which are only consistent with dishonesty. The correct
test is whether or not, on the basis of the primary facts pleaded, an inference of dishonesty is more likely than
one of innocence or negligence: _JSC Bank of Moscow v Kekhman [2015] EWHC 3073 (Comm) at [20]-[23]_
(Flaux J, as he then was).

iv) Particulars of dishonesty must be read as a whole and in context: Walker _v Stones [2001] QB 902 at 944B_
(Sir Christopher Slade).

322.

He continued, at [24]:

“To these principles there should be added the following general points about particulars:

i) The purpose of giving particulars is to allow the defendant to know the case he has to meet: Three Rivers at

[185]-[186]; McPhilemy v Times _Newspapers Ltd_ _[[1999] 3 All ER 775 at 793B (Lord Woolf MR).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61MS-00000-00&context=1519360)_

ii) When giving particulars, no more than a concise statement of the facts relied upon is required: McPhilemy
at 793B.

iii) Unless there is some obvious purpose to be served by fighting over the precise terms of a pleading,
contests over their terms are to be discouraged: McPhilemy at 793D.

323.


-----

(TC)

In _MRH Solicitors Limited v The County Court sitting at Manchester_ _[2015] EWHC 1795 (Admin) the Divisional_
Court (Burnett LJ, as he then was and Nicol J) considered the position where allegations of fraud were made
against someone who is not a party to the proceedings.
324.

Nicol J, giving the judgment of the court, having noted, at [32], that there was “no doubt” that the Recorder was
finding that MRH had been fraudulent and dishonest, continued:

“34. We well understand how the Recorder's suspicions were aroused. However, in the absence of good
reason a Judge ought to be extremely cautious before making conclusive findings of fraud unless the person
concerned has at least had the opportunity to give evidence to rebut the allegations. This is a matter of
elementary fairness. …

35. This is not only required because of fairness to the party affected but also to avoid the Court falling into
error – see for instance Co-operative Group (CWS) Ltd v International Computers _[[2003] EWCA Civ 1955 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFX1-DYBP-P513-00000-00&context=1519360)_

[38]. As Megarry J memorably said in John v Rees [1970] CH 345, 402,

“As everybody who has anything to do with the law well knows, the path of the law is strewn with examples of
open and shut cases which, somehow, were not; of unanswerable charges which, in the event, were answered;
of inexplicable conduct, which was fully explained…Nor are those with any knowledge of human nature who
pause to think for a moment likely to underestimate the feelings of resentment of those who find that a decision
against them has been made without their being afforded any opportunity to influence the course of events”.

He continued:

37. Mr Knowles [for MRH Solicitors] also drew attention to the principle of pleading, namely, that allegations of
fraud or dishonesty must be made clearly and with proper particulars. He argued that, absent a pleading of
dishonesty by MRH, the Recorder was simply disentitled to investigate the matter at all. So far as this was an
argument independent of fairness, we have some doubts as to its merit. After all, the purpose of the rules of
pleading is so that the parties know the issues on which they must adduce evidence. It is the parties to the
litigation who may have a legitimate grievance if the Court travels beyond the pleadings in making its orders or
in reaching its findings of fact. In this case that would be Mr Yousaf or Mr Ahmed, but neither of them has
appealed against the decision of the Recorder, perhaps because they considered that, even setting aside what
the Recorder had to say about MRH, his dismissal of their claims was unassailable.

38. Mr Knowles accepted that the Recorder would have been entitled (if he thought the evidence called for it) to
voice his suspicions or concerns as to the conduct of MRH, but noting that he had not heard anyone from MRH
give evidence. … What Mr Knowles submitted he should not have done in fairness to MRH was to make
positive and unqualified findings that the solicitors had been fraudulent and dishonest.

39. We agree.”

325.

In HMRC v Katib _[2019] UKUT 189 (TC) the Upper Tribunal (Mann J and Judge Richards, as he then was) having_
rejected an argument advanced by HMRC, relying on the above passage ([34] – [38]) of _MRH Solicitors_ that the
First-tier Tribunal (“FTT”) was not entitled to make findings of fraud against a non-party who had not been given a
chance to explain himself in the proceedings, said (with emphasis as in the decision):

“In our view, however, the High Court in MRH Solicitors was not setting out a general rule that findings of fraud
could never be made against non-parties to the litigation without a court first hearing from those parties.
Rather, the High Court was simply emphasising the considerations that a court should have in mind before
making findings against such persons and the importance of considerations of natural justice. Paragraph [24] of
the judgment emphasises that the correct course of action where fraud is alleged against a non-party will
depend on the facts of the individual case:


-----

(TC)

'24. In the unlikely event that something similar to this should happen in the future, in our view the right course
would be for the third party who believes they have been unfairly criticised in a judgment to apply to be joined
as a party. We emphasise that we are not saying that a third party who is criticised will necessarily be entitled
to be joined as a party. There are many cases heard in the civil courts (and also family and criminal courts)
where the conduct of an absent person falls to be considered. For example, in a conspiracy case not all the
alleged conspirators may be before the court as parties or witnesses. In complex commercial frauds it may well
be part of the case that an absent person or institution was party to dishonest conduct somewhere in the chain.
Everything will depend on the facts of the individual case.'”

326.

The Upper Tribunal, at [40], considered that, in the circumstances of the case, the FTT was “fully entitled” to make
findings of fraud against the non-party whose conduct had been put “squarely in issue” by Mr Katib in his witness
statement. This gave HMRC adequate notice of the allegations made against the non-party and the relevance of
those allegations to Mr Katib's appeal. The Upper Tribunal noted that the facts in Katib were, therefore, “in marked
contrast” to those in MRH Solicitors where no fraud against the solicitors had been pleaded.
327.

In the present case Mr Puzey accepts that if HMRC made allegations of fraud against the directors of the Lead
Appellants they would clearly have been entitled to a fully particularised allegation of the nature of their fraudulent
conduct. However, although no such allegations are made against those particular individuals, Mr Puzey contends
that it is plain from the outset that it is a case of fraud as is clear form paragraph 1 of the Statement of Case
(“SOC”) which states:

“The Appellants in this litigation are participants in an organised and contrived structure with the purpose of
defrauding the Revenue by claiming tax benefits to which they were not entitled. These tax benefits include
registration for VAT, the use of the VAT Flat Rate Scheme (FRS), and the use of the Employment Allowance
(EA). The Respondents estimate the tax lost from the scheme as a whole to be over £260 million.

328.

As Mr Margolin reminded us, there is nothing inherently fraudulent in a business model or structure being
“organised” or “contrived”. However, paragraph 1 of the SOC also clearly asserts that, in addition to being
“contrived”, the MUC business model or structure, the MUC scheme, was also fraudulent and had a dishonest
purpose, ie the claiming of tax benefits to which the MUCs were not entitled.
329.

The SOC also included the following matters of what HMRC contend was a fraudulent scheme:

(1)   The MUC scheme involved the disaggregation of labour supplies into a network of thousands of
interconnected MUCs, each employing a small number of workers (SOC paragraph 13);

(2)   The MUCs are not independent (SOC paragraph 14);

(3)   The MUCs are controlled externally (SOC paragraph 14);

(4)   The initial directors of the MUCs acted on the instructions of those involved in managing the scheme
(SOC paragraph 14);

(5)   The initial officers of the MUCs are directors in name only (SOC paragraph 15);

(6)   The replacement directors of the MUCs, based in the Philippines, are recruited by Compass Star
which is integral to the MUC scheme (SOC paragraph 20);

(7)   Compass Star advertises for those willing to be appointed directors of MUCs to carry out tasks that
are allocated by Compass Star (SOC paragraph 22);

(8)   Compass Star advertises the roles and offers payment to the Filipino directors, and offers payments
for referrals of additional 'directors' (SOC paragraph 23);


-----

(TC)

(9)   The Filipino directors are directors in name only, making no investment into the MUCs nor exercising
any practical control over the MUCs (SOC paragraph 28);

(10)   The MUC Scheme depends on the tax advantages obtained from the misuse of tax reliefs (SOC
paragraph 31);

(11)   The supply chains for the labour are provided by the online platform Supplierland, operated by Mr
Funtanilla, the director of Compass Star (SOC paragraph 36);

(12)   Compass Star has a significant degree of control in the running of the MUCs (SOC paragraph 37);

(13)   The MUCs are not independent entities but operate under the same overall control and for the
benefit of others (SOC paragraph 38);

(14)   Control over the MUCs was exercised by the organisers/facilitators of the MUC Scheme (SOC
paragraph 40); and

(15)   The MUC Scheme would have been unworkable if the organisers/facilitators did not exercise
dominant influence over the MUCs (SOC paragraph 41).

330.

Mr Puzey further contends that the clarity of HMRC's pleaded case is reinforced by paragraphs 111 – 120 of the
SOC which state:

“THE OPERATION OF THE MUCS – AN OVERALL SCHEME TO DEFRAUD THE REVENUE

111. The Respondents assert that the MUCs were set up and controlled by the Scheme organisers as part of
an orchestrated overall scheme to defraud the Revenue whether or not the directors of the MUCs themselves
were aware of that fact.

112. All of the MUCs were set up and registered for EA, VAT and the FRS pursuant to that scheme. The
MUCs' VAT/FRS applications contained representations that were untrue and calculated to mislead as to the
trade class/business activity to be undertaken. None revealed that they were labour suppliers, each claiming to
be in a different trade classification. This was done with the intention of inducing the Respondents to permit the
MUCs to be authorised under the FRS. Once that was granted the MUCs started to make supplies of labour
thus enabling the Scheme as a whole to benefit from the tax advantage conferred by the FRS.

113. The UK directors had no control over the companies. They were simply fronts for those behind the
scheme whether they were aware of that or not.

114. After registration, the directorships were all changed to nationals of the Philippines who likewise had no
control of the day-to-day operation of the MUCs and were directors in name only. They were paid a fixed fee
for basic administrative functions and had no real role in operating those businesses.

115. The Respondents assert that none of the deregistered MUCs were eligible to use the FRS at all because
they were associated with other persons in the manner alleged above. The essence of the FRS is that those
using it are not supposed to be connected with other businesses (to prevent what are in reality single taxpayers
disaggregating themselves to take advantage of the lower accounting rate available on the FRS). Here
however, the Respondents assert that the MUCs were all connected to intermediaries who, themselves were
participating in the Scheme. The MUCs were not free to contract with any customer but rather it was arranged
for them that they would only be making supplies to the chosen intermediaries. Indeed, that is how the entire
massive fraudulent enterprise was set up and managed from the outset.

116. The fact that the MUCs VAT registrations were obtained and utilised to serve the purposes of the fraud
justifies the decisions of the Respondents to remove the VAT registrations of those companies pursuant to the
_Ablessio_ Judgment. That was a lawful and necessary response to a contrived and well organised effort to
defraud the Revenue.


-----

(TC)

117. The MUCs in general and the Appellants in particular entered into the arrangements described above
which gave rise to the claims for Employment Allowance. The main purpose, or one of the main purposes of
those arrangements [was] to secure that those companies benefitted from the application of the EA provision.
Accordingly, they were properly denied the right to claim employment allowance.

118. It is not credible that the above circumstances could occur independently in so many thousands of cases.
These companies are clearly connected or closely associated, and were set up and registered for VAT, FRS,
and EA with the intention of misusing VAT registration and claiming the benefits of the FRS and EA when not
entitled to do so.

119. The grounds of appeal provide formulaic and bare denials of the existence of a Scheme, and the
Appellants' participation therein. The Grounds of Appeal do not seek to explain or justify the extraordinary
coincidence that 18,000 labour supply businesses could be formed in the UK in the space of a year or two
without any investment by the directors and then have the directorships switched to the Philippines; nor that
they should all be operated in the same controlled manner by third parties; nor that they do not retain the
income they receive but rather pay it away in fees and charges to the entities who organise, facilitate and
operate the Scheme. Given that the Appellants were, when the Appeals were submitted, being represented by
Mr Nolan's business, Aspire Business Partnership, that representative had full visibility of the Scheme as a
whole and yet the Grounds of Appeal do not engage with the reasons given in the appealed Decisions.

120. The reality of this MUC scheme is that it involved a web of companies which were intended to operate to
further the unlawful purposes of the over arching Scheme. They were not in control of their own affairs, and
each of them failed to disclose the reality of their existence, which was that they were all part of one contrived
and fraudulent scheme under common control. They existed in order to fraudulently abuse the VAT system, (in
particular, the FRS) and the EA whether the directors were aware of that or not. The Respondents have
properly deregistered the MUCs and assessed for arrears of VAT and National Insurance.”

331.

Although there was not any application by the Lead Appellants for further and better particulars of the SOC or for
the SOC or any part of it be struck out, Mr Margolin contends that the SOC fails to give any adequate or sufficient
particulars of the acts or omissions that are said to constitute the alleged fraud, who undertook dishonest acts and
the basis on which any relevant acts or knowledge is to be attributed to the Lead Appellants. We agree with him
that it should not be for the Lead Appellants or the Tribunal to wade through the SOC seeking to ascertain whether
an act or omission is relied upon as a basis for the allegation of fraud. Additionally, we note that neither the words
“dishonest” nor “dishonestly” appears anywhere in the SOC.
332.

That said, the SOC does contain references to certain individuals such as Mr Funtanilla being the director of
Compass Star (which had a significant degree of control in the running of the MUCs) and other individuals who, like
Mr Funtanilla, attended hospitality events such as “Director's Nights” in the Philippines and are alleged to be “key
players”, promotors, “closely linked” to Compass Star and “central to the MUC model”. However, as Officer Knowles
accepted, there are no specific allegations particularised in the SOC that any individual or corporate entity is
dishonest or has knowingly committed fraudulent acts.
333.

As such, although we do not consider that the SOC contains the particularisation necessary to enable us to identify
the fraudster or fraudsters behind the MUC scheme, we do consider that it does just enough to make it clear to the
Lead Appellants that HMRC's case, the case they have to meet, is that the MUC scheme as whole was and is itself
fraudulent. We also consider that the Lead Appellants were aware of the case they had to meet and that this is
clear by the evidence served by them on 3 August 2023, in particular that of Mr Funtanilla who, as Mr Puzey put it,
was, “at pains to address and dispute the allegation that the MUC scheme was dishonest”.
334.


-----

(TC)

As such, it is necessary to consider whether the MUC scheme involved the fraudulent use of the Lead Appellants'
VAT numbers and whether they were properly de-registered for VAT by HMRC pursuant to the decision of the
CJEU in Ablessio.
**Ablessio Issue**
335.

There are two elements to this issue. The first, whether the VAT registrations of the Lead Appellants were used or
likely to be used for fraudulent purposes; and the second that, if the VAT registrations were used or likely to be
used for fraudulent purposes, whether it is necessary for the directors of the Lead Appellants to have known or that
they should have known of the existence of the fraud for the MUCs to be liable to be de-registered for VAT.
_Fraudulent Purposes_
336.

The _Ablessio_ principle, as Mr Margolin referred to it, by which a taxable person can be de-registered for VAT
applies when there is sound evidence giving objective grounds for considering that it is probable that the VAT
number of a taxable person has been or will be used for fraudulent purposes (see Ablessio at [34]). It is therefore
necessary to consider whether the VAT numbers of the Lead Appellants were used for fraudulent purposes.
337.

HMRC allege that the fraudulent use of the Lead Appellants' VAT numbers was the exploitation of the FRS and EA
as a result of the contrived disaggregation of the supplies of labour and that this was fraudulent because the
organisers of the scheme sought to create the false impression that the MUCs were independent, each being
directed by their own director for their own benefit, whereas the reality was that those MUCs were simply pawns
being controlled for the purposes of the scheme.
338.

Mr Puzey contends that, although those operating the MUC Scheme went to great lengths to create the illusion that
the MUCs were independent from one another and free from any dominant influence, that was not the case. He
refers to, amongst other matters, the MUCs being registered in nominee names then quickly transferred out of the
jurisdiction; the maintenance of a network of virtual offices in the UK; the recruitment of the replacement directors,
the Filipino nationals based in the Philippines, by Compass Star; the tasks undertaken by those Filipino directors
allocated by Compass Star and the lack of any investment and/or practical control by those directors over “their”
companies.
339.

We agree that the evidence before us leads to an inevitable conclusion as to the lack of any independence or
control by the directors of the Lead Appellants of “their” MUCs who, as alleged in the SOC are “directors in name
only” and approve whatever is asked of them by the organisers of the fraud who clearly have a dominant influence
over them.
340.

By way of example, we refer to the applications for VAT registration that were made in name of a nominee director
without their knowledge after the date of their resignation and subsequent to the appointment of a Filipino national
as director. There is also the role played by Compass Star which was involved in the recruitment, selection and
payment of the Filipino directors in addition to making “recommendations”, which the directors always accepted
because they “trusted” Compass Star despite having very little (of no more than a day at most) if any previous
knowledge of its existence.
341.

The lack of independence by MUC directors and the lack of control of the companies of which they are directors is
apparent from as early in the process as the Facebook advertisements used for recruitment purposes. These
include, as part of the necessary requirements for appointment, a “cell phone” number, access to the internet in
addition to a requirement that a potential director:


-----

(TC)

“Must be able to personally carry out the Directors tasks from the Compass Star Web Portal”

That same advertisement made it clear that those directors' “tasks” were simply to “review and sign business
documents” created by “their” company BPO through the use of the Compass Star Portal.
342.

Similarly, a Facebook post, which we have set out above, describes the work of the directors as being to authorise:

“… documents like company schedule, company purchases, receipt and so on …”.

The communications from Compass Star, such as those set out above, which were received by Ms Gonzalo of
Phyarreidon, referred to her “duties” being to “approve” certain documents such as VAT returns and PAYE returns.
There was no evidence of any the directors of Lead Appellants exercising any judgment of their own by not
approving any such document.
343.

Additionally, there was no evidence of any of the directors doing anything other than that recommended by their
BPOs or selecting any services from Supplierland other than those already in the prepopulated basket as
recommended by Compass Star. There was also the unquestioning use of Supplierland to obtain due diligence and
using it to obtain customers that the directors of the Lead Appellants accepted without question and without
obtaining or requiring any further information about the business or operation of the customer concerned.
344.

Further evidence, if it were needed, of the Lead Appellants not being controlled by their directors but under the
dominant influence of others is in relation to the income they received, none of which came from the company of
which they were director. Rather they were paid by Compass Star at the times stated and, in the amounts, (ie PHP
10,000) as advertised, irrespective of the profits or otherwise of the Lead Appellants and, contrary to the Opinion of
Mr Goodfellow QC, this was clearly not a decision of the director concerned.
345.

Finally, in this regard, we refer to the term of the Verity/Angstrom Service Agreement under which “as the authority
dealing with the company administration” the Service Provider could “initiate proceedings to remove a director who
“fails to meet the obligations required of him”. In our judgment such a clause is clear evidence of the
director/shareholder being subject to the control of others. Although we agree with Mr Margolin that control is not
synonymous with fraud, it is clear that, without the tax advantages obtained by the FRS and EA the MUCs were
unable to make a profit, something that Mr Southern QC warned in his Opinion would undermine “their commercial
credibility”.
346.

Therefore, having regard to all of the circumstances, the organisers of the MUC scheme must have known that the
Lead Appellants were not entitled to use the FRS as a result of their association with the organisers and being
closely bound to one another by financial, economic and organisational links and only entitled to claim EA in
consequence of avoidance arrangements. Nevertheless, applications for the FRS and EA were made not only
knowing that was the case but also disguising the fact from HMRC by creating the false impression of the MUCs
being independent entities when that was clearly not the case.
347.

As such, we consider that there is sound evidence giving objective grounds for concluding that the VAT numbers of
the Lead Appellants were used for fraudulent purposes and, subject to whether their directors knew or should have
known that this was the case (which we consider next) we find, applying Ablessio, that the Lead Appellants were
liable to be de registered for VAT.
_Knowledge_
348.


-----

(TC)

Mr Puzey, who accepted that the directors of the Lead Appellants were neither fraudulent themselves nor knew or
should have known of any fraud, submits that the application of Ablessio cannot be avoided by the interposition of
an innocent “patsy” into a wholly contrived scheme, such as that in the present case, where the MUCs, under the
control of others (as opposed to their directors), were the means of committing the fraud. That would, he contends,
undermine the general principle of preventing abusive practices.
349.

However, such an argument was rejected by Judge Geraint Williams in the FTT in _Impact Contract Solutions_
_Limited v HMRC_ _[2022] UKFTT 47 (TC) (“Impact FTT”). Having agreed with counsel for HMRC, at [95], that the_
decision in Ablessio supports the conclusion “that those who are positively assisting/facilitating the fraudsters in a
VAT fraud are treated as participants and denied the right to deduct input tax is equally applicable to de-register a
taxable person who is using their VAT registration abusively to facilitate VAT fraud”, Judge Williams continued:

“96. Mr Watkinson [counsel for HMRC] submitted that simple facilitation would be sufficient for the application
of the Ablessio principle and would accord with the extant CJEU jurisprudence of furthering the purpose of the
broad anti-abuse/evasion principle in _Halifax. A simple facilitation test would not establish a system of strict_
liability as _Ablessio_ requires that there be sound evidence giving objective grounds for considering that it is
probable that the VAT registration will be used to facilitate or had been used to facilitate fraud. Mr Brown

[counsel for the appellant] submitted that simple facilitation without more was not sufficient reason to deregister a taxpayer. He submitted, there was a clear analogy between de-registering a taxable person and it
losing its right to claim input tax. In respect of the latter, refusing that right without there being a requirement to
prove that the taxable person knew or should have known, would establish a system of strict liability for
deregistration and go beyond what is necessary to protect the public exchequer, (Bonik at [41] and [42]).

97. In _Bonik_ the CJEU considered the denial of the right of deduction where the taxpayer did not know and
could not have known that it was participating in a transaction connected with fraud and rejected the denial by
the Bulgarian tax authorities on the basis that it would go beyond what is necessary to protect the exchequer.
The CJEU confirmed, by reference to _Kittel_ and other established EU case law, that denial of the right of
deduction required it to be established on the basis of objective grounds that the taxable person has actual or
implied knowledge that it was participating in a transaction connected with fraud otherwise a system of strict
liability would be established and go beyond what is necessary to preserve the exchequer's rights.

98. I agree with Mr Brown that simple participation without more would not be sufficient to de-register a taxable
person when applying the Ablessio principle. In Bonik, the CJEU restated that denial of the right of deduction
required it to be established on the basis of objective grounds that the taxable person has actual or implied
knowledge that it was participating in a transaction connected with fraud otherwise a system of strict liability
would be established and go beyond what is necessary to preserve the exchequer's rights. The test of “simple
facilitation” proposed by Mr Watkinson [counsel for HMRC] for de-registering a taxable person would mean that
HMRC would only have to establish a connection between the taxable person and the party committing the
VAT fraud for the taxable person to be de-registered, that proposition was rejected by the Court in Bonik.

350.

Impact appealed against the decision of Judge Williams in Impact FTT to the Upper Tribunal (Edwin Johnson J and
Judge Thomas Scott) (see Impact UT) where it was noted, at [3], that:

“… The First-tier Tribunal (Tax Chamber) (the “FTT”) directed that there be a hearing to determine various
preliminary issues in relation to that appeal. Those preliminary issues were as follows:

Question 1

Does the principle in Ablessio apply only to a party that has itself fraudulently defaulted on its VAT obligations,
or does it similarly apply to a party who has facilitated the VAT fraud of another party?

Question 2


-----

(TC)

If the principle in Ablessio does apply to a party who has facilitated the VAT fraud of another party, is simple
facilitation sufficient, or must it additionally be proved that:

(a) the facilitating party was itself dishonest; or

(b) the facilitating party knew that it was facilitating the fraud, and/or

(c) the facilitating party should have known that it was facilitating the fraud?

4. The FTT concluded as follows in relation to these two questions, as set out at [106]-[108] of its decision:

Question 1

106. The principle in Ablessio applies both to a party that has fraudulently defaulted on its VAT obligations and
to a party who has facilitated the VAT fraud of another party.

Question 2

107. Simple facilitation by a party of the VAT fraud of another is not sufficient to apply the principle in Ablessio.

108. It is not necessary to prove that the facilitating party was itself dishonest. It must, however, be proved that
the facilitating party knew or should have known that it was facilitating the VAT fraud of another party.

351.

At [100] the Upper Tribunal concluded that the principle in Ablessio applies:

“(a) to the deregistration for VAT purposes by HMRC of a person as well as to a refusal by HMRC to register a
person.

(b) to enable the deregistration of a person for VAT purposes who has facilitated the VAT fraud of another,
where the person to be de-registered **knew or should have known** that it was facilitating the VAT fraud of
another [emphasis added].

(c) notwithstanding that the person whom HMRC seek to de-register has at the relevant time or times also
made taxable supplies unconnected with such facilitation of fraud and which would result in a liability to be
[registered under paragraph 1(1) Schedule 1 VATA 1994.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4J0-TWPY-Y0K0-00000-00&context=1519360)

352.

Mr Puzey contends that, as it was their VAT numbers that were being misused, the Lead Appellants were not
engaged in “simple facilitation” but the commission, as an integral part of the fraud, of the abuse of the VAT system
and that the resulting loss of tax was attributable directly to the Lead Appellants as opposed to another person at a
point downstream, as in _Ablessio._ As such, he submits, the application of _Ablessio_ does not depend on the
knowledge of the Lead Appellants of somebody else's fraud.
353.

However, in view of Lewison LJ's observation in Volpi (see above), we do not consider it appropriate to pick over or
construe the phrase “simple facilitation”, as used by the FTT or Upper Tribunal in Impact, as if it were contained in
“a piece of legislation or a contract”, or subject it to a “narrow textual analysis”. Rather, it seems to us that the
phrase merely describes there being, as in the present case, a connection between a taxable person and the party
committing the VAT fraud and it is that connection which (simply) enables (facilitates) the commission of that VAT
fraud. Accordingly, we agree with Mr Margolin who, relying on the observations of both the Upper Tribunal and FTT
in Impact, contends that any argument advanced by HMRC on the basis of Ablessio cannot succeed in the absence
of any knowledge by the directors of the Lead Appellants that they were facilitating (enabling) the fraud of another,
ie the organisers of that fraud.
354.


-----

(TC)

It is quite possible that we would have reached a different conclusion if it had been pleaded and put to the directors
of the Lead Appellants in cross examination that, having regard to all of the circumstances, particularly in the light of
how they were appointed, their limited duties and responsibilities, their lack of any real decision making and their
receipt of payments from Compass Star rather than the companies of which they were directors, they had either
known or should have known of the fraud,.
FRS
355.

HMRC made the decision to terminate the Lead Appellants' use of the FRS, under Regulation 55P of the 1995
Regulations having considered it necessary for the protection of the revenue to do so. The assessments, made
under s 73 VATA, to recover VAT which HMRC contend was underdeclared by the use of the FRS were
consequent upon that decision. The issue that therefore arises is whether HMRC's decision to withdraw the use of
the FRS and issue assessments was reasonable (see s 84(4ZA) VATA).
356.

In Mark Saggers Media Limited v HMRC _[[2013] UKFTT 421 (TC) the FTT (Judge Brannan and Ms Bridge), having](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5970-X6F1-F102-00N2-00000-00&context=1519360)_
referred to s 84(4ZA) VATA, noted:

“55 … it is important to note the limitations on the jurisdiction of this Tribunal in an appeal of this type.

56. Section 84 (4ZA) _[VATA 1994 provides that we can only interfere with HMRC's decision if the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1H8-00000-00&context=1519360)_
Commissioners could not reasonably have been satisfied that there were grounds for the decision. It is not a
question whether we agree with HMRC's decision or whether we would have reached the same decision if we
had been in their shoes. The question for us is whether HMRC's decision was unreasonable.

57. In this context, unreasonableness means a decision which HMRC reached either failing to take account of
all relevant facts and circumstances or taking account of irrelevant facts and circumstances. A decision will also
be unreasonable if it was one which no body of Commissioners acting reasonably could have reached or if the
Commissioners made an error of law in reaching their decision.

357.

It is common ground that it is for the Lead Appellants to establish that the FRS decision of HMRC was
unreasonable. Mr Margolin contends that in reaching the FRS decision HMRC took into account irrelevant factors.
358.

The first of these “irrelevant” factors on which he relies is that the Lead Appellants were part of a fraud. However,
having concluded, for the reasons above, that the Lead Appellants were indeed, albeit unbeknown to their directors,
participants in a fraud we do not agree with Mr Margolin that this is an irrelevant consideration. Similarly, we do not
agree with him that it was an irrelevant factor that the Lead Appellants had provided misleading information in their
applications for VAT registration albeit this did include a matter subsequently corrected in evidence by Officer
Harker. Also, having found that the Lead Appellants were not independent entities but under the control or
“dominant influence” of others, the scheme organisers, we do not agree with Mr Margolin that HMRC were
unreasonable to take into account their association with others within the meaning of Regulations 55L and 55A(2) of
the 1995 Regulations.
359.

As for HMRC failing to take into account the views of the directors of the Lead Appellants, their role in operating
those companies and the fact that the MUC model had been the subject of positive professional compliance advice
from respected specialist leading counsel, which Mr Margolin contends are relevant mattersto which HMRC ought
to have taken account, we agree with Mr Puzey that it was not unreasonable for HMRC not to have done so.
360.

This is because if HMRC had tried to seek the views of the directors of the MUCs prior to issuing the many
thousands of decision letters removing their authorisation to use the FRS on 30 April 2021 and 31 January 2022


-----

(TC)

there is no guarantee that the Lead Appellants would have been amongst those whose MUCs had been selected.
Moreover, given Officer Harker's experience when he attempted to contact directors of MUCs in other cases on
which he was working, we do not consider it unreasonable for him to reach a decision on the FRS without obtaining
such views. We have already referred to the very limited role the directors had in the operation of the Lead
Appellants, contrary to and inconsistent with counsel's advice and do not consider the professional advice in
relation to the viability of the MUC scheme to be a factor HMRC ought to have taken into account. Moreover, it
would not have been possible for HMRC to have taken account of counsel's advice. Mr Goodfellow KC's Opinion
had not been disclosed until December 2023 and the advice of Mr Kamal and Mr Southern KC was disclosed on 2
January 2024 as an exhibit to Ms McLauglin's second witness statement in an application for its admission into
evidence.
361.

Accordingly, we find that HMRC's decision to terminate the Lead Appellants' use of the FRS, having considered it
necessary for the protection of the revenue, was reasonable as were the assessments issued in consequence of
that decision. However, even if that were not the case, having concluded that the Lead Appellants were associated
with another person and therefore ineligible for the FRS, we consider that it was inevitable that HMRC would have
come to the same conclusion (see John Dee Limited v C&E Commissioners).
EA
362.

The definitions of “avoidance arrangements” and “arrangements” in s 2(13) and (14) NICA are, in our judgment,
sufficiently broad to encompass the MUC scheme.
363.

Given our conclusion that HMRC have established that the MUC scheme as a whole was fraudulent, it must follow
that the Lead Appellants were only entitled to qualify for EA “in consequence of avoidance arrangements”.
Therefore, under s 2(10) NICA the Lead Appellants “cannot qualify” for EA and their appeals against HMRC's
decisions that they were not entitled to the EA cannot succeed.
_DECISION_
364.

For the reasons above, the Lead Appellants' appeals have succeeded in relation to the Ablessio issue. However,
we have also concluded that they were not permitted to account for VAT under the FRS or entitled to the EA.
Accordingly, we allow the appeals in part.
_RIGHT TO APPLY FOR PERMISSION TO APPEAL_
365.

This document contains full findings of fact and reasons for the decision. Any party dissatisfied with this decision
has a right to apply for permission to appeal against it pursuant to Rule 39 of the Tribunal Procedure (First-tier
Tribunal) (Tax Chamber) Rules 2009. The application must be received by this Tribunal not later than 56 days after
this decision is sent to that party. The parties are referred to “Guidance to accompany a Decision from the First tier
Tribunal (Tax Chamber)” which accompanies and forms part of this decision notice.

**End of Document**


-----

