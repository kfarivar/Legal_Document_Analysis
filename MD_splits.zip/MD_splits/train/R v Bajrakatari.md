# R v Bajrakatari

_[[2023] EWCA Crim 1117](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69C5-DK73-RS5N-C1RB-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 31/08/2023**

# Catchwords & Digest

**CRIMINAL LAW - APPEAL – APPEAL AGAINST SENTENCE**

The Court of Appeal, Criminal Division, granted the applicant’s application for an extension of time to leave
to appeal against sentence and his leave to appeal against his conviction from a decision of the single judge which
had refused it. The applicant pleaded guilty to being concerned in the production of cannabis. He was sentenced to
16 months’ imprisonment. He made an application for leave to appeal against conviction, on the ground that the
[possibility of a defence under s 45 of the Modern Slavery Act 2015 had not been properly investigated. The court](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
held, among other things, that it granted the necessary extension of time. The court also granted leave to appeal
against sentence and quashed the sentence of 16 months’ imprisonment imposed by the judge. The court imposed
in its place a sentence of nine months’ imprisonment. It had not been suggested that that should be suspended,
and, in any case, the applicant had now served the custodial element of that sentence.  The ancillary orders made
by the judge were not affected. The prison authorities would need to check whether there was any constraint on
the applicant’s immediate release due to immigration considerations in view of the fact that he was not legally in the
country, and it was likely that he would be deported.

**End of Document**


-----

