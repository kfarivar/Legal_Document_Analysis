# R v Spence [2022] EWCA Crim 1623

Court of Appeal, Criminal Division

Dingemans LJ, Pepperall J, HHJ Menary KC

30 November 2022Judgment

MR A SELBY KC appeared on behalf of the Applicant

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

LORD JUSTICE DINGEMANS:

**Introduction**

1. This is the hearing of a renewed application for leave to appeal against sentence by Alize Spence after
refusal by the single judge. The two main grounds of appeal are: first, that insufficient regard was given to

Mr Spence's age of 16, in that he was given the same sentence as his co‑defendant Mr Gordon‑Carew

who was 18 and therefore two years older than Mr Spence; and secondly, that insufficient weight was
given to a determination by the Single Competent Authority ("SCA") that Mr Spence was a victim of modern
day slavery; which meant that the sentence was manifestly excessive.

2. Mr Spence was born on 7 May 2003. As of 1 January 2020, which was the date of the murder, he was

aged 16 years and six months. On 24 February 2022, when he was 18 years, after a 48‑day trial, Mr

Spence was convicted of the murder of Mr Bill Henham which took place on 1 January 2020. Mr Spence

was convicted with co‑defendants Gregory Hawley, Dushane Meikle and Lamech Gordon‑Carew. On 20

May 2022, when he was 19 years old, Mr Spence was sentenced to be detained at His Majesty's Pleasure
with a minimum term of 18 years less days spent on remand. Mr Hawley was sentenced to imprisonment
for life with a minimum term of 25 years less days spent on remand. Mr Meikle was sentenced to

imprisonment for life with a minimum term of 25 years, less days spent on remand. Mr Gordon‑Carew was

sentenced to custody for life with a minimum term of 18 years, less days spent on remand.

**The factual background**

3. Mr Bill Henham was 24 years old and was, as the judge recorded, adored by parents, brother and wider
family On 1 January 2020 he had been celebrating New Year's Eve in Brighton when he came across a


-----

party taking place in a squat in a derelict office which was where Mr Spence lived. He turned up at around
4.30 in the morning. Mr Hawley, then 26 years old, was the lead squatter. Mr Spence, then 16 years old

and Mr Gordon‑Carew, then 18 years old, were staying there temporarily having travelled to Brighton

together from London to sell drugs.

4. Mr Spence was born in Croydon in 2003 and had five siblings. He had been involved with Children's
Services all of his life. At 13 he was sent by his mother to live with his father in bed and breakfast
accommodation provided by Croydon Council. His father used cannabis. At the age of 16 Mr Spence was
placed on a child protection register because of his association with county lines, being exploited and what
were described as multiple episodes of being missing without parental support or boundaries. Mr Spence
left his father's accommodation in December 2019 when he was aged 16. He then moved to Brighton
which was where he was on 1 January 2020, living in a squat and selling drugs.

5. Mr Gordon‑Carew, it is necessary to give a bit of detail about his life given the argument in relation to

disparity on sentence, also came from the Croydon area. His father was a drug dealer and had died

violently when Mr Gordon‑Carew was 11. Mr Gordon‑Carew had a difficult relationship with his mother and

was effectively homeless at the time of the offending. Mr Gordon‑Carew was assessed as having a

learning disability and a very low IQ. He had had a troubled school career and was diagnosed with ADHD
which made him impulsive. He also suffered epilepsy. The judge had seen him give evidence with the
benefit of an intermediary.

6. Mr Meikle, then 25 years old, was known in the Brighton homeless community and was acting as
informal security at the party.

7. For reasons that are known only to the defendants but which were thought likely to have been some
kind of trivial perceived sleight, the four defendants took Mr Henham to a room on the second floor where
he was beaten savagely. According to forensic evidence the primary attackers at that stage were Mr

Spence and Mr Gordon‑Carew who the judge concluded were acting on the instruction of Mr Hawley and

Mr Meikle. They hit and kicked Mr Henham in the head and body, they dragged him down to a small floor

on the first floor where the attack continued. While other party‑goers guarded the door on the instruction of

Mr Hawley and Mr Meikle, Mr Henham was kicked with shod feet and beaten with wooden banister
supports which had been torn from the staircase.

8. Mr Henham lost consciousness about an hour before he died. He sustained a total of 80 injuries to his
face, torso and legs, including 11 fractured ribs, a large forehead cut and severe brain injuries. At the
conclusion of the attack the defendants carried him to a balcony surrounding an internal courtyard and
tipped him into the recess. At this point the medical evidence suggested that he may still have been alive.
The defendants removed his clothing and wiped his body down with disinfectant, as well as trying to
disinfect the scene. Mr Meikle took photographs of Mr Henham's naked body and then all four left the

scene. Police found the body after receiving a tip‑off some 36 hours later.

**The sentence**

9. When sentencing, the judge identified numerous aggravating factors including an attack on a
defenceless man made vulnerable by alcohol by a group of four who were under the influence of drink and
drugs, which attack was sustained and brutal and close to sadistic. The attack resulted in devastating
injuries. Weapons of banister supports and shod feet which caused gratuitous and brutal violence and
mental suffering had been used. There had been disrespect and concealment of the body. None had
expressed remorse for what they had done. It is right to note that the judge had also said that there was
an eighth aggravating feature which was that the group had come to a joint intention to kill.

10. The judge when sentencing accepted that Mr Spence did not have sufficient maturity to appreciate
fully the consequences of what he had done, saying "This is indicated by your lack of remorse". The judge
referred to this as mitigation and referred to the Definitive Guideline for Sentencing Children and Young
People which emphasised the importance of the court considering the extent to which the child or young


-----

person had maturity to consider the consequences of their conduct and to consider the extent to which

they were acting on impulse without experience. When sentencing Mr Gordon‑Carew, the judge said that

although Mr Gordon‑Carew was a couple of years older than Alize Spence and was over the age of 18 at

the time of the offence, the judge took the view that the extent of his responsibility and culpability and

maturity was the same as Alize Spence's and would have been less than the case for most 18‑year‑olds.

That was because of his learning difficulties and low IQ. The judge recorded that Mr Gordon‑Carew and

Mr Spence had broadly similar backgrounds and effectively played the same part in the murder and both
were equally culpable. He therefore imposed the same minimum term on each of them.

**The renewed application for permission to appeal**

11. So far as the grounds for the renewed application for permission to appeal are concerned, we deal first
with the question of age. Mr Spence's age of 16 years at the time of the offence meant that the starting
point for his sentencing was 12 years, not 15 years. It is therefore apparent that Mr Spence's age had
been reflected in the starting point selected by the judge, as the judge made clear. Beyond his age the
judge considered Mr Spence's mental and emotional age in line with the relevant sentencing guidelines
and concluded that the significant mitigation afforded by his lack of maturity was considerably outweighed
by the circumstances of the offence and by Mr Spence's current lack of remorse. That was a conclusion

open to him on the facts and the judge indeed was best‑placed having seen the trial and the interaction

between the defendants to make such a decision. In our judgment it is plain that Mr Spence was not
penalised for his lack of insight and remorse when the offence was committed and that partly appears from
the judge's own sentencing remarks where he used the lack of remorse as evidence of the lack of maturity.

12. The judge determined that Mr Gordon‑Carew displayed a similar lack of maturity and culpability to Mr

Spence, taking account of his developmental age rather than just his chronological age. In order to

amount to a justiciable disparity of sentence between Mr Spence and Mr Gordon‑Carew, the disparity must

be such that a right‑thinking member of the public with full knowledge of the relevant facts and

circumstances would consider that something had gone wrong with the administration of justice: see
_Fawcett [1983] 5 Cr.App.R (S) 158._

13. In our judgment this is not such a case. The judge had regard to all the relevant sentencing guidelines
and balanced aggravating and mitigating features carefully. He conducted the trial, heard all the evidence

in relation to both Mr Spence and Mr Gordon‑Carew and he had seen Mr Gordon‑Carew give evidence and

had therefore the best possible insight into Mr Gordon‑Carew's developmental age. He was entitled

therefore to conclude, as he did, that the two displayed a similar lack of maturity.

14. That only then leaves in relation to the issue of aggravating features the fact that the judge identified
an intention to kill as an aggravating feature for murder. It is not an aggravating factor because it is already
included in the starting point under schedule 21 of the Sentencing Act 2020, but having regard to all the
other aggravating features which were identified by the judge, in our judgment it is not an error that would
cause us to have any doubt about the final sentence which was imposed on Mr Spence.

15. That brings us to the last issue that was raised on behalf of Mr Spence. It appears that just before
sentencing the SCA determination was adduced. This showed that Hampshire Constabulary had referred
the case of Mr Spence to the SCA. The SCA is a body set up by the Home Office to determine reasonable
and conclusive grounds decisions in relation to modern slavery. The SCA accepted on 24 April 2020 that
there were reasonable grounds to accept that Mr Spence might be a victim of modern slavery and on 17
May 2022 they determined on the evidence they had received that there were conclusive grounds to
accept that Mr Spence was a victim of **_modern slavery in that he had been the victim of criminal_**
exploitation.

16. The judge considered the determination by the SCA but noted that there was no evidence adduced at
trial to show that Mr Spence was the victim of criminal exploitation. The judge noted that the determination


-----

proved nothing and even if it had explained why Mr Spence was dealing drugs in Brighton, it did not
explain his role in the murder.

17. In our judgment the judge was right to conclude that the decision of the SCA did not provide mitigation
for this particular offence because the offence was murdering Mr Henham. There was nothing in the
evidence to suggest that Mr Spence had been pressurised or exploited into carrying out the murder. The
relevant features for mitigation were age and immaturity and the judge fairly reflected those elements in his
sentence.

**Conclusion**

18. Therefore, for all the reasons outlined above we refuse the renewed application for leave to appeal.
We are very grateful to Mr Selby KC and his team for the excellence of their written and oral submissions
and assistance to Mr Spence.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

