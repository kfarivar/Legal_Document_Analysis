# PHAN v HM ADVOCATE 2018 JC 195

[2018] HCJAC 7

High Court of Justiciary

Lord Justice-General (Carloway), Lord Menzies and Lord Turnbull

11 January 2018

**Justiciary — Review — Compatibility issue — Minuter claiming to have been compelled to commit offences**
**in consequence of being victim of human trafficking — Whether absence of statutory defence incompatible**
**with Directive 2011/36/EU — Whether continued prosecution incompatible with Directive 2011/36/EU and**
**Art 47 of the Charter of Fundamental Rights of the European Union (C326/391) — Charter of Fundamental**
**Rights of the European Union, Art 47 — Directive 2011/36/EU, Art 8 — Human Trafficking and Exploitation**
**(Scotland) Act2015(asp 12).**

Section 8 of the **HUMAN** **TRAFFICKING AND** **EXPLOITATION** **(SCOTLAND)** **ACT** **2015 (asp 12) (ʻthe 2015 Actʼ) provides,**

_inter alia, “(1) The Lord Advocate must issue and publish instructions about the prosecution of a person who is, or_
appears to be, the victim of an offence– (a) of human trafficking … (2) The instructions must in particular include
factors to be taken into account or steps to be taken by the prosecutor when deciding whether to prosecute a
person in the circumstances mentioned in subsections (3) … (3) The circumstances are where– (a) an adult does
an act which constitutes an offence because the adult had been compelled to do so, and (b) the compulsion
appears to be directly attributable to the adult being a victim of an offence mentioned in subsection (1).”

Article 26 of the Council of Europe Convention on Action against Trafficking in Human Beings (CETS 197) provides,
“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.”

Article 2 of Directive 2011/36/EU of the European Parliament and Council of 5 April 2011 on preventing and
combating trafficking in human beings and protecting its victims, and replacing Council Framework Decision

2002/629/JHA ([2011] OJ L101/1) (ʻthe Directiveʼ) provides, “(1) Member States shall take the necessary measures

to ensure that the following intentional acts are punishable: The recruitment, transportation, transfer, harbouring or
reception of persons, including the exchange or transfer of control over those persons, by means of the threat or
use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having control
over another person, for the purpose of exploitation”. Article 8 provides, “(1) Member States shall, in accordance
with the basic principles of their legal systems, take the necessary measures to ensure that competent national
authorities are entitled not to prosecute or impose penalties on victims of trafficking in human beings for their
involvement in criminal activities which they have been compelled to commit as a direct consequence of being
subjected to any of the acts referred to in Article 2.”

Article 47 of the Charter of Fundamental Rights of the European Union (C326/391) (ʻthe Charterʼ) provides,

“Everyone whose rights and freedoms guaranteed by the law of the Union are violated has the right to an effective


-----

remedy before a tribunal in compliance with the conditions laid down in this Article. Everyone is entitled to a fair and
public hearing … by an independent and impartial tribunal”.

On 26 April 2016, the minuter was found in a flat in Glasgow and was arrested and charged on the basis that the
premises were being used to
**[*196]**

cultivate cannabis. During his police interview, the minuter gave an account of having been a victim of human
trafficking, having been trafficked from Vietnam to Scotland via Russia and France, and having been locked in the
flat in Glasgow by his abductors and told to look after the cannabis plants. A Home Office investigation concluded
that the minuter had not been trafficked. The minuter was, thereafter, indicted in the sheriff court on charges under
[the Misuse of Drugs Act 1971 (cap 38).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)

The minuter challenged the compatibility of his prosecution with EU law, and in particular the Directive, because he
could not plead as a defence that he had been trafficked into the United Kingdom and compelled to commit the
offences. The sheriff referred the compatibility issue to the High Court of Justiciary for determination.

The minuter argued that, in the absence of a statutory defence in the **2015** **ACT that an accused had been**
compelled to commit a crime through trafficking, victims of trafficking were less well protected in Scotland than in
the rest of the United Kingdom and that the Directive gave him the right to have the question of whether he had
been a victim of human trafficking, and compelled to commit the offence, determined at a hearing by an
independent and impartial tribunal. The minuter submitted that, in the absence of a power in Scotland to stay a
prosecution, the court required to create a defence which would give effect to the Directive in a procedurally fair
manner and, in the absence of such a defence being available, the continued prosecution of the minuter was
oppressive.

The Crown submitted that the discretion of the Lord Advocate not to prosecute, taken together with the publication
of the criteria to be taken into account when exercising that discretion, was sufficient to satisfy the requirements of
Art 8 of the Directive and that the continued prosecution of the minuter was not incompatible with Art 47 of the
Charter or with the Directive, as the Directive did not confer on any person the right not to be prosecuted, nor did it
require a Member State to provide for a statutory defence.

Quyen Van Phan was indicted in the sheriff court at Glasgow at the instance of the Right Honourable W James

[Wolffe QC, Her Majestyʼs Advocate, on, inter alia, charges contrary to the Misuse of Drugs Act 1971. The case was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)

indicted for a first diet on 3 August 2016, with a trial diet on 22 August. The minuter pled not guilty and lodged a
compatibility minute which, following a number of adjournments in the cause, was argued before the sheriff on 10
July 2017. The sheriff referred the issue to the High Court of Justiciary for determination.

_Held that the Lord Advocateʼs discretion not to prosecute met the requirement of Art 8 of the Directive that national_

authorities be “entitled not to prosecute” victims of trafficking (para 39); and case remitted to the sheriff.

_Observed that: (1) unless there is material to contradict the Crownʼs findings or to demonstrate that significant_

evidence has been ignored by them, the court would be unlikely to stop a prosecution at a preliminary stage (para
41); (2) if a captive cannabis farmer had reasonable grounds for believing that, if he did not tend to the crop, he
would be seriously injured on the arrival of those controlling the operation, the defence of coercion may well be
made out (para 43); and (3) circumstances that did not amount to the defence of coercion may nevertheless provide
powerful mitigation and could be the subject of a proof in mitigation (paras 44, 45).

R v Joseph [2017] 1 WLR 3153followed.

Cases referred to:

[Advocate (HM) v V [2016] HCJAC 103 ; 2017 SCCR 7 ; 2017 SCL 29; 2016 GWD 37-663](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NR3-G7T1-DYMJ-110C-00000-00&context=1519360)


-----

Berlioz Investment Fund SA v Director of the Direct Taxation Administration, Luxembourg (C-682/15)
EU:C:2017:373 ; [2018] 1 CMLR 1 ; [2017] BTC 15

[Butt v Scottish Ministers [2012] HCJAC 107 ; 2013 JC 274 ; 2012 SLT 1066; 2012 SCCR 649; 2012 SCL 970](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDX2-8T41-D08Y-00000-00&context=1519360)

Finanmadrid EFC SA v Zambrano (C-49/14) EU:C:2016:98 ; [2016] 3 CMLR 3 ; [2016] CEC 1387
**[*197]**

[Hester v Macdonald 1961 SC 370 ; 1961 SLT 414](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KKY0-TXX6-C02W-00000-00&context=1519360)

Kamberaj v Istituto per lʼEdilizia Sociale della Provincia Autonoma di Bolzano (IPES) (C-571/10) EU:C:2012:233 ;

[[2012] 2 CMLR 43 ; [2013] All ER (EC) 125](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57P4-KCC1-DYBP-K2HP-00000-00&context=1519360)

[Lin v HM Advocate [2007] HCJAC 62 ; 2008 JC 142 ; 2008 SCCR 16; 2008 SCL 251; 2007 GWD 35-591](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDH2-8T41-D02F-00000-00&context=1519360)

[McBain v Crichton 1961 JC 25 ; 1961 SLT 209](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-HBJ0-TXX6-C0VG-00000-00&context=1519360)

Opinion 2/13 (C-2/13) EU:C:2014:2454 CJEU, 18 December 2014, unreported

[Paterson v HM Advocate [2008] HCJAC 2 ; 2008 JC 230 ; 2008 SCCR 582; 2008 SCL 572](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDK2-D6MY-P3YG-00000-00&context=1519360)

Puskar v Slovakia (C-73/16) EU:C:2017:253 ; 30 March 2017, unreported

R v Joseph [2017] EWCA Crim 36 ; [2017] 1 WLR 3153; [2017] 1 Cr App R 33; [2017] Crim. LR 817

[R v L [2013] EWCA Crim 991 ; [2014] 1 All ER 113 ; [2013] 2 Cr App R 23; [2014] Crim LR 150](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)

R v M [2010] EWCA Crim 2327 ; [2011] 1 Cr App R 12 ; [2011] Crim LR 425

[R (on the application of A (A Child)) v Secretary of State for Health [2017] UKSC 41 ; [2017] 1 WLR 2492; [2017] 4](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PPJ-JMP1-DYBP-M0BD-00000-00&context=1519360)
_[All ER 353; [2017] HRLR 9; [2017] Med LR 347; (2017) 156 BMLR 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PPJ-JMP1-DYBP-M0BD-00000-00&context=1519360)_

R (on the application of Buckinghamshire County Council) v Secretary of State for Transport _[2014] UKSC 3 ;_

[[2014] 1 WLR 324; [2014] 2 All ER 109; [2014] PTSR 182](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-CYX1-DYBP-M2K7-00000-00&context=1519360)

R (on the application of Corner House Research) v Director of the Serious Fraud Office [2008] UKHL 60 ; [2009] 1

[AC 756; [2008] 3 WLR 568; [2008] 4 All ER 927; [2008] Lloydʼs Rep FC 537; [2009] Crim LR 46](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TF3-FY20-Y96Y-G3YJ-00000-00&context=1519360)

R (on the application of Horvath) v Secretary of State for the Environment, Food and Rural Affairs (C-428/07)
EU:C:2009:458 ; [2009] ECR I -6355 ; [2009] 30 EG 66 (CS)

R (on the application of McNiece) v Criminal Injuries Compensation Authority [2017] EWHC 2 (Admin)

[R (on the application of Miller) v Secretary of State for Exiting the European Union [2017] UKSC 5 ; [2017] NI 141 ;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RJF-8GD1-DYMJ-21JD-00000-00&context=1519360)

[[2018] AC 61; [2017] 2 WLR 583; [2017] 1 All ER 593; [2017] 2 CMLR 15; [2017] HRLR 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MV9-JKP1-DYBP-M02H-00000-00&context=1519360)

[Ross v HM Advocate [2015] HCJAC 38 ; 2015 JC 271 ; 2015 SLT 325; 2015 SCCR 237](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VF22-D6MY-P489-00000-00&context=1519360)

[Ross v Lord Advocate [2016] CSIH 12 ; 2016 SC 502 ; 2016 SCCR 176; 2016 SCLR 764; 2016 GWD 8-155; 149](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P27-D1S1-F0JW-T2B4-00000-00&context=1519360)
_[BMLR 54](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JXJ-YVS1-DYJ0-B452-00000-00&context=1519360)_

[Stewart v Payne [2016] HCJAC 122 ; 2017 JC 155 ; 2017 SLT 159; 2017 SCCR 56; 2017 SCL 263](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SJN-7NN1-F0JW-T2FP-00000-00&context=1519360)

[Stuurman v HM Advocate 1980 JC 111 ; 1980 SLT (Notes) 95](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KM40-TXX6-C02N-00000-00&context=1519360)


-----

[Thomson v HM Advocate 1983 JC 69 ; 1983 SLT 682; 1983 SCCR 368](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KM10-TXX6-C0D0-00000-00&context=1519360)

Van Dao v R [2012] EWCA Crim 1717 ; [2013] Crim LR 234

W v Sanofi Pasteur MSD SNC (C-621/15) EU:C:2017:484 ; [2018] 1 CMLR 16 ; [2017] 4 WLR 171; [2018] CEC
[331; (2017) 158 BMLR 16](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R2T-JY91-DYJ0-B01G-00000-00&context=1519360)

X v Belgium (C-638/16 PPU) EU:C:2017:173 ; [2017] 3 CMLR 15 ; [2017] 4 WLR 89; [2017] CEC 1239

Textbooks etc referred to:

Council of Europe, Convention on Action against Trafficking in Human Beings (ʻthe Warsaw Conventionʼ) (CETS

197) (Council of Europe, Strasbourg, May 2005), Art 26 (Online: https://rm.coe.int/168008371d (17 May 2018))

Crown Office and Procurator Fiscal Service, Prosecution Code (CP/AY/6)) (Crown Office, Edinburgh, May 2001), p
6 (Online:
http://www.copfs.gov.uk/images/Documents/Prosecution_Policy_Guidance/Prosecution20Code20_Final20180412_
_1.pdf (17 May 2018))

Group of Experts on Action against Trafficking in Human Beings, Report Concerning the Implementation of the
Council of Europe Convention on Action against Trafficking in Human Beings by the United Kingdom — Second
Evaluation Round (GRETA(2016)21) (Council of Europe, Strasbourg, October 2016), (Online:
https://rm.coe.int/16806a99b1 (17 May 2018))

Hume, D, Commentaries on the Law of Scotland Respecting Crimes (4th Bell ed, Bell and Bradfute, Edinburgh,
1844), i, 53
**[*198]**

Independent Anti-slavery Commissioner, Combating **_Modern Slavery experienced by Vietnamese Nationals en_**
route to, and within, the UK (HMSO, London, September 2017), para 4.2.2 (Online:
http://www.antislaverycommissioner.co.uk/media/1159/iasc-report-combating-modern-slavery-experience-byvietname-nationals-en-route-to-and-within-the-uk.pdf (16 May 2018))

Lord Justice-Clerk (Carloway), Criminal Courts Practice Note no 3 of 2015: Sheriff Court Solemn Procedure
(Scottish Courts and Tribunals Service, Edinburgh, February 2015) (Online:
https://www.scotcourts.gov.uk/docs/default-source/rules-and-practice/practice-notes/criminal-courts/criminal-courtspn-no3-of-2015.pdf?sfvrsn=24 (16 May 2018))

Scottish Government, Human Trafficking and Exploitation (Scotland) Bill: Policy memorandum (SP Bill 57–PM)
(Scottish Parliament, Edinburgh, December 2014), para 52 (Online:
http://www.parliament.scot/S4_Bills/Human%20Trafficking%20Bill/b57s4-introd-pm.pdf (16 May 2018))

United Nations Office on Drugs and Crime, United Nations Convention against Transnational Organized Crime and

the Protocols Thereto (ʻthe Palermo Convention/Protocolʼ) (UNODC, Vienna, September 2004) (Online:

https://www.unodc.org/documents/treaties/UNTOC/Publications/TOC%20Convention/TOCebook-e.pdf) (17 May
2018))

The cause called before the High Court of Justiciary, comprising the Lord Justice-General (Carloway), Lord
Menzies and Lord Turnbull, for a hearing, on 21 December 2017.

At advising, on 11 January 2018, the opinion of the Court was delivered by the Lord Justice-General (Carloway)—

**Opinion of the Court—**
**Introduction**


-----

[1] This is a reference from the sheriff at Glasgow, posing the following questions:

ʻ(1) Is the Human Trafficking and Exploitation (Scotland) Act 2015 [(asp 12)] incompatible with Directive

2011/36/EU in the absence of a statutory defence to the effect that the [minuter] had been compelled to act as
he did as a direct consequence of being subject to human trafficking?

(2) In the absence of a statutory defence … is the continued prosecution of the minuter incompatible with
Directive 2011/36/EU, Article 47 of the Charter of Fundamental Rights of the European Union and Article 6(1)
of the European Convention on Human Rights?

(3) If the … Act and the … continuation of the … proceedings are compatible with Directive 2011/36/EU, and if
at trial the evidence broadly follows [certain] lines … would the court require to give additional directions over
and beyond the standard directions so as to give effect to the Directive, and, if so, what additional directions

should be given?ʼ

**Legislation**

[2] Following upon the prohibition on slavery in the European Convention on Human Rights and Fundamental
Freedoms, the Palermo Protocol (UN **OFFICE ON** **DRUGS AND** **CRIME, United Nations Convention against**
Transnational Organized Crime and the Protocols Thereto) had promoted the suppression of human trafficking,
especially that involving women and children, and the need to protect and assist victims. This was complemented
by the EU Framework Decision 2002/629/JHA and the Warsaw Convention (COUNCIL OF **EUROPE, Convention on**
Action against Trafficking in Human Beings). Article 26 of the latter provided:

ʻEach Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not

imposing penalties on victims for their

**[*199]**

involvement in unlawful activities, to the extent that they have been compelled to do so.ʼ

The PALERMO PROTOCOL and the WARSAW CONVENTION were ratified by the United Kingdom in 2006 and 2008.

[3] Recital 14 of Directive 2011/36/EU of the European Parliament and Council dated 5 April 2011 on preventing
and combating trafficking in human beings and protecting its victims, and replacing Council Framework Decision
2002/629/JHA ([2011] OJ L101/1), commonly known as the Human Trafficking Directive, states:

ʻVictims of trafficking in human beings should, in accordance with the basic principles of the legal systems of

the relevant Member States, be protected from prosecution or punishment for criminal activities such as the
use of false documents, or offences under legislation on prostitution or immigration, that they have been
compelled to commit as a direct consequence of being subject to trafficking. The aim of such protection is to
safeguard the human rights of victims, to avoid further victimisation and to encourage them to act as witnesses
in criminal proceedings against the perpetrators. This safeguard should not exclude prosecution or punishment

for offences that a person has voluntarily committed or participated in.ʼ

[4] Article 8 of the Directive specifies:

ʻ(1) Member States shall, in accordance with the basic principles of their legal systems, take the necessary

measures to ensure that competent national authorities are entitled not to prosecute or impose penalties on
victims of trafficking in human beings for their involvement in criminal activities which they have been

compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2.ʼ

The acts referred to in Art 2 include threats, or the use of force or other forms of coercion, abduction, fraud,
deception and the abuse of power or vulnerability.


-----

[5] Article 47 of the Charter of Fundamental Rights of the European Union (C326/391) (ʻthe Charterʼ) provides:

ʻEveryone whose rights and freedoms guaranteed by the law of the Union are violated has the right to an

effective remedy before a tribunal in compliance with the conditions laid down in this Article.

Everyone is entitled to a fair and public hearing … by an independent and impartial tribunalʼ.

[6] The Human Trafficking Directive was expressly implemented by the **HUMAN** **TRAFFICKING AND** **EXPLOITATION**

**(SCOTLAND)** **ACT 2015 (ʻthe 215 Actʼ). Section 8 of the 2015** **ACT provides:**

ʻ(1) The Lord Advocate must issue and publish instructions about the prosecution of a person who is, or

appears to be, the victim of an offence–(a)of human trafficking …

(2) The instructions must in particular include factors to be taken into account or steps to be taken by the
prosecutor when deciding whether to prosecute a person in the circumstances mentioned in [subsection] (3) …

(3) The circumstances are where–(a)an adult does an act which constitutes an offence because the adult has
been compelled to do so, and(b)the compulsion appears to be directly attributable to the adult being a victim of

an offence mentioned in subsection (1).ʼ

**[*200]**

[7] During the parliamentary process, the Cabinet Secretary for Justice had explained that, rather than placing the
onus on a person to establish that he was a victim who had been compelled to act, as had been done in other parts
[of the United Kingdom (Modern Slavery Act 2015 (cap 30), sec 45; Human Trafficking and Exploitation (Criminal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Justice and Support for Victims) Act (Northern Ireland) 2015 (cap 2)), the Government had preferred to place an

obligation on the respondent to ʻproduce instructions to prosecutors to deliver [a] victim centred approachʼ (Official

_Report, 1 October 2015, col 55)._

[8] The Lord Advocateʼs instructions contain the following:

ʻIf there is sufficient evidence that a person … has committed an offence and there is credible and reliable

information to support the fact that the person:(a)is a victim of human trafficking or exploitation(b)has been
compelled to carry out the offence and(c)the compulsion is directly attributable to being the victim of human

trafficking or exploitation,then there is a strong presumption again prosecution of that person for that offence.ʼ

**Facts**

[9] On 26 April 2016, the minuter was found in a flat on Forth Street, Glasgow which, it appears to be accepted, was
being used for the purposes of cannabis cultivation. There was £100 in cash, adequate supplies of food and drink
and a key available in the flat. Although the minuter said that he did not know where the key was, the police account
is that it was hanging on the wall of the only occupied bedroom. The minuter was arrested and charged. No
interview in relation to the offence took place.

[10] On 27 April 2016, the minuter was interviewed by the police as a potential victim of human trafficking. He gave
an account of being taken by persons unknown from Vietnam to Scotland, via Russia and France, hidden in a large
lorry with more than 20 others. He had not been on a plane or boat. His abductors had said that they would arrange

for him to work lawfully in the United Kingdom. He was happy with that, explaining that he was just ʻfollowing

instructionsʼ. He had previously registered with his abductors in Vietnam in answer to an internet advertisement. He

did not know their names, but they had many offices in Vietnam, including one in Hanoi. The minuter had worked on
a rice farm. He had had no education. His travel was to be paid for and he would repay it from his UK wages. Once
in the United Kingdom he was locked in a house before being taken to the flat where he was asked to look after the
cannabis plants. He had asked to leave the flat many times but had been beaten up. He had been locked in for two

-----

and-a-half months. The persons beating him up had been westerners who had communicated with him using ʻbody

signalsʼ. He had been paid £100 for painting work.

[11] On 16 December 2016, the minuter was interviewed by the Home Office. He said that he had a wife and two
sons. He had left his home in Phuong Vinh Tan (300 miles north of Hanoi), Vietnam, in May 2015, and travelled to

Russia by plane before arriving in France. He had stayed for three months in the ʻjungleʼ before getting on a lorry

and arriving in the United Kingdom sometime between October and December. Although his wife and children were
now in hiding, he had been able to contact them in November or December by using a mobile phone which he
**[*201]**

had been given. He had agreed to pay $18,000 for the journey to the United Kingdom and had handed over his
land and property in security. He had been working as a market porter. He had had five years schooling. He had
gone to a hotel in Hanoi and then flown from Hanoi to Russia before arriving in France in about June or July 2015.
He had stayed there for three or four months. He had then gone to the United Kingdom by lorry, although he had
not known where he was until his arrest. The minuter had been told that he would have to work for two years to pay
off his debt. He had been shown how to tend to the plants by a person who had stayed in the flat for the first week.
Food was provided in the fridge and freezer. He was told not to leave. He was locked in. He had asked to leave, but
his captors had threatened to, and did, beat him up because he had refused to work.

[12] The conclusion of the Home Office was that the minuter had not been trafficked. The Home Office interpreted
the PALERMO CONVENTION as meaning that trafficking involved the victim being coerced or deceived into a situation
in which he or she was exploited. In its decision, dated 25 January 2017, the Home Office determined that the
minuter was not a credible witness given the inconsistencies in his accounts to the police and to the Home Office,
not all of which are repeated here.

[13] The respondent reviewed the facts and determined, applying the guidelines, that there was no reasonable
basis for concluding that the minuter was the victim of trafficking and, in any event, the necessary element of
compulsion to commit the offence was not present. The minuter was accordingly placed on petition.
**Procedure**

[14] The minuter was indicted on charges of producing cannabis and concern in the supplying of cannabis, contrary
respectively to secs 4(2)(a) and 4(3)(b) of the _[Misuse of Drugs Act 1971 (cap 38) and theft of electricity. A](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)_
compatibility minute maintained that the continued prosecution of the minuter was incompatible with the Directive
because the minuter had no access to a defence that he had been trafficked into the United Kingdom and
compelled to commit the offences. The minute sought: a declarator that the 2015 **ACT was incompatible with EU law**
because of the absence of such a defence; an order deserting the proceedings because of the absence of the
defence on the ground of oppression; or directions to the jury on coercion in a manner which was compatible with
the Directive; or a reference to the High Court. A first diet was allocated for 3 August, with a trial diet on 22 August
2016. Thereafter, the case called on no less 11 occasions before, remarkably, 11 different sheriffs before one of
those sheriffs decided to take a decision to remit the matter to the High Court.

[15] The sheriff determined that it would not be appropriate to desert simpliciter, since it could not be said that a fair
trial was impossible (PATERSON V HM **_ADVOCATE; HM_** **_ADVOCATE V V). The decision taken by the respondent had not_**

been unfair. The guidelines had been cited with approval in the Council of Europeʼs GROUP OF EXPERTS ON ACTION

**AGAINST TRAFFICKING IN HUMAN BEINGS (Report concerning the implementation of the Council of Europe Convention**
_on Action against Trafficking in Human Beings by the United Kingdom — Second Evaluation Round) and the Anti-_

trafficking Monitoring Group, in October 2016. The respondentʼs guidelines, which contained a presumption against

the prosecution of victims of trafficking, were compliant with the Directive. That Directive allowed Member States to
devise their own systems of implementation. The 2015 **ACT placed responsibility for the decision**
**[*202]**


-----

to prosecute on the respondent. This was in accordance with the traditional approach to prosecution. The

respondentʼs decision had been made after consideration of compulsion. It had not determined the outcome of

proceedings and could not affect the fairness of the trial. The minuter was free to lead evidence in support of his
position that he was a victim of trafficking. In these circumstances, the minuter had not been deprived of any rights
that he may have had under the Directive. His rights under Art 6 of the European Convention had not been
breached.

[16] The issue of punishment was a matter which, according to the sheriff, gave rise to real difficulty. Evidence that
the minuter was the victim of trafficking was not a recognised defence, as it was elsewhere in the United Kingdom.
Even if the jury accepted his account of trafficking, the minuter would still face conviction and sentence unless his
position fell within an existing category of special or statutory defence. The sentencing sheriff would not know

whether the jury had, or had not, accepted the minuterʼs account. The defence of coercion required the minuter to

establish that he had acted under an immediate danger of death or serious bodily harm (THOMSON V **_HM_**
**_ADVOCATE). This requirement would not be met if the minuter had been acting under duress of a serious, but not_**
immediate, kind.
**SubmissionsMinuter**

[17] The minuter moved the court to answer questions (1) and (2) in the affirmative or, if it did not do so, to set out
appropriate directions on coercion. Attention was initially focused on the scale of the human trafficking problem; it
not being unusual for victims to be Vietnamese being exploited for the purposes of cannabis cultivation. The
international law background had commenced with the prohibition of slavery in the European Convention (Art 4).
Since 2000, a series of international conventions had addressed the situation, notably the PALERMO PROTOCOL, the
EU Framework Decision 2002/629/JHA and the WARSAW CONVENTION.

[18] The Charter of Fundamental Rights of the European Union contained a prohibition on slavery, and a specific
one relative to trafficking. Article 47 provided that everyone, whose rights and freedoms were guaranteed by EU
law, had a right to an effective remedy; that being one which was neither theoretical nor illusory (X V BELGIUM, AG,
para 158; W V SANOFI PASTEUR MSD **_SNC; FINANMADRID EFC_** **_SA V ZAMBRANO, AG, para 84; BERLIOZ INVESTMENT_**
**_FUND_** **_SA V_** **_DIRECTOR OF THE_** **_DIRECT_** **_TAXATION_** **_ADMINISTRATION, para 44). There had been a shift in the general_**
approach from respect for procedural autonomy to the protection of substantive rights (PUSKAR V **_SLOVAKIA, AG,_**
paras 46–51; **_BERLIOZ_** **_INVESTMENT_** **_FUND, paras 44–56, 83, 84). There required to be an effective opportunity to_**

challenge the respondentʼs decision to prosecute. National courts had a duty of ʻsincere co-operationʼ (R **_(MILLER) V_**

**_SECRETARY OF_** **_STATE FOR_** **_EXITING THE_** **_EUROPEAN_** **_UNION, para 61;_** **_R_** **_(BUCKINGHAMSHIRE_** **_COUNTY_** **_COUNCIL) V_**
**_SECRETARY OF_** **_STATE FOR_** **_TRANSPORT, para 206;_** **_OPINION_** **_2/13 on the accession of the European Union to the_**
European Convention).

[19] In England and Wales, the **WARSAW** **CONVENTION had been implemented (R V** **_M) in three ways, namely_**
through: (1) the common law defences of duress and necessity; (2) specific rules for the guidance of prosecutors;
and (3) the power of the court to stay a prosecution as an abuse of process. Careful consideration required to be
given as to whether prosecution and punishment should follow in the case of a victim, where the crime had been
something which he or she had been compelled,
**[*203]**

[in a broad sense, to commit. The matter was fact-sensitive. The Modern Slavery Act 2015 had provided a statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
defence where the accused person had been compelled to commit a crime through trafficking. It was a requirement
that a reasonable person, in the same situation, would have had no realistic alternative but to commit the crime.
The Human Trafficking and Exploitation (Criminal Justice and Support for Victims) Act (Northern Ireland) 2015 had
achieved much the same purpose in Northern Ireland, although it only provided a defence in respect of the
cultivation, and not concern in the supplying, of cannabis.

[20] The 2015 **ACT did not provide a defence. This had been an intentional decision by Parliament, following upon**
the statement by the Cabinet Secretary for Justice. For the purposes of EU law, the question of whether there had
been differential treatment depended upon whether the primacy, unity and effectiveness of EU law had been


-----

compromised. The fact that there was no statutory defence meant that victims of trafficking were less well protected
in Scotland than in the rest of the United Kingdom. Such an approach required to be justified substantively and by
reference to the requirement of legality. The justification given failed to recognise the procedural rights of victims
under Art 47 of the Charter, when the prosecutor decided whether to prosecute. The Directive gave the minuter a
right to have the question, of whether he was a victim and had been compelled to commit the offence, determined
at a fair and public hearing by an independent and impartial tribunal.

[21] The defence of coercion (THOMSON V **_HM_** **_ADVOCATE) did not provide sufficient protection because, in many_**
cases at least, there was no immediate danger of death or serious bodily harm or an inability to resist the violence.
Many of those, who had been compelled to commit offences as a direct consequence of being subject to the
prohibited acts, would not be able to rely on the defence as it was currently expressed (see **_VAN DAO V R for the_**
position in England).

[22] A proof in mitigation was not an effective remedy. If an accused had a substantive defence, or there were
issues related to other fundamental rights, these would be lost if a proof in mitigation was the only method by which
protection could be secured. Mitigation could not be advanced where it was inconsistent with a plea of guilty. Any
plea would proceed on a narrative in which the Crown would wish to state that the accused had not committed the
offence as a result of trafficking (see ROSS V HM **_ADVOCATE). Even if the narrative did not contradict the plea, the_**

burden of proof would lie upon the accused, and that was not consistent with an accusedʼs rights.

[23] The question, of whether the minuter had been compelled to act as he did as a result of trafficking, required to
be decided in a procedurally fair manner. Great deference was given by the courts to the Lord Advocate. There was

no ʻrobust traditionʼ of independent judicial review of his decisions (HESTER V MACDONALD, pp 378, 379; MCBAIN V

**_CRICHTON, pp 28, 29; ROSS V LORD ADVOCATE, para 75; STEWART V PAYNE). This was in contrast to the position in_**
England (R **_(CORNER HOUSE RESEARCH) V DIRECTOR OF THE SERIOUS FRAUD OFFICE, paras 30, 32). There was no_**

case in which the Lord Advocateʼs discretion in the context of a criminal prosecution had been subject to a

successful review (see STUURMAN V HM **_ADVOCATE)._**

[24] The Lord Advocate had not acted in a procedurally fair manner. The Crown had given an undertaking not to

use the police interview of the minuter in the prosecution, yet the foundation of the Crownʼs conclusion, that he was

not the victim of trafficking, had stemmed from the conclusive grounds decision
**[*204]**

notification, which had relied on a comparison between what the minuter had told the police and what he had said
to the Home Office.

[25] In **_R V_** **_JOSEPH (paras 24–28), the Court of Appeal had held that domestic law was compatible with the_**
obligations under the international conventions. That reasoning could not apply in Scotland, because there was no
power to stay a prosecution akin to that in England. In the absence of such a power, the court required to create a
defence which would give effect to the Directive in a procedurally fair manner. If it did not do so, the continued
prosecution of the minuter would be oppressive.

[26] The submission relative to Art 6 of the European Convention was departed from.
_Respondent_

[27] Section 8 of the 2015 **ACT required the respondent to issue and publish instructions about the prosecution of a**
person who appeared to be the victim of human trafficking. The instructions required certain factors to be taken into
account. The respondent had issued and published instructions in accordance with sec 8. These provided that there
was a strong presumption against prosecution where there was credible and reliable information that: the accused
was a victim of trafficking; he or she was compelled to commit the offence; and the compulsion was directly
attributable to being a victim.


-----

[28] The respondent had appointed a national lead prosecutor for human trafficking and exploitation. All cases
required to be reported to him for a final decision. If information came to light, which suggested that the accused
was the victim of human trafficking, the prosecutor was required to investigate. Where information came to light
after conviction, the prosecutor had to apply to have the conviction quashed.

[29] Article 8 of the Directive provided that the approach taken to implementation was to be in accordance with the
basic principles of the legal systems of each Member State. The Directive allowed for different approaches

(KAMBERAJ V **_ISTITUTO PER LʼEDILIZIA_** **_SOCIALE DELLA_** **_PROVINCIA_** **_AUTONOMA DI_** **_BOLZANO_** **_(IPES), para 77). Article 8_**

did not require a statutory defence (see also recital (14)). Member States were only required to ensure that the

national authorities ʻwere entitledʼ not to prosecute or to impose penalties on victims.

[30] Prior to the Directive, the principal European instrument relating to human trafficking had been the **WARSAW**
**CONVENTION. It had not formed part of EU law, as it had not been signed or ratified by the European Union. Article**
26 did not require a blanket immunity from prosecution, nor did it provide a defence. Rather, an assessment of
whether a prosecution was appropriate had to be carried out (R V M, para 13). The same approach could be taken
in the interpretation of Art 8 of the Directive.

[31] The prosecutorial discretion of the respondent was a basic principle of the legal system (MCBAIN V CRICHTON, p
29; STEWART V PAYNE). The respondent required to consider whether prosecution was in the public interest, even
where there was sufficient evidence (CROWN **OFFICE AND** **PROCURATOR** **FISCAL** **SERVICE,** _Prosecution Code, p 6)._

The respondentʼs discretion not to prosecute, taken together with the publication of criteria to be taken into account

when exercising that discretion, was sufficient to satisfy the requirements of Art 8 of the Directive. It had been held
to
**[*205]**

satisfy the requirements of Art 26 of the WARSAW CONVENTION in England and Wales (R V M). The introduction of a
statutory defence did not affect the compatibility of the English common law with the requirements of Art 26 (R V
**_JOSEPH). It had been described as a backstop to the prosecutorial discretion (R_** **_(MCNIECE) V_** **_CRIMINAL_** **_INJURIES_**
**_COMPENSATION_** **_AUTHORITY, para 131). Where the commencement or continuation of a prosecution breached a_**
European Convention right, the court had the power to halt the prosecution (BUTT V SCOTTISH MINISTERS, para 16).

[32] The obligation imposed on the respondent by sec 8 of the **2015** **ACT had not been necessary to ensure**
compliance with Art 8 of the Directive. Rather it served to codify the factors which would be taken into account
(POLICY MEMORANDUM to the Human Trafficking and Exploitation (Scotland) Bill (SP Bill 57), para 52). The Scottish
regime had been endorsed by the **GROUP OF** **EXPERTS ON** **ACTION AGAINST** **TRAFFICKING IN** **HUMAN** **BEINGS report.**
Individuals who had voluntarily committed criminal offences could seek to avoid punishment by falsely claiming to
have been compelled to do so. This phenomenon was not uncommon among Vietnamese nationals who were
involved in cannabis production (INDEPENDENT **ANTI-SLAVERY** **COMMISSIONER,** _Combating_ **_Modern Slavery_**
_experienced by Vietnamese Nationals en route to, and within, the UK, para 4.2.2). The need for a balanced,_

thorough and careful investigation was emphasised in the respondentʼs instructions.

[33] The existence of a statutory defence in other UK jurisdictions was irrelevant to the compatibility of the 2015 **ACT**
with EU law. The existence of alternative approaches within the United Kingdom did not constitute discrimination (R
**_(HORVATH) V SECRETARY OF STATE FOR THE ENVIRONMENT,_** **_FOOD AND RURAL AFFAIRS, para 58). The regime was to_**
be distinguished from a situation where one part of the United Kingdom differentiated between citizens based on
whether or not they were residents of that part (R **_(A) V SECRETARY OF STATE FOR HEALTH, para 37–49)._**

[34] Article 8 of the Directive did not require any particular approach to be taken by Member States. A judge was
entitled to take into account the fact that an accused was the victim of trafficking at the point of sentence. The
sentencer could grant an absolute discharge in almost all cases. The requirement that Member States confer a
discretion on the national authorities was subject to the caveat that such provision should be made in accordance
with the basic principles of their own legal systems.


-----

[35] The continued prosecution of the minuter was not incompatible with the Directive, as it did not confer on any
person the right not to be prosecuted or punished. The continued prosecution of the minuter was not incompatible
with Art 8 of the Directive or Art 47 of the Charter. The second question should be answered in the negative.

[36] No additional directions over and above the standard directions on coercion were required. The task of the jury
was to determine guilt or otherwise. The question of compulsion by virtue of being trafficked was a discrete question
which went only to mitigation, unless the circumstances were such as to amount to the recognised defences of
coercion or necessity. Mitigation was a matter for the judge to consider at the point of sentence, having heard any
relevant evidence during the trial or any proof in mitigation. The third question should be answered in the negative.
**Decision**

[37] Article 47 of the Charter of Fundamental Rights of the European Union provides that everyone whose rights
and freedoms are guaranteed by EU law has a
**[*206]**

right to an effective remedy before an independent and impartial tribunal. The first question is whether the minuterʼs

rights and freedoms under EU law have been violated. That in turn depends upon Art 8 of the Directive. This
provides that Member States require to ensure that national authorities are entitled not to prosecute or to impose

penalties on victims of human trafficking for their involvement in crimes which they have been ʻcompelledʼ to commit

as a ʻdirect consequenceʼ of, in essence, threats, the use of force or other forms of coercion. It does not require that

such victims are not prosecuted or punished. It does not confer a right on such victims not to be prosecuted or
punished. What must be available is an option. No doubt, if such an option were not available in Scotland,
proceedings could be taken to challenge that or any action taken without due consideration of such an option.

[38] An option not to prosecute a person for a particular crime has always been available in Scotland; it being a
matter for the respondent to decide whether to do so in the public interest. Whether a person was a victim of
trafficking is something which might have been taken into account in deciding whether to prosecute him or her for a
particular crime. Nevertheless, increasing recognition of the problem of trafficking and, of course, the terms of the
Directive and its international antecedents, prompted the passing of sec 8 of the **2015** **ACT. This required the**
respondent to publish instructions on that matter, specific to those who appear to be victims of human trafficking.
The respondent has done this by creating a strong presumption against the prosecution of such persons where
there is credible and reliable information to support the fact that the person has been compelled to carry out the
offence as a direct result of trafficking.

[39] The existence of such a discretion meets the requirements of Art 8 of the Directive in so far as it requires

national authorities to be ʻentitled not to prosecuteʼ victims of trafficking who have been compelled to commit a

crime. In this respect, the court agrees with R V JOSEPH, in which the Court of Appeal of England and Wales held
that, in respect of pre **_[Modern Slavery Act 2015 cases, the common law remained compatible with existing](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
international obligations, not just Art 26 of the WARSAW CONVENTION with its focus on penalties, but also Art 8 (cited
para 14). The Art 26 obligation had, in terms of the previous case law, been given effect through: (1) the common
law defences of duress and necessity; (2) guidance to prosecutors on the exercise of the discretion to prosecute;
and (3) the power of the court to stay a prosecution for an abuse of process (para 20(i)), but the Court also noted
(para 20(ii)) the place of prosecutorial discretion, the context of which is Art 8. The situation is not materially
different in Scotland.

[40] First, there is vested in the respondent a general discretion not to prosecute. This is transmitted to prosecutors
along with a specific instruction which provides a strong presumption against prosecution where a person has been
compelled to carry out the offence as a direct effect of trafficking. Although the court may give due deference to the
respondent in taking a decision to prosecute, that decision could be reviewed by the court where an accused
advances a plea in bar of trial on the grounds of oppression. Such a review may very well succeed if, for example,

the decision had been taken without regard to the respondentʼs instructions or if any prospective trial would

inevitably be unfair (BUTT V SCOTTISH MINISTERS, Lord Justice-Clerk (Carloway), para 16) having regard to the terms


-----

of any international obligations or EU law. However, no grounds have been advanced to suggest that the decision
to prosecute the minuter was not properly taken in the context of the presumption contained in the instructions. The
material available suggests that
**[*207]**

there were significant factors pointing away from the minuter having been trafficked in favour of him being a willing
economic migrant.

[41] As in England, there is no blanket immunity from prosecution for victims of trafficking. Various factors require to
be taken into account when deciding whether to prosecute, including the gravity of the offence. Each case will turn

on its own facts and circumstances but, unless there is material to contradict the respondentʼs findings or to

demonstrate that significant evidence has been ignored by him, then, as in England (R V JOSEPH, para 20(viii), citing
**_R V L, para 28), the courts would be unlikely to stop the prosecution at a preliminary stage._**

[42] Secondly, the common law in relation to coercion is available if the circumstances reveal that an accused has
been coerced into carrying out the cultivation of cannabis under threat of violence. It is important to observe that the
_locus classicus (THOMSON V_ **_HM_** **_ADVOCATE) was concerned with the robbery of a Post Office sorting-office using_**
firearms. It was rather different from the more placid, but time consuming crime of cultivating cannabis. In the
context of a single violent act, committed in a place accessible through public spaces where resort to the forces of
law and order will normally be possible, there is a need for any coercion to involve a threat of immediate serious
violence. As was made clear in THOMSON (Lord Justice-Clerk (Wheatley), delivering the opinion of the court, p 78),

ʻthe defence of coercion is normally only open when it is based on present danger from present threatsʼ (emphasis

added). It is properly tested having regard to: (1) the existence of immediate danger of violence; (2) the absence of

an ability to resist or avoid the danger; (3) the extent of the accusedʼs role in the crime; and (4) the disclosure of the

fact of coercion, and the return of any proceeds of the crime, on the first safe and convenient occasion. The third
and fourth elements are not essential but are rather factors to be included in the assessment of the credibility and
reliability of the primary account. Throughout **_THOMSON, as in the passages in_** **HUME (Commentaries, i, 53) cited,**

there are repeated qualifications using the words ʻnormallyʼ or ʻgenerallyʼ. It will always be a matter of facts and

circumstances whether a person was truly coerced (or compelled) to commit a crime by virtue of genuinely
anticipated and unavoidable violence.

[43] In the case of cannabis cultivation, for example, if the farmer is confined to a flat in which the cannabis is
grown, and has reasonable grounds for believing that, if he does not tend to the crop, he will be seriously injured on
the arrival of those controlling the operation, the defence may well be made out. THOMSON correctly stressed (p 78)
the need, as in the related defence of self-defence, to strike a fine balance between the nature of the danger
threatened and the seriousness of the crime. Nevertheless, there may be circumstances in which a person is
exposed to a threat of violence to himself or a third party from which he cannot be protected by the forces of law
and order and which he is not in a position to resist. Where such a situation arises, as it may do in a trafficking
situation, its effect in law would have to be assessed on its particular facts.

[44] Thirdly, even if the circumstances do not amount to the defence of coercion, they may nevertheless provide
powerful mitigation. It will be a matter for the minuter to decide whether to plead not guilty and to run a defence of
coercion. If the matter goes to trial and the jury reject coercion as a defence, the minuter can still maintain that he
was nevertheless trafficked and that that had a bearing on the degree of his culpability. The fact that the jury have
not been asked to rule on the fact of trafficking or its effect, other than in the context of coercion, has no bearing on

the sheriffʼs ability to assess that fact and its bearing. As with many potential

**[*208]**

mitigating factors, the sheriff is entitled to form a view based upon the evidence heard. This may include the
testimony of the minuter himself. If he or she has not given evidence prior to a guilty verdict or he or she elects to
plead guilty, he or she can still make such submissions about his or her personal circumstances (including being a
victim of trafficking) as he or she wishes. If there is a material issue of disputed fact, he has the option of a proof in


-----

mitigation. In all of these various situations, the sheriff has a discretion to reduce what would otherwise normally

have been the appropriate sentence. The sheriffʼs concerns in this area are misplaced and the contention that a

proof in mitigation is not an effective mechanism is rejected.

[45] In a case such as the present, where there are established parameters in relation to sentences for cannabis
cultivation (LIN V **_HM_** **_ADVOCATE), a significant reduction in the level of custodial sentence may be appropriate. In_**
[other situations, a non-custodial disposal may be imposed. In some, an absolute discharge might be given (Criminal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y03Y-00000-00&context=1519360)
_[Procedure (Scotland) Act 1995 (cap 46), sec 246), in which case there is in effect no conviction other than for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y03Y-00000-00&context=1519360)_
specific purposes (sec 247). What is clear is that the sheriff has a wide discretion in deciding what, if any, penalty
should be imposed where the person convicted has been a victim of trafficking and this has encouraged him or her
to commit the offence, albeit that the common law defence of coercion has not been made out.

[46] The court will answer each question in the reference in the negative.
**Postscript**

[47] This case was indicted for a trial diet in August 2016. When the matter called at the first diet on 3 August 2016,

the trial diet was postponed to 3 October with 7 September being a ʻfurtherʼ first diet. This was said to be in order

that ʻfurther discussionsʼ take place regarding a potential Home Office decision. On 7 September 2016, it was said

that the case was likely to proceed to trial and the outstanding matters were continued to that diet. On 14 October,

the trial diet was postponed until 20 February to allow ʻfurther investigationsʼ with a ʻfirst diet and hearingʼ on the

preliminary minutes allocated for 30 January 2017. On the latter date the ʻevidential hearingʼ was continued until 13

February to allow time to consider the Home Office decision. On 13 February, the hearing was discharged because

the decision was still awaited. A new diet of 20 February was set for an ʻevidential hearingʼ with a trial diet on 27

February. On 20 February, the trial diet was postponed to 3 April 2017 and a ʻcontinued first diet and debateʼ

assigned for 13 March 2017. On the latter date, the compatibility minute was continued to the trial diet, with a new

diet for other preliminary issues assigned for 27 March. On the latter date, an undertaking not to use the ʻpolice

interviewʼ at the trial was given. On 12 April 2017, the trial diet was ʻadjournedʼ to 18 July 2017, and a first diet

assigned for 30 June 2017. A ʻfurther first dietʼ was fixed for 10 July and that was also to form an evidential hearing

relative to the compatibility minute. The case ultimately called on 10 July, when argument was finally heard.
Throughout this period, extensions of the 12-month time-bar were granted, with the last one being to 4 December
2017.

[48] Perhaps the most remarkable element of the procedure is the fact that the case called before 11 different
sheriffs over a period of almost a year before argument was heard and a reference made. Such a delay is
unacceptable and is not justified by the various explanations, some of them repetitive, minuted. It is
**[*209]**

particularly regrettable in a case of this type where the issue of trafficking was raised. The conduct of the first diets
appears to have repeatedly contravened the clear terms of the **CRIMINAL** **COURTS** **PRACTICE** **NOTE NO** **3 OF** **2015**
concerning sheriff court solemn procedure, notably the direction that preliminary pleas and issues ought to be dealt
with at the (first) first diet and not continued repeatedly, sometimes to another first diet and often to a trial diet which
ultimately, and not surprisingly, did not take place. It is disturbing to note the large number of sheriffs who appear to
have allowed this to occur.

The Court remitted the case to the sheriff.
1

On 25 April 2018 after trial the minuter was acquitted


-----

**End of Document**


-----

