# R v DKN  [2021] EWCA Crim 353

CA, CRIMINAL DIVISION

202001548 B5

Males LJ, Goose J, HHJ Aubrey

Friday, 19 February 2021

19/02/2021

(Transcript produced without documentation)

LORD JUSTICE MALES:

1 This is an appeal out of time against a conviction for producing a controlled drug of class B, namely cannabis, as

a result of the appellant's guilty plea on 18 January 2016 in the Crown Court at Kingston‑upon‑Thames. It has been

referred to the full court by the registrar.

2 The first matter to deal with is the issue of anonymity. The applicant makes an application for an order for
anonymity under section 11 of the Contempt of Court Act 1981. In accordance with the principles set out in the
case of R v L; R v N [2017] EWCA Crim 2129, we are satisfied that this is an appropriate case for such an order.
Accordingly, we order that the applicant be referred to by initials, DKN, and that his name and identity must not be
published.

3 The conviction arose as a result of police execution of a search warrant on 7 September 2015 at an address in

Surbiton. The applicant and co‑accused were found in the loft of the property, which had been converted into a

cannabis farm with high powered lighting and ventilation systems and with the electricity supply having been
bypassed in a dangerous manner. Approximately 300 cannabis plants at varying stages of development were
seized.

4 The applicant was arrested and interviewed. He answered "no comment" to all questions asked, and in due
course pleaded guilty on a basis stating that he was illegally in the United Kingdom, could not therefore obtain
lawful employment and so agreed to work at the house because he was promised food and accommodation. He
was sentenced to 13 months' imprisonment. The sentencing judge found that the farm was a professional and
substantial commercial operation. However, he was satisfied that the applicant held a lesser role and was acting
under the direction of others with no influence on those above him in the chain.

5 At that time those representing the applicant identified a number of factors suggesting that he was a victim of
trafficking, but were not aware of the possibility of a defence under section 45 of the Modern Slavery Act, which
had only just come into force. Accordingly, those factors were relied upon by way of mitigation, but it was not
suggested that the applicant had or might have a defence. That point was therefore overlooked altogether and was
not drawn to the sentencing judge's attention.

6 There followed a fairly convoluted and drawn out procedure after the applicant had served his sentence,
including a referral to the NRM and a number of decisions to do with the applicant's immigration status. It is not


-----

necessary to set out the detail, but it culminated eventually in an appeal to the first tier tribunal. The first tier tribunal
found that the applicant was a victim of trafficking. We set out the key findings of that decision:

"After two months in the nail bar, he was forced out onto the streets. The CA [Competent Authority] points out that
he could have gone to the authorities at this point. Having read the [applicant's] further witness statement and
noting that he had been kept under house arrest during the entire period of transit and forced employment at the
nail bar, I find it reasonable that he would not be in a position to seek out the support of any of the authorities and
would instead be at the mercy of whoever next crossed his path, whether their motives were good or ill. The
circumstances of his time spent cultivating, bears the hallmark of forced labour in that the applicant was prevented
from leaving the premises, exploited by being forced to look after the cannabis plants, and given no wage. The
applicant's further witness statement makes clear that both the first and the second house were prisons to him and
in this regard I prefer the full evidence, as contained in the applicant's further witness statement.

In contrast to the CA decision … I find that the applicant did not enter into criminal behaviour willingly in order to
secure accommodation, but rather that his vulnerability was exploited by others for criminal gain. The expert report
finds that the applicant's account of his experiences is a plausible account of human trafficking, and strongly

indicates that he was trafficked to and within the UK. I note too that the expert report was based on a three‑hour

interview with the applicant."

7 It is that decision which has given rise to this appeal, and the fact that the process took a considerable time
before it culminated in that decision is the explanation for the delay in making this application. Accordingly, we
grant the necessary extension of time. There is also an application to admit as fresh evidence the decision of the
first tier tribunal. We grant that application.

[8 So far as the merits of the point are concerned, by section 45 of the Modern Slavery Act 2015 which came into](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
force on 31 July 2015, a person is not guilty of an offence if he is aged 18 or over at the date of the act which would
otherwise be an offence, he does the act because he is compelled to do it, the compulsion is attributable to slavery
or to relevant exploitation, and a reasonable person in the same situation as the person and having the person's
relevant characteristics would have no realistic alternative to doing it.

9 Mr Douglas‑Jones QC for the applicant submits that he would have had a defence under section 45 in the

circumstances which we have briefly outlined, and that submission is accepted by Mr Johnson on behalf of the
prosecution, who in a helpful respondent's notice has explained that the respondent does not object to any of the
applications to which we have so far referred and which we have granted, that each of the elements of the section
45 defence is made out, and that the prosecution would likely not have been able to discharge the burden of
disproving the section 45 defence. The prosecution, therefore, concedes that the applicant was deprived of a
defence that quite probably would have succeeded, and does not oppose the appeal. While the safety of the
conviction is ultimately, of course, a matter for this court, we too are satisfied that in the circumstances the
conviction is unsafe, and therefore, that the appeal must be allowed. Accordingly, we grant leave to appeal, allow
the appeal and quash the conviction.

______________

**End of Document**


-----

