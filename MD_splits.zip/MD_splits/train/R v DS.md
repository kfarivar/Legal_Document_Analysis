# R v DS [2020] EWCA Crim 285

Court of Appeal, Criminal Division

Lord Burnett LCJ and Edis and Johnson JJ

28 February 2020Judgment

**Mr B. Douglas-Jones QC and Mr. D. Bunting (instructed by The Crown Prosecution Service, South**
**East Complex Case Unit) for the Crown**

**Mr. H. Blaxland QC and Mr. L. Sergent (instructed by GT Stewart, Solicitors) for the Respondent**

Hearing dates: 26th February 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**ON 12th March 2020 THE COURT ORDERED that** **_[section 71(1) of the Criminal Justice Act 2003,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9KP0-TWPY-Y013-00000-00&context=1519360)_**
**shall not apply to the title of this judgment and to paragraphs 2, 39, 40 and 47 of this judgment which may**
**be reported.**

**On 31st March 2020 THE COURT ORDERED that** **_[section 71(1) of the Criminal Justice Act 2003,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9KP0-TWPY-Y013-00000-00&context=1519360)_**
**shall not apply to the text of the judgment as it appears below, by reason of the pleas of guilty now entered**
**by DS. Other proceedings against other persons including the person named below as “X” remain**
**outstanding.**

**Lord Burnett of Maldon:**

1. This is an appeal by the prosecution under section 58 of the Criminal Justice Act 2003 against a ruling
by HHJ Griffith-Jones QC of 14 January 2020 in the Crown Court at Maidstone. Reporting restrictions
apply to it until the conclusion of the Crown Court proceedings to which it relates. The respondent, DS,
has now passed his 18th birthday and is not entitled to anonymity by reason of his age.

2. At the conclusion of the hearing on 25 February 2020 we announced our decision. We gave leave to
appeal, allowed the appeal and directed the proceedings to continue in the Crown Court.

3. The judge ordered that proceedings against DS should be stayed as an abuse of the process of the
court. The proceedings were brought on an Indictment containing two counts of possession of class A
controlled drugs between 1 and 14 March 2018. Count 1 related to crack cocaine and Count 2 to heroin.
He had pleaded not guilty on 31 July 2019 and the court had directed that a referral should be made under
the National Referral Mechanism for potential child victims of modern slavery. This caused some delay in
the proceedings but resulted in a “conclusive grounds” determination of the Single Competent Authority
(“The Authority”) under the National Referral Mechanism dated 6 November 2019. The Authority
decided on that date that DS is a “Victim of Modern Slavery”. This decision was based on a statement
from him which said that he had been recruited as a homeless child into a “county line” drug dealing
network as a street level dealer, and that he would be subject to violence and threats if he did not continue.
DS is a British citizen. He had been living with his mother and stepfather and attending full time education
until he left home and became involved in the supply of Class A drugs On 16 December 2019 DS served


-----

a defence statement which admitted that he had carried out the acts alleged, and was guilty of the
offences, subject to the defence afforded by section 45(4) of the **_Modern Slavery Act 2015 (“the 2015_**
**Act”). He relied on the account he had given to the authority which was annexed to the statement. His**
counsel also submitted an application for an order staying these proceedings. Skeleton arguments were
exchanged and the hearing of the application took place on what would otherwise have been the first day
of the trial.

**The legal context**

4. The case concerns the approach of domestic law to the international obligations of the United Kingdom
in relation to the treatment of victims of trafficking and **_modern slavery. Although this is well-travelled_**
territory in a series of decisions of this court, it is worth briefly summarising the relevant material.

5. Article 4 of the European Convention on Human Rights is the starting point. This prohibits slavery and
forced labour. Domestic case law on when it is appropriate to prosecute a credible victim of human
trafficking has evolved from: (i) the Council of Europe Convention on Action Against Trafficking in Human
_Beings 2005 (CETS No 197) (“the Convention”), in particular Article 26; and (ii) EU Directive 2011/36/EU_
_on preventing and combating trafficking in human beings and protecting its victims_ (“the Directive”), in
particular Article 8. The two most relevant provisions, in relation to the non-prosecution of trafficked
individuals for offences committed whilst they were subject to trafficking, read as follows:

“Article 26 of the Convention – Non-punishment provision

Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

“Article 8 of the Directive, Non-prosecution or non-application of penalties to the victim

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of human trafficking in human beings for their involvement in criminal activities which they have
been compelled to commit as a direct consequence of being subjected to any of the acts referred to in
Article 2.”

6. Prior to the enactment of the 2015 Act, there was no domestic statutory reflection of the United
Kingdom's obligations under the Convention and the Directive. As such, the UK's obligations in this respect
were adhered to by means of – (i) relevant CPS guidance, which indicated the capacity of, and the
circumstances in which, a prosecutor could decline to proceed against an individual suspected of being a
victim of trafficking; (ii) where available, the common law of duress, and (iii) the court's abuse of process
jurisdiction, whereby it could review the CPS' prosecutorial decision, and, in certain cases, refuse to
entertain proceedings. The 2015 Act changed this landscape by placing this system on a concrete
domestic footing.

7. The policy of the CPS (2015) in respect of those not within the scope of the 2015 Act required the
prosecutor to consider three broad questions where the defence of duress did not arise on the evidence.
First, was there credible evidence that the defendant fell within the definition of trafficking in Annex 11 to
the UN Convention against Transnational Organised Crime (the Palermo Protocol) and Directive 2011/36;
secondly, was there a nexus between the crime committed and the trafficking; and thirdly, was it in the
public interest to prosecute?

8. Since the enactment of section 45 of the 2015 Act, which provides a statutory defence for some victims
of trafficking to some offences, that CPS Guidance has changed as we shall describe below. It is
necessary to consider the effect of the 2015 Act and the new Guidance, and the extent to which the role of
the court in its application has changed because of them.

9. It is, we think, unnecessary to distil the authorities in relation to this issue as they stood in relation to
cases which arose before the enactment of the 2015 Act. They have been most recently summarised by
thi t i _R_ _JXP [2019] EWCA C i_ _1280_ t [36] b Ni l D i LJ i i th j d t f th t


-----

and we respectfully adopt that analysis. This is the first time this court has had to consider the position in
relation to cases to which the 2015 Act applies, and the issues we have to decide are not directly covered
by authority.

**The Facts**

10. DS was born on 7 November 2000 and was 17 at the date when he possessed class A controlled
drugs with intent to supply them. He was 18 in November 2018.

He was arrested in relation to this Indictment on 13 March 2018 when he was the passenger in a car being
driven by another man who has pleaded guilty to the same offences as those he faces. The car was found
to contain 19 individual deals of heroin and 24 individual deals of cocaine, plus larger undivided packages
of heroin and cocaine. The street value was between £1,050 and £2,010. His DNA was found in the inner
packaging of the drugs. He had two mobile phones in his possession, one with a “tick list” in the Notes and
one with a number of text messages about the supply of Class A drugs. He made no comment in
interview. The seriousness of this offence is a relevant factor for the issues before us. This, on the face of
it, is a significant role in street level supplying for which the relevant sentencing guideline provides a
starting point of 4 years 6 months and a range of 3 years 6 months to 7 years. The age of DS would be a
strong mitigating factor. He had no convictions at the time of the offence, but was subsequently convicted
of offences of violence against the police which were committed on 27 May 2018. He was further arrested
on two further occasions after he turned eighteen, and there are two more sets of proceedings pending
against him.

11. When the Authority made its decision on 6 November, it was incumbent on the CPS under its new
Legal Guidance on Human Trafficking, Smuggling and Slavery1 (“the Guidance”) to review its charging
decision and to apply a four-stage test. That review was carried out on 8 November 2019. It was not
placed before Judge Griffith-Jones, in accordance with the usual CPS policy in relation to disclosure of
charging decisions in pending criminal proceedings. We have seen the document, by agreement between
the parties. It recorded the three sets of allegations of drug dealing against DS, namely those on the
Indictment referred to above, and two other very similar allegations. The first of these involved an arrest of
DS on 13 February 2019 with others in a car. The drugs were Class A drugs and their value was £2,660£5,320 and phones were recovered with similar content to the first. Cash was also recovered. The second
additional arrest was on 10 June 2019 and again involved a car, heroin and cocaine. This time DS was the
driver and cash drugs and phones were seized as before. Although the Judge did not have the review
decision, he did know that there were other cases, involving offences committed when DS was no longer a
child. The review concluded that the case should continue. The Judge was aware of the conclusions
reached by the prosecutor which he recorded as follows:
“This was on the basis that

a) There was no clear evidence of a credible common law defence of duress or of a statutory defence
under the 2015 Act; and

b) It was in the public interest to continue the decision.”

**The National Referral Mechanism history**

12. DS was first referred to the National Referral Mechanism on 22 March 2017. He had come to the
attention of the Youth Offending Team because of an allegation that he had assaulted his mother when
she was trying to stop him going out to see his friends. There was intelligence that he was involved in drug
or gang activity. Information was assembled which suggested that he was involved in dealing in drugs for
significant amounts of cash. He was not attending school because, he said, he was vulnerable to attack
there because of a drug debt. There had been a number of reports to the police that he was a missing
person. A “reasonable grounds” determination was made on 8 May 2017 that he was a Victim of
Trafficking, but the conclusive grounds decision on 27 November 2017 was that he was not. He did not cooperate with this referral. The National Crime Agency, then dealing with the case as Competent Authority,
said:

-----

“[DS] is not making any disclosures, his account of events does not appear to be externally corroborated,
there is no mention of him being coerced, forced or threatened but is believed to be choosing his current
lifestyle. I am therefore not satisfied that on balance, [DS] has been subjected to “exploitation” as per the
trafficking definition and the 'Service' element of the definition of slavery, servitude and forced or
compulsory labour.”

13. This decision was part of the history when the second referral was made as a result of the court's
intervention as we have recorded above. On this occasion DS did co-operate and supplied the Authority
with a statement, the one which was later attached to his defence statement. In summary, this said that he
had moved to Kent in 2011. His parents had split up when he was very young and by the time they moved
to Kent his mother was in a relationship with his stepfather. This relationship had caused problems for DS,
and eventually he was asked to leave home. He took to sleeping in train stations and

“….then a mutual friend said he knew someone who could help, but I would have to deal drugs for him. I
agreed, I know now I shouldn't have and wish I could turn back time but I had no food, no bed, no money. I
was 16 when I first approached him and then turned 17 shortly after. …”

14. He went on to describe how he was “trained up” by someone working on behalf of “Jimmy”, and how
he stayed in the houses of “customers” who were users and who got free drugs in return. He was
expected to be up and working by 09.00 or someone would come and shout at him. He was expected to
sell £500 or £1,000 worth of drugs a day and he was paid 10%. He was supplied with a “burner phone” for
selling the drugs. The accommodation with the customers was very unpleasant and squalid, and he was
subjected to violence from them on occasions. He viewed Jimmy and his co-defendant as his family, and
his life was at risk from rival dealers. Jimmy was violent and made regular threats to DS and others, and
also protected them from other people. He said

“When I was first put into contact with Jimmy he was only doing Gravesend and now he runs 3 different
areas. You would never know where Jimmy lived. He moves around. During the day he would be in one
house and then sleep in another. All the customers/drug users are scared of him – if a customer goes to
another dealer he will go crazy at that customer and beat them up. He thinks he owns Gravesend. There
is no other dealer that is not his friend.”

15. This resulted in the Authority's conclusive ground decision of the 6 November 2019. The Judge
commented:

“It is apparent that the Competent Authority considered that the defendant's earlier failure to disclose
information was understandable and could be explained by the very circumstances which gave rise to its
conclusive determination.”

16. By the time the matter was before the Judge, it appeared to be agreed that DS was actually describing
the man by whom he had been threatened by using another name for which we shall substitute “X” and
that the name “Jimmy” was the name of the county line which X operated.

**The proceedings and ruling in the Crown Court**

17. The Judge was dealing only with an application to stay the first Indictment (from March 2018). He
gave a written ruling in which he set out the effect of section 45 of the 2015 Act, summarised the nature
and purpose of the National Referral Mechanism, and set out the relevant history. He cited paragraphs

[14], [17], [28] and [33] of the judgment of the court presided over by the Lord Chief Justice in R v. L and
_others_ _[2013] EWCA Crim 991 about the nature of the jurisdiction to stay in_ **_modern slavery cases and_**
about the way in which the court will treat the decision of the Authority under the National Referral
Mechanism. These passages are:
“14. In the context of a prosecution of a defendant aged under 18 years of age, the best interests of the
victim are not and cannot be the only relevant consideration, but they represent a primary consideration.
These defendants are not safeguarded from prosecution or punishment for offences which were
unconnected with the fact that they were being or have been trafficked, although we do not overlook that
the fact that they have been trafficked may sometimes provide substantial mitigation. What, however, is


-----

required in the context of the prosecutorial decision to proceed is a level of protection from prosecution or
punishment for trafficked victims who have been compelled to commit criminal offences. These
arrangements should follow the “basic principles” of our legal system. In this jurisdiction, that protection is
provided by the exercise of the “abuse of process” jurisdiction.”

“17. ……For the reasons we have already given, no such danger exists. In the context of an abuse of
process argument on behalf of an alleged victim of trafficking, the court will reach its own decision on the
basis of the material advanced in support of and against the continuation of the prosecution. Where a court
considers issues relevant to age, trafficking and exploitation, the prosecution will be stayed if the court
disagrees with the decision to prosecute. The fears that the exercise of the jurisdiction to stay will be
inadequate are groundless.”

“28…….We are asked to note that the number of concluded decisions in favour of victims of trafficking is
relatively low, and it seems unlikely that a prosecutor will challenge or seem to disregard a concluded
decision that an individual has been trafficked, but that possibility may arise. Whether the concluded
decision of the competent authority is favourable or adverse to the individual it will have been made by an
authority vested with the responsibility for investigating these issues, and although the court is not bound
by the decision, unless there is evidence to contradict it, or significant evidence that was not considered, it
is likely that the criminal courts will abide by it.”

“33. As we have already explained, the distinct question for decision, once it is found that the defendant is
a victim of trafficking, is the extent to which the offences with which he is charged, or of which he has been
found guilty, are integral to or consequent on the exploitation of which he was the victim.”

18. The Judge recorded the rival submissions about the decision of the Authority. On behalf of DS it was
suggested that the decision should be respected and that some additional support for it could be found in
the unused material. For the prosecution it was submitted that the Authority's conclusion appeared to have
been reached without any testing of DS's account which should not simply have been accepted at face
value. The prosecution submitted the CPS review had applied the rigorous four stage test set out in the
Guidance. The purpose of this is to ensure that prosecutors properly apply in this context the Full Code
Test in the Code for Crown Prosecutors. A link is given in the first footnote above to the Guidance where
further material is set out, but the Guidance summarises the four-stage approach follows:

**“A four-stage approach to the prosecution decision**

When applying the Full Code Test in the Code for Crown Prosecutors, Prosecutors should adopt the
following four-stage assessment:

1. Is there a reason to believe that the person is a victim of trafficking or slavery?

If yes, move to Question 2.

If not, you do not need to consider this assessment further.

2. Is there clear evidence of a credible common law defence of duress?

If yes, then the case should not be charged or should be discontinued on evidential grounds.

If not, move to Question 3.

3. Is there clear evidence of a statutory defence under Section 45 of the Modern Slavery Act 2015?

If yes, then the case should not be charged or should be discontinued on evidential grounds.

If not, move to Question 4.

4. Is it in the public interest to prosecute? Even where there is no clear evidence of duress and no clear
evidence of a s.45 defence or where s.45 does not apply (because the offence is excluded under Schedule
4) this must be considered. In considering the public interest, Prosecutors should consider all the
circumstances of the case, including the seriousness of the offence and any direct or indirect compulsion
arising from their trafficking situation; see R v LM & Ors [2010] EWCA Crim 2327.”


-----

19. The Judge recorded that the parties agreed that the law he had to apply was to be found in R v. L and
_others, cited above, and said that in paragraph [17] of that decision the court had “inferred that in cases_
where the court concluded that offences were a manifestation of the exploitation of a Victim of Trafficking
the court would usually step in and stay a prosecution”. We have cited the actual text above, and with
respect to the Judge, do not consider that this is what paragraph [17] means. We shall return to this
paragraph below.

20. The Judge summarised the prosecution position before him, which was that the Authority's decision
was wrong, rather than that the offences were not consequent upon the exploitation which the Authority
had found. He directed himself by reference to paragraph [28] of _R v. L & Others, set out above, and_
decided that there was no evidence to contradict it and no evidence which had not been considered. That
being so, he decided that he should “abide by” the decision of the Authority. The Judge exercised his own
judgment in relation to the facts in this regard and identified some evidence which supported the Authority
decision. He rejected the submission that the Authority had simply and uncritically accepted the account of
DS. He said that it was supported by all the material which had been gathered at the time of the first
referral which, in the absence of anything from DS, had not been enough, but which was all consistent with
what he had now said.

21. There was evidence which had not been considered by the Authority, contained in telephone
conversations between DS and X while DS was on remand, in which DS had asked X for money. It was
conceded that this material did not amount to significant evidence apt to undermine the Authority's
determination. We also have seen this material, which does tend to show an amicable relationship
between DS and X. The Judge then said

“In conclusion therefore I take the view that the Competent Authority's determination was sound and that,
taking account of all the circumstances including the defendant's age and the proximity of these alleged
offences to the exploitation which gave rise to the determination that he is a Victim of Trafficking, I take the
view that this prosecution should not continue.”

22. This conclusion, he said, was specific to the prosecution of the particular indictment before him, and
that different considerations may apply to the later cases. It will be noted that the Judge did not go on to
consider whether it is in the public interest that DS should be prosecuted even if the Authority's decision as
to his status is correct.

**The prosecution decision**

23. The Draft Review Note of the Prosecutor's decision to maintain the prosecution of the respondent has
been placed before this court by agreement. It enables us to check for any significant departure from the
Guidance which if present, might assist DS's case. As appears above, although he had not seen the
document, the Judge was aware of the material it considered and of its conclusion. The prosecutor closely
follows the four-stage assessment under the CPS Guidance, conducting an evidential review at stages one
to three. She felt entitled to deviate from the 2019 Conclusive Grounds decision on the basis of the
Guidance, which relies on the passage cited above in paragraph [28] of _R v. L & Others, followed in_
paragraph [20](viii) of R v Joseph (Verna) _[2017] EWCA Crim 36. The Guidance says:-_

“Prosecutors should:

    - Take into account an NRM decision;

    - Consider a conclusive grounds decision to be of more weight than a reasonable grounds decision;

    - Make enquiries, where there is a reasonable grounds decision only, about when a conclusive decision is
likely to be made; and

    - Examine the cogency of the evidence on which the Competent Authority (CA) relied. The decision of the
CA as to whether a person had been trafficked for the purposes of exploitation is not binding on the Crown
Court or the CPS. Unless there was evidence to contradict it or significant evidence that had not been
[considered, it is likely that the criminal courts will abide by the decision; see R v L(C) [2014] 1 All ER 113 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)
_[28](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_ d R VSJ [2017] 1 WLR 3153 t t 20( iii) Th d i i h ld b ti i d b th t t


-----

see to what extent the evidence has been analysed, weighed and tested by the CA and to assess the
quality of any expert evidence relied upon.”

24. The passage underlined in that citation does not derive from authority, but we consider that it is a
legitimate approach for a prosecutor to take.

25. As to stage one of the four-stage test, the prosecutor believed that the case as to trafficking was not
made out, essentially on the basis that she felt that the respondent could not be said to have been a victim
of coercion, duress or similar on account of his voluntary adoption of the lifestyle that had led to the
relevant offending. She noted the length of the respondent's involvement in drug-related activity. In her
view, he had other options available to him against the background of his mother's and the authorities'
concerns. The prosecutor considered all three instances of offending, noting that because the latter two
instances post-dated the respondent's 18th birthday he would have to meet a stricter statutory test under
section 45(1) of the 2015 Act to make out a statutory defence.

26. Stages two and three concern the available defences, common law duress at stage two and the
statutory defence under section 45 of the 2015 Act at stage three. It is not suggested that duress applies
in this case, but DS has advanced section 45 in his defence statement. Section 45 came into force on 31st
July 2015 and provides:
**45 Defence for slavery or trafficking victims who commit an offence**

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5) For the purposes of this section—

_“relevant characteristics” means age, sex and any physical or mental illness or disability;_

_“relevant exploitation”_ is exploitation (within the meaning of section 3) that is attributable to the exploited
person being, or having been, a victim of human trafficking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.

(8) The Secretary of State may by regulations amend Schedule 4.


-----

27. The prosecutor concluded that there was no clear evidence to show that the prosecution would fail to
prove that this defence applied, and therefore concluded that the evidential test in the Code for Crown
Prosecutors was met.

28. The public interest falls to be considered at stage four. The Guidance as to the assessment of the
public interest, says:
“Stage 4: Is it in the public interest to prosecute?

The Public Interest and Compulsion

'Compulsion' includes all the means of trafficking defined by the United Nations Protocol on Trafficking
(The United Nations Convention against Transnational Organised Crime 2000 supplemented by the
Protocol to Prevent, Suppress and Punish Trafficking in Persons): threats, use of force, fraud and
deception, inducement, abuse of power or of a position of vulnerability, or use of debt bondage. It does not
require physical force or constraint.

For a child to be a victim of trafficking, the means of trafficking are irrelevant. Where a child is recruited,
transported, transferred, harboured or received for the purpose of exploitation, s/he is a victim of trafficking.

Compulsion is irrelevant insofar as a child's status as is a victim of trafficking is concerned. However,
compulsion will be a relevant consideration when considering whether the public interest in prosecuting a
child is satisfied. (see Code for Crown Prosecutors, paragraph 4.14 b) for further guidance).

The means of trafficking/slavery (i.e. the level of compulsion) may not be sufficient to give rise to defences
of duress or under Section 45 but will be relevant when considering the public interest test.

In considering whether a trafficking/slavery victim has been compelled to commit a crime, Prosecutors
should consider whether a suspect's criminality or culpability has been effectively extinguished or
diminished to a point where it is not in the public interest to prosecute.

A suspect's criminality or culpability should be considered in light of the seriousness of the offence. The
more serious the offence, the greater the dominant force needed to reduce the criminality or culpability to
the point where it is not in the public interest to prosecute; see R v VSJ & Ors [2017] EWCA Crim 36, see
also R v GS _[2018] EWCA Crim 1824.”_

29. The prosecutor made two observations about the public interest in maintaining a prosecution against
DS. First, the offences were serious, involving significant quantities of drugs demonstrating that the
respondent must be at a “medium level” in the hierarchy and a “trusted supplier”; and secondly, DS had
gone on to reoffend each time he had been arrested.

**The challenge**

30. For the prosecution it is, in outline, submitted that:

i) The Judge was wrong to hold that the CPS and the court, should have “abided by” the decision of the
Authority. He should have taken the view that it was open to the Crown to seek to challenge it.

ii) The Judge was wrong to entertain the application for a stay on the basis identified in R v. L & others
because by enacting section 45 Parliament has decided how to give effect to the United Kingdom's
international treaty obligations and the kind of jurisdiction which was formerly required no longer is. An
application in a post 2015 Act case should be limited to a conventional challenge to a prosecutor's decision
on public law grounds, unless a classic abuse of process has occurred.

iii) The Judge failed to appreciate that the enactment of section 45 had changed the nature of the function
of the jurisdiction he was being asked to exercise.

iv) The Judge misunderstood _R v. L & others where he paraphrased its effect as summarised at [17]_
above. That is not what it says. For this reason, he confined himself entirely to the question of whether DS
was a Victim of Trafficking and whether his offending was very closely linked to that exploitation. In fact,
an answer favourable to DS on stage one was not determinative and the CPS were right, and the Judge


-----

was wrong, to continue to consider stages two, three and, in particular, four. The Judge does not mention
the public interest at all.

v) The Judge was wrong to treat the March 2018 offences in isolation and to regard the subsequent
offending as simply irrelevant to whether the prosecution for the March 2018 offending should continue.
The CPS was right to view the totality of the offending and to decide whether it was in the public interest
that DS should be prosecuted. If he is to be prosecuted for any of it, why not for all of it?

31. It is fair to observe that the Judge approached the case on the basis on which he was invited to
approach it by counsel who then appeared for the prosecution. He did not submit that the law as stated in
_R v. L & Others requires reappraisal in the light of the new statutory defence. He limited himself to a_
factual challenge to the Authority decision. He did not deal with the public interest as a separate issue and
did not, as he might have done, invite the Judge to decline to hear the application unless he was able to
consider the case overall, that is to take into account and decide upon the future of all three arrests.

**Submissions**

32. Mr. Douglas-Jones QC, on behalf of the prosecution accepted that DS may well be victim of
exploitation. He submits that the issues on this appeal are

i) What weight should the prosecutor give to untested, self-serving and hearsay evidence when it had
been accepted by the Authority and was the basis of the Conclusive Grounds decision.

ii) Should there be a safety net for cases where the statutory defence under section 5 of the 2015 Act is
available, by way of what he described as a “vestigial” abuse of process jurisdiction to stay proceedings

iii) If so, what is the nature of that jurisdiction? Is it a review of the decision to prosecute, and, if so, how
should it be reviewed?

33. As to those issues, he submits:
i) The nature and quality of Conclusive Grounds decisions means it is often appropriate for the CPS to
adopt them but not always. The safest approach was to assess whether a defendant was a Victim of
Trafficking by reference to Article 2 of the Convention, and not domestic law.

ii) The prosecutor must consider evidential sufficiency in all cases, by reference to the common law
defence of duress and the section 45 defence.

iii) The public interest must always be considered by reference to the status of the defendant in any event.

iv) There is no longer any need to have recourse to a “safety net” of abuse of process.

v) It is only if oppression exists that a court would review a charging decision using its abuse of process
jurisdiction. He referred us to Sharma v. Browne-Antoine [2007] 1 WLR 780and R (Barons Pub Company
_Limited) v. Staines Magistrates'' Court v. Runnymede Borough Council & the Director of Public_
_Prosecutions [2013] EWHC 898 (Admin) to make good and explain this submission._

34. Mr. Douglas-Jones advanced his submissions under eight subject areas:
i) International law. He explained the context as we have described it above.

ii) He referred us to the CPS Guidance.

iii) Section 45(4)(b) of the 2015 Act, which requires the jury to decide whether a defendant is or has been
a victim of slavery or a victim of relevant exploitation in order to go on to decide whether and to what extent
the offending was a consequence of that fact.

iv) The vestigial nature of abuse of process after section 45.

v) Nature of hearing and standard of review.

vi) Status of Conclusive Grounds decisions by the Authority.

vii) Procedure on review.


-----

viii) Application of these principles to this case.

35. Mr. Douglas-Jones core submissions are:
i) That section 45(4)(b) means that the decision making function in relation to the issue of exploitation
where it arises is now placed on the jury, and not on the Authority and not on the trial judge.

ii) So far as the effect of section 45 on the scope of the court's power to stay proceedings is concerned,
Mr. Douglas-Jones invites us to compare the approach of the courts to Article 31 of the Convention and
Protocol relating to the Status of Refugees before and after the enactment of section 31 of the Immigration
and Asylum Act 1999. R v Uxbridge Magistrates' Court exp Adimi [2001] QB 667and R (Pepushi) v. CPS

[2004] Imm AR 549 reveal a precisely comparable situation to the present, and the court should react in
the same way.

iii) Mr. Douglas-Jones took us to a number of cases in which the courts have said that a challenge to a
charging decision by the CPS in the Administrative Court can only be entertained in very rare
circumstances. Bad faith and oppression would enable such a challenge, perhaps, but otherwise it is for
the CPS to decide what charges to bring and for the criminal court to try them. The passages relied upon
are well-known and do not need to be set out here.

iv) So far as paragraph [17] of R v. L & others is concerned, Mr. Douglas-Jones submits that the Judge
misunderstood it, because he took it in isolation and did not consider paragraph [18] as well, which, he
said, makes it clear that any review would be conducted on _Wednesbury_ grounds. In view of our
conclusion on this appeal it is not necessary for us to decide whether this submission is well founded or
not.

36.  Mr. Henry Blaxland QC for DS identified three issues.

i) The availability of abuse of process after section 45;

ii) The relevance of the Authority's Conclusive Grounds decision;

iii) The test to be applied on abuse of process submission.

37. Mr Blaxland referred us to sections 58 and 67 of the Criminal Justice Act 2003 for the test to be
applied in deciding an appeal of this kind and submitted that there was here no error of law:

i) The submission that the Judge should not have entertained the application to stay in the light of the
section 45 statutory defence was not made to the Judge, and he did not therefore err in failing to address
it.

ii) He submits that there is a tension between Article 10 of the Convention and paragraph 4 of the
Directive, but that they require the United Kingdom to have in place procedures for the protection of Victims
of Trafficking. He referred us to R v. Joseph (Verna) and others _[2017] EWCA Crim 36 [20] for a statement_
of the history of the development of the relevant principles. He submits that the CPS is not bound to follow
a Conclusive Grounds decision of the Authority, but that there must be a rational basis for departing from it.
This did not amount to a form of “fresh evidence” test, although he referred us to paragraph [20(viii)] of
_Joseph where the test applied by the Judge in the present case appears, and which has some of the same_
characteristics as such a test.

iii) He relies on the duty of the court not to act incompatibly with DS's Article 4 ECHR rights, and submits
that this is the origin of the continuing responsibility to stay proceedings as an abuse of process where
necessary in order to give effect to those rights.

iv) He submits that the court does need to exercise some control over decisions to prosecute where there
is a Conclusive Grounds decision, and should not be found to have erred in doing so.

v) He asks how it could be said to be in the public interest to carry on with this prosecution. It is commonly
understood that vulnerable and exploited people are used for the sale of drugs, and it is not unreasonable
on facts of this case where the court is dealing with a child to intervene and stay the proceedings.


-----

38. In reply Mr. Douglas-Jones submits that a Conclusive Grounds decision does not have to be flawed in
some way before the CPS is entitled to invite the court to reach a different conclusion. Such a decision
should be respected but it is a decision for a different purpose, and probably on different evidence.

**Decisions**

39. We begin by making three fundamental observations.

i) The jurisdiction to stay proceedings as an abuse of the process of the court is an important, but limited,
power of a criminal court. It should not be widened in scope to meet particular needs unless there is a very
clear reason for doing so.

ii) The Convention and the Directive are not directly applicable in domestic law. It is for Parliament and
the executive to decide how to give effect to the international obligations of the United Kingdom, and where
it does so by legislation the function of the court is to apply that legislation. The Directive required Member
States of the European Union to put in place arrangements that reflect its requirements. We have not
identified any clear gap between the provisions of the 2015 Act and those obligations, and in our judgment
the CPS Guidance means that the CPS is “entitled” not to prosecute for the purposes of Article 8 of the
Directive. That being so, our primary focus is on the domestic law as found in the common law of duress
and the statutory defence in section 45 of the 2015 Act.

iii) The state's positive obligation under article 4 ECHR has been considered in _Rantsev v. Cyprus and_
_Russia_ (2010) 51 EHRR 1: at [185]: “member States are required to put in place a legislative and
administrative framework to prohibit and punish trafficking. The Court observes that the Palermo Protocol
and the Anti-Trafficking Convention refer to the need for a comprehensive approach to combat trafficking
which includes measures to prevent trafficking and to protect victims, in addition to measures to punish
traffickers.” There is a recognition of the operational choices in terms of priorities and resources that must
be made in this context at [286]. The state's positive obligation to protect victims of trafficking is not
expressed in terms of non-prosecution, see [287]: it “requires States to endeavour to provide for the
physical safety of victims of trafficking while in their territories and to establish comprehensive policies and
programmes to prevent and combat trafficking…”. We do not think that there is any basis for deriving a
positive obligation not to prosecute victims of “forced or compulsory labour” in Article 4 of the ECHR. This,
the court found, is the lowest level of gravity of oppression against which protection is required, below
“slavery” and “servitude”. That is the level of oppression for which DS contends in this case. If any such
obligation did exist, it would be heavily qualified and there is no basis for concluding that the qualifications
found in the common law of duress, and in section 45 of the 2015 Act, and the CPS Guidance are
inadequate so that there is a violation of any such positive obligation under Article 4 ECHR which might
exist.

40. In our judgment, the result of the enactment of the 2015 Act and the section 45 statutory defence is
that the responsibility for deciding the facts relevant to the status of DS as a Victim of Trafficking is
unquestionably that of the jury. Formerly, there was a lacuna in that regard, which the courts sought to fill
by expanding somewhat the notion of abuse of process, which required the Judge to make relevant
decisions of fact. That is no longer necessary, and cases to which the 2015 Act applies should proceed on
the basis that they will be stayed if, but only if, an abuse of process as conventionally defined is found. By
way of summary only, this involves two categories of abuse, as is well known. The first is that a fair trial is
not possible and the second is that it would be wrong to try the defendant because of some misconduct by
the state in bringing about the prosecution. Neither of these species of abuse affected this case, and it
should not therefore have been stayed.

41. That is enough to dispose of this appeal, but some other issues were fully canvassed in argument and
we should refer to some of them. The first is the status which be accorded by the CPS to a Conclusive
Grounds decision by the Authority under the National Referral Mechanism. We consider that the CPS
Guidance stated above correctly states the law and that if it is properly applied the CPS will comply with its
legal obligations. The prosecutor must therefore take a Conclusive Grounds decision by the Single
Competent Authority into account in deciding


-----

i) whether a defendant is a Victim of Trafficking; and

ii) whether the offending has a very close nexus with the exploitation.

42. Under the 2015 Act, the prosecutor is entitled to challenge that Conclusive Grounds decision before
the jury in seeking to rebut the statutory defence and to invite the jury to come to a different decision. If
there is a sound evidential basis on which to do this, it will not be an abuse of process to try. If there is not,
it will still not be an abuse of process, but the Judge will consider any submission that there is no case to
answer. Whether or not a child is in fact a Victim of Trafficking is a matter which the jury is required to
consider under section 45(4)(b). This is an issue which they will have to consider on all properly
admissible evidence, which may include the evidence of the defendant or, if he does not give evidence,
may, if appropriate, include an adverse inference.

43. Whether the decision of the Authority is admissible at all before the jury is an issue which has been
briefly canvassed before us, but we do not think it is right for us to express any view. This is an appeal
under section 58 of the Criminal Justice Act 2003 and the issue we have to decide, and the only issue we
can properly decide, is whether the decision to stay these proceedings (a) was wrong in law, or (b)
involved an error of law or principle, or (c) was a ruling that it was not reasonable for the Judge to have
made. He was not asked to rule on this admissibility issue, and we ought not to do so either.

44. Given that we have decided that in a case to which the 2015 Act applies a judge has no reason to
attempt to evaluate a decision by of the Authority, at least in the absence of some arguable abuse of
process properly so-called, it is unnecessary to express a view on the approach which should be taken by
judges to that exercise. This is why we have not felt it necessary to resolve the submissions we received
about the meaning of paragraph [17] of R v. L & others in the context of paragraph [18] and the decisions
there referred to.  This issue may still arise in pre-2015 Act cases, but no such case is before us.

45. That issue concerns whether the judge should make a primary judgment on the question whether an
individual has been trafficked and whether there is the necessary nexus with the alleged offending, or
whether the approach is one of review.

46. Even if the decision of the Authority is correct, that is not the end of the matter. We should not be
taken to endorse the Judge's approach to the review which he carried out.  He stayed the prosecution
without considering whether it was in the public interest that it should proceed, even if the Authority's
decision as to his status was correct.

**Conclusion**

47. The appeal was allowed because there was no room in the light of section 45 of the 2015 Act for the
abuse of process jurisdiction to immunise the respondent from prosecution.

**End of Document**


-----

# R v DS

_[[2020] EWCA Crim 285, [2021] 1 All ER 1233, [2021] 1 WLR 303](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627S-BFT3-GXFD-80RS-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 28/02/2020**

# Catchwords & Digest

**CRIMINAL LAW - TRAFFICKING PEOPLE FOR EXPLOITATION – OFFENCES COMMITTED BY VICTIMS OF**
**HUMAN TRAFFICKING – WHETHER COURT HAVING JURISDICTION TO STAY PROCEEDINGS AS ABUSE**
**[OF PROCESS – MODERN SLAVERY ACT 2015, S 45.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)**

# Cases referring to this case

R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Considered

**End of Document**


20/01/2023

CACrimD

19/05/2021

CACrimD


-----

