# R v Jenkins [2022] EWCA Crim 603

Court of Appeal, Criminal Division

Warby LJ, Cutts J, and HHJ Sloan

28 April 2022Judgment

MR J DURR appeared on behalf of the Appellant

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

LORD JUSTICE WARBY:

1. This is an appeal against sentence in a case of drug dealing. The appellant is Charles Leonard
Jenkins, now aged 26.

2. His criminal record goes back to 2016 when he received a suspended sentence of imprisonment for
handling stolen goods when he was aged 20. By January 2018 he had accumulated a total of nine
convictions for 22 offences. These included acquisitive offences of handling, theft, and fraud, and some
offences against the person, but no drug offences. The drug offending that is directly relevant to this
appeal took place in March and May 2018 when the appellant was 22 years old.

The March Offences

3. On 20 February 2018 the appellant was released from then his most recent prison sentence, which was
for theft and breach of a suspended sentence order. On 22 March 2018 he was caught by police
committing two offences of possession of class A drugs with intent to supply. We will refer to these as “the
March Offences”, the facts of which were these, in brief.

4. Police officers and officers from the National Crime Agency attended an address on Lefroy Road in
Norwich, in possession of a warrant. They had to force entry as the front door of the premises had been
secured with three locks and a mattress had apparently been placed behind the door. When they entered,
the officers found the appellant and three others on the premises. Also inside the premises were drugs,
drugs paraphernalia and money. Other items were found outside having been thrown from the windows as
the police entered the premises. These turned out to include drugs, money, mobile telephones and scales.

5. The telephones were found to have text messages on them which were indicative of drug dealing.
Money recovered from inside and outside of the premises amounted to £2,880, including £2,400 in a
rucksack which was believed to have been owned by the appellant.


-----

6. From within and outside of the property the officers recovered a variety of drugs. These included a total
of 120.267 grams of crack cocaine in 142 wraps (that became count 1 on the indictment that was
eventually preferred). There was also heroin weighing some 149 grams in 141 wraps (that became count
2). The street value of the crack cocaine was estimated to be between £7,850 and £11,880. The heroin
had a street value estimated at between £6,285 and £9,315. This brought the total street value of the
drugs recovered to between £14,135 and £21,195.

7. The appellant and the others were arrested. Interviewed under caution that evening the appellant
denied that he owned any of the mobile phones found at the address and claimed that he had no
knowledge of class A drugs, having never heard of heroin or crack cocaine. He answered “no comment” to
most of the other questions he was asked. He was released.

The May Offences

8. On 12 May 2018 the appellant committed two further offences of possessing heroin and cocaine with
intent to supply, to which we will refer as “the May Offences”. The facts, in summary, were that the
appellant had been in a taxi on the A11 when it was stopped by police. He got out and threw something
into a field. This turned out to be a bag containing some 320 grams of class A drugs in 350 wraps with a
street value of between £15,000 and £20,000. He made no comment in interview, but he pleaded guilty at
the first reasonable opportunity and was sentenced in the Crown Court at Norwich on 19 July 2018 by His
Honour Judge Holt who imposed concurrent sentences of two years' imprisonment on each count.

9. There was and is no appeal against that sentence, but it is relevant to say this. The sentence reflected
the judge's view that this was an isolated offence by a man who had no relevant previous convictions and
had "never been involved in drugs dealing before". He found that the appellant's culpability was closer to
the “lower” category, and there were no aggravating features and a number of mitigating features, including
exploitation and a degree of pressure falling short of duress. The ultimate sentence also reflected full
credit for the appellant's early guilty plea.

10. It is clearly apparent, therefore, that this sentence took no account of the March Offences. That was
quite right in principle, because at that stage the appellant was denying his guilt of those offences, as were
the three others arrested with him. But the reason seems to be the more prosaic one that those
representing the prosecution were unaware of the March Offences and the judge was not told about them.
Indeed, formal proceedings in respect of those offences were not started until April 2020.

These proceedings

11. Those proceedings took a considerable time thereafter. On 4 August 2020 there was a Plea and Trial

Preparation Hearing at which the appellant and co‑defendants pleaded not guilty. At that point he was

denying joint enterprise, possession and intent to supply, and indicated that there might be a referral under
the National Referral Mechanism ("NRM") to investigate whether he had been subjected to **_modern_**
**_slavery._**

12. In October 2020 such a referral was made. The Single Competent Authority ("SCA") began what
turned out to be a lengthy investigation. Meanwhile, there were delays because of the pandemic which
meant that the case was eventually fixed for trial on 6 September 2021.

13. In November 2020 the appellant served a defence statement making it clear that he admitted
involvement in the supply of drugs but would contend that his presence and any involvement were due to
his being a victim of **_Modern Slavery, and that he would rely on the statutory defence provided for by_**
[section 45 of the Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

14. At that time the case law on the admissibility of SCA decisions in criminal proceedings was in a state
of some uncertainty. But in May 2021 a full court of five judges decided that decisions of the SCA are not
admissible as expert evidence or otherwise: see Brecani v The Queen [2021] EWCA Crim 731.

15. The court was then notified that the appellant wished to plead guilty, which he did on 2 September

2021 Sentencing was delayed because two co defendants contested a trial It was thus on 20 December


-----

2021 that the appellant was sentenced by Recorder Ayers in the Crown Court at Norwich. The Recorder
imposed a sentence of two years and six months' imprisonment on each count, concurrent. It is that
sentence that is the subject of the present appeal.

Sentencing information

16. The sentencing judge had a print-out of the appellant's antecedents from the Police National

Computer, some character references, a pre‑sentence report dated 2 November 2021, and a report and

decision letter from the SCA dated 23 November. By this time the appellant's antecedents were the nine
convictions we have already mentioned, coupled with three offences committed after the March Offences,
namely the May Offences, and one offence of possessing cannabis committed in June 2019.

17. The pre‑sentence report referred to conversations with the Modern Slavery Response Team, which

indicated that the appellant was not a leader and may, as he claimed, have been coerced into his role in
drug supply. The author suggested that the appellant's circumstances could be considered so exceptional

as to justify a non‑custodial sentence on the basis of the evidence, which at that stage was inconclusive,

that he was a victim of modern slavery and on the basis of his positive progress following release from his
last custodial term. The appellant was engaging with an organisation called Key4Life, a charity operating
out of prisons in London and running a preventative program supporting young men at risk of going to
prison.

18. A letter to the court confirmed that the appellant had gained a number of certificates and managed
sessions in the community with people with learning and physical disabilities. He had addressed his drug
addiction with the help of the Amber Foundation, who confirmed in a letter to the court that he had moved
into Amber Foundation accommodation in September 2019 and engaged well in the structured regime. He

was regularly drug tested and save for one lapse when he took cannabis was drug‑free. He left that

accommodation in February 2020 but remained in contact.

19. The appellant suffers from limited mobility due to cerebral palsy and scoliosis of the spine, both of
which are progressive conditions. He is reliant on a mobility scooter if he goes out. He requires assistance

with day‑to‑day care. Those details have been supplemented today by information provided by Mr Durr on

instructions from his client.

20. The SCA letter and report contained a finding that there were conclusive grounds for accepting that
between 21 and 23 March 2018 the appellant had been exploited by individuals for the purpose of forced
criminality. Put shortly, the SCA found that the appellant had been recruited into a county lines gang by a
dealer to whom he owed money. He had been transported to the Norwich address where he was
threatened, harmed, and forced to watch over a quantity of drugs and money. It was accepted by the
prosecution, it appears, that the SCA report was admissible in relation to sentence

The sentencing decision

21. At the sentencing hearing there were two main issues: the role that should be attributed to the
appellant and the level of reduction which his guilty pleas should attract. The Recorder started with the
second issue. He accepted the submission of Mr Durr for the appellant that in all the circumstances his
plea should attract credit of 25 per cent. That was on the basis that he had always accepted the factual
basis for the prosecution, and his guilty plea was only delayed because of legal uncertainties surrounding
the admissibility of SCA decisions.

22. The Recorder did not accept, however, that the appellant's role was a lesser one. He said it was
"quite clear" to him that the offending fell into Category 3 significant role. He took account of the SCA
decision that the appellant had been under significant coercion and pressure to become involved but said
that he had to balance that against the fact that the appellant had previously been involved in possessing
drugs with intent to supply. He had therefore not been naive; he understood the trade. Making some
allowance for the delay in the case and the character references provided, the Recorder identified the final


-----

sentence of two‑and‑a‑half years' imprisonment. Although he did not specify his notional sentence after a

trial, it can be calculated as one of 40 months or three years and four months.

Grounds of appeal

23. There are two grounds of appeal. First, it is said that the appellant's role should have been assessed
as lesser rather than significant due to the SCA's finding that there was an element of coercion. Secondly,
it is submitted that the sentence took account of the May Offences as an aggravating factor without having

proper regard to the fact that they post‑dated those for which the appellant was being sentenced. It is

argued that if all the drugs matters had been heard together it is inconceivable that a sentence as long as
four years and six months' imprisonment would have been imposed.

Discussion

24. In our judgment the Recorder did take account of the SCA's finding. His sentencing remarks were
brief but they did allude to that finding and they indicated that other things being equal it may well have led
the Recorder to treat the appellant's role as a lesser one. The main reason he did not do this was his
conclusion that the appellant was already an experienced drug dealer at the time. It is on that point that
the Recorder fell into error.

25. It was clearly wrong to sentence this appellant for the March Offences on the basis that he had
previous involvement in the drugs trade. That was a reversal of the true timeline. It is not entirely clear to
us exactly how that error came about, but whatever the explanation may be, it was an error of principle
which was detrimental to the appellant.

26. On the other hand, it might be said, this sentence should not be viewed in isolation. The time it took to
enter the guilty plea to the March Offences gave the appellant a corresponding benefit: the sentence
imposed in July 2018 was probably lower because it did not take account of that previous offending, which
the appellant could have admitted. He would say, no doubt, that he was entitled to reserve his position
given the failure to initiate proceedings against him, the modern slavery issue, and the legal uncertainty

that prevailed at the time. He could fairly say that the unexplained two‑year delay in prosecuting him for

the March Offences were not fault of his.

27. This all tends to complicate the task of considering whether the sentence imposed by the Recorder
last December was manifestly excessive. But in our judgment the best way through these complexities is
to start by considering what a just and proportionate sentence would have been had the March and the
May Offences all been dealt with in a timely fashion and sentenced together, by a judge in possession of
accurate information about all the offences, paying due regard to the principle of totality.

28. All the offending was in harm Category 3, but the sentencing judge would in our judgment have treated
the March Offences as offending of lower culpability by a defendant in his early twenties with no
established history of drug dealing and no relevant previous convictions who had significant personal

mitigation. The category range being two to four‑and‑a‑half years, an appropriate custodial sentence after

a trial would have been in the region of two‑and‑a‑half years. reduced to two years for the plea.

29. Culpability for the May Offences would also have been in the lower category for the reasons given by
His Honour Judge Holt. The approach that he took would have been adopted, except that the informed
sentencer would have treated the offending in May as aggravated by the fact that it took place after the
March offences, and whilst the appellant was under investigation for that offending. But making due
allowance for the age and vulnerability of the appellant, the elements of pressure and coercion, the early

guilty plea, and totality, we think it would have been excessive to add much as a further two‑and‑a‑half

years. A total sentence of three‑and‑a‑half years would have been sufficient to reflect the overall

criminality involved. A consecutive sentence for the March Offences would thus have been one of 18
months' imprisonment. For these reasons, we conclude that the sentence for the March Offences was
manifestly excessive and we quash it


-----

30. We do not finish there. A sentence of 18 months' imprisonment is capable of being suspended. That
is a rare course to take in a case of class A drug dealing. That is inevitably a serious matter and in almost
all cases, as the guideline makes clear, those who engage in it must expect lengthy immediate prison
sentences. But here we return to the reality of the case. The appellant was being sentenced for offending

which pre‑dated his previous prison sentence and after a long delay. It is plain that, albeit not affording him

a defence, he was the subject of **_modern slavery in the ways identified by the SCA in relation to these_**
offences. Further, and importantly, since his release from custody the appellant could hardly have done
more in difficult circumstances to turn his life around.

31. We therefore agree with the author of the pre‑sentence report that this is an exceptional case. The

references in the pre‑sentence report make impressive reading. It is the combination of these factors

which persuades us that, notwithstanding the seriousness of the offence, the custodial sentence imposed
should have been suspended.

32. We give effect to that conclusion by quashing the sentences imposed and replacing them on each
count concurrent with a sentence of 10 months' imprisonment suspended for 18 months. That, we make
clear, takes into account the period that has been served by this appellant in custody prior to the hearing of
this appeal.

33. The pre‑sentence report makes two recommendations. One was for a curfew which we do not

consider now to be an appropriate disposal. The other one was for a rehabilitation activity requirement for
an unspecified period. We consider that to be an appropriate requirement. We will seek the assistance of
probation in identifying the correct duration. Our provisional view was that the duration should be one of up
to 28 days. Can we therefore ask probation for help on that point?

PROBATION OFFICER: Yes, my Lords. I am from the probation service. I would suggest 25 days, my
Lord.

LORD JUSTICE WARBY: Yes, thank you very much. Is there any other help you can give us?

PROBATION OFFICER: There is not, my Lord. I think that the pre‑sentence report had it all in it. Clearly

Mr Jenkins has made lots of progress, so I am very confident that he will engage with this.

LORD JUSTICE WARBY: Thank you very much.

34. There will therefore be a rehabilitation activity requirement of up to 25 days. To the extent we have
indicated this appeal is allowed.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

