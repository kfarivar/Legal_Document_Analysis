# R v BXR [2022] All ER (D) 52 (Nov)

[2022] EWCA Crim 1483

Court of Appeal, Criminal Division

EnglandandWales

Popplewell LJ, Johnson J and Judge Picton

10 November 2022

**CRIMINAL LAW – POSSESSING FALSE IDENTITY DOCUMENT WITH IMPROPER INTENTION – WHETHER**
**CONVICTION UNSAFE WHERE FRESH EVIDENCE OF MODERN SLAVERY**
Abstract

_The Court of Appeal, Criminal Division, allowed the appeal of the defendant Nigerian overstayer, who had been_
_charged with offences, arising out of the use of the false passport to gain employment. The offences had been_
_[committed before the defence introduced by s 45 of the Modern Slavery Act 2015 had come into force. However,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
_the court admitted 'undisputed' fresh evidence which showed that the defendant, who had cognitive difficulties and_
_suffered from post-traumatic stress disorder, had been trafficked, and it quashed the convictions of the offences on_
_the indictment (possession of a false identity document with an improper intention and fraud). The court ruled,_
_among other things, that: (i) the degree of compulsion felt by the defendant, as a result of his earlier trafficking_
_experiences, and the further trafficking in offering him exploitative accommodation and work, had been very high;_
_(ii) that trafficking had been responsible for his using the false passport to obtain the exploitative job; (iii) the nexus_
_between the trafficking and use of the passport to gain employment had been such as to reduce his culpability for_
_the offending to a very low level, if not wholly to extinguish it; and (iv) accordingly, it had not been in the public_
_interest that the defendant had been prosecuted and, had the Crown Prosecution Service known the trafficking_
_circumstances responsible for the offences and applied the relevant guidance, it would very likely not have_
_prosecuted. The court, in so ruling, held that the absence of fault on the part of defendant's then legal advisers (who_
_had not been aware of the trafficking) was no bar to a successful application to set aside convictions in a case of_
_the present kind. Further, the defendant's conviction of a related summary offence was also quashed and the court_
_directed that no further proceedings should be taken in respect of another related summary offence which had been_
_sent to the Crown Court by the magistrates._
Digest

The judgment is available at: [2022] EWCA Crim 1483

**Background**

The defendant was of Nigerian origin. In April 2007, aged 33, he entered the UK on a visitor's visa and,
subsequently, overstayed.

In October 2012, the defendant started working in a factory in London where noodles were made and stored. He
presented his employer with a false passport, bearing a false stamp which purported to evidence that the holder
had been granted indefinite leave to remain, so as to be eligible for employment. The defendant's evidence was
that it had been a photocopy of the passport, not the original, and that it had been presented to an employment
agency run by a man (AB), rather than directly to the employer.


-----

In 2017, immigration officers visited the factory and discovered the existence and use of the false passport.

The defendant was cautioned. He initially claimed to have been granted indefinite leave to remain in 2000. When
interviewed, he answered no comment to all questions.

The defendant was charged with offences, arising out of the use of the false passport to gain employment. Counts 1
[and 2 charged possession of a false identity document with an improper intention contrary to s 4(1) and 4(2) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:51SF-9SP1-DYCN-C29V-00000-00&context=1519360)
[Identity Documents Act 2010 (IDA 2010). Count 1 related to the false name and Count 2 to the false stamp. Count 3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:51SF-9SP1-DYCN-C44D-00000-00&context=1519360)
[charged fraud, contrary to s 1 of the Fraud Act 2006 (FA 2006) in using the false passport to obtain employment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)
and the benefits therefrom. The defendant also pleaded guilty to a summary offence of illegal working, contrary to s
[24B of the Immigration Act 1971 (IA 1971) on the understanding that it had been sent for trial as a related offence](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
[by the magistrates under s 51 Crime and Disorder Act 1998 (CDA 1998).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FBX0-TWPY-Y1HT-00000-00&context=1519360)

Subsequently, in the Crown Court, the defendant pleaded guilty to the three indictment offences. Due to an error,
the summary offence, to which he had also pleaded guilty, was not sent by the magistrates; only an offence of
[remaining in the country after the expiry of temporary leave to remain, contrary to IA 1971 s 24(1)(b).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)

The defendant was sentenced to nine months' imprisonment on the indictment offences, and to three months'
imprisonment on the summary offence; all sentences were to run concurrently.

The defendant was granted an extension of time and permission to appeal against conviction.

**Issues and decisions**

Whether the conviction was unsafe because _[s 45 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_ **_[Modern Slavery Act 2015 (MSA 2015) provided the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
defendant with a defence, of which he had not been advised, and which would probably have succeeded. Further,
the defendant submitted that, had the prosecution known of his trafficking circumstances, it might well not have
prosecuted him.

Although the offences were indicted as having taken place between 1 October 2012 and 21 April 2017, it was
agreed that they had been complete before the defence introduced by s 45 had come into force on 31 July 2015.
Accordingly, the grounds advanced orally were directed to the law in force some three years earlier when the
passport had been used to gain employment and the offences had been committed.

The court considered whether to admit fresh evidence, purporting to show that the defendant had been trafficked.

[Until MSA 2015 had provided a defence, there had been no statutory provision transposing into domestic law the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
UK's international obligations towards victims of trafficking who committed crimes in the UK. The international
obligations derived from various instruments, including art 26 of the Council of Europe Convention on Action against
Trafficking in Human Beings 2005 (CETS No.197), ratified by the UK on 17 December 2008, which obliged the UK
to 'provide for the possibility of not imposing penalties on victims [of trafficking] for their involvement in unlawful
activities to the extent that they have been compelled to do so'. Article 4 defined trafficking and, so far as relevant to
the present case, provided that: 'For the purposes of this convention -(a) "trafficking in human beings" shall mean
the recruitment, transportation, transfer ... of persons by means of forms of coercion, ... of deception, of the abuse
of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent
of a person having control over another person, for the purpose of exploitation. Exploitation shall include, at a
minimum, ... forced labour or services, slavery or practices similar to slavery, servitude ...' (see [12] of the
judgment).

The UK gave effect to its international obligations through the decision made by the Crown Prosecution Service (the
CPS) whether to prosecute, and the court's jurisdiction to supervise prosecutions, so as to prevent what was most
[conveniently labelled as 'abuse of process'. The final CPS guidance before the coming into force of MSA 2015 had](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
been published on 29 August 2013 (the 2013 Guidance), which called for a 'three-stage approach' to the
prosecution decision in respect of victims of trafficking: 'In addition to applying the Full Code Test in the Code for
Crown Prosecutors prosecutors should adopt the following three stage assessment: (1) is there a reason to believe


-----

that the person has been trafficked? if so, (2) if there is clear evidence of a credible common law defence of duress,
the case should be discontinued on evidential grounds; but (3) even where there is not clear evidence of duress,
but the offence has been committed as a result of compulsion arising from trafficking, prosecutors should consider
the public interest in proceeding to prosecute' (see [13], [14] of the judgment).

The 2013 Guidance continued by working its way through the three-stage approach. With regard to compulsion
falling short of duress, it said that: 'The means of trafficking used in an individual case may not be sufficient to give
rise to a defence of duress, but how the person was trafficked will be relevant when considering whether the public
interest is met in deciding to prosecute or proceed with a prosecution. In assessing whether the victim was
compelled to commit the offence, prosecutors should consider whether: (1) the offence committed was a direct
consequence of, or in the course of trafficking and (2) whether the criminality is significantly diminished or
effectively extinguished because no realistic alternative was available but to comply with the dominant force of
another. Where a victim has been compelled to commit the offence, but not to a degree where duress is made out,
it will generally not be in the public interest to prosecute unless the offence is so serious or there are other
aggravating factors' (see [15] of the judgment).

Where the prosecutor had considered whether to prosecute and had applied the published CPS guidance, the court
would only intervene on well recognised public law grounds. Where, however, the evidence of trafficking was not
before the CPS and the question was whether to set aside a conviction based on evidence of trafficking which
subsequently emerged, the ultimate question was whether the conviction was unsafe. For those purposes, a
conviction was unsafe if: (1) the prosecution would not, or might well not, have prosecuted had it known the true
facts; or (2) such a prosecution would have been stayed as an abuse. Each turned on whether prosecution would
be in the public interest (see [16] of the judgment).

The mere fact that a convicted defendant had been the victim of trafficking was not, in itself, sufficient to set aside
the conviction. In such cases, the first important task was to assess the nexus between the offending and the
trafficking, that was to say to assess the degree of compulsion to commit the offence exerted on the offender by the
circumstances of trafficking. That was a sensitive and fact specific inquiry in each case. Where there was no
reasonable nexus, generally the conviction should not be set aside. At the other end of the scale, where the nexus
was such that, in reality, culpability was extinguished, the conviction should normally be set aside. In between those
examples at either end of the scale were cases in which there was a degree of causative connection between the
trafficking and the offending. Whether it was sufficient to make it contrary to the public interest to prosecute would
depend upon the extent to which it reduced the defendant's culpability for the offending (see [17] of the judgment).

Nexus was not the only factor: other factors which engaged the public interest were the gravity of the offence, and
alternatives reasonably open to the defendant, although the latter would often be an aspect of the nexus of
compulsion between the trafficking and the offence. There might also be particular features of the defendant in
question, including his history, and of the particular crime and the seriousness of the defendant's participation in it,
which increased or decreased the public interest in prosecution (see [18] of the judgment).

In the present case, the fresh evidence would be admitted and the convictions of the offences on the indictment
would be quashed. Pursuant to para 6(9) of Sch 3 to the Crime and Disorder Act 1988 (CDA 1988), the conviction
of the summary offence, which it was mistakenly thought had been sent by the magistrates under s 51 would also
be quashed and the court directed that no further proceedings should be taken in respect of the related summary
offence which had, in fact, been sent by the magistrates (see [48] of the judgment).

Prior to pleas and sentencing, the defendant had not said anything to his counsel or solicitors of the circumstances
of trafficking set out in the fresh evidence. Counsel for the defendant submitted that those legal advisers had been
on notice of the possibility and should have asked the defendant questions to discover the true position at the time.
The present court disagreed. As far as those advisers could be aware, it had simply been a case of a man who had
used a false passport to get a job, many years after he had entered the country legally, but had overstayed. Those
circumstances had not been such as to put the legal advisers on inquiry that there might have been trafficking,
which had not been volunteered by their client. The absence of fault on the part of legal advisers was, however, no
bar to a successful application to set aside convictions in a case of the present kind (see [10] of the judgment).


-----

Concerning the safety of the convictions, the defendant's cognitive difficulties were apparent in the way he had
given evidence. There were some discrepancies and inconsistencies in his account, but those were readily
explicable by the effect which the unchallenged trafficking and post-traumatic stress disorder would have had, in
conjunction with his cognitive difficulties. The court accepted the defendant's account as truthful (see [42] of the
judgment).

The account of his life when employed at the factory had involved trafficking by GH, AB and JK by reason of the
conditions at JK's, which would constitute servitude; and the conditions at the factory would constitute forced
labour. It was a reasonable inference that the benefits which GH, AB and JK had received had been the very
reason why he had been exploited into taking up employment there. There was a direct link between that trafficking
and the offending (see [43] of the judgment).

The degree of compulsion involved had been high. The background trafficking, which was undisputed, had been
severe and had left him traumatised and vulnerable, as the medical evidence reinforced. He had been trained to
think that he had had to do as he had been instructed when he had been here, reinforced by a voodoo ceremony,
and that had extended to what GH and AB had said without any conscious reasoning that they had been connected
to CD/EF. The defendant's evidence was that he had 'felt pressure and had to be submissive because of the
voodoo ceremony in Lagos and the shouting in church.' He had cognitive and language difficulties. He had been
sleeping rough for weeks or months. GH had befriended him and had been a preacher in a church of his faith and,
therefore, he had been in a position of trust and in a position to exploit his vulnerability. He had performed a twoweek evangelical 'deliverance ceremony' which would have reinforced dependence on GH. In his evidence, the
defendant said he had been told that he would have been in trouble if he had not taken the paper to AB (see [44] of
the judgment).

By virtue of those particular circumstances, the defendant would have felt a level of compulsion far greater than that
felt by someone without cognitive difficulties who had simply overstayed temporary leave to remain without more.
His trafficking background and well-founded fear of persecution if he were to return to Nigeria had put him in a
different position from that which might apply, generally, to unlawful immigrants. His experience in Nigeria had
made it reasonable for him to rule out returning, whereas overstayers, generally, would have the choice to leave the
country as an alternative option (see [45] of the judgment).

In all the circumstances, the degree of compulsion felt by him as a result of his earlier trafficking experiences, and
the further trafficking in offering him what was to be exploitative accommodation and work, had been very high. That
trafficking had been responsible for his using the false passport to obtain the exploitative job. The nexus between
the trafficking and use of the passport to gain employment had been such as to reduce his culpability for the
offending to a very low level, if not wholly to extinguish it. For those reasons, it had not been in the public interest
that he had been prosecuted. Had the CPS known the trafficking circumstances responsible for the offences and
applied the 2013 Guidance, it would very likely not have prosecuted (see [47] of the judgment).

Appeal allowed.

Benjamin Douglas-Jones KC (instructed by Birds Solicitors) for the defendant.

Andrew Johnson (instructed by the Crown Prosecution Service) for the Crown.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

# R v BXR [2022] EWCA Crim 1483

Court of Appeal, Criminal Division

Popplewell LJ, Johnson J and Judge Picton

10 November 2022Judgment

**Benjamin Douglas-Jones KC (instructed by Birds Solicitors) for the Appellant**

**Andrew Johnson (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date: 20 October 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.00am on 10 November 2022 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

An anonymity order has been made in respect of the appellant who is referred to as BXR, which will remain in place
throughout his lifetime. During that period no report may be published which may lead to his identification.

**Lord Justice Popplewell:**

**Introduction**

1. The applicant renews his application for an extension of time for permission to appeal against
conviction. The Single Judge said that he was granting permission to appeal but would leave it to this
court to consider an extension of time. We will grant the extension and refer to the applicant as the
appellant.

2. The appellant is of Nigerian origin and came to this country in April 2007 when aged 33. He entered on
a visitor's visa permitting him to stay for 6 months. He remained after the leave to remain expired on 12
December 2007.

3. On 1 October 2012 he started working in a factory in East London where noodles were made and
stored.  In order to do so, he presented to the employer a passport, which was in a false name, and had a
false stamp which purported to evidence that the holder had been granted indefinite leave to remain, so as
to be eligible for employment. The appellant's evidence is that it was a photocopy of the passport, not the


-----

original, and that it was presented to an employment agency run by a man ('AB') rather than directly to the
employer.

4. In April 2017 he was still working at the factory some 4 ½ years later. Following a visit there by
immigration officers, the existence and use of the false passport was uncovered. He was cautioned and
initially claimed to have been granted indefinite leave to remain in 2000. When interviewed he answered
no comment to all questions.

5. He was charged with four offences arising out of the use of the false passport to gain employment.
Counts 1 and 2 on the indictment charged possession of a false identity document with an improper
intention contrary to s. 4(1) and 4(2) of the Identity Documents Act 2010. Count 1 related to the false name
and Count 2 to the false stamp. Count 3 charged Fraud contrary to s. 1 of the Fraud Act 2006 in using the
false passport to obtain employment and the benefits therefrom. In addition he pleaded guilty to a
summary offence of illegal working contrary to s. 24B of the Immigration Act 1971 on the understanding
that it had been sent for trial as a related offence by the magistrates under s. 51 Crime and Disorder Act
1998.

6. On 23 May 2017, in the Crown Court at Snaresbrook, he pleaded guilty to the three indictment offences.
Due to an error, the summary offence, to which he also pleaded guilty, was not that sent by the magistrates
but an offence of remaining in the country after the expiry of temporary leave to remain, contrary to s.
24(1)(b) of the Immigration Act 1971. On the same day he was sentenced by Her Honour Judge Canavan
to 9 months imprisonment on the indictment offences and three months on the summary offence, all
sentences to run concurrently.

7. The grounds of appeal advanced in writing were that s. 45 of the Modern Slavery Act 2015 provided
the appellant with a defence, of which he was not advised, and which would probably have succeeded; and
that furthermore, had the prosecution known of the appellant's trafficking circumstances, it might well not
have prosecuted him; and that accordingly his convictions are unsafe.

8. Although the offences were indicted as having taken place between 1 October 2012 and 21 April 2017,
following clarification at the beginning of the hearing, it was agreed by Mr Douglas-Jones KC on the
appellant's behalf and by Mr Johnson on behalf of the Crown that the offences were complete before the
defence introduced by s. 45 of the 2015 Act came into force on 31 July 2015. Accordingly the grounds
advanced orally were directed to the law in force some three years earlier when the passport was used to
gain employment and the offences committed.  We are not concerned with whether there was a defence
under s. 45, or the jurisprudence which addresses the setting aside of convictions by guilty pleas where a
defence is available.

9. The evidence of the appellant being trafficked came in three statements made by him since the Crown
Court proceedings, together with further written material to which we refer. The appellant also gave
evidence before us and was cross examined. We considered this evidence _de bene esse in order to_
consider whether it should be admitted as fresh evidence.

10.  Prior to pleas and sentencing, the appellant did not say anything to his counsel or solicitors of the
circumstances of trafficking set out in the fresh evidence. Mr Douglas-Jones submitted that those legal
advisers were on notice of the possibility and should have asked the appellant questions to discover the
true position at the time. We disagree. As far as those advisers could be aware, this was simply a case of
a man who had used a false passport to get a job, many years after he had entered the country legally but
overstayed. Those circumstances were not such as to put the legal advisers on inquiry that there might
have been trafficking which was not volunteered by their client. The absence of fault on the part of legal
advisers is, however, no bar to a successful application to set aside convictions in a case of this kind: see
for example R v O _[[2011] EWCA Crim 2226.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:540S-68V1-F0JY-C02B-00000-00&context=1519360)_

**The law**

11. The development the law applicable to setting aside convictions where it is alleged that the offences
were committed by a victim of trafficking, prior to the 2015 Act coming into force, has been set out in a
number of guideline cases in this court including R v M(L) [2010] EWCA Crim 2327 [2011] 1 Cr App R 12;


-----

_R v N and L [2012] 1 Cr App R 35 [2013] QB 379; R v THN & L(C)_ _[2013] EWCA Crim 991, [2013] 2 Cr_
App R 23; R v Joseph (Verna) [2017] EWCA Crim 36, [2017] 1 Cr App R 33; R v L & N _[[2017] EWCA Crim](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
_[2129; R v S(G)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_ _[[2018] EWCA Crim 1824, [2019] 1 Cr App R 7; and R v AAD [2022] EWCA Crim 106. Two](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
very recent decisions applying this jurisprudence are R v AGM _[2022] EWCA Crim 920 and R v BYA_ _[[2022]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66KY-GB03-CGX8-00J1-00000-00&context=1519360)_
_[EWCA Crim 1326.  We identify the following as the most important principles applicable to the present](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66KY-GB03-CGX8-00J1-00000-00&context=1519360)_
appeal.

12. Until the 2015 Act provided a defence, there was no statutory provision transposing into domestic law
the UK's international obligations towards victims of trafficking who commit crimes in this country. The
international obligations derive from various instruments, including article 26 of the Council of Europe
Convention on Action against Trafficking in Human Beings 2005 (CETS No.197), ratified by the UK on 17
December 2008, which obliges the UK to “provide for the possibility of not imposing penalties on victims [of
trafficking] for their involvement in unlawful activities to the extent that they have been compelled to do so”.
Article 4 defines trafficking, and so far as relevant to the present case provides:

“For the purposes of this convention
(a) 'trafficking in human beings' shall mean the recruitment, transportation, transfer …. of persons by
means of forms of coercion, …. of deception, of the abuse of power or of a position of vulnerability or of the
giving or receiving of payments or benefits to achieve the consent of a person having control over another
person, for the purpose of exploitation. Exploitation shall include, at a minimum, …. forced labour or
services, slavery or practices similar to slavery, servitude….”

13. In England and Wales the UK gave effect to its international obligations through the decision made by
the Crown Prosecution Service (“the CPS”) whether to prosecute, and the Court's jurisdiction to supervise
prosecutions so as to prevent what is most conveniently labelled as “abuse of process”.

14. The final CPS guidance before the coming into force of the 2015 Act was published on 29 August
2013 (“the 2013 Guidance”). The 2013 Guidance calls for a “three-stage approach” to the prosecution
decision in respect of victims of trafficking:

“In addition to applying the Full Code Test in the Code for Crown Prosecutors, prosecutors should adopt
the following three stage assessment:

(1) is there a reason to believe that the person has been trafficked? if so,

(2) if there is clear evidence of a credible common law defence of duress, the case should be discontinued
on evidential grounds; but

(3) even where there is not clear evidence of duress, but the offence has been committed as a result of
compulsion arising from trafficking, prosecutors should consider the public interest in proceeding to
prosecute.”

15. The 2013 Guidance continues by working its way through the three-stage approach. With regard to
compulsion falling short of duress, it says this:

“The means of trafficking used in an individual case may not be sufficient to give rise to a defence of
duress, but how the person was trafficked will be relevant when considering whether the public interest is
met in deciding to prosecute or proceed with a prosecution. In assessing whether the victim was compelled
to commit the offence, prosecutors should consider whether:

(1) the offence committed was a direct consequence of, or in the course of trafficking and

(2) whether the criminality is significantly diminished or effectively extinguished because no realistic
alternative was available but to comply with the dominant force of another.

Where a victim has been compelled to commit the offence, but not to a degree where duress is made out,
it will generally not be in the public interest to prosecute unless the offence is so serious or there are other
aggravating factors.”


-----

16. Where the prosecutor has considered whether to prosecute and applied the published CPS guidance,
the court will only intervene on well recognised public law grounds. Where, however, the evidence of
trafficking was not before the CPS and the question is whether to set aside a conviction based on evidence
of trafficking which subsequently emerges, the ultimate question is whether the conviction is unsafe. For
these purposes a conviction is unsafe if (1) the Crown would not, or might well not have prosecuted had it
known the true facts or (2) such a prosecution would have been stayed as an abuse. Each turns on
whether prosecution would be in the public interest.

17. The mere fact that a convicted defendant has been the victim of trafficking is not in itself sufficient to
set aside the conviction. In such cases, the first important task is to assess the nexus between the
offending and the trafficking, that is to say to assess the degree of compulsion to commit the offence
exerted on the offender by the circumstances of trafficking. This is a sensitive and fact specific inquiry in
each case. Where there is no reasonable nexus, generally the conviction should not be set aside. At the
other end of the scale, where the nexus is such that in reality culpability is extinguished, the conviction
should normally be set aside.  In between these examples at either end of the scale are cases in which
there is a degree of causative connection between the trafficking and the offending. Whether it is sufficient
to make it contrary to the public interest to prosecute will depend upon the extent to which it reduces the
defendant's culpability for the offending.

18. Nexus is not however the only factor: other factors which engage the public interest are the gravity of
the offence, and alternatives reasonably open to the defendant, although the latter will often be an aspect
of the nexus of compulsion between the trafficking and the offence. There may also be particular features
of the defendant in question, including his history, and of the particular crime and the seriousness of the
defendant's participation in it, which increase or decrease the public interest in prosecution.

**Procedural history and evidence**

19. On 6 June 2017, the appellant claimed asylum. His asylum claim was rejected by the Secretary of
State for the Home Department on 29 January 2018.

20. On 30 September 2019, the appellant was referred through the National Referral Mechanism to the
Single Competent Authority (“the SCA”). On 8 November 2019, the SCA found there to be reasonable
grounds to suspect that he was a victim of trafficking. That decision was made on the basis of a detailed
statement from the appellant dated 30 September 2019 setting out the history of his trafficking.

21. The appellant appealed to the First-tier Tribunal (“FTT”) against the refusal of his asylum application
by the Secretary of State. The tribunal did not hear oral evidence from the appellant, on the basis that he
was considered to be a vulnerable person, but had before it a further detailed statement from him dated 30
December 2019.

22. The essential elements of what the appellant said in the two statements, as amplified in evidence
before us, can be summarised as follows.

23. In 2007, he was brutally attacked by a gang of men in his village (in Ogun State, Nigeria) for being in a
long-term gay relationship with a man ('LM'). LM was also attacked. After the attack, the couple did not
feel safe in the village and left the next day, travelling to Lagos by bus. The appellant then contacted a
trader ('CD') he knew in the city whom he sensed might also be gay. The couple moved in with CD and, in
lieu of paying rent, the appellant worked for his business doing manual labour.

24.  CD began to force him to have sex with men at “secret gatherings”. He was made to take unknown
substances at these gatherings. While in Lagos, the appellant witnessed what he described as “jungle
justice” which included vigilantes burning a man alive in the street for being gay. Both he and LM lived in
fear that this “jungle justice” could happen to them.

25. CD told the couple that he knew agents who could help them leave the country. He then arranged
their passports, visas and travel plans. The appellant was unaware of where he would be travelling to, and
did not take possession of his passport until he boarded the plane. CD became increasingly angry with him
as his departure grew nearer. As a result, he was scared of CD. The night before he left Nigeria for the


-----

UK, CD forced the appellant to agree to a “Covenant”, which included ritualistic elements, instructing him to
abide by CD's instructions and the instructions that CD would give via the person with whom the appellant
would be staying abroad. The appellant was scared about the consequences of breaking this Covenant.

26. On his arrival in the UK, the appellant was met by a man who took his passport and then drove him to
a house with two other men (who had also just arrived from Lagos). One of these men was ('PQ').  He
stayed in this house for a couple of years and, during this time, began a sexual relationship with PQ. This
house was run by EF. His movements were restricted during this time. During the week, he and PQ were
instructed to keep the house clean. On Friday and Saturday nights, parties took place in the house. The
appellant was made to prepare the house for these parties and was then forced to have sex with the
guests, and forced to take drugs. He was demeaned, threatened and beaten. On some occasions, he
was also instructed to have sex with men during the week. He was told that the instructions were
authorised by CD. The appellant was not paid during his time in the house. He was told that he owed a
huge sum of money to CD and that, by virtue of this debt bondage, he had to stay in the house until this
debt was repaid.

27. As the situation in the house worsened, he and PQ resolved to escape. They were occasionally
allowed to take short walks in the local area, and one day, they just kept walking. As neither man had any
money, they became homeless. They lived on the streets for months until they met a preacher in Stratford
('GH') who offered them accommodation, food and work. First, however, GH insisted that they undergo a
process of “deliverance”, which involved weeks of fasting and praying away their “evil”. In his statement,
the appellant described this process as a form of gay conversion therapy.

28. GH then organised for passport photographs to be taken of the appellant and PQ in order to arrange
work for the two men. He also organised accommodation for them, in the appellant's case with a single
mother ('JK'). The appellant moved into a very small room in JK's flat, and remained living there, with
some breaks, until 2017. He was not given a key to the flat and was largely confined to it when not at work
because the door locked automatically if it shut, so that if he left he would have to wait for JK to arrive
before he could get back in. He did not feel able to ask for a key because he had been warned to keep
quiet and not ask too many questions.  He was told by JK that he was expected to work so as to support
himself and pay for his accommodation, and to clean the flat and do the laundry for JK and her children.

29. JK told the appellant that GH was making arrangements for him to work. GH told him he was going to
work in the noodle factory. JK gave the appellant an envelope with a photocopy document inside, which
was a photocopy of a passport. The appellant was never given the passport itself. He was told by JK to
take it to AB at an employment agency in East London. In his evidence to us, the appellant said that he
was told that if he did not obey, he would be in trouble. AB took the photocopy passport document and
gave him the address of the noodle factory in Barking for him to start work immediately.

30. For the first years, the appellant received no wages directly: they were paid to GH and he was given a
cash stipend by AB or GH or JK, usually about £50 a week, to pay for his travel, food and living expenses.
Statutory terms of employment were prepared in 2014 which recorded that his annual salary was £14,700,
which is equivalent to £282.69 per week, although it is impossible to verify whether this was accurate.

31. In due course GH arranged for a bank account to be opened in the appellant's name into which the
wages were paid. The appellant was given a bank card by AB to enable him to withdraw money from the
account, but he had to give the card back each time after he used it, and had to hand over the bulk of the
wages to GH.

32. Most members of the factory workforce spoke Yoruba and a number were in a similar situation to the
appellant. It felt like he and the other Africans were made to do the job of two or three people. There were
also eastern Europeans who described the Africans as being treated like slaves and were concerned about
their treatment. When giving evidence to us the appellant described how AB or his colleagues would come
to the factory gates to ensure that the appellant and other African workers were doing what was asked of
them.


-----

33. When he was released from prison after his convictions and sentence, the appellant feared becoming
homeless again. As a result, he tried to find GH. However, GH did not offer to help because, according to
GH, the appellant still owed him money. The appellant was forced to sleep on the streets once again.

34. Despite the time that had passed, the appellant said that he still felt controlled by CD and GH. This, he
explained, felt like a physical silencing. He explained that it was only after some time and with the support
of a number of organisations including Helen Bamber Foundation, that he finally felt able to be open about
his sexuality and feel free from persecution.

35. The FTT also had before it a report dated 19 December 2019 from Amy Chisholm, a clinical
psychologist, based on her clinical findings and observations of the appellant. From the outset, Ms
Chisholm noted that the appellant struggled to understand questions, was unable to express himself clearly
and had great difficulty recalling timeframes.  He scored low marks in testing for cognitive functioning. Ms
Chisholm noted that the appellant's relevant GP diagnosis included Post-Traumatic Stress Disorder. She
herself diagnosed PTSD and additionally a Major Depressive Disorder in the moderate to severe range.
Ms Chisholm concluded that, in her clinical opinion, the appellant did not appear to be feigning or
exaggerating his symptoms and there was nothing to suggest a false allegation of mistreatment. In her
professional experience, the appellant's report of symptoms and his objective presentation was in keeping
with what she would expect to see in a survivor of persecution and violence on account of sexual identity,
and in a survivor of trafficking.  She concluded that the appellant had a tendency to understate rather than
overstate his experiences. Ms Chisholm also concluded that the appellant's psychiatric illness was linked
to memory impairment.

36. According to Ms Chisholm, the “voodoo ceremony” conducted by CD had had a profound impact on
the appellant. She noted that the appellant still displayed a fear of CD and emphasised the fact that he
had only recently begun to understand complex concepts such as trafficking and exploitation.

37. On 19 December 2019, Dr Phyllis Turvill of the Helen Bamber Foundation published a supplementary
medico-legal report which agreed with Ms Chisholm's findings. Dr Turvill found scarring on the appellant's
body consistent with beatings (many by an instrument such as a whip) and injuries suffered as a result of
interpersonal violence.

38.  In a decision promulgated on 22 January 2020, the FTT allowed the appellant's appeal against the
Secretary of State's refusal to grant asylum. The FTT Judge concluded that the appellant's account would
be accepted, although uncorroborated, and that “It is clear from the evidence before me that not only has
the appellant been subject to extreme violence and abuse in Nigeria but that he has been trafficked to the
United Kingdom and abused whilst in the United Kingdom and has been subject again to sexual violence
and forced labour and servitude.”

39. On 3 August 2020, the Applicant was granted asylum.

40. On 19 August 2020, the SCA concluded that the Applicant was not a victim of trafficking by reasons of
discrepancies or inconsistencies between his account of events at various stages. However, they agreed
to reconsider this decision, and having received the medical reports about the appellant, they concluded
that it offered a plausible explanation for the inconsistencies in his recollection of events and published a
conclusive grounds decision on 29 October 2021 that he was a victim of trafficking. This was confined,
however, to his circumstances before he became homeless. The SCA concluded that his time spent with
JK and her children and working at the factory did not meet the definition of forced labour because “you
were afforded a measure of freedom, you were not working under menace of a penalty, nor were you
forced to remain in this situation and you were able to leave of your own free will but you chose to remain
out of economic necessity.”

41. The appellant gave evidence before us and confirmed the contents of his statements. Mr Johnson
made clear to us that the Crown did not challenge anything in the appellant's account of his exploitation up
to the point of time when he had met GH, shortly before his employment. In cross-examination he
focussed on seeking to undermine the reliability of the appellant's evidence by reference to discrepancies
and inconsistencies in his evidence, and to establish that the employment was simply a matter of economic


-----

choice for the appellant. Mr Johnson also relied in particular upon a passage in the statement of one of the
immigration officers who recorded that whilst the appellant was being booked into the police station
following his arrest at the factory in April 2017, he had said to the immigration officer “I will speak to
solicitor to get leave to remain”. This, submitted Mr Johnson, showed that he had always been aware that
he had an alternative to undertaking unlawful employment.

**Conclusions**

42. The appellant's cognitive difficulties were apparent in the way he gave evidence. There were some
discrepancies and inconsistencies in his account, but we think these are readily explicable by the effect
which the unchallenged trafficking and PTSD would have had, in conjunction with his cognitive difficulties.
We accept his account of events as truthful.

43. The account of his life when employed at the factory involved trafficking by GH, AB and JK by reason
of the conditions at JK's, which would constitute servitude; and the conditions at the factory which would
constitute forced labour. It is a reasonable inference that the benefits which GH, AB and JK received were
the very reason why he was exploited into taking up employment there. There was a direct link between
that trafficking and the offending.

44. The degree of compulsion involved was high. The background trafficking, which is undisputed, was
severe and left him traumatised and vulnerable, as the medical evidence reinforces. He had been trained
to think that he must do as he was instructed when he was here, reinforced by a voodoo ceremony, and
that extended to what GH and AB said without any conscious reasoning that they were connected to
CD/EF. The appellant's evidence to us was that he “felt pressure and had to be submissive because of the
voodoo ceremony in Lagos and the shouting in church.”  He had cognitive and language difficulties. He
had been sleeping rough for weeks or months. GH befriended him and was a preacher in a church of his
faith, and therefore in a position of trust and in a position to exploit his vulnerability. He performed a two
week evangelical “deliverance ceremony” which would have reinforced dependence on GH. In his
evidence to us he said he was told that he would be in trouble if he did not take the paper to AB.

45. By virtue of these particular circumstances, the appellant would have felt a level of compulsion far
greater than that felt by someone without cognitive difficulties who had simply overstayed temporary leave
to remain without more. His trafficking background and well-founded fear of persecution if he were to
return to Nigeria put him in a different position from that which might apply generally to unlawful
immigrants. His experience in Nigeria made it reasonable for him to rule out returning, whereas
overstayers generally will have the choice to leave the country as an alternative option.

46. We do not set great weight on the comment to the investigating officer about seeing a solicitor to get
leave to remain. Assuming it was said (and the appellant had no recollection of doing so), it is not clear
whether he thought that was a realistic outcome even then in 2017; moreover if the factory was exploiting
illegal immigrants, he may have become aware of that possibility after the employment had begun and the
offences committed. In any event there is no reason to suppose that it would have appeared to him to be a
realistic alternative to the security he was exploited into thinking he was getting by being taken off the
streets in 2012 and given shelter and a job.

47. We have concluded that in all the circumstances the degree of compulsion felt by him as a result of his
earlier trafficking experiences, and the further trafficking in offering him what was to be exploitative
accommodation and work, was very high. This trafficking was responsible for his using the false passport
to obtain the exploitative job. The nexus between the trafficking and use of the passport to gain
employment is such as to reduce his culpability for the offending to a very low level if not wholly to
extinguish it. For those reasons we conclude that it was not in the public interest that he be prosecuted.
Had the CPS known the trafficking circumstances responsible for the offences, as we have found them to
be, and applied the 2013 Guidance, it would very likely not have prosecuted.

48. Accordingly we admit the fresh evidence and quash the convictions of the offences on the indictment.
Pursuant to paragraph 6(9) of Schedule 3 of the Crime and Disorder Act 1988 we also quash the
conviction of the summary offence which it was mistakenly thought had been sent by the magistrates under


-----

s. 51, and direct that no further proceedings shall be taken in respect of the related summary offence which
was in fact sent by the magistrates.

49. An anonymity order has previously been made. We have considered whether it should be continued,
and concluded that in the light of our findings it should remain in place for the remainder of the appellant's
lifetime, in accordance with the principles set out in R v L & N and R v AAD.

**End of Document**


-----

