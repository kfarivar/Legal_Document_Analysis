# Balogh and others v Hick Lane Bedding Ltd

_[[2021] EWHC 1140 (QB), [2021] All ER (D) 132 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62PS-N4S3-CGXG-01ND-00000-00&context=1519360)_

**Court: Queen's Bench Division**
**Judgment Date: 09/03/2021**

# Catchwords & Digest

**DAMAGES - MODERN SLAVERY – ASSESSMENT OF DAMAGES IN MODERN SLAVERY**
**BROUGHT AGAINST FORMER EMPLOYER**

In circumstances where the claimant Hungarian nationals had been the victims of
judgment in default had been granted in their favour in respect of their civil claims against the defendant company
(their former employer), the Queen's Bench Division gave judgment on the assessment of damages in the three
cases, which had been ordered to be case-managed and tried together.

# Cases considered by this case

Komives v Hick Lane Bedding Ltd and others

_[[2020] EWHC 3288 (QB)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61F6-29X3-GXFD-83KX-00000-00&context=1519360)_
Considered

R v Rafiq (Mohammed) and Another (2016)

_[[2016] EWCA Crim 1368](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KPY-7221-F0JY-C3NV-00000-00&context=1519360)_
Considered

**End of Document**


12/03/2020

QBD

26/04/2016

CACrimD


-----

