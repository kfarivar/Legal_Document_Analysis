# R v ADG and another [2023] EWCA Crim 1309

Court of Appeal, Criminal Division

Lord Justice Dingemans, Mr Justice Goss and Mrs Justice Foster

8 November 2023Judgment

**Will Parkhill instructed by the Registrar of Criminal Appeals on behalf of ADG**

**Joss Ticehurst instructed by the Registrar of Criminal Appeals on behalf of BIJ**

**Raymond Tully KC and Lee Bremridge instructed by** **the Crown Prosecution Service for the**
**Respondent**

Hearing date : 3 November 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 12 noon on 8 November 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives

.............................

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

**Lord Justice Dingemans :**

**Introduction**

1. This appeal against conviction raises an important issue about the elements of the defence for those
aged under 18 years, pursuant to section 45 of the Modern Slavery Act 2015 (the 2015 Act).

2. The first appellant ADG and the second appellant BIJ are [an age] year old men. They have the benefit
of anonymity pursuant to the provisions of section 45 of the Youth Justice and Criminal Evidence Act 1999,
which anonymity expires on their 18[th] birthday. The events which formed the basis of the indictment
against them took place when ADG and BIJ were aged [an age] to [an age] and because of their age at the
time at which these events occurred, we have decided that it is not necessary in the interests of justice to
remove the statutory anonymity before their 18[th] birthday.

3. On 16 November 2022, following a trial before the late His Honour Judge Rose and a jury, the
appellants were convicted of two counts of conspiracy to supply class A drugs (one conspiracy related to


-----

cocaine and the other to diamorphine). On 23 February 2023 the appellants were sentenced to a Youth
Rehabilitation Order (YRO) for a period of 3 years.

4. ADG had also been convicted on his own plea of guilty of two counts of being concerned in the supply
of class A drugs, and BIJ had been convicted on his own plea of guilty of 3 counts of being concerned in
the supply of class A drugs and 2 counts of possession with intent to supply class A drugs, and they were
both sentenced to a YRO for a period of 3 years for those offences. This means that, whatever the result
of this appeal, both ADG and BIJ will remain subject to concurrent YROs imposed for other offences.

**Relevant factual background**

5. The charges against ADG and BIJ arose out of a police investigation carried out by the Serious and
Organized Crime Team of Devon and Cornwall Constabulary into street dealing of both crack cocaine and
heroin. The investigation revealed a drug supply network that involved at least 16 people. 10 of those
individuals pleaded guilty. The network was involved in wide scale drug dealing.

6. The network had its origins in Liverpool, and was supplying cocaine and heroin to drug users in Devon,
principally in Exeter and Torbay. It operated during a 16-month period between October 2020 and
February 2022.

7. The network utilised mobile telephones to facilitate the supply of drugs, in what is commonly referred to
as a “County Line” operation. This involved broadcast messages advertising the sale of cocaine and heroin
being sent to drug users. Over the indictment period there were a number of drugs lines, with various
names and numbers, but the first iteration was on 5 October 2020 when the “Sonny Line” was activated by
a co-accused Robert Hadwin.

**The respective cases and the trial**

8. The prosecution case was that ADG and BIJ were involved in the conspiracy to supply both cocaine
and heroin in Devon, between October 2020 and February 2022. ADG was aged [an age] at the start of
the conspiracy period and aged [an age] at its end. BIJ was also [an age] at the start and [an age] at its
end.

9. The prosecution case was broadly agreed, with a 50 page document setting out a substantial number of
agreed facts. As the judge said in the summing up to the jury about 98.5 per cent of the prosecution case
was simply written down in front of them.

10. ADG accepted involvement in the conspiracy to supply class A drugs. He accepted that his role
included manning a phone used for the supply of drugs, sending messages advertising drugs for sale, and
collecting and delivering drugs. BIJ also accepted his involvement in the conspiracy to supply class A
drugs, however he said he was only involved from October 2020 until about April 2021. After that date he
said he was still involved in the supply of drugs, however it was a different conspiracy that he was part of.

11. In his defence case statement ADG set out that the “general nature of the defence is section 45 of
**_Modern Slavery Act 2015”. It was said that ADG was “targeted, utilised and exploited by others”. In his_**
defence statement BIJ stated that “the defendant avails himself of a defence pursuant to s.45 of the
**_Modern Slavery Act 2015”. BIJ referred to pressure to pay off drugs and cash that had been seized from_**
him when arrested by the police.

12. ADG gave evidence at the trial. He explained about his background. He was subject to a care order
and was required to live where directed by Social Services, having seven different placements at various
locations throughout the indictment period. He said he had started selling drugs aged around [an age] or

[an age]. He agreed that he'd been involved with two of the drugs lines in the conspiracy, and that he'd
sent out a large number of broadcast messages advertising drugs for sale. He said that there were times
when he packaged the drug deals, and that he had personally sold drugs and collected the money. He
described how approximately £7000 in drug money went to the north west of the country every three
weeks, and said he would be paid £50 per week, as well as being given things like clothes and trainers. He
wouldn't give further details about the organisation saying his safety was at risk.


-----

13. On two occasions ADG had been collected by someone while he was in a care placement away from
Devon. On 6 December 2020 ADG was collected by a taxi driver from a care placement in Wrexham and
driven to Exeter where he was involved with drug dealing. On 13 April 2021 ADG ran away from a care
placement in Wales, but was intercepted by police in a car that was returning to Exeter. These matters
were included in the agreed facts.

14. ADG said that he had been threatened when involved with the supply of drugs in a different criminal
operation in September 2019, which resulted in the police recording a threat to life enquiry. There were
also a number of police intelligence reports between February 2020 and October 2021 detailing concerns
regarding exploitation and threats. ADG gave evidence that he owed people money because he kept on
losing drugs through arrests, so he carried on selling the drugs and being involved. He said that there was
a time when his debt was paid off, but he carried on selling drugs. He gave inconsistent answers about
whether there were threats made to him.

15. The defence on behalf of ADG also relied on a report from a consultant psychologist. The conclusions
of the report were set out in an agreed fact. These showed that ADG's intellectual functioning was at a
level that was considered a learning disability, and that he had dyslexia.

16. BIJ also gave evidence on his own behalf at trial. He gave evidence about his background and that he
had been in foster care since around 2018. He said he became involved in the supply of drugs in about
April 2020 when he started associating with ADG. He said drugs would be sent to him and he would sell
them to drug users. He said the money would be sent back to those in control.

17. BIJ said that he was threatened and accused of stealing drugs, and so he carried on selling drugs into
the indictment period. BIJ accepted manning a drug dealing phone and sending out broadcast messages.
He accepted directing others in the supply of drugs. He accepted selling drugs and collecting the money.

18. In April 2021 BIJ went to a foster placement in North Wales, before returning to Exeter on 26 April.
From that point BIJ continued to sell drugs, but said that it was not part of the indicted conspiracy. He said
he became involved with separate people from a different city. Police intelligence reports between
September 2020 and February 2021 detailing concerns regarding exploitation and threats were set out as
agreed facts.

19. In their evidence both ADG and BIJ gave evidence in terms about being compelled to do various acts.

**The summing up**

20. It appears that the judge provided counsel with a draft of his proposed directions. At that stage the
judge proposed to direct the jury that this was a case where trafficking, as opposed to slavery, did not
arise. Representations were made about relevant journeys, including the journeys from care homes
arranged by others, and the judge agreed to remove his proposed direction that trafficking did not arise.
On behalf of ADG a legal direction on the meaning of exploitation and human trafficking was sought, but
the judge made no further alteration to the draft directions.

21. It appears that no one on behalf of either the prosecution or defence identified that the draft directions
included “compulsion” as an element of the defence, when it was not part of the section 45 defence so far
as it related to persons under the age of 18 years.

22. The judge then gave his legal directions and a route to verdict. So far as is material the judge directed
the jury under the question “what is modern slavery” as follows:

_“ADG and BIJ have both said in evidence that they only participated in their actions within the conspiracies_
because they were compelled to do so. The defence case is that the compulsion in question overpowered
any capacity to resist taking part and that this applied at all stages throughout the period in question.
There was never an occasion throughout the period when they were not operating under these
circumstances of compulsion.

The first question for you to decide is whether you conclude on the evidence, as you find it to be, that ADG
and _BIJ (considered separately) were engaged in the conspiracies, i.e. engaged in the drug supply_


-----

activities, only by reason of compulsion – or that this may have been the position. If this is your decision,
you will proceed to consider a second question, appearing shortly below.

However, if you are sure that this was not the position, sure on the evidence that the defendant whose
case you are considering was not operating only by reason of the compulsion asserted, you will not
proceed to the second question because you would then have rejected the existence of “modern slavery”
compulsion arising in the first place and your verdicts will be “guilty”.

If you decide that they either were, or may have been, compelled as they have asserted in evidence then
you must move on to the second question, which is this: has the prosecution made you sure that a
reasonable person in the same situation as ADG and BIJ (considered separately), of his age (in both cases
through the period in question [an age], [an age] and [an age]) and male sex, sharing any of his physical
characteristics and/or features of mental illness or psychological limitations and/or physical disabilities
would not have engaged in the conspiracies as each of them admits that they did?

There is no evidence in this trial of physical disability or mental illness. You have received evidence by
way of “agreed facts” as to the opinion of a consultant psychologist as to ADG's IQ and dyslexia.

As to that second question, if the prosecution have made you sure that a reasonable young male person
with similar characteristics to the defendant whose case you are considering would not have been involved
in the conspiracies to commit serious class A drug supply offences, your verdict for that defendant will be
“guilty”.

If the prosecution have not made you sure of this then your verdict will be “not guilty” for the defendant in
question.

I summarise all of the above in the following “route to verdicts” in relation to ADG and BIJ.”

23. The judge then set out the routes to verdict for ADG and BIJ in the following terms:

“1. Are you sure that the defendant whose case you are considering was not operating within the
conspiracies during the period of time in question only by reason of the compulsion asserted on his behalf?

If, “yes, we are sure of this, he was not operating only by reason of compulsion”, your verdicts are “guilty”
and you go no further.

If, “no, we are not sure of this – we have decided that he was operating under that compulsion, or that he
may have been”, then proceed to question 2.

2. Are you sure that a reasonable young male person with similar characteristics to the defendant whose
case you are considering would not have been involved in the conspiracies?

If, “yes, we are sure of this, a reasonable similar young male would not have been involved”, your verdicts
are “guilty”.

If, “no, we are not sure of this, we have decided that such a reasonable other young male would have been
involved, or may have been involved”, your verdict is “not guilty”.

(underlining added to identify passages relating to compulsion)

24. Other appropriate legal directions were given. As was to be expected of HHJ Rose, the rest of the
summing up was conspicuously fair and accurate.

**Relevant statutory provisions**

25. Section 45(1), (2) and (3) relate to the defence of modern slavery for those aged 18 years and over.
The provisions of section 45(4) relate to the defence for those aged under 18 years. The defence for those
aged 18 years and over includes a requirement to show that the defendant was compelled to do the act
which constituted the criminal offence. There is no such requirement for those aged under 18 years. The
provisions of section 45 of the 2015 Act are as follows:

“Defence for slavery or trafficking victims who commit an offence


-----

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5) For the purposes of this section—

_“relevant characteristics” means age, sex and any physical or mental illness or disability;_

_“relevant exploitation” is exploitation (within the meaning of section 3) that is attributable to the exploited_
person being, or having been, a victim of human trafficking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.

(8) The Secretary of State may by regulations amend Schedule 4.”

(underlining added to show compulsion is an element of the defence for those over the age of 18 but not
for those under the age of 18).

26. The defence in section 45 uses phrases set out in: section 1 of the 2015 Act which refers to “slavery,
servitude and forced or compulsory labour” and defines an offence; section 2 of the 2015 Act which refers
to “human trafficking” and defines that offence; and section 3 of the 2015 Act which defines exploitation.

27. Section 1 is headed “Slavery, servitude and forced or compulsory labour”. In section 1(2) it is provided
that slavery or servitude and forced or compulsory labour are to be construed in accordance with article 4
of the Human Rights Convention. The Human Rights Convention is defined in section 13 as the European
Convention on Human Rights and Fundamental Freedoms (ECHR). As is well known article 4 of the
ECHR defines what does not amount to forced or compulsory labour (for example military service) but
does not provide a further definition. Section 1 of the 2015 Act provides:

“(1) A person commits an offence if—

(a) the person holds another person in slavery or servitude and the circumstances are such that the person
knows or ought to know that the other person is held in slavery or servitude, or

(b) the person requires another person to perform forced or compulsory labour and the circumstances are
such that the person knows or ought to know that the other person is being required to perform forced or
compulsory labour


-----

(2) In subsection (1) the references to holding a person in slavery or servitude or requiring a person to
perform forced or compulsory labour are to be construed in accordance with Article 4 of the Human Rights
Convention.

(3) In determining whether a person is being held in slavery or servitude or required to perform forced or
compulsory labour, regard may be had to all the circumstances.

(4) For example, regard may be had—

(a) to any of the person's personal circumstances (such as the person being a child, the person's family
relationships, and any mental or physical illness) which may make the person more vulnerable than other
persons;

(b) to any work or services provided by the person, including work or services provided in circumstances
which constitute exploitation within section 3(3) to (6).

(5) The consent of a person (whether an adult or a child) to any of the acts alleged to constitute holding the
person in slavery or servitude, or requiring the person to perform forced or compulsory labour, does not
preclude a determination that the person is being held in slavery or servitude, or required to perform forced
or compulsory labour.”

28. Section 2 is headed “Human trafficking” and provides that:

“(1) A person commits an offence if the person arranges or facilitates the travel of another person (“V”) with
a view to V being exploited.

(2) It is irrelevant whether V consents to the travel (whether V is an adult or a child).

(3) A person may in particular arrange or facilitate V's travel by recruiting V, transporting or transferring V,
harbouring or receiving V, or transferring or exchanging control over V.

(4) A person arranges or facilitates V's travel with a view to V being exploited only if— (a)the person
intends to exploit V (in any part of the world) during or after the travel, or (b)the person knows or ought to
know that another person is likely to exploit V (in any part of the world) during or after the travel.

…”

29. Section 3 is headed “Meaning of exploitation” and other phrases used in sections 1 and 2 and
provides:

“(1) For the purposes of section 2 a person is exploited only if one or more of the following subsections
apply in relation to the person.

_Slavery, servitude and forced or compulsory labour_

(2) The person is the victim of behaviour—

(a) which involves the commission of an offence under section 1, or

(b) which would involve the commission of an offence under that section if it took place in England and
Wales.

_Sexual exploitation_

(3) Something is done to or in respect of the person—

(a) which involves the commission of an offence under—

(i) section 1 (1)(a) of the Protection of Children Act 1978 (indecent photographs of children), or

(ii) Part 1 of the Sexual Offences Act 2003 (sexual offences), as it has effect in England and Wales, or

(b) which would involve the commission of such an offence if it were done in England and Wales.

Removal of organs etc


-----

(4) The person is encouraged, required or expected to do anything—

(a) which involves the commission, by him or her or another person, of an offence under section 32 or 33
of the Human Tissue Act 2004 (prohibition of commercial dealings in organs and restrictions on use of live
donors) as it has effect in England and Wales, or

(b) which would involve the commission of such an offence, by him or her or another person, if it were done
in England and Wales.

Securing services etc by force, threats or deception

(5) The person is subjected to force, threats or deception designed to induce him or her—

(a) to provide services of any kind,

(b) to provide another person with benefits of any kind, or

(c) to enable another person to acquire benefits of any kind.

Securing services etc from children and vulnerable persons

(6) Another person uses or attempts to use the person for a purpose within paragraph (a), (b) or (c) of
subsection (5), having chosen him or her for that purpose on the grounds that—

(a) he or she is a child, is mentally or physically ill or disabled, or has a family relationship with a particular
person, and

(b) an adult, or a person without the illness, disability, or family relationship, would be likely to refuse to be
used for that purpose.”

**Issues on the appeal**

30. Both ADG and BIJ rely on a ground of appeal that the judge wrongly directed the jury that ADG and
BIJ needed to show that there was or may have been compulsion to make good the defence under section
45 of the 2015 Act. The element of the defence requiring compulsion applied to those over 18 years.

31. A further ground of appeal was raised in relation to ADG. That was to the effect that the judge had
wrongly refused to direct the jury upon the issue of 'relevant exploitation' going beyond the slavery aspect
of the defence available under the Act.

32. Mr Parkhill on behalf of ADG and Mr Ticehurst on behalf of BIJ submitted that the directions referred
on several occasions to 'compulsion' which is a requirement under section 45 of the 2015 Act as the
defence applies to those aged over 18, but it is not required by the 2015 Act for those under 18 years.
That simply requires that a reasonable person in the same situation and with the child's relevant
characteristics would do what the child did. The direction that the appellants had to be acting as they did
because of “compulsion” incorporated an element of the section 45 defence as it applies to those over 18
and was wrong. They rely on the decision of the Court of Appeal in _R v NHF_ _[[2022] EWCA Crim 859](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S2-RRH3-CGX8-016K-00000-00&context=1519360)_
where a conviction for being concerned in the supply of class A drugs was quashed. In that case the judge
had misdirected the jury as to the elements of the section 45 defence in the 2015 Act by requiring the
appellant to show that there was “no realistic alternative” to carrying out the act, which appeared to be a
reference back to compulsion, when there was no requirement under the statutory offence to do so.

33. On the issue of exploitation Mr Parkhill submitted that the failure to give further directions on the issue
of exploitation meant that the jury were not given the assistance that they required and that the conviction
was unsafe.

34. Mr Tully KC and Mr Bremridge on behalf of the prosecution accepted that the judge had referred to
compulsion in his directions. They submitted, however, that the defence in this case involved the
suggestion that both defendants were the 'victims of slavery' and not 'victims of relevant exploitation'
meaning human trafficking. As such the issue of compulsion/coercion/forced labour was central to the
defence being raised. The presence of terms 'compelled' and 'compulsion' in the legal directions in this
case did not render the convictions unsafe in respect of either ADG or BIJ. This was because it was


-----

necessary to address that central issue in a case where the defence of both young people was based upon
the assertion by them that each had only acted as they did because they were compelled to do so because
they were 'victims of slavery'.

35. As to the issue of 'relevant exploitation' and human trafficking Mr Tully and Mr Bremridge submitted
that the judge did not need to give directions beyond the direction given on **_modern slavery within the_**
meaning of the Act. The Judge's decision not to include 'relevant exploitation' within the direction was not
an error which rendered the convictions unsafe. Although it was correct that ADG had been transported
between locations, there was no evidence that he was the victim of human trafficking. The prosecution
pointed to the fact that in the 16 month period covered by the indictment dates, ADG was moved between
addresses in Kingsteignton, Bideford and Uffculme where he continued to supply drugs but where a similar
claim of trafficking is not made. Having heard the evidence over the course of approximately 3 weeks, the
Judge was entitled to conclude that the trips were part of the narrative of the direction on modern slavery
rather than give rise to a separate direction on human trafficking.

**Unsafe convictions**

36. It is apparent from the directions on law and the routes to verdict provided to the jury and set out in
paragraphs 22 and 23 above that the judge did direct the jury that ADG and BIJ would have to show either
that they became engaged in the conspiracies, or might have become engaged in the conspiracies,
because of compulsion. This would have been a proper direction for a defendant who was over 18 years
because of the terms of section 45(1), (2) and (3). Section 45(1)(b) and (c) requires that the defendant
commits an offence “because the person is compelled to do it” and that “the compulsion is attributable to
slavery or to relevant exploitation”.

37. Although the objective test for both over and under 18 year old defendants is in similar terms, see
paragraph 45(1)(d) and 45(4)(c), the defence for those under 18 years does not include the requirement to
show compulsion. What is required by section 45(4) is for the person under 18 to have committed the
offence as a “direct consequence of the person being, or having been, a victim of slavery or a victim of
relevant exploitation”. It is apparent that a requirement to show compulsion is more onerous than a
requirement to show that the relevant act was committed as a direct consequence of the person being, or
having been a victim of slavery or a victim of relevant exploitation.

38. It is unfortunate that when the judge circulated his draft directions this point was not picked up by
either prosecution or defence. It might be noted that it does not seem that either the prosecution or
defence had focussed on the critical difference between the elements of the section 45 defence for those
over 18 years and those under 18 years. Be that as it may, in circumstances where the judge has added in
another element to the defence which the law does not require, and in circumstances where it is not
possible to say that the jury were not influenced by that additional step on the routes to verdict, in our
judgment the convictions of both ADG and BIJ are unsafe. We therefore quash their convictions for
conspiracy to supply class A drugs.

39. It might be noted that with _R v NHF,_ this is the second case in which it is apparent that the critical
difference between the section 45 defence for those aged 18 years and over, and those aged under 18
years, has been missed. This may have something to do with the fact that sections 45(1), (2) and (3)
relate to the defence for those aged 18 years and over, and it is only section 45(4) that relates to those
aged under 18 years. It highlights the importance of reading carefully the relevant statutory provisions.

**No retrial**

40. As noted above both ADG and BIJ had been convicted on their own pleas of separate drug offending,
and both had been sentenced to concurrent YROs. In these circumstances the quashing of these
convictions will not make any practical difference to the sentence which they are serving.

41. Mr Tully on behalf of the prosecution submitted that there should be a retrial because it appears that
ADG and BIJ are facing proceedings for breaching their YROs and there are proceedings relating to other
offences. This application was resisted on behalf of ADG and BIJ.


-----

42. These events occurred when ADG and BIJ were aged 14 to 16 years, and they are nearly aged 18
years. They were convicted on their own pleas of guilty to other and separate drug dealing. If ADG and
BIJ have been foolish enough not to take advantage of the opportunities offered to them by the YRO
imposed by the judge (and we are not in a position to say if that is the case), they can be dealt with for
those breaches, and if necessary for the original offences to which they had pleaded guilty, and any other
offending for which they are convicted. In these circumstances it is not in the interests of justice to order a
retrial.

**Conclusion**

43. For the detailed reasons set out above these appeals against conviction are allowed and the
convictions are quashed. We do not order a retrial.

**End of Document**


-----

