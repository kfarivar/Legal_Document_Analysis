# R v BRP [2023] EWCA Crim 40

Court of Appeal, Criminal Division

Carr LJ, Cavanagh J, HHJ Conrad KC

25 January 2023Judgment

**Ms Paramjit Ahluwalia (instructed by Philippa Southwell of Birds Solicitors) for the Appellant**

**Mr Andrew Johnson (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date: 13 January 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10am on Wednesday 25 January 2023 by circulation to the parties or
their representatives by e-mail and by release to the National Archives.

.............................

**Lady Justice Carr:**

**Anonymity**

1. We make an anonymity order in this case in order to protect the interests of the proper administration of
justice. We bear in mind that the normal rule is open justice, but an anonymity order on the facts of the
present case is strictly necessary, pursuant to the principles identified in R v AAD and others _[[2022] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
_[Crim 106; [2022] 1 WLR 4042(“AAD”) at [3] and [4] and summarised in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_ _Human Trafficking and_ **_Modern_**
**_Slavery Law and Practice (2nd ed) (at 8.103-8.108). The risk to the applicant of being the subject of forced_**
labour in the United Kingdom (“UK”) is real.

**Introduction**

2. We have before us an application for leave to appeal against conviction, together with an associated
application for an extension of time (of almost three years). Both applications have been referred to the full
Court by the Registrar.

3. The applicant, who is Chinese, is now 31 years old. On 10 June 2019, in the Crown Court at
Birmingham before HHJ Montgomery KC, he pleaded guilty to a single count of conspiracy to supply Class
B drugs. On 16 August 2019, alongside six other Chinese co-defendants, he was sentenced by HHJ Drew
KC (“the Judge”) to 18 months' imprisonment.

4. He now seeks to challenge his conviction on the ground that he was not advised, as it is said he should
have been, of the possibility of a defence under s. 45 of the Modern Slavery Act 2015 (“s. 45”) (“the Act”).
At the time of the alleged offending he was a victim of forced labour and relevant exploitation. The
contention is that a s. 45 defence would quite probably have succeeded and that, applying the test in R v
_Boal [1992] QB 591(“Boal”), the conviction is unsafe._


-----

5. We consider the appeal to be arguable. As for delay, the applicant's new solicitors have served two
witness statements setting out the relevant timeline. Given that the appeal is arguable, that the delay has
been explained and justified in large measure, and the nature and importance of the issues raised, it is in
the interests of justice to grant the necessary extension of time. We therefore grant leave for the appeal to
be heard in full and proceed accordingly.

**The facts**

6. In the afternoon of 22 January 2019 police attended the Southside Apartment Complex, a complex set
in a gated and affluent part of Chinatown in Birmingham. One of the appellant's co-defendants arrived in a
taxi carrying a large cardboard box. He was approached and informed that he was to be the subject of a
drugs search, to which he responded that he would tell the police everything, and was taking the box to
“Flat 324” (“the Flat”). He indicated to the police that the box contained cannabis.

7. The appellant was then seen to exit the Flat. He smelt strongly of cannabis. He was detained, along
with five other co-defendants who were either also leaving or found within the Flat. The Flat contained two
bedrooms. Police found and seized multiple mobile telephones, several Chinese passports and other
documentation, English and Scottish bank notes, and approximately 50 kgs of “skunk” cannabis. The value
of the drugs was estimated to be over £200,000.

8. The appellant and his co-defendants were charged with conspiracy to supply on a single day, namely
22 January 2019.

**The guilty plea and sentencing process**

9. All but one of the defendants pleaded guilty. The appellant entered his guilty plea at the pre-trial review
on a signed written basis dated 20 May 2019 (“the basis of plea”) which stated:

“1. That he was illegally resident in the UK; he did not have any family or support basis in the UK.

2. That he was induced through exploitation by others and his own naivety into “the Conspiracy”.

3. That he made no financial gain from any profits of drugs supply.

4. He was made to live with several others in a small flat and had to share one room.

5. His passport was taken away from him.

6. All his personal belongings were contained in one small suitcase.

7. He had no influence over any other person.

8. His involvement in “the Conspiracy” falls just short of Duress.

9. Whilst he was aware that Cannabis was being held in the flat he took no part in the packaging or
processing of the same.

10. His involvement did not exceed being an “extra body” in the flat.”

10. On 15 August 2019 the Judge posted a note on the Digital Case System as follows:

“All parties should be aware of the following: the bases of plea will need to be supported by evidence from
the defendants if they intend to maintain them, as will any other similar basis of plea advanced orally in
mitigation.”

11. It appears that the appellant did not pursue his basis of plea. No evidence was called and there was
no Newton hearing. The Judge did not refer to any basis of plea in his sentencing remarks.

12. The Judge indicated that “this was a commercial operation, run in an efficient and well-organised way
in which drugs came into the UK, were re-packaged and then prepared for onward supply either in this
country or elsewhere”. Although there was a clear connection to a more widespread operation, the Judge
did not sentence the appellant on that basis. He placed the appellant's offending in category 2/lesser role


-----

for the purpose of the relevant Sentencing Council Guideline. He took a term of 21 months' imprisonment
after trial, which he then reduced by 15% by way of credit for guilty plea.

**Fresh evidence and developments following conviction and sentence**

13. The appellant seeks leave pursuant to s. 23 of the Criminal Appeal Act 1968 to introduce fresh
evidence as follows:

i) A positive Reasonable Grounds decision of the Single Competent Authority (“SCA”) dated 21 February
2020 (“the RG Decision”);

ii) A positive Conclusive Grounds decision of the SCA dated 8 February 2022 (“the CG Decision”);

iii) A report of Professor Katona, consultant psychiatrist, dated 8 September 2021;

iv) An OASys report dated 7 April 2021 (“the OASys report”);

v) Two witness statements from the appellant dated 22 July 2021 and 6 June 2022.

14. This evidence self-evidently post-dates the appellant's conviction. We entertained it for the purpose of
the appeal hearing _de bene esse. We also permitted the appellant to give oral evidence and for his_
evidence to be tested in cross-examination.

15. The following facts and chronology of events emerge.

The appellant's entry into the UK in 2010

16. The appellant had entered the UK on a Tier 4 (General) Student Visa (valid from 18 December 2009 to
6 November 2012) in 2010 in order to study English at Bournville College. In his oral evidence he stated
that the course involved around three to five hours' study a day, and that the annual cost of the course was
around £4,000. The fees were paid by his parents in China into his UK bank account (with the Bank of
China). His visa was curtailed in March 2012 when he ceased to study. He remained thereafter as an
overstayer. He had many jobs thereafter, including cleaning, washing and working for takeaway
restaurants.

The appellant's arrests in 2014 and issue of a bench warrant

17. The appellant was arrested on suspicion of attempted kidnap in June 2014 and served with
immigration papers notifying him of his overstayer status. In September 2014 he was arrested for
production of a controlled (class B) drug. In May 2015 a bench warrant was issued for his arrest in relation
to the drugs matter.

The appellant's asylum claim: 2014/2015

18. In October 2014 he claimed asylum. In his screening interview on 23 October 2014 he stated that he
came to the UK by air to study. His father had been arrested by the government for religious reasons. He
did not know whether his father was alive and believed that he would be persecuted as his father was,
were he to be returned. He stated that he could not produce his passport because it had been lost in a
burglary. He stated that he had been arrested in the UK and released without charge, because he (and his
friend) had done nothing wrong. In interview in March 2015 he stated that he had a girlfriend and a child in
the UK; he and his girlfriend were living together but not married.

19. His asylum claim was refused in November 2015. He had failed to attend a follow up interview and had
failed to attend his trial in the Crown Court. He was now listed as “wanted” on the Police National
Computer.

Events of 2019

20. The appellant's bench warrant remained in place until March 2019 when it was withdrawn. No
evidence was ultimately offered on the drug charge and on 2 May 2019 a verdict of not guilty was entered
under s. 17 of the Criminal Justice Act 1967.


-----

21. Following the appellant's conviction in June 2019, the Secretary of State for the Home Department
decided (on 29 August 2019) to deport him. On 24 December 2019, having completed his sentence and
been further detained in immigration detention, he was granted immigration bail.

Events of 2020 and the RG Decision

22. On 17 February 2020 the Salvation Army referred the appellant to the National Referral Mechanism
(“NRM”).

23. On 21 February 2020 he was the subject of the RG Decision. The appellant's account, as recorded in
the RG decision, included the following:

i) In November 2018 he was an illegal overstayer living with a friend in Birmingham. He did not have a job
and was “sofa-surfing”. In December 2018 his friend was not happy with him staying, so he started looking
for jobs online. He found an advert on a Chinese website called “Yingniao” for a cleaner's job, paying £25 a
day with accommodation and food. He applied successfully;

ii) The next day he was picked up by a man called “Big Bing” (also referred to as “Da Bing”) (“Bing”) and
taken to an apartment near the south side of Chinatown. He was told to clean the Flat and to cook,
although he was not allowed to go into the bedrooms or open their doors. He would sleep on the floor of
the lounge; two men would also sleep in the apartment. He told Bing that he had a partner and a son, and
showed him a picture of his son;

iii) At the house he smelt a distasteful smell from a box. When he asked about it, he was slapped and
kicked by Bing. He was told that it was cannabis and not to ask questions and do his job. He was to clean,
get rid of the smell and any mess, to dismantle the boxes and dispose of the rubbish. He never touched the
cannabis. When he objected to being involved in any illegal activities, Bing put his foot on the appellant's
chest/heart and threatened to kill him if he told anyone. Bing said he would tell the police about his illegal
overstayer status and threatened the appellant's family. The appellant was very scared as Bing said that he
was part of a gang. The appellant was told not to think of escaping as they would take his partner and
child. The appellant felt like he had no choice but to abide by their instructions. There were no further
threats because he did as he was instructed;

iv) He did all the cleaning and cooking. He would sometimes have to go out to buy things when visitors
came, and to serve them;

v) The police raid was about a month after he started. Boxes would come once a week, although
sometimes there would be no deliveries.

24. Two of the appellant's co-defendants were named by the appellant as individuals who had exploited
him.

Events of 2021/2022: the OASys report, the appellant's witness statement, the report of Professor Katona
and the CG Decision

_The OASys report_

25. The OASys report completed by the National Offender Management Service (“NOMS”) recorded the
appellant stating that he applied for a cleaning job at a flat and was then forced to be involved with the
index offence. He stated that those actually in charge of the operation were not arrested. The report also
recorded that the appellant was currently living with his partner and child in Coventry. They had been living
together since 2016. The child is not the appellant's son but the appellant had requested that his name be
put on the child's birth certificate. He relied on his partner for financial support and also received a stipend
from the Red Cross.

_The appellant's witness statement_

26. In a very lengthy witness statement dated 22 July 2021, the appellant gave details of his background
and relationship with his girlfriend and her son. He described how in 2011 he helped his girlfriend use
th ' id tit t t Th b l i M /J 2011 d th hild


-----

was born in August 2011. The appellant treated him like a son. His girlfriend left him in October 2011 but
came back to him in January 2012. He then left her in the summer of 2012. He went briefly to Manchester
but then to Birmingham. In 2014 he re-made contact with her, when she was living in Coventry with her
son. He visited but did not stay with her permanently because the accommodation was not suitable. But, in
2016 his girlfriend moved to a different council house. By this time they were a couple again. The council
rules meant that he could not stay there permanently so he only stayed occasionally. He would otherwise
sleep with different friends and occasionally on the streets, working odd jobs.

27. In relation to the circumstances leading up to and surrounding his arrest in January 2019, he repeated
the account recorded in the RG decision, with added detail. For example, when Bing put his foot on the
appellant's chest, he had also called over three other individuals who started to beat the appellant. Bing
also kicked the appellant and, having threatened to go to the police and find the appellant's family, said
“Are we clear?” The appellant stated that Bing said that he was a Triad, and if the appellant tried to run
away he would be able to find him or go after his family. Although the appellant never saw Bing again, Bing
would call through to check where he was and that he was working. Two other Chinese males were always
present in the Flat. Even when the appellant was allowed to leave the Flat, he said that he could not really
escape or go to the police or anyone else, because he was scared as a result of being told of the Triad
connection and potential repercussions. He was never paid any money and was too scared to ask about
this. He was very intimidated by those coming into the Flat and continuously received threats. He stated
that he was kept in custody with some of his co-defendants. He felt scared and was threatened. He
described telling his solicitor everything upon his release in December 2019, which led to his referral into
the NRM.

28. The appellant addressed his asylum claim in 2014. He also sought to clarify events relating to the day
when he took a child to the Home Office, namely 22 October 2014. He was attending for reporting or an
interview. He states that he had been asked that day to look after a friend's son, aged four or five years old.
When asked who the child was, he panicked and gave the details of his girlfriend's son. He also said that
he was the father, since he knew that his name was on the boy's birth certificate. He continued the lie the
next day in a screening interview. In March 2015 he falsely stated his partner's identity; he says he did so
because that was the name on the boy's birth certificate. He responded to the refusal of his asylum and
human rights claims and mentioned his arrest in June 2014.

29. In his oral evidence before us he repeated that he could not leave the Flat after the first day because
he had been threatened by Bing, who was a gangster. He denied knowing how to get help from the
authorities, despite having lived in the UK for some nine years. He only met Bing once. The extent of what
Bing knew about his family was the area in which they lived, and the bus route that was closest to their
home. He was allowed to leave the Flat, but only when given money to buy food. He admitted that he could
have contacted the police but said he was afraid; the police could not provide 24-hour protection. He did
not know if the two people in the Flat with him worked for Bing. He did not think about running away. He
denied making up his account now to find a way of avoiding the consequences of his actions. When asked
what had changed, so that he could speak about Bing now, he stated that Bing did not know his
whereabouts anymore. The environment was different. He stated that he is currently living with his partner
and son in her council house.

_The report of Professor Katona_

30. In his report dated 8 September 2021, following two remote interviews with the appellant and with an
interpreter present, Professor Katona opined that the appellant fulfils the criteria for post-traumatic stress
disorder (“PTSD”). He based his diagnoses on the presence of the following clinical features:

i) The appellant's description of experiencing significant stressors (being threatened, beaten, confined and
forced to work);

ii) The appellant's description of intrusion phenomena in the form of intrusive thoughts and nightmares;

iii) The appellant's description of avoidant behaviour in the form of trying to suppress his intrusive thoughts
and not going to Birmingham's Chinatown;


-----

iv) The appellant's description of significant alterations in arousal and reactivity in the form of disturbed
sleep, irritability and being easily startled;

v) The appellant's description of having quite prominent negative alterations in cognitions and mood in the
form of low mood and loss of interest;

vi) The fact that the appellant's PTSD symptoms had lasted for more than a month, had considerable
functional significance to the extent of substantially impeding his day-to-day activity and could not be
explained in terms of alcohol, medication, illicit drugs or other health problems.

31. In Professor Katona's view, the appellant's depressive and anxiety symptoms were best understood as
“secondary to his PTSD”.

32. Professor Katona recognised that it was not for him to come to any conclusions regarding the
appellant's credibility. However, he stated that nothing in the appellant's account was “not clinically
plausible”. Further, in his opinion, the appellant was not feigning or exaggerating his symptoms.

_The CG Decision_

33. The CG Decision was made on 8 February 2022. The SCA accepted that the appellant was a victim of
“modern slavery in United Kingdom during December 2018-January 2019 for the specific purposes of
forced labour”.

34. The SCA commented:

“The [appellant] has given a generally detailed, plausible and relatively consistent account in relation to his
claimed exploitation through his NRM referral and witness statement. Furthermore, it is noted that the
account is also consistent with external information from the US State Department Trafficking in Persons
Report 2021 in relation to the UK. The report stated that traffickers force adults to work in cannabis
cultivation…”

35. It gave weight to the views of Professor Katona, including as to credibility, and to a trafficking
assessment report dated 9 September 2021. It stated that there were no significant credibility issues in the
appellant's account. The SCA went on:

“Looking at the evidence in the round, it is considered the [appellant's] account has met the required
threshold, namely “on the balance of probabilities” it is more likely than not to have occurred.”

36. The SCA concluded:

“Overall, it is considered that the [appellant] was recruited through an online job advert. The [appellant] was
then transported from Chinatown (Birmingham) to a flat in the south of Chinatown (Birmingham). As a
result of the recruitment and transportation the [appellant] meets part “a”. The [appellant] was beaten and
was subjected to death threats towards himself and his family, thus meeting part “b”. Lastly, it is considered
that [the appellant] was forced into providing labour against his will, in which he received no pay, therefore
meeting part “c”.”

(References to parts “a”, “b” and “c” are references to the “action”, “means” and “purpose” elements of
trafficking).

Responses from the appellant's previous lawyers

37. According to the appellant's new solicitors, they received “some immigration and some trafficking
material” from Lisa's Law Solicitors on 5 March 2020. The appellant instructed them to advise on appeal
against conviction on 16 March 2020. There is a chronology of the steps taken between April 2020 and
January 2022 to obtain relevant paperwork from the court, the SCA, immigration solicitors and his previous
legal team, alongside obtaining legal aid.

38. In a statement dated 6 June 2022 the appellant stated that he was relieved when arrested because
this meant that he was “no longer under the control of [his] traffickers”. He did not tell the police about his
treatment because he had been told that “they were a triad of gangsters and had powerful connections”.


-----

He was not referred to the NRM, or advised of a s. 45 defence at any stage during the criminal
proceedings.

39. Draft grounds of appeal were sent to the appellant's previous legal team on 17 May 2022 in
accordance with the procedure identified in R v McCook _[[2014] EWCA Crim 734; [2015] Crim LR 350.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C0P-34W1-F0JY-C187-00000-00&context=1519360)_

40. The original solicitors' files record the appellant's instructions at the police station on 23 January 2019
as follows:

“I was arrested outside flat. I have a friend…I didn't go inside. Said busy so I left. I don't know anything
about the drugs…”

41. The solicitor advocate representing the appellant at the time of his guilty plea stated that it was “very
likely the case” that the appellant was not advised in relation to the availability of a s. 45 defence. The
basis of plea would have been typed up during the course of a meeting with the appellant. Whilst there is
reference to “duress”, the solicitors' file contains no record of the potential availability of a s. 45 defence
being mentioned.

42. The application for leave to appeal conviction was lodged on 10 June 2022.

**Grounds of appeal and response**

43. Ms Ahluwalia for the appellant submits that his conviction is unsafe and should be quashed. At the
date of the index offence the appellant was a victim of forced labour, and subject to relevant exploitation.
The basis of plea included clear indicators of relevant exploitation, including inducing the appellant into the
conspiracy and making him live with several others in a small flat, sharing one room. At no stage did
anyone instigate a referral into the NRM. The appellant was never advised as to the availability of a s. 45
defence; he was deprived of a defence which would quite probably have succeeded. There is no challenge
by reference to abuse of process.

44. In terms of the appellant's credibility, Ms Ahluwalia emphasises the consistency of the appellant's
account since the OASys report and the fact, for example, that the police noted the appellant to be
“extremely nervous” when they apprehended him. The appellant had not exaggerated his case in the
witness box.

45. Ms Ahluwalia recognised that the weakest part of the appellant's case related to the test in s. 45(1)(d).
But, the appellant was in a real predicament. He had been the subject of actual violence on the first day
and thereafter Bing had mechanisms of control, keeping an eye on the appellant.

46. For the respondent, Mr Johnson submits that the appellant's account should not be accepted. But
even if that account were to be considered credible, the necessary ingredients of a s. 45 defence are not
made out. This was not in any way a “typical trafficking” case. A reasonable person in the appellant's
position would have walked away at or immediately after the first encounter with Bing, or when leaving the
Flat to go shopping.

**The relevant legal principles**

47. The relevant legal background and principles were summarised most recently in _R v AFU_ _[[2023]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
_[EWCA Crim 23 at [81] to [99]. For present purposes, it is sufficient for us to repeat the following summary](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
only.

S. 45

48. The UK provides protection for victims of forced labour through s. 45, which came into force on 31 July
2015 and applies to all (relevant) offences committed after that date. S. 45 provides materially:

“(1) A person is not guilty of an offence if:

(a) the person is aged 18 over at the time of the act which constitutes the offence;

(b) the person does that act because he is compelled to do it;


-----

(c) the compulsion is attributable to slavery or to relevant exploitation; and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if
(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation….

(5) For the purposes of this section
“relevant characteristics” means age, sex and any physical or mental illness or disability;

“relevant exploitation” is exploitation…that is attributable to the exploited person being, or having been, a
victim of human trafficking.”

49. S. 1 of the Act provides, amongst other things, that a person commits an offence if they require
another person to perform forced labour and the circumstances are such that they know or ought to know
that the other person is being required to perform forced labour. S.3 of the Act provides, amongst other
things, that a person is exploited if they are the victim of behaviour which involves the commission of an
offence under s. 1.

50. It is for the defendant to raise evidence of each of the elements in s. 45(1), and for the prosecution to
disprove one or more of them to the criminal standard: see _R v MK; R v Gega [2018] EWCA Crim 667;_

[2019] QB 86 at [45].

51. Decisions of the SCA are not admissible at trial, but are admissible on appeal when it is contended
that a person's trafficking status has been overlooked or inadequately considered (see R v Brecani [2021]
_EWCA Crim 731; [2021] 1 WLR 5851 at [40] and [41] and_ _AAD at [79] to [89]). Whilst not binding, the_
decisions will usually be respected, unless there is good reason not to do so. However, there may be
cases where it is necessary for an appellant's account to be tested independently for the purposes of safe
resolution of the issues on appeal; for example, where a finding of trafficking is based on unsatisfactory
evidence (see AAD at [108]).

52. As confirmed in R v V [2020] EWCA Crim 1355 at [25], a s. 45 defence does not arise automatically on
proof that a person was a victim of forced labour. Whether or not a s. 45 defence exists is entirely a
question of fact for a jury to decide. The degree of compulsion on the defendant, and the alternatives
reasonably available to them, are “critical features” of the analysis: “the offence must be committed as a
direct consequence of or in the course of trafficking or slavery and the criminality must be significantly
diminished or effectively extinguished because no realistic alternative was available but to comply with the
dominant force of another.”

Appeals against conviction following a guilty plea

53. The court should be cautious when overturning convictions following guilty pleas. As Lord Hughes
made clear in R v Asiedu _[[2014] EWCA Crim 567; [2014] 2 Cr App R 7 (“Asiedu”) at [19] to [25], and [32], it](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-N401-F0JY-C1S4-00000-00&context=1519360)_
will ordinarily be difficult to overturn a voluntary confession. The defendant, having made a formal
admission in open court that they are guilty of the offence, will not normally be permitted to change their
mind. The trial process is not to be treated as a “tactical game”.

54. Broadly, there are three categories of case in which a guilty plea may be vitiated, as summarised in R
_v Tredget_ _[[2022] EWCA Crim 108; [2022] 4 WLR 62(“Tredget”) at [154] to [180] and Archbold (2023 ed) at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
7-43 to 7-46. The relevant category for our purposes is that of cases where the guilty plea is vitiated. This
can occur in several circumstances, including the appellant being under the influence of controlled drugs
when they entered their plea (R v Swain [1986] Crim LR 480); a plea compelled by an adverse or incorrect


-----

ruling as to the law (Asiedu); improper pressure (R v Nightingale _[[2013] EWCA Crim 405; [2013] 2 Cr App](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_
R 7); or incorrect legal advice that deprived the defendant of a defence which quite probably would have
succeeded such that a clear injustice has been done.

55. An appeal can succeed if the guilty plea is vitiated by erroneous legal advice or a failure to advise as
to a possible defence, even where the advice may not have been so fundamental as to have rendered the
plea a nullity. In this case, the effect of the advice must be to deprive the defendant of a defence which
would probably have succeeded: _Tredget_ at [158]; _R v Kakaei (Fouad)_ _[2021] EWCA Crim 503; [2021]_
Crim LR 1079 (“Kakaei”) at [67].

56. This test derives from Boal, where the court emphasised that in such situations a conviction should be
overturned only “exceptionally”, where “a clear injustice has been done” (see 599-600). This passage was
cited with approval in R v PK _[[2017] EWCA Crim 486; [2017] Crim LR 716 (“PK”) at [12]. The exceptionality](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NHG-R6Y1-F0JY-C538-00000-00&context=1519360)_
of the defence was further emphasised in Tredget at [158] and R v PBL [2020] EWCA Crim 1445 at [23].

[57. The Dastjerdi checklist (see R v Dastjerdi [2011] EWCA Crim 365 at [9]), applicable when determining](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:528Y-VRD1-F0JY-C17B-00000-00&context=1519360)
whether a conviction following a guilty plea should be overturned, was subsequently applied in PK at [13].
On the facts in this case, as set out above, it requires:

i) That the appellant should have been advised about the possibility of availing himself of the [s. 45]
defence;

ii) That the appellant was not so advised;

iii) That, had [the appellant] been so advised, it was open to him to advance the defence;

iv) That the prospects that [the appellant] would have been able successfully to advance such a defence
were good.

**Analysis and findings**

58. The central issue on this appeal is whether or not the appellant had a good s. 45 defence. If he did, he
was deprived of the opportunity to advance it through the failure of his legal advisers to advise adequately,
including at the time that he entered his guilty plea, and there will have been a clear injustice.

59. As set out above, the respondent's position is that the appellant's account is not credible but that, in
any event, even if credible, the necessary elements of compulsion and a lack of realistic alternatives for a
successful s. 45 defence are not made out. The appellant, on the other hand, contends that he had a good
s. 45 defence, and that the prosecution would not probably have been able to disprove any of the
necessary elements of such a defence.

60. In order to resolve this dispute, we consider it necessary and expedient in the interests of justice to
admit the fresh evidence identified in [13] above, together with the appellant's oral evidence before us.
Neither the fact of the NRM referral, nor the RG or CG Decisions, were available before conviction.
Although not all of the material is necessarily reliable, it is relevant to the strength or otherwise of a s. 45
defence and/or the advice given to the appellant during his trial and the sentencing process.

61. The following factors point towards the appellant's central account relating to the events of December
2018 and January 2019 being credible:

i) The CG Decision;

ii) The fact that he mentioned being “induced through exploitation” and “duress” in his basis of plea;

iii) The fact that his account of events has remained largely consistent since the OASys report;

iv) The fact that the appellant did not exaggerate his evidence in the witness box. Thus, for example, he
confirmed that his face-to-face contact with Bing was limited to the first day when they met. He also stated
that he was not sure whether the two men who remained in the Flat with him were associated with Bing.
He did not suggest that he had given Bing details of his family's whereabouts beyond the broad area where
they lived and the relevant bus route;


-----

v) Professor Katona's diagnosis of PTSD and his view that the appellant's symptoms are clinically
plausible.

62. That said, there is real scope to doubt the appellant's credibility:

i) The CG Decision is based essentially on an acceptance of the appellant's account, relying on the
consistency of his version of events since 2021. That account was not tested by reference, for example, to
the instructions given by the appellant to his solicitors upon arrest (which made no reference to any form of
forced labour or exploitation). There was no reference to any of the more general and serious credibility
issues affecting the appellant referred to below. Further, there is force in the respondent's submission that
this was not a case requiring the application of the particular trafficking expertise of the SCA. There was no
clear international dimension; rather this was, on the appellant's case, a case of domestic forced labour;

ii) As for consistency, by the time that the appellant was speaking to NOMS in 2021 for the purpose of the
OASys report (and subsequently), he was well aware of the context, having been referred under the NRM,
and that it was in his interests to contend that he had been the subject of forced labour. This would also
have been the position at the time of his lengthy witness statement of July 2021, which appears to have
had the heavy input of lawyers;

iii) The appellant is someone capable of grave deception when he considers it to be necessary - either in
his own interests or the interests of those for whom he cares. He has a striking history of deception in
circumstances where there could be no excuse by reference to improper pressure, forced labour or
trafficking concerns. We refer, by way of example, to the appellant's introduction in 2011 of his then
pregnant partner to another lady whose identity his partner could steal for the purpose of facilitating access
to pregnancy healthcare in the UK. This was at a time when the appellant was lawfully resident here under
his student visa. In October 2014 he passed off another boy as his son when attending the Home Office.
His explanation is that he feared being arrested for kidnap. The following year, in 2015, he gave the Home
Office false details of his partner, with whom he said he was living and in a relationship;

iv) Further, making all due allowances for linguistic difficulties, the statement in the appellant's basis of
plea that he “had no family…in the UK” was, at best, misleading. It suited the appellant at that stage to
deny having any family in the UK; when it came to his asylum and human rights claims, he said quite the
opposite. On any view, his statement that he had no “support basis” in the UK was false, given the support
available to him from his partner;

v) The appellant's account is not inherently plausible. The suggestion is that one or more drug dealers
would advertise on an open platform for assistance which would involve bringing a complete outsider into
an environment that was obviously unlawful from the outset – a highly risky recruitment strategy. It is to be
noted that the appellant was arrested on a Class B drug offence in 2014, albeit that the charge was later
dropped. The circumstances surrounding the appellant's arrest for attempted kidnap earlier in the same
year are difficult to understand. It is also far from obvious why it was necessary to hold the appellant in the
Flat under any form of compulsion: he had no real function in the conspiracy, beyond clearing up the boxes
that carried the drugs. He was not a cannabis gardener, or a courier, for example.

63. In the end result, we have not found it necessary to resolve the question of whether or not it is likely
that the prosecution could have proved the appellant's account of the events of December 2018 and
January 2019 to be fundamentally untrue. That is because, even accepting his account for present
purposes, we consider it clear that the prosecution would have been likely to prove to the criminal standard
of proof that at least one of the necessary ingredients of a s. 45 defence was not made out.

64.  It is essentially common ground that, on the basis of the appellant's account, the requirements of s.
45(1)(a) and (c) would be made out. However, it is not accepted that the necessary degree of compulsion
would be established and, most fundamentally, that a reasonable person in the same situation as the
appellant and having his relevant characteristics (age, sex, physical and mental illness or disability) would
have no realistic alternative to doing the act in question.

65. At the material time the appellant was 27 years old and an overstayer in the UK. He had no physical or
mental illness or disability (There is no evidence from Professor Katona that he would have had any


-----

mental illness in the immediate aftermath of his arrival in the Flat.) He spoke at least some English: he had
studied it for two years between 2010 and 2012 (reaching ESOL level 2) and lived in the UK since then,
working in multiple jobs over the years. Before us it was clear that he could both understand and speak
basic English reasonably well. He had had considerable experience of interaction with the police and the
Home Office. He was alive to how the NHS worked (and how to gain access to it, albeit through dishonest
means) and, for example, council housing rules. He had a female partner (and someone he regarded as
his child) living not far away in this country, in a council house in Coventry. He had a wide network of
friends and contacts in the UK, as evidenced by his lifestyle and occupations between 2012 and 2018. He
had demonstrated his resourcefulness over this period, holding down various jobs. This is all consistent
with his demeanour in court, which was of someone well capable of fending for himself.

66. The only reason given by the appellant for not leaving the Flat permanently was fear of Bing, whom he
believed to be part of a gang, and what Bing (or others at Bing's behest) would do to him or his family.

67. Set against the background above, and even bearing in mind the appellant's immigration status and
any related disinclination to go to the police, the respondent would have been able to prove that the
reasonable person in the appellant's position would have felt able to leave, despite Bing's threats.

68. The threats were made only on the first occasion. Bing did not visit the appellant again. The appellant
did not know if the others in the Flat worked for Bing or not. The appellant had given only very limited
details of the whereabouts of his partner and son. Whilst it is important not to apply impermissible
hindsight, the appellant confirmed that Bing has never contacted (or threatened) his family. More relevant,
perhaps, is the fact that there is no obvious good reason why the appellant felt able from 2020 onwards to
name and accuse Bing, but suggested that he was too scared to leave the Flat in 2019 because of Bing's
threats.

69. Further, there is no suggestion that the appellant was held forcibly against his will within the Flat, for
example, or controlled when he went out alone. He had his own telephone at all material times, and was
able freely to make and receive calls, and did so. Unlike in a typical trafficking situation, the appellant had a
well-established network of unconnected contacts in the UK and, most importantly, a partner living in the
UK in settled accommodation to whom he could turn. In basic terms, he had somewhere to go, and many
different people from whom he could have sought help, beyond and in addition to the authorities. It is
notable that the author of the OASys report considered that the appellant had “acted recklessly in allowing
himself to become involved with this offence and took a risk in continuing to do so rather than walking away
from the crime”. As Mr Johnson put it for the respondent, a reasonable person in the appellant's situation
could realistically have walked away at the very outset or at least on one of the occasions when he was
alone and away from the Flat.

70. In short, a s. 45 defence advanced by the appellant would quite probably have failed, in particular by
reference to s. 45(1)(d). The objective reasonableness test would probably not have been satisfied: the
respondent would probably have been able to prove to the criminal standard of proof that a reasonable
person in the appellant's situation and with his relevant characteristics had a realistic alternative to being
involved in the conspiracy.

**Conclusion**

71. In conclusion, and for the reasons set out above, the appellant was not deprived of the opportunity of
advancing a good s. 45 defence. Although he should have been, but was not, advised of the availability of
a s. 45 defence before entering his guilty plea, there has been no clear injustice and his conviction is not
unsafe. The appeal is dismissed.

**End of Document**


-----

# R v BRP

## [2023] EWCA Crim 40

 Court: Court of Appeal, Criminal Division Judgment Date: 25/01/2023

# Catchwords & Digest

## CRIMINAL LAW—APPEAL—UNSAFE CONVICTION

 The Court of Appeal, Criminal Division, dismissed the appellant’s appeal against his conviction for a single count of conspiracy to supply Class B drugs which had sentenced him to a total of 18 months’ imprisonment. The appellant sought to challenge his conviction on the ground that he was not advised of the possibility of a defence under of the Modern Slavery labour and relevant exploitation and that a s 45 defence would quite probably have succeeded. The court held, among other things, that the appellant was not deprived of the opportunity of advancing a good s 45 defence. Although he should have been, but was not, advised of the availability of a s 45 defence before entering his guilty plea, there had been no clear injustice and his conviction was not unsafe.

# Cases considered by this case

R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

R v Tredget

_[[2022] EWCA Crim 108, [2022] 4 WLR 62](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
Considered

R v AAD and others

_[[2022] EWCA Crim 106, [2022] 1 WLR 4042](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
Considered

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Considered


20/01/2023

CACrimD

08/02/2022

CACrimD

03/02/2022

CACrimD

19/05/2021

CACrimD


-----

R v Kakaei

_[[2021] EWCA Crim 503, [2021] All ER (D) 87 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62WP-MT43-GXFD-8174-00000-00&context=1519360)_
Considered

R v MK (also known as D); R v Gega (also known as Maione)

_[[2018] EWCA Crim 667, [2019] QB 86, [2018] 3 All ER 566, [2018] 3 WLR 895, [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_
[2 Cr App Rep 210, [2018] All ER (D) 10 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5S2J-3TH1-DYBP-N4PT-00000-00&context=1519360)
Considered

R v PK (2017)

_[[2017] EWCA Crim 162](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N22-K3P1-F0JY-C4D7-00000-00&context=1519360)_
Considered

R v McCook

_[[2014] EWCA Crim 734, [2016] 2 Cr App Rep 388](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C0P-34W1-F0JY-C187-00000-00&context=1519360)_
Considered

R v A

_[[2014] EWCA Crim 567, [2014] 2 Cr App Rep 94, (2014) Times, 08 April](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-N401-F0JY-C1S4-00000-00&context=1519360)_
Considered

R v Nightingale

_[[2013] EWCA Crim 405, [2013] 2 Cr App Rep 69, (2013) Times, 26 March](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_
Considered

R v Dast Jerdi (Bakhshi Ali)

_[[2011] EWCA Crim 365](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:528Y-VRD1-F0JY-C17B-00000-00&context=1519360)_
Explained

R v Boal

[[1992] QB 591, [1992] 3 All ER 177, [1992] 2 WLR 890, [1992] BCLC 872, [1992] IRLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-61MW-00000-00&context=1519360)
_[420, [1992] ICR 495, (1992) Times, 16 March](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W51J-00000-00&context=1519360)_
Considered

R v Swain

_[[1986] Lexis Citation 2011](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PN7-SXT0-TXX5-50XD-00000-00&context=1519360)_
Considered

**End of Document**


08/04/2021

CACrimD

28/03/2018

CACrimD

31/01/2017

CACrimD

10/04/2014

CACrimD

19/03/2014

CACrimD

13/03/2013

C-MAC

07/02/2011

CACrimD

13/03/1992

CACrimD

circa 1986

CA


-----

