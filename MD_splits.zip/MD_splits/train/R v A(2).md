# R v A [2021] EWCA Crim 1316

CA, CRIMINAL DIVISION

2020 02075/02077/

Haddon-Cave LJ, Garnham J, Saini J

Thursday 29 April 2021

29/04/2021

[1. LORD JUSTICE HADDON-CAVE: An anonymity order is made under section 11 of the Contempt of Court Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0M0-TWPY-Y1JF-00000-00&context=1519360)
_[1981,the effect of which is to ensure that no publication is made in relation to this case of any matter which might](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0M0-TWPY-Y1JF-00000-00&context=1519360)_
tend to or otherwise identify the victim in this case, either directly or inferentially.

2. On 22 September 1993, at a Crown Court in London, the applicant, who we will call 'A' (then aged 16) was
convicted of robbery and subsequently sentenced to a probation order of 2 years.

3. On 12 May 1995, in a Crown Court outside London, the applicant (then aged 18) pleaded guilty to burglary, with
three further offences of robbery taken into consideration. He was sentenced later that year to 15 months'
detention in a young offenders' institution.

4. He applies today before us for an extension of time (of approximately 26 years in relation to the first conviction
and 25 years in relation to the second conviction) in order to appeal against both conviction and sentence. He also
[seeks leave, pursuant to section 23 of the Criminal Appeal Act 1968,to introduce fresh evidence.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1P8-00000-00&context=1519360)

5. This matter has been referred to the Full Court by the Registrar of Criminal Appeals. We have been greatly
assisted today by the written and oral submissions of Ms Ahluwalia on behalf of the applicant and Mr Johnson on
behalf of the respondent. For their cogent and measured submissions, we are most grateful.

6. This is in many ways an exceptional case, both, as we will briefly explain, in relation to the circumstances which
A had to endure and the length of time of the extension which is sought.

7. In summary the applicant, through Ms Ahluwalia, submits, first, that he was a victim of modern slavery and that
as such he should not have been prosecuted for these two offences, committed when he was under 18; second,
that the defence of duress was available to him then; and in the alternative, thirdly, that even if he was properly
convicted, his status as a Victim of Trafficking should have served to mitigate his sentence.

8. The background facts of this case involve the most serious and sustained above. The facts are outlined in the
Criminal Appeal Office summary. It suffices to record that the applicant gave evidence in two recent trials of two
individuals who had abused him from an early age. The first was sentenced in 2017 (a priest) to a total of 22 years'
imprisonment for the abuse which he perpetrated on A, which the judge described as a "heart￿breaking tale". In
the second trial, the perpetrator was sentenced to 10 years' imprisonment. The judge in that case explained how A
had travelled to this country as a young boy, where he was abused by the relatives with whom he lived. He ran
away from home but was eventually found and was placed into care. However he fell into the clutches of this
abuser, who then proceeded to abuse him for many years.


-----

9. At an immigration hearing before a First Tier Tribunal judge in 2019, in which the applicant made a human-rights
claim for indefinite leave to remain, which was granted, the tribunal judge summarised A's experience as follows:

"The [applicant's] life in the UK has been desperately tragic. His social worker ... describes it as well: '[A] catalogue
of systematic abuse and cruelty on a staggering scale.' ... the life to which the [applicant] was forced into as a
young child: first, into domestic servitude and forced labour, having been trafficked to the UK; and then, from the
age of about 11 or 12, he was the victim of physical abuse, violence and rape.

It is really quite difficult to conceive of a more appalling history of abuse or one that incites a greater sense of
repulsion at the crimes against the [applicant] ... "

10. The fresh evidence which Ms Ahluwalia seeks to adduce relates to evidence -- both ABE interview evidence,
as well as medical and other evidence relating to this history of abuse.

11. Ms Ahluwalia raised two grounds of appeal, but rightly, and sensibly in our view, concentrated on the second.
The first ground related, as we have said, to the fact that A was a victim of slavery, and it would not have been
considered, she submitted, in the public interest to prosecute him in the light of the CPS Code. She recognised that
there were difficulties with this particular argument, which in our view there are, not least because there is no
general power for the Court of Appeal to review the exercise of prosecutorial discretion or to allow appeals on the
basis that new information means that the prosecutorial discretion might have been exercised differently.

12. The gravamen of her case really relied on ground 2. In essence she submitted that had the actual
circumstances of force and sexual exploitation been known at the time of the proceedings in 1993 and 1995, A's
legal representatives would have advised him in relation to the availability of the defence of duress. She further
submits ￿￿ and there is no resistance from Mr Johnson ￿￿ that the subsequent trials of his perpetrators and
indeed the immigration proceedings themselves show him to be a credible witness in relation to the matters about
which he gave evidence and has submitted evidence before us in relation to the abuse which he suffered.

13. As we have said, this case is exceptional in a number of ways, not least the passage of time. The principles to
be applied in extension of time cases are well known. They have been helpfully summarised by the court in O

_[2019] EWCA Crim 1389 at 45:_

"In R v Hughes [2009] EWCA Crim 841 at [20] it was said that an extension would 'be granted only where there is
good reason to give it, and ordinarily where the defendant will otherwise suffer significant injustice'. In R v Thorsby

_[2015] EWCA Crim 1 it was stated 'the principled approach to extensions of time is that the court will grant an_
extension if it is in the interests of justice to do so'. It was also said in that case that 'the public interest embraces
also, and in our view critically, the justice of the case and the liberty of the individual…' and 'the court will examine
the merits of the underlying grounds before the decision is made whether to grant an extension of time.' It was also
noted that the passage of time may put the court in difficulty in resolving whether an error has occurred and if so to
what extent."

14. At paragraph 18 of Thorsby, the court observed that in circumstances where "a substantial passage of time
may put the court in difficulty in resolving whether or not an error has occurred and if so to what extent ... the court
may not be able to conclude that it would be in the interests of justice to intervene."

15. Ms Ahluwalia submits on behalf of A that A has a clear, indeed she would no doubt submit strong, case that A
had been the subject of duress, leading him to commit these offences when he was still under 18, and that at the
time when he pleaded to these offences, he would have still been so frightened and in the thrall of his abuser at that
time such that his ability to reveal to his legal advisers as to what had been going on would not have been possible.

16. Mr Johnson on behalf of the respondent accepts that the applications made today should be made on the basis
of A's account and accepts that the court should receive the fresh evidence relied upon by the applicant de bene
esse, which we do. He submits, however, that the application should be refused as it is not in the interests of
justice to grant an extension of time of this length. He submits that this is not a case in which it could be said that
there would be significant injustice to the applicant if an extension of time is not granted.


-----

17. We have carefully considered and reflected on the submissions that have been made on both sides. We have
concluded that this is not a case in which this court should grant an extension of time for the following reasons.

18. First, it is not clear as to why A did not or could not have raised these grounds earlier than 2021. In 2014, A
made a series of formal witness statements regarding the facts which had dominated his early life and an appeal
could have been lodged then which led to the conviction of his perpetrators. He instructed criminal solicitors in July
2014.

19. Second, but more significantly perhaps, it is difficult in this case to say that A would suffer significant injustice if
not allowed to challenge these two convictions. We will not rehearse the entire history of the applicant's life but
simply record the fact that, subsequent to A turning 18, he had, as Ms Ahluwalia accepted, a large tranche of other
convictions ￿￿ some of which are significant ￿￿ on his record. The latest printout of his record records 30
convictions for 64 offences of a significant variety, the most recent being convictions in 2014 for burglary and theft
at Southwark Crown Court and in 2013 at the Central Criminal Court. The two convictions which are the subject of
these applications have to be seen alongside the significant other record of the applicant.

20. Thirdly, as we have mentioned, A made an application for indefinite leave to remain in the United Kingdom and
that was granted by the Immigration Tribunal, the judge having said that this was a wholly exceptional case. In our
view it would make little or no difference to A's position in terms of his life prospects if these two convictions which
he seeks to challenge remained as they are. They are, in effect, minor convictions seen against a significant further
record of criminal behaviour and quashing them would make, in our view, no significant difference.

21. We understand the other points that Ms Ahluwalia has ably made in relation to this case. But, ultimately this
court has to come to an overall decision have regard to all the relevant factors, including finality. In our view, this is
not a case in which it could be said that the outcome of any challenge in terms of duress would be a foregone
conclusion. The test laid out in Boal, where a person seeks to overturn a plea of guilty, is a high one.

22. For all those reasons, we refuse the main application for permission to appeal and refuse the application for an
extension of time.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18￿22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

