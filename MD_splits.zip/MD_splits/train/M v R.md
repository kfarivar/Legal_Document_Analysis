# M v R [2021] EWCA Crim 1934

Court of Appeal, Criminal Division

Fulford VP, Knowles and Wall JJ

17 December 2021Judgment

**James Wood QC and Rupert Hallowes (instructed by Vickers Solicitors) for the Appellant**

**Bruce Douglas-Jones QC and Michael Attenborough (instructed by The Crown Prosecution Service)**
for the Respondent

Hearing dates: 27 July 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

NOTE – THE TRIAL IN THIS CASE HAS NOW TAKEN PLACE. ACCORDINGLY, THIS JUDGMENT IS NO
LONGER SUBJECT TO REPORTING RESTRICTIONS PURSUANT TO S.37 CPIA 1996. IT REMAINS THE
RESPONSIBILITY OF THE PERSON INTENDING TO SHARE THIS JUDGMENT TO ENSURE THAT NO OTHER
RESTRICTIONS APPLY, IN PARTICULAR THOSE RESTRICTIONS THAT RELATE TO THE IDENTIFICATION
OF INDIVIDUALS.

**Lord Justice Fulford VP :**

**The Background**

1. This is an application for leave to appeal under section 35(1) of the Criminal Procedure and
Investigations Act 1996.

2. The reporting of these proceedings is prevented until the conclusion of the trial, pursuant to section 37
of the Criminal Procedure and Investigations Act 1996, save for specified basic facts such as the name of
the accused and the offence, unless this court or the Crown Court orders that these provisions do not
apply. The Crown Prosecution Service is to inform the Court of Appeal (Criminal Division) when the
proceedings in the Crown Court have concluded.

3. M, now aged 26, is due to stand trial in the Crown Court at Isleworth in respect of the following offences:

i) Count 1 - controlling or coercive behaviour in an intimate or family relationship, contrary to section 76 (1)
[and (11) of the Serious Crime Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FFB-Y691-DYCN-C3GM-00000-00&context=1519360)

ii) Count 2 – holding a person in slavery or servitude, contrary to section 1(1)(a) of the Modern Slavery
Act 2015.

4. On 7 May 2021 at Isleworth Crown Court, Judge Edmunds QC (the Honorary Recorder of the Royal
Borough of Kensington and Chelsea) heard submissions from the applicant inviting him to exclude
evidence from the trial – before it is served on his co-defendants – that tends to demonstrate that his
sexual orientation is that of a gay man. The judge ordered that the issue should be determined during a
preparatory hearing, pursuant to section 29 of the Criminal Procedure and Investigations Act 1996
(“CPIA”) One of the issues that arises on this application is whether he was correct to do so The judge


-----

furthermore, agreed that the preparatory hearing should be heard in private and that the appellant's codefendants (viz. his father, mother, brother and sister) should not be notified it was taking place. Whether
that decision was sustainable equally falls for consideration on this application. In a written ruling dated 19
May 2021, the judge ruled, in summary, in favour of the Crown and rejected submissions by the applicant,
pursuant to section 78 of the Police and Criminal Evidence Act 1984 (“PACE”), to exclude this evidence. It
is against that ruling that the applicant seeks to appeal, the judge having refused permission. The judge
noted that the applicant decided, having considered the matter, not to argue that the perceived difficulties
concerning his sexuality could be addressed by an application for severance or for a stay of the
proceedings based on abuse of process.

5. Section 78 of PACE provides:

“(1) In any proceedings the court may refuse to allow evidence on which the prosecution proposes to rely
to be given if it appears to the court that, having regard to all the circumstances, including the
circumstances in which the evidence was obtained, the admission of the evidence would have such an
adverse effect on the fairness of the proceedings that the court ought not to admit it.

[…]” (emphasis added)

**The Facts**

6. The applicant is charged along with his father, mother, brother and sister on the two counts set out
above. The complainant is the applicant's wife, and the offending is said to have occurred between the 27
October 2017 and the 24 April 2019.

7. The family is of Muslim and Pakistani heritage. The applicant and the complainant are first cousins.
Their marriage, arranged when they were children, took place in November 2016 in Pakistan. The
complainant was then aged 19. The applicant returned to the United Kingdom after the wedding, and his
wife followed almost a year later in October 2017, moving from Pakistan to live with the applicant and his
family.

8. The prosecution case is that the applicant's father controls the household. Following the complainant's
arrival in this country, her role was that of a household servant. Her working day started around 5.00 am,
and she was forced to cook and clean until being permitted to go to bed at around 10.30pm.

9. It is alleged her mobile telephone and passport were confiscated, she was not allowed to leave the
house unaccompanied and she was subjected to verbal and physical abuse by various of the accused,
which included slaps, kicks and punches. She was told she would be killed if she tried to leave, and within
a few days of her arrival the applicant informed her he wished they had never married. He said he had
been forced into the union. He never demonstrated any affection towards the complainant and instead
assaulted her. She managed to escape in April 2019. The police became involved and the investigation
leading to the present charges commenced.

10. The Crown's case against the applicant is that the evidence concerning his sexuality is of importance.
Three areas are highlighted: first, images of naked men and erect penises were found on his mobile
telephone; second, chat logs revealed that he had been involved in two simultaneous gay affairs which had
created a strong emotional attachment to both men on the part of the applicant (there was communication
with two further men which similarly tended to indicate the applicant is gay); and, third, a significant assault
by the applicant on his wife occurred on the occasion of their second wedding anniversary, during the
course of these liaisons. The complainant describes this incident in her witness statement of 7 August
2019 as follows:

“On 11th November 2018 my husband hit me. I remember the date because it was our wedding
anniversary. We were in our bedroom. I was saying that it had been two years and I wasn't getting
pregnant as his relationship wasn't good with me. He was angry. He punched me on my back when I was
sitting on the bed. He got up off the bed and kept hitting me. I was wearing my night clothes. He was
pulling me. I was holding onto the bottom of the bed to stop him. He bit me on my right lower leg, making it
bleed. I couldn't hold on any longer. He pulled me out of the room. He grabbed me on my throat. I started


-----

getting a strange noise in my ears. My nose and mouth started bleeding. I kicked him and got up. I tried to
get into the bathroom. He pulled my shirt and it ripped on the right side. I got into the bathroom and locked
the door. I put cold water on my face to try and stop the bleeding. There was blood on my clothes. He was
knocking on the door. I was worried that my father-in-law would come home, take my husband's side and
hit me. I came out of the bathroom. My husband told me to change the bedsheet. I was crying. He said, "I
want to tell you one thing. It's not your fault you're not getting pregnant, that's my fault. I like men, my
parents don't know this, I'm gay." I was just looking at him. He said, "Don't tell my parents”. I said, "Don't hit
me again but be good with me. I will never force you for a baby. I will tell them I fell over in the garden."”

11. Against that background, the prosecution submits that the applicant's behaviour towards his wife
significantly reflects the stresses arising from these complex relationships, given his true sexual identity,
his discomfiture within a heterosexual marriage and the consequences for him if he revealed his sexuality
to his family and others within their community. Therefore, the Crown argues this emotional dichotomy
comprises an important element of the case against the appellant, providing the true context of his abuse
of his wife and his participation in the coercive, controlling and abusive behaviour directed at her. The
applicant, by way of his defence, suggests that the complainant has invented these allegations as part of a
wider plan to gain permanent residence in the United Kingdom, and that she intends to abandon her
marriage once that right had been gained.

**The Submissions in the Crown Court**

12. The applicant indicated to the judge in the Crown Court that his family are unaware of his sexual
orientation. It was contended that his sexuality was either of no relevance or it was of such marginal
relevance that it should be excluded. He argued these are private matters, the disclosure of which would
have a devastating impact, given his family are conservative followers of Islam, and he fears for his own
safety and, indeed, that of his family, should this be revealed. The applicant posited that Articles 2, 3, 6 and
8 of the European Convention on Human Rights (“ECHR”) are engaged, in that disclosure would:

a) Constitute a breach of his and his family's right to life under Article 2, since disclosure would place them
in realistic danger of death or injury by reason of hostile attitudes to such matters, including amongst some
members of the Islamic community in the United and Kingdom and in Pakistan;

b) Breach his right to a private life under Article 8 in that none of his family or members of the Islamic
community in this country are aware of his sexuality;

c) Infringe his right not to be subjected to torture or to inhuman or degrading punishment under Article 3,
given the treatment of homosexuals in Pakistan;

d) Undermine his right to a fair trial under Article 6, in that disclosure would result in the applicant being
unable to give his best evidence or he would be inhibited from giving evidence at all if confronted at trial by
such deeply personal and sensitive material

13. The applicant additionally argued in the court below that he relied on an alleged indication by the
police given prior to and during his questioning that this information would not be disclosed to his coaccused. This created, he argued, a legitimate expectation that the material would not form part of the
prosecution case.

14. Finally, the applicant purported to withdraw his consent to his data being processed (if his consent had
been lawfully obtained in the first place) under the General Data Protection Regulation. The Crown were
“put to proof” that the processing and continued use of his data (and that of the third parties) was lawful
[and fair in accordance with the Data Protection Act 2018 (“DPA”), focussing on section 35 of the DPA.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)

15. The Crown submitted that the judge did not have jurisdiction to allow the hearing to occur in private,
particularly given the application's apparent lack of merit. It was suggested the case did not meet the
criteria for a preparatory hearing. It was disputed that a non-disclosure undertaking had been given. It was
submitted that the contents of the applicant's mobile telephone were not rendered inadmissible on account
of the suggested breaches of the protections provided by the DPA. The Crown contended that the judge
should not exclude this evidence relating to sexuality under section 78 of PACE or otherwise.


-----

**The Ruling**

16. We have already referred to elements of the judge's ruling (see [4] above). The judge, following R v H

[2004] EWCA Crim 3325, decided that exceptionally it was necessary to hear the defendant's application in
private, excluding the other accused, on the grounds that otherwise the administration of justice would be
frustrated. He concluded that a preparatory hearing was justified given the arguments concerned the
relationship between section 78 of PACE and the ECHR in an entirely novel context, in circumstances
when the court was not being asked to resolve substantive issues of fact. The judge observed that it was
inconceivable that the applicant would be able to appeal his conviction if the evidence was not excluded
under section 78 of PACE.

17. The judge noted that, on occasion, it was inevitable that damaging or calamitous private matters would
be revealed in criminal proceedings, even to the extent of exposing an individual to the risk of harm. He set
out some of the protections which, consequently, have been established within the trial process. These
relate particularly, but not in any sense exclusively, to complainants and witnesses, such as allowing
evidence to be given anonymously and imposing restrictions on the introduction of evidence of previous
sexual behaviour or bad character. There are some protections for the accused, and by way of example he
highlighted that a judge's permission is required before the prosecution can reveal that a defendant has
acted as a police informer and there are restrictions on the introduction of evidence of a defendant's bad
character.

18. On the issue of the applicant's sexuality, the judge determined that this was more than marginally
relevant to the issues in the case, and he rejected the contention that the material was being deployed by
the prosecution to put pressure on the applicant to plead guilty. The judge highlighted that the credibility of
the complainant was in contention, given she was accused of fabrication. In his account to police in
interview on 25 April 2019, as reiterated in his draft defence statement, the applicant asserted that his
relationship with his wife was “quite good”, “the relationship with my wife is all good” and “I didn't know
_there were any issues”. He maintained that the complainant had fallen out with her mother and was under_
pressure to obtain a divorce and return to Pakistan. As set out above, a notable example of evidence that
is relevant to the applicant's sexual orientation was the significant violence alleged against him on 11
November 2018, when – as the Crown alleged – he told the complainant that he was gay. This assault
coincided with text messages which demonstrated he was under significant strain in one of his homosexual
relationships.

19. The judge noted that the evidence of the applicant's sexual orientation is twofold: his admission to the
complainant and the contents of his mobile telephone.

20. The applicant had been arrested on 24 April 2019 and the judge observed it was undisputed that he
provided the police with the PIN number to his mobile telephone. His telephone was interrogated on 30
April 2019 and the extracted data was thereafter reviewed. Although there had been no formal consent, in
the judge's view the provision of the PIN code was relevant to the application of section 78 of PACE. The
applicant later sought to withdraw his consent via his lawyers, but the judge held that the purported
withdrawal did not have retrospective effect.

21. The judge addressed the suggested infringement of the DPA. He reminded himself of the relevant
provisions, including the requirement for compliance with the data protection principles by the relevant
individual. Under Part 3 of the DPA, section 35 provides:

“The first data protection principle

(1) The first data protection principle is that the processing of personal data for any of the law enforcement
purposes must be lawful and fair.

(2) The processing of personal data for any of the law enforcement purposes is lawful only if and to the
extent that it is based on law and either—

(a)the data subject has given consent to the processing for that purpose, or


-----

(b)the processing is necessary for the performance of a task carried out for that purpose by a competent
authority.

(3) In addition, where the processing for any of the law enforcement purposes is sensitive processing, the
processing is permitted only in the two cases set out in subsections (4) and (5).

(4) The first case is where—

(a)the data subject has given consent to the processing for the law enforcement purpose as mentioned in
subsection (2)(a), and

(b)at the time when the processing is carried out, the controller has an appropriate policy document in
place (see section 42).

(5) The second case is where—

(a)the processing is strictly necessary for the law enforcement purpose,

(b)the processing meets at least one of the conditions in Schedule 8, and

(c)at the time when the processing is carried out, the controller has an appropriate policy document in
place (see section 42).

[…]”

22. Section 36 of the DPA includes:

“The second data protection principle

(1) The second data protection principle is that—

(a) the law enforcement purpose for which personal data is collected on any occasion must be specified,
explicit and legitimate, and

(b) personal data so collected must not be processed in a manner that is incompatible with the purpose for
which it was collected.

[…]”

23. By subsection 8, “sensitive processing” includes processing data concerning an individual's sex life or
sexual orientation. The conditions for sensitive processing in Part 3 as contained in Schedule 8 include,
_inter alia, processing that is necessary for the “exercise of a function conferred on a person by an_
_enactment or rule of law” or for “reasons of substantial public interest” or “for the administration of justice”._

24. Against that background, the judge focussed on the circumstances in which the police became aware
of the relevant material. He considered that, save for some immaterial lapses, the information had been
handled with appropriate sensitivity. Although the precise circumstances are unclear, it is undisputed that
the applicant provided the PIN number to his mobile telephone. The officer in the case, DC Morris, set out
in a statement dated 11 May 2021 that the custody record and the “consent box” had been checked by DC
Collins (who has now retired) and she “confirmed that his consent had been recorded in the custody
_record”, albeit this does not appear to have been the case. Whilst the DPA does not define consent, the_
General Data Protection Regulation, at Article 4 (11) provides the following definition:

“'consent' of the data subject means any freely given, specific, informed and unambiguous indication of the
data subject's wishes by which he or she, by a statement or by a clear affirmative action, signifies
agreement to the processing of personal data relating to him or her;”

25. The telephone examination request form “105” was completed. It contains the record that the mobile
telephones that had been seized were required for examination because the complainant in interview
indicated she had attempted suicide by drinking engine oil but had told the defendants of her actions when
she became scared. According to the complainant, they interrogated the internet on one of their mobile
telephones (she was unsure which) to establish what steps needed to be taken to counteract any adverse
effect, whilst avoiding visiting a hospital. The data extracted from the mobile telephones was passed to DC


-----

Collins for review, when the existence, along with the sensitive nature, of the present material became
apparent during a review of the applicant's WhatsApp messages.

26. The judge had before him the Metropolitan Police Service (“MPS”) Policy Document entitled “How the
_Met protects special category and criminal convictions personal data” and the MPS policy on the digital_
examination of devices. The judge reminded himself that under section 31of the DPA “'the law enforcement
_purposes' are the purposes of the prevention, investigation, detection or prosecution of criminal offences”._

27. The applicant conceded that if the data had been obtained or processed unlawfully under the DPA that
would not ipso facto mean that the evidence needed to be excluded. Instead, it was submitted that it was
one of the elements to be borne in mind when looking at the circumstances in which the evidence was
obtained for the purposes of section 78.

28. The judge concluded that whilst it was impossible to identify any formal consent for the police to
access the contents of the mobile telephone, it was inconceivable that the applicant did not realise when
he gave his PIN that this would provide access to his WhatsApp messages and other uses that he had
made of the device. Furthermore, there was no evidence nor, we would add, suggestion that access would
be limited to specific purposes. This was not a case in which it is alleged that some kind of trick had been
used or that the police had otherwise acted in bad faith. The judge found it had been necessary to examine
the mobile telephone for a law enforcement purpose and the relevant conditions, which include a statutory
purpose and the administration of justice, were met. An appropriate policy document was in place. The
judge accepted there were criticisms of the data protection process, but they did not weigh materially on
the exercise of his discretion under section 78 of PACE.

29. The judge noted the absence of evidence regarding the assertion that the officers acted in breach of
an undertaking not to rely on this material. Instead, in the judge's view, the prosecution had essentially
acted with conspicuous care, for instance by not raising this issue with the applicant's co-accused. He
concluded that this careful exercise of restraint by the police did not constitute a commitment to forgo the
opportunity of relying on this material.

30. The judge considered two expert reports from Mariam Faruqi and Dr Farnham, along with a brief
statement from the applicant setting out his fears if disclosure occurred. The judge was evidently alive to
the risks of violence and the adverse impact on mental health that can accompany an uninvited incident of
being “outed” as to an individual's sexuality. In this context, he had been provided with a CPS Toolkit for
Prosecutors dated 30 July 2020 which dealt with the situations – self-evidently different from the
circumstances of the present case – of “Same sex sexual violence and sexual violence involving a trans
_complainant or suspect/defendant”. The judge carefully analysed the risks for the applicant and by way of_
overarching conclusions indicated that there is “a very high likelihood of estrangement or ostracism from at
_least some and possibly many members of_ (the applicant's) family and community; a (real) possibility of
_violence from others […]; (and) there are clear challenges to M's mental health such that he has a real fear_
_of suicidal ideation”._

31. The judge reminded himself that the core of the applicant's submissions was that the prosecution's
proposed action would impact on his personal safety, along with the contention that disclosure would make
it difficult or impossible for the applicant to testify in his own defence.

32. Against the background of the matters set out above, the judge turned to his principal conclusions. He
noted that section 78 of PACE is expressly restricted to consideration of the “admission of evidence” in the
context of whether it would have such an adverse effect on the “fairness of the proceedings” that it should
be excluded. Given that restriction, he concluded it was impermissible to interpret the section as permitting
the court to take into account “the impact of the proceedings on the personal safety” of the applicant, as
distinct from the fairness of proceedings vis-à-vis the verdict of the jury. The judge observed that there are
many multi-handed cases when defendants have opposing interests (e.g. trials involving “cut-throat
_defences”) or cases with a gang background in which a defendant may apprehend that his or her defence,_
or the evidence he or she intends to give, will create the risk of harm, thereby putting him or her under
considerable pressure. The judge rejected the suggestion that a properly regulated trial, as a consequence
of such an apprehended risk of personal danger could be unfair in the context of section 78 of PACE


-----

33. Further, he highlighted that the section is concerned with the effect of the “admission” of the evidence
on the fairness of the proceedings, as opposed to the “service” of evidence. The judge reminded himself
that section 6 of the Human Rights Act 1998 (“HRA”) makes it unlawful for a public authority to act in a way
incompatible with Convention rights, and that by section 8 of the HRA the court may grant such relief or
remedy, or make such orders, within its powers as it considers just and appropriate in relation to any act
(or proposed act) of a public authority which the court finds is (or would be) unlawful. He determined it was
not within his powers, in the context of section 78 of PACE, to order the prosecution not to serve the
relevant evidence or to exclude it from the proceedings. Put otherwise, section 78 of PACE did not give
him the power to act in this way. The judge was reinforced in this view by the absence of any authority
supporting – as he described the position – such an extensive interpretation of section 78 of PACE or
indicating that it would be sustainable for him to utilise it as a general power to control prospective
breaches of rights under the ECHR in the sense suggested in the applicant's submissions.

34. The judge directed the prosecution, prior to service of the material, to undertake a careful redaction
exercise to avoid identifying other individuals, and to ensure that the applicant's representatives were kept
informed as to the timing and nature of the notification to the other defendants.

**The Submissions**

35. In essence, Mr Wood QC on behalf of the applicant builds on the submissions that were advanced in
the court below, save that the submissions in relation to the suggested breach of the undertaking are not
pursued. He submits that the judge erred by declining to construe section 78 of PACE in accordance with
sections 3, 6 and 8 of the HRA:

“3. Interpretation of legislation.

(1) So far as it is possible to do so, primary legislation and subordinate legislation must be read and given
effect in a way which is compatible with the Convention rights.

[…]”

and:

_“6. Acts of public authorities._

(1) It is unlawful for a public authority to act in a way which is incompatible with a Convention right.

[…]”

and:

_“8. Judicial remedies._

(1) In relation to any act (or proposed act) of a public authority which the court finds is (or would be)
unlawful, it may grant such relief or remedy, or make such order, within its powers as it considers just and
appropriate.”

36. It is argued that the judge erroneously failed to interpret section 78 of PACE as providing a means of
“control” over prospective breaches of the ECHR. It is contended the judge should have viewed the
concept of “the fairness of the proceedings” as including the impact of the proceedings on the personal
safety of the applicant. Put otherwise, it is suggested that “safeguarding” is inextricably bound up with the
“fairness of the proceedings”.

37. In the alternative, it is submitted that the judge erred in failing to “read down” section 78 of PACE, in
accordance with section 3 of the HRA (viz. “So far as it is possible to do so, primary legislation and
_subordinate legislation must be read and given effect in a way which is compatible with the Convention_
_rights”) to permit him to exclude the relevant material. Furthermore, it is argued that given the service or_
admission of the material would involve breaches of Article 2 or Article 3 of the ECHR, it ought to have
been excluded, even without recourse to section 78 (whether by reference to section 8 of the HRA, the
court's inherent jurisdiction or otherwise).


-----

38. It is submitted that in breach of Articles 2 and 3 of the ECHR, the judge failed to investigate whether
sufficient protective measures were available.

39. Finally, it is argued that in applying the provisions of section 78 of PACE, the judge erred in his
consideration of the DPA, along with Article 8 of the ECHR, most particularly when he attached weight to
the fact that the applicant had provided the police with the PIN to his mobile telephone and when he
concluded that the flaws in “the data process” did not weigh materially in the exercise of his discretion
under section 78 of PACE.

**Analysis**

40. The digital messages are clearly relevant to the evidence that it is anticipated the complainant will give
of the circumstances of the critical assault on 11 November 2018, both as to what was said and what
happened. Without an admission from the applicant as to his sexuality, the messages provide considerable
support for the prosecution's main witness, on a central element of her testimony as described in extenso
above. Therefore, this material corroborates a significant aspect of her evidence, as well as placing the
overall events in their true context vis-à-vis the applicant.

41. We agree with the judge that it was necessary to examine the applicant's telephone for the statutory
purpose of law enforcement, along with the administration of justice. As set out above, the complainant
suggested that when she revealed she had attempted suicide by drinking engine oil, the accused searched
the internet via one of their mobile telephones for palliative measures which would avoid alerting the
medical services. It is unsurprising that the police cast their searches wider than merely looking for past
internet searches in a bid to secure evidence concerning this alleged incident. The entire messaging
history was available to the officer in the case for this purpose, in the context of the broader allegations. As
the judge indicated, “They subjected (the messages) to review for material relevant to the case and they
_found it. I do not consider that such processing breached the second data protection principle. I do not_
_accept that where processing is legitimately pursued for a specific purpose but reveals other material_
_relevant to the overall law enforcement purpose that processing of the data breaches the rules.” We agree._

42. It appears to be accepted that an appropriate policy document was available; certainly, no contrary
submission has been advanced. Although a) the evidence is uncertain as regards the provision of the PIN
to the mobile telephone, b) there was no data protection impact assessment and c) there was poor record
keeping as regards the handling of this data, these features did not have any significant impact on the
assessment of the issues under section 78 of PACE. The police did not know they were processing
sensitive material and once they did, they took every step to handle the material with appropriate care,
such that only strictly necessary processing occurred. There is no sustainable suggestion of bad faith or
deception, and it is not contended that the integrity of the messages has been compromised: they simply
speak for themselves. We do not accept that there was a laissez-faire or flawed approach by the police to
the gathering of this evidence, such that necessitated the exclusion of this material under section 78 of
PACE.

43. We turn, therefore, to the central issue on this application, namely whether section 78 of PACE can be
used in the way advocated by Mr Wood. This is a provision with a significant historical and legislative
background. In Sang [1980] AC 402, the House of Lords substantively curtailed the opportunity under the
common law for judges to refuse to admit improperly obtained evidence. This decision contributed to the
setting up of the Royal Commission on Criminal Procedure which reported in January 1981 (“the Philips
_Commission”) on whether there should be an exclusionary provision. The Commission advanced certain_
much-criticised conclusions on this issue. Thereafter, the Police and Criminal Evidence Bill – certainly on
this issue – had a chequered passage through Parliament, with section 78 in its present form only being
introduced shortly before the Bill passed.

44. In the conjoined appeals of _R v_ Looseley and Attorney General's Reference (No.3 of 2000) _[2001]_
_UKHL 53; [2001] 1 WLR 2060, Lord Nicholls in the House of Lords described the judicial discretion as_
finally implemented in section 78 of PACE and he analysed the relationship between this provision and
abuse of process. In passages of direct relevance to the present application, Lord Nicholls observed:


-----

“12. The phrase “fairness of the proceedings” in section 78 is directed primarily at matters going to
fairness in the actual conduct of the trial; for instance, the reliability of the evidence and the defendant's
ability to test its reliability. But, rightly, the courts have been unwilling to limit the scope of this wide and
[comprehensive expression strictly to procedural fairness. In R v Smurthwaite [1994] 1 All ER 898, 902 Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4D74-5KD0-TWP1-6150-00000-00&context=1519360)
Taylor of Gosforth CJ stated that section 78 has not altered the substantive rule that entrapment does not
of itself provide a defence. The fact that the evidence was obtained by entrapment does not of itself require
the judge to exclude it. But, in deciding whether to admit the evidence of an undercover police officer, the
judge may take into account matters such as whether the officer was enticing the defendant to commit an
offence he would not otherwise have committed, the nature of any entrapment, and how active or passive
was the officer's role in obtaining the evidence. […] Most recently in R v Shannon [2001] 1 WLR 51, 68,
para 39 Potter LJ, as I read his judgment, accepted that evidence may properly be excluded when the
behaviour of the police or prosecuting authority has been such as to justify a stay on grounds of abuse of
process.

13. Next, the common law also has developed since the decision in _R v Sang_ [1980] AC 402. In _R v_
_Horseferry Road Magistrate's Court, Ex p Bennett_ [1994] 1 AC 42 your Lordship's House held that the
court has jurisdiction to stay proceedings and order the release of the accused when the court becomes
aware there has been a serious abuse of power by the executive. The court can refuse to allow the police
or prosecuting authorities to take advantage of such an abuse of power by regarding it as an abuse of the
court's process. Lord Griffiths, at p 62, echoed the words of Lord Devlin that the courts “cannot
_contemplate for a moment the transference to the executive of the responsibility for seeing that the process_
_of law is not abused”: see Connelly v Director of Public Prosecutions [1964] AC 1254, 1354. The judiciary_
should accept a responsibility for the maintenance of the rule of law that embraces a willingness to oversee
executive action and to refuse to countenance behaviour that “threatens either basic human rights or the
rule of law”: Ex P Bennett [1994] 1 AC 42, 62.”

45. Lord Nicholls at [14] went on to observe that the same principles apply to cases involving forcible
abduction and entrapment (see also R v Latif [1996] 1 WLR 104). Therefore, “although entrapment is not a
_substantive defence, English law has now developed remedies in respect of entrapment: the court may_
_stay the relevant criminal proceedings, and the court may exclude evidence pursuant to section 78” ([16])._
[Lord Nicholls addressed the Human Rights Act 1998 as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

“15. These statutory and common law developments have been reinforced by the Human Rights Act 1998.
It is unlawful for the court, as a public authority, to act in a way which is incompatible with a Convention
right. Entrapment, and the use of evidence obtained by entrapment (“as a result of police incitement”), may
deprive a defendant of the right to a fair trial embodied in article 6: see the decision of the European Court
of Human Rights in Teixeira de Castro v Portugal (1998) 28 EHRR 101.

16. […] Of these two remedies the grant of a stay, rather than the exclusion of evidence at the trial, should
normally be regarded as the appropriate response in a case of entrapment. […]”

46. We would interpolate that, as suggested by the editors of Blackstone's Criminal Practice 2022 at

[F2.17], “neither the judicial discretion conferred by s. 78, nor the court's power to stay proceedings as an
_abuse of the court, has been modified by the ECHR, Article 6, and the jurisprudence of the ECtHR. There_
_is no appreciable difference between the requirements of Article 6, or the Strasbourg jurisprudence on_
_Article 6, and the English law as it has developed in recent years. […]”. Lord Nicholls in R v_ _Looseley_
continued:

“18. A further point of principle should be noted. As observed by Auld LJ in R v Chalkley [1998] QB 848,
874, a decision on whether to stay criminal proceedings as an abuse of process is distinct from a
determination of the forensic fairness of admitting evidence. Different tests are applicable to these two
decisions. Accordingly, when considering an application by a defendant to exclude evidence under section
78, courts should distinguish clearly between an application to exclude evidence on the ground that the
defendant should not be tried at all and an application to exclude evidence on the ground of procedural
fairness. Sometimes a defendant may base his application under section 78 on both grounds. Then the
court will need to reach a separate decision on each ground.”


-----

47. Although it can sustainably be suggested that the courts have not provided a single, overarching
explanation of the circumstances when there can be resort to section 78 to exclude evidence, nonetheless
the ambit of the provision is essentially well established. The classic description of the use of the section is
to be found in R v Quinn [1990] Crim LR 581 per Lord Lane CJ, “The function of the judge is therefore to
protect the fairness of the proceedings, and normally proceedings are fair if a jury hears all relevant
_evidence which either side wishes to place before it, but proceedings may become unfair if, for example,_
_one side is allowed to adduce relevant evidence which, for one reason or another, the other side cannot_
_properly challenge or meet, or where there has been an abuse of process, e.g. because evidence has_
_been obtained in deliberate breach of procedures laid down in an official code of practice” (our emphasis)._
Although the jurisprudence in this area is extensive, in our view the section is potentially engaged in three
broad situations: first, when fairness in the actual conduct of the trial is in issue (e.g. because the
defendant is unable to test the reliability of a piece of evidence); second, when there are significant and
substantial breaches of the procedural safeguards (e.g. infringements of the Codes of Practice); and, third,
when the “moral integrity” of the proceedings has been substantively undermined (e.g. on account of
entrapment or material bad faith).

48. It has not formed part of the applicant's submissions that section 78 has ever been used as a
mechanism to provide personal protection for witnesses or defendants from the consequences (e.g.
violence or other serious mistreatment) of otherwise admissible evidence being served in advance of or
adduced during a trial. We consider this to be entirely unsurprising. By reference to the example cited by
the judge, in a gang-related case a defendant may have given an account in interview that implicates
others, including his or her co-accused or one or more of the prosecution witnesses. Threats to the
defendant or an apprehension of significant harm in these circumstances would not sustainably provide the
basis for excluding all or part of the interview, given the critical need to conduct trials on the basis of all the
“relevant evidence which either side wishes to place before it” (save for the specific exceptions which are
not relevant to the instant issues: see R v Quinn at [47] above). The common law, the legislative history to
PACE, the impact of the _[Human Rights Act 1998 and the significant body of jurisprudence concerning](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
section 78 since 1984 do not establish any basis for suggesting that the section can or should be used as a
means of protecting a defendant from violence or other forms of harm on account of admissible evidence
being served or introduced. This suggested use of section 78 of PACE would “cut across a fundamental
_feature” and “go against the grain” of this statutory provision[1] given our conclusions as to the underlying_
purposes of the section, as set out above. We have borne in mind that expressions such as those just cited
should not supplant the simple test enacted in section 3 of the HRA: “So far as it is possible to do so […]”.[2]
Nor can Parliament have intended that section 3 should require the courts to make decisions which they
are not equipped to make.[3] The applicant's suggested interpretation would potentially impose on the judge,
in every case, a safeguarding obligation which the court would be, in reality, unable to undertake, not least
given the lack of appropriate facilities to investigate independently the potential risks to the relevant
individual. This would, therefore, involve a wholly inapposite means of dealing with the risks which are
alleged.

49. It is simply unnecessary, furthermore, to resort to section 3 of the HRA in order to interpret section 78
of PACE in this “unusual and far-reaching” way,[4] bearing in mind the responsibility that rests on the
authorities (in this context the Crown Prosecution Service and the police), which is accepted. This
obligation was described in Osman v United Kingdom (23452/94); (2000) 29 E.H.R.R. 245 (1998) as the
need for the State to do “all that could be reasonably expected of them to avoid a real and immediate risk
_to life of which they have or ought to have knowledge”, reflecting thereby a “positive obligation on the_
_authorities to take preventive operational measures to protect an individual whose life is at risk from the_
_criminal acts of another individual” (see [115] and [116]). We note that that the Strasbourg Court held that_
“such an obligation must be interpreted in a way which does not impose an impossible or disproportionate
_burden on the authorities” ([116]). The obligation to protect subjects from serious harm in these_
circumstances rests with the prosecution authorities, which will usually be shared by the Crown
Prosecution Service and the police, each bearing particular aspects of the responsibility.[5] It follows that we
reject the suggestion that the court should attempt to resort to section 78 of PACE, the HRA or its inherent
jurisdiction to prevent the service or admission of this material on the basis, as argued by the applicant,


-----

that either of these steps would involve breaches of articles 2 or 3 of the European Convention on Human
Rights (viz. the right to life and the protection from torture and inhuman and degrading treatment). We
emphasise, therefore, that articles 2 and 3 of the ECHR are not engaged vis-à-vis the Crown Court in the
context of the service or admission into evidence of this material, given particularly that the authorities
acknowledge that they bear the responsibility for evaluating and addressing in a realistic manner any
substantive risks that exist as regards the wellbeing of the applicant.

50. The applicant suggests that there is a common law power to exclude evidence in these circumstances,
particularly bearing in mind section 82(3) of PACE: “Nothing in this Part of this Act shall prejudice any
_power of a court to exclude evidence (whether by preventing questions from being put or otherwise) at its_
_discretion”. However, no authority supporting such an inherent exclusionary power, exercised for_
safeguarding purposes, has been identified or cited to us. It is not suggested it has ever been utilised and
we are unpersuaded that it exists. Mr Wood relied on _Richard Scott v Queen_ 1989 AC 1242(PC) in this
regard, but we found no substantive support for this proposition in that decision. The court instead referred
to the common law discretion to refuse to admit evidence to ensure a fair trial (see page 1258 A).

51. It follows that prior to service of the evidence relating to the applicant's sexual orientation, the
prosecution will need to effect redactions so that others are not needlessly identified (an obligation we
stress the Crown acknowledges); if not formally already made, the applicant should request protection from
the authorities, providing sufficiently detailed reasons (albeit the Crown Prosecution Service and the police
are self-evidently aware of the outline circumstances as described by the applicant); risk assessments will
need to be made as regards the safety of the applicant and any necessary consequential steps will be
taken; and the prosecution should inform the applicant's representatives as to when this material is to be
served on the applicant's co-accused. Given the far-reaching remedy the applicant has sought in this case,
we would observe in passing that he cannot expect that the investigating and prosecuting authorities will
be able, or are obliged, to fulfil unrealistic expectations as to protecting his safety, particularly if he is living
within the family unit, as currently appears to be the case.

**Summary of conclusions**

52. Put in general terms, evidence on which the prosecution seeks to rely (which is otherwise admissible)
can be introduced, subject to any submissions under section 78 of PACE as to whether i) it can be fairly
evaluated; ii) there have been significant and substantial breaches of the relevant procedural safeguards;
or iii) the moral integrity of the proceedings has been materially undermined. Furthermore, depending on
the circumstances, the evidence may be introduced even if one or more of the concerns under i) – iii) are
made out.

53. If a defendant is at risk because of the nature of evidence which is to be served or given during the
trial, the authorities – in reality, there will be a division of responsibility between the Crown Prosecution
Service and the police – will bear the responsibility for ensuring that the dangers are properly assessed
and, if necessary, realistic steps (“all that could be reasonably expected of them”) are taken to address
them.

54. Section 78 of PACE was introduced principally to address the House of Lords decision in Sang when
the opportunity under the common law for judges to refuse to admit improperly obtained evidence was
severely curtailed. This provision was not intended to be used, and it has not been used in nearly four
decades, as a mechanism for protecting a defendant from real or imagined fears of death or serious
violence, including as a result of evidence he or she may give from the witness box. The reason section 78
of PACE has not been used for this purpose is, as just set out, that the solution to the problem, when it
properly arises, is properly to be found elsewhere. There is no need, therefore, to create a wholly novel
situation (involving an “unusual and far-reaching” interpretation) when section 78 of PACE can be utilised,
one that is undoubtedly at far remove from its essential purpose as described by Lord Lane in 1990 in
_Quinn, that of protecting the fairness of the proceedings instead of protecting, we would add in_
parentheses, the personal safety of the applicant from life-threatening or other serious homophobic
violence.


-----

55. It follows that it will not be unfair under section 78 of PACE for a court to admit evidence that may
create a consequential responsibility for the prosecution authorities to take realistic steps to ensure that the
wellbeing of the relevant witness or defendant is not substantively endangered. That responsibility includes
real and immediate risks of life-threatening or other serious violence which may result from his testimony
from the witness box describing his sexual orientation.

56. It is not within the power – including the inherent jurisdiction of the court – to make an order prohibiting
the prosecution from serving evidence on which it proposes to rely. It is inapposite, furthermore, to seek to
rely on section 78 of PACE in these circumstances to prevent admission of this material, by reference to
suggested breaches of articles 2 or 3 of the ECHR.

57. Mr Wood has provided the court with extensive materials describing the risks that can face defendants
in circumstances such as the present. Given our decision that it would be impermissible to exclude the
evidence on the bases suggested by the applicant, it is unnecessary to rehearse the detail and the analysis
that has been provided of the suggested risks that may face the applicant once this evidence is served on
his co-accused.

**The Preparatory Hearing and Privacy**

58. We can deal with these issues shortly. Under section 29 of the CPIA, the judge can hold a preparatory
hearing if it appears to the judge that the indictment reveals a case of such complexity or seriousness, or it
appears to be a trial which is likely to be of such length that substantial benefits are likely to accrue from
the hearing. The maximum sentence under count 1 (section 1 **_Modern Slavery Act 2015) is life_**
imprisonment and, accordingly, the judge was entitled to consider that the case crossed the seriousness
threshold.

59. The principal purposes of such a hearing are, by section 29(2), identifying issues which are likely to be
material to the determinations and findings which are likely to be required during the trial; if there is to be a
jury, assisting their comprehension of those issues and expediting the proceedings before them; assisting
the judge's management of the trial; and considering questions as to the severance or joinder of charges.
The restrictions on preparatory hearings are considerable. As Hughes LJ observed in Regina v I, P, O, I &
_G [2009] EWCA Crim 1793; 2010 1 WLR 1125 at [21]:_

“Virtually the only reason for directing such a hearing nowadays is if the judge is going to have to give a
ruling which ought to be the subject of an interlocutory appeal. Such rulings are few and far between and
do not extend to most rulings of law. An interlocutory appeal can be a most beneficial process in a few,
very limited, circumstances. If a discrete point of law arises, its resolution in this court can if necessary be
accomplished within a very short time-frame and this can avoid the risk of many weeks of wasted trial
time.”

60. Although this was described as being “almost invariably” the position in R v Quillan [2015] EWCA Crim
_538; [2015] 1 WLR 4673 at [10], the court went on to indicate that “there may be special circumstances_
_where a trial will be very long and very costly and where a ruling on a point of law in relation to the legal_
_basis on which a count in the indictment is founded may determine whether or not a trial is required at all._
_In such a case such a point of law should be determined well before any trial starts”._

61. However, Hughes LJ had also observed at [21] in Regina v I, P, O, I & G that a good example of when
such a hearing is appropriate is when the point is “discrete, novel, certain to arise rather than hypothetical
_or contingent, involved no factual dispute and needed authoritatively to be determined lest the trial proceed_
_on what might turn out to be a false footing […]” (see at [21]). Those considerations apply in the present_
case. Given the novel nature of the submissions made to the judge and the potentially critical
consequences for the applicant, along with the potential for the trial to proceed on a wholly false footing,
we consider it was necessary for these issues to be resolved prior to the commencement of the trial with a
view to an application being made to this court following the judge's ruling. This was a highly unusual
situation and we have no doubt the judge was correct to order a preparatory hearing.


-----

62. Similarly, the judge was entitled to hold the hearing in private, without the co-accused. In R v H, P, S
_and T [2004] EWCA Crim, 3325, this court held at [20], “The real question is: has the Court a discretion to_
_allow a defendant to appear before the judge ex parte his other co-defendants? The answer seems to us,_
_(and it is so conceded by Mr Fisher on behalf of the Crown), that the Court must have a discretion if justice_
_demands that it should be so. The matter, however, has to be very much one for the discretion of the_
_judge. The exercise of that discretion could only be attacked on the usual grounds. […]” In this situation the_
judge was effectively “holding the ring” until he had decided the issue. If the co-accused had been present
when this was argued the issue would have been prejudged and all the serious personal prejudice the
applicant was seeking to avoid would have been incurred. Justice demanded the application be held ex
parte the applicant's co-defendants in order for a determination on the underlying merits to be reached. We
consider the judge was correct to follow this highly unusual course, dictated by these exceptional
circumstances.

**Conclusion**

63. We consider it was appropriate to canvass these hitherto untested issues by way of an interlocutory
appeal. We grant leave to appeal, and the appeal is dismissed. We are grateful to counsel for their wellprepared and cogently presented submissions, which significantly assisted the court in considering what
was, in the main, a novel point of statutory interpretation.

**End of Document**


-----

