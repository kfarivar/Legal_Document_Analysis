# Rantsev v Cyprus and another (App. No. 25965/04) [2010] ECHR 25965/04

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE ROZAKIS (PRESIDENT), JUDGES KOVLER, STEINER, SPIELMANN, JEBENS, MALINVERNI AND
NICOLAOU, AND S NIELSEN (SECTION REGISTRAR)

7 JANUARY 2009

10 DECEMBER 2009

**Human Rights — Life — Deprivation — Use of force — Investigation — Slavery — Liberty — Detention —**
**Applicant's daughter successfully applying for 'artiste' visa and work permit to work as artiste in cabaret —**
**Applicant's daughter leaving employ as artiste in cabaret — Applicant's daughter subsequently found dead**
**in suspicious circumstances — Whether violation of applicant's Convention rights — Whether applicant**
**entitled to non-pecuniary damage — European Convention on Human Rights, arts 2, 4, 5, 41.**

The applicant was a Russian national. He was the father of R. She arrived in Cyprus on 5 March 2001. On 13
February, XA, the owner of a cabaret in Limassol, had applied for an 'artiste' visa and work permit for R to allow her
to work as an artiste in his cabaret. The application was accompanied by a copy of R's passport, a medical
certificate, a copy of an employment contract and a bond. R was granted a temporary residence permit as a visitor.
She stayed in an apartment with other young women. On 19 March, MA was informed by the other women living
with R that she had left the apartment and had taken all her belongings with her. On 28 March, R was seen in a
discotheque. MA met R in the discotheque. He took her to the police station and informed the police officers of the
circumstances of her arrival in Cyprus. The officers refused to detain R as she was not contravening the law. MA
later came to collect R from the station and took R to the apartment of MP, a male employee at his cabaret. At
around 6.30 am on 28 March, R was found dead on the street below the apartment. Her handbag was over her
shoulder. The police found a bedspread looped through the railing of the smaller balcony adjoining the room in
which R had been staying on the upper floor of the apartment, below which the larger balcony on the fifth floor was
located. A subsequent investigation and inquest ensued in Cyprus. The applicant complained to the European
Court of Human Rights that there had been a violation of art 2 of the European Convention of Human Rights by
both the Russian and Cypriot authorities on account of the failure of the Cypriot authorities to take steps to protect
the life of R and the failure of the authorities of both states to conduct an effective investigation into her death. He
alleged a violation of art 3 of the Convention by the Cypriot authorities in respect of their failure to take steps to
protect R from ill-treatment and to investigate whether R was subject to inhuman or degrading treatment in the
period leading up to her death. The Court concluded that it was not necessary to consider separately the applicant's
art 3 complaint and would deal with the general issues raised in the context of its examination of a complaint by the
applicant under art 4 of the Convention. The applicant alleged a violation of art 4 of the Convention by both the
Russian and Cypriot authorities in light of their failure to protect his daughter from being trafficked and their failure
to conduct an effective investigation into the circumstances of her arrival in Cyprus and the nature of her
employment there. He complained that there was a violation of art 5(1) of the Convention by the Cypriot authorities
in so far as his daughter was detained at the police station, released into the custody of MA and subsequently
detained in the apartment of MA's employee. He sought damages for, inter alia, non-pecuniary loss pursuant to art
41 of the Convention.

Held: (1) It was clear that art 2 enjoined the state not only to refrain from the intentional and unlawful taking of life
but also to take appropriate steps to safeguard the lives of those within its jurisdiction. In the first place, that
obligation required the state to secure the right to life by putting in place effective criminal law provisions to deter


-----

the commission of offences against the person backed up by law enforcement machinery for the prevention,
suppression and punishment of breaches of such provisions. However, it also implied, in appropriate
circumstances, a positive obligation on the authorities to take preventive operational measures to protect an
individual whose life was at risk from the criminal acts of another individual. The scope of any positive obligation
should be interpreted in a way which did not impose an impossible or disproportionate burden on the authorities,
bearing in mind the difficulties in policing modern societies, the unpredictability of human conduct and the
operational choices which would have to be made in terms of priorities and resources. Not every claimed risk to life
could entail for the authorities a Convention requirement to take operational measures to prevent that risk from
materialising. For the Court to find a violation of the positive obligation to protect life, it would have to be established
that the authorities had known or ought to have known at the time of the existence of a real and immediate risk to
the life of an identified individual from the criminal acts of a third party and that they had failed to take measures
within the scope of their powers which, judged reasonably, might have been expected to avoid that risk. In all the
circumstances of the instant case, there had been no violation of the Cypriot authorities' positive obligation to
protect the first applicant's right to life under art 2 of the Convention (see [218], [219], [223] of the judgment);
_Osman v United Kingdom_ _[[1998] ECHR 23452/94 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4JX-00000-00&context=1519360)_

(2) The obligation to protect the right to life under art 2 of the Convention, read in conjunction with the state's
general duty under art 1 of the Convention to 'secure to everyone within [its] jurisdiction the rights and freedoms
defined in [the] Convention', required that there should be some form of effective official investigation when
individuals have been killed as a result of the use of force. The obligation to conduct an effective official
investigation also arose where death occurred in suspicious circumstances not imputable to state agents. The
essential purpose of such investigation was to secure the effective implementation of the domestic laws which
protected the right to life and, in those cases involving state agents or bodies, to ensure their accountability for
deaths occurring under their responsibility. The authorities should have acted of their own motion once the matter
had come to their attention. They could not leave it to the initiative of the next-of-kin either to lodge a formal
complaint or to take responsibility for the conduct of any investigative procedures. For an investigation to be
effective, the persons responsible for carrying it out would have to be independent from those implicated in the
events. That required not only hierarchical or institutional independence but also practical independence. The
investigation would have to be capable of leading to the identification and punishment of those responsible. A
requirement of promptness and reasonable expedition was implicit in the context of an effective investigation within
the meaning of art 2 of the Convention. In all cases, the next of kin of the victim would have to be involved in the
procedure to the extent necessary to safeguard his legitimate interests. The Court acknowledged at the outset that
there was no evidence that R died as a direct result of the use of force. However, as noted above, that did not
preclude the existence of an obligation to investigate her death under art 2. In light of the ambiguous and
unexplained circumstances surrounding R's death and the allegations of trafficking, ill-treatment and unlawful
detention in the period leading up to her death, a procedural obligation did arise in respect of the Cypriot authorities
to investigate the circumstances of R's death. By necessity, the investigation was required to consider not only the
immediate context of R's fall from the balcony but also the broader context of R's arrival and stay in Cyprus, in order
to assess whether there was a link between the allegations of trafficking and R's subsequent death. As to the
adequacy of the investigation, there are a number of elements of the investigation which were unsatisfactory. In all
the circumstances, there had been a procedural violation of art 2 of the Convention as regards the failure of the
Cypriot authorities to conduct an effective investigation into R's death. As regards to Russia, R's death had taken
place in Cyprus. Accordingly, unless it could be shown that there were special features in the instant case which
required a departure from the general approach, the obligation to ensure an effective official investigation applied to
Cyprus alone. In the circumstances, there had been no procedural violation of art 2 by the Russian Federation (see

[232]-[235], [242], [243], [247] of the judgment); Al-Adsani v UK _[[2001] ECHR 35763/97 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2VX-00000-00&context=1519360)_

(3) Together with arts 2 and 3, art 4 enshrined one of the basic values of the democratic societies making up the
Council of Europe. Unlike most of the substantive clauses of the Convention, art 4 made no provision for exceptions
and no derogation from it is permissible under art 15(2) even in the event of a public emergency threatening the life
of the nation. In assessing whether there had been a violation of art 4, the relevant legal or regulatory framework in
place would have to be taken into account. The spectrum of safeguards set out in national legislation would have to
be adequate to ensure the practical and effective protection of the rights of victims or potential victims of trafficking.


-----

Accordingly, in addition to criminal law measures to punish traffickers, art 4 required member states to put in place
adequate measures regulating businesses often used as a cover for human trafficking. Furthermore, a state's
immigration rules would have to address relevant concerns relating to encouragement, facilitation or tolerance of
trafficking. As with arts 2 and 3 of the Convention, art 4 might, in certain circumstances, require a state to take
operational measures to protect victims, or potential victims, of trafficking. Like art 2 and 3, art 4 also entailed a
procedural obligation to investigate situations of potential trafficking. The requirement to investigate did not depend
on a complaint from the victim or next-of-kin: once the matter had come to the attention of the authorities they would
have to act of their own motion. For an investigation to be effective, it would have to be independent from those
implicated in the events. It would also have to be capable of leading to the identification and punishment of
individuals responsible, an obligation not of result but of means. A requirement of promptness and reasonable
expedition was implicit in all cases but where the possibility of removing the individual from the harmful situation
was available, the investigation would have to be undertaken as a matter of urgency. The victim or the next-of-kin
would have to be involved in the procedure to the extent necessary to safeguard their legitimate interests.
Trafficking was a problem which was often not confined to the domestic arena. When a person was trafficked from
one state to another, trafficking offences might occur in the state of origin, any state of transit and the state of
destination. Relevant evidence and witnesses might be located in all states. In the circumstances, the regime of
artiste visas in Cyprus did not afford to R practical and effective protection against trafficking and exploitation. There
had accordingly been a violation of art 4 in that regard. In assessing whether a positive obligation to take measures
to protect R arose in the instant case, the deficiencies, in circumstances, which had given rise to a credible
suspicion that R might have been trafficked or exploited, had resulted in a failure by the Cypriot authorities to take
measures to protect R. There had accordingly been a violation of art 4 in that respect also. As to Russia, the legal
and administrative framework in place in Russia at the material time had not failed to ensure R's practical and
effective protection in the circumstances of the instant case. Any positive obligation incumbent on Russia to take
operational measures could only arise in respect of acts which occurred on Russian territory. The circumstances of
the instant case were not such as to give rise to a positive obligation on the part of the Russian authorities to take
operational measures to protect R. There had accordingly been no violation of art 4 by the Russian authorities in
that regard. In all the circumstances, there had accordingly been a violation by the Russian authorities of their
procedural obligation under art 4 to investigate alleged trafficking (see [283], [284], [286], [288], [289], [298], [303],

[306], [309] of the judgment); _Nachova v Bulgaria_ _[[2005] ECHR 43577/98,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2NP-00000-00&context=1519360)_ _Mahmut Kaya v Turkey_ _[[2000] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X1C9-00000-00&context=1519360)_
_[22535/93 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X1C9-00000-00&context=1519360)_

(4) In proclaiming the 'right to liberty', art 5(1) aimed to ensure that no-one should be dispossessed of his physical
liberty in an arbitrary fashion. The difference between restrictions on movement serious enough to fall within the
ambit of a deprivation of liberty under art 5(1) and mere restrictions of liberty which were subject only to art 2 of the
Fourth Protocol was one of degree or intensity, and not one of nature or substance. In order to determine whether
someone had been 'deprived of his liberty' within the meaning of art 5, the starting point would have to be her
concrete situation and account should be taken of a whole range of criteria such as the type, duration, effects and
manner of implementation of the measure in question. In all, the alleged detention had lasted about two hours.
Although of short duration, the Court emphasised the serious nature and consequences of the detention and
recalled that where the facts indicated a deprivation of liberty within the meaning of art 5(1), the relatively short
duration of the detention did not affect the conclusion. Accordingly, the detention of R at the police station and her
subsequent transfer and confinement to the apartment amounted to a deprivation of liberty within the meaning of art
5 of the Convention. It remained to be determined whether the deprivation of liberty fell within one of the categories
of permitted detention exhaustively listed in art 5(1). Article 5(1) referred essentially to national law and laid down
an obligation to comply with its substantive and procedural rules. It also required, however, that any measure
depriving the individual of his liberty would have to be compatible with the purpose of art 5, namely to protect the
individual from arbitrariness. By laying down that any deprivation of liberty should be 'in accordance with a
procedure prescribed by law', art 5(1) required, first, that any arrest or detention should have a legal basis in
domestic law. It had not been argued that R's detention in the apartment was lawful. That deprivation of liberty was
both arbitrary and unlawful. There therefore had been a violation of art 5(1) on account of R's unlawful and arbitrary
detention (see [314], [317], [322], [324], [325] of the judgment); considered.


-----

(5) Making an assessment on an equitable basis, the applicant would be awarded €40,000 in respect of nonpecuniary damage (see [349] of the judgment).
**PROCEDURE**

1. The case originated in an application (no. 25965/04) against the Republic of Cyprus and the Russian Federation
lodged with the Court under art 34 of the Convention for the Protection of Human Rights and Fundamental
Freedoms (“the Convention”) by a Russian national, Mr Nikolay Mikhaylovich Rantsev (“the applicant”), on 26 May
2004.

2. The applicant, who had been granted legal aid, was represented by Ms L. Churkina, a lawyer practising in
Yekaterinburg. The Cypriot Government were represented by their Agent, Mr P. Clerides, Attorney-General of the
Republic of Cyprus. The Russian Government were represented by their Agent, Mr G. Matyushkin.

3. The applicant complained under arts 2, 3, 4, 5 and 8 of the Convention about the lack of sufficient investigation
into the circumstances of the death of his daughter, the lack of adequate protection of his daughter by the Cypriot
police while she was still alive and the failure of the Cypriot authorities to take steps to punish those responsible for
his daughter's death and ill-treatment. He also complained under arts 2 and 4 about the failure of the Russian
authorities to investigate his daughter's alleged trafficking and subsequent death and to take steps to protect her
from the risk of trafficking. Finally, he complained under art 6 of the Convention about the inquest proceedings and
an alleged lack of access to court in Cyprus.

4. On 19 October 2007 the Cypriot and Russian Governments were requested to submit the entire investigation file
together with all correspondence between the two Governments on this matter. On 17 December 2007 and 17
March 2008, the Cypriot and Russian Governments respectively submitted a number of documents.

5. On 20 May 2008 the President of the First Section decided to accord the case priority treatment in accordance
with Rule 41 of the Rules of Court.

6. On 27 June 2008 the President of the First Section decided to give notice of the application to each of the
respondent Governments. It was also decided to examine the merits of the application at the same time as its
admissibility (art 29(3)).

7. On 27 and 28 October 2008 respectively, the Cypriot and Russian Governments submitted their written
observations on the admissibility and merits of the application. In addition, third-party comments were received from
two London-based non-governmental organisations, Interights and the AIRE Centre, which had been given leave by
the President to intervene in the written procedure (art 36(2) of the Convention and Rule 44(2)).

8. On 12 December 2008, the President of the First Section decided that legal aid should be granted to the
applicant for his representation before the Court.

9. On 16 December 2008 the applicant lodged written observations in reply together with his claims for just
satisfaction.

10. The Cypriot and Russian Governments lodged observations on the applicant's just satisfaction submissions.

11. By letter of 10 April 2009, the Cypriot Government requested the Court to strike the case out of its list and
enclosed the text of a unilateral declaration with a view to resolving the issues raised by the applicant. The applicant
filed written observations on the Cypriot Government's request on 21 May 2009.

12. The applicant requested an oral hearing but prior to adopting the present judgment the Court decided that it was
not necessary to hold one.
**THE FACTSI. THE CIRCUMSTANCES OF THE CASE**

13. The applicant, Mr Nikolay Mikhaylovich Rantsev, is a Russian national who was born in 1938 and lives in
Svetlogorsk, Russia. He is the father of Ms Oxana Rantseva, also a Russian national, born in 1980.


-----

14. The facts of the case, as established by the submissions of the parties and the material submitted by them, in
particular the witness statements taken by the Cypriot police, may be summarised as follows.

A. The background facts

15. Oxana Rantseva arrived in Cyprus on 5 March 2001. On 13 February 2001, X.A., the owner of a cabaret in
Limassol, had applied for an “artiste” visa and work permit for Ms Rantseva to allow her to work as an artiste in his
cabaret (see further para 115 below). The application was accompanied by a copy of Ms Rantseva's passport, a
medical certificate, a copy of an employment contract (apparently not yet signed by Ms Rantseva) and a bond,
signed by [X.A.] Agencies, in the following terms (original in English):

“KNOW ALL MEN BY THESE PRESENTS that I [X.A.] of L/SSOL Am bound to the Minister of the Interior
of the Republic of Cyprus in the sum of £150 to be paid to the said Minister of the Interior or other the [sic]
Minister of Interior for the time being or his attorney or attorneys.

Sealed with my seal.

Dated the 13[th] day of February 2001

WHEREAS Ms Oxana RANTSEVA of RUSSIA

Hereinafter called the immigrant, (which expression shall where the context so admits be deemed to
include his heirs, executors, administrators and assigns) is entering Cyprus and I have undertaken that the
immigrant shall not become in need of relief in Cyprus during a period of five years from the date hereof
and I have undertaken to replay [sic] to the Republic of Cyprus any sum which the Republic of Cyprus may
pay for the relief or support of the immigrant (the necessity for which relief and support the Minister shall be
the sole judge) or for the axpenses [sic] of repatriating the immigrant from Cyprus within a period of five
years from the date hereof.

NOW THE CONDITION OF THE ABOVE WRITTEN BOND is such that if the immigrant or myself, my
heirs, executors, administrators and assigns shall repay to the Republic of Cyprus on demand any sum
which the Republic of Cyprus may have paid as aforesaid for the relief or Support of the immigrant or for
the expenses of repatriation of the immigrant from Cyprus then the above written bond shall be void but
otherwise shall remain in full force.”

16. Ms Rantseva was granted a temporary residence permit as a visitor until 9 March 2001. She stayed in an
apartment with other young women working in X.A.'s cabaret. On 12 March 2001 she was granted a permit to work
until 8 June 2001 as an artiste in a cabaret owned by X.A. and managed by his brother, M.A. She began work on 16
March 2001.

17. On 19 March 2001, at around 11a.m., M.A. was informed by the other women living with Ms Rantseva that she
had left the apartment and taken all her belongings with her. The women told him that she had left a note in
Russian saying that she was tired and wanted to return to Russia. On the same date M.A. informed the Immigration
Office in Limassol that Ms Rantseva had abandoned her place of work and residence. According to M.A.'s
subsequent witness statement, he wanted Ms Rantseva to be arrested and expelled from Cyprus so that he could
bring another girl to work in the cabaret. However, Ms Rantseva's name was not entered on the list of persons
wanted by the police.

B. The events of 28 March 2001

18. On 28 March 2001, at around 4 a.m., Ms Rantseva was seen in a discotheque in Limassol by another cabaret
artiste. Upon being advised by the cabaret artiste that Ms Rantseva was in the discotheque, M.A. called the police
and asked them to arrest her. He then went to the discotheque together with a security guard from his cabaret. An
employee of the discotheque brought Ms Rantseva to him. In his subsequent witness statement, M.A. said
(translation):


-----

“When [Ms Rantseva] got in to my car, she did not complain at all or do anything else. She looked drunk
and I just told her to come with me. Because of the fact that she looked drunk, we didn't have a
conversation and she didn't talk to me at all.”

19. M.A. took Ms Rantseva to Limassol Central Police Station, where two police officers were on duty. He made a
brief statement in which he set out the circumstances of Ms Rantseva's arrival in Cyprus, her employment and her
subsequent disappearance from the apartment on 19 March 2001. According to the statement of the police officer
in charge when they arrived (translation):

“On 28 March 2001, slightly before 4a.m., [M.A.] found [Ms Rantseva] in the nightclub Titanic ... he took her
and led her to the police station stating that Ms Rantseva was illegal and that we should place her in the
cells. He ([M.A.]) then left the place (police station).”

20. The police officers then contacted the duty passport officer at his home and asked him to look into whether Ms
Rantseva was illegal. After investigating, he advised them that her name was not in the database of wanted
persons. He further advised that there was no record of M.A.'s complaint of 19 March 2001 and that, in any case, a
person did not become illegal until 15 days after a complaint was made. The passport officer contacted the person
in charge of the AIS (Police Aliens and Immigration Service), who gave instructions that Ms Rantseva was not to be
detained and that her employer, who was responsible for her, was to pick her up and take her to their Limassol
Office for further investigation at 7 a.m. that day. The police officers contacted M.A. to ask him to collect Ms
Rantseva. M.A. was upset that the police would not detain her and refused to come and collect her. The police
officers told him that their instructions were that if he did not take her they were to allow her to leave. M.A. became
angry and asked to speak to their superior. The police officers provided a telephone number to M.A. The officers
were subsequently advised by their superior that M.A. would come and collect Ms Rantseva. Both officers, in their
witness statements, said that Ms Rantseva did not appear drunk. The officer in charge said (translation):

“Ms Rantseva remained with us ... She was applying her make-up and did not look drunk ... At around
5.20a.m. ... I was ... informed that [M.A.] had come and picked her up...”

21. According to M.A.'s witness statement, when he collected Ms Rantseva from the police station, he also
collected her passport and the other documents which he had handed to the police when they had arrived. He then
took Ms Rantseva to the apartment of M.P., a male employee at his cabaret. The apartment M.P. lived in with his
wife, D.P., was a split-level apartment with the entrance located on the fifth floor of a block of flats. According to
M.A., they placed Ms Rantseva in a room on the second floor of the apartment. In his police statement, he said:

“She just looked drunk and did not seem to have any intention to do anything. I did not do anything to
prevent her from leaving the room in [the] flat where I had taken her.”

22. M.A. said that M.P. and his wife went to sleep in their bedroom on the second floor and that he stayed in the
living room of the apartment where he fell asleep. The apartment was arranged in such a way that in order to leave
the apartment by the front door, it would be necessary to pass through the living room.

23. M.P. stated that he left his work at the cabaret “Zygos” in Limassol at around 3.30 a.m. and went to the “Titanic”
discotheque for a drink. Upon his arrival there he was informed that the girl they had been looking for, of Russian
origin, was in the discotheque. Then M.A. arrived, accompanied by a security guard from the cabaret, and asked
the employees of “Titanic” to bring the girl to the entrance. M.A., Ms Rantseva and the security guard then all got
into M.A.'s car and left. At around 4.30 a.m. M.P. returned to his house and went to sleep. At around 6 a.m. his wife
woke him up and informed him that M.A. had arrived together with Ms Rantseva and that they would stay until the
Immigration Office opened. He then fell asleep.

24. D.P. stated that M.A. brought Ms Rantseva to the apartment at around 5.45 a.m.. She made coffee and M.A.
spoke with her husband in the living room. M.A. then asked D.P. to provide Ms Rantseva with a bedroom so that
she could get some rest. D.P. stated that Ms Rantseva looked drunk and did not want to drink or eat anything.
According to D.P., she and her husband went to sleep at around 6 a.m. while M.A. stayed in the living room. Having
made her statement, D.P. revised her initial description of events, now asserting that her husband had been asleep


-----

when M.A. arrived at their apartment with Ms Rantseva. She stated that she had been scared to admit that she had
opened the door of the apartment on her own and had had coffee with M.A..

25. At around 6.30 a.m. on 28 March 2001, Ms Rantseva was found dead on the street below the apartment. Her
handbag was over her shoulder. The police found a bedspread looped through the railing of the smaller balcony
adjoining the room in which Ms Rantseva had been staying on the upper floor of the apartment, below which the
larger balcony on the fifth floor was located.

26. M.A. claimed that he woke at 7 a.m. in order to take Ms Rantseva to the Immigration Office. He called to D.P.
and M.P. and heard D.P. saying that the police were in the street in front of the apartment building. They looked in
the bedroom but Ms Rantseva was not there. They looked out from the balcony and saw a body in the street. He
later discovered that it was Ms Rantseva.

27. D.P. claimed that she was woken by M.A. knocking on her door to tell her that Ms Rantseva was not in her room
and that they should look for her. She looked for her all over the apartment and then noticed that the balcony door
in the bedroom was open. She went out onto the balcony and saw the bedspread and realised what Ms Rantseva
had done. She went onto another balcony and saw a body lying on the street, covered by a white sheet and
surrounded by police officers.

28. M.P. stated that he was woken up by noise at around 7 a.m. and saw his wife in a state of shock; she told him
that Ms Rantseva had fallen from the balcony. He went into the living room where he saw M.A. and some police
officers.

29. In his testimony of 28 March 2001, G.A. stated that on 28 March 2001, around 6.30 a.m., he was smoking on
his balcony, located on the first floor of M.P. and D.P.'s building. He said:

“I saw something resembling a shadow fall from above and pass directly in front of me. Immediately
afterwards I heard a noise like something was breaking ... I told my wife to call the police ... I had heard
nothing before the fall and immediately afterwards I did not hear any voices. She did not scream during the
fall. She just fell as if she were unconscious ... Even if there had been a fight (in the apartment on the fifth
floor) I would not have been able to hear it.”

C. The investigation and inquest in Cyprus

30. The Cypriot Government advised the Court that the original investigation file had been destroyed in light of the
internal policy to destroy files after a period of five years in cases where it was concluded that death was not
attributable to a criminal act. A duplicate file, containing all the relevant documents with the exception of memo
sheets, has been provided to the Court by the Government.

31. The file contains a report by the officer in charge of the investigation. The report sets out the background facts,
as ascertained by forensic and crime scene evidence, and identifies 17 witnesses: M.A., M.P. D.P., G.A., the two
police officers on duty at Limassol Police Station, the duty passport officer, eight police officers who attended the
scene after Ms Rantseva's fall, the forensic examiner and the laboratory technician who analysed blood and urine
samples.

32. The report indicates that minutes after receiving the call from G.A.'s wife, shortly after 6.30 a.m., the police
arrived at the apartment building. They sealed off the scene at 6.40 a.m. and began an investigation into the cause
of Ms Rantseva's fall. They took photographs of the scene, including photographs of the room in the apartment
where Ms Rantseva had stayed and photographs of the balconies. The forensic examiner arrived at 9.30 a.m. and
certified death. An initial forensic examination took place at the scene

33. On the same day, the police interviewed M.A., M.P. and D.P. as well as G.A.. They also interviewed the two
police officers who had seen M.A. and Ms Rantseva at Limassol Police Station shortly before Ms Rantseva's death
and the duty passport officer (relevant extracts and summaries of the statements given is included in the facts set
out above at paras 17 to 29). Of the eight police officers who attended the scene, the investigation file includes
statements made by six of them including the officer placed in charge of the investigation There is no record of any


-----

statements being taken either from other employees of the cabaret where Ms Rantseva worked or from the women
with whom she briefly shared an apartment.

34. When he made his witness statement on 28 March 2001, M.A. handed Ms Rantseva's passport and other
documents to the police. After the conclusion and signature of his statement, he added a clarification regarding the
passport, indicating that Ms Rantseva had taken her passport and documents when she left the apartment on 19
March 2001.

35. On 29 March 2001 an autopsy was carried out by the Cypriot authorities. The autopsy found a number of
injuries on Ms Rantseva's body and to her internal organs. It concluded that these injuries resulted from her fall and
that the fall was the cause of her death. It is not clear when the applicant was informed of the results of the autopsy.
According to the applicant, he was not provided with a copy of the autopsy report and it is unclear whether he was
informed in any detail of the conclusions of the report, which were briefly summarised in the findings of the
subsequent inquest.

36. On 5 August 2001 the applicant visited Limassol Police Station together with a lawyer and spoke to the police
officer who had received Ms Rantseva and M.A. on 28 March 2001. The applicant asked to attend the inquest.
According to a later statement by the police officer, dated 8 July 2002, the applicant was told by the police during
the visit that his lawyer would be informed of the date of the inquest hearing before the District Court of Limassol.

37. On 10 October 2001 the applicant sent an application to the District Court of Limassol, copied to the General
Procurator's Office of the Republic of Cyprus and the Russian Consulate in the Republic of Cyprus. He referred to a
request of 8 October 2001 of the Procurator's Office of the Chelyabinsk region concerning legal assistance (see
para 48 below) and asked to exercise his right to familiarise himself with the materials of the case before the
inquest hearing, to be present at the hearing and to be notified in due time of the date of the hearing. He also
advised that he wished to present additional documents to the court in due course.

38. The inquest proceedings were fixed for 30 October 2001 and, according to the police officer's statement of 8
July 2002 (see para 36 above), the applicant's lawyer was promptly informed. However, neither she nor the
applicant appeared before the District Court. The case was adjourned to 11 December 2001 and an order was
made that the Russian Embassy be notified of the new date so as to inform the applicant.

39. In a facsimile dated 20 October 2001 and sent on 31 October 2001 to the District Court of Limassol, copied to
the General Procurator's Office of the Republic of Cyprus and the Russian Consulate in the Republic of Cyprus, the
applicant asked for information regarding the inquest date to be sent to his new place of residence.

40. On 11 December 2001 the applicant did not appear before the District Court and the inquest was adjourned
until 27 December 2001.

41. On 27 December 2001 the inquest took place before the Limassol District Court in the absence of the applicant.
The court's verdict of the same date stated, inter alia (translation):

“At around 6.30 a.m. on [28 March 2001] the deceased, in an attempt to escape from the afore-mentioned
apartment and in strange circumstances, jumped into the void as a result of which she was fatally injured...

My verdict is that MS OXANA RANTSEVA died on 28 March 2001, in circumstances resembling an
accident, in an attempt to escape from the apartment in which she was a guest (εφιλοξενείτο).

There is no evidence before me that suggests criminal liability of a third person for her death”.

D. Subsequent proceedings in Cyprus and Russia

42. Ms Rantseva's body was transferred to Russia on 8 April 2001.

43. On 9 April 2001 the applicant requested the Chelyabinsk Regional Bureau of Medical Examinations (“the
Chelyabinsk Bureau”) to perform an autopsy of the body. He further requested the Federal Security Service of the


-----

Russian Federation and the General Prosecutor's Office to investigate Ms Rantseva's death in Cyprus. On 10 May
2001 the Chelyabinsk Bureau issued its report on the autopsy.

44. In particular the following was reported in the forensic diagnosis (translation provided):

“It is a trauma from falling down from a large height, the falling on a plane of various levels, politrauma of
the body, open cranial trauma: multiple fragmentary comminuted fracture of the facial and brain skull,
multiple breeches of the brain membrane on the side of the brain vault and the base of the skull in the front
brain pit, haemorrhages under the soft brain membranes, haemorrhages into the soft tissues, multiple
bruises, large bruises and wounds on the skin, expressed deformation of the head in the front-to-back
direction, closed dull trauma of the thorax with injuries of the thorax organs..., contusion of the lungs along
the back surface, fracture of the spine in the thorax section with the complete breach of the marrow and its
displacement along and across ...

Alcohol intoxication of the medium degree: the presence of ethyl alcohol in the blood 1,8%, in the urine 2,5%.”

45. The report's conclusions included the following:

“The color and the look of bruises, breaches and wounds as well as hemorrhages with the morphological
changes of the same type in the injured tissues indicates, without any doubt, that the traumas happened
while she was alive, as well as the fact, that they happened not very long before death, within a very short
time period, one after another.

During the forensic examination of the corpse of Rantseva O.N. no injuries resulting from external violence,
connected with the use of various firearms, various sharp objects and weapons, influence of physical and
chemical reagents or natural factors have been established. ... During the forensic chemical examination of
the blood and urine, internal organs of the corpse no narcotic, strong or toxic substances are found. Said
circumstances exclude the possibility of the death of Rantseva O.N. from firearms, cold steel, physical,
chemical and natural factors as well as poisoning and diseases of various organs and systems. ...

Considering the location of the injuries, their morphological peculiarities, as well as certain differences,
discovered during the morphological and histological analysis and the response of the injured tissues we
believe that in this particular case a trauma from falling down from the great height took place, and it was
the result of the so-called staged/bi-moment fall on the planes of various levels during which the primary
contact of the body with an obstacle in the final phase of the fall from the great height was by the back
surface of the body with a possible sliding and secondary contact by the front surface of the body, mainly
the face with the expressed deformation of the head in the front-to-back direction due to shockcompressive impact...

During the forensic chemical examination of the corpse of Rantseva O.N. in her blood and urine we found
ethyl spirits 1,8 and 2,5 correspondingly, which during her life might correspond to medium alcohol
intoxication which is clinically characterized by a considerable emotional instability, breaches in mentality
and orientation in space in time.”

46. On 9 August 2001 the Russian Embassy in Cyprus requested from the chief of Limassol police station copies of
the investigation files relating to Ms Rantseva's death.

47. On 13 September 2001 the applicant applied to the Public Prosecutor of the Chelyabinsk region requesting the
Prosecutor to apply on his behalf to the Public Prosecutor of Cyprus for legal assistance free of charge as well as
an exemption from court expenses for additional investigation into the death of his daughter on the territory of
Cyprus.

48. By letter dated 11 December 2001 the Deputy General Prosecutor of the Russian Federation advised the
Minister of Justice of the Republic of Cyprus that the Public Prosecutor's Office of the Chelyabinsk region had
conducted an examination in respect of Ms Rantseva's death, including a forensic medical examination. He
forwarded a request, dated 8 October 2001, under the European Convention on Mutual Assistance in Criminal


-----

Matters (“the Mutual Assistance Convention” – see paras 175 to 178 below) and the Treaty between the USSR and
the Republic of Cyprus on Civil and Criminal Matters 1984 (“the Legal Assistance Treaty” – see paras 179 to 185
below), for legal assistance for the purposes of establishing all the circumstances of Ms Rantseva's death and
bringing to justice guilty parties, under Cypriot legislation. The request included the findings of the Russian
authorities as to the background circumstances; it is not clear how the findings were reached and what, if any,
investigation was conducted independently by the Russian authorities.

49. The findings stated, inter alia, as follows (translation provided):

“The police officers refused to arrest Rantseva O.N. due to her right to stay on the territory of Cyprus
without the right to work for 14 days, i.e. until April 2, 2001. Then Mr [M.A.] suggested to detain Rantseva
O.N. till the morning as a drunken person. He was refused, since, following the explanations provided by
the police officers Rantseva O.N. looked like a sober person, behaved decently, was calm, was laying
make-up. M.A., together with an unestablished person, at 5.30a.m. on March 28, 2001 took Rantseva O.N.
from the regional police precinct and brought her to the apartment of [D.P.] ... where [they] organised a
meal, and then, at 6.30a.m. locked Rantseva O.N. in a room of the attic of the 7[th] floor of said house.”

50. The request highlighted the conclusion of the experts at the Chelyabinsk Bureau of Forensic Medicine that there
had been two stages in Ms Rantseva's fall, first on her back and then on her front. The request noted that this
conclusion contradicted the findings made in the Cypriot forensic examination that Ms Rantseva's death had
resulted from a fall face-down. It further noted:

“It is possible to suppose, that at the moment of her falling down the victim could cry from horror. However,
it contradicts the materials of the investigation, which contain the evidence of an inhabitant of the 2[nd] floor
of this row of loggias, saying that a silent body fell down on the asphalt ...”

51. The report concluded:

“Judging by the report of the investigator to Mr Rantsev N.M., the investigation ends with the conclusion
that the death of Rantseva O.N. took place under strange and un-established circumstances, demanding
additional investigation.”

52. The Prosecutor of the Chelyabinsk region therefore requested, in accordance with the Legal Assistance Treaty,
that further investigation be carried out into the circumstances of Ms Rantseva's death in order to identify the cause
of death and eliminate the contradictions in the available evidence; that persons having any information concerning
the circumstances of the death be identified and interviewed; that the conduct of the various parties be considered
from the perspective of bringing murder and/or kidnapping and unlawful deprivation of freedom charges, and in
particular that M.A. be investigated; that the applicant be informed of the materials of the investigation; that the
Russian authorities be provided with a copy of the final decisions of judicial authorities as regards Ms Rantseva's
death; and that the applicant be granted legal assistance free of charge and be exempted from paying court
expenses.

53. On 27 December 2001 the Russian Federation wrote to the Cypriot Ministry of Justice requesting, on behalf of
the applicant, that criminal proceedings be instituted in respect of Ms Rantseva's death, that the applicant be joined
as a victim in the proceedings and that he be granted free legal assistance.

54. On 16 April 2002 the Russian Embassy in Cyprus conveyed to the Cypriot Ministry of Justice and Public Order
the requests dated 11 December and 27 December 2001 of the General Prosecutor's Office of the Russian
Federation, made under the Legal Assistance Treaty, for legal assistance concerning Ms Rantseva's death.

55. On 25 April 2002 the Office of the Prosecutor General of the Russian Federation reiterated its request for the
institution of criminal proceedings in connection with Ms Rantseva's death and the applicant's request to be added
as a victim to the proceedings in order to submit his further evidence, as well as his request for legal aid. It
requested the Cypriot Government to provide an update and advise of any decisions that had been taken.


-----

56. On 25 November 2002, the applicant applied to the Russian authorities to be recognised as a victim in the
proceedings concerning his daughter's death and reiterated his request for legal assistance. The request was
forwarded by the Office of the Prosecutor General of the Russian Federation to the Cypriot Ministry of Justice.

57. By letter of 27 December 2002 the Assistant to the Prosecutor General of the Russian Federation wrote to the
Cypriot Ministry of Justice referring to the detailed request made by the applicant for the initiation of criminal
proceedings in connection with the death of his daughter and for legal aid in Cyprus, which had previously been
forwarded to the Cypriot authorities pursuant to the Mutual Assistance Convention and the Legal Assistance Treaty.
The letter noted that no information had been received and requested that a response be provided.

58. On 13 January 2003 the Russian Embassy wrote to the Cypriot Ministry of Foreign Affairs requesting an
expedited response to its request for legal assistance in respect of Ms Rantseva's death.

59. By letters of 17 and 31 January 2003 the Office of the Prosecutor General of the Russian Federation noted that
it had received no response from the Cypriot authorities in relation to its requests for legal assistance, the contents
of which it repeated.

60. On 4 March 2003 the Cypriot Ministry of Justice informed the Prosecutor General of the Russian Federation that
its request had been duly executed by the Cypriot police. A letter from the Chief of Police, and the police report of 8
July 2002 recording the applicant's visit to Limassol Police Station in August 2001 were enclosed.

61. On 19 May 2003 the Russian Embassy wrote to the Cypriot Ministry of Foreign Affairs requesting an expedited
response to its request for legal assistance in respect of Ms Rantseva's death.

62. On 5 June 2003 the Office of the Prosecutor General of the Russian Federation submitted a further request
pursuant to the Legal Assistance Treaty. It requested that a further investigation be conducted into the
circumstances of Ms Rantseva's death as the verdict of 27 December 2001 was unsatisfactory. In particular, it
noted that despite the strange circumstances of the incident and the acknowledgment that Ms Rantseva was trying
to escape from the flat where she was held, the verdict did not make any reference to the inconsistent testimonies
of the relevant witnesses or contain any detailed description of the findings of the autopsy carried out by the Cypriot
authorities.

63. On 8 July 2003 the Russian Embassy wrote to the Cypriot Ministry of Foreign Affairs requesting a reply to its
previous requests as a matter of urgency.

64. On 4 December 2003 the Commissioner for Human Rights of the Russian Federation forwarded the applicant's
complaint about the inadequate reply from the Cypriot authorities to the Cypriot Ombudsman.

65. On 17 December 2003, in reply to the Russian authorities' request (see para 52 above), the Cypriot Ministry of
Justice forwarded to the Prosecutor General of the Russian Federation a further report prepared by the Cypriot
police and dated 17 November 2003. The report was prepared by one of the officers who had attended the scene
on 28 March 2001 and provided brief responses to the questions posed by the Russian authorities. The report
reiterated that witnesses had been interviewed and statements taken. It emphasised that all the evidence was taken
into consideration by the inquest. It continued as follows (translation):

“At about 6.30a.m. on 28 March 2001 the deceased went out onto the balcony of her room through the
balcony door, climbed down to the balcony of the first floor of the apartment with the assistance of a
bedspread which she tied to the protective railing of the balcony. She carried on her shoulder her personal
bag. From that point, she clung to the aluminium protective railing of the balcony so as to climb down to the
balcony of the apartment on the floor below in order to escape. Under unknown circumstances, she fell into
the street, as a result of which she was fatally injured.”

66. The report observed that it was not known why Ms Rantseva left the apartment on 19 March 2001 but on the
basis of the investigation (translation):


-----

“... it is concluded that the deceased did not want to be expelled from Cyprus and because her employer
was at the entrance of the flat where she was a guest, she decided to take the risk of trying to climb over
the balcony, as a result of which she fell to the ground and died instantaneously.”

67. As to the criticism of the Cypriot autopsy and alleged inconsistencies in the forensic evidence between the
Cypriot and Russian authorities, the report advised that these remarks had been forwarded to the Cypriot forensic
examiner who had carried out the autopsy. His response was that his own conclusions were sufficient and that no
supplementary information was required. Finally, the report reiterated that the inquest had concluded that there was
no indication of any criminal liability for Ms Rantseva's death.

68. By letter of 17 August 2005 the Russian Ambassador to Cyprus requested further information about a hearing
concerning the case apparently scheduled for 14 October 2005 and reiterated the applicant's request for free legal
assistance. The Cypriot Ministry of Justice responded by facsimile of 21 September 2005 indicating that Limassol
District Court had been unable to find any reference to a hearing in the case fixed for 14 October 2005 and
requesting clarification from the Russian authorities.

69. On 28 October 2005 the applicant asked the Russian authorities to obtain testimonies from two young Russian
women, now resident in Russia, who had been working with Ms Rantseva at the cabaret in Limassol and could
testify about sexual exploitation taking place there. He reiterated his request on 11 November 2005. The Russian
authorities replied that they could only obtain such testimonies upon receipt of a request by the Cypriot authorities.

70. By letter of 22 December 2005 the Office of the Prosecutor General of the Russian Federation wrote to the
Cypriot Ministry of Justice seeking an update on the new inquest into Ms Rantseva's death and requesting
information on how to appeal Cypriot court decisions. The letter indicated that, according to information available,
the hearing set for 14 October 2005 had been suspended due to the absence of evidence from the Russian
nationals who had worked in the cabaret with Ms Rantseva. The letter concluded with an undertaking to assist in
any request for legal assistance by Cyprus aimed at the collection of further evidence.

71. In January 2006, according to the applicant, the Attorney-General of Cyprus confirmed to the applicant's lawyer
that he was willing to order the re-opening of the investigation upon receipt of further evidence showing any criminal
activity.

72. On 26 January 2006 the Russian Embassy wrote to the Cypriot Ministry of Justice requesting an update on the
suspended hearing of 14 October 2005. The Ministry of Justice replied by facsimile on 30 January 2006 confirming
that neither the District Court of Limassol nor the Supreme Court of Cyprus had any record of such a hearing and
requesting further clarification of the details of the alleged hearing.

73. On 11 April 2006 the Office of the Prosecutor General of the Russian Federation wrote to the Cypriot Ministry of
Justice requesting an update on the suspended hearing and reiterating its query regarding the appeals procedure in
Cyprus.

74. On 14 April 2006, by letter to the Russian authorities, the Attorney-General of Cyprus advised that he saw no
reason to request the Russian authorities to obtain the testimonies of the two Russian citizens identified by the
applicant. If the said persons were in the Republic of Cyprus their testimonies could be obtained by the Cypriot
police and if they were in Russia, the Russian authorities did not need the consent of the Cypriot authorities to
obtain their statements.

75. On 26 April 2006 the Cypriot Ministry of Justice replied to the Office of the Prosecutor General of the Russian
Federation reiterating its request for more information about the alleged suspended hearing.

76. On 17 June 2006 the Office of the Prosecutor General of the Russian Federation wrote to the Attorney-General
of Cyprus reminding him of the outstanding requests for renewal of investigations into Ms Rantseva's death and for
information on the progress of judicial proceedings.


-----

77. On 22 June and 15 August 2006 the applicant reiterated his request to the Russian authorities that statements
be taken from the two Russian women.

78. On 17 October 2006 the Cypriot Ministry of Justice confirmed to the Office of the Prosecutor General of the
Russian Federation that the inquest into Ms Rantseva's death was completed on 27 December 2001 and that it
found that her death was the result of an accident. The letter noted:

“No appeal was filed against the decision, because of the lack of additional evidence”.

79. On 25 October 2006, 27 October 2006, 3 October 2007 and 6 November 2007 the applicant reiterated his
request to the Russian authorities that statements be taken from the two Russian women.
_II. REPORTS ON THE SITUATION OF “ARTISTES” IN CYPRUS_

A. Ex Officio report of the Cypriot Ombudsman on the regime regarding entry and employment of alien women as
artistes in entertainment places in Cyprus, 24 November 2003

80. In November 2003, the Cypriot Ombudsman published a report on “artistes” in Cyprus. In her introduction, she
explained the reasons for her report as follows (all quotes are from a translation of the report provided by the
Cypriot Government):

“Given the circumstances under which [Oxana] Rantseva had lost her life and in the light of similar cases
which have been brought into publicity regarding violence or demises of alien women who arrives in
Cyprus to work as 'artistes', I have decided to undertake an ex officio investigation ...”

81. As to the particular facts of Ms Rantseva's case, she noted the following:

“After formal immigration procedures, she started working on 16 March 2001. Three days later she
abandoned the cabaret and the place where she had been staying for reasons which have never been
clarified. The employer reported the fact to the Aliens and Immigration Department in Limassol. However,

[Oxana] Rantseva's name was not inserted on the list comprising people wanted by the Police, for
unknown reasons, as well.”

82. She further noted that:

“The reason for which [Oxana] Rantseva was surrendered by the police to her employer, instead of setting
her free, since there were [neither] arrest warrant [nor] expulsion decree against her, remained unknown.”

83. The Ombudsman's report considered the history of the employment of young foreign women as cabaret
artistes, noting that the word “artiste” in Cyprus has become synonymous with “prostitute”. Her report explained that
since the mid-1970s, thousands of young women had legally entered Cyprus to work as artistes but had in fact
worked as prostitutes in one of the many cabarets in Cyprus. Since the beginning of the 1980s, efforts had been
made by the authorities to introduce a stricter regime in order to guarantee effective immigration monitoring and to
limit the “well-known and commonly acknowledged phenomenon of women who arrived in Cyprus to work as
artistes”. However, a number of the measures proposed had not been implemented due to objections from cabaret
managers and artistic agents.

84. The Ombudsman's report noted that in the 1990s, the prostitution market in Cyprus started to be served by
women coming mainly from former States of the Soviet Union. She concluded that:

“During the same period, one could observe a certain improvement regarding the implementation of those
measures and the policy being adopted. However, there was not improvement regarding sexual
exploitation, trafficking and mobility of women under a regime of modern slavery.”

85. As regards the living and working conditions of artistes, the report stated:

“The majority of the women entering the country to work as artistes come from poor families of the post
socialist countries. Most of them are educated ... Few are the real artistes. Usually they are aware that they
will be compelled to prostitute themselves. However, they do not always know about the working conditions


-----

under which they will exercise this job. There are also cases of alien women who come to Cyprus, having
the impression that they will work as waitresses or dancers and that they will only have drinks with clients
('consomation'). They are made by force and threats to comply with the real terms of their work ...

Alien women who do not succumb to this pressure are forced by their employers to appear at the District
Aliens and Immigration Branch to declare their wish to terminate their contract and to leave Cyprus on
ostensible grounds ... Consequently, the employers can replace them quickly with other artistes ...

The alien artistes from the moment of their entry into the Republic of Cyprus to their departure are under
constant surveillance and guard of their employers. After finishing their work, they are not allowed to go
wherever they want. There are serious complaints even about cases of artistes who remain locked in their
residence place. Moreover, their passports and other personal documents are retained by their employers
or artistic agents. Those who refuse to obey are punished by means of violence or by being imposed fees
which usually consist in deducting percentages of drinks, 'consommation' or commercial sex. Of course
these amounts are included in the contracts signed by the artistes.

...

Generally, artistes stay at one or zero star hotels, flats or guest-houses situated near or above the
cabarets, whose owners are the artistic agents or the cabaret owners. These places are constantly
guarded. Three or four women sleep in each room. According to reports given by the Police, many of these
buildings are inappropriate and lack sufficient sanitation facilities.

...Finally, it is noted that at the point of their arrival in Cyprus alien artistes are charged with debts, for
instance with traveling expenses, commissions deducted by the artistic agent who brought them in Cyprus
or with commissions deducted by the agent who located them in their country etc. Therefore, they are
obliged to work under whichever conditions to pay off at least their debts.” (footnotes omitted)

86. Concerning the recruitment of women in their countries of origin, the report noted:

“Locating women who come to work in Cyprus is usually undertaken by local artistic agents in cooperation
with their homologues in different countries and arrangements are made between both of them. After
having worked for six months maximum in Cyprus, a number of these artistes are sent to Lebanon, Syria,
Greece or Germany.” (footnotes omitted)

87. The Ombudsman observed that the police received few complaints from trafficking victims:

“The police explain that the small number of complaints filed is due to the fear that artistes feel, since they
receive threats against their lives on the part of their procurer.”

88. She further noted that protection measures for victims who had filed complaints were insufficient. Although they
were permitted to work elsewhere, they were required to continue working in similar employment. They could
therefore be easily located by their former employers.

89. The Ombudsman concluded:

“The phenomenon of trafficking in person has so tremendously grown worldwide. Trafficking in persons
concerns not only sexual exploitation of others but also exploitation of their employment under conditions
of slavery and servitude ...

From the data of this report it is observed that over the last two decades Cyprus has not been only a
destination country but a transit country where women are systematically promoted to the prostitution
market. It follows also that this is also due to a great extent to the tolerance on the part of the immigration
authorities, which are fully aware of what really happens.

On the basis of the policy followed as for the issue of entry and employment permits to entertainment and
show places, thousands of alien women, with no safety valve, have entered by law the country to work as
artistes unlawfully. In various forms of pressure and coercion most of these women are forced by their


-----

employers to prostitution under cruel conditions, which infringe upon the fundamental human rights, such
as individual freedom and human dignity.” (footnotes omitted)

90. Although she considered the existing legislative framework to combat trafficking and sexual exploitation
satisfactory, she noted that no practical measures had been taken to implement the policies outlined, observing
that:

“...The various departments and services dealing with this problem, are often unaware of the matter and
have not been properly trained or ignore those obligations enshrined in the Law ...”

B. Extracts of report of 12 February 2004 by the Council of Europe Commissioner for Human Rights on his visit to
Cyprus in June 2003 (CommDH(2004)2)

91. The Council of Europe Commissioner for Human Rights visited Cyprus in June 2003 and in his subsequent
report of 12 February 2004, he referred to issues in Cyprus regarding trafficking of women. The report noted, inter
_alia, that:_

“29. It is not at all difficult to understand how Cyprus, given its remarkable economic and tourist
development, has come to be a major destination for this traffic in the Eastern Mediterranean region. The
absence of an immigration policy and the legislative shortcomings in that respect have merely encouraged
the phenomenon.”

92. As regards the legal framework in place in Cyprus (see paras 127 to 131 below), the Commissioner observed:

“30. The authorities have responded at the normative level. The Act of 2000 (number 3(I), 2000) has
established a suitable framework for suppression of trafficking in human beings and sexual exploitation of
children. Under the Act, any action identifiable as trafficking in human beings in the light of the Convention
for the Suppression of Trafficking in Persons and of the Exploitation and Prostitution of Others, together
with other acts of a similar nature specified by law, are an offence punishable by 10 years' imprisonment,
the penalty being increased to 15 years where the victim is under 18 years of age. The offence of sexual
exploitation carries a 15 year prison sentence. If committed by persons in the victim's entourage or persons
wielding authority or influence over the victim, the penalty is 20 years in prison. According to the provisions
of Article 4, using children for the production and sale of pornographic material is an offence. Article 7
grants State aid, within reasonable limits, to victims of exploitation; such aid comprises subsistence
allowance, temporary accommodation, medical care and psychiatric support. Article 8 reaffirms the right to
redress by stressing the power of the court to award punitive damages justified by the degree of
exploitation or the degree of the accused person's constraint over the victim. A foreign worker lawfully
present in Cyprus who is a victim of exploitation can approach the authorities to find other employment up
until the expiry of the initial work permit (Article 9). Lastly, the Council of Ministers, under Article 10,
appoints a guardian for victims with the principal duties of counselling and assisting them, examining
complaints of exploitation, and having the culprits prosecuted, as well as for pinpointing any deficiency or
loophole in the law and for making recommendations with a view to their removal.”

93. Concerning practical measures, the Commissioner noted:

“31. At a practical level, the Government has made efforts to protect women who have laid a complaint
against their employers by permitting them to remain in the country in order to substantiate the charges. In
certain cases, the women have remained in Cyprus at government expense during the investigation.”

94. However, he criticised the failure of the authorities to tackle the problem of the excessive number of young
foreign women coming to work in Cypriot cabarets:

“32. However, apart from punitive procedures, preventive control measures could be introduced. By the
authorities' own admission, the number of young women migrating to Cyprus as nightclub artistes is well
out of proportion to the population of the island.”


-----

C. Extracts of follow-up report of 26 March 2006 by the Council of Europe Commissioner for Human Rights on the
progress made in implementing his recommendations (CommDH(2006)12)

95. On 26 March 2006, the Council of Europe Commissioner for Human Rights published a follow-up report in
which he assessed the progress of the Cypriot Government in implementing the recommendations of his previous
report. As regards the issue of trafficking, the report observed that:

“48. The Commissioner noted in his 2003 report that the number of young women migrating to Cyprus as
nightclub artistes was well out of proportion to the population of the island, and that the authorities should
consider introducing preventive control measures to deal with this phenomenon, in conjunction with
legislative safeguards. In particular, the Commissioner recommended that the authorities adopt and
implement a plan of action against trafficking in human beings.”

96. The report continued:

“49. The so called 'cabaret artiste' visas are in fact permits to enter and work in nightclubs and bars. These
permits are valid for 3 months and can be extended for a further 3 months. The permit is applied for by the
establishment owner on behalf of the woman in question. Approximately 4,000 permits are issued each
year, with 1,200 women working at a given time and most women originating from Eastern Europe. A
special information leaflet has been prepared by the Migration Service and translated into four languages.
The leaflet is given to women entering the country on such permits, is also available on the website of the
Ministry of the Interior and the Ministry of Foreign Affairs and copies of the leaflet are sent to the
consulates in Russia, Bulgaria, the Ukraine and Romania in order for women to be informed before they
enter Cyprus. The leaflet sets out the rights of the women and the responsibilities of their employers. The
authorities are aware that many of the women who enter Cyprus on these artistes visas will in fact work in
prostitution.”

97. The Commissioner's report highlighted recent and pending developments in Cyprus:

“50. A new Law on Trafficking in Human Beings is currently being discussed. The new law will include
other forms of exploitation such as labour trafficking as well as trafficking for sexual exploitation. Cyprus
has signed but not ratified the Council of Europe Convention on Action Against Trafficking in Human
Beings.

51. The Attorney General's Office has prepared a National Action Plan for the Combating of Human
Trafficking. The Action Plan was presented and approved by the Council of Ministers in April 2005. Some
NGOs complained of their lack of involvement in the consultation process. The Ministry of the Interior is
responsible for the implementation of the Action Plan. According to the Action Plan, women involved in
cases of sexual exploitation or procuring are not arrested or charged with any offence, but are considered
as victims and are under the care of the Ministry of Labour and Social Security. Victims who will act as
witnesses in court trials can reside in Cyprus until the end of the case. They have the possibility of working,
or if they do not wish to work, the Ministry will cover all their residential, health and other needs. A special
procedures manual has been drafted for the treatment of victims of trafficking, and has been circulated to
all ministries and government departments, as well as NGOs for consultation.

52. There is no specific shelter for victims of trafficking at present, although victims may be accommodated
by the authorities in two rooms in state-owned retirement homes, which are available in each major town. A
shelter in Limassol is due to be opened soon, which will provide accommodation for 15 women, as well as
providing the services of a social worker, lawyer, and vocational advisor.”

98. As regards steps taken to improve information collection and research into trafficking, he noted:

“53. An Office for the Prevention and Combating of Human Trafficking was set up by the police in April
2004. The office's role is to collect and evaluate intelligence regarding trafficking in human beings, to coordinate operations of all police divisions and departments, to organise and participate in operations, and
to follow-up on cases that are under investigation, pending trial or presented to the courts. The office also


-----

prepares reports on trafficking and investigates child pornography on the Internet. In addition, the office
organises educational seminars carried out at the Cyprus Police Academy.

54. According to statistical information provided by the police from 2000 to 2005, there is a clear increase
in the number of cases reported concerning offences of sexual exploitation, procuring, and living on the
earnings of prostitution, etc. NGOs confirm that awareness about issues relating to trafficking has
increased.”

99. Finally, in respect of preventative measures, the Commissioner highlighted recent positive developments:

“55. Preventive and suppressive measures are also undertaken by the police, such as raids in cabarets,
inspections, interviews with women, co-operation with mass media, and control of advertisements found in
different newspapers. The police provide an anonymous toll-free hotline where anybody can call to seek
help or give information. Cabarets which are under investigation are put on a black list and are unable to
apply for new visas.

56. Some efforts have been made by the Cypriot authorities to improve victim identification and referral,
and in particular, 150 police officers have been trained on this issue. However, according to NGOs a
culture still prevails in which women are seen by the police to have 'consented' to their predicament and
victim identification remains inadequate.”

100. The report reached the following conclusions:

“57. Trafficking in human beings is one of the most pressing and complex Human Rights issues faced by
Council of Europe member states, including Cyprus. There is obviously a risk that the young women who
enter Cyprus on artiste visas may be victims of trafficking in human beings or later become victims of
abuse or coercion. These women are officially recruited as cabaret dancers but are nevertheless often
expected also to work as prostitutes. They are usually from countries with inferior income levels to those in
Cyprus and may find themselves in a vulnerable position to refuse demands from their employers or
clients. The system itself, whereby the establishment owner applies for the permit on behalf of the woman,
often renders the woman dependent on her employer or agent, and increases the risk of her falling into the
hands of trafficking networks.

58. The Commissioner urges the Cypriot authorities to be especially vigilant about monitoring the situation
and ensuring that the system of artiste visas is not used for facilitating trafficking or forced prostitution. In
this context, the Commissioner recalls the exemplary reaction of the Luxembourg authorities to similar
concerns expressed in his report on the country and their withdrawal of the cabaret artiste visa regime.
Changes to the current practice might, at the very least, include women having to apply for the visa
themselves, and the information leaflet being given to the women, if possible, before they enter the
country.

59. The Commissioner welcomes the new National Action Plan for the Combating of Human Trafficking as
a first step in addressing this issue and encourages the Ministry of the Interior to ensure its full
implementation. The new law on trafficking, once enacted, will also play an important role. The variety of
police activities in response to this phenomenon, such as the setting up of the Office for the Prevention and
Combating of Human Trafficking, should also be welcomed.

60. In order to respect the human rights of trafficked persons, the authorities need to be able to identify
victims and refer them to specialised agencies which can offer shelter and protection, as well as support
services. The Commissioner urges the Cypriot authorities to continue with the training of police officers in
victim identification and referral, and encourages the authorities to include women police officers in this
area. More effective partnerships with NGOs and other civil society actors should also be developed. The
Commissioner expresses his hope that the shelter in Limassol will be put into operation as soon as
possible.”

D. Extracts of report of 12 December 2008 by the Council of Europe Commissioner for Human Rights on his visit to

Cyprus on 7‑10 July 2008 (CommDH(2008)36)


-----

101. The Commissioner of Human Rights has recently published a further report following a visit to Cyprus in July
2008. The report comments on the developments in respect of issues relating to trafficking of human beings,
emphasising at the outset that trafficking of women for exploitation was a major problem in many European
countries, including Cyprus. The report continued as follows:

“33. Already in 2003, the Commissioner for Administration (Ombudswoman) stated that Cyprus had been
associated with trafficking both as a country of destination and transit, the majority of women being
blackmailed and forced to provide sexual services. In 2008, the island still is a destination country for a
large number of women trafficked from the Philippines, Russia, Moldova, Hungary, Ukraine, Greece,
Vietnam, Uzbekistan and the Dominican Republic for the purpose of commercial sexual exploitation ...
Women are reportedly denied part or all of their salaries, forced to surrender their passports, and pressed
into providing sexual services for clients. Most of these women are unable to move freely, are forced to
work far above normal working hours, and live in desperate conditions, isolated and under strict
surveillance.

34. Victims of trafficking are recruited to Cyprus mainly on three-month so-called 'artiste' or 'entertainment'
visas to work in the cabaret industry including night clubs and bars or on tourist visas to work in massage
parlours disguised as private apartments ... The permit is sought by the owner of the establishment, in
most cases so-called 'cabarets', for the women in question.

35. The study conducted by the Mediterranean Institute of Gender Studies (MIGS) led to a report on
trafficking in human beings published in October 2007. It shows that an estimated 2 000 foreign women
enter the island every year with short term 'artiste' or 'entertainment' work permits. Over the 20-year period
1982-2002, there was a dramatic increase of 111% in the number of cabarets operating on the island ...

36. During his visit the Commissioner learned that there are now approximately 120 cabaret
establishments in the Republic of Cyprus, each of them employing around 10 to 15 women ...” (footnotes
_omitted)_

102. The Commissioner noted that the Government had passed comprehensive anti-trafficking legislation
criminalising all forms of trafficking, prescribing up to 20 years' imprisonment for sexual exploitation and providing
for protection and support measures for victims (see paras 127 to 131 below). He also visited the new governmentrun shelter in operation since November 2007 and was impressed by the facility and the commitment shown by
staff. As regards allegations of corruption in the police force, and the report noted as follows:

“42. The Commissioner was assured that allegations of trafficking-related corruption within the police force
were isolated cases. The authorities informed the Commissioner that so far, three disciplinary cases
involving human trafficking/prostitution have been investigated: one resulted in an acquittal and two are still
under investigation. In addition, in 2006, a member of the police force was sentenced to 14 months
imprisonment and was subsequently dismissed from service following trafficking related charges.”

103. The report drew the following conclusions in respect of the artiste permit regime in Cyprus:

“45. The Commissioner reiterates that trafficking in women for the purposes of sexual exploitation is a
pressing and complex human rights issues faced by a number of Council of Europe member States,
including Cyprus. A paradox certainly exists that while the Cypriot government has made legislative efforts
to fight trafficking in human beings and expressed its willingness through their National Action Plan 2005, it
continues to issue work permits for so-called cabaret artistes and licences for the cabaret establishments.
While on paper the permits are issued to those women who will engage in some type of artistic
performance, the reality is that many, if not most, of these women are expected to work as prostitutes.

46. The existence of the 'artiste' work permit leads to a situation which makes it very difficult for law
enforcement authorities to prove coercion and trafficking and effectively combat it. This type of permit could
thus be perceived as contradicting the measures taken against trafficking or at least as rendering them
ineffective.

47. For these reasons, the Commissioner regrets that the 'artiste' work permit is still in place today despite
the fact that the government has previously expressed its commitment to abolish it It seems that the


-----

special information leaflet given to women entering the country on such a permit is of little effect, even
though the woman needs to have read and signed the leaflet in the presence of an official.

48. The Commissioner calls upon the Cypriot authorities to abolish the current scheme of cabaret 'artistes'
work permits ...”

104. The Commissioner also reiterated the importance of a well-trained and motivated police force in the fight
against trafficking in human beings and encouraged the authorities to ensure adequate and timely victim
identification.

E. Trafficking in Persons Report, U.S. State Department, June 2008

105. In its 2008 report on trafficking, the U.S. State Department noted that:

“Cyprus is a destination country for a large number of women trafficked from the Philippines, Russia,
Moldova, Hungary, Ukraine, Greece, Vietnam, Uzbekistan, and the Dominican Republic for the purpose of
commercial sexual exploitation ... Most victims of trafficking are fraudulently recruited to Cyprus on threemonth 'artiste' work permits to work in the cabaret industry or on tourist visas to work in massage parlors
disguised as private apartments.”

106. The report found that Cyprus had failed to provide evidence that it had increased its efforts to combat severe
forms of trafficking in persons from the previous year.

107. The report recommended that the Cypriot Government:

“Follow through with plans to abolish, or greatly restrict use of the artiste work permit—a well-known
conduit for trafficking; establish standard operating procedures to protect and assist victims in its new
trafficking shelter; develop and launch a comprehensive demand reduction campaign specifically aimed at
clients and the larger public to reduce wide-spread misconceptions about trafficking and the cabaret
industry; dedicate more resources to its anti-trafficking unit; and improve the quality of trafficking
prosecutions to secure convictions and appropriate punishments for traffickers.”

_III. RELEVANT DOMESTIC LAW AND PRACTICE_

A. Cyprus
_1._ _Extracts of the Constitution_

108. Under the Cypriot Constitution the right to life and corporal integrity is protected by art 7.

109. Article 8 provides that no person shall be subjected to torture or to inhuman or degrading punishment or
treatment.

110. Article 9 guarantees that:

“Every person has the right to a decent existence and to social security. A law shall provide for the
protection of the workers, assistance to the poor and for a system of social insurance.”

111. Article 10 provides, in so far as relevant, that:

“1. No person shall be held in slavery or servitude.

2. No person shall be required to perform forced or compulsory labour ...”

112. Article 11(1) provides that every person has the right to liberty and security of person. Article 11(2) prohibits
deprivation of liberty except in cases permitted under Article 5(1) of the Convention and as provided by law.
_2. Applications for entrance, residence and work permits for artistes_

a. The procedure at the relevant time

113. In 2000, the Civil Registry and Migration Department defined “artiste” as:


-----

“any alien who wishes to enter Cyprus in order to work in a cabaret, musical-dancing place or other night
entertainment place and has attained the age of 18 years.”

114. Under art 20 of the Aliens and Immigration Law, Cap. 105, the Council of Ministers has jurisdiction to issue
regulations concerning entry requirements for aliens, monitoring the immigration and movements of aliens,
regulating warranties in respect of aliens holding permits and determining any relevant fees. Notwithstanding the
existence of these powers, at the material time the entry procedures for those entering Cyprus to work as cabaret
artistes were regulated by decisions or instructions of the Minister of Interior, immigration officers and the general
directors of the Ministry.

115. In line with a procedure introduced in 1987, applications for entry, temporary residence and work permits had
to be submitted by the prospective employer (the cabaret manager) and the artistic agent, accompanied by an
employment contract recording the exact terms agreed between the parties and photocopies of relevant pages of
the artiste's passport. Artistic agents were also required to deposit a bank letter guarantee in the sum of 10,000
Cypriot pounds (CYP) (approximately EUR 17,000) to cover possible repatriation expenses. Cabaret managers
were required to deposit a bank warranty in the sum of CYP 2,500 (approximately EUR 4,200) to cover a
repatriation for which the manager was responsible.

116. If all the conditions were fulfilled, an entry and temporary resident permit valid for five days was granted. Upon
arrival, the artiste was required to undergo various medical tests for AIDS and other infectious or contagious
diseases. Upon submission of satisfactory results, a temporary residence and work permit valid for three months
was granted. The permit could be renewed for a further three months. The number of artistes who could be
employed in a single cabaret was limited.

117. In an effort to prevent artistes from being forced to leave the cabaret with clients, artistes were required to be
present on the cabaret premises between 9 p.m. and 3 a.m., even if their own performance lasted for only one hour.
Absence due to illness had to be certified by a doctor's letter. Cabaret managers were required to advise the
Immigration Office if an artiste failed to show up for work or otherwise breached her contract. Failure to do so would
result in the artiste being expelled, with her repatriation expenses covered by the bank guarantee deposited by the
cabaret manager. If an artistic agent had been convicted of offences linked to prostitution, he would not be granted
entry permits for artistes.

b. Other relevant developments

118. In 1986, following reports of prostitution of artistes, the Police Director proposed establishing an _ad hoc_
committee responsible for assessing whether artistes seeking to enter Cyprus held the necessary qualifications for
the grant of an artiste visa. However, the measure was never implemented. A committee with a more limited remit
was set up but, over time, was gradually weakened.

119. Under the procedure introduced in 1987, an application for an entry permit had to be accompanied by
evidence of artistic competency. However, this measure was indefinitely suspended in December 1987 on the
instructions of the then General Director of the Ministry of the Interior.

120. In 1990, following concerns about the fact that artistic agents also owned or managed cabarets or owned the
accommodation in which their artistes resided, the Civil Registry and Immigration Department notified all artistic
agents that from 30 June 1990 cabaret owners were not permitted to work also as artistic agents. They were
requested to advise the authorities which of the two professions they intended to exercise. Further, the level of the
bank guarantees was increased, from CYP 10,000 to CYP 15,000 in respect of artistic agents and from CYP 2,500
to CYP 10,000 in respect of cabaret managers. However, these measures were never implemented following
objections from artistic agents and cabaret managers. The only change which was made was an increase in the
level of the bank guarantee by cabaret managers from CYP 2,500 to CYP 3,750 (approximately EUR 6,400).
_3. Law on inquests_


-----

121. The holding of inquests in Cyprus is governed by the Coroners Law of 1959, Cap. 153. Under section 3, every
district judge and magistrate may hold inquests within the local limits of his jurisdiction. Section 3(3) provides that
any inquest commenced by a coroner may be continued, resumed, or reopened in the manner provided by the Law.

122. Section 14 sets out the procedure at the inquest and provides as follows (all quotes to Cypriot legislation are
translated):

“At every inquest–

(a) the coroner shall take on oath such evidence as is procurable as to the identity of the deceased, and
the time, place and manner of his death;

(b) every interested party may appear either by advocate or in person and examine, cross-examine or reexamine, as the case may be, any witness.”

123. Section 16 governs the extent of the coroner's powers and provides that:

“(1) A coroner holding an inquest shall have and may exercise all the powers of a district judge or
magistrate with regard to summoning and compelling the attendance of witnesses and requiring them to
give evidence, and with regard to the production of any document or thing at such inquest.”

124. Under section 24, where the coroner is of the opinion that sufficient grounds are disclosed for making a charge
against any person in connection with the death, he may issue a summons or warrant to secure the attendance of
such person before any court having jurisdiction.

125. Section 25 provides that following the hearing of evidence, the coroner shall give his verdict and certify it in
writing, showing, so far as such particulars have been proved to him, who the deceased was, and how, when and
where the deceased came by his death. Under section 26, if at the close of the inquest the coroner is of the opinion
that there are grounds for suspecting that some person is guilty of an offence in respect of the matter inquired into,
but cannot ascertain who such person is, he shall certify his opinion to that effect and transmit a copy of the
proceedings to the police officer in charge of the district in which the inquest is held.

126. Section 30 allows the President of the District Court, upon the application of the Attorney-General, to order the
holding, re-opening or quashing of an inquest or verdict. It provides that:

“(1) Where the President, District Court, upon application made by or under the authority of the AttorneyGeneral, is satisfied that it is necessary or desirable to do so, he may–

(a) order an inquest to be held touching the death of any person;

(b) direct any inquest to be reopened for the taking of further evidence, or for the inclusion in the
proceedings thereof and consideration with the evidence already taken, of any evidence taken in any
judicial proceedings which may be relevant to any issue determinable at such inquest, and the recording of
a fresh verdict upon the proceedings as a whole;

(c) quash the verdict in any inquest substituting therefor some other verdict which appears to be lawful and
in accordance with the evidence recorded or included as hereinbefore in this section provided; or

(d) quash any inquest, with or without ordering a new inquest to be held.”

_4. Trafficking in human beings_

127. Legislation on human trafficking was introduced in Cyprus under Law No. 3(1) of 2000 on the Combating of
Trafficking in Persons and Sexual Exploitation of Children. Section 3(1) prohibits:

“a. The sexual exploitation of adult persons for profit if:

i. it is done by the use of force, violence or threats; or

ii. there is fraud; or


-----

iii. it is done through abuse of power or other kind of pressure to such an extent so that the particular
person would have no substantial and reasonable choice but to succumb to pressure or ill-treatment;

b. the trafficking of adult persons for profit and for sexual exploitation purposes in the circumstances
referred to in subsection (a) above;

c. the sexual exploitation or the ill-treatment of minors;

d. the trafficking of minors for the purpose of their sexual exploitation or ill-treatment.”

128. Section 6 provides that the consent of the victim is not a defence to the offence of trafficking.

129. Under section 5(1), persons found guilty of trafficking adults for the purposes of sexual exploitation may be
imprisoned for up to ten years or fined CYP 10,000, or both. In the case of a child, the potential prison sentence is
increased to fifteen years and the fine to CYP 15,000. Section 3(2) provides for a greater penalty in certain cases:

“For the purposes of this section, blood relationship or relationship by affinity up to the third degree with the
victim and any other relation of the victim with the person, who by reason of his position exercises
influence and authority over the victim and includes relations with guardian, educators, hostel
administration, rehabilitation home, prisons or other similar institutions and other persons holding similar
position or capacity that constitutes abuse of power or other kind of coercion:

a. a person acting contrary to the provisions of section 1(a) and (b) commits an offence and upon
conviction is liable to imprisonment for fifteen years;

b. a person acting contrary to the provisions of section 1(c) and (d) commits an offence and upon
conviction is liable to imprisonment for twenty years.”

130. Section 7 imposes a duty on the State to protect victims of trafficking by providing them with support, including
accommodation, medical care and psychiatric support.

131. Under sections 10 and 11, the Council of Ministers may appoint a “guardian of victims” to advise, counsel, and
guide victims of exploitation; to hear and investigate complaints of exploitation; to provide victims with treatment and
safe residence; to take the necessary steps to prosecute offenders; to take measures aimed at rehabilitating, reemploying or repatriating victims; and to identify any deficiencies in the law to combat trafficking. Although a
custodian was appointed, at the time of the Cypriot Ombudsman's 2003 Report (see paras 80 to 90 above), the role
remained theoretical and no programme to ensure protection of victims had been prepared.

B. Russia
_1. Jurisdiction under the Russian Criminal Code_

132. Articles 11 and 12 of the Criminal Code of the Russian Federation set out the territorial application of Russian
criminal law. Article 11 establishes Russian jurisdiction over crimes committed in the territory of the Russian
Federation. Article 12(3) provides for limited jurisdiction in respect of non-Russian nationals who commit crimes
outside Russian territory where the crimes run counter to the interests of the Russian Federation and in cases
provided for by international agreement.
_2. General offences under the Criminal Code_

133. Article 105 of the Russian Criminal Code provides that murder shall be punishable with a prison term.

134. Article 125 of the Russian Criminal Code provides that deliberate abandonment and failure to provide
assistance to a person in danger is punishable by a fine, community service, corrective labour or a prison term.

135. Articles 126 and 127 make abduction and illegal deprivation of liberty punishable by prison terms.
_3. Trafficking in human beings_

136. In December 2003, an amendment was made to the Russian Criminal Code by the insertion of a new art 127.1
in the following terms:


-----

“1. Human beings' trafficking, that is, a human being's purchase and sale or his recruiting, transportation,
transfer, harbouring or receiving for the purpose of his exploitation ... shall be punishable by deprivation of
liberty for a term of up to five years.

2. The same deed committed:

a) in respect of two or more persons;

...

d) moving the victim across the State Border of the Russian Federation or illegally keeping him abroad;

...

f) with application of force or with the threat of applying it;

...

shall be punishable by deprivation of liberty for a term from three to 10 years.

3. The deeds provided for by Parts One and Two of this Article:

a) which have entailed the victim's death by negligence, the infliction of major damage to the victim's health
or other grave consequences;

b) committed in a way posing danger to the life or health of many people;

c) committed by an organized group–

shall be punishable by deprivation of liberty for a term from eight to 15 years.”

_IV._ _RELEVANT INTERNATIONAL TREATIES AND OTHER MATERIALS_

A. Slavery
_1. Slavery Convention 1926_

137. The Slavery Convention, signed in Geneva in 1926, entered into force on 7 July 1955. Russia acceded to the
Slavery Convention on 8 August 1956 and Cyprus on 21 April 1986. In the recitals, the Contracting Parties stated
as follows:

“Desiring to ... find a means of giving practical effect throughout the world to such intentions as were
expressed in regard to slave trade and slavery by the signatories of the Convention of Saint-Germain-enLaye, and recognising that it is necessary to conclude to that end more detailed arrangements than are
contained in that Convention,

Considering, moreover, that it is necessary to prevent forced labour from developing into conditions
analogous to slavery ...”

138. Article 1 defines slavery as:

“the status or condition of a person over whom any or all of the powers attaching to the right of ownership
are exercised”.

139. Under art 2, the parties undertake to prevent and suppress the slave trade and to bring about, progressively
and as soon as possible, the complete abolition of slavery in all its forms.

140. Article 5 deals with forced or compulsory labour and provides, inter alia, that:

“The High Contracting Parties recognise that recourse to compulsory or forced labour may have grave
consequences and undertake, each in respect of the territories placed under its sovereignty, jurisdiction,
protection, suzerainty or tutelage, to take all necessary measures to prevent compulsory or forced labour
from developing into conditions analogous to slavery.”


-----

141. Article 6 requires States whose laws do not make adequate provision for the punishment of infractions of laws
enacted with a view to giving effect to the purposes of the Slavery Convention to adopt the necessary measures in
order that severe penalties can be imposed in respect of such infractions.
_2._ _Jurisprudence of the International Criminal Tribunal for the Former Yugoslavia_

142. In the first case to deal with the definition of enslavement as a crime against humanity for sexual exploitation,
_Prosecutor v Kunarac, Vukovic and Kovac, 12 June 2002, the International Criminal Tribunal for the Former_
Yugoslavia observed that:

“117. ...the traditional concept of slavery, as defined in the 1926 Slavery Convention and often referred to
as 'chattel slavery' has evolved to encompass various contemporary forms of slavery which are also based
on the exercise of any or all of the powers attaching to the right of ownership. In the case of these various
contemporary forms of slavery, the victim is not subject to the exercise of the more extreme rights of
ownership associated with 'chattel slavery', but in all cases, as a result of the exercise of any or all of the
powers attaching to the right of ownership, there is some destruction of the juridical personality; the
destruction is greater in the case of 'chattel slavery' but the difference is one of degree ...”

143. It concluded that:

“119. ... the question whether a particular phenomenon is a form of enslavement will depend on the
operation of the factors or indicia of enslavement [including] the 'control of someone's movement, control of
physical environment, psychological control, measures taken to prevent or deter escape, force, threat of
force or coercion, duration, assertion of exclusivity, subjection to cruel treatment and abuse, control of
sexuality and forced labour'. Consequently, it is not possible exhaustively to enumerate all of the
contemporary forms of slavery which are comprehended in the expansion of the original idea ...”

_3. The Rome Statute_

144. The Statute of the International Criminal Court (“the Rome Statute”), which entered into force on 1 July 2002,
provides that “enslavement” under art 7(1)(c) of the Rome Statute:

“means the exercise of any or all of the powers attaching to the right of ownership over a person and
includes the exercise of such power in the course of trafficking in persons, in particular women and
children.”

145. Cyprus signed the Rome Statute on 15 October 1998 and ratified it on 7 March 2002. Russia signed the
Statute on 13 September 2000. It has not ratified the Statute.

B. Trafficking
_1. Early trafficking agreements_

146. The first international instrument to address trafficking of persons, the International Agreement for the
Suppression of White Slave Traffic, was adopted in 1904. It was followed in 1910 by the International Convention
for the Suppression of White Slave Traffic. Subsequently, in 1921, the League of Nations adopted a Convention for
the Suppression of Trafficking in Women and Children, affirmed in the later International Convention for the
Suppression of Traffic in Women of Full Age of 1933. The 1949 Convention for the Suppression of Traffic in
Persons and of the Exploitation of the Prostitution of Others brought the former instruments under the auspices of
the United Nations.
_2._ _The Convention on the Elimination of All Forms of Discrimination Against Women_

147. The Convention on the Elimination of All Forms of Discrimination against Women (CEDAW) was adopted in
1979 by the UN General Assembly. Russia ratified CEDAW on 23 January 1981 and Cyprus acceded to it on 23
July 1985.

148. Article 6 CEDAW provides that:

“States Parties shall take all appropriate measures, including legislation, to suppress all forms of traffic in
women and exploitation of prostitution of women.”


-----

_3._ _The Palermo Protocol_

149. The Protocol to Prevent, Suppress and Punish Trafficking in Persons, especially Women and Children (“the
Palermo Protocol”), supplementing the United Nations Convention against Transnational Organised Crime 2000
was signed by Cyprus on 12 December 2000 and by Russia on 16 December 2000. It was ratified by them on 26
May 2004 and 6 August 2003 respectively. Its preamble notes:

“Declaring that effective action to prevent and combat trafficking in persons, especially women and
children, requires a comprehensive international approach in the countries of origin, transit and destination
that includes measures to prevent such trafficking, to punish the traffickers and to protect the victims of
such trafficking, including by protecting their internationally recognized human rights.”

150. Article 3(a) defines “trafficking in persons” as:

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position
of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person
having control over another person, for the purpose of exploitation. Exploitation shall include, at a
minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or
services, slavery or practices similar to slavery, servitude or the removal of organs.”

151. Article 3(b) provides that the consent of a victim of trafficking to the intended exploitation is irrelevant where
any of the means set out in Article 3(a) have been used.

152. Article 5 obliges States to:

“adopt such legislative and other measures as may be necessary to establish as criminal offences the
conduct set forth in article 3 of this Protocol, when committed intentionally.”

153. Assistance and protection for victims of trafficking is dealt with in art 6, which provides, in so far as relevant:

“2. Each State Party shall ensure that its domestic legal or administrative system contains measures that
provide to victims of trafficking in persons, in appropriate cases:

(a) Information on relevant court and administrative proceedings;

(b) Assistance to enable their views and concerns to be presented and considered at appropriate stages of
criminal proceedings against offenders, in a manner not prejudicial to the rights of the defence.

3. Each State Party shall consider implementing measures to provide for the physical, psychological and
social recovery of victims of trafficking in persons ...

...

5. Each State Party shall endeavour to provide for the physical safety of victims of trafficking in persons
while they are within its territory.

...”

154. Article 9, on the prevention of trafficking in persons, provides that:

“1. States Parties shall establish comprehensive policies, programmes and other measures:

(a) To prevent and combat trafficking in persons; and

(b) To protect victims of trafficking in persons, especially women and children, from revictimization.

2. States Parties shall endeavour to undertake measures such as research, information and mass media
campaigns and social and economic initiatives to prevent and combat trafficking in persons.


-----

3. Policies, programmes and other measures established in accordance with this article shall, as
appropriate, include cooperation with non-governmental organizations, other relevant organizations and
other elements of civil society.

4. States Parties shall take or strengthen measures, including through bilateral or multilateral cooperation,
to alleviate the factors that make persons, especially women and children, vulnerable to trafficking, such as
poverty, underdevelopment and lack of equal opportunity.

5. States Parties shall adopt or strengthen legislative or other measures, such as educational, social or
cultural measures, including through bilateral and multilateral cooperation, to discourage the demand that
fosters all forms of exploitation of persons, especially women and children, that leads to trafficking.”

155. Article 10 emphasises the need for effective exchange of information between relevant authorities and training
of law enforcement and immigration officials. It provides, in so far as relevant:

“1. Law enforcement, immigration or other relevant authorities of States Parties shall, as appropriate,
cooperate with one another by exchanging information, in accordance with their domestic law, to enable
them to determine:

...

(c) The means and methods used by organized criminal groups for the purpose of trafficking in persons,
including the recruitment and transportation of victims, routes and links between and among individuals
and groups engaged in such trafficking, and possible measures for detecting them.

2. States Parties shall provide or strengthen training for law enforcement, immigration and other relevant
officials in the prevention of trafficking in persons. The training should focus on methods used in preventing
such trafficking, prosecuting the traffickers and protecting the rights of the victims, including protecting the
victims from the traffickers. The training should also take into account the need to consider human rights
and child- and gender-sensitive issues and it should encourage cooperation with non-governmental
organizations, other relevant organizations and other elements of civil society.

...”

_4. European Union action to combat trafficking_

156. The Council of the European Union has adopted a Framework Decision on combating trafficking in human
beings (Framework Decision 2002/JHA/629 of 19 July 2002). It provides for measures aimed at ensuring
approximation of the criminal law of the Member States as regards the definition of offences, penalties, jurisdiction
and prosecution, protection and assistance to victims.

157. In 2005, the Council adopted an action plan on best practices, standards and procedures for combating and
preventing trafficking in human beings (OJ C 311/1 of 9.12.2005). The action plan proposes steps to be taken by
Member States, by the Commission and by other EU bodies involving coordination of EU action, scoping the
problem, preventing trafficking, reducing demand, investigating and prosecuting trafficking, protecting and
supporting victims of trafficking, returns and reintegration and external relations.
_5. Council of Europe general action on trafficking_

158. In recent years, the Committee of Ministers of the Council of Europe has adopted three legal texts addressing
trafficking in human beings for sexual exploitation: Recommendation No. R (2000) 11 of the Committee of Ministers
to member states on action against trafficking in human beings for the purpose of sexual exploitation;
Recommendation Rec (2001) 16 of the Committee of Ministers to member states on the protection of children
against sexual exploitation; and Recommendation Rec (2002) 5 of the Committee of Ministers to member states on
the protection of women against violence. These texts propose, inter alia, a pan-European strategy encompassing
definitions, general measures, a methodological and action framework, prevention, victim assistance and
protection, criminal measures, judicial cooperation and arrangements for international cooperation and coordination.

159. The Parliamentary Assembly of the Council of Europe has also adopted a number of texts in this area,
including: Recommendation 1325 (1997) on traffic in women and forced prostitution in Council of Europe member


-----

States; Recommendation 1450 (2000) on violence against women in Europe; Recommendation 1523 (2001) on
domestic slavery; Recommendation 1526 (2001) on the campaign against trafficking in minors to put a stop to the
east European route: the example of Moldova; Recommendation 1545 (2002) on the campaign against trafficking in
women; Recommendation 1610 (2003) on migration connected with trafficking in women and prostitution; and
Recommendation 1663 (2004) on domestic slavery: servitude, au pairs and “mail-order brides”.
_6_ _The Council of Europe Convention on Action against Trafficking in Human Beings, CETS No. 197, 16 May 2005_

160. The Council of Europe Convention on Action against Trafficking in Human Beings (“the Anti-Trafficking
Convention”) was signed by Cyprus on 16 May 2005 and ratified on 24 October 2007. It entered into force in
respect of Cyprus on 1 February 2008. Russia has yet to sign the Convention. A total of 41 member States of the
Council of Europe have signed the Anti-Trafficking Convention and 26 have also ratified it.

161. The explanatory report accompanying the Anti-Trafficking Convention emphasises that trafficking in human
beings is a major problem in Europe today which threatens the human rights and fundamental values of democratic
societies. The report continues as follows:

“Trafficking in human beings, with the entrapment of its victims, is the modern form of the old worldwide
slave trade. It treats human beings as a commodity to be bought and sold, and to be put to forced labour,
usually in the sex industry but also, for example, in the agricultural sector, declared or undeclared
sweatshops, for a pittance or nothing at all. Most identified victims of trafficking are women but men also
are sometimes victims of trafficking in human beings. Furthermore, many of the victims are young,
sometimes children. All are desperate to make a meagre living, only to have their lives ruined by
exploitation and rapacity.

To be effective, a strategy for combating trafficking in human beings must adopt a multi-disciplinary
approach incorporating prevention, protection of human rights of victims and prosecution of traffickers,
while at the same time seeking to harmonise relevant national laws and ensure that these laws are applied
uniformly and effectively.”

162. In its preamble, the Anti-Trafficking Convention asserts, inter alia, that:

“Considering that trafficking in human beings constitutes a violation of human rights and an offence to the
dignity and the integrity of the human being;

Considering that trafficking in human beings may result in slavery for victims;

Considering that respect for victims' rights, protection of victims and action to combat trafficking in human
beings must be the paramount objectives ...”

163. Article 1 provides that the purposes of the Anti-Trafficking Convention are to prevent and combat trafficking in
human beings, to protect the human rights of the victims of trafficking, to design a comprehensive framework for the
protection and assistance of victims and witnesses and to ensure effective investigation and prosecution of
trafficking.

164. Article 4(a) adopts the Palermo Protocol definition of trafficking and Article 4(b) replicates the provision in the
Palermo Protocol on the irrelevance of the consent of a victim of trafficking to the exploitation (see paras 150 to 151
above).

165. Article 5 requires States to take measures to prevent trafficking and provides, inter alia, as follows:

“1. Each Party shall take measures to establish or strengthen national co-ordination between the various
bodies responsible for preventing and combating trafficking in human beings.

2. Each Party shall establish and/or strengthen effective policies and programmes to prevent trafficking in
human beings, by such means as: research, information, awareness raising and education campaigns,
social and economic initiatives and training programmes, in particular for persons vulnerable to trafficking
and for professionals concerned with trafficking in human beings ...”


-----

166. Article 6 requires States to take measures to discourage the demand that fosters trafficking and provides, in so
far as relevant, as follows:

“To discourage the demand that fosters all forms of exploitation of persons, especially women and children,
that leads to trafficking, each Party shall adopt or strengthen legislative, administrative, educational, social,
cultural or other measures including:

a. research on best practices, methods and strategies;

b. raising awareness of the responsibility and important role of media and civil society in identifying the
demand as one of the root causes of trafficking in human beings;

c. target information campaigns involving, as appropriate, inter alia, public authorities and policy makers;

...”

167. Article 10 sets out measures regarding training and cooperation and provides that:

“1. Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims ...

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in art 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in art
12, paras 1 and 2 ...”

168. Article 12 provides that:

1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery....

2. Each Party shall take due account of the victim's safety and protection needs ...”

169. Articles 18 to 21 require States to criminalise specified types of conduct:

“18. Each Party shall adopt such legislative and other measures as may be necessary to establish as
criminal offences the conduct contained in article 4 of this Convention, when committed intentionally.

19. Each Party shall consider adopting such legislative and other measures as may be necessary to
establish as criminal offences under its internal law, the use of services which are the object of exploitation
as referred to in Article 4 paragraph a of this Convention, with the knowledge that the person is a victim of
trafficking in human beings.

20. Each Party shall adopt such legislative and other measures as may be necessary to establish as
criminal offences the following conducts, when committed intentionally and for the purpose of enabling the
trafficking in human beings:

a. forging a travel or identity document;

b. procuring or providing such a document;

c. retaining, removing, concealing, damaging or destroying a travel or identity document of another person.

21(1). Each Party shall adopt such legislative and other measures as may be necessary to establish as
criminal offences when committed intentionally, aiding or abetting the commission of any of the offences
established in accordance with Articles 18 and 20 of the present Convention.


-----

(2). Each Party shall adopt such legislative and other measures as may be necessary to establish as
criminal offences when committed intentionally, an attempt to commit the offences established in
accordance with Articles 18 and 20, paragraph a, of this Convention.”

170. Article 23 requires States to adopt such legislative and other measures as may be necessary to ensure that
the criminal offences established in accordance with arts 18 to 21 are punishable by effective, proportionate and
dissuasive sanctions. For criminal offences established in accordance with art 18, such sanctions are to include
penalties involving deprivation of liberty which can give rise to extradition.

171. Article 27 provides that States must ensure that investigations into and prosecution of offences under the AntiTrafficking Convention are not dependent on a report or accusation made by a victim, at least when the offence was
committed in whole or in part on its territory. States must further ensure that victims of an offence in the territory of a
State other than their State of residence may make a complaint before the competent authorities of their State of
residence. The latter State must transmit the complaint without delay to the competent authority of the State in the
territory in which the offence was committed, where the complaint must be dealt with in accordance with the internal
law of the State in which the offence was committed.

172. Article 31(1) deals with jurisdiction, and requires States to adopt such legislative and other measures as may
be necessary to establish jurisdiction over any offence established in accordance with the Anti-Trafficking
Convention when the offence is committed:

“a. in its territory; or ...

d. by one of its nationals or by a stateless person who has his or her habitual residence in its territory, if the
offence is punishable under criminal law where it was committed or if the offence is committed outside the
territorial jurisdiction of any State;

e. against one of its nationals.”

173. States may reserve the right not to apply, or to apply only in specific cases or conditions, the jurisdiction rules
in art 31(1)(d) and (e).

174. Article 32 requires States to co-operate with each other, in accordance with the provisions of the Convention,
and through application of relevant applicable international and regional instruments, to the widest extent possible,
for the purpose of:

“– preventing and combating trafficking in human beings;

– protecting and providing assistance to victims;

– investigations or proceedings concerning criminal offences established in accordance with this
Convention.”

C. Mutual legal assistance
_1._ _European Convention on Mutual Assistance in Criminal Matters, CETS No. 30, 20 May 1959 (“Mutual_
_Assistance Convention”)_

175. The Mutual Assistance Convention was signed by Cyprus on 27 March 1996. It was ratified on 24 February
2000 and entered into force on 24 May 2000. The Russian Federation signed the Convention on 7 November 1996
and ratified it on 10 December 1999. It entered into force in respect of Russia on 9 March 2000.

176. Article 1 establishes an obligation on contracting parties to:

“afford each other, in accordance with the provisions of this Convention, the widest measure of mutual
assistance in proceedings in respect of offences the punishment of which, at the time of the request for
assistance, falls within the jurisdiction of the judicial authorities of the requesting Party”.

177. Article 3 provides that:


-----

“1. The requested Party shall execute in the manner provided for by its law any letters rogatory relating to a
criminal matter and addressed to it by the judicial authorities of the requesting Party for the purpose of
procuring evidence or transmitting articles to be produced in evidence, records or documents.

2. If the requesting Party desires witnesses or experts to give evidence on oath, it shall expressly so
request, and the requested Party shall comply with the request if the law of its country does not prohibit it.”

178. Article 26 allows States to enter into bilateral agreements on mutual legal assistance to supplement the
provisions of the Mutual Assistance Convention.
_2._ _Treaty between the USSR and the Republic of Cyprus on Legal Assistance in civil, family and criminal law_
_matters of 19 January 1984 (“Legal Assistance Treaty”)_

179. Article 2 of the Legal Assistance Treaty (ratified by Russia following the dissolution of the USSR) establishes a
general obligation for both parties to provide each other with legal assistance in civil and criminal matters in
accordance with the provisions of the Treaty.

180. Article 3 sets out the extent of the legal assistance required under the Treaty and provides as follows:

“Legal assistance in civil and criminal matters shall include service and sending of documents, supply of
information on the law in force and the judicial practice and performance of specific procedural acts
provided by the law of the requested Contracting Party and in particular the taking of evidence from
litigants, accused persons, defendants, witnesses and experts as well as recognition and enforcement of
judgments in civil matters, institution of criminal prosecutions and extradition of offenders.”

181. The procedure for making a request is detailed in art 5(1), which provides, in so far as relevant, that:

“A request for legal assistance shall be in writing and shall contain the following:
(1) The designation of the requesting authority.

(2) The designation of the requested authority.

(3) The specification of the case in relation to which legal assistance is requested and the content of the
request.

(4) Names and surnames of the persons to whom the request relates, their citizenship, occupation and
permanent or temporary residence.

...

(6) If necessary, the facts to be elucidated as well as the list of the required documents and any other
evidence.

(7) In criminal matters, in addition to the above, particulars of the offence and its legal definition.

182. Article 6 sets out the procedure for executing a request:

“1. The requested authority shall provide legal assistance in the manner provided by the procedural laws
and rules of its own State. However, it may execute the request in a manner specified therein if not in
conflict with the law of its own State.

2. If the requested authority is not competent to execute the request for legal assistance it shall forward the
request to the competent authority and shall advise the requesting authority accordingly.

3. The requested authority shall, upon request, in due time notify the requesting authority of the place and
time of the execution of the request.

4. The requested authority shall notify the requesting authority in writing of the execution of the request. If
the request cannot be executed the requested authority shall forthwith notify in writing the requesting
authority giving the reasons for failure to execute it and shall return the documents.”


-----

183. Under art 18 Contracting Parties are obliged to ensure that citizens of one State are exempted in the territory
of the other State from payment of fees and costs and are afforded facilities and free legal assistance under the
same conditions and to the same extent as citizens of the other State. Article 20 provides that a person requesting
free legal assistance may submit a relevant application to the competent authority of the State in the territory of
which he has his permanent or temporary residence. This authority will then transmit the application to the other
State.

184. Chapter VI of the Treaty contains special provisions on criminal matters concerning, in particular, the institution
of criminal proceedings. Article 35(1) provides that:

“Each Contracting Party shall institute, at the request of the other Contracting Party, in accordance with
and subject to the provisions of its own law, criminal proceedings against its own citizens who are alleged
to have committed an offence in the territory of the other Contracting Party.

185. Article 36 sets out the procedure for the making of a request to institute criminal proceedings:

“1. A request for institution of criminal proceedings shall be made in writing and contain the following:
(1) The designation of the requesting authority.

(2) The description of the acts constituting the offence in connection with which the institution of criminal
proceedings is requested.

(3) The time and place of the committed act as precisely as possible.

(4) The text of the law of the requesting Contracting Party under which the act is defined as an offence.

(5) The name and surname of the suspected person, particulars regarding his citizenship, permanent or
temporary residence and other information concerning him as well as, if possible, the description of the
person's appearance, his photograph and fingerprints.

(6) Complaints, if any, by the victim of the criminal offence including any claim for damages.

(7) Available information on the extent of the material damage resulting from the offence.”

_V. THE CYPRIOT GOVERNMENT'S UNILATERAL DECLARATION_

186. By letter of 10 April 2009 the Attorney-General of the Republic of Cyprus advised the Court as follows:

“Please note that the Government wishes to make a unilateral declaration with a view to resolving the
issues raised by the application. By the Unilateral Declaration the Government requests the Court to strike
out the application in accordance with Article 37 of the Convention. ”

187. The relevant parts of the appended a unilateral declaration read as follows:

“... (a) The Government regrets the decision taken by the police officers on 28 March 2001 not to release
the applicant's daughter but to hand her over to [M.A.], from whom she sought to escape. The Government
acknowledges that the above decision violated its positive obligation towards the applicant and his
daughter arising from Article 2 of the Convention to take preventive measures to protect the applicant's
daughter from the criminal acts of another individual.

(b) The Government acknowledges that the police investigation in the present case was ineffective as to
whether the applicant's daughter was subjected to inhuman or degrading treatment prior to her death. As
such the Government acknowledges that it violated the procedural obligation of Article 3 of the Convention
in respect of the failure to carry out an adequate and effective investigation as to whether the applicant's
daughter was subjected to inhuman or degrading treatment prior to her death.

(c) The Government acknowledges that it violated its positive obligations towards the applicant and his
daughter arising out of Article 4 of the Convention in that it did not take any measures to ascertain whether
the applicant's daughter had been a victim of trafficking in human beings and/or been subjected to sexual
or any other kind of exploitation.


-----

(d) The Government acknowledges that the treatment of applicant's daughter at the police station on 28
March 2001 in deciding not to release her but to hand her over to [M.A.] although there was not any basis
for her deprivation of liberty, was not consistent with Article 5(1) of the Convention.

(e) The Government acknowledges that it violated the applicant's right to an effective access to court in
failing to establish any real and effective communication between its organs (i.e. the Ministry of Justice and
Public Order and the police) and the applicant, regarding the inquest proceedings and any other possible
legal remedies that the applicant could resort to.

3. In regard to the above issues, the Government recalls that the Council of Ministers has followed the
advice of the Attorney General – Government Agent, and has thus appointed on 5 February 2009 three
independent criminal investigators whose mandate is to investigate:

(a) The circumstances of death of applicant's daughter and into any criminal responsibility by any person,
authority of the Republic, or member of the police concerning her death,

(b) the circumstances concerning her employment and stay in Cyprus in conjunction with the possibility of
her subjection to inhuman or degrading treatment or punishment and/or trafficking and/or sexual or other
exploitation, (by members of the police, authorities of the Republic or third persons) contrary to relevant
laws of the Republic applicable at the material time, and

(c) into the commission of any other unlawful act against her, (by members of the police, authorities of the
Republic or third persons) contrary to relevant laws of the Republic applicable at the material time.

4. The Government recalls that the investigators are independent from the police (the first investigator is
the President of the Independent Authority for the Investigation of Allegations and Complaints Against the
Police, the second is a Member of the said Authority, and the third is a practicing advocate with experience
in criminal law). The Government recalls that the investigators have already commenced their
investigation.

5. In these circumstances and having regard to the particular facts of the case the Government is prepared
to pay the applicant a global amount of 37,300 (thirty seven thousand and three hundred) EUR (covering
pecuniary and non pecuniary damage and costs and expenses). In its view, this amount would constitute
adequate redress and sufficient compensation for the impugned violations, and thus an acceptable sum as
to quantum in the present case. If, the Court however considers that the above amount does not constitute
adequate redress and sufficient compensation, the Government is ready to pay the applicant by way of just
satisfaction such other amount of compensation as is suggested by the Court ...”

**THE LAWI. APPLICATION OF ARTILCE 37(1) OF THE CONVENTION**

188. Article 37(1) of the Convention allows the Court to strike an application out of its list of cases and provides, in
so far as relevant, as follows:

“1. The Court may at any stage of the proceedings decide to strike an application out of its list of cases
where the circumstances lead to the conclusion that ...

(b) the matter has been resolved; or

(c) for any other reason established by the Court, it is no longer justified to continue the examination of the
application.

However, the Court shall continue the examination of the application if respect for human rights as defined
in the Convention and the Protocols thereto so requires ...”

A. Submissions to the Court
_1. The Cypriot Government_

189. The Cypriot Government submitted that where efforts with a view to securing a friendly settlement of the case
had been unsuccessful, the Court could strike an application out of the list on the basis of a unilateral declaration on
the ground that there existed “'any other reason”, as referred to in art 37(1) (c) of the Convention, justifying a
d i i b th C t t di ti th i ti f th li ti O th b i f th t t f th il t l


-----

declaration and the ongoing domestic investigation into the circumstances of Ms Rantseva's death (see para 187
above), the Cypriot Government considered that the requirements of art 37(1) (c) were fully met.
_2. The applicant_

190. The applicant requested the Court to reject the request of the Cypriot Government to strike the application out
of the list of cases on the basis of the unilateral declaration. He argued that the proposals contained in the
declaration did not guarantee that the responsible persons would be punished; that the declaration did not contain
any general measures to prevent similar violations from taking place in the future, even though trafficking for sexual
exploitation was a recognised problem in Cyprus; and that if the Court declined to deliver a judgment in the present
case, the Committee of Ministers would be unable to supervise the terms proposed by the Cypriot Government.
_3. Third party submissions by the AIRE Centre_

191. The AIRE Centre submitted that the extent of human trafficking in Council of Europe member States and the
present inadequate response of States to the problem meant that respect for human rights as defined in the
Convention required continued examination of cases that raised trafficking issues where they might otherwise be
struck out of the list in accordance with art 37(1).

192. In its submissions, the AIRE Centre referred to the factors taken into consideration by the Court when taking a
decision under art 37(1) as to whether a case merits continued examination, highlighting that one such factor was
“whether the issues raised are comparable to issues already determined by the Court in previous cases”. The AIRE
Centre highlighted the uncertainty surrounding the extent of member States' obligations to protect victims of
trafficking, in particular as regards protection measures not directly related to the investigation and prosecution of
criminal acts of trafficking and exploitation.

B. The Court's assessment
_1. General principles_

193. The Court observes at the outset that the unilateral declaration relates to the Republic of Cyprus only. No
unilateral declaration has been submitted by the Russian Federation. Accordingly, the Court will consider whether it
is justified to strike out the application in respect of complaints directed towards the Cypriot authorities only.

194. The Court recalls that it may be appropriate in certain circumstances to strike out an application, or part
thereof, under art 37(1) on the basis of a unilateral declaration by the respondent Government even where the
applicant wishes the examination of the case to be continued. Whether this is appropriate in a particular case
depends on whether the unilateral declaration offers a sufficient basis for finding that respect for human rights as
defined in the Convention does not require the Court to continue its examination of the case (art 37(1) in fine; see
[also, inter alia, Tahsin Acar v Turkey (preliminary objection) [2003] ECHR 26307/95, para 75; and Radoszewska-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X09P-00000-00&context=1519360)
_Zakościelna v Poland_ _[[2009] ECHR 858/08, para 50, 20 October 2009).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3M3-00000-00&context=1519360)_

195. Relevant factors in this respect include the nature of the complaints made, whether the issues raised are
comparable to issues already determined by the Court in previous cases, the nature and scope of any measures
taken by the respondent Government in the context of the execution of judgments delivered by the Court in any
such previous cases, and the impact of these measures on the case at issue. It may also be material whether the
facts are in dispute between the parties, and, if so, to what extent, and what prima facie evidentiary value is to be
attributed to the parties' submissions on the facts. Other relevant factors may include whether in their unilateral
declaration the respondent Government have made any admissions in relation to the alleged violations of the
Convention and, if so, the scope of such admissions and the manner in which the Government intend to provide
redress to the applicant. As to the last-mentioned point, in cases in which it is possible to eliminate the effects of an
alleged violation and the respondent Government declare their readiness to do so, the intended redress is more
likely to be regarded as appropriate for the purposes of striking out the application, the Court, as always, retaining
its power to restore the application to its list as provided in art 37(2) of the Convention and Rule 44(5) of the Rules
of Court (see Tahsin Acar, cited above, para 76).


-----

196. The foregoing factors are not intended to constitute an exhaustive list of relevant factors. Depending on the
particular facts of each case, it is conceivable that further considerations may come into play in the assessment of a
unilateral declaration for the purposes of art 37(1) of the Convention (see Tahsin Acar, cited above, para 77).

197. Finally, the Court reiterates that its judgments serve not only to decide those cases brought before it but, more
generally, to elucidate, safeguard and develop the rules instituted by the Convention, thereby contributing to the
observance by the States of the engagements undertaken by them as Contracting Parties (see Ireland v UK _[[1978]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X27J-00000-00&context=1519360)_
_[ECHR 5310/71, para 154;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X27J-00000-00&context=1519360)_ _Guzzardi v Italy_ _[[1980] ECHR 7367/76, para 86; and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1B4-00000-00&context=1519360)_ _Karner v Austria_ _[[2003] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X48G-00000-00&context=1519360)_
_[40016/98, para 26). Although the primary purpose of the Convention system is to provide individual relief, its](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X48G-00000-00&context=1519360)_
mission is also to determine issues on public-policy grounds in the common interest, thereby raising the general
standards of protection of human rights and extending human rights jurisprudence throughout the community of the
Convention States (see _Karner, cited above, para 26; and_ _Capital Bank AD v Bulgaria_ _[[2005] ECHR 49429/99,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3SW-00000-00&context=1519360)_
paras 78 to 79 (extracts)).
_2. Application of the general principles to the present case_

198. In considering whether it would be appropriate to strike out the present application in so far as it concerns
complaints directed against the Republic of Cyprus on the basis of the Cypriot unilateral declaration, the Court
makes the following observations.

199. First, the Court emphasises the serious nature of the allegations of trafficking in human beings made in the
present case, which raise issues under arts 2, 3, 4 and 5 of the Convention. In this regard, it is noted that
awareness of the problem of trafficking of human beings and the need to take action to combat it has grown in
recent years, as demonstrated by the adoption of measures at international level as well as the introduction of
relevant domestic legislation in a number of States (see also paras 264 and 269 below). The reports of the Council
of Europe's Commissioner for Human Rights and the report of the Cypriot Ombudsman highlight the acute nature of
the problem in Cyprus, where it is widely acknowledged that trafficking and sexual exploitation of cabaret artistes is
of particular concern (see paras 83, 89, 91, 94, 100 to 101 and 103 above).

200. Second, the Court draws attention to the paucity of case-law on the interpretation and application of art 4 of
the Convention in the context of trafficking cases. It is particularly significant that the Court has yet to rule on
whether, and if so to what extent, art 4 requires member States to take positive steps to protect potential victims of
trafficking outside the framework of criminal investigations and prosecutions.

201. The Cypriot Government have admitted that violations of the Convention occurred in the period leading up to
and following Ms Rantseva's death. They have taken additional recent steps to investigate the circumstances of Ms
Rantseva's death and have proposed a sum in respect of just satisfaction. However, in light of the Court's duty to
elucidate, safeguard and develop the rules instituted by the Convention, this is insufficient to allow the Court to
conclude that it is no longer justified to continue the examination of the application. In view of the observations
outlined above, there is a need for continued examination of cases which raise trafficking issues.

202. In conclusion, the Court finds that respect for human rights as defined in the Convention requires the
continuation of the examination of the case. Accordingly, it rejects the Cypriot Government's request to strike the
application out under art 37(1) of the Convention.
_II._ _THE ADMISSIBILITY OF THE COMPLAINTS UNDER ARTICLES 2, 3, 4 AND 5 OF THE CONVENTION_

A. The Russian Government's objection ratione loci
_1. The parties' submissions_

203. The Russian Government argued that the events forming the basis of the application having taken place
outside its territory, the application was inadmissible ratione loci in so far as it was directed against the Russian
Federation. They submitted that they had no “actual authority” over the territory of the Republic of Cyprus and that
the actions of the Russian Federation were limited by the sovereignty of the Republic of Cyprus.


-----

204. The applicant rejected this submission. He argued that in accordance with the Court's judgment in _Drozd v_
_France and Spain_ _[[1992] ECHR 12747/87, the Russian Federation could be held responsible where acts and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X200-00000-00&context=1519360)_
omissions of its authorities produced effects outside its own territory.
_2. The Court's assessment_

205. Article 1 of the Convention provides that:

“The High Contracting Parties shall secure to everyone within their jurisdiction the rights and freedoms
defined in Section I of [the] Convention.”

206. As the Court has previously emphasised, from the standpoint of public international law, the jurisdictional
competence of a State is primarily territorial. Accordingly, a State's competence to exercise jurisdiction over its own
nationals abroad is subordinate to the other State's territorial competence and a State may not generally exercise
jurisdiction on the territory of another State without the latter's consent, invitation or acquiescence. Article 1 of the
Convention must be considered to reflect this ordinary and essentially territorial notion of jurisdiction (see Banković
_v Belgium and 16 Other Contracting States [2001] ECHR 52207/99, paras 59-61)._

207. The applicant's complaints against Russia in the present case concern the latter's alleged failure to take the
necessary measures to protect Ms Rantseva from the risk of trafficking and exploitation and to conduct an
investigation into the circumstances of her arrival in Cyprus, her employment there and her subsequent death. The
Court observes that such complaints are not predicated on the assertion that Russia was responsible for acts
committed in Cyprus or by the Cypriot authorities. In light of the fact that the alleged trafficking commenced in
Russia and in view of the obligations undertaken by Russia to combat trafficking, it is not outside the Court's
competence to examine whether Russia complied with any obligation it may have had to take measures within the
limits of its own jurisdiction and powers to protect Ms Rantseva from trafficking and to investigate the possibility that
she had been trafficked. Similarly, the applicant's art 2 complaint against the Russian authorities concerns their
failure to take investigative measures, including securing evidence from witnesses resident in Russia. It is for the
Court to assess in its examination of the merits of the applicant's art 2 complaint the extent of any procedural
obligation incumbent on the Russian authorities and whether any such obligation was discharged in the
circumstances of the present case.

208. In conclusion, the Court is competent to examine the extent to which Russia could have taken steps within the
limits of its own territorial sovereignty to protect the applicant's daughter from trafficking, to investigate allegations of
trafficking and to investigate the circumstances leading to her death. Whether the matters complained of give rise to
State responsibility in the circumstances of the present case is a question which falls to be determined by the Court
in its examination of the merits of the application below.

B. The Russian Government's objection ratione materiae
_1. The parties' submissions_

209. The Russian Government argued that the complaint under art 4 of the Convention was inadmissible _ratione_
_materiae as there was no slavery, servitude or forced or compulsory labour in the present case. They pointed to the_
fact that Ms Rantseva had entered the Republic of Cyprus voluntarily, having voluntarily obtained a work permit to
allow her to work in accordance with an employment contract which she had concluded. There was no evidence
that Ms Rantseva had been in servitude and unable to change her condition or that she was forced to work. The
Russian Government further highlighted that Ms Rantseva had left, unimpeded, the apartment where she was
residing with the other cabaret artistes. They therefore contended that there were insufficient grounds to assert that
the cabaret artistes were being kept in the apartment against their will. The Russian Government added that the
fact that Ms Rantseva left the police station with M.A. was insufficient to support the conclusion that Ms Rantseva
was in servitude and forced to work. Had she feared for her life or safety, she could have informed the police
officers while she was at the police station.

210. The applicant insisted that the treatment to which Ms Rantseva had been subjected fell within the scope of art
4.
_2. The Court's assessment_


-----

211. The Court finds that the question whether the treatment about which the applicant complains falls within the
scope of art 4 is inextricably linked to the merits of this complaint. Accordingly, the Court holds that the objection
_ratione materiae should be joined to the merits._

C. Conclusion

212. The complaints under arts 2, 3, 4 and 5 cannot be rejected as incompatible ratione loci or ratione materiae with
the provisions of the Convention concerning Russia. The Court notes, in addition, that they are not manifestly illfounded within the meaning of art 35(3). It further notes they are not inadmissible on any other grounds. They must
therefore be declared admissible.
_III. ALLEGED VIOLATION OF ARTICLE 2 OF THE CONVENTION_

213. The applicant contended that there had been a violation of art 2 of the Convention by both the Russian and
Cypriot authorities on account of the failure of the Cypriot authorities to take steps to protect the life of his daughter
and the failure of the authorities of both States to conduct an effective investigation into her death. Article 2
provides, inter alia, that:

“1. Everyone's right to life shall be protected by law. No one shall be deprived of his life intentionally save in
the execution of a sentence of a court following his conviction of a crime for which this penalty is provided
by law.

....”

A. Alleged failure to take measures to protect against a risk to life
_1. Submissions of the parties_

a. The applicant

214. Relying on Osman v UK _[[1998] ECHR 23452/94, the applicant referred to the positive obligations arising under](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4JX-00000-00&context=1519360)_
art 2 which required States to take preventative operational measures to protect an individual whose life was at risk
from the criminal acts of another private individual where the State knew or ought to have known of a real and
immediate threat to life. The applicant argued that in failing to release Ms Rantseva and handing her over instead to
M.A., the Cypriot authorities had failed to take reasonable measures within their powers to avoid a real and
immediate threat to Ms Rantseva's life.

b. The Cypriot Government

215. The Cypriot Government did not dispute that art 2(1) imposed a positive obligation on the relevant authorities
to take preventative operational measures to protect an individual whose life was at risk from the criminal acts of
another individual. However, for such an obligation to arise, it had to be established that the authorities knew, or
ought to have known, of a real and immediate risk to the life of an identified individual and that they had failed to
take measures within the scope of their powers which, judged reasonably, might have been expected to avoid that
risk (citing Osman, above).

216. In their written submissions, the Cypriot Government argued that there was no failure to protect the life of the
applicant's daughter. On the information available to the police officers who had contact with Ms Rantseva on 28
March 2001, there was no reason to suspect a real or immediate risk to Ms Rantseva's life. The testimony of the
police officers revealed that Ms Rantseva was calmly applying her make-up and that the behaviour of M.A. towards
her appeared normal (see paras 20 and 49 above). Although Ms Rantseva had left her employment at the cabaret,
she had not submitted any complaint regarding her employer or the conditions of her work. She did not make a
complaint to the police officers while at the station and she did not refuse to leave with M.A.. The decision not to
release Ms Rantseva but to hand her over to M.A. did not violate any obligation incumbent on the Cypriot
authorities to protect her life.

217. In their subsequent unilateral declaration, the Cypriot Government acknowledged that the decision of the
police officers to hand Ms Rantseva over to M.A. was in violation of the positive obligation incumbent on Cyprus


-----

under art 2 to take preventative measures to protect Ms Rantseva from the criminal acts of another individual (see
para 187 above).
_2. The Court's assessment_

a. General principles

218. It is clear that art 2 enjoins the State not only to refrain from the intentional and unlawful taking of life but also
to take appropriate steps to safeguard the lives of those within its jurisdiction (see _LCB v UK_ _[[1998] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X55T-00000-00&context=1519360)_
_[23413/94, para 36; and Paul and Audrey Edwards, para 54). In the first place, this obligation requires the State to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X55T-00000-00&context=1519360)_
secure the right to life by putting in place effective criminal law provisions to deter the commission of offences
against the person backed up by law enforcement machinery for the prevention, suppression and punishment of
breaches of such provisions. However, it also implies, in appropriate circumstances, a positive obligation on the
authorities to take preventive operational measures to protect an individual whose life is at risk from the criminal
acts of another individual (see Osman, cited above, para 115; Medova v Russia _[[2009] ECHR 25385/04, para 95,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7R1-DYBP-X4YG-00000-00&context=1519360)_
15 January 2009; Opuz v Turkey _[[2009] ECHR 33401/02, para 128, 9 June 2009).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X04C-00000-00&context=1519360)_

219. The Court reiterates that the scope of any positive obligation must be interpreted in a way which does not
impose an impossible or disproportionate burden on the authorities, bearing in mind the difficulties in policing
modern societies, the unpredictability of human conduct and the operational choices which must be made in terms
of priorities and resources. Not every claimed risk to life can entail for the authorities a Convention requirement to
take operational measures to prevent that risk from materialising. For the Court to find a violation of the positive
obligation to protect life, it must be established that the authorities knew or ought to have known at the time of the
existence of a real and immediate risk to the life of an identified individual from the criminal acts of a third party and
that they failed to take measures within the scope of their powers which, judged reasonably, might have been
expected to avoid that risk (Osman, para 116; Paul and Audrey Edwards, para 55; and Medova, para 96).

b. Application of the general principles to the present case

220. The Court must examine whether the Cypriot authorities could have foreseen that in releasing Ms Rantseva
into the custody of M.A., her life would be at real and immediate risk.

221. The Court observes that in _Opuz, the responsibility of the State was engaged because the person who_
subsequently went on to shoot and kill the applicant's mother had previously made death threats and committed
acts of violence against the applicant and her mother, of which the authorities were aware (Opuz, cited above,
paras 133 to 136). Conversely, in Osman, the Court found that there was no violation of art 2 as the applicant had
failed to point to any stage in the sequence of events leading to the shooting of her husband where it could be said
that the police knew or ought to have known that the lives of the Osman family were at real and immediate risk
(Osman, cited above, para 121).

222. Although it is undisputed that victims of trafficking and exploitation are often forced to live and work in cruel
conditions and may suffer violence and ill-treatment at the hands of their employers (see paras 85, 87 to 88 and
101 above), in the absence of any specific indications in a particular case, the general risk of ill-treatment and
violence cannot constitute a real and immediate risk to life. In the present case, even if the police ought to have
been aware that Ms Rantseva might have been a victim of trafficking (a matter to be examined in the context of the
applicant's art 4 complaint, below), there were no indications during the time spent at the police station that Ms
Rantseva's life was at real and immediate risk. The Court considers that particular chain of events leading to Ms
Rantseva's death could not have been foreseeable to the police officers when they released her into M.A.'s
custody. Accordingly, the Court concludes that no obligation to take operational measures to prevent a risk to life
arose in the present case.

223. For the above reasons, the Court concludes that there has been no violation of the Cypriot authorities' positive
obligation to protect Ms Rantseva's right to life under art 2 of the Convention.

B. The procedural obligation to carry out an effective investigation
_1 Submissions of the parties_


-----

a. The applicant

224. The applicant claimed that Cyprus and Russia had violated their obligations under art 2 of the Convention to
conduct an effective investigation into the circumstances of Ms Rantseva's death. He pointed to alleged
contradictions between the autopsies of the Cypriot and Russian authorities (see para 50 above) and his requests
to Cyprus, via the relevant Russian authorities, for further investigation of apparent anomalies, requests which were
not followed up by the Cypriot authorities (see paras 52 and 62 above). He also complained about the limited
number of witness statements taken by the police (see paras 31 and 33 above), highlighting that five of the seven
relevant statements were either from the police officers on duty at Limassol Police Station or those present in the
apartment at the time of his daughter's death, persons who, in his view, had an interest in presenting a particular
version of events. The applicant further argued that any investigation should not depend on an official complaint or
claim from the victim's relatives. He contended that his daughter clearly died in strange circumstances requiring
elaboration and that an art 2-compliant investigation was accordingly required. The Cypriot investigation did not
comply with art 2 due to the inadequacies outlined above, as well as the fact that it was not accessible to him, as a
relative of the victim.

225. Specifically, as regards the inquest, the applicant complained that he was not advised of the date of the final
inquest hearing, which prevented his participation in it. He was not informed of the progress of the case or of other
remedies available to him. He alleged that he only received the District Court's conclusion in the inquest
proceedings on 16 April 2003, some 15 months after the proceedings had ended. Furthermore, the Cypriot
authorities failed to provide him with free legal assistance, when the cost of legal representation in Cyprus was
prohibitive for him.

226. As regards the Russian Federation, the applicant argued that the fact that his daughter was a citizen of the
Russian Federation meant that even though she was temporarily resident in Cyprus and her death occurred there,
the Russian Federation also had an obligation under art 2 to investigate the circumstances of her arrival in Cyprus,
her employment there and her subsequent death. He submitted that the Russian authorities should have applied to
the Cypriot authorities under the Legal Assistance Treaty to initiate criminal proceedings in accordance with arts 5
and 36 (see paras 181 and 207 above), as he had requested. Instead, the Russian authorities merely sought
information concerning the circumstances of Ms Rantseva's death. The applicant's subsequent application to the
relevant authorities in Russia to initiate criminal proceedings was refused by the Chelyabinsk Prosecutor's Office as
Ms Rantseva died outside Russia. His repeated requests that Russian authorities take statements from two
Russian nationals resident in Russia were refused as the Russian authorities considered that they were unable to
take the action requested without a legal assistance request from the Cypriot authorities. The applicant concluded
that these failures meant that the Russian authorities had not conducted an effective investigation into the death of
his daughter, as required by art 2 of the Convention.

b. The Cypriot Government

227. In their written submissions, the Cypriot Government conceded that an obligation to conduct an effective
investigation arose under art 2 where State agents were involved in events leading to an individual's death, but
contended that not every tragic death required that special steps by way of inquiry should be taken. In the present
case, the Cypriot authorities did not have an obligation to conduct an investigation into the circumstances of Ms
Rantseva's death but nonetheless did so. Although the exact circumstances leading to Ms Rantseva's death
remained unclear, the Cypriot Government contested the allegation that there were failures in the investigation. The
investigation was carried out by the police and was capable of leading to the identification and punishment of those
responsible. Reasonable steps were taken to secure relevant evidence and an inquest was held.

228. As far as the inquest was concerned, the Cypriot Government submitted that the applicant was advised by the
Cypriot authorities of the date of the inquest hearing. Moreover, the inquest was adjourned twice because the
applicant was not present. The Cypriot Government pointed to the delay of the Russian authorities in advising the
Cypriot authorities of the applicant's request for adjournment: the request only arrived four months after the inquest
had been concluded. Had the court been aware of the applicant's request, it might have adjourned the hearing
again. All other requests by the applicant had been addressed and relevant Cypriot authorities had sought to assist


-----

the applicant where possible. In respect of the applicant's complaint regarding legal aid, the Cypriot Government
pointed out that the applicant did not apply through the correct procedures. He should have applied under the Law
on Legal Aid; the Legal Assistance Treaty, invoked by the applicant, did not provide for legal aid but for free legal
assistance, which was quite different.

229. In their unilateral declaration (see para 187 above), the Cypriot Government confirmed that three independent
criminal investigators had recently been appointed to investigate the circumstances of Ms Rantseva's death and the
extent of any criminal responsibility of any person or authority for her death.

c. The Russian Government

230. The Russian Government accepted that at the relevant time, Russian criminal law did not provide for the
possibility of bringing criminal proceedings in Russia against non-Russian nationals in respect of a crime committed
outside Russian territory against a Russian national, although the law had since been changed. In any event, the
applicant did not request the Russian authorities to institute criminal proceedings themselves but merely requested
assistance in establishing the circumstances leading to his daughter's death in Cyprus. Accordingly, no preliminary
investigation into Ms Rantseva's death was conducted in Russia and no evidence was obtained. Although the
applicant requested on a number of occasions that the Russian authorities take evidence from two young Russian
women who had worked with Ms Rantseva, as he was advised, the Russian authorities were unable to take the
action requested in the absence of a legal assistance request from the Cypriot authorities. The Russian authorities
informed the Cypriot authorities that they were ready to execute any such request but no request was forthcoming.

231. The Russian Government contended that the Russian authorities took all possible measures to establish the
circumstances of Ms Rantseva's death, to render assistance to the Cypriot authorities in their investigations and to
protect and reinstate the applicant's rights. Accordingly, they argued, Russia had fulfilled any procedural obligations
incumbent on it under art 2 of the Convention.
_2. The Court's assessment_

a. General principles

232. As the Court has consistently held, the obligation to protect the right to life under art 2 of the Convention, read
in conjunction with the State's general duty under art 1 of the Convention to “secure to everyone within [its]
jurisdiction the rights and freedoms defined in [the] Convention”, requires that there should be some form of
effective official investigation when individuals have been killed as a result of the use of force (see McCann v UK

_[[1995] ECHR 18984/91, para 161, Series A no. 324;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X566-00000-00&context=1519360)_ _Kaya v Turkey_ _[[1998] ECHR 22729/93, para 86;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X0J9-00000-00&context=1519360)_ _Medova v_
_Russia, para 103). The obligation to conduct an effective official investigation also arises where death occurs in_
suspicious circumstances not imputable to State agents (see Menson v UK _[[2003] ECHR 47916/99). The essential](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X29M-00000-00&context=1519360)_
purpose of such investigation is to secure the effective implementation of the domestic laws which protect the right
to life and, in those cases involving State agents or bodies, to ensure their accountability for deaths occurring under
their responsibility. The authorities must act of their own motion once the matter has come to their attention. They
cannot leave it to the initiative of the next-of-kin either to lodge a formal complaint or to take responsibility for the
conduct of any investigative procedures (see, for example, İlhan v Turkey _[[2000] ECHR 22277/93, para 63;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X3J5-00000-00&context=1519360)_ _Paul_
_and Audrey Edwards, para 69)._

233. For an investigation to be effective, the persons responsible for carrying it out must be independent from those
implicated in the events. This requires not only hierarchical or institutional independence but also practical
independence (see Hugh Jordan v UK _[[2001] ECHR 24746/94, para 120 (extracts); and Kelly v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X07S-00000-00&context=1519360)_ _[[2001] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X067-00000-00&context=1519360)_
_[30054/96, para 114, 4 May 2001). The investigation must be capable of leading to the identification and punishment](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X067-00000-00&context=1519360)_
of those responsible (see _Paul and Audrey Edwards, cited above, para 71). A requirement of promptness and_
reasonable expedition is implicit in the context of an effective investigation within the meaning of art 2 of the
Convention (see Yaşa v Turkey _[[1998] ECHR 22495/93, paras 102-104; Çakıcı v Turkey](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4DN-00000-00&context=1519360)_ _[[1999] ECHR 23657/94,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1S5-00000-00&context=1519360)_
paras 80-87 and 106, ECHR 1999-IV; and _Kelly, cited above, para 97). In all cases, the next of kin of the victim_
must be involved in the procedure to the extent necessary to safeguard his legitimate interests (see, for example,
_Güleç v Turkey_ _[[1998] ECHR 21593/93, para 82; and Kelly, para 98).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X0BJ-00000-00&context=1519360)_


-----

b. Application of the general principles to the present case

i. Cyprus

234. The Court acknowledges at the outset that there is no evidence that Ms Rantseva died as a direct result of the
use of force. However, as noted above (see para 232 above), this does not preclude the existence of an obligation
to investigate her death under art 2 (see also Calvelli and Ciglio v Italy _[[2002] ECHR 32967/96, paras 48 to 50; and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_
Öneryıldız v Turkey _[[2004] ECHR 48939/99, paras 70 to 74). In light of the ambiguous and unexplained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7R1-DYBP-X4FD-00000-00&context=1519360)_
circumstances surrounding Ms Rantseva's death and the allegations of trafficking, ill-treatment and unlawful
detention in the period leading up to her death, the Court considers that a procedural obligation did arise in respect
of the Cypriot authorities to investigate the circumstances of Ms Rantseva's death. By necessity, the investigation
was required to consider not only the immediate context of Ms Rantseva's fall from the balcony but also the broader
context of Ms Rantseva's arrival and stay in Cyprus, in order to assess whether there was a link between the
allegations of trafficking and Ms Rantseva's subsequent death.

235. As to the adequacy of the investigation, the Court notes that the police arrived quickly and sealed off the scene
within minutes. Photographs were taken and a forensic examination was carried out (see para 32 above). That
same morning, the police took statements from those present in the apartment when Ms Rantseva died and from
the neighbour who had witnessed the fall. The police officers on duty at Limassol Police Station also made
statements (see para 33 above). An autopsy was carried out and an inquest was held (see paras Error: Reference
source not found to 41 above). However, there are a number of elements of the investigation which were
unsatisfactory.

236. First, there was conflicting testimony from those present in the apartment which the Cypriot investigating
authorities appear to have taken no steps to resolve (see paras 22 to 24 and 26 to 28 above). Similarly,
inconsistencies emerge from the evidence taken as to Ms Rantseva's physical condition, and in particular as to the
extent of the effects of alcohol on her conduct (see paras 18, 20 to 21 and 24 above). There are other apparent
anomalies, such as the alleged inconsistencies between the forensic reports of the Cypriot and Russian authorities
and the fact that Ms Rantseva made no noise as she fell from the balcony, for which no satisfactory explanation has
been provided (see paras 29, 50 to 52 and 67 above).

237. Second, the verdict at the inquest recorded that Ms Rantseva had died in “strange circumstances” in an
attempt to escape from the apartment in which she was a “guest” (see para 41 above). Despite the lack of clarity
surrounding the circumstances of her death, no effort was made by the Cypriot police to question those who lived
with Ms Rantseva or worked with her in the cabaret. Further, notwithstanding the striking conclusion of the inquest
that Ms Rantseva was trying to escape from the apartment, no attempt was made to establish why she was trying to
escape or to clarify whether she had been detained in the apartment against her will.

238. Third, aside from the initial statements of the two police officers and passport officer on duty made on 28 and
29 March 2001, there was apparently no investigation into what had occurred at the police station, and in particular
why the police had handed Ms Rantseva into the custody of M.A.. It is clear from the witness statements that the
AIS considered M.A. to be responsible for Ms Rantseva but the reasons for, and the appropriateness of, this
conclusion have never been fully investigated. Further, the statements of the police officers do not refer to any
statement being taken from Ms Rantseva and there is nothing in the investigation file to explain why this was not
done; a statement was made by M.A. (see para 19 above). The Court recalls that the Council of Europe
Commissioner reported in 2008 that he was assured that allegations of trafficking-related corruption within the
police force were isolated cases (see para 102 above). However, in light of the facts of the present case, the Court
considers that the authorities were under an obligation to investigate whether there was any indication of corruption
within the police force in respect of the events leading to Ms Rantseva's death.

239. Fourth, despite his clear request to the Cypriot authorities, the applicant was not personally advised of the date
of the inquest and as a consequence was not present when the verdict was handed down. The Cypriot Government
do not dispute the applicant's claim that he was only advised of the inquest finding 15 months after the hearing had


-----

taken place. Accordingly, the Cypriot authorities failed to ensure that the applicant was able to participate effectively
in the proceedings, despite his strenuous efforts to remain involved.

240. Fifth, the applicant's continued requests for investigation, via the Russian authorities, appear to have gone
unheeded by the Cypriot authorities. In particular, his requests for information as to further remedies open to him
within the Cypriot legal order, as well as requests for free legal assistance from the Cypriot authorities, were
ignored. The Cypriot Government's response in their written observations before the Court that the request for legal
assistance had been made under the wrong instrument is unsatisfactory. Given the applicant's repeated requests
and the gravity of the case in question, the Cypriot Government ought, at the very least, to have advised the
applicant of the appropriate procedure for making a request for free legal assistance.

241. Finally, for an investigation into a death to be effective, member States must take such steps as are necessary
and available in order to secure relevant evidence, whether or not it is located in the territory of the investigating
State. The Court observes that both Cyprus and Russia are parties to the Mutual Assistance Convention and have,
in addition, concluded the bilateral Legal Assistance Treaty (see paras 175 to 185 above). These instruments set
out a clear procedure by which the Cypriot authorities could have sought assistance from Russia in investigating the
circumstances of Ms Rantseva's stay in Cyprus and her subsequent death. The Prosecutor General of the Russian
Federation provided an unsolicited undertaking that Russia would assist in any request for legal assistance by
Cyprus aimed at the collection of further evidence (see para 70 above). However, there is no evidence that the
Cypriot authorities sought any legal assistance from Russia in the context of their investigation. In the
circumstances, the Court finds the Cypriot authorities' refusal to make a legal assistance request to obtain the
testimony of the two Russian women who worked with Ms Rantseva at the cabaret particularly unfortunate given
the value of such testimony in helping to clarify matters which were central to the investigation. Although Ms
Rantseva died in 2001, the applicant is still waiting for a satisfactory explanation of the circumstances leading to her
death.

242. The Court accordingly finds that there has been a procedural violation of art 2 of the Convention as regards
the failure of the Cypriot authorities to conduct an effective investigation into Ms Rantseva's death.

ii. Russia

243. The Court recalls that Ms Rantseva's death took place in Cyprus. Accordingly, unless it can be shown that
there are special features in the present case which require a departure from the general approach, the obligation
to ensure an effective official investigation applies to Cyprus alone (see, mutatis mutandis, Al-Adsani v UK _[[2001]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2VX-00000-00&context=1519360)_
_[ECHR 35763/97, para 38).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2VX-00000-00&context=1519360)_

244. As to the existence of special features, the applicant relies on the fact that Ms Rantseva was a Russian
national. However, the Court does not consider that art 2 requires member States' criminal laws to provide for
universal jurisdiction in cases involving the death of one of their nationals. There are no other special features which
would support the imposition of a duty on Russia to conduct its own investigation. Accordingly, the Court concludes
that there was no free-standing obligation incumbent on the Russian authorities under art 2 of the Convention to
investigate Ms Rantseva's death.

245. However, the corollary of the obligation on an investigating State to secure evidence located in other
jurisdictions is a duty on the State where evidence is located to render any assistance within its competence and
means sought under a legal assistance request. In the present case, as noted above, the Prosecutor General of the
Russian Federation, referring to the evidence of the two Russian women, expressed willingness to comply with any
mutual legal assistance request forwarded to the Russian authorities and to organise the taking of the witness
testimony, but no such request was forthcoming (see para 241 above). The applicant argued that the Russian
authorities should have proceeded to interview the two women notwithstanding the absence of any request from the
Cypriot authorities. However, the Court recalls that the responsibility for investigating Ms Rantseva's death lay with
Cyprus. In the absence of a legal assistance request, the Russian authorities were not required under art 2 to
secure the evidence themselves.


-----

246. As to the applicant's complaint that the Russian authorities failed to request the initiation of criminal
proceedings, the Court observes that the Russian authorities made extensive use of the opportunities presented by
mutual legal assistance agreements to press for action by the Cypriot authorities (see, for example, paras 48, 52,
55, 57 and 61 to 62 above). In particular, by letter dated 11 December 2001, they requested that further
investigation be conducted into Ms Rantseva's death, that relevant witnesses be interviewed and that the Cypriot
authorities bring charges of murder, kidnapping or unlawful deprivation of freedom in respect of Ms Rantseva's
death (see para 52 above). By letter dated 27 December 2001, a specific request was made to institute criminal
proceedings (see para 53 above). The request was reiterated on several occasions.

247. In conclusion, the Court finds that there has been no procedural violation of art 2 by the Russian Federation.
_IV. ALLEGED VIOLATION OF ARTICLE 3 OF THE CONVENTION_

248. The applicant alleged a violation of art 3 of the Convention by the Cypriot authorities in respect of their failure
to take steps to protect Ms Rantseva from ill-treatment and to investigate whether Ms Rantseva was subject to
inhuman or degrading treatment in the period leading up to her death. Article 3 provides that:

“No one shall be subjected to torture or to inhuman or degrading treatment or punishment.”

A. The parties' submissions
_1. The applicant_

249. The applicant argued that a positive obligation arose in the present case to protect Ms Rantseva from illtreatment from private individuals. He contended that the two forensic reports conducted following Ms Rantseva's
death revealed that the explanation of her death did not accord with the injuries recorded. He argued that the
witness testimony gathered did not provide a satisfactory response to the question whether there were injuries
present on Ms Rantseva's body prior to her death. Despite this, no investigation was conducted by the Cypriot
authorities into whether Ms Rantseva had been subjected to inhuman or degrading treatment. Further, no steps
were taken to avoid the risk of ill treatment to Ms Rantseva in circumstances where the authorities knew or ought to
have known of a real and immediate risk. Accordingly, in the applicant's submission, there was a breach of art 3 of
the Convention.
_2. The Cypriot Government_

250. In their written submissions, the Cypriot Government denied that any violation of art 3 had occurred. They
pointed out that nothing in the investigation file suggested that Ms Rantseva had been subjected to inhuman or
degrading treatment prior to her death. In any event, a thorough investigation, capable of leading to the
identification and punishment of those responsible, was conducted into the circumstances of Ms Rantseva's death.
The investigation therefore complied with art 3.

251. In their subsequent unilateral declaration (see para 187 above), the Cypriot Government acknowledged that
there had been a breach of the procedural obligation arising under art 3 of the Convention in so far as the police
investigation into whether Ms Rantseva was subjected to inhuman or degrading treatment prior to her death was
ineffective. They also confirmed that three independent investigators had been appointed to investigate the
circumstances of Ms Rantseva's employment and stay in Cyprus and whether she had been subjected to inhuman
or degrading treatment.

B. The Court's assessment

252. The Court notes that there is no evidence that Ms Rantseva was subjected to ill-treatment prior to her death.
However, it is clear that the use of violence and the ill-treatment of victims are common features of trafficking (see
paras 85, 87 to 88 and 101 above). The Court therefore considers that, in the absence of any specific allegations of
ill-treatment, any inhuman or degrading treatment suffered by Ms Rantseva prior to her death was inherently linked
to the alleged trafficking and exploitation. Accordingly, the Court concludes that it is not necessary to consider
separately the applicant's art 3 complaint and will deal with the general issues raised in the context of its
examination of the applicant's complaint under art 4 of the Convention.
_V. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION_


-----

253. The applicant alleged a violation of art 4 of the Convention by both the Russian and Cypriot authorities in light
of their failure to protect his daughter from being trafficked and their failure to conduct an effective investigation into
the circumstances of her arrival in Cyprus and the nature of her employment there. Article 4 provides, in so far as
relevant, that:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

...”

A. Submissions of the parties
_1. The applicant_

254. Referring to Siliadin v France [2005] ECHR 73316/01, and the Anti-Trafficking Convention (see paras 162 to
174, above), the applicant contended that the Cypriot authorities were under an obligation to adopt laws to combat
trafficking and to establish and strengthen policies and programmes to combat trafficking. He pointed to the reports
of the Council of Europe's Commissioner on Human Rights (see paras 91 to 104 above), which he said
demonstrated that there had been a deterioration in the situation of young foreign women moving to Cyprus to work
as cabaret artistes. He concluded that the obligations incumbent on Cyprus to combat trafficking had not been met.
In particular, the applicant pointed out that the Cypriot authorities were unable to explain why they had handed Ms
Rantseva over to her former employer at the police station instead of releasing her (see para 82 above). He
contended that in so doing, the Cypriot authorities had failed to take measures to protect his daughter from
trafficking. They had also failed to conduct any investigation into whether his daughter had been a victim of
trafficking or had been subjected to sexual or other exploitation. Although Ms Rantseva had entered Cyprus
voluntarily to work in the cabaret, the Court had established that prior consent, without more, does not negate a
finding of compulsory labour (referring to Van der Mussele v Belgium _[[1983] ECHR 8919/80, para 36).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_

255. In respect of Russia, the applicant pointed out that at the relevant time, the Russian Criminal Code did not
contain provisions which expressly addressed trafficking in human beings. He argued that the Russian authorities
were aware of the particular problem of young women being trafficked to Cyprus to work in the sex industry.
Accordingly, the Russian Federation was under an obligation to adopt measures to prevent the trafficking and
exploitation of Russian women but had failed to do so. In the present case, it was under a specific obligation to
investigate the circumstances of Ms Rantseva's arrival in Cyprus and the nature of her employment there, but no
such investigation had been carried out.
_2. The Cypriot Government_

256. In their written observations, the Cypriot Government confirmed that no measures were taken in the period
prior to or following Ms Rantseva's death to ascertain whether she had been a victim of trafficking in human beings
or whether she had been subjected to sexual or other forms of exploitation. However they denied that there had
been a violation of art 4 of the Convention. They conceded that there were positive obligations on the State which
required the penalisation and effective prosecution of any act aimed at maintaining a person in a situation of
slavery, servitude or forced or compulsory labour. However, they argued by analogy with arts 2 and 3 that positive
obligations only arose where the authorities knew or ought to have known of a real and immediate risk that an
identified individual was being held in such a situation. These positive obligations would only be violated where the
authorities subsequently failed to take measures within the scope of their powers which, judged reasonably, might
have been expected to avoid that risk.

257. In the present case, there was nothing in the investigation file, nor was there any other evidence, to indicate
that Ms Rantseva was held in slavery or servitude or was required to perform forced or compulsory labour. The
Cypriot Government further pointed to the fact that no complaint had been lodged with the domestic authorities by
the applicant that his daughter had been a victim of trafficking or exploitation and that none of the correspondence
from the Russian authorities made any reference to such a complaint. Ms Rantseva herself had made no
allegations of that nature prior to her death and the note she left in her apartment saying she was tired and was
going back to Russia (see para 17 above) was inadequate to support any such allegations. The Government
l i d th t th fi t ti th t l i t f thi t d t th th iti 13 A il 2006 b


-----

Russian Orthodox priest in Limassol. They argued that the Russian authorities had failed to cooperate with the
Cypriot authorities and take witness statements from two Russian women who had worked with Ms Rantseva at the
cabaret.

258. In their subsequent unilateral declaration (see para 187 above), the Cypriot Government accepted that they
had violated their positive obligations under art 4 in failing to take any measures to ascertain whether Ms Rantseva
had been a victim of trafficking in human beings or had been subjected to sexual or any other kind of exploitation.
They also confirmed that three independent investigators had been appointed to investigate the circumstances of
Ms Rantseva's employment and stay in Cyprus and whether there was any evidence that she was a victim of
trafficking or exploitation.
_3. The Russian Government_

259. As noted above, the Russian Government contested that Ms Rantseva's treatment in the present case fell
within the scope of art 4 (see para 209 above).

260. On the merits, the Russian Government agreed that the positive obligations arising under art 4 required
member States to ensure that residents were not being kept in slavery or servitude or being forced to work. Where
such a case did occur, member States were required to put in place an effective framework for the protection and
reinstatement of victims' rights and for the prosecution of guilty persons. However, in so far as the applicant's
complaint was directed against Russia, his argument was that the Russian authorities ought to have put in place a
system of preventative measures to protect citizens going abroad. The Russian Government pointed out that any
such measures would have had to strike a balance between art 4 and the right to free movement guaranteed by art
2 of Protocol No. 4 of the Convention, which provides that “[e]veryone shall be free to leave any country, including
his own”. They also argued that the scope of any such measures was significantly restricted by the need to respect
the sovereignty of the State to which the citizen wished to travel.

261. According to the Russian Government, there was a wealth of measures set out in Russian criminal law to
prevent violations of art 4, to protect victims and to prosecute perpetrators. Although at the relevant time Russian
criminal law did not contain provisions on human trafficking and slave labour, such conduct would nonetheless have
fallen within the definitions of other crimes such as threats to kill or cause grave harm to health, abduction, unlawful
deprivation of liberty and sexual crimes (see paras 133 to 135). The Russian Government also pointed to various
international treaties ratified by the Russian Federation, including the Slavery Convention 1926 (see paras 137 to
141above) and the Palermo Protocol 2000 (see paras 149 to 155 above), and highlighted that Russia had signed
up to a number of mutual legal assistance agreements (see paras 175 to 185 above). In the present case, they had
taken active measures to press for the identification and punishment of guilty persons within the framework of
mutual legal assistance treaties. They further explained that on 27 July 2006, the application of the Criminal Code
was extended to allow the prosecution of non-nationals who had committed crimes against Russian nationals
outside Russian territory. However, the exercise of this power depended on the consent of the State in whose
territory the offence was committed.

262. As regards the departure of Ms Rantseva for Cyprus, the Russian authorities pointed out that they only
became aware of a citizen leaving Russia at the point at which an individual crossed the border. Where entry
requirements of the State of destination were complied with, and in the absence of any circumstances preventing
the exit, the Russian authorities were not permitted to prohibit a person from exercising his right of free movement.
Accordingly, the Russian authorities could only make recommendations and warn its citizens against possible
dangers. They did provide warnings, via the media, as well as more detailed information regarding the risk factors.

263. The Russian Government also requested the Court to consider that there had been no previous findings of a
violation of art 4 against Cyprus. They submitted that they were entitled to take this into consideration in the
development of their relations with Cyprus.
_4. Third party submissions_

a. Interights


-----

264. Interights highlighted the growing awareness of human trafficking and the adoption of a number of international
and regional instruments seeking to combat it. However, they considered national policies and measures in the field
to be at times inadequate and ineffective. They argued that the paramount requirement for any legal system
effectively to address human trafficking was recognition of the need for a multidisciplinary approach; cooperation
among States; and a legal framework with an integrated human rights approach.

265. Interights emphasised that a distinctive element of human trafficking was the irrelevance of the victim's
consent to the intended exploitation where any of the means of coercion listed in the Palermo Protocol had been
used (see para 151 above). Accordingly, a person who was aware that she was to work in the sex industry was not
excluded by virtue of that awareness from being a victim of trafficking. Of further importance was the distinction
between smuggling, which concerned primarily the protection of the State against illegal migration, and trafficking,
which was a crime against individuals and did not necessarily involve a cross-border element.

266. Asserting that human trafficking was a form of modern-day slavery, Interights highlighted the conclusions of
the International Criminal Tribunal for the Former Yugoslavia in the case of Prosecutor v Kunarac et al (see paras
142 to 143 above) and argued that the necessary consequence of that judgment was that the definition of slavery
did not require a right of ownership over a person to exist but merely that one or more of the powers attached to
such a right be present. Thus the modern-day understanding of the term “slavery” could include situations where
the victim was subject to violence and coercion thereby giving the perpetrator total control over the victim.

267. Interights addressed the positive obligations of member States under the Convention in the context of
trafficking in human beings. In particular, there was, Interights contended, an obligation to enact appropriate
legislation on trafficking in human beings, as set out in the Anti-Trafficking Convention (see paras 160 to 174
above) and supported by the case-law of the Court. Such legislation was required to criminalise trafficking in human
beings, establishing liability of legal as well as natural persons; to introduce review procedures in respect of the
licensing and operation of businesses often used as a cover for human trafficking; and to establish appropriate
penalties. Other positive obligations included obligations to discourage demand for human trafficking, to ensure an
adequate law enforcement response to identify and eradicate any involvement of law enforcement officials in
human trafficking offences and build victims' confidence in the police and judicial systems and to ensure that the
identification of victims of trafficking took place efficiently and effectively by introducing relevant training. Research
on best practices, methods and strategies, raising awareness in the media and civil society, information campaigns
involving public authorities and policy makers, educational programmes and targeting sex tourism were also areas
of possible State action identified by Interights.

268. Finally, Interights argued that there was an implied positive obligation on States to carry out an effective and
diligent investigation into allegations of trafficking. Such investigation should comply with the conditions of
investigations required under art 2 of the Convention.

b. The AIRE Centre

269. The AIRE Centre highlighted the increasing number of people, the majority of whom were women and
children, who fell victim to trafficking for the purposes of sexual or other exploitation each year. They pointed to the
severe physical and psychological consequences for victims, which frequently rendered them too traumatised to
present themselves as victims of trafficking to the relevant authorities. They referred in particular to the conclusions
of a report by the U.S. State Department in 2008, Trafficking in Persons Report, which found that Cyprus had failed
to provide evidence that it had increased its efforts to combat severe forms of trafficking in persons from the
previous year (see para 106 above).

270. More generally, the AIRE Centre highlighted their concern that the rights of victims of human trafficking were
often subordinated to other goals in the fight against trafficking. International and regional instruments on human
trafficking often lacked practical and effective rights for the protection of victims. Apart from requirements regarding
the investigation and prosecution of trafficking offences, the provisions of the Palermo Protocol on protection of
victims were, the AIRE Centre argued, “generally either hortatory or aspirational”, obliging States to “consider” or
“endeavour to” introduce certain measures.


-----

271. Finally, the AIRE Centre noted that the jurisprudence of supervisory bodies for international instruments
against trafficking had yet to address fully the extent and content of positive obligations owed by States in the
circumstances arising in the present application. As regards the jurisprudence of this Court, the AIRE Centre noted
that although the Court had already been called upon to consider the extent of the application of art 4 in a trafficking
case (Siliadin, cited above), that case had dealt exclusively with the failure of the State to put in place adequate
criminal law provisions to prevent and punish the perpetrators. Referring to the case-law developed in the context of
arts 2, 3 and 8 of the Convention, the AIRE Centre argued that States had a positive obligation to provide protection
where they knew or ought to have known that an individual was, or was at risk of being, a victim of human
trafficking. The particular measures required would depend on the circumstances but States were not permitted to
leave such an individual unprotected or to return her to a situation of trafficking and exploitation.

B. The Court's assessment
_1. Application of art 4 of the Convention_

272. The first question which arises is whether the present case falls within the ambit of art 4. The Court recalls that
art 4 makes no mention of trafficking, proscribing “slavery”, “servitude” and “forced and compulsory labour”.

273. The Court has never considered the provisions of the Convention as the sole framework of reference for the
interpretation of the rights and freedoms enshrined therein (Demir and Baykara v Turkey _[[2008] ECHR 34503/97,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X05H-00000-00&context=1519360)_
para 67, 12 November 2008). It has long stated that one of the main principles of the application of the Convention
provisions is that it does not apply them in a vacuum (see Loizidou v Turkey _[1996] ECHR 15318/89; and Öcalan v_
_Turkey_ _[[2005] ECHR 46221/99, para 163). As an international treaty, the Convention must be interpreted in the light](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4X1-00000-00&context=1519360)_
of the rules of interpretation set out in the Vienna Convention of 23 May 1969 on the Law of Treaties.

274. Under that Convention, the Court is required to ascertain the ordinary meaning to be given to the words in their
context and in the light of the object and purpose of the provision from which they are drawn (see _Golder v UK_

_[[1975] ECHR 4451/70, para 29; Loizidou, para 43; and art 31(1) of the Vienna Convention). The Court must have](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X324-00000-00&context=1519360)_
regard to the fact that the context of the provision is a treaty for the effective protection of individual human rights
and that the Convention must be read as a whole, and interpreted in such a way as to promote internal consistency
and harmony between its various provisions (Stec v UK [2005] ECHR 65731/01 and 65900/01, para 48). Account
must also be taken of any relevant rules and principles of international law applicable in relations between the
Contracting Parties and the Convention should so far as possible be interpreted in harmony with other rules of
international law of which it forms part (see Al-Adsani v UK _[[2001] ECHR 35763/97, para 55; Demir and Baykara,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2VX-00000-00&context=1519360)_
para 67; Saadi v UK _[[2008] ECHR 13229/03, para 62, art 31 para. 3 (c) of the Vienna Convention).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X03M-00000-00&context=1519360)_

275. Finally, the Court emphasises that the object and purpose of the Convention, as an instrument for the
protection of individual human beings, requires that its provisions be interpreted and applied so as to make its
safeguards practical and effective (see, inter alia, Soering v UK _[[1989] ECHR 14038/88, para 87; and Artico v Italy](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_

_[[1980] ECHR 6694/74, para 33).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1KB-00000-00&context=1519360)_

276. In Siliadin, considering the scope of “slavery” under art 4, the Court referred to the classic definition of slavery
contained in the 1926 Slavery Convention, which required the exercise of a genuine right of ownership and
reduction of the status of the individual concerned to an “object” (Siliadin, cited above, para 122). With regard to the
concept of “servitude”, the Court has held that what is prohibited is a “particularly serious form of denial of freedom”
(see _Van Droogenbroeck v Belgium, Commission's report of 9 July 1980, paras 78-80, Series B no. 44). The_
concept of “servitude” entails an obligation, under coercion, to provide one's services, and is linked with the concept
of “slavery” (see Seguin v France [2000] ECHR 42400/98, 7 March 2000; and Siliadin, cited above, para 124). For
“forced or compulsory labour” to arise, the Court has held that there must be some physical or mental constraint, as
well as some overriding of the person's will (Van der Mussele v Belgium, para 34; Siliadin, cited above, para 117).

277. The absence of an express reference to trafficking in the Convention is unsurprising. The Convention was
inspired by the Universal Declaration of Human Rights, proclaimed by the General Assembly of the United Nations
in 1948, which itself made no express mention of trafficking. In its art 4, the Declaration prohibited “slavery and the
slave trade in all their forms”. However, in assessing the scope of art 4 of the Convention, sight should not be lost of


-----

the Convention's special features or of the fact that it is a living instrument which must be interpreted in the light of
present-day conditions. The increasingly high standards required in the area of the protection of human rights and
fundamental liberties correspondingly and inevitably require greater firmness in assessing breaches of the
fundamental values of democratic societies (see, among many other authorities, Selmouni v France _[[1999] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X50K-00000-00&context=1519360)_
_[25803/94, para 101; Christine Goodwin v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X50K-00000-00&context=1519360)_ _[[2002] ECHR 28957/95, para 71; and Siliadin, cited above, para 121).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4NG-00000-00&context=1519360)_

278. The Court notes that trafficking in human beings as a global phenomenon has increased significantly in recent
years (see paras 89, 100, 103 and 269 above). In Europe, its growth has been facilitated in part by the collapse of
former Communist blocs. The conclusion of the Palermo Protocol in 2000 and the Anti-Trafficking Convention in
2005 demonstrate the increasing recognition at international level of the prevalence of trafficking and the need for
measures to combat it.

279. The Court is not regularly called upon to consider the application of art 4 and, in particular, has had only one
occasion to date to consider the extent to which treatment associated with trafficking fell within the scope of that
Article (Siliadin, cited above). In that case, the Court concluded that the treatment suffered by the applicant
amounted to servitude and forced and compulsory labour, although it fell short of slavery. In light of the proliferation
of both trafficking itself and of measures taken to combat it, the Court considers it appropriate in the present case to
examine the extent to which trafficking itself may be considered to run counter to the spirit and purpose of art 4 of
the Convention such as to fall within the scope of the guarantees offered by that Article without the need to assess
which of the three types of proscribed conduct are engaged by the particular treatment in the case in question.

280. The Court observes that the International Criminal Tribunal for the Former Yugoslavia concluded that the
traditional concept of “slavery” has evolved to encompass various contemporary forms of slavery based on the
exercise of any or all of the powers attaching to the right of ownership (see para 142 above). In assessing whether
a situation amounts to a contemporary form of slavery, the Tribunal held that relevant factors included whether
there was control of a person's movement or physical environment, whether there was an element of psychological
control, whether measures were taken to prevent or deter escape and whether there was control of sexuality and
forced labour (see para 143 above).

281. The Court considers that trafficking in human beings, by its very nature and aim of exploitation, is based on the
exercise of powers attaching to the right of ownership. It treats human beings as commodities to be bought and sold
and put to forced labour, often for little or no payment, usually in the sex industry but also elsewhere (see paras 101
and 161 above). It implies close surveillance of the activities of victims, whose movements are often circumscribed
(see paras 85 and 101 above). It involves the use of violence and threats against victims, who live and work under
poor conditions (see paras 85, 87 to 88 and 101 above). It is described by Interights and in the explanatory report
accompanying the Anti-Trafficking Convention as the modern form of the old worldwide slave trade (see paras 161
and 266 above). The Cypriot Ombudsman referred to sexual exploitation and trafficking taking place “under a
regime of modern slavery” (see para 84 above).

282. There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its victims
and cannot be considered compatible with a democratic society and the values expounded in the Convention. In
view of its obligation to interpret the Convention in light of present-day conditions, the Court considers it
unnecessary to identify whether the treatment about which the applicant complains constitutes “slavery”, “servitude”
or “forced and compulsory labour”. Instead, the Court concludes that trafficking itself, within the meaning of art 3(a)
of the Palermo Protocol and art 4(a) of the Anti-Trafficking Convention, falls within the scope of art 4 of the
Convention. The Russian Government's objection of incompatibility ratione materiae is accordingly dismissed.
_2. General principles of art 4_

283. The Court reiterates that, together with arts 2 and 3, art 4 enshrines one of the basic values of the democratic
societies making up the Council of Europe (Siliadin, cited above, para 82). Unlike most of the substantive clauses of
the Convention, art 4 makes no provision for exceptions and no derogation from it is permissible under art 15(2)
even in the event of a public emergency threatening the life of the nation.

284. In assessing whether there has been a violation of art 4, the relevant legal or regulatory framework in place
t b t k i t t ( _t ti_ _t_ _di_ _N_ _h_ _B l_ _i_ _[[2005] ECHR 43577/98](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2NP-00000-00&context=1519360)_ d 43579/98


-----

93). The Court considers that the spectrum of safeguards set out in national legislation must be adequate to ensure
the practical and effective protection of the rights of victims or potential victims of trafficking. Accordingly, in addition
to criminal law measures to punish traffickers, art 4 requires member States to put in place adequate measures
regulating businesses often used as a cover for human trafficking. Furthermore, a State's immigration rules must
address relevant concerns relating to encouragement, facilitation or tolerance of trafficking (see, mutatis mutandis,
_Guerra v Italy_ _[[1998] ECHR 14967/89, paras 58 to 60;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X3K7-00000-00&context=1519360)_ _Z v UK_ _[[2001] ECHR 29392/95, paras 73 to 74; and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X16H-00000-00&context=1519360)_
_Nachova, cited above, paras 96 to 97 and 99-102)._

285. In its Siliadin judgment, the Court confirmed that art 4 entailed a specific positive obligation on member States
to penalise and prosecute effectively any act aimed at maintaining a person in a situation of slavery, servitude or
forced or compulsory labour (cited above, paras 89 and 112). In order to comply with this obligation, member States
are required to put in place a legislative and administrative framework to prohibit and punish trafficking. The Court
observes that the Palermo Protocol and the Anti-Trafficking Convention refer to the need for a comprehensive
approach to combat trafficking which includes measures to prevent trafficking and to protect victims, in addition to
measures to punish traffickers (see paras 149 and 163 above). It is clear from the provisions of these two
instruments that the Contracting States, including almost all of the member States of the Council of Europe, have
formed the view that only a combination of measures addressing all three aspects can be effective in the fight
against trafficking (see also the submissions of Interights and the AIRE Centre at paras 267 and 271 above).
Accordingly, the duty to penalise and prosecute trafficking is only one aspect of member States' general
undertaking to combat trafficking. The extent of the positive obligations arising under art 4 must be considered
within this broader context.

286. As with arts 2 and 3 of the Convention, art 4 may, in certain circumstances, require a State to take operational
measures to protect victims, or potential victims, of trafficking (see, _mutatis mutandis,_ _Osman, cited above, para_
115; and _Mahmut Kaya v Turkey_ _[[2000] ECHR 22535/93, para 115). In order for a positive obligation to take](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X1C9-00000-00&context=1519360)_
operational measures to arise in the circumstances of a particular case, it must be demonstrated that the State
authorities were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion that an
identified individual had been, or was at real and immediate risk of being, trafficked or exploited within the meaning
of art 3(a) of the Palermo Protocol and art 4(a) of the Anti-Trafficking Convention. In the case of an answer in the
affirmative, there will be a violation of art 4 of the Convention where the authorities fail to take appropriate measures
within the scope of their powers to remove the individual from that situation or risk (see, mutatis mutandis, Osman,
cited above, paras116 to 117; and Mahmut Kaya, cited above, paras 115 to 116).

287. Bearing in mind the difficulties involved in policing modern societies and the operational choices which must be
made in terms of priorities and resources, the obligation to take operational measures must, however, be
interpreted in a way which does not impose an impossible or disproportionate burden on the authorities (see,
_mutatis mutandis,_ _Osman, cited above, para 116). It is relevant to the consideration of the proportionality of any_
positive obligation arising in the present case that the Palermo Protocol, signed by both Cyprus and the Russian
Federation in 2000, requires States to endeavour to provide for the physical safety of victims of trafficking while in
their territories and to establish comprehensive policies and programmes to prevent and combat trafficking (see
paras 153 to 154 above). States are also required to provide relevant training for law enforcement and immigration
officials (see para 155 above).

288. Like arts 2 and 3, art 4 also entails a procedural obligation to investigate situations of potential trafficking. The
requirement to investigate does not depend on a complaint from the victim or next-of-kin: once the matter has come
to the attention of the authorities they must act of their own motion (see, _mutatis mutandis,_ _Paul and Audrey_
_Edwards v UK_ _[[2002] ECHR 46477/99, para 69). For an investigation to be effective, it must be independent from](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2BX-00000-00&context=1519360)_
those implicated in the events. It must also be capable of leading to the identification and punishment of individuals
responsible, an obligation not of result but of means. A requirement of promptness and reasonable expedition is
implicit in all cases but where the possibility of removing the individual from the harmful situation is available, the
investigation must be undertaken as a matter of urgency. The victim or the next-of-kin must be involved in the
procedure to the extent necessary to safeguard their legitimate interests (see, mutatis mutandis, Paul and Audrey
_Edwards, cited above, paras 70 to 73)._


-----

289. Finally, the Court reiterates that trafficking is a problem which is often not confined to the domestic arena.
When a person is trafficked from one State to another, trafficking offences may occur in the State of origin, any
State of transit and the State of destination. Relevant evidence and witnesses may be located in all States.
Although the Palermo Protocol is silent on the question of jurisdiction, the Anti-Trafficking Convention explicitly
requires each member State to establish jurisdiction over any trafficking offence committed in its territory (see para
172 above). Such an approach is, in the Court's view, only logical in light of the general obligation, outlined above,
incumbent on all States under art 4 of the Convention to investigate alleged trafficking offences. In addition to the
obligation to conduct a domestic investigation into events occurring on their own territories, member States are also
subject to a duty in cross-border trafficking cases to cooperate effectively with the relevant authorities of other
States concerned in the investigation of events which occurred outside their territories. Such a duty is in keeping
with the objectives of the member States, as expressed in the preamble to the Palermo Protocol, to adopt a
comprehensive international approach to trafficking in the countries of origin, transit and destination (see para 149
above). It is also consistent with international agreements on mutual legal assistance in which the respondent
States participate in the present case (see paras 175 to 185 above).
_3. Application of the general principles to the present case_

Cyprus

i. Positive obligation to put in place an appropriate legislative and administrative framework

290. The Court observes that in Cyprus legislation prohibiting trafficking and sexual exploitation was adopted in
2000 (see paras 127 to 131 above). The law reflects the provisions of the Palermo Protocol and prohibits trafficking
and sexual exploitation, with consent providing no defence to the offence. Severe penalties are set out in the
legislation. The law also provides for a duty to protect victims, inter alia through the appointment of a guardian of
victims. Although the Ombudsman criticised the failure of the authorities to adopt practical implementing measures,
she considered the law itself to be satisfactory (see para 90 above). The Council of Europe Commissioner also
found the legal framework established by Law 3(1) 2000 to be “suitable” (see para 92 above). Notwithstanding the
applicant's complaint as to the inadequacy of Cypriot trafficking legislation, the Court does not consider that the
circumstances of the present case give rise to any concern in this regard.

291. However, as regards the general legal and administrative framework and the adequacy of Cypriot immigration
policy, a number of weaknesses can be identified. The Council of Europe Commissioner for Human Rights noted in
his 2003 report that the absence of an immigration policy and legislative shortcomings in this respect have
encouraged the trafficking of women to Cyprus (see para 91 above). He called for preventive control measures to
be adopted to stem the flow of young women entering Cyprus to work as cabaret artistes (see para 94 above). In
subsequent reports, the Commissioner reiterated his concerns regarding the legislative framework, and in particular
criticised the system whereby cabaret managers were required to make the application for an entry permit for the
artiste as rendering the artiste dependent on her employer or agent and increasing her risk of falling into the hands
of traffickers (see para 100 above). In his 2008 report, the Commissioner criticised the artiste visa regime as
making it very difficult for law enforcement authorities to take the necessary steps to combat trafficking, noting that
the artiste permit could be perceived as contradicting the measures taken against trafficking or at least as rendering
them ineffective (see also the report of the U.S. State Department at paras 105 and 107 above). The Commissioner
expressed regret that, despite concerns raised in previous reports and the Government's commitment to abolish it,
the artiste work permit was still in place (see para 103 above). Similarly, the Ombudsman, in her 2003 report,
blamed the artiste visa regime for the entry of thousands of young foreign women into Cyprus, where they were
exploited by their employers under cruel living and working conditions (see para 89 above).

292. Further, the Court emphasises that while an obligation on employers to notify the authorities when an artiste
leaves her employment (see para 117 above) is a legitimate measure to allow the authorities to monitor the
compliance of immigrants with their immigration obligations, responsibility for ensuring compliance and for taking
steps in cases of non-compliance must remain with the authorities themselves. Measures which encourage cabaret
owners and managers to track down missing artistes or in some other way to take personal responsibility for the
conduct of artistes are unacceptable in the broader context of trafficking concerns regarding artistes in Cyprus.
Against this backdrop, the Court considers that the practice of requiring cabaret owners and managers to lodge a


-----

bank guarantee to cover potential future costs associated with artistes which they have employed (see para 115
above) particularly troubling. The separate bond signed in Ms Rantseva's case is of equal concern (see para 15
above), as is the unexplained conclusion of the AIS that M.A. was responsible for Ms Rantseva and was therefore
required to come and collect her from the police station (see para 20 above).

293. In the circumstances, the Court concludes that the regime of artiste visas in Cyprus did not afford to Ms
Rantseva practical and effective protection against trafficking and exploitation. There has accordingly been a
violation of art 4 in this regard.

ii. Positive obligation to take protective measures

294. In assessing whether a positive obligation to take measures to protect Ms Rantseva arose in the present case,
the Court considers the following to be significant. First, it is clear from the Ombudsman's 2003 report that here has
been a serious problem in Cyprus since the 1970s involving young foreign women being forced to work in the sex
industry (see para 83 above). The report further noted the significant increase in artistes coming from former Soviet
countries following the collapse of the USSR (see para 84 above). In her conclusions, the Ombudsman highlighted
that trafficking was able to flourish in Cyprus due to the tolerance of the immigration authorities (see para 89
above). In his 2006 report, the Council of Europe's Commissioner for Human Rights also noted that the authorities
were aware that many of the women who entered Cyprus on artiste's visas would work in prostitution (see para 96
above). There can therefore be no doubt that the Cypriot authorities were aware that a substantial number of
foreign women, particularly from the ex-USSR, were being trafficked to Cyprus on artistes visas and, upon arrival,
were being sexually exploited by cabaret owners and managers.

295. Second, the Court emphasises that Ms Rantseva was taken by her employer to Limassol police station. Upon
arrival at the police station, M.A. told the police that Ms Rantseva was a Russian national and was employed as a
cabaret artiste. Further, he explained that she had only recently arrived in Cyprus, had left her employment without
warning and had also moved out of the accommodation provided to her (see para 19 above). He handed to them
her passport and other documents (see para 21 above).

296. The Court recalls the obligations undertaken by the Cypriot authorities in the context of the Palermo Protocol
and, subsequently, the Anti-Trafficking Convention to ensure adequate training to those working in relevant fields to
enable them to identify potential trafficking victims (see paras 155 and 167 above). In particular, under art 10 of the
Palermo Protocol, States undertake to provide or strengthen training for law enforcement, immigration and other
relevant officials in the prevention of trafficking in persons. In the Court's opinion, there were sufficient indicators
available to the police authorities, against the general backdrop of trafficking issues in Cyprus, for them to have
been aware of circumstances giving rise to a credible suspicion that Ms Rantseva was, or was at real and
immediate risk of being, a victim of trafficking or exploitation. Accordingly, a positive obligation arose to investigate
without delay and to take any necessary operational measures to protect Ms Rantseva.

297. However, in the present case, it appears that the police did not even question Ms Rantseva when she arrived
at the police station. No statement was taken from her. The police made no further inquiries into the background
facts. They simply checked whether Ms Rantseva's name was on a list of persons wanted by the police and, on
finding that it was not, called her employer and asked him to return and collect her. When he refused and insisted
that she be detained, the police officer dealing with the case put M.A. in contact with his superior (see para 20
above). The details of what was said during M.A.'s conversation with the officer's superior are unknown, but the
result of the conversation was that M.A. agreed to come and collect Ms Rantseva and subsequently did so.

298. In the present case, the failures of the police authorities were multiple. First, they failed to make immediate
further inquiries into whether Ms Rantseva had been trafficked. Second, they did not release her but decided to
confide her to the custody of M.A.. Third, no attempt was made to comply with the provisions of Law 3(1) of 2000
and to take any of the measures in section 7 of that law (see para 130 above) to protect her. The Court accordingly
concludes that these deficiencies, in circumstances which gave rise to a credible suspicion that Ms Rantseva might
have been trafficked or exploited, resulted in a failure by the Cypriot authorities to take measures to protect Ms
Rantseva. There has accordingly been a violation of art 4 in this respect also.


-----

iii. Procedural obligation to investigate trafficking

299. A further question arises as to whether there has been a procedural breach as a result of the continuing failure
of the Cypriot authorities to conduct any effective investigation into the applicant's allegations that his daughter was
trafficked.

300. In light of the circumstances of Ms Rantseva's subsequent death, the Court considers that the requirement
incumbent on the Cypriot authorities to conduct an effective investigation into the trafficking allegations is subsumed
by the general obligation arising under art 2 in the present case to conduct an effective investigation into Ms
Rantseva's death (see para 234 above). The question of the effectiveness of the investigation into her death has
been considered above in the context of the Court's examination of the applicant's complaint under art 2 and a
violation has been found. There is therefore no need to examine separately the procedural complaint against
Cyprus under art 4.

b. Russia

i. Positive obligation to put in place an appropriate legislative and administrative framework

301. The Court recalls that the responsibility of Russia in the present case is limited to the acts which fell within its
jurisdiction (see paras 207 to 208 above). Although the criminal law did not specifically provide for the offence of
trafficking at the material time, the Russian Government argued that the conduct about which the applicant
complained fell within the definitions of other offences.

302. The Court observes that the applicant does not point to any particular failing in the Russian criminal law
provisions. Further, as regards the wider administrative and legal framework, the Court emphasises the efforts of
the Russian authorities to publicise the risks of trafficking through an information campaign conducted through the
media (see para 262 above).

303. On the basis of the evidence before it, the Court does not consider that the legal and administrative framework
in place in Russia at the material time failed to ensure Ms Rantseva's practical and effective protection in the
circumstances of the present case.

ii. Positive obligation to take protective measures

304. The Court recalls that any positive obligation incumbent on Russia to take operational measures can only arise
in respect of acts which occurred on Russian territory (see, mutatis mutandis, Al-Adsani, cited above, paras 38 to
39).

305. The Court notes that although the Russian authorities appear to have been aware of the general problem of
young women being trafficked to work in the sex industry in foreign States, there is no evidence that they were
aware of circumstances giving rise to a credible suspicion of a real and immediate risk to Ms Rantseva herself prior
to her departure for Cyprus. It is insufficient, in order for an obligation to take urgent operational measures to arise,
merely to show that there was a general risk in respect of young women travelling to Cyprus on artistes' visas.
Insofar as this general risk was concerned, the Court recalls that the Russian authorities took steps to warn citizens
of trafficking risks (see para 262 above).

306. In conclusion, the Court does not consider that the circumstances of the case were such as to give rise to a
positive obligation on the part of the Russian authorities to take operational measures to protect Ms Rantseva.
There has accordingly been no violation of art 4 by the Russian authorities in this regard.

iii. Procedural obligation to investigate potential trafficking

307. The Court recalls that, in cases involving cross-border trafficking, trafficking offences may take place in the
country of origin as well as in the country of destination (see para 289 above). In the case of Cyprus, as the
Ombudsman pointed out in her report (see para 86 above), the recruitment of victims is usually undertaken by
artistic agents in Cyprus working with agents in other countries. The failure to investigate the recruitment aspect of


-----

alleged trafficking would allow an important part of the trafficking chain to act with impunity. In this regard, the Court
highlights that the definition of trafficking adopted in both the Palermo Protocol and the Anti-Trafficking Convention
expressly includes the recruitment of victims (see paras 150 and 164 above). The need for a full and effective
investigation covering all aspects of trafficking allegations from recruitment to exploitation is indisputable. The
Russian authorities therefore had an obligation to investigate the possibility that individual agents or networks
operating in Russia were involved in trafficking Ms Rantseva to Cyprus.

308. However, the Court observes that the Russian authorities undertook no investigation into how and where Ms
Rantseva was recruited. In particular, the authorities took no steps to identify those involved in Ms Rantseva's
recruitment or the methods of recruitment used. The recruitment having occurred on Russian territory, the Russian
authorities were best placed to conduct an effective investigation into Ms Rantseva's recruitment. The failure to do
so in the present case was all the more serious in light of Ms Rantseva's subsequent death and the resulting
mystery surrounding the circumstances of her departure from Russia.

309. There has accordingly been a violation by the Russian authorities of their procedural obligation under art 4 to
investigate alleged trafficking.
_VI. ALLEGED VIOLATION OF ARTICLE 5 OF THE CONVENTION_

310. The applicant complained that there was a violation of art 5(1) of the Convention by the Cypriot authorities in
so far as his daughter was detained at the police station, released into the custody of M.A. and subsequently
detained in the apartment of M.A.'s employee. Article 5(1) provides, inter alia, that:

“Everyone has the right to liberty and security of person. No one shall be deprived of his liberty save in the
following cases and in accordance with a procedure prescribed by law:

(a) the lawful detention of a person after conviction by a competent court;

(b) the lawful arrest or detention of a person for non-compliance with the lawful order of a court or in order
to secure the fulfilment of any obligation prescribed by law;

(c) the lawful arrest or detention of a person effected for the purpose of bringing him before the competent
legal authority on reasonable suspicion of having committed an offence or when it is reasonably
considered necessary to prevent his committing an offence or fleeing after having done so;

(d) the detention of a minor by lawful order for the purpose of educational supervision or his lawful
detention for the purpose of bringing him before the competent legal authority;

(e) the lawful detention of persons for the prevention of the spreading of infectious diseases, of persons of
unsound mind, alcoholics or drug addicts or vagrants;

(f) the lawful arrest or detention of a person to prevent his effecting an unauthorised entry into the country
or of a person against whom action is being taken with a view to deportation or extradition.”

A. The parties' submissions
_1. The applicant_

311. The applicant submitted that his daughter's treatment at the police station and subsequent confinement to the
apartment of M.A.'s employee violated art 5(1) of the Convention. He emphasised the importance of art 5 in
protecting individuals from arbitrary detention and abuse of power. Ms Rantseva was legally on the territory of the
Republic of Cyprus and was, the applicant contended, unreasonably and unlawfully detained by M.A., escorted to
the police station, released into M.A.'s custody and detained in the apartment of M.A.'s employee. He further
observed that no document had been produced by the Cypriot authorities setting out the grounds on which Ms
Rantseva had been detained and subsequently handed over to M.A..
_2. The Cypriot Government_

312. In their written submissions, the Cypriot Government denied that there had been a violation of art 5 in the
present case. They argued that it was not clear from the established facts of the case whether the police had


-----

exercised any power over Ms Rantseva. Nor was it clear what would have happened had Ms Rantseva refused to
leave with M.A..

313. In their unilateral declaration (see para 187 above), the Government accepted that Ms Rantseva's treatment at
the police station and the decision not to release her but to hand her over to M.A., even though there was no legal
basis for her deprivation of liberty, was not consistent with the requirements of art 5.

B. The Court's assessment
_1. The existence of a deprivation of liberty in the present case_

314. The Court reiterates that in proclaiming the “right to liberty”, art 5(1) aims to ensure that no-one should be
dispossessed of his physical liberty in an arbitrary fashion. The difference between restrictions on movement
serious enough to fall within the ambit of a deprivation of liberty under art 5(1) and mere restrictions of liberty which
are subject only to art 2 of Protocol No. 4 is one of degree or intensity, and not one of nature or substance
(Guzzardi v Italy _[[1980] ECHR 7367/76, para 93). In order to determine whether someone has been “deprived of his](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1B4-00000-00&context=1519360)_
liberty” within the meaning of art 5, the starting point must be her concrete situation and account must be taken of a
whole range of criteria such as the type, duration, effects and manner of implementation of the measure in question
(see Engel v Netherlands _[1976] ECHR 5100/71, paras 58-59; Guzzardi, para 92; and Riera Blume v Spain_ _[[1999]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0YJ-00000-00&context=1519360)_
_[ECHR 37680/97, para 28).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0YJ-00000-00&context=1519360)_

315. In the present case, the Court observes that the applicant was taken by M.A. to the police station where she
was detained for about an hour. There is no evidence that Ms Rantseva was informed of the reason for her
detention; indeed, as the Court has noted above (see para 297) there is no record that she was interviewed by the
police at all during her time at the police station. Despite the fact that the police concluded that Ms Rantseva's
immigration status was not irregular and that there were no grounds for her continued detention, she was not
immediately released. Instead, at the request of the person in charge of the Aliens and Immigration Service (“AIS”),
the police telephoned M.A. and requested that he collect her and take her to the AIS office at 7 a.m. for further
investigation. M.A. was advised that if he did not collect her, she would be allowed to leave. Ms Rantseva was
detained at the police station until M.A.'s arrival, when she was released into his custody (see para 20 above).

316. The facts surrounding Ms Rantseva's subsequent stay in M.P.'s apartment are unclear. In his witness
statement to the police, M.A. denied that Ms Rantseva was held in the apartment against her will and insists that
she was free to leave (see para 21 above). The applicant alleges that Ms Rantseva was locked in the bedroom and
was thus forced to attempt an escape via the balcony. The Court notes that Ms Rantseva died after falling from the
balcony of the apartment in an apparent attempt to escape (see para 41 above). It is reasonable to assume that
had she been a guest in the apartment and was free to leave at any time, she would simply have left via the front
door (see _Storck v Germany_ _[[2005] ECHR 61603/00, paras 76-78). Accordingly, the Court considers that Ms](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X2TN-00000-00&context=1519360)_
Rantseva did not remain in the apartment of her own free will.

317. In all, the alleged detention lasted about two hours. Although of short duration, the Court emphasises the
serious nature and consequences of the detention and recalls that where the facts indicate a deprivation of liberty
within the meaning of art 5(1), the relatively short duration of the detention does not affect this conclusion (see
_Järvinen v Finland [1998] ECHR 30408/96, Commission decision of 15 January 1998; and_ _Novotka v Slovakia_

[2003] ECHR 47244/99, 4 November 2003, where the transportation to the police station, search and temporary
confinement in a cell lasting around one hour was considered to constitute a deprivation of liberty for the purposes
of art 5).

318. Accordingly, the Court finds that the detention of Ms Rantseva at the police station and her subsequent
transfer and confinement to the apartment amounted to a deprivation of liberty within the meaning of art 5 of the
Convention.
_2. Responsibility of Cyprus for the deprivation of liberty_

319. In so far as Ms Rantseva was detained by private individuals, the Court must examine the part played by the
police officers and determine whether the deprivation of liberty in the apartment engaged the responsibility of the


-----

Cypriot authorities, in particular in light of their positive obligation to protect individuals from arbitrary detention (see
_Riera Blume, cited above, paras 32-35)._

320. The Court has already expressed concern that the police chose to hand Ms Rantseva into M.A.'s custody
rather than simply allowing her to leave (see para 298 above). Ms Rantseva was not a minor. According to the
evidence of the police officers on duty, she displayed no signs of drunkenness (see para 20 above). It is insufficient
for the Cypriot authorities to argue that there is no evidence that Ms Rantseva did not consent to leaving with M.A.:
as the AIRE Centre pointed out (see para 269 above), victims of trafficking often suffer severe physical and
psychological consequences which render them too traumatised to present themselves as victims. Similarly, in her
2003 report the Ombudsman noted that fear of repercussions and inadequate protection measures resulted in a
limited number of complaints being made by victims to the Cypriot police (see paras 87 to 88 above).

321. Taken in the context of the general living and working conditions of cabaret artistes in Cyprus, as well as in
light of the particular circumstances of Ms Rantseva's case, the Court considers that it is not open to the police to
claim that they were acting in good faith and that they bore no responsibility for Ms Rantseva's subsequent
deprivation of liberty in M.P.'s apartment. It is clear that without the active cooperation of the Cypriot police in the
present case, the deprivation of liberty could not have occurred. The Court therefore considers that the national
authorities acquiesced in Ms Rantseva's loss of liberty.
_3. Compatibility of the deprivation of liberty with art 5(1)_

322. It remains to be determined whether the deprivation of liberty fell within one of the categories of permitted
detention exhaustively listed in art 5(1). The Court reiterates that art 5(1) refers essentially to national law and lays
down an obligation to comply with its substantive and procedural rules. It also requires, however, that any measure
depriving the individual of his liberty must be compatible with the purpose of art 5, namely to protect the individual
from arbitrariness (see Riera Blume, cited above, para 31).

323. By laying down that any deprivation of liberty should be “in accordance with a procedure prescribed by law”,
art 5(1) requires, first, that any arrest or detention should have a legal basis in domestic law. The Cypriot
Government did not point to any legal basis for the deprivation of liberty but it can be inferred that Ms Rantseva's
initial detention at the police station was effected in order to investigate whether she had failed to comply with
immigration requirements. However, having ascertained that Ms Rantseva's name was not included on the relevant
list, no explanation has been provided by the Cypriot authorities as to the reasons and legal basis for the decision
not to allow Ms Rantseva to leave the police station but to release her into the custody of M.A.. As noted above, the
police found that Ms Rantseva did not exhibit signs of drunkenness and did not pose any threat to herself or others
(see paras 20 and 320 above). There is no indication, and it has not been suggested, that Ms Rantseva requested
that M.A. come to collect her. The decision of the police authorities to detain Ms Rantseva until M.A.'s arrival and,
subsequently, to consign her to his custody had no basis in domestic law.

324. It has not been argued that Ms Rantseva's detention in the apartment was lawful. The Court finds that this
deprivation of liberty was both arbitrary and unlawful.

325. The Court therefore concludes that there has been a violation of art 5(1) on account of Ms Rantseva's unlawful
and arbitrary detention.
_VII. ALLEGED VIOLATION OF ARTICLE 6 OF THE CONVENTION_

326. The applicant contended that the Cypriot authorities violated his right of access to court under art 6 of the
Convention by failing to ensure his participation in the inquest proceedings, by failing to grant him free legal aid and
by failing to provide him with information on available legal remedies in Cyprus. Article 6 provides, in so far as
relevant, as follows:

“In the determination of his civil rights and obligations ... everyone is entitled to a fair ... hearing ... by [a] ...
tribunal ...”

A. The parties' submissions
_1. The applicant_


-----

327. The applicant highlighted the importance of the right of access to court in a democratic society. Such a right
entailed an opportunity for an individual to have a clear, practical opportunity to challenge an act which interfered
with his rights. The applicant pointed out that there had been no trial in respect of his daughter's death. He further
complained about the failure of the Cypriot authorities to ensure his effective participation in the inquest
proceedings and to provide free legal assistance. Accordingly, he submitted, the Cypriot authorities had violated his
right of access to court guaranteed under art 6 of the Convention.
_2. The Cypriot Government_

328. In their written observations, the Cypriot Government submitted that art 6 did not apply to inquest proceedings
as they were not proceedings that determined civil rights and obligations. Accordingly, the applicant could not claim
a right of access to the proceedings in respect of his daughter's death.

329. If, on the other hand, inquest proceedings did engage art 6, the Cypriot Government contended that the
applicant's right of access to court was ensured in the present case.

330. In their subsequent unilateral declaration (see para 187 above), the Cypriot Government acknowledged a
violation of the applicant's right to an effective access to court by the failure of the Cypriot authorities to establish
any real and effective communication between them and the applicant as regards the inquest and any other
possible legal remedies available to the applicant.

B. Admissibility

331. The Court observes at the outset that art 6 does not give rise to a right to have criminal proceedings instituted
in a particular case or to have third parties prosecuted or sentenced for a criminal offence (see, for example,
_Rampogna and Murgia v Italy [1999] ECHR 40753/98, 11 May 1999; Perez v France_ _[[2004] ECHR 47287/99, para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3V6-00000-00&context=1519360)_
70; and _Dinchev v Bulgaria_ _[[2009] ECHR 23057/03, para 39, 22 January 2009). To the extent that the applicant](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7R1-DYBP-X4PT-00000-00&context=1519360)_
complains under art 6(1) about the failure of the Cypriot authorities to bring criminal proceedings in respect of his
daughter's death, his complaint is therefore inadmissible ratione materiae and must be rejected under art 35 paras
3 and 4 of the Convention.

332. As regards the complaint regarding participation in the inquest proceedings, the Court observes that
procedural guarantees in inquest proceedings are inherent in art 2 of the Convention and the applicant's complaints
have already been examined in that context (see para 239 above). As to the applicability of art 6 to inquest
proceedings, the Court considers there is no criminal charge or civil right at stake for the applicant in the context of
such proceedings. Accordingly, this part of the complaint is also inadmissible ratione materiae and must be rejected
under art 35 paras 3 and 4 of the Convention.

333. Finally, as regards the applicant's complaints that he was not informed of other remedies available to him and
was not provided with free legal assistance, when the cost of legal representation in Cyprus was prohibitive, the
Court considers that these complaints are inherently linked to the applicant's complaint under art 2 of the
Convention and recalls that they have been addressed in that context (see para 240 above). It is therefore not
necessary to consider the extent to which any separate issue may arise under art 6 in such circumstances.

334. Accordingly, the complaints under art 6(1) must be declared inadmissible and rejected in accordance with art
35 paras 3 and 4 of the Convention.
_VIII. ALLEGED VIOLATION OF ARTICLE 8 OF THE CONVENTION_

335. The applicant also invoked art 8 of the Convention, which provides as follows:

“1. Everyone has the right to respect for his private and family life, his home and his correspondence.

2. There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security,
public safety or the economic well-being of the country, for the prevention of disorder or crime, for the
protection of health or morals, or for the protection of the rights and freedoms of others.”


-----

336. The applicant has provided no further details of the nature of his complaint under this Article. In the light of all
the material in its possession, and in so far as the matters complained of were within its competence, the Court
finds no appearance of a violation of the rights and freedoms set out in the Convention or its Protocols arising from
this complaint. The complaint must therefore be declared inadmissible pursuant to art 35 paras 3 and 4 of the
Convention.
_IX. APPLICATION OF ARTICLE 41 OF THE CONVENTION_

337. Article 41 of the Convention provides:

“If the Court finds that there has been a violation of the Convention or the Protocols thereto, and if the
internal law of the High Contracting Party concerned allows only partial reparation to be made, the Court
shall, if necessary, afford just satisfaction to the injured party.”

Damage
_1. The parties' submissions_

338. The applicant sought EUR 100,000 in respect of non-pecuniary damage resulting from the death of his
daughter. He pointed to the serious nature of the alleged violations in the present case and the fact that his
daughter was the sole provider for the family. He also highlighted the emotional anguish occasioned by his
daughter's death and his subsequent efforts to bring those responsible to justice.

339. The Cypriot Government argued that the sum claimed was excessive, having regard to the Court's case-law.
They further pointed out that the applicant had provided no evidence that he was financially dependent upon his
daughter. In their unilateral declaration (see para 187 above), they offered to pay the applicant EUR 37,300 in
respect of pecuniary and non-pecuniary damage and costs and expenses, or such other sum as suggested by the
Court.

340. The Russian Government submitted that any non-pecuniary damages should be paid by the State which failed
to ensure the safety of the applicant's daughter and failed to perform an effective investigation into her death. They
noted that they were not the respondent State as far as the applicant's substantive art 2 complaint was concerned.
_2. The Court's assessment_

341. The Court notes that a claim for loss of economic support is more appropriately considered as a claim for
pecuniary loss. In this respect, the Court reiterates that there must be a clear causal connection between the
damage claimed by the applicant and the violation of the Convention and that this may, in the appropriate case,
include compensation in respect of loss of earnings (see, inter alia, Aktaş v Turkey _[[2003] ECHR 24351/94, para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7R1-DYBP-X4KH-00000-00&context=1519360)_
352(extracts)). In the present case the Court has not found Cyprus responsible for Mr Rantseva's death, holding
that there was a procedural, and not a substantive, violation of art 2 in the present case. Accordingly, the Court
does not consider it appropriate to make any award to the applicant in respect of pecuniary damage arising from Ms
Rantseva's death.

342. As regards non-pecuniary damage, the Court has found that the Cypriot authorities failed to take steps to
protect Ms Rantseva from trafficking and to investigate whether she had been trafficked. It has further found that the
Cypriot authorities failed to conduct an effective investigation into Ms Rantseva's death. Accordingly, the Court is
satisfied that the applicant must be regarded as having suffered anguish and distress as a result of the unexplained
circumstances of Ms Rantseva's death and the failure of the Cypriot authorities to take steps to protect her from
trafficking and exploitation and to investigate effectively the circumstances of her arrival and stay in Cyprus. Ruling
on an equitable basis, the Court awards the sum of EUR 40,000 in respect of the damage sustained by the
applicant as a result of the conduct of the Cypriot authorities, plus any tax that may be chargable on that amount.

343. The Court recalls that it has found a procedural violation of art 4 in respect of Russia. Ruling on an equitable
basis, it awards the applicant EUR 2,000 in non-pecuniary damage in respect of the damage sustained by him by
the conduct of the Russian authorities, plus any tax that may be chargable on that amount.

Costs and expenses


-----

_1. The parties' submissions_

344. The applicant requested reimbursement of costs and expenses incurred in the sum of around 485,480 Russian
roubles (RUB) (approximately EUR 11,240), including travel, photocopying, translation and services of a notary.
The sum also included the sum of RUB 233,600 in respect of the sale of his home in Russia, which he claimed was
necessary in order to obtain necessary funds; funeral costs in the sum of about RUB 46,310; and RUB 26,661
spent on attending a conference on trafficking in Cyprus in 2008. Relevant receipts were provided.

345. The Cypriot Government argued that the applicant could only claim for costs which were necessarily incurred
to prevent or redress a breach of the Convention, reasonable as to quantum and causally linked to the violation in
question. As such, they contested the applicant's claim of RUB 233,600 in respect of the sale of his flat, the sums
expended on attending the 2008 conference and any costs and expenses not substantiated by receipts or not
reasonable as to quantum.

346. The Russian Government contended that the applicant had failed to substantiate his allegation that he was
required to sell his flat and travel to Cyprus. In particular, they submitted that the applicant could have applied to
relevant law enforcement authorities in Russia to request necessary documents and evidence from the Cypriot
authorities and could have instructed a lawyer in Cyprus. The Russian Government also contested the applicant's
claim for the costs of the 2008 conference on the ground that it was not directly linked to the investigation of Ms
Rantseva's death.
_2. The Court's assessment_

347. The Court recalls that the applicant is entitled to the reimbursement of costs and expenses in so far as it has
been shown that these have been actually and necessarily incurred and are reasonable as to quantum. In the
present case, the applicant is not entitled to claim the proceeds of the sale of his house or for the expenses of
travelling to the conference in Cyprus in 2008, such conference not being directly linked to the investigation of Ms
Rantseva's death. Further, the Court recalls that it found only a procedural breach of art 2. Accordingly, the
applicant is not entitled to reimbursement of funeral expenses.

348. Having regard to the above, the Court considers it reasonable to award the sum of EUR 4,000 in respect of
costs and expenses plus any tax that may be chargeable to the applicant on that amount, less EUR 850 received
by way of legal aid from the Council of Europe. In the circumstances of this case the Court considers it appropriate
that the costs and expenses are awarded against Cyprus.

C. Default interest

349. The Court considers it appropriate that the default interest should be based on the marginal lending rate of the
European Central Bank, to which should be added three percentage points.
**FOR THESE REASONS, THE COURT UNANIMOUSLY**

1. Rejects the Cypriot Government's request to strike the application out of the list;

2. Decides to join to the merits the Russian Government's objection ratione materiae as to art 4 of the Convention,
and rejects it;

3. Declares the complaints under arts 2, 3, 4 and 5 admissible and the remainder of the application inadmissible.

4. Holds that there has been no violation of the Cypriot authorities' positive obligation to protect Ms Rantseva's right
to life under art 2 of the Convention;

5. Holds that there has been a procedural violation of art 2 of the Convention by Cyprus because of the failure to
conduct an effective investigation into Ms Rantseva's death;

6. Holds that there has been no violation of art 2 of the Convention by Russia;

7. Holds that it is not necessary to consider separately the applicant's complaint under art 3 of the Convention;


-----

8. _Holds that there has been a violation of art 4 of the Convention by Cyprus by not affording to Ms Rantseva_
practical and effective protection against trafficking and exploitation in general and by not taking the necessary
specific measures to protect her;

9. Holds that there is no need to examine separately the alleged breach of art 4 concerning the continuing failure of
the Cypriot authorities to conduct an effective investigation;

10. Holds that there has been no breach by Russia of its positive obligations under art 4 of the Convention to take
operational measures to protect Ms Ranseva against trafficking;

11. _Holds that there has been a violation of art 4 of the Convention by Russia of its procedural obligations to_
investigate the alleged trafficking;

12. Holds that there has been a violation of art 5 of the Convention by Cyprus;

13. Holds

(a) that the Cypriot Government is to pay the applicant, within three months from the date on which the judgment
becomes final in accordance with art 44(2) of the Convention, EUR 40,000 (forty thousand euros) in respect of nonpecuniary damage and EUR 3,150 (three thousand one hundred and fifty euros) in respect of costs and expenses,
plus any tax that may be chargeable to the applicant on these amounts;

(b) that the Russian Government is to pay the applicant, within three months from the date on which the judgment
becomes final in accordance with art 44(2) of the Convention, EUR 2,000 (two thousand euros) in respect of nonpecuniary damage, to be converted into Russian roubles at the rate applicable at the date of settlement, plus any
tax that may be chargeable to the applicant on this amount;

(c) that from the expiry of the above-mentioned three months until settlement simple interest shall be payable on the
above amounts at a rate equal to the marginal lending rate of the European Central Bank during the default period
plus three percentage points;

14. Dismisses the remainder of the applicant's claim for just satisfaction.

**End of Document**


-----

