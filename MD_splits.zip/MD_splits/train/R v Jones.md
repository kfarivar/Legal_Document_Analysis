# R v Jones [2019] EWCA Crim 2050

CA, CRIMINAL DIVISION

2019/01615/A3 & 2019/02969/A3

Bean LJ, Laing J, Sir Nicholas Blake

19 November 2019

19/11/2019

Tuesday 19[th] November 2019

**LORD JUSTICE BEAN: I shall ask Mrs Justice Elisabeth Laing to give the judgment of the court.**

MRS JUSTICE ELISABETH LAING:

Introduction

1. This is, in the case of Daniel Jones, an appeal against sentence brought with the leave of the single judge. We
are also considering an application by his son Terence Jones for leave to appeal against sentence, which was
referred to the full court by the Registrar, once leave to appeal had been granted to Daniel Jones. Terence Jones
also requires an extension of time.

2. This morning Mr Lamb has represented Daniel Jones and Mr Morrison has represented Terence Jones. We are
grateful to both counsel, who also settled the Advice and Grounds of Appeal.

3. On 15[th] January 2019, in the Crown Court at Durham, Daniel and Terence Jones changed their pleas to guilty to
one count of kidnapping.

4. On 4[th] April 2019, His Honour Judge Carroll sentenced Daniel Jones to 75 months and two weeks' immediate
imprisonment and Terence Jones to four years and six months' immediate imprisonment. The judge made victim
surcharge orders in both cases in the sum of £170. Both were made subject to restraining orders for a period of ten
years.

5. Count 1 on the indictment (requiring a person to perform forced or compulsory labour) was ordered to lie on the
file against Daniel Jones. An offence of assault occasioning actual bodily harm was also ordered to lie on the file
against both defendants. Margaret Harker changed her plea to guilty to a count of assault occasioning actual bodily
harm and was sentenced to 23 weeks' imprisonment, suspended for eighteen months. Count 1 (kidnapping) was
ordered to lie on the file against her.

The facts

6. The complainant, Mr Paul Wakefield, lived in a caravan provided by Daniel Jones, for whom he had been
working. For an unknown reason, Mr Wakefield ran away from the caravan. He went to his mother's home, which
was nearby. She was not there. He then went to a friend's home, at about 8pm on 22[nd] July 2018. At first, he
asked for help. Then he left, but came running back again, saying that "they" were after him. Daniel and Terence
Jones then forced their way into the friend's home and dragged Mr Wakefield out of the house. They attacked him


-----

and knocked him out. They picked him up and bundled him into a van which was driven by Daniel Jones' wife,
Margaret Harker. The van was then driven away, back to Daniel Jones' home. Mr Wakefield was punched in the
van by Terence Jones and by Margaret Harker. Daniel Jones encouraged them, saying "Just give it to him". They
took Mr Wakefield back to the caravan where he was staying and threatened him with violence if he tried to escape.

7. The following day a Nissan Micra was stopped by the police. Daniel Jones, Margaret Harker and Mr Wakefield
were inside the car. Mr Wakefield was taken into the protection of the police. As a result of the assault, Mr
Wakefield suffered a black eye, bruised ribs, a cut to his lips consistent with having been punched, and bruising to
his ear and chest.

8. There was a Victim Impact Statement before the Crown Court from Mr Wakefield.

9. Daniel Jones is now 46. He had appeared before the courts on 35 previous occasions for 75 offences between
1988 and 2017. Most of his convictions were for driving offences. Offences for which he received custodial
sentences were common assault and threatening behaviour in 1992; robbery and theft in 1993, for which he
received a sentence of 21 months' detention in a young offender institution; and dwelling house burglaries, for
which he was sentenced to 21 months' imprisonment in 1995, and to 30 months' imprisonment in 1999. His other
offences included using a false instrument, criminal damage, possessing an offensive weapon, handling stolen
goods, and breach of court orders.

10. Terence Jones is aged 26. He had appeared before the courts on fifteen previous occasions for 30 offences
between 2010 and 2018. In 2012 he was sentenced to 30 months' detention in a young offender institution for an
offence of wounding with intent, contrary to section 18 of the Offences against the Person Act 1861. He had also
received custodial sentences for dangerous driving and for harassment. His other offences included driving
offences, breaches of court orders, threatening behaviour, battery and criminal damage.

11. There were no pre-sentence reports before the sentencing judge.

The sentencing remarks

12. The judge referred to the defendants' previous convictions. He noted that count 1 on the indictment (which
related to an offence of what is called "modern slavery"), had not been pursued by the prosecution. The judge
said that he expressly and completely put out of his mind the possibility that Mr Wakefield had been a victim of
“modern slavery” and would be true to the pleas that had been accepted by the prosecution.

13. The judge said that Mr Wakefield had been kidnapped for some reason; people do not go around kidnapping
people for no reason. It was clear that Daniel Jones, the father of Terence Jones, was the leading light in the
offence. He would not explain why Mr Wakefield had been kidnapped and so the judge had to sentence in the dark
as to why the offence had been committed. That suggested to the judge that there was no meaningful remorse
whatsoever.

14. The judge then described the circumstances of the offence. He said that the kidnap had lasted about 24 hours
or so. He then described the injuries which Mr Wakefield had suffered. He said that the victim impact statement
made it clear that Mr Wakefield was extremely frightened and continued to live in fear of his own safety. He had
been moved out of County Durham for his own safety. That had taken him away from his family. He had had to
start a fresh life somewhere else. He intended to stay in this new place for the foreseeable future. The judge said
that this was an extremely serious offence. He then described the defendants' previous convictions.

15. The judge then considered whether there was any mitigation. He noted again that counsel had said nothing
about the circumstances of the offence or the reasons for it. Daniel Jones had "fallen on his sword". It was all
down to him, and it was his fault that he had involved his son and his wife. He had asked for ten per cent credit for
his plea of guilty on the day of the trial. Terence Jones had asked for the same credit and had pointed out that he
held a subordinate role to that of his father.


-----

16. The judge said that he had been referred to a number of authorities. He referred in particular to the decision of
this court in R v Spence and Thomas (1983) 5 Cr App R(S) 413. In that case the Court of Appeal had indicated that
there was a wide possible variation in seriousness between one possible incident and another. At the top of the
scale were carefully planned abductions, where the victim is used as a hostage or where ransom money was
demanded. Such offences would seldom be met with less than eight years' imprisonment. Where violence or
firearms were used, or there were other exacerbating features such as detention of the victim for a long period, the
proper sentence would be very much longer than that. At the other end of the scale were offences which could
perhaps be scarcely classed as kidnapping at all. They often arose out of family tiffs or lovers' disputes and they
seldom required anything more than a sentence of eighteen months' imprisonment or less.

17. The judge then referred to the 13[th] edition of Banks on Sentence, which made the point that in recent times the
level of sentencing for this type of case appears to have increased. The judge said that there could be no
conclusion other than that the kidnap had been planned, whatever the reason for it was. It was not spontaneous.
Considerable violence had been used, to the extent of knocking the victim unconscious. Two parties were involved
in the kidnap itself, and the third offender was in the getaway vehicle. The kidnap, as he had said, lasted about 24
hours. It was a serious example of its type.

18. The judge said that the starting point on count 2 for Daniel Jones was seven years' imprisonment. He gave a
discount for the guilty plea of ten per cent and sentenced him to 75 months and two weeks' imprisonment.

19. The judge took a starting point for Terence Jones, reflecting his lesser role, of five years' imprisonment. He
gave a discount of ten per cent for his guilty plea and sentenced him to 54 months' imprisonment.

20. The grounds of appeal in each case are very brief. Mr Lamb, on behalf of Daniel Jones, asserted that the
sentence was "too excessive". Mr Morrison adopted Mr Lamb's ground and made a further point, which as we
understood it, was that if Daniel Jones' sentence was manifestly excessive, a proportionate adjustment should be
made to Terence's sentence.

21. In his commendably succinct oral submissions, Mr Lamb referred to the decision of this court in Spence and
_Thomas (the case to which the judge referred in his sentencing remarks). Mr Morrison, who expanded somewhat_
on the submissions that had been made by Mr Lamb, described the two extremes of a spectrum for sentencing in
such cases, which were referred to by the Court of Appeal in Spence and Thomas. His submission was that this
case was at the lower end of that spectrum. He further submitted that Terence Jones' help to his father indicated a
lesser degree of culpability than that of his father. He had acted under direction; he had no involvement with the
victim; he had no plan; and he had not benefited from the offence in any way. Mr Morrison also suggested that he
might have some quarrel with the credit given for the guilty plea, although, given that the judge said that that was
the credit for which the defence had asked, it is not entirely clear why.

Discussion

22. The judge's sentencing remarks are careful and considered. He was not helped in this case by any definitive
guideline from the Sentencing Council. He obtained such help as he could from potentially relevant decisions of
this court, although none was exactly in point.

23. Mr Wakefield had a terrifying experience. He was dragged out of a friend's house, beaten until he lost
consciousness, and bundled into a van. He was hit more than once in the van. His ordeal lasted 24 hours. He was
not to know at any point during that ordeal how long it would last. He was still so frightened that he has had to
leave County Durham and move to a completely new area. The judge was right to see Daniel Jones as the
instigator of the offence by a margin which was reflected in the different sentences which he passed on Daniel and
on Terence Jones.

24. On these facts we do not consider that either sentence was manifestly excessive or arguably so. We dismiss
Daniel Jones' appeal against sentence and we refuse Terence Jones' application for leave to appeal against
sentence. That makes it unnecessary for us to deal with his application for an extension of time.


-----

_

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18-22 Furnival

Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

