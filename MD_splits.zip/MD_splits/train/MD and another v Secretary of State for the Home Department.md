# MD and another v Secretary of State for the Home Department [2022] EWCA
 Civ 336

Court of Appeal, Civil Division

Underhill VP, Asplin and Simler LJJ

16 March 2022Judgment

**Robin Tam QC and Jack Anderson (instructed by the Treasury Solicitor) for the Appellant**

**Chris Buttler QC and Ayesha Christie (instructed by Simpson Millar and Deighton Peirce Glynn) for**
the Respondents

Hearing dates: 2 & 3 November 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Underhill:**

**INTRODUCTION**

1. This appeal arises out of two claims against the Secretary of State for the Home Department which
were heard together in the Administrative Court. The Claimants in both cases, who are the Respondents
before us, are Albanian single mothers who were trafficked to this country for sexual exploitation and have
been formally recognised as victims of trafficking. The process of recognition involves two stages – first
when it is decided that there are reasonable grounds to believe that the person in question is a victim of
trafficking (a so-called “potential” victim) and secondly when a “conclusive grounds” decision is made (what
I will call a “confirmed” victim). As victims of trafficking they are entitled to anonymity: see sections 1 and 2
[(1) (db) of the Sexual Offences (Amendment) Act 1992.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)

2. From the date of the reasonable grounds decisions in their cases both Claimants were entitled to
financial support funded by the Home Office under the arrangements of which I give details below (“VoT
support”). Both also sought asylum under the Refugee Convention (which has since been granted): in that
capacity they were entitled to support under the statutory regime applying to asylum-seekers (“asylumseeker support”) of which, again, I give details below.

3. The claims in these proceedings arise out of the interaction of those two support regimes with each
other and also with the provisions relating to entitlement to so-called “mainstream” social security benefits,
i.e. either universal credit or one of the “legacy benefits” which it has now largely replaced. They cannot
sensibly be summarised until I have explained the applicable provisions. It is enough to note at this stage
that the Claimants say that the way in which the regimes impacted on them constituted discrimination in
breach of their rights under article 14 of the European Convention on Human Rights (“the ECHR”) and was
[accordingly unlawful under section 6 (1) of the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

4. By a decision handed down on 24 May 2021 Kerr J upheld the claims of unlawful discrimination and
awarded declaratory relief. He also held that the Claimants were entitled to damages under section 8 of


-----

the 1998 Act and directed that the quantum of damages be determined at a further hearing: that hearing
has been deferred pending the outcome of this appeal. I give further details of his decision below.

5. The Secretary of State has not sought to appeal against the decision that there was a breach of the
Claimants' Convention rights; but she appeals, with permission granted by Holroyde LJ, against one of the
bases on which discrimination was found and against the decision that they are entitled to damages.

6. The Claimants have been represented by Mr Chris Buttler QC and Ms Ayesha Christie, and the
Secretary of State by Mr Robin Tam QC and Mr Jack Anderson. The same counsel appeared before Kerr
J. Although for convenience I will refer to the parties' skeleton arguments as though they were the work of
leading counsel alone, I am sure that that is far from being the case. The case was very well argued on
both sides.

7. The questions raised by this appeal are essentially issues of technical legal analysis and it is on those
that this judgment will focus. But it should not be thought that the Court is unaware of what the Claimants
have suffered as a result of their experiences, which include violent rape and forced prostitution, or of their
difficulties in adjusting to a new country, particularly as single mothers. Both suffer from post-traumatic
stress disorder (“PTSD”) and associated mental health problems.

**THE FINANCIAL SUPPORT REGIMES**

8. I start by summarising the relevant provisions of the regimes for trafficking and asylum-seeker support
and the provisions governing their relationship with entitlement to mainstream benefits. The provisions in
question were subject to some changes over the period covered by the two claims, which is from January
2018 to February 2021 (see para. 47 below). Although the VoT support regime is the main focus of the
claims, it is best to start with the asylum-seeker regime, which came first.

ASYLUM-SEEKER SUPPORT

9. Part VI of the Immigration and Asylum Act 1999 specifies the kinds of support available to “asylumseekers”, defined in section 94 as persons over 18 who have made a claim for asylum which has been
recorded by the Secretary of State but which has not yet been determined. “Claim for asylum” is defined to
cover claims relying on article 3 of the ECHR as well as claims relying on the Refugee Convention.

10. Section 95 (1) empowers the Secretary of State to provide, or arrange for the provision of, support for:

“(a) asylum-seekers, or

(b)  dependants of asylum-seekers,

who appear to the Secretary of State to be destitute or to be likely to become destitute …”.

Subsection (3) provides:

“For the purposes of this section, a person is destitute if —

(a)  he does not have adequate accommodation or any means of obtaining it (whether or not his other
essential living needs are met); or

(b)  he has adequate accommodation or the means of obtaining it, but cannot meet his other essential
living needs.”

The concept of “essential living needs” which underlies section 95 (3) is important in the arguments before
us.

11. Section 96 (1) provides for ways in which support under section 95 may be provided. These include
(at (a)) the provision of accommodation and (at (b)) the provision of essential living needs. By section 94
(2) references to provision of support in Part VI include support provided under arrangements made by the
Secretary of State under section 95.

12. Section 98 empowers the Secretary of State to afford temporary support to asylum-seekers and their
dependants who may be destitute pending a decision as to whether they are in fact entitled to support


-----

under section 95; and section 4 provides for support for failed asylum-seekers. No point arises in this
appeal about either section, but I mention them because they are referred to in other provisions to which I
shall have to refer.

13. Section 95 (12) gives effect to Schedule 8 of the Act, which empowers the Secretary of State to make
regulations supplementing the section. Pursuant to that power, the Secretary of State has made the
Asylum Support Regulations 2000. The relevant provisions for our purposes are regulations 10 and 10A.

14. Regulation 10 is concerned with essential living needs and reads (so far as relevant):

“(1) This regulation applies where the Secretary of State has decided that asylum support should be
provided in respect of the essential living needs of a person.

(2)  As a general rule, asylum support in respect of the essential living needs of that person may be
expected to be provided weekly in the form of a cash payment of [a specified amount].

(3)-(5)…”

I will refer to a payment under regulation 10 (2) as an “essential living needs payment”.

15. Regulation 10A (1) provides for additional weekly amounts to be paid to pregnant women or to parents
of children aged under 3.

16. It is convenient to refer to payments under regulations 10 (2) and 10A (1) as entitlements, though of
course they are payable only if the Secretary of State believes that the recipients are destitute or likely to
become destitute – and even then it is only a “general rule” that support will be provided in the form of a
weekly cash payment.

17. The amount of the essential living needs payment specified in regulation 10 (2) has varied over the
period with which we are concerned. The relevant figures are:

Prior to 6.2.18    £36.95

6.2.18-14.6.20    £37.75

15.6.20-21.2.21    £39.60

22.2.21-20.2.22    £39.63

The additional amounts specified in regulation 10A (1) have remained the same throughout at £3 for a
pregnant woman, £5 for a child up to the age of 1, and £3 for a child up to the age of 3.

18. The persons entitled to essential living needs payments under regulation 10 (2) include dependants of
asylum-seekers. Thus an asylum-seeker with a dependent child will receive (at current rates) £39.63 for
themselves and the same amount for the child (together with any entitlement under regulation 10A (1)). I
will refer to sums paid to asylum-seekers in respect of their dependent children as “asylum-seeker
dependent child support”.

VoT SUPPORT

Background

19. Article 12.1 of the European Convention on Action against Trafficking in Human Beings (“ECAT”),
which the UK ratified on 17 December 2008 with effect from 1 April 2009, begins:

“Each Party shall adopt such legislative or other measures as may be necessary to assist victims [of
trafficking] in their physical, psychological and social recovery. Such assistance shall include, at least:

“(a)  standards of living capable of ensuring their subsistence, through such measures as: appropriate
and secure accommodation, psychological and material assistance

(b)-(f) …”


-----

(Heads (b)-(f) are concerned with various specific services which are not relevant for our purposes.) It will
be seen that assistance with “physical, psychological and social recovery” is the central concept, and it
also underlies article 13, which requires all potential victims of trafficking to be accorded a minimum period
for “recovery and reflection”. A common shorthand for the needs which article 12.1 requires to be
addressed is “recovery needs”. “Material assistance” is likely to require at least a degree of financial
support.

20. Paragraph 2 of article 11 of EU Directive 2011/36/EU (the so-called “Anti-Trafficking Directive”), which
became effective in the UK from 6 April 2013, requires member states to “take the necessary measures to
ensure that a person is provided with assistance and support as soon as the competent authorities have a
reasonable-grounds indication for believing that the person might [be a victim of trafficking]”. Paragraph 4
requires them to “establish appropriate mechanisms aimed at … assistance to and support for victims”;
and paragraph 5 provides that such assistance and support “shall include at least standards of living
capable of ensuring victims' subsistence through measures such as the provision of appropriate and safe
accommodation and material assistance”. Those provisions are to substantially the same effect as article
12 of ECAT (see the analysis in MN v Secretary of State for the Home Department _[2020] EWCA Civ 1746,_

[2021] 1 WLR 1956).

21. The UK has sought to implement the relevant obligations under ECAT (and, in due course, the
Directive) not through legislation but by administrative policy. Specifically, what the Government has done
(as regards England and Wales) is to enter into contractual arrangements with the Salvation Army for the
provision of specified services. Those services include the provision, where necessary, both of
accommodation and of cash payments by way of “subsistence”. The arrangements were originally under a
contract referred to as “the Victim Care Contract” (“the VCC”), but more recently as “the Modern Slavery
Victim Care Contract” (“the MSVCC”). A version of the contract has been in place since 2009, when the
party contracting on behalf of the Government was the Secretary of State for Justice, but it has been
renewed from time to time. The version with which we are concerned was entered into in 2015, the
Government party named being the Secretary of State for the Home Department.

22. Again, for convenience I will sometimes refer to payments made in accordance with those
arrangements as “entitlements” or the like, even though they are paid by way of administrative policy rather
than pursuant to any statutory obligation.

The VCC

23. Initially there was no formal statement of policy setting out the arrangements made by the Secretary of
State pursuant to article 12.1 (a) of ECAT and the equivalent provisions of the Directive: they could only be
found by referring to the relevant provisions of the VCC.

24. At the start of the period with which we are concerned para. F-001 of Schedule 2 to the VCC provided
for weekly “subsistence payments” to be made to adult potential victims of trafficking, described as
“Service Users”, in accordance with a table defining the amounts by reference to “Service User Type”. We
are concerned only with the third row of the table, which specifies the payments for service users
“accommodated by the Authority and in receipt of subsistence payments through that service”: the amount
payable in such a case is “£65 minus the amount of subsistence received by the Authority”. “The
Authority” is a reference to the Secretary of State. It is common ground that the reference to “the amount
of subsistence received by the Authority” is a slip for “from the Authority”. Even as corrected, the language
is rather opaque, but it is not in dispute that the effect is to require the deduction of sums received under
the Asylum Support Regulations by victims of trafficking who had made asylum claims. Thus a victim
receiving asylum support would receive an essential living needs payment from the Home Office under
regulation 10 (2) together with a “top-up” payment from the Salvation Army (though funded by the Home
Office) under the VCC to bring the total to £65; for the period from 6 February 2018, for example, the two
payments would be respectively £37.75 and £27.25. It is necessarily implicit in that approach that a
“subsistence payment” under the VCC is intended to cover more than essential living needs: as to this, see
para. 27 below.


-----

25. Para. F-001 also provided for “Additional Subsistence Payments” for “Service Users that have
dependant [sic] children”, in the sums of £20.50 for the first child and £13.55 for each additional child.
[Those sums corresponded to the amounts then payable by way of child benefit under the Social Security](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y00B-00000-00&context=1519360)
_[Contributions and Benefits Act 1992. Mr Buttler described these payments (and the payments which later](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y00B-00000-00&context=1519360)_
replaced them – see paras. 29-31 below) as “Dependent Child Trafficking Support”, shortened by the
Judge to “child trafficking support”. Mr Tam suggested that that description was tendentious. Without
necessarily accepting that that is so, I will use the label “VoT dependent child support”. I should make
clear that para. F-001 has no application to children who are themselves victims of trafficking: they are
provided for by local authorities under entirely different arrangements.

26. There is no explicit statement in the VCC about whether VoT dependent child support payments would
be made where asylum-seeker dependent child support payments had been received in respect of the
child in question. However, the Secretary of State put in evidence before Kerr J an exchange of letters
between the Home Office and the Salvation Army which confirmed that the rule as understood and applied
was that no payments would be made under the VCC in such a case: the amounts payable for dependent
children by way of asylum support were of course higher than the amounts payable for them under the
VCC. That approach was of course consistent with the position as regards victims of trafficking
themselves, as described in para. 24 above,

27. I need to refer to an episode in March 2018 which casts light on the Secretary of State's obligations as
regards subsistence payments. With effect from 1 March she reduced the amounts payable to service
users in the relevant category from £65 to £37.75, on the basis that she believed that it was wrong that
they should receive more than was received by asylum-seekers for essential living needs. In R (K and AM)
_v Secretary of State for the Home Department_ _[2018] EWHC 2951 (Admin), [2019] 4 WLR 92, (to which I_
will refer as K) Mostyn J held that that reduction was unlawful because it was based on a misunderstanding
of the concept of “subsistence” in the Directive, to which the VCC was intended to give effect. In the
context of the Directive the term “subsistence” went beyond the minimum required to stave off destitution,
i.e. essential living needs, and also covered pecuniary assistance with the recovery needs which were
peculiar to victims of trafficking; and the “top-up” in the subsistence payment reflected that element. He
also held that the reduction was discriminatory by reference to article 14 of the ECHR and that the
Secretary of State had been in breach of her duty under section 149 of the Equality Act 2010. The
Secretary of State did not appeal against that decision, and the level of payments was restored to £65. An
order was also made for her to pay the sums not paid since the unlawful change of policy.1

The Guidance: Introduction

28. On 24 March 2020 the Secretary of State issued statutory guidance under section 49 (1) of the
**_[Modern Slavery Act 2015 (“the Guidance”). The matters required to be covered by such guidance include](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
“arrangements for providing assistance and support to persons who there are reasonable grounds to
believe may be victims of slavery or human trafficking”. That aspect is covered in Annex F – “Detail of
support available for adults in England and Wales”. There have been many subsequent versions of the
Guidance: we are primarily concerned only with this very first version and its immediate successor
(versions 1 and 1.01), but we were not given complete copies of either, and I will occasionally refer to
version 2.4, dated January 2021, of which we have a more complete copy.

The Guidance: Version 1

29. Section 8 of the Guidance is headed “Support for Adult Victims”. Para. 8.28 (in version 2.4) refers to
Annex F for the details of the support to be provided. Paras. 15.1-15.342 of Annex F are concerned with
accommodation and related issues. Paras. 15.35-15.39 are headed “Financial support”.

30. Paras. 15.35-36 read as follows:

“15.35. Potential victims and victims of modern slavery who have entered the NRM3, received a positive
Reasonable Grounds decision and are in VCC accommodation or outreach support, will be paid financial
support. This payment will continue while they remain in VCC support as long as they are assessed to


-----

have a recovery need for this assistance. Financial support is intended to meet the potential victim's
essential living needs during this period and assist with their social, psychological and physical recovery.

15.36 The current rate of financial support payable by the Home Office to potential victims or victims of
**_modern slavery receiving VCC support depends on the accommodation they are in. Subject to_**
paragraphs 15.37 and 15.38 below, the rates are as follows:

- £65 per week for those in self-catered VCC accommodation

-  £35 per week for those in catered VCC accommodation

- £35 per week for those receiving outreach support in other accommodation

- Subject to 15.38 below, child dependents4 of potential victims will also receive financial support from the
VCC:

- £20.50 per week for the first child dependent

- £13.55 for all subsequent child dependents.”

31. It will be seen that the amounts specified re-state the provision made in the VCC. The final sentence
of para. 15.35 confirms, in accordance with K, that the financial support provided for is intended not only to
meet the essential living needs of victims but also to assist more widely with their “social, psychological
and physical recovery” (a phrase deriving from article 12.1 of ECAT).

32. Paras. 15.37-38 appeared under the sub-heading “Financial support for potential victims who are also
receiving asylum support”. They read:

“15.37. The payment rates will be adjusted if the potential victim or victim of **_modern slavery receiving_**
VCC support is also an asylum seeker or failed asylum seeker receiving financial support under sections
95, 98 or section 4 of the Immigration and Asylum Act 1999 ('asylum support'). In these circumstances, the
individual will receive £65 per week, made up of his payments from asylum support and a further payment
from the VCC to take total payment to £65 per week.

15.38. Potential victims or victims of modern slavery receiving NRM support5 who are receiving asylum
support will not receive any financial support through the VCC in respect of any dependents, or pregnancy
payments as these will be met through the asylum support system.”

33. It will be seen that these two paragraphs correspond to the arrangements operated under the VCC
prior to the publication of the Guidance as regards victims of trafficking who are recipients of asylum
support. Specifically, para. 15.37 sets out the top-up arrangement explained at para. 24 above; and para.
15.38 confirms that no payments are to be made in respect of dependent children, corresponding to the
position explained at para. 25.

34. Although the financial support provisions in Annex F are concerned primarily with potential victims,
confirmed victims may continue to receive equivalent financial support. Following the conclusive grounds
decision a “Recovery Needs Assessment” will be conducted in order to determine “any ongoing recovery
needs requiring [MSVCC] support”. That appears from para. 8.27 of version 2.4 of the Guidance, but I
understand it to reflect the position under earlier versions and indeed in the “pre-Guidance” period.

The Guidance: Version 1.01 and later

35. On 6 April 2020, i.e. only a fortnight after version 1, the Secretary of State issued version 1.01. The
structure of Annex F generally, and specifically the section relating to financial support, remains the same
as in version 1, but there are three changes:

(1) The amount specified in the third bullet under para. 15.36 – i.e. for those receiving outreach support in
other accommodation – is raised from £35 to £39.60.

(2) The amounts specified in the fourth bullet of para. 15.36 for child dependants are altered to read as
follows:


-----

“Subject to 15.38 below, child dependents of potential victims will also receive financial support from the
VCC:

o  £39.60 per week for each child dependent

o  Additional weekly payments per child under a certain age:

     - £5 per week for a child until their first birthday

     - £3 per week for a child from the day after their first birthday until their third birthday.”

(3) A fifth bullet is added, as follows:

“Subject to 15.38 below, additional payments will be made to potential victims who are expecting, or have
very young child dependents:

o  £3 per week for pregnant women

o  A one-off maternity grant of £300 per expected child, for expectant mothers who are within 8 weeks of
their expected due date or an individual who, on the date of entry to support is accompanied by a
dependent child of less than 6 weeks old. Individuals who are eligible for a Sure Start Maternity Grant or
maternity grant from the asylum support system, are not eligible to receive this grant in respect of the child
concerned. If, however, an individual receives less from either the Sure Start Maternity Grant or asylum
support maternity grant than £300 per expected child, then a further top up payment from the VCC will be
provided to ensure that the individual receives a total of £300 per expected child.”

Paras. 15.37-38 remain in identical terms.

36. It will be seen that the first and second of the changes to para. 15.36 bring the amounts payable under
Annex F precisely into line with the sums payable for “essential living needs” under regulation 10 (2), and
by way of “additional support” under regulation 10A (1), of the Asylum Support Regulations: see para. 17
above. In particular, the sums payable for dependent children go up from the child benefit-aligned rate of
£20.50 for the first child and £13.55 for each subsequent child to the asylum support rate of £39.60 for
each child. However, if, like the Claimants in this case, the parent was in receipt of asylum support that
made no difference in practice, since they would receive the equivalent amount under regulation 10 (2) and
the effect of para. 15.38 was that it would not be paid twice. We are not directly concerned with the third
change, relating to maternity grants, but it will be noted that it too provides for any maternity grants paid
either from Sure Start6 or by way of asylum support to be brought into account.

The Guidance: later versions

37. The only subsequent substantive change in this part of Annex F is that the figure of £39.60 in the third
bullet under para. 15.36 was increased to £39.63 in version 2.1, issued in March 2021. That replicates the
increase to the payment specified under regulation 10 (2) of the Asylum Support Regulations: see para. 17
above.

38. Otherwise, I need only note that at some point paras. 15.35-15.38 became paras. 15.36-15.39, and
that the VCC became referred to as the MSVCC.

Summary

39. Although it has been necessary to track the position through the different documents in which they
have been embodied, in the respects relevant to this appeal the arrangements for financial support for
victims of trafficking have been substantially the same throughout the relevant period. The features to note
for our purposes are:

(1) The entitlements of potential victims of trafficking to a subsistence payment and to VoT dependent
child support do not involve any assessment of individual need. Subject to point (2), they are payable
simply in consequence of the making of a reasonable grounds decision, and irrespective of whether the
victim has other sources of income or support, e.g. from earnings (if they are entitled to work) or from
family or charitable sources. Mr Buttler described this feature as the payments being “non-means-tested”.


-----

(2) If the beneficiary is in receipt of asylum support, the amounts payable are adjusted accordingly. In the
case of adults this means that they receive only the top-up payment which is intended to address recovery
needs over and above their essential living needs. In the case of dependent children it means that their
parents receive nothing. Mr Buttler described the non-receipt of VoT dependent child support in such a
case as “the Exclusionary Rule”. Mr Tam objected that that label too was tendentious, since it is the
Secretary of State's case that it was simply the result of avoiding double payment for the same needs.
That may be a fair criticism, but I will sometimes use it where it is convenient to do so, leaving it in quotes
in deference to Mr Tam's concern.

ENTITLEMENT TO WORK AND TO MAINSTREAM BENEFITS

40. Section 115 (1) of the 1999 Act, read with subsection (3), excludes “persons subject to immigration
control” from entitlement to a wide range of specified benefits, including universal credit and the legacy
benefits which it replaces – that is, mainstream benefits. Subsection (9) reads (so far as relevant):

“'A person subject to immigration control' means a person who—

(a) requires leave to enter or remain in the United Kingdom but does not have it;

(b) has leave to enter or remain in the United Kingdom which is subject to a condition that he does not
have recourse to public funds;

(c) …; or

(d) … .”

41. I should mention for completeness that victims of trafficking with dependent children may be entitled to
financial support from a local authority under section 17 of the Children Act 1989. Mr Buttler alluded to this
at one point in his submissions, but it represents an entirely different scheme of support and is not material
to the issues before us.

OVERVIEW

42. Victims of trafficking have different characteristics which will affect the kinds of financial support
available to them. Two such characteristics are of fundamental importance for our purposes:

(1) Nationality/immigration status. Most adult victims of trafficking are foreign nationals who are not
entitled to live or work in this country or to receive mainstream benefits. But that is not invariably the case.
A substantial number either are UK citizens or are entitled to ILR or to a form of limited leave to remain
which allows them to have recourse to public funds (and to work) – I will call this “unconditional limited
leave”7. (Prior to the UK's withdrawal from the EU, those rights would of course also be enjoyed by EU or
EEA citizens, and they continue to be enjoyed by Irish citizens.)

(2) Asylum-seekers. Although many victims of trafficking who are not UK citizens make claims for asylum,
as the Claimants have done, not all do so. Many will wish, after an appropriate period of recovery, to
return to their home countries or, even if they might wish to claim asylum, may appreciate that they have
no viable basis for doing so.

43. In the light of those distinctions, Mr Tam submitted in his skeleton argument, and I agree, that victims
of trafficking in the UK can usefully be classified into three groups:

(a) Group 1: Those whose nationality/immigration status gives them no right to live or work in the UK, or
claim mainstream benefits, and who have not claimed asylum. They are financially supported only as
victims of trafficking.

(b) Group 2: Those whose nationality/immigration status gives them no right to live or work in the UK, or
claim mainstream benefits, but who are claiming asylum. They are financially supported both as asylumseekers and as victims of trafficking (subject to the set-off arrangements identified above).


-----

(c) Group 3: Those who do have a right to live and work in the UK, including a right to mainstream
benefits. They are financially supported as victims of trafficking, but they will be entitled to mainstream
benefits (typically now Universal Credit) if they qualify and will of course also be able to earn if they work.

It will be seen that the difference between groups 1 and 2 on the one hand and group 3 on the other lies in
their nationality/immigration status.

44. We were told that reliable figures are not available for the numbers, or proportions, in each group. It is
a reasonable inference that group 3 is smaller than the other two, because victims of trafficking are mostly
foreign nationals and it seems very unlikely that many of them will have been granted ILR or unconditional
limited leave; but there are nevertheless a substantial number of adult victims of trafficking with UK
nationality.

45. Asylum-seekers will generally, if not always, be subject to immigration control and not be entitled to
mainstream benefits. (I say “if not always” because, as I understand it, if persons with unconditional limited
leave claim asylum during the course of their leave they will continue to be entitled to benefits and to work
during the currency of that leave; but any such cases will be unusual.)

46. The income which a victim of trafficking in group 3 would receive from mainstream benefits (or
earnings), over and above their VoT support, would obviously depend on their circumstances. But it is
undisputed that it would always be higher than the rates of asylum support.

**THE CLAIMANTS' CASE**

47. The bare facts about the Claimants' cases, as relevant to the issues before us, are as follows:

(1) EH received a positive reasonable grounds decision on 20 June 2017 and thereupon began to receive
VoT support. She claimed asylum on 17 July 2017, although for reasons that we were not told she did not
begin to receive asylum support payments until 19 January 2018. She gave birth to a daughter in
September 2017 and to a son in May 2019. On 9 June 2020 she received her positive conclusive grounds
decision. Following a recovery needs assessment (see para. 34 above), VoT support was discontinued on
21 August 2020. She sought judicial review of that decision but her claim was still pending when, on 29
March 2021, she was granted asylum. At that point she became entitled to work and to claim mainstream
benefits. Mr Buttler told us that her claim runs from 19 January 2018 to 21 August 2020.

(2) MD had her initial asylum claim refused but filed a fresh claim on 11 June 2018. At that date she had
two dependent children, aged 1 and 2. She received a positive reasonable grounds decision on 12
December 2018. On 16 January 2019 she began to receive VoT support. On 19 March 2019 she received
her positive conclusive grounds decision. On 19 October 2019 she began to receive asylum support for
herself and her children. Her VoT support was discontinued in November 2020 following a recovery needs
assessment, but it was reinstated on 21 December 2020. She was granted asylum on 21 February 2021
and at that point became entitled to work and to claim mainstream benefits. Mr Buttler told us that her
claim ran from 16 October 2019 to 21 February 2121.

Both Claimants are thus in group 2: they were, in the periods to which their claims relate, victims of
trafficking who were in receipt of asylum support and their entitlement to VoT support was reduced in
accordance with the arrangements described above.

48. I start by identifying the Claimants' substantive grievance, as pleaded in their judicial review grounds
and developed in their witness statements, leaving aside its legal formulation. That grievance is that they
were unable to attend appointments connected with their status as victims of trafficking because the
amounts that they received by way of support were insufficient for them to be able to take their children
with them (where appropriate) or to pay for childcare. The appointments in question included sessions with
counsellors or psychologists to assist with their PTSD, other medical appointments, “NRM meetings” and
interviews with their solicitors8. No doubt not all victims of trafficking with young children would experience
this problem: in some cases friends or family might provide voluntary childcare, or funds might be available
from charitable or other sources to pay for it (or to pay a child's fare to accompany the parent). But the
evidence was that the Claimants' experience was far from unique. The problem is of course much more


-----

likely to arise for lone parents, because a partner could usually, though no doubt not in every case, be
expected to look after the children while the parent in question attended the appointment.

49. Turning to how that grievance was formulated as a matter of law, the Claimants took two alternative
approaches. One was that the Secretary of State's failure to cover the childcare costs associated with
attending appointments was irrational. Kerr J rejected that ground, and it has not been revived before us.

50. The other approach was by way of the discrimination claim under article 14 of the ECHR to which I
have already referred. I need not set out the terms of article 14 or summarise the effect of the case-law. It
is sufficient to say at this stage that:

(a) it proscribes discrimination, as regards the enjoyment of Convention rights, on a number of specified
grounds, including sex, but also on the ground of “other status”;

(b) discrimination may be either direct or indirect; and

(c) differential treatment (whether direct or indirect) may be justified – I will refer to treatment which would
constitute discrimination unless it is shown to have been justified as “prima facie discrimination”.

51. At the start of his judgment Kerr J summarised the way that the Claimants put their claims in law as
follows:

“2. It is common ground that because they are asylum seekers, in receipt of asylum support, [the
Claimants] do not receive financial support under the provisions of the **_Modern Slavery Victim Care_**
Contract in respect of any dependent children; whereas if they were not in receipt of asylum support but in
receipt of financial support from other sources (universal credit, 'legacy' benefits or paid work) they would
receive financial support in respect of dependent children.

3. The claimants submit that this difference of treatment between asylum seeker victims of trafficking with
dependent children and non-asylum seeker victims of trafficking with dependent children is contrary to
article 14 of the European Convention on Human Rights …, read with article 4 and article 1, first protocol
… and cannot be justified; and that it is irrational.

4. The claimants also submit that the same difference of treatment violates article 14 because it impacts
adversely on lone parents, who are nearly all women. It was argued at length and in detail that the adverse
impact arose because lone parent asylum seeker victims of trafficking are less able than co-parents to
obtain and pay for child care that is essential to enable victims to attend appointments, notably for legal,
medical and counselling purposes.

5.  In the course of oral argument at the hearing the claimants adopted the court's suggestion that the
adverse impact can be more simply identified in that members of the disadvantaged group – lone parent
asylum seeker victims of trafficking, who are mainly female – receive less money each week than others,
not seeking asylum, who are not members of that disadvantaged group.”

52. The Claimants were thus alleging discrimination on two bases – the first being identified in paras. 2
and 3 and the second in para. 4, as modified by para. 5. The first basis alleges direct discrimination on the
basis of status as an asylum-seeker. The second alleges indirect discrimination, the disadvantaged group
being lone parents/women. I will refer to them as “the direct discrimination claim” and “the indirect
discrimination claim” respectively. (Para. 3 also refers to the irrationality claim, but, as already noted, that
does not arise in these appeals.)

53. I will not at this stage say anything further about the indirect discrimination claim (save to note that it
was only brought by MD): I analyse it more fully at paras. 120-128 below. But it is necessary to look
closely at the direct discrimination claim. As to this, I should refer to two other passages in Kerr J's
judgment.

54. First, at para. 19, as part of his explanation of the facts, he sets out para. 15.38 of Annex F, which
contains the so-called “Exclusionary Rule” disentitling asylum-seekers to VoT dependent child support. He
continues, at para. 20:


-----

“That is the difference of treatment under challenge, emphasising that the asylum seeker trafficking victim
is excluded from an entitlement enjoyed by her non-asylum seeker counterpart in receipt of mainstream
benefits.”

55. Second, at paras. 28-29, as part of his summary of the Claimants' case he refers to the circumstances
of a victim of trafficking referred to as XY:

“28. [A] British single mother victim of trafficking on mainstream benefits and receiving income from part
time work, known as 'XY', receives dependent child trafficking support for her daughter. XY is not an
asylum seeker. She has been able to use the extra money to pay for, among other things, child minding
while she attends appointments with her solicitor and her (unfortunately titled) 'modern slavery advocate'.

29.  XY's case provides an example of the differential treatment. The claimants, being asylum seekers, are
not so fortunate. XY's 'trafficking-related needs' are no different from those of the claimants. But XY is
better able to meet them, not just because she receives trafficking support for her daughter but also
because her income from mainstream benefits and part time work is a good deal higher than the asylum
support rate.”

That derives from a witness statement given by XY, and it is clear that her circumstances featured
prominently in the submissions to Kerr J. There is in fact in the article 14 context no legal requirement to
[identify an individual comparator (as there is in equal pay claims under the Equality Act 2010), but the case](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
of XY was advanced as illustrating the circumstances of the comparator group.  It will be observed that XY
is in group 3: her British nationality entitles her to mainstream benefits and to work.

56. The paragraphs which I quote from Kerr J's judgment at paras. 51 and 54-55 above are problematic
and require unpacking. They roll up two distinct disadvantages/differences of treatment, namely:

(1)  the fact that the Claimants were not entitled to “financial support under the provisions of the [VCC] in
respect of any dependent children” (i.e. what I have called VoT dependent child support); and

(2) the fact that the Claimants had to meet the needs of their dependent children from asylum support
alone whereas victims of trafficking in the position of XY could do so from both VoT support and income
from “other sources (universal credit, 'legacy' benefits or paid work)” such as XY enjoyed.

I will refer to the two disadvantages as “VoT child support disadvantage” and “mainstream benefits
disadvantage”: the latter label is a shorthand because the Claimants refer also to the ability to work.

57. Those two disadvantages involve different comparisons and would in principle lead to different relief.
Specifically:

(1) The non-receipt of VoT dependent child support is peculiar to asylum-seekers9 (group 2). The
allegedly disadvantaged group are thus indeed, as Kerr J records at para. 3, “asylum seeker victims of
trafficking with dependent children”, and the comparator group are “non-asylum seeker victims of trafficking
with dependent children” – in other words all other victims of trafficking with dependent children, who
comprise not only group 3 but also group 1. The appropriate damages, if the other criteria for an award are
satisfied, would be the amount of unpaid VoT dependent child support – i.e. what in K was referred to as
“back pay”.

(2) The non-receipt of mainstream benefits (or income from work) is not peculiar to asylum-seekers. It is
common to both group 1, who are not asylum-seekers, and group 2, who are. The comparator group are
those whose nationality/immigration status entitles them to work and to have recourse to benefits – i.e.
group 3. It is true that those in group 3 will in practice almost certainly not be asylum-seekers (though it is
not impossible – see para. 45 above); but that is not the basis of the difference of treatment, otherwise
group 1 would be entitled to mainstream benefits too. The appropriate damages – again, if the other
criteria for an award were satisfied – would in principle be the amount of the additional income that the
Claimants would have received from mainstream benefits or work (though assessment on that basis might
be very difficult).


-----

58. It is essential to appreciate that the Claimants base their claim in these proceedings only on VoT child
support disadvantage. As Kerr J says at para. 20 of his judgment, “[t]hat is the difference of treatment
under challenge”; and it is the only one which depends on the difference between asylum-seekers and
non-asylum-seekers. Mainstream benefits disadvantage is not even referred to in MD's grounds, and the
relief sought is an order quashing the Secretary of State's policy that “victims of trafficking in receipt of
asylum support are ineligible for trafficking support payments for dependent children”, together with
damages equivalent to the unpaid amounts of VoT dependent child support. As for EH's grounds, the
section headed “the difference in treatment” likewise begins by identifying “the Defendant's policy ... to
make child trafficking payments [i.e. VoT dependent child support] to all victims of modern slavery except
those in receipt of asylum support” (para. 58). It is true that it does at para. 59 go on to refer to the fact that
“victims of trafficking who are in receipt of mainstream benefits” receive child trafficking payments, but the
reference appears only to be intended to illustrate the point that VoT dependent child support is paid
regardless of need. Again, the relief sought is in substantially the same terms as sought by MD.

59. That being so, the use of XY as a comparator, and specifically the emphasis (as noted by Kerr J at his
para. 20) on her income from mainstream benefits and part-time work, was unhelpful, since the Claimants'
non-receipt of that income did not constitute the disadvantage complained of. At the risk of anticipating
some points which I will have to consider below, it is necessary to appreciate that the Secretary of State's
response to the two disadvantages is quite different. Specifically:

(1) As regards VoT child support disadvantage she accepts, of course, that victims of trafficking in receipt
of asylum support did not receive VoT dependent child support. But she says that that is simply because
they received (at least) the equivalent amount by way of asylum-seeker dependent child support (see
paras. 24 and 36 above)10. In other words, the disadvantage is a matter of labels only and is purely
nominal. All three groups get the same amounts in respect of their dependent children: the payment
simply comes by a different route in the case of those in group 2. (To anticipate, that seems to me
obviously right: see para. 90 below.)

(2) She also accepts the mainstream benefits disadvantage. More specifically, she accepts that, whereas
the Claimants' trafficking-related needs (including the essential living needs of their children) were met only
from VoT support/asylum support, victims of trafficking in group 3 receive both VoT support and
mainstream benefits (or income from work): in short, they were being paid twice in respect of the same
needs. She produced detailed evidence and submissions attempting to explain that state of affairs, which
she describes as a mistake, as I will describe in the next section of this judgment; but since this is not the
subject-matter of the claim her explanation might be thought not to be truly necessary.

60. I believe that the conflation of two distinct disadvantages/comparisons, and the Secretary of State's
response to them, has caused real confusion in the analysis of this case and led to serious difficulties with
the Judge's reasoning. The problem originates in the Claimants introducing a factor (i.e. non-receipt of
mainstream benefits) which was irrelevant to the claimed disadvantage, but it was compounded by the
Secretary of State focusing on that factor to such an extent in her evidence.

61. I should add that the point made by Kerr J at para. 5 of his judgment, with reference to the indirect
discrimination claim, applies equally to the direct discrimination claim. The disadvantage claimed to have
been suffered is straightforwardly that the Claimants have not received VoT dependent child support
payments. No doubt if they had received more money than they did they could have used it to address
their difficulties in attending trafficking-related appointments, but that is not the essence of the
disadvantage.

**HOW THE DIFFERENTIAL TREATMENT AROSE**

62. In order to understand the Judge's reasoning, and the submissions before us, it is necessary to set out
the Secretary of State's explanation for the differences in the treatment of victims of trafficking in group 2
and in group 3.

63. As I have said, as regards the actual disadvantage of which the Claimants complain – that is, the nonpayment of VoT dependent child support to victims in group 2, unlike those in group 3 (and group 1) – it is


-----

the Secretary of State's case that that was because they received the equivalent amounts by way of
asylum-seeker dependent child support and that any disadvantage was purely nominal.

64. Much of the argument before the Judge, however, and before us, was about the Secretary of State's
explanation of the other disadvantage – that is that, unlike victims of trafficking in group 3 who receive VoT
support and mainstream benefits, the Claimants receive only VoT/asylum-seeker support. It was her case
that it was never the Government's intention that victims of trafficking in group 3 should be paid twice in
respect of the same needs: that was a mistake, or anomaly, which gave the recipients a windfall. She was
able to adduce only very general evidence in support of that case and has not been able to identify
precisely how the mistake occurred. She did in fact apply shortly before the hearing before Kerr J for an
adjournment in order to enable further enquiries to be made; but the application was refused and the
hearing had to proceed on the basis of such evidence as there was.

65. The evidence in question was from Jonet Tann, a policy adviser on adult victim support policy in the
**_Modern Slavery Unit at the Home Office. She notes at para. 14 of her witness statement that whereas the_**
rules governing jobseekers' allowance, which is one of the primary legacy benefits replaced by universal
credit, would have meant that the entitlements of those in group 3 were reduced by any sums received by
way of VoT support, there was no equivalent provision in the rules governing universal credit. She
continues:

“This difference in approach to mainstream benefits may explain the current situation of paying child
dependant payments to those who are in receipt of mainstream benefits, if it was assumed at the time of
the contract that all mainstream benefits would deduct VCC payments as per legacy benefits.”

That is not very well expressed, but the evident meaning is that it may well have been (wrongly) assumed
that any amounts paid by way of VoT support would be deducted from universal credit, as they had been
from the legacy benefits, and that accordingly no adjustment should be made to the amounts payable
under the VCC contract. Ms Tann was not, however, in a position to confirm by documentary or other
“corporate memory” evidence that that had indeed been the assumption.

66. The Claimants served a request under CPR 18 for further information about (among other things)
para. 14 of Ms Tann's statement. The Secretary of State's response acknowledged that the reference to
“VCC payments” being deducted under the regulations governing legacy benefits was not wholly accurate.
Her statement was correct as regards payments made to adult victims of trafficking for their own
subsistence but not as regards payments made “to, or in respect of, a child or young person who is a
member of the claimant's family”: such payments would be disregarded.

67. It would appear that the windfall could in principle have been avoided either by the Secretary of State
for Work and Pensions providing in the Universal Credit Regulations for payments by way of VoT support
to be deducted in the calculation of universal credit (and likewise, if necessary, as regards legacy benefits)
or by the Home Secretary providing for the amount of VoT support to be reduced for victims of trafficking
who were in receipt of income from mainstream benefits. In the absence of any detailed contemporary
evidence Mr Tam declined to allocate responsibility (still less blame) as between the two Departments or to
say which of those courses would have been taken if the issue had been appreciated. He likened the
situation to a “squidgy jelly”, in that, as Kerr J put it at para. 39 of his judgment, “if you try to push part of it
in from the edge (i.e. eliminate an anomaly), it is squeezed out through a gap in the side elsewhere in the
system (i.e. producing another, different anomaly)”. I have to say that I am not sure the metaphor is very
apt, since it is not self-evident that either course would necessarily have produced other anomalies; but I
acknowledge the general point that making rules in these complex interlocking areas, particularly where
different Departments are involved, must be far from straightforward.

68. Ms Tann also gave evidence that the entire issue of what financial support should be afforded to
victims of trafficking was under review within the Home Office. At para. 37 of her statement she refers to
the announcement in July 2020 of an “NRM transformation programme”, which would among other things
include “a new financial support policy to provide an individualised needs-based approach to financial
support”: the new policy was planned to be implemented in 2021. In the following paragraphs she goes on


-----

to provide a short summary of the key elements of the policy as currently planned. The third element was
described as “off-setting financial support”. As to this, she says, at para. 44:

“Payments from the MSVCC should complement rather than duplicate other finances and support services.
Accordingly, the amount of financial support that potential and confirmed victims receive from the MSVCC
(including additional payments for child dependent and pregnancy) will be adjusted if potential or confirmed
victims are also in receipt of alternative funds. Examples of such funds could include mainstream benefits
and asylum support.”

**KERR J's DECISION**

69. In the first part of his judgment Kerr J summarises the factual background and the grounds of
challenge. I have covered this ground above. His conclusions and reasons are at paras. 73-134. For
present purposes I can give a very brief summary: I shall have to come back to his reasoning on particular
points later.

70. He starts, at paras. 73-83, by considering how, as a matter of fact, the mainstream benefits
disadvantage arose. He accepts the Secretary of State's case that it was a mistake.

71. At paras. 84-86 he considers and rejects the Claimants' case based on irrationality. Since that is not
pursued in this appeal I need not summarise his reasons.

72. At paras. 87-123 he considers the discrimination claim. His conclusions are as follows:

(1) As regards the direct discrimination claim, he says at para. 87 that “differential treatment is admitted”.
That statement is not challenged by the Secretary of State, and I must treat her as having accepted that
the non-payment of VoT dependent child support, being the disadvantage complained of, formally
constituted (adverse) differential treatment. But I note that the Judge describes the difference in question
as being between the treatment of “asylum seeking victims of trafficking with dependent children” and of
“those on mainstream benefits and not seeking asylum”: as explained at paras. 56-57 above, that way of
putting it conflates two distinct disadvantages. Be that as it may, the Judge proceeded on the basis that
the admitted difference of treatment meant that there was prima facie direct discrimination under article 14
(read with article 1 of Protocol 1)11.

(2) The alternative claim of prima facie indirect discrimination was also upheld: see paras. 90-96.

(3) At paras. 97-123 he considers and rejects the Secretary of State's justification defence as regards both
forms of discrimination. The discussion covers a number of points, but the essence is that where a
mistake had been made that disadvantaged vulnerable people it could not be justified simply by saying that
it would be put right at some unspecified time in the future.

73. It followed from that conclusion that the Secretary of State had acted unlawfully within the meaning of
section 6 (1) of the 1998 Act. At paras. 125-134 the Judge considers whether any damages, and if so in
what amount, should be awarded to the Claimants as victims of that unlawful conduct. He concludes that
they should be awarded damages for financial loss in an amount “equal to back payments of what they
would have received but for the discrimination”, together with “a relatively modest award of non financial
loss to compensate them for the distress caused by the discrimination” (para. 134).

74. The substantive parts of the Judge's order read as follows:

“1. It is declared that the defendant's payment of additional financial support to victims of human trafficking
who have dependent children and who are in receipt of mainstream benefits and/or lawfully in work
breaches Article 14 ECHR, read with Article 4 and Article 1 of the First Protocol, because the non-payment
of such additional financial support to victims of human trafficking who have dependent children and are in
receipt of asylum support (a) unjustifiably discriminates against those in receipt of asylum support
compared to those in receipt of mainstream benefits or in work, and (b) unjustifiably indirectly discriminates
against women.

2. The defendant shall pay damages to the first and second claimants comprising: (i) damages for
financial loss corresponding to the amount of child trafficking support payments the claimants would have


-----

received whilst entitled to adult trafficking support, had they not been denied child trafficking support
payments on account of being in receipt of asylum support; (ii) non-pecuniary damages to compensate the
claimants for the distress caused by the discrimination.”

**THE ISSUES IN THIS APPEAL**

75. The Secretary of State initially advanced three grounds of appeal, as follows:

    - Ground 1 contended that even if a breach of article 14 had occurred the Judge was wrong to make any
award of damages, in respect of either pecuniary or non-pecuniary loss.

     - Ground 2 challenged the Judge's rejection of the justification defence.

     - Ground 3 challenged the finding of indirect discrimination.

In the end, however, she chose not to proceed with ground 2 as regards the direct discrimination claim
(she made no concession as regards justification in the indirect discrimination claim). Mr Tam made it
clear that the Secretary of State did not accept that she might not in principle have been able to justify the
differential treatment which she admitted; but he said that the limited evidence that she had been able to
adduce meant that she did not feel able to contend that the Judge's conclusion was not open to him.

76. The Claimants filed a Respondent's Notice. As regards the direct discrimination claim they sought to
support the Judge's decision by two further reasons which he had rejected. The first (para. 3) was that he
was wrong to find that the differential treatment in question was a mistake (“the mistake issue”): although
the Claimants do not need this point as regards liability, it has an important bearing on the damages claim
and it is accordingly live before us. The same is not true of the second reason (para. 4), which was to the
effect that, contrary to a finding made by the Judge in relation to the irrationality challenge, the Government
was under a duty to cover the childcare costs associated with victims of trafficking attending traffickingrelated appointments. (I shall, however, have to say something about it in a different context: see para.
147 below.) As regards the indirect discrimination claim, MD12 identifies two alternative bases for
upholding the Judge's finding: I will return to these later.

77. I will address first the challenge made by the Claimants in the Respondent's Notice to the Judge's
finding on the mistake issue. I will then turn to the Secretary of State's surviving grounds of appeal (taking
the issue of justification in relation to the indirect discrimination claim as part of ground 3).

**(1)                         THE MISTAKE ISSUE**

78. At the risk of labouring the point, I must make clear by way of preliminary that the effect of my analysis
at paras. 56-60 above is that the reason why the Claimants suffered the mainstream benefits disadvantage
should not be relevant to their claim since it is concerned with a disadvantage other than the one on which
the claims are based. But in the light of the way the case was argued I have to address it.

THE JUDGE'S REASONING

79. Kerr J starts by discussing the admittedly unsatisfactory nature of the evidence which the Secretary of
State had adduced about how the differential treatment of which the Claimants complained arose. He
concludes, at para. 79, that

“… though far from ideal, the right course is to decide the case on the evidence before the court, since the
Secretary of State does not disavow it, but subject to taking into account that her case is founded on
evidence whose accuracy, completeness and reliability she does not fully guarantee”.

80. At para. 80 he refers to Mr Tam's “squidgy jelly” point. He continues, at paras. 81-83:

“81. For these proceedings only, I accept that the Secretary of State's explanation is realistic and likely to
be the correct inference from such historical material as is available in the documents and in Ms Tann's
witness statement. I do not think it likely that the government would have wanted victims of trafficking on
mainstream benefits and not on asylum support to receive dependent child trafficking support payments in
addition to other payments intended to cover the child's living needs.


-----

82.  The most likely explanation is that this was indeed a mistake. No one is, realistically, going to get
money for nothing from the Treasury on purpose. That is indeed what appears to have happened in the
case of XY who has had the misfortune of being a victim of trafficking but the good fortune to be on
mainstream benefits and receiving income from part time work.

83.  The claimants have not put forward any credible alternative explanation. I find myself having to accept
the Secretary of State's explanation even though the evidential foundation for it is not solid and it is very
surprising that there are no records or documents directly supporting Ms Tann's deduced account.”

81. That reasoning is directed only to mainstream benefits disadvantage, which was, as we have seen, the
focus of the Secretary of State's evidence. However, the underlying reasoning is also capable of
supporting her explanation of VoT child support disadvantage: see paras. 89-90 below.

THE CLAIMANTS' CHALLENGE

82. Mr Buttler contended that, as he put it at para. 33 of his skeleton argument, “Kerr J was wrong to
accept the Secretary of State's inference that the payment of Dependent Child Trafficking Support to those
in receipt of mainstream benefits was an anomaly”. In his skeleton argument and his oral submissions he
made a number of points in support of that contention which I can summarise as follows:

(1) VoT support is not means-tested: see para. 39 (1) above. The only exception is the adjustment for
adult victims of trafficking who receive asylum-seeker support; but that is a “targeted” provision aimed at a
very specific instance of victims being paid twice to meet the same needs (subject to point (3) below).  It
follows that there is nothing anomalous in VoT dependent child support being paid to those who received
universal credit.

(2) The alleged anomaly could not be attributed to an oversight at the time that universal credit was
introduced, as Ms Tann's evidence implied. The Universal Credit Regulations 2013 came into force on 29
April 2013, but the current VCC contract dated from 2015. Ms Tann's evidence that VoT support payments
had been taken into account as regards legacy benefits had to be heavily qualified by the Part 18 answer
referred to at para. 66 above.

(3) Specifically as regards VoT dependent child support, that could not in any event be regarded as being
intended to meet the essential living needs of the children in respect of whom it was paid. It was important
to appreciate that it was originally set at a rate equivalent to child benefit: see para. 25 above. It is wellestablished that child benefit, which is not means-tested, is not intended to cover a child's “subsistence
needs”: Mr Buttler referred to R (Ford) v Inland Revenue [2005] EWHC 1109 (Admin) (per Richards J at
para. 3); R (PO) v Council of the London Borough of Newham _[[2014] EWHC 2561 (Admin) (per Mr John](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D0M-WW11-F0JY-C2MX-00000-00&context=1519360)_
Howell QC at para. 45); R (SC) v Secretary of State for Work and Pensions _[2019] EWCA Civ 615, [2019]_
1 WLR 5687, (per Leggatt LJ at para. 153); and the original Universal Credit White Paper.

(4) At para. 19 of her witness statement Ms Tann referred to the fact that the Secretary of State was
proposing to pay back-payments to a number of victims who it had been discovered had “received reduced
financial support payments as a result of receiving alternative sources of income”: that was contrary to
“published policy ... [and] … the wording of the VCC”. Mr Buttler submitted that that was further evidence
that there was nothing anomalous in the victims in group 3 receiving both VoT dependent child support and
mainstream benefits.

83. Skilfully though Mr Buttler advanced those submissions, I do not accept them. Kerr J was entitled to
place weight on the common sense proposition that the Government was unlikely to wish to pay twice in
respect of the same needs. The starting-point is its treatment of payments of VoT support to adult victims
of trafficking. As appears from paras. 24-26 and 32-33 above, it has always been Government policy to
deduct receipts by way of asylum support for essential living needs from the subsistence payments made
to victims of trafficking. That is self-evidently on the basis that part of the subsistence payment is intended
to meet essential living needs, and victims should not receive that element twice. Mr Buttler acknowledges
this, but he characterises it as a single “targeted” exception. That cannot be quite correct, because a
policy of not paying twice for the same need must also lie behind by the reduction of VoT maternity


-----

payments by the amount of any Sure Start payment (see para. 36 above). But Mr Buttler's broad point is
that the underlying principle is that VoT support is not means-tested and that accordingly there is nothing
anomalous or unintended about victims of trafficking in group 3 being paid twice for the same needs. As to
that, I take his particular arguments in turn.

84. As to (1), to say that VoT support is not means-tested in the sense that it does not take into account
the overall financial resources of victims of trafficking is true but not material. We are concerned with the
more limited question of payments by the Government.

85. As to (2), the Judge's reasoning did not depend on accepting Ms Tann's suggested explanation of how
the anomaly arose: even if it pre-dated 2013, it remains reasonable to believe that the Government did not
intend victims of trafficking in group 3 to be paid twice for the same essential living needs.

86. As to (3), the fact that prior to April 2020 the rate prescribed for dependent child support under para. F001 of the VCC (and the short-lived version 1 of the Guidance) was derived from child benefit does not
mean that the purpose of the payment was anything other than to meet the child's essential living needs,
just as the purpose of (the relevant part of) the payments to the adults was. It is hard to think of any other
purpose, and that is consistent with their description – “Additional Subsistence Payments” (the VCC) and
“financial support” (Annex F).  Nor is the fact that the amount was lower than that paid to asylum-seekers
inconsistent with it being intended to meet essential living needs. It may have been too low, but that is a
different matter (and in fact it may be that it was precisely because the rate was considered to be too low
that it was decided to increase it in April 2020).

87. As to (4), Ms Tann's evidence does not make clear what “alternative sources of income” were being
referred to, and the point was (we were told) not explored before the Judge. If they consisted of, say,
support from family or charities that would not be inconsistent with a policy that the Government should not
pay twice for the same needs. The Judge was plainly not obliged to regard it as contradicting the principal
point being made by Ms Tann.

88. In short, the Judge was entitled to conclude that the mainstream benefits disadvantage was the result
of a mistake and that the Government did not intend to pay victims of trafficking twice for the same needs,
as had occurred with those in group 3.

89. As I have said, that conclusion only goes to the Secretary of State's explanation of the mainstream
benefits disadvantage, which is not the disadvantage in respect of which the Claimants claim. However,
the Judge's reasoning also has consequences for the explanation for the VoT support disadvantage. If, as
Mr Buttler accepted (see para. 82 (1) above), a policy of not paying twice for the same need is the
explanation for the deduction of asylum support payments from the subsistence payment made to adult
victims of trafficking I can see no reason why it should not equally be the explanation for the non-payment
of VoT dependent child support where an asylum-seeker dependent child support payment had been
made. The situations are indistinguishable. Both asylum-seeker dependent child support and VoT
dependent child support are on the face of it plainly directed to meeting the essential living needs of the
child – indeed from April 2020 the amounts were identical – and it would obviously not be right that a
payment in respect of the same need should be paid twice.

90. It also follows from the conclusion in the previous paragraph that the admitted difference in treatment
as between asylum-seekers and non-asylum-seekers is purely nominal. As a matter of substance, the
Claimants, and others in group 2, received the same sums of money from the Secretary of State in respect
of the needs of their dependent children as those in groups 1 and 3: the only difference is that it came by a
different route, i.e. under the Regulations rather than through the VCC. That has important consequences
for the damages issue.

**(2)                         DAMAGES**

THE BACKGROUND LAW

91. Section 8 of the Human Rights Act 1998 provides (so far as material):


-----

“(1) In relation to any act (or proposed act) of a public authority which the court finds is (or would be)
unlawful, it may grant such relief or remedy, or make such order, within its powers as it considers just and
appropriate.

(2)  But damages may be awarded only by a court which has power to award damages, or to order the
payment of compensation, in civil proceedings.

(3)  No award of damages is to be made unless, taking account of all the circumstances of the case,
including —

(a) any other relief or remedy granted, or order made, in relation to the act in question (by that or any other
court), and

(b) the consequences of any decision (of that or any other court) in respect of that act,

the court is satisfied that the award is necessary to afford just satisfaction to the person in whose favour it
is made.

(4)   In determining —

(a) whether to award damages, or

(b) the amount of an award,

the court must take into account the principles applied by the European Court of Human Rights in relation
to the award of compensation under Article 41 of the Convention.

(5)  …

(6) In this section —

…

'damages' means damages for an unlawful act of a public authority; and

'unlawful' means unlawful under section 6 (1).”

92. Mr Tam emphasised that an award of damages does not automatically follow from a finding of breach
of a Convention right. On the contrary, the effect of subsection (3) is that an award of damages should not
be made unless the court is satisfied that the award is necessary to afford just satisfaction to the victim.

93. General guidance about the approach to an award of damages under section 8 was given by Lord
Bingham in R (Greenfield) v Secretary of State for the Home Department _[2005] UKHL 14, [2005] 1 WLR_
673. The only point that I need take from that guidance is that, as he says at para. 6 of his speech, the
relevant principles must be derived from the Strasbourg case-law. We were, however, referred to a
number of authorities which address the question of in what circumstances an award of damages is
necessary where a breach of article 14 has been found but the more favourable treatment of the
comparator is anomalous – as the Secretary of State says is the case as regards the mainstream benefits
disadvantage. I take the authorities in turn.

94. In _Van Raalte v The Netherlands app. no. 20060/92 [1997] ECHR 6 the European Court of Human_
Rights (“the ECtHR”) found that a provision of the Dutch child benefit legislation which exempted unmarried
childless women aged over 45 from an obligation to pay contributions was in breach of the article 14 rights
of the applicant, who was an unmarried childless man. He asked for an award of damages in respect both
of pecuniary loss, being the amount of contributions that he had made, and of the distress that he had
suffered by being discriminated against: see para. 47 of the Court's judgment. The Court declined to make
an award of damages under either head. Its reasoning is short and rather opaque, but it apparently
accepted the evidence of the Dutch government that but for the discrimination women as well as men
would have had to pay the contributions and that he should accordingly not be regarded as having suffered
any loss: see para. 48. As regards non-pecuniary loss the Court “consider[ed] that the present judgement
constitutes in itself sufficient just satisfaction”: see para. 50.


-----

95. In R (Hooper) v Secretary of State for Work and Pensions _[2003] EWCA Civ 813, [2003] 1 WLR 2623,_
this Court held that the article 14 rights of four widowers had been breached by the non-payment to them
of statutory benefits that would have been paid to widows in equivalent circumstances. The judgment of
the Court was delivered by Lord Phillips MR. The details of the claims, which involved three different types
of benefit, are complex, and I need not explain them. For our purposes, it is only necessary to note two
points.

96. First, in respect of one of the complaints, relating to non-payment of widowed mother's allowance
(“WMA”), no award of damages was made because if the claimants had received the benefit the income
support which they were receiving would have been reduced pro tanto. At para. 158 Lord Phillips said this:

“In these circumstances, [the claimants] have not demonstrated that the discrimination of which they
complain in respective WMA has caused them any pecuniary loss, so the principle of just satisfaction does
not require any award in respect of pecuniary loss. Indeed it might have led the Secretary of State to
question whether, in truth, they have been discriminated against by the refusal to pay them WMA. They
have received the same amount of social security benefits that they would have received had they been
widows in the same situation. It is only the form in which they have received those benefits that differs.”

97. Second, the Court declined to make an award of damages to one of the claimants, Mr Naylor, in
respect of his non-receipt of widow's pension between the ages of 45 and 65. That entitlement had been
abolished by statute. Parliament had provided for a transitional period during which widows already in
receipt of the pension could continue to receive it; but Lord Phillips said at paras. 162-163:

“162. … [I]t does not follow from this that there was any justification for making equivalent payments to
widowers. To have done so would merely have increased the size of those to whom anomalous payments
were being made. This would not have achieved any legitimate aim.

163. For these reasons we do not consider that the principle of just satisfaction entitles Mr Naylor to extrastatutory payments equivalent to Widow's Pension ... The appropriate course in this case is that adopted
by the Strasbourg Court in Van Raalte v The Netherlands.”

The Court also declined to make any award in respect of non-pecuniary loss: see para. 166.

98. _Hooper was heard in this Court together with the related appeal in_ _Wilkinson v Inland Revenue_
_Commissioners. Both cases went to the House of Lords, where they were again heard together, but the_
points noted above were not in issue. I consider the decision of the House of Lords in Wilkinson below.
(Hooper in fact went to Strasbourg, but the decision of the ECtHR likewise contains nothing relevant for our
purposes.)

99. In M and Langley v Secretary of State for Work and Pensions _[[2004] EWCA Civ 1343, [2006] QB 380,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TX8-S1D0-Y96Y-H3FT-00000-00&context=1519360)_
the second appellant, Ms Langley, claimed that a provision in housing legislation (an “anti-abuse
provision”) which was available to members of a couple “living together as husband and wife” but not to
members of a same-sex relationship discriminated against her on the grounds of her sexual orientation
contrary to article 14. Her claim was rejected at first instance and on appeal, but at para. 93 of his
judgment Sedley LJ nevertheless considered the question of remedy. He said:

“As [counsel for the Secretary of State has submitted], the outcome for Ms. Langley would have been the
same if there had been no difference in treatment between her and a former same-sex partner, since the
single logical solution – albeit one which only the rule-maker could bring about – has always been to
include same-sex couples in the anti-abuse provision. In other words, whether it is in relation to her being a
victim or whether it is in relation to her securing a remedy, Ms. Langley's case founders on the fact that the
discrimination of which she complains has done her no harm.”

Neuberger LJ expressed the same view at paras. 144-149 of his judgment. Having referred to Hooper, at
paras. 147-148 he said:

“147. It seems to me that the facts of the present case equally demonstrate that, even if Ms Langley has a
legitimate complaint of infringement of her Article 14 rights, she should receive no compensation. If Article
14 did apply the court would have to decide whether the anomaly was that same-sex relationships fell


-----

outside the ambit of [the relevant regulation] … or whether … the anomaly is that heterosexual
relationships fall within it. In my judgment, that question could only be resolved one way. …

148. Once one concludes that any infringement of Article 14 would have arisen because the regulation did
not extend to same-sex relationships, the basis for any party to a heterosexual relationship claiming
compensation falls away. The proper complaint is that the regulation does not apply to same-sex
relationships, not that it does apply to heterosexual relationships.”

100. Finally, in R (Wilkinson) v Inland Revenue Commissioners _[2005] UKHL 30, [2005] 1 WLR 1718, it_
had been held that the article 14 rights of a widower had been breached by the denial of a bereavement
allowance that the Inland Revenue would have accorded to a widow. The House of Lords held that he was
not entitled to an award of damages.

101. The leading speech in Wilkinson was delivered by Lord Hoffmann, with whom the other members of
the Appellate Committee agreed. At paras. 25-28 he said:

“25. Section 8(4) [of the1998 Act] provides that in determining whether to award damages or the amount
of the award, the court must take into account the principles applied by the Strasbourg court in affording
just satisfaction to the injured party. In R (Greenfield) v Secretary of State for the Home Department [2005]
2005] 1 WLR 673 the House recently had occasion to consider what that meant in the specific context of
breaches of article 6. But Lord Bingham of Cornhill emphasised more generally that the purpose of
awarding damages under the 1998 Act was to allow claimants to recover in an English court what they
would have recovered in Strasbourg; no more nor less. It did not create a statutory duty for which damages
could be recovered as if the breach of Convention rights was a tort in English law. And the jurisprudence of
the Strasbourg court shows that it is more concerned with upholding human rights in member States than
with awarding damages.

26. A general principle applied to affording just satisfaction is to put the applicant so far as possible in the
position in which he would have been if the State had complied with its obligations under the Act. In a
discrimination case, in which the wrongful act is treating A better than B, this involves forming a view about
whether the State should have complied by treating A worse or B better. Normally one would conclude that
A's treatment represented the norm and that B should have been treated better. In some cases, however, it
will be clear that A's treatment was an unjustifiable anomaly. Such a case is _Van Raalte v Netherlands_
(1997) 24 EHRR 503, in which the Court found a breach of article 14 read with article 1 of the First Protocol
because the law exempted unmarried childless women over 45 from paying contributions under the
General Child Benefits Act without exempting unmarried childless men. The exemption for women was
abolished in 1989 but judgment was not given until 1997. The court rejected a claim for repayment of the
contributions from which the applicant would have been exempt if he had been a woman.

27. In my opinion the reason for the rejection of this claim is that if the State had complied with its
Convention obligations, it would [have] done what it did in 1989 and not exempted either men or women. It
follows that the applicant would have been no better off. He would still have had to pay. In the
circumstances, the judgment itself was treated as being sufficient just satisfaction.

28. The same is true in this case. There was no justification whatever for extending the widows' allowance
to men. If, therefore, Parliament had paid proper regard to article 14, it would have abolished the allowance
for widows. Mr Wilkinson would not have received an allowance and no damages are therefore necessary
to put him in the position in which he would have been if there had been compliance with his Convention
rights.”

102. Lord Scott and Lord Brown delivered concurring speeches. Lord Brown approached the issue from a
slightly different angle. However, I need not lengthen this judgment further by referring to his speech since
he apparently regarded his analysis as complementary to Lord Hoffmann's; and, even if it is not, it is not
part of the majority ratio.

THE JUDGE'S REASONING


-----

103. Kerr J began this part of his judgment, at para. 125, by referring to section 8 (3) of the 1998 Act. He
also referred to _Greenfield and two other authorities giving guidance about the general approach to the_
award of damages under section 8.  He did not, however, mention the authorities discussed above, and it
is not clear that he was referred to them.

104. At para. 126 he said:

“On the facts of this case, as I must take them to be on the evidence before the court, I have accepted that
the discrimination against the claimants probably occurred by mistake; they received the amount of support
the government intended them to receive; while others, not on asylum support, accidentally and fortuitously
received more than the government intended that they should receive, in the form of an unmerited
windfall.”

105. However, notwithstanding that repeated acceptance that their comparators received “an unmerited
windfall”, he went on to find, as we have seen, that in the circumstances of this case the Claimants were
entitled to an award of damages for financial loss. His reasons appear at paras. 127-133, as follows:

“127. … While I accept that there was no deliberate targeting of the claimants and the group of which they
form part, there does seem to be real force in Mr Buttler's submission that the treatment of the claimants
has been egregious.

128.  I come back to the point that the claimants are, as victims of trafficking, by definition part of a group
of vulnerable persons whom the state has a duty to protect and assist. They have not been given the same
entitlement to benefits as others who are in the same position in all respects save for not being asylum
seekers. They have, in a real sense, been deprived of an entitlement because they are asylum seekers as
well as being victims of trafficking.

129.  In that context I do not think the Secretary of State's argument that there was no deliberate targeting
carries much weight. Discrimination claims under the _[Equality Act 2010 often do not involve deliberate](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
targeting. Where financial loss is caused by the discrimination it is recoverable however noble the motive of
the discriminator. Any egregious conduct by the discriminator is reflected in the size of awards for injury to
feelings rather than financial loss.

130. I also bear in mind that since being put on notice of the discrimination, the Secretary of State has
taken a deliberate decision not to make good, by way of arrears, the amounts of money that would have
been paid to these victims of trafficking if they had not also been asylum seekers.

131. Instead, she has unsuccessfully sought to justify in court doing nothing to remedy the discrimination
until after an unspecified amount of time has elapsed to enable the proposed wholesale reform to be
carried out. The Secretary of State hopes that this will be 'going live' this calendar year, but it is only a
hope, as it is expressly 'subject to resource and capacity constraints'; a caveat that does not augur well for
the claimants.

132. Those features of the case do not lead me to conclude that the Secretary of State is taking the
continuing discrimination against the claimants particularly seriously, despite their vulnerability, which
weighs with me considerably, and the added distress that must have been caused by the discrimination.

133.  For those reasons, I am satisfied that this is a case where an award of damages is necessary to
afford just satisfaction to the claimants. They should recover as financial loss the amounts they would have
received if they had not been asylum seekers as well as victims of trafficking. I do not accept that this
means they can claim the amount of expense incurred when attending appointments.

134.  Their financial loss corresponds, in my judgment, to an amount equal to back payments of what they
would have received but for the discrimination (as was ordered by Mostyn J in _K's case), by way of an_
award of damages for financial loss. They should, in addition, receive a relatively modest award of nonfinancial loss to compensate them for the distress caused by the discrimination.”


-----

106. The reference in para. 134 to “back payments of what they would have received but for the
discrimination” is rather inexplicit, but it is clear that the Judge was referring to payments of VoT dependent
child support, which is what the Claimants were saying that they had been deprived of.

107. That reasoning appears to have three elements (ignoring at present the distinct question whether
there should be an award for distress).

108. First, the treatment of the Claimants is said to have been “egregious” (para. 127), apparently in the
sense that it was exceptionally culpable. The features which the Judge believed deserved that epithet are
apparently that victims of trafficking in the position of the Claimants are peculiarly vulnerable (paras. 128
and 132) and that the Secretary of State had so far done nothing to remedy the anomaly and was not
taking the situation sufficiently seriously (paras. 130-132).

109. Second, the Claimants and others in their position had been deprived of an entitlement because they
were asylum-seekers (paras. 128 and 130).

110. Third, it was irrelevant that the discriminatory treatment was not “deliberately targeted” at the
Claimants: in discrimination claims it is the differential treatment that matters, not the discriminator's motive
(para. 129). It seems that this is the reason why the Judge believed that his acceptance of the Secretary of
State's case on “windfall” did not preclude an award of damages.

DISCUSSION AND CONCLUSION

111. On the basis of my analysis at paras. 89-90 above, this was not a case in which an award of
damages was necessary. Although the Claimants did not receive VoT dependent child support, they
received the equivalent sum by way of asylum-seeker dependent child support. There was thus in reality
no financial loss for which they needed to be compensated.

112. That conclusion might be thought to mean that the Claimants' claim should have failed on liability:
discrimination requires a difference in treatment which is real rather than purely nominal. But it appears
(see para. 72 (1) above) that the Secretary of State admitted differential treatment without seeking to
distinguish between VoT child support disadvantage and mainstream benefits disadvantage, with the
consequence – there being no appeal against the Judge's conclusion on justification, at least as regards
direct discrimination – that the battle falls to be fought at the stage of remedy rather than liability. That is
untidy, but it cannot be a reason for awarding damages where there has been no loss. As it happens, a
similar situation seems to have arisen in Hooper: see the passage quoted from Lord Phillips's judgment at
para. 96 above.

113. The Judge's reasoning does not address that straightforward point because he proceeded on the
basis that the relevant disadvantage was what he called at para. 126 “the unmerited windfall”. But that is a
reference to the mainstream benefits disadvantage, which is not what the Claimants were complaining of.
That being so, I need not consider his reasoning in detail. However, I should say that I do not accept it, for
the following reasons.

114. The fundamental point is that in my view it necessarily follows from his finding on the “mistake” issue,
repeated at para. 126, that this case falls within the ratio of the Van Raalte line of authorities – to which, as
I have said, he makes no reference. The fact that victims of trafficking on mainstream benefits were paid
twice for the same needs was, to adopt Lord Hoffmann's phrase in Wilkinson, “an unjustifiable anomaly”:
what would have happened, if the Government had had its eye on the ball, was that adjustments would
have been made to either the amount of VoT support or the amount of mainstream benefits so as to
remove the element of double payment for the same need.

115. Once that is established, the points relied on by the Judge, as analysed at paras. 108-110 above, are
no answer. Taking them briefly:

(1) The fact that victims of trafficking are, as a class, peculiarly vulnerable cannot in itself justify paying
them an amount which is an unjustifiable anomaly simply because others get it. It can of course be
argued, and indeed was, that all victims of trafficking with dependent children should, whatever the
Government intended be put in the same position as those in group 3 – or in any event should receive


-----

more financial support than they do. But that is an argument based on irrationality and not on
discrimination, and it was rejected by the Judge.

(2) The delay by the Government in introducing the replacement scheme described (in outline) by Ms
Tann could not in itself alter the fact that the advantage currently enjoyed by victims of trafficking in group 3
was an anomaly. (It might in theory have been the basis of an argument that it was not in fact a mistake at
all; but that is not what the Judge found.) The purpose of an award under section 8 is not to punish the
wrongdoer for dilatoriness but to make just satisfaction for the actual loss suffered.

(3) The Judge was, for the reasons already given, wrong to say that the mainstream benefits disadvantage
arose because the Claimants were asylum-seekers: rather it was the result of their nationality/immigration
status. But even if he had been right, the point goes nowhere if the difference of treatment was anomalous
in the Van Raalte sense.

(4) The Judge is right that if the Claimants had in fact suffered a loss the fact that the discrimination was
not “targeted” would not be a reason for denying them an award of damages. But the effect of the _Van_
_Raalte line of authorities is that they had in fact suffered no loss._

116. Mr Buttler advanced an alternative argument to the effect that, since Ms Tann's evidence was that the
Government was seeking to remedy the anomaly by replacing the existing system for victims of trafficking
with “an individualised needs-based approach”, the likelihood was that such a system would have resulted
in greater payments to lone parent victims, like the Claimants, who were unable to afford to attend
trafficking-related appointments; and that Kerr J should have awarded compensation on the basis that they
had lost the amounts that they would have received on that basis. This argument was not raised in the
Respondents' Notice, but in any event it is in my view misconceived. The fact is that on the Secretary of
State's policy as it was at the material time, which provided for standard payments to all victims of
trafficking in respect of their essential living needs, the payments made to victims in group 3 were
anomalous. It is immaterial that she intends in due course to adopt a different policy which might be more
beneficial in some cases.

117. It also follows from the foregoing that the Claimants are not entitled to any damages for the distress
caused by the discrimination, as awarded by the Judge at para. 134. There is evidence that they suffered
distress from their financial situation generally, or in any event from their consequent inability to attend
trafficking-related appointments. But no distress can have been caused by the specific treatment
complained of – i.e. not receiving VoT dependent child support – since they received the equivalent
amount by way of asylum-seeker dependent child support. (It is also doubtful whether the Claimants were
in any event aware, at least until they received legal advice, that they were, even nominally, receiving less
than other victims of trafficking.)

118. We heard some interesting submissions about the approach of the ECtHR to awards of damages for
non-pecuniary loss, and I should pay tribute to the work of the Claimants' counsel in producing a
comprehensive table of all the Strasbourg decisions in which an award of damages for distress had been
made; but since there is no basis for such an award here I do not think I should embark on any analysis.
One question was whether the Court would in an appropriate case presume, or infer, that the victim of a
breach had suffered distress. Without expressing a view on that question, it seems to me that if a claimant
seeks an award of damages for distress caused by the breach of a Convention right they would be well
advised to adduce specific evidence about it.

**(3)                         THE INDIRECT DISCRIMINATION CLAIM**

INTRODUCTORY

119. I should note by way of preliminary that the lion's share of the argument before us was focused on
the first two issues. Comparatively little time was spent on the indirect discrimination claim, and some
possible aspects were not explored in submissions.


-----

120. The approach to the usual case of indirect discrimination in the context of article 14 of the ECtHR is
sufficiently summarised for our purposes in para. 59 of the judgment of Lord Reed in R (SC) v Secretary of
_State for Work and Pensions_ _[2021] UKSC 26, [2022] AC 223, where he says:_

“… [I]t has to be shown by the claimant that a neutrally formulated measure affects a disproportionate
number of members of a group of persons sharing a characteristic which is alleged to be the ground of
discrimination, so as to give rise to a presumption of indirect discrimination. Once a prima facie case of
indirect discrimination has been established, the burden shifts to the state to show that the indirect
difference in treatment is not discriminatory.”

At para. 48 he makes the point that failure to treat unlike cases differently is also a well-recognised form of
discrimination.

HOW THE CLAIM WAS PUT

121. I start with how MD formulated her indirect discrimination claim in her judicial review grounds.

122. The treatment complained of is identified at paras. 53 and 54 under two heads – “Failure to treat like
cases alike” and “Failure to treat differently, in breach of the Thlimmenos principle”. The essence of the
former case (so-called “orthodox” indirect discrimination) is that victims of trafficking in group 2 have (at
least) the same needs as victims in group 3 and yet receive less financial support: this essentially tracks
the complaint in the direct discrimination claim. The essence of the latter (so-called “Thlimmenos
discrimination”) is that victims of trafficking who are lone parents are in a different position from victims who
are co-parents, for the reasons summarised at para. 48 above, and should accordingly have been treated
differently.

123. The differential impact of that treatment on women is set out at para. 55, as follows:

“Differential impact on women: The Defendant's withholding of additional support payments to victims of
trafficking with children in receipt of asylum support has a disproportionately prejudicial effect on women.
This is because substantially more women than men are lone parent victims of trafficking. The Salvation
Army found in 2012 that, of 625 victims of trafficking, 24% of women had dependent children compared
with 3% of men and 'these women were usually ... single parents'.”

124. The relief claimed was the same as in respect of the claim of direct discrimination.

125. The claim was put more fully at paras. 35-37 of MD's skeleton argument before the Judge. I need not
set them out in full. The relevant group was defined in para. 36 as “all victims of trafficking with dependent
children who are in receipt of asylum support” (i.e. group 2). As regards orthodox indirect discrimination,
the treatment complained of was the application to that group of “the Exclusionary Rule” (i.e. the
disentitlement to VoT dependent child support): in Lord Reed's terminology that is the “neutrally formulated
measure”. That rule was said to have a disproportionately adverse impact on two parts of that group:

- lone parents, because they cannot rely on a co-parent to provide childcare while they attend traffickingrelated appointments;

- women, because they are disproportionately likely to be lone parents.

126. I make four points about that formulation:

(1) It involves a fundamentally different comparison than the direct discrimination claim. Although the
skeleton argument refers to “the Exclusionary Rule”, the reference is strictly irrelevant. The comparison is
between two groups who are subject to the rule – lone parents and parents with partners – not between
those who are subject to it and those who are not: there is no need, therefore, to show that the gender
make-up of the two groups is different.  The differential impact as between men and women does not
consist of the non-payment of VoT dependent child support as such, which is the same for both, but of the
greater difficulties which it causes to lone parents.  Mr Buttler said that the form of indirect discrimination
thus pleaded was recognised by this Court in _R (Salvato) v Secretary of State for Work and Pensions_

_[2021] EWCA Civ 1482: see paras. 54-77 in the judgment of Andrews LJ._


-----

(2) It would appear to follow that the measure of any pecuniary compensation should not as such be the
back-payment of the “withheld” VoT dependent child support. Since the differential impact does not consist
of the non-payment of that support (which applies to both lone parents and co-parents) but of the greater
difficulties which it causes to lone parents any compensation should be addressed to that impact and its
consequences.

(3) The approach to justification must be different than in the case of direct discrimination. What the
Secretary of State would have to justify was a measure that produced a state of affairs where the rate of
child support paid to asylum-seeking victims of trafficking rule had a disproportionate impact on lone
parents (who are disproportionately female) because of their greater needs.

(4) It follows from my conclusions on the direct discrimination claim that the limitation of the case to
_asylum-seeking lone parent victims of trafficking (group 2) is a red herring. Non-asylum-seeking lone_
parent victims of trafficking (group 3) receive the same level of support, albeit with a different label. But
that does not affect the substantive point.

127. However, although that is MD's case as originally formulated, the Judge proceeded, he says by
agreement, on a different basis. As we have seen, at para. 5 of his judgment he says:

“In the course of oral argument at the hearing the claimants adopted the court's suggestion that the
adverse impact can be more simply identified in that members of the disadvantaged group – lone parent
_asylum seeker victims of trafficking, who are mainly female – receive less money each week than others,_
_not seeking asylum, who are not members of that disadvantaged group [my emphasis].”_

He made the same point in the section of his judgment where he was setting out the Claimants'
submissions. At paras. 50-53 he summarised their case as advanced “in written argument and evidence”.
At para. 53 in particular he summarised the detailed evidence which he had heard about the difficulties for
lone parents in attending trafficking-related appointments. He then said, at para. 54:

“These propositions, though pressed at length and in detail, are not particularly controversial and were not
substantially disputed by the Secretary of State. In any case, the difference of treatment is easily
established by observing, more simply, that those affected by what the claimants call the exclusionary rule
_receive less money each week than those not affected by it [my emphasis]; an observation from the court_
which the claimants were content to adopt and which the Secretary of State did not (and could not)
dispute.”

128. That reformulation wholly changes the nature of the case advanced. The comparison becomes, as
with the direct discrimination claim, between victims of trafficking with dependent children to whom “the
Exclusionary Rule” applies and victims of trafficking with dependent children to whom it does not. In
consequence, the disadvantage is simply the non-receipt of the money, rather than having the same
money but greater needs. Although the Judge is not explicit about his reasons for preferring that
formulation, it seems from the context that he may well have had in mind the problems that would be
caused by having to assess loss on any other basis than simply the non-receipt of money: cf. para. 126 (2)
above.

129. As regards the claim of Thlimmenos discrimination, at para. 49 of his judgment, as part of the section
setting out the parties' submissions, the Judge said:

“After some discussion at the hearing, it was clarified that the claimants' case is advanced as one of
orthodox indirect discrimination in the form of disparate impact on those two groups13, rather than as in
written argument, discrimination by failing without reasonable justification to differentiate the treatment of
persons in unlike positions, as articulated by the European Court of Human Rights in _Thlimmenos v._
_Greece (2000) 31 EHRR 411 (at [44]).”_

THE JUDGE'S DECISION

130. The Judge's declaration was that the Secretary of State's policy was discriminatory “against women”:
he did not find that it was discriminatory against lone parents as such.


-----

131. His reasons for that finding (leaving aside the issue of justification) are at paras. 90-96 of his
judgment, which read as follows:

“90. I consider next the second way in which the article 14 claim is put, as a claim of indirect
discrimination: that the exclusionary rule impacts adversely on lone parent asylum seeking victims of
trafficking, most of whom are women.

91. The Secretary of State does not deny the adverse impact of the regime on women. While the court is
not equipped with fully up to date statistical evidence that asylum seeking victims of trafficking who are
lone parents are mostly women, the Salvation Army found in 2012 that of 625 victims of trafficking, 24 per
cent of women had dependent children compared with 3 per cent of men and '[t]hese women were usually
single parents, whereas men with children were accompanied by their female partners'.

92. Realistically, neither Mr Tam nor Ms Tann suggested that the contrary may be the case. The
unfortunate truth is that asylum seeking victims of trafficking with dependent children are in most cases
women who have been trafficked, and in many cases for the purpose of sexual exploitation like the
claimants. I do not think any sensible person would suggest otherwise.

93. I do not accept the Secretary of State's suggestion in Mr Tam's oral presentation that the correct
comparison for article 14 purposes is with male lone parent asylum seeking victims of trafficking. That
comparison overlooks the core status of women as a group entitled to the protection of article 14. The
correct comparison is with asylum seeking victims of trafficking without dependent children.

94. Nor, by the same reasoning, do I accept the suggestion in oral argument that the claimants' case
amounts to a 'plea for positive discrimination', i.e. a claim that they should receive preferential treatment in
the form of more money than is available to others with no worse a claim to the same extra money. That is
not correct because there is a difference of treatment which undeniably impacts adversely on a class of
persons predominantly comprising women.

95. Again, it is open to the Secretary of State to characterise the case of [sic] one where an unmerited
windfall is bestowed on another class of persons. But calling the payments to others a windfall does not
escape the conclusion that if you are a lone parent asylum seeker you are going to miss out on the windfall
and that those in that class who miss out on the windfall are predominantly women.

96. Indirect discrimination against that predominantly female class is therefore made out and engages
article 14 which, again, is thereby breached unless the difference of treatment can be justified. Adverse
impact is sufficiently established by the fact that members of the affected class get less money each week
than those not affected. It is not necessary to go further and make detailed findings about the cost and
availability of child care, the need for children not to attend their parents' trafficking related appointments,
and so forth.”

(The references in that passage to “the claimants” are strictly inaccurate because this claim was only
advanced by MD.)

132. The Judge's consideration of justification begins as follows:

“97. I turn next to consider the Secretary of State's defence of justification. I do so in respect of both
differences of treatment that have been made out, taking them together. The effect on the class
discriminated against is the same in the direct discrimination claim and the indirect discrimination claim.
The justification contended for is the same and, it seems to me, must succeed in both cases or neither. I
cannot see how it could succeed in one case and fail in the other.

98. It is the difference in treatment that must be justified, not the measure which causes it. …”

I need not set out the rest of his reasoning. It will be seen that the Judge approached the issue of
justification on the same basis for both the direct and indirect discrimination claims.

133. As we have already seen, the Judge also approached the issue of damages without distinguishing
between the direct and indirect discrimination claims.


-----

DISCUSSION AND CONCLUSION

134. It was common ground before us that there are elements in the Judge's reasoning which are, with
respect, plainly wrong.

135. In the first place, the exercise required by the Judge's reformulation was to compare the gender
proportions between (a) the group of asylum-seeking victims of trafficking with dependent children (being
those to whom “the Exclusionary Rule” is applied) and (b) the group of _non-asylum-seeking victims of_
trafficking with dependent children (to whom it is not applied). However, he says at para. 93 that “[t]he
correct comparison is with asylum seeking victims of trafficking without dependent children [my emphasis]”.
That cannot be right: “the Exclusionary Rule” only applies to victims of trafficking with dependent children.
Mr Tam submitted that there was in fact no evidence of any gender disproportion between the two groups,
but it is enough to say that the Judge failed to address the question.

136. Second, the Judge appears, at paras. 94 and 95, to proceed on the basis that indirect sex
discrimination can be established by showing that the measure complained of is applied to a group
“predominantly comprising women”, as he had emphasised at para. 92. But that is not a correct approach:
it is not the gender composition of the pool affected that matters but whether the measure has a differential
impact as between men and women within the pool. For a recent example of this point being made, see
para. 45 of the judgment of Andrews LJ in Salvato.

137. Third, paras. 97-98 of the judgment wrongly elide the tests of justification for direct and indirect
discrimination. Contrary to what the Judge said, it is the measure that has to be justified, not the
discriminatory effect.

138. As regards _prima facie discrimination, Mr Buttler frankly acknowledged that he could not defend_
paras. 92-95 of the judgment. But he relied on two alternative bases, pleaded at paras. 5 and 6 of the
Respondent's Notice, on which he says that the Judge's finding of indirect sex discrimination can be
upheld. They read as follows:

“5. … Kerr J's finding of indirect discrimination against women should be upheld on the alternative basis
that ... the Exclusionary Rule has a disproportionately adverse effect on women, in that women are
disproportionately less able than men to rely on a co-parent to provide childcare to enable them to attend
and meaningly participate in trafficking or appointments. This is because (as the Secretary of State
accepted and Kerr J found – judgment paras. 91-92) female victims of trafficking with children are usually
single parents, whereas male victims of trafficking with children usually have a partner. This means that the
Exclusionary Rule (which withholds money that would pay for childcare) serves to make it generally more
difficult for female than male victims of trafficking to obtain the counselling, healthcare and legal help they
need ...

6. Further, Kerr J was right to order damages for breach of Article 14 ECHR, for the reason that the
Exclusionary Rule gives rise to Thlimmenos-type discrimination, in that single parents are in a significantly
different situation from co-parents in that they have additional trafficking-related needs associated with
being a single parent (i.e. a need for paid childcare to attend trafficking-related appointments). …”.

139. Mr Tam submitted that neither argument is open to MD on this appeal because both represented
cases that were abandoned below. As for para. 5, that was a reversion to MD's original formulation of the
indirect discrimination claim: as Kerr J records at paras. 5 and 54 of his judgment, his proposed
reformulation, which quite clearly involved a departure from the original formulation, was accepted by Mr
Buttler. As for para. 6, Mr Tam referred us to para. 49 of the judgment (see para. 129 above).

140. This objection gives rise to a real difficulty. Mr Buttler told us in his oral submissions that,
notwithstanding what the Judge says at paras. 5 and 54 of the judgment, he had never abandoned his
original formulation; but Mr Tam submitted that he had indeed done so. Likewise, a footnote in Mr Buttler's
skeleton argument says that, “contrary to the impression given at [para.] 90 [of the judgment]” (there is no
reference to para. 49), the Thlimmenos ground was not abandoned and that instead “MD indicated that she
was content for it not to be determined if the indirect discrimination claim were allowed on an alternative
basis” Given the very limited focus on the indirect discrimination case at the hearing before us these


-----

points were not explored further. Even if they had been, it might not have been easy to decide whether
Kerr J had indeed mischaracterised what had been said. It goes without saying that I do not doubt that Mr
Buttler believes that his position is mis-stated in the judgment. On the other hand, para. 5 and para. 49 are
quite explicit, and it would be surprising if Kerr J had misunderstood Mr Buttler's position on two points on
which it is clear there had been substantial discussion and which were fundamental to his analysis.

141. On balance I think the fairer course is for us to consider the points raised in the Respondent's Notice
without prejudice to whether they are formally open to MD. However, that course is not without difficulties.
The Judge simply did not address either MD's “orthodox” indirect discrimination claim, as originally
formulated, or her _Thlimmenos claim, and so we do not have the benefit of any findings specifically_
directed to them; and, as I have said, we heard only very limited submissions. We can only proceed on the
basis of the judgment as it stands and the submissions made; and that means a fairly summary analysis.

142. Taking that course, I have concluded that MD's claim of indirect discrimination should be dismissed,
whether it is put on the “orthodox” or the Thlimmenos basis. My reasons are as follows.

143. I am prepared to accept that the evidence recorded by the Judge at para. 91 of his judgment
establishes that a substantially higher proportion of female than male asylum-seeking victims of trafficking
with dependent children in group 2 are lone parents. The evidence is extremely slender but it was
unchallenged and is inherently plausible. I also accept that lone parents are more likely than co-parents to
experience difficulties in attending trafficking-related appointments for the reasons given at para. 49 above
– although, as there noted, that is not necessarily the case, and it is not possible to establish what
proportion do so.

144. However, Mr Tam submitted that that was not enough to establish _prima facie discrimination. He_
emphasised that we were not here dealing with a requirement or condition of some kind governing access
to a benefit which women would find more difficult to comply with than men, but rather with a flat rate
benefit which was said to disadvantage women because their needs were in a disproportionate number of
cases greater than those of the men to whom it was paid. The effect of that submission appears to be that
the situation in this case is not analogous to that considered in Salvato, as Mr Buttler had submitted (see
para. 126 (1) above), but rather to R (Adiatu) v Her Majesty's Treasury [2020] EWHC 1554, [2020] PTSR
2198(he did not refer specifically to either authority, but his submissions on the issue were perforce very
summary). In Salvato this Court was concerned with the rule that the childcare costs element of universal
credit can only be claimed after the costs have been incurred. It upheld a finding that the rule was prima
_facie discriminatory because lower earners were less likely to be able to pay for childcare in advance and_
women were disproportionately lower earning than men.  In _Adiatu the Divisional Court rejected an_
argument that the rate of statutory sick pay was discriminatory against women because a higher proportion
of women were low earners: see paras. 140-149.

145. Further and in any event, Mr Tam submitted that even if prima facie discrimination could be found in
the circumstances of MD's case it would be justified. It was plainly a legitimate policy choice for the
Government to have a single rate of payment in respect of the essential living needs of a dependent child.

146. I am inclined to think that both Mr Tam's submissions are well-founded. But in the unusual
circumstances of the present case I prefer to decide the case on as limited a basis as possible. The issues
raised by the first submission may not be straightforward and it is unsatisfactory to decide them on the
basis of the materials and submissions before us. Accordingly, I will limit my decision to the question of
justification. In my view it was indeed plainly within the wide discretion available to the Secretary of State
in a decision of this character to set a fixed rate of child support notwithstanding that inevitably some
parents would have greater financial needs than others. No doubt the financial needs of lone parents
might be expected to be greater – overall, though certainly not in all cases – than those of co-parents; but I
do not believe that that is sufficient to require the Secretary of State to make special provision for them.
Nor do I believe that it makes a difference that the comparatively few male victims of trafficking with
dependent children are less likely to be lone parents.

147. My conclusion is supported by the fact that the Judge rejected the irrationality argument. I note that
at para 85 he observed that:


-----

“It is not incumbent on government to cover the child care costs associated with attending appointments
even though it is clearly inappropriate for the victim's dependent children to attend them in most cases; and
even though the victim's attendance of such appointments is made more difficult by the absence of
properly funded child care.”

At para. 4 of the Respondent's Notice that conclusion is said to be contrary to the UK's obligations under
article 12 of ECAT. The point was not developed before us, but I do not accept it in any event: the
obligations imposed by article 12 are general in character and it is a matter for the Government how
specifically to implement them. It must no doubt do so rationally, but that is what the Judge found it had
done.

148.  I should note for completeness that at para. 7 of the Respondent's Notice it is contended that the
Secretary of State cannot seek to justify any _prima facie discrimination in circumstances where her own_
evidence was that she was proposing to introduce a new needs-based scheme of VoT support. I see
nothing in this point. The fact that the Government proposes to change its policy does not of itself mean
that the previous policy was unjustifiable.

149. I would accordingly allow the appeal on this ground.

**DISPOSAL**

150. I would allow the Secretary of State's appeal on both surviving grounds. The result is that I would set
aside element (b) in the declaration at para. 1 of the Judge's Order and set aside paras. 2 and 3 in their
entirety.

**Asplin LJ:**

151. I agree.

**Simler LJ:**

152. I also agree, and wish to add a few words, associating myself with Underhill LJ's observation at
paragraph 7. In an appeal that focussed entirely on technical legal arguments, it might be thought easy to
lose sight of the individual tragedy suffered by each of the women involved in this appeal. They are both
single mothers: MD has two sons and EH has a daughter and a son. Both were trafficked from Albania,
suffering horrific sexual and other abuse at the hands of their traffickers, and both have been
psychologically traumatised by their experiences. They are undoubtedly vulnerable, and I do not
underestimate the difficulties they have had in coming to the United Kingdom and adjusting to life here in
these circumstances.

**End of Document**


-----

