# R (on the application of MD and another) v Secretary of State for the Home
 Department [2021] EWHC 1370 (Admin)

Queen's Bench Division, Administrative Court (London)

Kerr J

24 May 2021Judgment

**Mr Chris Buttler and Ms Ayesha Christie (instructed by (1) Simpson Millar LLP (2) Deighton Pierce**
**Glynn Limited) for the Claimants**

**Mr Robin Tam QC and Mr Jack Anderson (instructed by** **Government Legal Department) for the**
**Defendant**

Hearing dates: 2nd and 3rd March 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that no official shorthand note shall be taken of this Judgment and that copies of this version as handed
down may be treated as authentic.

.............................

MR JUSTICE KERR

Covid-19 Protocol: this judgment was handed down by the judge remotely by circulation to the parties'
representatives by email and release to Bailii. The date and time of hand-down is 10am on 24 May 2021

**Mr Justice Kerr :**

**Introduction**

1. The claimants are single mothers from Albania living in this country. Both have suffered much. They
have dependent children. They have been conclusively found to be victims of sex trafficking. They are
now receiving support in this country under the support regime for victims of trafficking. Both have also
sought asylum. They have now been recognised as refugees. MD's asylum application was granted on 21
February 2021; EH's, on 29 March 2021.

2. It is common ground that because they are asylum seekers, in receipt of asylum support, they do not
receive financial support under the provisions of the **_Modern Slavery Victim Care Contract in respect of_**
any dependent children; whereas if they were not in receipt of asylum support but in receipt of financial
support from other sources (universal credit, “legacy” benefits or paid work) they would receive financial
support in respect of dependent children.

3. The claimants submit that this difference of treatment between asylum seeker victims of trafficking with
dependent children and non-asylum seeker victims of trafficking with dependent children is contrary to
article 14 of the European Convention on Human Rights (ECHR), read with article 4 and article 1, first
protocol (A1P1) and cannot be justified; and that it is irrational


-----

4. The claimants also submit that the same difference of treatment violates article 14 because it impacts
adversely on lone parents, who are nearly all women. It was argued at length and in detail that the
adverse impact arose because lone parent asylum seeker victims of trafficking are less able than coparents to obtain and pay for child care that is essential to enable victims to attend appointments, notably
for legal, medical and counselling purposes.

5. In the course of oral argument at the hearing the claimants adopted the court's suggestion that the
adverse impact can be more simply identified in that members of the disadvantaged group - lone parent
asylum seeker victims of trafficking, who are mainly female – receive less money each week than others,
not seeking asylum, who are not members of that disadvantaged group.

6. The claimants, accordingly, seek a declaration that the defendant (Secretary of State) is in breach of
article 14 of the ECHR and damages affording just satisfaction for that breach, to be assessed if not
agreed. The Secretary of State unsuccessfully sought an adjournment of the hearing to enable her to look
into the matter further, but now asks the court to dismiss the claims.

7. The Secretary of State does not dispute that this difference of treatment exists. She submitted that it is
the product of an error and of historical accident. Money paid to victims of trafficking in respect of their
dependent children, where the victims are not in receipt of asylum support but of mainstream benefits
(universal credit or legacy benefits), should be deducted from their mainstream benefits, but through
inadvertence is not being deducted.

8. That is not, says the Secretary of State, discrimination against persons such as the claimants; it is an
unmerited windfall for a class of persons in an arbitrarily advantaged group who ought not to be receiving
the windfall. The Secretary of State accepts that the regime needs changing and asserts that a change is
planned which will consider levels of support on an “individualised” basis.

9. Meanwhile, the Secretary of State asks the court to grant no relief on this application. In her skeleton
argument she advanced the double negative proposition that as between asylum seeking victims of
trafficking and non-asylum seeking victims of trafficking, she “does not admit that there is no justification for
the difference of treatment involved”. The difference of treatment is an “anomaly” which the Secretary of
State intends to address.

10. As for the adverse impact on lone parent asylum seeking victims of trafficking, most of whom are
women, the Secretary of State submits that she “was justified in providing trafficking support in the form of
flat rate payments in accordance with the terms of her policy”. The measure is not manifestly without
reasonable foundation and the court should not intervene, for the decision is as to “how resources should
be allocated”.

**The Facts**

11. In 2013, universal credit (UC) was introduced in this country. It was, as is well known, the most
substantial reform of the social security support system in at least a generation. Alongside UC, those
eligible continued to receive certain “legacy” benefits such as job seeker's allowance, employment support
allowance, child tax credit and child benefit. UC and legacy benefits are often (and in this judgment)
referred to as “mainstream benefits”.

12. The Secretary of State is responsible for administering asylum support to those seeking asylum in this
country. Asylum support is regulated by statute and is broadly concerned with meeting essential living
needs at a level sufficient to avert destitution. Asylum seekers are excluded from receipt of mainstream
benefits. Asylum support includes additional payments for essential needs of dependent children,
including where the asylum seeker is a victim of trafficking.

13. The Secretary of State is also responsible for administering support to victims of trafficking. This is
provided through a policy document called the “MSA Guidance”. MSA stands for **_[Modern Slavery Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
_[2015. The MSA Guidance is made under section 49(1) of that Act. The MSA Guidance implements the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
obligations of the United Kingdom under the Council of Europe Convention on Action Against Trafficking in
Human Beings (ECAT).


-----

14. Those obligations include providing financial support to those identified as victims or potential victims
of trafficking. The MSA Guidance states that the purpose of such support is twofold: to meet the person's
essential living needs; and to meet what the claimants call her “trafficking needs”, i.e. in the language of
the MSA Guidance, to assist with her social, psychological and physical recovery and reintegration into
society after being freed.

15. A victim of trafficking who is also an asylum seeker, accordingly, receives an additional amount for
“trafficking needs”, over and above the amount of asylum support for essential living needs. That
additional amount (currently, £25.40 per week) is what is paid for the purpose of assisting with social,
psychological and physical recovery. The claimants characterise that payment as for “adult trafficking
needs”. The Secretary of State does not accept that description.

16. Asylum seekers with dependent children who are victims of trafficking receive no further payment to
meet what the claimants call the “[a]dult's additional trafficking needs on account of having a child”. In
evidence and argument, the claimants explain that this refers to the need for the victim to purchase child
care for the purpose of attending appointments for legal, medical or counselling purposes and the like,
which her children should not and usually may not attend.

17. The Secretary of State says this is a misleading characterisation because the UK's obligations under
the ECAT do not extend to, and the MSA Guidance does not make provision for, financial support to
purchase child care. For the children of victims the MSA provides only, says the Secretary of State, for
their essential living needs to be met.

18. However, the Secretary of State does accept that if the trafficking victim with dependent children is not
also an asylum seeker but instead in receipt of mainstream benefits, unlike her asylum seeker counterpart
she gets an additional amount (currently, £39.60 per week) per child (plus an additional £5 per week if the
child is aged under one year, or an additional £3 per week if the child is aged from one to three years).

19. That is the effect of the provisions in Annex F to the MSA Guidance, which then contain an exception
at paragraph 15.38 in the case of asylum seekers (now paragraph 15.39 in the January 2021 version, but
not materially different):

“Potential victims or victims of modern slavery receiving NRM [National Referral Mechanism] support who
are receiving asylum support will not receive any financial support through the VCC [Victim Care Contract]
in respect of any dependents, or pregnancy payments as these will be met through the asylum support
system.”

20. That is the difference of treatment under challenge. The claimants call it “the exclusionary rule”,
emphasising that the asylum seeker trafficking victim is excluded from an entitlement enjoyed by her nonasylum seeker counterpart in receipt of mainstream benefits. The Secretary of State prefers the term
“windfall” to describe the anomalous entitlement of the latter to payments that should in principle be
deducted from the mainstream benefits she is receiving.

21. The Secretary of State's policy adviser, Ms Jonet Tann, explains that rates of support and how they
have changed over time is not the subject of any explicit record. The Home Office has no “corporate
memory” from contemporaneous documents on the issue. She suggests the rationale can, however, be
inferred from a comparison with other forms of support.

22. The rates set in 2015 for child dependents of victims of trafficking corresponded to the rates for child
benefit and guardian's allowance at that time. This, Ms Tann says, raises the inference that the purpose of
the payment for dependents was to make a contribution to the cost of raising the child rather than to pay
for child care.

23. Then, in July 2020, the child dependent rates for victims of trafficking were amended to match the
asylum support rate for dependent children (currently £39.60); a rate set by reference to the amount
considered necessary to avert destitution by covering the child's essential living needs.

24. Since the purpose of payments for child dependents is to cover the child's essential needs and nothing
more the Secretary of State suggests that it would be inappropriate to pay twice over for the subsistence


-----

of a child of an asylum seeking victim of trafficking; once through the asylum support system and once
through the MSA Guidance and the VCC. That cannot realistically have been the Secretary of State's
policy when devising the provisions and rates.

25. The anomaly lies, rather, in the payment twice over for the subsistence of a child of a non-asylum
seeking victim of trafficking in receipt of mainstream benefits, the Secretary of State says. She wishes to
investigate the position further, to ensure the evidence before the court is full and accurate, to discharge
her duty of candour. However, the hearing before me was expedited and the court was unwilling to grant
an adjournment for this purpose. The Secretary of State had already been granted three extensions of
time to file her acknowledgment of service and summary grounds and two to file detailed grounds and
evidence.

26. The claimants disputed this inferred interpretation of the history in some detail, referring to the
documentary record and judicial comments about the nature and purpose of various legacy benefits. Child
benefit was not, they said, designed to meet a child's subsistence needs. Asylum support for dependent
children and “trafficking support” for dependent children were intended to meet different needs; the latter
must include “trafficking needs”, while the former would not.

**Grounds of Challenge**

**_The first issue: different treatment as between victims of trafficking receiving_**
**_asylum support and those receiving mainstream benefits_**

27. The claimant advanced two grounds of challenge: breach of article 14 of the ECHR and irrationality.
They made the following main points through Mr Chris Buttler, whose submissions were set out in greater
detail than in my paraphrase.

28. First, a British single mother victim of trafficking on mainstream benefits and receiving income from
part time work, known as “XY”, receives dependent child trafficking support for her daughter. XY is not an
asylum seeker. She has been able to use the extra money to pay for, among other things, child minding
while she attends appointments with her solicitor and her (unfortunately titled) “modern slavery advocate”.

29. XY's case provides an example of the differential treatment. The claimants, being asylum seekers, are
not so fortunate. XY's “trafficking-related needs” are no different from those of the claimants. But XY is
better able to meet them, not just because she receives trafficking support for her daughter but also
because her income from mainstream benefits and part time work is a good deal higher than the asylum
support rate.

30. The difference in treatment engages article 14 because being an asylum seeker victim of trafficking is
“other status” within that article and because the difference in treatment affects enjoyment of rights under
article 4 and A1P1. Since the Secretary of State accepts as much, the only possible defence to breach of
article 14 would be justification for the difference of treatment, i.e. showing that the measure is not
“manifestly without reasonable foundation”.

31. The claimants submitted by reference to well known case law that the “reasonable foundation” must be
established by the defendant; the claimant need not show its manifest absence; the issue is one of
proportionality; there is a sliding scale of scrutiny, depending on the context; and the present case does not
involve socio-economic policy choices with no right or wrong answers, where proportionality is readily
satisfied because appropriate leeway is accorded to the political branches of government.

32. The claimants do not accept the Secretary of State's explanation for the difference in treatment,
inferred from the rates at which certain benefits were paid, in the absence of any contemporary documents
or “corporate memory”. They make several points against the inferred interpretation of the history, not
suggesting any alternative motivation but submitting that they do not have to, because no reasonable
foundation is made out by the Secretary of State.

33. They point out that the introduction of UC in 2013 predated by about two years the current trafficking
support system and accompanying VCC, dating from March 2015; that dependent child trafficking support


-----

is paid to all victims of trafficking without means testing, save only asylum seekers; that child benefit is not
designed to meet a child's essential living needs; and that dependent child trafficking support has never
been offset against mainstream benefits.

34. The claimants further submit that if the Secretary of State's inferred interpretation that the difference in
treatment arose through inadvertence, that shows not the presence but the manifest absence of a
reasonable foundation for the difference in treatment. The error cannot provide a reasonable foundation
for the different treatment.

35. The claimants made further points in oral argument. The Secretary of State, they complained, could
end the discrimination by removing the exclusionary rule pending further review of the position and a more
permanent solution, or by introducing some form of means testing for asylum seeking victims of trafficking
with children. To do so would have followed the reasoning of Lord Kerr JSC (in the context of opposite sex
civil partnerships) in R (Steinfeld) v. Secretary of State for International Development [2020] AC 1 at [50].

36. Furthermore, said the claimants, the evidence showed that the 2015 version of the VCC stated on its
face that it applied to those in receipt of asylum support. A later understanding which, on the evidence,
came into being in 2018 to the contrary effect, was wrong and out of line with the UK's obligations under
the ECAT because the expense of fulfilling the recovery needs of victims of trafficking are self-evidently
higher where the victim has children.

37. Mr Buttler submitted there could be no possible legitimate aim served by continuing the discrimination
while a solution is found; there is no firm timescale for the introduction of an assessment of “individualised”
needs; the disparity of treatment is stark – a shortfall calculated at £93.40 per week in the case of MD - and
the persons suffering from it are already likely to be severely traumatised by their experiences of being
trafficked.

38. And, submit the claimants, the same reasoning must lead the court to characterise as irrational at
common law and therefore unlawful the “exclusionary rule” which denies child trafficking support payments
to asylum seeking victims of trafficking with dependent children, whose trafficking-related needs in respect
of their children are no different from those of non-asylum seeking victims of trafficking.

39. For the Secretary of State, Mr Robin Tam QC made the following main points, as I paraphrase them.
He commented that the overall system of support for asylum seekers, victims of trafficking and others, is
complicated and prone to anomalies at the edges. He likened the system to a squidgy jelly; if you try to
push part of it in from the edge (i.e. eliminate an anomaly), it is squeezed out through a gap in the side
elsewhere in the system (i.e. producing another, different anomaly).

40. The policy judgment of the Secretary of State, Mr Tam submitted, is that the child dependents of
victims of trafficking in receipt of asylum support are funded as regards their subsistence needs; and that
the additional payment for “trafficking needs”, i.e. to assist recovery and reintegration, is not intended to
extend to dependent children and should be confined to their parents.

41. Otherwise, Mr Tam submitted on the basis of Ms Tann's evidence, victims of trafficking would be paid
twice over in respect of their children. That would be contrary to the policy judgment. Similarly, they
should not be paid twice over in respect of their children if they are on mainstream benefits. However, that
part of the policy has not been correctly implemented; the anomaly already mentioned means that some
(such as XY) are being paid twice over.

42. While there is no satisfactory institutional record to demonstrate that, the claimants cannot reasonably
impugn that evidence. The Secretary of State's explanation is supported by the point that non-asylum
seeking victims of trafficking, not on mainstream benefits and not allowed to work, whose support comes
entirely from the VCC, are treated in the same way as asylum seeking victims of trafficking whose support,
likewise, comes entirely from the Secretary of State.

43. The Secretary of State submitted that while use of the child benefit rate and overlaps with legacy
benefits elsewhere in the system were probative of her intention, what mattered ultimately was her policy
judgment, which is a matter for her and not the claimants or the court. The ECAT does not require


-----

trafficking needs payments, over and above subsistence, to extend to children and it is not the policy of the
Secretary of State that they should so extend.

44. The Secretary of State accepts that the anomaly alluded to by the claimants – whereby non-asylum
seeking victims of trafficking on mainstream benefits receive additional dependent children payments,
while asylum seeking victims of trafficking, receiving asylum support, do not – can be said to be a
difference in treatment on the ground of “other status” for article 14 purposes; but, “the ECHR is not a
guarantee of administrative perfection”, as Mr Tam put it.

45. The difference of treatment, he said, should not impel the court to impose “immediate solutions to
complex problems”; that would not respect the state's considerable margin of appreciation in matters of
judgment in the field of social and economic policy. The temporary presence of the anomaly should not be
regarded as rendering the difference in treatment manifestly without reasonable foundation.

46. Further, Mr Tam submitted, there is no deliberate targeting of the affected group. The anomaly should
be addressed by wholesale not piecemeal reform and this would take time; meanwhile, the court should
not intervene in this “difficult policy area”. As he put it in his skeleton argument:

“The Defendant's decision to proceed with finalising the development of a comprehensive new policy
instead of adopting piecemeal reform justifies the continuation of the status quo pending that new policy.
For that reason, the difference in treatment is justified: see, by analogy, R (Harrison) v Justice Secretary

_[[2020] EWHC 2096 (Admin), [2020] HRLR 18 at §107, 111-117, applying](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60GH-0XM3-CGXG-01V2-00000-00&context=1519360)_ _Walden v Liechtenstein and_
distinguishing R (Steinfeld) v Education Secretary _[2018] UKSC 32, [2020] AC 1. In the present case, the_
Defendant has already embarked on the process of designing a new policy, identified its outlines and is
actively working on implementation, with a view to the system going live within this calendar year, subject
to resource and capacity constraints.”

47. By the same reasoning, the decision under challenge cannot be said to be irrational, or Wednesbury
unreasonable, Mr Tam contended. It is rational to decide not to pay trafficking dependency payments to
asylum seeking victims of trafficking where they already receive equivalent payments through asylum
support. The implementation of the policy has gone wrong in that the anomaly has crept in; but there is
nothing irrational about the policy itself.

**_The second issue: adverse impact on victims of trafficking who are lone_**
**_parents who are predominantly women_**

48. The second issue embraces two complaints, taken together. While in their first complaint the
claimants rely on direct discrimination in breach of article 14 against persons with “other status” (asylum
seeking victims of trafficking with dependent children), as a second issue they assert indirect
discrimination, again in breach of article 14, in the form of disparate impact of that difference in treatment
on lone parents, a group also enjoying “other status”; of whom the large majority are women, who have
“core status” for article 14 purposes.

49. After some discussion at the hearing, it was clarified that the claimants' case is advanced as one of
orthodox indirect discrimination in the form of disparate impact on those two groups, rather than as in
written argument, discrimination by failing without reasonable justification to differentiate the treatment of
persons in unlike positions, as articulated by the European Court of Human Rights in _Thlimmenos v._
_Greece (2000) 31 EHRR 411 (at [44])._

50. In written argument and evidence, this second matter of complaint proceeded from the premise that
the “exclusionary rule” disproportionately affected lone parents because they did not have a co-parent to
provide child care while they attended appointments for the purposes of achieving recovery and
reintegration and would therefore either have to use up their own trafficking support payment to buy child
care, or forego the benefits of those appointments; and that the group of lone parents thus affected
predominantly comprises women.

51. Mr Buttler pointed out that, as Mostyn J recognised in _K v. Secretary of State for the Home_
_Department [2019] 4 WLR 92, trafficking support payments have a different purpose from asylum support_


-----

payments; they are intended not just to meet essential living needs to the extent required to stave off
destitution, but also to facilitate the victim's recovery from trauma and reintegration into society. That is
now reflected in the additional £25.40 available to single adult victims, provided for in the MSA Guidance
and the VCC.

52. Mr Buttler stressed the importance to victims of trafficking of being able to attend appointments of
various kinds to promote their recovery and rehabilitation. The appointments may be legal, medical or for
counselling, among other things. He took me in detail through a substantial body of evidence from (among
others) lawyers, clinical psychologists, a consultant psychiatrist and, not least, the claimants themselves.

53. This evidence was deployed to establish, first, that attending such appointments is essential to
recovery from the trauma of being trafficked; second, that children are usually barred from attending to
protect them from hearing about their parent's experiences and to facilitate frank disclosure by the parent;
third, that attending such appointments is time consuming and costs money in the form of transport costs
and the like; fourth, that child care has to be purchased to enable attendance; and fifth, that the claimants,
on asylum support, cannot afford this.

54. These propositions, though pressed at length and in detail, are not particularly controversial and were
not substantially disputed by the Secretary of State. In any case, the difference of treatment is easily
established by observing, more simply, that those affected by what the claimants call the exclusionary rule
receive less money each week than those not affected by it; an observation from the court adopted which
the claimants were content to adopt and which the Secretary of State did not (and could not) dispute.

55. The Secretary of State did, however, adduce evidence of discretionary grants being available in some
cases from the Salvation Army, which administers the VCC on behalf of the Secretary of State, including a
charitable victim care fund; and of the opportunity to submit what Ms Tann called a “purchase order”
requesting ad hoc payment for child care, funded by the Home Office if it is approved.

56. The claimants' evidence in rebuttal, from the claimants' solicitors in contact with charity workers in the
field, described those sources of funding as not specifically related to child care. One support worker
described the process as “very hit and miss” and criticised the process as “convoluted and arbitrary”; grant
applications were normally unsuccessful and, where they succeeded, were given only to enable “access to
education and training”. There were no grants to purchase child care while attending appointments.

57. The claimants submitted that the difference in treatment could not be objectively justified. The
exclusionary rule fails the tests of proportionality, they said; the discriminatory effect of the measure, not
the measure itself, must be justified and not by cost saving alone; any cost saving must be achieved in a
non-discriminatory way. The four stage test in Bank Mellat v HM Treasury (No. 2) [2014] AC 700(per Lord
Reed at [74]) produces a negative conclusion on the issue of justification.

58. For the Secretary of State, Mr Tam submitted that the difference of treatment was justified; it was not
manifestly without reasonable foundation. What is important is that:

“the Court respects the proper boundary between its role and that of the legislature and/or executive. It is
not for the Court to decide how resources should be allocated or to create new of increased schemes of
benefits to meet what it might consider to be hard cases or pressing needs”.

59. Mr Tam made several other points. The ECAT does not oblige the UK to pay for child care to attend
appointments. The Secretary of State's policy judgment is not to fund the cost of such child care. Free
child care from friends or relatives will be available to some lone parent victims of trafficking on asylum
support who need to attend appointments. Their factual circumstances vary greatly.

60. Furthermore as Ms Tann pointed out, victims of trafficking enjoy the same right as anyone else to 15
hours per week of child care for two year olds, for 38 weeks a year; and 15 hours of child care or early
education for each child aged three or four. There is nothing illusory or nebulous about those rights. The
availability of some ad hoc payments on a discretionary or charitable basis is also part of the context in
which trafficking support is considered.


-----

61. As for the saving of public funds, while cost alone cannot justify paying women less than men, the
saving of cost is plainly relevant to justification and can constitute a legitimate aim in the context of an
article 14 claim of indirect discrimination. Mr Tam contended that saving cost alone can justify indirect
discrimination provided there is a relationship of proportionality between the legitimate aim (saving public
funds) and the measure chosen to achieve it.

62. He submitted that the Court of Appeal's endorsement, in the judgment of Sir Terence Etherton MR and
Singh LJ, in R (TP, AR and SXC) v. Secretary of State for Work and Pensions _[2020] EWCA Civ 37, [2020]_
PTSR 1785 at [173], of Swift J's formulation of the principles in his judgment below at [53] supported the
proposition that cost alone can in some cases justify indirectly discriminatory measures where the
necessary relationship of proportionality between the aim and the means of achieving it is present.

63. Mr Tam suggested that this must be right; otherwise the law would be “proceeding on the assumption
that resources are infinite”; yet “there is no general principle that the Defendant must alleviate all potential
hardships at the public expense”. The principle that saving cost alone cannot provide justification for a
discriminatory measure must be confined to “certain categories of direct discrimination on suspect
grounds”.

64. In oral argument, Mr Tam characterised the claimants' indirect discrimination complaint as a plea by
them for positive discrimination or special treatment so that they could enjoy the “windfall” accidentally
bestowed on victims of trafficking in receipt of mainstream benefits. They could only establish the
necessary disparate impact by pointing to receipt of that windfall; aside from that anomaly, the disparate
impact of the difference in treatment is not there.

65. Mr Tam further submitted orally that the claim was not properly characterised as one of discrimination
but a claim for more money to meet individual needs. He suggested the comparison should be not that
relied on by the claimants but, rather, a comparison between asylum seeking victims of trafficking who are
female lone parents and those who are male lone parents; the two groups are treated exactly alike, without
any discrimination on the ground of sex.

**The Submissions on Remedy**

66. The court directed that submissions should be made on whether damages should, in principle, be
awarded in addition to a declaration. Mr Buttler submitted that just satisfaction required an award of both
pecuniary and non-pecuniary damage here for these claimants. Alternatively, the claimants should receive
back payments corresponding to the amounts they would have received in respect of their dependent
children if they had not been asylum seekers.

67. The treatment of the claimants, he argued, was egregious and contrasted starkly with the Secretary of
State's intention, according to Ms Tann's witness statement, to make back payments to victims of
trafficking on mainstream benefits who had not received dependent child trafficking support. The principle
_restitutio in integrum should be applied and damages awarded accordingly._

68. The Secretary of State, Mr Buttler contended, apparently intends to continue the discrimination for an
unspecified period until a durable solution is found. The court should roundly reject her invitation to the
court to tolerate that state of affairs for an indefinite period.

69. The Secretary of State pointed to the prohibition in section 8(3) of the Human Rights Act 1998 against
any award of damages unless the court “is satisfied that the award is necessary to afford just satisfaction to
the person in whose favour it is made”; that issue being determined taking into account the principles
applied by the Court of Human Rights at Strasbourg (section 8(4)).

70. Mr Tam reminded me that, as Lord Bingham said in R (Greenfield) v Home Secretary _[2005] UKHL 14,_

[2005] 1 WLR 673, approving at [9] observations of Lord Woolf MR in _Anufrijeva v Southwark London_
_Borough Council_ _[2003] EWCA Civ 1406, [2004] 1 QB 1124, at [52]-[53]:_

“[t]he remedy of damages generally plays a less prominent role in actions based on breaches of the
articles of the Convention, than in actions based on breaches of private law obligations where, more often
th t th l d l i d i d


-----

Where an infringement of an individual's human rights has occurred, the concern will usually be to bring the
infringement to an end and any question of compensation will be of secondary, if any, importance.”

71. Mr Tam also submitted that the present case was not one where any violation of article 14 led to an
outcome for the claimants that “constitutes or is akin to a private wrong, such as trespass to the person”
(per Laws LJ at [17] in R (Sturnham) v. Parole Board _[2012] EWCA Civ 452, [2013] 2 AC 254). The nature_
and seriousness of the breach is relevant to whether damages are appropriate, as is the question what
steps have been taken to address the matter.

72. He submitted that no damages should be awarded, whether for pecuniary or non-pecuniary loss. To
award damages in the present case would be to extend the existing anomaly and provide a windfall for the
claimants; while the circumstances were quite unlike those where a statutory tort is committed under the
_[Equality Act 2010. It is material that the claimants are already receiving a “substantial package of support](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
from the state in terms of accommodation, healthcare and direct payments”, while the Secretary of State is
“already in the process of introducing a new policy to replace the current arrangements”.

**Reasoning and Conclusions**

73. I will start by considering the factual position. It is unusual and unsatisfactory because the Secretary
of State does not have complete confidence in the evidence she has put before the court. It is entirely
correct and in accordance with her duty of candour that she has informed the court of this difficulty; but it
does put the court in a difficult position when deciding on what factual basis to give its decision.

74. When unsuccessfully seeking an adjournment shortly before the hearing, the Secretary of State said
this in written submissions to the court:

“… the Defendant obviously has a duty to correct any factual position which may not be wholly correct and
to evaluate any effect that may have on her defence to this claim. In addition, the Defendant can see the
possibility that there are arguments that the Claimants may wish to advance once the position has been
clarified.”

75. I refused the adjournment, for reasons I gave in written observations included with my order made on
26 February 2021. The Secretary of State had had ample time to prepare, with a total of five extensions of
time, the hearing had been expedited and Mostyn J had in his order of 14 December 2020 commented that
“the delay in preparation of the defendant's defence and supporting evidence is lamentable”.

76. In his skeleton argument at paragraph 72 (submitted before my decision to refuse an adjournment), Mr
Tam included the following, successfully opposing a separate hearing on the question whether damages
should be recoverable for any breach of article 14 of the ECHR (with my italics):

“… if the Court were to consider the same matters again, there is always a risk of inconsistent findings.
That risk is substantially magnified in the present case by the state of the Defendant's evidence in relation
to the historical position concerning legacy mainstream benefits. If the Claimants' case were adjourned to a
further remedy hearing, _the Defendant may by then have ascertained more details of the position_
_concerning the historical position. As the Defendant has already said, those details may show that her_
_current evidence is incorrect. If the Claimants' proposal were acceded to, the Court at the future remedy_
hearing should proceed on the basis of the updated evidence, which may lead to conclusions that are at
odds with the conclusions reached following the present hearing taking place on the basis of different
evidence.”

77. Yet, while accepting there that it may be her “current evidence is incorrect”, earlier in the same
skeleton argument at paragraph 27, the Secretary of State submitted that, on the issue whether payment of
dependent child trafficking support to those on mainstream benefits is an anomaly, “the Defendant's
evidence on this question cannot reasonably be impugned by the Claimants”. The claimants might be
forgiven for asking “why not?” If the Secretary of State doubts her own evidence, why should the claimants
or the court accept it?

78. One answer is that in judicial review proceedings, the court generally accepts the factual account of
th d f d t d d t t t i f t l di t J di i l i di t ll


-----

suitable for disputes of fact. The claimants have not made any application to cross-examine and I think
they were right not to do so. Applications to cross-examine are not to be encouraged in judicial review
claims.

79. On what factual basis should the court proceed? I have come to the conclusion that, though far from
ideal, the right course is to decide the case on the evidence before the court, since the Secretary of State
does not disavow it, but subject to taking into account that her case is founded on evidence whose
accuracy, completeness and reliability she does not fully guarantee.

80. Mr Tam's analogy between the benefits regime and a “squidgy jelly”, mentioned above, is in my
judgment appropriate and realistic. I accept that the system is complicated and difficult to devise and that
removing one anomaly can create another unless proper thought is applied and care exercised. The
inclusion of article 14 discrimination in our domestic law means that can encourage claims because of the
resulting differences in treatment of persons in different classes or cohorts.

81. For these proceedings only, I accept that the Secretary of State's explanation is realistic and likely to
be the correct inference from such historical material as is available in the documents and in Ms Tann's
witness statement. I do not think it likely that the government would have wanted victims of trafficking on
mainstream benefits and not on asylum support to receive dependent child trafficking support payments in
addition to other payments intended to cover the child's living needs.

82. The most likely explanation is that this was indeed a mistake. No one is, realistically, going to get
money for nothing from the Treasury on purpose. That is indeed what appears to have happened in the
case of XY who has had the misfortune of being a victim of trafficking but the good fortune to be on
mainstream benefits and receiving income from part time work.

83. The claimants have not put forward any credible alternative explanation. I find myself having to accept
the Secretary of State's explanation even though the evidential foundation for it is not solid and it is very
surprising that there are no records or documents directly supporting Ms Tann's deduced account.

84. It is convenient to address the allegation of common law irrationality next. I do not think irrationality is
the right way to characterise a mistake in the execution of a policy that is not itself irrational. The policy
judgment not to pay dependent child trafficking payments to asylum seekers may appear harsh to some
but it is rational. The Secretary of State's policy judgment is not contrary to the UK's obligations under
ECAT, as Mr Tam pointed out.

85. It is not incumbent on government to cover the child care costs associated with attending
appointments even though it is clearly inappropriate for the victim's dependent children to attend them in
most cases; and even though the victim's attendance of such appointments is made more difficult by the
absence of properly funded child care.

86. Some free child care is available under the general law, including to victims of trafficking who are
seeking asylum. The evidence of infrequent ad hoc payments to a few lucky ones with well connected or
persistent support workers is not reassuring, but the paucity of discretionary support from charitable
sources cannot create a funding obligation on the Secretary of State via the concept of irrationality, where
none otherwise exists.

87. I come next to the first issue of differential treatment and article 14 of the ECHR. I do so on the basis
that the Secretary of State did not intend to treat asylum seeking victims of trafficking with dependent
children less favourably as a class than those on mainstream benefits and not seeking asylum.
Nevertheless, it is not disputed that she has done so and continues to do so. Differential treatment is
admitted.

88. Whatever the nature and quality of the error made, its effect is not in doubt: the claimants are in a less
good financial position than those in the position of XY and others. One can argue forensically over
whether the difference of treatment should be characterised as an exclusionary rule or whether it is merely
missing out on an unjustified windfall enjoyed by others. On either view, it is a difference of treatment.


-----

89. Certainly, from the claimant's perspective, the difference of treatment operates as an exclusionary rule.
It is not of comfort to them to be told they are receiving what they should be receiving while others who are
more fortunate are receiving more than they should be receiving. The claimants are still being directly
discriminated against and in breach of article 14 unless, which I shall consider shortly, the discrimination is
justified.

90. I consider next the second way in which the article 14 claim is put, as a claim of indirect discrimination:
that the exclusionary rule impacts adversely on lone parent asylum seeking victims of trafficking, most of
whom are women.

91. The Secretary of State does not deny the adverse impact of the regime on women. While the court is
not equipped with fully up to date statistical evidence that asylum seeking victims of trafficking who are
lone parents are mostly women, the Salvation Army found in 2012 that of 625 victims of trafficking, 24 per
cent of women had dependent children compared with 3 per cent of men and “[t]hese women were usually
single parents, whereas men with children were accompanied by their female partners”.

92. Realistically, neither Mr Tam nor Ms Tann suggested that the contrary may be the case. The
unfortunate truth is that asylum seeking victims of trafficking with dependent children are in most cases
women who have been trafficked, and in many cases for the purpose of sexual exploitation like the
claimants. I do not think any sensible person would suggest otherwise.

93. I do not accept the Secretary of State's suggestion in Mr Tam's oral presentation that the correct
comparison for article 14 purposes is with male lone parent asylum seeking victims of trafficking. That
comparison overlooks the core status of women as a group entitled to the protection of article 14. The
correct comparison is with asylum seeking victims of trafficking without dependent children.

94. Nor, by the same reasoning, do I accept the suggestion in oral argument that the claimants' case
amounts to a “plea for positive discrimination”, i.e. a claim that they should receive preferential treatment in
the form of more money than is available to others with no worse a claim to the same extra money. That is
not correct because there is a difference of treatment which undeniably impacts adversely on a class of
persons predominantly comprising women.

95. Again, it is open to the Secretary of State to characterise the case of one where an unmerited windfall
is bestowed on another class of persons. But calling the payments to others a windfall does not escape
the conclusion that if you are a lone parent asylum seeker you are going to miss out on the windfall and
that those in that class who miss out on the windfall are predominantly women.

96. Indirect discrimination against that predominantly female class is therefore made out and engages
article 14 which, again, is thereby breached unless the difference of treatment can be justified. Adverse
impact is sufficiently established by the fact that members of the affected class get less money each week
than those not affected. It is not necessary to go further and make detailed findings about the cost and
availability of child care, the need for children not to attend their parents' trafficking related appointments,
and so forth.

97. I turn next to consider the Secretary of State's defence of justification. I do so in respect of both
differences of treatment that have been made out, taking them together. The effect on the class
discriminated against is the same in the direct discrimination claim and the indirect discrimination claim.
The justification contended for is the same and, it seems to me, must succeed in both cases or neither. I
cannot see how it could succeed in one case and fail in the other.

98. It is the difference in treatment that must be justified, not the measure which causes it. The threshold
for a justification defence to succeed is relatively low. It is sufficient to show that the measure is not
manifestly without reasonable foundation. It is for the defendant to show the existence of a reasonable
foundation for the difference in treatment.

99. The Secretary of State relies on the saving of public funds as a legitimate aim and contends, as she
must, that the differences in treatment are rationally connected to that aim and are a proportionate means
of achieving it. However, she says – and I accept – that the differences in treatment occurred by mistake,


-----

not intentionally. The saving of public funds was not achieved in that a “windfall” is being and has been
wrongly bestowed on a different group.

100. As regards Mr Tam's submission founded on R (TP, AR and SXC) v. Secretary of State for Work and
_Pensions_ _[2020] EWCA Civ 37, [2020] PTSR 1785 at [173], I accept that there may be indirect_
discrimination cases in which saving public funds forms a large part, if not all, of the case establishing a
relationship of proportionality between that legitimate aim and the means of achieving it, so as to justify a
difference in treatment between different groups.

101. However, I am unimpressed by the argument that the ECHR is not a guarantee of administrative
perfection and that the court should on the facts here readily defer to the state's margin of appreciation in
matters of judgment in the field of social and economic policy. As I have said, I have no difficulty with the
exercise of judgment by the state in the present case. It is the failure properly to implement that judgment,
not the judgment itself, that is in issue.

102. It is the difference of treatment caused by the state's failure to implement a rational judgment made
for the purpose of saving public funds that must be justified. The margin of appreciation available to
protect the making of that judgment in the first place does not so readily protect against incompetence in
executing the judgment. A margin of appreciation is not the same thing as a licence to err.

103. To say that the ECHR is not a guarantee of administrative perfection seems to me little more than an
institutional shrug of the shoulders, along the lines that “these things happen”; or “it's just one of those
things” or some other such commonplace pronouncement.

104. For the court to say otherwise is not illegitimate interference with the role of the executive or the court
imposing “immediate solutions to complex problems”, in Mr Tam's phrase. It is, rather, the court doing its
duty to apply the law (article 14 of the ECHR) which the legislature has chosen for this country.

105. I think the Secretary of State's real submission is that the mistake is pardonable and the court should
indulge the executive and excuse it by allowing a defence of justification. In considering that invitation, the
court has to look at the impact of the error on its victims who, it should not be forgotten, are persons who
by definition have been trafficked and to whom the ECAT obligations are owed to protect them and help
them recover from bad experiences.

106. As noted above, the Secretary of State relies on Eady J's decision in _R (Harrison) v. Secretary of_
_State for Justice, a decision currently under appeal and due to be heard in the Court of Appeal in_
November 2021. The claimants were humanists who complained that the failure of the defendant to
provide for state recognition of humanist marriages under English law violated their rights under article 14
of the ECHR, read with articles 8 and 9.

107. The Law Commission had looked at the issue in a 2015 “scoping paper” and in a review document in
July 2019. In the former, the Law Commission agreed with the government that the law should be
“reformed to accommodate marriages by non-religious belief organisations”; but stated that “any steps to
do that need to take place alongside a broader updating of the law of marriage that seeks to address a
number of long-standing problems.”

108. In the latter 2019 review document, the Commission set itself the task (still ongoing) of making future
recommendations including “how marriage by humanist and other non-religious belief organisations could
be incorporated into a new or revised scheme”. After delay attributed to the coronavirus pandemic, the
claimants evidently ran out of patience and Eady J determined their claim in July 2020.

109. The government submitted among other things that not amending the marriage laws pending
completion of the Law Commission's work furthered the legitimate aims of avoiding adding to the
complexity of the marriage laws; avoiding the creation of new anomalies and new forms of discrimination;
avoiding piecemeal reform when further issues of social policy arose; and giving the government and
Parliament time to “reflect on what should be done when one is considering an evolving societal attitude”
(in the words of Lord Kerr JSC in the Steinfeld case at [36]).


-----

110. Eady J decided (at [112] that the real question was whether the defendant had established “a
legitimate aim in taking time to consider the appropriate solution as part of a wider reform of the law in this
regard?” She noted that Lord Kerr JSC in _Steinfeld had dismissed the argument that the government's_
desire for time to consider the question of reform amounted to a legitimate aim.

111. She observed, however, that unlike in the case before her, in Steinfeld a recent change in the law
had introduced a new difference of treatment (between same sex couples who could enter into a civil
partnership and opposite sex couples who could not). The complaint before her was of failure to exercise
a power under a 2013 statute that could have permitted recognition of humanist marriages.

112. Eady J accepted, on those facts, that pursuit of wholesale reform over time, which the Law
Commission had advocated back in 2015, was a legitimate aim and that maintaining the status quo
pending such reform was rationally connected to that aim and a proportionate means of achieving it.

113. At [125], she distinguished _Steinfeld on the basis that remedying the discrimination was_
straightforward, requiring only the immediate extension of civil partnerships to same sex couples. That
was not so in the case before her; there was no simple answer and many related and difficult issues arose
for consideration.

114. In my judgment, the present case is different from both Steinfeld and Harrison. As Mr Tam pointed
out, no mistake was made in Steinfeld. The government had consciously chosen to introduce a new kind
of discrimination and wanted time to evaluate civil partnerships generally, a desire not qualifying as a
legitimate aim. In _Harrison also, no mistake was made but the need for further time for government to_
consider the issues in the round was justified by the complexity and sensitivity of the issues.

115. In the present case, the issues have nothing to do with societal attitudes evolving over time. A simple
mistake was apparently made causing the discrimination complained of. The Secretary of State advances
as a legitimate aim the pursuit of wholesale reform including individualised assessments for asylum seeker
victims of trafficking with dependent children. Leaving the discrimination in place until the government gets
round to reforming benefit entitlements for all affected categories is said to be a proportionate means of
achieving that aim.

116. I do not find that reasoning convincing as a justification for the difference in treatment. The victims of
the discrimination, the claimants and others like them, are very vulnerable people.  They are unlikely to
have the means to pay for child care. There is some free child care available and patchy “hit and miss”
discretionary funding. I accept that, for what it is worth, that is relevant to justification.

117. But it does not persuade me that the present situation should continue for what could be a long time.
The evidence of progress towards the anticipated wholesale reform is sparse. The claimants are offered
“jam tomorrow” with no clear pathway forward. There is no convincing timescale for the wholesale reform.
The evidence for the Secretary of State is not of progress towards reform but of corporate amnesia and
repeated requests for more time.

118. Thus, in the Secretary of State's submissions of 26 February 2021 seeking the adjournment which I
refused, she stated that a cross-departmental review which has not yet started would need to take place
and:

“will involve discussions across Government departments and undertaking significant internal inquires to
ensure that the Claimants and the Court are provided with a complete and accurate picture of the
Defendant's defence. In particular, the DWP is responsible for mainstream benefits, which are governed by
complex and highly technical legislation”.

119. In Mr Tam's skeleton argument for the substantive hearing, he explained that:

“In the present case, the Defendant has already embarked on the process of designing a new policy,
identified its outlines and is actively working on implementation, with a view to the system going live within
this calendar year, subject to resource and capacity constraints (my italics).”


-----

120. The perceived problem that elimination of the discriminatory treatment would create fresh anomalies
and encourage further claims of differential treatment engaging article 14 is, in my judgment, considerably
overstated. If the new reformed regime correctly implements the Secretary of State's policy judgment and
mistakes are avoided, she will have the considerable protection of the state's wide margin of appreciation
in matters of policy judgment in the social security field and will be able to rely on conserving public funds
as a legitimate aim.

121. The spectre of fresh anomalies leading to fresh claims would cut more ice with the court if there were
clear evidence showing what are the outlines of the new policy which is in the course of being designed.
Beyond the reference to “individualised” assessments, we do not know what the policy will be. Yet, MD's
claim was brought as long ago as July 2020 and EH's claim was brought in October 2020.

122. Despite that, as recently as February 2021, the Secretary of State was seeking to adjourn the claims
until June 2021 or later, with only the thin evidence I have mentioned of any real progress towards the
wholesale reform she wishes to introduce.

123. In oral argument, Mr Tam warned the court: “don't tinker”. The tone was good natured and not
disrespectful but the submission was constitutionally wrong and unfair to the court. It was not the court that
decided article 14 should be part of English law; nor how much money victims of trafficking (with or without
children and whether or not seeking asylum) should receive. The court is bound to apply the law and did
not make the law.

124. For those reasons, I do not accept that the Secretary of State has shown a reasonable foundation for
the difference in treatment. On the contrary, the necessary reasonable foundation is in my judgment
manifestly absent. I turn to consider finally whether the claims should sound in damages.

125. I cannot so decide unless I am, under section 8(3) of the Human Rights Act 1998, “satisfied that the
award is necessary to afford just satisfaction to the person in whose favour it is made”. That issue is to be
determined taking into account the principles applied by the Court of Human Rights at Strasbourg (section
8(4)). Those principles are reflected in the domestic authorities cited to me, notably Lord Bingham's
speech in Greenfield. Lord Woolf MR's judgment in Anufrijeva and Laws LJ's judgment in Sturnham.

126. On the facts of this case, as I must take them to be on the evidence before the court, I have accepted
that the discrimination against the claimants probably occurred by mistake; they received the amount of
support the government intended them to receive; while others, not on asylum support, accidentally and
fortuitously received more than the government intended that they should receive, in the form of an
unmerited windfall.

127. I have to consider to what extent that assists the Secretary of State with her contention that I should
not be satisfied that an award of damages is necessary to afford just satisfaction to the claimants. While I
accept that there was no deliberate targeting of the claimants and the group of which they form part, there
does seem to be real force in Mr Buttler's submission that the treatment of the claimants has been
egregious.

128. I come back to the point that the claimants are, as victims of trafficking, by definition part of a group of
vulnerable persons whom the state has a duty to protect and assist. They have not been given the same
entitlement to benefits as others who are in the same position in all respects save for not being asylum
seekers. They have, in a real sense, been deprived of an entitlement because they are asylum seekers as
well as being victims of trafficking.

129. In that context I do not think the Secretary of State's argument that there was no deliberate targeting
carries much weight. Discrimination claims under the _[Equality Act 2010 often do not involve deliberate](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
targeting. Where financial loss is caused by the discrimination it is recoverable however noble the motive
of the discriminator. Any egregious conduct by the discriminator is reflected in the size of awards for injury
to feelings rather than financial loss.


-----

130. I also bear in mind that since being put on notice of the discrimination, the Secretary of State has
taken a deliberate decision not to make good, by way of arrears, the amounts of money that would have
been paid to these victims of trafficking if they had not also been asylum seekers.

131. Instead, she has unsuccessfully sought to justify in court doing nothing to remedy the discrimination
until after an unspecified amount of time has elapsed to enable the proposed wholesale reform to be
carried out. The Secretary of State hopes that this will be “going live” this calendar year, but it is only a
hope, as it is expressly “subject to resource and capacity constraints”; a caveat that does not augur well for
the claimants.

132. Those features of the case do not lead me to conclude that the Secretary of State is taking the
continuing discrimination against the claimants particularly seriously, despite their vulnerability, which
weighs with me considerably, and the added distress that must have been caused by the discrimination.

133. For those reasons, I am satisfied that this is a case where an award of damages is necessary to
afford just satisfaction to the claimants. They should recover as financial loss the amounts they would
have received if they had not been asylum seekers as well as victims of trafficking. I do not accept that this
means they can claim the amount of expense incurred when attending appointments.

134. Their financial loss corresponds, in my judgment, to an amount equal to back payments of what they
would have received but for the discrimination (as was ordered by Mostyn J in _K's case), by way of an_
award of damages for financial loss. They should, in addition, receive a relatively modest award of nonfinancial loss to compensate them for the distress caused by the discrimination.

**Conclusion; disposal**

135. For those reasons, I will grant a declaration to the effect that the difference of treatment does violate
article 14 of the ECHR. I will hear the parties on the wording of the declaration, if it is not agreed. I will
direct that the claimants are entitled to damages in respect of the violation and that the amount of damages
recoverable should be determined in the county court, if not agreed.

**End of Document**


-----

