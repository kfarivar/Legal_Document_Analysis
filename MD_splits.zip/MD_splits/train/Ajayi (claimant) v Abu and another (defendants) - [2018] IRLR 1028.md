# Ajayi (claimant) v Abu and another (defendants) [2018] IRLR 1028

[2017] EWHC 3098 (QB)

Queen's Bench Division

01122017

**_[900   Protection from Harassment Act](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_**

**_[999   Prevention of human trafficking](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_**

**_[5100   National Minimum Wage](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_**
**The facts:**

The claimant came from poor circumstances in a rural village in Nigeria. She was distantly related to the second
defendant, Mrs Abu. The first defendant was Mrs Abu's husband. The claimant started to work for Mrs Abu's sister
in Nigeria when she was probably in her mid-teens. In 2005, the sister and her children travelled to the UK
accompanied by the claimant for a family holiday at the defendants' home. The claimant then stayed with the
defendants' family as a domestic worker, assisting with childcare. She initially spoke very little English. The
defendants paid for her to undertake courses in English, citizenship, computing and child care. They purchased
study materials, clothing and other personal items for her. Payments were made to her, mostly in cash, but no wage
slips were provided. She attended church regularly, generally with the defendants' family. Each year, Mrs Abu
completed the paperwork required by the Home Office to extend the claimant's stay in the UK. In the early years,
the claimant's English was not sufficient for her to complete, read or understand the documents herself. The
defendants also sent letters to the Immigration & Nationality Directorate stating that they employed the claimant as
a domestic worker in accordance with an enclosed contract of employment and confirming that they would comply
with all relevant laws in the UK relating to employment and wages. 'Standard Terms and Conditions' signed by both
the claimant and Mrs Abu were enclosed. In each case, the weekly pay provided for followed the rates required by
the national minimum wage regulations as it increased from year to year. In 2014, relations between the family and
claimant became much more difficult. The defendants found another position for the claimant as a domestic worker,
but she refused to take it up. There was a heated argument in mid-February 2015. At about that time the
defendants took the claimant's house keys from her and removed a key to a shared cupboard where food was
stored. The claimant's employment was terminated in a letter from the defendants dated 5 March 2015. The letter
concluded 'you are now required to leave our house as soon as possible. We will be forced to evict you and call the
police again if you do not leave our home'. She remained at the home, until, later that month, she returned to find all
her belongings packed and placed out on the street.

The claimant brought proceedings, seeking compensation: as the victim of trafficking; as the victim of harassment
under the _[Protection from Harassment Act 1997; on the basis that she was paid less than the statutory rate set](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)_
[under the National Minimum Wage Act 1998; and on the basis that the defendants had been in breach of contract.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)
She submitted that she had never been paid anything like the amounts shown in the submitted terms and
conditions or given two independent days off during the week or five weeks' holiday per year, independent of the
family, as provided for in the terms and conditions. She alleged that she had suffered psychiatric injury of a mild to


-----

moderate degree, namely a mixed anxiety and depressive disorder. The defendants denied all the pleaded grounds
[and sought to rely on the Limitation Act 1980.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)

Article 2.1 of the Trafficking _[Directive 2011/36/EU defined the process of trafficking as involving the 'recruitment,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
transportation, transfer, harbouring or reception of persons, including the exchange or transfer of control over those
persons, by means of the threat or use of force or other forms of coercion, of abduction, or fraud, of deception, of
the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve
the consent of the person having control over another person, for the purpose of exploitation.' Article 3 stated that
'Exploitation shall include, as a minimum, … forced labour or services …' Article 4(a) of the Council of Europe
Convention on Action Against Trafficking in Human Beings (the 'Trafficking Convention') defined trafficking in
almost identical terms.

The High Court (Queen's Bench Division) (Judge Hampton) by a reserved judgment given on 1 December 2017
allowed the claims.
**The High Court held:**

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_

(1) The claimant was the victim of trafficking.

Some of the indicators of forced labour published in guidance notes by the International Labour Organisation were
present. There was abuse of vulnerability, withholding of wages, abusive working and living conditions (for limited
periods), insidious and subtle intimidation and threats to and undermining of the claimant's position, exposure to
excessive overtime, evidence of deceptive practices by the defendants, and indications of intent to exploit the
claimant.

Three factors, the act, the means and the purpose which must be satisfied for trafficking to have occurred, could be
identified from art 2.1 of the Trafficking Directive. Once the claimant arrived in the UK and arrangements were made
for her to stay with the defendant family, the act, namely the harbouring of the claimant or the transfer of control
over the claimant from the sister to the defendants within the meaning of art 2.1, was established. As to the means,
there was no physical force or threat. The coercion was much more subtle. Psychological bonds were imposed
upon the claimant by the expectations of the defendants, the claimant's experience, the parties' social background
and cultural expectations with which the defendants were undoubtedly familiar. The claimant was chained without
physical chains. Her position in the defendants' household was vulnerable, with the ever-present worry of being
returned to Nigeria if she did not conform. That situation established the means. The purpose of the arrangement
was to exploit the claimant's services for the provision of childcare and general domestic help in the defendants'
household for limited payment. The claimant provided services of value to the defendants which enabled them to
work full-time, whilst the claimant cared for their children. In addition, the claimant not only looked after herself
within the home; she undertook household tasks for the defendants, sharing with and relieving them of the burden
of such tasks. She did more than might have been expected of an adult family member. She was in every respect a
domestic worker, whose services the defendants secured without fully complying 'with all the relevant laws in the
UK relating to employment and wages etc', as they falsely represented to the Home Office.

Accordingly, the defendants abused the claimant's position of vulnerability to keep her in a position of effective
economic servitude. The facts required to establish forced labour and therefore trafficking of the claimant were
proved within the meaning of the Trafficking Convention.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_

(2) The claimant was entitled to an award under the National Minimum Wage Act 1997.

From the commencement of her employment until early September 2014, her usual hours of work were 60 hours
per week. Thereafter, her working time diminished to approximately 20 hours per week. The 30 hours per week
referred to in her terms and

**[*1029]**


-----

conditions amounted to 'salaried hours worked' within the meaning of the classifications under the National
Minimum Wage Regulations 1999. Given that those terms and conditions provided for additional hours to attract a
wage of £7.60 per hour, additional work constituted 'time work' for the purposes of the regulations. The defendants
had failed to prove that she was paid any specific regular sum, save for over a short period. Other than the
accommodation offset provided for in the 1999 Regulations, only payments made directly to her could have been
offset against the defendants' minimum wage liability. Pursuant to reg 9(a) of the 1999 Regulations, sums paid for
visas, courses, books and other items could not have been offset. On the balance of probabilities it was likely that
over the course of the nine and a half years the claimant would have received payment in cash of approximately
£100 per month over the whole period, rising to £200 per month for three months; accordingly, from the payments
due to be made to the claimant under the 1998 Act, such payments would be deducted.

The claim for breach of contract did not add anything to the claim under the 1998 Act, save that there was a breach
of the terms and conditions in failing to provide the claimant with free time and holidays as provided for, and failure
to provide private accommodation. Any further compensation in that respect would be dealt with in the claim for
personal injury and distress.

[As the claim for a minimum wage was a claim in contract the primary limitation period was provided for in s 5 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0M0-TWPY-Y0NT-00000-00&context=1519360)
Limitation Act 1980 and was six years. Accordingly, any claim in respect of a breach prior to October 2009 was,
prima facie, time barred. However, the claimant was entitled to rely on s 32(1)(b) and (2). Section 32 operated to
delay the date on which time started to run where a defendant was guilty of deliberate wrongdoing and concealed
or failed to disclose it in circumstances where it was unlikely to have been discovered for some time. In the present
case, there was a deliberate breach of the duty to pay the claimant the minimum wage which was not disclosed to
the claimant and that was committed in circumstances where the claimant was unlikely to discover it for some time.
The claimant did not understand the effect of the documents she was signing until after October 2009.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_

[(3) The claimant was subjected to harassment under the Protection from Harassment Act 1997.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)

The primary focus was on whether the conduct was oppressive and unacceptable albeit the court had to keep in
mind that it had to have been of an order which would have sustained criminal liability. Much of the behaviour relied
upon by the claimant as amounting to harassment, whilst unattractive, regrettable and sometimes unreasonable,
did not cross the boundary into conduct which was oppressive and unacceptable until the later stages of her
employment. The first event amounting to harassment was the confiscation of the claimant's keys to the house. No
finding was made that there was any use or threat of violence. Nevertheless, the removal of keys had the effect of
causing alarm and distress to the claimant. Thereafter, the letter of dismissal was part of a course of conduct
calculated to cause the claimant alarm and distress. Whilst the defendants were entitled to dismiss the claimant as
her employers, the terms of the letter which required her to leave the house when the defendants must have known
that she had no access to or means to pay for alternative accommodation, was oppressive. The defendants had
informed her on more than one occasion that her visa required her to work as a domestic worker in a domestic
household and that if she did not do so she would have to leave the UK. The terms of the letter and the requirement
that she leave the family home, bearing in mind the unequal relationship between the parties and the claimant's
vulnerability as to finding alternative accommodation, amounted to harassment. Finally, the placing of the claimant's
belongings on the street and locking her out was an act of cruelty. It was also harassment within the meaning of the
1997 Act. The claimant was a young woman in a vulnerable position. Simply packing up her belongings and putting
them out on the street, without warning, whilst she was out of the house, so that she returned, finding herself unable
to gain entrance even though the family were within, was calculated to cause alarm and distress. Accordingly the
defendants had pursued a course of conduct which amounted to harassment and the claimant was entitled to
damages.

_[900, 999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_

(4) The claimant was entitled to an award of general damages.


-----

The defendants were in breach of contract in failing to pay the claimant in accordance with their own terms and
conditions or to give her opportunities for independent days off and holidays. The Trafficking Convention required
that the UK should provide a right of victims to compensation from the perpetrators of trafficking. The acts of
harassment gave rise to acute distress for the claimant. Some guidance as to the measure of damages could be
found in Vento v Chief Constable of West Yorkshire Police, as revised in Presidential Guidance. The claimant was
entitled to damages for injury to feelings and psychiatric injury at a level in the lower half of the top band of the
_Vento guidance. Accordingly, for the injury to feelings arising from the trafficking and the breach of contract, an_
award of £30,000 was made. An additional award of £9,000 was made for psychiatric injury.
**Cases referred to:**

_Cave v Robinson Jarvis & Rolf (a firm) [2002] UKHL 18,_ _[[2002] 2 All ER 641, [2003] 1 AC 384, [2002] 2 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-60HK-00000-00&context=1519360)_
1107HL

_Hounga v Allen_ _[[2014] UKSC 47, [2014] IRLR 811, [2014] 1 WLR 2889, [2014] 4 All ER 595, [2015] 3 LRC 155 SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2X-VY01-DYPB-W2BN-00000-00&context=1519360)_

_Majrowski v Guy's and St Thomas' NHS Trust_ _[[2006] UKHL 34, [2006] IRLR 695, [2007] 1 AC 224, [2006] 4 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1CV-00000-00&context=1519360)_
_[395, [2006] 3 WLR 125HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4M4V-55N0-TWP1-607D-00000-00&context=1519360)_

_[Rantsev v Cyprus (App No 25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1 ECt HR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_Veakins v Kier Islington Ltd_ _[[2009] EWCA Civ 1288, [2010] IRLR 132 CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XN4-5070-Y9JK-R52D-00000-00&context=1519360)_

_Vento v Chief Constable of West Yorkshire Police_ _[[2002] EWCA Civ 1871, [2003] IRLR 102 CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1YX-00000-00&context=1519360)_
**Appearances:**

[Trafficking Directive 2011/36/EU](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)

_[Protection from Harassment Act 1997](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)_

National Minimum Wage Act 1997

_[Limitation Act 1980](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)_

For people trafficking see Harvey AI [364] and 57 Halsbury's Laws (2018) para 295

For the claimant:

ANNA BEALE, instructed by ATLEU

For the defendants:

OLIVER HYAMS, instructed by Bloomfield
1

**JUDGE HAMPTON:**
**Introduction**

The claimant is a native of Nigeria who came to the UK to work with the defendants' family in 2005. The
circumstances in which she came to the UK and her treatment whilst she worked for and was accommodated by
the defendants is the subject matter of these proceedings.
**[*1030]**
2

The claimant claims she is the victim of human trafficking. This is denied by the defendants. In addition, the
[claimant has made a claim under the National Minimum Wage Act 1998 (the '1998 Act'), as she claims that she was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)
paid less than the statutory rate set under the 1998 Act throughout her employment. Alternatively, she claims


-----

damages for breach of contract on the grounds that she has consistently received less remuneration than
documents setting out her Terms and Conditions of her employment provided for.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
3

The claimant seeks compensation as the victim of trafficking. The United Kingdom has ratified the Council of
Europe Convention on Action Against Trafficking in Human Beings, (The Trafficking Convention). Article 15 of the
Trafficking Convention provides that the internal law of the ratifying nations should provide a right of victims to
compensation from the perpetrators. The Supreme Court held in Hounga v Allen _[[2014] UKSC 47, [2014] IRLR 811](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2X-VY01-DYPB-W2BN-00000-00&context=1519360)_
that this obligation not only required the United Kingdom to ensure that victims of trafficking have a right to
compensation for the trafficking itself, but also a right to compensation for related acts of discrimination. The court
also held that there is also a strong presumption in favour of interpreting English law in a way which does not place
the United Kingdom in breach of an international obligation. In _Rantsev v Cyprus_ **(App No 25965/04)** _[(2010) 28](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
_[BHRC 313, the European Court of Human Rights recognised that art 4 of the ECHR prohibits human trafficking and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
[art 13 requires convention states to provide a domestic remedy for violations of the ECHR rights. Section 3 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0RX-00000-00&context=1519360)
Human Rights Act 1998 requires domestic courts to give effect to primary and subordinate legislation in a way
which is compatible with Convention rights. Accordingly, if the court finds that the claimant is the victim of trafficking,
she is entitled to compensation.
4

The claimant also claims that her treatment in the hands of the defendants amounts to harassment within the
[meaning of the Protection from Harassment Act 1997 (the '1997 Act').](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)
5

One of the issues raised by these proceedings has already been determined at a single issue trial by Master
McCloud. She found that the defendants were not entitled to rely on reg 57(3) of the National Minimum Wage
[Regulations 2015, SI 2015/621, which affords an exemption to payment of the national minimum wage, for a worker](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FH2-8SF1-F16W-C37Y-00000-00&context=1519360)
residing in the family home of the worker's employer in certain circumstances. The Master determined that the
defendants were not entitled to rely upon that exemption. Accordingly the defendants have conceded that the
claimant is entitled to some award under the 1998 Act, but the court must determine the amount.
6

The defendants have also raised a limitation defence to any sums outstanding, or damages payable for any part of
the claimant's cause of action which arose before 28 October 2009. (The Claim Form was issued on 28 October
2015.) The defendants deny that the claimant has been trafficked within the meaning of the Trafficking Convention
or that she has been harassed within the meaning of the 1997 Act. They assert that the claimant was treated as a
niece, throughout the nine and a half years of her employment by them, and that she has brought this claim in an
effort to reinforce her desire to obtain permission to remain in the United Kingdom.
7
**History**

The claimant and the second defendant are distantly related. The claimant first started to work for Mrs Abu's sister,
Mrs Eluwole, in Nigeria in 1998, when she was probably in her mid teens. There is some uncertainty about the
claimant's age. A declaration made by the claimant for the purposes of her first entry to the United Kingdom gave a
date of birth in February 1974. The claimant has subsequently obtained a naming certificate, which gives a date of
birth in May 1982. In the circumstances of the case, I find that the latter date is probably more accurate.
8

The claimant was one of two domestic workers employed by Mrs Eluwole who at that time worked in a bank. She
told the court that her husband was a stock broker. The arrangement was made by Mrs Eluwole's mother and the
claimant's mother, who are cousins. Mrs Eluwole lived in Lagos Nigeria. The claimant came from poor
circumstances in a rural village.
9


-----

Whilst in the Eluwole family, the claimant was required to assist with caring for the children of the family, housework
and helping with animals kept on the compound. Mrs Eluwole also arranged for her to be apprenticed to a local
hairdresser with a view to the claimant eventually following that profession. It is clear from her evidence that the
claimant never found this training very satisfactory. The claimant was not paid any wage by Mrs Eluwole, but her
accommodation, food and any other needs were catered for within the family home. Mrs Eluwole confirmed that this
is not an unusual arrangement in Nigeria.
10

The defendants visited Nigeria for a family funeral in 2004 when they met the claimant. There is an issue between
the parties as to whether there was any discussion or agreement between the defendants and Mrs Eluwole, that
Mrs Eluwole would arrange for the claimant to travel to the UK to live with the defendants' family and work as a
domestic worker for them.
11

It is not in issue that in late summer 2005, Mrs Eluwole and her three children travelled to the UK accompanied by
the claimant, for a family holiday at the defendants' home. The claimant's visa obtained for that visit (p 706),
describes her as a Domestic Worker (visitor) and has endorsed the words 'accompanying the Eluwole family'. It is
the defendants' case that the claimant accompanied the family in order to assist Mrs Eluwole with child care. Mrs
Eluwole made arrangements for the claimant to apply for a Nigerian passport and a visa to travel to the United
Kingdom. The claimant spoke very little English at that stage and Mrs Eluwole arranged for an interpreter to assist
the claimant at the British High Commission, when she applied for her visa.
12

When they arrived in the United Kingdom, it is the claimant's perception that Mrs Eluwole spoke with immigration
officials on her behalf. This is denied by Mrs Eluwole who says that as she has a British passport, she went to a
different passport channel at the airport and only encountered the claimant at the baggage reclaim stage. Whilst the
Eluwole family were staying at the defendants' home, a two bedroom property in Greenwich, arrangements were
made for the claimant to remain in the United Kingdom with the defendants' family as a domestic worker. It is the
defendants' case that this arrangement arose because Mrs Eluwole learned that she was being made redundant
whilst she was on holiday in the United Kingdom. As the claimant was enjoying her time with the defendants' family,
it was suggested that she should stay in the United Kingdom with them, to work as a domestic worker and to assist
with childcare. The defendants offered to make arrangements for the claimant to learn English. The claimant
described this as going to school. The defendants enrolled her in successive English for Speakers of Other
Languages (ESOL) evening classes for four hours per week at colleges in Greenwich, and after the family moved,
in Bexley. I find that the claimant's belief that she was to go to any form of full-time education, was an assumption
made by her and not a promise made by the defendants. A full list of the college courses attended by the claimant,
which were arranged for her and paid by the defendants, is set out in para 51 of Mrs Abu's witness statement. The
claimant accepted in her evidence that the list was accurate. These
**[*1031]**

courses included a Citizenship course in 2012, a Computing course in 2014 and a Caring for Children Level 1
between September 2014 and January 2015. The claimant accepts that the defendants paid the modest fees for
these courses, either directly, or by providing the claimant with the necessary funds and purchased books and other
learning materials for the claimant.
13

The claimant remained in the defendants' home with their three children, a daughter born in October 2001, a son,
who is autistic who was born in February 2004, and another daughter born in November 2007 until March 2015.
The claimant moved with the defendants' family from Greenwich to Belvedere during 2007, although the children
continued to go to school or nursery in Greenwich until the end of 2007.
14


-----

In November 2007 the defendants' third child was born. Mrs Abu was on maternity leave between October 2007
and May 2008 and thereafter worked for two days per week from home. Throughout the period that the claimant
lived with the defendants' family, Mr Abu worked full time although there were periods of paternity and sick leave.
15

It is the claimant's case that throughout her time with the defendants' family she provided childcare, taking the
children to school with occasional assistance from Mr or Mrs Abu or friends or neighbours whose children attended
the same schools. She also took domestic work, cleaning, laundry and cooking, not only for the children but the rest
of the household. She attended church regularly, generally with the defendants' family until 2012 when she started
to attend another church in Dartford. Thereafter the whole family started to worship there. Regular church
attendance and a social life centred on church activities has been a feature of the evidence in this case.
16

The claimant also accompanied the defendants' family on family holidays. These were modest affairs on the south
coast where the family stayed in a caravan. I have been provided with a photograph of a cheerful looking family,
including the claimant by the sea. It is the claimant's case that during such holidays, although it was a change from
domestic routine at home, she was expected to assist with childcare and cooking for the family. It was not an
independent holiday providing the claimant with a break from her usual duties.
17

It is the defendants' case that the claimant became moody and difficult whilst Mrs Abu was expecting her third child.
It's the claimant's case that her experience in working for Mrs Eluwole in Nigeria was that when Mrs Eluwole was
expecting her third child her working days had become longer and more arduous. She was concerned that the
arrival of a third child in the Abu family would have the same effect. It is also the case, that whatever the claimant
may have been promised, she was clearly expecting a more intensive educational programme than four hours per
week on an ESOL course.
18

Throughout the period during which the claimant lived with the defendants' family, Mrs Abu completed the
necessary paperwork required by the Home Office to extend the claimant's stay in the United Kingdom. In the early
years of her residence with the family, the claimant's command of English was not sufficient for her to complete,
read or understand these documents herself. Many of the relevant documents dating back to November 2005, have
been disclosed by the Home Office. A letter dated 14 November 2005 expressed in the first person by the claimant,
but actually written by Mrs Abu on the claimant's behalf is headed 'Notification of change of employer' (p 478). Mrs
Abu accepted in her evidence that she produced this document, together with most of the correspondence, and
completed the relevant application forms required in successive years to renew the claimant's visa to stay in the
United Kingdom. The letter of 14 November 2005, refers to Mr and Mrs Abu as being the claimant's 'new
employers'. It states:

'they have offered me an improved and better contract and conditions of employment'.

The letter goes on:

'the Abu family requires a domestic worker to mainly meet their childcare and domestic responsibilities
because they are both in full time employment and they have both faced a lot of inconveniences over the years
with regards to finding adequate childcare. I have been able to assist mainly in handling their domestic
responsibilities whilst they are both at work. I have agreed to work for them as a domestic worker'.

A formal application to extend the claimant's stay was enclosed with that letter.
19

In addition a letter of the same date, signed by Mrs Abu on behalf of both defendants to the Immigration &
Nationality Directorate states:


-----

'we write to confirm that we are the employer of (the claimant). We have employed her as a domestic worker in
our home as stated in the enclosed contract of employment duly signed by us. We confirm that we wish to
continue employing her in accordance with the terms of the signed contract. We also confirm that we would
comply with all relevant laws in the United Kingdom relating to employment and wages' (my emphasis).

The letter makes a further reference to the terms of the contract. Accompanying these letters was a letter of the
same date addressed to the claimant signed by Mrs Abu stating that it enclosed two copies of 'our standard
agreements in addition the Standard Terms and Conditions of employment for the position of a domestic worker'. A
document entitled 'Standard Terms and Conditions' was enclosed with the correspondence. There are a number of
similar documents in the Home Office papers. It is likely that the one included in the trial bundle at 707C is the
earliest of these. It is signed both by the claimant and by Mrs Abu and provides, amongst other things that:

–   The domestic worker will be living in our home as a member of our family.

–   The domestic worker will have a separate fully furnished bedroom to herself and will share the
bathroom and toilet with the rest of the family (free accommodation).

…

–   The domestic worker is expected to be working for 30 hours a week.

–   The domestic worker is entitled to two days off a week preferably at the weekends, but it may vary
from week to week.

–   The domestic worker will be paid £155 weekly for the 30 hours a week work, but additional hours will
attract £7.60 per hour (very occasional).

–   The domestic worker is entitled to five weeks holiday a year with full pay preferably during the school
holidays.

–   Either party are entitled to give one months' notice in writing to terminate the contract/agreement.

20

Mrs Abu said in her oral evidence that the document was downloaded from the internet. Similar letters and
Standard Terms and Conditions were sent to the Directorate over successive years for example: (p 502) December
2006; (p 520) December 2007; (p 538) December 2008. Mr Abu confirmed in his oral evidence that Mrs Abu dealt
with the relevant documentation, that these are her signatures and save for signing when required, he did not get
involved in producing the necessary paperwork. The various examples of the Terms and Conditions are not dated,
but in each case, the weekly pay provided for follows the rates required by the National Minimum Wage Regulations
as it increased from year to year. The first Application to the Directorate signed by the claim
**[*1032]**

ant on 14 November 2005 refers on p 11 of that application (p 470) to net pay being £620 per month plus benefits.
21

It is the claimant's case that never throughout her employment was she paid anything like the amounts shown in the
Terms and Conditions.
22

In her witness statement at para 15 (p 175) Mrs Abu stated that the documents entitled Terms and Conditions 'did
not purport to be a contract of employment'. This assertion is surprising and damaging to Mrs Abu's credibility. It is
in direct contradiction to the description that she herself gave to the Terms and Conditions, in successive
applications completed by her, provided to the claimant for signature and then sent to the Directorate to extend the
claimant's visa in the United Kingdom. In that the defendants have accepted that the wages stated in the
documents were never paid in full to the claimant (their case is that deductions were made for the cost of food and
accommodation), it follows that a deception was perpetrated by the defendants, on the claimant's behalf in these
applications to the Home Office, in successive years throughout the claimant's employment by the defendants.
23


-----

It is also the claimant's case that she was never given two independent days off during the week or that she ever
had five weeks' holiday, independent of the family, as provided for in the Terms and Conditions. She accepts that
she accompanied the defendants' family on their caravan holidays and days out, to the south coast. I have no doubt
that during that period she would have enjoyed time by the sea and on the beach with the defendants and their
children. I find that this did not amount to a holiday from her work, as her duties with regard to childcare and
assisting with the family with domestic tasks continued. The defendants did not assert and I find that the claimant
never had, or expected to have, five weeks of free time independent of the family during any of the years that she
worked for the defendants.
24

In 2006 the defendants assisted the claimant to open a bank account. I note that a letter from the Home Office
dated 10 January 2007 (p 522) requests evidence of funds, for example bank statement or wage slips. That
provoked the response at p 524, produced on the claimant's behalf by Mrs Abu, which refers to difficulties opening
a bank account and the fact that the claimant did not receive a wage slip. It is common ground that no wage slips
were provided and that most payments which were made to the claimant were made in cash. The defendants state,
and the claimant accepts, that the defendants also purchased study materials, clothing and other personal items for
the claimant from time to time.
25

The claimant's evidence, which I accept, was that in her early years with the defendants' family, she was not able to
read or understand the documents that she was signing. She says in her witness statement at para 88 (p 155) that
she '… did not think about it as Mrs Abu filled in the forms and I just got the opportunity to sign on the dining room
table … I was not given much opportunity to read the very lengthy form and I did not dare to ask for it. They knew
that I did not read or write English properly and they did not give me a chance to ask questions. I would never have
asked questions – I trusted them.' She goes on to say in the following paragraph, that in about 2012 she started to
be able to read and understand the document she was signing every year and began to realise that what the
defendants were telling the Home Office was not true. I note from the defendants' records of the claimant's college
attendance, the claimant did not start ESOL Elementary Level 2 until the academic year 2012/2013. I find that this
is a clear indication of the slow progress the claimant made with her studies of the English language.
26

Relations within the family became much more difficult after the defendants made an application on the claimant's
behalf in 2014 for indefinite Leave to Remain which was refused. On 13 March 2014 the claimant was requested by
the Home Office to provide wage slips and bank accounts (p 662). Enclosed with the documents disclosed by the
Home Office is a document (p 664) giving a breakdown of earnings during the period January–April 2014. It is the
claimant's case that this document was prepared by Mrs Abu, and I find that it was. It is also the claimant's case
that these figures do not accurately state the sums of money which she was actually paid. The claimant's
application for indefinite leave to remain was refused in a letter dated 24 April 2014 (p 680). That letter states that
'you have failed to submit any documentary evidence that you are paid £7.60 per hour as your contract states or
that you can maintain and accommodate yourself adequately without recourse to public funds'. That letter was
accompanied by a notice of a decision to remove the claimant from the United Kingdom (p 684).
27

The Right of Appeal was exercised on the claimant's behalf by the defendants who enlisted the help of a lawyer to
assist. The claimant describes the visit to the lawyer in her witness statement. She says that the lawyer spoke
Yoruba and it was at that point that the claimant was shocked to learn that the defendants were representing that
she was paid £800 per month, £500 attributable to accommodation and food and £300 in cash. She says she was
made to sign a document that confirmed that these were the amounts that were being paid. I accept the claimant's
evidence that she was afraid of what would happen if she did not sign it and that she felt under pressure. It was
quite clear from the claimant's oral evidence that she was very uncomfortable with this process. As she stated in
her witness statement and repeated in court, as a Christian she knows it is wrong to lie.
28


-----

She arranged a return visit to the lawyer on her own and said that the lawyer accused her of trying to blackmail Mr
and Mrs Abu. I find that the impression that she was given was, that if she did not tell the lies and sign the
documents as required, she was likely to be deported. I find that this was both a shock and very considerable
disappointment to the claimant and led to a complete breakdown in trust between herself and the defendants. She
had come to understand that she was working much longer hours than the contracts that were being sent on her
behalf stated. She believed she had been promised a British passport (although I find this was a misunderstanding
on her behalf, and that what was actually on offer was indefinite leave to remain) and accordingly she was very
unhappy and became less cooperative in the family home.
29

An example of this is her conduct during periods of prayer within the family home. It was common ground that the
family would pray together in a circle facing inwards. At this time, the claimant started to face away from the family
during prayers. Mrs Eluwole, who visited the family in October 2014, reprimanded the claimant for this practice
asking her why 'she was backing us'. The claimant was clearly resentful of the deceptions she considered had been
perpetrated against her by the defendants and very worried about her immigration position.
30

The family, nevertheless, continued to attend church either together, although the claimant also attended
separately. By this time, she had been undertaking voluntary cleaning work as a Sanctuary Keeper at the church
she attended. There was a church conference held during August 2014 which continued for four days. The claimant
attended the conference and provided cleaning services. This kept her out of the house for some time. During this
period there was an altercation between the parties about preparation of food during the period of the
**[*1033]**

conference on the first day. On the second day, the defendants' family left the venue whilst the claimant remained
there and the claimant had to find her own way home, when she had expected to return home with the defendants. I
have heard differing accounts of what happened during the conference and why, each commenting on the others
behaviour in pejorative terms. Indeed, a considerable period of time in the course of the evidence was spent on
these incidents. It is not necessary for me to make positive findings as to what actually happened. There was
clearly a misunderstanding, which I find was brought out by a failure to communicate within the family, exacerbated
by the increasingly hostile atmosphere.
31

The defendants' evidence was that they were content for the claimant to attend this conference and carry out her
duties as a sanctuary keeper and they did not attempt to prevent her going. This is inconsistent with the impression
given in the letter which terminated the claimant's employment with the defendants dated 5 March 2015 (p 256)
signed by both defendants in which the following was stated 'on 10 August 2014, we spoke to you about the fact
you left your duties between 6 and 9 August. The conversation developed into a loud and bitter argument' (the
dates being those of the church conference). Each of the defendants tried to explain the apparent contradiction
between their evidence to the court and the contents of this letter. I found their attempt to explain this inconsistency
in the context of the case in general unimpressive and damaging to their credibility and reliability as witnesses.
32

These incidents made a difficult situation worse. In the meantime the claimant had applied for other work. In April
2014, she registered with a website Findababysitter.com. At that point she discovered that the terms of her visa
were such that she believed she could not work for anyone else and could only work as a domestic worker resident
with her employer. The claimant accepts that the defendants also found another position for her as a domestic
worker in the potential employer's home. Although initially accepting this position, she then refused to take it up. Her
evidence was that the other lady was not very nice and she was not happy with the conditions that she thought
were on offer. She said, and I accept, that she no longer trusted the defendants who had told her to lie about what
she was paid to the Home Office. She was shocked by the situation in which she found herself and was scared.
33


-----

In October 2014, Mrs Eluwole paid another visit to the defendants. At some time in the course of that visit there was
contact between Mrs Eluwole's mother and the claimant's mother in Nigeria which resulted in some unpleasantness
between those two ladies. It is clear from the evidence given by Mrs Eluwole that the claimant's mother was
concerned that the defendants were trying to make the claimant leave their home. There had also been intervention
by another family member in Nigeria.
34

In due course there was a heated argument in mid-February 2015 in which Mrs Eluwole was involved. The claimant
alleges she was assaulted by Mrs Eluwole, which is denied. Mr Akinwale, another relative, first cousin of Mrs Abu
and Mrs Eluwole, and a paternal cousin to the claimant, who lived nearby was asked to intervene. He gave
evidence and told me that as a precaution he thought to get the police involved, although the appointment with the
police which was made was, in due course, cancelled. At about this time the defendants took the claimant's house
keys from her and removed a key to a shared cupboard where food was stored which had always been available to
her. The defendants also complained of the claimant's refusal to take other employment. Mrs Abu agreed that she
had made no enquiries as to whether the refusal was reasonable. She accepted that she did not know the individual
who had offered her the job and had not spoken to that individual about it. She simply said that she had given the
claimant the telephone number of the potential employer.
35

Mrs Abu maintained in her evidence that she was not aware that the claimant was upset about being asked to lie to
the Home Office. She said that the claimant did not tell her of this. She denied that there was any talk of
deportation. As for the removal of the claimant's house key, she said at this time Mrs Eluwole was staying with the
family and there was always somebody around to let the claimant in, if she had been out.
36

Following the incident in mid-February, the claimant's employment was terminated in the letter from the defendants
dated 5 March 2015 to which I have already referred. The letter concluded with the remarks 'you are now required
to leave our house as soon as possible. We will be forced to evict you and call the police again if you do not leave
our home'. The claimant remained at the defendants' home and continued her activities with the church.
37

On 14 March 2015, she returned to the defendants' home to find that all her belongings had been packed up and
placed out on the street. She knocked on the door and although she believes that the family were in, she was not
admitted. A neighbour took pity on her and took her into her home. That neighbour contacted someone from the
church who accommodated the claimant for two to three days. The claimant had already been in touch with a
charity which helps migrant domestic workers and had spoken to a solicitor who worked with victims of trafficking.
After the claimant was evicted from the defendants' home, she called that solicitor and went to see her. She was
then referred to the Salvation Army which runs a referral line for potential victims of trafficking. They assisted the
claimant to complete the National Referral Mechanism Form for victims of trafficking (p 356). In June 2015 the
claimant made an application for asylum. By a letter dated 20 October 2016, the Home Office notified the claimant
that it had 'concluded there are not sufficient grounds, on the balance of probabilities, to believe that you have been
a victim of **_modern slavery (human trafficking) or slavery, servitude or forced/compulsory labour)' (p 410). The_**
claimant, represented by Migrant Legal Action, challenged this decision and on 6 February 2017 issued an
application for Judicial Review. On 26 October 2017, the claimant was notified by the Home Office that 'the
Competent Authority has reconsidered your conclusive grounds decision (and) concluded that you are a victim of
human trafficking' (p 464).
38
**The proceedings**

In the meantime the claimant, represented by the Anti-trafficking and Labour Exploitation Unit, commenced this
action on 28 October 2015. The Particulars of Claims seek compensation, in summary, based on the assertions
[that the claimant was trafficked into the UK; is the victim of harassment within the meaning of the Protection from](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)
_[Harassment Act 1997; for breach of contract of the term implied into her contract of employment with the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)_
defendants, pursuant to s 17 of the 1998 Act, that she would be paid at least the National Minimum Wage; that she


-----

was not allowed two days per week off or five weeks holiday a year provided for in her contract and was required to
work excessive hours. She alleges that she has suffered psychiatric injury of a mild to moderate degree, namely a
mixed anxiety and depressive disorder.
39

[The defendants deny all the pleaded grounds of the claimant's claim and rely on the Limitation Act 1980.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)
40

After pleadings closed, the claimant applied to strike out the defendants' defence to the Minimum Wage claim on 1
November 2016. After a further directions hearing the Master directed a single issue trial on the defendants'
**[*1034]**

defence to the Minimum Wage claim. That trial proceeded on 18 July 2017 and that aspect of the defendants'
defence was dismissed on 31 July 2017.
41

It can be seen from the Master's judgment that despite her direction that special measures should apply to the
single issue trial to assist the claimant to give evidence, these were not arranged in advance of the hearing. The
start of this trial, disappointingly, was similarly hampered.
42

The defendants argued at the single issue hearing that the claimant fell within the scope of the family workers'
exemption pursuant to reg 57(3) of the National Minimum Wage Regulations. The Master concluded in the course
of her careful judgment that this defence was 'doomed to fail'.
43

The defendants are clearly bound by those findings (which I note are the subject of an appeal). So far as any
findings or observations about the case on other issues are concerned, the court is not bound by the Master's
observations that the claimant was 'kept in economic servitude' or 'oppressive servitude'. Nevertheless I agree with
and adopt the conclusion referred to in para 94 of her judgment, that it is disturbing that a civil servant such as Mrs
Abu should have represented to the Home Office for visa purposes that the payment terms for the claimant were as
set out in the terms of conditions, whilst knowing full well that they were not.
44

There remain significant issues which this court is required to determine. I summarise them as follows:

(i)   Whether the claimant was the victim of trafficking. This is relevant to all the other issues which arise in
the case, but also the question of the parties' credibility.

(ii)   As to the National Minimum Wage claim, when considering the quantum of that claim, what type of
work the claimant was engaged in, what her hours were and what additional payment she is entitled to,
and also whether part of the claim relating to the period before 28 October 2009 is time barred by the
_[Limitation Act 1980. On this issue the claimant relies on s 32(1)(b) and (2) of that Act.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)_

(iii)   The claimant's claim for breach of contract in that the defendants failed to comply with the express
term as the payment of wages. In fact this issue really takes my determination no further.

(iv)   Whether the defendants' conduct amounted to harassment within the meaning for the 1997 Act. The
facts relied upon amounting to harassment are set out in para 49 of the Particulars of Claim. The claimant
relies on the trafficking itself, exploitation of her vulnerable immigration status as well as specific incidents
when the family relationship started to break down badly in mid 2014.

(v)   Whether, if I find that there has been harassment or breach of contract, the claimant has suffered
foreseeable injury as a result.

45
**The Evidence**


-----

There are a number of factual issues that arise. I have dealt with some of those of above and I will refer to them in
the discussion which follows. All findings are made adopting the civil standard, namely the balance of probabilities.
In the evidence I have been referred to a number of incidents occurring during the nine-and-a-half years that the
parties lived together in the same household. I do not propose to make a finding in relation to each one, but deal
only with those which are most relevant. The fact that I may not have referred to one particular detail in the
evidence, however, does not mean that I have disregarded it.
46

I have heard from the claimant herself. She is the only witness called in support of her case as to the factual
circumstances of her employment and residence with the defendants. The defendants have given evidence and
called other members of their circle of friends. Mrs Eluwole, Mrs Abu's sister who travelled with the claimant to the
United Kingdom in 2005, also gave evidence. Mrs Enebeli, a teacher and friend of the defendants' family and Mrs
Omolere another friend of the family, both of whom were also involved in church activities in which the claimant and
the defendants' family participated provided evidence. It is noticeable that these ladies only saw the claimant in the
presence of the defendants' family save on one occasion when the claimant came to Mrs Omolere's home early to
assist her with a barbeque she was holding to celebrate her daughters first birthday in June 2014.
47

Mr Akinwale, first cousin to Mrs Abu and Mrs Eluwole who lived nearby and who was called upon to mediate
between the parties in February/March 2015 was also called to give evidence. It was asserted in the course of the
argument that as Mr Akinwale was a paternal cousin to the claimant, he was a family member from whom the
claimant could have sought help and friendship, when relationships became difficult during 2014 and early 2015. I
find that the claimant's diffidence in relation to approaching him, was entirely genuine. He was of an older
generation. He was seen by the claimant as a person in authority over her. It was very clear from the evidence
which I heard from the claimant throughout her evidence, that as a junior member of the family from a poor
background, she was required by her culture and upbringing to respect and obey older family members. When the
defendants called upon him to intervene, his response was to call the police. The claimant was already very
anxious about her position, in particular the fact she thought she was being asked to lie, and this would no doubt
have reinforced her anxiety still further.
48

It was suggested by Mrs Abu in her evidence, that when the defendants put the claimant out on the street in March
2015, she could have gone to Mr Akinwale's home to seek help. I find on the evidence that Mr Akinwale was not
warned that this was likely to happen, nor did the defendants ask him to provide accommodation, temporary or
otherwise. Mr Akinwale's evidence about whether he was in a position to provide the claimant with a home was
confusing and contradictory. At first he said that the claimant was welcome to come to him at any time to talk, but
not to live. Then when questioned again he said that the home had lots of rooms and he had invited her to stay with
his family in January 2015.
49

I have heard expert evidence from Dr McQuade, a director of Anti Slavery International. He provided his opinion to
the court on whether, in the circumstances of the claimant's arrival in the United Kingdom and subsequent
employment by the defendants, the claimant could be said to be a victim of trafficking within the meaning of the
Council of Europe Convention. He has an impressive curriculum vitae and has acted as an expert in other
trafficking cases. He is clearly familiar with the criteria applied by the International Labour Organisation as indicators
of forced labour. Although at case management stage, directions were given for a jointly appointed expert on
trafficking to be instructed, at the Pre-Trial Review, the defendants abandoned reliance on Dr McQuade, but were
refused permission to instruct a separate expert. Accordingly the claimant was given permission to call Dr McQuade
and the defendants have had the opportunity to cross examine him.
50

I have also received a medical report on the claimant's behalf from Professor Katona dated 25 January 2016.
Permission was given to both parties to obtain psychiatric evidence, however the defendants have not obtained
their own report.


-----

51
**The Factual Witnesses and Findings of Fact (not dealt with above)**

The claimant and the defendants have provided evidence about the claimant's arrival into the defendants'
household over 12 years ago and the circumstances of her
**[*1035]**

residence with them until March 2015. Inevitably there are differences in recollections caused by the effect on
memory by the passage of time. The perceptions of parties also changed over time, and in my judgment have been
affected by the distressing circumstances in which the claimant's residence came to an end. These were obviously
distressing to the claimant. I accept Mrs Abu's evidence that tensions in the house had become so bad by March
2015 that she was a loss to know what to do. She was also concerned about the welfare of her children. This did
not, however, in my judgment justify the eviction of the claimant from the defendants' home in the circumstances
described.
52

It is judicial experience that those involved in disputes within family relationships or other close personal or
domestic relationships which have failed have a natural inclination to reinterpret past events in either vengeful or
self exculpatory terms. This is particularly so in the present case where the claimant's expectations of the life she
was expected to lead in the United Kingdom, including her education, had not been met, I find that she has a
genuine and justified sense of grievance against the defendants. I also find that the defendants feel a sense of
grievance that the claimant has turned against them, after they provided her with a home and assisted her with
education and the opportunity to remain in the United Kingdom.
53

The defendants are clearly distressed by the way in which relationships broke down between the parties. They are
clearly concerned about potential consequences of this court action not only financially and professionally but, no
doubt, it will affect their standing in the community in which they live. I find that they were angered in 2014 and 2015
by the way in which the claimant, for whom they had provided home, food and assistance with education turned
against them and was not prepared to engage with their attempt to resolve the problems within the family or the
community.
54

It is relevant in this context that an arrangement that a young person, possibly a relative, in poor circumstances
coming to work as a domestic worker within a family home, in return for bed and board and some assistance with
education, but without remuneration, is culturally acceptable within the defendants' community in Nigeria. When I
ask Mrs Abu about this, her initial response was evasive, she confirmed that it did happen but she only knew of one
such arrangement, which was that made between the claimant and her sister. Mrs Eluwole confirmed without
hesitation that this was an acceptable arrangement in Nigeria and that it can work well. She had not been present
when Mrs Abu gave her evidence.
55

Having read and heard the evidence of the defendants themselves and Mrs Eluwole, I find, on the balance of
probabilities, that that was such an arrangement that the defendants felt that they were providing for the claimant. I
have no doubt that in some cases such an arrangement can be entirely benign, providing a young person with a
home and opportunities which would not otherwise be available. However, such arrangements can go badly wrong
as they have in this case, and the young person may be far away from the family home in a situation where there
are no friends or close family members to whom they can turn. Moreover, to satisfy the Immigration Authorities, as
Mrs Abu clearly was aware, it was necessary to represent that the domestic worker was being paid in accordance
with British employment laws.
56

I find that the defendants and Mrs Eluwole did not fully appreciate how isolating and oppressive the arrangements
in the family home came to be for the claimant, as, I find, they gave no thought to it. Mrs Eluwole gave me the
di ti t i i th t th l i t h ld h b t f l f th t it ff d d t h t id i th


-----

United Kingdom and learn English. As the claimant's understanding of English gradually improved and she came to
realise that the applications for her visas were untruthful, she found her position more oppressive. I also find, that
whatever the defendants may have stated in successive applications to the Home Office for the claimant's visa to
be renewed, it was never any part of their express arrangement as discussed with the claimant, to provide the
claimant with regular wages, whether as to the interval at which any money would be paid or the amount. Nor did
they provide any regular payments. I find that they genuinely considered that their obligations had been discharged
by providing the claimant with bed and board, clothing and sundries and paying her college fees, providing her with
occasional payment for eg bus fares, clothing and sundries, as a parent might with a young adult daughter or an
adult niece living in the same household.
57

The parties' expectations and obligations must be considered against the background of the Trafficking Convention
and the European Convention of Human Rights.
58

I have considered the defendants' criticism of the claimant's evidence, that it has been affected by her own belief
that she is a victim, reinforced by the Home Office conclusion, that she is the victim of trafficking. I find that she has
good reason to see herself in that light. The claimant has been criticised by the defendants for failing to mention the
hairdressing apprenticeship in which she was enrolled by Mrs Eluwole when part of that household in Nigeria. I do
not find this criticism to be fair. It is not an issue which directly affects this case although it is part of the background.
The claimant is not to be criticised for making no reference to this in her witness statement.
59

The conclusion of the Home Office has also affected the evidence of the defendants, both of whom I find to be,
understandably, defensive. Their evidence was self-exculpatory, tending to emphasise the benefits they perceived
they were providing for the claimant, minimising the work that she provided for them in the household and, on some
details, unreliably vague. They can properly be criticised for the lack of any records as to payments made to the
claimant, and any hours that she worked. They were under a duty pursuant to s 9 of the 1998 Act to maintain such
records. Mr Abu was at pains to point out that this was a relaxed arrangement. That may be so, but that does not
justify the deceitful letters to the Home Office, setting out the terms of the claimant's employment with them and the
payments those terms asserted were being paid to the claimant when these did not reflect the reality of their
arrangement with the claimant.
60

I also accept that the claimant's circumstances whilst resident with the defendants were not all bad. I have seen
some photographs, inevitably only a snapshot in time, of family parties in which the claimant appears to be enjoying
herself and is being included within family and church gatherings. She was not a modern-day Cinderella confined to
a kitchen or her own room, either physically or by lack of suitable clothing, whilst the rest of the household went out
to enjoy themselves. In some respects the claimant's evidence has overstated her position. She was somewhat
evasive about the question of her personal freedom to come and go from the home. She accepts that she had a key
to the property until it was confiscated from her in February 2015. She was also provided with mobile telephones
throughout her residence, the most recent of which she regularly used without restriction, in the period when
relationships were breaking down, because as she said she was seeking help. She was understandably very wary
of questions asked by the defendants' counsel that she may have thought emphasised her freedoms to come and
go, go to college, make friends and acquaintances either at college or at church or in other circumstances. She was
guarded when she was asked about a male friend, although this indi
**[*1036]**

vidual is referred to in her own witness statement. I accept that she developed friendly relationships with neighbours
with whom she shared the school run, or who assisted the claimant by taking the defendants' daughter to school
whilst the claimant waited at the defendants' home a for a school bus to take the defendants' son to his special
school.
61


-----

Nevertheless, these acquaintances were superficial and to some extent brief. I find on the balance of probabilities
that when the claimant started to form a friendship with a woman from the Jehovah's Witnesses organisation, when
the family was still in Greenwich, so in the earlier part of her residence with the defendants, she was discouraged
from pursuing this. I accept the claimant's evidence that the defendants advised her not to talk to, or trust, people
outside the immediate family or friendship group. At this stage of her residence with the defendants the claimant
had limited English and limited opportunities to make friends for herself. She is an intelligent young woman in a
vulnerable situation – she heeded such warnings, which did not need to be repeated. Accordingly, until a much later
stage, after the claimant's English improved and she joined the Winners Church in 2012, the claimant genuinely
considered, as I find the defendants had intended, that her social circle should be restricted to the defendants'
family group and friends. The claimant remained throughout a junior member of the defendants' household and
subject to their direction.
62

Some of the assertions made by the defendants in seeking to emphasise the freedom afforded to the claimant did
not stand up to scrutiny on cross-examination. For example, Mr Abu in para 37 of his witness statement (p 168)
asserted that the claimant had a friend across the street with whom she spent time as soon as she left the children
at school. He went on that the claimant would be at the friend's house for the most part of the day except when she
had to go out for something or go to college.

'This I have witnessed on many occasions'.

When it was put to him that in fact generally he had been working full time and he was asked on how many
occasions had he observed this arrangement, he had to concede that it was only five or six times over a period of
four-to-five years. The effect was that he was exaggerating his evidence to overemphasise the freedom afforded to
the claimant. I found Mr Abu's evidence on the claimant's duties, and the demands made upon her, to be
particularly unsatisfactory. For example, he asserted at one point that the whole family shared in the ironing,
including himself. When pressed, he had to concede the claimant did 50% of the ironing. He said that in the early
days, after the claimant had taken the defendants' daughter to school and their son remained at home, as the son
was autistic and withdrawn the claimant had little to do. He completely failed to take into account that if the claimant
had not been there, some form of paid help would have been required to care for his son, who did not go to full time
education until September 2008. Before then he had attended nursery for differing periods. I accept the claimant's
evidence that although assisted from time to time by members of the Abu family, it was her duty, as stated in her
terms and conditions and which she fulfilled, to take both children to nursery or to school.
63

So far as other witnesses are concerned, I am satisfied they have done their best to give a truthful account of the
matters upon which they were asked to give evidence. They paint the picture of a contented family group, with no
suggestion the claimant was unhappy or being oppressed in the defendants' household. It is part of human
experience that there is the natural tendency, except when in the company of very close friends, for family members
to avoid revealing tensions and problems to friends and acquaintances outside the family group, particularly in
social situations. It is noticeable that the two witnesses from outside the family, Mrs Enebeli and Mrs Omolere only
spoke of contact with the claimant when part of the defendants' family group with the exception of the birthday party
for Mrs Omolere's daughter referred to above.
64

It is part of the evidence, and I accept, that the claimant has never been subjected to physical restraint or abuse at
the hands of the defendants. Such physical assault as she complains of, preceded her residence with the
defendants, when part of the Eluwole household. I note that the only time she complains of being struck when living
with the defendants, was when Mrs Eluwole became involved in an argument in December 2014. I find that if the
claimant was an untruthful witness, or given to exaggeration, she might have made such allegations to bolster her
case; she has not done so. In addition, she has not stated that she was never paid by the defendants. She accepts
that they paid her college fees. Where these were paid from her own bank account, the defendants provided the
funds. She readily disclosed the fact that she did receive payments both to Prof Katona who has provided


-----

psychiatric report and to Dr McQuade. She has difficulty quantifying the sums as no records were kept. She accepts
that not all the money she was paid was banked.
65

The claimant was plainly a nervous witness and was clearly cowed in the presence of the defendants and their
witnesses, all of whom she knew. She was very anxious whilst giving her evidence. No doubt part of that anxiety is
created by her uncertain immigration status. I reject the assertion made on behalf of the defendants that she is
pursuing this litigation as a means to improve her prospect of obtaining leave to remain in the United Kingdom
permanently. I reject the inference that her evidence has been tailored to achieve that objective.
66

Overall, I have found the claimant's evidence as to the circumstances of her life with the defendants' family to be
truthful but she has, to a certain extent, minimised the amount of freedom that she was allowed to attend college on
her own and, towards the latter end of her period with the defendants, attend church services and activities. I find
that as the claimant's English improved and she became more confident, she was able to spend more time in
church activities and to engage in voluntary work such as the Sanctuary Cleaners group at the Winners Church.
67
**The hours worked by the claimant**

Determining the number of hours that the claimant worked for the defendants is a challenging exercise as none of
the parties have kept any records. Mr Abu told me that it was a relaxed arrangement.
68

I do not accept that it is realistic to find that the claimant has worked 12 hours per day, seven days per week for the
whole period of her employment with the defendant, as asserted by the Schedule of Special Damages composed
on her behalf by her legal advisors. Nevertheless, I find that she worked far longer than the six hours per day for
five days a week provided for in her contract.
69

Prior to the period of maternity leave taken by Mrs Abu, I find that Mrs Abu was out of the home, according to her
own evidence, for a period of approximately 10 hours, allowing for an eight-hour working day and travelling time.
From time to time she would be away from the home for longer periods when she undertook the family shopping on
her way home from work. Once the family moved to Belvedere, Mrs Abu was out of the house for approximately 11
hours. Whilst Mr Abu was in the house for about an hour after Mrs Abu's departure for work, during the week he did
not return home until after Mrs Abu's arrival in the evenings. In any event, it was part of the claimant's duties to get
the children ready for school. After the period of maternity leave between October 2007 and May 2008, Mrs Abu
started to work from home for, generally, two days a week. During that period, although Mrs Abu was on hand to
deal with any particular difficulties which might arise, for example with regard to her autistic son, I find that the
arrangement
**[*1037]**

was that the claimant remained very much on duty to care for the children and deal with housework during the
working day.
70

I find on the balance of probabilities that whilst not actively engaged in taking or collecting the children to or from
school or nursery, the claimant was expected to busy herself about the house in domestic tasks. Although Mrs Abu
may have operated the washing machine, I find that the claimant was expected to assist with laundry by hanging
clothes out on the line and undertaking the bulk of the ironing. I have already commented upon how Mr Abu, in his
evidence, tended to minimise the claimant's tasks.
71

Once Mrs Abu worked from home for two days a week, I find that she played a greater part in taking the children to
or collecting them from school. I also find that there were periods when Mr Abu was on sick leave or on holiday,
when he also participated from time to time in school runs


-----

72

I find that the claimant's duties did not finish once the children were at home. The terms and conditions of her
employment devised by the defendants themselves required the claimant to ensure the children changed out of
school uniform and were provided with warm food when they got home. I find from the claimant's account that she
also assisted with preparing the children for bed.
73

I accept the claimant's evidence that if she wished to go to a church activity at the weekends she would do extra
work on Fridays to accommodate her absence. I find that in the circumstances of the claimant's employment and
residence with the defendants, she had no choice but to comply with the expectations of the household. This
included not only childcare and the school run, but also assistance with housework and cooking for the family.
Those expectations arose not just because of the unspoken expectations arising from the parties' social and
cultural background, but because, I find on the balance of probabilities, the claimant would be criticised for not
assisting. It is particularly relevant in this regard that after the difficulties which arose in regard to the claimant's
attendance at the church conference between 6 and 9 August 2014, the defendants considered that the claimant
had 'left your duties', as they stated in the letter terminating her employment dated 5 March 2015 (p 256). One of
the dates referred to was a Saturday. The letter and the defendants' unconvincing attempts to explain the apparent
contradiction between the content of that letter and their assertions that there was a relaxed arrangement as to their
expectations of the claimant in the performance of household tasks, were particularly damaging to the defendant's
credibility.
74

The conclusions which I draw as to the hours worked by the claimant cannot be precise on the evidence presented
to me. A decision is required, and the court must make a finding using the evidence available. I find on the balance
of probabilities that the claimant worked for at least 10 hours per day during the working week during most of the
period of her employment with the defendants until relationships seriously broke down in late 2014. There may have
been days when she worked shorter hours; this is compensated for on days when she worked longer in order to
accommodate her activities, in particular with the church, at the weekend. She will have had a limited degree of
leisure when the younger children were at nursery, and thereafter when they commence full-time education.
Nevertheless I find that the claimant was expected to undertake housework when the children were not at home.
Any free time during the working day was balanced by the expectation that the claimant would engage in the
preparation of meals for the children during the week and generally for the family at the weekend. She was also
expected to help with clearing up after family meals.
75

She did not of course have any duties with regard to taking the children to school or nursery during the weekends. I
do not consider it is appropriate to include church attendance or other activities at the weekend, with the family as
part of the working day, noting that when the claimant decided to attend a different church in 2012, she was not
prevented from doing so. Nevertheless, she was expected to assist with childcare, housework and food preparation
at the weekends. Accordingly I attribute five hours on Saturdays and Sundays to the claimant's hours of work.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
76

Thus, when calculating the sums outstanding to her following the Master's decision on her entitlement to additional
payment under the 1998 Act, I find that from the commencement of her employment until early September 2014,
the claimant's usual hours of work were 60 hours per week.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
77

Thereafter, the relationships with between the parties seriously broke down. I note that one of the reasons for
argument in early 2015, was that the claimant was no longer working for the defendants. Mrs Eluwole visited the


-----

family in October 2014 and remained for some time. I find on the balance of probabilities that the claimant's working
time in the household diminished considerably between September and the end of January 2015 to approximately
20 hours per week over the whole period. I note that the defendants have not asserted that the claimant refused to
assist at all with the children during that period.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
78
**Was the claimant a victim of trafficking?**

I accept the claimant's evidence that during the whole period she was subject to a degree of control imposed by the
defendants which amounts in the circumstances to intimidation. The intimidation was not physical in the sense of
threats to personal safety, but the claimant lived with the fear that if she did not conform with the defendants'
requirements she would lose her position and this would result in her return to Nigeria. The intimidation was subtle
and in some respects unspoken.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
79

For example, I accept the claimant's evidence that she overheard remarks made by Mr Abu during telephone
conversations that the claimant had 'no choice but to behave', in response to enquiries made by Mrs Eluwole in the
occasional telephone call. I find the claimant's detail about this aspect of the evidence is such that this is an
accurate recollection. The tendency of both defendants to minimise the contributions the claimant made to childcare
and domestic work, their deceitfulness on other matters, in particular the terms and conditions of employment, and
their dealing with the Home Office are such that I find their evidence to be unreliable on these and other details in
the case.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
80

The parties are agreed upon the relevant law, which I have referred to briefly above. I have been assisted by the
evidence of Dr McQuade, who referred in his report to the list of indicators of forced labour published in guidance
notes by the International Labour Organisation (which were referred to in the Supreme Court decision in Hounga v
_Allen_ _[[2014] IRLR 811). In fact the notes have been revised since that decision and there are now 11 indicators.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2X-VY01-DYPB-W2BN-00000-00&context=1519360)_
These are set out in para 32 of his report (p 231) and are abuse of vulnerability; deception; restriction of movement;
isolation; physical and sexual violence; intimidation and threats; retention of identity documents; withholding of
wages; debt bondage; abusive working and living conditions and excessive overtime.
**[*1038]**

Dr McQuade concluded from his interview with the claimant and the other information presented to him that six of
the 11 indicators were present.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
81

I take into account that the claimant was never physically abused, nor was she ever locked into the family home.
She was never kept completely penniless; she received cash payments from time to time. She had the freedom to
go to college and in the latter years to attend voluntary work at church. She also attended a course for voluntary
workers, with the encouragement of Mrs Abu. Nevertheless, the control on an individual does not require physical
restraint, violence, or the threat of violence, to be effective and coercive. I have considered the indicators of forced
labour referred to in Dr McQuade's report. The ILO guidance notes state that the presence of a single indicator may
imply the existence of forced labour. However, in other cases it is necessary to look for several indicators which,
when taken together, point to a forced labour case. I have considered the six indicators identified by Dr McQuade,
with reference to my findings in the present case.


-----

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
82

I find that there was abuse of vulnerability. The claimant was always in a vulnerable situation in the defendants'
household as a migrant on a visa which she believed bound her to work in the defendants household, a belief
reinforced by remarks she said (and I accept) were made by the defendants. The ILO's guidance notes state as to
the concept of vulnerability:

'…[That it can occur] “when an employer takes advantage of a worker's vulnerable position, for example, to
impose excessive working hours or to withhold wages that a forced labour situation may arise. Forced labour is
also more likely in cases of multiple dependency on the employer, such as when the worker depends on the
employer not only for his or her job but also for housing, food …'

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
83

I find that the claimant was in such a position. That the expectation of both herself and the defendants was that she
was 'on duty' in the household for approximately 10 hours per day, was never afforded two complete days off in
each week, and was never provided with five weeks of holiday independent of the defendants' family, amounts to
excessive working hours. She was never paid the wage provided for in her terms and conditions.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
84

As to isolation, I do not find that this was established to the extent provided for in the ILO guidance notes. Although
there is some evidence of complaint by the defendants about the claimant's use of a telephone, and monitoring of
her telephone calls, she was not kept behind closed doors. She did not have any means of communication
confiscated. She was able to attend college, and in the latter years attend a different church to that which was
attended by the defendants' family, contrary to the wishes of the defendants that the family should attend the same
church. It is to be noted, however, that the defendants' attitude to this situation was to join the same church at a
later stage.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
85

The withholding of wages has been established by the decision of Master McCloud.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
86

There were abusive working and living conditions for limited periods during the claimant's employment. She had, as
the defendants' accept, lack of private living space when the family lived in a two-bedroom property in Greenwich.
Thereafter, when they moved to Belvedere, although the claimant had her own room and a degree of privacy, the
son's clothing was kept in that room. The claimant was not able to secure that room to keep herself private. When
the family had visitors in 2014/2015 the claimant was required to vacate that room and use a playroom instead
during winter months. The playroom had been converted from a former garage, and although I find the claimant's
complaints about its conditions to be, to some degree, overstated, it was an invasion of her privacy that she was
required to vacate the room that the defendants had previously allocated to her.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
87

As to intimidation and threats, the ILO guidance notes include not only threats of physical violence (which are not
relevant in this case). A threat can involve denunciation to immigration authorities, loss of wages or access to
housing etc. They can also include insulting or undermining workers as being a form of psychological coercion. In


-----

the present case, the intimidation and threats to and undermining of the claimant's position was insidious and
subtle. There was not a direct threat of denunciation to immigration authorities. However, I find that the defendants
had explained to the claimant that her visa permitted her only to work as a domestic worker within a family home. I
find that comments, such as she had no choice but to behave, that she should not trust people outside the family,
and references to other families who had sent bad and disrespectful girls home were in fact made. I find that they
were intended to persuade the claimant to conform to the family's expectations and they increased the claimant's
sense of vulnerability and dependence on the defendants. I find that the defendants must have been aware of this.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
88

I find that the claimant was exposed to excessive overtime. Although I have not found a constant 12-hour working
day to have been established, nevertheless I find that the claimant's hours grossly exceeded those set out in the
terms and conditions devised by the defendants and I have commented on lack of free time above.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
89

The consequences of Master McCloud's decision taken together with the successive applications to the Home
Office to extend the claimant's visa, and then for permission for permanent leave to remain, necessarily lead to a
finding that the defendants engaged in deceptive practices.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
90

Furthermore, the defendants accept that when the claimant first arrived in the United Kingdom her command of
English was limited. They must have been aware that the documents that they required her to sign for the purposes
of the Home Office could not be read and understood by her. In that she was simply presented with these
documents and asked to sign them, the defendants perpetrated the deception as to the claimant's working
conditions and entitlement to pay against the claimant, as well as against the Home Office. This deception
increased her vulnerability. Whilst I note that Dr McQuade observes that this deception does not sit neatly within the
ILO guidelines, it is nevertheless indicative of intent to exploit the claimant.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
91

Article 2.1 of the Trafficking Directive defines the process of trafficking as involving the:

'recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or transfer of
control over those persons, by means of the threat or use of force or other forms of coercion, of abduction, or
fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of
payments or benefits to achieve the consent of the person having control over another person, for the purpose
of exploitation'.

**[*1039]**

Broken down, Dr McQuade helpfully identifies three factors, the act, the means and the purpose which must be
satisfied for trafficking to have occurred (p 234). Article 2.3 of the Trafficking Directive refers to forced labour or
services.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
92

Whilst I have not been satisfied on the balance of probabilities that arrangements were made during the family visit
to Nigeria in 2004 for the claimant to travel to the United Kingdom, I am satisfied that once she arrived in the United
Kingdom and arrangements were made for her to stay with the defendant family the act, namely the harbouring of


-----

the claimant or the transfer of control over the claimant from Mrs Eluwole to the defendants within the meaning of
art 2.1, was established.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
93

As to the means, I accept there was no physical force or threat. The coercion was much more subtle. Psychological
bonds were imposed upon the claimant by the expectations of the defendants, the claimant's experience, the
parties' social background and cultural expectations with which the defendants were undoubtedly familiar. The
claimant was chained without physical chains. Her position in the defendants' household was vulnerable, with the
ever-present worry of being returned to Nigeria if she did not conform. This situation established the means.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
94

The purpose of this arrangement was to exploit the claimant's services for the provision of childcare and general
domestic help in the defendants' household for limited payment. The claimant provided services of value to the
defendants which enabled them to work full-time, whilst the claimant cared for their children. In addition the claimant
not only looked after herself within the home; she undertook household tasks as described above for the
defendants, sharing with and, I find, relieving them of the burden of such tasks. She did more than might have been
expected of an adult family member. She was in every respect a domestic worker, whose services the defendants
secured without fully complying 'with all the relevant laws in the United Kingdom relating to employment and wages
etcetera', as they falsely represented to the Home Office (eg p 556).

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
95

Accordingly I am satisfied that the defendants abused the claimant's position of vulnerability to keep her in a
position of effective economic servitude. And that the facts required to establish forced labour and therefore
trafficking of the claimant are proved within the meaning of the Trafficking Convention.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
96
**The claim under the National Minimum Wage Act/breach of implied terms of contract**

I have set out my findings as to the hours worked above. I am satisfied that the 30 hours per week referred to in the
claimant's terms and conditions amounts to 'salaried hours worked' within the meaning of the classifications under
the National Minimum Wage Regulations 1999, _[SI 1999/584. Given that those terms and conditions provided for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW8-2N90-TX08-C01Y-00000-00&context=1519360)_
additional hours to attract a wage of £7.60 per hour, I find that additional work constituted 'time work' for the
purposes of the regulations.
97

Section 28(3) of the 1998 Act provides that where in civil proceedings a person seeks to recover on a claim in
contract an amount described as additional remuneration in s 17(1) (that is, the underpayment of the national
minimum wage as calculated under that section) it is presumed for the purpose of the proceedings that the worker
in question was remunerated at a rate less than the national minimum wage unless the contrary is established.
Accordingly, the burden of proof of the amounts the claimant was paid and the hours for which she was paid rests
on the defendants. The defendants had a statutory duty to maintain records under s 9 of the 1998 Act and the
regulations made under that Act. They have failed to do so. Mr Abu sought to excuse this by saying that this was a
relaxed arrangement.
98

Given the lack of any reliable documentation or precise evidence as to the hours the claimant worked and the
precise amounts she was paid, it is impossible to make a precise calculation of the amount to which she is entitled


-----

under the 1998 Act following the Master's judgment. The court can only do its best using the material which is
available.
99

The claimant has conceded that she did receive some payments from time to time. In his witness statement for the
trial, the first defendant maintained that the claimant was paid a minimum of £200 every month outside of other
cash payments in the middle of the month which amounted to about £300 per month. Mrs Abu did not quantify the
amounts paid to the claimant. In cross-examination both defendants denied that any part of the alleged £200
payment was made to the claimant for expenses such as college fees, visas and payments to the claimant's
mother. The defendants produced a table of payments made on the claimant's behalf included in the trial bundle at
p 340. The total amount is £7,190.60 over nine-and-a-half years, namely £63 per month.
100

Mrs Abu said that her bank statements would not show withdrawals for cash payments to the claimant because
these were made by her husband from his account and he would hand them over to her. Mr Abu produced his bank
statements on the fourth day of the trial for the first time. They were heavily redacted. They did not cover the
complete period. Whilst they show cash withdrawals made, usually, after his own pay was received, the withdrawals
vary and there are only 13 single withdrawals of £200. Mr Abu's explanation for the multiple withdrawals on a single
day was that he would call Mrs Abu and find out how much cash she needed to make up the claimant's pay of
£200. The explanation is inconsistent with Mrs Abu's account of how the cash was made up, to pay to the claimant
and is of no assistance to the court. The defendants have been unable to provide any convincing explanation as to
why they simply did not pay the claimant by bank transfer once a bank account had been set up for her in 2006. Mr
Abu said that the claimant preferred to be paid in cash. However he admitted that she had never said so. There is
evidence in both Mr Abu's and the claimant's bank statements that he did on occasion transfer money to the
claimant.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
101

Accordingly I find that the defendants have failed to prove on the balance of probabilities that the claimant was
regularly paid £200 per month, or indeed any specific regular sum in the course of her employment save for a short
period between May and July 2014.
102

The claimant, by contrast, has accepted that minimal payments were made to her. She has been able to account
for £3,730 of payments and volunteered that she received cash payments of £200 for a few months in 2014
following the visit to the solicitor. It is noted that a withdrawal of an exact amount of £200 does appear in Mr Abu's
bank statements in each of the months from May to July 2014.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
103

Other than the accommodation offset provided for in the 1999 Regulations, only payments made directly to the
claimant may be offset against the defendants' minimum wage liability. Pursuant to reg 9(a) of the 1999
Regulations, sums paid for visas, courses, books and other items cannot be offset against the national minimum
wage liability. In relation to such payments, the first defendant accepted that the claimant had never asked him to
pay sums to her mother on her behalf. Accordingly, I disre
**[*1040]**

gard any such payments, the precise amount and number of which have not been proved in any event, with the
exception of one payment of £95.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
104


-----

Noting the claimant's concession that she did receive cash payments from time to time from the defendants, I find
on the balance of probabilities that these will have exceeded the figure for which she has been able to account, but
it is impossible to say by how much. Accordingly the court must fall back on the burden of proof imposed upon the
defendants by the 1998 Act, which has not been discharged. Conversely, the court must guard against
overcompensating the claimant. I find on the balance of probabilities that it is likely that over the course of the nine
and a half years that the claimant worked for the defendants she will have received payment in cash of
approximately £100 per month over the whole period, rising to £200 per month, for three months during May to July
2014. The figure of £3730 which she can account for, is included in this figure. Accordingly, from the payments due
to be made to the claimant under the 1998 Act, the payments I find were probably made are to be deducted.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
105
**Breach of Contract**

So far as the claim for breach of contract is concerned, I note the provisions of s 17 of the 1998 Act which
effectively implies into a contract a right for additional remuneration as defined in that section. The claim for breach
of contract does not add anything to the claimant's claim under the 1998 Act, save that I find there was a breach of
the terms and conditions in failing to provide the claimant with free time and holidays as provided for, and failure to
provide private accommodation. Any further compensation will be dealt with in the claim for personal injury and
distress referred to below.

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
106
**Limitation**

[As the claimant's claim for a minimum wage is a claim in contract the primary limitation period is provided for in s 5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0M0-TWPY-Y0NT-00000-00&context=1519360)
of the Limitation Act 1980 and is six years. Accordingly as the claimant's claim was issued on 28 October 2015 any
claim in respect of a breach prior to 28 October 2009 is, prima facie, time barred under that section. However, on
the evidence which I have heard, I find that the claimant is entitled to rely on s 32(1)(b) and (2) of the 1980 Act.
107

Section 32(1)(b) provides that:

'(1) … Where in the case of any action for which a period of limitation is prescribed by this Act, either—

(a)…

(b) any fact relevant to the plaintiff's right of action has been deliberately concealed from him by the defendant
or …

the period of limitation shall not begin to run until the plaintiff has discovered the fraud concealment or mistake
(as the case may be) or could with reasonable diligence have discovered it.'

108

Section 32(2) of the 1980 Act provides that:

'For the purposes of sub-section (1) deliberate commission of a breach of duty in circumstances in which it is
unlikely to be discovered for some time amounts to a deliberate concealment of the facts involved in that
breach of duty.'

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
109

Section 32 will operate to delay the date on which time starts to run where a defendant is guilty of deliberate
wrongdoing and conceals or fails to disclose it in circumstances where it is unlikely to be discovered for some time:


-----

see _Cave v Robinson Jarvis & Rolfe [2002] UKHL 18,_ _[[2002] 2 All ER 641, at 647. I find that the defendants](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-60HK-00000-00&context=1519360)_
deliberately withheld from the claimant the fact that they were representing to the Home Office that they were
complying with UK employment laws when plainly they were not. They knew that she was unable to read, write or
sufficiently understand English in order to comprehend the terms and conditions documents which she signed over
successive years. Even by September 2009, the claimant was still assessed at Pre-Entry ESOL level by the Adult
Education College in Bexley (p 656).

_[5100](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5PRD-0JM1-DYNP-N2H4-00000-00&context=1519360)_
110

Mrs Abu admitted in cross-examination that she knew she was obliged to pay the claimant the minimum wage by
the Home Office requirements. She accepted that she did not believe the defendants were exempt from that
obligation because the claimant was a member of the family. I find there was a deliberate breach of duty which was
not disclosed to the claimant and this was committed in circumstances where the claimant was unlikely to discover
it for some time. I accept the claimant's evidence given in her witness statement that she did not truly understand
the effect of the document she was signing until about 2012, but in any event, I find that such understanding did not
arise until after October 2009.
111
**Harassment**

In considering whether the defendants have engaged in conduct which amounts to harassment to the claimant, I
take into account my findings that the claimant has been the victim of trafficking and that there was an unequal
[power relationship between the parties. The claim is brought under ss 1 and 3 of the Protection from Harassment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y18X-00000-00&context=1519360)
Act 1997 (the '1997 Act'). Section 1(1) provides that a person must not pursue a course of conduct:

(a)   Which amounts to harassment of another

(b)   Which he knows or should know amounts to harassment of the other.

Section 3 of the Act provides for a victim to bring a claim in Civil Proceedings for damages. Section 7 of the 1997
Act provides guidance into interpretation which I have taken into account.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
112

I have also been assisted by the remarks of the Court of Appeal in the decision of _Veakins v Kier Islington Ltd_

_[[2009] EWCA Civ 1288, [2010] IRLR 132. Kay LJ referred to the earlier judgment of Lord Nicholls in Majrowski v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XN4-5070-Y9JK-R52D-00000-00&context=1519360)_
_Guy's and St Thomas' NHS Trust_ _[[2006] UKHL 34, [2006] IRLR 695 in which it was observed that 'courts are well](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1CV-00000-00&context=1519360)_
able to recognise the boundary between conduct which is unattractive, even unreasonable, and conduct which is
oppressive and unacceptable'. Kay LJ went on to observe that 'courts have been enjoined to consider whether the
conduct complained of is “oppressive and unacceptable” as opposed to merely unattractive, unreasonable or
regrettable. The primary focus is on whether the conduct is oppressive and unacceptable albeit the court must keep
in mind that it must be of an order which “would sustain criminal liability” '.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
113

I find that much of the behaviour relied upon by the claimant as amounting to harassment whilst being unattractive,
regrettable and sometimes unreasonable does not cross the boundary into conduct which I find to be oppressive
and unacceptable until the later stages of the claimant's employment by the defendants.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
114


-----

The first event which I find amounts to harassment within the meaning of the 1997 Act, is the confiscation of the
claimant's keys to the house, following an argument in mid February 2015. There had been an earlier argument
resulting from Mrs Abu and Mrs Eluwole learning about contact between their mother and the claimant's mother in
Nigeria, in which they considered that the claimant's mother had insulted their own mother. There was a heated
argument. After the argument tensions continued and the defendants told the claimant on
**[*1041]**

13 February that they were proposing to terminate her employment. On 16 February 2015 the arguments between
the parties became so bad that Mr Akinwale was asked to intervene. His evidence was that he called the police,
because he was concerned about the behaviour on both sides. I also find, on his evidence that he was seeking to
pre-empt an allegation of mistreatment of the claimant by the defendants.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
115

I should make it clear that I make no finding that there was any use or threat of violence from the defendants
against the claimant. Nevertheless the removal of keys had the effect of causing alarm and distress to the claimant.
This was her only home in the United Kingdom. She had no other accommodation to go to. While she had made
friends and acquaintances at college and at church, there was no one to whom she could reasonably be asked to
return for help in these circumstances, although her telephone usage indicates that she was making a number of
calls. In addition, her lack of regular payment from the defendants was such that she had very little by way of
financial means to assist her if she had to find alternative accommodation. Although Mrs Abu had made enquires as
to alternative employment for the claimant, the claimant did not find the terms on offer to be acceptable. Mrs Abu
accepted that she made no enquires herself as to whether the employment was suitable for the claimant.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
116

Thereafter I find the defendants' letter of dismissal of the claimant dated 5 March 2015 was part of a course of
conduct calculated to cause the claimant alarm and distress. Whilst I accept that the defendants were entitled to
dismiss the claimant as her employers, the terms of the letter, which required her to leave the house, when the
defendants must have known that the claimant had no access to or means to pay for, alternative accommodation
was oppressive. The defendants had, I find, informed the claimant on more than one occasion that her visa required
her to work as a domestic worker in a domestic household and that if she did not do so she would have to leave the
United Kingdom. I find that the terms of the letter and the requirement that the claimant leave the family home,
bearing in mind the unequal relationship between the parties and the claimant's vulnerability as to finding alternative
accommodation, amounted to harassment.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
117

Finally, the placing of the claimant's belongings on the street and locking her out on the 14 March was an act of
cruelty. It was also harassment within the meaning of the 1997 Act. The claimant was a young woman in vulnerable
position. However strained Mrs Abu may have felt the atmosphere in the house had become, simply packing up the
claimant's belongings and putting them out on the street, without warning, whilst the claimant was out of the house,
so that she returned, finding herself unable to gain entrance even though the family were within, was calculated to
cause alarm and distress.

_[900](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
118

Accordingly I find that the defendants have pursued a course of conduct between December 2014 and 14 March
2015 which amounts to harassment within the meaning of the 1997 Act and the claimant is entitled to damages.


-----

_[900, 999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
119
**Quantum**

I am satisfied that the defendants are in breach of the claimant's contract in failing to pay her in accordance with
their own terms and conditions or to give her opportunities for independent days off and holidays. I also take into
account the remarks of the Supreme Court in the decision of Hounga v Allen and the requirements of art 15 of the
Trafficking Convention that the United Kingdom should provide a right of victims to compensation from the
perpetrators of trafficking.

_[900, 999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
120

I am satisfied that the acts of harassment that I have found to be proved gave rise to acute distress for the claimant,
the effects of which she still experienced when examined by Professor Katona in January 2016. It is unfortunate
that there has been no update to that report. I note however that Professor Katona observes in para 8 of his report
that subject to being provided with a secure environment and treatment, the claimant's prognosis is excellent.
Regrettably, so far, the claimant has not received such formal treatment. This case bears some similarity with the
decision in NAWA v Yousuf 2010, unreported, although the conditions in which the claimant was expected to work
was not as bad as they were in that case. I accept the claimant's submissions that some guidance as to the
measure of damages to be adopted can be found in the decision of the Court of Appeal in Vento v Chief Constable
_of West Yorkshire Police_ _[[2010] IRLR 132 which have been revised in the Presidential Guidance on Employment](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XN4-5070-Y9JK-R52D-00000-00&context=1519360)_
Tribunal Awards etc published by Judge Simon and Judge Doyle on 5 September 2017.

_[900, 999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7K1-DYNP-N0JJ-00000-00&context=1519360)_
121

I find that the claimant is entitled to damages for injury to feelings and psychiatric injury at a level in the lower half of
the top band of the _Vento Guidance. Accordingly, for the injury to feelings arising from the trafficking, and the_
breach of contract, I make an award of £30,000. I make an additional award of £9,000 for the psychiatric injury
amounting to £39,000 in all.
122
**Disadvantage in the Labour Market**

Noting that the prognosis for the claimant's psychiatric injury is good and that the claimant is as much at a
disadvantage from her uncertain immigration status and lack of formal qualifications as she is from the
circumstances which give rise to these proceedings, I do not consider that the claimant is entitled to an award for
disadvantage in the labour market.
123
**Special Damages**

The claimant seeks £3,500 being the cost of Cognitive Behavioural Therapy Treatment as recommended by
Professor Katona. This figure has not been challenged and accordingly I make an award in that sum.
124
**Conclusion**

For the reasons stated, I find that the claimant has been the victim of trafficking. She has also been subjected to
harassment within the meaning of the 1997 Act. The claimant is entitled to an award of £39,000 in general damages
for the reasons given in para 120 above.
125

The claimant is also entitled, as the Master found, to an award under the National Minimum Wage Act 1997 which
should be calculated on the basis of my findings given in paras 76, 77 and 103 above. Due to pressure of time, I
have not been able to carry out and check appropriate calculations. I invite the parties to make and agree the
i t fi


-----

126

I invite the parties to agree upon and calculate the appropriate rates and award of interest in order to provide the
final Judgment sum.

**End of Document**


-----

