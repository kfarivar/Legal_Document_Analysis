# R v Khan [2023] EWCA Crim 1238

Court of Appeal, Criminal Division

Macur LJ, May J, Heather Williams J

4 October 2023Judgment

MR J MANNING appeared on behalf of the Applicant.

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. MRS JUSTICE MAY: On 11 April 2022, at the Central Criminal Court, following a trial before HHJ

Lickley KC and a jury, the applicant and his co‑defendant, Jordan Curtis, were convicted by a majority of

one count of attempted murder. This is a renewed application for an extension of time of 44 days and for
leave to appeal conviction following refusal by the single judge. There is also an application made under
section 23 of the Criminal Appeal Act 1968 for permission to adduce fresh evidence in the form of the
Home Office Single Competent Authority's Conclusive Grounds Decision, confirming that the applicant is a
victim of modern slavery.

**_The Facts_**

2. The facts of the offending and details of the evidence relied on by the prosecution at trial are fully set
out in the Court of Appeal Office summary, it is unnecessary to repeat them all here. In short, the victim,
Ellie Mullen, then aged 17, was approached by two young men on 26 August 2020, one of whom stabbed
her multiple times, whilst the other, a boy whom she knew as Jordan Curtis, stood by and encouraged him.
The applicant was then aged 16 years and 11 months. After the stabbing, the applicant ran off and was

arrested nearby. An 8‑inch kitchen knife was found under a car next to him. In interview the applicant

made no comment.

3. By the time of trial, at which he gave evidence, the applicant had accepted that he had stabbed Ms
Mullen but he said he had little memory of it, he had acted at all times under the influence of drugs and
could not have formed the necessary intention to kill. In convicting him, the jury plainly rejected his
account.

**_Grounds_**


-----

4. Mr Manning, who appears pro bono for the applicant and for whose clear written advice and oral
submissions we are grateful, takes two points. First, he submits that the judge was wrong to have
permitted the prosecution to amend the indictment, shortly before trial, to remove a bladed article count.
Next, Mr Manning says that the judge erred in refusing to permit hearsay evidence of an expert
psychiatrist, Dr Iankov, to be adduced before the jury at trial. Mr Manning argues that the Crown's purpose
in removing the bladed article count was to prevent the jury from learning about the **_modern slavery_**
aspect of the case. He points out that, whilst section 45A of the Modern Slavery Act 2015 provides the
victim of modern slavery with a defence to many criminal charges, that section does not apply to murder
or attempted murder, or offences under section 18 or section 20 of the Offences Against the Persons Act
1861. Deleting the bladed article count, leaving just the single count of attempted murder, to which the
offences under section 18 and section 20 are implicit alternatives, removed the opportunity for the defence
to deploy the **_modern slavery defence under section 45A of the 2015 Act. He submits that the Single_**
Competent Authority's Decision should be admitted on this appeal in support of his case on this point. He
stresses that the applicant is, and was, a vulnerable young person and that information about his
background as a victim of **_modern slavery should have been put before the jury. Permitting the_**
prosecution to take the bladed article off the indictment accordingly undermined the fairness of trial.

5. In his written advice, Mr Manning referred to the House of Lords decision in R v Asfaw [2008] UKHL 31,
and to the observations of Lord Bingham in that case, to the effect that manipulation of the indictment to
prevent a defendant relying on a defence, can amount to an abuse of process.

6. Mr Manning's next point related to the evidence of Dr Iankov. He argues that passages from a report
prepared by the doctor on his client should have been permitted to be read to the jury as hearsay
evidence. Dr Iankov had been the applicant's treating psychiatrist at the time of his remand to youth
detention following his arrest in August 2020, when he had raised concerns about the applicant's fitness to
plead. In the event, following his being seen by two other psychiatrists, the applicant was found fit for trial.
However, Dr Iankov had by then been asked to prepare, and had prepared, a second report addressing a
number of matters specifically raised with him by the applicant's solicitors, including in relation to the matter
of intent. Dr Iankov appeared and gave evidence before the jury shortly before the applicant was called to
give evidence, specifically and only at that stage, to explain the applicant's presentation as contemplated
[and discussed in the case of R v Mulindwa [2017] EWCA Crim 416. There was discussion, in the absence](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMS-JRM1-DYJ0-60F8-00000-00&context=1519360)
of the jury at the time, as to whether Dr Iankov would be permitted to be recalled at the appropriate time to
give evidence going to the issue of intent, the judge indicating that further argument would be required.

7. By the time the trial reached the point at which Dr Iankov's further evidence might have been
introduced, he had gone abroad on annual leave. Thereafter, for reasons which are unexplained, he

refused to co‑operate with the applicant's representatives. The defence accordingly applied to adduce

relevant parts of the psychiatrist's second report as hearsay. The judge refused, on the basis that intent
was a matter for the jury, and that in any event the lack of clarity in the report, combined with the inability of
the jury to hear any clarification through questioning of the psychiatrist, told against allowing the evidence
in under the hearsay provisions. Further, he held there had been insufficient explanation as to why Dr
Iankov had not attended, for instance, by video link, to be questioned.

8. Mr Manning argues that the judge was wrong so to hold. That the jury were left with no assistance as to
how to approach the question of the applicant's intent in the context of his learning disability, cognitive
impairment and drug consumption, and that the applicant was unfairly prejudiced at his trial thereby.

**_Decision_**

9. We refuse both the extension of time and leave to appeal essentially for the reasons given by the single
judge. We also refuse the application to admit further evidence, under section 23, as it would make no
difference to our decision. The prosecution were entitled to remove the bladed article count. In
circumstances where, as we now understand, the applicant would have had a defence to that count under
section 45A, fairness and the public interest must have been against pursuing the applicant on that charge.
In any event, being a victim of modern slavery provides no defence to a charge of attempted murder or
the lesser alternatives to that charge Evidence about modern slavery could not have been relevant to


-----

the jury's consideration of whether or not the applicant stabbed Ms Mullen intending to kill her. It would be,
and doubtless was, relevant as mitigation following a finding of guilt but not before. Indeed, if the bladed
article count had remained, the judge would have been bound to direct the jury to ignore the **_modern_**
**_slavery evidence when considering the charge of attempted murder. The case of Asfaw involved entirely_**
different circumstances. There was no question of abuse of process here, where the prosecution had
given notice of its intention to remove the bladed article count immediately after the applicant had served a
Defence Statement accepting that he had stabbed Ms Mullen.

10. As to Dr Iankov's evidence, we see no reason to interfere with the judge's exercise of his discretion not
to admit this evidence as hearsay. Indeed, we cannot see how he could have decided differently, in
circumstances where the passages intended to be relied upon were unclear and unexplained, and where
the judge was not satisfied that sufficient steps had been taken to secure Dr Iankov's attendance. We
asked Mr Manning whether, in the light of the judge's comment, he had asked for an adjournment in order
to obtain the necessary psychiatric evidence; he thought that he had not.

11. We are not satisfied that the absence of such evidence renders the conviction unsafe. The jury had
evidence from the applicant as to the drugs he had taken. They were able to assess that evidence by
reference to his age and presentation. They were given an intoxication direction.

12. Dr Iankov would not have been entitled to give any opinion as to the applicant's actual intention, that
being a matter for the jury on the evidence. The doctor's report did not address the factual evidence of
what the applicant said, as he stabbed Ms Mullen, namely “I'm going to kill you, I'm going to kill you”, and
his absence meant that he could not be asked about it. All of this was fully considered by the judge at the
time. We endorse and adopt the single judge's description of HHJ Lickley's decision as “unimpeachable”.

13. For those reasons, we refuse the extension of time, refuse leave and decline to admit the further
evidence under section 23.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

